//! The module `Check.Types.Recording`, from `target/bootstrap/src/prismc/check/types/recording.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// AtHere: fn St, Range -> SrcAt
/// ```
pub fn at_here_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range) -> crate::check::typed::SrcAt {
    crate::check::typed::SrcAt { file_p: st_p0.file_p.clone(), span_p: span_p1.clone() }
}

/// ```prism
/// NoteTy: fn St, Range, Ty -> St
/// ```
pub fn note_ty_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, t_p2: &crate::check::types::Ty) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.exprs_p = crate::prelude::push(&this.typed_p.exprs_p, &crate::check::typed::TyNote { at_p: at_here_f(st_p0, span_p1), ty_p: t_p2.clone() });
            this
        }
    }
}

/// ```prism
/// NoteFaultAt: unbounded fn St, Range, Ty, Ty -> St
/// ```
pub fn note_fault_at_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, expected_p2: &crate::check::types::Ty, found_p3: &crate::check::types::Ty) -> crate::check::types::St {
    match walk_f(st_p0, found_p3) {
        crate::check::types::Ty::TyCon(m1383_0_0, m1383_0_1) if (&m1383_0_0 == &crate::prelude::Text::lit("Prelude.Error")) && ((&m1383_0_1).len() == 0) => {
            let mut this: crate::check::types::St = st_p0.clone();
            this.fault_qs_p = crate::prelude::push(&this.fault_qs_p, &crate::check::types::Waiting { expected_p: expected_p2.clone(), found_p: found_p3.clone(), span_p: span_p1.clone(), file_p: st_p0.file_p.clone() });
            this
        },
        crate::check::types::Ty::TyCon(m1383_1_0, _) if (&m1383_1_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) => ask_plain_at_f(st_p0, span_p1, expected_p2),
        crate::check::types::Ty::TySig(m1383_2_0, inner_p4) if (&m1383_2_0 == &crate::prelude::Text::lit("$")) => note_plain_under_f(st_p0, span_p1, expected_p2, &*inner_p4),
        crate::check::types::Ty::TySig(m1383_3_0, inner_p5) if (&m1383_3_0 == &crate::prelude::Text::lit("!")) => note_plain_under_f(st_p0, span_p1, expected_p2, &*inner_p5),
        _ => st_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `NoteFaultAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NoteFaultAt: unbounded fn St, Range, Ty, Ty -> St
/// ```
pub struct NoteFaultAt {
    pub st_p0: crate::check::types::St,
    pub span_p1: crate::syntax::Range,
    pub expected_p2: crate::check::types::Ty,
    pub found_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::St> for NoteFaultAt {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let span_p1 = &self.span_p1;
        let expected_p2 = &self.expected_p2;
        let found_p3 = &self.found_p3;
        let expected_p2x = expected_p2.clone();
        let found_p3x = found_p3.clone();
        let span_p1x = span_p1.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(start_walk_f(st_p0x.clone(), found_p3x.clone()), move |walk_f_1389: crate::check::types::Ty| match walk_f_1389 {
            crate::check::types::Ty::TyCon(m1383_0_0, m1383_0_1) if (&m1383_0_0 == &crate::prelude::Text::lit("Prelude.Error")) && ((&m1383_0_1).len() == 0) => ::prism_rtl::Turn::Finished({
                let mut this: crate::check::types::St = st_p0x.clone();
                this.fault_qs_p = crate::prelude::push(&this.fault_qs_p, &crate::check::types::Waiting { expected_p: expected_p2x.clone(), found_p: found_p3x.clone(), span_p: span_p1x.clone(), file_p: st_p0x.file_p.clone() });
                this
            }),
            crate::check::types::Ty::TyCon(m1383_1_0, _) if (&m1383_1_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) => ::prism_rtl::Turn::Finished(ask_plain_at_f(&st_p0x, &span_p1x, &expected_p2x)),
            crate::check::types::Ty::TySig(m1383_2_0, inner_p4) if (&m1383_2_0 == &crate::prelude::Text::lit("$")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NotePlainUnder { st_p0: st_p0x.clone(), span_p1: span_p1x.clone(), expected_p2: expected_p2x.clone(), inner_p3: (*inner_p4).clone() })),
            crate::check::types::Ty::TySig(m1383_3_0, inner_p5) if (&m1383_3_0 == &crate::prelude::Text::lit("!")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NotePlainUnder { st_p0: st_p0x.clone(), span_p1: span_p1x.clone(), expected_p2: expected_p2x.clone(), inner_p3: (*inner_p5).clone() })),
            _ => ::prism_rtl::Turn::Finished(st_p0x.clone()),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start NoteFaultAt, x`: what the function value is when passed to `@Run`.
pub fn start_note_fault_at_f(st_p0: crate::check::types::St, span_p1: crate::syntax::Range, expected_p2: crate::check::types::Ty, found_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(NoteFaultAt { st_p0, span_p1, expected_p2, found_p3 })
}

/// ```prism
/// NotePlainUnder: unbounded fn St, Range, Ty, Ty -> St
/// ```
pub fn note_plain_under_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, expected_p2: &crate::check::types::Ty, inner_p3: &crate::check::types::Ty) -> crate::check::types::St {
    match walk_f(st_p0, inner_p3) {
        crate::check::types::Ty::TyCon(m2038_0_0, _) if (&m2038_0_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) => ask_plain_at_f(st_p0, span_p1, expected_p2),
        _ => st_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `NotePlainUnder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NotePlainUnder: unbounded fn St, Range, Ty, Ty -> St
/// ```
pub struct NotePlainUnder {
    pub st_p0: crate::check::types::St,
    pub span_p1: crate::syntax::Range,
    pub expected_p2: crate::check::types::Ty,
    pub inner_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::St> for NotePlainUnder {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let span_p1 = &self.span_p1;
        let expected_p2 = &self.expected_p2;
        let inner_p3 = &self.inner_p3;
        let expected_p2x = expected_p2.clone();
        let inner_p3x = inner_p3.clone();
        let span_p1x = span_p1.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(start_walk_f(st_p0x.clone(), inner_p3x.clone()), move |walk_f_2044: crate::check::types::Ty| match walk_f_2044 {
            crate::check::types::Ty::TyCon(m2038_0_0, _) if (&m2038_0_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) => ::prism_rtl::Turn::Finished(ask_plain_at_f(&st_p0x, &span_p1x, &expected_p2x)),
            _ => ::prism_rtl::Turn::Finished(st_p0x.clone()),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start NotePlainUnder, x`: what the function value is when passed to `@Run`.
pub fn start_note_plain_under_f(st_p0: crate::check::types::St, span_p1: crate::syntax::Range, expected_p2: crate::check::types::Ty, inner_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(NotePlainUnder { st_p0, span_p1, expected_p2, inner_p3 })
}

/// ```prism
/// AskPlainAt: fn St, Range, Ty -> St
/// ```
pub fn ask_plain_at_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, expected_p2: &crate::check::types::Ty) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.plain_qs_p = crate::prelude::push(&this.plain_qs_p, &crate::check::types::Waiting { expected_p: expected_p2.clone(), found_p: expected_p2.clone(), span_p: span_p1.clone(), file_p: st_p0.file_p.clone() });
    this
}

/// ```prism
/// PlainNotes: unbounded fn St -> [SrcAt]
/// ```
pub fn plain_notes_f(st_p0: &crate::check::types::St) -> crate::prelude::Array<crate::check::typed::SrcAt> {
    crate::prelude::run_to_end(crate::prelude::fold_job(st_p0.plain_qs_p.clone(), crate::prelude::Array::new(), {
        let st_p0x = st_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::typed::SrcAt>, crate::check::types::Waiting)| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p1 = p0;
                let q_p2 = p1;
                {
                    let joined_plain_p3 = match &q_p2.expected_p {
                        crate::check::types::Ty::TyFlex(n_p5) => crate::check::types::has_nat_f(&st_p0xy.plain_arms_p, n_p5),
                        _ => false,
                    };
                    crate::prelude::call_then(start_walk_f(st_p0xy.clone(), q_p2.expected_p.clone()), move |walk_f_3061: crate::check::types::Ty| {
                        let wanted_p4 = match walk_f_3061 {
                            crate::check::types::Ty::TySig(m3055_0_0, inner_p6) if (&m3055_0_0 == &crate::prelude::Text::lit("$")) => (*inner_p6).clone(),
                            crate::check::types::Ty::TySig(m3055_1_0, inner_p7) if (&m3055_1_0 == &crate::prelude::Text::lit("!")) => (*inner_p7).clone(),
                            other_p8 => other_p8,
                            _ => unreachable!("no arm matched"),
                        };
                        if joined_plain_p3 || crate::check::types::is_plain_collection_f(&st_p0xy, &wanted_p4) {
                            ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p1, &crate::check::typed::SrcAt { file_p: q_p2.file_p.clone(), span_p: q_p2.span_p.clone() }))
                        } else {
                            ::prism_rtl::Turn::Finished(acc_p1.clone())
                        }
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::typed::SrcAt>, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::typed::SrcAt>>>>
    }))
}

/// The step machine of `PlainNotes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainNotes: unbounded fn St -> [SrcAt]
/// ```
pub struct PlainNotes {
    pub st_p0: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::check::typed::SrcAt>> for PlainNotes {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::check::typed::SrcAt>> {
        let st_p0 = &self.st_p0;
        crate::prelude::fold_job(st_p0.plain_qs_p.clone(), crate::prelude::Array::new(), {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::typed::SrcAt>, crate::check::types::Waiting)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p1 = p0;
                    let q_p2 = p1;
                    {
                        let joined_plain_p3 = match &q_p2.expected_p {
                            crate::check::types::Ty::TyFlex(n_p5) => crate::check::types::has_nat_f(&st_p0xy.plain_arms_p, n_p5),
                            _ => false,
                        };
                        crate::prelude::call_then(start_walk_f(st_p0xy.clone(), q_p2.expected_p.clone()), move |walk_f_3061: crate::check::types::Ty| {
                            let wanted_p4 = match walk_f_3061 {
                                crate::check::types::Ty::TySig(m3055_0_0, inner_p6) if (&m3055_0_0 == &crate::prelude::Text::lit("$")) => (*inner_p6).clone(),
                                crate::check::types::Ty::TySig(m3055_1_0, inner_p7) if (&m3055_1_0 == &crate::prelude::Text::lit("!")) => (*inner_p7).clone(),
                                other_p8 => other_p8,
                                _ => unreachable!("no arm matched"),
                            };
                            if joined_plain_p3 || crate::check::types::is_plain_collection_f(&st_p0xy, &wanted_p4) {
                                ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p1, &crate::check::typed::SrcAt { file_p: q_p2.file_p.clone(), span_p: q_p2.span_p.clone() }))
                            } else {
                                ::prism_rtl::Turn::Finished(acc_p1.clone())
                            }
                        })
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::typed::SrcAt>, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::typed::SrcAt>>>>
        }).cycle()
    }
}

/// `Start PlainNotes, x`: what the function value is when passed to `@Run`.
pub fn start_plain_notes_f(st_p0: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::typed::SrcAt>>> {
    ::std::rc::Rc::new(PlainNotes { st_p0 })
}

/// ```prism
/// UnifyAt: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub fn unify_at_f(st_p0: &crate::check::types::St, expected_p1: &crate::check::types::Ty, found_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    unify_noted_f(&note_fault_at_f(st_p0, span_p3, expected_p1, found_p2), expected_p1, found_p2, span_p3)
}

/// The step machine of `UnifyAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyAt: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub struct UnifyAt {
    pub st_p0: crate::check::types::St,
    pub expected_p1: crate::check::types::Ty,
    pub found_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for UnifyAt {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let expected_p1 = &self.expected_p1;
        let found_p2 = &self.found_p2;
        let span_p3 = &self.span_p3;
        let expected_p1x = expected_p1.clone();
        let found_p2x = found_p2.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(start_note_fault_at_f(st_p0x.clone(), span_p3x.clone(), expected_p1x.clone(), found_p2x.clone()), move |note_fault_at_f_3792: crate::check::types::St| ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyNoted { st_p0: note_fault_at_f_3792, expected_p1: expected_p1x.clone(), found_p2: found_p2x.clone(), span_p3: span_p3x.clone() })))
    }
}

/// `Start UnifyAt, x`: what the function value is when passed to `@Run`.
pub fn start_unify_at_f(st_p0: crate::check::types::St, expected_p1: crate::check::types::Ty, found_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(UnifyAt { st_p0, expected_p1, found_p2, span_p3 })
}

/// ```prism
/// UnifyNoted: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub fn unify_noted_f(st_p0: &crate::check::types::St, expected_p1: &crate::check::types::Ty, found_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    'm4451: {
        let scrutinee = &walk_f(st_p0, found_p2);
        if let crate::check::types::Ty::TyCon(m4451_0_0, m4451_0_1) = scrutinee && (m4451_0_0 == &crate::prelude::Text::lit("Prelude.Error")) && (m4451_0_1.len() == 0) {
            break 'm4451 match walk_f(st_p0, expected_p1) {
                crate::check::types::Ty::TySig(m4506_0_0, _) if (&m4506_0_0 == &crate::prelude::Text::lit("~")) => st_p0.clone(),
                crate::check::types::Ty::TyFlex(n_p4) if !info_of_f(st_p0, &n_p4).plain_p => {
                    let (v_p5, st2_p6) = fault_var_f(st_p0, span_p3);
                    crate::check::types::unify::unify_f(&st2_p6, expected_p1, &v_p5, span_p3)
                },
                _ => crate::check::types::unify::unify_f(st_p0, expected_p1, found_p2, span_p3),
                _ => unreachable!("no arm matched"),
            };
        }
        if let crate::check::types::Ty::TySig(m4451_1_0, i_p7) = scrutinee && (m4451_1_0 == &crate::prelude::Text::lit("!")) {
            break 'm4451 'm4764: {
                let scrutinee = &(walk_f(st_p0, &**i_p7), walk_f(st_p0, expected_p1));
                if let (crate::check::types::Ty::TyCon(m4764_0_0_0, m4764_0_0_1), crate::check::types::Ty::TySig(m4764_0_1_0, m4764_0_1_1)) = scrutinee && (m4764_0_0_0 == &crate::prelude::Text::lit("Prelude.Error")) && (m4764_0_0_1.len() == 0) && (m4764_0_1_0 == &crate::prelude::Text::lit("!")) && let crate::check::types::Ty::TySig(m4764_0_1_1_r_0, _) = &**m4764_0_1_1 && (m4764_0_1_1_r_0 == &crate::prelude::Text::lit("~")) {
                    break 'm4764 st_p0.clone();
                }
                crate::check::types::unify::unify_f(st_p0, expected_p1, found_p2, span_p3)
            };
        }
        if let crate::check::types::Ty::TyCon(m4451_2_0, m4451_2_1) = scrutinee && (m4451_2_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m4451_2_1.len() == 1) && let ::std::option::Option::Some(c_p8) = crate::prelude::index(m4451_2_1, &crate::prelude::Nat::from(0u32)) {
            break 'm4451 match walk_f(st_p0, expected_p1) {
                crate::check::types::Ty::TyArray(_) => crate::check::types::unify::unify_f(st_p0, expected_p1, &c_p8, span_p3),
                crate::check::types::Ty::TyMap(_, _) => crate::check::types::unify::unify_f(st_p0, expected_p1, &c_p8, span_p3),
                _ => crate::check::types::unify::unify_f(st_p0, expected_p1, found_p2, span_p3),
            };
        }
        crate::check::types::unify::unify_f(st_p0, expected_p1, found_p2, span_p3)
    }
}

/// The step machine of `UnifyNoted`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyNoted: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub struct UnifyNoted {
    pub st_p0: crate::check::types::St,
    pub expected_p1: crate::check::types::Ty,
    pub found_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for UnifyNoted {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let expected_p1 = &self.expected_p1;
        let found_p2 = &self.found_p2;
        let span_p3 = &self.span_p3;
        let expected_p1x = expected_p1.clone();
        let found_p2x = found_p2.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(start_walk_f(st_p0x.clone(), found_p2x.clone()), move |walk_f_4457: crate::check::types::Ty| 'm4451: {
            if let crate::check::types::Ty::TyCon(m4451_0_0, m4451_0_1) = &walk_f_4457 && (m4451_0_0 == &crate::prelude::Text::lit("Prelude.Error")) && (m4451_0_1.len() == 0) {
                break 'm4451 crate::prelude::call_then(start_walk_f(st_p0x.clone(), expected_p1x.clone()), move |walk_f_4512: crate::check::types::Ty| match walk_f_4512 {
                    crate::check::types::Ty::TySig(m4506_0_0, _) if (&m4506_0_0 == &crate::prelude::Text::lit("~")) => ::prism_rtl::Turn::Finished(st_p0x.clone()),
                    crate::check::types::Ty::TyFlex(n_p4) if !info_of_f(&st_p0x, &n_p4).plain_p => {
                        let (v_p5, st2_p6) = fault_var_f(&st_p0x, &span_p3x);
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st2_p6.clone(), expected_p1: expected_p1x.clone(), found_p2: v_p5.clone(), span_p3: span_p3x.clone() }))
                    },
                    _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st_p0x.clone(), expected_p1: expected_p1x.clone(), found_p2: found_p2x.clone(), span_p3: span_p3x.clone() })),
                    _ => unreachable!("no arm matched"),
                });
            }
            if let crate::check::types::Ty::TySig(m4451_1_0, i_p7) = &walk_f_4457 && (m4451_1_0 == &crate::prelude::Text::lit("!")) {
                break 'm4451 {
                    let i_p7x = (**i_p7).clone();
                    crate::prelude::call_then(start_walk_f(st_p0x.clone(), i_p7x.clone()), move |walk_f_4773: crate::check::types::Ty| crate::prelude::call_then(start_walk_f(st_p0x.clone(), expected_p1x.clone()), move |walk_f_4787: crate::check::types::Ty| 'm4764: {
                        let scrutinee = &(walk_f_4773, walk_f_4787);
                        if let (crate::check::types::Ty::TyCon(m4764_0_0_0, m4764_0_0_1), crate::check::types::Ty::TySig(m4764_0_1_0, m4764_0_1_1)) = scrutinee && (m4764_0_0_0 == &crate::prelude::Text::lit("Prelude.Error")) && (m4764_0_0_1.len() == 0) && (m4764_0_1_0 == &crate::prelude::Text::lit("!")) && let crate::check::types::Ty::TySig(m4764_0_1_1_r_0, _) = &**m4764_0_1_1 && (m4764_0_1_1_r_0 == &crate::prelude::Text::lit("~")) {
                            break 'm4764 ::prism_rtl::Turn::Finished(st_p0x.clone());
                        }
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st_p0x.clone(), expected_p1: expected_p1x.clone(), found_p2: found_p2x.clone(), span_p3: span_p3x.clone() }))
                    }))
                };
            }
            if let crate::check::types::Ty::TyCon(m4451_2_0, m4451_2_1) = &walk_f_4457 && (m4451_2_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m4451_2_1.len() == 1) && let ::std::option::Option::Some(c_p8) = crate::prelude::index(m4451_2_1, &crate::prelude::Nat::from(0u32)) {
                break 'm4451 crate::prelude::call_then(start_walk_f(st_p0x.clone(), expected_p1x.clone()), move |walk_f_5136: crate::check::types::Ty| match walk_f_5136 {
                    crate::check::types::Ty::TyArray(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st_p0x.clone(), expected_p1: expected_p1x.clone(), found_p2: c_p8.clone(), span_p3: span_p3x.clone() })),
                    crate::check::types::Ty::TyMap(_, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st_p0x.clone(), expected_p1: expected_p1x.clone(), found_p2: c_p8.clone(), span_p3: span_p3x.clone() })),
                    _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st_p0x.clone(), expected_p1: expected_p1x.clone(), found_p2: found_p2x.clone(), span_p3: span_p3x.clone() })),
                });
            }
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st_p0x.clone(), expected_p1: expected_p1x.clone(), found_p2: found_p2x.clone(), span_p3: span_p3x.clone() }))
        })
    }
}

/// `Start UnifyNoted, x`: what the function value is when passed to `@Run`.
pub fn start_unify_noted_f(st_p0: crate::check::types::St, expected_p1: crate::check::types::Ty, found_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(UnifyNoted { st_p0, expected_p1, found_p2, span_p3 })
}

/// ```prism
/// FaultVar: fn St, Range -> ((Ty, St))
/// ```
pub fn fault_var_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (v_p2, st2_p3) = crate::check::types::fresh_var_f(st_p0, &false, &crate::prelude::Text::lit(""));
    (v_p2.clone(), {
        let mut this: crate::check::types::St = st2_p3.clone();
        this.fault_vars_p = crate::prelude::push(&this.fault_vars_p, &crate::check::types::Waiting { expected_p: v_p2.clone(), found_p: crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Prelude.Error"), crate::prelude::Array::new()), span_p: span_p1.clone(), file_p: st_p0.file_p.clone() });
        this
    })
}

/// ```prism
/// IsFailurePattern: unbounded fn St, Ty, Ty -> Bool
/// ```
pub fn is_failure_pattern_f(st_p0: &crate::check::types::St, scrut_p1: &crate::check::types::Ty, pat_p2: &crate::check::types::Ty) -> bool {
    match (walk_f(st_p0, scrut_p1), walk_f(st_p0, pat_p2)) {
        (crate::check::types::Ty::TySig(m5838_0_0_0, _), crate::check::types::Ty::TyCon(m5838_0_1_0, m5838_0_1_1)) if (&m5838_0_0_0 == &crate::prelude::Text::lit("~")) && (&m5838_0_1_0 == &crate::prelude::Text::lit("Prelude.Error")) && ((&m5838_0_1_1).len() == 0) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `IsFailurePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsFailurePattern: unbounded fn St, Ty, Ty -> Bool
/// ```
pub struct IsFailurePattern {
    pub st_p0: crate::check::types::St,
    pub scrut_p1: crate::check::types::Ty,
    pub pat_p2: crate::check::types::Ty,
}

impl ::prism_rtl::Job<bool> for IsFailurePattern {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let scrut_p1 = &self.scrut_p1;
        let pat_p2 = &self.pat_p2;
        let pat_p2x = pat_p2.clone();
        let scrut_p1x = scrut_p1.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(start_walk_f(st_p0x.clone(), scrut_p1x.clone()), move |walk_f_5847: crate::check::types::Ty| crate::prelude::call_then(start_walk_f(st_p0x.clone(), pat_p2x.clone()), move |walk_f_5865: crate::check::types::Ty| match (walk_f_5847, walk_f_5865) {
            (crate::check::types::Ty::TySig(m5838_0_0_0, _), crate::check::types::Ty::TyCon(m5838_0_1_0, m5838_0_1_1)) if (&m5838_0_0_0 == &crate::prelude::Text::lit("~")) && (&m5838_0_1_0 == &crate::prelude::Text::lit("Prelude.Error")) && ((&m5838_0_1_1).len() == 0) => ::prism_rtl::Turn::Finished(true),
            _ => ::prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        }))
    }
}

/// `Start IsFailurePattern, x`: what the function value is when passed to `@Run`.
pub fn start_is_failure_pattern_f(st_p0: crate::check::types::St, scrut_p1: crate::check::types::Ty, pat_p2: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsFailurePattern { st_p0, scrut_p1, pat_p2 })
}

/// ```prism
/// FaultsDefaulted: unbounded fn St, Bool -> St
/// ```
pub fn faults_defaulted_f(st_p0: &crate::check::types::St, all_p1: &bool) -> crate::check::types::St {
    crate::prelude::run_to_end(crate::prelude::fold_job(st_p0.fault_vars_p.clone(), st_p0.clone(), {
        let all_p1x = *all_p1;
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Waiting)| {
            let all_p1xy = all_p1x;
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p2 = p0;
                let w_p3 = p1;
                crate::prelude::call_then(start_walk_f(s_p2.clone(), w_p3.expected_p.clone()), move |walk_f_6333: crate::check::types::Ty| match walk_f_6333 {
                    crate::check::types::Ty::TyFlex(n_p4) if (all_p1xy || (&info_of_f(&s_p2, &n_p4).level_p >= &crate::prelude::Nat::from(1u32))) => ::prism_rtl::Turn::Finished({
                        let mut this: crate::check::types::St = s_p2.clone();
                        this.tys_p = crate::prelude::insert(&this.tys_p, &n_p4, &crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Prelude.Error"), crate::prelude::Array::new()));
                        this
                    }),
                    _ => ::prism_rtl::Turn::Finished(s_p2.clone()),
                    _ => unreachable!("no arm matched"),
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `FaultsDefaulted`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FaultsDefaulted: unbounded fn St, Bool -> St
/// ```
pub struct FaultsDefaulted {
    pub st_p0: crate::check::types::St,
    pub all_p1: bool,
}

impl ::prism_rtl::Job<crate::check::types::St> for FaultsDefaulted {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let all_p1 = &self.all_p1;
        crate::prelude::fold_job(st_p0.fault_vars_p.clone(), st_p0.clone(), {
            let all_p1x = *all_p1;
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Waiting)| {
                let all_p1xy = all_p1x;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p2 = p0;
                    let w_p3 = p1;
                    crate::prelude::call_then(start_walk_f(s_p2.clone(), w_p3.expected_p.clone()), move |walk_f_6333: crate::check::types::Ty| match walk_f_6333 {
                        crate::check::types::Ty::TyFlex(n_p4) if (all_p1xy || (&info_of_f(&s_p2, &n_p4).level_p >= &crate::prelude::Nat::from(1u32))) => ::prism_rtl::Turn::Finished({
                            let mut this: crate::check::types::St = s_p2.clone();
                            this.tys_p = crate::prelude::insert(&this.tys_p, &n_p4, &crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Prelude.Error"), crate::prelude::Array::new()));
                            this
                        }),
                        _ => ::prism_rtl::Turn::Finished(s_p2.clone()),
                        _ => unreachable!("no arm matched"),
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start FaultsDefaulted, x`: what the function value is when passed to `@Run`.
pub fn start_faults_defaulted_f(st_p0: crate::check::types::St, all_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(FaultsDefaulted { st_p0, all_p1 })
}

/// ```prism
/// FaultsSettled: unbounded fn St -> St
/// ```
pub fn faults_settled_f(st0_p0: &crate::check::types::St) -> crate::check::types::St {
    let st_p1 = faults_defaulted_f(st0_p0, &true);
    let checked_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(st_p1.fault_vars_p.clone(), st_p1.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Waiting)| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p3 = p0;
        let w_p4 = p1;
        crate::prelude::call_then(start_walk_f(s_p3.clone(), w_p4.expected_p.clone()), move |walk_f_6829: crate::check::types::Ty| match walk_f_6829 {
            crate::check::types::Ty::TyCon(m6823_0_0, m6823_0_1) if (&m6823_0_0 == &crate::prelude::Text::lit("Prelude.Error")) && ((&m6823_0_1).len() == 0) => ::prism_rtl::Turn::Finished(s_p3.clone()),
            crate::check::types::Ty::TySig(m6823_1_0, _) if (&m6823_1_0 == &crate::prelude::Text::lit("~")) => ::prism_rtl::Turn::Finished(s_p3.clone()),
            crate::check::types::Ty::TyErr => ::prism_rtl::Turn::Finished(s_p3.clone()),
            other_p5 => {
                let there_p6 = {
                    let mut this: crate::check::types::St = s_p3.clone();
                    this.file_p = w_p4.file_p.clone();
                    this
                };
                crate::prelude::call_then(crate::check::types::start_show_ty_f(there_p6.clone(), other_p5.clone()), move |show_ty_f_7072: crate::prelude::Text| ::prism_rtl::Turn::Finished(err_f(&there_p6, &crate::prelude::Text::lit("mismatch"), &w_p4.span_p, &crate::prelude::Text::from(format!("expected `{}`, found `Error`", &show_ty_f_7072)))))
            },
            _ => unreachable!("no arm matched"),
        })
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>));
    let mut this: crate::check::types::St = checked_p2.clone();
    this.file_p = st_p1.file_p.clone();
    this
}

/// The step machine of `FaultsSettled`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FaultsSettled: unbounded fn St -> St
/// ```
pub struct FaultsSettled {
    pub st0_p0: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::types::St> for FaultsSettled {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st0_p0 = &self.st0_p0;
        let st0_p0x = st0_p0.clone();
        crate::prelude::call_then(start_faults_defaulted_f(st0_p0x.clone(), true), move |faults_defaulted_f_6748: crate::check::types::St| {
            let st_p1 = faults_defaulted_f_6748;
            crate::prelude::call_value(crate::prelude::fold_job(st_p1.fault_vars_p.clone(), st_p1.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Waiting)| crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p3 = p0;
                let w_p4 = p1;
                crate::prelude::call_then(start_walk_f(s_p3.clone(), w_p4.expected_p.clone()), move |walk_f_6829: crate::check::types::Ty| match walk_f_6829 {
                    crate::check::types::Ty::TyCon(m6823_0_0, m6823_0_1) if (&m6823_0_0 == &crate::prelude::Text::lit("Prelude.Error")) && ((&m6823_0_1).len() == 0) => ::prism_rtl::Turn::Finished(s_p3.clone()),
                    crate::check::types::Ty::TySig(m6823_1_0, _) if (&m6823_1_0 == &crate::prelude::Text::lit("~")) => ::prism_rtl::Turn::Finished(s_p3.clone()),
                    crate::check::types::Ty::TyErr => ::prism_rtl::Turn::Finished(s_p3.clone()),
                    other_p5 => {
                        let there_p6 = {
                            let mut this: crate::check::types::St = s_p3.clone();
                            this.file_p = w_p4.file_p.clone();
                            this
                        };
                        crate::prelude::call_then(crate::check::types::start_show_ty_f(there_p6.clone(), other_p5.clone()), move |show_ty_f_7072: crate::prelude::Text| ::prism_rtl::Turn::Finished(err_f(&there_p6, &crate::prelude::Text::lit("mismatch"), &w_p4.span_p, &crate::prelude::Text::from(format!("expected `{}`, found `Error`", &show_ty_f_7072)))))
                    },
                    _ => unreachable!("no arm matched"),
                })
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>), move |fold_6792: crate::check::types::St| {
                let checked_p2 = fold_6792;
                ::prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = checked_p2.clone();
                    this.file_p = st_p1.file_p.clone();
                    this
                })
            })
        })
    }
}

/// `Start FaultsSettled, x`: what the function value is when passed to `@Run`.
pub fn start_faults_settled_f(st0_p0: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(FaultsSettled { st0_p0 })
}

/// ```prism
/// ResultSpan: fn Block -> Range
/// ```
pub fn result_span_f(b_p0: &crate::syntax::Block) -> crate::syntax::Range {
    match crate::syntax::lexer::chars::last_o(&b_p0.stmts_p) {
        ::std::option::Option::Some(s_p1) => s_p1.span_p.clone(),
        ::std::option::Option::None => b_p0.span_p.clone(),
    }
}

/// ```prism
/// TailSpan: fn Block -> Range
/// ```
pub fn tail_span_f(b_p0: &crate::syntax::Block) -> crate::syntax::Range {
    match crate::syntax::lexer::chars::last_o(&b_p0.stmts_p) {
        ::std::option::Option::Some(s_p1) => match &s_p1.kind_p {
            crate::syntax::StmtKind::SExpr(e_p2) => e_p2.span_p.clone(),
            _ => b_p0.span_p.clone(),
        },
        ::std::option::Option::None => b_p0.span_p.clone(),
    }
}

/// ```prism
/// FaultNotes: unbounded fn St -> [TyNote]
/// ```
pub fn fault_notes_f(st_p0: &crate::check::types::St) -> crate::prelude::Array<crate::check::typed::TyNote> {
    crate::prelude::run_to_end(crate::prelude::fold_job(st_p0.fault_qs_p.clone(), crate::prelude::Array::new(), {
        let st_p0x = st_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::typed::TyNote>, crate::check::types::Waiting)| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p1 = p0;
                let q_p2 = p1;
                crate::prelude::call_then(start_resolve_ty_f(st_p0xy.clone(), q_p2.expected_p.clone()), move |resolve_ty_f_7840: crate::check::types::Ty| {
                    let z_p3 = resolve_ty_f_7840;
                    if is_fault_head_f(&z_p3) {
                        ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p1, &crate::check::typed::TyNote { at_p: crate::check::typed::SrcAt { file_p: q_p2.file_p.clone(), span_p: q_p2.span_p.clone() }, ty_p: z_p3.clone() }))
                    } else {
                        ::prism_rtl::Turn::Finished(acc_p1.clone())
                    }
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::typed::TyNote>, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::typed::TyNote>>>>
    }))
}

/// The step machine of `FaultNotes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FaultNotes: unbounded fn St -> [TyNote]
/// ```
pub struct FaultNotes {
    pub st_p0: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::check::typed::TyNote>> for FaultNotes {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::check::typed::TyNote>> {
        let st_p0 = &self.st_p0;
        crate::prelude::fold_job(st_p0.fault_qs_p.clone(), crate::prelude::Array::new(), {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::typed::TyNote>, crate::check::types::Waiting)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p1 = p0;
                    let q_p2 = p1;
                    crate::prelude::call_then(start_resolve_ty_f(st_p0xy.clone(), q_p2.expected_p.clone()), move |resolve_ty_f_7840: crate::check::types::Ty| {
                        let z_p3 = resolve_ty_f_7840;
                        if is_fault_head_f(&z_p3) {
                            ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p1, &crate::check::typed::TyNote { at_p: crate::check::typed::SrcAt { file_p: q_p2.file_p.clone(), span_p: q_p2.span_p.clone() }, ty_p: z_p3.clone() }))
                        } else {
                            ::prism_rtl::Turn::Finished(acc_p1.clone())
                        }
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::typed::TyNote>, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::typed::TyNote>>>>
        }).cycle()
    }
}

/// `Start FaultNotes, x`: what the function value is when passed to `@Run`.
pub fn start_fault_notes_f(st_p0: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::typed::TyNote>>> {
    ::std::rc::Rc::new(FaultNotes { st_p0 })
}

/// ```prism
/// IsFaultHead: fn Ty -> Bool
/// ```
pub fn is_fault_head_f(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TySig(m8003_0_0, _) if (m8003_0_0 == &crate::prelude::Text::lit("~")) => true,
        crate::check::types::Ty::TySig(m8003_1_0, i_p1) if (m8003_1_0 == &crate::prelude::Text::lit("$")) => is_fault_head_f(&**i_p1),
        crate::check::types::Ty::TySig(m8003_2_0, i_p2) if (m8003_2_0 == &crate::prelude::Text::lit("!")) => is_fault_head_f(&**i_p2),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// NoteBinder: fn St, Range, Text, Ty -> St
/// ```
pub fn note_binder_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, name_p2: &crate::prelude::Text, t_p3: &crate::check::types::Ty) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.binders_p = crate::prelude::push(&this.typed_p.binders_p, &crate::check::typed::BinderNote { at_p: at_here_f(st_p0, span_p1), name_p: name_p2.clone(), ty_p: t_p3.clone() });
            this
        }
    }
}

/// ```prism
/// NoteLocal: fn St, Range, Nat, Text -> St
/// ```
pub fn note_local_f(st0_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, id_p2: &crate::prelude::Nat, name_p3: &crate::prelude::Text) -> crate::check::types::St {
    let st_p4 = {
        let mut this: crate::check::types::St = st0_p0.clone();
        this.binder_ids_p = crate::prelude::push(&this.binder_ids_p, id_p2);
        this
    };
    if !st_p4.recording_p {
        st_p4.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p4.clone();
            this.typed_p.locals_p = crate::prelude::push(&this.typed_p.locals_p, &crate::check::typed::LocalNote { at_p: at_here_f(&st_p4, span_p1), id_p: id_p2.clone(), name_p: name_p3.clone() });
            this
        }
    }
}

/// ```prism
/// NoteGlobal: fn St, Range, Text -> St
/// ```
pub fn note_global_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, qk_p2: &crate::prelude::Text) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.globals_p = crate::prelude::push(&this.typed_p.globals_p, &crate::check::typed::GlobalNote { at_p: at_here_f(st_p0, span_p1), target_p: qk_p2.clone() });
            this
        }
    }
}

/// ```prism
/// NoteCall: fn St, Range, Nat -> St
/// ```
pub fn note_call_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, id_p2: &crate::prelude::Nat) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.calls_p = crate::prelude::push(&this.typed_p.calls_p, &crate::check::typed::LocalNote { at_p: at_here_f(st_p0, span_p1), id_p: id_p2.clone(), name_p: crate::prelude::Text::lit("") });
            this
        }
    }
}

/// ```prism
/// NoteUse: fn St, Range, Nat, Text -> St
/// ```
pub fn note_use_f(st0_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, id_p2: &crate::prelude::Nat, name_p3: &crate::prelude::Text) -> crate::check::types::St {
    let st_p4 = {
        let mut this: crate::check::types::St = st0_p0.clone();
        this.use_ids_p = crate::prelude::push(&this.use_ids_p, id_p2);
        this
    };
    if !st_p4.recording_p {
        st_p4.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p4.clone();
            this.typed_p.uses_p = crate::prelude::push(&this.typed_p.uses_p, &crate::check::typed::LocalNote { at_p: at_here_f(&st_p4, span_p1), id_p: id_p2.clone(), name_p: name_p3.clone() });
            this
        }
    }
}

/// ```prism
/// IsClosed: unbounded fn St, St -> Bool
/// ```
pub fn is_closed_f(before_p0: &crate::check::types::St, st_p1: &crate::check::types::St) -> bool {
    let made_p2 = crate::prelude::drop(&st_p1.binder_ids_p, &crate::prelude::len(&before_p0.binder_ids_p));
    crate::prelude::fold(&crate::prelude::drop(&st_p1.use_ids_p, &crate::prelude::len(&before_p0.use_ids_p)), &true, &(|ok_p3: &bool, u_p4: &crate::prelude::Nat| *ok_p3 && crate::check::types::has_nat_f(&made_p2, u_p4)))
}

/// ```prism
/// NoteGen: fn St, Range, Text, Scheme -> St
/// ```
pub fn note_gen_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, name_p2: &crate::prelude::Text, sc_p3: &crate::check::types::Scheme) -> crate::check::types::St {
    if !st_p0.recording_p || ((&crate::prelude::len(&sc_p3.qs_p) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&sc_p3.cqs_p) == &crate::prelude::Nat::from(0u32))) {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.gens_p = crate::prelude::push(&this.typed_p.gens_p, &crate::check::typed::GenNote { at_p: at_here_f(st_p0, span_p1), name_p: name_p2.clone(), tys_p: sc_p3.qs_p.clone(), cols_p: sc_p3.cqs_p.clone() });
            this
        }
    }
}

/// ```prism
/// NoteInst: fn St, Range, Text, Scheme, Inst -> St
/// ```
pub fn note_inst_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, name_p2: &crate::prelude::Text, sc_p3: &crate::check::types::Scheme, inst_p4: &crate::check::types::schemes::Inst) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.insts_p = crate::prelude::push(&this.typed_p.insts_p, &crate::check::typed::InstNote { at_p: at_here_f(st_p0, span_p1), name_p: name_p2.clone(), tys_p: crate::prelude::each(&sc_p3.qs_p, &(|q_p5: &crate::prelude::Text| (q_p5.clone(), crate::prelude::or(&crate::prelude::get(&inst_p4.tys_p, q_p5), &crate::check::types::Ty::TyErr)))), cols_p: crate::prelude::each(&sc_p3.cqs_p, &(|q_p6: &crate::prelude::Text| (q_p6.clone(), crate::prelude::or(&crate::prelude::get(&inst_p4.cols_p, q_p6), &crate::check::types::Col::CBound)))) });
            this
        }
    }
}

/// ```prism
/// NoteApp: fn St, Range, Text, Text, Text, [Nat], Text, Col -> St
/// ```
pub fn note_app_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, callee_p2: &crate::prelude::Text, kind_p3: &crate::prelude::Text, layer_p4: &crate::prelude::Text, lifted_p5: &crate::prelude::Array<crate::prelude::Nat>, inner_p6: &crate::prelude::Text, col_p7: &crate::check::types::Col) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.apps_p = crate::prelude::push(&this.typed_p.apps_p, &crate::check::typed::AppNote { at_p: at_here_f(st_p0, span_p1), callee_p: callee_p2.clone(), kind_p: kind_p3.clone(), layer_p: layer_p4.clone(), lifted_p: lifted_p5.clone(), inner_p: inner_p6.clone(), color_p: col_p7.clone() });
            this
        }
    }
}

/// ```prism
/// NoteLift: fn St, Range, Text, [Range] -> St
/// ```
pub fn note_lift_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, sigil_p2: &crate::prelude::Text, operands_p3: &crate::prelude::Array<crate::syntax::Range>) -> crate::check::types::St {
    if !st_p0.recording_p || (&crate::prelude::len(operands_p3) == &crate::prelude::Nat::from(0u32)) {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.lifts_p = crate::prelude::push(&this.typed_p.lifts_p, &crate::check::typed::LiftNote { at_p: at_here_f(st_p0, span_p1), sigil_p: sigil_p2.clone(), operands_p: operands_p3.clone() });
            this
        }
    }
}

/// ```prism
/// NoteFn: fn St, Range, Text, Col, Col -> St
/// ```
pub fn note_fn_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, name_p2: &crate::prelude::Text, declared_p3: &crate::check::types::Col, body_p4: &crate::check::types::Col) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.fns_p = crate::prelude::push(&this.typed_p.fns_p, &crate::check::typed::FnNote { at_p: at_here_f(st_p0, span_p1), name_p: name_p2.clone(), declared_p: declared_p3.clone(), body_p: body_p4.clone() });
            this
        }
    }
}

/// ```prism
/// NoteImpl: fn St, Nat, Range, Text, Ty, Text -> St
/// ```
pub fn note_impl_f(st_p0: &crate::check::types::St, file_p1: &crate::prelude::Nat, span_p2: &crate::syntax::Range, cls_p3: &crate::prelude::Text, t_p4: &crate::check::types::Ty, how_p5: &crate::prelude::Text) -> crate::check::types::St {
    if ((!st_p0.recording_p || crate::syntax::lexer::chars::has_prefix_f(cls_p3, &crate::prelude::Text::lit("Range "))) || (cls_p3 == &crate::prelude::Text::lit("Prelude.Sub"))) || (cls_p3 == &crate::prelude::Text::lit("Prelude.Signed")) {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.impls_p = crate::prelude::push(&this.typed_p.impls_p, &crate::check::typed::ImplNote { at_p: crate::check::typed::SrcAt { file_p: file_p1.clone(), span_p: span_p2.clone() }, cls_p: cls_p3.clone(), ty_p: t_p4.clone(), how_p: how_p5.clone() });
            this
        }
    }
}

/// ```prism
/// NoteGenericUse: fn St, Text, [Text], Range, Inst -> St
/// ```
pub fn note_generic_use_f(st_p0: &crate::check::types::St, target_p1: &crate::prelude::Text, qs_p2: &crate::prelude::Array<crate::prelude::Text>, span_p3: &crate::syntax::Range, inst_p4: &crate::check::types::schemes::Inst) -> crate::check::types::St {
    let noted_p5 = crate::check::types::GenericUse { user_p: st_p0.definition_p.clone(), target_p: target_p1.clone(), file_p: st_p0.file_p.clone(), span_p: span_p3.clone(), types_p: crate::prelude::each(qs_p2, &(|q_p6: &crate::prelude::Text| (q_p6.clone(), crate::prelude::or(&crate::prelude::get(&inst_p4.tys_p, q_p6), &crate::check::types::Ty::TyErr)))) };
    let mut this: crate::check::types::St = st_p0.clone();
    this.generic_uses_p = crate::prelude::push(&this.generic_uses_p, &noted_p5);
    this
}

/// ```prism
/// NoteChoice: fn St, Nat, Range, Text, Text -> St
/// ```
pub fn note_choice_f(st_p0: &crate::check::types::St, file_p1: &crate::prelude::Nat, span_p2: &crate::syntax::Range, cls_p3: &crate::prelude::Text, ch_p4: &crate::prelude::Text) -> crate::check::types::St {
    let k_p5 = choice_key_f(file_p1, span_p2, cls_p3);
    if (crate::syntax::lexer::chars::has_prefix_f(cls_p3, &crate::prelude::Text::lit("Range ")) || (cls_p3 == &crate::prelude::Text::lit("Prelude.Sub"))) || (cls_p3 == &crate::prelude::Text::lit("Prelude.Signed")) {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.choices_p = crate::prelude::insert(&this.choices_p, &k_p5, &crate::check::types::add_text_f(&crate::prelude::or(&crate::prelude::get(&this.choices_p, &k_p5), &crate::prelude::Array::new()), ch_p4));
            this
        }
    }
}

/// ```prism
/// NoteSizeTy: fn St, Range, Ty -> St
/// ```
pub fn note_size_ty_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, t_p2: &crate::check::types::Ty) -> crate::check::types::St {
    match t_p2 {
        crate::check::types::Ty::TyFn(_, ps_p3, _) => match crate::prelude::index(ps_p3, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::Some(p_p4) => {
                let mut this: crate::check::types::St = st_p0.clone();
                this.size_tys_p = crate::prelude::insert(&this.size_tys_p, &crate::prelude::Text::from(format!("{}:{}:{}", &st_p0.file_p, &span_p1.start_p, &span_p1.end_p)), &p_p4);
                this
            },
            ::std::option::Option::None => st_p0.clone(),
        },
        _ => st_p0.clone(),
    }
}

/// ```prism
/// ChoiceKey: fn Nat, Range, Text -> Text
/// ```
pub fn choice_key_f(file_p0: &crate::prelude::Nat, span_p1: &crate::syntax::Range, cls_p2: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{}:{}:{}:{}", file_p0, &span_p1.start_p, &span_p1.end_p, cls_p2))
}

/// ```prism
/// NoteMethod: fn St, Range, Text, Text -> St
/// ```
pub fn note_method_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, method_p2: &crate::prelude::Text, cls_p3: &crate::prelude::Text) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.methods_p = crate::prelude::push(&this.typed_p.methods_p, &crate::check::typed::MethodNote { at_p: at_here_f(st_p0, span_p1), method_p: method_p2.clone(), cls_p: cls_p3.clone() });
            this
        }
    }
}

/// ```prism
/// NoteGroup: fn St, Range, Text, [ [Nat] ] -> St
/// ```
pub fn note_group_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, kind_p2: &crate::prelude::Text, order_p3: &crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.groups_p = crate::prelude::push(&this.typed_p.groups_p, &crate::check::typed::GroupNote { at_p: at_here_f(st_p0, span_p1), kind_p: kind_p2.clone(), order_p: order_p3.clone() });
            this
        }
    }
}

/// ```prism
/// ZonkTyped: unbounded fn St -> TProgram
/// ```
pub fn zonk_typed_f(st0_p0: &crate::check::types::St) -> crate::check::typed::TProgram {
    let st_p1 = default_free_f(st0_p0);
    let t_p2 = st_p1.typed_p.clone();
    let mut this: crate::check::typed::TProgram = t_p2.clone();
    this.faults_p = fault_notes_f(&st_p1);
    this.plains_p = plain_notes_f(&st_p1);
    this.exprs_p = crate::prelude::run_to_end(crate::prelude::each_job(this.exprs_p.clone(), {
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::check::typed::TyNote| {
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let n_p3 = p0;
                crate::prelude::call_then(start_resolve_ty_f(st_p1xy.clone(), n_p3.ty_p.clone()), move |resolve_ty_f_14661: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::typed::TyNote { at_p: n_p3.at_p.clone(), ty_p: resolve_ty_f_14661 }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::typed::TyNote) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::TyNote>>>
    }));
    this.binders_p = crate::prelude::run_to_end(crate::prelude::each_job(this.binders_p.clone(), {
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::check::typed::BinderNote| {
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let n_p4 = p0;
                crate::prelude::call_then(start_resolve_ty_f(st_p1xy.clone(), n_p4.ty_p.clone()), move |resolve_ty_f_14763: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::typed::BinderNote { at_p: n_p4.at_p.clone(), name_p: n_p4.name_p.clone(), ty_p: resolve_ty_f_14763 }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::typed::BinderNote) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::BinderNote>>>
    }));
    this.insts_p = crate::prelude::run_to_end(crate::prelude::each_job(this.insts_p.clone(), {
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::check::typed::InstNote| {
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let n_p5 = p0;
                crate::prelude::call_value(crate::prelude::each_job(n_p5.tys_p.clone(), {
                    let st_p1xyx = st_p1xy.clone();
                    ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                        let st_p1xyxy = st_p1xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (q_p6, x_p7) = p0;
                            crate::prelude::call_then(start_resolve_ty_f(st_p1xyxy.clone(), x_p7.clone()), move |resolve_ty_f_14890: crate::check::types::Ty| ::prism_rtl::Turn::Finished((q_p6.clone(), resolve_ty_f_14890)))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::Ty)>>>
                }), move |each_14860: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>| crate::prelude::call_value(crate::prelude::each_job(n_p5.cols_p.clone(), {
                    let st_p1xyx = st_p1xy.clone();
                    ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Col)| {
                        let st_p1xyxy = st_p1xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (q_p8, c_p9) = p0;
                            crate::prelude::call_then(start_resolve_col_f(st_p1xyxy.clone(), c_p9.clone()), move |resolve_col_f_14948: crate::check::types::Col| ::prism_rtl::Turn::Finished((q_p8.clone(), resolve_col_f_14948)))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Col)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::Col)>>>
                }), move |each_14917: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Col)>| ::prism_rtl::Turn::Finished(crate::check::typed::InstNote { at_p: n_p5.at_p.clone(), name_p: n_p5.name_p.clone(), tys_p: each_14860, cols_p: each_14917 })))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::typed::InstNote) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::InstNote>>>
    }));
    this.impls_p = crate::prelude::run_to_end(crate::prelude::each_job(this.impls_p.clone(), {
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::check::typed::ImplNote| {
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let n_pa = p0;
                crate::prelude::call_then(start_resolve_ty_f(st_p1xy.clone(), n_pa.ty_p.clone()), move |resolve_ty_f_15043: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::typed::ImplNote { at_p: n_pa.at_p.clone(), cls_p: n_pa.cls_p.clone(), ty_p: resolve_ty_f_15043, how_p: n_pa.how_p.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::typed::ImplNote) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::ImplNote>>>
    }));
    this.apps_p = crate::prelude::run_to_end(crate::prelude::each_job(this.apps_p.clone(), {
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::check::typed::AppNote| {
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let n_pb = p0;
                crate::prelude::call_then(start_resolve_col_f(st_p1xy.clone(), n_pb.color_p.clone()), move |resolve_col_f_15214: crate::check::types::Col| ::prism_rtl::Turn::Finished(crate::check::typed::AppNote { at_p: n_pb.at_p.clone(), callee_p: n_pb.callee_p.clone(), kind_p: n_pb.kind_p.clone(), layer_p: n_pb.layer_p.clone(), lifted_p: n_pb.lifted_p.clone(), inner_p: n_pb.inner_p.clone(), color_p: resolve_col_f_15214 }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::typed::AppNote) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::AppNote>>>
    }));
    this.fns_p = crate::prelude::run_to_end(crate::prelude::each_job(this.fns_p.clone(), {
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::check::typed::FnNote| {
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let n_pc = p0;
                crate::prelude::call_then(start_resolve_col_f(st_p1xy.clone(), n_pc.declared_p.clone()), move |resolve_col_f_15314: crate::check::types::Col| crate::prelude::call_then(start_resolve_col_f(st_p1xy.clone(), n_pc.body_p.clone()), move |resolve_col_f_15348: crate::check::types::Col| ::prism_rtl::Turn::Finished(crate::check::typed::FnNote { at_p: n_pc.at_p.clone(), name_p: n_pc.name_p.clone(), declared_p: resolve_col_f_15314, body_p: resolve_col_f_15348 })))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::typed::FnNote) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::FnNote>>>
    }));
    this
}

/// The step machine of `ZonkTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ZonkTyped: unbounded fn St -> TProgram
/// ```
pub struct ZonkTyped {
    pub st0_p0: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::typed::TProgram> for ZonkTyped {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::typed::TProgram> {
        let st0_p0 = &self.st0_p0;
        let st0_p0x = st0_p0.clone();
        crate::prelude::call_then(start_default_free_f(st0_p0x.clone()), move |default_free_f_14480: crate::check::types::St| {
            let st_p1 = default_free_f_14480;
            let t_p2 = st_p1.typed_p.clone();
            ::prism_rtl::Turn::Finished({
                let mut this: crate::check::typed::TProgram = t_p2.clone();
                this.faults_p = fault_notes_f(&st_p1);
                this.plains_p = plain_notes_f(&st_p1);
                this.exprs_p = crate::prelude::run_to_end(crate::prelude::each_job(this.exprs_p.clone(), {
                    let st_p1x = st_p1.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::typed::TyNote| {
                        let st_p1xy = st_p1x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let n_p3 = p0;
                            crate::prelude::call_then(start_resolve_ty_f(st_p1xy.clone(), n_p3.ty_p.clone()), move |resolve_ty_f_14661: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::typed::TyNote { at_p: n_p3.at_p.clone(), ty_p: resolve_ty_f_14661 }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::typed::TyNote) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::TyNote>>>
                }));
                this.binders_p = crate::prelude::run_to_end(crate::prelude::each_job(this.binders_p.clone(), {
                    let st_p1x = st_p1.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::typed::BinderNote| {
                        let st_p1xy = st_p1x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let n_p4 = p0;
                            crate::prelude::call_then(start_resolve_ty_f(st_p1xy.clone(), n_p4.ty_p.clone()), move |resolve_ty_f_14763: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::typed::BinderNote { at_p: n_p4.at_p.clone(), name_p: n_p4.name_p.clone(), ty_p: resolve_ty_f_14763 }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::typed::BinderNote) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::BinderNote>>>
                }));
                this.insts_p = crate::prelude::run_to_end(crate::prelude::each_job(this.insts_p.clone(), {
                    let st_p1x = st_p1.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::typed::InstNote| {
                        let st_p1xy = st_p1x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let n_p5 = p0;
                            crate::prelude::call_value(crate::prelude::each_job(n_p5.tys_p.clone(), {
                                let st_p1xyx = st_p1xy.clone();
                                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                                    let st_p1xyxy = st_p1xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (q_p6, x_p7) = p0;
                                        crate::prelude::call_then(start_resolve_ty_f(st_p1xyxy.clone(), x_p7.clone()), move |resolve_ty_f_14890: crate::check::types::Ty| ::prism_rtl::Turn::Finished((q_p6.clone(), resolve_ty_f_14890)))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::Ty)>>>
                            }), move |each_14860: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>| crate::prelude::call_value(crate::prelude::each_job(n_p5.cols_p.clone(), {
                                let st_p1xyx = st_p1xy.clone();
                                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Col)| {
                                    let st_p1xyxy = st_p1xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (q_p8, c_p9) = p0;
                                        crate::prelude::call_then(start_resolve_col_f(st_p1xyxy.clone(), c_p9.clone()), move |resolve_col_f_14948: crate::check::types::Col| ::prism_rtl::Turn::Finished((q_p8.clone(), resolve_col_f_14948)))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Col)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::Col)>>>
                            }), move |each_14917: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Col)>| ::prism_rtl::Turn::Finished(crate::check::typed::InstNote { at_p: n_p5.at_p.clone(), name_p: n_p5.name_p.clone(), tys_p: each_14860, cols_p: each_14917 })))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::typed::InstNote) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::InstNote>>>
                }));
                this.impls_p = crate::prelude::run_to_end(crate::prelude::each_job(this.impls_p.clone(), {
                    let st_p1x = st_p1.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::typed::ImplNote| {
                        let st_p1xy = st_p1x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let n_pa = p0;
                            crate::prelude::call_then(start_resolve_ty_f(st_p1xy.clone(), n_pa.ty_p.clone()), move |resolve_ty_f_15043: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::typed::ImplNote { at_p: n_pa.at_p.clone(), cls_p: n_pa.cls_p.clone(), ty_p: resolve_ty_f_15043, how_p: n_pa.how_p.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::typed::ImplNote) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::ImplNote>>>
                }));
                this.apps_p = crate::prelude::run_to_end(crate::prelude::each_job(this.apps_p.clone(), {
                    let st_p1x = st_p1.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::typed::AppNote| {
                        let st_p1xy = st_p1x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let n_pb = p0;
                            crate::prelude::call_then(start_resolve_col_f(st_p1xy.clone(), n_pb.color_p.clone()), move |resolve_col_f_15214: crate::check::types::Col| ::prism_rtl::Turn::Finished(crate::check::typed::AppNote { at_p: n_pb.at_p.clone(), callee_p: n_pb.callee_p.clone(), kind_p: n_pb.kind_p.clone(), layer_p: n_pb.layer_p.clone(), lifted_p: n_pb.lifted_p.clone(), inner_p: n_pb.inner_p.clone(), color_p: resolve_col_f_15214 }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::typed::AppNote) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::AppNote>>>
                }));
                this.fns_p = crate::prelude::run_to_end(crate::prelude::each_job(this.fns_p.clone(), {
                    let st_p1x = st_p1.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::typed::FnNote| {
                        let st_p1xy = st_p1x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let n_pc = p0;
                            crate::prelude::call_then(start_resolve_col_f(st_p1xy.clone(), n_pc.declared_p.clone()), move |resolve_col_f_15314: crate::check::types::Col| crate::prelude::call_then(start_resolve_col_f(st_p1xy.clone(), n_pc.body_p.clone()), move |resolve_col_f_15348: crate::check::types::Col| ::prism_rtl::Turn::Finished(crate::check::typed::FnNote { at_p: n_pc.at_p.clone(), name_p: n_pc.name_p.clone(), declared_p: resolve_col_f_15314, body_p: resolve_col_f_15348 })))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::typed::FnNote) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::FnNote>>>
                }));
                this
            })
        })
    }
}

/// `Start ZonkTyped, x`: what the function value is when passed to `@Run`.
pub fn start_zonk_typed_f(st0_p0: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::TProgram>> {
    ::std::rc::Rc::new(ZonkTyped { st0_p0 })
}

/// ```prism
/// DefaultFree: unbounded fn St -> St
/// ```
pub fn default_free_f(st_p0: &crate::check::types::St) -> crate::check::types::St {
    let t_p1 = st_p0.typed_p.clone();
    let quantified_p2 = crate::prelude::fold(&t_p1.gens_p, &crate::prelude::Array::new(), &(|acc_p7: &crate::prelude::Array<crate::prelude::Text>, g_p8: &crate::check::typed::GenNote| crate::prelude::append(acc_p7, &g_p8.tys_p)));
    let in_exprs_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(t_p1.exprs_p.clone(), crate::prelude::Array::new(), {
        let st_p0x = st_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::TyNote)| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p9 = p0;
                let n_pa = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0xy.clone(), acc_p1: acc_p9.clone(), t_p2: n_pa.ty_p.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::TyNote)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    let in_binders_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(t_p1.binders_p.clone(), in_exprs_p3.clone(), {
        let st_p0x = st_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::BinderNote)| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pb = p0;
                let n_pc = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0xy.clone(), acc_p1: acc_pb.clone(), t_p2: n_pc.ty_p.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::BinderNote)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    let in_insts_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(t_p1.insts_p.clone(), in_binders_p4.clone(), {
        let st_p0x = st_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::InstNote)| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pd = p0;
                let n_pe = p1;
                crate::prelude::fold_job(n_pe.tys_p.clone(), acc_pd.clone(), {
                    let st_p0xyx = st_p0xy.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, (crate::prelude::Text, crate::check::types::Ty))| {
                        let st_p0xyxy = st_p0xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a2_pf = p0;
                            let (_, x_pg) = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0xyxy.clone(), acc_p1: a2_pf.clone(), t_p2: x_pg.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
                }).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::InstNote)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    let vars_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(t_p1.impls_p.clone(), in_insts_p5.clone(), {
        let st_p0x = st_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::ImplNote)| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_ph = p0;
                let n_pi = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0xy.clone(), acc_p1: acc_ph.clone(), t_p2: n_pi.ty_p.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::ImplNote)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    crate::prelude::fold(&vars_p6, st_p0, &(|s_pj: &crate::check::types::St, v_pk: &crate::prelude::Nat| if crate::check::types::has_text_f(&quantified_p2, &crate::prelude::Text::from(format!("\'{}", v_pk))) {
        s_pj.clone()
    } else {
        {
            let mut this: crate::check::types::St = s_pj.clone();
            this.tys_p = crate::prelude::insert(&this.tys_p, v_pk, &crate::check::types::t_unit_p());
            this
        }
    }))
}

/// The step machine of `DefaultFree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefaultFree: unbounded fn St -> St
/// ```
pub struct DefaultFree {
    pub st_p0: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::types::St> for DefaultFree {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let t_p1 = st_p0.typed_p.clone();
        let quantified_p2 = crate::prelude::fold(&t_p1.gens_p, &crate::prelude::Array::new(), &(|acc_p7: &crate::prelude::Array<crate::prelude::Text>, g_p8: &crate::check::typed::GenNote| crate::prelude::append(acc_p7, &g_p8.tys_p)));
        let st_p0x = st_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(t_p1.exprs_p.clone(), crate::prelude::Array::new(), {
            let st_p0xx = st_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::TyNote)| {
                let st_p0xxy = st_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p9 = p0;
                    let n_pa = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0xxy.clone(), acc_p1: acc_p9.clone(), t_p2: n_pa.ty_p.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::TyNote)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
        }), move |fold_15982: crate::prelude::Array<crate::prelude::Nat>| {
            let in_exprs_p3 = fold_15982;
            crate::prelude::call_value(crate::prelude::fold_job(t_p1.binders_p.clone(), in_exprs_p3.clone(), {
                let st_p0xx = st_p0x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::BinderNote)| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pb = p0;
                        let n_pc = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0xxy.clone(), acc_p1: acc_pb.clone(), t_p2: n_pc.ty_p.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::BinderNote)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
            }), move |fold_16059: crate::prelude::Array<crate::prelude::Nat>| {
                let in_binders_p4 = fold_16059;
                crate::prelude::call_value(crate::prelude::fold_job(t_p1.insts_p.clone(), in_binders_p4.clone(), {
                    let st_p0xx = st_p0x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::InstNote)| {
                        let st_p0xxy = st_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pd = p0;
                            let n_pe = p1;
                            crate::prelude::fold_job(n_pe.tys_p.clone(), acc_pd.clone(), {
                                let st_p0xxyx = st_p0xxy.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, (crate::prelude::Text, crate::check::types::Ty))| {
                                    let st_p0xxyxy = st_p0xxyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let a2_pf = p0;
                                        let (_, x_pg) = p1;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0xxyxy.clone(), acc_p1: a2_pf.clone(), t_p2: x_pg.clone() }))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
                            }).cycle()
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::InstNote)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
                }), move |fold_16139: crate::prelude::Array<crate::prelude::Nat>| {
                    let in_insts_p5 = fold_16139;
                    crate::prelude::call_value(crate::prelude::fold_job(t_p1.impls_p.clone(), in_insts_p5.clone(), {
                        let st_p0xx = st_p0x.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::ImplNote)| {
                            let st_p0xxy = st_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_ph = p0;
                                let n_pi = p1;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0xxy.clone(), acc_p1: acc_ph.clone(), t_p2: n_pi.ty_p.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::typed::ImplNote)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
                    }), move |fold_16250: crate::prelude::Array<crate::prelude::Nat>| {
                        let vars_p6 = fold_16250;
                        ::prism_rtl::Turn::Finished(crate::prelude::fold(&vars_p6, &st_p0x, &(|s_pj: &crate::check::types::St, v_pk: &crate::prelude::Nat| if crate::check::types::has_text_f(&quantified_p2, &crate::prelude::Text::from(format!("\'{}", v_pk))) {
                            s_pj.clone()
                        } else {
                            {
                                let mut this: crate::check::types::St = s_pj.clone();
                                this.tys_p = crate::prelude::insert(&this.tys_p, v_pk, &crate::check::types::t_unit_p());
                                this
                            }
                        })))
                    })
                })
            })
        })
    }
}

/// `Start DefaultFree, x`: what the function value is when passed to `@Run`.
pub fn start_default_free_f(st_p0: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(DefaultFree { st_p0 })
}

/// ```prism
/// ResolveCol: unbounded fn St, Col -> Col
/// ```
pub fn resolve_col_f(st_p0: &crate::check::types::St, c_p1: &crate::check::types::Col) -> crate::check::types::Col {
    match crate::check::types::colors::walk_col_f(st_p0, c_p1) {
        crate::check::types::Col::CFlex(n_p2) => match crate::prelude::get(&st_p0.col_q_p, &n_p2) {
            ::std::option::Option::Some(q_p3) => crate::check::types::Col::CQ(q_p3),
            ::std::option::Option::None => crate::check::types::Col::CBound,
        },
        other_p4 => other_p4,
    }
}

/// The step machine of `ResolveCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveCol: unbounded fn St, Col -> Col
/// ```
pub struct ResolveCol {
    pub st_p0: crate::check::types::St,
    pub c_p1: crate::check::types::Col,
}

impl ::prism_rtl::Job<crate::check::types::Col> for ResolveCol {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Col> {
        let st_p0 = &self.st_p0;
        let c_p1 = &self.c_p1;
        let c_p1x = c_p1.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(crate::check::types::colors::start_walk_col_f(st_p0x.clone(), c_p1x.clone()), move |walk_col_f_16639: crate::check::types::Col| match walk_col_f_16639 {
            crate::check::types::Col::CFlex(n_p2) => match crate::prelude::get(&st_p0x.col_q_p, &n_p2) {
                ::std::option::Option::Some(q_p3) => ::prism_rtl::Turn::Finished(crate::check::types::Col::CQ(q_p3.clone())),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::check::types::Col::CBound),
            },
            other_p4 => ::prism_rtl::Turn::Finished(other_p4.clone()),
        })
    }
}

/// `Start ResolveCol, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_col_f(st_p0: crate::check::types::St, c_p1: crate::check::types::Col) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Col>> {
    ::std::rc::Rc::new(ResolveCol { st_p0, c_p1 })
}

/// ```prism
/// ResolveTy: unbounded fn St, Ty -> Ty
/// ```
pub fn resolve_ty_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    resolve_in_f(st_p0, &zonk_f(st_p0, t_p1))
}

/// The step machine of `ResolveTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveTy: unbounded fn St, Ty -> Ty
/// ```
pub struct ResolveTy {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for ResolveTy {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(start_zonk_f(st_p0x.clone(), t_p1x.clone()), move |zonk_f_16852: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(ResolveIn { st_p0: st_p0x.clone(), t_p1: zonk_f_16852 })))
    }
}

/// `Start ResolveTy, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_ty_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(ResolveTy { st_p0, t_p1 })
}

/// ```prism
/// ResolveIn: unbounded fn St, Ty -> Ty
/// ```
pub fn resolve_in_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p1 {
        crate::check::types::Ty::TyCon(n_p2, args_p3) => crate::check::types::Ty::TyCon(n_p2.clone(), crate::prelude::run_to_end(crate::prelude::each_job(args_p3.clone(), {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p4 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ResolveIn { st_p0: st_p0xy.clone(), t_p1: a_p4.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c_p5, ps_p6, res_p7) => crate::check::types::Ty::TyFn(resolve_col_f(st_p0, c_p5), crate::prelude::run_to_end(crate::prelude::each_job(ps_p6.clone(), {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let p_p8 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ResolveIn { st_p0: st_p0xy.clone(), t_p1: p_p8.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        })), ::std::rc::Rc::new(resolve_in_f(st_p0, &**res_p7))),
        crate::check::types::Ty::TyTuple(ts_p9) => crate::check::types::Ty::TyTuple(crate::prelude::run_to_end(crate::prelude::each_job(ts_p9.clone(), {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pa = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ResolveIn { st_p0: st_p0xy.clone(), t_p1: a_pa.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e_pb) => crate::check::types::Ty::TyArray(::std::rc::Rc::new(resolve_in_f(st_p0, &**e_pb))),
        crate::check::types::Ty::TyMap(k_pc, v_pd) => crate::check::types::Ty::TyMap(::std::rc::Rc::new(resolve_in_f(st_p0, &**k_pc)), ::std::rc::Rc::new(resolve_in_f(st_p0, &**v_pd))),
        crate::check::types::Ty::TySig(s_pe, i_pf) => crate::check::types::Ty::TySig(s_pe.clone(), ::std::rc::Rc::new(resolve_in_f(st_p0, &**i_pf))),
        crate::check::types::Ty::TyAt(i_pg, rw_ph) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(resolve_in_f(st_p0, &**i_pg)), rw_ph.clone()),
        crate::check::types::Ty::TyElem(rw_pi, o_pj) => crate::check::types::Ty::TyElem(rw_pi.clone(), ::std::rc::Rc::new(resolve_in_f(st_p0, &**o_pj))),
        crate::check::types::Ty::TyAssoc(tr_pk, n_pl, a_pm) => crate::check::types::Ty::TyAssoc(tr_pk.clone(), n_pl.clone(), ::std::rc::Rc::new(resolve_in_f(st_p0, &**a_pm))),
        other_pn => other_pn.clone(),
    }
}

/// The step machine of `ResolveIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveIn: unbounded fn St, Ty -> Ty
/// ```
pub struct ResolveIn {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for ResolveIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyCon(n_p2, args_p3) => {
                let args_p3x = args_p3.clone();
                let n_p2x = n_p2.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p3x.clone(), {
                    let st_p0xx = st_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let st_p0xxy = st_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p4 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ResolveIn { st_p0: st_p0xxy.clone(), t_p1: a_p4.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_16961: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p2x.clone(), each_16961)))
            },
            crate::check::types::Ty::TyFn(c_p5, ps_p6, res_p7) => {
                let c_p5x = c_p5.clone();
                let ps_p6x = ps_p6.clone();
                let res_p7x = (**res_p7).clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_resolve_col_f(st_p0x.clone(), c_p5x.clone()), move |resolve_col_f_17021: crate::check::types::Col| crate::prelude::call_value(crate::prelude::each_job(ps_p6x.clone(), {
                    let st_p0xx = st_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let st_p0xxy = st_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let p_p8 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ResolveIn { st_p0: st_p0xxy.clone(), t_p1: p_p8.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_17041: crate::prelude::Array<crate::check::types::Ty>| crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), res_p7x.clone()), move |resolve_in_f_17074: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(resolve_col_f_17021, each_17041, ::std::rc::Rc::new(resolve_in_f_17074))))))
            },
            crate::check::types::Ty::TyTuple(ts_p9) => {
                let st_p0x = st_p0.clone();
                let ts_p9x = ts_p9.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_p9x.clone(), {
                    let st_p0xx = st_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let st_p0xxy = st_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pa = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ResolveIn { st_p0: st_p0xxy.clone(), t_p1: a_pa.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_17118: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_17118)))
            },
            crate::check::types::Ty::TyArray(e_pb) => {
                let e_pbx = (**e_pb).clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), e_pbx.clone()), move |resolve_in_f_17173: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(::std::rc::Rc::new(resolve_in_f_17173))))
            },
            crate::check::types::Ty::TyMap(k_pc, v_pd) => {
                let k_pcx = (**k_pc).clone();
                let st_p0x = st_p0.clone();
                let v_pdx = (**v_pd).clone();
                crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), k_pcx.clone()), move |resolve_in_f_17213: crate::check::types::Ty| crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), v_pdx.clone()), move |resolve_in_f_17232: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(::std::rc::Rc::new(resolve_in_f_17213), ::std::rc::Rc::new(resolve_in_f_17232)))))
            },
            crate::check::types::Ty::TySig(s_pe, i_pf) => {
                let i_pfx = (**i_pf).clone();
                let s_pex = s_pe.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), i_pfx.clone()), move |resolve_in_f_17275: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pex.clone(), ::std::rc::Rc::new(resolve_in_f_17275))))
            },
            crate::check::types::Ty::TyAt(i_pg, rw_ph) => {
                let i_pgx = (**i_pg).clone();
                let rw_phx = rw_ph.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), i_pgx.clone()), move |resolve_in_f_17314: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(::std::rc::Rc::new(resolve_in_f_17314), rw_phx.clone())))
            },
            crate::check::types::Ty::TyElem(rw_pi, o_pj) => {
                let o_pjx = (**o_pj).clone();
                let rw_pix = rw_pi.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), o_pjx.clone()), move |resolve_in_f_17365: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(rw_pix.clone(), ::std::rc::Rc::new(resolve_in_f_17365))))
            },
            crate::check::types::Ty::TyAssoc(tr_pk, n_pl, a_pm) => {
                let a_pmx = (**a_pm).clone();
                let n_plx = n_pl.clone();
                let st_p0x = st_p0.clone();
                let tr_pkx = tr_pk.clone();
                crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), a_pmx.clone()), move |resolve_in_f_17420: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(tr_pkx.clone(), n_plx.clone(), ::std::rc::Rc::new(resolve_in_f_17420))))
            },
            other_pn => ::prism_rtl::Turn::Finished(other_pn.clone()),
        }
    }
}

/// `Start ResolveIn, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_in_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(ResolveIn { st_p0, t_p1 })
}

/// ```prism
/// AtBinder: fn St, Ty, Range -> St
/// ```
pub fn at_binder_f(st_p0: &crate::check::types::St, ty1: &crate::check::types::Ty, range2: &crate::syntax::Range) -> crate::check::types::St {
    match (ty1, range2) {
        (crate::check::types::Ty::TyFlex(n_p1), span_p2) => {
            let mut this: crate::check::types::St = st_p0.clone();
            this.binder_at_p = crate::prelude::insert(&this.binder_at_p, n_p1, span_p2);
            this
        },
        (_, _) => st_p0.clone(),
    }
}

/// ```prism
/// FreshRow: fn St, [Text] -> ((Rw, St))
/// ```
pub fn fresh_row_f(st_p0: &crate::check::types::St, lacking_p1: &crate::prelude::Array<crate::prelude::Text>) -> (crate::check::types::Rw, crate::check::types::St) {
    let n_p2 = st_p0.next_p.clone();
    let st2_p3 = {
        let mut this: crate::check::types::St = st_p0.clone();
        this.next_p = &this.next_p + &crate::prelude::Nat::from(1u32);
        this.lacks_p = crate::prelude::insert(&this.lacks_p, &n_p2, lacking_p1);
        this
    };
    (crate::check::types::Rw { fams_p: crate::prelude::Array::new(), minus_p: crate::prelude::Array::new(), tail_p: crate::check::types::Tail::TlFlex(n_p2.clone()) }, st2_p3.clone())
}

/// ```prism
/// AddDiag: fn St, CDiag -> St
/// ```
pub fn add_diag_f(st_p0: &crate::check::types::St, d_p1: &crate::check::errors::CDiag) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.diags_p = crate::prelude::push(&this.diags_p, d_p1);
    this
}

/// ```prism
/// Err: fn St, Text, Range, Text -> St
/// ```
pub fn err_f(st_p0: &crate::check::types::St, code_p1: &crate::prelude::Text, span_p2: &crate::syntax::Range, message_p3: &crate::prelude::Text) -> crate::check::types::St {
    add_diag_f(st_p0, &crate::check::errors::diag0_f(code_p1, &st_p0.file_p, span_p2, message_p3))
}

/// ```prism
/// ErrFix: fn St, Text, Range, Text, Text -> St
/// ```
pub fn err_fix_f(st_p0: &crate::check::types::St, code_p1: &crate::prelude::Text, span_p2: &crate::syntax::Range, message_p3: &crate::prelude::Text, fix_p4: &crate::prelude::Text) -> crate::check::types::St {
    add_diag_f(st_p0, &crate::check::errors::diag_fix_f(code_p1, &st_p0.file_p, span_p2, message_p3, fix_p4))
}

/// ```prism
/// InfoOf: fn St, Nat -> VInfo
/// ```
pub fn info_of_f(st_p0: &crate::check::types::St, n_p1: &crate::prelude::Nat) -> crate::check::types::VInfo {
    crate::prelude::or(&crate::prelude::get(&st_p0.infos_p, n_p1), &crate::check::types::VInfo { plain_p: false, level_p: crate::prelude::Nat::from(0u32), name_p: crate::prelude::Text::lit("") })
}

/// ```prism
/// Walk: unbounded fn St, Ty -> Ty
/// ```
pub fn walk_f(st_p0: &crate::check::types::St, ty1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match ty1 {
        crate::check::types::Ty::TyFlex(n_p1) => match crate::prelude::get(&st_p0.tys_p, n_p1) {
            ::std::option::Option::Some(t_p2) => walk_f(st_p0, &t_p2),
            ::std::option::Option::None => crate::check::types::Ty::TyFlex(n_p1.clone()),
        },
        t_p4 => t_p4.clone(),
    }
}

/// The step machine of `Walk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Walk: unbounded fn St, Ty -> Ty
/// ```
pub struct Walk {
    pub st_p0: crate::check::types::St,
    pub ty1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for Walk {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let ty1 = &self.ty1;
        match ty1 {
            crate::check::types::Ty::TyFlex(n_p1) => match crate::prelude::get(&st_p0.tys_p, n_p1) {
                ::std::option::Option::Some(t_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Walk { st_p0: st_p0.clone(), ty1: t_p2.clone() })),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyFlex(n_p1.clone())),
            },
            t_p4 => ::prism_rtl::Turn::Finished(t_p4.clone()),
        }
    }
}

/// `Start Walk, x`: what the function value is when passed to `@Run`.
pub fn start_walk_f(st_p0: crate::check::types::St, ty1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(Walk { st_p0, ty1 })
}

/// ```prism
/// WalkRow: unbounded fn St, Rw -> Rw
/// ```
pub fn walk_row_f(st_p0: &crate::check::types::St, r_p1: &crate::check::types::Rw) -> crate::check::types::Rw {
    match &r_p1.tail_p {
        crate::check::types::Tail::TlFlex(n_p2) => match crate::prelude::get(&st_p0.rows_p, n_p2) {
            ::std::option::Option::Some(r2_p3) => {
                let w_p4 = walk_row_f(st_p0, &r2_p3);
                crate::check::types::Rw { fams_p: crate::check::types::sort_texts_f(&crate::check::types::union_texts_f(&r_p1.fams_p, &w_p4.fams_p)), minus_p: crate::check::types::union_texts_f(&r_p1.minus_p, &w_p4.minus_p), tail_p: w_p4.tail_p.clone() }
            },
            ::std::option::Option::None => r_p1.clone(),
        },
        _ => r_p1.clone(),
    }
}

/// The step machine of `WalkRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkRow: unbounded fn St, Rw -> Rw
/// ```
pub struct WalkRow {
    pub st_p0: crate::check::types::St,
    pub r_p1: crate::check::types::Rw,
}

impl ::prism_rtl::Job<crate::check::types::Rw> for WalkRow {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Rw> {
        let st_p0 = &self.st_p0;
        let r_p1 = &self.r_p1;
        match &r_p1.tail_p {
            crate::check::types::Tail::TlFlex(n_p2) => match crate::prelude::get(&st_p0.rows_p, n_p2) {
                ::std::option::Option::Some(r2_p3) => {
                    let r_p1x = r_p1.clone();
                    let st_p0x = st_p0.clone();
                    crate::prelude::call_then(start_walk_row_f(st_p0x.clone(), r2_p3.clone()), move |walk_row_f_18787: crate::check::types::Rw| {
                        let w_p4 = walk_row_f_18787;
                        ::prism_rtl::Turn::Finished(crate::check::types::Rw { fams_p: crate::check::types::sort_texts_f(&crate::check::types::union_texts_f(&r_p1x.fams_p, &w_p4.fams_p)), minus_p: crate::check::types::union_texts_f(&r_p1x.minus_p, &w_p4.minus_p), tail_p: w_p4.tail_p.clone() })
                    })
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(r_p1.clone()),
            },
            _ => ::prism_rtl::Turn::Finished(r_p1.clone()),
        }
    }
}

/// `Start WalkRow, x`: what the function value is when passed to `@Run`.
pub fn start_walk_row_f(st_p0: crate::check::types::St, r_p1: crate::check::types::Rw) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Rw>> {
    ::std::rc::Rc::new(WalkRow { st_p0, r_p1 })
}

/// ```prism
/// Zonk: unbounded fn St, Ty -> Ty
/// ```
pub fn zonk_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match crate::check::types::unify::norm_assoc_f(st_p0, &walk_f(st_p0, t_p1)) {
        crate::check::types::Ty::TyCon(n_p2, args_p3) => crate::check::types::Ty::TyCon(n_p2.clone(), crate::prelude::run_to_end(crate::prelude::each_job(args_p3.clone(), {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p4 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Zonk { st_p0: st_p0xy.clone(), t_p1: a_p4.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c_p5, ps_p6, res_p7) => crate::check::types::Ty::TyFn(crate::check::types::colors::walk_col_f(st_p0, &c_p5), crate::prelude::run_to_end(crate::prelude::each_job(ps_p6.clone(), {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let p_p8 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Zonk { st_p0: st_p0xy.clone(), t_p1: p_p8.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        })), ::std::rc::Rc::new(zonk_f(st_p0, &*res_p7))),
        crate::check::types::Ty::TyTuple(ts_p9) => crate::check::types::Ty::TyTuple(crate::prelude::run_to_end(crate::prelude::each_job(ts_p9.clone(), {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pa = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Zonk { st_p0: st_p0xy.clone(), t_p1: a_pa.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e_pb) => crate::check::types::Ty::TyArray(::std::rc::Rc::new(zonk_f(st_p0, &*e_pb))),
        crate::check::types::Ty::TyMap(k_pc, v_pd) => crate::check::types::Ty::TyMap(::std::rc::Rc::new(zonk_f(st_p0, &*k_pc)), ::std::rc::Rc::new(zonk_f(st_p0, &*v_pd))),
        crate::check::types::Ty::TySig(s_pe, i_pf) => crate::check::types::Ty::TySig(s_pe, ::std::rc::Rc::new(zonk_f(st_p0, &*i_pf))),
        crate::check::types::Ty::TyAt(i_pg, rw_ph) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(zonk_f(st_p0, &*i_pg)), walk_row_f(st_p0, &rw_ph)),
        crate::check::types::Ty::TyElem(rw_pi, o_pj) => crate::check::types::Ty::TyElem(walk_row_f(st_p0, &rw_pi), ::std::rc::Rc::new(zonk_f(st_p0, &*o_pj))),
        crate::check::types::Ty::TyElemAny(rw_pk) => crate::check::types::Ty::TyElemAny(walk_row_f(st_p0, &rw_pk)),
        crate::check::types::Ty::TyAssoc(tr_pl, n_pm, a_pn) => crate::check::types::Ty::TyAssoc(tr_pl, n_pm, ::std::rc::Rc::new(zonk_f(st_p0, &*a_pn))),
        w_po => w_po,
    }
}

/// The step machine of `Zonk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Zonk: unbounded fn St, Ty -> Ty
/// ```
pub struct Zonk {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for Zonk {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_19078: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::unify::start_norm_assoc_f(st_p0x.clone(), walk_f_19078), move |norm_assoc_f_19063: crate::check::types::Ty| match norm_assoc_f_19063 {
            crate::check::types::Ty::TyCon(n_p2, args_p3) => crate::prelude::call_value(crate::prelude::each_job(args_p3.clone(), {
                let st_p0xx = st_p0x.clone();
                ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p4 = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Zonk { st_p0: st_p0xxy.clone(), t_p1: a_p4.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_19120: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p2.clone(), each_19120))),
            crate::check::types::Ty::TyFn(c_p5, ps_p6, res_p7) => crate::prelude::call_then(crate::check::types::colors::start_walk_col_f(st_p0x.clone(), c_p5.clone()), move |walk_col_f_19175: crate::check::types::Col| crate::prelude::call_value(crate::prelude::each_job(ps_p6.clone(), {
                let st_p0xx = st_p0x.clone();
                ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let p_p8 = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Zonk { st_p0: st_p0xxy.clone(), t_p1: p_p8.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_19192: crate::prelude::Array<crate::check::types::Ty>| crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*res_p7).clone()), move |zonk_f_19220: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(walk_col_f_19175, each_19192, ::std::rc::Rc::new(zonk_f_19220)))))),
            crate::check::types::Ty::TyTuple(ts_p9) => crate::prelude::call_value(crate::prelude::each_job(ts_p9.clone(), {
                let st_p0xx = st_p0x.clone();
                ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_pa = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Zonk { st_p0: st_p0xxy.clone(), t_p1: a_pa.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_19259: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_19259))),
            crate::check::types::Ty::TyArray(e_pb) => crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*e_pb).clone()), move |zonk_f_19309: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(::std::rc::Rc::new(zonk_f_19309)))),
            crate::check::types::Ty::TyMap(k_pc, v_pd) => crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*k_pc).clone()), move |zonk_f_19344: crate::check::types::Ty| crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*v_pd).clone()), move |zonk_f_19358: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(::std::rc::Rc::new(zonk_f_19344), ::std::rc::Rc::new(zonk_f_19358))))),
            crate::check::types::Ty::TySig(s_pe, i_pf) => crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*i_pf).clone()), move |zonk_f_19396: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pe.clone(), ::std::rc::Rc::new(zonk_f_19396)))),
            crate::check::types::Ty::TyAt(i_pg, rw_ph) => crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*i_pg).clone()), move |zonk_f_19430: crate::check::types::Ty| crate::prelude::call_then(start_walk_row_f(st_p0x.clone(), rw_ph.clone()), move |walk_row_f_19444: crate::check::types::Rw| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(::std::rc::Rc::new(zonk_f_19430), walk_row_f_19444)))),
            crate::check::types::Ty::TyElem(rw_pi, o_pj) => crate::prelude::call_then(start_walk_row_f(st_p0x.clone(), rw_pi.clone()), move |walk_row_f_19486: crate::check::types::Rw| crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*o_pj).clone()), move |zonk_f_19504: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(walk_row_f_19486, ::std::rc::Rc::new(zonk_f_19504))))),
            crate::check::types::Ty::TyElemAny(rw_pk) => crate::prelude::call_then(start_walk_row_f(st_p0x.clone(), rw_pk.clone()), move |walk_row_f_19545: crate::check::types::Rw| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyElemAny(walk_row_f_19545))),
            crate::check::types::Ty::TyAssoc(tr_pl, n_pm, a_pn) => crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*a_pn).clone()), move |zonk_f_19599: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(tr_pl.clone(), n_pm.clone(), ::std::rc::Rc::new(zonk_f_19599)))),
            w_po => ::prism_rtl::Turn::Finished(w_po.clone()),
        }))
    }
}

/// `Start Zonk, x`: what the function value is when passed to `@Run`.
pub fn start_zonk_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(Zonk { st_p0, t_p1 })
}

/// ```prism
/// FreeVars: unbounded fn St, Ty -> [Nat]
/// ```
pub fn free_vars_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::prelude::Array<crate::prelude::Nat> {
    free_vars_into_f(st_p0, &crate::prelude::Array::new(), t_p1)
}

/// The step machine of `FreeVars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeVars: unbounded fn St, Ty -> [Nat]
/// ```
pub struct FreeVars {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>> for FreeVars {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Nat>> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: crate::prelude::Array::new(), t_p2: t_p1.clone() }))
    }
}

/// `Start FreeVars, x`: what the function value is when passed to `@Run`.
pub fn start_free_vars_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>> {
    ::std::rc::Rc::new(FreeVars { st_p0, t_p1 })
}

/// ```prism
/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub fn free_vars_into_f(st_p0: &crate::check::types::St, acc_p1: &crate::prelude::Array<crate::prelude::Nat>, t_p2: &crate::check::types::Ty) -> crate::prelude::Array<crate::prelude::Nat> {
    match walk_f(st_p0, t_p2) {
        crate::check::types::Ty::TyFlex(n_p3) => crate::check::types::add_nat_f(acc_p1, &n_p3),
        crate::check::types::Ty::TyCon(_, args_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p4.clone(), acc_p1.clone(), {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Ty)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p5 = p0;
                    let x_p6 = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0xy.clone(), acc_p1: a_p5.clone(), t_p2: x_p6.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
        })),
        crate::check::types::Ty::TyFn(_, ps_p7, res_p8) => free_vars_into_f(st_p0, &crate::prelude::run_to_end(crate::prelude::fold_job(ps_p7.clone(), acc_p1.clone(), {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Ty)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p9 = p0;
                    let x_pa = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0xy.clone(), acc_p1: a_p9.clone(), t_p2: x_pa.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
        })), &*res_p8),
        crate::check::types::Ty::TyTuple(ts_pb) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_pb.clone(), acc_p1.clone(), {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Ty)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pc = p0;
                    let x_pd = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0xy.clone(), acc_p1: a_pc.clone(), t_p2: x_pd.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
        })),
        crate::check::types::Ty::TyArray(e_pe) => free_vars_into_f(st_p0, acc_p1, &*e_pe),
        crate::check::types::Ty::TyMap(k_pf, v_pg) => free_vars_into_f(st_p0, &free_vars_into_f(st_p0, acc_p1, &*k_pf), &*v_pg),
        crate::check::types::Ty::TySig(_, i_ph) => free_vars_into_f(st_p0, acc_p1, &*i_ph),
        crate::check::types::Ty::TyAt(i_pi, _) => free_vars_into_f(st_p0, acc_p1, &*i_pi),
        crate::check::types::Ty::TyElem(_, o_pj) => free_vars_into_f(st_p0, acc_p1, &*o_pj),
        crate::check::types::Ty::TyAssoc(_, _, a_pk) => free_vars_into_f(st_p0, acc_p1, &*a_pk),
        _ => acc_p1.clone(),
    }
}

/// The step machine of `FreeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub struct FreeVarsInto {
    pub st_p0: crate::check::types::St,
    pub acc_p1: crate::prelude::Array<crate::prelude::Nat>,
    pub t_p2: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>> for FreeVarsInto {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Nat>> {
        let st_p0 = &self.st_p0;
        let acc_p1 = &self.acc_p1;
        let t_p2 = &self.t_p2;
        let acc_p1x = acc_p1.clone();
        let st_p0x = st_p0.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(start_walk_f(st_p0x.clone(), t_p2x.clone()), move |walk_f_19832: crate::check::types::Ty| match walk_f_19832 {
            crate::check::types::Ty::TyFlex(n_p3) => ::prism_rtl::Turn::Finished(crate::check::types::add_nat_f(&acc_p1x, &n_p3)),
            crate::check::types::Ty::TyCon(_, args_p4) => crate::prelude::fold_job(args_p4.clone(), acc_p1x.clone(), {
                let st_p0xx = st_p0x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Ty)| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p5 = p0;
                        let x_p6 = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0xxy.clone(), acc_p1: a_p5.clone(), t_p2: x_p6.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
            }).cycle(),
            crate::check::types::Ty::TyFn(_, ps_p7, res_p8) => crate::prelude::call_value(crate::prelude::fold_job(ps_p7.clone(), acc_p1x.clone(), {
                let st_p0xx = st_p0x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Ty)| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p9 = p0;
                        let x_pa = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0xxy.clone(), acc_p1: a_p9.clone(), t_p2: x_pa.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
            }), move |fold_19986: crate::prelude::Array<crate::prelude::Nat>| ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0x.clone(), acc_p1: fold_19986, t_p2: (*res_p8).clone() }))),
            crate::check::types::Ty::TyTuple(ts_pb) => crate::prelude::fold_job(ts_pb.clone(), acc_p1x.clone(), {
                let st_p0xx = st_p0x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Ty)| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_pc = p0;
                        let x_pd = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0xxy.clone(), acc_p1: a_pc.clone(), t_p2: x_pd.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e_pe) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*e_pe).clone() })),
            crate::check::types::Ty::TyMap(k_pf, v_pg) => crate::prelude::call_then(start_free_vars_into_f(st_p0x.clone(), acc_p1x.clone(), (*k_pf).clone()), move |free_vars_into_f_20169: crate::prelude::Array<crate::prelude::Nat>| ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0x.clone(), acc_p1: free_vars_into_f_20169, t_p2: (*v_pg).clone() }))),
            crate::check::types::Ty::TySig(_, i_ph) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*i_ph).clone() })),
            crate::check::types::Ty::TyAt(i_pi, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*i_pi).clone() })),
            crate::check::types::Ty::TyElem(_, o_pj) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*o_pj).clone() })),
            crate::check::types::Ty::TyAssoc(_, _, a_pk) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FreeVarsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*a_pk).clone() })),
            _ => ::prism_rtl::Turn::Finished(acc_p1x.clone()),
        })
    }
}

/// `Start FreeVarsInto, x`: what the function value is when passed to `@Run`.
pub fn start_free_vars_into_f(st_p0: crate::check::types::St, acc_p1: crate::prelude::Array<crate::prelude::Nat>, t_p2: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>> {
    ::std::rc::Rc::new(FreeVarsInto { st_p0, acc_p1, t_p2 })
}
