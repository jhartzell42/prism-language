//! The module `Check.Types.Recording`, from `target/bootstrap/src/prismc/check/types/recording.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// AtHere: fn St, Range -> SrcAt
/// ```
pub fn at_here(st: &crate::check::types::St, span: &crate::syntax::Range) -> crate::check::typed::SrcAt {
    crate::check::typed::SrcAt { file: st.file.clone(), span: span.clone() }
}

/// ```prism
/// NoteTy: fn St, Range, Ty -> St
/// ```
pub fn note_ty(st: &crate::check::types::St, span: &crate::syntax::Range, t: &crate::check::types::Ty) -> crate::check::types::St {
    if !st.recording {
        st.clone()
    } else {
        {
            let mut this: crate::check::types::St = st.clone();
            this.typed.exprs = push(&this.typed.exprs, &crate::check::typed::TyNote { at: at_here(st, span), ty: t.clone() });
            this
        }
    }
}

/// ```prism
/// NoteBinder: fn St, Range, Text, Ty -> St
/// ```
pub fn note_binder(st: &crate::check::types::St, span: &crate::syntax::Range, name: &Text, t: &crate::check::types::Ty) -> crate::check::types::St {
    if !st.recording {
        st.clone()
    } else {
        {
            let mut this: crate::check::types::St = st.clone();
            this.typed.binders = push(&this.typed.binders, &crate::check::typed::BinderNote { at: at_here(st, span), name: name.clone(), ty: t.clone() });
            this
        }
    }
}

/// ```prism
/// NoteGen: fn St, Range, Text, Scheme -> St
/// ```
pub fn note_gen(st: &crate::check::types::St, span: &crate::syntax::Range, name: &Text, sc: &crate::check::types::Scheme) -> crate::check::types::St {
    if !st.recording || ((&len(&sc.qs) == &Nat::from(0u32)) && (&len(&sc.cqs) == &Nat::from(0u32))) {
        st.clone()
    } else {
        {
            let mut this: crate::check::types::St = st.clone();
            this.typed.gens = push(&this.typed.gens, &crate::check::typed::GenNote { at: at_here(st, span), name: name.clone(), tys: sc.qs.clone(), cols: sc.cqs.clone() });
            this
        }
    }
}

/// ```prism
/// NoteInst: fn St, Range, Text, Scheme, Inst -> St
/// ```
pub fn note_inst(st: &crate::check::types::St, span: &crate::syntax::Range, name: &Text, sc: &crate::check::types::Scheme, inst: &crate::check::types::schemes::Inst) -> crate::check::types::St {
    if !st.recording {
        st.clone()
    } else {
        {
            let mut this: crate::check::types::St = st.clone();
            this.typed.insts = push(&this.typed.insts, &crate::check::typed::InstNote { at: at_here(st, span), name: name.clone(), tys: each(&sc.qs, &(|q: &Text| (q.clone(), or(&get(&inst.tys, q), &crate::check::types::Ty::TyErr)))), cols: each(&sc.cqs, &(|q: &Text| (q.clone(), or(&get(&inst.cols, q), &crate::check::types::Col::CBound)))) });
            this
        }
    }
}

/// ```prism
/// NoteApp: fn St, Range, Text, Text, Text, [Nat], Text, Col -> St
/// ```
pub fn note_app(st: &crate::check::types::St, span: &crate::syntax::Range, callee: &Text, kind: &Text, layer: &Text, lifted: &Array<Nat>, inner: &Text, col: &crate::check::types::Col) -> crate::check::types::St {
    if !st.recording {
        st.clone()
    } else {
        {
            let mut this: crate::check::types::St = st.clone();
            this.typed.apps = push(&this.typed.apps, &crate::check::typed::AppNote { at: at_here(st, span), callee: callee.clone(), kind: kind.clone(), layer: layer.clone(), lifted: lifted.clone(), inner: inner.clone(), color: col.clone() });
            this
        }
    }
}

/// ```prism
/// NoteLift: fn St, Range, Text, [Range] -> St
/// ```
pub fn note_lift(st: &crate::check::types::St, span: &crate::syntax::Range, sigil: &Text, operands: &Array<crate::syntax::Range>) -> crate::check::types::St {
    if !st.recording || (&len(operands) == &Nat::from(0u32)) {
        st.clone()
    } else {
        {
            let mut this: crate::check::types::St = st.clone();
            this.typed.lifts = push(&this.typed.lifts, &crate::check::typed::LiftNote { at: at_here(st, span), sigil: sigil.clone(), operands: operands.clone() });
            this
        }
    }
}

/// ```prism
/// NoteFn: fn St, Range, Text, Col, Col -> St
/// ```
pub fn note_fn(st: &crate::check::types::St, span: &crate::syntax::Range, name: &Text, declared: &crate::check::types::Col, body: &crate::check::types::Col) -> crate::check::types::St {
    if !st.recording {
        st.clone()
    } else {
        {
            let mut this: crate::check::types::St = st.clone();
            this.typed.fns = push(&this.typed.fns, &crate::check::typed::FnNote { at: at_here(st, span), name: name.clone(), declared: declared.clone(), body: body.clone() });
            this
        }
    }
}

/// ```prism
/// NoteImpl: fn St, Nat, Range, Text, Ty, Text -> St
/// ```
pub fn note_impl(st: &crate::check::types::St, file: &Nat, span: &crate::syntax::Range, cls: &Text, t: &crate::check::types::Ty, how: &Text) -> crate::check::types::St {
    if ((!st.recording || crate::syntax::lexer::chars::has_prefix(cls, &Text::lit("Range "))) || (cls == &Text::lit("Prelude.Sub"))) || (cls == &Text::lit("Prelude.Signed")) {
        st.clone()
    } else {
        {
            let mut this: crate::check::types::St = st.clone();
            this.typed.impls = push(&this.typed.impls, &crate::check::typed::ImplNote { at: crate::check::typed::SrcAt { file: file.clone(), span: span.clone() }, cls: cls.clone(), ty: t.clone(), how: how.clone() });
            this
        }
    }
}

/// ```prism
/// NoteChoice: fn St, Nat, Range, Text, Text -> St
/// ```
pub fn note_choice(st: &crate::check::types::St, file: &Nat, span: &crate::syntax::Range, cls: &Text, ch: &Text) -> crate::check::types::St {
    let k = choice_key(file, span, cls);
    if (crate::syntax::lexer::chars::has_prefix(cls, &Text::lit("Range ")) || (cls == &Text::lit("Prelude.Sub"))) || (cls == &Text::lit("Prelude.Signed")) {
        st.clone()
    } else {
        {
            let mut this: crate::check::types::St = st.clone();
            this.choices = insert(&this.choices, &k, &crate::check::types::add_text(&or(&get(&this.choices, &k), &Array::new()), ch));
            this
        }
    }
}

/// ```prism
/// NoteSizeTy: fn St, Range, Ty -> St
/// ```
pub fn note_size_ty(st: &crate::check::types::St, span: &crate::syntax::Range, t: &crate::check::types::Ty) -> crate::check::types::St {
    match t {
        crate::check::types::Ty::TyFn(_, ps, _) => match index(ps, &Nat::from(0u32)) {
            Some(p_) => {
                let mut this: crate::check::types::St = st.clone();
                this.size_tys = insert(&this.size_tys, &Text::from(format!("{}:{}:{}", &st.file, &span.start, &span.end)), &p_);
                this
            },
            None => st.clone(),
        },
        _ => st.clone(),
    }
}

/// ```prism
/// ChoiceKey: fn Nat, Range, Text -> Text
/// ```
pub fn choice_key(file: &Nat, span: &crate::syntax::Range, cls: &Text) -> Text {
    Text::from(format!("{}:{}:{}:{}", file, &span.start, &span.end, cls))
}

/// ```prism
/// NoteMethod: fn St, Range, Text, Text -> St
/// ```
pub fn note_method(st: &crate::check::types::St, span: &crate::syntax::Range, method: &Text, cls: &Text) -> crate::check::types::St {
    if !st.recording {
        st.clone()
    } else {
        {
            let mut this: crate::check::types::St = st.clone();
            this.typed.methods = push(&this.typed.methods, &crate::check::typed::MethodNote { at: at_here(st, span), method: method.clone(), cls: cls.clone() });
            this
        }
    }
}

/// ```prism
/// NoteGroup: fn St, Range, Text, [ [Nat] ] -> St
/// ```
pub fn note_group(st: &crate::check::types::St, span: &crate::syntax::Range, kind: &Text, order: &Array<Array<Nat>>) -> crate::check::types::St {
    if !st.recording {
        st.clone()
    } else {
        {
            let mut this: crate::check::types::St = st.clone();
            this.typed.groups = push(&this.typed.groups, &crate::check::typed::GroupNote { at: at_here(st, span), kind: kind.clone(), order: order.clone() });
            this
        }
    }
}

/// ```prism
/// ZonkTyped: unbounded fn St -> TProgram
/// ```
pub fn zonk_typed(st: &crate::check::types::St) -> crate::check::typed::TProgram {
    let t = st.typed.clone();
    let mut this: crate::check::typed::TProgram = t.clone();
    this.exprs = run_to_end(each_job(this.exprs.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::typed::TyNote| {
            let st = st.clone();
            entered(once_job(move || {
                let n = p0;
                call_then(start_resolve_ty(st.clone(), n.ty.clone()), move |resolve_ty_5437: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::TyNote { at: n.at.clone(), ty: resolve_ty_5437 }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::TyNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::TyNote>>>
    }));
    this.binders = run_to_end(each_job(this.binders.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::typed::BinderNote| {
            let st = st.clone();
            entered(once_job(move || {
                let n = p0;
                call_then(start_resolve_ty(st.clone(), n.ty.clone()), move |resolve_ty_5539: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::BinderNote { at: n.at.clone(), name: n.name.clone(), ty: resolve_ty_5539 }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::BinderNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::BinderNote>>>
    }));
    this.insts = run_to_end(each_job(this.insts.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::typed::InstNote| {
            let st = st.clone();
            entered(once_job(move || {
                let n = p0;
                call_value(each_job(n.tys.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let (q, x) = p0;
                            call_then(start_resolve_ty(st.clone(), x.clone()), move |resolve_ty_5666: crate::check::types::Ty| prism_rtl::Turn::Finished((q.clone(), resolve_ty_5666)))
                        }))
                    }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Ty)>>>
                }), move |each_5636: Array<(Text, crate::check::types::Ty)>| call_value(each_job(n.cols.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: (Text, crate::check::types::Col)| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let (q, c) = p0;
                            call_then(start_resolve_col(st.clone(), c.clone()), move |resolve_col_5724: crate::check::types::Col| prism_rtl::Turn::Finished((q.clone(), resolve_col_5724)))
                        }))
                    }) as Rc<dyn Fn((Text, crate::check::types::Col)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Col)>>>
                }), move |each_5693: Array<(Text, crate::check::types::Col)>| prism_rtl::Turn::Finished(crate::check::typed::InstNote { at: n.at.clone(), name: n.name.clone(), tys: each_5636, cols: each_5693 })))
            }))
        }) as Rc<dyn Fn(crate::check::typed::InstNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::InstNote>>>
    }));
    this.impls = run_to_end(each_job(this.impls.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::typed::ImplNote| {
            let st = st.clone();
            entered(once_job(move || {
                let n = p0;
                call_then(start_resolve_ty(st.clone(), n.ty.clone()), move |resolve_ty_5819: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::ImplNote { at: n.at.clone(), cls: n.cls.clone(), ty: resolve_ty_5819, how: n.how.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::ImplNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::ImplNote>>>
    }));
    this.apps = run_to_end(each_job(this.apps.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::typed::AppNote| {
            let st = st.clone();
            entered(once_job(move || {
                let n = p0;
                call_then(start_resolve_col(st.clone(), n.color.clone()), move |resolve_col_5990: crate::check::types::Col| prism_rtl::Turn::Finished(crate::check::typed::AppNote { at: n.at.clone(), callee: n.callee.clone(), kind: n.kind.clone(), layer: n.layer.clone(), lifted: n.lifted.clone(), inner: n.inner.clone(), color: resolve_col_5990 }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::AppNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::AppNote>>>
    }));
    this.fns = run_to_end(each_job(this.fns.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::typed::FnNote| {
            let st = st.clone();
            entered(once_job(move || {
                let n = p0;
                call_then(start_resolve_col(st.clone(), n.declared.clone()), move |resolve_col_6090: crate::check::types::Col| call_then(start_resolve_col(st.clone(), n.body.clone()), move |resolve_col_6124: crate::check::types::Col| prism_rtl::Turn::Finished(crate::check::typed::FnNote { at: n.at.clone(), name: n.name.clone(), declared: resolve_col_6090, body: resolve_col_6124 })))
            }))
        }) as Rc<dyn Fn(crate::check::typed::FnNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::FnNote>>>
    }));
    this
}

/// The step machine of `ZonkTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ZonkTyped: unbounded fn St -> TProgram
/// ```
pub struct ZonkTyped {
    pub st: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::typed::TProgram> for ZonkTyped {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::typed::TProgram> {
        let st = &self.st;
        let t = st.typed.clone();
        prism_rtl::Turn::Finished({
            let mut this: crate::check::typed::TProgram = t.clone();
            this.exprs = run_to_end(each_job(this.exprs.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::typed::TyNote| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let n = p0;
                        call_then(start_resolve_ty(st.clone(), n.ty.clone()), move |resolve_ty_5437: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::TyNote { at: n.at.clone(), ty: resolve_ty_5437 }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::TyNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::TyNote>>>
            }));
            this.binders = run_to_end(each_job(this.binders.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::typed::BinderNote| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let n = p0;
                        call_then(start_resolve_ty(st.clone(), n.ty.clone()), move |resolve_ty_5539: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::BinderNote { at: n.at.clone(), name: n.name.clone(), ty: resolve_ty_5539 }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::BinderNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::BinderNote>>>
            }));
            this.insts = run_to_end(each_job(this.insts.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::typed::InstNote| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let n = p0;
                        call_value(each_job(n.tys.clone(), {
                            let st = st.clone();
                            Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                                let st = st.clone();
                                entered(once_job(move || {
                                    let (q, x) = p0;
                                    call_then(start_resolve_ty(st.clone(), x.clone()), move |resolve_ty_5666: crate::check::types::Ty| prism_rtl::Turn::Finished((q.clone(), resolve_ty_5666)))
                                }))
                            }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Ty)>>>
                        }), move |each_5636: Array<(Text, crate::check::types::Ty)>| call_value(each_job(n.cols.clone(), {
                            let st = st.clone();
                            Rc::new(move |p0: (Text, crate::check::types::Col)| {
                                let st = st.clone();
                                entered(once_job(move || {
                                    let (q, c) = p0;
                                    call_then(start_resolve_col(st.clone(), c.clone()), move |resolve_col_5724: crate::check::types::Col| prism_rtl::Turn::Finished((q.clone(), resolve_col_5724)))
                                }))
                            }) as Rc<dyn Fn((Text, crate::check::types::Col)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Col)>>>
                        }), move |each_5693: Array<(Text, crate::check::types::Col)>| prism_rtl::Turn::Finished(crate::check::typed::InstNote { at: n.at.clone(), name: n.name.clone(), tys: each_5636, cols: each_5693 })))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::InstNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::InstNote>>>
            }));
            this.impls = run_to_end(each_job(this.impls.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::typed::ImplNote| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let n = p0;
                        call_then(start_resolve_ty(st.clone(), n.ty.clone()), move |resolve_ty_5819: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::ImplNote { at: n.at.clone(), cls: n.cls.clone(), ty: resolve_ty_5819, how: n.how.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::ImplNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::ImplNote>>>
            }));
            this.apps = run_to_end(each_job(this.apps.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::typed::AppNote| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let n = p0;
                        call_then(start_resolve_col(st.clone(), n.color.clone()), move |resolve_col_5990: crate::check::types::Col| prism_rtl::Turn::Finished(crate::check::typed::AppNote { at: n.at.clone(), callee: n.callee.clone(), kind: n.kind.clone(), layer: n.layer.clone(), lifted: n.lifted.clone(), inner: n.inner.clone(), color: resolve_col_5990 }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::AppNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::AppNote>>>
            }));
            this.fns = run_to_end(each_job(this.fns.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::typed::FnNote| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let n = p0;
                        call_then(start_resolve_col(st.clone(), n.declared.clone()), move |resolve_col_6090: crate::check::types::Col| call_then(start_resolve_col(st.clone(), n.body.clone()), move |resolve_col_6124: crate::check::types::Col| prism_rtl::Turn::Finished(crate::check::typed::FnNote { at: n.at.clone(), name: n.name.clone(), declared: resolve_col_6090, body: resolve_col_6124 })))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::FnNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::FnNote>>>
            }));
            this
        })
    }
}

/// `Start ZonkTyped, x`: what the function value is when passed to `@Run`.
pub fn start_zonk_typed(st: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::typed::TProgram>> {
    Rc::new(ZonkTyped { st })
}

/// ```prism
/// ResolveCol: unbounded fn St, Col -> Col
/// ```
pub fn resolve_col(st: &crate::check::types::St, c: &crate::check::types::Col) -> crate::check::types::Col {
    match crate::check::types::colors::walk_col(st, c) {
        crate::check::types::Col::CFlex(n) => match get(&st.col_q, &n) {
            Some(q) => crate::check::types::Col::CQ(q),
            None => crate::check::types::Col::CBound,
        },
        other => other,
    }
}

/// The step machine of `ResolveCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveCol: unbounded fn St, Col -> Col
/// ```
pub struct ResolveCol {
    pub st: crate::check::types::St,
    pub c: crate::check::types::Col,
}

impl prism_rtl::Job<crate::check::types::Col> for ResolveCol {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Col> {
        let st = &self.st;
        let c = &self.c;
        let c = c.clone();
        let st = st.clone();
        call_then(crate::check::types::colors::start_walk_col(st.clone(), c.clone()), move |walk_col_6359: crate::check::types::Col| match walk_col_6359 {
            crate::check::types::Col::CFlex(n) => match get(&st.col_q, &n) {
                Some(q) => prism_rtl::Turn::Finished(crate::check::types::Col::CQ(q.clone())),
                None => prism_rtl::Turn::Finished(crate::check::types::Col::CBound),
            },
            other => prism_rtl::Turn::Finished(other.clone()),
        })
    }
}

/// `Start ResolveCol, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_col(st: crate::check::types::St, c: crate::check::types::Col) -> Rc<dyn prism_rtl::Job<crate::check::types::Col>> {
    Rc::new(ResolveCol { st, c })
}

/// ```prism
/// ResolveTy: unbounded fn St, Ty -> Ty
/// ```
pub fn resolve_ty(st: &crate::check::types::St, t: &crate::check::types::Ty) -> crate::check::types::Ty {
    resolve_in(st, &zonk(st, t))
}

/// The step machine of `ResolveTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveTy: unbounded fn St, Ty -> Ty
/// ```
pub struct ResolveTy {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for ResolveTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(start_zonk(st.clone(), t.clone()), move |zonk_6572: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(ResolveIn { st: st.clone(), t: zonk_6572 })))
    }
}

/// `Start ResolveTy, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_ty(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(ResolveTy { st, t })
}

/// ```prism
/// ResolveIn: unbounded fn St, Ty -> Ty
/// ```
pub fn resolve_in(st: &crate::check::types::St, t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TyCon(n, args) => crate::check::types::Ty::TyCon(n.clone(), run_to_end(each_job(args.clone(), {
            let st = st.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(ResolveIn { st: st.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c, ps, res) => crate::check::types::Ty::TyFn(resolve_col(st, c), run_to_end(each_job(ps.clone(), {
            let st = st.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(ResolveIn { st: st.clone(), t: p_.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        })), Rc::new(resolve_in(st, &**res))),
        crate::check::types::Ty::TyTuple(ts) => crate::check::types::Ty::TyTuple(run_to_end(each_job(ts.clone(), {
            let st = st.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(ResolveIn { st: st.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e) => crate::check::types::Ty::TyArray(Rc::new(resolve_in(st, &**e))),
        crate::check::types::Ty::TyMap(k, v_) => crate::check::types::Ty::TyMap(Rc::new(resolve_in(st, &**k)), Rc::new(resolve_in(st, &**v_))),
        crate::check::types::Ty::TySig(s, i) => crate::check::types::Ty::TySig(s.clone(), Rc::new(resolve_in(st, &**i))),
        crate::check::types::Ty::TyAt(i, rw) => crate::check::types::Ty::TyAt(Rc::new(resolve_in(st, &**i)), rw.clone()),
        crate::check::types::Ty::TyElem(rw, o) => crate::check::types::Ty::TyElem(rw.clone(), Rc::new(resolve_in(st, &**o))),
        crate::check::types::Ty::TyAssoc(n, a) => crate::check::types::Ty::TyAssoc(n.clone(), Rc::new(resolve_in(st, &**a))),
        other => other.clone(),
    }
}

/// The step machine of `ResolveIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveIn: unbounded fn St, Ty -> Ty
/// ```
pub struct ResolveIn {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for ResolveIn {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st = &self.st;
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyCon(n, args) => {
                let args = args.clone();
                let n = n.clone();
                let st = st.clone();
                call_value(each_job(args.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(ResolveIn { st: st.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_6681: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n.clone(), each_6681)))
            },
            crate::check::types::Ty::TyFn(c, ps, res) => {
                let c = c.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                let st = st.clone();
                call_then(start_resolve_col(st.clone(), c.clone()), move |resolve_col_6741: crate::check::types::Col| call_value(each_job(ps.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let p_ = p0;
                            prism_rtl::Turn::More(Rc::new(ResolveIn { st: st.clone(), t: p_.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_6761: Array<crate::check::types::Ty>| call_then(start_resolve_in(st.clone(), res.clone()), move |resolve_in_6794: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(resolve_col_6741, each_6761, Rc::new(resolve_in_6794))))))
            },
            crate::check::types::Ty::TyTuple(ts) => {
                let st = st.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(ResolveIn { st: st.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_6838: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_6838)))
            },
            crate::check::types::Ty::TyArray(e) => {
                let e = (**e).clone();
                let st = st.clone();
                call_then(start_resolve_in(st.clone(), e.clone()), move |resolve_in_6893: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(resolve_in_6893))))
            },
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let st = st.clone();
                let v_ = (**v_).clone();
                call_then(start_resolve_in(st.clone(), k.clone()), move |resolve_in_6933: crate::check::types::Ty| call_then(start_resolve_in(st.clone(), v_.clone()), move |resolve_in_6952: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(resolve_in_6933), Rc::new(resolve_in_6952)))))
            },
            crate::check::types::Ty::TySig(s, i) => {
                let i = (**i).clone();
                let s = s.clone();
                let st = st.clone();
                call_then(start_resolve_in(st.clone(), i.clone()), move |resolve_in_6995: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s.clone(), Rc::new(resolve_in_6995))))
            },
            crate::check::types::Ty::TyAt(i, rw) => {
                let i = (**i).clone();
                let rw = rw.clone();
                let st = st.clone();
                call_then(start_resolve_in(st.clone(), i.clone()), move |resolve_in_7034: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(Rc::new(resolve_in_7034), rw.clone())))
            },
            crate::check::types::Ty::TyElem(rw, o) => {
                let o = (**o).clone();
                let rw = rw.clone();
                let st = st.clone();
                call_then(start_resolve_in(st.clone(), o.clone()), move |resolve_in_7085: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(rw.clone(), Rc::new(resolve_in_7085))))
            },
            crate::check::types::Ty::TyAssoc(n, a) => {
                let a = (**a).clone();
                let n = n.clone();
                let st = st.clone();
                call_then(start_resolve_in(st.clone(), a.clone()), move |resolve_in_7132: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(n.clone(), Rc::new(resolve_in_7132))))
            },
            other => prism_rtl::Turn::Finished(other.clone()),
        }
    }
}

/// `Start ResolveIn, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_in(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(ResolveIn { st, t })
}

/// ```prism
/// AtBinder: fn St, Ty, Range -> St
/// ```
pub fn at_binder(st: &crate::check::types::St, ty1: &crate::check::types::Ty, range2: &crate::syntax::Range) -> crate::check::types::St {
    match (ty1, range2) {
        (crate::check::types::Ty::TyFlex(n), span) => {
            let mut this: crate::check::types::St = st.clone();
            this.binder_at = insert(&this.binder_at, n, span);
            this
        },
        (_, _) => st.clone(),
    }
}

/// ```prism
/// FreshRow: fn St, [Text] -> ((Rw, St))
/// ```
pub fn fresh_row(st: &crate::check::types::St, lacking: &Array<Text>) -> (crate::check::types::Rw, crate::check::types::St) {
    let n = st.next.clone();
    let st2 = {
        let mut this: crate::check::types::St = st.clone();
        this.next = &this.next + &Nat::from(1u32);
        this.lacks = insert(&this.lacks, &n, lacking);
        this
    };
    (crate::check::types::Rw { fams: Array::new(), minus: Array::new(), tail: crate::check::types::Tail::TlFlex(n.clone()) }, st2.clone())
}

/// ```prism
/// AddDiag: fn St, CDiag -> St
/// ```
pub fn add_diag(st: &crate::check::types::St, d: &crate::check::errors::CDiag) -> crate::check::types::St {
    let mut this: crate::check::types::St = st.clone();
    this.diags = push(&this.diags, d);
    this
}

/// ```prism
/// Err: fn St, Text, Range, Text -> St
/// ```
pub fn err(st: &crate::check::types::St, code: &Text, span: &crate::syntax::Range, message: &Text) -> crate::check::types::St {
    add_diag(st, &crate::check::errors::diag0(code, &st.file, span, message))
}

/// ```prism
/// ErrFix: fn St, Text, Range, Text, Text -> St
/// ```
pub fn err_fix(st: &crate::check::types::St, code: &Text, span: &crate::syntax::Range, message: &Text, fix: &Text) -> crate::check::types::St {
    add_diag(st, &crate::check::errors::diag_fix(code, &st.file, span, message, fix))
}

/// ```prism
/// InfoOf: fn St, Nat -> VInfo
/// ```
pub fn info_of(st: &crate::check::types::St, n: &Nat) -> crate::check::types::VInfo {
    or(&get(&st.infos, n), &crate::check::types::VInfo { plain: false, level: Nat::from(0u32), name: Text::lit("") })
}

/// ```prism
/// Walk: unbounded fn St, Ty -> Ty
/// ```
pub fn walk(st: &crate::check::types::St, ty1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match ty1 {
        crate::check::types::Ty::TyFlex(n) => match get(&st.tys, n) {
            Some(t) => walk(st, &t),
            None => crate::check::types::Ty::TyFlex(n.clone()),
        },
        t => t.clone(),
    }
}

/// The step machine of `Walk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Walk: unbounded fn St, Ty -> Ty
/// ```
pub struct Walk {
    pub st: crate::check::types::St,
    pub ty1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for Walk {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st = &self.st;
        let ty1 = &self.ty1;
        match ty1 {
            crate::check::types::Ty::TyFlex(n) => match get(&st.tys, n) {
                Some(t) => prism_rtl::Turn::More(Rc::new(Walk { st: st.clone(), ty1: t.clone() })),
                None => prism_rtl::Turn::Finished(crate::check::types::Ty::TyFlex(n.clone())),
            },
            t => prism_rtl::Turn::Finished(t.clone()),
        }
    }
}

/// `Start Walk, x`: what the function value is when passed to `@Run`.
pub fn start_walk(st: crate::check::types::St, ty1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(Walk { st, ty1 })
}

/// ```prism
/// WalkRow: unbounded fn St, Rw -> Rw
/// ```
pub fn walk_row(st: &crate::check::types::St, r: &crate::check::types::Rw) -> crate::check::types::Rw {
    match &r.tail {
        crate::check::types::Tail::TlFlex(n) => match get(&st.rows, n) {
            Some(r2) => {
                let w = walk_row(st, &r2);
                crate::check::types::Rw { fams: crate::check::types::sort_texts(&crate::check::types::union_texts(&r.fams, &w.fams)), minus: crate::check::types::union_texts(&r.minus, &w.minus), tail: w.tail.clone() }
            },
            None => r.clone(),
        },
        _ => r.clone(),
    }
}

/// The step machine of `WalkRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkRow: unbounded fn St, Rw -> Rw
/// ```
pub struct WalkRow {
    pub st: crate::check::types::St,
    pub r: crate::check::types::Rw,
}

impl prism_rtl::Job<crate::check::types::Rw> for WalkRow {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Rw> {
        let st = &self.st;
        let r = &self.r;
        match &r.tail {
            crate::check::types::Tail::TlFlex(n) => match get(&st.rows, n) {
                Some(r2) => {
                    let r = r.clone();
                    let st = st.clone();
                    call_then(start_walk_row(st.clone(), r2.clone()), move |walk_row_8499: crate::check::types::Rw| {
                        let w = walk_row_8499;
                        prism_rtl::Turn::Finished(crate::check::types::Rw { fams: crate::check::types::sort_texts(&crate::check::types::union_texts(&r.fams, &w.fams)), minus: crate::check::types::union_texts(&r.minus, &w.minus), tail: w.tail.clone() })
                    })
                },
                None => prism_rtl::Turn::Finished(r.clone()),
            },
            _ => prism_rtl::Turn::Finished(r.clone()),
        }
    }
}

/// `Start WalkRow, x`: what the function value is when passed to `@Run`.
pub fn start_walk_row(st: crate::check::types::St, r: crate::check::types::Rw) -> Rc<dyn prism_rtl::Job<crate::check::types::Rw>> {
    Rc::new(WalkRow { st, r })
}

/// ```prism
/// Zonk: unbounded fn St, Ty -> Ty
/// ```
pub fn zonk(st: &crate::check::types::St, t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match crate::check::types::unify::norm_assoc(st, &walk(st, t)) {
        crate::check::types::Ty::TyCon(n, args) => crate::check::types::Ty::TyCon(n.clone(), run_to_end(each_job(args.clone(), {
            let st = st.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(Zonk { st: st.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c, ps, res) => crate::check::types::Ty::TyFn(crate::check::types::colors::walk_col(st, &c), run_to_end(each_job(ps.clone(), {
            let st = st.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(Zonk { st: st.clone(), t: p_.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        })), Rc::new(zonk(st, &*res))),
        crate::check::types::Ty::TyTuple(ts) => crate::check::types::Ty::TyTuple(run_to_end(each_job(ts.clone(), {
            let st = st.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(Zonk { st: st.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e) => crate::check::types::Ty::TyArray(Rc::new(zonk(st, &*e))),
        crate::check::types::Ty::TyMap(k, v_) => crate::check::types::Ty::TyMap(Rc::new(zonk(st, &*k)), Rc::new(zonk(st, &*v_))),
        crate::check::types::Ty::TySig(s, i) => crate::check::types::Ty::TySig(s, Rc::new(zonk(st, &*i))),
        crate::check::types::Ty::TyAt(i, rw) => crate::check::types::Ty::TyAt(Rc::new(zonk(st, &*i)), walk_row(st, &rw)),
        crate::check::types::Ty::TyElem(rw, o) => crate::check::types::Ty::TyElem(walk_row(st, &rw), Rc::new(zonk(st, &*o))),
        crate::check::types::Ty::TyElemAny(rw) => crate::check::types::Ty::TyElemAny(walk_row(st, &rw)),
        crate::check::types::Ty::TyAssoc(n, a) => crate::check::types::Ty::TyAssoc(n, Rc::new(zonk(st, &*a))),
        w => w,
    }
}

/// The step machine of `Zonk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Zonk: unbounded fn St, Ty -> Ty
/// ```
pub struct Zonk {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for Zonk {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(start_walk(st.clone(), t.clone()), move |walk_8790: crate::check::types::Ty| call_then(crate::check::types::unify::start_norm_assoc(st.clone(), walk_8790), move |norm_assoc_8775: crate::check::types::Ty| match norm_assoc_8775 {
            crate::check::types::Ty::TyCon(n, args) => call_value(each_job(args.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(Zonk { st: st.clone(), t: a.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_8832: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n.clone(), each_8832))),
            crate::check::types::Ty::TyFn(c, ps, res) => call_then(crate::check::types::colors::start_walk_col(st.clone(), c.clone()), move |walk_col_8887: crate::check::types::Col| call_value(each_job(ps.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let p_ = p0;
                        prism_rtl::Turn::More(Rc::new(Zonk { st: st.clone(), t: p_.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_8904: Array<crate::check::types::Ty>| call_then(start_zonk(st.clone(), (*res).clone()), move |zonk_8932: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(walk_col_8887, each_8904, Rc::new(zonk_8932)))))),
            crate::check::types::Ty::TyTuple(ts) => call_value(each_job(ts.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(Zonk { st: st.clone(), t: a.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_8971: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_8971))),
            crate::check::types::Ty::TyArray(e) => call_then(start_zonk(st.clone(), (*e).clone()), move |zonk_9021: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(zonk_9021)))),
            crate::check::types::Ty::TyMap(k, v_) => call_then(start_zonk(st.clone(), (*k).clone()), move |zonk_9056: crate::check::types::Ty| call_then(start_zonk(st.clone(), (*v_).clone()), move |zonk_9070: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(zonk_9056), Rc::new(zonk_9070))))),
            crate::check::types::Ty::TySig(s, i) => call_then(start_zonk(st.clone(), (*i).clone()), move |zonk_9108: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s.clone(), Rc::new(zonk_9108)))),
            crate::check::types::Ty::TyAt(i, rw) => call_then(start_zonk(st.clone(), (*i).clone()), move |zonk_9142: crate::check::types::Ty| call_then(start_walk_row(st.clone(), rw.clone()), move |walk_row_9156: crate::check::types::Rw| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(Rc::new(zonk_9142), walk_row_9156)))),
            crate::check::types::Ty::TyElem(rw, o) => call_then(start_walk_row(st.clone(), rw.clone()), move |walk_row_9198: crate::check::types::Rw| call_then(start_zonk(st.clone(), (*o).clone()), move |zonk_9216: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(walk_row_9198, Rc::new(zonk_9216))))),
            crate::check::types::Ty::TyElemAny(rw) => call_then(start_walk_row(st.clone(), rw.clone()), move |walk_row_9257: crate::check::types::Rw| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElemAny(walk_row_9257))),
            crate::check::types::Ty::TyAssoc(n, a) => call_then(start_zonk(st.clone(), (*a).clone()), move |zonk_9303: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(n.clone(), Rc::new(zonk_9303)))),
            w => prism_rtl::Turn::Finished(w.clone()),
        }))
    }
}

/// `Start Zonk, x`: what the function value is when passed to `@Run`.
pub fn start_zonk(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(Zonk { st, t })
}

/// ```prism
/// FreeVars: unbounded fn St, Ty -> [Nat]
/// ```
pub fn free_vars(st: &crate::check::types::St, t: &crate::check::types::Ty) -> Array<Nat> {
    free_vars_into(st, &Array::new(), t)
}

/// The step machine of `FreeVars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeVars: unbounded fn St, Ty -> [Nat]
/// ```
pub struct FreeVars {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Nat>> for FreeVars {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let st = &self.st;
        let t = &self.t;
        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: Array::new(), t: t.clone() }))
    }
}

/// `Start FreeVars, x`: what the function value is when passed to `@Run`.
pub fn start_free_vars(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(FreeVars { st, t })
}

/// ```prism
/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub fn free_vars_into(st: &crate::check::types::St, acc: &Array<Nat>, t: &crate::check::types::Ty) -> Array<Nat> {
    match walk(st, t) {
        crate::check::types::Ty::TyFlex(n) => crate::check::types::add_nat(acc, &n),
        crate::check::types::Ty::TyCon(_, args) => run_to_end(fold_job(args.clone(), acc.clone(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })),
        crate::check::types::Ty::TyFn(_, ps, res) => free_vars_into(st, &run_to_end(fold_job(ps.clone(), acc.clone(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })), &*res),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), acc.clone(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })),
        crate::check::types::Ty::TyArray(e) => free_vars_into(st, acc, &*e),
        crate::check::types::Ty::TyMap(k, v_) => free_vars_into(st, &free_vars_into(st, acc, &*k), &*v_),
        crate::check::types::Ty::TySig(_, i) => free_vars_into(st, acc, &*i),
        crate::check::types::Ty::TyAt(i, _) => free_vars_into(st, acc, &*i),
        crate::check::types::Ty::TyElem(_, o) => free_vars_into(st, acc, &*o),
        crate::check::types::Ty::TyAssoc(_, a) => free_vars_into(st, acc, &*a),
        _ => acc.clone(),
    }
}

/// The step machine of `FreeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub struct FreeVarsInto {
    pub st: crate::check::types::St,
    pub acc: Array<Nat>,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Nat>> for FreeVarsInto {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let st = &self.st;
        let acc = &self.acc;
        let t = &self.t;
        let acc = acc.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_walk(st.clone(), t.clone()), move |walk_9536: crate::check::types::Ty| match walk_9536 {
            crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(crate::check::types::add_nat(&acc, &n)),
            crate::check::types::Ty::TyCon(_, args) => fold_job(args.clone(), acc.clone(), {
                let st = st.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        let x = p1;
                        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }).cycle(),
            crate::check::types::Ty::TyFn(_, ps, res) => call_value(fold_job(ps.clone(), acc.clone(), {
                let st = st.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        let x = p1;
                        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }), move |fold_9690: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: fold_9690, t: (*res).clone() }))),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), acc.clone(), {
                let st = st.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        let x = p1;
                        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: acc.clone(), t: (*e).clone() })),
            crate::check::types::Ty::TyMap(k, v_) => call_then(start_free_vars_into(st.clone(), acc.clone(), (*k).clone()), move |free_vars_into_9873: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: free_vars_into_9873, t: (*v_).clone() }))),
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: acc.clone(), t: (*i).clone() })),
            crate::check::types::Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: acc.clone(), t: (*i).clone() })),
            crate::check::types::Ty::TyElem(_, o) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: acc.clone(), t: (*o).clone() })),
            crate::check::types::Ty::TyAssoc(_, a) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: acc.clone(), t: (*a).clone() })),
            _ => prism_rtl::Turn::Finished(acc.clone()),
        })
    }
}

/// `Start FreeVarsInto, x`: what the function value is when passed to `@Run`.
pub fn start_free_vars_into(st: crate::check::types::St, acc: Array<Nat>, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(FreeVarsInto { st, acc, t })
}
