//! The module `Check.Types.Recording`, from `target/bootstrap/src/prismc/check/types/recording.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// AtHere: fn St, Range -> SrcAt
/// ```
pub fn at_here(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range) -> crate::check::typed::SrcAt {
    crate::check::typed::SrcAt { file: st_p0.file.clone(), span: span_p1.clone() }
}

/// ```prism
/// NoteTy: fn St, Range, Ty -> St
/// ```
pub fn note_ty(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, t_p2: &crate::check::types::Ty) -> crate::check::types::St {
    if !st_p0.recording {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed.exprs = push(&this.typed.exprs, &crate::check::typed::TyNote { at: at_here(st_p0, span_p1), ty: t_p2.clone() });
            this
        }
    }
}

/// ```prism
/// NoteBinder: fn St, Range, Text, Ty -> St
/// ```
pub fn note_binder(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, name_p2: &Text, t_p3: &crate::check::types::Ty) -> crate::check::types::St {
    if !st_p0.recording {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed.binders = push(&this.typed.binders, &crate::check::typed::BinderNote { at: at_here(st_p0, span_p1), name: name_p2.clone(), ty: t_p3.clone() });
            this
        }
    }
}

/// ```prism
/// NoteLocal: fn St, Range, Nat -> St
/// ```
pub fn note_local(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, id_p2: &Nat) -> crate::check::types::St {
    if !st_p0.recording {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed.locals = push(&this.typed.locals, &crate::check::typed::LocalNote { at: at_here(st_p0, span_p1), id: id_p2.clone() });
            this
        }
    }
}

/// ```prism
/// NoteUse: fn St, Range, Nat -> St
/// ```
pub fn note_use(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, id_p2: &Nat) -> crate::check::types::St {
    if !st_p0.recording {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed.uses = push(&this.typed.uses, &crate::check::typed::LocalNote { at: at_here(st_p0, span_p1), id: id_p2.clone() });
            this
        }
    }
}

/// ```prism
/// NoteGen: fn St, Range, Text, Scheme -> St
/// ```
pub fn note_gen(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, name_p2: &Text, sc_p3: &crate::check::types::Scheme) -> crate::check::types::St {
    if !st_p0.recording || ((&len(&sc_p3.qs) == &Nat::from(0u32)) && (&len(&sc_p3.cqs) == &Nat::from(0u32))) {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed.gens = push(&this.typed.gens, &crate::check::typed::GenNote { at: at_here(st_p0, span_p1), name: name_p2.clone(), tys: sc_p3.qs.clone(), cols: sc_p3.cqs.clone() });
            this
        }
    }
}

/// ```prism
/// NoteInst: fn St, Range, Text, Scheme, Inst -> St
/// ```
pub fn note_inst(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, name_p2: &Text, sc_p3: &crate::check::types::Scheme, inst_p4: &crate::check::types::schemes::Inst) -> crate::check::types::St {
    if !st_p0.recording {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed.insts = push(&this.typed.insts, &crate::check::typed::InstNote { at: at_here(st_p0, span_p1), name: name_p2.clone(), tys: each(&sc_p3.qs, &(|q_p5: &Text| (q_p5.clone(), or(&get(&inst_p4.tys, q_p5), &crate::check::types::Ty::TyErr)))), cols: each(&sc_p3.cqs, &(|q_p6: &Text| (q_p6.clone(), or(&get(&inst_p4.cols, q_p6), &crate::check::types::Col::CBound)))) });
            this
        }
    }
}

/// ```prism
/// NoteApp: fn St, Range, Text, Text, Text, [Nat], Text, Col -> St
/// ```
pub fn note_app(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, callee_p2: &Text, kind_p3: &Text, layer_p4: &Text, lifted_p5: &Array<Nat>, inner_p6: &Text, col_p7: &crate::check::types::Col) -> crate::check::types::St {
    if !st_p0.recording {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed.apps = push(&this.typed.apps, &crate::check::typed::AppNote { at: at_here(st_p0, span_p1), callee: callee_p2.clone(), kind: kind_p3.clone(), layer: layer_p4.clone(), lifted: lifted_p5.clone(), inner: inner_p6.clone(), color: col_p7.clone() });
            this
        }
    }
}

/// ```prism
/// NoteLift: fn St, Range, Text, [Range] -> St
/// ```
pub fn note_lift(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, sigil_p2: &Text, operands_p3: &Array<crate::syntax::Range>) -> crate::check::types::St {
    if !st_p0.recording || (&len(operands_p3) == &Nat::from(0u32)) {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed.lifts = push(&this.typed.lifts, &crate::check::typed::LiftNote { at: at_here(st_p0, span_p1), sigil: sigil_p2.clone(), operands: operands_p3.clone() });
            this
        }
    }
}

/// ```prism
/// NoteFn: fn St, Range, Text, Col, Col -> St
/// ```
pub fn note_fn(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, name_p2: &Text, declared_p3: &crate::check::types::Col, body_p4: &crate::check::types::Col) -> crate::check::types::St {
    if !st_p0.recording {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed.fns = push(&this.typed.fns, &crate::check::typed::FnNote { at: at_here(st_p0, span_p1), name: name_p2.clone(), declared: declared_p3.clone(), body: body_p4.clone() });
            this
        }
    }
}

/// ```prism
/// NoteImpl: fn St, Nat, Range, Text, Ty, Text -> St
/// ```
pub fn note_impl(st_p0: &crate::check::types::St, file_p1: &Nat, span_p2: &crate::syntax::Range, cls_p3: &Text, t_p4: &crate::check::types::Ty, how_p5: &Text) -> crate::check::types::St {
    if ((!st_p0.recording || crate::syntax::lexer::chars::has_prefix(cls_p3, &Text::lit("Range "))) || (cls_p3 == &Text::lit("Prelude.Sub"))) || (cls_p3 == &Text::lit("Prelude.Signed")) {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed.impls = push(&this.typed.impls, &crate::check::typed::ImplNote { at: crate::check::typed::SrcAt { file: file_p1.clone(), span: span_p2.clone() }, cls: cls_p3.clone(), ty: t_p4.clone(), how: how_p5.clone() });
            this
        }
    }
}

/// ```prism
/// NoteChoice: fn St, Nat, Range, Text, Text -> St
/// ```
pub fn note_choice(st_p0: &crate::check::types::St, file_p1: &Nat, span_p2: &crate::syntax::Range, cls_p3: &Text, ch_p4: &Text) -> crate::check::types::St {
    let k_p5 = choice_key(file_p1, span_p2, cls_p3);
    if (crate::syntax::lexer::chars::has_prefix(cls_p3, &Text::lit("Range ")) || (cls_p3 == &Text::lit("Prelude.Sub"))) || (cls_p3 == &Text::lit("Prelude.Signed")) {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.choices = insert(&this.choices, &k_p5, &crate::check::types::add_text(&or(&get(&this.choices, &k_p5), &Array::new()), ch_p4));
            this
        }
    }
}

/// ```prism
/// NoteSizeTy: fn St, Range, Ty -> St
/// ```
pub fn note_size_ty(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, t_p2: &crate::check::types::Ty) -> crate::check::types::St {
    match t_p2 {
        crate::check::types::Ty::TyFn(_, ps_p3, _) => match index(ps_p3, &Nat::from(0u32)) {
            Some(p_p4) => {
                let mut this: crate::check::types::St = st_p0.clone();
                this.size_tys = insert(&this.size_tys, &Text::from(format!("{}:{}:{}", &st_p0.file, &span_p1.start, &span_p1.end)), &p_p4);
                this
            },
            None => st_p0.clone(),
        },
        _ => st_p0.clone(),
    }
}

/// ```prism
/// ChoiceKey: fn Nat, Range, Text -> Text
/// ```
pub fn choice_key(file_p0: &Nat, span_p1: &crate::syntax::Range, cls_p2: &Text) -> Text {
    Text::from(format!("{}:{}:{}:{}", file_p0, &span_p1.start, &span_p1.end, cls_p2))
}

/// ```prism
/// NoteMethod: fn St, Range, Text, Text -> St
/// ```
pub fn note_method(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, method_p2: &Text, cls_p3: &Text) -> crate::check::types::St {
    if !st_p0.recording {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed.methods = push(&this.typed.methods, &crate::check::typed::MethodNote { at: at_here(st_p0, span_p1), method: method_p2.clone(), cls: cls_p3.clone() });
            this
        }
    }
}

/// ```prism
/// NoteGroup: fn St, Range, Text, [ [Nat] ] -> St
/// ```
pub fn note_group(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, kind_p2: &Text, order_p3: &Array<Array<Nat>>) -> crate::check::types::St {
    if !st_p0.recording {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed.groups = push(&this.typed.groups, &crate::check::typed::GroupNote { at: at_here(st_p0, span_p1), kind: kind_p2.clone(), order: order_p3.clone() });
            this
        }
    }
}

/// ```prism
/// ZonkTyped: unbounded fn St -> TProgram
/// ```
pub fn zonk_typed(st_p0: &crate::check::types::St) -> crate::check::typed::TProgram {
    let t_p1 = st_p0.typed.clone();
    let mut this: crate::check::typed::TProgram = t_p1.clone();
    this.exprs = run_to_end(each_job(this.exprs.clone(), {
        let st_p0 = st_p0.clone();
        Rc::new(move |p0: crate::check::typed::TyNote| {
            let st_p0 = st_p0.clone();
            entered(once_job(move || {
                let n_p2 = p0;
                call_then(start_resolve_ty(st_p0.clone(), n_p2.ty.clone()), move |resolve_ty_5873: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::TyNote { at: n_p2.at.clone(), ty: resolve_ty_5873 }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::TyNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::TyNote>>>
    }));
    this.binders = run_to_end(each_job(this.binders.clone(), {
        let st_p0 = st_p0.clone();
        Rc::new(move |p0: crate::check::typed::BinderNote| {
            let st_p0 = st_p0.clone();
            entered(once_job(move || {
                let n_p3 = p0;
                call_then(start_resolve_ty(st_p0.clone(), n_p3.ty.clone()), move |resolve_ty_5975: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::BinderNote { at: n_p3.at.clone(), name: n_p3.name.clone(), ty: resolve_ty_5975 }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::BinderNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::BinderNote>>>
    }));
    this.insts = run_to_end(each_job(this.insts.clone(), {
        let st_p0 = st_p0.clone();
        Rc::new(move |p0: crate::check::typed::InstNote| {
            let st_p0 = st_p0.clone();
            entered(once_job(move || {
                let n_p4 = p0;
                call_value(each_job(n_p4.tys.clone(), {
                    let st_p0 = st_p0.clone();
                    Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                        let st_p0 = st_p0.clone();
                        entered(once_job(move || {
                            let (q_p5, x_p6) = p0;
                            call_then(start_resolve_ty(st_p0.clone(), x_p6.clone()), move |resolve_ty_6102: crate::check::types::Ty| prism_rtl::Turn::Finished((q_p5.clone(), resolve_ty_6102)))
                        }))
                    }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Ty)>>>
                }), move |each_6072: Array<(Text, crate::check::types::Ty)>| call_value(each_job(n_p4.cols.clone(), {
                    let st_p0 = st_p0.clone();
                    Rc::new(move |p0: (Text, crate::check::types::Col)| {
                        let st_p0 = st_p0.clone();
                        entered(once_job(move || {
                            let (q_p7, c_p8) = p0;
                            call_then(start_resolve_col(st_p0.clone(), c_p8.clone()), move |resolve_col_6160: crate::check::types::Col| prism_rtl::Turn::Finished((q_p7.clone(), resolve_col_6160)))
                        }))
                    }) as Rc<dyn Fn((Text, crate::check::types::Col)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Col)>>>
                }), move |each_6129: Array<(Text, crate::check::types::Col)>| prism_rtl::Turn::Finished(crate::check::typed::InstNote { at: n_p4.at.clone(), name: n_p4.name.clone(), tys: each_6072, cols: each_6129 })))
            }))
        }) as Rc<dyn Fn(crate::check::typed::InstNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::InstNote>>>
    }));
    this.impls = run_to_end(each_job(this.impls.clone(), {
        let st_p0 = st_p0.clone();
        Rc::new(move |p0: crate::check::typed::ImplNote| {
            let st_p0 = st_p0.clone();
            entered(once_job(move || {
                let n_p9 = p0;
                call_then(start_resolve_ty(st_p0.clone(), n_p9.ty.clone()), move |resolve_ty_6255: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::ImplNote { at: n_p9.at.clone(), cls: n_p9.cls.clone(), ty: resolve_ty_6255, how: n_p9.how.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::ImplNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::ImplNote>>>
    }));
    this.apps = run_to_end(each_job(this.apps.clone(), {
        let st_p0 = st_p0.clone();
        Rc::new(move |p0: crate::check::typed::AppNote| {
            let st_p0 = st_p0.clone();
            entered(once_job(move || {
                let n_pa = p0;
                call_then(start_resolve_col(st_p0.clone(), n_pa.color.clone()), move |resolve_col_6426: crate::check::types::Col| prism_rtl::Turn::Finished(crate::check::typed::AppNote { at: n_pa.at.clone(), callee: n_pa.callee.clone(), kind: n_pa.kind.clone(), layer: n_pa.layer.clone(), lifted: n_pa.lifted.clone(), inner: n_pa.inner.clone(), color: resolve_col_6426 }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::AppNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::AppNote>>>
    }));
    this.fns = run_to_end(each_job(this.fns.clone(), {
        let st_p0 = st_p0.clone();
        Rc::new(move |p0: crate::check::typed::FnNote| {
            let st_p0 = st_p0.clone();
            entered(once_job(move || {
                let n_pb = p0;
                call_then(start_resolve_col(st_p0.clone(), n_pb.declared.clone()), move |resolve_col_6526: crate::check::types::Col| call_then(start_resolve_col(st_p0.clone(), n_pb.body.clone()), move |resolve_col_6560: crate::check::types::Col| prism_rtl::Turn::Finished(crate::check::typed::FnNote { at: n_pb.at.clone(), name: n_pb.name.clone(), declared: resolve_col_6526, body: resolve_col_6560 })))
            }))
        }) as Rc<dyn Fn(crate::check::typed::FnNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::FnNote>>>
    }));
    this
}

/// The step machine of `ZonkTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ZonkTyped: unbounded fn St -> TProgram
/// ```
pub struct ZonkTyped {
    pub st_p0: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::typed::TProgram> for ZonkTyped {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::typed::TProgram> {
        let st_p0 = &self.st_p0;
        let t_p1 = st_p0.typed.clone();
        prism_rtl::Turn::Finished({
            let mut this: crate::check::typed::TProgram = t_p1.clone();
            this.exprs = run_to_end(each_job(this.exprs.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |p0: crate::check::typed::TyNote| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let n_p2 = p0;
                        call_then(start_resolve_ty(st_p0.clone(), n_p2.ty.clone()), move |resolve_ty_5873: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::TyNote { at: n_p2.at.clone(), ty: resolve_ty_5873 }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::TyNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::TyNote>>>
            }));
            this.binders = run_to_end(each_job(this.binders.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |p0: crate::check::typed::BinderNote| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let n_p3 = p0;
                        call_then(start_resolve_ty(st_p0.clone(), n_p3.ty.clone()), move |resolve_ty_5975: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::BinderNote { at: n_p3.at.clone(), name: n_p3.name.clone(), ty: resolve_ty_5975 }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::BinderNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::BinderNote>>>
            }));
            this.insts = run_to_end(each_job(this.insts.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |p0: crate::check::typed::InstNote| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let n_p4 = p0;
                        call_value(each_job(n_p4.tys.clone(), {
                            let st_p0 = st_p0.clone();
                            Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                                let st_p0 = st_p0.clone();
                                entered(once_job(move || {
                                    let (q_p5, x_p6) = p0;
                                    call_then(start_resolve_ty(st_p0.clone(), x_p6.clone()), move |resolve_ty_6102: crate::check::types::Ty| prism_rtl::Turn::Finished((q_p5.clone(), resolve_ty_6102)))
                                }))
                            }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Ty)>>>
                        }), move |each_6072: Array<(Text, crate::check::types::Ty)>| call_value(each_job(n_p4.cols.clone(), {
                            let st_p0 = st_p0.clone();
                            Rc::new(move |p0: (Text, crate::check::types::Col)| {
                                let st_p0 = st_p0.clone();
                                entered(once_job(move || {
                                    let (q_p7, c_p8) = p0;
                                    call_then(start_resolve_col(st_p0.clone(), c_p8.clone()), move |resolve_col_6160: crate::check::types::Col| prism_rtl::Turn::Finished((q_p7.clone(), resolve_col_6160)))
                                }))
                            }) as Rc<dyn Fn((Text, crate::check::types::Col)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Col)>>>
                        }), move |each_6129: Array<(Text, crate::check::types::Col)>| prism_rtl::Turn::Finished(crate::check::typed::InstNote { at: n_p4.at.clone(), name: n_p4.name.clone(), tys: each_6072, cols: each_6129 })))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::InstNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::InstNote>>>
            }));
            this.impls = run_to_end(each_job(this.impls.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |p0: crate::check::typed::ImplNote| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let n_p9 = p0;
                        call_then(start_resolve_ty(st_p0.clone(), n_p9.ty.clone()), move |resolve_ty_6255: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::ImplNote { at: n_p9.at.clone(), cls: n_p9.cls.clone(), ty: resolve_ty_6255, how: n_p9.how.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::ImplNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::ImplNote>>>
            }));
            this.apps = run_to_end(each_job(this.apps.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |p0: crate::check::typed::AppNote| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let n_pa = p0;
                        call_then(start_resolve_col(st_p0.clone(), n_pa.color.clone()), move |resolve_col_6426: crate::check::types::Col| prism_rtl::Turn::Finished(crate::check::typed::AppNote { at: n_pa.at.clone(), callee: n_pa.callee.clone(), kind: n_pa.kind.clone(), layer: n_pa.layer.clone(), lifted: n_pa.lifted.clone(), inner: n_pa.inner.clone(), color: resolve_col_6426 }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::AppNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::AppNote>>>
            }));
            this.fns = run_to_end(each_job(this.fns.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |p0: crate::check::typed::FnNote| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let n_pb = p0;
                        call_then(start_resolve_col(st_p0.clone(), n_pb.declared.clone()), move |resolve_col_6526: crate::check::types::Col| call_then(start_resolve_col(st_p0.clone(), n_pb.body.clone()), move |resolve_col_6560: crate::check::types::Col| prism_rtl::Turn::Finished(crate::check::typed::FnNote { at: n_pb.at.clone(), name: n_pb.name.clone(), declared: resolve_col_6526, body: resolve_col_6560 })))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::FnNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::FnNote>>>
            }));
            this
        })
    }
}

/// `Start ZonkTyped, x`: what the function value is when passed to `@Run`.
pub fn start_zonk_typed(st_p0: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::typed::TProgram>> {
    Rc::new(ZonkTyped { st_p0 })
}

/// ```prism
/// ResolveCol: unbounded fn St, Col -> Col
/// ```
pub fn resolve_col(st_p0: &crate::check::types::St, c_p1: &crate::check::types::Col) -> crate::check::types::Col {
    match crate::check::types::colors::walk_col(st_p0, c_p1) {
        crate::check::types::Col::CFlex(n_p2) => match get(&st_p0.col_q, &n_p2) {
            Some(q_p3) => crate::check::types::Col::CQ(q_p3),
            None => crate::check::types::Col::CBound,
        },
        other_p4 => other_p4,
    }
}

/// The step machine of `ResolveCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveCol: unbounded fn St, Col -> Col
/// ```
pub struct ResolveCol {
    pub st_p0: crate::check::types::St,
    pub c_p1: crate::check::types::Col,
}

impl prism_rtl::Job<crate::check::types::Col> for ResolveCol {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Col> {
        let st_p0 = &self.st_p0;
        let c_p1 = &self.c_p1;
        let c_p1 = c_p1.clone();
        let st_p0 = st_p0.clone();
        call_then(crate::check::types::colors::start_walk_col(st_p0.clone(), c_p1.clone()), move |walk_col_6795: crate::check::types::Col| match walk_col_6795 {
            crate::check::types::Col::CFlex(n_p2) => match get(&st_p0.col_q, &n_p2) {
                Some(q_p3) => prism_rtl::Turn::Finished(crate::check::types::Col::CQ(q_p3.clone())),
                None => prism_rtl::Turn::Finished(crate::check::types::Col::CBound),
            },
            other_p4 => prism_rtl::Turn::Finished(other_p4.clone()),
        })
    }
}

/// `Start ResolveCol, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_col(st_p0: crate::check::types::St, c_p1: crate::check::types::Col) -> Rc<dyn prism_rtl::Job<crate::check::types::Col>> {
    Rc::new(ResolveCol { st_p0, c_p1 })
}

/// ```prism
/// ResolveTy: unbounded fn St, Ty -> Ty
/// ```
pub fn resolve_ty(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    resolve_in(st_p0, &zonk(st_p0, t_p1))
}

/// The step machine of `ResolveTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveTy: unbounded fn St, Ty -> Ty
/// ```
pub struct ResolveTy {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for ResolveTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(start_zonk(st_p0.clone(), t_p1.clone()), move |zonk_7008: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(ResolveIn { st_p0: st_p0.clone(), t_p1: zonk_7008 })))
    }
}

/// `Start ResolveTy, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_ty(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(ResolveTy { st_p0, t_p1 })
}

/// ```prism
/// ResolveIn: unbounded fn St, Ty -> Ty
/// ```
pub fn resolve_in(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p1 {
        crate::check::types::Ty::TyCon(n_p2, args_p3) => crate::check::types::Ty::TyCon(n_p2.clone(), run_to_end(each_job(args_p3.clone(), {
            let st_p0 = st_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let a_p4 = p0;
                    prism_rtl::Turn::More(Rc::new(ResolveIn { st_p0: st_p0.clone(), t_p1: a_p4.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c_p5, ps_p6, res_p7) => crate::check::types::Ty::TyFn(resolve_col(st_p0, c_p5), run_to_end(each_job(ps_p6.clone(), {
            let st_p0 = st_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let p_p8 = p0;
                    prism_rtl::Turn::More(Rc::new(ResolveIn { st_p0: st_p0.clone(), t_p1: p_p8.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        })), Rc::new(resolve_in(st_p0, &**res_p7))),
        crate::check::types::Ty::TyTuple(ts_p9) => crate::check::types::Ty::TyTuple(run_to_end(each_job(ts_p9.clone(), {
            let st_p0 = st_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let a_pa = p0;
                    prism_rtl::Turn::More(Rc::new(ResolveIn { st_p0: st_p0.clone(), t_p1: a_pa.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e_pb) => crate::check::types::Ty::TyArray(Rc::new(resolve_in(st_p0, &**e_pb))),
        crate::check::types::Ty::TyMap(k_pc, v_pd) => crate::check::types::Ty::TyMap(Rc::new(resolve_in(st_p0, &**k_pc)), Rc::new(resolve_in(st_p0, &**v_pd))),
        crate::check::types::Ty::TySig(s_pe, i_pf) => crate::check::types::Ty::TySig(s_pe.clone(), Rc::new(resolve_in(st_p0, &**i_pf))),
        crate::check::types::Ty::TyAt(i_pg, rw_ph) => crate::check::types::Ty::TyAt(Rc::new(resolve_in(st_p0, &**i_pg)), rw_ph.clone()),
        crate::check::types::Ty::TyElem(rw_pi, o_pj) => crate::check::types::Ty::TyElem(rw_pi.clone(), Rc::new(resolve_in(st_p0, &**o_pj))),
        crate::check::types::Ty::TyAssoc(n_pk, a_pl) => crate::check::types::Ty::TyAssoc(n_pk.clone(), Rc::new(resolve_in(st_p0, &**a_pl))),
        other_pm => other_pm.clone(),
    }
}

/// The step machine of `ResolveIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveIn: unbounded fn St, Ty -> Ty
/// ```
pub struct ResolveIn {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for ResolveIn {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyCon(n_p2, args_p3) => {
                let args_p3 = args_p3.clone();
                let n_p2 = n_p2.clone();
                let st_p0 = st_p0.clone();
                call_value(each_job(args_p3.clone(), {
                    let st_p0 = st_p0.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let st_p0 = st_p0.clone();
                        entered(once_job(move || {
                            let a_p4 = p0;
                            prism_rtl::Turn::More(Rc::new(ResolveIn { st_p0: st_p0.clone(), t_p1: a_p4.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_7117: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p2.clone(), each_7117)))
            },
            crate::check::types::Ty::TyFn(c_p5, ps_p6, res_p7) => {
                let c_p5 = c_p5.clone();
                let ps_p6 = ps_p6.clone();
                let res_p7 = (**res_p7).clone();
                let st_p0 = st_p0.clone();
                call_then(start_resolve_col(st_p0.clone(), c_p5.clone()), move |resolve_col_7177: crate::check::types::Col| call_value(each_job(ps_p6.clone(), {
                    let st_p0 = st_p0.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let st_p0 = st_p0.clone();
                        entered(once_job(move || {
                            let p_p8 = p0;
                            prism_rtl::Turn::More(Rc::new(ResolveIn { st_p0: st_p0.clone(), t_p1: p_p8.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_7197: Array<crate::check::types::Ty>| call_then(start_resolve_in(st_p0.clone(), res_p7.clone()), move |resolve_in_7230: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(resolve_col_7177, each_7197, Rc::new(resolve_in_7230))))))
            },
            crate::check::types::Ty::TyTuple(ts_p9) => {
                let st_p0 = st_p0.clone();
                let ts_p9 = ts_p9.clone();
                call_value(each_job(ts_p9.clone(), {
                    let st_p0 = st_p0.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let st_p0 = st_p0.clone();
                        entered(once_job(move || {
                            let a_pa = p0;
                            prism_rtl::Turn::More(Rc::new(ResolveIn { st_p0: st_p0.clone(), t_p1: a_pa.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_7274: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_7274)))
            },
            crate::check::types::Ty::TyArray(e_pb) => {
                let e_pb = (**e_pb).clone();
                let st_p0 = st_p0.clone();
                call_then(start_resolve_in(st_p0.clone(), e_pb.clone()), move |resolve_in_7329: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(resolve_in_7329))))
            },
            crate::check::types::Ty::TyMap(k_pc, v_pd) => {
                let k_pc = (**k_pc).clone();
                let st_p0 = st_p0.clone();
                let v_pd = (**v_pd).clone();
                call_then(start_resolve_in(st_p0.clone(), k_pc.clone()), move |resolve_in_7369: crate::check::types::Ty| call_then(start_resolve_in(st_p0.clone(), v_pd.clone()), move |resolve_in_7388: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(resolve_in_7369), Rc::new(resolve_in_7388)))))
            },
            crate::check::types::Ty::TySig(s_pe, i_pf) => {
                let i_pf = (**i_pf).clone();
                let s_pe = s_pe.clone();
                let st_p0 = st_p0.clone();
                call_then(start_resolve_in(st_p0.clone(), i_pf.clone()), move |resolve_in_7431: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pe.clone(), Rc::new(resolve_in_7431))))
            },
            crate::check::types::Ty::TyAt(i_pg, rw_ph) => {
                let i_pg = (**i_pg).clone();
                let rw_ph = rw_ph.clone();
                let st_p0 = st_p0.clone();
                call_then(start_resolve_in(st_p0.clone(), i_pg.clone()), move |resolve_in_7470: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(Rc::new(resolve_in_7470), rw_ph.clone())))
            },
            crate::check::types::Ty::TyElem(rw_pi, o_pj) => {
                let o_pj = (**o_pj).clone();
                let rw_pi = rw_pi.clone();
                let st_p0 = st_p0.clone();
                call_then(start_resolve_in(st_p0.clone(), o_pj.clone()), move |resolve_in_7521: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(rw_pi.clone(), Rc::new(resolve_in_7521))))
            },
            crate::check::types::Ty::TyAssoc(n_pk, a_pl) => {
                let a_pl = (**a_pl).clone();
                let n_pk = n_pk.clone();
                let st_p0 = st_p0.clone();
                call_then(start_resolve_in(st_p0.clone(), a_pl.clone()), move |resolve_in_7568: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(n_pk.clone(), Rc::new(resolve_in_7568))))
            },
            other_pm => prism_rtl::Turn::Finished(other_pm.clone()),
        }
    }
}

/// `Start ResolveIn, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_in(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(ResolveIn { st_p0, t_p1 })
}

/// ```prism
/// AtBinder: fn St, Ty, Range -> St
/// ```
pub fn at_binder(st_p0: &crate::check::types::St, ty1: &crate::check::types::Ty, range2: &crate::syntax::Range) -> crate::check::types::St {
    match (ty1, range2) {
        (crate::check::types::Ty::TyFlex(n_p1), span_p2) => {
            let mut this: crate::check::types::St = st_p0.clone();
            this.binder_at = insert(&this.binder_at, n_p1, span_p2);
            this
        },
        (_, _) => st_p0.clone(),
    }
}

/// ```prism
/// FreshRow: fn St, [Text] -> ((Rw, St))
/// ```
pub fn fresh_row(st_p0: &crate::check::types::St, lacking_p1: &Array<Text>) -> (crate::check::types::Rw, crate::check::types::St) {
    let n_p2 = st_p0.next.clone();
    let st2_p3 = {
        let mut this: crate::check::types::St = st_p0.clone();
        this.next = &this.next + &Nat::from(1u32);
        this.lacks = insert(&this.lacks, &n_p2, lacking_p1);
        this
    };
    (crate::check::types::Rw { fams: Array::new(), minus: Array::new(), tail: crate::check::types::Tail::TlFlex(n_p2.clone()) }, st2_p3.clone())
}

/// ```prism
/// AddDiag: fn St, CDiag -> St
/// ```
pub fn add_diag(st_p0: &crate::check::types::St, d_p1: &crate::check::errors::CDiag) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.diags = push(&this.diags, d_p1);
    this
}

/// ```prism
/// Err: fn St, Text, Range, Text -> St
/// ```
pub fn err(st_p0: &crate::check::types::St, code_p1: &Text, span_p2: &crate::syntax::Range, message_p3: &Text) -> crate::check::types::St {
    add_diag(st_p0, &crate::check::errors::diag0(code_p1, &st_p0.file, span_p2, message_p3))
}

/// ```prism
/// ErrFix: fn St, Text, Range, Text, Text -> St
/// ```
pub fn err_fix(st_p0: &crate::check::types::St, code_p1: &Text, span_p2: &crate::syntax::Range, message_p3: &Text, fix_p4: &Text) -> crate::check::types::St {
    add_diag(st_p0, &crate::check::errors::diag_fix(code_p1, &st_p0.file, span_p2, message_p3, fix_p4))
}

/// ```prism
/// InfoOf: fn St, Nat -> VInfo
/// ```
pub fn info_of(st_p0: &crate::check::types::St, n_p1: &Nat) -> crate::check::types::VInfo {
    or(&get(&st_p0.infos, n_p1), &crate::check::types::VInfo { plain: false, level: Nat::from(0u32), name: Text::lit("") })
}

/// ```prism
/// Walk: unbounded fn St, Ty -> Ty
/// ```
pub fn walk(st_p0: &crate::check::types::St, ty1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match ty1 {
        crate::check::types::Ty::TyFlex(n_p1) => match get(&st_p0.tys, n_p1) {
            Some(t_p2) => walk(st_p0, &t_p2),
            None => crate::check::types::Ty::TyFlex(n_p1.clone()),
        },
        t_p4 => t_p4.clone(),
    }
}

/// The step machine of `Walk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Walk: unbounded fn St, Ty -> Ty
/// ```
pub struct Walk {
    pub st_p0: crate::check::types::St,
    pub ty1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for Walk {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let ty1 = &self.ty1;
        match ty1 {
            crate::check::types::Ty::TyFlex(n_p1) => match get(&st_p0.tys, n_p1) {
                Some(t_p2) => prism_rtl::Turn::More(Rc::new(Walk { st_p0: st_p0.clone(), ty1: t_p2.clone() })),
                None => prism_rtl::Turn::Finished(crate::check::types::Ty::TyFlex(n_p1.clone())),
            },
            t_p4 => prism_rtl::Turn::Finished(t_p4.clone()),
        }
    }
}

/// `Start Walk, x`: what the function value is when passed to `@Run`.
pub fn start_walk(st_p0: crate::check::types::St, ty1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(Walk { st_p0, ty1 })
}

/// ```prism
/// WalkRow: unbounded fn St, Rw -> Rw
/// ```
pub fn walk_row(st_p0: &crate::check::types::St, r_p1: &crate::check::types::Rw) -> crate::check::types::Rw {
    match &r_p1.tail {
        crate::check::types::Tail::TlFlex(n_p2) => match get(&st_p0.rows, n_p2) {
            Some(r2_p3) => {
                let w_p4 = walk_row(st_p0, &r2_p3);
                crate::check::types::Rw { fams: crate::check::types::sort_texts(&crate::check::types::union_texts(&r_p1.fams, &w_p4.fams)), minus: crate::check::types::union_texts(&r_p1.minus, &w_p4.minus), tail: w_p4.tail.clone() }
            },
            None => r_p1.clone(),
        },
        _ => r_p1.clone(),
    }
}

/// The step machine of `WalkRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkRow: unbounded fn St, Rw -> Rw
/// ```
pub struct WalkRow {
    pub st_p0: crate::check::types::St,
    pub r_p1: crate::check::types::Rw,
}

impl prism_rtl::Job<crate::check::types::Rw> for WalkRow {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Rw> {
        let st_p0 = &self.st_p0;
        let r_p1 = &self.r_p1;
        match &r_p1.tail {
            crate::check::types::Tail::TlFlex(n_p2) => match get(&st_p0.rows, n_p2) {
                Some(r2_p3) => {
                    let r_p1 = r_p1.clone();
                    let st_p0 = st_p0.clone();
                    call_then(start_walk_row(st_p0.clone(), r2_p3.clone()), move |walk_row_8935: crate::check::types::Rw| {
                        let w_p4 = walk_row_8935;
                        prism_rtl::Turn::Finished(crate::check::types::Rw { fams: crate::check::types::sort_texts(&crate::check::types::union_texts(&r_p1.fams, &w_p4.fams)), minus: crate::check::types::union_texts(&r_p1.minus, &w_p4.minus), tail: w_p4.tail.clone() })
                    })
                },
                None => prism_rtl::Turn::Finished(r_p1.clone()),
            },
            _ => prism_rtl::Turn::Finished(r_p1.clone()),
        }
    }
}

/// `Start WalkRow, x`: what the function value is when passed to `@Run`.
pub fn start_walk_row(st_p0: crate::check::types::St, r_p1: crate::check::types::Rw) -> Rc<dyn prism_rtl::Job<crate::check::types::Rw>> {
    Rc::new(WalkRow { st_p0, r_p1 })
}

/// ```prism
/// Zonk: unbounded fn St, Ty -> Ty
/// ```
pub fn zonk(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match crate::check::types::unify::norm_assoc(st_p0, &walk(st_p0, t_p1)) {
        crate::check::types::Ty::TyCon(n_p2, args_p3) => crate::check::types::Ty::TyCon(n_p2.clone(), run_to_end(each_job(args_p3.clone(), {
            let st_p0 = st_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let a_p4 = p0;
                    prism_rtl::Turn::More(Rc::new(Zonk { st_p0: st_p0.clone(), t_p1: a_p4.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c_p5, ps_p6, res_p7) => crate::check::types::Ty::TyFn(crate::check::types::colors::walk_col(st_p0, &c_p5), run_to_end(each_job(ps_p6.clone(), {
            let st_p0 = st_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let p_p8 = p0;
                    prism_rtl::Turn::More(Rc::new(Zonk { st_p0: st_p0.clone(), t_p1: p_p8.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        })), Rc::new(zonk(st_p0, &*res_p7))),
        crate::check::types::Ty::TyTuple(ts_p9) => crate::check::types::Ty::TyTuple(run_to_end(each_job(ts_p9.clone(), {
            let st_p0 = st_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let a_pa = p0;
                    prism_rtl::Turn::More(Rc::new(Zonk { st_p0: st_p0.clone(), t_p1: a_pa.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e_pb) => crate::check::types::Ty::TyArray(Rc::new(zonk(st_p0, &*e_pb))),
        crate::check::types::Ty::TyMap(k_pc, v_pd) => crate::check::types::Ty::TyMap(Rc::new(zonk(st_p0, &*k_pc)), Rc::new(zonk(st_p0, &*v_pd))),
        crate::check::types::Ty::TySig(s_pe, i_pf) => crate::check::types::Ty::TySig(s_pe, Rc::new(zonk(st_p0, &*i_pf))),
        crate::check::types::Ty::TyAt(i_pg, rw_ph) => crate::check::types::Ty::TyAt(Rc::new(zonk(st_p0, &*i_pg)), walk_row(st_p0, &rw_ph)),
        crate::check::types::Ty::TyElem(rw_pi, o_pj) => crate::check::types::Ty::TyElem(walk_row(st_p0, &rw_pi), Rc::new(zonk(st_p0, &*o_pj))),
        crate::check::types::Ty::TyElemAny(rw_pk) => crate::check::types::Ty::TyElemAny(walk_row(st_p0, &rw_pk)),
        crate::check::types::Ty::TyAssoc(n_pl, a_pm) => crate::check::types::Ty::TyAssoc(n_pl, Rc::new(zonk(st_p0, &*a_pm))),
        w_pn => w_pn,
    }
}

/// The step machine of `Zonk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Zonk: unbounded fn St, Ty -> Ty
/// ```
pub struct Zonk {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for Zonk {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(start_walk(st_p0.clone(), t_p1.clone()), move |walk_9226: crate::check::types::Ty| call_then(crate::check::types::unify::start_norm_assoc(st_p0.clone(), walk_9226), move |norm_assoc_9211: crate::check::types::Ty| match norm_assoc_9211 {
            crate::check::types::Ty::TyCon(n_p2, args_p3) => call_value(each_job(args_p3.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let a_p4 = p0;
                        prism_rtl::Turn::More(Rc::new(Zonk { st_p0: st_p0.clone(), t_p1: a_p4.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_9268: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p2.clone(), each_9268))),
            crate::check::types::Ty::TyFn(c_p5, ps_p6, res_p7) => call_then(crate::check::types::colors::start_walk_col(st_p0.clone(), c_p5.clone()), move |walk_col_9323: crate::check::types::Col| call_value(each_job(ps_p6.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let p_p8 = p0;
                        prism_rtl::Turn::More(Rc::new(Zonk { st_p0: st_p0.clone(), t_p1: p_p8.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_9340: Array<crate::check::types::Ty>| call_then(start_zonk(st_p0.clone(), (*res_p7).clone()), move |zonk_9368: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(walk_col_9323, each_9340, Rc::new(zonk_9368)))))),
            crate::check::types::Ty::TyTuple(ts_p9) => call_value(each_job(ts_p9.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let a_pa = p0;
                        prism_rtl::Turn::More(Rc::new(Zonk { st_p0: st_p0.clone(), t_p1: a_pa.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_9407: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_9407))),
            crate::check::types::Ty::TyArray(e_pb) => call_then(start_zonk(st_p0.clone(), (*e_pb).clone()), move |zonk_9457: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(zonk_9457)))),
            crate::check::types::Ty::TyMap(k_pc, v_pd) => call_then(start_zonk(st_p0.clone(), (*k_pc).clone()), move |zonk_9492: crate::check::types::Ty| call_then(start_zonk(st_p0.clone(), (*v_pd).clone()), move |zonk_9506: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(zonk_9492), Rc::new(zonk_9506))))),
            crate::check::types::Ty::TySig(s_pe, i_pf) => call_then(start_zonk(st_p0.clone(), (*i_pf).clone()), move |zonk_9544: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pe.clone(), Rc::new(zonk_9544)))),
            crate::check::types::Ty::TyAt(i_pg, rw_ph) => call_then(start_zonk(st_p0.clone(), (*i_pg).clone()), move |zonk_9578: crate::check::types::Ty| call_then(start_walk_row(st_p0.clone(), rw_ph.clone()), move |walk_row_9592: crate::check::types::Rw| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(Rc::new(zonk_9578), walk_row_9592)))),
            crate::check::types::Ty::TyElem(rw_pi, o_pj) => call_then(start_walk_row(st_p0.clone(), rw_pi.clone()), move |walk_row_9634: crate::check::types::Rw| call_then(start_zonk(st_p0.clone(), (*o_pj).clone()), move |zonk_9652: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(walk_row_9634, Rc::new(zonk_9652))))),
            crate::check::types::Ty::TyElemAny(rw_pk) => call_then(start_walk_row(st_p0.clone(), rw_pk.clone()), move |walk_row_9693: crate::check::types::Rw| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElemAny(walk_row_9693))),
            crate::check::types::Ty::TyAssoc(n_pl, a_pm) => call_then(start_zonk(st_p0.clone(), (*a_pm).clone()), move |zonk_9739: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(n_pl.clone(), Rc::new(zonk_9739)))),
            w_pn => prism_rtl::Turn::Finished(w_pn.clone()),
        }))
    }
}

/// `Start Zonk, x`: what the function value is when passed to `@Run`.
pub fn start_zonk(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(Zonk { st_p0, t_p1 })
}

/// ```prism
/// FreeVars: unbounded fn St, Ty -> [Nat]
/// ```
pub fn free_vars(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> Array<Nat> {
    free_vars_into(st_p0, &Array::new(), t_p1)
}

/// The step machine of `FreeVars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeVars: unbounded fn St, Ty -> [Nat]
/// ```
pub struct FreeVars {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Nat>> for FreeVars {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: Array::new(), t_p2: t_p1.clone() }))
    }
}

/// `Start FreeVars, x`: what the function value is when passed to `@Run`.
pub fn start_free_vars(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(FreeVars { st_p0, t_p1 })
}

/// ```prism
/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub fn free_vars_into(st_p0: &crate::check::types::St, acc_p1: &Array<Nat>, t_p2: &crate::check::types::Ty) -> Array<Nat> {
    match walk(st_p0, t_p2) {
        crate::check::types::Ty::TyFlex(n_p3) => crate::check::types::add_nat(acc_p1, &n_p3),
        crate::check::types::Ty::TyCon(_, args_p4) => run_to_end(fold_job(args_p4.clone(), acc_p1.clone(), {
            let st_p0 = st_p0.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let a_p5 = p0;
                    let x_p6 = p1;
                    prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: a_p5.clone(), t_p2: x_p6.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })),
        crate::check::types::Ty::TyFn(_, ps_p7, res_p8) => free_vars_into(st_p0, &run_to_end(fold_job(ps_p7.clone(), acc_p1.clone(), {
            let st_p0 = st_p0.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let a_p9 = p0;
                    let x_pa = p1;
                    prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: a_p9.clone(), t_p2: x_pa.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })), &*res_p8),
        crate::check::types::Ty::TyTuple(ts_pb) => run_to_end(fold_job(ts_pb.clone(), acc_p1.clone(), {
            let st_p0 = st_p0.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let a_pc = p0;
                    let x_pd = p1;
                    prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: a_pc.clone(), t_p2: x_pd.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })),
        crate::check::types::Ty::TyArray(e_pe) => free_vars_into(st_p0, acc_p1, &*e_pe),
        crate::check::types::Ty::TyMap(k_pf, v_pg) => free_vars_into(st_p0, &free_vars_into(st_p0, acc_p1, &*k_pf), &*v_pg),
        crate::check::types::Ty::TySig(_, i_ph) => free_vars_into(st_p0, acc_p1, &*i_ph),
        crate::check::types::Ty::TyAt(i_pi, _) => free_vars_into(st_p0, acc_p1, &*i_pi),
        crate::check::types::Ty::TyElem(_, o_pj) => free_vars_into(st_p0, acc_p1, &*o_pj),
        crate::check::types::Ty::TyAssoc(_, a_pk) => free_vars_into(st_p0, acc_p1, &*a_pk),
        _ => acc_p1.clone(),
    }
}

/// The step machine of `FreeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub struct FreeVarsInto {
    pub st_p0: crate::check::types::St,
    pub acc_p1: Array<Nat>,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Nat>> for FreeVarsInto {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let st_p0 = &self.st_p0;
        let acc_p1 = &self.acc_p1;
        let t_p2 = &self.t_p2;
        let acc_p1 = acc_p1.clone();
        let st_p0 = st_p0.clone();
        let t_p2 = t_p2.clone();
        call_then(start_walk(st_p0.clone(), t_p2.clone()), move |walk_9972: crate::check::types::Ty| match walk_9972 {
            crate::check::types::Ty::TyFlex(n_p3) => prism_rtl::Turn::Finished(crate::check::types::add_nat(&acc_p1, &n_p3)),
            crate::check::types::Ty::TyCon(_, args_p4) => fold_job(args_p4.clone(), acc_p1.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let a_p5 = p0;
                        let x_p6 = p1;
                        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: a_p5.clone(), t_p2: x_p6.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }).cycle(),
            crate::check::types::Ty::TyFn(_, ps_p7, res_p8) => call_value(fold_job(ps_p7.clone(), acc_p1.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let a_p9 = p0;
                        let x_pa = p1;
                        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: a_p9.clone(), t_p2: x_pa.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }), move |fold_10126: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: fold_10126, t_p2: (*res_p8).clone() }))),
            crate::check::types::Ty::TyTuple(ts_pb) => fold_job(ts_pb.clone(), acc_p1.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let a_pc = p0;
                        let x_pd = p1;
                        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: a_pc.clone(), t_p2: x_pd.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e_pe) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: acc_p1.clone(), t_p2: (*e_pe).clone() })),
            crate::check::types::Ty::TyMap(k_pf, v_pg) => call_then(start_free_vars_into(st_p0.clone(), acc_p1.clone(), (*k_pf).clone()), move |free_vars_into_10309: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: free_vars_into_10309, t_p2: (*v_pg).clone() }))),
            crate::check::types::Ty::TySig(_, i_ph) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: acc_p1.clone(), t_p2: (*i_ph).clone() })),
            crate::check::types::Ty::TyAt(i_pi, _) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: acc_p1.clone(), t_p2: (*i_pi).clone() })),
            crate::check::types::Ty::TyElem(_, o_pj) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: acc_p1.clone(), t_p2: (*o_pj).clone() })),
            crate::check::types::Ty::TyAssoc(_, a_pk) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: acc_p1.clone(), t_p2: (*a_pk).clone() })),
            _ => prism_rtl::Turn::Finished(acc_p1.clone()),
        })
    }
}

/// `Start FreeVarsInto, x`: what the function value is when passed to `@Run`.
pub fn start_free_vars_into(st_p0: crate::check::types::St, acc_p1: Array<Nat>, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(FreeVarsInto { st_p0, acc_p1, t_p2 })
}
