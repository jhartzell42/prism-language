//! The module `Check.Types`, from `target/bootstrap/src/prismc/check/types/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod colors;
pub mod recording;
pub mod schemes;
pub mod unify;

/// `CLeq`:
///
/// ```prism
/// type CLeq = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CLeq {
    pub lo_p: Col,
    pub hi_p: Col,
    pub file_p: Nat,
    pub span_p: crate::syntax::Range,
    pub kind_p: Text,
    pub name_p: Text,
    pub why_p: Text,
}

impl Show for CLeq {
    fn show(&self, p: &mut Printer) {
        p.record("CLeq", &[("lo", &self.lo_p), ("hi", &self.hi_p), ("file", &self.file_p), ("span", &self.span_p), ("kind", &self.kind_p), ("name", &self.name_p), ("why", &self.why_p)]);
    }
}

impl ToPod for CLeq {
    fn to_pod(&self) -> Pod {
        Pod::record("CLeq", vec![("lo", self.lo_p.to_pod()), ("hi", self.hi_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod()), ("kind", self.kind_p.to_pod()), ("name", self.name_p.to_pod()), ("why", self.why_p.to_pod())])
    }
}

impl FromPod for CLeq {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CLeq { lo_p: FromPod::from_pod(field(p, "lo")?)?, hi_p: FromPod::from_pod(field(p, "hi")?)?, file_p: FromPod::from_pod(field(p, "file")?)?, span_p: FromPod::from_pod(field(p, "span")?)?, kind_p: FromPod::from_pod(field(p, "kind")?)?, name_p: FromPod::from_pod(field(p, "name")?)?, why_p: FromPod::from_pod(field(p, "why")?)? })
    }
}

/// `Col`:
///
/// ```prism
/// type Col = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Col {
    CBound,
    CUnbound,
    CRigid(Text),
    CQ(Text),
    CFlex(Nat),
}

impl Show for Col {
    fn show(&self, p: &mut Printer) {
        match self {
            Col::CBound => p.choice("CBound", &[]),
            Col::CUnbound => p.choice("CUnbound", &[]),
            Col::CRigid(a0) => p.choice("CRigid", &[a0]),
            Col::CQ(a0) => p.choice("CQ", &[a0]),
            Col::CFlex(a0) => p.choice("CFlex", &[a0]),
        }
    }
}

impl ToPod for Col {
    fn to_pod(&self) -> Pod {
        match self {
            Col::CBound => Pod::Choice("CBound".into(), vec![]),
            Col::CUnbound => Pod::Choice("CUnbound".into(), vec![]),
            Col::CRigid(a0) => Pod::Choice("CRigid".into(), vec![a0.to_pod()]),
            Col::CQ(a0) => Pod::Choice("CQ".into(), vec![a0.to_pod()]),
            Col::CFlex(a0) => Pod::Choice("CFlex".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Col {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "CBound" && a.len() == 0 => Ok(Col::CBound),
            Pod::Choice(c, a) if &**c == "CUnbound" && a.len() == 0 => Ok(Col::CUnbound),
            Pod::Choice(c, a) if &**c == "CRigid" && a.len() == 1 => Ok(Col::CRigid(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CQ" && a.len() == 1 => Ok(Col::CQ(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CFlex" && a.len() == 1 => Ok(Col::CFlex(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Col", other),
        }
    }
}

/// `Incl`:
///
/// ```prism
/// type Incl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Incl {
    pub sub_p: Rw,
    pub sup_p: Rw,
    pub file_p: Nat,
    pub span_p: crate::syntax::Range,
    pub what_p: Text,
    pub forward_p: bool,
}

impl Show for Incl {
    fn show(&self, p: &mut Printer) {
        p.record("Incl", &[("sub", &self.sub_p), ("sup", &self.sup_p), ("file", &self.file_p), ("span", &self.span_p), ("what", &self.what_p), ("forward", &self.forward_p)]);
    }
}

impl ToPod for Incl {
    fn to_pod(&self) -> Pod {
        Pod::record("Incl", vec![("sub", self.sub_p.to_pod()), ("sup", self.sup_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod()), ("what", self.what_p.to_pod()), ("forward", self.forward_p.to_pod())])
    }
}

impl FromPod for Incl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Incl { sub_p: FromPod::from_pod(field(p, "sub")?)?, sup_p: FromPod::from_pod(field(p, "sup")?)?, file_p: FromPod::from_pod(field(p, "file")?)?, span_p: FromPod::from_pod(field(p, "span")?)?, what_p: FromPod::from_pod(field(p, "what")?)?, forward_p: FromPod::from_pod(field(p, "forward")?)? })
    }
}

/// `Rw`:
///
/// ```prism
/// type Rw = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Rw {
    pub fams_p: Array<Text>,
    pub minus_p: Array<Text>,
    pub tail_p: Tail,
}

impl Show for Rw {
    fn show(&self, p: &mut Printer) {
        p.record("Rw", &[("fams", &self.fams_p), ("minus", &self.minus_p), ("tail", &self.tail_p)]);
    }
}

impl ToPod for Rw {
    fn to_pod(&self) -> Pod {
        Pod::record("Rw", vec![("fams", self.fams_p.to_pod()), ("minus", self.minus_p.to_pod()), ("tail", self.tail_p.to_pod())])
    }
}

impl FromPod for Rw {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Rw { fams_p: FromPod::from_pod(field(p, "fams")?)?, minus_p: FromPod::from_pod(field(p, "minus")?)?, tail_p: FromPod::from_pod(field(p, "tail")?)? })
    }
}

/// `Scheme`:
///
/// ```prism
/// type Scheme = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Scheme {
    pub qs_p: Array<Text>,
    pub plain_qs_p: Array<Text>,
    pub rqs_p: Array<Text>,
    pub cqs_p: Array<Text>,
    pub cjoins_p: Array<(Text, Text)>,
    pub bounds_p: Array<(Text, Text)>,
    pub ty_p: Ty,
}

impl Show for Scheme {
    fn show(&self, p: &mut Printer) {
        p.record("Scheme", &[("qs", &self.qs_p), ("plainQs", &self.plain_qs_p), ("rqs", &self.rqs_p), ("cqs", &self.cqs_p), ("cjoins", &self.cjoins_p), ("bounds", &self.bounds_p), ("ty", &self.ty_p)]);
    }
}

impl ToPod for Scheme {
    fn to_pod(&self) -> Pod {
        Pod::record("Scheme", vec![("qs", self.qs_p.to_pod()), ("plainQs", self.plain_qs_p.to_pod()), ("rqs", self.rqs_p.to_pod()), ("cqs", self.cqs_p.to_pod()), ("cjoins", self.cjoins_p.to_pod()), ("bounds", self.bounds_p.to_pod()), ("ty", self.ty_p.to_pod())])
    }
}

impl FromPod for Scheme {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Scheme { qs_p: FromPod::from_pod(field(p, "qs")?)?, plain_qs_p: FromPod::from_pod(field(p, "plainQs")?)?, rqs_p: FromPod::from_pod(field(p, "rqs")?)?, cqs_p: FromPod::from_pod(field(p, "cqs")?)?, cjoins_p: FromPod::from_pod(field(p, "cjoins")?)?, bounds_p: FromPod::from_pod(field(p, "bounds")?)?, ty_p: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// `St`:
///
/// ```prism
/// type St = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct St {
    pub next_p: Nat,
    pub tys_p: Map<Nat, Ty>,
    pub infos_p: Map<Nat, VInfo>,
    pub rows_p: Map<Nat, Rw>,
    pub lacks_p: Map<Nat, Array<Text>>,
    pub wants_p: Array<Want>,
    pub incls_p: Array<Incl>,
    pub diags_p: Array<crate::check::errors::CDiag>,
    pub level_p: Nat,
    pub file_p: Nat,
    pub color_p: Col,
    pub color_why_p: Text,
    pub color_flex_p: Array<(Col, Text, crate::syntax::Range)>,
    pub cols_p: Map<Nat, Col>,
    pub cleqs_p: Array<CLeq>,
    pub col_q_p: Map<Nat, Text>,
    pub col_up_p: Map<Text, Text>,
    pub deferred_p: Array<(Ty, Ty, crate::syntax::Range)>,
    pub binder_at_p: Map<Nat, crate::syntax::Range>,
    pub row_names_p: Map<Nat, Text>,
    pub layer_qs_p: Array<(Ty, crate::syntax::Range, Text)>,
    pub field_qs_p: Array<crate::check::types::unify::FieldQ>,
    pub recording_p: bool,
    pub typed_p: crate::check::typed::TProgram,
    pub choices_p: Map<Text, Array<Text>>,
    pub size_tys_p: Map<Text, Ty>,
    pub local_next_p: Nat,
    pub local_ids_p: Map<Text, Nat>,
    pub any_givens_p: Array<(Text, Text)>,
}

impl Show for St {
    fn show(&self, p: &mut Printer) {
        p.record("St", &[("next", &self.next_p), ("tys", &self.tys_p), ("infos", &self.infos_p), ("rows", &self.rows_p), ("lacks", &self.lacks_p), ("wants", &self.wants_p), ("incls", &self.incls_p), ("diags", &self.diags_p), ("level", &self.level_p), ("file", &self.file_p), ("color", &self.color_p), ("colorWhy", &self.color_why_p), ("colorFlex", &self.color_flex_p), ("cols", &self.cols_p), ("cleqs", &self.cleqs_p), ("colQ", &self.col_q_p), ("colUp", &self.col_up_p), ("deferred", &self.deferred_p), ("binderAt", &self.binder_at_p), ("rowNames", &self.row_names_p), ("layerQs", &self.layer_qs_p), ("fieldQs", &self.field_qs_p), ("recording", &self.recording_p), ("typed", &self.typed_p), ("choices", &self.choices_p), ("sizeTys", &self.size_tys_p), ("localNext", &self.local_next_p), ("localIds", &self.local_ids_p), ("anyGivens", &self.any_givens_p)]);
    }
}

impl ToPod for St {
    fn to_pod(&self) -> Pod {
        Pod::record("St", vec![("next", self.next_p.to_pod()), ("tys", self.tys_p.to_pod()), ("infos", self.infos_p.to_pod()), ("rows", self.rows_p.to_pod()), ("lacks", self.lacks_p.to_pod()), ("wants", self.wants_p.to_pod()), ("incls", self.incls_p.to_pod()), ("diags", self.diags_p.to_pod()), ("level", self.level_p.to_pod()), ("file", self.file_p.to_pod()), ("color", self.color_p.to_pod()), ("colorWhy", self.color_why_p.to_pod()), ("colorFlex", self.color_flex_p.to_pod()), ("cols", self.cols_p.to_pod()), ("cleqs", self.cleqs_p.to_pod()), ("colQ", self.col_q_p.to_pod()), ("colUp", self.col_up_p.to_pod()), ("deferred", self.deferred_p.to_pod()), ("binderAt", self.binder_at_p.to_pod()), ("rowNames", self.row_names_p.to_pod()), ("layerQs", self.layer_qs_p.to_pod()), ("fieldQs", self.field_qs_p.to_pod()), ("recording", self.recording_p.to_pod()), ("typed", self.typed_p.to_pod()), ("choices", self.choices_p.to_pod()), ("sizeTys", self.size_tys_p.to_pod()), ("localNext", self.local_next_p.to_pod()), ("localIds", self.local_ids_p.to_pod()), ("anyGivens", self.any_givens_p.to_pod())])
    }
}

impl FromPod for St {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(St { next_p: FromPod::from_pod(field(p, "next")?)?, tys_p: FromPod::from_pod(field(p, "tys")?)?, infos_p: FromPod::from_pod(field(p, "infos")?)?, rows_p: FromPod::from_pod(field(p, "rows")?)?, lacks_p: FromPod::from_pod(field(p, "lacks")?)?, wants_p: FromPod::from_pod(field(p, "wants")?)?, incls_p: FromPod::from_pod(field(p, "incls")?)?, diags_p: FromPod::from_pod(field(p, "diags")?)?, level_p: FromPod::from_pod(field(p, "level")?)?, file_p: FromPod::from_pod(field(p, "file")?)?, color_p: FromPod::from_pod(field(p, "color")?)?, color_why_p: FromPod::from_pod(field(p, "colorWhy")?)?, color_flex_p: FromPod::from_pod(field(p, "colorFlex")?)?, cols_p: FromPod::from_pod(field(p, "cols")?)?, cleqs_p: FromPod::from_pod(field(p, "cleqs")?)?, col_q_p: FromPod::from_pod(field(p, "colQ")?)?, col_up_p: FromPod::from_pod(field(p, "colUp")?)?, deferred_p: FromPod::from_pod(field(p, "deferred")?)?, binder_at_p: FromPod::from_pod(field(p, "binderAt")?)?, row_names_p: FromPod::from_pod(field(p, "rowNames")?)?, layer_qs_p: FromPod::from_pod(field(p, "layerQs")?)?, field_qs_p: FromPod::from_pod(field(p, "fieldQs")?)?, recording_p: FromPod::from_pod(field(p, "recording")?)?, typed_p: FromPod::from_pod(field(p, "typed")?)?, choices_p: FromPod::from_pod(field(p, "choices")?)?, size_tys_p: FromPod::from_pod(field(p, "sizeTys")?)?, local_next_p: FromPod::from_pod(field(p, "localNext")?)?, local_ids_p: FromPod::from_pod(field(p, "localIds")?)?, any_givens_p: FromPod::from_pod(field(p, "anyGivens")?)? })
    }
}

/// `Tail`:
///
/// ```prism
/// type Tail = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Tail {
    TlClosed,
    TlFlex(Nat),
    TlRigid(Text),
    TlQ(Text),
}

impl Show for Tail {
    fn show(&self, p: &mut Printer) {
        match self {
            Tail::TlClosed => p.choice("TlClosed", &[]),
            Tail::TlFlex(a0) => p.choice("TlFlex", &[a0]),
            Tail::TlRigid(a0) => p.choice("TlRigid", &[a0]),
            Tail::TlQ(a0) => p.choice("TlQ", &[a0]),
        }
    }
}

impl ToPod for Tail {
    fn to_pod(&self) -> Pod {
        match self {
            Tail::TlClosed => Pod::Choice("TlClosed".into(), vec![]),
            Tail::TlFlex(a0) => Pod::Choice("TlFlex".into(), vec![a0.to_pod()]),
            Tail::TlRigid(a0) => Pod::Choice("TlRigid".into(), vec![a0.to_pod()]),
            Tail::TlQ(a0) => Pod::Choice("TlQ".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Tail {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TlClosed" && a.len() == 0 => Ok(Tail::TlClosed),
            Pod::Choice(c, a) if &**c == "TlFlex" && a.len() == 1 => Ok(Tail::TlFlex(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TlRigid" && a.len() == 1 => Ok(Tail::TlRigid(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TlQ" && a.len() == 1 => Ok(Tail::TlQ(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Tail", other),
        }
    }
}

/// `Ty`:
///
/// ```prism
/// type Ty = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Ty {
    TyFlex(Nat),
    TyRigid(Text),
    TyQ(Text),
    TyCon(Text, Array<Ty>),
    TyFn(Col, Array<Ty>, Rc<Ty>),
    TyTuple(Array<Ty>),
    TyArray(Rc<Ty>),
    TyMap(Rc<Ty>, Rc<Ty>),
    TySig(Text, Rc<Ty>),
    TyAt(Rc<Ty>, Rw),
    TyElem(Rw, Rc<Ty>),
    TyElemAny(Rw),
    TyAssoc(Text, Rc<Ty>),
    TyAny(Array<Text>),
    TyErr,
}

impl Show for Ty {
    fn show(&self, p: &mut Printer) {
        match self {
            Ty::TyFlex(a0) => p.choice("TyFlex", &[a0]),
            Ty::TyRigid(a0) => p.choice("TyRigid", &[a0]),
            Ty::TyQ(a0) => p.choice("TyQ", &[a0]),
            Ty::TyCon(a0, a1) => p.choice("TyCon", &[a0, a1]),
            Ty::TyFn(a0, a1, a2) => p.choice("TyFn", &[a0, a1, a2]),
            Ty::TyTuple(a0) => p.choice("TyTuple", &[a0]),
            Ty::TyArray(a0) => p.choice("TyArray", &[a0]),
            Ty::TyMap(a0, a1) => p.choice("TyMap", &[a0, a1]),
            Ty::TySig(a0, a1) => p.choice("TySig", &[a0, a1]),
            Ty::TyAt(a0, a1) => p.choice("TyAt", &[a0, a1]),
            Ty::TyElem(a0, a1) => p.choice("TyElem", &[a0, a1]),
            Ty::TyElemAny(a0) => p.choice("TyElemAny", &[a0]),
            Ty::TyAssoc(a0, a1) => p.choice("TyAssoc", &[a0, a1]),
            Ty::TyAny(a0) => p.choice("TyAny", &[a0]),
            Ty::TyErr => p.choice("TyErr", &[]),
        }
    }
}

impl ToPod for Ty {
    fn to_pod(&self) -> Pod {
        match self {
            Ty::TyFlex(a0) => Pod::Choice("TyFlex".into(), vec![a0.to_pod()]),
            Ty::TyRigid(a0) => Pod::Choice("TyRigid".into(), vec![a0.to_pod()]),
            Ty::TyQ(a0) => Pod::Choice("TyQ".into(), vec![a0.to_pod()]),
            Ty::TyCon(a0, a1) => Pod::Choice("TyCon".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyFn(a0, a1, a2) => Pod::Choice("TyFn".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ty::TyTuple(a0) => Pod::Choice("TyTuple".into(), vec![a0.to_pod()]),
            Ty::TyArray(a0) => Pod::Choice("TyArray".into(), vec![a0.to_pod()]),
            Ty::TyMap(a0, a1) => Pod::Choice("TyMap".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TySig(a0, a1) => Pod::Choice("TySig".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyAt(a0, a1) => Pod::Choice("TyAt".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyElem(a0, a1) => Pod::Choice("TyElem".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyElemAny(a0) => Pod::Choice("TyElemAny".into(), vec![a0.to_pod()]),
            Ty::TyAssoc(a0, a1) => Pod::Choice("TyAssoc".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyAny(a0) => Pod::Choice("TyAny".into(), vec![a0.to_pod()]),
            Ty::TyErr => Pod::Choice("TyErr".into(), vec![]),
        }
    }
}

impl FromPod for Ty {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TyFlex" && a.len() == 1 => Ok(Ty::TyFlex(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyRigid" && a.len() == 1 => Ok(Ty::TyRigid(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyQ" && a.len() == 1 => Ok(Ty::TyQ(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyCon" && a.len() == 2 => Ok(Ty::TyCon(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyFn" && a.len() == 3 => Ok(Ty::TyFn(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "TyTuple" && a.len() == 1 => Ok(Ty::TyTuple(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyArray" && a.len() == 1 => Ok(Ty::TyArray(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyMap" && a.len() == 2 => Ok(Ty::TyMap(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TySig" && a.len() == 2 => Ok(Ty::TySig(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyAt" && a.len() == 2 => Ok(Ty::TyAt(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyElem" && a.len() == 2 => Ok(Ty::TyElem(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyElemAny" && a.len() == 1 => Ok(Ty::TyElemAny(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyAssoc" && a.len() == 2 => Ok(Ty::TyAssoc(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyAny" && a.len() == 1 => Ok(Ty::TyAny(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyErr" && a.len() == 0 => Ok(Ty::TyErr),
            other => mismatch("a Ty", other),
        }
    }
}

/// `VInfo`:
///
/// ```prism
/// type VInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct VInfo {
    pub plain_p: bool,
    pub level_p: Nat,
    pub name_p: Text,
}

impl Show for VInfo {
    fn show(&self, p: &mut Printer) {
        p.record("VInfo", &[("plain", &self.plain_p), ("level", &self.level_p), ("name", &self.name_p)]);
    }
}

impl ToPod for VInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("VInfo", vec![("plain", self.plain_p.to_pod()), ("level", self.level_p.to_pod()), ("name", self.name_p.to_pod())])
    }
}

impl FromPod for VInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(VInfo { plain_p: FromPod::from_pod(field(p, "plain")?)?, level_p: FromPod::from_pod(field(p, "level")?)?, name_p: FromPod::from_pod(field(p, "name")?)? })
    }
}

/// `Want`:
///
/// ```prism
/// type Want = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Want {
    pub cls_p: Text,
    pub ty_p: Ty,
    pub file_p: Nat,
    pub span_p: crate::syntax::Range,
    pub level_p: Nat,
}

impl Show for Want {
    fn show(&self, p: &mut Printer) {
        p.record("Want", &[("cls", &self.cls_p), ("ty", &self.ty_p), ("file", &self.file_p), ("span", &self.span_p), ("level", &self.level_p)]);
    }
}

impl ToPod for Want {
    fn to_pod(&self) -> Pod {
        Pod::record("Want", vec![("cls", self.cls_p.to_pod()), ("ty", self.ty_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod()), ("level", self.level_p.to_pod())])
    }
}

impl FromPod for Want {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Want { cls_p: FromPod::from_pod(field(p, "cls")?)?, ty_p: FromPod::from_pod(field(p, "ty")?)?, file_p: FromPod::from_pod(field(p, "file")?)?, span_p: FromPod::from_pod(field(p, "span")?)?, level_p: FromPod::from_pod(field(p, "level")?)? })
    }
}

/// ```prism
/// NewSt: fn Nat -> St
/// ```
pub fn new_st_f(file_p0: &Nat) -> St {
    St { next_p: Nat::from(0u32), tys_p: Map::new(), infos_p: Map::new(), rows_p: Map::new(), lacks_p: Map::new(), wants_p: Array::new(), incls_p: Array::new(), diags_p: Array::new(), level_p: Nat::from(0u32), file_p: file_p0.clone(), color_p: Col::CBound, color_why_p: Text::lit(""), color_flex_p: Array::new(), cols_p: Map::new(), cleqs_p: Array::new(), col_q_p: Map::new(), col_up_p: Map::new(), deferred_p: Array::new(), binder_at_p: Map::new(), row_names_p: Map::new(), layer_qs_p: Array::new(), field_qs_p: Array::new(), recording_p: false, typed_p: crate::check::typed::empty_typed_p(), choices_p: Map::new(), size_tys_p: Map::new(), local_next_p: Nat::from(0u32), local_ids_p: Map::new(), any_givens_p: Array::new() }
}

/// ```prism
/// Closed: fn [Text] -> Rw
/// ```
pub fn closed_f(fs_p0: &Array<Text>) -> Rw {
    Rw { fams_p: sort_texts_f(fs_p0), minus_p: Array::new(), tail_p: Tail::TlClosed }
}

/// ```prism
/// let emptyRow
/// ```
pub fn empty_row_p() -> Rw {
    Rw { fams_p: Array::new(), minus_p: Array::new(), tail_p: Tail::TlClosed }
}

/// ```prism
/// let tInt
/// ```
pub fn t_int_p() -> Ty {
    Ty::TyCon(Text::lit("Int"), Array::new())
}

/// ```prism
/// let tNat
/// ```
pub fn t_nat_p() -> Ty {
    Ty::TyCon(Text::lit("Nat"), Array::new())
}

/// ```prism
/// let tText
/// ```
pub fn t_text_p() -> Ty {
    Ty::TyCon(Text::lit("Text"), Array::new())
}

/// ```prism
/// let tBool
/// ```
pub fn t_bool_p() -> Ty {
    Ty::TyCon(Text::lit("Bool"), Array::new())
}

/// ```prism
/// let tUnit
/// ```
pub fn t_unit_p() -> Ty {
    Ty::TyCon(Text::lit("unit"), Array::new())
}

/// ```prism
/// let tChar
/// ```
pub fn t_char_p() -> Ty {
    Ty::TyCon(Text::lit("Char"), Array::new())
}

/// ```prism
/// let tFloat
/// ```
pub fn t_float_p() -> Ty {
    Ty::TyCon(Text::lit("Float"), Array::new())
}

/// ```prism
/// HasText: fn [Text], Text -> Bool
/// ```
pub fn has_text_f(xs_p0: &Array<Text>, x_p1: &Text) -> bool {
    crate::prelude::fold(xs_p0, &false, &(|seen_p2: &bool, y_p3: &Text| *seen_p2 || (y_p3 == x_p1)))
}

/// ```prism
/// HasNat: fn [Nat], Nat -> Bool
/// ```
pub fn has_nat_f(xs_p0: &Array<Nat>, x_p1: &Nat) -> bool {
    crate::prelude::fold(xs_p0, &false, &(|seen_p2: &bool, y_p3: &Nat| *seen_p2 || (y_p3 == x_p1)))
}

/// ```prism
/// AddText: fn [Text], Text -> [Text]
/// ```
pub fn add_text_f(xs_p0: &Array<Text>, x_p1: &Text) -> Array<Text> {
    if has_text_f(xs_p0, x_p1) { xs_p0.clone() } else { crate::prelude::push(xs_p0, x_p1) }
}

/// ```prism
/// UnionTexts: fn [Text], [Text] -> [Text]
/// ```
pub fn union_texts_f(xs_p0: &Array<Text>, ys_p1: &Array<Text>) -> Array<Text> {
    crate::prelude::fold(ys_p1, xs_p0, &(|acc_p2: &Array<Text>, y_p3: &Text| add_text_f(acc_p2, y_p3)))
}

/// ```prism
/// MinusTexts: fn [Text], [Text] -> [Text]
/// ```
pub fn minus_texts_f(xs_p0: &Array<Text>, ys_p1: &Array<Text>) -> Array<Text> {
    crate::prelude::filter(xs_p0, &(|x_p2: &Text| !has_text_f(ys_p1, x_p2)))
}

/// ```prism
/// InterTexts: fn [Text], [Text] -> [Text]
/// ```
pub fn inter_texts_f(xs_p0: &Array<Text>, ys_p1: &Array<Text>) -> Array<Text> {
    crate::prelude::filter(xs_p0, &(|x_p2: &Text| has_text_f(ys_p1, x_p2)))
}

/// ```prism
/// AddNat: fn [Nat], Nat -> [Nat]
/// ```
pub fn add_nat_f(xs_p0: &Array<Nat>, x_p1: &Nat) -> Array<Nat> {
    if has_nat_f(xs_p0, x_p1) { xs_p0.clone() } else { crate::prelude::push(xs_p0, x_p1) }
}

/// ```prism
/// SortTexts: fn [Text] -> [Text]
/// ```
pub fn sort_texts_f(xs_p0: &Array<Text>) -> Array<Text> {
    crate::prelude::fold(xs_p0, &Array::new(), &(|acc_p1: &Array<Text>, x_p2: &Text| if has_text_f(acc_p1, x_p2) {
        acc_p1.clone()
    } else {
        crate::prelude::append(&crate::prelude::push(&crate::prelude::filter(acc_p1, &(|y_p3: &Text| y_p3 < x_p2)), x_p2), &crate::prelude::filter(acc_p1, &(|y_p4: &Text| !(y_p4 < x_p2))))
    }))
}

/// ```prism
/// BareName: fn Text -> Text
/// ```
pub fn bare_name_f(q_p0: &Text) -> Text {
    crate::prelude::or(&crate::syntax::lexer::chars::last_o(&crate::prelude::split_on(q_p0, &Text::lit("."))), q_p0)
}

/// ```prism
/// FreshVar: fn St, Bool, Text -> ((Ty, St))
/// ```
pub fn fresh_var_f(st_p0: &St, plain_p1: &bool, name_p2: &Text) -> (Ty, St) {
    let n_p3 = st_p0.next_p.clone();
    let st2_p4 = {
        let mut this: St = st_p0.clone();
        this.next_p = &this.next_p + &Nat::from(1u32);
        this.infos_p = crate::prelude::insert(&this.infos_p, &n_p3, &VInfo { plain_p: *plain_p1, level_p: this.level_p.clone(), name_p: name_p2.clone() });
        this
    };
    (Ty::TyFlex(n_p3.clone()), st2_p4.clone())
}

/// ```prism
/// FreshCol: fn St -> ((Col, St))
/// ```
pub fn fresh_col_f(st_p0: &St) -> (Col, St) {
    let n_p1 = st_p0.next_p.clone();
    let st2_p2 = {
        let mut this: St = st_p0.clone();
        this.next_p = &this.next_p + &Nat::from(1u32);
        this.infos_p = crate::prelude::insert(&this.infos_p, &n_p1, &VInfo { plain_p: false, level_p: this.level_p.clone(), name_p: Text::lit("") });
        this
    };
    (Col::CFlex(n_p1.clone()), st2_p2.clone())
}

/// ```prism
/// StackOf: unbounded fn St, Ty -> Text
/// ```
pub fn stack_of_f(st_p0: &St, t_p1: &Ty) -> Text {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        Ty::TySig(s_p2, i_p3) => Text::from(format!("{}{}", &s_p2, &stack_of_f(st_p0, &*i_p3))),
        Ty::TyAt(i_p4, _) => Text::from(format!("@{}", &stack_of_f(st_p0, &*i_p4))),
        _ => Text::lit(""),
    }
}

/// The step machine of `StackOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StackOf: unbounded fn St, Ty -> Text
/// ```
pub struct StackOf {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl prism_rtl::Job<Text> for StackOf {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_8402: Ty| match walk_f_8402 {
            Ty::TySig(s_p2, i_p3) => crate::prelude::call_then(start_stack_of_f(st_p0x.clone(), (*i_p3).clone()), move |stack_of_f_8435: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &s_p2, &stack_of_f_8435)))),
            Ty::TyAt(i_p4, _) => crate::prelude::call_then(start_stack_of_f(st_p0x.clone(), (*i_p4).clone()), move |stack_of_f_8474: Text| prism_rtl::Turn::Finished(Text::from(format!("@{}", &stack_of_f_8474)))),
            _ => prism_rtl::Turn::Finished(Text::lit("")),
        })
    }
}

/// `Start StackOf, x`: what the function value is when passed to `@Run`.
pub fn start_stack_of_f(st_p0: St, t_p1: Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(StackOf { st_p0, t_p1 })
}

/// ```prism
/// HeadSigil: unbounded fn St, Ty -> Text
/// ```
pub fn head_sigil_f(st_p0: &St, t_p1: &Ty) -> Text {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        Ty::TySig(s_p2, _) => s_p2,
        Ty::TyAt(_, _) => Text::lit("@"),
        _ => Text::lit(""),
    }
}

/// The step machine of `HeadSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HeadSigil: unbounded fn St, Ty -> Text
/// ```
pub struct HeadSigil {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl prism_rtl::Job<Text> for HeadSigil {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_8652: Ty| match walk_f_8652 {
            Ty::TySig(s_p2, _) => prism_rtl::Turn::Finished(s_p2.clone()),
            Ty::TyAt(_, _) => prism_rtl::Turn::Finished(Text::lit("@")),
            _ => prism_rtl::Turn::Finished(Text::lit("")),
        })
    }
}

/// `Start HeadSigil, x`: what the function value is when passed to `@Run`.
pub fn start_head_sigil_f(st_p0: St, t_p1: Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(HeadSigil { st_p0, t_p1 })
}

/// ```prism
/// IsFlexVar: unbounded fn St, Ty -> Bool
/// ```
pub fn is_flex_var_f(st_p0: &St, t_p1: &Ty) -> bool {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        Ty::TyFlex(_) => true,
        _ => false,
    }
}

/// The step machine of `IsFlexVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsFlexVar: unbounded fn St, Ty -> Bool
/// ```
pub struct IsFlexVar {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl prism_rtl::Job<bool> for IsFlexVar {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_8801: Ty| match walk_f_8801 {
            Ty::TyFlex(_) => prism_rtl::Turn::Finished(true),
            _ => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start IsFlexVar, x`: what the function value is when passed to `@Run`.
pub fn start_is_flex_var_f(st_p0: St, t_p1: Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsFlexVar { st_p0, t_p1 })
}

/// ```prism
/// IsFreeHeaded: unbounded fn St, Ty -> Bool
/// ```
pub fn is_free_headed_f(st_p0: &St, t_p1: &Ty) -> bool {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        Ty::TyFlex(n_p2) => !crate::check::types::recording::info_of_f(st_p0, &n_p2).plain_p,
        _ => false,
    }
}

/// The step machine of `IsFreeHeaded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsFreeHeaded: unbounded fn St, Ty -> Bool
/// ```
pub struct IsFreeHeaded {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl prism_rtl::Job<bool> for IsFreeHeaded {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_9009: Ty| match walk_f_9009 {
            Ty::TyFlex(n_p2) => prism_rtl::Turn::Finished(!crate::check::types::recording::info_of_f(&st_p0x, &n_p2).plain_p),
            _ => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start IsFreeHeaded, x`: what the function value is when passed to `@Run`.
pub fn start_is_free_headed_f(st_p0: St, t_p1: Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsFreeHeaded { st_p0, t_p1 })
}

/// ```prism
/// WithMarks: fn Text, Ty, Rw -> Ty
/// ```
pub fn with_marks_f(marks_p0: &Text, t_p1: &Ty, rw_p2: &Rw) -> Ty {
    crate::prelude::fold(&reverse2_f(&crate::syntax::lexer::chars::fold_chars_f(marks_p0, &Array::new(), &(Rc::new(move |(p0, p1): (Array<Text>, Text)| crate::prelude::once_job(move || {
        let acc_p3 = p0;
        let c_p4 = p1;
        prism_rtl::Turn::Finished(crate::prelude::push(&acc_p3, &c_p4))
    })) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))), t_p1, &(|acc_p5: &Ty, m_p6: &Text| if m_p6 == &Text::lit("@") {
        Ty::TyAt(Rc::new(acc_p5.clone()), rw_p2.clone())
    } else {
        Ty::TySig(m_p6.clone(), Rc::new(acc_p5.clone()))
    }))
}

/// ```prism
/// Reverse2: fn [Text] -> [Text]
/// ```
pub fn reverse2_f(xs_p0: &Array<Text>) -> Array<Text> {
    crate::prelude::fold(xs_p0, &Array::new(), &(|acc_p1: &Array<Text>, x_p2: &Text| crate::prelude::append(&Array::from(vec![x_p2.clone()]), acc_p1)))
}

/// ```prism
/// ShowTy: unbounded fn St, Ty -> Text
/// ```
pub fn show_ty_f(st_p0: &St, t_p1: &Ty) -> Text {
    show_ty_in_f(st_p0, &crate::check::types::recording::zonk_f(st_p0, t_p1), &false)
}

/// The step machine of `ShowTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowTy: unbounded fn St, Ty -> Text
/// ```
pub struct ShowTy {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl prism_rtl::Job<Text> for ShowTy {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x.clone(), t_p1x.clone()), move |zonk_f_9735: Ty| prism_rtl::Turn::More(Rc::new(ShowTyIn { st_p0: st_p0x.clone(), t_p1: zonk_f_9735, nested_p2: false })))
    }
}

/// `Start ShowTy, x`: what the function value is when passed to `@Run`.
pub fn start_show_ty_f(st_p0: St, t_p1: Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowTy { st_p0, t_p1 })
}

/// ```prism
/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
/// ```
pub fn show_ty_in_f(st_p0: &St, t_p1: &Ty, nested_p2: &bool) -> Text {
    match t_p1 {
        Ty::TyFlex(n_p3) => Text::from(format!("t{}", n_p3)),
        Ty::TyRigid(n_p4) => n_p4.clone(),
        Ty::TyQ(n_p5) => n_p5.clone(),
        Ty::TyCon(n_p6, m9897_3_1) if (m9897_3_1.len() == 0) => bare_name_f(n_p6),
        Ty::TyCon(n_p7, args_p8) => {
            let inner_p9 = Text::from(format!("{}{}", &bare_name_f(n_p7), &crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(args_p8.clone(), {
                let st_p0x = st_p0.clone();
                Rc::new(move |p0: Ty| {
                    let st_p0xy = st_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_pa = p0;
                        crate::prelude::call_then(start_show_ty_in_f(st_p0xy.clone(), a_pa.clone(), true), move |show_ty_in_f_10067: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &show_ty_in_f_10067))))
                    }))
                }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
            })))));
            if *nested_p2 { Text::from(format!("({})", &inner_p9)) } else { inner_p9.clone() }
        },
        Ty::TyFn(c_pb, ps_pc, res_pd) => {
            let inner_pe = Text::from(format!("{}fn {} -> {}", &show_col_f(c_pb), &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_pc.clone(), {
                let st_p0x = st_p0.clone();
                Rc::new(move |p0: Ty| {
                    let st_p0xy = st_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let p_pf = p0;
                        prism_rtl::Turn::More(Rc::new(ShowTyIn { st_p0: st_p0xy.clone(), t_p1: p_pf.clone(), nested_p2: false }))
                    }))
                }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &Text::lit(", ")), &show_ty_in_f(st_p0, &**res_pd, &false)));
            if *nested_p2 { Text::from(format!("({})", &inner_pe)) } else { inner_pe.clone() }
        },
        Ty::TyTuple(ts_pg) => Text::from(format!("(({}))", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ts_pg.clone(), {
            let st_p0x = st_p0.clone();
            Rc::new(move |p0: Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_ph = p0;
                    prism_rtl::Turn::More(Rc::new(ShowTyIn { st_p0: st_p0xy.clone(), t_p1: a_ph.clone(), nested_p2: false }))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
        })), &Text::lit(", ")))),
        Ty::TyArray(e_pi) => {
            let inner_pj = show_ty_in_f(st_p0, &**e_pi, &false);
            if crate::syntax::lexer::chars::has_prefix_f(&inner_pj, &Text::lit("[")) {
                Text::from(format!("[ {} ]", &inner_pj))
            } else {
                Text::from(format!("[{}]", &inner_pj))
            }
        },
        Ty::TyMap(k_pk, v_pl) => {
            let inner_pm = Text::from(format!("{} ==> {}", &show_ty_in_f(st_p0, &**k_pk, &true), &show_ty_in_f(st_p0, &**v_pl, &true)));
            if *nested_p2 { Text::from(format!("({})", &inner_pm)) } else { inner_pm.clone() }
        },
        Ty::TySig(s_pn, i_po) => Text::from(format!("{}{}", s_pn, &show_ty_in_f(st_p0, &**i_po, &true))),
        Ty::TyAt(i_pp, rw_pq) => Text::from(format!("@{}", &show_ty_in_f(st_p0, &**i_pp, &true))),
        Ty::TyElem(rw_pr, o_ps) => {
            let inner_pt = Text::from(format!("Element {} {}", &show_row_in_f(rw_pr, &true), &show_ty_in_f(st_p0, &**o_ps, &true)));
            if *nested_p2 { Text::from(format!("({})", &inner_pt)) } else { inner_pt.clone() }
        },
        Ty::TyElemAny(rw_pu) => if *nested_p2 {
            Text::from(format!("(Elem {})", &show_row_in_f(rw_pu, &true)))
        } else {
            Text::from(format!("Elem {}", &show_row_in_f(rw_pu, &true)))
        },
        Ty::TyAssoc(n_pv, a_p10) => if *nested_p2 {
            Text::from(format!("({} {})", n_pv, &show_ty_in_f(st_p0, &**a_p10, &true)))
        } else {
            Text::from(format!("{} {}", n_pv, &show_ty_in_f(st_p0, &**a_p10, &true)))
        },
        Ty::TyAny(ts_p11) => Text::from(format!("any {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(ts_p11, &(|x_p12: &Text| Text::from(format!("^{}", &bare_name_f(x_p12))))), &Text::lit(" ")))),
        Ty::TyErr => Text::lit("?"),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ShowTyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
/// ```
pub struct ShowTyIn {
    pub st_p0: St,
    pub t_p1: Ty,
    pub nested_p2: bool,
}

impl prism_rtl::Job<Text> for ShowTyIn {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let nested_p2 = &self.nested_p2;
        match t_p1 {
            Ty::TyFlex(n_p3) => prism_rtl::Turn::Finished(Text::from(format!("t{}", n_p3))),
            Ty::TyRigid(n_p4) => prism_rtl::Turn::Finished(n_p4.clone()),
            Ty::TyQ(n_p5) => prism_rtl::Turn::Finished(n_p5.clone()),
            Ty::TyCon(n_p6, m9897_3_1) if (m9897_3_1.len() == 0) => prism_rtl::Turn::Finished(bare_name_f(n_p6)),
            Ty::TyCon(n_p7, args_p8) => {
                let args_p8x = args_p8.clone();
                let n_p7x = n_p7.clone();
                let nested_p2x = *nested_p2;
                let st_p0x = st_p0.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p8x.clone(), {
                    let st_p0xx = st_p0x.clone();
                    Rc::new(move |p0: Ty| {
                        let st_p0xxy = st_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pa = p0;
                            crate::prelude::call_then(start_show_ty_in_f(st_p0xxy.clone(), a_pa.clone(), true), move |show_ty_in_f_10067: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &show_ty_in_f_10067))))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_10048: Array<Text>| {
                    let inner_p9 = Text::from(format!("{}{}", &bare_name_f(&n_p7x), &crate::prelude::concat(&each_10048)));
                    if nested_p2x {
                        prism_rtl::Turn::Finished(Text::from(format!("({})", &inner_p9)))
                    } else {
                        prism_rtl::Turn::Finished(inner_p9.clone())
                    }
                })
            },
            Ty::TyFn(c_pb, ps_pc, res_pd) => {
                let c_pbx = c_pb.clone();
                let nested_p2x = *nested_p2;
                let ps_pcx = ps_pc.clone();
                let res_pdx = (**res_pd).clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_pcx.clone(), {
                    let st_p0xx = st_p0x.clone();
                    Rc::new(move |p0: Ty| {
                        let st_p0xxy = st_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let p_pf = p0;
                            prism_rtl::Turn::More(Rc::new(ShowTyIn { st_p0: st_p0xxy.clone(), t_p1: p_pf.clone(), nested_p2: false }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_10199: Array<Text>| crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), res_pdx.clone(), false), move |show_ty_in_f_10247: Text| {
                    let inner_pe = Text::from(format!("{}fn {} -> {}", &show_col_f(&c_pbx), &crate::syntax::lexer::chars::join_f(&each_10199, &Text::lit(", ")), &show_ty_in_f_10247));
                    if nested_p2x {
                        prism_rtl::Turn::Finished(Text::from(format!("({})", &inner_pe)))
                    } else {
                        prism_rtl::Turn::Finished(inner_pe.clone())
                    }
                }))
            },
            Ty::TyTuple(ts_pg) => {
                let st_p0x = st_p0.clone();
                let ts_pgx = ts_pg.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_pgx.clone(), {
                    let st_p0xx = st_p0x.clone();
                    Rc::new(move |p0: Ty| {
                        let st_p0xxy = st_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_ph = p0;
                            prism_rtl::Turn::More(Rc::new(ShowTyIn { st_p0: st_p0xxy.clone(), t_p1: a_ph.clone(), nested_p2: false }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_10342: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("(({}))", &crate::syntax::lexer::chars::join_f(&each_10342, &Text::lit(", "))))))
            },
            Ty::TyArray(e_pi) => {
                let e_pix = (**e_pi).clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), e_pix.clone(), false), move |show_ty_in_f_10424: Text| {
                    let inner_pj = show_ty_in_f_10424;
                    if crate::syntax::lexer::chars::has_prefix_f(&inner_pj, &Text::lit("[")) {
                        prism_rtl::Turn::Finished(Text::from(format!("[ {} ]", &inner_pj)))
                    } else {
                        prism_rtl::Turn::Finished(Text::from(format!("[{}]", &inner_pj)))
                    }
                })
            },
            Ty::TyMap(k_pk, v_pl) => {
                let k_pkx = (**k_pk).clone();
                let nested_p2x = *nested_p2;
                let st_p0x = st_p0.clone();
                let v_plx = (**v_pl).clone();
                crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), k_pkx.clone(), true), move |show_ty_in_f_10551: Text| crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), v_plx.clone(), true), move |show_ty_in_f_10578: Text| {
                    let inner_pm = Text::from(format!("{} ==> {}", &show_ty_in_f_10551, &show_ty_in_f_10578));
                    if nested_p2x {
                        prism_rtl::Turn::Finished(Text::from(format!("({})", &inner_pm)))
                    } else {
                        prism_rtl::Turn::Finished(inner_pm.clone())
                    }
                }))
            },
            Ty::TySig(s_pn, i_po) => {
                let i_pox = (**i_po).clone();
                let s_pnx = s_pn.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), i_pox.clone(), true), move |show_ty_in_f_10665: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &s_pnx, &show_ty_in_f_10665))))
            },
            Ty::TyAt(i_pp, rw_pq) => {
                let i_ppx = (**i_pp).clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), i_ppx.clone(), true), move |show_ty_in_f_10707: Text| prism_rtl::Turn::Finished(Text::from(format!("@{}", &show_ty_in_f_10707))))
            },
            Ty::TyElem(rw_pr, o_ps) => {
                let nested_p2x = *nested_p2;
                let o_psx = (**o_ps).clone();
                let rw_prx = rw_pr.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), o_psx.clone(), true), move |show_ty_in_f_10799: Text| {
                    let inner_pt = Text::from(format!("Element {} {}", &show_row_in_f(&rw_prx, &true), &show_ty_in_f_10799));
                    if nested_p2x {
                        prism_rtl::Turn::Finished(Text::from(format!("({})", &inner_pt)))
                    } else {
                        prism_rtl::Turn::Finished(inner_pt.clone())
                    }
                })
            },
            Ty::TyElemAny(rw_pu) => if *nested_p2 {
                prism_rtl::Turn::Finished(Text::from(format!("(Elem {})", &show_row_in_f(rw_pu, &true))))
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("Elem {}", &show_row_in_f(rw_pu, &true))))
            },
            Ty::TyAssoc(n_pv, a_p10) => if *nested_p2 {
                {
                    let a_p10x = (**a_p10).clone();
                    let n_pvx = n_pv.clone();
                    let st_p0x = st_p0.clone();
                    crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), a_p10x.clone(), true), move |show_ty_in_f_10994: Text| prism_rtl::Turn::Finished(Text::from(format!("({} {})", &n_pvx, &show_ty_in_f_10994))))
                }
            } else {
                {
                    let a_p10x = (**a_p10).clone();
                    let n_pvx = n_pv.clone();
                    let st_p0x = st_p0.clone();
                    crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), a_p10x.clone(), true), move |show_ty_in_f_11030: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &n_pvx, &show_ty_in_f_11030))))
                }
            },
            Ty::TyAny(ts_p11) => prism_rtl::Turn::Finished(Text::from(format!("any {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(ts_p11, &(|x_p12: &Text| Text::from(format!("^{}", &bare_name_f(x_p12))))), &Text::lit(" "))))),
            Ty::TyErr => prism_rtl::Turn::Finished(Text::lit("?")),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ShowTyIn, x`: what the function value is when passed to `@Run`.
pub fn start_show_ty_in_f(st_p0: St, t_p1: Ty, nested_p2: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowTyIn { st_p0, t_p1, nested_p2 })
}

/// ```prism
/// ShowCol: fn Col -> Text
/// ```
pub fn show_col_f(col0: &Col) -> Text {
    match col0 {
        Col::CBound => Text::lit(""),
        Col::CUnbound => Text::lit("unbounded "),
        Col::CRigid(n_p0) => Text::from(format!("{} ", n_p0)),
        Col::CQ(n_p1) => Text::from(format!("{} ", n_p1)),
        Col::CFlex(_) => Text::lit(""),
    }
}

/// ```prism
/// ShowRow: fn Rw -> Text
/// ```
pub fn show_row_f(rw_p0: &Rw) -> Text {
    show_row_in_f(rw_p0, &false)
}

/// ```prism
/// ShowRowIn: fn Rw, Bool -> Text
/// ```
pub fn show_row_in_f(rw_p0: &Rw, nested_p1: &bool) -> Text {
    let fams_p2 = crate::prelude::each(&rw_p0.fams_p, &(|f_p7: &Text| Text::from(format!("{}.*", f_p7))));
    let tail_p3 = match &rw_p0.tail_p {
        Tail::TlClosed => Array::new(),
        Tail::TlFlex(n_p8) => Array::from(vec![Text::from(format!("r{}", n_p8))]),
        Tail::TlRigid(n_p9) => Array::from(vec![n_p9.clone()]),
        Tail::TlQ(n_pa) => Array::from(vec![n_pa.clone()]),
    };
    let parts_p4 = crate::prelude::append(&tail_p3, &fams_p2);
    let minus_p5 = if &crate::prelude::len(&rw_p0.minus_p) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" − {{{}}}", &crate::syntax::lexer::chars::join_f(&rw_p0.minus_p, &Text::lit(", "))))
    };
    let inner_p6 = if &crate::prelude::len(&parts_p4) == &Nat::from(0u32) {
        Text::lit("unit")
    } else {
        crate::syntax::lexer::chars::join_f(&parts_p4, &Text::lit(" | "))
    };
    if *nested_p1 && ((&crate::prelude::len(&parts_p4) > &Nat::from(1u32)) || (&minus_p5 != &Text::lit(""))) {
        Text::from(format!("({}{})", &inner_p6, &minus_p5))
    } else {
        Text::from(format!("{}{}", &inner_p6, &minus_p5))
    }
}
