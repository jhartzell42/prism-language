//! The module `Check.Types`, from `target/bootstrap/src/prismc/check/types/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `CLeq`:
///
/// ```prism
/// type CLeq = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CLeq {
    pub lo: Col,
    pub hi: Col,
    pub file: Nat,
    pub span: crate::syntax::Range,
    pub kind: Text,
    pub name: Text,
    pub why: Text,
}

impl Show for CLeq {
    fn show(&self, p: &mut Printer) {
        p.record("CLeq", &[("lo", &self.lo), ("hi", &self.hi), ("file", &self.file), ("span", &self.span), ("kind", &self.kind), ("name", &self.name), ("why", &self.why)]);
    }
}

impl ToPod for CLeq {
    fn to_pod(&self) -> Pod {
        Pod::record("CLeq", vec![("lo", self.lo.to_pod()), ("hi", self.hi.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod()), ("kind", self.kind.to_pod()), ("name", self.name.to_pod()), ("why", self.why.to_pod())])
    }
}

impl FromPod for CLeq {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CLeq { lo: FromPod::from_pod(field(p, "lo")?)?, hi: FromPod::from_pod(field(p, "hi")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)?, kind: FromPod::from_pod(field(p, "kind")?)?, name: FromPod::from_pod(field(p, "name")?)?, why: FromPod::from_pod(field(p, "why")?)? })
    }
}

/// `Col`:
///
/// ```prism
/// type Col = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Col {
    CBound,
    CUnbound,
    CRigid(Text),
    CQ(Text),
    CFlex(Nat),
}

impl Show for Col {
    fn show(&self, p: &mut Printer) {
        match self {
            Col::CBound => p.choice("CBound", &[]),
            Col::CUnbound => p.choice("CUnbound", &[]),
            Col::CRigid(a0) => p.choice("CRigid", &[a0]),
            Col::CQ(a0) => p.choice("CQ", &[a0]),
            Col::CFlex(a0) => p.choice("CFlex", &[a0]),
        }
    }
}

impl ToPod for Col {
    fn to_pod(&self) -> Pod {
        match self {
            Col::CBound => Pod::Choice("CBound".into(), vec![]),
            Col::CUnbound => Pod::Choice("CUnbound".into(), vec![]),
            Col::CRigid(a0) => Pod::Choice("CRigid".into(), vec![a0.to_pod()]),
            Col::CQ(a0) => Pod::Choice("CQ".into(), vec![a0.to_pod()]),
            Col::CFlex(a0) => Pod::Choice("CFlex".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Col {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "CBound" && a.len() == 0 => Ok(Col::CBound),
            Pod::Choice(c, a) if &**c == "CUnbound" && a.len() == 0 => Ok(Col::CUnbound),
            Pod::Choice(c, a) if &**c == "CRigid" && a.len() == 1 => Ok(Col::CRigid(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CQ" && a.len() == 1 => Ok(Col::CQ(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CFlex" && a.len() == 1 => Ok(Col::CFlex(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Col", other),
        }
    }
}

/// `FieldQ`:
///
/// ```prism
/// type FieldQ = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FieldQ {
    pub recv: Ty,
    pub field: Text,
    pub result: Ty,
    pub span: crate::syntax::Range,
    pub file: Nat,
    pub owners: Array<Text>,
}

impl Show for FieldQ {
    fn show(&self, p: &mut Printer) {
        p.record("FieldQ", &[("recv", &self.recv), ("field", &self.field), ("result", &self.result), ("span", &self.span), ("file", &self.file), ("owners", &self.owners)]);
    }
}

impl ToPod for FieldQ {
    fn to_pod(&self) -> Pod {
        Pod::record("FieldQ", vec![("recv", self.recv.to_pod()), ("field", self.field.to_pod()), ("result", self.result.to_pod()), ("span", self.span.to_pod()), ("file", self.file.to_pod()), ("owners", self.owners.to_pod())])
    }
}

impl FromPod for FieldQ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FieldQ { recv: FromPod::from_pod(field(p, "recv")?)?, field: FromPod::from_pod(field(p, "field")?)?, result: FromPod::from_pod(field(p, "result")?)?, span: FromPod::from_pod(field(p, "span")?)?, file: FromPod::from_pod(field(p, "file")?)?, owners: FromPod::from_pod(field(p, "owners")?)? })
    }
}

/// `Incl`:
///
/// ```prism
/// type Incl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Incl {
    pub sub: Rw,
    pub sup: Rw,
    pub file: Nat,
    pub span: crate::syntax::Range,
    pub what: Text,
    pub forward: bool,
}

impl Show for Incl {
    fn show(&self, p: &mut Printer) {
        p.record("Incl", &[("sub", &self.sub), ("sup", &self.sup), ("file", &self.file), ("span", &self.span), ("what", &self.what), ("forward", &self.forward)]);
    }
}

impl ToPod for Incl {
    fn to_pod(&self) -> Pod {
        Pod::record("Incl", vec![("sub", self.sub.to_pod()), ("sup", self.sup.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod()), ("what", self.what.to_pod()), ("forward", self.forward.to_pod())])
    }
}

impl FromPod for Incl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Incl { sub: FromPod::from_pod(field(p, "sub")?)?, sup: FromPod::from_pod(field(p, "sup")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)?, what: FromPod::from_pod(field(p, "what")?)?, forward: FromPod::from_pod(field(p, "forward")?)? })
    }
}

/// `Inst`:
///
/// ```prism
/// type Inst = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Inst {
    pub tys: Map<Text, Ty>,
    pub rows: Map<Text, Tail>,
    pub cols: Map<Text, Col>,
}

impl Show for Inst {
    fn show(&self, p: &mut Printer) {
        p.record("Inst", &[("tys", &self.tys), ("rows", &self.rows), ("cols", &self.cols)]);
    }
}

impl ToPod for Inst {
    fn to_pod(&self) -> Pod {
        Pod::record("Inst", vec![("tys", self.tys.to_pod()), ("rows", self.rows.to_pod()), ("cols", self.cols.to_pod())])
    }
}

impl FromPod for Inst {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Inst { tys: FromPod::from_pod(field(p, "tys")?)?, rows: FromPod::from_pod(field(p, "rows")?)?, cols: FromPod::from_pod(field(p, "cols")?)? })
    }
}

/// `Rw`:
///
/// ```prism
/// type Rw = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Rw {
    pub fams: Array<Text>,
    pub minus: Array<Text>,
    pub tail: Tail,
}

impl Show for Rw {
    fn show(&self, p: &mut Printer) {
        p.record("Rw", &[("fams", &self.fams), ("minus", &self.minus), ("tail", &self.tail)]);
    }
}

impl ToPod for Rw {
    fn to_pod(&self) -> Pod {
        Pod::record("Rw", vec![("fams", self.fams.to_pod()), ("minus", self.minus.to_pod()), ("tail", self.tail.to_pod())])
    }
}

impl FromPod for Rw {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Rw { fams: FromPod::from_pod(field(p, "fams")?)?, minus: FromPod::from_pod(field(p, "minus")?)?, tail: FromPod::from_pod(field(p, "tail")?)? })
    }
}

/// `Scheme`:
///
/// ```prism
/// type Scheme = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Scheme {
    pub qs: Array<Text>,
    pub plain_qs: Array<Text>,
    pub rqs: Array<Text>,
    pub cqs: Array<Text>,
    pub cjoins: Array<(Text, Text)>,
    pub bounds: Array<(Text, Text)>,
    pub ty: Ty,
}

impl Show for Scheme {
    fn show(&self, p: &mut Printer) {
        p.record("Scheme", &[("qs", &self.qs), ("plain_qs", &self.plain_qs), ("rqs", &self.rqs), ("cqs", &self.cqs), ("cjoins", &self.cjoins), ("bounds", &self.bounds), ("ty", &self.ty)]);
    }
}

impl ToPod for Scheme {
    fn to_pod(&self) -> Pod {
        Pod::record("Scheme", vec![("qs", self.qs.to_pod()), ("plain_qs", self.plain_qs.to_pod()), ("rqs", self.rqs.to_pod()), ("cqs", self.cqs.to_pod()), ("cjoins", self.cjoins.to_pod()), ("bounds", self.bounds.to_pod()), ("ty", self.ty.to_pod())])
    }
}

impl FromPod for Scheme {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Scheme { qs: FromPod::from_pod(field(p, "qs")?)?, plain_qs: FromPod::from_pod(field(p, "plain_qs")?)?, rqs: FromPod::from_pod(field(p, "rqs")?)?, cqs: FromPod::from_pod(field(p, "cqs")?)?, cjoins: FromPod::from_pod(field(p, "cjoins")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, ty: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// `St`:
///
/// ```prism
/// type St = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct St {
    pub next: Nat,
    pub tys: Map<Nat, Ty>,
    pub infos: Map<Nat, VInfo>,
    pub rows: Map<Nat, Rw>,
    pub lacks: Map<Nat, Array<Text>>,
    pub wants: Array<Want>,
    pub incls: Array<Incl>,
    pub diags: Array<crate::check::errors::CDiag>,
    pub level: Nat,
    pub file: Nat,
    pub color: Col,
    pub color_why: Text,
    pub color_flex: Array<(Col, Text, crate::syntax::Range)>,
    pub cols: Map<Nat, Col>,
    pub cleqs: Array<CLeq>,
    pub col_q: Map<Nat, Text>,
    pub col_up: Map<Text, Text>,
    pub deferred: Array<(Ty, Ty, crate::syntax::Range)>,
    pub binder_at: Map<Nat, crate::syntax::Range>,
    pub row_names: Map<Nat, Text>,
    pub layer_qs: Array<(Ty, crate::syntax::Range, Text)>,
    pub field_qs: Array<FieldQ>,
    pub recording: bool,
    pub typed: crate::check::typed::TProgram,
    pub choices: Map<Text, Array<Text>>,
    pub size_tys: Map<Text, Ty>,
}

impl Show for St {
    fn show(&self, p: &mut Printer) {
        p.record("St", &[("next", &self.next), ("tys", &self.tys), ("infos", &self.infos), ("rows", &self.rows), ("lacks", &self.lacks), ("wants", &self.wants), ("incls", &self.incls), ("diags", &self.diags), ("level", &self.level), ("file", &self.file), ("color", &self.color), ("color_why", &self.color_why), ("color_flex", &self.color_flex), ("cols", &self.cols), ("cleqs", &self.cleqs), ("col_q", &self.col_q), ("col_up", &self.col_up), ("deferred", &self.deferred), ("binder_at", &self.binder_at), ("row_names", &self.row_names), ("layer_qs", &self.layer_qs), ("field_qs", &self.field_qs), ("recording", &self.recording), ("typed", &self.typed), ("choices", &self.choices), ("size_tys", &self.size_tys)]);
    }
}

impl ToPod for St {
    fn to_pod(&self) -> Pod {
        Pod::record("St", vec![("next", self.next.to_pod()), ("tys", self.tys.to_pod()), ("infos", self.infos.to_pod()), ("rows", self.rows.to_pod()), ("lacks", self.lacks.to_pod()), ("wants", self.wants.to_pod()), ("incls", self.incls.to_pod()), ("diags", self.diags.to_pod()), ("level", self.level.to_pod()), ("file", self.file.to_pod()), ("color", self.color.to_pod()), ("color_why", self.color_why.to_pod()), ("color_flex", self.color_flex.to_pod()), ("cols", self.cols.to_pod()), ("cleqs", self.cleqs.to_pod()), ("col_q", self.col_q.to_pod()), ("col_up", self.col_up.to_pod()), ("deferred", self.deferred.to_pod()), ("binder_at", self.binder_at.to_pod()), ("row_names", self.row_names.to_pod()), ("layer_qs", self.layer_qs.to_pod()), ("field_qs", self.field_qs.to_pod()), ("recording", self.recording.to_pod()), ("typed", self.typed.to_pod()), ("choices", self.choices.to_pod()), ("size_tys", self.size_tys.to_pod())])
    }
}

impl FromPod for St {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(St { next: FromPod::from_pod(field(p, "next")?)?, tys: FromPod::from_pod(field(p, "tys")?)?, infos: FromPod::from_pod(field(p, "infos")?)?, rows: FromPod::from_pod(field(p, "rows")?)?, lacks: FromPod::from_pod(field(p, "lacks")?)?, wants: FromPod::from_pod(field(p, "wants")?)?, incls: FromPod::from_pod(field(p, "incls")?)?, diags: FromPod::from_pod(field(p, "diags")?)?, level: FromPod::from_pod(field(p, "level")?)?, file: FromPod::from_pod(field(p, "file")?)?, color: FromPod::from_pod(field(p, "color")?)?, color_why: FromPod::from_pod(field(p, "color_why")?)?, color_flex: FromPod::from_pod(field(p, "color_flex")?)?, cols: FromPod::from_pod(field(p, "cols")?)?, cleqs: FromPod::from_pod(field(p, "cleqs")?)?, col_q: FromPod::from_pod(field(p, "col_q")?)?, col_up: FromPod::from_pod(field(p, "col_up")?)?, deferred: FromPod::from_pod(field(p, "deferred")?)?, binder_at: FromPod::from_pod(field(p, "binder_at")?)?, row_names: FromPod::from_pod(field(p, "row_names")?)?, layer_qs: FromPod::from_pod(field(p, "layer_qs")?)?, field_qs: FromPod::from_pod(field(p, "field_qs")?)?, recording: FromPod::from_pod(field(p, "recording")?)?, typed: FromPod::from_pod(field(p, "typed")?)?, choices: FromPod::from_pod(field(p, "choices")?)?, size_tys: FromPod::from_pod(field(p, "size_tys")?)? })
    }
}

/// `Tail`:
///
/// ```prism
/// type Tail = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Tail {
    TlClosed,
    TlFlex(Nat),
    TlRigid(Text),
    TlQ(Text),
}

impl Show for Tail {
    fn show(&self, p: &mut Printer) {
        match self {
            Tail::TlClosed => p.choice("TlClosed", &[]),
            Tail::TlFlex(a0) => p.choice("TlFlex", &[a0]),
            Tail::TlRigid(a0) => p.choice("TlRigid", &[a0]),
            Tail::TlQ(a0) => p.choice("TlQ", &[a0]),
        }
    }
}

impl ToPod for Tail {
    fn to_pod(&self) -> Pod {
        match self {
            Tail::TlClosed => Pod::Choice("TlClosed".into(), vec![]),
            Tail::TlFlex(a0) => Pod::Choice("TlFlex".into(), vec![a0.to_pod()]),
            Tail::TlRigid(a0) => Pod::Choice("TlRigid".into(), vec![a0.to_pod()]),
            Tail::TlQ(a0) => Pod::Choice("TlQ".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Tail {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TlClosed" && a.len() == 0 => Ok(Tail::TlClosed),
            Pod::Choice(c, a) if &**c == "TlFlex" && a.len() == 1 => Ok(Tail::TlFlex(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TlRigid" && a.len() == 1 => Ok(Tail::TlRigid(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TlQ" && a.len() == 1 => Ok(Tail::TlQ(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Tail", other),
        }
    }
}

/// `Ty`:
///
/// ```prism
/// type Ty = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Ty {
    TyFlex(Nat),
    TyRigid(Text),
    TyQ(Text),
    TyCon(Text, Array<Ty>),
    TyFn(Col, Array<Ty>, Rc<Ty>),
    TyTuple(Array<Ty>),
    TyArray(Rc<Ty>),
    TyMap(Rc<Ty>, Rc<Ty>),
    TySig(Text, Rc<Ty>),
    TyAt(Rc<Ty>, Rw),
    TyElem(Rw, Rc<Ty>),
    TyElemAny(Rw),
    TyAssoc(Text, Rc<Ty>),
    TyAny(Array<Text>),
    TyErr,
}

impl Show for Ty {
    fn show(&self, p: &mut Printer) {
        match self {
            Ty::TyFlex(a0) => p.choice("TyFlex", &[a0]),
            Ty::TyRigid(a0) => p.choice("TyRigid", &[a0]),
            Ty::TyQ(a0) => p.choice("TyQ", &[a0]),
            Ty::TyCon(a0, a1) => p.choice("TyCon", &[a0, a1]),
            Ty::TyFn(a0, a1, a2) => p.choice("TyFn", &[a0, a1, a2]),
            Ty::TyTuple(a0) => p.choice("TyTuple", &[a0]),
            Ty::TyArray(a0) => p.choice("TyArray", &[a0]),
            Ty::TyMap(a0, a1) => p.choice("TyMap", &[a0, a1]),
            Ty::TySig(a0, a1) => p.choice("TySig", &[a0, a1]),
            Ty::TyAt(a0, a1) => p.choice("TyAt", &[a0, a1]),
            Ty::TyElem(a0, a1) => p.choice("TyElem", &[a0, a1]),
            Ty::TyElemAny(a0) => p.choice("TyElemAny", &[a0]),
            Ty::TyAssoc(a0, a1) => p.choice("TyAssoc", &[a0, a1]),
            Ty::TyAny(a0) => p.choice("TyAny", &[a0]),
            Ty::TyErr => p.choice("TyErr", &[]),
        }
    }
}

impl ToPod for Ty {
    fn to_pod(&self) -> Pod {
        match self {
            Ty::TyFlex(a0) => Pod::Choice("TyFlex".into(), vec![a0.to_pod()]),
            Ty::TyRigid(a0) => Pod::Choice("TyRigid".into(), vec![a0.to_pod()]),
            Ty::TyQ(a0) => Pod::Choice("TyQ".into(), vec![a0.to_pod()]),
            Ty::TyCon(a0, a1) => Pod::Choice("TyCon".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyFn(a0, a1, a2) => Pod::Choice("TyFn".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ty::TyTuple(a0) => Pod::Choice("TyTuple".into(), vec![a0.to_pod()]),
            Ty::TyArray(a0) => Pod::Choice("TyArray".into(), vec![a0.to_pod()]),
            Ty::TyMap(a0, a1) => Pod::Choice("TyMap".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TySig(a0, a1) => Pod::Choice("TySig".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyAt(a0, a1) => Pod::Choice("TyAt".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyElem(a0, a1) => Pod::Choice("TyElem".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyElemAny(a0) => Pod::Choice("TyElemAny".into(), vec![a0.to_pod()]),
            Ty::TyAssoc(a0, a1) => Pod::Choice("TyAssoc".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyAny(a0) => Pod::Choice("TyAny".into(), vec![a0.to_pod()]),
            Ty::TyErr => Pod::Choice("TyErr".into(), vec![]),
        }
    }
}

impl FromPod for Ty {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TyFlex" && a.len() == 1 => Ok(Ty::TyFlex(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyRigid" && a.len() == 1 => Ok(Ty::TyRigid(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyQ" && a.len() == 1 => Ok(Ty::TyQ(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyCon" && a.len() == 2 => Ok(Ty::TyCon(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyFn" && a.len() == 3 => Ok(Ty::TyFn(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "TyTuple" && a.len() == 1 => Ok(Ty::TyTuple(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyArray" && a.len() == 1 => Ok(Ty::TyArray(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyMap" && a.len() == 2 => Ok(Ty::TyMap(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TySig" && a.len() == 2 => Ok(Ty::TySig(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyAt" && a.len() == 2 => Ok(Ty::TyAt(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyElem" && a.len() == 2 => Ok(Ty::TyElem(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyElemAny" && a.len() == 1 => Ok(Ty::TyElemAny(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyAssoc" && a.len() == 2 => Ok(Ty::TyAssoc(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyAny" && a.len() == 1 => Ok(Ty::TyAny(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyErr" && a.len() == 0 => Ok(Ty::TyErr),
            other => mismatch("a Ty", other),
        }
    }
}

/// `VInfo`:
///
/// ```prism
/// type VInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct VInfo {
    pub plain: bool,
    pub level: Nat,
    pub name: Text,
}

impl Show for VInfo {
    fn show(&self, p: &mut Printer) {
        p.record("VInfo", &[("plain", &self.plain), ("level", &self.level), ("name", &self.name)]);
    }
}

impl ToPod for VInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("VInfo", vec![("plain", self.plain.to_pod()), ("level", self.level.to_pod()), ("name", self.name.to_pod())])
    }
}

impl FromPod for VInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(VInfo { plain: FromPod::from_pod(field(p, "plain")?)?, level: FromPod::from_pod(field(p, "level")?)?, name: FromPod::from_pod(field(p, "name")?)? })
    }
}

/// `Want`:
///
/// ```prism
/// type Want = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Want {
    pub cls: Text,
    pub ty: Ty,
    pub file: Nat,
    pub span: crate::syntax::Range,
    pub level: Nat,
}

impl Show for Want {
    fn show(&self, p: &mut Printer) {
        p.record("Want", &[("cls", &self.cls), ("ty", &self.ty), ("file", &self.file), ("span", &self.span), ("level", &self.level)]);
    }
}

impl ToPod for Want {
    fn to_pod(&self) -> Pod {
        Pod::record("Want", vec![("cls", self.cls.to_pod()), ("ty", self.ty.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod()), ("level", self.level.to_pod())])
    }
}

impl FromPod for Want {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Want { cls: FromPod::from_pod(field(p, "cls")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)?, level: FromPod::from_pod(field(p, "level")?)? })
    }
}

/// ```prism
/// NewSt: fn Nat -> St
/// ```
pub fn new_st(file: &Nat) -> St {
    St { next: Nat::from(0u32), tys: Map::new(), infos: Map::new(), rows: Map::new(), lacks: Map::new(), wants: Array::new(), incls: Array::new(), diags: Array::new(), level: Nat::from(0u32), file: file.clone(), color: Col::CBound, color_why: Text::lit(""), color_flex: Array::new(), cols: Map::new(), cleqs: Array::new(), col_q: Map::new(), col_up: Map::new(), deferred: Array::new(), binder_at: Map::new(), row_names: Map::new(), layer_qs: Array::new(), field_qs: Array::new(), recording: false, typed: crate::check::typed::empty_typed(), choices: Map::new(), size_tys: Map::new() }
}

/// ```prism
/// Closed: fn [Text] -> Rw
/// ```
pub fn closed(fs: &Array<Text>) -> Rw {
    Rw { fams: sort_texts(fs), minus: Array::new(), tail: Tail::TlClosed }
}

/// ```prism
/// let emptyRow
/// ```
pub fn empty_row() -> Rw {
    Rw { fams: Array::new(), minus: Array::new(), tail: Tail::TlClosed }
}

/// ```prism
/// let tInt
/// ```
pub fn t_int() -> Ty {
    Ty::TyCon(Text::lit("Int"), Array::new())
}

/// ```prism
/// let tNat
/// ```
pub fn t_nat() -> Ty {
    Ty::TyCon(Text::lit("Nat"), Array::new())
}

/// ```prism
/// let tText
/// ```
pub fn t_text() -> Ty {
    Ty::TyCon(Text::lit("Text"), Array::new())
}

/// ```prism
/// let tBool
/// ```
pub fn t_bool() -> Ty {
    Ty::TyCon(Text::lit("Bool"), Array::new())
}

/// ```prism
/// let tUnit
/// ```
pub fn t_unit() -> Ty {
    Ty::TyCon(Text::lit("unit"), Array::new())
}

/// ```prism
/// let tChar
/// ```
pub fn t_char() -> Ty {
    Ty::TyCon(Text::lit("Char"), Array::new())
}

/// ```prism
/// let tFloat
/// ```
pub fn t_float() -> Ty {
    Ty::TyCon(Text::lit("Float"), Array::new())
}

/// ```prism
/// HasText: fn [Text], Text -> Bool
/// ```
pub fn has_text(xs: &Array<Text>, x: &Text) -> bool {
    fold(xs, &false, &(|seen: &bool, y: &Text| *seen || (y == x)))
}

/// ```prism
/// HasNat: fn [Nat], Nat -> Bool
/// ```
pub fn has_nat(xs: &Array<Nat>, x: &Nat) -> bool {
    fold(xs, &false, &(|seen: &bool, y: &Nat| *seen || (y == x)))
}

/// ```prism
/// AddText: fn [Text], Text -> [Text]
/// ```
pub fn add_text(xs: &Array<Text>, x: &Text) -> Array<Text> {
    if has_text(xs, x) { xs.clone() } else { push(xs, x) }
}

/// ```prism
/// UnionTexts: fn [Text], [Text] -> [Text]
/// ```
pub fn union_texts(xs: &Array<Text>, ys: &Array<Text>) -> Array<Text> {
    fold(ys, xs, &(|acc: &Array<Text>, y: &Text| add_text(acc, y)))
}

/// ```prism
/// MinusTexts: fn [Text], [Text] -> [Text]
/// ```
pub fn minus_texts(xs: &Array<Text>, ys: &Array<Text>) -> Array<Text> {
    filter(xs, &(|x: &Text| !has_text(ys, x)))
}

/// ```prism
/// InterTexts: fn [Text], [Text] -> [Text]
/// ```
pub fn inter_texts(xs: &Array<Text>, ys: &Array<Text>) -> Array<Text> {
    filter(xs, &(|x: &Text| has_text(ys, x)))
}

/// ```prism
/// AddNat: fn [Nat], Nat -> [Nat]
/// ```
pub fn add_nat(xs: &Array<Nat>, x: &Nat) -> Array<Nat> {
    if has_nat(xs, x) { xs.clone() } else { push(xs, x) }
}

/// ```prism
/// SortTexts: fn [Text] -> [Text]
/// ```
pub fn sort_texts(xs: &Array<Text>) -> Array<Text> {
    fold(xs, &Array::new(), &(|acc: &Array<Text>, x: &Text| if has_text(acc, x) {
        acc.clone()
    } else {
        append(&push(&filter(acc, &(|y: &Text| y < x)), x), &filter(acc, &(|y: &Text| !(y < x))))
    }))
}

/// ```prism
/// BareName: fn Text -> Text
/// ```
pub fn bare_name(q: &Text) -> Text {
    or(&crate::syntax::lexer::last(&split(q, &Text::lit("."))), q)
}

/// ```prism
/// FreshVar: fn St, Bool, Text -> ((Ty, St))
/// ```
pub fn fresh_var(st: &St, plain: &bool, name: &Text) -> (Ty, St) {
    let n = st.next.clone();
    let st2 = {
        let mut this: St = st.clone();
        this.next = &this.next + &Nat::from(1u32);
        this.infos = insert(&this.infos, &n, &VInfo { plain: *plain, level: this.level.clone(), name: name.clone() });
        this
    };
    (Ty::TyFlex(n.clone()), st2.clone())
}

/// ```prism
/// FreshCol: fn St -> ((Col, St))
/// ```
pub fn fresh_col(st: &St) -> (Col, St) {
    let n = st.next.clone();
    let st2 = {
        let mut this: St = st.clone();
        this.next = &this.next + &Nat::from(1u32);
        this.infos = insert(&this.infos, &n, &VInfo { plain: false, level: this.level.clone(), name: Text::lit("") });
        this
    };
    (Col::CFlex(n.clone()), st2.clone())
}

/// ```prism
/// StackOf: unbounded fn St, Ty -> Text
/// ```
pub fn stack_of(st: &St, t: &Ty) -> Text {
    match walk(st, t) {
        Ty::TySig(s, i) => Text::from(format!("{}{}", &s, &stack_of(st, &*i))),
        Ty::TyAt(i, _) => Text::from(format!("@{}", &stack_of(st, &*i))),
        _ => Text::lit(""),
    }
}

/// The step machine of `StackOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StackOf: unbounded fn St, Ty -> Text
/// ```
pub struct StackOf {
    pub st: St,
    pub t: Ty,
}

impl prism_rtl::Job<Text> for StackOf {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(start_walk(st.clone(), t.clone()), move |walk_7616: Ty| match walk_7616 {
            Ty::TySig(s, i) => call_then(start_stack_of(st.clone(), (*i).clone()), move |stack_of_7649: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &s, &stack_of_7649)))),
            Ty::TyAt(i, _) => call_then(start_stack_of(st.clone(), (*i).clone()), move |stack_of_7688: Text| prism_rtl::Turn::Finished(Text::from(format!("@{}", &stack_of_7688)))),
            _ => prism_rtl::Turn::Finished(Text::lit("")),
        })
    }
}

/// `Start StackOf, x`: what the function value is when passed to `@Run`.
pub fn start_stack_of(st: St, t: Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(StackOf { st, t })
}

/// ```prism
/// HeadSigil: unbounded fn St, Ty -> Text
/// ```
pub fn head_sigil(st: &St, t: &Ty) -> Text {
    match walk(st, t) {
        Ty::TySig(s, _) => s.clone(),
        Ty::TyAt(_, _) => Text::lit("@"),
        _ => Text::lit(""),
    }
}

/// The step machine of `HeadSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HeadSigil: unbounded fn St, Ty -> Text
/// ```
pub struct HeadSigil {
    pub st: St,
    pub t: Ty,
}

impl prism_rtl::Job<Text> for HeadSigil {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(start_walk(st.clone(), t.clone()), move |walk_7866: Ty| match walk_7866 {
            Ty::TySig(s, _) => prism_rtl::Turn::Finished(s.clone()),
            Ty::TyAt(_, _) => prism_rtl::Turn::Finished(Text::lit("@")),
            _ => prism_rtl::Turn::Finished(Text::lit("")),
        })
    }
}

/// `Start HeadSigil, x`: what the function value is when passed to `@Run`.
pub fn start_head_sigil(st: St, t: Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(HeadSigil { st, t })
}

/// ```prism
/// IsFlexVar: unbounded fn St, Ty -> Bool
/// ```
pub fn is_flex_var(st: &St, t: &Ty) -> bool {
    match walk(st, t) {
        Ty::TyFlex(_) => true,
        _ => false,
    }
}

/// The step machine of `IsFlexVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsFlexVar: unbounded fn St, Ty -> Bool
/// ```
pub struct IsFlexVar {
    pub st: St,
    pub t: Ty,
}

impl prism_rtl::Job<bool> for IsFlexVar {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(start_walk(st.clone(), t.clone()), move |walk_8015: Ty| match walk_8015 {
            Ty::TyFlex(_) => prism_rtl::Turn::Finished(true),
            _ => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start IsFlexVar, x`: what the function value is when passed to `@Run`.
pub fn start_is_flex_var(st: St, t: Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsFlexVar { st, t })
}

/// ```prism
/// IsFreeHeaded: unbounded fn St, Ty -> Bool
/// ```
pub fn is_free_headed(st: &St, t: &Ty) -> bool {
    match walk(st, t) {
        Ty::TyFlex(n) => !info_of(st, &n).plain,
        _ => false,
    }
}

/// The step machine of `IsFreeHeaded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsFreeHeaded: unbounded fn St, Ty -> Bool
/// ```
pub struct IsFreeHeaded {
    pub st: St,
    pub t: Ty,
}

impl prism_rtl::Job<bool> for IsFreeHeaded {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(start_walk(st.clone(), t.clone()), move |walk_8223: Ty| match walk_8223 {
            Ty::TyFlex(n) => prism_rtl::Turn::Finished(!info_of(&st, &n).plain),
            _ => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start IsFreeHeaded, x`: what the function value is when passed to `@Run`.
pub fn start_is_free_headed(st: St, t: Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsFreeHeaded { st, t })
}

/// ```prism
/// WithMarks: fn Text, Ty, Rw -> Ty
/// ```
pub fn with_marks(marks: &Text, t: &Ty, rw: &Rw) -> Ty {
    fold(&reverse2(&crate::syntax::lexer::fold_chars(marks, &Array::new(), &(Rc::new(move |(p0, p1): (Array<Text>, Text)| once_job(move || {
        let acc = p0;
        let c = p1;
        prism_rtl::Turn::Finished(push(&acc, &c))
    })) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))), t, &(|acc: &Ty, m: &Text| if m == &Text::lit("@") {
        Ty::TyAt(Rc::new(acc.clone()), rw.clone())
    } else {
        Ty::TySig(m.clone(), Rc::new(acc.clone()))
    }))
}

/// ```prism
/// Reverse2: fn [Text] -> [Text]
/// ```
pub fn reverse2(xs: &Array<Text>) -> Array<Text> {
    fold(xs, &Array::new(), &(|acc: &Array<Text>, x: &Text| append(&Array::from(vec![x.clone()]), acc)))
}

/// ```prism
/// ShowTy: unbounded fn St, Ty -> Text
/// ```
pub fn show_ty(st: &St, t: &Ty) -> Text {
    show_ty_in(st, &zonk(st, t), &false)
}

/// The step machine of `ShowTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowTy: unbounded fn St, Ty -> Text
/// ```
pub struct ShowTy {
    pub st: St,
    pub t: Ty,
}

impl prism_rtl::Job<Text> for ShowTy {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(start_zonk(st.clone(), t.clone()), move |zonk_8949: Ty| prism_rtl::Turn::More(Rc::new(ShowTyIn { st: st.clone(), t: zonk_8949, nested: false })))
    }
}

/// `Start ShowTy, x`: what the function value is when passed to `@Run`.
pub fn start_show_ty(st: St, t: Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowTy { st, t })
}

/// ```prism
/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
/// ```
pub fn show_ty_in(st: &St, t: &Ty, nested: &bool) -> Text {
    match t {
        Ty::TyFlex(n) => Text::from(format!("t{}", n)),
        Ty::TyRigid(n) => n.clone(),
        Ty::TyQ(n) => n.clone(),
        Ty::TyCon(n, m9111_3_1) if (m9111_3_1.len() == 0) => bare_name(n),
        Ty::TyCon(n, args) => {
            let inner = Text::from(format!("{}{}", &bare_name(n), &concat(&run_to_end(each_job(args.clone(), {
                let st = st.clone();
                Rc::new(move |p0: Ty| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        call_then(start_show_ty_in(st.clone(), a.clone(), true), move |show_ty_in_9281: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &show_ty_in_9281))))
                    }))
                }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
            })))));
            if *nested { Text::from(format!("({})", &inner)) } else { inner.clone() }
        },
        Ty::TyFn(c, ps, res) => {
            let inner = Text::from(format!("{}fn {} -> {}", &show_col(c), &crate::syntax::lexer::join(&run_to_end(each_job(ps.clone(), {
                let st = st.clone();
                Rc::new(move |p0: Ty| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let p_ = p0;
                        prism_rtl::Turn::More(Rc::new(ShowTyIn { st: st.clone(), t: p_.clone(), nested: false }))
                    }))
                }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &Text::lit(", ")), &show_ty_in(st, &**res, &false)));
            if *nested { Text::from(format!("({})", &inner)) } else { inner.clone() }
        },
        Ty::TyTuple(ts) => Text::from(format!("(({}))", &crate::syntax::lexer::join(&run_to_end(each_job(ts.clone(), {
            let st = st.clone();
            Rc::new(move |p0: Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(ShowTyIn { st: st.clone(), t: a.clone(), nested: false }))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
        })), &Text::lit(", ")))),
        Ty::TyArray(e) => {
            let inner = show_ty_in(st, &**e, &false);
            if crate::syntax::lexer::has_prefix(&inner, &Text::lit("[")) {
                Text::from(format!("[ {} ]", &inner))
            } else {
                Text::from(format!("[{}]", &inner))
            }
        },
        Ty::TyMap(k, v_) => {
            let inner = Text::from(format!("{} ==> {}", &show_ty_in(st, &**k, &true), &show_ty_in(st, &**v_, &true)));
            if *nested { Text::from(format!("({})", &inner)) } else { inner.clone() }
        },
        Ty::TySig(s, i) => Text::from(format!("{}{}", s, &show_ty_in(st, &**i, &true))),
        Ty::TyAt(i, rw) => Text::from(format!("@{}", &show_ty_in(st, &**i, &true))),
        Ty::TyElem(rw, o) => {
            let inner = Text::from(format!("Element {} {}", &show_row_in(rw, &true), &show_ty_in(st, &**o, &true)));
            if *nested { Text::from(format!("({})", &inner)) } else { inner.clone() }
        },
        Ty::TyElemAny(rw) => if *nested {
            Text::from(format!("(Elem {})", &show_row_in(rw, &true)))
        } else {
            Text::from(format!("Elem {}", &show_row_in(rw, &true)))
        },
        Ty::TyAssoc(n, a) => if *nested {
            Text::from(format!("({} {})", n, &show_ty_in(st, &**a, &true)))
        } else {
            Text::from(format!("{} {}", n, &show_ty_in(st, &**a, &true)))
        },
        Ty::TyAny(ts) => Text::from(format!("any {}", &crate::syntax::lexer::join(&each(ts, &(|x: &Text| Text::from(format!("^{}", &bare_name(x))))), &Text::lit(" ")))),
        Ty::TyErr => Text::lit("?"),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ShowTyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
/// ```
pub struct ShowTyIn {
    pub st: St,
    pub t: Ty,
    pub nested: bool,
}

impl prism_rtl::Job<Text> for ShowTyIn {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st = &self.st;
        let t = &self.t;
        let nested = &self.nested;
        match t {
            Ty::TyFlex(n) => prism_rtl::Turn::Finished(Text::from(format!("t{}", n))),
            Ty::TyRigid(n) => prism_rtl::Turn::Finished(n.clone()),
            Ty::TyQ(n) => prism_rtl::Turn::Finished(n.clone()),
            Ty::TyCon(n, m9111_3_1) if (m9111_3_1.len() == 0) => prism_rtl::Turn::Finished(bare_name(n)),
            Ty::TyCon(n, args) => {
                let args = args.clone();
                let n = n.clone();
                let nested = *nested;
                let st = st.clone();
                call_value(each_job(args.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: Ty| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let a = p0;
                            call_then(start_show_ty_in(st.clone(), a.clone(), true), move |show_ty_in_9281: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &show_ty_in_9281))))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_9262: Array<Text>| {
                    let inner = Text::from(format!("{}{}", &bare_name(&n), &concat(&each_9262)));
                    if nested {
                        prism_rtl::Turn::Finished(Text::from(format!("({})", &inner)))
                    } else {
                        prism_rtl::Turn::Finished(inner.clone())
                    }
                })
            },
            Ty::TyFn(c, ps, res) => {
                let c = c.clone();
                let nested = *nested;
                let ps = ps.clone();
                let res = (**res).clone();
                let st = st.clone();
                call_value(each_job(ps.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: Ty| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let p_ = p0;
                            prism_rtl::Turn::More(Rc::new(ShowTyIn { st: st.clone(), t: p_.clone(), nested: false }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_9413: Array<Text>| call_then(start_show_ty_in(st.clone(), res.clone(), false), move |show_ty_in_9461: Text| {
                    let inner = Text::from(format!("{}fn {} -> {}", &show_col(&c), &crate::syntax::lexer::join(&each_9413, &Text::lit(", ")), &show_ty_in_9461));
                    if nested {
                        prism_rtl::Turn::Finished(Text::from(format!("({})", &inner)))
                    } else {
                        prism_rtl::Turn::Finished(inner.clone())
                    }
                }))
            },
            Ty::TyTuple(ts) => {
                let st = st.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: Ty| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(ShowTyIn { st: st.clone(), t: a.clone(), nested: false }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_9556: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("(({}))", &crate::syntax::lexer::join(&each_9556, &Text::lit(", "))))))
            },
            Ty::TyArray(e) => {
                let e = (**e).clone();
                let st = st.clone();
                call_then(start_show_ty_in(st.clone(), e.clone(), false), move |show_ty_in_9638: Text| {
                    let inner = show_ty_in_9638;
                    if crate::syntax::lexer::has_prefix(&inner, &Text::lit("[")) {
                        prism_rtl::Turn::Finished(Text::from(format!("[ {} ]", &inner)))
                    } else {
                        prism_rtl::Turn::Finished(Text::from(format!("[{}]", &inner)))
                    }
                })
            },
            Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let nested = *nested;
                let st = st.clone();
                let v_ = (**v_).clone();
                call_then(start_show_ty_in(st.clone(), k.clone(), true), move |show_ty_in_9765: Text| call_then(start_show_ty_in(st.clone(), v_.clone(), true), move |show_ty_in_9792: Text| {
                    let inner = Text::from(format!("{} ==> {}", &show_ty_in_9765, &show_ty_in_9792));
                    if nested {
                        prism_rtl::Turn::Finished(Text::from(format!("({})", &inner)))
                    } else {
                        prism_rtl::Turn::Finished(inner.clone())
                    }
                }))
            },
            Ty::TySig(s, i) => {
                let i = (**i).clone();
                let s = s.clone();
                let st = st.clone();
                call_then(start_show_ty_in(st.clone(), i.clone(), true), move |show_ty_in_9879: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &s, &show_ty_in_9879))))
            },
            Ty::TyAt(i, rw) => {
                let i = (**i).clone();
                let st = st.clone();
                call_then(start_show_ty_in(st.clone(), i.clone(), true), move |show_ty_in_9921: Text| prism_rtl::Turn::Finished(Text::from(format!("@{}", &show_ty_in_9921))))
            },
            Ty::TyElem(rw, o) => {
                let nested = *nested;
                let o = (**o).clone();
                let rw = rw.clone();
                let st = st.clone();
                call_then(start_show_ty_in(st.clone(), o.clone(), true), move |show_ty_in_10013: Text| {
                    let inner = Text::from(format!("Element {} {}", &show_row_in(&rw, &true), &show_ty_in_10013));
                    if nested {
                        prism_rtl::Turn::Finished(Text::from(format!("({})", &inner)))
                    } else {
                        prism_rtl::Turn::Finished(inner.clone())
                    }
                })
            },
            Ty::TyElemAny(rw) => if *nested {
                prism_rtl::Turn::Finished(Text::from(format!("(Elem {})", &show_row_in(rw, &true))))
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("Elem {}", &show_row_in(rw, &true))))
            },
            Ty::TyAssoc(n, a) => if *nested {
                {
                    let a = (**a).clone();
                    let n = n.clone();
                    let st = st.clone();
                    call_then(start_show_ty_in(st.clone(), a.clone(), true), move |show_ty_in_10208: Text| prism_rtl::Turn::Finished(Text::from(format!("({} {})", &n, &show_ty_in_10208))))
                }
            } else {
                {
                    let a = (**a).clone();
                    let n = n.clone();
                    let st = st.clone();
                    call_then(start_show_ty_in(st.clone(), a.clone(), true), move |show_ty_in_10244: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &n, &show_ty_in_10244))))
                }
            },
            Ty::TyAny(ts) => prism_rtl::Turn::Finished(Text::from(format!("any {}", &crate::syntax::lexer::join(&each(ts, &(|x: &Text| Text::from(format!("^{}", &bare_name(x))))), &Text::lit(" "))))),
            Ty::TyErr => prism_rtl::Turn::Finished(Text::lit("?")),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ShowTyIn, x`: what the function value is when passed to `@Run`.
pub fn start_show_ty_in(st: St, t: Ty, nested: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowTyIn { st, t, nested })
}

/// ```prism
/// ShowCol: fn Col -> Text
/// ```
pub fn show_col(col0: &Col) -> Text {
    match col0 {
        Col::CBound => Text::lit(""),
        Col::CUnbound => Text::lit("unbounded "),
        Col::CRigid(n) => Text::from(format!("{} ", n)),
        Col::CQ(n) => Text::from(format!("{} ", n)),
        Col::CFlex(_) => Text::lit(""),
    }
}

/// ```prism
/// ShowRow: fn Rw -> Text
/// ```
pub fn show_row(rw: &Rw) -> Text {
    show_row_in(rw, &false)
}

/// ```prism
/// ShowRowIn: fn Rw, Bool -> Text
/// ```
pub fn show_row_in(rw: &Rw, nested: &bool) -> Text {
    let fams = each(&rw.fams, &(|f: &Text| Text::from(format!("{}.*", f))));
    let tail = match &rw.tail {
        Tail::TlClosed => Array::new(),
        Tail::TlFlex(n) => Array::from(vec![Text::from(format!("r{}", n))]),
        Tail::TlRigid(n) => Array::from(vec![n.clone()]),
        Tail::TlQ(n) => Array::from(vec![n.clone()]),
    };
    let parts = append(&tail, &fams);
    let minus = if &len(&rw.minus) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" − {{{}}}", &crate::syntax::lexer::join(&rw.minus, &Text::lit(", "))))
    };
    let inner = if &len(&parts) == &Nat::from(0u32) {
        Text::lit("unit")
    } else {
        crate::syntax::lexer::join(&parts, &Text::lit(" | "))
    };
    if *nested && ((&len(&parts) > &Nat::from(1u32)) || (&minus != &Text::lit(""))) {
        Text::from(format!("({}{})", &inner, &minus))
    } else {
        Text::from(format!("{}{}", &inner, &minus))
    }
}

/// ```prism
/// AtHere: fn St, Range -> SrcAt
/// ```
pub fn at_here(st: &St, span: &crate::syntax::Range) -> crate::check::typed::SrcAt {
    crate::check::typed::SrcAt { file: st.file.clone(), span: span.clone() }
}

/// ```prism
/// NoteTy: fn St, Range, Ty -> St
/// ```
pub fn note_ty(st: &St, span: &crate::syntax::Range, t: &Ty) -> St {
    if !st.recording {
        st.clone()
    } else {
        {
            let mut this: St = st.clone();
            this.typed.exprs = push(&this.typed.exprs, &crate::check::typed::TyNote { at: at_here(st, span), ty: t.clone() });
            this
        }
    }
}

/// ```prism
/// NoteBinder: fn St, Range, Text, Ty -> St
/// ```
pub fn note_binder(st: &St, span: &crate::syntax::Range, name: &Text, t: &Ty) -> St {
    if !st.recording {
        st.clone()
    } else {
        {
            let mut this: St = st.clone();
            this.typed.binders = push(&this.typed.binders, &crate::check::typed::BinderNote { at: at_here(st, span), name: name.clone(), ty: t.clone() });
            this
        }
    }
}

/// ```prism
/// NoteGen: fn St, Range, Text, Scheme -> St
/// ```
pub fn note_gen(st: &St, span: &crate::syntax::Range, name: &Text, sc: &Scheme) -> St {
    if !st.recording || ((&len(&sc.qs) == &Nat::from(0u32)) && (&len(&sc.cqs) == &Nat::from(0u32))) {
        st.clone()
    } else {
        {
            let mut this: St = st.clone();
            this.typed.gens = push(&this.typed.gens, &crate::check::typed::GenNote { at: at_here(st, span), name: name.clone(), tys: sc.qs.clone(), cols: sc.cqs.clone() });
            this
        }
    }
}

/// ```prism
/// NoteInst: fn St, Range, Text, Scheme, Inst -> St
/// ```
pub fn note_inst(st: &St, span: &crate::syntax::Range, name: &Text, sc: &Scheme, inst: &Inst) -> St {
    if !st.recording {
        st.clone()
    } else {
        {
            let mut this: St = st.clone();
            this.typed.insts = push(&this.typed.insts, &crate::check::typed::InstNote { at: at_here(st, span), name: name.clone(), tys: each(&sc.qs, &(|q: &Text| (q.clone(), or(&get(&inst.tys, q), &Ty::TyErr)))), cols: each(&sc.cqs, &(|q: &Text| (q.clone(), or(&get(&inst.cols, q), &Col::CBound)))) });
            this
        }
    }
}

/// ```prism
/// NoteApp: fn St, Range, Text, Text, Text, [Nat], Text, Col -> St
/// ```
pub fn note_app(st: &St, span: &crate::syntax::Range, callee: &Text, kind: &Text, layer: &Text, lifted: &Array<Nat>, inner: &Text, col: &Col) -> St {
    if !st.recording {
        st.clone()
    } else {
        {
            let mut this: St = st.clone();
            this.typed.apps = push(&this.typed.apps, &crate::check::typed::AppNote { at: at_here(st, span), callee: callee.clone(), kind: kind.clone(), layer: layer.clone(), lifted: lifted.clone(), inner: inner.clone(), color: col.clone() });
            this
        }
    }
}

/// ```prism
/// NoteFn: fn St, Range, Text, Col, Col -> St
/// ```
pub fn note_fn(st: &St, span: &crate::syntax::Range, name: &Text, declared: &Col, body: &Col) -> St {
    if !st.recording {
        st.clone()
    } else {
        {
            let mut this: St = st.clone();
            this.typed.fns = push(&this.typed.fns, &crate::check::typed::FnNote { at: at_here(st, span), name: name.clone(), declared: declared.clone(), body: body.clone() });
            this
        }
    }
}

/// ```prism
/// NoteImpl: fn St, Nat, Range, Text, Ty, Text -> St
/// ```
pub fn note_impl(st: &St, file: &Nat, span: &crate::syntax::Range, cls: &Text, t: &Ty, how: &Text) -> St {
    if ((!st.recording || crate::syntax::lexer::has_prefix(cls, &Text::lit("Range "))) || (cls == &Text::lit("Prelude.Sub"))) || (cls == &Text::lit("Prelude.Signed")) {
        st.clone()
    } else {
        {
            let mut this: St = st.clone();
            this.typed.impls = push(&this.typed.impls, &crate::check::typed::ImplNote { at: crate::check::typed::SrcAt { file: file.clone(), span: span.clone() }, cls: cls.clone(), ty: t.clone(), how: how.clone() });
            this
        }
    }
}

/// ```prism
/// NoteChoice: fn St, Nat, Range, Text, Text -> St
/// ```
pub fn note_choice(st: &St, file: &Nat, span: &crate::syntax::Range, cls: &Text, ch: &Text) -> St {
    let k = choice_key(file, span, cls);
    if (crate::syntax::lexer::has_prefix(cls, &Text::lit("Range ")) || (cls == &Text::lit("Prelude.Sub"))) || (cls == &Text::lit("Prelude.Signed")) {
        st.clone()
    } else {
        {
            let mut this: St = st.clone();
            this.choices = insert(&this.choices, &k, &add_text(&or(&get(&this.choices, &k), &Array::new()), ch));
            this
        }
    }
}

/// ```prism
/// NoteSizeTy: fn St, Range, Ty -> St
/// ```
pub fn note_size_ty(st: &St, span: &crate::syntax::Range, t: &Ty) -> St {
    match t {
        Ty::TyFn(_, ps, _) => match index(ps, &Nat::from(0u32)) {
            Some(p_) => {
                let mut this: St = st.clone();
                this.size_tys = insert(&this.size_tys, &Text::from(format!("{}:{}:{}", &st.file, &span.start, &span.end)), &p_);
                this
            },
            None => st.clone(),
        },
        _ => st.clone(),
    }
}

/// ```prism
/// ChoiceKey: fn Nat, Range, Text -> Text
/// ```
pub fn choice_key(file: &Nat, span: &crate::syntax::Range, cls: &Text) -> Text {
    Text::from(format!("{}:{}:{}:{}", file, &span.start, &span.end, cls))
}

/// ```prism
/// NoteMethod: fn St, Range, Text, Text -> St
/// ```
pub fn note_method(st: &St, span: &crate::syntax::Range, method: &Text, cls: &Text) -> St {
    if !st.recording {
        st.clone()
    } else {
        {
            let mut this: St = st.clone();
            this.typed.methods = push(&this.typed.methods, &crate::check::typed::MethodNote { at: at_here(st, span), method: method.clone(), cls: cls.clone() });
            this
        }
    }
}

/// ```prism
/// NoteGroup: fn St, Range, Text, [ [Nat] ] -> St
/// ```
pub fn note_group(st: &St, span: &crate::syntax::Range, kind: &Text, order: &Array<Array<Nat>>) -> St {
    if !st.recording {
        st.clone()
    } else {
        {
            let mut this: St = st.clone();
            this.typed.groups = push(&this.typed.groups, &crate::check::typed::GroupNote { at: at_here(st, span), kind: kind.clone(), order: order.clone() });
            this
        }
    }
}

/// ```prism
/// ZonkTyped: unbounded fn St -> TProgram
/// ```
pub fn zonk_typed(st: &St) -> crate::check::typed::TProgram {
    let t = st.typed.clone();
    let mut this: crate::check::typed::TProgram = t.clone();
    this.exprs = run_to_end(each_job(this.exprs.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::typed::TyNote| {
            let st = st.clone();
            entered(once_job(move || {
                let n = p0;
                call_then(start_resolve_ty(st.clone(), n.ty.clone()), move |resolve_ty_15751: Ty| prism_rtl::Turn::Finished(crate::check::typed::TyNote { at: n.at.clone(), ty: resolve_ty_15751 }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::TyNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::TyNote>>>
    }));
    this.binders = run_to_end(each_job(this.binders.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::typed::BinderNote| {
            let st = st.clone();
            entered(once_job(move || {
                let n = p0;
                call_then(start_resolve_ty(st.clone(), n.ty.clone()), move |resolve_ty_15853: Ty| prism_rtl::Turn::Finished(crate::check::typed::BinderNote { at: n.at.clone(), name: n.name.clone(), ty: resolve_ty_15853 }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::BinderNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::BinderNote>>>
    }));
    this.insts = run_to_end(each_job(this.insts.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::typed::InstNote| {
            let st = st.clone();
            entered(once_job(move || {
                let n = p0;
                call_value(each_job(n.tys.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: (Text, Ty)| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let (q, x) = p0;
                            call_then(start_resolve_ty(st.clone(), x.clone()), move |resolve_ty_15980: Ty| prism_rtl::Turn::Finished((q.clone(), resolve_ty_15980)))
                        }))
                    }) as Rc<dyn Fn((Text, Ty)) -> Rc<dyn prism_rtl::Job<(Text, Ty)>>>
                }), move |each_15950: Array<(Text, Ty)>| call_value(each_job(n.cols.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: (Text, Col)| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let (q, c) = p0;
                            call_then(start_resolve_col(st.clone(), c.clone()), move |resolve_col_16038: Col| prism_rtl::Turn::Finished((q.clone(), resolve_col_16038)))
                        }))
                    }) as Rc<dyn Fn((Text, Col)) -> Rc<dyn prism_rtl::Job<(Text, Col)>>>
                }), move |each_16007: Array<(Text, Col)>| prism_rtl::Turn::Finished(crate::check::typed::InstNote { at: n.at.clone(), name: n.name.clone(), tys: each_15950, cols: each_16007 })))
            }))
        }) as Rc<dyn Fn(crate::check::typed::InstNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::InstNote>>>
    }));
    this.impls = run_to_end(each_job(this.impls.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::typed::ImplNote| {
            let st = st.clone();
            entered(once_job(move || {
                let n = p0;
                call_then(start_resolve_ty(st.clone(), n.ty.clone()), move |resolve_ty_16133: Ty| prism_rtl::Turn::Finished(crate::check::typed::ImplNote { at: n.at.clone(), cls: n.cls.clone(), ty: resolve_ty_16133, how: n.how.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::ImplNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::ImplNote>>>
    }));
    this.apps = run_to_end(each_job(this.apps.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::typed::AppNote| {
            let st = st.clone();
            entered(once_job(move || {
                let n = p0;
                call_then(start_resolve_col(st.clone(), n.color.clone()), move |resolve_col_16304: Col| prism_rtl::Turn::Finished(crate::check::typed::AppNote { at: n.at.clone(), callee: n.callee.clone(), kind: n.kind.clone(), layer: n.layer.clone(), lifted: n.lifted.clone(), inner: n.inner.clone(), color: resolve_col_16304 }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::AppNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::AppNote>>>
    }));
    this.fns = run_to_end(each_job(this.fns.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::typed::FnNote| {
            let st = st.clone();
            entered(once_job(move || {
                let n = p0;
                call_then(start_resolve_col(st.clone(), n.declared.clone()), move |resolve_col_16404: Col| call_then(start_resolve_col(st.clone(), n.body.clone()), move |resolve_col_16438: Col| prism_rtl::Turn::Finished(crate::check::typed::FnNote { at: n.at.clone(), name: n.name.clone(), declared: resolve_col_16404, body: resolve_col_16438 })))
            }))
        }) as Rc<dyn Fn(crate::check::typed::FnNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::FnNote>>>
    }));
    this
}

/// The step machine of `ZonkTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ZonkTyped: unbounded fn St -> TProgram
/// ```
pub struct ZonkTyped {
    pub st: St,
}

impl prism_rtl::Job<crate::check::typed::TProgram> for ZonkTyped {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::typed::TProgram> {
        let st = &self.st;
        let t = st.typed.clone();
        prism_rtl::Turn::Finished({
            let mut this: crate::check::typed::TProgram = t.clone();
            this.exprs = run_to_end(each_job(this.exprs.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::typed::TyNote| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let n = p0;
                        call_then(start_resolve_ty(st.clone(), n.ty.clone()), move |resolve_ty_15751: Ty| prism_rtl::Turn::Finished(crate::check::typed::TyNote { at: n.at.clone(), ty: resolve_ty_15751 }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::TyNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::TyNote>>>
            }));
            this.binders = run_to_end(each_job(this.binders.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::typed::BinderNote| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let n = p0;
                        call_then(start_resolve_ty(st.clone(), n.ty.clone()), move |resolve_ty_15853: Ty| prism_rtl::Turn::Finished(crate::check::typed::BinderNote { at: n.at.clone(), name: n.name.clone(), ty: resolve_ty_15853 }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::BinderNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::BinderNote>>>
            }));
            this.insts = run_to_end(each_job(this.insts.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::typed::InstNote| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let n = p0;
                        call_value(each_job(n.tys.clone(), {
                            let st = st.clone();
                            Rc::new(move |p0: (Text, Ty)| {
                                let st = st.clone();
                                entered(once_job(move || {
                                    let (q, x) = p0;
                                    call_then(start_resolve_ty(st.clone(), x.clone()), move |resolve_ty_15980: Ty| prism_rtl::Turn::Finished((q.clone(), resolve_ty_15980)))
                                }))
                            }) as Rc<dyn Fn((Text, Ty)) -> Rc<dyn prism_rtl::Job<(Text, Ty)>>>
                        }), move |each_15950: Array<(Text, Ty)>| call_value(each_job(n.cols.clone(), {
                            let st = st.clone();
                            Rc::new(move |p0: (Text, Col)| {
                                let st = st.clone();
                                entered(once_job(move || {
                                    let (q, c) = p0;
                                    call_then(start_resolve_col(st.clone(), c.clone()), move |resolve_col_16038: Col| prism_rtl::Turn::Finished((q.clone(), resolve_col_16038)))
                                }))
                            }) as Rc<dyn Fn((Text, Col)) -> Rc<dyn prism_rtl::Job<(Text, Col)>>>
                        }), move |each_16007: Array<(Text, Col)>| prism_rtl::Turn::Finished(crate::check::typed::InstNote { at: n.at.clone(), name: n.name.clone(), tys: each_15950, cols: each_16007 })))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::InstNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::InstNote>>>
            }));
            this.impls = run_to_end(each_job(this.impls.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::typed::ImplNote| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let n = p0;
                        call_then(start_resolve_ty(st.clone(), n.ty.clone()), move |resolve_ty_16133: Ty| prism_rtl::Turn::Finished(crate::check::typed::ImplNote { at: n.at.clone(), cls: n.cls.clone(), ty: resolve_ty_16133, how: n.how.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::ImplNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::ImplNote>>>
            }));
            this.apps = run_to_end(each_job(this.apps.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::typed::AppNote| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let n = p0;
                        call_then(start_resolve_col(st.clone(), n.color.clone()), move |resolve_col_16304: Col| prism_rtl::Turn::Finished(crate::check::typed::AppNote { at: n.at.clone(), callee: n.callee.clone(), kind: n.kind.clone(), layer: n.layer.clone(), lifted: n.lifted.clone(), inner: n.inner.clone(), color: resolve_col_16304 }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::AppNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::AppNote>>>
            }));
            this.fns = run_to_end(each_job(this.fns.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::typed::FnNote| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let n = p0;
                        call_then(start_resolve_col(st.clone(), n.declared.clone()), move |resolve_col_16404: Col| call_then(start_resolve_col(st.clone(), n.body.clone()), move |resolve_col_16438: Col| prism_rtl::Turn::Finished(crate::check::typed::FnNote { at: n.at.clone(), name: n.name.clone(), declared: resolve_col_16404, body: resolve_col_16438 })))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::FnNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::FnNote>>>
            }));
            this
        })
    }
}

/// `Start ZonkTyped, x`: what the function value is when passed to `@Run`.
pub fn start_zonk_typed(st: St) -> Rc<dyn prism_rtl::Job<crate::check::typed::TProgram>> {
    Rc::new(ZonkTyped { st })
}

/// ```prism
/// ResolveCol: unbounded fn St, Col -> Col
/// ```
pub fn resolve_col(st: &St, c: &Col) -> Col {
    match walk_col(st, c) {
        Col::CFlex(n) => match get(&st.col_q, &n) {
            Some(q) => Col::CQ(q.clone()),
            None => Col::CBound,
        },
        other => other.clone(),
    }
}

/// The step machine of `ResolveCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveCol: unbounded fn St, Col -> Col
/// ```
pub struct ResolveCol {
    pub st: St,
    pub c: Col,
}

impl prism_rtl::Job<Col> for ResolveCol {
    fn cycle(&self) -> prism_rtl::Turn<Col> {
        let st = &self.st;
        let c = &self.c;
        let c = c.clone();
        let st = st.clone();
        call_then(start_walk_col(st.clone(), c.clone()), move |walk_col_16673: Col| match walk_col_16673 {
            Col::CFlex(n) => match get(&st.col_q, &n) {
                Some(q) => prism_rtl::Turn::Finished(Col::CQ(q.clone())),
                None => prism_rtl::Turn::Finished(Col::CBound),
            },
            other => prism_rtl::Turn::Finished(other.clone()),
        })
    }
}

/// `Start ResolveCol, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_col(st: St, c: Col) -> Rc<dyn prism_rtl::Job<Col>> {
    Rc::new(ResolveCol { st, c })
}

/// ```prism
/// ResolveTy: unbounded fn St, Ty -> Ty
/// ```
pub fn resolve_ty(st: &St, t: &Ty) -> Ty {
    resolve_in(st, &zonk(st, t))
}

/// The step machine of `ResolveTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveTy: unbounded fn St, Ty -> Ty
/// ```
pub struct ResolveTy {
    pub st: St,
    pub t: Ty,
}

impl prism_rtl::Job<Ty> for ResolveTy {
    fn cycle(&self) -> prism_rtl::Turn<Ty> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(start_zonk(st.clone(), t.clone()), move |zonk_16886: Ty| prism_rtl::Turn::More(Rc::new(ResolveIn { st: st.clone(), t: zonk_16886 })))
    }
}

/// `Start ResolveTy, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_ty(st: St, t: Ty) -> Rc<dyn prism_rtl::Job<Ty>> {
    Rc::new(ResolveTy { st, t })
}

/// ```prism
/// ResolveIn: unbounded fn St, Ty -> Ty
/// ```
pub fn resolve_in(st: &St, t: &Ty) -> Ty {
    match t {
        Ty::TyCon(n, args) => Ty::TyCon(n.clone(), run_to_end(each_job(args.clone(), {
            let st = st.clone();
            Rc::new(move |p0: Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(ResolveIn { st: st.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
        }))),
        Ty::TyFn(c, ps, res) => Ty::TyFn(resolve_col(st, c), run_to_end(each_job(ps.clone(), {
            let st = st.clone();
            Rc::new(move |p0: Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(ResolveIn { st: st.clone(), t: p_.clone() }))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
        })), Rc::new(resolve_in(st, &**res))),
        Ty::TyTuple(ts) => Ty::TyTuple(run_to_end(each_job(ts.clone(), {
            let st = st.clone();
            Rc::new(move |p0: Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(ResolveIn { st: st.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
        }))),
        Ty::TyArray(e) => Ty::TyArray(Rc::new(resolve_in(st, &**e))),
        Ty::TyMap(k, v_) => Ty::TyMap(Rc::new(resolve_in(st, &**k)), Rc::new(resolve_in(st, &**v_))),
        Ty::TySig(s, i) => Ty::TySig(s.clone(), Rc::new(resolve_in(st, &**i))),
        Ty::TyAt(i, rw) => Ty::TyAt(Rc::new(resolve_in(st, &**i)), rw.clone()),
        Ty::TyElem(rw, o) => Ty::TyElem(rw.clone(), Rc::new(resolve_in(st, &**o))),
        Ty::TyAssoc(n, a) => Ty::TyAssoc(n.clone(), Rc::new(resolve_in(st, &**a))),
        other => other.clone(),
    }
}

/// The step machine of `ResolveIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveIn: unbounded fn St, Ty -> Ty
/// ```
pub struct ResolveIn {
    pub st: St,
    pub t: Ty,
}

impl prism_rtl::Job<Ty> for ResolveIn {
    fn cycle(&self) -> prism_rtl::Turn<Ty> {
        let st = &self.st;
        let t = &self.t;
        match t {
            Ty::TyCon(n, args) => {
                let args = args.clone();
                let n = n.clone();
                let st = st.clone();
                call_value(each_job(args.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: Ty| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(ResolveIn { st: st.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
                }), move |each_16995: Array<Ty>| prism_rtl::Turn::Finished(Ty::TyCon(n.clone(), each_16995)))
            },
            Ty::TyFn(c, ps, res) => {
                let c = c.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                let st = st.clone();
                call_then(start_resolve_col(st.clone(), c.clone()), move |resolve_col_17055: Col| call_value(each_job(ps.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: Ty| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let p_ = p0;
                            prism_rtl::Turn::More(Rc::new(ResolveIn { st: st.clone(), t: p_.clone() }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
                }), move |each_17075: Array<Ty>| call_then(start_resolve_in(st.clone(), res.clone()), move |resolve_in_17108: Ty| prism_rtl::Turn::Finished(Ty::TyFn(resolve_col_17055, each_17075, Rc::new(resolve_in_17108))))))
            },
            Ty::TyTuple(ts) => {
                let st = st.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: Ty| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(ResolveIn { st: st.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
                }), move |each_17152: Array<Ty>| prism_rtl::Turn::Finished(Ty::TyTuple(each_17152)))
            },
            Ty::TyArray(e) => {
                let e = (**e).clone();
                let st = st.clone();
                call_then(start_resolve_in(st.clone(), e.clone()), move |resolve_in_17207: Ty| prism_rtl::Turn::Finished(Ty::TyArray(Rc::new(resolve_in_17207))))
            },
            Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let st = st.clone();
                let v_ = (**v_).clone();
                call_then(start_resolve_in(st.clone(), k.clone()), move |resolve_in_17247: Ty| call_then(start_resolve_in(st.clone(), v_.clone()), move |resolve_in_17266: Ty| prism_rtl::Turn::Finished(Ty::TyMap(Rc::new(resolve_in_17247), Rc::new(resolve_in_17266)))))
            },
            Ty::TySig(s, i) => {
                let i = (**i).clone();
                let s = s.clone();
                let st = st.clone();
                call_then(start_resolve_in(st.clone(), i.clone()), move |resolve_in_17309: Ty| prism_rtl::Turn::Finished(Ty::TySig(s.clone(), Rc::new(resolve_in_17309))))
            },
            Ty::TyAt(i, rw) => {
                let i = (**i).clone();
                let rw = rw.clone();
                let st = st.clone();
                call_then(start_resolve_in(st.clone(), i.clone()), move |resolve_in_17348: Ty| prism_rtl::Turn::Finished(Ty::TyAt(Rc::new(resolve_in_17348), rw.clone())))
            },
            Ty::TyElem(rw, o) => {
                let o = (**o).clone();
                let rw = rw.clone();
                let st = st.clone();
                call_then(start_resolve_in(st.clone(), o.clone()), move |resolve_in_17399: Ty| prism_rtl::Turn::Finished(Ty::TyElem(rw.clone(), Rc::new(resolve_in_17399))))
            },
            Ty::TyAssoc(n, a) => {
                let a = (**a).clone();
                let n = n.clone();
                let st = st.clone();
                call_then(start_resolve_in(st.clone(), a.clone()), move |resolve_in_17446: Ty| prism_rtl::Turn::Finished(Ty::TyAssoc(n.clone(), Rc::new(resolve_in_17446))))
            },
            other => prism_rtl::Turn::Finished(other.clone()),
        }
    }
}

/// `Start ResolveIn, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_in(st: St, t: Ty) -> Rc<dyn prism_rtl::Job<Ty>> {
    Rc::new(ResolveIn { st, t })
}

/// ```prism
/// AtBinder: fn St, Ty, Range -> St
/// ```
pub fn at_binder(st: &St, ty1: &Ty, range2: &crate::syntax::Range) -> St {
    match (ty1, range2) {
        (Ty::TyFlex(n), span) => {
            let mut this: St = st.clone();
            this.binder_at = insert(&this.binder_at, n, span);
            this
        },
        (_, _) => st.clone(),
    }
}

/// ```prism
/// FreshRow: fn St, [Text] -> ((Rw, St))
/// ```
pub fn fresh_row(st: &St, lacking: &Array<Text>) -> (Rw, St) {
    let n = st.next.clone();
    let st2 = {
        let mut this: St = st.clone();
        this.next = &this.next + &Nat::from(1u32);
        this.lacks = insert(&this.lacks, &n, lacking);
        this
    };
    (Rw { fams: Array::new(), minus: Array::new(), tail: Tail::TlFlex(n.clone()) }, st2.clone())
}

/// ```prism
/// AddDiag: fn St, CDiag -> St
/// ```
pub fn add_diag(st: &St, d: &crate::check::errors::CDiag) -> St {
    let mut this: St = st.clone();
    this.diags = push(&this.diags, d);
    this
}

/// ```prism
/// Err: fn St, Text, Range, Text -> St
/// ```
pub fn err(st: &St, code: &Text, span: &crate::syntax::Range, message: &Text) -> St {
    add_diag(st, &crate::check::errors::diag0(code, &st.file, span, message))
}

/// ```prism
/// ErrFix: fn St, Text, Range, Text, Text -> St
/// ```
pub fn err_fix(st: &St, code: &Text, span: &crate::syntax::Range, message: &Text, fix: &Text) -> St {
    add_diag(st, &crate::check::errors::diag_fix(code, &st.file, span, message, fix))
}

/// ```prism
/// InfoOf: fn St, Nat -> VInfo
/// ```
pub fn info_of(st: &St, n: &Nat) -> VInfo {
    or(&get(&st.infos, n), &VInfo { plain: false, level: Nat::from(0u32), name: Text::lit("") })
}

/// ```prism
/// Walk: unbounded fn St, Ty -> Ty
/// ```
pub fn walk(st: &St, ty1: &Ty) -> Ty {
    match ty1 {
        Ty::TyFlex(n) => match get(&st.tys, n) {
            Some(t) => walk(st, &t),
            None => Ty::TyFlex(n.clone()),
        },
        t => t.clone(),
    }
}

/// The step machine of `Walk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Walk: unbounded fn St, Ty -> Ty
/// ```
pub struct Walk {
    pub st: St,
    pub ty1: Ty,
}

impl prism_rtl::Job<Ty> for Walk {
    fn cycle(&self) -> prism_rtl::Turn<Ty> {
        let st = &self.st;
        let ty1 = &self.ty1;
        match ty1 {
            Ty::TyFlex(n) => match get(&st.tys, n) {
                Some(t) => prism_rtl::Turn::More(Rc::new(Walk { st: st.clone(), ty1: t.clone() })),
                None => prism_rtl::Turn::Finished(Ty::TyFlex(n.clone())),
            },
            t => prism_rtl::Turn::Finished(t.clone()),
        }
    }
}

/// `Start Walk, x`: what the function value is when passed to `@Run`.
pub fn start_walk(st: St, ty1: Ty) -> Rc<dyn prism_rtl::Job<Ty>> {
    Rc::new(Walk { st, ty1 })
}

/// ```prism
/// WalkRow: unbounded fn St, Rw -> Rw
/// ```
pub fn walk_row(st: &St, r: &Rw) -> Rw {
    match &r.tail {
        Tail::TlFlex(n) => match get(&st.rows, n) {
            Some(r2) => {
                let w = walk_row(st, &r2);
                Rw { fams: sort_texts(&union_texts(&r.fams, &w.fams)), minus: union_texts(&r.minus, &w.minus), tail: w.tail.clone() }
            },
            None => r.clone(),
        },
        _ => r.clone(),
    }
}

/// The step machine of `WalkRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkRow: unbounded fn St, Rw -> Rw
/// ```
pub struct WalkRow {
    pub st: St,
    pub r: Rw,
}

impl prism_rtl::Job<Rw> for WalkRow {
    fn cycle(&self) -> prism_rtl::Turn<Rw> {
        let st = &self.st;
        let r = &self.r;
        match &r.tail {
            Tail::TlFlex(n) => match get(&st.rows, n) {
                Some(r2) => {
                    let r = r.clone();
                    let st = st.clone();
                    call_then(start_walk_row(st.clone(), r2.clone()), move |walk_row_18813: Rw| {
                        let w = walk_row_18813;
                        prism_rtl::Turn::Finished(Rw { fams: sort_texts(&union_texts(&r.fams, &w.fams)), minus: union_texts(&r.minus, &w.minus), tail: w.tail.clone() })
                    })
                },
                None => prism_rtl::Turn::Finished(r.clone()),
            },
            _ => prism_rtl::Turn::Finished(r.clone()),
        }
    }
}

/// `Start WalkRow, x`: what the function value is when passed to `@Run`.
pub fn start_walk_row(st: St, r: Rw) -> Rc<dyn prism_rtl::Job<Rw>> {
    Rc::new(WalkRow { st, r })
}

/// ```prism
/// Zonk: unbounded fn St, Ty -> Ty
/// ```
pub fn zonk(st: &St, t: &Ty) -> Ty {
    match norm_assoc(st, &walk(st, t)) {
        Ty::TyCon(n, args) => Ty::TyCon(n.clone(), run_to_end(each_job(args.clone(), {
            let st = st.clone();
            Rc::new(move |p0: Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(Zonk { st: st.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
        }))),
        Ty::TyFn(c, ps, res) => Ty::TyFn(walk_col(st, &c), run_to_end(each_job(ps.clone(), {
            let st = st.clone();
            Rc::new(move |p0: Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(Zonk { st: st.clone(), t: p_.clone() }))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
        })), Rc::new(zonk(st, &*res))),
        Ty::TyTuple(ts) => Ty::TyTuple(run_to_end(each_job(ts.clone(), {
            let st = st.clone();
            Rc::new(move |p0: Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(Zonk { st: st.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
        }))),
        Ty::TyArray(e) => Ty::TyArray(Rc::new(zonk(st, &*e))),
        Ty::TyMap(k, v_) => Ty::TyMap(Rc::new(zonk(st, &*k)), Rc::new(zonk(st, &*v_))),
        Ty::TySig(s, i) => Ty::TySig(s.clone(), Rc::new(zonk(st, &*i))),
        Ty::TyAt(i, rw) => Ty::TyAt(Rc::new(zonk(st, &*i)), walk_row(st, &rw)),
        Ty::TyElem(rw, o) => Ty::TyElem(walk_row(st, &rw), Rc::new(zonk(st, &*o))),
        Ty::TyElemAny(rw) => Ty::TyElemAny(walk_row(st, &rw)),
        Ty::TyAssoc(n, a) => Ty::TyAssoc(n.clone(), Rc::new(zonk(st, &*a))),
        w => w.clone(),
    }
}

/// The step machine of `Zonk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Zonk: unbounded fn St, Ty -> Ty
/// ```
pub struct Zonk {
    pub st: St,
    pub t: Ty,
}

impl prism_rtl::Job<Ty> for Zonk {
    fn cycle(&self) -> prism_rtl::Turn<Ty> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(start_walk(st.clone(), t.clone()), move |walk_19104: Ty| call_then(start_norm_assoc(st.clone(), walk_19104), move |norm_assoc_19089: Ty| match norm_assoc_19089 {
            Ty::TyCon(n, args) => call_value(each_job(args.clone(), {
                let st = st.clone();
                Rc::new(move |p0: Ty| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(Zonk { st: st.clone(), t: a.clone() }))
                    }))
                }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
            }), move |each_19146: Array<Ty>| prism_rtl::Turn::Finished(Ty::TyCon(n.clone(), each_19146))),
            Ty::TyFn(c, ps, res) => call_then(start_walk_col(st.clone(), c.clone()), move |walk_col_19201: Col| call_value(each_job(ps.clone(), {
                let st = st.clone();
                Rc::new(move |p0: Ty| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let p_ = p0;
                        prism_rtl::Turn::More(Rc::new(Zonk { st: st.clone(), t: p_.clone() }))
                    }))
                }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
            }), move |each_19218: Array<Ty>| call_then(start_zonk(st.clone(), (*res).clone()), move |zonk_19246: Ty| prism_rtl::Turn::Finished(Ty::TyFn(walk_col_19201, each_19218, Rc::new(zonk_19246)))))),
            Ty::TyTuple(ts) => call_value(each_job(ts.clone(), {
                let st = st.clone();
                Rc::new(move |p0: Ty| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(Zonk { st: st.clone(), t: a.clone() }))
                    }))
                }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
            }), move |each_19285: Array<Ty>| prism_rtl::Turn::Finished(Ty::TyTuple(each_19285))),
            Ty::TyArray(e) => call_then(start_zonk(st.clone(), (*e).clone()), move |zonk_19335: Ty| prism_rtl::Turn::Finished(Ty::TyArray(Rc::new(zonk_19335)))),
            Ty::TyMap(k, v_) => call_then(start_zonk(st.clone(), (*k).clone()), move |zonk_19370: Ty| call_then(start_zonk(st.clone(), (*v_).clone()), move |zonk_19384: Ty| prism_rtl::Turn::Finished(Ty::TyMap(Rc::new(zonk_19370), Rc::new(zonk_19384))))),
            Ty::TySig(s, i) => call_then(start_zonk(st.clone(), (*i).clone()), move |zonk_19422: Ty| prism_rtl::Turn::Finished(Ty::TySig(s.clone(), Rc::new(zonk_19422)))),
            Ty::TyAt(i, rw) => call_then(start_zonk(st.clone(), (*i).clone()), move |zonk_19456: Ty| call_then(start_walk_row(st.clone(), rw.clone()), move |walk_row_19470: Rw| prism_rtl::Turn::Finished(Ty::TyAt(Rc::new(zonk_19456), walk_row_19470)))),
            Ty::TyElem(rw, o) => call_then(start_walk_row(st.clone(), rw.clone()), move |walk_row_19512: Rw| call_then(start_zonk(st.clone(), (*o).clone()), move |zonk_19530: Ty| prism_rtl::Turn::Finished(Ty::TyElem(walk_row_19512, Rc::new(zonk_19530))))),
            Ty::TyElemAny(rw) => call_then(start_walk_row(st.clone(), rw.clone()), move |walk_row_19571: Rw| prism_rtl::Turn::Finished(Ty::TyElemAny(walk_row_19571))),
            Ty::TyAssoc(n, a) => call_then(start_zonk(st.clone(), (*a).clone()), move |zonk_19617: Ty| prism_rtl::Turn::Finished(Ty::TyAssoc(n.clone(), Rc::new(zonk_19617)))),
            w => prism_rtl::Turn::Finished(w.clone()),
        }))
    }
}

/// `Start Zonk, x`: what the function value is when passed to `@Run`.
pub fn start_zonk(st: St, t: Ty) -> Rc<dyn prism_rtl::Job<Ty>> {
    Rc::new(Zonk { st, t })
}

/// ```prism
/// FreeVars: unbounded fn St, Ty -> [Nat]
/// ```
pub fn free_vars(st: &St, t: &Ty) -> Array<Nat> {
    free_vars_into(st, &Array::new(), t)
}

/// The step machine of `FreeVars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeVars: unbounded fn St, Ty -> [Nat]
/// ```
pub struct FreeVars {
    pub st: St,
    pub t: Ty,
}

impl prism_rtl::Job<Array<Nat>> for FreeVars {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let st = &self.st;
        let t = &self.t;
        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: Array::new(), t: t.clone() }))
    }
}

/// `Start FreeVars, x`: what the function value is when passed to `@Run`.
pub fn start_free_vars(st: St, t: Ty) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(FreeVars { st, t })
}

/// ```prism
/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub fn free_vars_into(st: &St, acc: &Array<Nat>, t: &Ty) -> Array<Nat> {
    match walk(st, t) {
        Ty::TyFlex(n) => add_nat(acc, &n),
        Ty::TyCon(_, args) => run_to_end(fold_job(args.clone(), acc.clone(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })),
        Ty::TyFn(_, ps, res) => free_vars_into(st, &run_to_end(fold_job(ps.clone(), acc.clone(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })), &*res),
        Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), acc.clone(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })),
        Ty::TyArray(e) => free_vars_into(st, acc, &*e),
        Ty::TyMap(k, v_) => free_vars_into(st, &free_vars_into(st, acc, &*k), &*v_),
        Ty::TySig(_, i) => free_vars_into(st, acc, &*i),
        Ty::TyAt(i, _) => free_vars_into(st, acc, &*i),
        Ty::TyElem(_, o) => free_vars_into(st, acc, &*o),
        Ty::TyAssoc(_, a) => free_vars_into(st, acc, &*a),
        _ => acc.clone(),
    }
}

/// The step machine of `FreeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub struct FreeVarsInto {
    pub st: St,
    pub acc: Array<Nat>,
    pub t: Ty,
}

impl prism_rtl::Job<Array<Nat>> for FreeVarsInto {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let st = &self.st;
        let acc = &self.acc;
        let t = &self.t;
        let acc = acc.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_walk(st.clone(), t.clone()), move |walk_19850: Ty| match walk_19850 {
            Ty::TyFlex(n) => prism_rtl::Turn::Finished(add_nat(&acc, &n)),
            Ty::TyCon(_, args) => fold_job(args.clone(), acc.clone(), {
                let st = st.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        let x = p1;
                        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }).cycle(),
            Ty::TyFn(_, ps, res) => call_value(fold_job(ps.clone(), acc.clone(), {
                let st = st.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        let x = p1;
                        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }), move |fold_20004: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: fold_20004, t: (*res).clone() }))),
            Ty::TyTuple(ts) => fold_job(ts.clone(), acc.clone(), {
                let st = st.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        let x = p1;
                        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }).cycle(),
            Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: acc.clone(), t: (*e).clone() })),
            Ty::TyMap(k, v_) => call_then(start_free_vars_into(st.clone(), acc.clone(), (*k).clone()), move |free_vars_into_20187: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: free_vars_into_20187, t: (*v_).clone() }))),
            Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: acc.clone(), t: (*i).clone() })),
            Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: acc.clone(), t: (*i).clone() })),
            Ty::TyElem(_, o) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: acc.clone(), t: (*o).clone() })),
            Ty::TyAssoc(_, a) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st.clone(), acc: acc.clone(), t: (*a).clone() })),
            _ => prism_rtl::Turn::Finished(acc.clone()),
        })
    }
}

/// `Start FreeVarsInto, x`: what the function value is when passed to `@Run`.
pub fn start_free_vars_into(st: St, acc: Array<Nat>, t: Ty) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(FreeVarsInto { st, acc, t })
}

/// ```prism
/// Unify: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub fn unify(st: &St, expected: &Ty, found: &Ty, span: &crate::syntax::Range) -> St {
    let (verdict, st2) = unify_in(st, expected, found, span);
    if &verdict == &Text::lit("mismatch") {
        {
            let e = show_ty(&st2, expected);
            let f = show_ty(&st2, found);
            if &e == &f {
                err(&st2, &Text::lit("mismatch"), span, &Text::from(format!("expected `{}`, found `{}`", &show_ty_q(&st2, expected), &show_ty_q(&st2, found))))
            } else {
                err(&st2, &Text::lit("mismatch"), span, &Text::from(format!("expected `{}`, found `{}`", &e, &f)))
            }
        }
    } else {
        st2.clone()
    }
}

/// The step machine of `Unify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Unify: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub struct Unify {
    pub st: St,
    pub expected: Ty,
    pub found: Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<St> for Unify {
    fn cycle(&self) -> prism_rtl::Turn<St> {
        let st = &self.st;
        let expected = &self.expected;
        let found = &self.found;
        let span = &self.span;
        let expected = expected.clone();
        let found = found.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(start_unify_in(st.clone(), expected.clone(), found.clone(), span.clone()), move |unify_in_21051: (Text, St)| {
            let (verdict, st2) = unify_in_21051;
            if &verdict == &Text::lit("mismatch") {
                call_then(start_show_ty(st2.clone(), expected.clone()), move |show_ty_21131: Text| {
                    let e = show_ty_21131;
                    call_then(start_show_ty(st2.clone(), found.clone()), move |show_ty_21168: Text| {
                        let f = show_ty_21168;
                        if &e == &f {
                            call_then(start_show_ty_q(st2.clone(), expected.clone()), move |show_ty_q_21244: Text| call_then(start_show_ty_q(st2.clone(), found.clone()), move |show_ty_q_21277: Text| prism_rtl::Turn::Finished(err(&st2, &Text::lit("mismatch"), &span, &Text::from(format!("expected `{}`, found `{}`", &show_ty_q_21244, &show_ty_q_21277))))))
                        } else {
                            prism_rtl::Turn::Finished(err(&st2, &Text::lit("mismatch"), &span, &Text::from(format!("expected `{}`, found `{}`", &e, &f))))
                        }
                    })
                })
            } else {
                prism_rtl::Turn::Finished(st2.clone())
            }
        })
    }
}

/// `Start Unify, x`: what the function value is when passed to `@Run`.
pub fn start_unify(st: St, expected: Ty, found: Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<St>> {
    Rc::new(Unify { st, expected, found, span })
}

/// ```prism
/// ShowTyQ: unbounded fn St, Ty -> Text
/// ```
pub fn show_ty_q(st: &St, t: &Ty) -> Text {
    match zonk(st, t) {
        Ty::TyCon(n, m21508_0_1) if ((&m21508_0_1).len() == 0) => n.clone(),
        Ty::TyCon(n, args) => Text::from(format!("({}{})", &n, &concat(&run_to_end(each_job(args.clone(), {
            let st = st.clone();
            Rc::new(move |p0: Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    call_then(start_show_ty_q(st.clone(), a.clone()), move |show_ty_q_21599: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &show_ty_q_21599))))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
        }))))),
        Ty::TySig(s, i) => Text::from(format!("{}{}", &s, &show_ty_q(st, &*i))),
        Ty::TyArray(e) => {
            let inner = show_ty_q(st, &*e);
            if crate::syntax::lexer::has_prefix(&inner, &Text::lit("[")) {
                Text::from(format!("[ {} ]", &inner))
            } else {
                Text::from(format!("[{}]", &inner))
            }
        },
        Ty::TyMap(k, v_) => Text::from(format!("({} ==> {})", &show_ty_q(st, &*k), &show_ty_q(st, &*v_))),
        Ty::TyAt(i, rw) => Text::from(format!("@{} emit {}", &show_ty_q(st, &*i), &show_row_in(&rw, &true))),
        other => show_ty(st, &other),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ShowTyQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowTyQ: unbounded fn St, Ty -> Text
/// ```
pub struct ShowTyQ {
    pub st: St,
    pub t: Ty,
}

impl prism_rtl::Job<Text> for ShowTyQ {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(start_zonk(st.clone(), t.clone()), move |zonk_21514: Ty| match zonk_21514 {
            Ty::TyCon(n, m21508_0_1) if ((&m21508_0_1).len() == 0) => prism_rtl::Turn::Finished(n.clone()),
            Ty::TyCon(n, args) => call_value(each_job(args.clone(), {
                let st = st.clone();
                Rc::new(move |p0: Ty| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        call_then(start_show_ty_q(st.clone(), a.clone()), move |show_ty_q_21599: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &show_ty_q_21599))))
                    }))
                }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_21580: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({}{})", &n, &concat(&each_21580))))),
            Ty::TySig(s, i) => call_then(start_show_ty_q(st.clone(), (*i).clone()), move |show_ty_q_21640: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &s, &show_ty_q_21640)))),
            Ty::TyArray(e) => call_then(start_show_ty_q(st.clone(), (*e).clone()), move |show_ty_q_21691: Text| {
                let inner = show_ty_q_21691;
                if crate::syntax::lexer::has_prefix(&inner, &Text::lit("[")) {
                    prism_rtl::Turn::Finished(Text::from(format!("[ {} ]", &inner)))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("[{}]", &inner)))
                }
            }),
            Ty::TyMap(k, v_) => call_then(start_show_ty_q(st.clone(), (*k).clone()), move |show_ty_q_21791: Text| call_then(start_show_ty_q(st.clone(), (*v_).clone()), move |show_ty_q_21811: Text| prism_rtl::Turn::Finished(Text::from(format!("({} ==> {})", &show_ty_q_21791, &show_ty_q_21811))))),
            Ty::TyAt(i, rw) => call_then(start_show_ty_q(st.clone(), (*i).clone()), move |show_ty_q_21847: Text| prism_rtl::Turn::Finished(Text::from(format!("@{} emit {}", &show_ty_q_21847, &show_row_in(&rw, &true))))),
            other => prism_rtl::Turn::More(Rc::new(ShowTy { st: st.clone(), t: other.clone() })),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start ShowTyQ, x`: what the function value is when passed to `@Run`.
pub fn start_show_ty_q(st: St, t: Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowTyQ { st, t })
}

/// ```prism
/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
/// ```
pub fn try_unify(st: &St, expected: &Ty, found: &Ty, span: &crate::syntax::Range) -> (bool, St) {
    let (verdict, st2) = unify_in(st, expected, found, span);
    (&verdict == &Text::lit(""), st2.clone())
}

/// The step machine of `TryUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
/// ```
pub struct TryUnify {
    pub st: St,
    pub expected: Ty,
    pub found: Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(bool, St)> for TryUnify {
    fn cycle(&self) -> prism_rtl::Turn<(bool, St)> {
        let st = &self.st;
        let expected = &self.expected;
        let found = &self.found;
        let span = &self.span;
        let expected = expected.clone();
        let found = found.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(start_unify_in(st.clone(), expected.clone(), found.clone(), span.clone()), move |unify_in_22177: (Text, St)| {
            let (verdict, st2) = unify_in_22177;
            prism_rtl::Turn::Finished((&verdict == &Text::lit(""), st2.clone()))
        })
    }
}

/// `Start TryUnify, x`: what the function value is when passed to `@Run`.
pub fn start_try_unify(st: St, expected: Ty, found: Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(bool, St)>> {
    Rc::new(TryUnify { st, expected, found, span })
}

/// ```prism
/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub fn unify_in(st: &St, expected: &Ty, found: &Ty, span: &crate::syntax::Range) -> (Text, St) {
    let e = norm_assoc(st, &walk(st, expected));
    let f = norm_assoc(st, &walk(st, found));
    if is_waiting_assoc(st, &e) || is_waiting_assoc(st, &f) {
        if &e == &f {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit(""), defer(st, &e, &f, span))
        }
    } else {
        unify_heads(st, &e, &f, span)
    }
}

/// The step machine of `UnifyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub struct UnifyIn {
    pub st: St,
    pub expected: Ty,
    pub found: Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, St)> for UnifyIn {
    fn cycle(&self) -> prism_rtl::Turn<(Text, St)> {
        let st = &self.st;
        let expected = &self.expected;
        let found = &self.found;
        let span = &self.span;
        let expected = expected.clone();
        let found = found.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(start_walk(st.clone(), expected.clone()), move |walk_22467: Ty| call_then(start_norm_assoc(st.clone(), walk_22467), move |norm_assoc_22452: Ty| {
            let e = norm_assoc_22452;
            call_then(start_walk(st.clone(), found.clone()), move |walk_22513: Ty| call_then(start_norm_assoc(st.clone(), walk_22513), move |norm_assoc_22498: Ty| {
                let f = norm_assoc_22498;
                call_then(start_is_waiting_assoc(st.clone(), e.clone()), move |is_waiting_assoc_22537: bool| if is_waiting_assoc_22537 || is_waiting_assoc(&st, &f) {
                    if &e == &f {
                        prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit(""), defer(&st, &e, &f, &span)))
                    }
                } else {
                    prism_rtl::Turn::More(Rc::new(UnifyHeads { st: st.clone(), e: e.clone(), f: f.clone(), span: span.clone() }))
                })
            }))
        }))
    }
}

/// `Start UnifyIn, x`: what the function value is when passed to `@Run`.
pub fn start_unify_in(st: St, expected: Ty, found: Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, St)>> {
    Rc::new(UnifyIn { st, expected, found, span })
}

/// ```prism
/// NormAssoc: unbounded fn St, Ty -> Ty
/// ```
pub fn norm_assoc(st: &St, t: &Ty) -> Ty {
    match t {
        Ty::TyAssoc(m22955_0_0, a) if (m22955_0_0 == &Text::lit("Quotient")) => match walk(st, &**a) {
            Ty::TyCon(m22991_0_0, m22991_0_1) if (&m22991_0_0 == &Text::lit("Float")) && ((&m22991_0_1).len() == 0) => t_float(),
            Ty::TyCon(n, m22991_1_1) if ((&m22991_1_1).len() == 0) => if ((&n == &Text::lit("Nat")) || (&n == &Text::lit("Int"))) || (&n == &Text::lit("U8")) {
                Ty::TySig(Text::lit("?"), Rc::new(Ty::TyCon(n.clone(), Array::new())))
            } else {
                t.clone()
            },
            _ => t.clone(),
            _ => unreachable!("no arm matched"),
        },
        other => other.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `NormAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NormAssoc: unbounded fn St, Ty -> Ty
/// ```
pub struct NormAssoc {
    pub st: St,
    pub t: Ty,
}

impl prism_rtl::Job<Ty> for NormAssoc {
    fn cycle(&self) -> prism_rtl::Turn<Ty> {
        let st = &self.st;
        let t = &self.t;
        match t {
            Ty::TyAssoc(m22955_0_0, a) if (m22955_0_0 == &Text::lit("Quotient")) => {
                let a = (**a).clone();
                let st = st.clone();
                let t = t.clone();
                call_then(start_walk(st.clone(), a.clone()), move |walk_22997: Ty| match walk_22997 {
                    Ty::TyCon(m22991_0_0, m22991_0_1) if (&m22991_0_0 == &Text::lit("Float")) && ((&m22991_0_1).len() == 0) => prism_rtl::Turn::Finished(t_float()),
                    Ty::TyCon(n, m22991_1_1) if ((&m22991_1_1).len() == 0) => if ((&n == &Text::lit("Nat")) || (&n == &Text::lit("Int"))) || (&n == &Text::lit("U8")) {
                        prism_rtl::Turn::Finished(Ty::TySig(Text::lit("?"), Rc::new(Ty::TyCon(n.clone(), Array::new()))))
                    } else {
                        prism_rtl::Turn::Finished(t.clone())
                    },
                    _ => prism_rtl::Turn::Finished(t.clone()),
                    _ => unreachable!("no arm matched"),
                })
            },
            other => prism_rtl::Turn::Finished(other.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start NormAssoc, x`: what the function value is when passed to `@Run`.
pub fn start_norm_assoc(st: St, t: Ty) -> Rc<dyn prism_rtl::Job<Ty>> {
    Rc::new(NormAssoc { st, t })
}

/// ```prism
/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
/// ```
pub fn is_waiting_assoc(st: &St, t: &Ty) -> bool {
    match t {
        Ty::TyAssoc(_, a) => is_flex_var(st, &**a),
        _ => false,
    }
}

/// The step machine of `IsWaitingAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
/// ```
pub struct IsWaitingAssoc {
    pub st: St,
    pub t: Ty,
}

impl prism_rtl::Job<bool> for IsWaitingAssoc {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st = &self.st;
        let t = &self.t;
        match t {
            Ty::TyAssoc(_, a) => prism_rtl::Turn::More(Rc::new(IsFlexVar { st: st.clone(), t: (**a).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsWaitingAssoc, x`: what the function value is when passed to `@Run`.
pub fn start_is_waiting_assoc(st: St, t: Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsWaitingAssoc { st, t })
}

/// ```prism
/// Defer: fn St, Ty, Ty, Range -> St
/// ```
pub fn defer(st: &St, e: &Ty, f: &Ty, span: &crate::syntax::Range) -> St {
    let mut this: St = st.clone();
    this.deferred = push(&this.deferred, &(e.clone(), f.clone(), span.clone()));
    this
}

/// ```prism
/// RetryDeferred: unbounded fn St -> St
/// ```
pub fn retry_deferred(st: &St) -> St {
    let waiting = st.deferred.clone();
    let cleared = {
        let mut this: St = st.clone();
        this.deferred = Array::new();
        this
    };
    run_to_end(fold_job(waiting.clone(), cleared.clone(), Rc::new(move |(p0, p1): (St, (Ty, Ty, crate::syntax::Range))| entered(once_job(move || {
        let s = p0;
        let (e, f, span) = p1;
        prism_rtl::Turn::More(Rc::new(Unify { st: s.clone(), expected: e.clone(), found: f.clone(), span: span.clone() }))
    }))) as Rc<dyn Fn((St, (Ty, Ty, crate::syntax::Range))) -> Rc<dyn prism_rtl::Job<St>>>))
}

/// The step machine of `RetryDeferred`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RetryDeferred: unbounded fn St -> St
/// ```
pub struct RetryDeferred {
    pub st: St,
}

impl prism_rtl::Job<St> for RetryDeferred {
    fn cycle(&self) -> prism_rtl::Turn<St> {
        let st = &self.st;
        let waiting = st.deferred.clone();
        let cleared = {
            let mut this: St = st.clone();
            this.deferred = Array::new();
            this
        };
        fold_job(waiting.clone(), cleared.clone(), Rc::new(move |(p0, p1): (St, (Ty, Ty, crate::syntax::Range))| entered(once_job(move || {
            let s = p0;
            let (e, f, span) = p1;
            prism_rtl::Turn::More(Rc::new(Unify { st: s.clone(), expected: e.clone(), found: f.clone(), span: span.clone() }))
        }))) as Rc<dyn Fn((St, (Ty, Ty, crate::syntax::Range))) -> Rc<dyn prism_rtl::Job<St>>>).cycle()
    }
}

/// `Start RetryDeferred, x`: what the function value is when passed to `@Run`.
pub fn start_retry_deferred(st: St) -> Rc<dyn prism_rtl::Job<St>> {
    Rc::new(RetryDeferred { st })
}

/// ```prism
/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub fn unify_heads(st: &St, e: &Ty, f: &Ty, span: &crate::syntax::Range) -> (Text, St) {
    match (e.clone(), f.clone()) {
        (Ty::TyErr, _) => (Text::lit(""), st.clone()),
        (_, Ty::TyErr) => (Text::lit(""), st.clone()),
        (Ty::TySig(m23820_2_0_0, _), Ty::TyCon(m23820_2_1_0, m23820_2_1_1)) if (&m23820_2_0_0 == &Text::lit("~")) && (&m23820_2_1_0 == &Text::lit("Prelude.Error")) && ((&m23820_2_1_1).len() == 0) => (Text::lit(""), st.clone()),
        (Ty::TyCon(m23820_3_0_0, m23820_3_0_1), Ty::TySig(m23820_3_1_0, _)) if (&m23820_3_0_0 == &Text::lit("Prelude.Error")) && ((&m23820_3_0_1).len() == 0) && (&m23820_3_1_0 == &Text::lit("~")) => (Text::lit(""), st.clone()),
        (Ty::TyFlex(a), Ty::TyFlex(b)) => if &a == &b {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit(""), merge_vars(st, &a, &b))
        },
        (Ty::TyFlex(a), t) => bind_var(st, &a, &t, span),
        (t, Ty::TyFlex(b)) => bind_var(st, &b, &t, span),
        (Ty::TyRigid(a), Ty::TyRigid(b)) => if &a == &b {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (Ty::TyQ(a), Ty::TyQ(b)) => if &a == &b {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (Ty::TyCon(a, xs), Ty::TyCon(b, ys)) => if (&a == &b) && (&len(&xs) == &len(&ys)) {
            unify_all(st, &xs, &ys, span)
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (Ty::TyFn(c1, ps, r1), Ty::TyFn(c2, qs, r2)) => if &len(&ps) == &len(&qs) {
            {
                let (v_, st2) = unify_col(st, &c1, &c2);
                if &v_ != &Text::lit("") {
                    (v_.clone(), st2.clone())
                } else {
                    unify_all(&st2, &push(&ps, &*r1), &push(&qs, &*r2), span)
                }
            }
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (Ty::TyTuple(xs), Ty::TyTuple(ys)) => if &len(&xs) == &len(&ys) {
            unify_all(st, &xs, &ys, span)
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (Ty::TyArray(x), Ty::TyArray(y)) => unify_in(st, &*x, &*y, span),
        (Ty::TyMap(k1, v1), Ty::TyMap(k2, v2)) => unify_all(st, &Array::from(vec![(*k1).clone(), (*v1).clone()]), &Array::from(vec![(*k2).clone(), (*v2).clone()]), span),
        (Ty::TySig(s1, i1), Ty::TySig(s2, i2)) => if &s1 == &s2 {
            unify_in(st, &*i1, &*i2, span)
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (Ty::TyAt(i1, r1), Ty::TyAt(i2, r2)) => {
            let (v_, st2) = unify_in(st, &*i1, &*i2, span);
            if &v_ != &Text::lit("") {
                (v_.clone(), st2.clone())
            } else {
                unify_row(&st2, &r1, &r2, span)
            }
        },
        (Ty::TyElem(r1, o1), Ty::TyElem(r2, o2)) => {
            let (v_, st2) = unify_row(st, &r1, &r2, span);
            if &v_ != &Text::lit("") {
                (v_.clone(), st2.clone())
            } else {
                unify_in(&st2, &*o1, &*o2, span)
            }
        },
        (Ty::TyElemAny(r1), Ty::TyElemAny(r2)) => unify_row(st, &r1, &r2, span),
        (Ty::TyAssoc(n1, a1), Ty::TyAssoc(n2, a2)) => if &n1 == &n2 {
            unify_in(st, &*a1, &*a2, span)
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (Ty::TyAny(xs), Ty::TyAny(ys)) => if &sort_texts(&xs) == &sort_texts(&ys) {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        _ => (Text::lit("mismatch"), st.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `UnifyHeads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub struct UnifyHeads {
    pub st: St,
    pub e: Ty,
    pub f: Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, St)> for UnifyHeads {
    fn cycle(&self) -> prism_rtl::Turn<(Text, St)> {
        let st = &self.st;
        let e = &self.e;
        let f = &self.f;
        let span = &self.span;
        match (e.clone(), f.clone()) {
            (Ty::TyErr, _) => prism_rtl::Turn::Finished((Text::lit(""), st.clone())),
            (_, Ty::TyErr) => prism_rtl::Turn::Finished((Text::lit(""), st.clone())),
            (Ty::TySig(m23820_2_0_0, _), Ty::TyCon(m23820_2_1_0, m23820_2_1_1)) if (&m23820_2_0_0 == &Text::lit("~")) && (&m23820_2_1_0 == &Text::lit("Prelude.Error")) && ((&m23820_2_1_1).len() == 0) => prism_rtl::Turn::Finished((Text::lit(""), st.clone())),
            (Ty::TyCon(m23820_3_0_0, m23820_3_0_1), Ty::TySig(m23820_3_1_0, _)) if (&m23820_3_0_0 == &Text::lit("Prelude.Error")) && ((&m23820_3_0_1).len() == 0) && (&m23820_3_1_0 == &Text::lit("~")) => prism_rtl::Turn::Finished((Text::lit(""), st.clone())),
            (Ty::TyFlex(a), Ty::TyFlex(b)) => if &a == &b {
                prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit(""), merge_vars(st, &a, &b)))
            },
            (Ty::TyFlex(a), t) => prism_rtl::Turn::More(Rc::new(BindVar { st: st.clone(), n: a.clone(), t: t.clone(), span: span.clone() })),
            (t, Ty::TyFlex(b)) => prism_rtl::Turn::More(Rc::new(BindVar { st: st.clone(), n: b.clone(), t: t.clone(), span: span.clone() })),
            (Ty::TyRigid(a), Ty::TyRigid(b)) => if &a == &b {
                prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            (Ty::TyQ(a), Ty::TyQ(b)) => if &a == &b {
                prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            (Ty::TyCon(a, xs), Ty::TyCon(b, ys)) => if (&a == &b) && (&len(&xs) == &len(&ys)) {
                prism_rtl::Turn::More(Rc::new(UnifyAll { st: st.clone(), xs: xs.clone(), ys: ys.clone(), span: span.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            (Ty::TyFn(c1, ps, r1), Ty::TyFn(c2, qs, r2)) => if &len(&ps) == &len(&qs) {
                {
                    let span = span.clone();
                    let st = st.clone();
                    call_then(start_unify_col(st.clone(), c1.clone(), c2.clone()), move |unify_col_24674: (Text, St)| {
                        let (v_, st2) = unify_col_24674;
                        if &v_ != &Text::lit("") {
                            prism_rtl::Turn::Finished((v_.clone(), st2.clone()))
                        } else {
                            prism_rtl::Turn::More(Rc::new(UnifyAll { st: st2.clone(), xs: push(&ps, &*r1), ys: push(&qs, &*r2), span: span.clone() }))
                        }
                    })
                }
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            (Ty::TyTuple(xs), Ty::TyTuple(ys)) => if &len(&xs) == &len(&ys) {
                prism_rtl::Turn::More(Rc::new(UnifyAll { st: st.clone(), xs: xs.clone(), ys: ys.clone(), span: span.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            (Ty::TyArray(x), Ty::TyArray(y)) => prism_rtl::Turn::More(Rc::new(UnifyIn { st: st.clone(), expected: (*x).clone(), found: (*y).clone(), span: span.clone() })),
            (Ty::TyMap(k1, v1), Ty::TyMap(k2, v2)) => prism_rtl::Turn::More(Rc::new(UnifyAll { st: st.clone(), xs: Array::from(vec![(*k1).clone(), (*v1).clone()]), ys: Array::from(vec![(*k2).clone(), (*v2).clone()]), span: span.clone() })),
            (Ty::TySig(s1, i1), Ty::TySig(s2, i2)) => if &s1 == &s2 {
                prism_rtl::Turn::More(Rc::new(UnifyIn { st: st.clone(), expected: (*i1).clone(), found: (*i2).clone(), span: span.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            (Ty::TyAt(i1, r1), Ty::TyAt(i2, r2)) => {
                let span = span.clone();
                let st = st.clone();
                call_then(start_unify_in(st.clone(), (*i1).clone(), (*i2).clone(), span.clone()), move |unify_in_25258: (Text, St)| {
                    let (v_, st2) = unify_in_25258;
                    if &v_ != &Text::lit("") {
                        prism_rtl::Turn::Finished((v_.clone(), st2.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(UnifyRow { st: st2.clone(), a0: r1.clone(), b0: r2.clone(), span: span.clone() }))
                    }
                })
            },
            (Ty::TyElem(r1, o1), Ty::TyElem(r2, o2)) => {
                let span = span.clone();
                let st = st.clone();
                call_then(start_unify_row(st.clone(), r1.clone(), r2.clone(), span.clone()), move |unify_row_25426: (Text, St)| {
                    let (v_, st2) = unify_row_25426;
                    if &v_ != &Text::lit("") {
                        prism_rtl::Turn::Finished((v_.clone(), st2.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(UnifyIn { st: st2.clone(), expected: (*o1).clone(), found: (*o2).clone(), span: span.clone() }))
                    }
                })
            },
            (Ty::TyElemAny(r1), Ty::TyElemAny(r2)) => prism_rtl::Turn::More(Rc::new(UnifyRow { st: st.clone(), a0: r1.clone(), b0: r2.clone(), span: span.clone() })),
            (Ty::TyAssoc(n1, a1), Ty::TyAssoc(n2, a2)) => if &n1 == &n2 {
                prism_rtl::Turn::More(Rc::new(UnifyIn { st: st.clone(), expected: (*a1).clone(), found: (*a2).clone(), span: span.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            (Ty::TyAny(xs), Ty::TyAny(ys)) => if &sort_texts(&xs) == &sort_texts(&ys) {
                prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            _ => prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone())),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start UnifyHeads, x`: what the function value is when passed to `@Run`.
pub fn start_unify_heads(st: St, e: Ty, f: Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, St)>> {
    Rc::new(UnifyHeads { st, e, f, span })
}

/// ```prism
/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
/// ```
pub fn unify_all(st: &St, xs: &Array<Ty>, ys: &Array<Ty>, span: &crate::syntax::Range) -> (Text, St) {
    run_to_end(fold_job(crate::check::errors::range0(&len(xs)), (Text::lit(""), st.clone()), {
        let xs = xs.clone();
        let ys = ys.clone();
        let span = span.clone();
        Rc::new(move |(p0, p1): ((Text, St), Nat)| {
            let xs = xs.clone();
            let ys = ys.clone();
            let span = span.clone();
            entered(once_job(move || {
                let (v_, s) = p0;
                let i = p1;
                if &v_ != &Text::lit("") {
                    prism_rtl::Turn::Finished((v_.clone(), s.clone()))
                } else {
                    prism_rtl::Turn::More(Rc::new(UnifyIn { st: s.clone(), expected: or(&index(&xs, &i), &Ty::TyErr), found: or(&index(&ys, &i), &Ty::TyErr), span: span.clone() }))
                }
            }))
        }) as Rc<dyn Fn(((Text, St), Nat)) -> Rc<dyn prism_rtl::Job<(Text, St)>>>
    }))
}

/// The step machine of `UnifyAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
/// ```
pub struct UnifyAll {
    pub st: St,
    pub xs: Array<Ty>,
    pub ys: Array<Ty>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, St)> for UnifyAll {
    fn cycle(&self) -> prism_rtl::Turn<(Text, St)> {
        let st = &self.st;
        let xs = &self.xs;
        let ys = &self.ys;
        let span = &self.span;
        fold_job(crate::check::errors::range0(&len(xs)), (Text::lit(""), st.clone()), {
            let xs = xs.clone();
            let ys = ys.clone();
            let span = span.clone();
            Rc::new(move |(p0, p1): ((Text, St), Nat)| {
                let xs = xs.clone();
                let ys = ys.clone();
                let span = span.clone();
                entered(once_job(move || {
                    let (v_, s) = p0;
                    let i = p1;
                    if &v_ != &Text::lit("") {
                        prism_rtl::Turn::Finished((v_.clone(), s.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(UnifyIn { st: s.clone(), expected: or(&index(&xs, &i), &Ty::TyErr), found: or(&index(&ys, &i), &Ty::TyErr), span: span.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(((Text, St), Nat)) -> Rc<dyn prism_rtl::Job<(Text, St)>>>
        }).cycle()
    }
}

/// `Start UnifyAll, x`: what the function value is when passed to `@Run`.
pub fn start_unify_all(st: St, xs: Array<Ty>, ys: Array<Ty>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, St)>> {
    Rc::new(UnifyAll { st, xs, ys, span })
}

/// ```prism
/// MergeVars: fn St, Nat, Nat -> St
/// ```
pub fn merge_vars(st: &St, a: &Nat, b: &Nat) -> St {
    let ia = info_of(st, a);
    let ib = info_of(st, b);
    let merged = VInfo { plain: ia.plain || ib.plain, level: min(&ia.level, &ib.level), name: if &ib.name == &Text::lit("") { ia.name.clone() } else { ib.name.clone() } };
    let mut this: St = st.clone();
    this.tys = insert(&this.tys, a, &Ty::TyFlex(b.clone()));
    this.infos = insert(&this.infos, b, &merged);
    this
}

/// ```prism
/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
/// ```
pub fn bind_var(st: &St, n: &Nat, t: &Ty, span: &crate::syntax::Range) -> (Text, St) {
    let info = info_of(st, n);
    let stack = stack_of(st, t);
    if has_nat(&free_vars(st, t), n) {
        (Text::lit("reported"), err(st, &Text::lit("occurs"), span, &Text::from(format!("`t{}` would contain itself: `t{} = {}`", n, n, &show_ty(st, t)))))
    } else {
        if info.plain && (&stack != &Text::lit("")) {
            if &info.name != &Text::lit("") {
                {
                    let marks = marks_of(&info.name);
                    let whole = Text::from(format!("{}{}", &marks, &show_ty_in(st, &zonk(st, t), &true)));
                    let at_ = or(&get(&st.binder_at, n), span);
                    let st2 = err_fix(st, &Text::lit("mark-stack"), &at_, &Text::from(format!("`{}` has type `{}`, whose stack is `{}{}`; the name shows `{}`", &info.name, &whole, &marks, &stack, &marks)), &Text::from(format!("rename to `{}{}{}`", &marks, &stack, &crate::syntax::lexer::drop_prefix(&info.name, &marks))));
                    (Text::lit(""), {
                        let mut this: St = lower_levels(&st2, &append(&free_vars(&st2, t), &free_col_vars(&st2, t)), &info.level);
                        this.tys = insert(&this.tys, n, t);
                        this
                    })
                }
            } else {
                (Text::lit("mismatch"), st.clone())
            }
        } else {
            {
                let lowered = lower_levels(st, &append(&free_vars(st, t), &free_col_vars(st, t)), &info.level);
                (Text::lit(""), {
                    let mut this: St = lowered.clone();
                    this.tys = insert(&this.tys, n, t);
                    this
                })
            }
        }
    }
}

/// The step machine of `BindVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
/// ```
pub struct BindVar {
    pub st: St,
    pub n: Nat,
    pub t: Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, St)> for BindVar {
    fn cycle(&self) -> prism_rtl::Turn<(Text, St)> {
        let st = &self.st;
        let n = &self.n;
        let t = &self.t;
        let span = &self.span;
        let info = info_of(st, n);
        let n = n.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_stack_of(st.clone(), t.clone()), move |stack_of_26672: Text| {
            let stack = stack_of_26672;
            call_then(start_free_vars(st.clone(), t.clone()), move |free_vars_26701: Array<Nat>| if has_nat(&free_vars_26701, &n) {
                call_then(start_show_ty(st.clone(), t.clone()), move |show_ty_26807: Text| prism_rtl::Turn::Finished((Text::lit("reported"), err(&st, &Text::lit("occurs"), &span, &Text::from(format!("`t{}` would contain itself: `t{} = {}`", &n, &n, &show_ty_26807))))))
            } else {
                if info.plain && (&stack != &Text::lit("")) {
                    if &info.name != &Text::lit("") {
                        {
                            let marks = marks_of(&info.name);
                            call_then(start_zonk(st.clone(), t.clone()), move |zonk_26984: Ty| call_then(start_show_ty_in(st.clone(), zonk_26984, true), move |show_ty_in_26970: Text| {
                                let whole = Text::from(format!("{}{}", &marks, &show_ty_in_26970));
                                let at_ = or(&get(&st.binder_at, &n), &span);
                                let st2 = err_fix(&st, &Text::lit("mark-stack"), &at_, &Text::from(format!("`{}` has type `{}`, whose stack is `{}{}`; the name shows `{}`", &info.name, &whole, &marks, &stack, &marks)), &Text::from(format!("rename to `{}{}{}`", &marks, &stack, &crate::syntax::lexer::drop_prefix(&info.name, &marks))));
                                prism_rtl::Turn::Finished((Text::lit(""), {
                                    let mut this: St = lower_levels(&st2, &append(&free_vars(&st2, &t), &free_col_vars(&st2, &t)), &info.level);
                                    this.tys = insert(&this.tys, &n, &t);
                                    this
                                }))
                            }))
                        }
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
                    }
                } else {
                    call_then(start_free_vars(st.clone(), t.clone()), move |free_vars_27649: Array<Nat>| call_then(start_free_col_vars(st.clone(), t.clone()), move |free_col_vars_27667: Array<Nat>| {
                        let lowered = lower_levels(&st, &append(&free_vars_27649, &free_col_vars_27667), &info.level);
                        prism_rtl::Turn::Finished((Text::lit(""), {
                            let mut this: St = lowered.clone();
                            this.tys = insert(&this.tys, &n, &t);
                            this
                        }))
                    }))
                }
            })
        })
    }
}

/// `Start BindVar, x`: what the function value is when passed to `@Run`.
pub fn start_bind_var(st: St, n: Nat, t: Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, St)>> {
    Rc::new(BindVar { st, n, t, span })
}

/// ```prism
/// MarksOf: fn Text -> Text
/// ```
pub fn marks_of(name: &Text) -> Text {
    let c = {
        let mut this: Cursor = front(name);
        while let Some((_, next)) = step(&this) {
            if !is_mark_char(&crate::syntax::lexer::char_at(&this)) {
                break;
            }
            this = next.clone();
        }
        this
    };
    before(&c)
}

/// ```prism
/// IsMarkChar: fn Text -> Bool
/// ```
pub fn is_mark_char(c: &Text) -> bool {
    (((((c == &Text::lit("$")) || (c == &Text::lit("!"))) || (c == &Text::lit("@"))) || (c == &Text::lit("?"))) || (c == &Text::lit("~"))) || (c == &Text::lit("&"))
}

/// ```prism
/// LowerLevels: fn St, [Nat], Nat -> St
/// ```
pub fn lower_levels(st: &St, vs: &Array<Nat>, level: &Nat) -> St {
    fold(vs, st, &(|s: &St, v_: &Nat| lower_one(s, v_, level)))
}

/// ```prism
/// LowerOne: fn St, Nat, Nat -> St
/// ```
pub fn lower_one(s: &St, v_: &Nat, level: &Nat) -> St {
    let i = info_of(s, v_);
    if &i.level <= level {
        s.clone()
    } else {
        {
            let mut this: St = s.clone();
            this.infos = insert(&this.infos, v_, &VInfo { plain: i.plain, level: level.clone(), name: i.name.clone() });
            this
        }
    }
}

/// ```prism
/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
/// ```
pub fn unify_row(st: &St, a0: &Rw, b0: &Rw, span: &crate::syntax::Range) -> (Text, St) {
    let a = walk_row(st, a0);
    let b = walk_row(st, b0);
    let only_a = minus_texts(&a.fams, &b.fams);
    let only_b = minus_texts(&b.fams, &a.fams);
    match (a.tail.clone(), b.tail.clone()) {
        (Tail::TlClosed, Tail::TlClosed) => if (&len(&only_a) == &Nat::from(0u32)) && (&len(&only_b) == &Nat::from(0u32)) {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (Tail::TlFlex(x), Tail::TlFlex(y)) => if &x == &y {
            if (&len(&only_a) == &Nat::from(0u32)) && (&len(&only_b) == &Nat::from(0u32)) {
                (Text::lit(""), st.clone())
            } else {
                (Text::lit("mismatch"), st.clone())
            }
        } else {
            {
                let lacking = union_texts(&union_texts(&lacks_of(st, &x), &lacks_of(st, &y)), &union_texts(&a.fams, &b.fams));
                let (fresh, st2) = fresh_row(st, &lacking);
                let (v1, st3) = bind_row(&st2, &x, &Rw { fams: only_b.clone(), minus: Array::new(), tail: fresh.tail.clone() }, span);
                if &v1 != &Text::lit("") {
                    (v1.clone(), st3.clone())
                } else {
                    bind_row(&st3, &y, &Rw { fams: only_a.clone(), minus: Array::new(), tail: fresh.tail.clone() }, span)
                }
            }
        },
        (Tail::TlFlex(x), other) => if &len(&only_a) == &Nat::from(0u32) {
            bind_row(st, &x, &Rw { fams: only_b.clone(), minus: b.minus.clone(), tail: other.clone() }, span)
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (other, Tail::TlFlex(y)) => if &len(&only_b) == &Nat::from(0u32) {
            bind_row(st, &y, &Rw { fams: only_a.clone(), minus: a.minus.clone(), tail: other.clone() }, span)
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (Tail::TlRigid(x), Tail::TlRigid(y)) => if ((&x == &y) && (&len(&only_a) == &Nat::from(0u32))) && (&len(&only_b) == &Nat::from(0u32)) {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (Tail::TlQ(x), Tail::TlQ(y)) => if ((&x == &y) && (&len(&only_a) == &Nat::from(0u32))) && (&len(&only_b) == &Nat::from(0u32)) {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        _ => (Text::lit("mismatch"), st.clone()),
    }
}

/// The step machine of `UnifyRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
/// ```
pub struct UnifyRow {
    pub st: St,
    pub a0: Rw,
    pub b0: Rw,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, St)> for UnifyRow {
    fn cycle(&self) -> prism_rtl::Turn<(Text, St)> {
        let st = &self.st;
        let a0 = &self.a0;
        let b0 = &self.b0;
        let span = &self.span;
        let a0 = a0.clone();
        let b0 = b0.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(start_walk_row(st.clone(), a0.clone()), move |walk_row_28709: Rw| {
            let a = walk_row_28709;
            call_then(start_walk_row(st.clone(), b0.clone()), move |walk_row_28736: Rw| {
                let b = walk_row_28736;
                let only_a = minus_texts(&a.fams, &b.fams);
                let only_b = minus_texts(&b.fams, &a.fams);
                match (a.tail.clone(), b.tail.clone()) {
                    (Tail::TlClosed, Tail::TlClosed) => if (&len(&only_a) == &Nat::from(0u32)) && (&len(&only_b) == &Nat::from(0u32)) {
                        prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
                    },
                    (Tail::TlFlex(x), Tail::TlFlex(y)) => if &x == &y {
                        if (&len(&only_a) == &Nat::from(0u32)) && (&len(&only_b) == &Nat::from(0u32)) {
                            prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
                        } else {
                            prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
                        }
                    } else {
                        {
                            let lacking = union_texts(&union_texts(&lacks_of(&st, &x), &lacks_of(&st, &y)), &union_texts(&a.fams, &b.fams));
                            let (fresh, st2) = fresh_row(&st, &lacking);
                            call_then(start_bind_row(st2.clone(), x.clone(), Rw { fams: only_b.clone(), minus: Array::new(), tail: fresh.tail.clone() }, span.clone()), move |bind_row_29350: (Text, St)| {
                                let (v1, st3) = bind_row_29350;
                                if &v1 != &Text::lit("") {
                                    prism_rtl::Turn::Finished((v1.clone(), st3.clone()))
                                } else {
                                    prism_rtl::Turn::More(Rc::new(BindRow { st: st3.clone(), n: y.clone(), rw: Rw { fams: only_a.clone(), minus: Array::new(), tail: fresh.tail.clone() }, span: span.clone() }))
                                }
                            })
                        }
                    },
                    (Tail::TlFlex(x), other) => if &len(&only_a) == &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(BindRow { st: st.clone(), n: x.clone(), rw: Rw { fams: only_b.clone(), minus: b.minus.clone(), tail: other.clone() }, span: span.clone() }))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
                    },
                    (other, Tail::TlFlex(y)) => if &len(&only_b) == &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(BindRow { st: st.clone(), n: y.clone(), rw: Rw { fams: only_a.clone(), minus: a.minus.clone(), tail: other.clone() }, span: span.clone() }))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
                    },
                    (Tail::TlRigid(x), Tail::TlRigid(y)) => if ((&x == &y) && (&len(&only_a) == &Nat::from(0u32))) && (&len(&only_b) == &Nat::from(0u32)) {
                        prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
                    },
                    (Tail::TlQ(x), Tail::TlQ(y)) => if ((&x == &y) && (&len(&only_a) == &Nat::from(0u32))) && (&len(&only_b) == &Nat::from(0u32)) {
                        prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
                    },
                    _ => prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone())),
                }
            })
        })
    }
}

/// `Start UnifyRow, x`: what the function value is when passed to `@Run`.
pub fn start_unify_row(st: St, a0: Rw, b0: Rw, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, St)>> {
    Rc::new(UnifyRow { st, a0, b0, span })
}

/// ```prism
/// AskField: fn St, Ty, Text, Ty, Range, [Text] -> St
/// ```
pub fn ask_field(st: &St, recv: &Ty, field: &Text, result: &Ty, span: &crate::syntax::Range, owners: &Array<Text>) -> St {
    let mut this: St = st.clone();
    this.field_qs = push(&this.field_qs, &FieldQ { recv: recv.clone(), field: field.clone(), result: result.clone(), span: span.clone(), file: this.file.clone(), owners: owners.clone() });
    this
}

/// ```prism
/// AskLayer: fn St, Ty, Range, Text -> St
/// ```
pub fn ask_layer(st: &St, t: &Ty, span: &crate::syntax::Range, fname: &Text) -> St {
    let mut this: St = st.clone();
    this.layer_qs = push(&this.layer_qs, &(t.clone(), span.clone(), fname.clone()));
    this
}

/// ```prism
/// LayerQuestions: unbounded fn St -> St
/// ```
pub fn layer_questions(st: &St) -> St {
    let qs = st.layer_qs.clone();
    let cleared = {
        let mut this: St = st.clone();
        this.layer_qs = Array::new();
        this
    };
    run_to_end(fold_job(qs.clone(), cleared.clone(), Rc::new(move |(p0, p1): (St, (Ty, crate::syntax::Range, Text))| entered(once_job(move || {
        let s = p0;
        let (t, span, fname) = p1;
        call_then(start_head_sigil(s.clone(), t.clone()), move |head_sigil_31333: Text| {
            let h = head_sigil_31333;
            call_then(start_is_free_headed(s.clone(), t.clone()), move |is_free_headed_31360: bool| if (is_free_headed_31360 || (&h == &Text::lit("$"))) || (&h == &Text::lit("!")) {
                prism_rtl::Turn::Finished(err_fix(&s, &Text::lit("layer-unknown"), &span, &Text::from(format!("the layer of this argument to `{}` is not known here", &fname)), &Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
            } else {
                prism_rtl::Turn::Finished(s.clone())
            })
        })
    }))) as Rc<dyn Fn((St, (Ty, crate::syntax::Range, Text))) -> Rc<dyn prism_rtl::Job<St>>>))
}

/// The step machine of `LayerQuestions`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LayerQuestions: unbounded fn St -> St
/// ```
pub struct LayerQuestions {
    pub st: St,
}

impl prism_rtl::Job<St> for LayerQuestions {
    fn cycle(&self) -> prism_rtl::Turn<St> {
        let st = &self.st;
        let qs = st.layer_qs.clone();
        let cleared = {
            let mut this: St = st.clone();
            this.layer_qs = Array::new();
            this
        };
        fold_job(qs.clone(), cleared.clone(), Rc::new(move |(p0, p1): (St, (Ty, crate::syntax::Range, Text))| entered(once_job(move || {
            let s = p0;
            let (t, span, fname) = p1;
            call_then(start_head_sigil(s.clone(), t.clone()), move |head_sigil_31333: Text| {
                let h = head_sigil_31333;
                call_then(start_is_free_headed(s.clone(), t.clone()), move |is_free_headed_31360: bool| if (is_free_headed_31360 || (&h == &Text::lit("$"))) || (&h == &Text::lit("!")) {
                    prism_rtl::Turn::Finished(err_fix(&s, &Text::lit("layer-unknown"), &span, &Text::from(format!("the layer of this argument to `{}` is not known here", &fname)), &Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
                } else {
                    prism_rtl::Turn::Finished(s.clone())
                })
            })
        }))) as Rc<dyn Fn((St, (Ty, crate::syntax::Range, Text))) -> Rc<dyn prism_rtl::Job<St>>>).cycle()
    }
}

/// `Start LayerQuestions, x`: what the function value is when passed to `@Run`.
pub fn start_layer_questions(st: St) -> Rc<dyn prism_rtl::Job<St>> {
    Rc::new(LayerQuestions { st })
}

/// ```prism
/// NameRow: fn St, Tail, Text -> St
/// ```
pub fn name_row(st: &St, tail1: &Tail, text2: &Text) -> St {
    match (tail1, text2) {
        (Tail::TlFlex(n), q) => {
            let mut this: St = st.clone();
            this.row_names = insert(&this.row_names, n, q);
            this
        },
        (_, _) => st.clone(),
    }
}

/// ```prism
/// RowName: fn St, Nat -> Text
/// ```
pub fn row_name(st: &St, n: &Nat) -> Text {
    or(&get(&st.row_names, n), &Text::from(format!("r{}", n)))
}

/// ```prism
/// LacksOf: fn St, Nat -> [Text]
/// ```
pub fn lacks_of(st: &St, n: &Nat) -> Array<Text> {
    or(&get(&st.lacks, n), &Array::new())
}

/// ```prism
/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
/// ```
pub fn bind_row(st: &St, n: &Nat, rw: &Rw, span: &crate::syntax::Range) -> (Text, St) {
    let bad = inter_texts(&lacks_of(st, n), &rw.fams);
    if &len(&bad) > &Nat::from(0u32) {
        {
            let fam = or(&index(&bad, &Nat::from(0u32)), &Text::lit(""));
            (Text::lit("reported"), err_fix(st, &Text::lit("row-lacks"), span, &Text::from(format!("`{} | {}.*` promises `{}` has no `{}` tags", &row_name(st, n), &fam, &row_name(st, n), &fam)), &Text::from(format!("answer the `{}` tags before this point, or widen the row", &fam))))
        }
    } else {
        {
            let st2 = match &rw.tail {
                Tail::TlFlex(m) => {
                    let mut this: St = st.clone();
                    this.lacks = insert(&this.lacks, m, &union_texts(&lacks_of(st, m), &lacks_of(st, n)));
                    this
                },
                _ => st.clone(),
            };
            (Text::lit(""), {
                let mut this: St = st2.clone();
                this.rows = insert(&this.rows, n, rw);
                this
            })
        }
    }
}

/// The step machine of `BindRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
/// ```
pub struct BindRow {
    pub st: St,
    pub n: Nat,
    pub rw: Rw,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, St)> for BindRow {
    fn cycle(&self) -> prism_rtl::Turn<(Text, St)> {
        let st = &self.st;
        let n = &self.n;
        let rw = &self.rw;
        let span = &self.span;
        let bad = inter_texts(&lacks_of(st, n), &rw.fams);
        if &len(&bad) > &Nat::from(0u32) {
            {
                let fam = or(&index(&bad, &Nat::from(0u32)), &Text::lit(""));
                prism_rtl::Turn::Finished((Text::lit("reported"), err_fix(st, &Text::lit("row-lacks"), span, &Text::from(format!("`{} | {}.*` promises `{}` has no `{}` tags", &row_name(st, n), &fam, &row_name(st, n), &fam)), &Text::from(format!("answer the `{}` tags before this point, or widen the row", &fam)))))
            }
        } else {
            {
                let st2 = match &rw.tail {
                    Tail::TlFlex(m) => {
                        let mut this: St = st.clone();
                        this.lacks = insert(&this.lacks, m, &union_texts(&lacks_of(st, m), &lacks_of(st, n)));
                        this
                    },
                    _ => st.clone(),
                };
                prism_rtl::Turn::Finished((Text::lit(""), {
                    let mut this: St = st2.clone();
                    this.rows = insert(&this.rows, n, rw);
                    this
                }))
            }
        }
    }
}

/// `Start BindRow, x`: what the function value is when passed to `@Run`.
pub fn start_bind_row(st: St, n: Nat, rw: Rw, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, St)>> {
    Rc::new(BindRow { st, n, rw, span })
}

/// ```prism
/// Mono: fn Ty -> Scheme
/// ```
pub fn mono(t: &Ty) -> Scheme {
    Scheme { qs: Array::new(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: t.clone() }
}

/// ```prism
/// SubstQ: unbounded fn Inst, Ty -> Ty
/// ```
pub fn subst_q(m: &Inst, t: &Ty) -> Ty {
    match t {
        Ty::TyQ(n) => or(&get(&m.tys, n), &Ty::TyQ(n.clone())),
        Ty::TyCon(n, args) => Ty::TyCon(n.clone(), run_to_end(each_job(args.clone(), {
            let m = m.clone();
            Rc::new(move |p0: Ty| {
                let m = m.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(SubstQ { m: m.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
        }))),
        Ty::TyFn(c, ps, res) => Ty::TyFn(subst_col(m, c), run_to_end(each_job(ps.clone(), {
            let m = m.clone();
            Rc::new(move |p0: Ty| {
                let m = m.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(SubstQ { m: m.clone(), t: p_.clone() }))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
        })), Rc::new(subst_q(m, &**res))),
        Ty::TyTuple(ts) => Ty::TyTuple(run_to_end(each_job(ts.clone(), {
            let m = m.clone();
            Rc::new(move |p0: Ty| {
                let m = m.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(SubstQ { m: m.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
        }))),
        Ty::TyArray(e) => Ty::TyArray(Rc::new(subst_q(m, &**e))),
        Ty::TyMap(k, v_) => Ty::TyMap(Rc::new(subst_q(m, &**k)), Rc::new(subst_q(m, &**v_))),
        Ty::TySig(s, i) => Ty::TySig(s.clone(), Rc::new(subst_q(m, &**i))),
        Ty::TyAt(i, rw) => Ty::TyAt(Rc::new(subst_q(m, &**i)), subst_row_q(m, rw)),
        Ty::TyElem(rw, o) => Ty::TyElem(subst_row_q(m, rw), Rc::new(subst_q(m, &**o))),
        Ty::TyElemAny(rw) => Ty::TyElemAny(subst_row_q(m, rw)),
        Ty::TyAssoc(n, a) => Ty::TyAssoc(n.clone(), Rc::new(subst_q(m, &**a))),
        other => other.clone(),
    }
}

/// The step machine of `SubstQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubstQ: unbounded fn Inst, Ty -> Ty
/// ```
pub struct SubstQ {
    pub m: Inst,
    pub t: Ty,
}

impl prism_rtl::Job<Ty> for SubstQ {
    fn cycle(&self) -> prism_rtl::Turn<Ty> {
        let m = &self.m;
        let t = &self.t;
        match t {
            Ty::TyQ(n) => prism_rtl::Turn::Finished(or(&get(&m.tys, n), &Ty::TyQ(n.clone()))),
            Ty::TyCon(n, args) => {
                let args = args.clone();
                let m = m.clone();
                let n = n.clone();
                call_value(each_job(args.clone(), {
                    let m = m.clone();
                    Rc::new(move |p0: Ty| {
                        let m = m.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(SubstQ { m: m.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
                }), move |each_33493: Array<Ty>| prism_rtl::Turn::Finished(Ty::TyCon(n.clone(), each_33493)))
            },
            Ty::TyFn(c, ps, res) => {
                let c = c.clone();
                let m = m.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(each_job(ps.clone(), {
                    let m = m.clone();
                    Rc::new(move |p0: Ty| {
                        let m = m.clone();
                        entered(once_job(move || {
                            let p_ = p0;
                            prism_rtl::Turn::More(Rc::new(SubstQ { m: m.clone(), t: p_.clone() }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
                }), move |each_33566: Array<Ty>| call_then(start_subst_q(m.clone(), res.clone()), move |subst_q_33595: Ty| prism_rtl::Turn::Finished(Ty::TyFn(subst_col(&m, &c), each_33566, Rc::new(subst_q_33595)))))
            },
            Ty::TyTuple(ts) => {
                let m = m.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let m = m.clone();
                    Rc::new(move |p0: Ty| {
                        let m = m.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(SubstQ { m: m.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
                }), move |each_33635: Array<Ty>| prism_rtl::Turn::Finished(Ty::TyTuple(each_33635)))
            },
            Ty::TyArray(e) => {
                let e = (**e).clone();
                let m = m.clone();
                call_then(start_subst_q(m.clone(), e.clone()), move |subst_q_33686: Ty| prism_rtl::Turn::Finished(Ty::TyArray(Rc::new(subst_q_33686))))
            },
            Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let m = m.clone();
                let v_ = (**v_).clone();
                call_then(start_subst_q(m.clone(), k.clone()), move |subst_q_33722: Ty| call_then(start_subst_q(m.clone(), v_.clone()), move |subst_q_33737: Ty| prism_rtl::Turn::Finished(Ty::TyMap(Rc::new(subst_q_33722), Rc::new(subst_q_33737)))))
            },
            Ty::TySig(s, i) => {
                let i = (**i).clone();
                let m = m.clone();
                let s = s.clone();
                call_then(start_subst_q(m.clone(), i.clone()), move |subst_q_33776: Ty| prism_rtl::Turn::Finished(Ty::TySig(s.clone(), Rc::new(subst_q_33776))))
            },
            Ty::TyAt(i, rw) => {
                let i = (**i).clone();
                let m = m.clone();
                let rw = rw.clone();
                call_then(start_subst_q(m.clone(), i.clone()), move |subst_q_33811: Ty| prism_rtl::Turn::Finished(Ty::TyAt(Rc::new(subst_q_33811), subst_row_q(&m, &rw))))
            },
            Ty::TyElem(rw, o) => {
                let m = m.clone();
                let o = (**o).clone();
                let rw = rw.clone();
                call_then(start_subst_q(m.clone(), o.clone()), move |subst_q_33888: Ty| prism_rtl::Turn::Finished(Ty::TyElem(subst_row_q(&m, &rw), Rc::new(subst_q_33888))))
            },
            Ty::TyElemAny(rw) => prism_rtl::Turn::Finished(Ty::TyElemAny(subst_row_q(m, rw))),
            Ty::TyAssoc(n, a) => {
                let a = (**a).clone();
                let m = m.clone();
                let n = n.clone();
                call_then(start_subst_q(m.clone(), a.clone()), move |subst_q_33977: Ty| prism_rtl::Turn::Finished(Ty::TyAssoc(n.clone(), Rc::new(subst_q_33977))))
            },
            other => prism_rtl::Turn::Finished(other.clone()),
        }
    }
}

/// `Start SubstQ, x`: what the function value is when passed to `@Run`.
pub fn start_subst_q(m: Inst, t: Ty) -> Rc<dyn prism_rtl::Job<Ty>> {
    Rc::new(SubstQ { m, t })
}

/// ```prism
/// SubstRowQ: fn Inst, Rw -> Rw
/// ```
pub fn subst_row_q(m: &Inst, rw: &Rw) -> Rw {
    match &rw.tail {
        Tail::TlQ(n) => match get(&m.rows, n) {
            Some(t) => Rw { fams: rw.fams.clone(), minus: rw.minus.clone(), tail: t.clone() },
            None => rw.clone(),
        },
        _ => rw.clone(),
    }
}

/// ```prism
/// SubstCol: fn Inst, Col -> Col
/// ```
pub fn subst_col(m: &Inst, col1: &Col) -> Col {
    match col1 {
        Col::CQ(n) => or(&get(&m.cols, n), &Col::CQ(n.clone())),
        c => c.clone(),
    }
}

/// ```prism
/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
/// ```
pub fn instantiate(st: &St, sc: &Scheme, span: &crate::syntax::Range) -> (Ty, St) {
    let (t, st2, _) = instantiate_with(st, sc, span, &Array::new());
    (t.clone(), st2.clone())
}

/// The step machine of `Instantiate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
/// ```
pub struct Instantiate {
    pub st: St,
    pub sc: Scheme,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(Ty, St)> for Instantiate {
    fn cycle(&self) -> prism_rtl::Turn<(Ty, St)> {
        let st = &self.st;
        let sc = &self.sc;
        let span = &self.span;
        let sc = sc.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(start_instantiate_with(st.clone(), sc.clone(), span.clone(), Array::new()), move |instantiate_with_34567: (Ty, St, Inst)| {
            let (t, st2, _) = instantiate_with_34567;
            prism_rtl::Turn::Finished((t.clone(), st2.clone()))
        })
    }
}

/// `Start Instantiate, x`: what the function value is when passed to `@Run`.
pub fn start_instantiate(st: St, sc: Scheme, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Ty, St)>> {
    Rc::new(Instantiate { st, sc, span })
}

/// ```prism
/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
/// ```
pub fn instantiate_with(st: &St, sc: &Scheme, span: &crate::syntax::Range, explicit: &Array<Ty>) -> (Ty, St, Inst) {
    let (tys, st1) = fold(&crate::check::errors::range0(&len(&sc.qs)), &(Map::new(), st.clone()), &(|(m, s): &(Map<Text, Ty>, St), i: &Nat| {
        let q = or(&index(&sc.qs, i), &Text::lit(""));
        match index(explicit, i) {
            Some(g) => (insert(m, &q, &g), s.clone()),
            None => {
                let (v_, s2) = fresh_var(s, &has_text(&sc.plain_qs, &q), &Text::lit(""));
                (insert(m, &q, &v_), s2.clone())
            },
        }
    }));
    let nq = len(&sc.qs);
    let (rows, st2) = run_to_end(fold_job(sc.rqs.clone(), (Map::new(), st1.clone()), {
        let sc = sc.clone();
        Rc::new(move |(p0, p1): ((Map<Text, Tail>, St), Text)| {
            let sc = sc.clone();
            entered(once_job(move || {
                let (m, s) = p0;
                let q = p1;
                call_then(start_lacks_in(sc.ty.clone(), q.clone()), move |lacks_in_35309: Array<Text>| {
                    let (rw, s2) = fresh_row(&s, &lacks_in_35309);
                    prism_rtl::Turn::Finished((insert(&m, &q, &rw.tail), name_row(&s2, &rw.tail, &q)))
                })
            }))
        }) as Rc<dyn Fn(((Map<Text, Tail>, St), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, Tail>, St)>>>
    }));
    let (cols, st2b) = fold(&sc.cqs, &(Map::new(), st2.clone()), &(|(m, s): &(Map<Text, Col>, St), q: &Text| {
        let (c, s2) = fresh_col(s);
        (insert(m, q, &c), s2.clone())
    }));
    let inst = Inst { tys: tys.clone(), rows: rows.clone(), cols: cols.clone() };
    let st2c = run_to_end(fold_job(sc.cjoins.clone(), st2b.clone(), {
        let cols = cols.clone();
        let span = span.clone();
        Rc::new(move |(p0, p1): (St, (Text, Text))| {
            let cols = cols.clone();
            let span = span.clone();
            entered(once_job(move || {
                let s = p0;
                let (lo, hi) = p1;
                prism_rtl::Turn::More(Rc::new(AddLeq { st: s.clone(), lo0: or(&get(&cols, &lo), &Col::CBound), hi0: or(&get(&cols, &hi), &Col::CBound), span: span.clone(), kind: Text::lit("arg"), name: Text::lit(""), why: Text::lit("") }))
            }))
        }) as Rc<dyn Fn((St, (Text, Text))) -> Rc<dyn prism_rtl::Job<St>>>
    }));
    let st3 = fold(&sc.bounds, &st2c, &(|s: &St, (v_, tr): &(Text, Text)| {
        let mut this: St = s.clone();
        this.wants = push(&this.wants, &Want { cls: tr.clone(), ty: or(&get(&tys, v_), &Ty::TyErr), file: s.file.clone(), span: span.clone(), level: s.level.clone() });
        this
    }));
    (subst_q(&inst, &sc.ty), st3.clone(), inst.clone())
}

/// The step machine of `InstantiateWith`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
/// ```
pub struct InstantiateWith {
    pub st: St,
    pub sc: Scheme,
    pub span: crate::syntax::Range,
    pub explicit: Array<Ty>,
}

impl prism_rtl::Job<(Ty, St, Inst)> for InstantiateWith {
    fn cycle(&self) -> prism_rtl::Turn<(Ty, St, Inst)> {
        let st = &self.st;
        let sc = &self.sc;
        let span = &self.span;
        let explicit = &self.explicit;
        let (tys, st1) = fold(&crate::check::errors::range0(&len(&sc.qs)), &(Map::new(), st.clone()), &(|(m, s): &(Map<Text, Ty>, St), i: &Nat| {
            let q = or(&index(&sc.qs, i), &Text::lit(""));
            match index(explicit, i) {
                Some(g) => (insert(m, &q, &g), s.clone()),
                None => {
                    let (v_, s2) = fresh_var(s, &has_text(&sc.plain_qs, &q), &Text::lit(""));
                    (insert(m, &q, &v_), s2.clone())
                },
            }
        }));
        let nq = len(&sc.qs);
        let sc = sc.clone();
        let span = span.clone();
        call_value(fold_job(sc.rqs.clone(), (Map::new(), st1.clone()), {
            let sc = sc.clone();
            Rc::new(move |(p0, p1): ((Map<Text, Tail>, St), Text)| {
                let sc = sc.clone();
                entered(once_job(move || {
                    let (m, s) = p0;
                    let q = p1;
                    call_then(start_lacks_in(sc.ty.clone(), q.clone()), move |lacks_in_35309: Array<Text>| {
                        let (rw, s2) = fresh_row(&s, &lacks_in_35309);
                        prism_rtl::Turn::Finished((insert(&m, &q, &rw.tail), name_row(&s2, &rw.tail, &q)))
                    })
                }))
            }) as Rc<dyn Fn(((Map<Text, Tail>, St), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, Tail>, St)>>>
        }), move |fold_35230: (Map<Text, Tail>, St)| {
            let (rows, st2) = fold_35230;
            let (cols, st2b) = fold(&sc.cqs, &(Map::new(), st2.clone()), &(|(m, s): &(Map<Text, Col>, St), q: &Text| {
                let (c, s2) = fresh_col(s);
                (insert(m, q, &c), s2.clone())
            }));
            let inst = Inst { tys: tys.clone(), rows: rows.clone(), cols: cols.clone() };
            call_value(fold_job(sc.cjoins.clone(), st2b.clone(), {
                let cols = cols.clone();
                let span = span.clone();
                Rc::new(move |(p0, p1): (St, (Text, Text))| {
                    let cols = cols.clone();
                    let span = span.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let (lo, hi) = p1;
                        prism_rtl::Turn::More(Rc::new(AddLeq { st: s.clone(), lo0: or(&get(&cols, &lo), &Col::CBound), hi0: or(&get(&cols, &hi), &Col::CBound), span: span.clone(), kind: Text::lit("arg"), name: Text::lit(""), why: Text::lit("") }))
                    }))
                }) as Rc<dyn Fn((St, (Text, Text))) -> Rc<dyn prism_rtl::Job<St>>>
            }), move |fold_35588: St| {
                let st2c = fold_35588;
                let st3 = fold(&sc.bounds, &st2c, &(|s: &St, (v_, tr): &(Text, Text)| {
                    let mut this: St = s.clone();
                    this.wants = push(&this.wants, &Want { cls: tr.clone(), ty: or(&get(&tys, v_), &Ty::TyErr), file: s.file.clone(), span: span.clone(), level: s.level.clone() });
                    this
                }));
                call_then(start_subst_q(inst.clone(), sc.ty.clone()), move |subst_q_35882: Ty| prism_rtl::Turn::Finished((subst_q_35882, st3.clone(), inst.clone())))
            })
        })
    }
}

/// `Start InstantiateWith, x`: what the function value is when passed to `@Run`.
pub fn start_instantiate_with(st: St, sc: Scheme, span: crate::syntax::Range, explicit: Array<Ty>) -> Rc<dyn prism_rtl::Job<(Ty, St, Inst)>> {
    Rc::new(InstantiateWith { st, sc, span, explicit })
}

/// ```prism
/// LacksIn: unbounded fn Ty, Text -> [Text]
/// ```
pub fn lacks_in(t: &Ty, q: &Text) -> Array<Text> {
    match t {
        Ty::TyCon(_, args) => run_to_end(fold_job(args.clone(), Array::new(), {
            let q = q.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Ty)| {
                let q = q.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_lacks_in(a.clone(), q.clone()), move |lacks_in_36169: Array<Text>| prism_rtl::Turn::Finished(union_texts(&acc, &lacks_in_36169)))
                }))
            }) as Rc<dyn Fn((Array<Text>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        Ty::TyFn(_, ps, r) => run_to_end(fold_job(ps.clone(), lacks_in(&**r, q), {
            let q = q.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Ty)| {
                let q = q.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_lacks_in(a.clone(), q.clone()), move |lacks_in_36259: Array<Text>| prism_rtl::Turn::Finished(union_texts(&acc, &lacks_in_36259)))
                }))
            }) as Rc<dyn Fn((Array<Text>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), Array::new(), {
            let q = q.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Ty)| {
                let q = q.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_lacks_in(a.clone(), q.clone()), move |lacks_in_36331: Array<Text>| prism_rtl::Turn::Finished(union_texts(&acc, &lacks_in_36331)))
                }))
            }) as Rc<dyn Fn((Array<Text>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        Ty::TyArray(e) => lacks_in(&**e, q),
        Ty::TyMap(k, v_) => union_texts(&lacks_in(&**k, q), &lacks_in(&**v_, q)),
        Ty::TySig(_, i) => lacks_in(&**i, q),
        Ty::TyAt(i, rw) => union_texts(&lacks_in(&**i, q), &row_lacks(rw, q)),
        Ty::TyElem(rw, o) => union_texts(&lacks_in(&**o, q), &row_lacks(rw, q)),
        Ty::TyElemAny(rw) => row_lacks(rw, q),
        _ => Array::new(),
    }
}

/// The step machine of `LacksIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LacksIn: unbounded fn Ty, Text -> [Text]
/// ```
pub struct LacksIn {
    pub t: Ty,
    pub q: Text,
}

impl prism_rtl::Job<Array<Text>> for LacksIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        let q = &self.q;
        match t {
            Ty::TyCon(_, args) => fold_job(args.clone(), Array::new(), {
                let q = q.clone();
                Rc::new(move |(p0, p1): (Array<Text>, Ty)| {
                    let q = q.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let a = p1;
                        call_then(start_lacks_in(a.clone(), q.clone()), move |lacks_in_36169: Array<Text>| prism_rtl::Turn::Finished(union_texts(&acc, &lacks_in_36169)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            Ty::TyFn(_, ps, r) => {
                let ps = ps.clone();
                let q = q.clone();
                let r = (**r).clone();
                call_then(start_lacks_in(r.clone(), q.clone()), move |lacks_in_36217: Array<Text>| fold_job(ps.clone(), lacks_in_36217, {
                    let q = q.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Ty)| {
                        let q = q.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let a = p1;
                            call_then(start_lacks_in(a.clone(), q.clone()), move |lacks_in_36259: Array<Text>| prism_rtl::Turn::Finished(union_texts(&acc, &lacks_in_36259)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle())
            },
            Ty::TyTuple(ts) => fold_job(ts.clone(), Array::new(), {
                let q = q.clone();
                Rc::new(move |(p0, p1): (Array<Text>, Ty)| {
                    let q = q.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let a = p1;
                        call_then(start_lacks_in(a.clone(), q.clone()), move |lacks_in_36331: Array<Text>| prism_rtl::Turn::Finished(union_texts(&acc, &lacks_in_36331)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(LacksIn { t: (**e).clone(), q: q.clone() })),
            Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let q = q.clone();
                let v_ = (**v_).clone();
                call_then(start_lacks_in(k.clone(), q.clone()), move |lacks_in_36401: Array<Text>| call_then(start_lacks_in(v_.clone(), q.clone()), move |lacks_in_36417: Array<Text>| prism_rtl::Turn::Finished(union_texts(&lacks_in_36401, &lacks_in_36417))))
            },
            Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(LacksIn { t: (**i).clone(), q: q.clone() })),
            Ty::TyAt(i, rw) => {
                let i = (**i).clone();
                let q = q.clone();
                let rw = rw.clone();
                call_then(start_lacks_in(i.clone(), q.clone()), move |lacks_in_36493: Array<Text>| prism_rtl::Turn::Finished(union_texts(&lacks_in_36493, &row_lacks(&rw, &q))))
            },
            Ty::TyElem(rw, o) => {
                let o = (**o).clone();
                let q = q.clone();
                let rw = rw.clone();
                call_then(start_lacks_in(o.clone(), q.clone()), move |lacks_in_36555: Array<Text>| prism_rtl::Turn::Finished(union_texts(&lacks_in_36555, &row_lacks(&rw, &q))))
            },
            Ty::TyElemAny(rw) => prism_rtl::Turn::Finished(row_lacks(rw, q)),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start LacksIn, x`: what the function value is when passed to `@Run`.
pub fn start_lacks_in(t: Ty, q: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(LacksIn { t, q })
}

/// ```prism
/// RowLacks: fn Rw, Text -> [Text]
/// ```
pub fn row_lacks(rw: &Rw, q: &Text) -> Array<Text> {
    if &rw.tail == &Tail::TlQ(q.clone()) { rw.fams.clone() } else { Array::new() }
}

/// ```prism
/// Skolemize: unbounded fn Scheme -> Ty
/// ```
pub fn skolemize(sc: &Scheme) -> Ty {
    let tys = fold(&sc.qs, &Map::new(), &(|m: &Map<Text, Ty>, q: &Text| insert(m, q, &Ty::TyRigid(q.clone()))));
    let rows = fold(&sc.rqs, &Map::new(), &(|m: &Map<Text, Tail>, q: &Text| insert(m, q, &Tail::TlRigid(q.clone()))));
    let cols = fold(&sc.cqs, &Map::new(), &(|m: &Map<Text, Col>, q: &Text| insert(m, q, &Col::CRigid(q.clone()))));
    subst_q(&Inst { tys: tys.clone(), rows: rows.clone(), cols: cols.clone() }, &sc.ty)
}

/// The step machine of `Skolemize`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Skolemize: unbounded fn Scheme -> Ty
/// ```
pub struct Skolemize {
    pub sc: Scheme,
}

impl prism_rtl::Job<Ty> for Skolemize {
    fn cycle(&self) -> prism_rtl::Turn<Ty> {
        let sc = &self.sc;
        let tys = fold(&sc.qs, &Map::new(), &(|m: &Map<Text, Ty>, q: &Text| insert(m, q, &Ty::TyRigid(q.clone()))));
        let rows = fold(&sc.rqs, &Map::new(), &(|m: &Map<Text, Tail>, q: &Text| insert(m, q, &Tail::TlRigid(q.clone()))));
        let cols = fold(&sc.cqs, &Map::new(), &(|m: &Map<Text, Col>, q: &Text| insert(m, q, &Col::CRigid(q.clone()))));
        prism_rtl::Turn::More(Rc::new(SubstQ { m: Inst { tys: tys.clone(), rows: rows.clone(), cols: cols.clone() }, t: sc.ty.clone() }))
    }
}

/// `Start Skolemize, x`: what the function value is when passed to `@Run`.
pub fn start_skolemize(sc: Scheme) -> Rc<dyn prism_rtl::Job<Ty>> {
    Rc::new(Skolemize { sc })
}

/// ```prism
/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
/// ```
pub fn generalize(st0: &St, t: &Ty, keep: &Array<Nat>, bounds: &Array<(Nat, Text)>) -> (Scheme, St) {
    let waiting = run_to_end(fold_job(st0.field_qs.clone(), Array::new(), {
        let st0 = st0.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, FieldQ)| {
            let st0 = st0.clone();
            entered(once_job(move || {
                let acc = p0;
                let q = p1;
                call_then(start_free_vars_into(st0.clone(), acc.clone(), q.recv.clone()), move |free_vars_into_37719: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st0.clone(), acc: free_vars_into_37719, t: q.result.clone() })))
            }))
        }) as Rc<dyn Fn((Array<Nat>, FieldQ)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    let st = generalize_cols(&lower_levels(st0, &waiting, &st0.level));
    let z = zonk(&st, t);
    let vs = filter(&free_vars(&st, &z), &(|v_: &Nat| (&info_of(&st, v_).level > &st.level) && !has_nat(keep, v_)));
    let cvs = filter(&free_col_vars(&st, &z), &(|v_: &Nat| &info_of(&st, v_).level > &st.level));
    let tys = fold(&vs, &Map::new(), &(|m: &Map<Nat, Ty>, v_: &Nat| insert(m, v_, &Ty::TyQ(Text::from(format!("'{}", v_))))));
    let cols = fold(&cvs, &Map::new(), &(|m: &Map<Nat, Col>, v_: &Nat| insert(m, v_, &Col::CQ(Text::from(format!("'c{}", v_))))));
    let named = subst_flex(&tys, &cols, &z);
    let plains = each(&filter(&vs, &(|v_: &Nat| info_of(&st, v_).plain)), &(|v_: &Nat| Text::from(format!("'{}", v_))));
    let bs = each(&filter(bounds, &(|(v_, _): &(Nat, Text)| has_nat(&vs, v_))), &(|(v_, tr): &(Nat, Text)| (Text::from(format!("'{}", v_)), tr.clone())));
    let st2 = {
        let mut this: St = st.clone();
        this.col_q = fold(&cvs, &this.col_q, &(|m: &Map<Nat, Text>, v_: &Nat| insert(m, v_, &Text::from(format!("'c{}", v_)))));
        this
    };
    (Scheme { qs: each(&vs, &(|v_: &Nat| Text::from(format!("'{}", v_)))), plain_qs: plains.clone(), rqs: Array::new(), cqs: each(&cvs, &(|v_: &Nat| Text::from(format!("'c{}", v_)))), cjoins: Array::new(), bounds: bs.clone(), ty: named.clone() }, st2.clone())
}

/// The step machine of `Generalize`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
/// ```
pub struct Generalize {
    pub st0: St,
    pub t: Ty,
    pub keep: Array<Nat>,
    pub bounds: Array<(Nat, Text)>,
}

impl prism_rtl::Job<(Scheme, St)> for Generalize {
    fn cycle(&self) -> prism_rtl::Turn<(Scheme, St)> {
        let st0 = &self.st0;
        let t = &self.t;
        let keep = &self.keep;
        let bounds = &self.bounds;
        let bounds = bounds.clone();
        let keep = keep.clone();
        let st0 = st0.clone();
        let t = t.clone();
        call_value(fold_job(st0.field_qs.clone(), Array::new(), {
            let st0 = st0.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, FieldQ)| {
                let st0 = st0.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let q = p1;
                    call_then(start_free_vars_into(st0.clone(), acc.clone(), q.recv.clone()), move |free_vars_into_37719: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeVarsInto { st: st0.clone(), acc: free_vars_into_37719, t: q.result.clone() })))
                }))
            }) as Rc<dyn Fn((Array<Nat>, FieldQ)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        }), move |fold_37666: Array<Nat>| {
            let waiting = fold_37666;
            call_then(start_generalize_cols(lower_levels(&st0, &waiting, &st0.level)), move |generalize_cols_37773: St| {
                let st = generalize_cols_37773;
                call_then(start_zonk(st.clone(), t.clone()), move |zonk_37838: Ty| {
                    let z = zonk_37838;
                    call_then(start_free_vars(st.clone(), z.clone()), move |free_vars_37870: Array<Nat>| {
                        let vs = filter(&free_vars_37870, &(|v_: &Nat| (&info_of(&st, v_).level > &st.level) && !has_nat(&keep, v_)));
                        call_then(start_free_col_vars(st.clone(), z.clone()), move |free_col_vars_37971: Array<Nat>| {
                            let cvs = filter(&free_col_vars_37971, &(|v_: &Nat| &info_of(&st, v_).level > &st.level));
                            let tys = fold(&vs, &Map::new(), &(|m: &Map<Nat, Ty>, v_: &Nat| insert(m, v_, &Ty::TyQ(Text::from(format!("'{}", v_))))));
                            let cols = fold(&cvs, &Map::new(), &(|m: &Map<Nat, Col>, v_: &Nat| insert(m, v_, &Col::CQ(Text::from(format!("'c{}", v_))))));
                            call_then(start_subst_flex(tys.clone(), cols.clone(), z.clone()), move |subst_flex_38168: Ty| {
                                let named = subst_flex_38168;
                                let plains = each(&filter(&vs, &(|v_: &Nat| info_of(&st, v_).plain)), &(|v_: &Nat| Text::from(format!("'{}", v_))));
                                let bs = each(&filter(&bounds, &(|(v_, _): &(Nat, Text)| has_nat(&vs, v_))), &(|(v_, tr): &(Nat, Text)| (Text::from(format!("'{}", v_)), tr.clone())));
                                let st2 = {
                                    let mut this: St = st.clone();
                                    this.col_q = fold(&cvs, &this.col_q, &(|m: &Map<Nat, Text>, v_: &Nat| insert(m, v_, &Text::from(format!("'c{}", v_)))));
                                    this
                                };
                                prism_rtl::Turn::Finished((Scheme { qs: each(&vs, &(|v_: &Nat| Text::from(format!("'{}", v_)))), plain_qs: plains.clone(), rqs: Array::new(), cqs: each(&cvs, &(|v_: &Nat| Text::from(format!("'c{}", v_)))), cjoins: Array::new(), bounds: bs.clone(), ty: named.clone() }, st2.clone()))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start Generalize, x`: what the function value is when passed to `@Run`.
pub fn start_generalize(st0: St, t: Ty, keep: Array<Nat>, bounds: Array<(Nat, Text)>) -> Rc<dyn prism_rtl::Job<(Scheme, St)>> {
    Rc::new(Generalize { st0, t, keep, bounds })
}

/// ```prism
/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
/// ```
pub fn subst_flex(m: &Map<Nat, Ty>, cm: &Map<Nat, Col>, t: &Ty) -> Ty {
    match t {
        Ty::TyFlex(n) => or(&get(m, n), &Ty::TyFlex(n.clone())),
        Ty::TyCon(n, args) => Ty::TyCon(n.clone(), run_to_end(each_job(args.clone(), {
            let m = m.clone();
            let cm = cm.clone();
            Rc::new(move |p0: Ty| {
                let m = m.clone();
                let cm = cm.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(SubstFlex { m: m.clone(), cm: cm.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
        }))),
        Ty::TyFn(c, ps, res) => {
            let c2 = match c {
                Col::CFlex(n) => or(&get(cm, n), c),
                other => other.clone(),
            };
            Ty::TyFn(c2.clone(), run_to_end(each_job(ps.clone(), {
                let m = m.clone();
                let cm = cm.clone();
                Rc::new(move |p0: Ty| {
                    let m = m.clone();
                    let cm = cm.clone();
                    entered(once_job(move || {
                        let p_ = p0;
                        prism_rtl::Turn::More(Rc::new(SubstFlex { m: m.clone(), cm: cm.clone(), t: p_.clone() }))
                    }))
                }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
            })), Rc::new(subst_flex(m, cm, &**res)))
        },
        Ty::TyTuple(ts) => Ty::TyTuple(run_to_end(each_job(ts.clone(), {
            let m = m.clone();
            let cm = cm.clone();
            Rc::new(move |p0: Ty| {
                let m = m.clone();
                let cm = cm.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(SubstFlex { m: m.clone(), cm: cm.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
        }))),
        Ty::TyArray(e) => Ty::TyArray(Rc::new(subst_flex(m, cm, &**e))),
        Ty::TyMap(k, v_) => Ty::TyMap(Rc::new(subst_flex(m, cm, &**k)), Rc::new(subst_flex(m, cm, &**v_))),
        Ty::TySig(s, i) => Ty::TySig(s.clone(), Rc::new(subst_flex(m, cm, &**i))),
        Ty::TyAt(i, rw) => Ty::TyAt(Rc::new(subst_flex(m, cm, &**i)), rw.clone()),
        Ty::TyElem(rw, o) => Ty::TyElem(rw.clone(), Rc::new(subst_flex(m, cm, &**o))),
        Ty::TyAssoc(n, a) => Ty::TyAssoc(n.clone(), Rc::new(subst_flex(m, cm, &**a))),
        other => other.clone(),
    }
}

/// The step machine of `SubstFlex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
/// ```
pub struct SubstFlex {
    pub m: Map<Nat, Ty>,
    pub cm: Map<Nat, Col>,
    pub t: Ty,
}

impl prism_rtl::Job<Ty> for SubstFlex {
    fn cycle(&self) -> prism_rtl::Turn<Ty> {
        let m = &self.m;
        let cm = &self.cm;
        let t = &self.t;
        match t {
            Ty::TyFlex(n) => prism_rtl::Turn::Finished(or(&get(m, n), &Ty::TyFlex(n.clone()))),
            Ty::TyCon(n, args) => {
                let args = args.clone();
                let cm = cm.clone();
                let m = m.clone();
                let n = n.clone();
                call_value(each_job(args.clone(), {
                    let m = m.clone();
                    let cm = cm.clone();
                    Rc::new(move |p0: Ty| {
                        let m = m.clone();
                        let cm = cm.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(SubstFlex { m: m.clone(), cm: cm.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
                }), move |each_38747: Array<Ty>| prism_rtl::Turn::Finished(Ty::TyCon(n.clone(), each_38747)))
            },
            Ty::TyFn(c, ps, res) => {
                let c2 = match c {
                    Col::CFlex(n) => or(&get(cm, n), c),
                    other => other.clone(),
                };
                let cm = cm.clone();
                let m = m.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(each_job(ps.clone(), {
                    let m = m.clone();
                    let cm = cm.clone();
                    Rc::new(move |p0: Ty| {
                        let m = m.clone();
                        let cm = cm.clone();
                        entered(once_job(move || {
                            let p_ = p0;
                            prism_rtl::Turn::More(Rc::new(SubstFlex { m: m.clone(), cm: cm.clone(), t: p_.clone() }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
                }), move |each_38906: Array<Ty>| call_then(start_subst_flex(m.clone(), cm.clone(), res.clone()), move |subst_flex_38942: Ty| prism_rtl::Turn::Finished(Ty::TyFn(c2.clone(), each_38906, Rc::new(subst_flex_38942)))))
            },
            Ty::TyTuple(ts) => {
                let cm = cm.clone();
                let m = m.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let m = m.clone();
                    let cm = cm.clone();
                    Rc::new(move |p0: Ty| {
                        let m = m.clone();
                        let cm = cm.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(SubstFlex { m: m.clone(), cm: cm.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Ty>>>
                }), move |each_38989: Array<Ty>| prism_rtl::Turn::Finished(Ty::TyTuple(each_38989)))
            },
            Ty::TyArray(e) => {
                let cm = cm.clone();
                let e = (**e).clone();
                let m = m.clone();
                call_then(start_subst_flex(m.clone(), cm.clone(), e.clone()), move |subst_flex_39047: Ty| prism_rtl::Turn::Finished(Ty::TyArray(Rc::new(subst_flex_39047))))
            },
            Ty::TyMap(k, v_) => {
                let cm = cm.clone();
                let k = (**k).clone();
                let m = m.clone();
                let v_ = (**v_).clone();
                call_then(start_subst_flex(m.clone(), cm.clone(), k.clone()), move |subst_flex_39090: Ty| call_then(start_subst_flex(m.clone(), cm.clone(), v_.clone()), move |subst_flex_39112: Ty| prism_rtl::Turn::Finished(Ty::TyMap(Rc::new(subst_flex_39090), Rc::new(subst_flex_39112)))))
            },
            Ty::TySig(s, i) => {
                let cm = cm.clone();
                let i = (**i).clone();
                let m = m.clone();
                let s = s.clone();
                call_then(start_subst_flex(m.clone(), cm.clone(), i.clone()), move |subst_flex_39158: Ty| prism_rtl::Turn::Finished(Ty::TySig(s.clone(), Rc::new(subst_flex_39158))))
            },
            Ty::TyAt(i, rw) => {
                let cm = cm.clone();
                let i = (**i).clone();
                let m = m.clone();
                let rw = rw.clone();
                call_then(start_subst_flex(m.clone(), cm.clone(), i.clone()), move |subst_flex_39200: Ty| prism_rtl::Turn::Finished(Ty::TyAt(Rc::new(subst_flex_39200), rw.clone())))
            },
            Ty::TyElem(rw, o) => {
                let cm = cm.clone();
                let m = m.clone();
                let o = (**o).clone();
                let rw = rw.clone();
                call_then(start_subst_flex(m.clone(), cm.clone(), o.clone()), move |subst_flex_39254: Ty| prism_rtl::Turn::Finished(Ty::TyElem(rw.clone(), Rc::new(subst_flex_39254))))
            },
            Ty::TyAssoc(n, a) => {
                let a = (**a).clone();
                let cm = cm.clone();
                let m = m.clone();
                let n = n.clone();
                call_then(start_subst_flex(m.clone(), cm.clone(), a.clone()), move |subst_flex_39304: Ty| prism_rtl::Turn::Finished(Ty::TyAssoc(n.clone(), Rc::new(subst_flex_39304))))
            },
            other => prism_rtl::Turn::Finished(other.clone()),
        }
    }
}

/// `Start SubstFlex, x`: what the function value is when passed to `@Run`.
pub fn start_subst_flex(m: Map<Nat, Ty>, cm: Map<Nat, Col>, t: Ty) -> Rc<dyn prism_rtl::Job<Ty>> {
    Rc::new(SubstFlex { m, cm, t })
}

/// ```prism
/// HoldsNode: unbounded fn St, Ty -> Bool
/// ```
pub fn holds_node(st: &St, t: &Ty) -> bool {
    match walk(st, t) {
        Ty::TySig(s, i) => ((&s == &Text::lit("$")) || (&s == &Text::lit("!"))) || holds_node(st, &*i),
        Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), false, {
            let st = st.clone();
            Rc::new(move |(p0, p1): (bool, Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(seen || holds_node(&st, &x))
                }))
            }) as Rc<dyn Fn((bool, Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        Ty::TyArray(e) => holds_node(st, &*e),
        Ty::TyMap(k, v_) => holds_node(st, &*k) || holds_node(st, &*v_),
        Ty::TyCon(_, args) => run_to_end(fold_job(args.clone(), false, {
            let st = st.clone();
            Rc::new(move |(p0, p1): (bool, Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(seen || holds_node(&st, &x))
                }))
            }) as Rc<dyn Fn((bool, Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        _ => false,
    }
}

/// The step machine of `HoldsNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldsNode: unbounded fn St, Ty -> Bool
/// ```
pub struct HoldsNode {
    pub st: St,
    pub t: Ty,
}

impl prism_rtl::Job<bool> for HoldsNode {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(start_walk(st.clone(), t.clone()), move |walk_39538: Ty| match walk_39538 {
            Ty::TySig(s, i) => prism_rtl::Turn::Finished(((&s == &Text::lit("$")) || (&s == &Text::lit("!"))) || holds_node(&st, &*i)),
            Ty::TyTuple(ts) => fold_job(ts.clone(), false, {
                let st = st.clone();
                Rc::new(move |(p0, p1): (bool, Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(seen || holds_node(&st, &x))
                    }))
                }) as Rc<dyn Fn((bool, Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(HoldsNode { st: st.clone(), t: (*e).clone() })),
            Ty::TyMap(k, v_) => call_then(start_holds_node(st.clone(), (*k).clone()), move |holds_node_39721: bool| prism_rtl::Turn::Finished(holds_node_39721 || holds_node(&st, &*v_))),
            Ty::TyCon(_, args) => fold_job(args.clone(), false, {
                let st = st.clone();
                Rc::new(move |(p0, p1): (bool, Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(seen || holds_node(&st, &x))
                    }))
                }) as Rc<dyn Fn((bool, Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            _ => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start HoldsNode, x`: what the function value is when passed to `@Run`.
pub fn start_holds_node(st: St, t: Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HoldsNode { st, t })
}

/// ```prism
/// EnterLevel: fn St -> St
/// ```
pub fn enter_level(st: &St) -> St {
    let mut this: St = st.clone();
    this.level = &this.level + &Nat::from(1u32);
    this
}

/// ```prism
/// LeaveLevel: fn St -> St
/// ```
pub fn leave_level(st: &St) -> St {
    let mut this: St = st.clone();
    this.level = or(&(&this.level).checked_sub(&Nat::from(1u32)), &Nat::from(0u32));
    this
}

/// ```prism
/// JoinCol: fn Col, Col -> Col
/// ```
pub fn join_col(col0: &Col, col1: &Col) -> Col {
    match (col0, col1) {
        (Col::CBound, c) => c.clone(),
        (c, Col::CBound) => c.clone(),
        (Col::CUnbound, _) => Col::CUnbound,
        (_, Col::CUnbound) => Col::CUnbound,
        (a, b) => if a == b { a.clone() } else { Col::CUnbound },
    }
}

/// ```prism
/// ColLeq: fn Col, Col -> Bool
/// ```
pub fn col_leq(a: &Col, b: &Col) -> bool {
    &join_col(a, b) == b
}

/// ```prism
/// ColWord: fn Col -> Text
/// ```
pub fn col_word(col0: &Col) -> Text {
    match col0 {
        Col::CBound => Text::lit("bounded"),
        Col::CUnbound => Text::lit("unbounded"),
        Col::CRigid(n) => Text::from(format!("`{}`-colored", n)),
        Col::CQ(n) => Text::from(format!("`{}`-colored", n)),
        Col::CFlex(_) => Text::lit("bounded"),
    }
}

/// ```prism
/// UseColor: unbounded fn St, Col, Text, Range -> St
/// ```
pub fn use_color(st: &St, c0: &Col, why: &Text, span: &crate::syntax::Range) -> St {
    match walk_col(st, c0) {
        Col::CFlex(n) => {
            let mut this: St = st.clone();
            this.color_flex = push(&this.color_flex, &(Col::CFlex(n.clone()), why.clone(), span.clone()));
            this
        },
        c => join_known(st, &c, why),
    }
}

/// The step machine of `UseColor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UseColor: unbounded fn St, Col, Text, Range -> St
/// ```
pub struct UseColor {
    pub st: St,
    pub c0: Col,
    pub why: Text,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<St> for UseColor {
    fn cycle(&self) -> prism_rtl::Turn<St> {
        let st = &self.st;
        let c0 = &self.c0;
        let why = &self.why;
        let span = &self.span;
        let c0 = c0.clone();
        let span = span.clone();
        let st = st.clone();
        let why = why.clone();
        call_then(start_walk_col(st.clone(), c0.clone()), move |walk_col_41209: Col| match walk_col_41209 {
            Col::CFlex(n) => prism_rtl::Turn::Finished({
                let mut this: St = st.clone();
                this.color_flex = push(&this.color_flex, &(Col::CFlex(n.clone()), why.clone(), span.clone()));
                this
            }),
            c => prism_rtl::Turn::Finished(join_known(&st, &c, &why)),
        })
    }
}

/// `Start UseColor, x`: what the function value is when passed to `@Run`.
pub fn start_use_color(st: St, c0: Col, why: Text, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<St>> {
    Rc::new(UseColor { st, c0, why, span })
}

/// ```prism
/// JoinKnown: fn St, Col, Text -> St
/// ```
pub fn join_known(st: &St, c0: &Col, why: &Text) -> St {
    let c = up_col(st, c0);
    let mut this: St = st.clone();
    if !col_leq(&c, &this.color) {
        this.color_why = why.clone();
    }
    this.color = join_col(&this.color, &c);
    this
}

/// ```prism
/// UpCol: fn St, Col -> Col
/// ```
pub fn up_col(st: &St, col1: &Col) -> Col {
    match col1 {
        Col::CRigid(n) => match get(&st.col_up, n) {
            Some(up) => Col::CRigid(up.clone()),
            None => Col::CRigid(n.clone()),
        },
        c => c.clone(),
    }
}

/// ```prism
/// WalkCol: unbounded fn St, Col -> Col
/// ```
pub fn walk_col(st: &St, col1: &Col) -> Col {
    match col1 {
        Col::CFlex(n) => match get(&st.cols, n) {
            Some(c) => walk_col(st, &c),
            None => Col::CFlex(n.clone()),
        },
        c => c.clone(),
    }
}

/// The step machine of `WalkCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkCol: unbounded fn St, Col -> Col
/// ```
pub struct WalkCol {
    pub st: St,
    pub col1: Col,
}

impl prism_rtl::Job<Col> for WalkCol {
    fn cycle(&self) -> prism_rtl::Turn<Col> {
        let st = &self.st;
        let col1 = &self.col1;
        match col1 {
            Col::CFlex(n) => match get(&st.cols, n) {
                Some(c) => prism_rtl::Turn::More(Rc::new(WalkCol { st: st.clone(), col1: c.clone() })),
                None => prism_rtl::Turn::Finished(Col::CFlex(n.clone())),
            },
            c => prism_rtl::Turn::Finished(c.clone()),
        }
    }
}

/// `Start WalkCol, x`: what the function value is when passed to `@Run`.
pub fn start_walk_col(st: St, col1: Col) -> Rc<dyn prism_rtl::Job<Col>> {
    Rc::new(WalkCol { st, col1 })
}

/// ```prism
/// IsRigidCol: fn Col -> Bool
/// ```
pub fn is_rigid_col(col0: &Col) -> bool {
    match col0 {
        Col::CRigid(_) => true,
        _ => false,
    }
}

/// ```prism
/// IsOwnCol: fn St, Col -> Bool
/// ```
pub fn is_own_col(s: &St, col1: &Col) -> bool {
    match col1 {
        Col::CFlex(n) => &info_of(s, n).level > &s.level,
        _ => false,
    }
}

/// ```prism
/// IsFlexCol: fn Col -> Bool
/// ```
pub fn is_flex_col(col0: &Col) -> bool {
    match col0 {
        Col::CFlex(_) => true,
        _ => false,
    }
}

/// ```prism
/// SettledCol: unbounded fn St, Col -> Col
/// ```
pub fn settled_col(st: &St, c: &Col) -> Col {
    match walk_col(st, c) {
        Col::CFlex(_) => Col::CBound,
        other => other.clone(),
    }
}

/// The step machine of `SettledCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SettledCol: unbounded fn St, Col -> Col
/// ```
pub struct SettledCol {
    pub st: St,
    pub c: Col,
}

impl prism_rtl::Job<Col> for SettledCol {
    fn cycle(&self) -> prism_rtl::Turn<Col> {
        let st = &self.st;
        let c = &self.c;
        let c = c.clone();
        let st = st.clone();
        call_then(start_walk_col(st.clone(), c.clone()), move |walk_col_42563: Col| match walk_col_42563 {
            Col::CFlex(_) => prism_rtl::Turn::Finished(Col::CBound),
            other => prism_rtl::Turn::Finished(other.clone()),
        })
    }
}

/// `Start SettledCol, x`: what the function value is when passed to `@Run`.
pub fn start_settled_col(st: St, c: Col) -> Rc<dyn prism_rtl::Job<Col>> {
    Rc::new(SettledCol { st, c })
}

/// ```prism
/// UnifyCol: unbounded fn St, Col, Col -> ((Text, St))
/// ```
pub fn unify_col(st: &St, a0: &Col, b0: &Col) -> (Text, St) {
    let a = walk_col(st, a0);
    let b = walk_col(st, b0);
    if &a == &b {
        (Text::lit(""), st.clone())
    } else {
        match (a.clone(), b.clone()) {
            (Col::CFlex(x), other) => (Text::lit(""), bind_col(st, &x, &other)),
            (other, Col::CFlex(y)) => (Text::lit(""), bind_col(st, &y, &other)),
            (Col::CQ(_), _) => (Text::lit(""), st.clone()),
            (_, Col::CQ(_)) => (Text::lit(""), st.clone()),
            _ => (Text::lit("mismatch"), st.clone()),
        }
    }
}

/// The step machine of `UnifyCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyCol: unbounded fn St, Col, Col -> ((Text, St))
/// ```
pub struct UnifyCol {
    pub st: St,
    pub a0: Col,
    pub b0: Col,
}

impl prism_rtl::Job<(Text, St)> for UnifyCol {
    fn cycle(&self) -> prism_rtl::Turn<(Text, St)> {
        let st = &self.st;
        let a0 = &self.a0;
        let b0 = &self.b0;
        let a0 = a0.clone();
        let b0 = b0.clone();
        let st = st.clone();
        call_then(start_walk_col(st.clone(), a0.clone()), move |walk_col_42858: Col| {
            let a = walk_col_42858;
            call_then(start_walk_col(st.clone(), b0.clone()), move |walk_col_42885: Col| {
                let b = walk_col_42885;
                if &a == &b {
                    prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
                } else {
                    match (a.clone(), b.clone()) {
                        (Col::CFlex(x), other) => prism_rtl::Turn::Finished((Text::lit(""), bind_col(&st, &x, &other))),
                        (other, Col::CFlex(y)) => prism_rtl::Turn::Finished((Text::lit(""), bind_col(&st, &y, &other))),
                        (Col::CQ(_), _) => prism_rtl::Turn::Finished((Text::lit(""), st.clone())),
                        (_, Col::CQ(_)) => prism_rtl::Turn::Finished((Text::lit(""), st.clone())),
                        _ => prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone())),
                    }
                }
            })
        })
    }
}

/// `Start UnifyCol, x`: what the function value is when passed to `@Run`.
pub fn start_unify_col(st: St, a0: Col, b0: Col) -> Rc<dyn prism_rtl::Job<(Text, St)>> {
    Rc::new(UnifyCol { st, a0, b0 })
}

/// ```prism
/// BindCol: fn St, Nat, Col -> St
/// ```
pub fn bind_col(st: &St, n: &Nat, c: &Col) -> St {
    let st2 = match c {
        Col::CFlex(m) => lower_one(st, m, &info_of(st, n).level),
        _ => st.clone(),
    };
    let mut this: St = st2.clone();
    this.cols = insert(&this.cols, n, c);
    this
}

/// ```prism
/// FreeColVars: unbounded fn St, Ty -> [Nat]
/// ```
pub fn free_col_vars(st: &St, t: &Ty) -> Array<Nat> {
    free_cols_into(st, &Array::new(), t)
}

/// The step machine of `FreeColVars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeColVars: unbounded fn St, Ty -> [Nat]
/// ```
pub struct FreeColVars {
    pub st: St,
    pub t: Ty,
}

impl prism_rtl::Job<Array<Nat>> for FreeColVars {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let st = &self.st;
        let t = &self.t;
        prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: Array::new(), t: t.clone() }))
    }
}

/// `Start FreeColVars, x`: what the function value is when passed to `@Run`.
pub fn start_free_col_vars(st: St, t: Ty) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(FreeColVars { st, t })
}

/// ```prism
/// FreeColsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub fn free_cols_into(st: &St, acc: &Array<Nat>, t: &Ty) -> Array<Nat> {
    match walk(st, t) {
        Ty::TyCon(_, args) => run_to_end(fold_job(args.clone(), acc.clone(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })),
        Ty::TyFn(c, ps, res) => {
            let acc2 = match walk_col(st, &c) {
                Col::CFlex(n) => add_nat(acc, &n),
                _ => acc.clone(),
            };
            free_cols_into(st, &run_to_end(fold_job(ps.clone(), acc2.clone(), {
                let st = st.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        let x = p1;
                        prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            })), &*res)
        },
        Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), acc.clone(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })),
        Ty::TyArray(e) => free_cols_into(st, acc, &*e),
        Ty::TyMap(k, v_) => free_cols_into(st, &free_cols_into(st, acc, &*k), &*v_),
        Ty::TySig(_, i) => free_cols_into(st, acc, &*i),
        Ty::TyAt(i, _) => free_cols_into(st, acc, &*i),
        Ty::TyElem(_, o) => free_cols_into(st, acc, &*o),
        Ty::TyAssoc(_, a) => free_cols_into(st, acc, &*a),
        _ => acc.clone(),
    }
}

/// The step machine of `FreeColsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeColsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub struct FreeColsInto {
    pub st: St,
    pub acc: Array<Nat>,
    pub t: Ty,
}

impl prism_rtl::Job<Array<Nat>> for FreeColsInto {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let st = &self.st;
        let acc = &self.acc;
        let t = &self.t;
        let acc = acc.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_walk(st.clone(), t.clone()), move |walk_43619: Ty| match walk_43619 {
            Ty::TyCon(_, args) => fold_job(args.clone(), acc.clone(), {
                let st = st.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        let x = p1;
                        prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }).cycle(),
            Ty::TyFn(c, ps, res) => call_then(start_walk_col(st.clone(), c.clone()), move |walk_col_43747: Col| {
                let acc2 = match walk_col_43747 {
                    Col::CFlex(n) => add_nat(&acc, &n),
                    _ => acc.clone(),
                };
                call_value(fold_job(ps.clone(), acc2.clone(), {
                    let st = st.clone();
                    Rc::new(move |(p0, p1): (Array<Nat>, Ty)| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let a = p0;
                            let x = p1;
                            prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                        }))
                    }) as Rc<dyn Fn((Array<Nat>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }), move |fold_43850: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: fold_43850, t: (*res).clone() })))
            }),
            Ty::TyTuple(ts) => fold_job(ts.clone(), acc.clone(), {
                let st = st.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        let x = p1;
                        prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }).cycle(),
            Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: acc.clone(), t: (*e).clone() })),
            Ty::TyMap(k, v_) => call_then(start_free_cols_into(st.clone(), acc.clone(), (*k).clone()), move |free_cols_into_44034: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: free_cols_into_44034, t: (*v_).clone() }))),
            Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: acc.clone(), t: (*i).clone() })),
            Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: acc.clone(), t: (*i).clone() })),
            Ty::TyElem(_, o) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: acc.clone(), t: (*o).clone() })),
            Ty::TyAssoc(_, a) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: acc.clone(), t: (*a).clone() })),
            _ => prism_rtl::Turn::Finished(acc.clone()),
        })
    }
}

/// `Start FreeColsInto, x`: what the function value is when passed to `@Run`.
pub fn start_free_cols_into(st: St, acc: Array<Nat>, t: Ty) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(FreeColsInto { st, acc, t })
}

/// ```prism
/// AddLeq: unbounded fn St, Col, Col, Range, Text, Text, Text -> St
/// ```
pub fn add_leq(st: &St, lo0: &Col, hi0: &Col, span: &crate::syntax::Range, kind: &Text, name: &Text, why: &Text) -> St {
    let lo = walk_col(st, lo0);
    let hi = walk_col(st, hi0);
    if ((&lo == &Col::CBound) || (&hi == &Col::CUnbound)) || (&lo == &hi) {
        st.clone()
    } else {
        {
            let mut this: St = st.clone();
            this.cleqs = push(&this.cleqs, &CLeq { lo: lo.clone(), hi: hi.clone(), file: this.file.clone(), span: span.clone(), kind: kind.clone(), name: name.clone(), why: why.clone() });
            this
        }
    }
}

/// The step machine of `AddLeq`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AddLeq: unbounded fn St, Col, Col, Range, Text, Text, Text -> St
/// ```
pub struct AddLeq {
    pub st: St,
    pub lo0: Col,
    pub hi0: Col,
    pub span: crate::syntax::Range,
    pub kind: Text,
    pub name: Text,
    pub why: Text,
}

impl prism_rtl::Job<St> for AddLeq {
    fn cycle(&self) -> prism_rtl::Turn<St> {
        let st = &self.st;
        let lo0 = &self.lo0;
        let hi0 = &self.hi0;
        let span = &self.span;
        let kind = &self.kind;
        let name = &self.name;
        let why = &self.why;
        let hi0 = hi0.clone();
        let kind = kind.clone();
        let lo0 = lo0.clone();
        let name = name.clone();
        let span = span.clone();
        let st = st.clone();
        let why = why.clone();
        call_then(start_walk_col(st.clone(), lo0.clone()), move |walk_col_44510: Col| {
            let lo = walk_col_44510;
            call_then(start_walk_col(st.clone(), hi0.clone()), move |walk_col_44539: Col| {
                let hi = walk_col_44539;
                if ((&lo == &Col::CBound) || (&hi == &Col::CUnbound)) || (&lo == &hi) {
                    prism_rtl::Turn::Finished(st.clone())
                } else {
                    prism_rtl::Turn::Finished({
                        let mut this: St = st.clone();
                        this.cleqs = push(&this.cleqs, &CLeq { lo: lo.clone(), hi: hi.clone(), file: this.file.clone(), span: span.clone(), kind: kind.clone(), name: name.clone(), why: why.clone() });
                        this
                    })
                }
            })
        })
    }
}

/// `Start AddLeq, x`: what the function value is when passed to `@Run`.
pub fn start_add_leq(st: St, lo0: Col, hi0: Col, span: crate::syntax::Range, kind: Text, name: Text, why: Text) -> Rc<dyn prism_rtl::Job<St>> {
    Rc::new(AddLeq { st, lo0, hi0, span, kind, name, why })
}

/// ```prism
/// Propagate: unbounded fn St, Bool -> St
/// ```
pub fn propagate(st: &St, rigid: &bool) -> St {
    let (st2, changed) = run_to_end(fold_job(st.cleqs.clone(), (st.clone(), false), {
        let rigid = *rigid;
        Rc::new(move |(p0, p1): ((St, bool), CLeq)| {
            let rigid = rigid;
            entered(once_job(move || {
                let (s, ch) = p0;
                let c = p1;
                call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_45117: Col| {
                    let lo = walk_col_45117;
                    call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_45147: Col| match walk_col_45147 {
                        Col::CFlex(h) => {
                            let forced = (&lo == &Col::CUnbound) || (rigid && is_rigid_col(&lo));
                            if forced {
                                prism_rtl::Turn::Finished((bind_col(&s, &h, &lo), true))
                            } else {
                                prism_rtl::Turn::Finished((s.clone(), ch))
                            }
                        },
                        _ => prism_rtl::Turn::Finished((s.clone(), ch)),
                    })
                })
            }))
        }) as Rc<dyn Fn(((St, bool), CLeq)) -> Rc<dyn prism_rtl::Job<(St, bool)>>>
    }));
    if changed { propagate(&st2, rigid) } else { st2.clone() }
}

/// The step machine of `Propagate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Propagate: unbounded fn St, Bool -> St
/// ```
pub struct Propagate {
    pub st: St,
    pub rigid: bool,
}

impl prism_rtl::Job<St> for Propagate {
    fn cycle(&self) -> prism_rtl::Turn<St> {
        let st = &self.st;
        let rigid = &self.rigid;
        let rigid = *rigid;
        let st = st.clone();
        call_value(fold_job(st.cleqs.clone(), (st.clone(), false), {
            let rigid = rigid;
            Rc::new(move |(p0, p1): ((St, bool), CLeq)| {
                let rigid = rigid;
                entered(once_job(move || {
                    let (s, ch) = p0;
                    let c = p1;
                    call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_45117: Col| {
                        let lo = walk_col_45117;
                        call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_45147: Col| match walk_col_45147 {
                            Col::CFlex(h) => {
                                let forced = (&lo == &Col::CUnbound) || (rigid && is_rigid_col(&lo));
                                if forced {
                                    prism_rtl::Turn::Finished((bind_col(&s, &h, &lo), true))
                                } else {
                                    prism_rtl::Turn::Finished((s.clone(), ch))
                                }
                            },
                            _ => prism_rtl::Turn::Finished((s.clone(), ch)),
                        })
                    })
                }))
            }) as Rc<dyn Fn(((St, bool), CLeq)) -> Rc<dyn prism_rtl::Job<(St, bool)>>>
        }), move |fold_45054: (St, bool)| {
            let (st2, changed) = fold_45054;
            if changed {
                prism_rtl::Turn::More(Rc::new(Propagate { st: st2.clone(), rigid }))
            } else {
                prism_rtl::Turn::Finished(st2.clone())
            }
        })
    }
}

/// `Start Propagate, x`: what the function value is when passed to `@Run`.
pub fn start_propagate(st: St, rigid: bool) -> Rc<dyn prism_rtl::Job<St>> {
    Rc::new(Propagate { st, rigid })
}

/// ```prism
/// GeneralizeCols: unbounded fn St -> St
/// ```
pub fn generalize_cols(st0: &St) -> St {
    let st1 = lower_joined(&propagate(st0, &false));
    let st2 = run_to_end(fold_job(st1.cleqs.clone(), st1.clone(), Rc::new(move |(p0, p1): (St, CLeq)| entered(once_job(move || {
        let s = p0;
        let c = p1;
        call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_45887: Col| {
            let lo = walk_col_45887;
            call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_45920: Col| {
                let hi = walk_col_45920;
                match (lo.clone(), hi.clone()) {
                    (Col::CFlex(x), Col::CFlex(y)) => if ((&x != &y) && is_own_col(&s, &lo)) && is_own_col(&s, &hi) {
                        prism_rtl::Turn::Finished(bind_col(&s, &x, &hi))
                    } else {
                        prism_rtl::Turn::Finished(s.clone())
                    },
                    _ => prism_rtl::Turn::Finished(s.clone()),
                }
            })
        })
    }))) as Rc<dyn Fn((St, CLeq)) -> Rc<dyn prism_rtl::Job<St>>>));
    run_to_end(fold_job(st2.cleqs.clone(), st2.clone(), Rc::new(move |(p0, p1): (St, CLeq)| entered(once_job(move || {
        let s = p0;
        let c = p1;
        call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_46149: Col| {
            let lo = walk_col_46149;
            call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_46182: Col| {
                let hi = walk_col_46182;
                match (lo.clone(), hi.clone()) {
                    (Col::CFlex(_), Col::CFlex(_)) => prism_rtl::Turn::Finished(s.clone()),
                    (Col::CFlex(_), Col::CUnbound) => prism_rtl::Turn::Finished(s.clone()),
                    (Col::CFlex(x), other) => if is_own_col(&s, &lo) {
                        prism_rtl::Turn::Finished(bind_col(&s, &x, &other))
                    } else {
                        prism_rtl::Turn::Finished(s.clone())
                    },
                    (Col::CRigid(r), Col::CFlex(y)) => if is_own_col(&s, &hi) {
                        prism_rtl::Turn::Finished(bind_col(&s, &y, &lo))
                    } else {
                        prism_rtl::Turn::Finished(s.clone())
                    },
                    _ => prism_rtl::Turn::Finished(s.clone()),
                }
            })
        })
    }))) as Rc<dyn Fn((St, CLeq)) -> Rc<dyn prism_rtl::Job<St>>>))
}

/// The step machine of `GeneralizeCols`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GeneralizeCols: unbounded fn St -> St
/// ```
pub struct GeneralizeCols {
    pub st0: St,
}

impl prism_rtl::Job<St> for GeneralizeCols {
    fn cycle(&self) -> prism_rtl::Turn<St> {
        let st0 = &self.st0;
        let st0 = st0.clone();
        call_then(start_propagate(st0.clone(), false), move |propagate_45805: St| call_then(start_lower_joined(propagate_45805), move |lower_joined_45792: St| {
            let st1 = lower_joined_45792;
            call_value(fold_job(st1.cleqs.clone(), st1.clone(), Rc::new(move |(p0, p1): (St, CLeq)| entered(once_job(move || {
                let s = p0;
                let c = p1;
                call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_45887: Col| {
                    let lo = walk_col_45887;
                    call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_45920: Col| {
                        let hi = walk_col_45920;
                        match (lo.clone(), hi.clone()) {
                            (Col::CFlex(x), Col::CFlex(y)) => if ((&x != &y) && is_own_col(&s, &lo)) && is_own_col(&s, &hi) {
                                prism_rtl::Turn::Finished(bind_col(&s, &x, &hi))
                            } else {
                                prism_rtl::Turn::Finished(s.clone())
                            },
                            _ => prism_rtl::Turn::Finished(s.clone()),
                        }
                    })
                })
            }))) as Rc<dyn Fn((St, CLeq)) -> Rc<dyn prism_rtl::Job<St>>>), move |fold_45841: St| {
                let st2 = fold_45841;
                fold_job(st2.cleqs.clone(), st2.clone(), Rc::new(move |(p0, p1): (St, CLeq)| entered(once_job(move || {
                    let s = p0;
                    let c = p1;
                    call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_46149: Col| {
                        let lo = walk_col_46149;
                        call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_46182: Col| {
                            let hi = walk_col_46182;
                            match (lo.clone(), hi.clone()) {
                                (Col::CFlex(_), Col::CFlex(_)) => prism_rtl::Turn::Finished(s.clone()),
                                (Col::CFlex(_), Col::CUnbound) => prism_rtl::Turn::Finished(s.clone()),
                                (Col::CFlex(x), other) => if is_own_col(&s, &lo) {
                                    prism_rtl::Turn::Finished(bind_col(&s, &x, &other))
                                } else {
                                    prism_rtl::Turn::Finished(s.clone())
                                },
                                (Col::CRigid(r), Col::CFlex(y)) => if is_own_col(&s, &hi) {
                                    prism_rtl::Turn::Finished(bind_col(&s, &y, &lo))
                                } else {
                                    prism_rtl::Turn::Finished(s.clone())
                                },
                                _ => prism_rtl::Turn::Finished(s.clone()),
                            }
                        })
                    })
                }))) as Rc<dyn Fn((St, CLeq)) -> Rc<dyn prism_rtl::Job<St>>>).cycle()
            })
        }))
    }
}

/// `Start GeneralizeCols, x`: what the function value is when passed to `@Run`.
pub fn start_generalize_cols(st0: St) -> Rc<dyn prism_rtl::Job<St>> {
    Rc::new(GeneralizeCols { st0 })
}

/// ```prism
/// LowerJoined: unbounded fn St -> St
/// ```
pub fn lower_joined(st: &St) -> St {
    let (st2, changed) = run_to_end(fold_job(st.cleqs.clone(), (st.clone(), false), Rc::new(move |(p0, p1): ((St, bool), CLeq)| entered(once_job(move || {
        let (s, ch) = p0;
        let c = p1;
        call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_46727: Col| call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_46746: Col| match (walk_col_46727, walk_col_46746) {
            (Col::CFlex(x), Col::CFlex(y)) => {
                let lx = info_of(&s, &x).level.clone();
                let ly = info_of(&s, &y).level.clone();
                if ((&lx > &s.level) && (&ly <= &s.level)) && (&lx > &ly) {
                    prism_rtl::Turn::Finished((lower_one(&s, &x, &ly), true))
                } else {
                    if ((&ly > &s.level) && (&lx <= &s.level)) && (&ly > &lx) {
                        prism_rtl::Turn::Finished((lower_one(&s, &y, &lx), true))
                    } else {
                        prism_rtl::Turn::Finished((s.clone(), ch))
                    }
                }
            },
            _ => prism_rtl::Turn::Finished((s.clone(), ch)),
        }))
    }))) as Rc<dyn Fn(((St, bool), CLeq)) -> Rc<dyn prism_rtl::Job<(St, bool)>>>));
    if changed { lower_joined(&st2) } else { st2.clone() }
}

/// The step machine of `LowerJoined`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LowerJoined: unbounded fn St -> St
/// ```
pub struct LowerJoined {
    pub st: St,
}

impl prism_rtl::Job<St> for LowerJoined {
    fn cycle(&self) -> prism_rtl::Turn<St> {
        let st = &self.st;
        let st = st.clone();
        call_value(fold_job(st.cleqs.clone(), (st.clone(), false), Rc::new(move |(p0, p1): ((St, bool), CLeq)| entered(once_job(move || {
            let (s, ch) = p0;
            let c = p1;
            call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_46727: Col| call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_46746: Col| match (walk_col_46727, walk_col_46746) {
                (Col::CFlex(x), Col::CFlex(y)) => {
                    let lx = info_of(&s, &x).level.clone();
                    let ly = info_of(&s, &y).level.clone();
                    if ((&lx > &s.level) && (&ly <= &s.level)) && (&lx > &ly) {
                        prism_rtl::Turn::Finished((lower_one(&s, &x, &ly), true))
                    } else {
                        if ((&ly > &s.level) && (&lx <= &s.level)) && (&ly > &lx) {
                            prism_rtl::Turn::Finished((lower_one(&s, &y, &lx), true))
                        } else {
                            prism_rtl::Turn::Finished((s.clone(), ch))
                        }
                    }
                },
                _ => prism_rtl::Turn::Finished((s.clone(), ch)),
            }))
        }))) as Rc<dyn Fn(((St, bool), CLeq)) -> Rc<dyn prism_rtl::Job<(St, bool)>>>), move |fold_46664: (St, bool)| {
            let (st2, changed) = fold_46664;
            if changed {
                prism_rtl::Turn::More(Rc::new(LowerJoined { st: st2.clone() }))
            } else {
                prism_rtl::Turn::Finished(st2.clone())
            }
        })
    }
}

/// `Start LowerJoined, x`: what the function value is when passed to `@Run`.
pub fn start_lower_joined(st: St) -> Rc<dyn prism_rtl::Job<St>> {
    Rc::new(LowerJoined { st })
}

/// ```prism
/// CheckColors: unbounded fn St -> St
/// ```
pub fn check_colors(st0: &St) -> St {
    let st = propagate(&propagate(st0, &false), &true);
    let st2 = run_to_end(fold_job(st.cleqs.clone(), st.clone(), Rc::new(move |(p0, p1): (St, CLeq)| entered(once_job(move || {
        let s = p0;
        let c = p1;
        call_then(start_settled_col(s.clone(), c.lo.clone()), move |settled_col_47524: Col| {
            let lo = settled_col_47524;
            call_then(start_settled_col(s.clone(), c.hi.clone()), move |settled_col_47560: Col| {
                let hi = settled_col_47560;
                if col_leq(&lo, &hi) || col_leq(&up_col(&s, &lo), &up_col(&s, &hi)) {
                    prism_rtl::Turn::Finished(s.clone())
                } else {
                    prism_rtl::Turn::Finished(add_diag(&s, &leq_diag(&c, &lo, &hi)))
                }
            })
        })
    }))) as Rc<dyn Fn((St, CLeq)) -> Rc<dyn prism_rtl::Job<St>>>));
    let mut this: St = st2.clone();
    this.cleqs = Array::new();
    this.color_flex = Array::new();
    this.col_up = Map::new();
    this
}

/// The step machine of `CheckColors`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckColors: unbounded fn St -> St
/// ```
pub struct CheckColors {
    pub st0: St,
}

impl prism_rtl::Job<St> for CheckColors {
    fn cycle(&self) -> prism_rtl::Turn<St> {
        let st0 = &self.st0;
        let st0 = st0.clone();
        call_then(start_propagate(st0.clone(), false), move |propagate_47438: St| call_then(start_propagate(propagate_47438, true), move |propagate_47427: St| {
            let st = propagate_47427;
            call_value(fold_job(st.cleqs.clone(), st.clone(), Rc::new(move |(p0, p1): (St, CLeq)| entered(once_job(move || {
                let s = p0;
                let c = p1;
                call_then(start_settled_col(s.clone(), c.lo.clone()), move |settled_col_47524: Col| {
                    let lo = settled_col_47524;
                    call_then(start_settled_col(s.clone(), c.hi.clone()), move |settled_col_47560: Col| {
                        let hi = settled_col_47560;
                        if col_leq(&lo, &hi) || col_leq(&up_col(&s, &lo), &up_col(&s, &hi)) {
                            prism_rtl::Turn::Finished(s.clone())
                        } else {
                            prism_rtl::Turn::Finished(add_diag(&s, &leq_diag(&c, &lo, &hi)))
                        }
                    })
                })
            }))) as Rc<dyn Fn((St, CLeq)) -> Rc<dyn prism_rtl::Job<St>>>), move |fold_47480: St| {
                let st2 = fold_47480;
                prism_rtl::Turn::Finished({
                    let mut this: St = st2.clone();
                    this.cleqs = Array::new();
                    this.color_flex = Array::new();
                    this.col_up = Map::new();
                    this
                })
            })
        }))
    }
}

/// `Start CheckColors, x`: what the function value is when passed to `@Run`.
pub fn start_check_colors(st0: St) -> Rc<dyn prism_rtl::Job<St>> {
    Rc::new(CheckColors { st0 })
}

/// ```prism
/// LeqDiag: fn CLeq, Col, Col -> CDiag
/// ```
pub fn leq_diag(c: &CLeq, lo: &Col, hi: &Col) -> crate::check::errors::CDiag {
    if &c.kind == &Text::lit("lifted") {
        crate::check::errors::diag_fix(&Text::lit("lifted-unbounded"), &c.file, &c.span, &Text::from(format!("{} `{}` lifted over `{}`; use `@Run`", &col_word(lo), &c.name, &c.why)), &Text::from(format!("run it through `!done <- @Run {}, ...`", &c.name)))
    } else {
        if &c.kind == &Text::lit("arg") {
            crate::check::errors::diag_fix(&Text::lit("calls-unbounded"), &c.file, &c.span, &Text::from(format!("{} `{}` takes a {} closure; this one is {}", &col_word(hi), &c.name, &col_word(hi), &col_word(lo))), &Text::lit("mark the parameter `unbounded fn`, or run the work through `@Run`"))
        } else {
            if &c.kind == &Text::lit("lambda") {
                crate::check::errors::diag_fix(&Text::lit("calls-unbounded"), &c.file, &c.span, &Text::from(format!("this {} lambda calls {} `{}`", &col_word(hi), &col_word(lo), &c.why)), &Text::lit("mark the function type it meets `unbounded fn`, or run the call through `@Run`"))
            } else {
                crate::check::errors::diag_fix(&Text::lit("calls-unbounded"), &c.file, &c.span, &Text::from(format!("{} `{}` calls {} `{}`", &col_word(hi), &c.name, &col_word(lo), &c.why)), &Text::from(format!("mark `{}` `unbounded fn`, or run the call through `@Run`", &c.name)))
            }
        }
    }
}

/// ```prism
/// SettleBody: unbounded fn St, Col, Text -> St
/// ```
pub fn settle_body(st0: &St, col: &Col, name: &Text) -> St {
    let st = propagate(st0, &false);
    let waiting = st.color_flex.clone();
    let cleared = {
        let mut this: St = st.clone();
        this.color_flex = Array::new();
        this
    };
    run_to_end(fold_job(waiting.clone(), cleared.clone(), {
        let col = col.clone();
        let name = name.clone();
        Rc::new(move |(p0, p1): (St, (Col, Text, crate::syntax::Range))| {
            let col = col.clone();
            let name = name.clone();
            entered(once_job(move || {
                let s = p0;
                let (c, why, span) = p1;
                call_then(start_walk_col(s.clone(), c.clone()), move |walk_col_49031: Col| match walk_col_49031 {
                    Col::CFlex(n) => prism_rtl::Turn::More(Rc::new(AddLeq { st: s.clone(), lo0: Col::CFlex(n.clone()), hi0: col.clone(), span: span.clone(), kind: if &name == &Text::lit("") { Text::lit("lambda") } else { Text::lit("body") }, name: name.clone(), why: why.clone() })),
                    known => prism_rtl::Turn::Finished(join_known(&s, &known, &why)),
                })
            }))
        }) as Rc<dyn Fn((St, (Col, Text, crate::syntax::Range))) -> Rc<dyn prism_rtl::Job<St>>>
    }))
}

/// The step machine of `SettleBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SettleBody: unbounded fn St, Col, Text -> St
/// ```
pub struct SettleBody {
    pub st0: St,
    pub col: Col,
    pub name: Text,
}

impl prism_rtl::Job<St> for SettleBody {
    fn cycle(&self) -> prism_rtl::Turn<St> {
        let st0 = &self.st0;
        let col = &self.col;
        let name = &self.name;
        let col = col.clone();
        let name = name.clone();
        let st0 = st0.clone();
        call_then(start_propagate(st0.clone(), false), move |propagate_48865: St| {
            let st = propagate_48865;
            let waiting = st.color_flex.clone();
            let cleared = {
                let mut this: St = st.clone();
                this.color_flex = Array::new();
                this
            };
            fold_job(waiting.clone(), cleared.clone(), {
                let col = col.clone();
                let name = name.clone();
                Rc::new(move |(p0, p1): (St, (Col, Text, crate::syntax::Range))| {
                    let col = col.clone();
                    let name = name.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let (c, why, span) = p1;
                        call_then(start_walk_col(s.clone(), c.clone()), move |walk_col_49031: Col| match walk_col_49031 {
                            Col::CFlex(n) => prism_rtl::Turn::More(Rc::new(AddLeq { st: s.clone(), lo0: Col::CFlex(n.clone()), hi0: col.clone(), span: span.clone(), kind: if &name == &Text::lit("") { Text::lit("lambda") } else { Text::lit("body") }, name: name.clone(), why: why.clone() })),
                            known => prism_rtl::Turn::Finished(join_known(&s, &known, &why)),
                        })
                    }))
                }) as Rc<dyn Fn((St, (Col, Text, crate::syntax::Range))) -> Rc<dyn prism_rtl::Job<St>>>
            }).cycle()
        })
    }
}

/// `Start SettleBody, x`: what the function value is when passed to `@Run`.
pub fn start_settle_body(st0: St, col: Col, name: Text) -> Rc<dyn prism_rtl::Job<St>> {
    Rc::new(SettleBody { st0, col, name })
}
