//! The module `Check.Types`, from `target/bootstrap/src/prismc/check/types/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod colors;
pub mod recording;
pub mod schemes;
pub mod unify;

/// `AssocImpl`:
///
/// ```prism
/// type AssocImpl = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct AssocImpl {
    pub cls_p: crate::prelude::Text,
    pub name_p: crate::prelude::Text,
    pub head_p: Ty,
    pub qs_p: crate::prelude::Array<crate::prelude::Text>,
    pub value_p: Ty,
}

impl crate::prelude::Show for AssocImpl {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("AssocImpl", &[("cls", &self.cls_p), ("name", &self.name_p), ("head", &self.head_p), ("qs", &self.qs_p), ("value", &self.value_p)]);
    }
}

impl crate::prelude::ToPod for AssocImpl {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("AssocImpl", vec![("cls", self.cls_p.to_pod()), ("name", self.name_p.to_pod()), ("head", self.head_p.to_pod()), ("qs", self.qs_p.to_pod()), ("value", self.value_p.to_pod())])
    }
}

impl crate::prelude::FromPod for AssocImpl {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(AssocImpl { cls_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cls")?)?, name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, head_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "head")?)?, qs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "qs")?)?, value_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "value")?)? })
    }
}

/// `CLeq`:
///
/// ```prism
/// type CLeq = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct CLeq {
    pub lo_p: Col,
    pub hi_p: Col,
    pub file_p: crate::prelude::Nat,
    pub span_p: crate::syntax::Range,
    pub kind_p: crate::prelude::Text,
    pub name_p: crate::prelude::Text,
    pub why_p: crate::prelude::Text,
}

impl crate::prelude::Show for CLeq {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("CLeq", &[("lo", &self.lo_p), ("hi", &self.hi_p), ("file", &self.file_p), ("span", &self.span_p), ("kind", &self.kind_p), ("name", &self.name_p), ("why", &self.why_p)]);
    }
}

impl crate::prelude::ToPod for CLeq {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("CLeq", vec![("lo", self.lo_p.to_pod()), ("hi", self.hi_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod()), ("kind", self.kind_p.to_pod()), ("name", self.name_p.to_pod()), ("why", self.why_p.to_pod())])
    }
}

impl crate::prelude::FromPod for CLeq {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(CLeq { lo_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lo")?)?, hi_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "hi")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)?, kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)?, name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, why_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "why")?)? })
    }
}

/// `Col`:
///
/// ```prism
/// type Col = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Col {
    CBound,
    CUnbound,
    CRigid(crate::prelude::Text),
    CQ(crate::prelude::Text),
    CFlex(crate::prelude::Nat),
}

impl crate::prelude::Show for Col {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Col::CBound => p.choice("CBound", &[]),
            Col::CUnbound => p.choice("CUnbound", &[]),
            Col::CRigid(a0) => p.choice("CRigid", &[a0]),
            Col::CQ(a0) => p.choice("CQ", &[a0]),
            Col::CFlex(a0) => p.choice("CFlex", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for Col {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Col::CBound => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CBound", 0), vec![]),
            Col::CUnbound => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CUnbound", 1), vec![]),
            Col::CRigid(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CRigid", 2), vec![a0.to_pod()]),
            Col::CQ(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CQ", 3), vec![a0.to_pod()]),
            Col::CFlex(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CFlex", 4), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Col {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "CBound" && a.len() == 0 => ::std::result::Result::Ok(Col::CBound),
            crate::prelude::Pod::Choice(c, a) if &**c == "CUnbound" && a.len() == 0 => ::std::result::Result::Ok(Col::CUnbound),
            crate::prelude::Pod::Choice(c, a) if &**c == "CRigid" && a.len() == 1 => ::std::result::Result::Ok(Col::CRigid(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "CQ" && a.len() == 1 => ::std::result::Result::Ok(Col::CQ(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "CFlex" && a.len() == 1 => ::std::result::Result::Ok(Col::CFlex(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a Col", other),
        }
    }
}

/// `ElemLift`:
///
/// ```prism
/// type ElemLift = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ElemLift {
    pub field_p: crate::prelude::Text,
    pub owner_p: crate::prelude::Text,
    pub arg_p: crate::syntax::Range,
    pub file_p: crate::prelude::Nat,
    pub layer_p: crate::prelude::Text,
    pub src_p: crate::prelude::Text,
}

impl crate::prelude::Show for ElemLift {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ElemLift", &[("field", &self.field_p), ("owner", &self.owner_p), ("arg", &self.arg_p), ("file", &self.file_p), ("layer", &self.layer_p), ("src", &self.src_p)]);
    }
}

impl crate::prelude::ToPod for ElemLift {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ElemLift", vec![("field", self.field_p.to_pod()), ("owner", self.owner_p.to_pod()), ("arg", self.arg_p.to_pod()), ("file", self.file_p.to_pod()), ("layer", self.layer_p.to_pod()), ("src", self.src_p.to_pod())])
    }
}

impl crate::prelude::FromPod for ElemLift {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ElemLift { field_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "field")?)?, owner_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "owner")?)?, arg_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "arg")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, layer_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "layer")?)?, src_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "src")?)? })
    }
}

/// `GenericUse`:
///
/// ```prism
/// type GenericUse = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct GenericUse {
    pub user_p: crate::prelude::Text,
    pub target_p: crate::prelude::Text,
    pub file_p: crate::prelude::Nat,
    pub span_p: crate::syntax::Range,
    pub types_p: crate::prelude::Array<(crate::prelude::Text, Ty)>,
}

impl crate::prelude::Show for GenericUse {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("GenericUse", &[("user", &self.user_p), ("target", &self.target_p), ("file", &self.file_p), ("span", &self.span_p), ("types", &self.types_p)]);
    }
}

impl crate::prelude::ToPod for GenericUse {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("GenericUse", vec![("user", self.user_p.to_pod()), ("target", self.target_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod()), ("types", self.types_p.to_pod())])
    }
}

impl crate::prelude::FromPod for GenericUse {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(GenericUse { user_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "user")?)?, target_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "target")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)?, types_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "types")?)? })
    }
}

/// `Incl`:
///
/// ```prism
/// type Incl = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Incl {
    pub sub_p: Rw,
    pub sup_p: Rw,
    pub file_p: crate::prelude::Nat,
    pub span_p: crate::syntax::Range,
    pub what_p: crate::prelude::Text,
    pub forward_p: bool,
}

impl crate::prelude::Show for Incl {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Incl", &[("sub", &self.sub_p), ("sup", &self.sup_p), ("file", &self.file_p), ("span", &self.span_p), ("what", &self.what_p), ("forward", &self.forward_p)]);
    }
}

impl crate::prelude::ToPod for Incl {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Incl", vec![("sub", self.sub_p.to_pod()), ("sup", self.sup_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod()), ("what", self.what_p.to_pod()), ("forward", self.forward_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Incl {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Incl { sub_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "sub")?)?, sup_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "sup")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)?, what_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "what")?)?, forward_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "forward")?)? })
    }
}

/// `Pack`:
///
/// ```prism
/// type Pack = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Pack {
    pub result_p: Ty,
    pub inner_p: Ty,
    pub file_p: crate::prelude::Nat,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for Pack {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Pack", &[("result", &self.result_p), ("inner", &self.inner_p), ("file", &self.file_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Pack {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Pack", vec![("result", self.result_p.to_pod()), ("inner", self.inner_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Pack {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Pack { result_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "result")?)?, inner_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "inner")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `Rw`:
///
/// ```prism
/// type Rw = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Rw {
    pub fams_p: crate::prelude::Array<crate::prelude::Text>,
    pub minus_p: crate::prelude::Array<crate::prelude::Text>,
    pub tail_p: Tail,
}

impl crate::prelude::Show for Rw {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Rw", &[("fams", &self.fams_p), ("minus", &self.minus_p), ("tail", &self.tail_p)]);
    }
}

impl crate::prelude::ToPod for Rw {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Rw", vec![("fams", self.fams_p.to_pod()), ("minus", self.minus_p.to_pod()), ("tail", self.tail_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Rw {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Rw { fams_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fams")?)?, minus_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "minus")?)?, tail_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tail")?)? })
    }
}

/// `Scheme`:
///
/// ```prism
/// type Scheme = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Scheme {
    pub qs_p: crate::prelude::Array<crate::prelude::Text>,
    pub plain_qs_p: crate::prelude::Array<crate::prelude::Text>,
    pub rqs_p: crate::prelude::Array<crate::prelude::Text>,
    pub cqs_p: crate::prelude::Array<crate::prelude::Text>,
    pub cjoins_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    pub bounds_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    pub eqs_p: crate::prelude::Array<Waiting>,
    pub ty_p: Ty,
}

impl crate::prelude::Show for Scheme {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Scheme", &[("qs", &self.qs_p), ("plainQs", &self.plain_qs_p), ("rqs", &self.rqs_p), ("cqs", &self.cqs_p), ("cjoins", &self.cjoins_p), ("bounds", &self.bounds_p), ("eqs", &self.eqs_p), ("ty", &self.ty_p)]);
    }
}

impl crate::prelude::ToPod for Scheme {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Scheme", vec![("qs", self.qs_p.to_pod()), ("plainQs", self.plain_qs_p.to_pod()), ("rqs", self.rqs_p.to_pod()), ("cqs", self.cqs_p.to_pod()), ("cjoins", self.cjoins_p.to_pod()), ("bounds", self.bounds_p.to_pod()), ("eqs", self.eqs_p.to_pod()), ("ty", self.ty_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Scheme {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Scheme { qs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "qs")?)?, plain_qs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "plainQs")?)?, rqs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rqs")?)?, cqs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cqs")?)?, cjoins_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cjoins")?)?, bounds_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "bounds")?)?, eqs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "eqs")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)? })
    }
}

/// `St`:
///
/// ```prism
/// type St = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct St {
    pub next_p: crate::prelude::Nat,
    pub tys_p: crate::prelude::Map<crate::prelude::Nat, Ty>,
    pub infos_p: crate::prelude::Map<crate::prelude::Nat, VInfo>,
    pub rows_p: crate::prelude::Map<crate::prelude::Nat, Rw>,
    pub lacks_p: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>>,
    pub wants_p: crate::prelude::Array<Want>,
    pub incls_p: crate::prelude::Array<Incl>,
    pub diags_p: crate::prelude::Array<crate::check::errors::CDiag>,
    pub level_p: crate::prelude::Nat,
    pub file_p: crate::prelude::Nat,
    pub color_p: Col,
    pub color_why_p: crate::prelude::Text,
    pub color_flex_p: crate::prelude::Array<(Col, crate::prelude::Text, crate::syntax::Range)>,
    pub cols_p: crate::prelude::Map<crate::prelude::Nat, Col>,
    pub cleqs_p: crate::prelude::Array<CLeq>,
    pub col_q_p: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>,
    pub col_up_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>,
    pub deferred_p: crate::prelude::Array<Waiting>,
    pub binder_at_p: crate::prelude::Map<crate::prelude::Nat, crate::syntax::Range>,
    pub row_names_p: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>,
    pub layer_qs_p: crate::prelude::Array<(Ty, crate::syntax::Range, crate::prelude::Text)>,
    pub field_qs_p: crate::prelude::Array<crate::check::types::unify::FieldQ>,
    pub recording_p: bool,
    pub typed_p: crate::check::typed::TProgram,
    pub choices_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>,
    pub size_tys_p: crate::prelude::Map<crate::prelude::Text, Ty>,
    pub unsigned_fns_p: crate::prelude::Array<crate::prelude::Text>,
    pub local_next_p: crate::prelude::Nat,
    pub local_ids_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>,
    pub any_givens_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    pub assoc_impls_p: crate::prelude::Array<AssocImpl>,
    pub plain_arms_p: crate::prelude::Array<crate::prelude::Nat>,
    pub fault_qs_p: crate::prelude::Array<Waiting>,
    pub plain_qs_p: crate::prelude::Array<Waiting>,
    pub elem_lifts_p: crate::prelude::Array<ElemLift>,
    pub fault_vars_p: crate::prelude::Array<Waiting>,
    pub binder_ids_p: crate::prelude::Array<crate::prelude::Nat>,
    pub use_ids_p: crate::prelude::Array<crate::prelude::Nat>,
    pub method_uses_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>,
    pub packs_p: crate::prelude::Array<Pack>,
    pub definition_p: crate::prelude::Text,
    pub generic_uses_p: crate::prelude::Array<GenericUse>,
}

impl crate::prelude::Show for St {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("St", &[("next", &self.next_p), ("tys", &self.tys_p), ("infos", &self.infos_p), ("rows", &self.rows_p), ("lacks", &self.lacks_p), ("wants", &self.wants_p), ("incls", &self.incls_p), ("diags", &self.diags_p), ("level", &self.level_p), ("file", &self.file_p), ("color", &self.color_p), ("colorWhy", &self.color_why_p), ("colorFlex", &self.color_flex_p), ("cols", &self.cols_p), ("cleqs", &self.cleqs_p), ("colQ", &self.col_q_p), ("colUp", &self.col_up_p), ("deferred", &self.deferred_p), ("binderAt", &self.binder_at_p), ("rowNames", &self.row_names_p), ("layerQs", &self.layer_qs_p), ("fieldQs", &self.field_qs_p), ("recording", &self.recording_p), ("typed", &self.typed_p), ("choices", &self.choices_p), ("sizeTys", &self.size_tys_p), ("unsignedFns", &self.unsigned_fns_p), ("localNext", &self.local_next_p), ("localIds", &self.local_ids_p), ("anyGivens", &self.any_givens_p), ("assocImpls", &self.assoc_impls_p), ("plainArms", &self.plain_arms_p), ("faultQs", &self.fault_qs_p), ("plainQs", &self.plain_qs_p), ("elemLifts", &self.elem_lifts_p), ("faultVars", &self.fault_vars_p), ("binderIds", &self.binder_ids_p), ("useIds", &self.use_ids_p), ("methodUses", &self.method_uses_p), ("packs", &self.packs_p), ("definition", &self.definition_p), ("genericUses", &self.generic_uses_p)]);
    }
}

impl crate::prelude::ToPod for St {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("St", vec![("next", self.next_p.to_pod()), ("tys", self.tys_p.to_pod()), ("infos", self.infos_p.to_pod()), ("rows", self.rows_p.to_pod()), ("lacks", self.lacks_p.to_pod()), ("wants", self.wants_p.to_pod()), ("incls", self.incls_p.to_pod()), ("diags", self.diags_p.to_pod()), ("level", self.level_p.to_pod()), ("file", self.file_p.to_pod()), ("color", self.color_p.to_pod()), ("colorWhy", self.color_why_p.to_pod()), ("colorFlex", self.color_flex_p.to_pod()), ("cols", self.cols_p.to_pod()), ("cleqs", self.cleqs_p.to_pod()), ("colQ", self.col_q_p.to_pod()), ("colUp", self.col_up_p.to_pod()), ("deferred", self.deferred_p.to_pod()), ("binderAt", self.binder_at_p.to_pod()), ("rowNames", self.row_names_p.to_pod()), ("layerQs", self.layer_qs_p.to_pod()), ("fieldQs", self.field_qs_p.to_pod()), ("recording", self.recording_p.to_pod()), ("typed", self.typed_p.to_pod()), ("choices", self.choices_p.to_pod()), ("sizeTys", self.size_tys_p.to_pod()), ("unsignedFns", self.unsigned_fns_p.to_pod()), ("localNext", self.local_next_p.to_pod()), ("localIds", self.local_ids_p.to_pod()), ("anyGivens", self.any_givens_p.to_pod()), ("assocImpls", self.assoc_impls_p.to_pod()), ("plainArms", self.plain_arms_p.to_pod()), ("faultQs", self.fault_qs_p.to_pod()), ("plainQs", self.plain_qs_p.to_pod()), ("elemLifts", self.elem_lifts_p.to_pod()), ("faultVars", self.fault_vars_p.to_pod()), ("binderIds", self.binder_ids_p.to_pod()), ("useIds", self.use_ids_p.to_pod()), ("methodUses", self.method_uses_p.to_pod()), ("packs", self.packs_p.to_pod()), ("definition", self.definition_p.to_pod()), ("genericUses", self.generic_uses_p.to_pod())])
    }
}

impl crate::prelude::FromPod for St {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(St { next_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "next")?)?, tys_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tys")?)?, infos_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "infos")?)?, rows_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rows")?)?, lacks_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lacks")?)?, wants_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "wants")?)?, incls_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "incls")?)?, diags_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "diags")?)?, level_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "level")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, color_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "color")?)?, color_why_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "colorWhy")?)?, color_flex_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "colorFlex")?)?, cols_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cols")?)?, cleqs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cleqs")?)?, col_q_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "colQ")?)?, col_up_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "colUp")?)?, deferred_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "deferred")?)?, binder_at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "binderAt")?)?, row_names_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rowNames")?)?, layer_qs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "layerQs")?)?, field_qs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fieldQs")?)?, recording_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "recording")?)?, typed_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "typed")?)?, choices_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "choices")?)?, size_tys_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "sizeTys")?)?, unsigned_fns_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "unsignedFns")?)?, local_next_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "localNext")?)?, local_ids_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "localIds")?)?, any_givens_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "anyGivens")?)?, assoc_impls_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "assocImpls")?)?, plain_arms_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "plainArms")?)?, fault_qs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "faultQs")?)?, plain_qs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "plainQs")?)?, elem_lifts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "elemLifts")?)?, fault_vars_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "faultVars")?)?, binder_ids_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "binderIds")?)?, use_ids_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "useIds")?)?, method_uses_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "methodUses")?)?, packs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "packs")?)?, definition_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "definition")?)?, generic_uses_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "genericUses")?)? })
    }
}

/// `Tail`:
///
/// ```prism
/// type Tail = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Tail {
    TlClosed,
    TlFlex(crate::prelude::Nat),
    TlRigid(crate::prelude::Text),
    TlQ(crate::prelude::Text),
}

impl crate::prelude::Show for Tail {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Tail::TlClosed => p.choice("TlClosed", &[]),
            Tail::TlFlex(a0) => p.choice("TlFlex", &[a0]),
            Tail::TlRigid(a0) => p.choice("TlRigid", &[a0]),
            Tail::TlQ(a0) => p.choice("TlQ", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for Tail {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Tail::TlClosed => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TlClosed", 0), vec![]),
            Tail::TlFlex(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TlFlex", 1), vec![a0.to_pod()]),
            Tail::TlRigid(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TlRigid", 2), vec![a0.to_pod()]),
            Tail::TlQ(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TlQ", 3), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Tail {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "TlClosed" && a.len() == 0 => ::std::result::Result::Ok(Tail::TlClosed),
            crate::prelude::Pod::Choice(c, a) if &**c == "TlFlex" && a.len() == 1 => ::std::result::Result::Ok(Tail::TlFlex(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TlRigid" && a.len() == 1 => ::std::result::Result::Ok(Tail::TlRigid(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TlQ" && a.len() == 1 => ::std::result::Result::Ok(Tail::TlQ(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a Tail", other),
        }
    }
}

/// `Ty`:
///
/// ```prism
/// type Ty = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Ty {
    TyFlex(crate::prelude::Nat),
    TyRigid(crate::prelude::Text),
    TyQ(crate::prelude::Text),
    TyCon(crate::prelude::Text, crate::prelude::Array<Ty>),
    TyFn(Col, crate::prelude::Array<Ty>, ::std::rc::Rc<Ty>),
    TyTuple(crate::prelude::Array<Ty>),
    TyArray(::std::rc::Rc<Ty>),
    TyMap(::std::rc::Rc<Ty>, ::std::rc::Rc<Ty>),
    TySig(crate::prelude::Text, ::std::rc::Rc<Ty>),
    TyAt(::std::rc::Rc<Ty>, Rw),
    TyElem(Rw, ::std::rc::Rc<Ty>),
    TyElemAny(Rw),
    TyAssoc(crate::prelude::Text, crate::prelude::Text, ::std::rc::Rc<Ty>),
    TyAny(crate::prelude::Array<crate::prelude::Text>),
    TyErr,
}

impl crate::prelude::Show for Ty {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Ty::TyFlex(a0) => p.choice("TyFlex", &[a0]),
            Ty::TyRigid(a0) => p.choice("TyRigid", &[a0]),
            Ty::TyQ(a0) => p.choice("TyQ", &[a0]),
            Ty::TyCon(a0, a1) => p.choice("TyCon", &[a0, a1]),
            Ty::TyFn(a0, a1, a2) => p.choice("TyFn", &[a0, a1, a2]),
            Ty::TyTuple(a0) => p.choice("TyTuple", &[a0]),
            Ty::TyArray(a0) => p.choice("TyArray", &[a0]),
            Ty::TyMap(a0, a1) => p.choice("TyMap", &[a0, a1]),
            Ty::TySig(a0, a1) => p.choice("TySig", &[a0, a1]),
            Ty::TyAt(a0, a1) => p.choice("TyAt", &[a0, a1]),
            Ty::TyElem(a0, a1) => p.choice("TyElem", &[a0, a1]),
            Ty::TyElemAny(a0) => p.choice("TyElemAny", &[a0]),
            Ty::TyAssoc(a0, a1, a2) => p.choice("TyAssoc", &[a0, a1, a2]),
            Ty::TyAny(a0) => p.choice("TyAny", &[a0]),
            Ty::TyErr => p.choice("TyErr", &[]),
        }
    }
}

impl crate::prelude::ToPod for Ty {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Ty::TyFlex(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TyFlex", 0), vec![a0.to_pod()]),
            Ty::TyRigid(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TyRigid", 1), vec![a0.to_pod()]),
            Ty::TyQ(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TyQ", 2), vec![a0.to_pod()]),
            Ty::TyCon(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TyCon", 3), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyFn(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TyFn", 4), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ty::TyTuple(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TyTuple", 5), vec![a0.to_pod()]),
            Ty::TyArray(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TyArray", 6), vec![a0.to_pod()]),
            Ty::TyMap(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TyMap", 7), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TySig(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TySig", 8), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyAt(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TyAt", 9), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyElem(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TyElem", 10), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyElemAny(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TyElemAny", 11), vec![a0.to_pod()]),
            Ty::TyAssoc(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TyAssoc", 12), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ty::TyAny(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TyAny", 13), vec![a0.to_pod()]),
            Ty::TyErr => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TyErr", 14), vec![]),
        }
    }
}

impl crate::prelude::FromPod for Ty {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "TyFlex" && a.len() == 1 => ::std::result::Result::Ok(Ty::TyFlex(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TyRigid" && a.len() == 1 => ::std::result::Result::Ok(Ty::TyRigid(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TyQ" && a.len() == 1 => ::std::result::Result::Ok(Ty::TyQ(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TyCon" && a.len() == 2 => ::std::result::Result::Ok(Ty::TyCon(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TyFn" && a.len() == 3 => ::std::result::Result::Ok(Ty::TyFn(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TyTuple" && a.len() == 1 => ::std::result::Result::Ok(Ty::TyTuple(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TyArray" && a.len() == 1 => ::std::result::Result::Ok(Ty::TyArray(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TyMap" && a.len() == 2 => ::std::result::Result::Ok(Ty::TyMap(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TySig" && a.len() == 2 => ::std::result::Result::Ok(Ty::TySig(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TyAt" && a.len() == 2 => ::std::result::Result::Ok(Ty::TyAt(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TyElem" && a.len() == 2 => ::std::result::Result::Ok(Ty::TyElem(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TyElemAny" && a.len() == 1 => ::std::result::Result::Ok(Ty::TyElemAny(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TyAssoc" && a.len() == 3 => ::std::result::Result::Ok(Ty::TyAssoc(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TyAny" && a.len() == 1 => ::std::result::Result::Ok(Ty::TyAny(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TyErr" && a.len() == 0 => ::std::result::Result::Ok(Ty::TyErr),
            other => ::prism_rtl::pod::mismatch("a Ty", other),
        }
    }
}

/// `VInfo`:
///
/// ```prism
/// type VInfo = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct VInfo {
    pub plain_p: bool,
    pub level_p: crate::prelude::Nat,
    pub name_p: crate::prelude::Text,
}

impl crate::prelude::Show for VInfo {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("VInfo", &[("plain", &self.plain_p), ("level", &self.level_p), ("name", &self.name_p)]);
    }
}

impl crate::prelude::ToPod for VInfo {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("VInfo", vec![("plain", self.plain_p.to_pod()), ("level", self.level_p.to_pod()), ("name", self.name_p.to_pod())])
    }
}

impl crate::prelude::FromPod for VInfo {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(VInfo { plain_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "plain")?)?, level_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "level")?)?, name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)? })
    }
}

/// `Waiting`:
///
/// ```prism
/// type Waiting = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Waiting {
    pub expected_p: Ty,
    pub found_p: Ty,
    pub span_p: crate::syntax::Range,
    pub file_p: crate::prelude::Nat,
}

impl crate::prelude::Show for Waiting {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Waiting", &[("expected", &self.expected_p), ("found", &self.found_p), ("span", &self.span_p), ("file", &self.file_p)]);
    }
}

impl crate::prelude::ToPod for Waiting {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Waiting", vec![("expected", self.expected_p.to_pod()), ("found", self.found_p.to_pod()), ("span", self.span_p.to_pod()), ("file", self.file_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Waiting {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Waiting { expected_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "expected")?)?, found_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "found")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)? })
    }
}

/// `Want`:
///
/// ```prism
/// type Want = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Want {
    pub cls_p: crate::prelude::Text,
    pub ty_p: Ty,
    pub file_p: crate::prelude::Nat,
    pub span_p: crate::syntax::Range,
    pub level_p: crate::prelude::Nat,
}

impl crate::prelude::Show for Want {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Want", &[("cls", &self.cls_p), ("ty", &self.ty_p), ("file", &self.file_p), ("span", &self.span_p), ("level", &self.level_p)]);
    }
}

impl crate::prelude::ToPod for Want {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Want", vec![("cls", self.cls_p.to_pod()), ("ty", self.ty_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod()), ("level", self.level_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Want {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Want { cls_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cls")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)?, level_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "level")?)? })
    }
}

/// ```prism
/// UseKey: fn Nat, Range -> Text
/// ```
pub fn use_key_f(file_p0: &crate::prelude::Nat, span_p1: &crate::syntax::Range) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{}:{}:{}", file_p0, &span_p1.start_p, &span_p1.end_p))
}

/// ```prism
/// NewSt: fn Nat -> St
/// ```
pub fn new_st_f(file_p0: &crate::prelude::Nat) -> St {
    St { next_p: crate::prelude::Nat::from(0u32), tys_p: crate::prelude::Map::new(), infos_p: crate::prelude::Map::new(), rows_p: crate::prelude::Map::new(), lacks_p: crate::prelude::Map::new(), wants_p: crate::prelude::Array::new(), incls_p: crate::prelude::Array::new(), diags_p: crate::prelude::Array::new(), level_p: crate::prelude::Nat::from(0u32), file_p: file_p0.clone(), color_p: Col::CBound, color_why_p: crate::prelude::Text::lit(""), color_flex_p: crate::prelude::Array::new(), cols_p: crate::prelude::Map::new(), cleqs_p: crate::prelude::Array::new(), col_q_p: crate::prelude::Map::new(), col_up_p: crate::prelude::Map::new(), deferred_p: crate::prelude::Array::new(), binder_at_p: crate::prelude::Map::new(), row_names_p: crate::prelude::Map::new(), layer_qs_p: crate::prelude::Array::new(), field_qs_p: crate::prelude::Array::new(), recording_p: false, typed_p: crate::check::typed::empty_typed_p(), choices_p: crate::prelude::Map::new(), size_tys_p: crate::prelude::Map::new(), unsigned_fns_p: crate::prelude::Array::new(), local_next_p: crate::prelude::Nat::from(0u32), local_ids_p: crate::prelude::Map::new(), any_givens_p: crate::prelude::Array::new(), assoc_impls_p: crate::prelude::Array::new(), plain_arms_p: crate::prelude::Array::new(), fault_qs_p: crate::prelude::Array::new(), plain_qs_p: crate::prelude::Array::new(), elem_lifts_p: crate::prelude::Array::new(), fault_vars_p: crate::prelude::Array::new(), binder_ids_p: crate::prelude::Array::new(), use_ids_p: crate::prelude::Array::new(), method_uses_p: crate::prelude::Map::new(), packs_p: crate::prelude::Array::new(), definition_p: crate::prelude::Text::lit(""), generic_uses_p: crate::prelude::Array::new() }
}

/// ```prism
/// Closed: fn [Text] -> Rw
/// ```
pub fn closed_f(fs_p0: &crate::prelude::Array<crate::prelude::Text>) -> Rw {
    Rw { fams_p: sort_texts_f(fs_p0), minus_p: crate::prelude::Array::new(), tail_p: Tail::TlClosed }
}

/// ```prism
/// let emptyRow
/// ```
pub fn empty_row_p() -> Rw {
    Rw { fams_p: crate::prelude::Array::new(), minus_p: crate::prelude::Array::new(), tail_p: Tail::TlClosed }
}

/// ```prism
/// let tInt
/// ```
pub fn t_int_p() -> Ty {
    Ty::TyCon(crate::prelude::Text::lit("Int"), crate::prelude::Array::new())
}

/// ```prism
/// let tNat
/// ```
pub fn t_nat_p() -> Ty {
    Ty::TyCon(crate::prelude::Text::lit("Nat"), crate::prelude::Array::new())
}

/// ```prism
/// let tText
/// ```
pub fn t_text_p() -> Ty {
    Ty::TyCon(crate::prelude::Text::lit("Text"), crate::prelude::Array::new())
}

/// ```prism
/// let tBool
/// ```
pub fn t_bool_p() -> Ty {
    Ty::TyCon(crate::prelude::Text::lit("Bool"), crate::prelude::Array::new())
}

/// ```prism
/// let tUnit
/// ```
pub fn t_unit_p() -> Ty {
    Ty::TyCon(crate::prelude::Text::lit("unit"), crate::prelude::Array::new())
}

/// ```prism
/// let quotientTrait
/// ```
pub fn quotient_trait_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("Prelude.Num")
}

/// ```prism
/// let tChar
/// ```
pub fn t_char_p() -> Ty {
    Ty::TyCon(crate::prelude::Text::lit("Char"), crate::prelude::Array::new())
}

/// ```prism
/// let tFloat
/// ```
pub fn t_float_p() -> Ty {
    Ty::TyCon(crate::prelude::Text::lit("Float"), crate::prelude::Array::new())
}

/// ```prism
/// HasText: fn [Text], Text -> Bool
/// ```
pub fn has_text_f(xs_p0: &crate::prelude::Array<crate::prelude::Text>, x_p1: &crate::prelude::Text) -> bool {
    crate::prelude::fold(xs_p0, &false, &(|seen_p2: &bool, y_p3: &crate::prelude::Text| *seen_p2 || (y_p3 == x_p1)))
}

/// ```prism
/// HasNat: fn [Nat], Nat -> Bool
/// ```
pub fn has_nat_f(xs_p0: &crate::prelude::Array<crate::prelude::Nat>, x_p1: &crate::prelude::Nat) -> bool {
    crate::prelude::fold(xs_p0, &false, &(|seen_p2: &bool, y_p3: &crate::prelude::Nat| *seen_p2 || (y_p3 == x_p1)))
}

/// ```prism
/// AddText: fn [Text], Text -> [Text]
/// ```
pub fn add_text_f(xs_p0: &crate::prelude::Array<crate::prelude::Text>, x_p1: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    if has_text_f(xs_p0, x_p1) { xs_p0.clone() } else { crate::prelude::push(xs_p0, x_p1) }
}

/// ```prism
/// UnionTexts: fn [Text], [Text] -> [Text]
/// ```
pub fn union_texts_f(xs_p0: &crate::prelude::Array<crate::prelude::Text>, ys_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::fold(ys_p1, xs_p0, &(|acc_p2: &crate::prelude::Array<crate::prelude::Text>, y_p3: &crate::prelude::Text| add_text_f(acc_p2, y_p3)))
}

/// ```prism
/// MinusTexts: fn [Text], [Text] -> [Text]
/// ```
pub fn minus_texts_f(xs_p0: &crate::prelude::Array<crate::prelude::Text>, ys_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::filter(xs_p0, &(|x_p2: &crate::prelude::Text| !has_text_f(ys_p1, x_p2)))
}

/// ```prism
/// InterTexts: fn [Text], [Text] -> [Text]
/// ```
pub fn inter_texts_f(xs_p0: &crate::prelude::Array<crate::prelude::Text>, ys_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::filter(xs_p0, &(|x_p2: &crate::prelude::Text| has_text_f(ys_p1, x_p2)))
}

/// ```prism
/// AddNat: fn [Nat], Nat -> [Nat]
/// ```
pub fn add_nat_f(xs_p0: &crate::prelude::Array<crate::prelude::Nat>, x_p1: &crate::prelude::Nat) -> crate::prelude::Array<crate::prelude::Nat> {
    if has_nat_f(xs_p0, x_p1) { xs_p0.clone() } else { crate::prelude::push(xs_p0, x_p1) }
}

/// ```prism
/// SortTexts: fn [Text] -> [Text]
/// ```
pub fn sort_texts_f(xs_p0: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::fold(xs_p0, &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<crate::prelude::Text>, x_p2: &crate::prelude::Text| if has_text_f(acc_p1, x_p2) {
        acc_p1.clone()
    } else {
        crate::prelude::append(&crate::prelude::push(&crate::prelude::filter(acc_p1, &(|y_p3: &crate::prelude::Text| y_p3 < x_p2)), x_p2), &crate::prelude::filter(acc_p1, &(|y_p4: &crate::prelude::Text| !(y_p4 < x_p2))))
    }))
}

/// ```prism
/// BareName: fn Text -> Text
/// ```
pub fn bare_name_f(q_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::or(&crate::syntax::lexer::chars::last_o(&crate::prelude::split_on(q_p0, &crate::prelude::Text::lit("."))), q_p0)
}

/// ```prism
/// FreshVar: fn St, Bool, Text -> ((Ty, St))
/// ```
pub fn fresh_var_f(st_p0: &St, plain_p1: &bool, name_p2: &crate::prelude::Text) -> (Ty, St) {
    let n_p3 = st_p0.next_p.clone();
    let st2_p4 = {
        let mut this: St = st_p0.clone();
        this.next_p = &this.next_p + &crate::prelude::Nat::from(1u32);
        this.infos_p = crate::prelude::insert(&this.infos_p, &n_p3, &VInfo { plain_p: *plain_p1, level_p: this.level_p.clone(), name_p: name_p2.clone() });
        this
    };
    (Ty::TyFlex(n_p3.clone()), st2_p4.clone())
}

/// ```prism
/// FreshCol: fn St -> ((Col, St))
/// ```
pub fn fresh_col_f(st_p0: &St) -> (Col, St) {
    let n_p1 = st_p0.next_p.clone();
    let st2_p2 = {
        let mut this: St = st_p0.clone();
        this.next_p = &this.next_p + &crate::prelude::Nat::from(1u32);
        this.infos_p = crate::prelude::insert(&this.infos_p, &n_p1, &VInfo { plain_p: false, level_p: this.level_p.clone(), name_p: crate::prelude::Text::lit("") });
        this
    };
    (Col::CFlex(n_p1.clone()), st2_p2.clone())
}

/// ```prism
/// StackOf: unbounded fn St, Ty -> Text
/// ```
pub fn stack_of_f(st_p0: &St, t_p1: &Ty) -> crate::prelude::Text {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        Ty::TySig(s_p2, i_p3) => crate::prelude::Text::from(format!("{}{}", &s_p2, &stack_of_f(st_p0, &*i_p3))),
        Ty::TyAt(i_p4, _) => crate::prelude::Text::from(format!("@{}", &stack_of_f(st_p0, &*i_p4))),
        _ => crate::prelude::Text::lit(""),
    }
}

/// The step machine of `StackOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StackOf: unbounded fn St, Ty -> Text
/// ```
pub struct StackOf {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl ::prism_rtl::Job<crate::prelude::Text> for StackOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_13344: Ty| match walk_f_13344 {
            Ty::TySig(s_p2, i_p3) => crate::prelude::call_then(start_stack_of_f(st_p0x.clone(), (*i_p3).clone()), move |stack_of_f_13377: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}", &s_p2, &stack_of_f_13377)))),
            Ty::TyAt(i_p4, _) => crate::prelude::call_then(start_stack_of_f(st_p0x.clone(), (*i_p4).clone()), move |stack_of_f_13416: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("@{}", &stack_of_f_13416)))),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("")),
        })
    }
}

/// `Start StackOf, x`: what the function value is when passed to `@Run`.
pub fn start_stack_of_f(st_p0: St, t_p1: Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(StackOf { st_p0, t_p1 })
}

/// ```prism
/// HeadSigil: unbounded fn St, Ty -> Text
/// ```
pub fn head_sigil_f(st_p0: &St, t_p1: &Ty) -> crate::prelude::Text {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        Ty::TySig(s_p2, _) => s_p2,
        Ty::TyAt(_, _) => crate::prelude::Text::lit("@"),
        _ => crate::prelude::Text::lit(""),
    }
}

/// The step machine of `HeadSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HeadSigil: unbounded fn St, Ty -> Text
/// ```
pub struct HeadSigil {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl ::prism_rtl::Job<crate::prelude::Text> for HeadSigil {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_13594: Ty| match walk_f_13594 {
            Ty::TySig(s_p2, _) => ::prism_rtl::Turn::Finished(s_p2.clone()),
            Ty::TyAt(_, _) => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("@")),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("")),
        })
    }
}

/// `Start HeadSigil, x`: what the function value is when passed to `@Run`.
pub fn start_head_sigil_f(st_p0: St, t_p1: Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(HeadSigil { st_p0, t_p1 })
}

/// ```prism
/// IsFlexVar: unbounded fn St, Ty -> Bool
/// ```
pub fn is_flex_var_f(st_p0: &St, t_p1: &Ty) -> bool {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        Ty::TyFlex(_) => true,
        _ => false,
    }
}

/// The step machine of `IsFlexVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsFlexVar: unbounded fn St, Ty -> Bool
/// ```
pub struct IsFlexVar {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl ::prism_rtl::Job<bool> for IsFlexVar {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_13743: Ty| match walk_f_13743 {
            Ty::TyFlex(_) => ::prism_rtl::Turn::Finished(true),
            _ => ::prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start IsFlexVar, x`: what the function value is when passed to `@Run`.
pub fn start_is_flex_var_f(st_p0: St, t_p1: Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsFlexVar { st_p0, t_p1 })
}

/// ```prism
/// IsFreeHeaded: unbounded fn St, Ty -> Bool
/// ```
pub fn is_free_headed_f(st_p0: &St, t_p1: &Ty) -> bool {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        Ty::TyFlex(n_p2) => !crate::check::types::recording::info_of_f(st_p0, &n_p2).plain_p,
        _ => false,
    }
}

/// The step machine of `IsFreeHeaded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsFreeHeaded: unbounded fn St, Ty -> Bool
/// ```
pub struct IsFreeHeaded {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl ::prism_rtl::Job<bool> for IsFreeHeaded {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_13951: Ty| match walk_f_13951 {
            Ty::TyFlex(n_p2) => ::prism_rtl::Turn::Finished(!crate::check::types::recording::info_of_f(&st_p0x, &n_p2).plain_p),
            _ => ::prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start IsFreeHeaded, x`: what the function value is when passed to `@Run`.
pub fn start_is_free_headed_f(st_p0: St, t_p1: Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsFreeHeaded { st_p0, t_p1 })
}

/// ```prism
/// NonEmptyOf: fn Ty -> Ty
/// ```
pub fn non_empty_of_f(c_p0: &Ty) -> Ty {
    Ty::TyCon(crate::prelude::Text::lit("Prelude.NonEmpty"), crate::prelude::Array::from(vec![c_p0.clone()]))
}

/// ```prism
/// AnswerType: fn Rw -> Ty
/// ```
pub fn answer_type_f(rw_p0: &Rw) -> Ty {
    Ty::TyCon(crate::prelude::Text::lit("Answer"), crate::prelude::Array::from(vec![Ty::TyElemAny(rw_p0.clone())]))
}

/// ```prism
/// AnswerOfOutput: fn Ty -> Ty
/// ```
pub fn answer_of_output_f(out_p0: &Ty) -> Ty {
    match without_time_f(out_p0) {
        Ty::TyTuple(parts_p1) => crate::prelude::fold(&parts_p1, &Ty::TyTuple(parts_p1.clone()), &(|found_p2: &Ty, part_p3: &Ty| match part_p3 {
            Ty::TySig(m14878_0_0, inner_p4) if (m14878_0_0 == &crate::prelude::Text::lit("!")) => without_time_f(&**inner_p4),
            _ => found_p2.clone(),
            _ => unreachable!("no arm matched"),
        })),
        value_p5 => value_p5,
    }
}

/// ```prism
/// WithoutTime: fn Ty -> Ty
/// ```
pub fn without_time_f(t_p0: &Ty) -> Ty {
    match t_p0 {
        Ty::TySig(m15021_0_0, inner_p1) if (m15021_0_0 == &crate::prelude::Text::lit("$")) => without_time_f(&**inner_p1),
        Ty::TySig(m15021_1_0, inner_p2) if (m15021_1_0 == &crate::prelude::Text::lit("!")) => without_time_f(&**inner_p2),
        _ => t_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsPlainCollection: unbounded fn St, Ty -> Bool
/// ```
pub fn is_plain_collection_f(st_p0: &St, t_p1: &Ty) -> bool {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        Ty::TyArray(_) => true,
        Ty::TyMap(_, _) => true,
        _ => false,
    }
}

/// The step machine of `IsPlainCollection`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsPlainCollection: unbounded fn St, Ty -> Bool
/// ```
pub struct IsPlainCollection {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl ::prism_rtl::Job<bool> for IsPlainCollection {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_15259: Ty| match walk_f_15259 {
            Ty::TyArray(_) => ::prism_rtl::Turn::Finished(true),
            Ty::TyMap(_, _) => ::prism_rtl::Turn::Finished(true),
            _ => ::prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start IsPlainCollection, x`: what the function value is when passed to `@Run`.
pub fn start_is_plain_collection_f(st_p0: St, t_p1: Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsPlainCollection { st_p0, t_p1 })
}

/// ```prism
/// ?NonEmptyColl: unbounded fn St, Ty -> ?Ty
/// ```
pub fn non_empty_coll_o(st_p0: &St, t_p1: &Ty) -> ::std::option::Option<Ty> {
    'm15472: {
        let scrutinee = &crate::check::types::recording::walk_f(st_p0, t_p1);
        if let Ty::TyCon(m15472_0_0, m15472_0_1) = scrutinee && (m15472_0_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m15472_0_1.len() == 1) && let ::std::option::Option::Some(c_p2) = crate::prelude::index(m15472_0_1, &crate::prelude::Nat::from(0u32)) {
            break 'm15472 ::std::option::Option::Some(c_p2.clone());
        }
        ::std::option::Option::None
    }
}

/// The step machine of `NonEmptyColl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?NonEmptyColl: unbounded fn St, Ty -> ?Ty
/// ```
pub struct NonEmptyColl {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl ::prism_rtl::Job<::std::option::Option<Ty>> for NonEmptyColl {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<Ty>> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_15478: Ty| 'm15472: {
            if let Ty::TyCon(m15472_0_0, m15472_0_1) = &walk_f_15478 && (m15472_0_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m15472_0_1.len() == 1) && let ::std::option::Option::Some(c_p2) = crate::prelude::index(m15472_0_1, &crate::prelude::Nat::from(0u32)) {
                break 'm15472 ::prism_rtl::Turn::Finished(::std::option::Option::Some(c_p2.clone()));
            }
            ::prism_rtl::Turn::Finished(::std::option::Option::None)
        })
    }
}

/// `Start NonEmptyColl, x`: what the function value is when passed to `@Run`.
pub fn start_non_empty_coll_o(st_p0: St, t_p1: Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<Ty>>> {
    ::std::rc::Rc::new(NonEmptyColl { st_p0, t_p1 })
}

/// ```prism
/// WithMarks: fn Text, Ty, Rw -> Ty
/// ```
pub fn with_marks_f(marks_p0: &crate::prelude::Text, t_p1: &Ty, rw_p2: &Rw) -> Ty {
    crate::prelude::fold(&reverse2_f(&crate::syntax::lexer::chars::fold_chars_f(marks_p0, &crate::prelude::Array::new(), &(::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| crate::prelude::once_job(move || {
        let acc_p3 = p0;
        let c_p4 = p1;
        ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p3, &c_p4))
    })) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>))), t_p1, &(|acc_p5: &Ty, m_p6: &crate::prelude::Text| if m_p6 == &crate::prelude::Text::lit("@") {
        Ty::TyAt(::std::rc::Rc::new(acc_p5.clone()), rw_p2.clone())
    } else {
        Ty::TySig(m_p6.clone(), ::std::rc::Rc::new(acc_p5.clone()))
    }))
}

/// ```prism
/// Reverse2: fn [Text] -> [Text]
/// ```
pub fn reverse2_f(xs_p0: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::fold(xs_p0, &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<crate::prelude::Text>, x_p2: &crate::prelude::Text| crate::prelude::append(&crate::prelude::Array::from(vec![x_p2.clone()]), acc_p1)))
}

/// ```prism
/// ShowTy: unbounded fn St, Ty -> Text
/// ```
pub fn show_ty_f(st_p0: &St, t_p1: &Ty) -> crate::prelude::Text {
    show_ty_in_f(st_p0, &crate::check::types::recording::zonk_f(st_p0, t_p1), &false)
}

/// The step machine of `ShowTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowTy: unbounded fn St, Ty -> Text
/// ```
pub struct ShowTy {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ShowTy {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x.clone(), t_p1x.clone()), move |zonk_f_16204: Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(ShowTyIn { st_p0: st_p0x.clone(), t_p1: zonk_f_16204, nested_p2: false })))
    }
}

/// `Start ShowTy, x`: what the function value is when passed to `@Run`.
pub fn start_show_ty_f(st_p0: St, t_p1: Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ShowTy { st_p0, t_p1 })
}

/// ```prism
/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
/// ```
pub fn show_ty_in_f(st_p0: &St, t_p1: &Ty, nested_p2: &bool) -> crate::prelude::Text {
    'm16366: {
        if let Ty::TyFlex(n_p3) = t_p1 {
            break 'm16366 crate::prelude::Text::from(format!("t{}", n_p3));
        }
        if let Ty::TyRigid(n_p4) = t_p1 {
            break 'm16366 n_p4.clone();
        }
        if let Ty::TyQ(n_p5) = t_p1 {
            break 'm16366 n_p5.clone();
        }
        if let Ty::TyCon(n_p6, m16366_3_1) = t_p1 && (m16366_3_1.len() == 0) {
            break 'm16366 bare_name_f(n_p6);
        }
        if let Ty::TyCon(m16366_4_0, m16366_4_1) = t_p1 && (m16366_4_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m16366_4_1.len() == 1) && let ::std::option::Option::Some(c_p7) = crate::prelude::index(m16366_4_1, &crate::prelude::Nat::from(0u32)) {
            break 'm16366 crate::prelude::Text::from(format!("{}+", &show_ty_in_f(st_p0, &c_p7, &true)));
        }
        if let Ty::TyCon(m16366_5_0, m16366_5_1) = t_p1 && (m16366_5_0 == &crate::prelude::Text::lit("Answer")) && (m16366_5_1.len() == 1) && let ::std::option::Option::Some(Ty::TyElemAny(rw_p8)) = crate::prelude::index(m16366_5_1, &crate::prelude::Nat::from(0u32)) {
            break 'm16366 if *nested_p2 {
                crate::prelude::Text::from(format!("(Answer {})", &show_row_in_f(&rw_p8, &true)))
            } else {
                crate::prelude::Text::from(format!("Answer {}", &show_row_in_f(&rw_p8, &true)))
            };
        }
        if let Ty::TyCon(n_p9, args_pa) = t_p1 {
            break 'm16366 {
                let inner_pb = crate::prelude::Text::from(format!("{}{}", &bare_name_f(n_p9), &crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(args_pa.clone(), {
                    let st_p0x = st_p0.clone();
                    ::std::rc::Rc::new(move |p0: Ty| {
                        let st_p0xy = st_p0x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pc = p0;
                            crate::prelude::call_then(start_show_ty_in_f(st_p0xy.clone(), a_pc.clone(), true), move |show_ty_in_f_16716: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(" {}", &show_ty_in_f_16716))))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                })))));
                if *nested_p2 {
                    crate::prelude::Text::from(format!("({})", &inner_pb))
                } else {
                    inner_pb.clone()
                }
            };
        }
        if let Ty::TyFn(c_pd, ps_pe, res_pf) = t_p1 {
            break 'm16366 {
                let inner_pg = crate::prelude::Text::from(format!("{}fn {} -> {}", &show_col_f(c_pd), &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_pe.clone(), {
                    let st_p0x = st_p0.clone();
                    ::std::rc::Rc::new(move |p0: Ty| {
                        let st_p0xy = st_p0x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let p_ph = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ShowTyIn { st_p0: st_p0xy.clone(), t_p1: p_ph.clone(), nested_p2: false }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                })), &crate::prelude::Text::lit(", ")), &show_ty_in_f(st_p0, &**res_pf, &false)));
                if *nested_p2 {
                    crate::prelude::Text::from(format!("({})", &inner_pg))
                } else {
                    inner_pg.clone()
                }
            };
        }
        if let Ty::TyTuple(ts_pi) = t_p1 {
            break 'm16366 crate::prelude::Text::from(format!("(({}))", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ts_pi.clone(), {
                let st_p0x = st_p0.clone();
                ::std::rc::Rc::new(move |p0: Ty| {
                    let st_p0xy = st_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_pj = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ShowTyIn { st_p0: st_p0xy.clone(), t_p1: a_pj.clone(), nested_p2: false }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            })), &crate::prelude::Text::lit(", "))));
        }
        if let Ty::TyArray(e_pk) = t_p1 {
            break 'm16366 {
                let inner_pl = show_ty_in_f(st_p0, &**e_pk, &false);
                if crate::syntax::lexer::chars::has_prefix_f(&inner_pl, &crate::prelude::Text::lit("[")) {
                    crate::prelude::Text::from(format!("[ {} ]", &inner_pl))
                } else {
                    crate::prelude::Text::from(format!("[{}]", &inner_pl))
                }
            };
        }
        if let Ty::TyMap(k_pm, v_pn) = t_p1 {
            break 'm16366 {
                let inner_po = crate::prelude::Text::from(format!("{} ==> {}", &show_ty_in_f(st_p0, &**k_pm, &true), &show_ty_in_f(st_p0, &**v_pn, &true)));
                if *nested_p2 {
                    crate::prelude::Text::from(format!("({})", &inner_po))
                } else {
                    inner_po.clone()
                }
            };
        }
        if let Ty::TySig(s_pp, i_pq) = t_p1 {
            break 'm16366 crate::prelude::Text::from(format!("{}{}", s_pp, &show_ty_in_f(st_p0, &**i_pq, &true)));
        }
        if let Ty::TyAt(i_pr, rw_ps) = t_p1 {
            break 'm16366 crate::prelude::Text::from(format!("@{}", &show_ty_in_f(st_p0, &**i_pr, &true)));
        }
        if let Ty::TyElem(rw_pt, o_pu) = t_p1 {
            break 'm16366 {
                let inner_pv = crate::prelude::Text::from(format!("Element {} {}", &show_row_in_f(rw_pt, &true), &show_ty_in_f(st_p0, &**o_pu, &true)));
                if *nested_p2 {
                    crate::prelude::Text::from(format!("({})", &inner_pv))
                } else {
                    inner_pv.clone()
                }
            };
        }
        if let Ty::TyElemAny(rw_p10) = t_p1 {
            break 'm16366 if *nested_p2 {
                crate::prelude::Text::from(format!("(Elem {})", &show_row_in_f(rw_p10, &true)))
            } else {
                crate::prelude::Text::from(format!("Elem {}", &show_row_in_f(rw_p10, &true)))
            };
        }
        if let Ty::TyAssoc(_, n_p11, a_p12) = t_p1 {
            break 'm16366 if *nested_p2 {
                crate::prelude::Text::from(format!("({} {})", n_p11, &show_ty_in_f(st_p0, &**a_p12, &true)))
            } else {
                crate::prelude::Text::from(format!("{} {}", n_p11, &show_ty_in_f(st_p0, &**a_p12, &true)))
            };
        }
        if let Ty::TyAny(ts_p13) = t_p1 {
            break 'm16366 crate::prelude::Text::from(format!("any {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(ts_p13, &(|x_p14: &crate::prelude::Text| crate::prelude::Text::from(format!("^{}", &bare_name_f(x_p14))))), &crate::prelude::Text::lit(" "))));
        }
        if let Ty::TyErr = t_p1 {
            break 'm16366 crate::prelude::Text::lit("?");
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ShowTyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
/// ```
pub struct ShowTyIn {
    pub st_p0: St,
    pub t_p1: Ty,
    pub nested_p2: bool,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ShowTyIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let nested_p2 = &self.nested_p2;
        'm16366: {
            if let Ty::TyFlex(n_p3) = t_p1 {
                break 'm16366 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("t{}", n_p3)));
            }
            if let Ty::TyRigid(n_p4) = t_p1 {
                break 'm16366 ::prism_rtl::Turn::Finished(n_p4.clone());
            }
            if let Ty::TyQ(n_p5) = t_p1 {
                break 'm16366 ::prism_rtl::Turn::Finished(n_p5.clone());
            }
            if let Ty::TyCon(n_p6, m16366_3_1) = t_p1 && (m16366_3_1.len() == 0) {
                break 'm16366 ::prism_rtl::Turn::Finished(bare_name_f(n_p6));
            }
            if let Ty::TyCon(m16366_4_0, m16366_4_1) = t_p1 && (m16366_4_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m16366_4_1.len() == 1) && let ::std::option::Option::Some(c_p7) = crate::prelude::index(m16366_4_1, &crate::prelude::Nat::from(0u32)) {
                break 'm16366 {
                    let st_p0x = st_p0.clone();
                    crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), c_p7.clone(), true), move |show_ty_in_f_16495: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}+", &show_ty_in_f_16495))))
                };
            }
            if let Ty::TyCon(m16366_5_0, m16366_5_1) = t_p1 && (m16366_5_0 == &crate::prelude::Text::lit("Answer")) && (m16366_5_1.len() == 1) && let ::std::option::Option::Some(Ty::TyElemAny(rw_p8)) = crate::prelude::index(m16366_5_1, &crate::prelude::Nat::from(0u32)) {
                break 'm16366 if *nested_p2 {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("(Answer {})", &show_row_in_f(&rw_p8, &true))))
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("Answer {}", &show_row_in_f(&rw_p8, &true))))
                };
            }
            if let Ty::TyCon(n_p9, args_pa) = t_p1 {
                break 'm16366 {
                    let args_pax = args_pa.clone();
                    let n_p9x = n_p9.clone();
                    let nested_p2x = *nested_p2;
                    let st_p0x = st_p0.clone();
                    crate::prelude::call_value(crate::prelude::each_job(args_pax.clone(), {
                        let st_p0xx = st_p0x.clone();
                        ::std::rc::Rc::new(move |p0: Ty| {
                            let st_p0xxy = st_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_pc = p0;
                                crate::prelude::call_then(start_show_ty_in_f(st_p0xxy.clone(), a_pc.clone(), true), move |show_ty_in_f_16716: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(" {}", &show_ty_in_f_16716))))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                    }), move |each_16697: crate::prelude::Array<crate::prelude::Text>| {
                        let inner_pb = crate::prelude::Text::from(format!("{}{}", &bare_name_f(&n_p9x), &crate::prelude::concat(&each_16697)));
                        if nested_p2x {
                            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &inner_pb)))
                        } else {
                            ::prism_rtl::Turn::Finished(inner_pb.clone())
                        }
                    })
                };
            }
            if let Ty::TyFn(c_pd, ps_pe, res_pf) = t_p1 {
                break 'm16366 {
                    let c_pdx = c_pd.clone();
                    let nested_p2x = *nested_p2;
                    let ps_pex = ps_pe.clone();
                    let res_pfx = (**res_pf).clone();
                    let st_p0x = st_p0.clone();
                    crate::prelude::call_value(crate::prelude::each_job(ps_pex.clone(), {
                        let st_p0xx = st_p0x.clone();
                        ::std::rc::Rc::new(move |p0: Ty| {
                            let st_p0xxy = st_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let p_ph = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(ShowTyIn { st_p0: st_p0xxy.clone(), t_p1: p_ph.clone(), nested_p2: false }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                    }), move |each_16848: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), res_pfx.clone(), false), move |show_ty_in_f_16896: crate::prelude::Text| {
                        let inner_pg = crate::prelude::Text::from(format!("{}fn {} -> {}", &show_col_f(&c_pdx), &crate::syntax::lexer::chars::join_f(&each_16848, &crate::prelude::Text::lit(", ")), &show_ty_in_f_16896));
                        if nested_p2x {
                            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &inner_pg)))
                        } else {
                            ::prism_rtl::Turn::Finished(inner_pg.clone())
                        }
                    }))
                };
            }
            if let Ty::TyTuple(ts_pi) = t_p1 {
                break 'm16366 {
                    let st_p0x = st_p0.clone();
                    let ts_pix = ts_pi.clone();
                    crate::prelude::call_value(crate::prelude::each_job(ts_pix.clone(), {
                        let st_p0xx = st_p0x.clone();
                        ::std::rc::Rc::new(move |p0: Ty| {
                            let st_p0xxy = st_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_pj = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(ShowTyIn { st_p0: st_p0xxy.clone(), t_p1: a_pj.clone(), nested_p2: false }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                    }), move |each_16991: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("(({}))", &crate::syntax::lexer::chars::join_f(&each_16991, &crate::prelude::Text::lit(", "))))))
                };
            }
            if let Ty::TyArray(e_pk) = t_p1 {
                break 'm16366 {
                    let e_pkx = (**e_pk).clone();
                    let st_p0x = st_p0.clone();
                    crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), e_pkx.clone(), false), move |show_ty_in_f_17073: crate::prelude::Text| {
                        let inner_pl = show_ty_in_f_17073;
                        if crate::syntax::lexer::chars::has_prefix_f(&inner_pl, &crate::prelude::Text::lit("[")) {
                            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("[ {} ]", &inner_pl)))
                        } else {
                            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("[{}]", &inner_pl)))
                        }
                    })
                };
            }
            if let Ty::TyMap(k_pm, v_pn) = t_p1 {
                break 'm16366 {
                    let k_pmx = (**k_pm).clone();
                    let nested_p2x = *nested_p2;
                    let st_p0x = st_p0.clone();
                    let v_pnx = (**v_pn).clone();
                    crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), k_pmx.clone(), true), move |show_ty_in_f_17200: crate::prelude::Text| crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), v_pnx.clone(), true), move |show_ty_in_f_17227: crate::prelude::Text| {
                        let inner_po = crate::prelude::Text::from(format!("{} ==> {}", &show_ty_in_f_17200, &show_ty_in_f_17227));
                        if nested_p2x {
                            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &inner_po)))
                        } else {
                            ::prism_rtl::Turn::Finished(inner_po.clone())
                        }
                    }))
                };
            }
            if let Ty::TySig(s_pp, i_pq) = t_p1 {
                break 'm16366 {
                    let i_pqx = (**i_pq).clone();
                    let s_ppx = s_pp.clone();
                    let st_p0x = st_p0.clone();
                    crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), i_pqx.clone(), true), move |show_ty_in_f_17314: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}", &s_ppx, &show_ty_in_f_17314))))
                };
            }
            if let Ty::TyAt(i_pr, rw_ps) = t_p1 {
                break 'm16366 {
                    let i_prx = (**i_pr).clone();
                    let st_p0x = st_p0.clone();
                    crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), i_prx.clone(), true), move |show_ty_in_f_17356: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("@{}", &show_ty_in_f_17356))))
                };
            }
            if let Ty::TyElem(rw_pt, o_pu) = t_p1 {
                break 'm16366 {
                    let nested_p2x = *nested_p2;
                    let o_pux = (**o_pu).clone();
                    let rw_ptx = rw_pt.clone();
                    let st_p0x = st_p0.clone();
                    crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), o_pux.clone(), true), move |show_ty_in_f_17448: crate::prelude::Text| {
                        let inner_pv = crate::prelude::Text::from(format!("Element {} {}", &show_row_in_f(&rw_ptx, &true), &show_ty_in_f_17448));
                        if nested_p2x {
                            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &inner_pv)))
                        } else {
                            ::prism_rtl::Turn::Finished(inner_pv.clone())
                        }
                    })
                };
            }
            if let Ty::TyElemAny(rw_p10) = t_p1 {
                break 'm16366 if *nested_p2 {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("(Elem {})", &show_row_in_f(rw_p10, &true))))
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("Elem {}", &show_row_in_f(rw_p10, &true))))
                };
            }
            if let Ty::TyAssoc(_, n_p11, a_p12) = t_p1 {
                break 'm16366 if *nested_p2 {
                    {
                        let a_p12x = (**a_p12).clone();
                        let n_p11x = n_p11.clone();
                        let st_p0x = st_p0.clone();
                        crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), a_p12x.clone(), true), move |show_ty_in_f_17651: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({} {})", &n_p11x, &show_ty_in_f_17651))))
                    }
                } else {
                    {
                        let a_p12x = (**a_p12).clone();
                        let n_p11x = n_p11.clone();
                        let st_p0x = st_p0.clone();
                        crate::prelude::call_then(start_show_ty_in_f(st_p0x.clone(), a_p12x.clone(), true), move |show_ty_in_f_17687: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {}", &n_p11x, &show_ty_in_f_17687))))
                    }
                };
            }
            if let Ty::TyAny(ts_p13) = t_p1 {
                break 'm16366 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("any {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(ts_p13, &(|x_p14: &crate::prelude::Text| crate::prelude::Text::from(format!("^{}", &bare_name_f(x_p14))))), &crate::prelude::Text::lit(" ")))));
            }
            if let Ty::TyErr = t_p1 {
                break 'm16366 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("?"));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ShowTyIn, x`: what the function value is when passed to `@Run`.
pub fn start_show_ty_in_f(st_p0: St, t_p1: Ty, nested_p2: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ShowTyIn { st_p0, t_p1, nested_p2 })
}

/// ```prism
/// ShowCol: fn Col -> Text
/// ```
pub fn show_col_f(col0: &Col) -> crate::prelude::Text {
    match col0 {
        Col::CBound => crate::prelude::Text::lit(""),
        Col::CUnbound => crate::prelude::Text::lit("unbounded "),
        Col::CRigid(n_p0) => crate::prelude::Text::from(format!("{} ", n_p0)),
        Col::CQ(n_p1) => crate::prelude::Text::from(format!("{} ", n_p1)),
        Col::CFlex(_) => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// ShowRow: fn Rw -> Text
/// ```
pub fn show_row_f(rw_p0: &Rw) -> crate::prelude::Text {
    show_row_in_f(rw_p0, &false)
}

/// ```prism
/// ShowRowIn: fn Rw, Bool -> Text
/// ```
pub fn show_row_in_f(rw_p0: &Rw, nested_p1: &bool) -> crate::prelude::Text {
    let fams_p2 = crate::prelude::each(&rw_p0.fams_p, &(|f_p7: &crate::prelude::Text| crate::prelude::Text::from(format!("{}.*", f_p7))));
    let tail_p3 = match &rw_p0.tail_p {
        Tail::TlClosed => crate::prelude::Array::new(),
        Tail::TlFlex(n_p8) => crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("r{}", n_p8))]),
        Tail::TlRigid(n_p9) => crate::prelude::Array::from(vec![n_p9.clone()]),
        Tail::TlQ(n_pa) => crate::prelude::Array::from(vec![n_pa.clone()]),
    };
    let parts_p4 = crate::prelude::append(&tail_p3, &fams_p2);
    let minus_p5 = if &crate::prelude::len(&rw_p0.minus_p) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!(" − {{{}}}", &crate::syntax::lexer::chars::join_f(&rw_p0.minus_p, &crate::prelude::Text::lit(", "))))
    };
    let inner_p6 = if &crate::prelude::len(&parts_p4) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("unit")
    } else {
        crate::syntax::lexer::chars::join_f(&parts_p4, &crate::prelude::Text::lit(" | "))
    };
    if *nested_p1 && ((&crate::prelude::len(&parts_p4) > &crate::prelude::Nat::from(1u32)) || (&minus_p5 != &crate::prelude::Text::lit(""))) {
        crate::prelude::Text::from(format!("({}{})", &inner_p6, &minus_p5))
    } else {
        crate::prelude::Text::from(format!("{}{}", &inner_p6, &minus_p5))
    }
}
