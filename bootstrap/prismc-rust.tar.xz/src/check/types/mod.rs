//! The module `Check.Types`, from `target/bootstrap/src/prismc/check/types/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod colors;
pub mod recording;
pub mod schemes;
pub mod unify;

/// `CLeq`:
///
/// ```prism
/// type CLeq = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CLeq {
    pub lo: Col,
    pub hi: Col,
    pub file: Nat,
    pub span: crate::syntax::Range,
    pub kind: Text,
    pub name: Text,
    pub why: Text,
}

impl Show for CLeq {
    fn show(&self, p: &mut Printer) {
        p.record("CLeq", &[("lo", &self.lo), ("hi", &self.hi), ("file", &self.file), ("span", &self.span), ("kind", &self.kind), ("name", &self.name), ("why", &self.why)]);
    }
}

impl ToPod for CLeq {
    fn to_pod(&self) -> Pod {
        Pod::record("CLeq", vec![("lo", self.lo.to_pod()), ("hi", self.hi.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod()), ("kind", self.kind.to_pod()), ("name", self.name.to_pod()), ("why", self.why.to_pod())])
    }
}

impl FromPod for CLeq {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CLeq { lo: FromPod::from_pod(field(p, "lo")?)?, hi: FromPod::from_pod(field(p, "hi")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)?, kind: FromPod::from_pod(field(p, "kind")?)?, name: FromPod::from_pod(field(p, "name")?)?, why: FromPod::from_pod(field(p, "why")?)? })
    }
}

/// `Col`:
///
/// ```prism
/// type Col = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Col {
    CBound,
    CUnbound,
    CRigid(Text),
    CQ(Text),
    CFlex(Nat),
}

impl Show for Col {
    fn show(&self, p: &mut Printer) {
        match self {
            Col::CBound => p.choice("CBound", &[]),
            Col::CUnbound => p.choice("CUnbound", &[]),
            Col::CRigid(a0) => p.choice("CRigid", &[a0]),
            Col::CQ(a0) => p.choice("CQ", &[a0]),
            Col::CFlex(a0) => p.choice("CFlex", &[a0]),
        }
    }
}

impl ToPod for Col {
    fn to_pod(&self) -> Pod {
        match self {
            Col::CBound => Pod::Choice("CBound".into(), vec![]),
            Col::CUnbound => Pod::Choice("CUnbound".into(), vec![]),
            Col::CRigid(a0) => Pod::Choice("CRigid".into(), vec![a0.to_pod()]),
            Col::CQ(a0) => Pod::Choice("CQ".into(), vec![a0.to_pod()]),
            Col::CFlex(a0) => Pod::Choice("CFlex".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Col {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "CBound" && a.len() == 0 => Ok(Col::CBound),
            Pod::Choice(c, a) if &**c == "CUnbound" && a.len() == 0 => Ok(Col::CUnbound),
            Pod::Choice(c, a) if &**c == "CRigid" && a.len() == 1 => Ok(Col::CRigid(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CQ" && a.len() == 1 => Ok(Col::CQ(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CFlex" && a.len() == 1 => Ok(Col::CFlex(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Col", other),
        }
    }
}

/// `Incl`:
///
/// ```prism
/// type Incl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Incl {
    pub sub: Rw,
    pub sup: Rw,
    pub file: Nat,
    pub span: crate::syntax::Range,
    pub what: Text,
    pub forward: bool,
}

impl Show for Incl {
    fn show(&self, p: &mut Printer) {
        p.record("Incl", &[("sub", &self.sub), ("sup", &self.sup), ("file", &self.file), ("span", &self.span), ("what", &self.what), ("forward", &self.forward)]);
    }
}

impl ToPod for Incl {
    fn to_pod(&self) -> Pod {
        Pod::record("Incl", vec![("sub", self.sub.to_pod()), ("sup", self.sup.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod()), ("what", self.what.to_pod()), ("forward", self.forward.to_pod())])
    }
}

impl FromPod for Incl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Incl { sub: FromPod::from_pod(field(p, "sub")?)?, sup: FromPod::from_pod(field(p, "sup")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)?, what: FromPod::from_pod(field(p, "what")?)?, forward: FromPod::from_pod(field(p, "forward")?)? })
    }
}

/// `Rw`:
///
/// ```prism
/// type Rw = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Rw {
    pub fams: Array<Text>,
    pub minus: Array<Text>,
    pub tail: Tail,
}

impl Show for Rw {
    fn show(&self, p: &mut Printer) {
        p.record("Rw", &[("fams", &self.fams), ("minus", &self.minus), ("tail", &self.tail)]);
    }
}

impl ToPod for Rw {
    fn to_pod(&self) -> Pod {
        Pod::record("Rw", vec![("fams", self.fams.to_pod()), ("minus", self.minus.to_pod()), ("tail", self.tail.to_pod())])
    }
}

impl FromPod for Rw {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Rw { fams: FromPod::from_pod(field(p, "fams")?)?, minus: FromPod::from_pod(field(p, "minus")?)?, tail: FromPod::from_pod(field(p, "tail")?)? })
    }
}

/// `Scheme`:
///
/// ```prism
/// type Scheme = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Scheme {
    pub qs: Array<Text>,
    pub plain_qs: Array<Text>,
    pub rqs: Array<Text>,
    pub cqs: Array<Text>,
    pub cjoins: Array<(Text, Text)>,
    pub bounds: Array<(Text, Text)>,
    pub ty: Ty,
}

impl Show for Scheme {
    fn show(&self, p: &mut Printer) {
        p.record("Scheme", &[("qs", &self.qs), ("plain_qs", &self.plain_qs), ("rqs", &self.rqs), ("cqs", &self.cqs), ("cjoins", &self.cjoins), ("bounds", &self.bounds), ("ty", &self.ty)]);
    }
}

impl ToPod for Scheme {
    fn to_pod(&self) -> Pod {
        Pod::record("Scheme", vec![("qs", self.qs.to_pod()), ("plain_qs", self.plain_qs.to_pod()), ("rqs", self.rqs.to_pod()), ("cqs", self.cqs.to_pod()), ("cjoins", self.cjoins.to_pod()), ("bounds", self.bounds.to_pod()), ("ty", self.ty.to_pod())])
    }
}

impl FromPod for Scheme {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Scheme { qs: FromPod::from_pod(field(p, "qs")?)?, plain_qs: FromPod::from_pod(field(p, "plain_qs")?)?, rqs: FromPod::from_pod(field(p, "rqs")?)?, cqs: FromPod::from_pod(field(p, "cqs")?)?, cjoins: FromPod::from_pod(field(p, "cjoins")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, ty: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// `St`:
///
/// ```prism
/// type St = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct St {
    pub next: Nat,
    pub tys: Map<Nat, Ty>,
    pub infos: Map<Nat, VInfo>,
    pub rows: Map<Nat, Rw>,
    pub lacks: Map<Nat, Array<Text>>,
    pub wants: Array<Want>,
    pub incls: Array<Incl>,
    pub diags: Array<crate::check::errors::CDiag>,
    pub level: Nat,
    pub file: Nat,
    pub color: Col,
    pub color_why: Text,
    pub color_flex: Array<(Col, Text, crate::syntax::Range)>,
    pub cols: Map<Nat, Col>,
    pub cleqs: Array<CLeq>,
    pub col_q: Map<Nat, Text>,
    pub col_up: Map<Text, Text>,
    pub deferred: Array<(Ty, Ty, crate::syntax::Range)>,
    pub binder_at: Map<Nat, crate::syntax::Range>,
    pub row_names: Map<Nat, Text>,
    pub layer_qs: Array<(Ty, crate::syntax::Range, Text)>,
    pub field_qs: Array<crate::check::types::unify::FieldQ>,
    pub recording: bool,
    pub typed: crate::check::typed::TProgram,
    pub choices: Map<Text, Array<Text>>,
    pub size_tys: Map<Text, Ty>,
    pub local_next: Nat,
    pub local_ids: Map<Text, Nat>,
}

impl Show for St {
    fn show(&self, p: &mut Printer) {
        p.record("St", &[("next", &self.next), ("tys", &self.tys), ("infos", &self.infos), ("rows", &self.rows), ("lacks", &self.lacks), ("wants", &self.wants), ("incls", &self.incls), ("diags", &self.diags), ("level", &self.level), ("file", &self.file), ("color", &self.color), ("color_why", &self.color_why), ("color_flex", &self.color_flex), ("cols", &self.cols), ("cleqs", &self.cleqs), ("col_q", &self.col_q), ("col_up", &self.col_up), ("deferred", &self.deferred), ("binder_at", &self.binder_at), ("row_names", &self.row_names), ("layer_qs", &self.layer_qs), ("field_qs", &self.field_qs), ("recording", &self.recording), ("typed", &self.typed), ("choices", &self.choices), ("size_tys", &self.size_tys), ("local_next", &self.local_next), ("local_ids", &self.local_ids)]);
    }
}

impl ToPod for St {
    fn to_pod(&self) -> Pod {
        Pod::record("St", vec![("next", self.next.to_pod()), ("tys", self.tys.to_pod()), ("infos", self.infos.to_pod()), ("rows", self.rows.to_pod()), ("lacks", self.lacks.to_pod()), ("wants", self.wants.to_pod()), ("incls", self.incls.to_pod()), ("diags", self.diags.to_pod()), ("level", self.level.to_pod()), ("file", self.file.to_pod()), ("color", self.color.to_pod()), ("color_why", self.color_why.to_pod()), ("color_flex", self.color_flex.to_pod()), ("cols", self.cols.to_pod()), ("cleqs", self.cleqs.to_pod()), ("col_q", self.col_q.to_pod()), ("col_up", self.col_up.to_pod()), ("deferred", self.deferred.to_pod()), ("binder_at", self.binder_at.to_pod()), ("row_names", self.row_names.to_pod()), ("layer_qs", self.layer_qs.to_pod()), ("field_qs", self.field_qs.to_pod()), ("recording", self.recording.to_pod()), ("typed", self.typed.to_pod()), ("choices", self.choices.to_pod()), ("size_tys", self.size_tys.to_pod()), ("local_next", self.local_next.to_pod()), ("local_ids", self.local_ids.to_pod())])
    }
}

impl FromPod for St {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(St { next: FromPod::from_pod(field(p, "next")?)?, tys: FromPod::from_pod(field(p, "tys")?)?, infos: FromPod::from_pod(field(p, "infos")?)?, rows: FromPod::from_pod(field(p, "rows")?)?, lacks: FromPod::from_pod(field(p, "lacks")?)?, wants: FromPod::from_pod(field(p, "wants")?)?, incls: FromPod::from_pod(field(p, "incls")?)?, diags: FromPod::from_pod(field(p, "diags")?)?, level: FromPod::from_pod(field(p, "level")?)?, file: FromPod::from_pod(field(p, "file")?)?, color: FromPod::from_pod(field(p, "color")?)?, color_why: FromPod::from_pod(field(p, "color_why")?)?, color_flex: FromPod::from_pod(field(p, "color_flex")?)?, cols: FromPod::from_pod(field(p, "cols")?)?, cleqs: FromPod::from_pod(field(p, "cleqs")?)?, col_q: FromPod::from_pod(field(p, "col_q")?)?, col_up: FromPod::from_pod(field(p, "col_up")?)?, deferred: FromPod::from_pod(field(p, "deferred")?)?, binder_at: FromPod::from_pod(field(p, "binder_at")?)?, row_names: FromPod::from_pod(field(p, "row_names")?)?, layer_qs: FromPod::from_pod(field(p, "layer_qs")?)?, field_qs: FromPod::from_pod(field(p, "field_qs")?)?, recording: FromPod::from_pod(field(p, "recording")?)?, typed: FromPod::from_pod(field(p, "typed")?)?, choices: FromPod::from_pod(field(p, "choices")?)?, size_tys: FromPod::from_pod(field(p, "size_tys")?)?, local_next: FromPod::from_pod(field(p, "local_next")?)?, local_ids: FromPod::from_pod(field(p, "local_ids")?)? })
    }
}

/// `Tail`:
///
/// ```prism
/// type Tail = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Tail {
    TlClosed,
    TlFlex(Nat),
    TlRigid(Text),
    TlQ(Text),
}

impl Show for Tail {
    fn show(&self, p: &mut Printer) {
        match self {
            Tail::TlClosed => p.choice("TlClosed", &[]),
            Tail::TlFlex(a0) => p.choice("TlFlex", &[a0]),
            Tail::TlRigid(a0) => p.choice("TlRigid", &[a0]),
            Tail::TlQ(a0) => p.choice("TlQ", &[a0]),
        }
    }
}

impl ToPod for Tail {
    fn to_pod(&self) -> Pod {
        match self {
            Tail::TlClosed => Pod::Choice("TlClosed".into(), vec![]),
            Tail::TlFlex(a0) => Pod::Choice("TlFlex".into(), vec![a0.to_pod()]),
            Tail::TlRigid(a0) => Pod::Choice("TlRigid".into(), vec![a0.to_pod()]),
            Tail::TlQ(a0) => Pod::Choice("TlQ".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Tail {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TlClosed" && a.len() == 0 => Ok(Tail::TlClosed),
            Pod::Choice(c, a) if &**c == "TlFlex" && a.len() == 1 => Ok(Tail::TlFlex(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TlRigid" && a.len() == 1 => Ok(Tail::TlRigid(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TlQ" && a.len() == 1 => Ok(Tail::TlQ(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Tail", other),
        }
    }
}

/// `Ty`:
///
/// ```prism
/// type Ty = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Ty {
    TyFlex(Nat),
    TyRigid(Text),
    TyQ(Text),
    TyCon(Text, Array<Ty>),
    TyFn(Col, Array<Ty>, Rc<Ty>),
    TyTuple(Array<Ty>),
    TyArray(Rc<Ty>),
    TyMap(Rc<Ty>, Rc<Ty>),
    TySig(Text, Rc<Ty>),
    TyAt(Rc<Ty>, Rw),
    TyElem(Rw, Rc<Ty>),
    TyElemAny(Rw),
    TyAssoc(Text, Rc<Ty>),
    TyAny(Array<Text>),
    TyErr,
}

impl Show for Ty {
    fn show(&self, p: &mut Printer) {
        match self {
            Ty::TyFlex(a0) => p.choice("TyFlex", &[a0]),
            Ty::TyRigid(a0) => p.choice("TyRigid", &[a0]),
            Ty::TyQ(a0) => p.choice("TyQ", &[a0]),
            Ty::TyCon(a0, a1) => p.choice("TyCon", &[a0, a1]),
            Ty::TyFn(a0, a1, a2) => p.choice("TyFn", &[a0, a1, a2]),
            Ty::TyTuple(a0) => p.choice("TyTuple", &[a0]),
            Ty::TyArray(a0) => p.choice("TyArray", &[a0]),
            Ty::TyMap(a0, a1) => p.choice("TyMap", &[a0, a1]),
            Ty::TySig(a0, a1) => p.choice("TySig", &[a0, a1]),
            Ty::TyAt(a0, a1) => p.choice("TyAt", &[a0, a1]),
            Ty::TyElem(a0, a1) => p.choice("TyElem", &[a0, a1]),
            Ty::TyElemAny(a0) => p.choice("TyElemAny", &[a0]),
            Ty::TyAssoc(a0, a1) => p.choice("TyAssoc", &[a0, a1]),
            Ty::TyAny(a0) => p.choice("TyAny", &[a0]),
            Ty::TyErr => p.choice("TyErr", &[]),
        }
    }
}

impl ToPod for Ty {
    fn to_pod(&self) -> Pod {
        match self {
            Ty::TyFlex(a0) => Pod::Choice("TyFlex".into(), vec![a0.to_pod()]),
            Ty::TyRigid(a0) => Pod::Choice("TyRigid".into(), vec![a0.to_pod()]),
            Ty::TyQ(a0) => Pod::Choice("TyQ".into(), vec![a0.to_pod()]),
            Ty::TyCon(a0, a1) => Pod::Choice("TyCon".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyFn(a0, a1, a2) => Pod::Choice("TyFn".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ty::TyTuple(a0) => Pod::Choice("TyTuple".into(), vec![a0.to_pod()]),
            Ty::TyArray(a0) => Pod::Choice("TyArray".into(), vec![a0.to_pod()]),
            Ty::TyMap(a0, a1) => Pod::Choice("TyMap".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TySig(a0, a1) => Pod::Choice("TySig".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyAt(a0, a1) => Pod::Choice("TyAt".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyElem(a0, a1) => Pod::Choice("TyElem".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyElemAny(a0) => Pod::Choice("TyElemAny".into(), vec![a0.to_pod()]),
            Ty::TyAssoc(a0, a1) => Pod::Choice("TyAssoc".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ty::TyAny(a0) => Pod::Choice("TyAny".into(), vec![a0.to_pod()]),
            Ty::TyErr => Pod::Choice("TyErr".into(), vec![]),
        }
    }
}

impl FromPod for Ty {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TyFlex" && a.len() == 1 => Ok(Ty::TyFlex(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyRigid" && a.len() == 1 => Ok(Ty::TyRigid(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyQ" && a.len() == 1 => Ok(Ty::TyQ(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyCon" && a.len() == 2 => Ok(Ty::TyCon(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyFn" && a.len() == 3 => Ok(Ty::TyFn(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "TyTuple" && a.len() == 1 => Ok(Ty::TyTuple(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyArray" && a.len() == 1 => Ok(Ty::TyArray(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyMap" && a.len() == 2 => Ok(Ty::TyMap(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TySig" && a.len() == 2 => Ok(Ty::TySig(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyAt" && a.len() == 2 => Ok(Ty::TyAt(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyElem" && a.len() == 2 => Ok(Ty::TyElem(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyElemAny" && a.len() == 1 => Ok(Ty::TyElemAny(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyAssoc" && a.len() == 2 => Ok(Ty::TyAssoc(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TyAny" && a.len() == 1 => Ok(Ty::TyAny(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TyErr" && a.len() == 0 => Ok(Ty::TyErr),
            other => mismatch("a Ty", other),
        }
    }
}

/// `VInfo`:
///
/// ```prism
/// type VInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct VInfo {
    pub plain: bool,
    pub level: Nat,
    pub name: Text,
}

impl Show for VInfo {
    fn show(&self, p: &mut Printer) {
        p.record("VInfo", &[("plain", &self.plain), ("level", &self.level), ("name", &self.name)]);
    }
}

impl ToPod for VInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("VInfo", vec![("plain", self.plain.to_pod()), ("level", self.level.to_pod()), ("name", self.name.to_pod())])
    }
}

impl FromPod for VInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(VInfo { plain: FromPod::from_pod(field(p, "plain")?)?, level: FromPod::from_pod(field(p, "level")?)?, name: FromPod::from_pod(field(p, "name")?)? })
    }
}

/// `Want`:
///
/// ```prism
/// type Want = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Want {
    pub cls: Text,
    pub ty: Ty,
    pub file: Nat,
    pub span: crate::syntax::Range,
    pub level: Nat,
}

impl Show for Want {
    fn show(&self, p: &mut Printer) {
        p.record("Want", &[("cls", &self.cls), ("ty", &self.ty), ("file", &self.file), ("span", &self.span), ("level", &self.level)]);
    }
}

impl ToPod for Want {
    fn to_pod(&self) -> Pod {
        Pod::record("Want", vec![("cls", self.cls.to_pod()), ("ty", self.ty.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod()), ("level", self.level.to_pod())])
    }
}

impl FromPod for Want {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Want { cls: FromPod::from_pod(field(p, "cls")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)?, level: FromPod::from_pod(field(p, "level")?)? })
    }
}

/// ```prism
/// NewSt: fn Nat -> St
/// ```
pub fn new_st(file_p0: &Nat) -> St {
    St { next: Nat::from(0u32), tys: Map::new(), infos: Map::new(), rows: Map::new(), lacks: Map::new(), wants: Array::new(), incls: Array::new(), diags: Array::new(), level: Nat::from(0u32), file: file_p0.clone(), color: Col::CBound, color_why: Text::lit(""), color_flex: Array::new(), cols: Map::new(), cleqs: Array::new(), col_q: Map::new(), col_up: Map::new(), deferred: Array::new(), binder_at: Map::new(), row_names: Map::new(), layer_qs: Array::new(), field_qs: Array::new(), recording: false, typed: crate::check::typed::empty_typed(), choices: Map::new(), size_tys: Map::new(), local_next: Nat::from(0u32), local_ids: Map::new() }
}

/// ```prism
/// Closed: fn [Text] -> Rw
/// ```
pub fn closed(fs_p0: &Array<Text>) -> Rw {
    Rw { fams: sort_texts(fs_p0), minus: Array::new(), tail: Tail::TlClosed }
}

/// ```prism
/// let emptyRow
/// ```
pub fn empty_row() -> Rw {
    Rw { fams: Array::new(), minus: Array::new(), tail: Tail::TlClosed }
}

/// ```prism
/// let tInt
/// ```
pub fn t_int() -> Ty {
    Ty::TyCon(Text::lit("Int"), Array::new())
}

/// ```prism
/// let tNat
/// ```
pub fn t_nat() -> Ty {
    Ty::TyCon(Text::lit("Nat"), Array::new())
}

/// ```prism
/// let tText
/// ```
pub fn t_text() -> Ty {
    Ty::TyCon(Text::lit("Text"), Array::new())
}

/// ```prism
/// let tBool
/// ```
pub fn t_bool() -> Ty {
    Ty::TyCon(Text::lit("Bool"), Array::new())
}

/// ```prism
/// let tUnit
/// ```
pub fn t_unit() -> Ty {
    Ty::TyCon(Text::lit("unit"), Array::new())
}

/// ```prism
/// let tChar
/// ```
pub fn t_char() -> Ty {
    Ty::TyCon(Text::lit("Char"), Array::new())
}

/// ```prism
/// let tFloat
/// ```
pub fn t_float() -> Ty {
    Ty::TyCon(Text::lit("Float"), Array::new())
}

/// ```prism
/// HasText: fn [Text], Text -> Bool
/// ```
pub fn has_text(xs_p0: &Array<Text>, x_p1: &Text) -> bool {
    fold(xs_p0, &false, &(|seen_p2: &bool, y_p3: &Text| *seen_p2 || (y_p3 == x_p1)))
}

/// ```prism
/// HasNat: fn [Nat], Nat -> Bool
/// ```
pub fn has_nat(xs_p0: &Array<Nat>, x_p1: &Nat) -> bool {
    fold(xs_p0, &false, &(|seen_p2: &bool, y_p3: &Nat| *seen_p2 || (y_p3 == x_p1)))
}

/// ```prism
/// AddText: fn [Text], Text -> [Text]
/// ```
pub fn add_text(xs_p0: &Array<Text>, x_p1: &Text) -> Array<Text> {
    if has_text(xs_p0, x_p1) { xs_p0.clone() } else { push(xs_p0, x_p1) }
}

/// ```prism
/// UnionTexts: fn [Text], [Text] -> [Text]
/// ```
pub fn union_texts(xs_p0: &Array<Text>, ys_p1: &Array<Text>) -> Array<Text> {
    fold(ys_p1, xs_p0, &(|acc_p2: &Array<Text>, y_p3: &Text| add_text(acc_p2, y_p3)))
}

/// ```prism
/// MinusTexts: fn [Text], [Text] -> [Text]
/// ```
pub fn minus_texts(xs_p0: &Array<Text>, ys_p1: &Array<Text>) -> Array<Text> {
    filter(xs_p0, &(|x_p2: &Text| !has_text(ys_p1, x_p2)))
}

/// ```prism
/// InterTexts: fn [Text], [Text] -> [Text]
/// ```
pub fn inter_texts(xs_p0: &Array<Text>, ys_p1: &Array<Text>) -> Array<Text> {
    filter(xs_p0, &(|x_p2: &Text| has_text(ys_p1, x_p2)))
}

/// ```prism
/// AddNat: fn [Nat], Nat -> [Nat]
/// ```
pub fn add_nat(xs_p0: &Array<Nat>, x_p1: &Nat) -> Array<Nat> {
    if has_nat(xs_p0, x_p1) { xs_p0.clone() } else { push(xs_p0, x_p1) }
}

/// ```prism
/// SortTexts: fn [Text] -> [Text]
/// ```
pub fn sort_texts(xs_p0: &Array<Text>) -> Array<Text> {
    fold(xs_p0, &Array::new(), &(|acc_p1: &Array<Text>, x_p2: &Text| if has_text(acc_p1, x_p2) {
        acc_p1.clone()
    } else {
        append(&push(&filter(acc_p1, &(|y_p3: &Text| y_p3 < x_p2)), x_p2), &filter(acc_p1, &(|y_p4: &Text| !(y_p4 < x_p2))))
    }))
}

/// ```prism
/// BareName: fn Text -> Text
/// ```
pub fn bare_name(q_p0: &Text) -> Text {
    or(&crate::syntax::lexer::chars::last(&split_on(q_p0, &Text::lit("."))), q_p0)
}

/// ```prism
/// FreshVar: fn St, Bool, Text -> ((Ty, St))
/// ```
pub fn fresh_var(st_p0: &St, plain_p1: &bool, name_p2: &Text) -> (Ty, St) {
    let n_p3 = st_p0.next.clone();
    let st2_p4 = {
        let mut this: St = st_p0.clone();
        this.next = &this.next + &Nat::from(1u32);
        this.infos = insert(&this.infos, &n_p3, &VInfo { plain: *plain_p1, level: this.level.clone(), name: name_p2.clone() });
        this
    };
    (Ty::TyFlex(n_p3.clone()), st2_p4.clone())
}

/// ```prism
/// FreshCol: fn St -> ((Col, St))
/// ```
pub fn fresh_col(st_p0: &St) -> (Col, St) {
    let n_p1 = st_p0.next.clone();
    let st2_p2 = {
        let mut this: St = st_p0.clone();
        this.next = &this.next + &Nat::from(1u32);
        this.infos = insert(&this.infos, &n_p1, &VInfo { plain: false, level: this.level.clone(), name: Text::lit("") });
        this
    };
    (Col::CFlex(n_p1.clone()), st2_p2.clone())
}

/// ```prism
/// StackOf: unbounded fn St, Ty -> Text
/// ```
pub fn stack_of(st_p0: &St, t_p1: &Ty) -> Text {
    match crate::check::types::recording::walk(st_p0, t_p1) {
        Ty::TySig(s_p2, i_p3) => Text::from(format!("{}{}", &s_p2, &stack_of(st_p0, &*i_p3))),
        Ty::TyAt(i_p4, _) => Text::from(format!("@{}", &stack_of(st_p0, &*i_p4))),
        _ => Text::lit(""),
    }
}

/// The step machine of `StackOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StackOf: unbounded fn St, Ty -> Text
/// ```
pub struct StackOf {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl prism_rtl::Job<Text> for StackOf {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), t_p1.clone()), move |walk_8203: Ty| match walk_8203 {
            Ty::TySig(s_p2, i_p3) => call_then(start_stack_of(st_p0.clone(), (*i_p3).clone()), move |stack_of_8236: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &s_p2, &stack_of_8236)))),
            Ty::TyAt(i_p4, _) => call_then(start_stack_of(st_p0.clone(), (*i_p4).clone()), move |stack_of_8275: Text| prism_rtl::Turn::Finished(Text::from(format!("@{}", &stack_of_8275)))),
            _ => prism_rtl::Turn::Finished(Text::lit("")),
        })
    }
}

/// `Start StackOf, x`: what the function value is when passed to `@Run`.
pub fn start_stack_of(st_p0: St, t_p1: Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(StackOf { st_p0, t_p1 })
}

/// ```prism
/// HeadSigil: unbounded fn St, Ty -> Text
/// ```
pub fn head_sigil(st_p0: &St, t_p1: &Ty) -> Text {
    match crate::check::types::recording::walk(st_p0, t_p1) {
        Ty::TySig(s_p2, _) => s_p2,
        Ty::TyAt(_, _) => Text::lit("@"),
        _ => Text::lit(""),
    }
}

/// The step machine of `HeadSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HeadSigil: unbounded fn St, Ty -> Text
/// ```
pub struct HeadSigil {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl prism_rtl::Job<Text> for HeadSigil {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), t_p1.clone()), move |walk_8453: Ty| match walk_8453 {
            Ty::TySig(s_p2, _) => prism_rtl::Turn::Finished(s_p2.clone()),
            Ty::TyAt(_, _) => prism_rtl::Turn::Finished(Text::lit("@")),
            _ => prism_rtl::Turn::Finished(Text::lit("")),
        })
    }
}

/// `Start HeadSigil, x`: what the function value is when passed to `@Run`.
pub fn start_head_sigil(st_p0: St, t_p1: Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(HeadSigil { st_p0, t_p1 })
}

/// ```prism
/// IsFlexVar: unbounded fn St, Ty -> Bool
/// ```
pub fn is_flex_var(st_p0: &St, t_p1: &Ty) -> bool {
    match crate::check::types::recording::walk(st_p0, t_p1) {
        Ty::TyFlex(_) => true,
        _ => false,
    }
}

/// The step machine of `IsFlexVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsFlexVar: unbounded fn St, Ty -> Bool
/// ```
pub struct IsFlexVar {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl prism_rtl::Job<bool> for IsFlexVar {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), t_p1.clone()), move |walk_8602: Ty| match walk_8602 {
            Ty::TyFlex(_) => prism_rtl::Turn::Finished(true),
            _ => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start IsFlexVar, x`: what the function value is when passed to `@Run`.
pub fn start_is_flex_var(st_p0: St, t_p1: Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsFlexVar { st_p0, t_p1 })
}

/// ```prism
/// IsFreeHeaded: unbounded fn St, Ty -> Bool
/// ```
pub fn is_free_headed(st_p0: &St, t_p1: &Ty) -> bool {
    match crate::check::types::recording::walk(st_p0, t_p1) {
        Ty::TyFlex(n_p2) => !crate::check::types::recording::info_of(st_p0, &n_p2).plain,
        _ => false,
    }
}

/// The step machine of `IsFreeHeaded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsFreeHeaded: unbounded fn St, Ty -> Bool
/// ```
pub struct IsFreeHeaded {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl prism_rtl::Job<bool> for IsFreeHeaded {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), t_p1.clone()), move |walk_8810: Ty| match walk_8810 {
            Ty::TyFlex(n_p2) => prism_rtl::Turn::Finished(!crate::check::types::recording::info_of(&st_p0, &n_p2).plain),
            _ => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start IsFreeHeaded, x`: what the function value is when passed to `@Run`.
pub fn start_is_free_headed(st_p0: St, t_p1: Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsFreeHeaded { st_p0, t_p1 })
}

/// ```prism
/// WithMarks: fn Text, Ty, Rw -> Ty
/// ```
pub fn with_marks(marks_p0: &Text, t_p1: &Ty, rw_p2: &Rw) -> Ty {
    fold(&reverse2(&crate::syntax::lexer::chars::fold_chars(marks_p0, &Array::new(), &(Rc::new(move |(p0, p1): (Array<Text>, Text)| once_job(move || {
        let acc_p3 = p0;
        let c_p4 = p1;
        prism_rtl::Turn::Finished(push(&acc_p3, &c_p4))
    })) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))), t_p1, &(|acc_p5: &Ty, m_p6: &Text| if m_p6 == &Text::lit("@") {
        Ty::TyAt(Rc::new(acc_p5.clone()), rw_p2.clone())
    } else {
        Ty::TySig(m_p6.clone(), Rc::new(acc_p5.clone()))
    }))
}

/// ```prism
/// Reverse2: fn [Text] -> [Text]
/// ```
pub fn reverse2(xs_p0: &Array<Text>) -> Array<Text> {
    fold(xs_p0, &Array::new(), &(|acc_p1: &Array<Text>, x_p2: &Text| append(&Array::from(vec![x_p2.clone()]), acc_p1)))
}

/// ```prism
/// ShowTy: unbounded fn St, Ty -> Text
/// ```
pub fn show_ty(st_p0: &St, t_p1: &Ty) -> Text {
    show_ty_in(st_p0, &crate::check::types::recording::zonk(st_p0, t_p1), &false)
}

/// The step machine of `ShowTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowTy: unbounded fn St, Ty -> Text
/// ```
pub struct ShowTy {
    pub st_p0: St,
    pub t_p1: Ty,
}

impl prism_rtl::Job<Text> for ShowTy {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_zonk(st_p0.clone(), t_p1.clone()), move |zonk_9536: Ty| prism_rtl::Turn::More(Rc::new(ShowTyIn { st_p0: st_p0.clone(), t_p1: zonk_9536, nested_p2: false })))
    }
}

/// `Start ShowTy, x`: what the function value is when passed to `@Run`.
pub fn start_show_ty(st_p0: St, t_p1: Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowTy { st_p0, t_p1 })
}

/// ```prism
/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
/// ```
pub fn show_ty_in(st_p0: &St, t_p1: &Ty, nested_p2: &bool) -> Text {
    match t_p1 {
        Ty::TyFlex(n_p3) => Text::from(format!("t{}", n_p3)),
        Ty::TyRigid(n_p4) => n_p4.clone(),
        Ty::TyQ(n_p5) => n_p5.clone(),
        Ty::TyCon(n_p6, m9698_3_1) if (m9698_3_1.len() == 0) => bare_name(n_p6),
        Ty::TyCon(n_p7, args_p8) => {
            let inner_p9 = Text::from(format!("{}{}", &bare_name(n_p7), &concat(&run_to_end(each_job(args_p8.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |p0: Ty| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let a_pa = p0;
                        call_then(start_show_ty_in(st_p0.clone(), a_pa.clone(), true), move |show_ty_in_9868: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &show_ty_in_9868))))
                    }))
                }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
            })))));
            if *nested_p2 { Text::from(format!("({})", &inner_p9)) } else { inner_p9.clone() }
        },
        Ty::TyFn(c_pb, ps_pc, res_pd) => {
            let inner_pe = Text::from(format!("{}fn {} -> {}", &show_col(c_pb), &crate::syntax::lexer::chars::join(&run_to_end(each_job(ps_pc.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |p0: Ty| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let p_pf = p0;
                        prism_rtl::Turn::More(Rc::new(ShowTyIn { st_p0: st_p0.clone(), t_p1: p_pf.clone(), nested_p2: false }))
                    }))
                }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &Text::lit(", ")), &show_ty_in(st_p0, &**res_pd, &false)));
            if *nested_p2 { Text::from(format!("({})", &inner_pe)) } else { inner_pe.clone() }
        },
        Ty::TyTuple(ts_pg) => Text::from(format!("(({}))", &crate::syntax::lexer::chars::join(&run_to_end(each_job(ts_pg.clone(), {
            let st_p0 = st_p0.clone();
            Rc::new(move |p0: Ty| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let a_ph = p0;
                    prism_rtl::Turn::More(Rc::new(ShowTyIn { st_p0: st_p0.clone(), t_p1: a_ph.clone(), nested_p2: false }))
                }))
            }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
        })), &Text::lit(", ")))),
        Ty::TyArray(e_pi) => {
            let inner_pj = show_ty_in(st_p0, &**e_pi, &false);
            if crate::syntax::lexer::chars::has_prefix(&inner_pj, &Text::lit("[")) {
                Text::from(format!("[ {} ]", &inner_pj))
            } else {
                Text::from(format!("[{}]", &inner_pj))
            }
        },
        Ty::TyMap(k_pk, v_pl) => {
            let inner_pm = Text::from(format!("{} ==> {}", &show_ty_in(st_p0, &**k_pk, &true), &show_ty_in(st_p0, &**v_pl, &true)));
            if *nested_p2 { Text::from(format!("({})", &inner_pm)) } else { inner_pm.clone() }
        },
        Ty::TySig(s_pn, i_po) => Text::from(format!("{}{}", s_pn, &show_ty_in(st_p0, &**i_po, &true))),
        Ty::TyAt(i_pp, rw_pq) => Text::from(format!("@{}", &show_ty_in(st_p0, &**i_pp, &true))),
        Ty::TyElem(rw_pr, o_ps) => {
            let inner_pt = Text::from(format!("Element {} {}", &show_row_in(rw_pr, &true), &show_ty_in(st_p0, &**o_ps, &true)));
            if *nested_p2 { Text::from(format!("({})", &inner_pt)) } else { inner_pt.clone() }
        },
        Ty::TyElemAny(rw_pu) => if *nested_p2 {
            Text::from(format!("(Elem {})", &show_row_in(rw_pu, &true)))
        } else {
            Text::from(format!("Elem {}", &show_row_in(rw_pu, &true)))
        },
        Ty::TyAssoc(n_pv, a_p10) => if *nested_p2 {
            Text::from(format!("({} {})", n_pv, &show_ty_in(st_p0, &**a_p10, &true)))
        } else {
            Text::from(format!("{} {}", n_pv, &show_ty_in(st_p0, &**a_p10, &true)))
        },
        Ty::TyAny(ts_p11) => Text::from(format!("any {}", &crate::syntax::lexer::chars::join(&each(ts_p11, &(|x_p12: &Text| Text::from(format!("^{}", &bare_name(x_p12))))), &Text::lit(" ")))),
        Ty::TyErr => Text::lit("?"),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ShowTyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
/// ```
pub struct ShowTyIn {
    pub st_p0: St,
    pub t_p1: Ty,
    pub nested_p2: bool,
}

impl prism_rtl::Job<Text> for ShowTyIn {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let nested_p2 = &self.nested_p2;
        match t_p1 {
            Ty::TyFlex(n_p3) => prism_rtl::Turn::Finished(Text::from(format!("t{}", n_p3))),
            Ty::TyRigid(n_p4) => prism_rtl::Turn::Finished(n_p4.clone()),
            Ty::TyQ(n_p5) => prism_rtl::Turn::Finished(n_p5.clone()),
            Ty::TyCon(n_p6, m9698_3_1) if (m9698_3_1.len() == 0) => prism_rtl::Turn::Finished(bare_name(n_p6)),
            Ty::TyCon(n_p7, args_p8) => {
                let args_p8 = args_p8.clone();
                let n_p7 = n_p7.clone();
                let nested_p2 = *nested_p2;
                let st_p0 = st_p0.clone();
                call_value(each_job(args_p8.clone(), {
                    let st_p0 = st_p0.clone();
                    Rc::new(move |p0: Ty| {
                        let st_p0 = st_p0.clone();
                        entered(once_job(move || {
                            let a_pa = p0;
                            call_then(start_show_ty_in(st_p0.clone(), a_pa.clone(), true), move |show_ty_in_9868: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &show_ty_in_9868))))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_9849: Array<Text>| {
                    let inner_p9 = Text::from(format!("{}{}", &bare_name(&n_p7), &concat(&each_9849)));
                    if nested_p2 {
                        prism_rtl::Turn::Finished(Text::from(format!("({})", &inner_p9)))
                    } else {
                        prism_rtl::Turn::Finished(inner_p9.clone())
                    }
                })
            },
            Ty::TyFn(c_pb, ps_pc, res_pd) => {
                let c_pb = c_pb.clone();
                let nested_p2 = *nested_p2;
                let ps_pc = ps_pc.clone();
                let res_pd = (**res_pd).clone();
                let st_p0 = st_p0.clone();
                call_value(each_job(ps_pc.clone(), {
                    let st_p0 = st_p0.clone();
                    Rc::new(move |p0: Ty| {
                        let st_p0 = st_p0.clone();
                        entered(once_job(move || {
                            let p_pf = p0;
                            prism_rtl::Turn::More(Rc::new(ShowTyIn { st_p0: st_p0.clone(), t_p1: p_pf.clone(), nested_p2: false }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_10000: Array<Text>| call_then(start_show_ty_in(st_p0.clone(), res_pd.clone(), false), move |show_ty_in_10048: Text| {
                    let inner_pe = Text::from(format!("{}fn {} -> {}", &show_col(&c_pb), &crate::syntax::lexer::chars::join(&each_10000, &Text::lit(", ")), &show_ty_in_10048));
                    if nested_p2 {
                        prism_rtl::Turn::Finished(Text::from(format!("({})", &inner_pe)))
                    } else {
                        prism_rtl::Turn::Finished(inner_pe.clone())
                    }
                }))
            },
            Ty::TyTuple(ts_pg) => {
                let st_p0 = st_p0.clone();
                let ts_pg = ts_pg.clone();
                call_value(each_job(ts_pg.clone(), {
                    let st_p0 = st_p0.clone();
                    Rc::new(move |p0: Ty| {
                        let st_p0 = st_p0.clone();
                        entered(once_job(move || {
                            let a_ph = p0;
                            prism_rtl::Turn::More(Rc::new(ShowTyIn { st_p0: st_p0.clone(), t_p1: a_ph.clone(), nested_p2: false }))
                        }))
                    }) as Rc<dyn Fn(Ty) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_10143: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("(({}))", &crate::syntax::lexer::chars::join(&each_10143, &Text::lit(", "))))))
            },
            Ty::TyArray(e_pi) => {
                let e_pi = (**e_pi).clone();
                let st_p0 = st_p0.clone();
                call_then(start_show_ty_in(st_p0.clone(), e_pi.clone(), false), move |show_ty_in_10225: Text| {
                    let inner_pj = show_ty_in_10225;
                    if crate::syntax::lexer::chars::has_prefix(&inner_pj, &Text::lit("[")) {
                        prism_rtl::Turn::Finished(Text::from(format!("[ {} ]", &inner_pj)))
                    } else {
                        prism_rtl::Turn::Finished(Text::from(format!("[{}]", &inner_pj)))
                    }
                })
            },
            Ty::TyMap(k_pk, v_pl) => {
                let k_pk = (**k_pk).clone();
                let nested_p2 = *nested_p2;
                let st_p0 = st_p0.clone();
                let v_pl = (**v_pl).clone();
                call_then(start_show_ty_in(st_p0.clone(), k_pk.clone(), true), move |show_ty_in_10352: Text| call_then(start_show_ty_in(st_p0.clone(), v_pl.clone(), true), move |show_ty_in_10379: Text| {
                    let inner_pm = Text::from(format!("{} ==> {}", &show_ty_in_10352, &show_ty_in_10379));
                    if nested_p2 {
                        prism_rtl::Turn::Finished(Text::from(format!("({})", &inner_pm)))
                    } else {
                        prism_rtl::Turn::Finished(inner_pm.clone())
                    }
                }))
            },
            Ty::TySig(s_pn, i_po) => {
                let i_po = (**i_po).clone();
                let s_pn = s_pn.clone();
                let st_p0 = st_p0.clone();
                call_then(start_show_ty_in(st_p0.clone(), i_po.clone(), true), move |show_ty_in_10466: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &s_pn, &show_ty_in_10466))))
            },
            Ty::TyAt(i_pp, rw_pq) => {
                let i_pp = (**i_pp).clone();
                let st_p0 = st_p0.clone();
                call_then(start_show_ty_in(st_p0.clone(), i_pp.clone(), true), move |show_ty_in_10508: Text| prism_rtl::Turn::Finished(Text::from(format!("@{}", &show_ty_in_10508))))
            },
            Ty::TyElem(rw_pr, o_ps) => {
                let nested_p2 = *nested_p2;
                let o_ps = (**o_ps).clone();
                let rw_pr = rw_pr.clone();
                let st_p0 = st_p0.clone();
                call_then(start_show_ty_in(st_p0.clone(), o_ps.clone(), true), move |show_ty_in_10600: Text| {
                    let inner_pt = Text::from(format!("Element {} {}", &show_row_in(&rw_pr, &true), &show_ty_in_10600));
                    if nested_p2 {
                        prism_rtl::Turn::Finished(Text::from(format!("({})", &inner_pt)))
                    } else {
                        prism_rtl::Turn::Finished(inner_pt.clone())
                    }
                })
            },
            Ty::TyElemAny(rw_pu) => if *nested_p2 {
                prism_rtl::Turn::Finished(Text::from(format!("(Elem {})", &show_row_in(rw_pu, &true))))
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("Elem {}", &show_row_in(rw_pu, &true))))
            },
            Ty::TyAssoc(n_pv, a_p10) => if *nested_p2 {
                {
                    let a_p10 = (**a_p10).clone();
                    let n_pv = n_pv.clone();
                    let st_p0 = st_p0.clone();
                    call_then(start_show_ty_in(st_p0.clone(), a_p10.clone(), true), move |show_ty_in_10795: Text| prism_rtl::Turn::Finished(Text::from(format!("({} {})", &n_pv, &show_ty_in_10795))))
                }
            } else {
                {
                    let a_p10 = (**a_p10).clone();
                    let n_pv = n_pv.clone();
                    let st_p0 = st_p0.clone();
                    call_then(start_show_ty_in(st_p0.clone(), a_p10.clone(), true), move |show_ty_in_10831: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &n_pv, &show_ty_in_10831))))
                }
            },
            Ty::TyAny(ts_p11) => prism_rtl::Turn::Finished(Text::from(format!("any {}", &crate::syntax::lexer::chars::join(&each(ts_p11, &(|x_p12: &Text| Text::from(format!("^{}", &bare_name(x_p12))))), &Text::lit(" "))))),
            Ty::TyErr => prism_rtl::Turn::Finished(Text::lit("?")),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ShowTyIn, x`: what the function value is when passed to `@Run`.
pub fn start_show_ty_in(st_p0: St, t_p1: Ty, nested_p2: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowTyIn { st_p0, t_p1, nested_p2 })
}

/// ```prism
/// ShowCol: fn Col -> Text
/// ```
pub fn show_col(col0: &Col) -> Text {
    match col0 {
        Col::CBound => Text::lit(""),
        Col::CUnbound => Text::lit("unbounded "),
        Col::CRigid(n_p0) => Text::from(format!("{} ", n_p0)),
        Col::CQ(n_p1) => Text::from(format!("{} ", n_p1)),
        Col::CFlex(_) => Text::lit(""),
    }
}

/// ```prism
/// ShowRow: fn Rw -> Text
/// ```
pub fn show_row(rw_p0: &Rw) -> Text {
    show_row_in(rw_p0, &false)
}

/// ```prism
/// ShowRowIn: fn Rw, Bool -> Text
/// ```
pub fn show_row_in(rw_p0: &Rw, nested_p1: &bool) -> Text {
    let fams_p2 = each(&rw_p0.fams, &(|f_p7: &Text| Text::from(format!("{}.*", f_p7))));
    let tail_p3 = match &rw_p0.tail {
        Tail::TlClosed => Array::new(),
        Tail::TlFlex(n_p8) => Array::from(vec![Text::from(format!("r{}", n_p8))]),
        Tail::TlRigid(n_p9) => Array::from(vec![n_p9.clone()]),
        Tail::TlQ(n_pa) => Array::from(vec![n_pa.clone()]),
    };
    let parts_p4 = append(&tail_p3, &fams_p2);
    let minus_p5 = if &len(&rw_p0.minus) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" − {{{}}}", &crate::syntax::lexer::chars::join(&rw_p0.minus, &Text::lit(", "))))
    };
    let inner_p6 = if &len(&parts_p4) == &Nat::from(0u32) {
        Text::lit("unit")
    } else {
        crate::syntax::lexer::chars::join(&parts_p4, &Text::lit(" | "))
    };
    if *nested_p1 && ((&len(&parts_p4) > &Nat::from(1u32)) || (&minus_p5 != &Text::lit(""))) {
        Text::from(format!("({}{})", &inner_p6, &minus_p5))
    } else {
        Text::from(format!("{}{}", &inner_p6, &minus_p5))
    }
}
