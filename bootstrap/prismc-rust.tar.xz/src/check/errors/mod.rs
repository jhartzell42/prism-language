//! The module `Check.Errors`, from `target/bootstrap/src/prismc/check/errors.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `CDiag`:
///
/// ```prism
/// type CDiag = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CDiag {
    pub code: Text,
    pub file: Nat,
    pub span: crate::syntax::Range,
    pub message: Text,
    pub fix: Text,
}

impl Show for CDiag {
    fn show(&self, p: &mut Printer) {
        p.record("CDiag", &[("code", &self.code), ("file", &self.file), ("span", &self.span), ("message", &self.message), ("fix", &self.fix)]);
    }
}

impl ToPod for CDiag {
    fn to_pod(&self) -> Pod {
        Pod::record("CDiag", vec![("code", self.code.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod()), ("message", self.message.to_pod()), ("fix", self.fix.to_pod())])
    }
}

impl FromPod for CDiag {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CDiag { code: FromPod::from_pod(field(p, "code")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)?, message: FromPod::from_pod(field(p, "message")?)?, fix: FromPod::from_pod(field(p, "fix")?)? })
    }
}

/// `Src`:
///
/// ```prism
/// type Src = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Src {
    pub path_: Text,
    pub text: Text,
    pub starts: Array<Nat>,
    pub segs: Array<SrcSeg>,
}

impl Show for Src {
    fn show(&self, p: &mut Printer) {
        p.record("Src", &[("path", &self.path_), ("text", &self.text), ("starts", &self.starts), ("segs", &self.segs)]);
    }
}

impl ToPod for Src {
    fn to_pod(&self) -> Pod {
        Pod::record("Src", vec![("path", self.path_.to_pod()), ("text", self.text.to_pod()), ("starts", self.starts.to_pod()), ("segs", self.segs.to_pod())])
    }
}

impl FromPod for Src {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Src { path_: FromPod::from_pod(field(p, "path")?)?, text: FromPod::from_pod(field(p, "text")?)?, starts: FromPod::from_pod(field(p, "starts")?)?, segs: FromPod::from_pod(field(p, "segs")?)? })
    }
}

/// `SrcSeg`:
///
/// ```prism
/// type SrcSeg = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct SrcSeg {
    pub path_: Text,
    pub start: Nat,
    pub line: Nat,
    pub role: Text,
}

impl Show for SrcSeg {
    fn show(&self, p: &mut Printer) {
        p.record("SrcSeg", &[("path", &self.path_), ("start", &self.start), ("line", &self.line), ("role", &self.role)]);
    }
}

impl ToPod for SrcSeg {
    fn to_pod(&self) -> Pod {
        Pod::record("SrcSeg", vec![("path", self.path_.to_pod()), ("start", self.start.to_pod()), ("line", self.line.to_pod()), ("role", self.role.to_pod())])
    }
}

impl FromPod for SrcSeg {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(SrcSeg { path_: FromPod::from_pod(field(p, "path")?)?, start: FromPod::from_pod(field(p, "start")?)?, line: FromPod::from_pod(field(p, "line")?)?, role: FromPod::from_pod(field(p, "role")?)? })
    }
}

/// ```prism
/// MkSrc: fn Text, Text -> Src
/// ```
pub fn mk_src(path_p0: &Text, text_p1: &Text) -> Src {
    Src { path_: path_p0.clone(), text: text_p1.clone(), starts: cline_starts(text_p1), segs: Array::from(vec![SrcSeg { path_: path_p0.clone(), start: Nat::from(0u32), line: Nat::from(0u32), role: Text::lit("loose") }]) }
}

/// ```prism
/// MkJoinedSrc: fn [((Text, Text, Text))] -> Src
/// ```
pub fn mk_joined_src(files_p0: &Array<(Text, Text, Text)>) -> Src {
    let text_p1 = crate::syntax::lexer::chars::join(&each(files_p0, &(|(_, t_p4, _): &(Text, Text, Text)| t_p4.clone())), &Text::lit("\n"));
    let starts_p2 = cline_starts(&text_p1);
    let (segs_pa, _) = fold(files_p0, &(Array::new(), Nat::from(0u32)), &(|(acc_p5, at_p6): &(Array<SrcSeg>, Nat), (path_p7, t_p8, role_p9): &(Text, Text, Text)| (push(acc_p5, &SrcSeg { path_: path_p7.clone(), start: at_p6.clone(), line: cline_of(&starts_p2, at_p6), role: role_p9.clone() }), &(at_p6 + &len_text(t_p8)) + &Nat::from(1u32))));
    let first_p3 = match index(files_p0, &Nat::from(0u32)) {
        Some((path_pb, _, _)) => path_pb,
        None => Text::lit(""),
    };
    Src { path_: first_p3.clone(), text: text_p1.clone(), starts: starts_p2.clone(), segs: segs_pa.clone() }
}

/// ```prism
/// SegAt: fn Src, Nat -> SrcSeg
/// ```
pub fn seg_at(src_p0: &Src, offset_p1: &Nat) -> SrcSeg {
    fold(&src_p0.segs, &or(&index(&src_p0.segs, &Nat::from(0u32)), &SrcSeg { path_: src_p0.path_.clone(), start: Nat::from(0u32), line: Nat::from(0u32), role: Text::lit("loose") }), &(|found_p2: &SrcSeg, s_p3: &SrcSeg| if &s_p3.start <= offset_p1 { s_p3.clone() } else { found_p2.clone() }))
}

/// ```prism
/// SrcPlace: fn Src, Nat -> Text
/// ```
pub fn src_place(src_p0: &Src, offset_p1: &Nat) -> Text {
    let seg_p2 = seg_at(src_p0, offset_p1);
    Text::from(format!("{}:{}", &seg_p2.path_, &(&or(&(&cline_of(&src_p0.starts, offset_p1)).checked_sub(&seg_p2.line), &Nat::from(0u32)) + &Nat::from(1u32))))
}

/// ```prism
/// Diag0: fn Text, Nat, Range, Text -> CDiag
/// ```
pub fn diag0(code_p0: &Text, file_p1: &Nat, span_p2: &crate::syntax::Range, message_p3: &Text) -> CDiag {
    CDiag { code: code_p0.clone(), file: file_p1.clone(), span: span_p2.clone(), message: message_p3.clone(), fix: Text::lit("") }
}

/// ```prism
/// DiagFix: fn Text, Nat, Range, Text, Text -> CDiag
/// ```
pub fn diag_fix(code_p0: &Text, file_p1: &Nat, span_p2: &crate::syntax::Range, message_p3: &Text, fix_p4: &Text) -> CDiag {
    CDiag { code: code_p0.clone(), file: file_p1.clone(), span: span_p2.clone(), message: message_p3.clone(), fix: fix_p4.clone() }
}

/// ```prism
/// CLineStarts: fn Text -> [Nat]
/// ```
pub fn cline_starts(text_p0: &Text) -> Array<Nat> {
    let (starts_p4, _) = fold(&split_on(text_p0, &Text::lit("\n")), &(Array::new(), Nat::from(0u32)), &(|(acc_p1, at_p2): &(Array<Nat>, Nat), line_p3: &Text| (push(acc_p1, at_p2), &(at_p2 + &len_text(line_p3)) + &Nat::from(1u32))));
    starts_p4.clone()
}

/// ```prism
/// CLineOf: fn [Nat], Nat -> Nat
/// ```
pub fn cline_of(starts_p0: &Array<Nat>, offset_p1: &Nat) -> Nat {
    crate::syntax::lexer::chars::dec(&fold(starts_p0, &Nat::from(0u32), &(|n_p2: &Nat, s_p3: &Nat| if s_p3 <= offset_p1 { n_p2 + &Nat::from(1u32) } else { n_p2.clone() })))
}

/// ```prism
/// LineText: fn Src, Nat -> Text
/// ```
pub fn line_text(src_p0: &Src, n_p1: &Nat) -> Text {
    let from_p2 = or(&index(&src_p0.starts, n_p1), &Nat::from(0u32));
    let to_p3 = or(&index(&src_p0.starts, &(n_p1 + &Nat::from(1u32))), &(&len_text(&src_p0.text) + &Nat::from(1u32)));
    crate::syntax::lexer::chars::between(&src_p0.text, &from_p2, &max(&from_p2, &or(&(&to_p3).checked_sub(&Nat::from(1u32)), &Nat::from(0u32))))
}

/// ```prism
/// SpanText: fn Src, Range -> Text
/// ```
pub fn span_text(src_p0: &Src, r_p1: &crate::syntax::Range) -> Text {
    crate::syntax::lexer::chars::between(&src_p0.text, &r_p1.start, &max(&r_p1.start, &r_p1.end))
}

/// ```prism
/// Repeat: fn Text, Nat -> Text
/// ```
pub fn repeat(t_p0: &Text, n_p1: &Nat) -> Text {
    concat(&fold(&range0(n_p1), &Array::new(), &(|acc_p2: &Array<Text>, _: &Nat| push(acc_p2, t_p0))))
}

/// ```prism
/// Range0: fn Nat -> [Nat]
/// ```
pub fn range0(n_p0: &Nat) -> Array<Nat> {
    let mut this: Array<Nat> = Array::new();
    let mut i_p1: Nat = Nat::from(0u32);
    let mut left_p2: Nat = n_p0.clone();
    while let Some(m_p3) = (&left_p2).checked_sub(&Nat::from(1u32)) {
        left_p2 = m_p3.clone();
        this = push(&this, &i_p1);
        i_p1 = &i_p1 + &Nat::from(1u32);
    }
    this
}

/// ```prism
/// RenderCDiag: fn [Src], CDiag -> Text
/// ```
pub fn render_cdiag(srcs_p0: &Array<Src>, d_p1: &CDiag) -> Text {
    match index(srcs_p0, &d_p1.file) {
        None => Text::from(format!("?: {}[{}]: {}\n", &severity(d_p1), &d_p1.code, &d_p1.message)),
        Some(src_p2) => {
            let line_p3 = cline_of(&src_p2.starts, &d_p1.span.start);
            let col_p4 = crate::syntax::lexer::chars::column_of(&src_p2.text, &or(&index(&src_p2.starts, &line_p3), &Nat::from(0u32)), &d_p1.span.start);
            let text_p5 = line_text(&src_p2, &line_p3);
            let width_p6 = max(&Nat::from(1u32), &min(&crate::syntax::lexer::chars::count_chars(&span_text(&src_p2, &d_p1.span)), &or(&(&crate::syntax::lexer::chars::count_chars(&text_p5)).checked_sub(&col_p4), &Nat::from(1u32))));
            let carets_p7 = Text::from(format!("    {}{}", &repeat(&Text::lit(" "), &col_p4), &repeat(&Text::lit("^"), &width_p6)));
            let fix_p8 = if &d_p1.fix == &Text::lit("") {
                Text::lit("")
            } else {
                Text::from(format!("  fix: {}\n", &d_p1.fix))
            };
            Text::from(format!("{}: {}[{}]: {}\n    {}\n{}\n{}", &src_place(&src_p2, &d_p1.span.start), &severity(d_p1), &d_p1.code, &d_p1.message, &text_p5, &carets_p7, &fix_p8))
        },
    }
}

/// ```prism
/// Severity: fn CDiag -> Text
/// ```
pub fn severity(d_p0: &CDiag) -> Text {
    if is_warning(d_p0) { Text::lit("warning") } else { Text::lit("error") }
}

/// ```prism
/// IsWarning: fn CDiag -> Bool
/// ```
pub fn is_warning(d_p0: &CDiag) -> bool {
    &d_p0.code == &Text::lit("unused")
}

/// ```prism
/// SortDiags: fn [CDiag] -> [CDiag]
/// ```
pub fn sort_diags(ds_p0: &Array<CDiag>) -> Array<CDiag> {
    fold(ds_p0, &Array::new(), &(|acc_p1: &Array<CDiag>, d_p2: &CDiag| insert_sorted(acc_p1, d_p2)))
}

/// ```prism
/// InsertSorted: fn [CDiag], CDiag -> [CDiag]
/// ```
pub fn insert_sorted(acc_p0: &Array<CDiag>, d_p1: &CDiag) -> Array<CDiag> {
    let before_p2 = filter(acc_p0, &(|x_p4: &CDiag| !diag_before2(d_p1, x_p4)));
    let after_p3 = filter(acc_p0, &(|x_p5: &CDiag| diag_before2(d_p1, x_p5)));
    if any_is(acc_p0, d_p1) {
        acc_p0.clone()
    } else {
        append(&push(&before_p2, d_p1), &after_p3)
    }
}

/// ```prism
/// AnyIs: fn [CDiag], CDiag -> Bool
/// ```
pub fn any_is(xs_p0: &Array<CDiag>, d_p1: &CDiag) -> bool {
    fold(xs_p0, &false, &(|seen_p2: &bool, x_p3: &CDiag| *seen_p2 || (x_p3 == d_p1)))
}

/// ```prism
/// DiagBefore2: fn CDiag, CDiag -> Bool
/// ```
pub fn diag_before2(a_p0: &CDiag, b_p1: &CDiag) -> bool {
    if &a_p0.file != &b_p1.file {
        &a_p0.file < &b_p1.file
    } else {
        &a_p0.span.start < &b_p1.span.start
    }
}

/// ```prism
/// CountWord: fn Nat -> Text
/// ```
pub fn count_word(n0: &Nat) -> Text {
    match n0 {
        c0_0 if (c0_0 == &Nat::from(0u32)) => Text::lit("no"),
        c1_0 if (c1_0 == &Nat::from(1u32)) => Text::lit("one"),
        c2_0 if (c2_0 == &Nat::from(2u32)) => Text::lit("two"),
        c3_0 if (c3_0 == &Nat::from(3u32)) => Text::lit("three"),
        c4_0 if (c4_0 == &Nat::from(4u32)) => Text::lit("four"),
        n_p0 => show_text(n_p0),
        _ => unreachable!("no arm matched"),
    }
}
