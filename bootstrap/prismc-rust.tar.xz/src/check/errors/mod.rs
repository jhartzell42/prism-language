//! The module `Check.Errors`, from `target/bootstrap/src/prismc/check/errors/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `CDiag`:
///
/// ```prism
/// type CDiag = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CDiag {
    pub code: Text,
    pub file: Nat,
    pub span: crate::syntax::Range,
    pub message: Text,
    pub fix: Text,
}

impl Show for CDiag {
    fn show(&self, p: &mut Printer) {
        p.record("CDiag", &[("code", &self.code), ("file", &self.file), ("span", &self.span), ("message", &self.message), ("fix", &self.fix)]);
    }
}

impl ToPod for CDiag {
    fn to_pod(&self) -> Pod {
        Pod::record("CDiag", vec![("code", self.code.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod()), ("message", self.message.to_pod()), ("fix", self.fix.to_pod())])
    }
}

impl FromPod for CDiag {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CDiag { code: FromPod::from_pod(field(p, "code")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)?, message: FromPod::from_pod(field(p, "message")?)?, fix: FromPod::from_pod(field(p, "fix")?)? })
    }
}

/// `Src`:
///
/// ```prism
/// type Src = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Src {
    pub path_: Text,
    pub text: Text,
    pub starts: Array<Nat>,
    pub segs: Array<SrcSeg>,
}

impl Show for Src {
    fn show(&self, p: &mut Printer) {
        p.record("Src", &[("path", &self.path_), ("text", &self.text), ("starts", &self.starts), ("segs", &self.segs)]);
    }
}

impl ToPod for Src {
    fn to_pod(&self) -> Pod {
        Pod::record("Src", vec![("path", self.path_.to_pod()), ("text", self.text.to_pod()), ("starts", self.starts.to_pod()), ("segs", self.segs.to_pod())])
    }
}

impl FromPod for Src {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Src { path_: FromPod::from_pod(field(p, "path")?)?, text: FromPod::from_pod(field(p, "text")?)?, starts: FromPod::from_pod(field(p, "starts")?)?, segs: FromPod::from_pod(field(p, "segs")?)? })
    }
}

/// `SrcSeg`:
///
/// ```prism
/// type SrcSeg = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct SrcSeg {
    pub path_: Text,
    pub start: Nat,
    pub line: Nat,
    pub role: Text,
}

impl Show for SrcSeg {
    fn show(&self, p: &mut Printer) {
        p.record("SrcSeg", &[("path", &self.path_), ("start", &self.start), ("line", &self.line), ("role", &self.role)]);
    }
}

impl ToPod for SrcSeg {
    fn to_pod(&self) -> Pod {
        Pod::record("SrcSeg", vec![("path", self.path_.to_pod()), ("start", self.start.to_pod()), ("line", self.line.to_pod()), ("role", self.role.to_pod())])
    }
}

impl FromPod for SrcSeg {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(SrcSeg { path_: FromPod::from_pod(field(p, "path")?)?, start: FromPod::from_pod(field(p, "start")?)?, line: FromPod::from_pod(field(p, "line")?)?, role: FromPod::from_pod(field(p, "role")?)? })
    }
}

/// ```prism
/// MkSrc: fn Text, Text -> Src
/// ```
pub fn mk_src(path_: &Text, text: &Text) -> Src {
    Src { path_: path_.clone(), text: text.clone(), starts: cline_starts(text), segs: Array::from(vec![SrcSeg { path_: path_.clone(), start: Nat::from(0u32), line: Nat::from(0u32), role: Text::lit("loose") }]) }
}

/// ```prism
/// MkJoinedSrc: fn [((Text, Text, Text))] -> Src
/// ```
pub fn mk_joined_src(files: &Array<(Text, Text, Text)>) -> Src {
    let text = crate::syntax::lexer::join(&each(files, &(|(_, t, _): &(Text, Text, Text)| t.clone())), &Text::lit("\n"));
    let starts = cline_starts(&text);
    let (segs, _) = fold(files, &(Array::new(), Nat::from(0u32)), &(|(acc, at_): &(Array<SrcSeg>, Nat), (path_, t, role): &(Text, Text, Text)| (push(acc, &SrcSeg { path_: path_.clone(), start: at_.clone(), line: cline_of(&starts, at_), role: role.clone() }), &(at_ + &len_text(t)) + &Nat::from(1u32))));
    let first_ = match index(files, &Nat::from(0u32)) {
        Some((path_, _, _)) => path_.clone(),
        None => Text::lit(""),
    };
    Src { path_: first_.clone(), text: text.clone(), starts: starts.clone(), segs: segs.clone() }
}

/// ```prism
/// SegAt: fn Src, Nat -> SrcSeg
/// ```
pub fn seg_at(src: &Src, offset: &Nat) -> SrcSeg {
    fold(&src.segs, &or(&index(&src.segs, &Nat::from(0u32)), &SrcSeg { path_: src.path_.clone(), start: Nat::from(0u32), line: Nat::from(0u32), role: Text::lit("loose") }), &(|found: &SrcSeg, s: &SrcSeg| if &s.start <= offset { s.clone() } else { found.clone() }))
}

/// ```prism
/// SrcPlace: fn Src, Nat -> Text
/// ```
pub fn src_place(src: &Src, offset: &Nat) -> Text {
    let seg = seg_at(src, offset);
    Text::from(format!("{}:{}", &seg.path_, &(&or(&(&cline_of(&src.starts, offset)).checked_sub(&seg.line), &Nat::from(0u32)) + &Nat::from(1u32))))
}

/// ```prism
/// Diag0: fn Text, Nat, Range, Text -> CDiag
/// ```
pub fn diag0(code: &Text, file: &Nat, span: &crate::syntax::Range, message: &Text) -> CDiag {
    CDiag { code: code.clone(), file: file.clone(), span: span.clone(), message: message.clone(), fix: Text::lit("") }
}

/// ```prism
/// DiagFix: fn Text, Nat, Range, Text, Text -> CDiag
/// ```
pub fn diag_fix(code: &Text, file: &Nat, span: &crate::syntax::Range, message: &Text, fix: &Text) -> CDiag {
    CDiag { code: code.clone(), file: file.clone(), span: span.clone(), message: message.clone(), fix: fix.clone() }
}

/// ```prism
/// CLineStarts: fn Text -> [Nat]
/// ```
pub fn cline_starts(text: &Text) -> Array<Nat> {
    let (starts, _) = fold(&split(text, &Text::lit("\n")), &(Array::new(), Nat::from(0u32)), &(|(acc, at_): &(Array<Nat>, Nat), line: &Text| (push(acc, at_), &(at_ + &len_text(line)) + &Nat::from(1u32))));
    starts.clone()
}

/// ```prism
/// CLineOf: fn [Nat], Nat -> Nat
/// ```
pub fn cline_of(starts: &Array<Nat>, offset: &Nat) -> Nat {
    crate::syntax::lexer::dec(&fold(starts, &Nat::from(0u32), &(|n: &Nat, s: &Nat| if s <= offset { n + &Nat::from(1u32) } else { n.clone() })))
}

/// ```prism
/// LineText: fn Src, Nat -> Text
/// ```
pub fn line_text(src: &Src, n: &Nat) -> Text {
    let from = or(&index(&src.starts, n), &Nat::from(0u32));
    let to = or(&index(&src.starts, &(n + &Nat::from(1u32))), &(&len_text(&src.text) + &Nat::from(1u32)));
    crate::syntax::lexer::between(&src.text, &from, &max(&from, &or(&(&to).checked_sub(&Nat::from(1u32)), &Nat::from(0u32))))
}

/// ```prism
/// SpanText: fn Src, Range -> Text
/// ```
pub fn span_text(src: &Src, r: &crate::syntax::Range) -> Text {
    crate::syntax::lexer::between(&src.text, &r.start, &max(&r.start, &r.end))
}

/// ```prism
/// Repeat: fn Text, Nat -> Text
/// ```
pub fn repeat(t: &Text, n: &Nat) -> Text {
    concat(&fold(&range0(n), &Array::new(), &(|acc: &Array<Text>, _: &Nat| push(acc, t))))
}

/// ```prism
/// Range0: fn Nat -> [Nat]
/// ```
pub fn range0(n: &Nat) -> Array<Nat> {
    let mut this: Array<Nat> = Array::new();
    let mut i: Nat = Nat::from(0u32);
    let mut left: Nat = n.clone();
    while let Some(m) = (&left).checked_sub(&Nat::from(1u32)) {
        left = m.clone();
        this = push(&this, &i);
        i = &i + &Nat::from(1u32);
    }
    this
}

/// ```prism
/// RenderCDiag: fn [Src], CDiag -> Text
/// ```
pub fn render_cdiag(srcs: &Array<Src>, d: &CDiag) -> Text {
    match index(srcs, &d.file) {
        None => Text::from(format!("?: {}[{}]: {}\n", &severity(d), &d.code, &d.message)),
        Some(src) => {
            let line = cline_of(&src.starts, &d.span.start);
            let col = crate::syntax::lexer::column_of(&src.text, &or(&index(&src.starts, &line), &Nat::from(0u32)), &d.span.start);
            let text = line_text(&src, &line);
            let width = max(&Nat::from(1u32), &min(&crate::syntax::lexer::count_chars(&span_text(&src, &d.span)), &or(&(&crate::syntax::lexer::count_chars(&text)).checked_sub(&col), &Nat::from(1u32))));
            let carets = Text::from(format!("    {}{}", &repeat(&Text::lit(" "), &col), &repeat(&Text::lit("^"), &width)));
            let fix = if &d.fix == &Text::lit("") {
                Text::lit("")
            } else {
                Text::from(format!("  fix: {}\n", &d.fix))
            };
            Text::from(format!("{}: {}[{}]: {}\n    {}\n{}\n{}", &src_place(&src, &d.span.start), &severity(d), &d.code, &d.message, &text, &carets, &fix))
        },
    }
}

/// ```prism
/// Severity: fn CDiag -> Text
/// ```
pub fn severity(d: &CDiag) -> Text {
    if is_warning(d) { Text::lit("warning") } else { Text::lit("error") }
}

/// ```prism
/// IsWarning: fn CDiag -> Bool
/// ```
pub fn is_warning(d: &CDiag) -> bool {
    (&d.code == &Text::lit("unused")) || (&d.code == &Text::lit("section"))
}

/// ```prism
/// SortDiags: fn [CDiag] -> [CDiag]
/// ```
pub fn sort_diags(ds: &Array<CDiag>) -> Array<CDiag> {
    fold(ds, &Array::new(), &(|acc: &Array<CDiag>, d: &CDiag| insert_sorted(acc, d)))
}

/// ```prism
/// InsertSorted: fn [CDiag], CDiag -> [CDiag]
/// ```
pub fn insert_sorted(acc: &Array<CDiag>, d: &CDiag) -> Array<CDiag> {
    let before_ = filter(acc, &(|x: &CDiag| !diag_before2(d, x)));
    let after_ = filter(acc, &(|x: &CDiag| diag_before2(d, x)));
    if any_is(acc, d) { acc.clone() } else { append(&push(&before_, d), &after_) }
}

/// ```prism
/// AnyIs: fn [CDiag], CDiag -> Bool
/// ```
pub fn any_is(xs: &Array<CDiag>, d: &CDiag) -> bool {
    fold(xs, &false, &(|seen: &bool, x: &CDiag| *seen || (x == d)))
}

/// ```prism
/// DiagBefore2: fn CDiag, CDiag -> Bool
/// ```
pub fn diag_before2(a: &CDiag, b: &CDiag) -> bool {
    if &a.file != &b.file { &a.file < &b.file } else { &a.span.start < &b.span.start }
}

/// ```prism
/// CountWord: fn Nat -> Text
/// ```
pub fn count_word(n0: &Nat) -> Text {
    match n0 {
        c0_0 if (c0_0 == &Nat::from(0u32)) => Text::lit("no"),
        c1_0 if (c1_0 == &Nat::from(1u32)) => Text::lit("one"),
        c2_0 if (c2_0 == &Nat::from(2u32)) => Text::lit("two"),
        c3_0 if (c3_0 == &Nat::from(3u32)) => Text::lit("three"),
        c4_0 if (c4_0 == &Nat::from(4u32)) => Text::lit("four"),
        n => show_text(n),
        _ => unreachable!("no arm matched"),
    }
}
