//! The module `Check.Errors`, from `target/bootstrap/src/prismc/check/errors.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `CDiag`:
///
/// ```prism
/// type CDiag = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct CDiag {
    pub code_p: crate::prelude::Text,
    pub file_p: crate::prelude::Nat,
    pub span_p: crate::syntax::Range,
    pub message_p: crate::prelude::Text,
    pub fix_p: crate::prelude::Text,
}

impl crate::prelude::Show for CDiag {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("CDiag", &[("code", &self.code_p), ("file", &self.file_p), ("span", &self.span_p), ("message", &self.message_p), ("fix", &self.fix_p)]);
    }
}

impl crate::prelude::ToPod for CDiag {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("CDiag", vec![("code", self.code_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod()), ("message", self.message_p.to_pod()), ("fix", self.fix_p.to_pod())])
    }
}

impl crate::prelude::FromPod for CDiag {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(CDiag { code_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "code")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)?, message_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "message")?)?, fix_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fix")?)? })
    }
}

/// `Src`:
///
/// ```prism
/// type Src = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Src {
    pub path_p: crate::prelude::Text,
    pub text_p: crate::prelude::Text,
    pub starts_p: crate::prelude::Array<crate::prelude::Nat>,
    pub segs_p: crate::prelude::Array<SrcSeg>,
}

impl crate::prelude::Show for Src {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Src", &[("path", &self.path_p), ("text", &self.text_p), ("starts", &self.starts_p), ("segs", &self.segs_p)]);
    }
}

impl crate::prelude::ToPod for Src {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Src", vec![("path", self.path_p.to_pod()), ("text", self.text_p.to_pod()), ("starts", self.starts_p.to_pod()), ("segs", self.segs_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Src {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Src { path_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "path")?)?, text_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "text")?)?, starts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "starts")?)?, segs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "segs")?)? })
    }
}

/// `SrcSeg`:
///
/// ```prism
/// type SrcSeg = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct SrcSeg {
    pub path_p: crate::prelude::Text,
    pub start_p: crate::prelude::Nat,
    pub line_p: crate::prelude::Nat,
    pub role_p: crate::prelude::Text,
}

impl crate::prelude::Show for SrcSeg {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("SrcSeg", &[("path", &self.path_p), ("start", &self.start_p), ("line", &self.line_p), ("role", &self.role_p)]);
    }
}

impl crate::prelude::ToPod for SrcSeg {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("SrcSeg", vec![("path", self.path_p.to_pod()), ("start", self.start_p.to_pod()), ("line", self.line_p.to_pod()), ("role", self.role_p.to_pod())])
    }
}

impl crate::prelude::FromPod for SrcSeg {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(SrcSeg { path_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "path")?)?, start_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "start")?)?, line_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "line")?)?, role_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "role")?)? })
    }
}

/// ```prism
/// MkSrc: fn Text, Text -> Src
/// ```
pub fn mk_src_f(path_p0: &crate::prelude::Text, text_p1: &crate::prelude::Text) -> Src {
    Src { path_p: path_p0.clone(), text_p: text_p1.clone(), starts_p: cline_starts_f(text_p1), segs_p: crate::prelude::Array::from(vec![SrcSeg { path_p: path_p0.clone(), start_p: crate::prelude::Nat::from(0u32), line_p: crate::prelude::Nat::from(0u32), role_p: crate::prelude::Text::lit("loose") }]) }
}

/// ```prism
/// MkJoinedSrc: fn [((Text, Text, Text))] -> Src
/// ```
pub fn mk_joined_src_f(files_p0: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)>) -> Src {
    let text_p1 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(files_p0, &(|(_, t_p4, _): &(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)| t_p4.clone())), &crate::prelude::Text::lit("\n"));
    let starts_p2 = cline_starts_f(&text_p1);
    let (segs_pa, _) = crate::prelude::fold(files_p0, &(crate::prelude::Array::new(), crate::prelude::Nat::from(0u32)), &(|(acc_p5, at_p6): &(crate::prelude::Array<SrcSeg>, crate::prelude::Nat), (path_p7, t_p8, role_p9): &(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)| (crate::prelude::push(acc_p5, &SrcSeg { path_p: path_p7.clone(), start_p: at_p6.clone(), line_p: cline_of_f(&starts_p2, at_p6), role_p: role_p9.clone() }), &(at_p6 + &crate::prelude::len_text(t_p8)) + &crate::prelude::Nat::from(1u32))));
    let first_p3 = match crate::prelude::index(files_p0, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some((path_pb, _, _)) => path_pb,
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    };
    Src { path_p: first_p3.clone(), text_p: text_p1.clone(), starts_p: starts_p2.clone(), segs_p: segs_pa.clone() }
}

/// ```prism
/// SegAt: fn Src, Nat -> SrcSeg
/// ```
pub fn seg_at_f(src_p0: &Src, offset_p1: &crate::prelude::Nat) -> SrcSeg {
    crate::prelude::fold(&src_p0.segs_p, &crate::prelude::or(&crate::prelude::index(&src_p0.segs_p, &crate::prelude::Nat::from(0u32)), &SrcSeg { path_p: src_p0.path_p.clone(), start_p: crate::prelude::Nat::from(0u32), line_p: crate::prelude::Nat::from(0u32), role_p: crate::prelude::Text::lit("loose") }), &(|found_p2: &SrcSeg, s_p3: &SrcSeg| if &s_p3.start_p <= offset_p1 { s_p3.clone() } else { found_p2.clone() }))
}

/// ```prism
/// SrcPlace: fn Src, Nat -> Text
/// ```
pub fn src_place_f(src_p0: &Src, offset_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    let seg_p2 = seg_at_f(src_p0, offset_p1);
    crate::prelude::Text::from(format!("{}:{}", &seg_p2.path_p, &(&crate::prelude::or(&(&cline_of_f(&src_p0.starts_p, offset_p1)).checked_sub(&seg_p2.line_p), &crate::prelude::Nat::from(0u32)) + &crate::prelude::Nat::from(1u32))))
}

/// ```prism
/// Diag0: fn Text, Nat, Range, Text -> CDiag
/// ```
pub fn diag0_f(code_p0: &crate::prelude::Text, file_p1: &crate::prelude::Nat, span_p2: &crate::syntax::Range, message_p3: &crate::prelude::Text) -> CDiag {
    CDiag { code_p: code_p0.clone(), file_p: file_p1.clone(), span_p: span_p2.clone(), message_p: message_p3.clone(), fix_p: crate::prelude::Text::lit("") }
}

/// ```prism
/// DiagFix: fn Text, Nat, Range, Text, Text -> CDiag
/// ```
pub fn diag_fix_f(code_p0: &crate::prelude::Text, file_p1: &crate::prelude::Nat, span_p2: &crate::syntax::Range, message_p3: &crate::prelude::Text, fix_p4: &crate::prelude::Text) -> CDiag {
    CDiag { code_p: code_p0.clone(), file_p: file_p1.clone(), span_p: span_p2.clone(), message_p: message_p3.clone(), fix_p: fix_p4.clone() }
}

/// ```prism
/// CLineStarts: fn Text -> [Nat]
/// ```
pub fn cline_starts_f(text_p0: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Nat> {
    let (starts_p4, _) = crate::prelude::fold(&crate::prelude::split_on(text_p0, &crate::prelude::Text::lit("\n")), &(crate::prelude::Array::new(), crate::prelude::Nat::from(0u32)), &(|(acc_p1, at_p2): &(crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Nat), line_p3: &crate::prelude::Text| (crate::prelude::push(acc_p1, at_p2), &(at_p2 + &crate::prelude::len_text(line_p3)) + &crate::prelude::Nat::from(1u32))));
    starts_p4.clone()
}

/// ```prism
/// CLineOf: fn [Nat], Nat -> Nat
/// ```
pub fn cline_of_f(starts_p0: &crate::prelude::Array<crate::prelude::Nat>, offset_p1: &crate::prelude::Nat) -> crate::prelude::Nat {
    crate::syntax::lexer::chars::dec_f(&crate::prelude::fold(starts_p0, &crate::prelude::Nat::from(0u32), &(|n_p2: &crate::prelude::Nat, s_p3: &crate::prelude::Nat| if s_p3 <= offset_p1 { n_p2 + &crate::prelude::Nat::from(1u32) } else { n_p2.clone() })))
}

/// ```prism
/// LineText: fn Src, Nat -> Text
/// ```
pub fn line_text_f(src_p0: &Src, n_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    let from_p2 = crate::prelude::or(&crate::prelude::index(&src_p0.starts_p, n_p1), &crate::prelude::Nat::from(0u32));
    let to_p3 = crate::prelude::or(&crate::prelude::index(&src_p0.starts_p, &(n_p1 + &crate::prelude::Nat::from(1u32))), &(&crate::prelude::len_text(&src_p0.text_p) + &crate::prelude::Nat::from(1u32)));
    crate::syntax::lexer::chars::between_f(&src_p0.text_p, &from_p2, &crate::prelude::max(&from_p2, &crate::prelude::or(&(&to_p3).checked_sub(&crate::prelude::Nat::from(1u32)), &crate::prelude::Nat::from(0u32))))
}

/// ```prism
/// SpanText: fn Src, Range -> Text
/// ```
pub fn span_text_f(src_p0: &Src, r_p1: &crate::syntax::Range) -> crate::prelude::Text {
    crate::syntax::lexer::chars::between_f(&src_p0.text_p, &r_p1.start_p, &crate::prelude::max(&r_p1.start_p, &r_p1.end_p))
}

/// ```prism
/// Repeat: fn Text, Nat -> Text
/// ```
pub fn repeat_f(t_p0: &crate::prelude::Text, n_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    crate::prelude::concat(&crate::prelude::fold(&range0_f(n_p1), &crate::prelude::Array::new(), &(|acc_p2: &crate::prelude::Array<crate::prelude::Text>, _: &crate::prelude::Nat| crate::prelude::push(acc_p2, t_p0))))
}

/// ```prism
/// Range0: fn Nat -> [Nat]
/// ```
pub fn range0_f(n_p0: &crate::prelude::Nat) -> crate::prelude::Array<crate::prelude::Nat> {
    let mut this: crate::prelude::Array<crate::prelude::Nat> = crate::prelude::Array::new();
    let mut i_p1: crate::prelude::Nat = crate::prelude::Nat::from(0u32);
    let mut left_p2: crate::prelude::Nat = n_p0.clone();
    while let ::std::option::Option::Some(m_p3) = (&left_p2).checked_sub(&crate::prelude::Nat::from(1u32)) {
        left_p2 = m_p3.clone();
        this = crate::prelude::push(&this, &i_p1);
        i_p1 = &i_p1 + &crate::prelude::Nat::from(1u32);
    }
    this
}

/// ```prism
/// RenderCDiag: fn [Src], CDiag -> Text
/// ```
pub fn render_cdiag_f(srcs_p0: &crate::prelude::Array<Src>, d_p1: &CDiag) -> crate::prelude::Text {
    match crate::prelude::index(srcs_p0, &d_p1.file_p) {
        ::std::option::Option::None => crate::prelude::Text::from(format!("?: {}[{}]: {}\n", &severity_f(d_p1), &d_p1.code_p, &d_p1.message_p)),
        ::std::option::Option::Some(src_p2) => {
            let line_p3 = cline_of_f(&src_p2.starts_p, &d_p1.span_p.start_p);
            let col_p4 = crate::syntax::lexer::chars::column_of_f(&src_p2.text_p, &crate::prelude::or(&crate::prelude::index(&src_p2.starts_p, &line_p3), &crate::prelude::Nat::from(0u32)), &d_p1.span_p.start_p);
            let text_p5 = line_text_f(&src_p2, &line_p3);
            let width_p6 = crate::prelude::max(&crate::prelude::Nat::from(1u32), &crate::prelude::min(&crate::syntax::lexer::chars::count_chars_f(&span_text_f(&src_p2, &d_p1.span_p)), &crate::prelude::or(&(&crate::syntax::lexer::chars::count_chars_f(&text_p5)).checked_sub(&col_p4), &crate::prelude::Nat::from(1u32))));
            let carets_p7 = crate::prelude::Text::from(format!("    {}{}", &repeat_f(&crate::prelude::Text::lit(" "), &col_p4), &repeat_f(&crate::prelude::Text::lit("^"), &width_p6)));
            let fix_p8 = if &d_p1.fix_p == &crate::prelude::Text::lit("") {
                crate::prelude::Text::lit("")
            } else {
                crate::prelude::Text::from(format!("  fix: {}\n", &d_p1.fix_p))
            };
            crate::prelude::Text::from(format!("{}: {}[{}]: {}\n    {}\n{}\n{}", &src_place_f(&src_p2, &d_p1.span_p.start_p), &severity_f(d_p1), &d_p1.code_p, &d_p1.message_p, &text_p5, &carets_p7, &fix_p8))
        },
    }
}

/// ```prism
/// Severity: fn CDiag -> Text
/// ```
pub fn severity_f(d_p0: &CDiag) -> crate::prelude::Text {
    if is_warning_f(d_p0) {
        crate::prelude::Text::lit("warning")
    } else {
        crate::prelude::Text::lit("error")
    }
}

/// ```prism
/// IsWarning: fn CDiag -> Bool
/// ```
pub fn is_warning_f(d_p0: &CDiag) -> bool {
    &d_p0.code_p == &crate::prelude::Text::lit("unused")
}

/// ```prism
/// SortDiags: fn [CDiag] -> [CDiag]
/// ```
pub fn sort_diags_f(ds_p0: &crate::prelude::Array<CDiag>) -> crate::prelude::Array<CDiag> {
    crate::prelude::fold(ds_p0, &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<CDiag>, d_p2: &CDiag| insert_sorted_f(acc_p1, d_p2)))
}

/// ```prism
/// InsertSorted: fn [CDiag], CDiag -> [CDiag]
/// ```
pub fn insert_sorted_f(acc_p0: &crate::prelude::Array<CDiag>, d_p1: &CDiag) -> crate::prelude::Array<CDiag> {
    let before_p2 = crate::prelude::filter(acc_p0, &(|x_p4: &CDiag| !diag_before2_f(d_p1, x_p4)));
    let after_p3 = crate::prelude::filter(acc_p0, &(|x_p5: &CDiag| diag_before2_f(d_p1, x_p5)));
    if any_is_f(acc_p0, d_p1) {
        acc_p0.clone()
    } else {
        crate::prelude::append(&crate::prelude::push(&before_p2, d_p1), &after_p3)
    }
}

/// ```prism
/// AnyIs: fn [CDiag], CDiag -> Bool
/// ```
pub fn any_is_f(xs_p0: &crate::prelude::Array<CDiag>, d_p1: &CDiag) -> bool {
    crate::prelude::fold(xs_p0, &false, &(|seen_p2: &bool, x_p3: &CDiag| *seen_p2 || (x_p3 == d_p1)))
}

/// ```prism
/// DiagBefore2: fn CDiag, CDiag -> Bool
/// ```
pub fn diag_before2_f(a_p0: &CDiag, b_p1: &CDiag) -> bool {
    if &a_p0.file_p != &b_p1.file_p {
        &a_p0.file_p < &b_p1.file_p
    } else {
        &a_p0.span_p.start_p < &b_p1.span_p.start_p
    }
}

/// ```prism
/// CountWord: fn Nat -> Text
/// ```
pub fn count_word_f(n0: &crate::prelude::Nat) -> crate::prelude::Text {
    match n0 {
        c0_0 if (c0_0 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("no"),
        c1_0 if (c1_0 == &crate::prelude::Nat::from(1u32)) => crate::prelude::Text::lit("one"),
        c2_0 if (c2_0 == &crate::prelude::Nat::from(2u32)) => crate::prelude::Text::lit("two"),
        c3_0 if (c3_0 == &crate::prelude::Nat::from(3u32)) => crate::prelude::Text::lit("three"),
        c4_0 if (c4_0 == &crate::prelude::Nat::from(4u32)) => crate::prelude::Text::lit("four"),
        n_p0 => crate::prelude::show_text(n_p0),
        _ => unreachable!("no arm matched"),
    }
}
