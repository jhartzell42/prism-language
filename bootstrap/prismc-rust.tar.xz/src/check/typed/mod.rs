//! The module `Check.Typed`, from `target/bootstrap/src/prismc/check/typed/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod print;

/// `AppNote`:
///
/// ```prism
/// type AppNote = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct AppNote {
    pub at_p: SrcAt,
    pub callee_p: crate::prelude::Text,
    pub kind_p: crate::prelude::Text,
    pub layer_p: crate::prelude::Text,
    pub lifted_p: crate::prelude::Array<crate::prelude::Nat>,
    pub inner_p: crate::prelude::Text,
    pub color_p: crate::check::types::Col,
}

impl crate::prelude::Show for AppNote {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("AppNote", &[("at", &self.at_p), ("callee", &self.callee_p), ("kind", &self.kind_p), ("layer", &self.layer_p), ("lifted", &self.lifted_p), ("inner", &self.inner_p), ("color", &self.color_p)]);
    }
}

impl crate::prelude::ToPod for AppNote {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("AppNote", vec![("at", self.at_p.to_pod()), ("callee", self.callee_p.to_pod()), ("kind", self.kind_p.to_pod()), ("layer", self.layer_p.to_pod()), ("lifted", self.lifted_p.to_pod()), ("inner", self.inner_p.to_pod()), ("color", self.color_p.to_pod())])
    }
}

impl crate::prelude::FromPod for AppNote {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(AppNote { at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, callee_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "callee")?)?, kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)?, layer_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "layer")?)?, lifted_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lifted")?)?, inner_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "inner")?)?, color_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "color")?)? })
    }
}

/// `BinderNote`:
///
/// ```prism
/// type BinderNote = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct BinderNote {
    pub at_p: SrcAt,
    pub name_p: crate::prelude::Text,
    pub ty_p: crate::check::types::Ty,
}

impl crate::prelude::Show for BinderNote {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("BinderNote", &[("at", &self.at_p), ("name", &self.name_p), ("ty", &self.ty_p)]);
    }
}

impl crate::prelude::ToPod for BinderNote {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("BinderNote", vec![("at", self.at_p.to_pod()), ("name", self.name_p.to_pod()), ("ty", self.ty_p.to_pod())])
    }
}

impl crate::prelude::FromPod for BinderNote {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(BinderNote { at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)? })
    }
}

/// `DefNote`:
///
/// ```prism
/// type DefNote = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct DefNote {
    pub at_p: SrcAt,
    pub name_p: crate::prelude::Text,
    pub scheme_p: crate::check::types::Scheme,
}

impl crate::prelude::Show for DefNote {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("DefNote", &[("at", &self.at_p), ("name", &self.name_p), ("scheme", &self.scheme_p)]);
    }
}

impl crate::prelude::ToPod for DefNote {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("DefNote", vec![("at", self.at_p.to_pod()), ("name", self.name_p.to_pod()), ("scheme", self.scheme_p.to_pod())])
    }
}

impl crate::prelude::FromPod for DefNote {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(DefNote { at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, scheme_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "scheme")?)? })
    }
}

/// `FnNote`:
///
/// ```prism
/// type FnNote = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct FnNote {
    pub at_p: SrcAt,
    pub name_p: crate::prelude::Text,
    pub declared_p: crate::check::types::Col,
    pub body_p: crate::check::types::Col,
}

impl crate::prelude::Show for FnNote {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("FnNote", &[("at", &self.at_p), ("name", &self.name_p), ("declared", &self.declared_p), ("body", &self.body_p)]);
    }
}

impl crate::prelude::ToPod for FnNote {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("FnNote", vec![("at", self.at_p.to_pod()), ("name", self.name_p.to_pod()), ("declared", self.declared_p.to_pod()), ("body", self.body_p.to_pod())])
    }
}

impl crate::prelude::FromPod for FnNote {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(FnNote { at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, declared_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "declared")?)?, body_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "body")?)? })
    }
}

/// `GenNote`:
///
/// ```prism
/// type GenNote = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct GenNote {
    pub at_p: SrcAt,
    pub name_p: crate::prelude::Text,
    pub tys_p: crate::prelude::Array<crate::prelude::Text>,
    pub cols_p: crate::prelude::Array<crate::prelude::Text>,
}

impl crate::prelude::Show for GenNote {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("GenNote", &[("at", &self.at_p), ("name", &self.name_p), ("tys", &self.tys_p), ("cols", &self.cols_p)]);
    }
}

impl crate::prelude::ToPod for GenNote {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("GenNote", vec![("at", self.at_p.to_pod()), ("name", self.name_p.to_pod()), ("tys", self.tys_p.to_pod()), ("cols", self.cols_p.to_pod())])
    }
}

impl crate::prelude::FromPod for GenNote {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(GenNote { at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, tys_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tys")?)?, cols_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cols")?)? })
    }
}

/// `GlobalNote`:
///
/// ```prism
/// type GlobalNote = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct GlobalNote {
    pub at_p: SrcAt,
    pub target_p: crate::prelude::Text,
}

impl crate::prelude::Show for GlobalNote {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("GlobalNote", &[("at", &self.at_p), ("target", &self.target_p)]);
    }
}

impl crate::prelude::ToPod for GlobalNote {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("GlobalNote", vec![("at", self.at_p.to_pod()), ("target", self.target_p.to_pod())])
    }
}

impl crate::prelude::FromPod for GlobalNote {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(GlobalNote { at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, target_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "target")?)? })
    }
}

/// `GroupNote`:
///
/// ```prism
/// type GroupNote = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct GroupNote {
    pub at_p: SrcAt,
    pub kind_p: crate::prelude::Text,
    pub order_p: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>,
}

impl crate::prelude::Show for GroupNote {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("GroupNote", &[("at", &self.at_p), ("kind", &self.kind_p), ("order", &self.order_p)]);
    }
}

impl crate::prelude::ToPod for GroupNote {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("GroupNote", vec![("at", self.at_p.to_pod()), ("kind", self.kind_p.to_pod()), ("order", self.order_p.to_pod())])
    }
}

impl crate::prelude::FromPod for GroupNote {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(GroupNote { at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)?, order_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "order")?)? })
    }
}

/// `ImplNote`:
///
/// ```prism
/// type ImplNote = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ImplNote {
    pub at_p: SrcAt,
    pub cls_p: crate::prelude::Text,
    pub ty_p: crate::check::types::Ty,
    pub how_p: crate::prelude::Text,
}

impl crate::prelude::Show for ImplNote {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ImplNote", &[("at", &self.at_p), ("cls", &self.cls_p), ("ty", &self.ty_p), ("how", &self.how_p)]);
    }
}

impl crate::prelude::ToPod for ImplNote {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ImplNote", vec![("at", self.at_p.to_pod()), ("cls", self.cls_p.to_pod()), ("ty", self.ty_p.to_pod()), ("how", self.how_p.to_pod())])
    }
}

impl crate::prelude::FromPod for ImplNote {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ImplNote { at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, cls_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cls")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)?, how_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "how")?)? })
    }
}

/// `InstNote`:
///
/// ```prism
/// type InstNote = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct InstNote {
    pub at_p: SrcAt,
    pub name_p: crate::prelude::Text,
    pub tys_p: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>,
    pub cols_p: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Col)>,
}

impl crate::prelude::Show for InstNote {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("InstNote", &[("at", &self.at_p), ("name", &self.name_p), ("tys", &self.tys_p), ("cols", &self.cols_p)]);
    }
}

impl crate::prelude::ToPod for InstNote {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("InstNote", vec![("at", self.at_p.to_pod()), ("name", self.name_p.to_pod()), ("tys", self.tys_p.to_pod()), ("cols", self.cols_p.to_pod())])
    }
}

impl crate::prelude::FromPod for InstNote {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(InstNote { at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, tys_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tys")?)?, cols_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cols")?)? })
    }
}

/// `LiftNote`:
///
/// ```prism
/// type LiftNote = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct LiftNote {
    pub at_p: SrcAt,
    pub sigil_p: crate::prelude::Text,
    pub operands_p: crate::prelude::Array<crate::syntax::Range>,
}

impl crate::prelude::Show for LiftNote {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("LiftNote", &[("at", &self.at_p), ("sigil", &self.sigil_p), ("operands", &self.operands_p)]);
    }
}

impl crate::prelude::ToPod for LiftNote {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("LiftNote", vec![("at", self.at_p.to_pod()), ("sigil", self.sigil_p.to_pod()), ("operands", self.operands_p.to_pod())])
    }
}

impl crate::prelude::FromPod for LiftNote {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(LiftNote { at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, sigil_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "sigil")?)?, operands_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "operands")?)? })
    }
}

/// `LocalNote`:
///
/// ```prism
/// type LocalNote = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct LocalNote {
    pub at_p: SrcAt,
    pub id_p: crate::prelude::Nat,
    pub name_p: crate::prelude::Text,
}

impl crate::prelude::Show for LocalNote {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("LocalNote", &[("at", &self.at_p), ("id", &self.id_p), ("name", &self.name_p)]);
    }
}

impl crate::prelude::ToPod for LocalNote {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("LocalNote", vec![("at", self.at_p.to_pod()), ("id", self.id_p.to_pod()), ("name", self.name_p.to_pod())])
    }
}

impl crate::prelude::FromPod for LocalNote {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(LocalNote { at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, id_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "id")?)?, name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)? })
    }
}

/// `MethodNote`:
///
/// ```prism
/// type MethodNote = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct MethodNote {
    pub at_p: SrcAt,
    pub method_p: crate::prelude::Text,
    pub cls_p: crate::prelude::Text,
}

impl crate::prelude::Show for MethodNote {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("MethodNote", &[("at", &self.at_p), ("method", &self.method_p), ("cls", &self.cls_p)]);
    }
}

impl crate::prelude::ToPod for MethodNote {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("MethodNote", vec![("at", self.at_p.to_pod()), ("method", self.method_p.to_pod()), ("cls", self.cls_p.to_pod())])
    }
}

impl crate::prelude::FromPod for MethodNote {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(MethodNote { at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, method_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "method")?)?, cls_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cls")?)? })
    }
}

/// `SrcAt`:
///
/// ```prism
/// type SrcAt = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct SrcAt {
    pub file_p: crate::prelude::Nat,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for SrcAt {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("SrcAt", &[("file", &self.file_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for SrcAt {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("SrcAt", vec![("file", self.file_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for SrcAt {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(SrcAt { file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `TProgram`:
///
/// ```prism
/// type TProgram = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TProgram {
    pub exprs_p: crate::prelude::Array<TyNote>,
    pub apps_p: crate::prelude::Array<AppNote>,
    pub lifts_p: crate::prelude::Array<LiftNote>,
    pub fns_p: crate::prelude::Array<FnNote>,
    pub impls_p: crate::prelude::Array<ImplNote>,
    pub methods_p: crate::prelude::Array<MethodNote>,
    pub groups_p: crate::prelude::Array<GroupNote>,
    pub binders_p: crate::prelude::Array<BinderNote>,
    pub locals_p: crate::prelude::Array<LocalNote>,
    pub uses_p: crate::prelude::Array<LocalNote>,
    pub calls_p: crate::prelude::Array<LocalNote>,
    pub globals_p: crate::prelude::Array<GlobalNote>,
    pub gens_p: crate::prelude::Array<GenNote>,
    pub insts_p: crate::prelude::Array<InstNote>,
    pub defs_p: crate::prelude::Array<DefNote>,
    pub unshrunk_p: crate::prelude::Array<SrcAt>,
    pub faults_p: crate::prelude::Array<TyNote>,
    pub plains_p: crate::prelude::Array<SrcAt>,
}

impl crate::prelude::Show for TProgram {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TProgram", &[("exprs", &self.exprs_p), ("apps", &self.apps_p), ("lifts", &self.lifts_p), ("fns", &self.fns_p), ("impls", &self.impls_p), ("methods", &self.methods_p), ("groups", &self.groups_p), ("binders", &self.binders_p), ("locals", &self.locals_p), ("uses", &self.uses_p), ("calls", &self.calls_p), ("globals", &self.globals_p), ("gens", &self.gens_p), ("insts", &self.insts_p), ("defs", &self.defs_p), ("unshrunk", &self.unshrunk_p), ("faults", &self.faults_p), ("plains", &self.plains_p)]);
    }
}

impl crate::prelude::ToPod for TProgram {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TProgram", vec![("exprs", self.exprs_p.to_pod()), ("apps", self.apps_p.to_pod()), ("lifts", self.lifts_p.to_pod()), ("fns", self.fns_p.to_pod()), ("impls", self.impls_p.to_pod()), ("methods", self.methods_p.to_pod()), ("groups", self.groups_p.to_pod()), ("binders", self.binders_p.to_pod()), ("locals", self.locals_p.to_pod()), ("uses", self.uses_p.to_pod()), ("calls", self.calls_p.to_pod()), ("globals", self.globals_p.to_pod()), ("gens", self.gens_p.to_pod()), ("insts", self.insts_p.to_pod()), ("defs", self.defs_p.to_pod()), ("unshrunk", self.unshrunk_p.to_pod()), ("faults", self.faults_p.to_pod()), ("plains", self.plains_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TProgram {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TProgram { exprs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "exprs")?)?, apps_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "apps")?)?, lifts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lifts")?)?, fns_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fns")?)?, impls_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "impls")?)?, methods_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "methods")?)?, groups_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "groups")?)?, binders_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "binders")?)?, locals_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "locals")?)?, uses_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "uses")?)?, calls_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "calls")?)?, globals_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "globals")?)?, gens_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "gens")?)?, insts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "insts")?)?, defs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "defs")?)?, unshrunk_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "unshrunk")?)?, faults_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "faults")?)?, plains_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "plains")?)? })
    }
}

/// `TyNote`:
///
/// ```prism
/// type TyNote = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TyNote {
    pub at_p: SrcAt,
    pub ty_p: crate::check::types::Ty,
}

impl crate::prelude::Show for TyNote {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TyNote", &[("at", &self.at_p), ("ty", &self.ty_p)]);
    }
}

impl crate::prelude::ToPod for TyNote {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TyNote", vec![("at", self.at_p.to_pod()), ("ty", self.ty_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TyNote {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TyNote { at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)? })
    }
}

/// ```prism
/// let emptyTyped
/// ```
pub fn empty_typed_p() -> TProgram {
    TProgram { exprs_p: crate::prelude::Array::new(), apps_p: crate::prelude::Array::new(), lifts_p: crate::prelude::Array::new(), fns_p: crate::prelude::Array::new(), impls_p: crate::prelude::Array::new(), methods_p: crate::prelude::Array::new(), groups_p: crate::prelude::Array::new(), binders_p: crate::prelude::Array::new(), locals_p: crate::prelude::Array::new(), uses_p: crate::prelude::Array::new(), calls_p: crate::prelude::Array::new(), globals_p: crate::prelude::Array::new(), gens_p: crate::prelude::Array::new(), insts_p: crate::prelude::Array::new(), defs_p: crate::prelude::Array::new(), unshrunk_p: crate::prelude::Array::new(), faults_p: crate::prelude::Array::new(), plains_p: crate::prelude::Array::new() }
}

/// ```prism
/// AtKey: fn SrcAt -> Text
/// ```
pub fn at_key_f(a_p0: &SrcAt) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{}:{}:{}", &a_p0.file_p, &a_p0.span_p.start_p, &a_p0.span_p.end_p))
}
