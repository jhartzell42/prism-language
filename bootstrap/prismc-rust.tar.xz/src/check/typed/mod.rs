//! The module `Check.Typed`, from `target/bootstrap/src/prismc/check/typed/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod print;

/// `AppNote`:
///
/// ```prism
/// type AppNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct AppNote {
    pub at: SrcAt,
    pub callee: Text,
    pub kind: Text,
    pub layer: Text,
    pub lifted: Array<Nat>,
    pub inner: Text,
    pub color: crate::check::types::Col,
}

impl Show for AppNote {
    fn show(&self, p: &mut Printer) {
        p.record("AppNote", &[("at", &self.at), ("callee", &self.callee), ("kind", &self.kind), ("layer", &self.layer), ("lifted", &self.lifted), ("inner", &self.inner), ("color", &self.color)]);
    }
}

impl ToPod for AppNote {
    fn to_pod(&self) -> Pod {
        Pod::record("AppNote", vec![("at", self.at.to_pod()), ("callee", self.callee.to_pod()), ("kind", self.kind.to_pod()), ("layer", self.layer.to_pod()), ("lifted", self.lifted.to_pod()), ("inner", self.inner.to_pod()), ("color", self.color.to_pod())])
    }
}

impl FromPod for AppNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(AppNote { at: FromPod::from_pod(field(p, "at")?)?, callee: FromPod::from_pod(field(p, "callee")?)?, kind: FromPod::from_pod(field(p, "kind")?)?, layer: FromPod::from_pod(field(p, "layer")?)?, lifted: FromPod::from_pod(field(p, "lifted")?)?, inner: FromPod::from_pod(field(p, "inner")?)?, color: FromPod::from_pod(field(p, "color")?)? })
    }
}

/// `BinderNote`:
///
/// ```prism
/// type BinderNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct BinderNote {
    pub at: SrcAt,
    pub name: Text,
    pub ty: crate::check::types::Ty,
}

impl Show for BinderNote {
    fn show(&self, p: &mut Printer) {
        p.record("BinderNote", &[("at", &self.at), ("name", &self.name), ("ty", &self.ty)]);
    }
}

impl ToPod for BinderNote {
    fn to_pod(&self) -> Pod {
        Pod::record("BinderNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("ty", self.ty.to_pod())])
    }
}

impl FromPod for BinderNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(BinderNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, ty: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// `DefNote`:
///
/// ```prism
/// type DefNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct DefNote {
    pub at: SrcAt,
    pub name: Text,
    pub scheme: crate::check::types::Scheme,
}

impl Show for DefNote {
    fn show(&self, p: &mut Printer) {
        p.record("DefNote", &[("at", &self.at), ("name", &self.name), ("scheme", &self.scheme)]);
    }
}

impl ToPod for DefNote {
    fn to_pod(&self) -> Pod {
        Pod::record("DefNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("scheme", self.scheme.to_pod())])
    }
}

impl FromPod for DefNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(DefNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, scheme: FromPod::from_pod(field(p, "scheme")?)? })
    }
}

/// `FnNote`:
///
/// ```prism
/// type FnNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FnNote {
    pub at: SrcAt,
    pub name: Text,
    pub declared: crate::check::types::Col,
    pub body: crate::check::types::Col,
}

impl Show for FnNote {
    fn show(&self, p: &mut Printer) {
        p.record("FnNote", &[("at", &self.at), ("name", &self.name), ("declared", &self.declared), ("body", &self.body)]);
    }
}

impl ToPod for FnNote {
    fn to_pod(&self) -> Pod {
        Pod::record("FnNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("declared", self.declared.to_pod()), ("body", self.body.to_pod())])
    }
}

impl FromPod for FnNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FnNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, declared: FromPod::from_pod(field(p, "declared")?)?, body: FromPod::from_pod(field(p, "body")?)? })
    }
}

/// `GenNote`:
///
/// ```prism
/// type GenNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct GenNote {
    pub at: SrcAt,
    pub name: Text,
    pub tys: Array<Text>,
    pub cols: Array<Text>,
}

impl Show for GenNote {
    fn show(&self, p: &mut Printer) {
        p.record("GenNote", &[("at", &self.at), ("name", &self.name), ("tys", &self.tys), ("cols", &self.cols)]);
    }
}

impl ToPod for GenNote {
    fn to_pod(&self) -> Pod {
        Pod::record("GenNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("tys", self.tys.to_pod()), ("cols", self.cols.to_pod())])
    }
}

impl FromPod for GenNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GenNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, tys: FromPod::from_pod(field(p, "tys")?)?, cols: FromPod::from_pod(field(p, "cols")?)? })
    }
}

/// `GroupNote`:
///
/// ```prism
/// type GroupNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct GroupNote {
    pub at: SrcAt,
    pub kind: Text,
    pub order: Array<Array<Nat>>,
}

impl Show for GroupNote {
    fn show(&self, p: &mut Printer) {
        p.record("GroupNote", &[("at", &self.at), ("kind", &self.kind), ("order", &self.order)]);
    }
}

impl ToPod for GroupNote {
    fn to_pod(&self) -> Pod {
        Pod::record("GroupNote", vec![("at", self.at.to_pod()), ("kind", self.kind.to_pod()), ("order", self.order.to_pod())])
    }
}

impl FromPod for GroupNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GroupNote { at: FromPod::from_pod(field(p, "at")?)?, kind: FromPod::from_pod(field(p, "kind")?)?, order: FromPod::from_pod(field(p, "order")?)? })
    }
}

/// `ImplNote`:
///
/// ```prism
/// type ImplNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ImplNote {
    pub at: SrcAt,
    pub cls: Text,
    pub ty: crate::check::types::Ty,
    pub how: Text,
}

impl Show for ImplNote {
    fn show(&self, p: &mut Printer) {
        p.record("ImplNote", &[("at", &self.at), ("cls", &self.cls), ("ty", &self.ty), ("how", &self.how)]);
    }
}

impl ToPod for ImplNote {
    fn to_pod(&self) -> Pod {
        Pod::record("ImplNote", vec![("at", self.at.to_pod()), ("cls", self.cls.to_pod()), ("ty", self.ty.to_pod()), ("how", self.how.to_pod())])
    }
}

impl FromPod for ImplNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ImplNote { at: FromPod::from_pod(field(p, "at")?)?, cls: FromPod::from_pod(field(p, "cls")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, how: FromPod::from_pod(field(p, "how")?)? })
    }
}

/// `InstNote`:
///
/// ```prism
/// type InstNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct InstNote {
    pub at: SrcAt,
    pub name: Text,
    pub tys: Array<(Text, crate::check::types::Ty)>,
    pub cols: Array<(Text, crate::check::types::Col)>,
}

impl Show for InstNote {
    fn show(&self, p: &mut Printer) {
        p.record("InstNote", &[("at", &self.at), ("name", &self.name), ("tys", &self.tys), ("cols", &self.cols)]);
    }
}

impl ToPod for InstNote {
    fn to_pod(&self) -> Pod {
        Pod::record("InstNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("tys", self.tys.to_pod()), ("cols", self.cols.to_pod())])
    }
}

impl FromPod for InstNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(InstNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, tys: FromPod::from_pod(field(p, "tys")?)?, cols: FromPod::from_pod(field(p, "cols")?)? })
    }
}

/// `LiftNote`:
///
/// ```prism
/// type LiftNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct LiftNote {
    pub at: SrcAt,
    pub sigil: Text,
    pub operands: Array<crate::syntax::Range>,
}

impl Show for LiftNote {
    fn show(&self, p: &mut Printer) {
        p.record("LiftNote", &[("at", &self.at), ("sigil", &self.sigil), ("operands", &self.operands)]);
    }
}

impl ToPod for LiftNote {
    fn to_pod(&self) -> Pod {
        Pod::record("LiftNote", vec![("at", self.at.to_pod()), ("sigil", self.sigil.to_pod()), ("operands", self.operands.to_pod())])
    }
}

impl FromPod for LiftNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(LiftNote { at: FromPod::from_pod(field(p, "at")?)?, sigil: FromPod::from_pod(field(p, "sigil")?)?, operands: FromPod::from_pod(field(p, "operands")?)? })
    }
}

/// `LocalNote`:
///
/// ```prism
/// type LocalNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct LocalNote {
    pub at: SrcAt,
    pub id: Nat,
}

impl Show for LocalNote {
    fn show(&self, p: &mut Printer) {
        p.record("LocalNote", &[("at", &self.at), ("id", &self.id)]);
    }
}

impl ToPod for LocalNote {
    fn to_pod(&self) -> Pod {
        Pod::record("LocalNote", vec![("at", self.at.to_pod()), ("id", self.id.to_pod())])
    }
}

impl FromPod for LocalNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(LocalNote { at: FromPod::from_pod(field(p, "at")?)?, id: FromPod::from_pod(field(p, "id")?)? })
    }
}

/// `MethodNote`:
///
/// ```prism
/// type MethodNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct MethodNote {
    pub at: SrcAt,
    pub method: Text,
    pub cls: Text,
}

impl Show for MethodNote {
    fn show(&self, p: &mut Printer) {
        p.record("MethodNote", &[("at", &self.at), ("method", &self.method), ("cls", &self.cls)]);
    }
}

impl ToPod for MethodNote {
    fn to_pod(&self) -> Pod {
        Pod::record("MethodNote", vec![("at", self.at.to_pod()), ("method", self.method.to_pod()), ("cls", self.cls.to_pod())])
    }
}

impl FromPod for MethodNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(MethodNote { at: FromPod::from_pod(field(p, "at")?)?, method: FromPod::from_pod(field(p, "method")?)?, cls: FromPod::from_pod(field(p, "cls")?)? })
    }
}

/// `SrcAt`:
///
/// ```prism
/// type SrcAt = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct SrcAt {
    pub file: Nat,
    pub span: crate::syntax::Range,
}

impl Show for SrcAt {
    fn show(&self, p: &mut Printer) {
        p.record("SrcAt", &[("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for SrcAt {
    fn to_pod(&self) -> Pod {
        Pod::record("SrcAt", vec![("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for SrcAt {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(SrcAt { file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TProgram`:
///
/// ```prism
/// type TProgram = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TProgram {
    pub exprs: Array<TyNote>,
    pub apps: Array<AppNote>,
    pub lifts: Array<LiftNote>,
    pub fns: Array<FnNote>,
    pub impls: Array<ImplNote>,
    pub methods: Array<MethodNote>,
    pub groups: Array<GroupNote>,
    pub binders: Array<BinderNote>,
    pub locals: Array<LocalNote>,
    pub uses: Array<LocalNote>,
    pub gens: Array<GenNote>,
    pub insts: Array<InstNote>,
    pub defs: Array<DefNote>,
    pub unshrunk: Array<SrcAt>,
}

impl Show for TProgram {
    fn show(&self, p: &mut Printer) {
        p.record("TProgram", &[("exprs", &self.exprs), ("apps", &self.apps), ("lifts", &self.lifts), ("fns", &self.fns), ("impls", &self.impls), ("methods", &self.methods), ("groups", &self.groups), ("binders", &self.binders), ("locals", &self.locals), ("uses", &self.uses), ("gens", &self.gens), ("insts", &self.insts), ("defs", &self.defs), ("unshrunk", &self.unshrunk)]);
    }
}

impl ToPod for TProgram {
    fn to_pod(&self) -> Pod {
        Pod::record("TProgram", vec![("exprs", self.exprs.to_pod()), ("apps", self.apps.to_pod()), ("lifts", self.lifts.to_pod()), ("fns", self.fns.to_pod()), ("impls", self.impls.to_pod()), ("methods", self.methods.to_pod()), ("groups", self.groups.to_pod()), ("binders", self.binders.to_pod()), ("locals", self.locals.to_pod()), ("uses", self.uses.to_pod()), ("gens", self.gens.to_pod()), ("insts", self.insts.to_pod()), ("defs", self.defs.to_pod()), ("unshrunk", self.unshrunk.to_pod())])
    }
}

impl FromPod for TProgram {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TProgram { exprs: FromPod::from_pod(field(p, "exprs")?)?, apps: FromPod::from_pod(field(p, "apps")?)?, lifts: FromPod::from_pod(field(p, "lifts")?)?, fns: FromPod::from_pod(field(p, "fns")?)?, impls: FromPod::from_pod(field(p, "impls")?)?, methods: FromPod::from_pod(field(p, "methods")?)?, groups: FromPod::from_pod(field(p, "groups")?)?, binders: FromPod::from_pod(field(p, "binders")?)?, locals: FromPod::from_pod(field(p, "locals")?)?, uses: FromPod::from_pod(field(p, "uses")?)?, gens: FromPod::from_pod(field(p, "gens")?)?, insts: FromPod::from_pod(field(p, "insts")?)?, defs: FromPod::from_pod(field(p, "defs")?)?, unshrunk: FromPod::from_pod(field(p, "unshrunk")?)? })
    }
}

/// `TyNote`:
///
/// ```prism
/// type TyNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyNote {
    pub at: SrcAt,
    pub ty: crate::check::types::Ty,
}

impl Show for TyNote {
    fn show(&self, p: &mut Printer) {
        p.record("TyNote", &[("at", &self.at), ("ty", &self.ty)]);
    }
}

impl ToPod for TyNote {
    fn to_pod(&self) -> Pod {
        Pod::record("TyNote", vec![("at", self.at.to_pod()), ("ty", self.ty.to_pod())])
    }
}

impl FromPod for TyNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyNote { at: FromPod::from_pod(field(p, "at")?)?, ty: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// ```prism
/// let emptyTyped
/// ```
pub fn empty_typed() -> TProgram {
    TProgram { exprs: Array::new(), apps: Array::new(), lifts: Array::new(), fns: Array::new(), impls: Array::new(), methods: Array::new(), groups: Array::new(), binders: Array::new(), locals: Array::new(), uses: Array::new(), gens: Array::new(), insts: Array::new(), defs: Array::new(), unshrunk: Array::new() }
}

/// ```prism
/// AtKey: fn SrcAt -> Text
/// ```
pub fn at_key(a_p0: &SrcAt) -> Text {
    Text::from(format!("{}:{}:{}", &a_p0.file, &a_p0.span.start, &a_p0.span.end))
}
