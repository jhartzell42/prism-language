//! The module `Check.Typed`, from `target/bootstrap/src/prismc/check/typed/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (docs/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `AppNote`:
///
/// ```prism
/// type AppNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct AppNote {
    pub at: SrcAt,
    pub callee: Text,
    pub kind: Text,
    pub layer: Text,
    pub lifted: Array<Nat>,
    pub inner: Text,
    pub color: crate::check::types::Col,
}

impl Show for AppNote {
    fn show(&self, p: &mut Printer) {
        p.record("AppNote", &[("at", &self.at), ("callee", &self.callee), ("kind", &self.kind), ("layer", &self.layer), ("lifted", &self.lifted), ("inner", &self.inner), ("color", &self.color)]);
    }
}

impl ToPod for AppNote {
    fn to_pod(&self) -> Pod {
        Pod::record("AppNote", vec![("at", self.at.to_pod()), ("callee", self.callee.to_pod()), ("kind", self.kind.to_pod()), ("layer", self.layer.to_pod()), ("lifted", self.lifted.to_pod()), ("inner", self.inner.to_pod()), ("color", self.color.to_pod())])
    }
}

impl FromPod for AppNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(AppNote { at: FromPod::from_pod(field(p, "at")?)?, callee: FromPod::from_pod(field(p, "callee")?)?, kind: FromPod::from_pod(field(p, "kind")?)?, layer: FromPod::from_pod(field(p, "layer")?)?, lifted: FromPod::from_pod(field(p, "lifted")?)?, inner: FromPod::from_pod(field(p, "inner")?)?, color: FromPod::from_pod(field(p, "color")?)? })
    }
}

/// `BinderNote`:
///
/// ```prism
/// type BinderNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct BinderNote {
    pub at: SrcAt,
    pub name: Text,
    pub ty: crate::check::types::Ty,
}

impl Show for BinderNote {
    fn show(&self, p: &mut Printer) {
        p.record("BinderNote", &[("at", &self.at), ("name", &self.name), ("ty", &self.ty)]);
    }
}

impl ToPod for BinderNote {
    fn to_pod(&self) -> Pod {
        Pod::record("BinderNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("ty", self.ty.to_pod())])
    }
}

impl FromPod for BinderNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(BinderNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, ty: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// `DefNote`:
///
/// ```prism
/// type DefNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct DefNote {
    pub at: SrcAt,
    pub name: Text,
    pub scheme: crate::check::types::Scheme,
}

impl Show for DefNote {
    fn show(&self, p: &mut Printer) {
        p.record("DefNote", &[("at", &self.at), ("name", &self.name), ("scheme", &self.scheme)]);
    }
}

impl ToPod for DefNote {
    fn to_pod(&self) -> Pod {
        Pod::record("DefNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("scheme", self.scheme.to_pod())])
    }
}

impl FromPod for DefNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(DefNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, scheme: FromPod::from_pod(field(p, "scheme")?)? })
    }
}

/// `FnNote`:
///
/// ```prism
/// type FnNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FnNote {
    pub at: SrcAt,
    pub name: Text,
    pub declared: crate::check::types::Col,
    pub body: crate::check::types::Col,
}

impl Show for FnNote {
    fn show(&self, p: &mut Printer) {
        p.record("FnNote", &[("at", &self.at), ("name", &self.name), ("declared", &self.declared), ("body", &self.body)]);
    }
}

impl ToPod for FnNote {
    fn to_pod(&self) -> Pod {
        Pod::record("FnNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("declared", self.declared.to_pod()), ("body", self.body.to_pod())])
    }
}

impl FromPod for FnNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FnNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, declared: FromPod::from_pod(field(p, "declared")?)?, body: FromPod::from_pod(field(p, "body")?)? })
    }
}

/// `GenNote`:
///
/// ```prism
/// type GenNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct GenNote {
    pub at: SrcAt,
    pub name: Text,
    pub tys: Array<Text>,
    pub cols: Array<Text>,
}

impl Show for GenNote {
    fn show(&self, p: &mut Printer) {
        p.record("GenNote", &[("at", &self.at), ("name", &self.name), ("tys", &self.tys), ("cols", &self.cols)]);
    }
}

impl ToPod for GenNote {
    fn to_pod(&self) -> Pod {
        Pod::record("GenNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("tys", self.tys.to_pod()), ("cols", self.cols.to_pod())])
    }
}

impl FromPod for GenNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GenNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, tys: FromPod::from_pod(field(p, "tys")?)?, cols: FromPod::from_pod(field(p, "cols")?)? })
    }
}

/// `GroupNote`:
///
/// ```prism
/// type GroupNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct GroupNote {
    pub at: SrcAt,
    pub kind: Text,
    pub order: Array<Array<Nat>>,
}

impl Show for GroupNote {
    fn show(&self, p: &mut Printer) {
        p.record("GroupNote", &[("at", &self.at), ("kind", &self.kind), ("order", &self.order)]);
    }
}

impl ToPod for GroupNote {
    fn to_pod(&self) -> Pod {
        Pod::record("GroupNote", vec![("at", self.at.to_pod()), ("kind", self.kind.to_pod()), ("order", self.order.to_pod())])
    }
}

impl FromPod for GroupNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GroupNote { at: FromPod::from_pod(field(p, "at")?)?, kind: FromPod::from_pod(field(p, "kind")?)?, order: FromPod::from_pod(field(p, "order")?)? })
    }
}

/// `ImplNote`:
///
/// ```prism
/// type ImplNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ImplNote {
    pub at: SrcAt,
    pub cls: Text,
    pub ty: crate::check::types::Ty,
    pub how: Text,
}

impl Show for ImplNote {
    fn show(&self, p: &mut Printer) {
        p.record("ImplNote", &[("at", &self.at), ("cls", &self.cls), ("ty", &self.ty), ("how", &self.how)]);
    }
}

impl ToPod for ImplNote {
    fn to_pod(&self) -> Pod {
        Pod::record("ImplNote", vec![("at", self.at.to_pod()), ("cls", self.cls.to_pod()), ("ty", self.ty.to_pod()), ("how", self.how.to_pod())])
    }
}

impl FromPod for ImplNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ImplNote { at: FromPod::from_pod(field(p, "at")?)?, cls: FromPod::from_pod(field(p, "cls")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, how: FromPod::from_pod(field(p, "how")?)? })
    }
}

/// `InstNote`:
///
/// ```prism
/// type InstNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct InstNote {
    pub at: SrcAt,
    pub name: Text,
    pub tys: Array<(Text, crate::check::types::Ty)>,
    pub cols: Array<(Text, crate::check::types::Col)>,
}

impl Show for InstNote {
    fn show(&self, p: &mut Printer) {
        p.record("InstNote", &[("at", &self.at), ("name", &self.name), ("tys", &self.tys), ("cols", &self.cols)]);
    }
}

impl ToPod for InstNote {
    fn to_pod(&self) -> Pod {
        Pod::record("InstNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("tys", self.tys.to_pod()), ("cols", self.cols.to_pod())])
    }
}

impl FromPod for InstNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(InstNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, tys: FromPod::from_pod(field(p, "tys")?)?, cols: FromPod::from_pod(field(p, "cols")?)? })
    }
}

/// `MethodNote`:
///
/// ```prism
/// type MethodNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct MethodNote {
    pub at: SrcAt,
    pub method: Text,
    pub cls: Text,
}

impl Show for MethodNote {
    fn show(&self, p: &mut Printer) {
        p.record("MethodNote", &[("at", &self.at), ("method", &self.method), ("cls", &self.cls)]);
    }
}

impl ToPod for MethodNote {
    fn to_pod(&self) -> Pod {
        Pod::record("MethodNote", vec![("at", self.at.to_pod()), ("method", self.method.to_pod()), ("cls", self.cls.to_pod())])
    }
}

impl FromPod for MethodNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(MethodNote { at: FromPod::from_pod(field(p, "at")?)?, method: FromPod::from_pod(field(p, "method")?)?, cls: FromPod::from_pod(field(p, "cls")?)? })
    }
}

/// `SrcAt`:
///
/// ```prism
/// type SrcAt = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct SrcAt {
    pub file: Nat,
    pub span: crate::syntax::Range,
}

impl Show for SrcAt {
    fn show(&self, p: &mut Printer) {
        p.record("SrcAt", &[("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for SrcAt {
    fn to_pod(&self) -> Pod {
        Pod::record("SrcAt", vec![("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for SrcAt {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(SrcAt { file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TProgram`:
///
/// ```prism
/// type TProgram = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TProgram {
    pub exprs: Array<TyNote>,
    pub apps: Array<AppNote>,
    pub fns: Array<FnNote>,
    pub impls: Array<ImplNote>,
    pub methods: Array<MethodNote>,
    pub groups: Array<GroupNote>,
    pub binders: Array<BinderNote>,
    pub gens: Array<GenNote>,
    pub insts: Array<InstNote>,
    pub defs: Array<DefNote>,
    pub unshrunk: Array<SrcAt>,
}

impl Show for TProgram {
    fn show(&self, p: &mut Printer) {
        p.record("TProgram", &[("exprs", &self.exprs), ("apps", &self.apps), ("fns", &self.fns), ("impls", &self.impls), ("methods", &self.methods), ("groups", &self.groups), ("binders", &self.binders), ("gens", &self.gens), ("insts", &self.insts), ("defs", &self.defs), ("unshrunk", &self.unshrunk)]);
    }
}

impl ToPod for TProgram {
    fn to_pod(&self) -> Pod {
        Pod::record("TProgram", vec![("exprs", self.exprs.to_pod()), ("apps", self.apps.to_pod()), ("fns", self.fns.to_pod()), ("impls", self.impls.to_pod()), ("methods", self.methods.to_pod()), ("groups", self.groups.to_pod()), ("binders", self.binders.to_pod()), ("gens", self.gens.to_pod()), ("insts", self.insts.to_pod()), ("defs", self.defs.to_pod()), ("unshrunk", self.unshrunk.to_pod())])
    }
}

impl FromPod for TProgram {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TProgram { exprs: FromPod::from_pod(field(p, "exprs")?)?, apps: FromPod::from_pod(field(p, "apps")?)?, fns: FromPod::from_pod(field(p, "fns")?)?, impls: FromPod::from_pod(field(p, "impls")?)?, methods: FromPod::from_pod(field(p, "methods")?)?, groups: FromPod::from_pod(field(p, "groups")?)?, binders: FromPod::from_pod(field(p, "binders")?)?, gens: FromPod::from_pod(field(p, "gens")?)?, insts: FromPod::from_pod(field(p, "insts")?)?, defs: FromPod::from_pod(field(p, "defs")?)?, unshrunk: FromPod::from_pod(field(p, "unshrunk")?)? })
    }
}

/// `TyNote`:
///
/// ```prism
/// type TyNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyNote {
    pub at: SrcAt,
    pub ty: crate::check::types::Ty,
}

impl Show for TyNote {
    fn show(&self, p: &mut Printer) {
        p.record("TyNote", &[("at", &self.at), ("ty", &self.ty)]);
    }
}

impl ToPod for TyNote {
    fn to_pod(&self) -> Pod {
        Pod::record("TyNote", vec![("at", self.at.to_pod()), ("ty", self.ty.to_pod())])
    }
}

impl FromPod for TyNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyNote { at: FromPod::from_pod(field(p, "at")?)?, ty: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// ```prism
/// let emptyTyped
/// ```
pub fn empty_typed() -> TProgram {
    TProgram { exprs: Array::new(), apps: Array::new(), fns: Array::new(), impls: Array::new(), methods: Array::new(), groups: Array::new(), binders: Array::new(), gens: Array::new(), insts: Array::new(), defs: Array::new(), unshrunk: Array::new() }
}

/// ```prism
/// AtKey: fn SrcAt -> Text
/// ```
pub fn at_key(a: &SrcAt) -> Text {
    Text::from(format!("{}:{}:{}", &a.file, &a.span.start, &a.span.end))
}

/// ```prism
/// TySexp: unbounded fn Ty -> Text
/// ```
pub fn ty_sexp(t: &crate::check::types::Ty) -> Text {
    match t {
        crate::check::types::Ty::TyFlex(n) => Text::from(format!("(var t{})", n)),
        crate::check::types::Ty::TyRigid(n) => Text::from(format!("(rigid {})", n)),
        crate::check::types::Ty::TyQ(n) => Text::from(format!("(q {})", n)),
        crate::check::types::Ty::TyCon(n, m5457_3_1) if (m5457_3_1.len() == 0) => n.clone(),
        crate::check::types::Ty::TyCon(n, args) => Text::from(format!("({}{})", n, &concat(&run_to_end(each_job(args.clone(), Rc::new(move |p0: crate::check::types::Ty| entered(once_job(move || {
            let a = p0;
            call_then(start_ty_sexp(a.clone()), move |ty_sexp_5616: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_5616))))
        }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>))))),
        crate::check::types::Ty::TyFn(c, ps, res) => Text::from(format!("(fn {} ({}) {})", &col_sexp(c), &crate::syntax::lexer::join(&run_to_end(each_job(ps.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_ty_sexp(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" ")), &ty_sexp(&**res))),
        crate::check::types::Ty::TyTuple(ts) => Text::from(format!("(tuple{})", &concat(&run_to_end(each_job(ts.clone(), Rc::new(move |p0: crate::check::types::Ty| entered(once_job(move || {
            let a = p0;
            call_then(start_ty_sexp(a.clone()), move |ty_sexp_5765: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_5765))))
        }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>))))),
        crate::check::types::Ty::TyArray(e) => Text::from(format!("(array {})", &ty_sexp(&**e))),
        crate::check::types::Ty::TyMap(k, v_) => Text::from(format!("(map {} {})", &ty_sexp(&**k), &ty_sexp(&**v_))),
        crate::check::types::Ty::TySig(s, i) => Text::from(format!("({} {})", s, &ty_sexp(&**i))),
        crate::check::types::Ty::TyAt(i, rw) => Text::from(format!("(@ {} {})", &ty_sexp(&**i), &row_sexp(rw))),
        crate::check::types::Ty::TyElem(rw, o) => Text::from(format!("(element {} {})", &row_sexp(rw), &ty_sexp(&**o))),
        crate::check::types::Ty::TyElemAny(rw) => Text::from(format!("(elem {})", &row_sexp(rw))),
        crate::check::types::Ty::TyAssoc(n, a) => Text::from(format!("(assoc {} {})", n, &ty_sexp(&**a))),
        crate::check::types::Ty::TyAny(trs) => Text::from(format!("(any{})", &concat(&each(trs, &(|x: &Text| Text::from(format!(" ^{}", x))))))),
        crate::check::types::Ty::TyErr => Text::lit("unknown"),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TySexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TySexp: unbounded fn Ty -> Text
/// ```
pub struct TySexp {
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for TySexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(Text::from(format!("(var t{})", n))),
            crate::check::types::Ty::TyRigid(n) => prism_rtl::Turn::Finished(Text::from(format!("(rigid {})", n))),
            crate::check::types::Ty::TyQ(n) => prism_rtl::Turn::Finished(Text::from(format!("(q {})", n))),
            crate::check::types::Ty::TyCon(n, m5457_3_1) if (m5457_3_1.len() == 0) => prism_rtl::Turn::Finished(n.clone()),
            crate::check::types::Ty::TyCon(n, args) => {
                let args = args.clone();
                let n = n.clone();
                call_value(each_job(args.clone(), Rc::new(move |p0: crate::check::types::Ty| entered(once_job(move || {
                    let a = p0;
                    call_then(start_ty_sexp(a.clone()), move |ty_sexp_5616: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_5616))))
                }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5597: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({}{})", &n, &concat(&each_5597)))))
            },
            crate::check::types::Ty::TyFn(c, ps, res) => {
                let c = c.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(each_job(ps.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_ty_sexp(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5677: Array<Text>| call_then(start_ty_sexp(res.clone()), move |ty_sexp_5702: Text| prism_rtl::Turn::Finished(Text::from(format!("(fn {} ({}) {})", &col_sexp(&c), &crate::syntax::lexer::join(&each_5677, &Text::lit(" ")), &ty_sexp_5702)))))
            },
            crate::check::types::Ty::TyTuple(ts) => {
                let ts = ts.clone();
                call_value(each_job(ts.clone(), Rc::new(move |p0: crate::check::types::Ty| entered(once_job(move || {
                    let a = p0;
                    call_then(start_ty_sexp(a.clone()), move |ty_sexp_5765: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_5765))))
                }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5748: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("(tuple{})", &concat(&each_5748)))))
            },
            crate::check::types::Ty::TyArray(e) => {
                let e = (**e).clone();
                call_then(start_ty_sexp(e.clone()), move |ty_sexp_5804: Text| prism_rtl::Turn::Finished(Text::from(format!("(array {})", &ty_sexp_5804))))
            },
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_ty_sexp(k.clone()), move |ty_sexp_5839: Text| call_then(start_ty_sexp(v_.clone()), move |ty_sexp_5850: Text| prism_rtl::Turn::Finished(Text::from(format!("(map {} {})", &ty_sexp_5839, &ty_sexp_5850)))))
            },
            crate::check::types::Ty::TySig(s, i) => {
                let i = (**i).clone();
                let s = s.clone();
                call_then(start_ty_sexp(i.clone()), move |ty_sexp_5885: Text| prism_rtl::Turn::Finished(Text::from(format!("({} {})", &s, &ty_sexp_5885))))
            },
            crate::check::types::Ty::TyAt(i, rw) => {
                let i = (**i).clone();
                let rw = rw.clone();
                call_then(start_ty_sexp(i.clone()), move |ty_sexp_5918: Text| prism_rtl::Turn::Finished(Text::from(format!("(@ {} {})", &ty_sexp_5918, &row_sexp(&rw)))))
            },
            crate::check::types::Ty::TyElem(rw, o) => {
                let o = (**o).clone();
                let rw = rw.clone();
                call_then(start_ty_sexp(o.clone()), move |ty_sexp_5985: Text| prism_rtl::Turn::Finished(Text::from(format!("(element {} {})", &row_sexp(&rw), &ty_sexp_5985))))
            },
            crate::check::types::Ty::TyElemAny(rw) => prism_rtl::Turn::Finished(Text::from(format!("(elem {})", &row_sexp(rw)))),
            crate::check::types::Ty::TyAssoc(n, a) => {
                let a = (**a).clone();
                let n = n.clone();
                call_then(start_ty_sexp(a.clone()), move |ty_sexp_6068: Text| prism_rtl::Turn::Finished(Text::from(format!("(assoc {} {})", &n, &ty_sexp_6068))))
            },
            crate::check::types::Ty::TyAny(trs) => prism_rtl::Turn::Finished(Text::from(format!("(any{})", &concat(&each(trs, &(|x: &Text| Text::from(format!(" ^{}", x)))))))),
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished(Text::lit("unknown")),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TySexp, x`: what the function value is when passed to `@Run`.
pub fn start_ty_sexp(t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TySexp { t })
}

/// ```prism
/// ColSexp: fn Col -> Text
/// ```
pub fn col_sexp(col0: &crate::check::types::Col) -> Text {
    match col0 {
        crate::check::types::Col::CBound => Text::lit("bounded"),
        crate::check::types::Col::CUnbound => Text::lit("unbounded"),
        crate::check::types::Col::CRigid(n) => Text::from(format!("(color {})", n)),
        crate::check::types::Col::CQ(n) => Text::from(format!("(color {})", n)),
        crate::check::types::Col::CFlex(n) => Text::from(format!("(color c{})", n)),
    }
}

/// ```prism
/// RowSexp: fn Rw -> Text
/// ```
pub fn row_sexp(rw: &crate::check::types::Rw) -> Text {
    let tail = match &rw.tail {
        crate::check::types::Tail::TlClosed => Text::lit(""),
        crate::check::types::Tail::TlFlex(n) => Text::from(format!(" (tail r{})", n)),
        crate::check::types::Tail::TlRigid(n) => Text::from(format!(" (tail {})", n)),
        crate::check::types::Tail::TlQ(n) => Text::from(format!(" (tail {})", n)),
    };
    let minus = if &len(&rw.minus) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (minus{})", &concat(&each(&rw.minus, &(|m: &Text| Text::from(format!(" {}", m)))))))
    };
    Text::from(format!("(row{}{}{})", &concat(&each(&rw.fams, &(|f: &Text| Text::from(format!(" {}.*", f))))), &tail, &minus))
}

/// ```prism
/// SchemeSexp: unbounded fn Scheme -> Text
/// ```
pub fn scheme_sexp(sc: &crate::check::types::Scheme) -> Text {
    let qs = if &len(&sc.qs) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (forall{})", &concat(&each(&sc.qs, &(|q: &Text| Text::from(format!(" {}", q)))))))
    };
    let rqs = if &len(&sc.rqs) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (rows{})", &concat(&each(&sc.rqs, &(|q: &Text| Text::from(format!(" {}", q)))))))
    };
    let cqs = if &len(&sc.cqs) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (colors{})", &concat(&each(&sc.cqs, &(|q: &Text| Text::from(format!(" {}", q)))))))
    };
    let bs = if &len(&sc.bounds) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (where{})", &concat(&each(&sc.bounds, &(|(v_, c): &(Text, Text)| Text::from(format!(" {}:^{}", v_, c)))))))
    };
    Text::from(format!("(scheme{}{}{}{} {})", &qs, &rqs, &cqs, &bs, &ty_sexp(&sc.ty)))
}

/// The step machine of `SchemeSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SchemeSexp: unbounded fn Scheme -> Text
/// ```
pub struct SchemeSexp {
    pub sc: crate::check::types::Scheme,
}

impl prism_rtl::Job<Text> for SchemeSexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let sc = &self.sc;
        let qs = if &len(&sc.qs) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (forall{})", &concat(&each(&sc.qs, &(|q: &Text| Text::from(format!(" {}", q)))))))
        };
        let rqs = if &len(&sc.rqs) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (rows{})", &concat(&each(&sc.rqs, &(|q: &Text| Text::from(format!(" {}", q)))))))
        };
        let cqs = if &len(&sc.cqs) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (colors{})", &concat(&each(&sc.cqs, &(|q: &Text| Text::from(format!(" {}", q)))))))
        };
        let bs = if &len(&sc.bounds) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (where{})", &concat(&each(&sc.bounds, &(|(v_, c): &(Text, Text)| Text::from(format!(" {}:^{}", v_, c)))))))
        };
        let sc = sc.clone();
        call_then(start_ty_sexp(sc.ty.clone()), move |ty_sexp_7171: Text| prism_rtl::Turn::Finished(Text::from(format!("(scheme{}{}{}{} {})", &qs, &rqs, &cqs, &bs, &ty_sexp_7171))))
    }
}

/// `Start SchemeSexp, x`: what the function value is when passed to `@Run`.
pub fn start_scheme_sexp(sc: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(SchemeSexp { sc })
}

/// ```prism
/// AtText: fn [Src], SrcAt -> Text
/// ```
pub fn at_text(srcs: &Array<crate::check::errors::Src>, a: &SrcAt) -> Text {
    match index(srcs, &a.file) {
        None => Text::from(format!("?:{}", &a.span.start)),
        Some(src) => Text::from(format!("{}:{}-{}", &crate::check::errors::seg_at(&src, &a.span.start).path_, &pos_text(&src, &a.span.start), &pos_text(&src, &a.span.end))),
    }
}

/// ```prism
/// PosText: fn Src, Nat -> Text
/// ```
pub fn pos_text(src: &crate::check::errors::Src, offset: &Nat) -> Text {
    let line = crate::check::errors::cline_of(&src.starts, offset);
    let col = crate::syntax::lexer::column_of(&src.text, &or(&index(&src.starts, &line), &Nat::from(0u32)), offset);
    Text::from(format!("{}:{}", &(&or(&(&line).checked_sub(&crate::check::errors::seg_at(src, offset).line), &Nat::from(0u32)) + &Nat::from(1u32)), &(&col + &Nat::from(1u32))))
}

/// ```prism
/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
/// ```
pub fn typed_sexp(srcs: &Array<crate::check::errors::Src>, trees: &Array<crate::syntax::Module>, shown_: &Nat, tp: &TProgram) -> Text {
    let tys = fold(&tp.exprs, &Map::new(), &(|m: &Map<Text, crate::check::types::Ty>, n: &TyNote| insert(m, &at_key(&n.at), &n.ty)));
    let files = filter(&crate::check::errors::range0(&len(trees)), &(|i: &Nat| i < shown_));
    let defs = concat(&run_to_end(each_job(filter(&tp.defs, &(|d: &DefNote| &d.at.file < shown_)), {
        let srcs = srcs.clone();
        Rc::new(move |p0: DefNote| {
            let srcs = srcs.clone();
            entered(once_job(move || {
                let d = p0;
                call_then(start_scheme_sexp(d.scheme.clone()), move |scheme_sexp_8257: Text| prism_rtl::Turn::Finished(Text::from(format!("  (def {} {} {})\n", &d.name, &at_text(&srcs, &d.at), &scheme_sexp_8257))))
            }))
        }) as Rc<dyn Fn(DefNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let exprs = concat(&run_to_end(each_job(files.clone(), {
        let srcs = srcs.clone();
        let tys = tys.clone();
        let trees = trees.clone();
        Rc::new(move |p0: Nat| {
            let srcs = srcs.clone();
            let tys = tys.clone();
            let trees = trees.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ExprsOfFile { srcs: srcs.clone(), tys: tys.clone(), file: i.clone(), m: or(&index(&trees, &i), &empty_mod()) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let mine_fn = {
        let shown_ = shown_.clone();
        Rc::new(move |a: &SrcAt| shown(a, &shown_))
    };
    let apps = concat(&each(&filter(&tp.apps, &(|x: &AppNote| (&mine_fn)(&x.at))), &(|x: &AppNote| Text::from(format!("  (app {} {} {} {} (lifted{}) {} {})\n", &at_text(srcs, &x.at), &quote(&x.callee), &x.kind, &layer_word(&x.layer), &concat(&each(&x.lifted, &(|i: &Nat| Text::from(format!(" {}", i))))), &layer_word(&x.inner), &col_sexp(&x.color))))));
    let fns = concat(&each(&filter(&tp.fns, &(|x: &FnNote| (&mine_fn)(&x.at))), &(|x: &FnNote| Text::from(format!("  (fn {} {} {} {})\n", &quote(&x.name), &at_text(srcs, &x.at), &col_sexp(&x.declared), &col_sexp(&x.body))))));
    let methods = concat(&each(&filter(&tp.methods, &(|x: &MethodNote| (&mine_fn)(&x.at))), &(|x: &MethodNote| Text::from(format!("  (method {} {} ^{})\n", &at_text(srcs, &x.at), &x.method, &x.cls)))));
    let impls = concat(&run_to_end(each_job(filter(&tp.impls, &(|x: &ImplNote| (&mine_fn)(&x.at))), {
        let srcs = srcs.clone();
        Rc::new(move |p0: ImplNote| {
            let srcs = srcs.clone();
            entered(once_job(move || {
                let x = p0;
                call_then(start_ty_sexp(x.ty.clone()), move |ty_sexp_9027: Text| prism_rtl::Turn::Finished(Text::from(format!("  (impl {} ^{} {} {})\n", &at_text(&srcs, &x.at), &x.cls, &ty_sexp_9027, &x.how))))
            }))
        }) as Rc<dyn Fn(ImplNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let groups = concat(&each(&filter(&tp.groups, &(|x: &GroupNote| (&mine_fn)(&x.at))), &(|x: &GroupNote| Text::from(format!("  (group {} {}{})\n", &x.kind, &at_text(srcs, &x.at), &concat(&each(&x.order, &(|c: &Array<Nat>| Text::from(format!(" ({})", &crate::syntax::lexer::join(&each(c, &(|i: &Nat| Text::from(format!("{}", i)))), &Text::lit(" "))))))))))));
    let binders = concat(&run_to_end(each_job(filter(&tp.binders, &(|x: &BinderNote| (&mine_fn)(&x.at))), {
        let srcs = srcs.clone();
        Rc::new(move |p0: BinderNote| {
            let srcs = srcs.clone();
            entered(once_job(move || {
                let x = p0;
                call_then(start_ty_sexp(x.ty.clone()), move |ty_sexp_9355: Text| prism_rtl::Turn::Finished(Text::from(format!("  (binder {} {} {})\n", &quote(&x.name), &at_text(&srcs, &x.at), &ty_sexp_9355))))
            }))
        }) as Rc<dyn Fn(BinderNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let gens = concat(&each(&filter(&tp.gens, &(|x: &GenNote| (&mine_fn)(&x.at))), &(|x: &GenNote| Text::from(format!("  (gen {} {}{}{})\n", &quote(&x.name), &at_text(srcs, &x.at), &concat(&each(&x.tys, &(|q: &Text| Text::from(format!(" {}", q))))), &concat(&each(&x.cols, &(|q: &Text| Text::from(format!(" {}", q))))))))));
    let insts = concat(&run_to_end(each_job(filter(&tp.insts, &(|x: &InstNote| (&mine_fn)(&x.at))), {
        let srcs = srcs.clone();
        Rc::new(move |p0: InstNote| {
            let srcs = srcs.clone();
            entered(once_job(move || {
                let x = p0;
                call_value(each_job(x.tys.clone(), Rc::new(move |p0: (Text, crate::check::types::Ty)| entered(once_job(move || {
                    let (q, t) = p0;
                    call_then(start_ty_sexp(t.clone()), move |ty_sexp_9710: Text| prism_rtl::Turn::Finished(Text::from(format!(" ({} {})", &q, &ty_sexp_9710))))
                }))) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_9678: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("  (inst {} {}{}{})\n", &quote(&x.name), &at_text(&srcs, &x.at), &concat(&each_9678), &concat(&each(&x.cols, &(|(q, c): &(Text, crate::check::types::Col)| Text::from(format!(" ({} {})", q, &col_sexp(c))))))))))
            }))
        }) as Rc<dyn Fn(InstNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    Text::from(format!("(typed\n (defs\n{} )\n (exprs\n{} )\n (apps\n{} )\n (fns\n{} )\n (methods\n{} )\n (impls\n{} )\n (groups\n{} )\n (binders\n{} )\n (gens\n{} )\n (insts\n{} ))\n", &defs, &exprs, &apps, &fns, &methods, &impls, &groups, &binders, &gens, &insts))
}

/// The step machine of `TypedSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
/// ```
pub struct TypedSexp {
    pub srcs: Array<crate::check::errors::Src>,
    pub trees: Array<crate::syntax::Module>,
    pub shown_: Nat,
    pub tp: TProgram,
}

impl prism_rtl::Job<Text> for TypedSexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs = &self.srcs;
        let trees = &self.trees;
        let shown_ = &self.shown_;
        let tp = &self.tp;
        let tys = fold(&tp.exprs, &Map::new(), &(|m: &Map<Text, crate::check::types::Ty>, n: &TyNote| insert(m, &at_key(&n.at), &n.ty)));
        let files = filter(&crate::check::errors::range0(&len(trees)), &(|i: &Nat| i < shown_));
        let shown_ = shown_.clone();
        let srcs = srcs.clone();
        let tp = tp.clone();
        let trees = trees.clone();
        call_value(each_job(filter(&tp.defs, &(|d: &DefNote| &d.at.file < &shown_)), {
            let srcs = srcs.clone();
            Rc::new(move |p0: DefNote| {
                let srcs = srcs.clone();
                entered(once_job(move || {
                    let d = p0;
                    call_then(start_scheme_sexp(d.scheme.clone()), move |scheme_sexp_8257: Text| prism_rtl::Turn::Finished(Text::from(format!("  (def {} {} {})\n", &d.name, &at_text(&srcs, &d.at), &scheme_sexp_8257))))
                }))
            }) as Rc<dyn Fn(DefNote) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_8167: Array<Text>| {
            let defs = concat(&each_8167);
            call_value(each_job(files.clone(), {
                let srcs = srcs.clone();
                let tys = tys.clone();
                let trees = trees.clone();
                Rc::new(move |p0: Nat| {
                    let srcs = srcs.clone();
                    let tys = tys.clone();
                    let trees = trees.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(ExprsOfFile { srcs: srcs.clone(), tys: tys.clone(), file: i.clone(), m: or(&index(&trees, &i), &empty_mod()) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_8307: Array<Text>| {
                let exprs = concat(&each_8307);
                let mine_fn = {
                    let shown_ = shown_.clone();
                    Rc::new(move |a: &SrcAt| shown(a, &shown_))
                };
                let apps = concat(&each(&filter(&tp.apps, &(|x: &AppNote| (&mine_fn)(&x.at))), &(|x: &AppNote| Text::from(format!("  (app {} {} {} {} (lifted{}) {} {})\n", &at_text(&srcs, &x.at), &quote(&x.callee), &x.kind, &layer_word(&x.layer), &concat(&each(&x.lifted, &(|i: &Nat| Text::from(format!(" {}", i))))), &layer_word(&x.inner), &col_sexp(&x.color))))));
                let fns = concat(&each(&filter(&tp.fns, &(|x: &FnNote| (&mine_fn)(&x.at))), &(|x: &FnNote| Text::from(format!("  (fn {} {} {} {})\n", &quote(&x.name), &at_text(&srcs, &x.at), &col_sexp(&x.declared), &col_sexp(&x.body))))));
                let methods = concat(&each(&filter(&tp.methods, &(|x: &MethodNote| (&mine_fn)(&x.at))), &(|x: &MethodNote| Text::from(format!("  (method {} {} ^{})\n", &at_text(&srcs, &x.at), &x.method, &x.cls)))));
                call_value(each_job(filter(&tp.impls, &(|x: &ImplNote| (&mine_fn)(&x.at))), {
                    let srcs = srcs.clone();
                    Rc::new(move |p0: ImplNote| {
                        let srcs = srcs.clone();
                        entered(once_job(move || {
                            let x = p0;
                            call_then(start_ty_sexp(x.ty.clone()), move |ty_sexp_9027: Text| prism_rtl::Turn::Finished(Text::from(format!("  (impl {} ^{} {} {})\n", &at_text(&srcs, &x.at), &x.cls, &ty_sexp_9027, &x.how))))
                        }))
                    }) as Rc<dyn Fn(ImplNote) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_8943: Array<Text>| {
                    let impls = concat(&each_8943);
                    let groups = concat(&each(&filter(&tp.groups, &(|x: &GroupNote| (&mine_fn)(&x.at))), &(|x: &GroupNote| Text::from(format!("  (group {} {}{})\n", &x.kind, &at_text(&srcs, &x.at), &concat(&each(&x.order, &(|c: &Array<Nat>| Text::from(format!(" ({})", &crate::syntax::lexer::join(&each(c, &(|i: &Nat| Text::from(format!("{}", i)))), &Text::lit(" "))))))))))));
                    call_value(each_job(filter(&tp.binders, &(|x: &BinderNote| (&mine_fn)(&x.at))), {
                        let srcs = srcs.clone();
                        Rc::new(move |p0: BinderNote| {
                            let srcs = srcs.clone();
                            entered(once_job(move || {
                                let x = p0;
                                call_then(start_ty_sexp(x.ty.clone()), move |ty_sexp_9355: Text| prism_rtl::Turn::Finished(Text::from(format!("  (binder {} {} {})\n", &quote(&x.name), &at_text(&srcs, &x.at), &ty_sexp_9355))))
                            }))
                        }) as Rc<dyn Fn(BinderNote) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_9261: Array<Text>| {
                        let binders = concat(&each_9261);
                        let gens = concat(&each(&filter(&tp.gens, &(|x: &GenNote| (&mine_fn)(&x.at))), &(|x: &GenNote| Text::from(format!("  (gen {} {}{}{})\n", &quote(&x.name), &at_text(&srcs, &x.at), &concat(&each(&x.tys, &(|q: &Text| Text::from(format!(" {}", q))))), &concat(&each(&x.cols, &(|q: &Text| Text::from(format!(" {}", q))))))))));
                        call_value(each_job(filter(&tp.insts, &(|x: &InstNote| (&mine_fn)(&x.at))), {
                            let srcs = srcs.clone();
                            Rc::new(move |p0: InstNote| {
                                let srcs = srcs.clone();
                                entered(once_job(move || {
                                    let x = p0;
                                    call_value(each_job(x.tys.clone(), Rc::new(move |p0: (Text, crate::check::types::Ty)| entered(once_job(move || {
                                        let (q, t) = p0;
                                        call_then(start_ty_sexp(t.clone()), move |ty_sexp_9710: Text| prism_rtl::Turn::Finished(Text::from(format!(" ({} {})", &q, &ty_sexp_9710))))
                                    }))) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_9678: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("  (inst {} {}{}{})\n", &quote(&x.name), &at_text(&srcs, &x.at), &concat(&each_9678), &concat(&each(&x.cols, &(|(q, c): &(Text, crate::check::types::Col)| Text::from(format!(" ({} {})", q, &col_sexp(c))))))))))
                                }))
                            }) as Rc<dyn Fn(InstNote) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_9581: Array<Text>| {
                            let insts = concat(&each_9581);
                            prism_rtl::Turn::Finished(Text::from(format!("(typed\n (defs\n{} )\n (exprs\n{} )\n (apps\n{} )\n (fns\n{} )\n (methods\n{} )\n (impls\n{} )\n (groups\n{} )\n (binders\n{} )\n (gens\n{} )\n (insts\n{} ))\n", &defs, &exprs, &apps, &fns, &methods, &impls, &groups, &binders, &gens, &insts)))
                        })
                    })
                })
            })
        })
    }
}

/// `Start TypedSexp, x`: what the function value is when passed to `@Run`.
pub fn start_typed_sexp(srcs: Array<crate::check::errors::Src>, trees: Array<crate::syntax::Module>, shown_: Nat, tp: TProgram) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypedSexp { srcs, trees, shown_, tp })
}

/// ```prism
/// Shown: fn SrcAt, Nat -> Bool
/// ```
pub fn shown(a: &SrcAt, shown_: &Nat) -> bool {
    &a.file < shown_
}

/// ```prism
/// let emptyMod
/// ```
pub fn empty_mod() -> crate::syntax::Module {
    crate::syntax::Module { name: None, emit_row: None, mods: Array::new(), uses: Array::new(), decls: Array::new(), template: None, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// Quote: fn Text -> Text
/// ```
pub fn quote(t: &Text) -> Text {
    Text::from(format!("\"{}\"", t))
}

/// ```prism
/// LayerWord: fn Text -> Text
/// ```
pub fn layer_word(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("")) => Text::lit("-"),
        s => s.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
/// ```
pub fn exprs_of_file(srcs: &Array<crate::check::errors::Src>, tys: &Map<Text, crate::check::types::Ty>, file: &Nat, m: &crate::syntax::Module) -> Text {
    let es = run_to_end(fold_job(m.decls.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Decl)| entered(once_job(move || {
        let acc = p0;
        let d = p1;
        call_then(start_decl_exprs(d.clone()), move |decl_exprs_10530: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &decl_exprs_10530)))
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Decl)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>));
    concat(&run_to_end(each_job(es.clone(), {
        let srcs = srcs.clone();
        let tys = tys.clone();
        let file = file.clone();
        Rc::new(move |p0: crate::syntax::Expr| {
            let srcs = srcs.clone();
            let tys = tys.clone();
            let file = file.clone();
            entered(once_job(move || {
                let e = p0;
                prism_rtl::Turn::More(Rc::new(ExprLine { srcs: srcs.clone(), tys: tys.clone(), a: SrcAt { file: file.clone(), span: e.span.clone() } }))
            }))
        }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Text>>>
    })))
}

/// The step machine of `ExprsOfFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
/// ```
pub struct ExprsOfFile {
    pub srcs: Array<crate::check::errors::Src>,
    pub tys: Map<Text, crate::check::types::Ty>,
    pub file: Nat,
    pub m: crate::syntax::Module,
}

impl prism_rtl::Job<Text> for ExprsOfFile {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs = &self.srcs;
        let tys = &self.tys;
        let file = &self.file;
        let m = &self.m;
        let file = file.clone();
        let m = m.clone();
        let srcs = srcs.clone();
        let tys = tys.clone();
        call_value(fold_job(m.decls.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Decl)| entered(once_job(move || {
            let acc = p0;
            let d = p1;
            call_then(start_decl_exprs(d.clone()), move |decl_exprs_10530: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &decl_exprs_10530)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Decl)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>), move |fold_10487: Array<crate::syntax::Expr>| {
            let es = fold_10487;
            call_value(each_job(es.clone(), {
                let srcs = srcs.clone();
                let tys = tys.clone();
                let file = file.clone();
                Rc::new(move |p0: crate::syntax::Expr| {
                    let srcs = srcs.clone();
                    let tys = tys.clone();
                    let file = file.clone();
                    entered(once_job(move || {
                        let e = p0;
                        prism_rtl::Turn::More(Rc::new(ExprLine { srcs: srcs.clone(), tys: tys.clone(), a: SrcAt { file: file.clone(), span: e.span.clone() } }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_10555: Array<Text>| prism_rtl::Turn::Finished(concat(&each_10555)))
        })
    }
}

/// `Start ExprsOfFile, x`: what the function value is when passed to `@Run`.
pub fn start_exprs_of_file(srcs: Array<crate::check::errors::Src>, tys: Map<Text, crate::check::types::Ty>, file: Nat, m: crate::syntax::Module) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ExprsOfFile { srcs, tys, file, m })
}

/// ```prism
/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
/// ```
pub fn expr_line(srcs: &Array<crate::check::errors::Src>, tys: &Map<Text, crate::check::types::Ty>, a: &SrcAt) -> Text {
    Text::from(format!("  (expr {} {})\n", &at_text(srcs, a), &ty_sexp(&or(&get(tys, &at_key(a)), &crate::check::types::Ty::TyErr))))
}

/// The step machine of `ExprLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
/// ```
pub struct ExprLine {
    pub srcs: Array<crate::check::errors::Src>,
    pub tys: Map<Text, crate::check::types::Ty>,
    pub a: SrcAt,
}

impl prism_rtl::Job<Text> for ExprLine {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs = &self.srcs;
        let tys = &self.tys;
        let a = &self.a;
        let a = a.clone();
        let srcs = srcs.clone();
        let tys = tys.clone();
        call_then(start_ty_sexp(or(&get(&tys, &at_key(&a)), &crate::check::types::Ty::TyErr)), move |ty_sexp_10734: Text| prism_rtl::Turn::Finished(Text::from(format!("  (expr {} {})\n", &at_text(&srcs, &a), &ty_sexp_10734))))
    }
}

/// `Start ExprLine, x`: what the function value is when passed to `@Run`.
pub fn start_expr_line(srcs: Array<crate::check::errors::Src>, tys: Map<Text, crate::check::types::Ty>, a: SrcAt) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ExprLine { srcs, tys, a })
}

/// ```prism
/// DeclExprs: unbounded fn Decl -> [Expr]
/// ```
pub fn decl_exprs(d: &crate::syntax::Decl) -> Array<crate::syntax::Expr> {
    match &d.kind {
        crate::syntax::DeclKind::DFn(f) => body_exprs(&f.body),
        crate::syntax::DeclKind::DLet(l) => exprs_in(&l.value),
        crate::syntax::DeclKind::DWidget(w) => stmts_exprs(&w.body.stmts),
        crate::syntax::DeclKind::DTrait(t) => run_to_end(fold_job(t.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TraitItem)| entered(once_job(move || {
            let acc = p0;
            let it = p1;
            match &it {
                crate::syntax::TraitItem::TiFn(f) => {
                    let f = f.clone();
                    call_then(start_body_exprs(f.body.clone()), move |body_exprs_11021: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_11021)))
                },
                _ => prism_rtl::Turn::Finished(acc.clone()),
            }
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::DeclKind::DImpl(i) => run_to_end(fold_job(i.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TraitItem)| entered(once_job(move || {
            let acc = p0;
            let it = p1;
            match &it {
                crate::syntax::TraitItem::TiFn(f) => {
                    let f = f.clone();
                    call_then(start_body_exprs(f.body.clone()), move |body_exprs_11145: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_11145)))
                },
                _ => prism_rtl::Turn::Finished(acc.clone()),
            }
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::DeclKind::DCheck(c) => run_to_end(fold_job(c.lines.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::CheckLine)| entered(once_job(move || {
            let acc = p0;
            let l = p1;
            call_then(start_exprs_in(l.expr.clone()), move |exprs_in_11243: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_11243)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::CheckLine)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::DeclKind::DTest(t) => exprs_in(&t.blueprint),
        _ => Array::new(),
    }
}

/// The step machine of `DeclExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeclExprs: unbounded fn Decl -> [Expr]
/// ```
pub struct DeclExprs {
    pub d: crate::syntax::Decl,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for DeclExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let d = &self.d;
        match &d.kind {
            crate::syntax::DeclKind::DFn(f) => prism_rtl::Turn::More(Rc::new(BodyExprs { fn_body0: f.body.clone() })),
            crate::syntax::DeclKind::DLet(l) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: l.value.clone() })),
            crate::syntax::DeclKind::DWidget(w) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts: w.body.stmts.clone() })),
            crate::syntax::DeclKind::DTrait(t) => fold_job(t.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TraitItem)| entered(once_job(move || {
                let acc = p0;
                let it = p1;
                match &it {
                    crate::syntax::TraitItem::TiFn(f) => {
                        let f = f.clone();
                        call_then(start_body_exprs(f.body.clone()), move |body_exprs_11021: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_11021)))
                    },
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle(),
            crate::syntax::DeclKind::DImpl(i) => fold_job(i.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TraitItem)| entered(once_job(move || {
                let acc = p0;
                let it = p1;
                match &it {
                    crate::syntax::TraitItem::TiFn(f) => {
                        let f = f.clone();
                        call_then(start_body_exprs(f.body.clone()), move |body_exprs_11145: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_11145)))
                    },
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle(),
            crate::syntax::DeclKind::DCheck(c) => fold_job(c.lines.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::CheckLine)| entered(once_job(move || {
                let acc = p0;
                let l = p1;
                call_then(start_exprs_in(l.expr.clone()), move |exprs_in_11243: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_11243)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::CheckLine)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle(),
            crate::syntax::DeclKind::DTest(t) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: t.blueprint.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start DeclExprs, x`: what the function value is when passed to `@Run`.
pub fn start_decl_exprs(d: crate::syntax::Decl) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(DeclExprs { d })
}

/// ```prism
/// BodyExprs: unbounded fn FnBody -> [Expr]
/// ```
pub fn body_exprs(fn_body0: &crate::syntax::FnBody) -> Array<crate::syntax::Expr> {
    match fn_body0 {
        crate::syntax::FnBody::BodyExpr(e) => exprs_in(e),
        crate::syntax::FnBody::BodyBlock(b) => stmts_exprs(&b.stmts),
    }
}

/// The step machine of `BodyExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodyExprs: unbounded fn FnBody -> [Expr]
/// ```
pub struct BodyExprs {
    pub fn_body0: crate::syntax::FnBody,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for BodyExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let fn_body0 = &self.fn_body0;
        match fn_body0 {
            crate::syntax::FnBody::BodyExpr(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            crate::syntax::FnBody::BodyBlock(b) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts: b.stmts.clone() })),
        }
    }
}

/// `Start BodyExprs, x`: what the function value is when passed to `@Run`.
pub fn start_body_exprs(fn_body0: crate::syntax::FnBody) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(BodyExprs { fn_body0 })
}

/// ```prism
/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
/// ```
pub fn stmts_exprs(stmts: &Array<crate::syntax::Stmt>) -> Array<crate::syntax::Expr> {
    run_to_end(fold_job(stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Stmt)| entered(once_job(move || {
        let acc = p0;
        let s = p1;
        call_then(start_stmt_exprs(s.clone()), move |stmt_exprs_11546: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &stmt_exprs_11546)))
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>))
}

/// The step machine of `StmtsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
/// ```
pub struct StmtsExprs {
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for StmtsExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let stmts = &self.stmts;
        fold_job(stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Stmt)| entered(once_job(move || {
            let acc = p0;
            let s = p1;
            call_then(start_stmt_exprs(s.clone()), move |stmt_exprs_11546: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &stmt_exprs_11546)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle()
    }
}

/// `Start StmtsExprs, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_exprs(stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(StmtsExprs { stmts })
}

/// ```prism
/// StmtExprs: unbounded fn Stmt -> [Expr]
/// ```
pub fn stmt_exprs(s: &crate::syntax::Stmt) -> Array<crate::syntax::Expr> {
    match &s.kind {
        crate::syntax::StmtKind::SBind(_, e, t_opt) => match t_opt {
            Some(x) => append(&exprs_in(e), &exprs_in(x)),
            None => exprs_in(e),
        },
        crate::syntax::StmtKind::SIgnore(e) => exprs_in(e),
        crate::syntax::StmtKind::SLet(_, _, e) => exprs_in(e),
        crate::syntax::StmtKind::SFn(f) => body_exprs(&f.body),
        crate::syntax::StmtKind::SWidget(w) => stmts_exprs(&w.body.stmts),
        crate::syntax::StmtKind::SSet(t, v_) => append(&exprs_in(t), &exprs_in(v_)),
        crate::syntax::StmtKind::SAccum(t, _, v_) => append(&exprs_in(t), &exprs_in(v_)),
        crate::syntax::StmtKind::SRequire(c) => exprs_in(c),
        crate::syntax::StmtKind::SForbid(c) => exprs_in(c),
        crate::syntax::StmtKind::SWhile(c, b) => append(&cond_exprs(c), &stmts_exprs(&b.stmts)),
        crate::syntax::StmtKind::SReturn(e) => exprs_in(e),
        crate::syntax::StmtKind::SExpr(e) => exprs_in(e),
        _ => Array::new(),
    }
}

/// The step machine of `StmtExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtExprs: unbounded fn Stmt -> [Expr]
/// ```
pub struct StmtExprs {
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for StmtExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SBind(_, e, t_opt) => match t_opt {
                Some(x) => {
                    let e = e.clone();
                    let x = x.clone();
                    call_then(start_exprs_in(e.clone()), move |exprs_in_11686: Array<crate::syntax::Expr>| call_then(start_exprs_in(x.clone()), move |exprs_in_11699: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_11686, &exprs_in_11699))))
                },
                None => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            },
            crate::syntax::StmtKind::SIgnore(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            crate::syntax::StmtKind::SLet(_, _, e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            crate::syntax::StmtKind::SFn(f) => prism_rtl::Turn::More(Rc::new(BodyExprs { fn_body0: f.body.clone() })),
            crate::syntax::StmtKind::SWidget(w) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts: w.body.stmts.clone() })),
            crate::syntax::StmtKind::SSet(t, v_) => {
                let t = t.clone();
                let v_ = v_.clone();
                call_then(start_exprs_in(t.clone()), move |exprs_in_11886: Array<crate::syntax::Expr>| call_then(start_exprs_in(v_.clone()), move |exprs_in_11899: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_11886, &exprs_in_11899))))
            },
            crate::syntax::StmtKind::SAccum(t, _, v_) => {
                let t = t.clone();
                let v_ = v_.clone();
                call_then(start_exprs_in(t.clone()), move |exprs_in_11943: Array<crate::syntax::Expr>| call_then(start_exprs_in(v_.clone()), move |exprs_in_11956: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_11943, &exprs_in_11956))))
            },
            crate::syntax::StmtKind::SRequire(c) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: c.clone() })),
            crate::syntax::StmtKind::SForbid(c) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: c.clone() })),
            crate::syntax::StmtKind::SWhile(c, b) => {
                let b = b.clone();
                let c = c.clone();
                call_then(start_cond_exprs(c.clone()), move |cond_exprs_12043: Array<crate::syntax::Expr>| call_then(start_stmts_exprs(b.stmts.clone()), move |stmts_exprs_12058: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&cond_exprs_12043, &stmts_exprs_12058))))
            },
            crate::syntax::StmtKind::SReturn(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            crate::syntax::StmtKind::SExpr(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start StmtExprs, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_exprs(s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(StmtExprs { s })
}

/// ```prism
/// CondExprs: unbounded fn Cond -> [Expr]
/// ```
pub fn cond_exprs(cond0: &crate::syntax::Cond) -> Array<crate::syntax::Expr> {
    match cond0 {
        crate::syntax::Cond::CondExpr(e) => exprs_in(&**e),
        crate::syntax::Cond::CondBind(_, e, g_opt) => append(&exprs_in(&**e), &opt_exprs(&**g_opt)),
    }
}

/// The step machine of `CondExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondExprs: unbounded fn Cond -> [Expr]
/// ```
pub struct CondExprs {
    pub cond0: crate::syntax::Cond,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for CondExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let cond0 = &self.cond0;
        match cond0 {
            crate::syntax::Cond::CondExpr(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: (**e).clone() })),
            crate::syntax::Cond::CondBind(_, e, g_opt) => {
                let g_opt = (**g_opt).clone();
                let e = (**e).clone();
                call_then(start_exprs_in(e.clone()), move |exprs_in_12272: Array<crate::syntax::Expr>| call_then(start_opt_exprs(g_opt.clone()), move |opt_exprs_12285: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_12272, &opt_exprs_12285))))
            },
        }
    }
}

/// `Start CondExprs, x`: what the function value is when passed to `@Run`.
pub fn start_cond_exprs(cond0: crate::syntax::Cond) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(CondExprs { cond0 })
}

/// ```prism
/// ArgsExprs: unbounded fn [Arg] -> [Expr]
/// ```
pub fn args_exprs(args: &Array<crate::syntax::Arg>) -> Array<crate::syntax::Expr> {
    run_to_end(fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arg)| entered(once_job(move || {
        let acc = p0;
        let a = p1;
        call_then(start_exprs_in(a.value.clone()), move |exprs_in_12399: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_12399)))
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>))
}

/// The step machine of `ArgsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgsExprs: unbounded fn [Arg] -> [Expr]
/// ```
pub struct ArgsExprs {
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for ArgsExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let args = &self.args;
        fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arg)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_exprs_in(a.value.clone()), move |exprs_in_12399: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_12399)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle()
    }
}

/// `Start ArgsExprs, x`: what the function value is when passed to `@Run`.
pub fn start_args_exprs(args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(ArgsExprs { args })
}

/// ```prism
/// BlockExprs: unbounded fn Block -> [Expr]
/// ```
pub fn block_exprs(b: &crate::syntax::Block) -> Array<crate::syntax::Expr> {
    stmts_exprs(&b.stmts)
}

/// The step machine of `BlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockExprs: unbounded fn Block -> [Expr]
/// ```
pub struct BlockExprs {
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for BlockExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let b = &self.b;
        prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts: b.stmts.clone() }))
    }
}

/// `Start BlockExprs, x`: what the function value is when passed to `@Run`.
pub fn start_block_exprs(b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(BlockExprs { b })
}

/// ```prism
/// ExprsIn: unbounded fn Expr -> [Expr]
/// ```
pub fn exprs_in(e: &crate::syntax::Expr) -> Array<crate::syntax::Expr> {
    let inner = match &*e.kind {
        crate::syntax::ExprKind::ETuple(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| entered(once_job(move || {
            let acc = p0;
            let x = p1;
            call_then(start_exprs_in(x.clone()), move |exprs_in_12785: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_12785)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::EArray(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| entered(once_job(move || {
            let acc = p0;
            let x = p1;
            call_then(start_exprs_in(x.clone()), move |exprs_in_12853: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_12853)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::EMap(kvs) => run_to_end(fold_job(kvs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))| entered(once_job(move || {
            let acc = p0;
            let (k, v_) = p1;
            call_then(start_exprs_in(k.clone()), move |exprs_in_12936: Array<crate::syntax::Expr>| call_then(start_exprs_in(v_.clone()), move |exprs_in_12950: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &exprs_in_12936), &exprs_in_12950))))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::EGroup(x) => exprs_in(&**x),
        crate::syntax::ExprKind::ECall(c, args, _, _) => append(&exprs_in(&**c), &args_exprs(args)),
        crate::syntax::ExprKind::EBinary(_, l, r) => append(&exprs_in(&**l), &exprs_in(&**r)),
        crate::syntax::ExprKind::EUnary(_, x) => exprs_in(&**x),
        crate::syntax::ExprKind::EFreeSigil(_, x) => exprs_in(&**x),
        crate::syntax::ExprKind::EField(r, _, _) => exprs_in(&**r),
        crate::syntax::ExprKind::EIndex(r, i) => append(&exprs_in(&**r), &exprs_in(&**i)),
        crate::syntax::ExprKind::ETopicIndex(x) => exprs_in(&**x),
        crate::syntax::ExprKind::EMethod(r, _, args) => append(&exprs_in(&**r), &args_exprs(args)),
        crate::syntax::ExprKind::ETypeArgs(x, _) => exprs_in(&**x),
        crate::syntax::ExprKind::ECast(x, _, _) => exprs_in(&**x),
        crate::syntax::ExprKind::ELambda(_, body) => match &**body {
            crate::syntax::LambdaBody::LbExpr(x) => exprs_in(&**x),
            crate::syntax::LambdaBody::LbBlock(b) => block_exprs(b),
        },
        crate::syntax::ExprKind::EIf(c, t, el_opt) => append(&append(&cond_exprs(&**c), &block_exprs(t)), &opt_block_exprs(el_opt)),
        crate::syntax::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), exprs_in(&**s), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arm)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_opt_exprs(a.guard.clone()), move |opt_exprs_13764: Array<crate::syntax::Expr>| call_then(start_block_exprs(a.body.clone()), move |block_exprs_13786: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &opt_exprs_13764), &block_exprs_13786))))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::ERebuild(s, b) => append(&exprs_in(&**s), &block_exprs(b)),
        crate::syntax::ExprKind::EFor(_, s, b) => append(&exprs_in(&**s), &block_exprs(b)),
        crate::syntax::ExprKind::EGiven(b) => block_exprs(b),
        crate::syntax::ExprKind::EUpdate(t, b) => append(&exprs_in(&**t), &block_exprs(b)),
        crate::syntax::ExprKind::EWidgetBlock(b) => block_exprs(b),
        crate::syntax::ExprKind::EAny(x) => exprs_in(&**x),
        crate::syntax::ExprKind::ELit(l) => match &l.kind {
            crate::syntax::LitKind::LText(segs) => run_to_end(fold_job(segs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TextSeg)| entered(once_job(move || {
                let acc = p0;
                let sg = p1;
                match &sg {
                    crate::syntax::TextSeg::SegPlaceholder(x) => {
                        let x = x.clone();
                        call_then(start_exprs_in(x.clone()), move |exprs_in_14215: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_14215)))
                    },
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TextSeg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            _ => Array::new(),
        },
        crate::syntax::ExprKind::ETemplate(t) => template_exprs(&t.parts),
        _ => Array::new(),
    };
    match &*e.kind {
        crate::syntax::ExprKind::ERest => inner.clone(),
        crate::syntax::ExprKind::EError => inner.clone(),
        _ => append(&Array::from(vec![e.clone()]), &inner),
    }
}

/// The step machine of `ExprsIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprsIn: unbounded fn Expr -> [Expr]
/// ```
pub struct ExprsIn {
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for ExprsIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let e = &self.e;
        let inner = match &*e.kind {
            crate::syntax::ExprKind::ETuple(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| entered(once_job(move || {
                let acc = p0;
                let x = p1;
                call_then(start_exprs_in(x.clone()), move |exprs_in_12785: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_12785)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::EArray(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| entered(once_job(move || {
                let acc = p0;
                let x = p1;
                call_then(start_exprs_in(x.clone()), move |exprs_in_12853: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_12853)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::EMap(kvs) => run_to_end(fold_job(kvs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))| entered(once_job(move || {
                let acc = p0;
                let (k, v_) = p1;
                call_then(start_exprs_in(k.clone()), move |exprs_in_12936: Array<crate::syntax::Expr>| call_then(start_exprs_in(v_.clone()), move |exprs_in_12950: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &exprs_in_12936), &exprs_in_12950))))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::EGroup(x) => exprs_in(&**x),
            crate::syntax::ExprKind::ECall(c, args, _, _) => append(&exprs_in(&**c), &args_exprs(args)),
            crate::syntax::ExprKind::EBinary(_, l, r) => append(&exprs_in(&**l), &exprs_in(&**r)),
            crate::syntax::ExprKind::EUnary(_, x) => exprs_in(&**x),
            crate::syntax::ExprKind::EFreeSigil(_, x) => exprs_in(&**x),
            crate::syntax::ExprKind::EField(r, _, _) => exprs_in(&**r),
            crate::syntax::ExprKind::EIndex(r, i) => append(&exprs_in(&**r), &exprs_in(&**i)),
            crate::syntax::ExprKind::ETopicIndex(x) => exprs_in(&**x),
            crate::syntax::ExprKind::EMethod(r, _, args) => append(&exprs_in(&**r), &args_exprs(args)),
            crate::syntax::ExprKind::ETypeArgs(x, _) => exprs_in(&**x),
            crate::syntax::ExprKind::ECast(x, _, _) => exprs_in(&**x),
            crate::syntax::ExprKind::ELambda(_, body) => match &**body {
                crate::syntax::LambdaBody::LbExpr(x) => exprs_in(&**x),
                crate::syntax::LambdaBody::LbBlock(b) => block_exprs(b),
            },
            crate::syntax::ExprKind::EIf(c, t, el_opt) => append(&append(&cond_exprs(&**c), &block_exprs(t)), &opt_block_exprs(el_opt)),
            crate::syntax::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), exprs_in(&**s), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arm)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_opt_exprs(a.guard.clone()), move |opt_exprs_13764: Array<crate::syntax::Expr>| call_then(start_block_exprs(a.body.clone()), move |block_exprs_13786: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &opt_exprs_13764), &block_exprs_13786))))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::ERebuild(s, b) => append(&exprs_in(&**s), &block_exprs(b)),
            crate::syntax::ExprKind::EFor(_, s, b) => append(&exprs_in(&**s), &block_exprs(b)),
            crate::syntax::ExprKind::EGiven(b) => block_exprs(b),
            crate::syntax::ExprKind::EUpdate(t, b) => append(&exprs_in(&**t), &block_exprs(b)),
            crate::syntax::ExprKind::EWidgetBlock(b) => block_exprs(b),
            crate::syntax::ExprKind::EAny(x) => exprs_in(&**x),
            crate::syntax::ExprKind::ELit(l) => match &l.kind {
                crate::syntax::LitKind::LText(segs) => run_to_end(fold_job(segs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TextSeg)| entered(once_job(move || {
                    let acc = p0;
                    let sg = p1;
                    match &sg {
                        crate::syntax::TextSeg::SegPlaceholder(x) => {
                            let x = x.clone();
                            call_then(start_exprs_in(x.clone()), move |exprs_in_14215: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_14215)))
                        },
                        _ => prism_rtl::Turn::Finished(acc.clone()),
                    }
                }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TextSeg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
                _ => Array::new(),
            },
            crate::syntax::ExprKind::ETemplate(t) => template_exprs(&t.parts),
            _ => Array::new(),
        };
        match &*e.kind {
            crate::syntax::ExprKind::ERest => prism_rtl::Turn::Finished(inner.clone()),
            crate::syntax::ExprKind::EError => prism_rtl::Turn::Finished(inner.clone()),
            _ => prism_rtl::Turn::Finished(append(&Array::from(vec![e.clone()]), &inner)),
        }
    }
}

/// `Start ExprsIn, x`: what the function value is when passed to `@Run`.
pub fn start_exprs_in(e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(ExprsIn { e })
}

/// ```prism
/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
/// ```
pub fn template_exprs(parts: &Array<crate::syntax::TemplatePart>) -> Array<crate::syntax::Expr> {
    run_to_end(fold_job(parts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TemplatePart)| entered(once_job(move || {
        let acc = p0;
        let p_ = p1;
        match &p_ {
            crate::syntax::TemplatePart::TpPlaceholder(x, _) => {
                let x = x.clone();
                call_then(start_exprs_in(x.clone()), move |exprs_in_14610: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_14610)))
            },
            crate::syntax::TemplatePart::TpBlock(b) => {
                let b = b.clone();
                call_then(start_block_exprs(b.clone()), move |block_exprs_14649: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &block_exprs_14649)))
            },
            crate::syntax::TemplatePart::TpCall(_, args, ps_opt, _) => {
                let ps_opt = ps_opt.clone();
                let args = args.clone();
                call_then(start_args_exprs(args.clone()), move |args_exprs_14722: Array<crate::syntax::Expr>| call_then(start_opt_parts(ps_opt.clone()), move |opt_parts_14741: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &args_exprs_14722), &opt_parts_14741))))
            },
            _ => prism_rtl::Turn::Finished(acc.clone()),
        }
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>))
}

/// The step machine of `TemplateExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
/// ```
pub struct TemplateExprs {
    pub parts: Array<crate::syntax::TemplatePart>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for TemplateExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let parts = &self.parts;
        fold_job(parts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TemplatePart)| entered(once_job(move || {
            let acc = p0;
            let p_ = p1;
            match &p_ {
                crate::syntax::TemplatePart::TpPlaceholder(x, _) => {
                    let x = x.clone();
                    call_then(start_exprs_in(x.clone()), move |exprs_in_14610: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_14610)))
                },
                crate::syntax::TemplatePart::TpBlock(b) => {
                    let b = b.clone();
                    call_then(start_block_exprs(b.clone()), move |block_exprs_14649: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &block_exprs_14649)))
                },
                crate::syntax::TemplatePart::TpCall(_, args, ps_opt, _) => {
                    let ps_opt = ps_opt.clone();
                    let args = args.clone();
                    call_then(start_args_exprs(args.clone()), move |args_exprs_14722: Array<crate::syntax::Expr>| call_then(start_opt_parts(ps_opt.clone()), move |opt_parts_14741: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &args_exprs_14722), &opt_parts_14741))))
                },
                _ => prism_rtl::Turn::Finished(acc.clone()),
            }
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle()
    }
}

/// `Start TemplateExprs, x`: what the function value is when passed to `@Run`.
pub fn start_template_exprs(parts: Array<crate::syntax::TemplatePart>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(TemplateExprs { parts })
}

/// ```prism
/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
/// ```
pub fn opt_parts(opt0: &Option<Array<crate::syntax::TemplatePart>>) -> Array<crate::syntax::Expr> {
    match opt0 {
        Some(ps) => template_exprs(ps),
        None => Array::new(),
    }
}

/// The step machine of `OptParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
/// ```
pub struct OptParts {
    pub opt0: Option<Array<crate::syntax::TemplatePart>>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for OptParts {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(ps) => prism_rtl::Turn::More(Rc::new(TemplateExprs { parts: ps.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptParts, x`: what the function value is when passed to `@Run`.
pub fn start_opt_parts(opt0: Option<Array<crate::syntax::TemplatePart>>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(OptParts { opt0 })
}

/// ```prism
/// OptBlockExprs: unbounded fn ?Block -> [Expr]
/// ```
pub fn opt_block_exprs(opt0: &Option<crate::syntax::Block>) -> Array<crate::syntax::Expr> {
    match opt0 {
        Some(b) => block_exprs(b),
        None => Array::new(),
    }
}

/// The step machine of `OptBlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptBlockExprs: unbounded fn ?Block -> [Expr]
/// ```
pub struct OptBlockExprs {
    pub opt0: Option<crate::syntax::Block>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for OptBlockExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(b) => prism_rtl::Turn::More(Rc::new(BlockExprs { b: b.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptBlockExprs, x`: what the function value is when passed to `@Run`.
pub fn start_opt_block_exprs(opt0: Option<crate::syntax::Block>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(OptBlockExprs { opt0 })
}

/// ```prism
/// OptExprs: unbounded fn ?Expr -> [Expr]
/// ```
pub fn opt_exprs(opt0: &Option<crate::syntax::Expr>) -> Array<crate::syntax::Expr> {
    match opt0 {
        Some(x) => exprs_in(x),
        None => Array::new(),
    }
}

/// The step machine of `OptExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptExprs: unbounded fn ?Expr -> [Expr]
/// ```
pub struct OptExprs {
    pub opt0: Option<crate::syntax::Expr>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for OptExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(x) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: x.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptExprs, x`: what the function value is when passed to `@Run`.
pub fn start_opt_exprs(opt0: Option<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(OptExprs { opt0 })
}
