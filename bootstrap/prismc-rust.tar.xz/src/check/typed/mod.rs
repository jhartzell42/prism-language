//! The module `Check.Typed`, from `target/bootstrap/src/prismc/check/typed/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod print;

/// `AppNote`:
///
/// ```prism
/// type AppNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct AppNote {
    pub at_p: SrcAt,
    pub callee_p: Text,
    pub kind_p: Text,
    pub layer_p: Text,
    pub lifted_p: Array<Nat>,
    pub inner_p: Text,
    pub color_p: crate::check::types::Col,
}

impl Show for AppNote {
    fn show(&self, p: &mut Printer) {
        p.record("AppNote", &[("at", &self.at_p), ("callee", &self.callee_p), ("kind", &self.kind_p), ("layer", &self.layer_p), ("lifted", &self.lifted_p), ("inner", &self.inner_p), ("color", &self.color_p)]);
    }
}

impl ToPod for AppNote {
    fn to_pod(&self) -> Pod {
        Pod::record("AppNote", vec![("at", self.at_p.to_pod()), ("callee", self.callee_p.to_pod()), ("kind", self.kind_p.to_pod()), ("layer", self.layer_p.to_pod()), ("lifted", self.lifted_p.to_pod()), ("inner", self.inner_p.to_pod()), ("color", self.color_p.to_pod())])
    }
}

impl FromPod for AppNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(AppNote { at_p: FromPod::from_pod(field(p, "at")?)?, callee_p: FromPod::from_pod(field(p, "callee")?)?, kind_p: FromPod::from_pod(field(p, "kind")?)?, layer_p: FromPod::from_pod(field(p, "layer")?)?, lifted_p: FromPod::from_pod(field(p, "lifted")?)?, inner_p: FromPod::from_pod(field(p, "inner")?)?, color_p: FromPod::from_pod(field(p, "color")?)? })
    }
}

/// `BinderNote`:
///
/// ```prism
/// type BinderNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct BinderNote {
    pub at_p: SrcAt,
    pub name_p: Text,
    pub ty_p: crate::check::types::Ty,
}

impl Show for BinderNote {
    fn show(&self, p: &mut Printer) {
        p.record("BinderNote", &[("at", &self.at_p), ("name", &self.name_p), ("ty", &self.ty_p)]);
    }
}

impl ToPod for BinderNote {
    fn to_pod(&self) -> Pod {
        Pod::record("BinderNote", vec![("at", self.at_p.to_pod()), ("name", self.name_p.to_pod()), ("ty", self.ty_p.to_pod())])
    }
}

impl FromPod for BinderNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(BinderNote { at_p: FromPod::from_pod(field(p, "at")?)?, name_p: FromPod::from_pod(field(p, "name")?)?, ty_p: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// `DefNote`:
///
/// ```prism
/// type DefNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct DefNote {
    pub at_p: SrcAt,
    pub name_p: Text,
    pub scheme_p: crate::check::types::Scheme,
}

impl Show for DefNote {
    fn show(&self, p: &mut Printer) {
        p.record("DefNote", &[("at", &self.at_p), ("name", &self.name_p), ("scheme", &self.scheme_p)]);
    }
}

impl ToPod for DefNote {
    fn to_pod(&self) -> Pod {
        Pod::record("DefNote", vec![("at", self.at_p.to_pod()), ("name", self.name_p.to_pod()), ("scheme", self.scheme_p.to_pod())])
    }
}

impl FromPod for DefNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(DefNote { at_p: FromPod::from_pod(field(p, "at")?)?, name_p: FromPod::from_pod(field(p, "name")?)?, scheme_p: FromPod::from_pod(field(p, "scheme")?)? })
    }
}

/// `FnNote`:
///
/// ```prism
/// type FnNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FnNote {
    pub at_p: SrcAt,
    pub name_p: Text,
    pub declared_p: crate::check::types::Col,
    pub body_p: crate::check::types::Col,
}

impl Show for FnNote {
    fn show(&self, p: &mut Printer) {
        p.record("FnNote", &[("at", &self.at_p), ("name", &self.name_p), ("declared", &self.declared_p), ("body", &self.body_p)]);
    }
}

impl ToPod for FnNote {
    fn to_pod(&self) -> Pod {
        Pod::record("FnNote", vec![("at", self.at_p.to_pod()), ("name", self.name_p.to_pod()), ("declared", self.declared_p.to_pod()), ("body", self.body_p.to_pod())])
    }
}

impl FromPod for FnNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FnNote { at_p: FromPod::from_pod(field(p, "at")?)?, name_p: FromPod::from_pod(field(p, "name")?)?, declared_p: FromPod::from_pod(field(p, "declared")?)?, body_p: FromPod::from_pod(field(p, "body")?)? })
    }
}

/// `GenNote`:
///
/// ```prism
/// type GenNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct GenNote {
    pub at_p: SrcAt,
    pub name_p: Text,
    pub tys_p: Array<Text>,
    pub cols_p: Array<Text>,
}

impl Show for GenNote {
    fn show(&self, p: &mut Printer) {
        p.record("GenNote", &[("at", &self.at_p), ("name", &self.name_p), ("tys", &self.tys_p), ("cols", &self.cols_p)]);
    }
}

impl ToPod for GenNote {
    fn to_pod(&self) -> Pod {
        Pod::record("GenNote", vec![("at", self.at_p.to_pod()), ("name", self.name_p.to_pod()), ("tys", self.tys_p.to_pod()), ("cols", self.cols_p.to_pod())])
    }
}

impl FromPod for GenNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GenNote { at_p: FromPod::from_pod(field(p, "at")?)?, name_p: FromPod::from_pod(field(p, "name")?)?, tys_p: FromPod::from_pod(field(p, "tys")?)?, cols_p: FromPod::from_pod(field(p, "cols")?)? })
    }
}

/// `GlobalNote`:
///
/// ```prism
/// type GlobalNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct GlobalNote {
    pub at_p: SrcAt,
    pub target_p: Text,
}

impl Show for GlobalNote {
    fn show(&self, p: &mut Printer) {
        p.record("GlobalNote", &[("at", &self.at_p), ("target", &self.target_p)]);
    }
}

impl ToPod for GlobalNote {
    fn to_pod(&self) -> Pod {
        Pod::record("GlobalNote", vec![("at", self.at_p.to_pod()), ("target", self.target_p.to_pod())])
    }
}

impl FromPod for GlobalNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GlobalNote { at_p: FromPod::from_pod(field(p, "at")?)?, target_p: FromPod::from_pod(field(p, "target")?)? })
    }
}

/// `GroupNote`:
///
/// ```prism
/// type GroupNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct GroupNote {
    pub at_p: SrcAt,
    pub kind_p: Text,
    pub order_p: Array<Array<Nat>>,
}

impl Show for GroupNote {
    fn show(&self, p: &mut Printer) {
        p.record("GroupNote", &[("at", &self.at_p), ("kind", &self.kind_p), ("order", &self.order_p)]);
    }
}

impl ToPod for GroupNote {
    fn to_pod(&self) -> Pod {
        Pod::record("GroupNote", vec![("at", self.at_p.to_pod()), ("kind", self.kind_p.to_pod()), ("order", self.order_p.to_pod())])
    }
}

impl FromPod for GroupNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GroupNote { at_p: FromPod::from_pod(field(p, "at")?)?, kind_p: FromPod::from_pod(field(p, "kind")?)?, order_p: FromPod::from_pod(field(p, "order")?)? })
    }
}

/// `ImplNote`:
///
/// ```prism
/// type ImplNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ImplNote {
    pub at_p: SrcAt,
    pub cls_p: Text,
    pub ty_p: crate::check::types::Ty,
    pub how_p: Text,
}

impl Show for ImplNote {
    fn show(&self, p: &mut Printer) {
        p.record("ImplNote", &[("at", &self.at_p), ("cls", &self.cls_p), ("ty", &self.ty_p), ("how", &self.how_p)]);
    }
}

impl ToPod for ImplNote {
    fn to_pod(&self) -> Pod {
        Pod::record("ImplNote", vec![("at", self.at_p.to_pod()), ("cls", self.cls_p.to_pod()), ("ty", self.ty_p.to_pod()), ("how", self.how_p.to_pod())])
    }
}

impl FromPod for ImplNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ImplNote { at_p: FromPod::from_pod(field(p, "at")?)?, cls_p: FromPod::from_pod(field(p, "cls")?)?, ty_p: FromPod::from_pod(field(p, "ty")?)?, how_p: FromPod::from_pod(field(p, "how")?)? })
    }
}

/// `InstNote`:
///
/// ```prism
/// type InstNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct InstNote {
    pub at_p: SrcAt,
    pub name_p: Text,
    pub tys_p: Array<(Text, crate::check::types::Ty)>,
    pub cols_p: Array<(Text, crate::check::types::Col)>,
}

impl Show for InstNote {
    fn show(&self, p: &mut Printer) {
        p.record("InstNote", &[("at", &self.at_p), ("name", &self.name_p), ("tys", &self.tys_p), ("cols", &self.cols_p)]);
    }
}

impl ToPod for InstNote {
    fn to_pod(&self) -> Pod {
        Pod::record("InstNote", vec![("at", self.at_p.to_pod()), ("name", self.name_p.to_pod()), ("tys", self.tys_p.to_pod()), ("cols", self.cols_p.to_pod())])
    }
}

impl FromPod for InstNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(InstNote { at_p: FromPod::from_pod(field(p, "at")?)?, name_p: FromPod::from_pod(field(p, "name")?)?, tys_p: FromPod::from_pod(field(p, "tys")?)?, cols_p: FromPod::from_pod(field(p, "cols")?)? })
    }
}

/// `LiftNote`:
///
/// ```prism
/// type LiftNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct LiftNote {
    pub at_p: SrcAt,
    pub sigil_p: Text,
    pub operands_p: Array<crate::syntax::Range>,
}

impl Show for LiftNote {
    fn show(&self, p: &mut Printer) {
        p.record("LiftNote", &[("at", &self.at_p), ("sigil", &self.sigil_p), ("operands", &self.operands_p)]);
    }
}

impl ToPod for LiftNote {
    fn to_pod(&self) -> Pod {
        Pod::record("LiftNote", vec![("at", self.at_p.to_pod()), ("sigil", self.sigil_p.to_pod()), ("operands", self.operands_p.to_pod())])
    }
}

impl FromPod for LiftNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(LiftNote { at_p: FromPod::from_pod(field(p, "at")?)?, sigil_p: FromPod::from_pod(field(p, "sigil")?)?, operands_p: FromPod::from_pod(field(p, "operands")?)? })
    }
}

/// `LocalNote`:
///
/// ```prism
/// type LocalNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct LocalNote {
    pub at_p: SrcAt,
    pub id_p: Nat,
}

impl Show for LocalNote {
    fn show(&self, p: &mut Printer) {
        p.record("LocalNote", &[("at", &self.at_p), ("id", &self.id_p)]);
    }
}

impl ToPod for LocalNote {
    fn to_pod(&self) -> Pod {
        Pod::record("LocalNote", vec![("at", self.at_p.to_pod()), ("id", self.id_p.to_pod())])
    }
}

impl FromPod for LocalNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(LocalNote { at_p: FromPod::from_pod(field(p, "at")?)?, id_p: FromPod::from_pod(field(p, "id")?)? })
    }
}

/// `MethodNote`:
///
/// ```prism
/// type MethodNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct MethodNote {
    pub at_p: SrcAt,
    pub method_p: Text,
    pub cls_p: Text,
}

impl Show for MethodNote {
    fn show(&self, p: &mut Printer) {
        p.record("MethodNote", &[("at", &self.at_p), ("method", &self.method_p), ("cls", &self.cls_p)]);
    }
}

impl ToPod for MethodNote {
    fn to_pod(&self) -> Pod {
        Pod::record("MethodNote", vec![("at", self.at_p.to_pod()), ("method", self.method_p.to_pod()), ("cls", self.cls_p.to_pod())])
    }
}

impl FromPod for MethodNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(MethodNote { at_p: FromPod::from_pod(field(p, "at")?)?, method_p: FromPod::from_pod(field(p, "method")?)?, cls_p: FromPod::from_pod(field(p, "cls")?)? })
    }
}

/// `SrcAt`:
///
/// ```prism
/// type SrcAt = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct SrcAt {
    pub file_p: Nat,
    pub span_p: crate::syntax::Range,
}

impl Show for SrcAt {
    fn show(&self, p: &mut Printer) {
        p.record("SrcAt", &[("file", &self.file_p), ("span", &self.span_p)]);
    }
}

impl ToPod for SrcAt {
    fn to_pod(&self) -> Pod {
        Pod::record("SrcAt", vec![("file", self.file_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for SrcAt {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(SrcAt { file_p: FromPod::from_pod(field(p, "file")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TProgram`:
///
/// ```prism
/// type TProgram = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TProgram {
    pub exprs_p: Array<TyNote>,
    pub apps_p: Array<AppNote>,
    pub lifts_p: Array<LiftNote>,
    pub fns_p: Array<FnNote>,
    pub impls_p: Array<ImplNote>,
    pub methods_p: Array<MethodNote>,
    pub groups_p: Array<GroupNote>,
    pub binders_p: Array<BinderNote>,
    pub locals_p: Array<LocalNote>,
    pub uses_p: Array<LocalNote>,
    pub calls_p: Array<LocalNote>,
    pub globals_p: Array<GlobalNote>,
    pub gens_p: Array<GenNote>,
    pub insts_p: Array<InstNote>,
    pub defs_p: Array<DefNote>,
    pub unshrunk_p: Array<SrcAt>,
}

impl Show for TProgram {
    fn show(&self, p: &mut Printer) {
        p.record("TProgram", &[("exprs", &self.exprs_p), ("apps", &self.apps_p), ("lifts", &self.lifts_p), ("fns", &self.fns_p), ("impls", &self.impls_p), ("methods", &self.methods_p), ("groups", &self.groups_p), ("binders", &self.binders_p), ("locals", &self.locals_p), ("uses", &self.uses_p), ("calls", &self.calls_p), ("globals", &self.globals_p), ("gens", &self.gens_p), ("insts", &self.insts_p), ("defs", &self.defs_p), ("unshrunk", &self.unshrunk_p)]);
    }
}

impl ToPod for TProgram {
    fn to_pod(&self) -> Pod {
        Pod::record("TProgram", vec![("exprs", self.exprs_p.to_pod()), ("apps", self.apps_p.to_pod()), ("lifts", self.lifts_p.to_pod()), ("fns", self.fns_p.to_pod()), ("impls", self.impls_p.to_pod()), ("methods", self.methods_p.to_pod()), ("groups", self.groups_p.to_pod()), ("binders", self.binders_p.to_pod()), ("locals", self.locals_p.to_pod()), ("uses", self.uses_p.to_pod()), ("calls", self.calls_p.to_pod()), ("globals", self.globals_p.to_pod()), ("gens", self.gens_p.to_pod()), ("insts", self.insts_p.to_pod()), ("defs", self.defs_p.to_pod()), ("unshrunk", self.unshrunk_p.to_pod())])
    }
}

impl FromPod for TProgram {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TProgram { exprs_p: FromPod::from_pod(field(p, "exprs")?)?, apps_p: FromPod::from_pod(field(p, "apps")?)?, lifts_p: FromPod::from_pod(field(p, "lifts")?)?, fns_p: FromPod::from_pod(field(p, "fns")?)?, impls_p: FromPod::from_pod(field(p, "impls")?)?, methods_p: FromPod::from_pod(field(p, "methods")?)?, groups_p: FromPod::from_pod(field(p, "groups")?)?, binders_p: FromPod::from_pod(field(p, "binders")?)?, locals_p: FromPod::from_pod(field(p, "locals")?)?, uses_p: FromPod::from_pod(field(p, "uses")?)?, calls_p: FromPod::from_pod(field(p, "calls")?)?, globals_p: FromPod::from_pod(field(p, "globals")?)?, gens_p: FromPod::from_pod(field(p, "gens")?)?, insts_p: FromPod::from_pod(field(p, "insts")?)?, defs_p: FromPod::from_pod(field(p, "defs")?)?, unshrunk_p: FromPod::from_pod(field(p, "unshrunk")?)? })
    }
}

/// `TyNote`:
///
/// ```prism
/// type TyNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyNote {
    pub at_p: SrcAt,
    pub ty_p: crate::check::types::Ty,
}

impl Show for TyNote {
    fn show(&self, p: &mut Printer) {
        p.record("TyNote", &[("at", &self.at_p), ("ty", &self.ty_p)]);
    }
}

impl ToPod for TyNote {
    fn to_pod(&self) -> Pod {
        Pod::record("TyNote", vec![("at", self.at_p.to_pod()), ("ty", self.ty_p.to_pod())])
    }
}

impl FromPod for TyNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyNote { at_p: FromPod::from_pod(field(p, "at")?)?, ty_p: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// ```prism
/// let emptyTyped
/// ```
pub fn empty_typed_p() -> TProgram {
    TProgram { exprs_p: Array::new(), apps_p: Array::new(), lifts_p: Array::new(), fns_p: Array::new(), impls_p: Array::new(), methods_p: Array::new(), groups_p: Array::new(), binders_p: Array::new(), locals_p: Array::new(), uses_p: Array::new(), calls_p: Array::new(), globals_p: Array::new(), gens_p: Array::new(), insts_p: Array::new(), defs_p: Array::new(), unshrunk_p: Array::new() }
}

/// ```prism
/// AtKey: fn SrcAt -> Text
/// ```
pub fn at_key_f(a_p0: &SrcAt) -> Text {
    Text::from(format!("{}:{}:{}", &a_p0.file_p, &a_p0.span_p.start_p, &a_p0.span_p.end_p))
}
