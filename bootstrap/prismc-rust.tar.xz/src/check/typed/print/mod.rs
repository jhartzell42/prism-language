//! The module `Check.Typed.Print`, from `target/bootstrap/src/prismc/check/typed/print.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// TySexp: unbounded fn Ty -> Text
/// ```
pub fn ty_sexp(t_p0: &crate::check::types::Ty) -> Text {
    match t_p0 {
        crate::check::types::Ty::TyFlex(n_p1) => Text::from(format!("(var t{})", n_p1)),
        crate::check::types::Ty::TyRigid(n_p2) => Text::from(format!("(rigid {})", n_p2)),
        crate::check::types::Ty::TyQ(n_p3) => Text::from(format!("(q {})", n_p3)),
        crate::check::types::Ty::TyCon(n_p4, m820_3_1) if (m820_3_1.len() == 0) => n_p4.clone(),
        crate::check::types::Ty::TyCon(n_p5, args_p6) => Text::from(format!("({}{})", n_p5, &concat(&run_to_end(each_job(args_p6.clone(), Rc::new(move |p0: crate::check::types::Ty| entered(once_job(move || {
            let a_p7 = p0;
            call_then(start_ty_sexp(a_p7.clone()), move |ty_sexp_979: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_979))))
        }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>))))),
        crate::check::types::Ty::TyFn(c_p8, ps_p9, res_pa) => Text::from(format!("(fn {} ({}) {})", &col_sexp(c_p8), &crate::syntax::lexer::chars::join(&run_to_end(each_job(ps_p9.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_ty_sexp(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" ")), &ty_sexp(&**res_pa))),
        crate::check::types::Ty::TyTuple(ts_pb) => Text::from(format!("(tuple{})", &concat(&run_to_end(each_job(ts_pb.clone(), Rc::new(move |p0: crate::check::types::Ty| entered(once_job(move || {
            let a_pc = p0;
            call_then(start_ty_sexp(a_pc.clone()), move |ty_sexp_1128: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_1128))))
        }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>))))),
        crate::check::types::Ty::TyArray(e_pd) => Text::from(format!("(array {})", &ty_sexp(&**e_pd))),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => Text::from(format!("(map {} {})", &ty_sexp(&**k_pe), &ty_sexp(&**v_pf))),
        crate::check::types::Ty::TySig(s_pg, i_ph) => Text::from(format!("({} {})", s_pg, &ty_sexp(&**i_ph))),
        crate::check::types::Ty::TyAt(i_pi, rw_pj) => Text::from(format!("(@ {} {})", &ty_sexp(&**i_pi), &row_sexp(rw_pj))),
        crate::check::types::Ty::TyElem(rw_pk, o_pl) => Text::from(format!("(element {} {})", &row_sexp(rw_pk), &ty_sexp(&**o_pl))),
        crate::check::types::Ty::TyElemAny(rw_pm) => Text::from(format!("(elem {})", &row_sexp(rw_pm))),
        crate::check::types::Ty::TyAssoc(n_pn, a_po) => Text::from(format!("(assoc {} {})", n_pn, &ty_sexp(&**a_po))),
        crate::check::types::Ty::TyAny(trs_pp) => Text::from(format!("(any{})", &concat(&each(trs_pp, &(|x_pq: &Text| Text::from(format!(" ^{}", x_pq))))))),
        crate::check::types::Ty::TyErr => Text::lit("unknown"),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TySexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TySexp: unbounded fn Ty -> Text
/// ```
pub struct TySexp {
    pub t_p0: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for TySexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyFlex(n_p1) => prism_rtl::Turn::Finished(Text::from(format!("(var t{})", n_p1))),
            crate::check::types::Ty::TyRigid(n_p2) => prism_rtl::Turn::Finished(Text::from(format!("(rigid {})", n_p2))),
            crate::check::types::Ty::TyQ(n_p3) => prism_rtl::Turn::Finished(Text::from(format!("(q {})", n_p3))),
            crate::check::types::Ty::TyCon(n_p4, m820_3_1) if (m820_3_1.len() == 0) => prism_rtl::Turn::Finished(n_p4.clone()),
            crate::check::types::Ty::TyCon(n_p5, args_p6) => {
                let args_p6 = args_p6.clone();
                let n_p5 = n_p5.clone();
                call_value(each_job(args_p6.clone(), Rc::new(move |p0: crate::check::types::Ty| entered(once_job(move || {
                    let a_p7 = p0;
                    call_then(start_ty_sexp(a_p7.clone()), move |ty_sexp_979: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_979))))
                }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_960: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({}{})", &n_p5, &concat(&each_960)))))
            },
            crate::check::types::Ty::TyFn(c_p8, ps_p9, res_pa) => {
                let c_p8 = c_p8.clone();
                let ps_p9 = ps_p9.clone();
                let res_pa = (**res_pa).clone();
                call_value(each_job(ps_p9.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_ty_sexp(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_1040: Array<Text>| call_then(start_ty_sexp(res_pa.clone()), move |ty_sexp_1065: Text| prism_rtl::Turn::Finished(Text::from(format!("(fn {} ({}) {})", &col_sexp(&c_p8), &crate::syntax::lexer::chars::join(&each_1040, &Text::lit(" ")), &ty_sexp_1065)))))
            },
            crate::check::types::Ty::TyTuple(ts_pb) => {
                let ts_pb = ts_pb.clone();
                call_value(each_job(ts_pb.clone(), Rc::new(move |p0: crate::check::types::Ty| entered(once_job(move || {
                    let a_pc = p0;
                    call_then(start_ty_sexp(a_pc.clone()), move |ty_sexp_1128: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_1128))))
                }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_1111: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("(tuple{})", &concat(&each_1111)))))
            },
            crate::check::types::Ty::TyArray(e_pd) => {
                let e_pd = (**e_pd).clone();
                call_then(start_ty_sexp(e_pd.clone()), move |ty_sexp_1167: Text| prism_rtl::Turn::Finished(Text::from(format!("(array {})", &ty_sexp_1167))))
            },
            crate::check::types::Ty::TyMap(k_pe, v_pf) => {
                let k_pe = (**k_pe).clone();
                let v_pf = (**v_pf).clone();
                call_then(start_ty_sexp(k_pe.clone()), move |ty_sexp_1202: Text| call_then(start_ty_sexp(v_pf.clone()), move |ty_sexp_1213: Text| prism_rtl::Turn::Finished(Text::from(format!("(map {} {})", &ty_sexp_1202, &ty_sexp_1213)))))
            },
            crate::check::types::Ty::TySig(s_pg, i_ph) => {
                let i_ph = (**i_ph).clone();
                let s_pg = s_pg.clone();
                call_then(start_ty_sexp(i_ph.clone()), move |ty_sexp_1248: Text| prism_rtl::Turn::Finished(Text::from(format!("({} {})", &s_pg, &ty_sexp_1248))))
            },
            crate::check::types::Ty::TyAt(i_pi, rw_pj) => {
                let i_pi = (**i_pi).clone();
                let rw_pj = rw_pj.clone();
                call_then(start_ty_sexp(i_pi.clone()), move |ty_sexp_1281: Text| prism_rtl::Turn::Finished(Text::from(format!("(@ {} {})", &ty_sexp_1281, &row_sexp(&rw_pj)))))
            },
            crate::check::types::Ty::TyElem(rw_pk, o_pl) => {
                let o_pl = (**o_pl).clone();
                let rw_pk = rw_pk.clone();
                call_then(start_ty_sexp(o_pl.clone()), move |ty_sexp_1348: Text| prism_rtl::Turn::Finished(Text::from(format!("(element {} {})", &row_sexp(&rw_pk), &ty_sexp_1348))))
            },
            crate::check::types::Ty::TyElemAny(rw_pm) => prism_rtl::Turn::Finished(Text::from(format!("(elem {})", &row_sexp(rw_pm)))),
            crate::check::types::Ty::TyAssoc(n_pn, a_po) => {
                let a_po = (**a_po).clone();
                let n_pn = n_pn.clone();
                call_then(start_ty_sexp(a_po.clone()), move |ty_sexp_1431: Text| prism_rtl::Turn::Finished(Text::from(format!("(assoc {} {})", &n_pn, &ty_sexp_1431))))
            },
            crate::check::types::Ty::TyAny(trs_pp) => prism_rtl::Turn::Finished(Text::from(format!("(any{})", &concat(&each(trs_pp, &(|x_pq: &Text| Text::from(format!(" ^{}", x_pq)))))))),
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished(Text::lit("unknown")),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TySexp, x`: what the function value is when passed to `@Run`.
pub fn start_ty_sexp(t_p0: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TySexp { t_p0 })
}

/// ```prism
/// ColSexp: fn Col -> Text
/// ```
pub fn col_sexp(col0: &crate::check::types::Col) -> Text {
    match col0 {
        crate::check::types::Col::CBound => Text::lit("bounded"),
        crate::check::types::Col::CUnbound => Text::lit("unbounded"),
        crate::check::types::Col::CRigid(n_p0) => Text::from(format!("(color {})", n_p0)),
        crate::check::types::Col::CQ(n_p1) => Text::from(format!("(color {})", n_p1)),
        crate::check::types::Col::CFlex(n_p2) => Text::from(format!("(color c{})", n_p2)),
    }
}

/// ```prism
/// RowSexp: fn Rw -> Text
/// ```
pub fn row_sexp(rw_p0: &crate::check::types::Rw) -> Text {
    let tail_p1 = match &rw_p0.tail {
        crate::check::types::Tail::TlClosed => Text::lit(""),
        crate::check::types::Tail::TlFlex(n_p3) => Text::from(format!(" (tail r{})", n_p3)),
        crate::check::types::Tail::TlRigid(n_p4) => Text::from(format!(" (tail {})", n_p4)),
        crate::check::types::Tail::TlQ(n_p5) => Text::from(format!(" (tail {})", n_p5)),
    };
    let minus_p2 = if &len(&rw_p0.minus) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (minus{})", &concat(&each(&rw_p0.minus, &(|m_p6: &Text| Text::from(format!(" {}", m_p6)))))))
    };
    Text::from(format!("(row{}{}{})", &concat(&each(&rw_p0.fams, &(|f_p7: &Text| Text::from(format!(" {}.*", f_p7))))), &tail_p1, &minus_p2))
}

/// ```prism
/// SchemeSexp: unbounded fn Scheme -> Text
/// ```
pub fn scheme_sexp(sc_p0: &crate::check::types::Scheme) -> Text {
    let qs_p1 = if &len(&sc_p0.qs) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (forall{})", &concat(&each(&sc_p0.qs, &(|q_p5: &Text| Text::from(format!(" {}", q_p5)))))))
    };
    let rqs_p2 = if &len(&sc_p0.rqs) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (rows{})", &concat(&each(&sc_p0.rqs, &(|q_p6: &Text| Text::from(format!(" {}", q_p6)))))))
    };
    let cqs_p3 = if &len(&sc_p0.cqs) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (colors{})", &concat(&each(&sc_p0.cqs, &(|q_p7: &Text| Text::from(format!(" {}", q_p7)))))))
    };
    let bs_p4 = if &len(&sc_p0.bounds) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (where{})", &concat(&each(&sc_p0.bounds, &(|(v_p8, c_p9): &(Text, Text)| Text::from(format!(" {}:^{}", v_p8, c_p9)))))))
    };
    Text::from(format!("(scheme{}{}{}{} {})", &qs_p1, &rqs_p2, &cqs_p3, &bs_p4, &ty_sexp(&sc_p0.ty)))
}

/// The step machine of `SchemeSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SchemeSexp: unbounded fn Scheme -> Text
/// ```
pub struct SchemeSexp {
    pub sc_p0: crate::check::types::Scheme,
}

impl prism_rtl::Job<Text> for SchemeSexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let sc_p0 = &self.sc_p0;
        let qs_p1 = if &len(&sc_p0.qs) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (forall{})", &concat(&each(&sc_p0.qs, &(|q_p5: &Text| Text::from(format!(" {}", q_p5)))))))
        };
        let rqs_p2 = if &len(&sc_p0.rqs) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (rows{})", &concat(&each(&sc_p0.rqs, &(|q_p6: &Text| Text::from(format!(" {}", q_p6)))))))
        };
        let cqs_p3 = if &len(&sc_p0.cqs) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (colors{})", &concat(&each(&sc_p0.cqs, &(|q_p7: &Text| Text::from(format!(" {}", q_p7)))))))
        };
        let bs_p4 = if &len(&sc_p0.bounds) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (where{})", &concat(&each(&sc_p0.bounds, &(|(v_p8, c_p9): &(Text, Text)| Text::from(format!(" {}:^{}", v_p8, c_p9)))))))
        };
        let sc_p0 = sc_p0.clone();
        call_then(start_ty_sexp(sc_p0.ty.clone()), move |ty_sexp_2534: Text| prism_rtl::Turn::Finished(Text::from(format!("(scheme{}{}{}{} {})", &qs_p1, &rqs_p2, &cqs_p3, &bs_p4, &ty_sexp_2534))))
    }
}

/// `Start SchemeSexp, x`: what the function value is when passed to `@Run`.
pub fn start_scheme_sexp(sc_p0: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(SchemeSexp { sc_p0 })
}

/// ```prism
/// AtText: fn [Src], SrcAt -> Text
/// ```
pub fn at_text(srcs_p0: &Array<crate::check::errors::Src>, a_p1: &crate::check::typed::SrcAt) -> Text {
    match index(srcs_p0, &a_p1.file) {
        None => Text::from(format!("?:{}", &a_p1.span.start)),
        Some(src_p2) => Text::from(format!("{}:{}-{}", &crate::check::errors::seg_at(&src_p2, &a_p1.span.start).path_, &pos_text(&src_p2, &a_p1.span.start), &pos_text(&src_p2, &a_p1.span.end))),
    }
}

/// ```prism
/// PosText: fn Src, Nat -> Text
/// ```
pub fn pos_text(src_p0: &crate::check::errors::Src, offset_p1: &Nat) -> Text {
    let line_p2 = crate::check::errors::cline_of(&src_p0.starts, offset_p1);
    let col_p3 = crate::syntax::lexer::chars::column_of(&src_p0.text, &or(&index(&src_p0.starts, &line_p2), &Nat::from(0u32)), offset_p1);
    Text::from(format!("{}:{}", &(&or(&(&line_p2).checked_sub(&crate::check::errors::seg_at(src_p0, offset_p1).line), &Nat::from(0u32)) + &Nat::from(1u32)), &(&col_p3 + &Nat::from(1u32))))
}

/// ```prism
/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
/// ```
pub fn typed_sexp(srcs_p0: &Array<crate::check::errors::Src>, trees_p1: &Array<crate::syntax::Module>, shown_p2: &Nat, tp_p3: &crate::check::typed::TProgram) -> Text {
    let tys_p4 = fold(&tp_p3.exprs, &Map::new(), &(|m_pk: &Map<Text, crate::check::types::Ty>, n_pl: &crate::check::typed::TyNote| insert(m_pk, &crate::check::typed::at_key(&n_pl.at), &n_pl.ty)));
    let files_p5 = filter(&crate::check::errors::range0(&len(trees_p1)), &(|i_pm: &Nat| i_pm < shown_p2));
    let defs_p6 = concat(&run_to_end(each_job(filter(&tp_p3.defs, &(|d_pn: &crate::check::typed::DefNote| &d_pn.at.file < shown_p2)), {
        let srcs_p0 = srcs_p0.clone();
        Rc::new(move |p0: crate::check::typed::DefNote| {
            let srcs_p0 = srcs_p0.clone();
            entered(once_job(move || {
                let d_po = p0;
                call_then(start_scheme_sexp(d_po.scheme.clone()), move |scheme_sexp_3620: Text| prism_rtl::Turn::Finished(Text::from(format!("  (def {} {} {})\n", &d_po.name, &at_text(&srcs_p0, &d_po.at), &scheme_sexp_3620))))
            }))
        }) as Rc<dyn Fn(crate::check::typed::DefNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let exprs_p7 = concat(&run_to_end(each_job(files_p5.clone(), {
        let srcs_p0 = srcs_p0.clone();
        let tys_p4 = tys_p4.clone();
        let trees_p1 = trees_p1.clone();
        Rc::new(move |p0: Nat| {
            let srcs_p0 = srcs_p0.clone();
            let tys_p4 = tys_p4.clone();
            let trees_p1 = trees_p1.clone();
            entered(once_job(move || {
                let i_pp = p0;
                prism_rtl::Turn::More(Rc::new(ExprsOfFile { srcs_p0: srcs_p0.clone(), tys_p1: tys_p4.clone(), file_p2: i_pp.clone(), m_p3: or(&index(&trees_p1, &i_pp), &empty_mod()) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let mine_f8 = {
        let shown_p2 = shown_p2.clone();
        Rc::new(move |a_pq: &crate::check::typed::SrcAt| shown(a_pq, &shown_p2)) as Rc<dyn Fn(&crate::check::typed::SrcAt) -> bool>
    };
    let apps_p9 = concat(&each(&filter(&tp_p3.apps, &(|x_pr: &crate::check::typed::AppNote| (&mine_f8)(&x_pr.at))), &(|x_ps: &crate::check::typed::AppNote| Text::from(format!("  (app {} {} {} {} (lifted{}) {} {})\n", &at_text(srcs_p0, &x_ps.at), &quote(&x_ps.callee), &x_ps.kind, &layer_word(&x_ps.layer), &concat(&each(&x_ps.lifted, &(|i_pt: &Nat| Text::from(format!(" {}", i_pt))))), &layer_word(&x_ps.inner), &col_sexp(&x_ps.color))))));
    let lifts_pa = concat(&each(&filter(&tp_p3.lifts, &(|x_pu: &crate::check::typed::LiftNote| (&mine_f8)(&x_pu.at))), &(|x_pv: &crate::check::typed::LiftNote| Text::from(format!("  (lift {} {}{})\n", &at_text(srcs_p0, &x_pv.at), &x_pv.sigil, &concat(&each(&x_pv.operands, &(|r_p10: &crate::syntax::Range| Text::from(format!(" {}", &at_text(srcs_p0, &crate::check::typed::SrcAt { file: x_pv.at.file.clone(), span: r_p10.clone() })))))))))));
    let fns_pb = concat(&each(&filter(&tp_p3.fns, &(|x_p11: &crate::check::typed::FnNote| (&mine_f8)(&x_p11.at))), &(|x_p12: &crate::check::typed::FnNote| Text::from(format!("  (fn {} {} {} {})\n", &quote(&x_p12.name), &at_text(srcs_p0, &x_p12.at), &col_sexp(&x_p12.declared), &col_sexp(&x_p12.body))))));
    let methods_pc = concat(&each(&filter(&tp_p3.methods, &(|x_p13: &crate::check::typed::MethodNote| (&mine_f8)(&x_p13.at))), &(|x_p14: &crate::check::typed::MethodNote| Text::from(format!("  (method {} {} ^{})\n", &at_text(srcs_p0, &x_p14.at), &x_p14.method, &x_p14.cls)))));
    let impls_pd = concat(&run_to_end(each_job(filter(&tp_p3.impls, &(|x_p15: &crate::check::typed::ImplNote| (&mine_f8)(&x_p15.at))), {
        let srcs_p0 = srcs_p0.clone();
        Rc::new(move |p0: crate::check::typed::ImplNote| {
            let srcs_p0 = srcs_p0.clone();
            entered(once_job(move || {
                let x_p16 = p0;
                call_then(start_ty_sexp(x_p16.ty.clone()), move |ty_sexp_4583: Text| prism_rtl::Turn::Finished(Text::from(format!("  (impl {} ^{} {} {})\n", &at_text(&srcs_p0, &x_p16.at), &x_p16.cls, &ty_sexp_4583, &x_p16.how))))
            }))
        }) as Rc<dyn Fn(crate::check::typed::ImplNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let groups_pe = concat(&each(&filter(&tp_p3.groups, &(|x_p17: &crate::check::typed::GroupNote| (&mine_f8)(&x_p17.at))), &(|x_p18: &crate::check::typed::GroupNote| Text::from(format!("  (group {} {}{})\n", &x_p18.kind, &at_text(srcs_p0, &x_p18.at), &concat(&each(&x_p18.order, &(|c_p19: &Array<Nat>| Text::from(format!(" ({})", &crate::syntax::lexer::chars::join(&each(c_p19, &(|i_p1a: &Nat| Text::from(format!("{}", i_p1a)))), &Text::lit(" "))))))))))));
    let binders_pf = concat(&run_to_end(each_job(filter(&tp_p3.binders, &(|x_p1b: &crate::check::typed::BinderNote| (&mine_f8)(&x_p1b.at))), {
        let srcs_p0 = srcs_p0.clone();
        Rc::new(move |p0: crate::check::typed::BinderNote| {
            let srcs_p0 = srcs_p0.clone();
            entered(once_job(move || {
                let x_p1c = p0;
                call_then(start_ty_sexp(x_p1c.ty.clone()), move |ty_sexp_4911: Text| prism_rtl::Turn::Finished(Text::from(format!("  (binder {} {} {})\n", &quote(&x_p1c.name), &at_text(&srcs_p0, &x_p1c.at), &ty_sexp_4911))))
            }))
        }) as Rc<dyn Fn(crate::check::typed::BinderNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let locals_pg = concat(&each(&filter(&tp_p3.locals, &(|x_p1d: &crate::check::typed::LocalNote| (&mine_f8)(&x_p1d.at))), &(|x_p1e: &crate::check::typed::LocalNote| Text::from(format!("  (local {} {})\n", &x_p1e.id, &at_text(srcs_p0, &x_p1e.at))))));
    let uses_ph = concat(&each(&filter(&tp_p3.uses, &(|x_p1f: &crate::check::typed::LocalNote| (&mine_f8)(&x_p1f.at))), &(|x_p1g: &crate::check::typed::LocalNote| Text::from(format!("  (use {} {})\n", &x_p1g.id, &at_text(srcs_p0, &x_p1g.at))))));
    let gens_pi = concat(&each(&filter(&tp_p3.gens, &(|x_p1h: &crate::check::typed::GenNote| (&mine_f8)(&x_p1h.at))), &(|x_p1i: &crate::check::typed::GenNote| Text::from(format!("  (gen {} {}{}{})\n", &quote(&x_p1i.name), &at_text(srcs_p0, &x_p1i.at), &concat(&each(&x_p1i.tys, &(|q_p1j: &Text| Text::from(format!(" {}", q_p1j))))), &concat(&each(&x_p1i.cols, &(|q_p1k: &Text| Text::from(format!(" {}", q_p1k))))))))));
    let insts_pj = concat(&run_to_end(each_job(filter(&tp_p3.insts, &(|x_p1l: &crate::check::typed::InstNote| (&mine_f8)(&x_p1l.at))), {
        let srcs_p0 = srcs_p0.clone();
        Rc::new(move |p0: crate::check::typed::InstNote| {
            let srcs_p0 = srcs_p0.clone();
            entered(once_job(move || {
                let x_p1m = p0;
                call_value(each_job(x_p1m.tys.clone(), Rc::new(move |p0: (Text, crate::check::types::Ty)| entered(once_job(move || {
                    let (q_p1n, t_p1o) = p0;
                    call_then(start_ty_sexp(t_p1o.clone()), move |ty_sexp_5486: Text| prism_rtl::Turn::Finished(Text::from(format!(" ({} {})", &q_p1n, &ty_sexp_5486))))
                }))) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5454: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("  (inst {} {}{}{})\n", &quote(&x_p1m.name), &at_text(&srcs_p0, &x_p1m.at), &concat(&each_5454), &concat(&each(&x_p1m.cols, &(|(q_p1p, c_p1q): &(Text, crate::check::types::Col)| Text::from(format!(" ({} {})", q_p1p, &col_sexp(c_p1q))))))))))
            }))
        }) as Rc<dyn Fn(crate::check::typed::InstNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    Text::from(format!("(typed\n (defs\n{} )\n (exprs\n{} )\n (apps\n{} )\n (lifts\n{} )\n (fns\n{} )\n (methods\n{} )\n (impls\n{} )\n (groups\n{} )\n (binders\n{} )\n (locals\n{} )\n (uses\n{} )\n (gens\n{} )\n (insts\n{} ))\n", &defs_p6, &exprs_p7, &apps_p9, &lifts_pa, &fns_pb, &methods_pc, &impls_pd, &groups_pe, &binders_pf, &locals_pg, &uses_ph, &gens_pi, &insts_pj))
}

/// The step machine of `TypedSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
/// ```
pub struct TypedSexp {
    pub srcs_p0: Array<crate::check::errors::Src>,
    pub trees_p1: Array<crate::syntax::Module>,
    pub shown_p2: Nat,
    pub tp_p3: crate::check::typed::TProgram,
}

impl prism_rtl::Job<Text> for TypedSexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs_p0 = &self.srcs_p0;
        let trees_p1 = &self.trees_p1;
        let shown_p2 = &self.shown_p2;
        let tp_p3 = &self.tp_p3;
        let tys_p4 = fold(&tp_p3.exprs, &Map::new(), &(|m_pk: &Map<Text, crate::check::types::Ty>, n_pl: &crate::check::typed::TyNote| insert(m_pk, &crate::check::typed::at_key(&n_pl.at), &n_pl.ty)));
        let files_p5 = filter(&crate::check::errors::range0(&len(trees_p1)), &(|i_pm: &Nat| i_pm < shown_p2));
        let shown_p2 = shown_p2.clone();
        let srcs_p0 = srcs_p0.clone();
        let tp_p3 = tp_p3.clone();
        let trees_p1 = trees_p1.clone();
        call_value(each_job(filter(&tp_p3.defs, &(|d_pn: &crate::check::typed::DefNote| &d_pn.at.file < &shown_p2)), {
            let srcs_p0 = srcs_p0.clone();
            Rc::new(move |p0: crate::check::typed::DefNote| {
                let srcs_p0 = srcs_p0.clone();
                entered(once_job(move || {
                    let d_po = p0;
                    call_then(start_scheme_sexp(d_po.scheme.clone()), move |scheme_sexp_3620: Text| prism_rtl::Turn::Finished(Text::from(format!("  (def {} {} {})\n", &d_po.name, &at_text(&srcs_p0, &d_po.at), &scheme_sexp_3620))))
                }))
            }) as Rc<dyn Fn(crate::check::typed::DefNote) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_3530: Array<Text>| {
            let defs_p6 = concat(&each_3530);
            call_value(each_job(files_p5.clone(), {
                let srcs_p0 = srcs_p0.clone();
                let tys_p4 = tys_p4.clone();
                let trees_p1 = trees_p1.clone();
                Rc::new(move |p0: Nat| {
                    let srcs_p0 = srcs_p0.clone();
                    let tys_p4 = tys_p4.clone();
                    let trees_p1 = trees_p1.clone();
                    entered(once_job(move || {
                        let i_pp = p0;
                        prism_rtl::Turn::More(Rc::new(ExprsOfFile { srcs_p0: srcs_p0.clone(), tys_p1: tys_p4.clone(), file_p2: i_pp.clone(), m_p3: or(&index(&trees_p1, &i_pp), &empty_mod()) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_3670: Array<Text>| {
                let exprs_p7 = concat(&each_3670);
                let mine_f8 = {
                    let shown_p2 = shown_p2.clone();
                    Rc::new(move |a_pq: &crate::check::typed::SrcAt| shown(a_pq, &shown_p2)) as Rc<dyn Fn(&crate::check::typed::SrcAt) -> bool>
                };
                let apps_p9 = concat(&each(&filter(&tp_p3.apps, &(|x_pr: &crate::check::typed::AppNote| (&mine_f8)(&x_pr.at))), &(|x_ps: &crate::check::typed::AppNote| Text::from(format!("  (app {} {} {} {} (lifted{}) {} {})\n", &at_text(&srcs_p0, &x_ps.at), &quote(&x_ps.callee), &x_ps.kind, &layer_word(&x_ps.layer), &concat(&each(&x_ps.lifted, &(|i_pt: &Nat| Text::from(format!(" {}", i_pt))))), &layer_word(&x_ps.inner), &col_sexp(&x_ps.color))))));
                let lifts_pa = concat(&each(&filter(&tp_p3.lifts, &(|x_pu: &crate::check::typed::LiftNote| (&mine_f8)(&x_pu.at))), &(|x_pv: &crate::check::typed::LiftNote| Text::from(format!("  (lift {} {}{})\n", &at_text(&srcs_p0, &x_pv.at), &x_pv.sigil, &concat(&each(&x_pv.operands, &(|r_p10: &crate::syntax::Range| Text::from(format!(" {}", &at_text(&srcs_p0, &crate::check::typed::SrcAt { file: x_pv.at.file.clone(), span: r_p10.clone() })))))))))));
                let fns_pb = concat(&each(&filter(&tp_p3.fns, &(|x_p11: &crate::check::typed::FnNote| (&mine_f8)(&x_p11.at))), &(|x_p12: &crate::check::typed::FnNote| Text::from(format!("  (fn {} {} {} {})\n", &quote(&x_p12.name), &at_text(&srcs_p0, &x_p12.at), &col_sexp(&x_p12.declared), &col_sexp(&x_p12.body))))));
                let methods_pc = concat(&each(&filter(&tp_p3.methods, &(|x_p13: &crate::check::typed::MethodNote| (&mine_f8)(&x_p13.at))), &(|x_p14: &crate::check::typed::MethodNote| Text::from(format!("  (method {} {} ^{})\n", &at_text(&srcs_p0, &x_p14.at), &x_p14.method, &x_p14.cls)))));
                call_value(each_job(filter(&tp_p3.impls, &(|x_p15: &crate::check::typed::ImplNote| (&mine_f8)(&x_p15.at))), {
                    let srcs_p0 = srcs_p0.clone();
                    Rc::new(move |p0: crate::check::typed::ImplNote| {
                        let srcs_p0 = srcs_p0.clone();
                        entered(once_job(move || {
                            let x_p16 = p0;
                            call_then(start_ty_sexp(x_p16.ty.clone()), move |ty_sexp_4583: Text| prism_rtl::Turn::Finished(Text::from(format!("  (impl {} ^{} {} {})\n", &at_text(&srcs_p0, &x_p16.at), &x_p16.cls, &ty_sexp_4583, &x_p16.how))))
                        }))
                    }) as Rc<dyn Fn(crate::check::typed::ImplNote) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_4499: Array<Text>| {
                    let impls_pd = concat(&each_4499);
                    let groups_pe = concat(&each(&filter(&tp_p3.groups, &(|x_p17: &crate::check::typed::GroupNote| (&mine_f8)(&x_p17.at))), &(|x_p18: &crate::check::typed::GroupNote| Text::from(format!("  (group {} {}{})\n", &x_p18.kind, &at_text(&srcs_p0, &x_p18.at), &concat(&each(&x_p18.order, &(|c_p19: &Array<Nat>| Text::from(format!(" ({})", &crate::syntax::lexer::chars::join(&each(c_p19, &(|i_p1a: &Nat| Text::from(format!("{}", i_p1a)))), &Text::lit(" "))))))))))));
                    call_value(each_job(filter(&tp_p3.binders, &(|x_p1b: &crate::check::typed::BinderNote| (&mine_f8)(&x_p1b.at))), {
                        let srcs_p0 = srcs_p0.clone();
                        Rc::new(move |p0: crate::check::typed::BinderNote| {
                            let srcs_p0 = srcs_p0.clone();
                            entered(once_job(move || {
                                let x_p1c = p0;
                                call_then(start_ty_sexp(x_p1c.ty.clone()), move |ty_sexp_4911: Text| prism_rtl::Turn::Finished(Text::from(format!("  (binder {} {} {})\n", &quote(&x_p1c.name), &at_text(&srcs_p0, &x_p1c.at), &ty_sexp_4911))))
                            }))
                        }) as Rc<dyn Fn(crate::check::typed::BinderNote) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_4817: Array<Text>| {
                        let binders_pf = concat(&each_4817);
                        let locals_pg = concat(&each(&filter(&tp_p3.locals, &(|x_p1d: &crate::check::typed::LocalNote| (&mine_f8)(&x_p1d.at))), &(|x_p1e: &crate::check::typed::LocalNote| Text::from(format!("  (local {} {})\n", &x_p1e.id, &at_text(&srcs_p0, &x_p1e.at))))));
                        let uses_ph = concat(&each(&filter(&tp_p3.uses, &(|x_p1f: &crate::check::typed::LocalNote| (&mine_f8)(&x_p1f.at))), &(|x_p1g: &crate::check::typed::LocalNote| Text::from(format!("  (use {} {})\n", &x_p1g.id, &at_text(&srcs_p0, &x_p1g.at))))));
                        let gens_pi = concat(&each(&filter(&tp_p3.gens, &(|x_p1h: &crate::check::typed::GenNote| (&mine_f8)(&x_p1h.at))), &(|x_p1i: &crate::check::typed::GenNote| Text::from(format!("  (gen {} {}{}{})\n", &quote(&x_p1i.name), &at_text(&srcs_p0, &x_p1i.at), &concat(&each(&x_p1i.tys, &(|q_p1j: &Text| Text::from(format!(" {}", q_p1j))))), &concat(&each(&x_p1i.cols, &(|q_p1k: &Text| Text::from(format!(" {}", q_p1k))))))))));
                        call_value(each_job(filter(&tp_p3.insts, &(|x_p1l: &crate::check::typed::InstNote| (&mine_f8)(&x_p1l.at))), {
                            let srcs_p0 = srcs_p0.clone();
                            Rc::new(move |p0: crate::check::typed::InstNote| {
                                let srcs_p0 = srcs_p0.clone();
                                entered(once_job(move || {
                                    let x_p1m = p0;
                                    call_value(each_job(x_p1m.tys.clone(), Rc::new(move |p0: (Text, crate::check::types::Ty)| entered(once_job(move || {
                                        let (q_p1n, t_p1o) = p0;
                                        call_then(start_ty_sexp(t_p1o.clone()), move |ty_sexp_5486: Text| prism_rtl::Turn::Finished(Text::from(format!(" ({} {})", &q_p1n, &ty_sexp_5486))))
                                    }))) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5454: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("  (inst {} {}{}{})\n", &quote(&x_p1m.name), &at_text(&srcs_p0, &x_p1m.at), &concat(&each_5454), &concat(&each(&x_p1m.cols, &(|(q_p1p, c_p1q): &(Text, crate::check::types::Col)| Text::from(format!(" ({} {})", q_p1p, &col_sexp(c_p1q))))))))))
                                }))
                            }) as Rc<dyn Fn(crate::check::typed::InstNote) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_5357: Array<Text>| {
                            let insts_pj = concat(&each_5357);
                            prism_rtl::Turn::Finished(Text::from(format!("(typed\n (defs\n{} )\n (exprs\n{} )\n (apps\n{} )\n (lifts\n{} )\n (fns\n{} )\n (methods\n{} )\n (impls\n{} )\n (groups\n{} )\n (binders\n{} )\n (locals\n{} )\n (uses\n{} )\n (gens\n{} )\n (insts\n{} ))\n", &defs_p6, &exprs_p7, &apps_p9, &lifts_pa, &fns_pb, &methods_pc, &impls_pd, &groups_pe, &binders_pf, &locals_pg, &uses_ph, &gens_pi, &insts_pj)))
                        })
                    })
                })
            })
        })
    }
}

/// `Start TypedSexp, x`: what the function value is when passed to `@Run`.
pub fn start_typed_sexp(srcs_p0: Array<crate::check::errors::Src>, trees_p1: Array<crate::syntax::Module>, shown_p2: Nat, tp_p3: crate::check::typed::TProgram) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypedSexp { srcs_p0, trees_p1, shown_p2, tp_p3 })
}

/// ```prism
/// Shown: fn SrcAt, Nat -> Bool
/// ```
pub fn shown(a_p0: &crate::check::typed::SrcAt, shown_p1: &Nat) -> bool {
    &a_p0.file < shown_p1
}

/// ```prism
/// let emptyMod
/// ```
pub fn empty_mod() -> crate::syntax::Module {
    crate::syntax::Module { name: None, emit_row: None, mods: Array::new(), uses: Array::new(), decls: Array::new(), template: None, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// Quote: fn Text -> Text
/// ```
pub fn quote(t_p0: &Text) -> Text {
    Text::from(format!("\"{}\"", t_p0))
}

/// ```prism
/// LayerWord: fn Text -> Text
/// ```
pub fn layer_word(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("")) => Text::lit("-"),
        s_p0 => s_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
/// ```
pub fn exprs_of_file(srcs_p0: &Array<crate::check::errors::Src>, tys_p1: &Map<Text, crate::check::types::Ty>, file_p2: &Nat, m_p3: &crate::syntax::Module) -> Text {
    let es_p4 = run_to_end(fold_job(m_p3.decls.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::Decl)| entered(once_job(move || {
        let acc_p5 = p0;
        let d_p6 = p1;
        call_then(start_decl_exprs(d_p6.clone()), move |decl_exprs_6366: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p5, &decl_exprs_6366)))
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>));
    concat(&run_to_end(each_job(es_p4.clone(), {
        let srcs_p0 = srcs_p0.clone();
        let tys_p1 = tys_p1.clone();
        let file_p2 = file_p2.clone();
        Rc::new(move |p0: crate::syntax::Expr| {
            let srcs_p0 = srcs_p0.clone();
            let tys_p1 = tys_p1.clone();
            let file_p2 = file_p2.clone();
            entered(once_job(move || {
                let e_p7 = p0;
                prism_rtl::Turn::More(Rc::new(ExprLine { srcs_p0: srcs_p0.clone(), tys_p1: tys_p1.clone(), a_p2: crate::check::typed::SrcAt { file: file_p2.clone(), span: e_p7.span.clone() } }))
            }))
        }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Text>>>
    })))
}

/// The step machine of `ExprsOfFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
/// ```
pub struct ExprsOfFile {
    pub srcs_p0: Array<crate::check::errors::Src>,
    pub tys_p1: Map<Text, crate::check::types::Ty>,
    pub file_p2: Nat,
    pub m_p3: crate::syntax::Module,
}

impl prism_rtl::Job<Text> for ExprsOfFile {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs_p0 = &self.srcs_p0;
        let tys_p1 = &self.tys_p1;
        let file_p2 = &self.file_p2;
        let m_p3 = &self.m_p3;
        let file_p2 = file_p2.clone();
        let m_p3 = m_p3.clone();
        let srcs_p0 = srcs_p0.clone();
        let tys_p1 = tys_p1.clone();
        call_value(fold_job(m_p3.decls.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::Decl)| entered(once_job(move || {
            let acc_p5 = p0;
            let d_p6 = p1;
            call_then(start_decl_exprs(d_p6.clone()), move |decl_exprs_6366: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p5, &decl_exprs_6366)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>), move |fold_6323: Array<crate::syntax::Expr>| {
            let es_p4 = fold_6323;
            call_value(each_job(es_p4.clone(), {
                let srcs_p0 = srcs_p0.clone();
                let tys_p1 = tys_p1.clone();
                let file_p2 = file_p2.clone();
                Rc::new(move |p0: crate::syntax::Expr| {
                    let srcs_p0 = srcs_p0.clone();
                    let tys_p1 = tys_p1.clone();
                    let file_p2 = file_p2.clone();
                    entered(once_job(move || {
                        let e_p7 = p0;
                        prism_rtl::Turn::More(Rc::new(ExprLine { srcs_p0: srcs_p0.clone(), tys_p1: tys_p1.clone(), a_p2: crate::check::typed::SrcAt { file: file_p2.clone(), span: e_p7.span.clone() } }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_6391: Array<Text>| prism_rtl::Turn::Finished(concat(&each_6391)))
        })
    }
}

/// `Start ExprsOfFile, x`: what the function value is when passed to `@Run`.
pub fn start_exprs_of_file(srcs_p0: Array<crate::check::errors::Src>, tys_p1: Map<Text, crate::check::types::Ty>, file_p2: Nat, m_p3: crate::syntax::Module) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ExprsOfFile { srcs_p0, tys_p1, file_p2, m_p3 })
}

/// ```prism
/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
/// ```
pub fn expr_line(srcs_p0: &Array<crate::check::errors::Src>, tys_p1: &Map<Text, crate::check::types::Ty>, a_p2: &crate::check::typed::SrcAt) -> Text {
    Text::from(format!("  (expr {} {})\n", &at_text(srcs_p0, a_p2), &ty_sexp(&or(&get(tys_p1, &crate::check::typed::at_key(a_p2)), &crate::check::types::Ty::TyErr))))
}

/// The step machine of `ExprLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
/// ```
pub struct ExprLine {
    pub srcs_p0: Array<crate::check::errors::Src>,
    pub tys_p1: Map<Text, crate::check::types::Ty>,
    pub a_p2: crate::check::typed::SrcAt,
}

impl prism_rtl::Job<Text> for ExprLine {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs_p0 = &self.srcs_p0;
        let tys_p1 = &self.tys_p1;
        let a_p2 = &self.a_p2;
        let a_p2 = a_p2.clone();
        let srcs_p0 = srcs_p0.clone();
        let tys_p1 = tys_p1.clone();
        call_then(start_ty_sexp(or(&get(&tys_p1, &crate::check::typed::at_key(&a_p2)), &crate::check::types::Ty::TyErr)), move |ty_sexp_6570: Text| prism_rtl::Turn::Finished(Text::from(format!("  (expr {} {})\n", &at_text(&srcs_p0, &a_p2), &ty_sexp_6570))))
    }
}

/// `Start ExprLine, x`: what the function value is when passed to `@Run`.
pub fn start_expr_line(srcs_p0: Array<crate::check::errors::Src>, tys_p1: Map<Text, crate::check::types::Ty>, a_p2: crate::check::typed::SrcAt) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ExprLine { srcs_p0, tys_p1, a_p2 })
}

/// ```prism
/// DeclExprs: unbounded fn Decl -> [Expr]
/// ```
pub fn decl_exprs(d_p0: &crate::syntax::decls::Decl) -> Array<crate::syntax::Expr> {
    match &d_p0.kind {
        crate::syntax::decls::DeclKind::DFn(f_p1) => body_exprs(&f_p1.body),
        crate::syntax::decls::DeclKind::DLet(l_p2) => exprs_in(&l_p2.value),
        crate::syntax::decls::DeclKind::DWidget(w_p3) => stmts_exprs(&w_p3.body.stmts),
        crate::syntax::decls::DeclKind::DTrait(t_p4) => run_to_end(fold_job(t_p4.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)| entered(once_job(move || {
            let acc_p5 = p0;
            let it_p6 = p1;
            match &it_p6 {
                crate::syntax::decls::TraitItem::TiFn(f_p7) => {
                    let f_p7 = f_p7.clone();
                    call_then(start_body_exprs(f_p7.body.clone()), move |body_exprs_6857: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p5, &body_exprs_6857)))
                },
                _ => prism_rtl::Turn::Finished(acc_p5.clone()),
            }
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::decls::DeclKind::DImpl(i_p8) => run_to_end(fold_job(i_p8.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)| entered(once_job(move || {
            let acc_p9 = p0;
            let it_pa = p1;
            match &it_pa {
                crate::syntax::decls::TraitItem::TiFn(f_pb) => {
                    let f_pb = f_pb.clone();
                    call_then(start_body_exprs(f_pb.body.clone()), move |body_exprs_6981: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p9, &body_exprs_6981)))
                },
                _ => prism_rtl::Turn::Finished(acc_p9.clone()),
            }
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::decls::DeclKind::DCheck(c_pc) => run_to_end(fold_job(c_pc.lines.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine)| entered(once_job(move || {
            let acc_pd = p0;
            let l_pe = p1;
            call_then(start_exprs_in(l_pe.expr.clone()), move |exprs_in_7079: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_pd, &exprs_in_7079)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::decls::DeclKind::DTest(t_pf) => exprs_in(&t_pf.blueprint),
        _ => Array::new(),
    }
}

/// The step machine of `DeclExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeclExprs: unbounded fn Decl -> [Expr]
/// ```
pub struct DeclExprs {
    pub d_p0: crate::syntax::decls::Decl,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for DeclExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let d_p0 = &self.d_p0;
        match &d_p0.kind {
            crate::syntax::decls::DeclKind::DFn(f_p1) => prism_rtl::Turn::More(Rc::new(BodyExprs { fn_body0: f_p1.body.clone() })),
            crate::syntax::decls::DeclKind::DLet(l_p2) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: l_p2.value.clone() })),
            crate::syntax::decls::DeclKind::DWidget(w_p3) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts_p0: w_p3.body.stmts.clone() })),
            crate::syntax::decls::DeclKind::DTrait(t_p4) => fold_job(t_p4.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)| entered(once_job(move || {
                let acc_p5 = p0;
                let it_p6 = p1;
                match &it_p6 {
                    crate::syntax::decls::TraitItem::TiFn(f_p7) => {
                        let f_p7 = f_p7.clone();
                        call_then(start_body_exprs(f_p7.body.clone()), move |body_exprs_6857: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p5, &body_exprs_6857)))
                    },
                    _ => prism_rtl::Turn::Finished(acc_p5.clone()),
                }
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle(),
            crate::syntax::decls::DeclKind::DImpl(i_p8) => fold_job(i_p8.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)| entered(once_job(move || {
                let acc_p9 = p0;
                let it_pa = p1;
                match &it_pa {
                    crate::syntax::decls::TraitItem::TiFn(f_pb) => {
                        let f_pb = f_pb.clone();
                        call_then(start_body_exprs(f_pb.body.clone()), move |body_exprs_6981: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p9, &body_exprs_6981)))
                    },
                    _ => prism_rtl::Turn::Finished(acc_p9.clone()),
                }
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle(),
            crate::syntax::decls::DeclKind::DCheck(c_pc) => fold_job(c_pc.lines.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine)| entered(once_job(move || {
                let acc_pd = p0;
                let l_pe = p1;
                call_then(start_exprs_in(l_pe.expr.clone()), move |exprs_in_7079: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_pd, &exprs_in_7079)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle(),
            crate::syntax::decls::DeclKind::DTest(t_pf) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: t_pf.blueprint.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start DeclExprs, x`: what the function value is when passed to `@Run`.
pub fn start_decl_exprs(d_p0: crate::syntax::decls::Decl) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(DeclExprs { d_p0 })
}

/// ```prism
/// BodyExprs: unbounded fn FnBody -> [Expr]
/// ```
pub fn body_exprs(fn_body0: &crate::syntax::decls::FnBody) -> Array<crate::syntax::Expr> {
    match fn_body0 {
        crate::syntax::decls::FnBody::BodyExpr(e_p0) => exprs_in(e_p0),
        crate::syntax::decls::FnBody::BodyBlock(b_p1) => stmts_exprs(&b_p1.stmts),
    }
}

/// The step machine of `BodyExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodyExprs: unbounded fn FnBody -> [Expr]
/// ```
pub struct BodyExprs {
    pub fn_body0: crate::syntax::decls::FnBody,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for BodyExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let fn_body0 = &self.fn_body0;
        match fn_body0 {
            crate::syntax::decls::FnBody::BodyExpr(e_p0) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: e_p0.clone() })),
            crate::syntax::decls::FnBody::BodyBlock(b_p1) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts_p0: b_p1.stmts.clone() })),
        }
    }
}

/// `Start BodyExprs, x`: what the function value is when passed to `@Run`.
pub fn start_body_exprs(fn_body0: crate::syntax::decls::FnBody) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(BodyExprs { fn_body0 })
}

/// ```prism
/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
/// ```
pub fn stmts_exprs(stmts_p0: &Array<crate::syntax::Stmt>) -> Array<crate::syntax::Expr> {
    run_to_end(fold_job(stmts_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Stmt)| entered(once_job(move || {
        let acc_p1 = p0;
        let s_p2 = p1;
        call_then(start_stmt_exprs(s_p2.clone()), move |stmt_exprs_7382: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p1, &stmt_exprs_7382)))
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>))
}

/// The step machine of `StmtsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
/// ```
pub struct StmtsExprs {
    pub stmts_p0: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for StmtsExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let stmts_p0 = &self.stmts_p0;
        fold_job(stmts_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Stmt)| entered(once_job(move || {
            let acc_p1 = p0;
            let s_p2 = p1;
            call_then(start_stmt_exprs(s_p2.clone()), move |stmt_exprs_7382: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p1, &stmt_exprs_7382)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle()
    }
}

/// `Start StmtsExprs, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_exprs(stmts_p0: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(StmtsExprs { stmts_p0 })
}

/// ```prism
/// StmtExprs: unbounded fn Stmt -> [Expr]
/// ```
pub fn stmt_exprs(s_p0: &crate::syntax::Stmt) -> Array<crate::syntax::Expr> {
    match &s_p0.kind {
        crate::syntax::StmtKind::SBind(_, e_p1, t_o2) => match t_o2 {
            Some(x_p3) => append(&exprs_in(e_p1), &exprs_in(x_p3)),
            None => exprs_in(e_p1),
        },
        crate::syntax::StmtKind::SIgnore(e_p4) => exprs_in(e_p4),
        crate::syntax::StmtKind::SLet(_, _, e_p5) => exprs_in(e_p5),
        crate::syntax::StmtKind::SFn(f_p6) => body_exprs(&f_p6.body),
        crate::syntax::StmtKind::SWidget(w_p7) => stmts_exprs(&w_p7.body.stmts),
        crate::syntax::StmtKind::SSet(t_p8, v_p9) => append(&exprs_in(t_p8), &exprs_in(v_p9)),
        crate::syntax::StmtKind::SAccum(t_pa, _, v_pb) => append(&exprs_in(t_pa), &exprs_in(v_pb)),
        crate::syntax::StmtKind::SRequire(c_pc) => exprs_in(c_pc),
        crate::syntax::StmtKind::SForbid(c_pd) => exprs_in(c_pd),
        crate::syntax::StmtKind::SWhile(c_pe, b_pf) => append(&cond_exprs(c_pe), &stmts_exprs(&b_pf.stmts)),
        crate::syntax::StmtKind::SReturn(e_pg) => exprs_in(e_pg),
        crate::syntax::StmtKind::SExpr(e_ph) => exprs_in(e_ph),
        _ => Array::new(),
    }
}

/// The step machine of `StmtExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtExprs: unbounded fn Stmt -> [Expr]
/// ```
pub struct StmtExprs {
    pub s_p0: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for StmtExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let s_p0 = &self.s_p0;
        match &s_p0.kind {
            crate::syntax::StmtKind::SBind(_, e_p1, t_o2) => match t_o2 {
                Some(x_p3) => {
                    let e_p1 = e_p1.clone();
                    let x_p3 = x_p3.clone();
                    call_then(start_exprs_in(e_p1.clone()), move |exprs_in_7522: Array<crate::syntax::Expr>| call_then(start_exprs_in(x_p3.clone()), move |exprs_in_7535: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_7522, &exprs_in_7535))))
                },
                None => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: e_p1.clone() })),
            },
            crate::syntax::StmtKind::SIgnore(e_p4) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: e_p4.clone() })),
            crate::syntax::StmtKind::SLet(_, _, e_p5) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: e_p5.clone() })),
            crate::syntax::StmtKind::SFn(f_p6) => prism_rtl::Turn::More(Rc::new(BodyExprs { fn_body0: f_p6.body.clone() })),
            crate::syntax::StmtKind::SWidget(w_p7) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts_p0: w_p7.body.stmts.clone() })),
            crate::syntax::StmtKind::SSet(t_p8, v_p9) => {
                let t_p8 = t_p8.clone();
                let v_p9 = v_p9.clone();
                call_then(start_exprs_in(t_p8.clone()), move |exprs_in_7722: Array<crate::syntax::Expr>| call_then(start_exprs_in(v_p9.clone()), move |exprs_in_7735: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_7722, &exprs_in_7735))))
            },
            crate::syntax::StmtKind::SAccum(t_pa, _, v_pb) => {
                let t_pa = t_pa.clone();
                let v_pb = v_pb.clone();
                call_then(start_exprs_in(t_pa.clone()), move |exprs_in_7779: Array<crate::syntax::Expr>| call_then(start_exprs_in(v_pb.clone()), move |exprs_in_7792: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_7779, &exprs_in_7792))))
            },
            crate::syntax::StmtKind::SRequire(c_pc) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: c_pc.clone() })),
            crate::syntax::StmtKind::SForbid(c_pd) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: c_pd.clone() })),
            crate::syntax::StmtKind::SWhile(c_pe, b_pf) => {
                let b_pf = b_pf.clone();
                let c_pe = c_pe.clone();
                call_then(start_cond_exprs(c_pe.clone()), move |cond_exprs_7879: Array<crate::syntax::Expr>| call_then(start_stmts_exprs(b_pf.stmts.clone()), move |stmts_exprs_7894: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&cond_exprs_7879, &stmts_exprs_7894))))
            },
            crate::syntax::StmtKind::SReturn(e_pg) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: e_pg.clone() })),
            crate::syntax::StmtKind::SExpr(e_ph) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: e_ph.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start StmtExprs, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_exprs(s_p0: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(StmtExprs { s_p0 })
}

/// ```prism
/// CondExprs: unbounded fn Cond -> [Expr]
/// ```
pub fn cond_exprs(cond0: &crate::syntax::Cond) -> Array<crate::syntax::Expr> {
    match cond0 {
        crate::syntax::Cond::CondExpr(e_p0) => exprs_in(&**e_p0),
        crate::syntax::Cond::CondBind(_, e_p1, g_o2) => append(&exprs_in(&**e_p1), &opt_exprs(&**g_o2)),
    }
}

/// The step machine of `CondExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondExprs: unbounded fn Cond -> [Expr]
/// ```
pub struct CondExprs {
    pub cond0: crate::syntax::Cond,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for CondExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let cond0 = &self.cond0;
        match cond0 {
            crate::syntax::Cond::CondExpr(e_p0) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: (**e_p0).clone() })),
            crate::syntax::Cond::CondBind(_, e_p1, g_o2) => {
                let g_o2 = (**g_o2).clone();
                let e_p1 = (**e_p1).clone();
                call_then(start_exprs_in(e_p1.clone()), move |exprs_in_8108: Array<crate::syntax::Expr>| call_then(start_opt_exprs(g_o2.clone()), move |opt_exprs_8121: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_8108, &opt_exprs_8121))))
            },
        }
    }
}

/// `Start CondExprs, x`: what the function value is when passed to `@Run`.
pub fn start_cond_exprs(cond0: crate::syntax::Cond) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(CondExprs { cond0 })
}

/// ```prism
/// ArgsExprs: unbounded fn [Arg] -> [Expr]
/// ```
pub fn args_exprs(args_p0: &Array<crate::syntax::Arg>) -> Array<crate::syntax::Expr> {
    run_to_end(fold_job(args_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arg)| entered(once_job(move || {
        let acc_p1 = p0;
        let a_p2 = p1;
        call_then(start_exprs_in(a_p2.value.clone()), move |exprs_in_8235: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p1, &exprs_in_8235)))
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>))
}

/// The step machine of `ArgsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgsExprs: unbounded fn [Arg] -> [Expr]
/// ```
pub struct ArgsExprs {
    pub args_p0: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for ArgsExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let args_p0 = &self.args_p0;
        fold_job(args_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arg)| entered(once_job(move || {
            let acc_p1 = p0;
            let a_p2 = p1;
            call_then(start_exprs_in(a_p2.value.clone()), move |exprs_in_8235: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p1, &exprs_in_8235)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle()
    }
}

/// `Start ArgsExprs, x`: what the function value is when passed to `@Run`.
pub fn start_args_exprs(args_p0: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(ArgsExprs { args_p0 })
}

/// ```prism
/// BlockExprs: unbounded fn Block -> [Expr]
/// ```
pub fn block_exprs(b_p0: &crate::syntax::Block) -> Array<crate::syntax::Expr> {
    stmts_exprs(&b_p0.stmts)
}

/// The step machine of `BlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockExprs: unbounded fn Block -> [Expr]
/// ```
pub struct BlockExprs {
    pub b_p0: crate::syntax::Block,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for BlockExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let b_p0 = &self.b_p0;
        prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts_p0: b_p0.stmts.clone() }))
    }
}

/// `Start BlockExprs, x`: what the function value is when passed to `@Run`.
pub fn start_block_exprs(b_p0: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(BlockExprs { b_p0 })
}

/// ```prism
/// ExprsIn: unbounded fn Expr -> [Expr]
/// ```
pub fn exprs_in(e_p0: &crate::syntax::Expr) -> Array<crate::syntax::Expr> {
    let inner_p1 = match &*e_p0.kind {
        crate::syntax::ExprKind::ETuple(es_p2) => run_to_end(fold_job(es_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| entered(once_job(move || {
            let acc_p3 = p0;
            let x_p4 = p1;
            call_then(start_exprs_in(x_p4.clone()), move |exprs_in_8621: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p3, &exprs_in_8621)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::EArray(es_p5) => run_to_end(fold_job(es_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| entered(once_job(move || {
            let acc_p6 = p0;
            let x_p7 = p1;
            call_then(start_exprs_in(x_p7.clone()), move |exprs_in_8689: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p6, &exprs_in_8689)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::EMap(kvs_p8) => run_to_end(fold_job(kvs_p8.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))| entered(once_job(move || {
            let acc_p9 = p0;
            let (k_pa, v_pb) = p1;
            call_then(start_exprs_in(k_pa.clone()), move |exprs_in_8772: Array<crate::syntax::Expr>| call_then(start_exprs_in(v_pb.clone()), move |exprs_in_8786: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc_p9, &exprs_in_8772), &exprs_in_8786))))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::EGroup(x_pc) => exprs_in(&**x_pc),
        crate::syntax::ExprKind::ECall(c_pd, args_pe, _, _) => append(&exprs_in(&**c_pd), &args_exprs(args_pe)),
        crate::syntax::ExprKind::EBinary(_, l_pf, r_pg) => append(&exprs_in(&**l_pf), &exprs_in(&**r_pg)),
        crate::syntax::ExprKind::EUnary(_, x_ph) => exprs_in(&**x_ph),
        crate::syntax::ExprKind::EFreeSigil(_, x_pi) => exprs_in(&**x_pi),
        crate::syntax::ExprKind::EField(r_pj, _, _) => exprs_in(&**r_pj),
        crate::syntax::ExprKind::EIndex(r_pk, i_pl) => append(&exprs_in(&**r_pk), &exprs_in(&**i_pl)),
        crate::syntax::ExprKind::ETopicIndex(x_pm) => exprs_in(&**x_pm),
        crate::syntax::ExprKind::EMethod(r_pn, _, args_po) => append(&exprs_in(&**r_pn), &args_exprs(args_po)),
        crate::syntax::ExprKind::ETypeArgs(x_pp, _) => exprs_in(&**x_pp),
        crate::syntax::ExprKind::ECast(x_pq, _, _) => exprs_in(&**x_pq),
        crate::syntax::ExprKind::ELambda(_, body_pr) => match &**body_pr {
            crate::syntax::LambdaBody::LbExpr(x_ps) => exprs_in(&**x_ps),
            crate::syntax::LambdaBody::LbBlock(b_pt) => block_exprs(b_pt),
        },
        crate::syntax::ExprKind::EIf(c_pu, t_pv, el_o10) => append(&append(&cond_exprs(&**c_pu), &block_exprs(t_pv)), &opt_block_exprs(el_o10)),
        crate::syntax::ExprKind::EMatch(s_p11, arms_p12) => run_to_end(fold_job(arms_p12.clone(), exprs_in(&**s_p11), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arm)| entered(once_job(move || {
            let acc_p13 = p0;
            let a_p14 = p1;
            call_then(start_opt_exprs(a_p14.guard.clone()), move |opt_exprs_9600: Array<crate::syntax::Expr>| call_then(start_block_exprs(a_p14.body.clone()), move |block_exprs_9622: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc_p13, &opt_exprs_9600), &block_exprs_9622))))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::ERebuild(s_p15, b_p16) => append(&exprs_in(&**s_p15), &block_exprs(b_p16)),
        crate::syntax::ExprKind::EFor(_, s_p17, b_p18) => append(&exprs_in(&**s_p17), &block_exprs(b_p18)),
        crate::syntax::ExprKind::EGiven(b_p19) => block_exprs(b_p19),
        crate::syntax::ExprKind::EUpdate(t_p1a, b_p1b) => append(&exprs_in(&**t_p1a), &block_exprs(b_p1b)),
        crate::syntax::ExprKind::EWidgetBlock(b_p1c) => block_exprs(b_p1c),
        crate::syntax::ExprKind::EAny(x_p1d) => exprs_in(&**x_p1d),
        crate::syntax::ExprKind::ELit(l_p1e) => match &l_p1e.kind {
            crate::syntax::LitKind::LText(segs_p1f) => run_to_end(fold_job(segs_p1f.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TextSeg)| entered(once_job(move || {
                let acc_p1g = p0;
                let sg_p1h = p1;
                match &sg_p1h {
                    crate::syntax::TextSeg::SegPlaceholder(x_p1i) => {
                        let x_p1i = x_p1i.clone();
                        call_then(start_exprs_in(x_p1i.clone()), move |exprs_in_10051: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p1g, &exprs_in_10051)))
                    },
                    _ => prism_rtl::Turn::Finished(acc_p1g.clone()),
                }
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TextSeg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            _ => Array::new(),
        },
        crate::syntax::ExprKind::ETemplate(t_p1j) => template_exprs(&t_p1j.parts),
        _ => Array::new(),
    };
    match &*e_p0.kind {
        crate::syntax::ExprKind::ERest => inner_p1.clone(),
        crate::syntax::ExprKind::EError => inner_p1.clone(),
        _ => append(&Array::from(vec![e_p0.clone()]), &inner_p1),
    }
}

/// The step machine of `ExprsIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprsIn: unbounded fn Expr -> [Expr]
/// ```
pub struct ExprsIn {
    pub e_p0: crate::syntax::Expr,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for ExprsIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let e_p0 = &self.e_p0;
        let inner_p1 = match &*e_p0.kind {
            crate::syntax::ExprKind::ETuple(es_p2) => run_to_end(fold_job(es_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| entered(once_job(move || {
                let acc_p3 = p0;
                let x_p4 = p1;
                call_then(start_exprs_in(x_p4.clone()), move |exprs_in_8621: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p3, &exprs_in_8621)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::EArray(es_p5) => run_to_end(fold_job(es_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| entered(once_job(move || {
                let acc_p6 = p0;
                let x_p7 = p1;
                call_then(start_exprs_in(x_p7.clone()), move |exprs_in_8689: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p6, &exprs_in_8689)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::EMap(kvs_p8) => run_to_end(fold_job(kvs_p8.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))| entered(once_job(move || {
                let acc_p9 = p0;
                let (k_pa, v_pb) = p1;
                call_then(start_exprs_in(k_pa.clone()), move |exprs_in_8772: Array<crate::syntax::Expr>| call_then(start_exprs_in(v_pb.clone()), move |exprs_in_8786: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc_p9, &exprs_in_8772), &exprs_in_8786))))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::EGroup(x_pc) => exprs_in(&**x_pc),
            crate::syntax::ExprKind::ECall(c_pd, args_pe, _, _) => append(&exprs_in(&**c_pd), &args_exprs(args_pe)),
            crate::syntax::ExprKind::EBinary(_, l_pf, r_pg) => append(&exprs_in(&**l_pf), &exprs_in(&**r_pg)),
            crate::syntax::ExprKind::EUnary(_, x_ph) => exprs_in(&**x_ph),
            crate::syntax::ExprKind::EFreeSigil(_, x_pi) => exprs_in(&**x_pi),
            crate::syntax::ExprKind::EField(r_pj, _, _) => exprs_in(&**r_pj),
            crate::syntax::ExprKind::EIndex(r_pk, i_pl) => append(&exprs_in(&**r_pk), &exprs_in(&**i_pl)),
            crate::syntax::ExprKind::ETopicIndex(x_pm) => exprs_in(&**x_pm),
            crate::syntax::ExprKind::EMethod(r_pn, _, args_po) => append(&exprs_in(&**r_pn), &args_exprs(args_po)),
            crate::syntax::ExprKind::ETypeArgs(x_pp, _) => exprs_in(&**x_pp),
            crate::syntax::ExprKind::ECast(x_pq, _, _) => exprs_in(&**x_pq),
            crate::syntax::ExprKind::ELambda(_, body_pr) => match &**body_pr {
                crate::syntax::LambdaBody::LbExpr(x_ps) => exprs_in(&**x_ps),
                crate::syntax::LambdaBody::LbBlock(b_pt) => block_exprs(b_pt),
            },
            crate::syntax::ExprKind::EIf(c_pu, t_pv, el_o10) => append(&append(&cond_exprs(&**c_pu), &block_exprs(t_pv)), &opt_block_exprs(el_o10)),
            crate::syntax::ExprKind::EMatch(s_p11, arms_p12) => run_to_end(fold_job(arms_p12.clone(), exprs_in(&**s_p11), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arm)| entered(once_job(move || {
                let acc_p13 = p0;
                let a_p14 = p1;
                call_then(start_opt_exprs(a_p14.guard.clone()), move |opt_exprs_9600: Array<crate::syntax::Expr>| call_then(start_block_exprs(a_p14.body.clone()), move |block_exprs_9622: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc_p13, &opt_exprs_9600), &block_exprs_9622))))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::ERebuild(s_p15, b_p16) => append(&exprs_in(&**s_p15), &block_exprs(b_p16)),
            crate::syntax::ExprKind::EFor(_, s_p17, b_p18) => append(&exprs_in(&**s_p17), &block_exprs(b_p18)),
            crate::syntax::ExprKind::EGiven(b_p19) => block_exprs(b_p19),
            crate::syntax::ExprKind::EUpdate(t_p1a, b_p1b) => append(&exprs_in(&**t_p1a), &block_exprs(b_p1b)),
            crate::syntax::ExprKind::EWidgetBlock(b_p1c) => block_exprs(b_p1c),
            crate::syntax::ExprKind::EAny(x_p1d) => exprs_in(&**x_p1d),
            crate::syntax::ExprKind::ELit(l_p1e) => match &l_p1e.kind {
                crate::syntax::LitKind::LText(segs_p1f) => run_to_end(fold_job(segs_p1f.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TextSeg)| entered(once_job(move || {
                    let acc_p1g = p0;
                    let sg_p1h = p1;
                    match &sg_p1h {
                        crate::syntax::TextSeg::SegPlaceholder(x_p1i) => {
                            let x_p1i = x_p1i.clone();
                            call_then(start_exprs_in(x_p1i.clone()), move |exprs_in_10051: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p1g, &exprs_in_10051)))
                        },
                        _ => prism_rtl::Turn::Finished(acc_p1g.clone()),
                    }
                }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TextSeg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
                _ => Array::new(),
            },
            crate::syntax::ExprKind::ETemplate(t_p1j) => template_exprs(&t_p1j.parts),
            _ => Array::new(),
        };
        match &*e_p0.kind {
            crate::syntax::ExprKind::ERest => prism_rtl::Turn::Finished(inner_p1.clone()),
            crate::syntax::ExprKind::EError => prism_rtl::Turn::Finished(inner_p1.clone()),
            _ => prism_rtl::Turn::Finished(append(&Array::from(vec![e_p0.clone()]), &inner_p1)),
        }
    }
}

/// `Start ExprsIn, x`: what the function value is when passed to `@Run`.
pub fn start_exprs_in(e_p0: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(ExprsIn { e_p0 })
}

/// ```prism
/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
/// ```
pub fn template_exprs(parts_p0: &Array<crate::syntax::TemplatePart>) -> Array<crate::syntax::Expr> {
    run_to_end(fold_job(parts_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TemplatePart)| entered(once_job(move || {
        let acc_p1 = p0;
        let p_p2 = p1;
        match &p_p2 {
            crate::syntax::TemplatePart::TpPlaceholder(x_p3, _) => {
                let x_p3 = x_p3.clone();
                call_then(start_exprs_in(x_p3.clone()), move |exprs_in_10446: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p1, &exprs_in_10446)))
            },
            crate::syntax::TemplatePart::TpBlock(b_p4) => {
                let b_p4 = b_p4.clone();
                call_then(start_block_exprs(b_p4.clone()), move |block_exprs_10485: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p1, &block_exprs_10485)))
            },
            crate::syntax::TemplatePart::TpCall(_, args_p5, ps_o6, _) => {
                let ps_o6 = ps_o6.clone();
                let args_p5 = args_p5.clone();
                call_then(start_args_exprs(args_p5.clone()), move |args_exprs_10558: Array<crate::syntax::Expr>| call_then(start_opt_parts(ps_o6.clone()), move |opt_parts_10577: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc_p1, &args_exprs_10558), &opt_parts_10577))))
            },
            _ => prism_rtl::Turn::Finished(acc_p1.clone()),
        }
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>))
}

/// The step machine of `TemplateExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
/// ```
pub struct TemplateExprs {
    pub parts_p0: Array<crate::syntax::TemplatePart>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for TemplateExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let parts_p0 = &self.parts_p0;
        fold_job(parts_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TemplatePart)| entered(once_job(move || {
            let acc_p1 = p0;
            let p_p2 = p1;
            match &p_p2 {
                crate::syntax::TemplatePart::TpPlaceholder(x_p3, _) => {
                    let x_p3 = x_p3.clone();
                    call_then(start_exprs_in(x_p3.clone()), move |exprs_in_10446: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p1, &exprs_in_10446)))
                },
                crate::syntax::TemplatePart::TpBlock(b_p4) => {
                    let b_p4 = b_p4.clone();
                    call_then(start_block_exprs(b_p4.clone()), move |block_exprs_10485: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p1, &block_exprs_10485)))
                },
                crate::syntax::TemplatePart::TpCall(_, args_p5, ps_o6, _) => {
                    let ps_o6 = ps_o6.clone();
                    let args_p5 = args_p5.clone();
                    call_then(start_args_exprs(args_p5.clone()), move |args_exprs_10558: Array<crate::syntax::Expr>| call_then(start_opt_parts(ps_o6.clone()), move |opt_parts_10577: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc_p1, &args_exprs_10558), &opt_parts_10577))))
                },
                _ => prism_rtl::Turn::Finished(acc_p1.clone()),
            }
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle()
    }
}

/// `Start TemplateExprs, x`: what the function value is when passed to `@Run`.
pub fn start_template_exprs(parts_p0: Array<crate::syntax::TemplatePart>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(TemplateExprs { parts_p0 })
}

/// ```prism
/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
/// ```
pub fn opt_parts(opt0: &Option<Array<crate::syntax::TemplatePart>>) -> Array<crate::syntax::Expr> {
    match opt0 {
        Some(ps_p0) => template_exprs(ps_p0),
        None => Array::new(),
    }
}

/// The step machine of `OptParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
/// ```
pub struct OptParts {
    pub opt0: Option<Array<crate::syntax::TemplatePart>>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for OptParts {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(ps_p0) => prism_rtl::Turn::More(Rc::new(TemplateExprs { parts_p0: ps_p0.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptParts, x`: what the function value is when passed to `@Run`.
pub fn start_opt_parts(opt0: Option<Array<crate::syntax::TemplatePart>>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(OptParts { opt0 })
}

/// ```prism
/// OptBlockExprs: unbounded fn ?Block -> [Expr]
/// ```
pub fn opt_block_exprs(opt0: &Option<crate::syntax::Block>) -> Array<crate::syntax::Expr> {
    match opt0 {
        Some(b_p0) => block_exprs(b_p0),
        None => Array::new(),
    }
}

/// The step machine of `OptBlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptBlockExprs: unbounded fn ?Block -> [Expr]
/// ```
pub struct OptBlockExprs {
    pub opt0: Option<crate::syntax::Block>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for OptBlockExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(b_p0) => prism_rtl::Turn::More(Rc::new(BlockExprs { b_p0: b_p0.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptBlockExprs, x`: what the function value is when passed to `@Run`.
pub fn start_opt_block_exprs(opt0: Option<crate::syntax::Block>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(OptBlockExprs { opt0 })
}

/// ```prism
/// OptExprs: unbounded fn ?Expr -> [Expr]
/// ```
pub fn opt_exprs(opt0: &Option<crate::syntax::Expr>) -> Array<crate::syntax::Expr> {
    match opt0 {
        Some(x_p0) => exprs_in(x_p0),
        None => Array::new(),
    }
}

/// The step machine of `OptExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptExprs: unbounded fn ?Expr -> [Expr]
/// ```
pub struct OptExprs {
    pub opt0: Option<crate::syntax::Expr>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for OptExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(x_p0) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: x_p0.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptExprs, x`: what the function value is when passed to `@Run`.
pub fn start_opt_exprs(opt0: Option<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(OptExprs { opt0 })
}
