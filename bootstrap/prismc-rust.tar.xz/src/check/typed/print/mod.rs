//! The module `Check.Typed.Print`, from `target/bootstrap/src/prismc/check/typed/print.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// TySexp: unbounded fn Ty -> Text
/// ```
pub fn ty_sexp_f(t_p0: &crate::check::types::Ty) -> Text {
    match t_p0 {
        crate::check::types::Ty::TyFlex(n_p1) => Text::from(format!("(var t{})", n_p1)),
        crate::check::types::Ty::TyRigid(n_p2) => Text::from(format!("(rigid {})", n_p2)),
        crate::check::types::Ty::TyQ(n_p3) => Text::from(format!("(q {})", n_p3)),
        crate::check::types::Ty::TyCon(n_p4, m820_3_1) if (m820_3_1.len() == 0) => n_p4.clone(),
        crate::check::types::Ty::TyCon(n_p5, args_p6) => Text::from(format!("({}{})", n_p5, &crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(args_p6.clone(), Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_p7 = p0;
            crate::prelude::call_then(start_ty_sexp_f(a_p7.clone()), move |ty_sexp_f_979: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_f_979))))
        }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>))))),
        crate::check::types::Ty::TyFn(c_p8, ps_p9, res_pa) => Text::from(format!("(fn {} ({}) {})", &col_sexp_f(c_p8), &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_p9.clone(), Rc::new(|a0: crate::check::types::Ty| crate::prelude::entered(start_ty_sexp_f(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" ")), &ty_sexp_f(&**res_pa))),
        crate::check::types::Ty::TyTuple(ts_pb) => Text::from(format!("(tuple{})", &crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(ts_pb.clone(), Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_pc = p0;
            crate::prelude::call_then(start_ty_sexp_f(a_pc.clone()), move |ty_sexp_f_1128: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_f_1128))))
        }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>))))),
        crate::check::types::Ty::TyArray(e_pd) => Text::from(format!("(array {})", &ty_sexp_f(&**e_pd))),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => Text::from(format!("(map {} {})", &ty_sexp_f(&**k_pe), &ty_sexp_f(&**v_pf))),
        crate::check::types::Ty::TySig(s_pg, i_ph) => Text::from(format!("({} {})", s_pg, &ty_sexp_f(&**i_ph))),
        crate::check::types::Ty::TyAt(i_pi, rw_pj) => Text::from(format!("(@ {} {})", &ty_sexp_f(&**i_pi), &row_sexp_f(rw_pj))),
        crate::check::types::Ty::TyElem(rw_pk, o_pl) => Text::from(format!("(element {} {})", &row_sexp_f(rw_pk), &ty_sexp_f(&**o_pl))),
        crate::check::types::Ty::TyElemAny(rw_pm) => Text::from(format!("(elem {})", &row_sexp_f(rw_pm))),
        crate::check::types::Ty::TyAssoc(n_pn, a_po) => Text::from(format!("(assoc {} {})", n_pn, &ty_sexp_f(&**a_po))),
        crate::check::types::Ty::TyAny(trs_pp) => Text::from(format!("(any{})", &crate::prelude::concat(&crate::prelude::each(trs_pp, &(|x_pq: &Text| Text::from(format!(" ^{}", x_pq))))))),
        crate::check::types::Ty::TyErr => Text::lit("unknown"),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TySexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TySexp: unbounded fn Ty -> Text
/// ```
pub struct TySexp {
    pub t_p0: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for TySexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyFlex(n_p1) => prism_rtl::Turn::Finished(Text::from(format!("(var t{})", n_p1))),
            crate::check::types::Ty::TyRigid(n_p2) => prism_rtl::Turn::Finished(Text::from(format!("(rigid {})", n_p2))),
            crate::check::types::Ty::TyQ(n_p3) => prism_rtl::Turn::Finished(Text::from(format!("(q {})", n_p3))),
            crate::check::types::Ty::TyCon(n_p4, m820_3_1) if (m820_3_1.len() == 0) => prism_rtl::Turn::Finished(n_p4.clone()),
            crate::check::types::Ty::TyCon(n_p5, args_p6) => {
                let args_p6x = args_p6.clone();
                let n_p5x = n_p5.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p6x.clone(), Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p7 = p0;
                    crate::prelude::call_then(start_ty_sexp_f(a_p7.clone()), move |ty_sexp_f_979: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_f_979))))
                }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_960: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({}{})", &n_p5x, &crate::prelude::concat(&each_960)))))
            },
            crate::check::types::Ty::TyFn(c_p8, ps_p9, res_pa) => {
                let c_p8x = c_p8.clone();
                let ps_p9x = ps_p9.clone();
                let res_pax = (**res_pa).clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_p9x.clone(), Rc::new(|a0: crate::check::types::Ty| crate::prelude::entered(start_ty_sexp_f(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_1040: Array<Text>| crate::prelude::call_then(start_ty_sexp_f(res_pax.clone()), move |ty_sexp_f_1065: Text| prism_rtl::Turn::Finished(Text::from(format!("(fn {} ({}) {})", &col_sexp_f(&c_p8x), &crate::syntax::lexer::chars::join_f(&each_1040, &Text::lit(" ")), &ty_sexp_f_1065)))))
            },
            crate::check::types::Ty::TyTuple(ts_pb) => {
                let ts_pbx = ts_pb.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_pbx.clone(), Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pc = p0;
                    crate::prelude::call_then(start_ty_sexp_f(a_pc.clone()), move |ty_sexp_f_1128: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_f_1128))))
                }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_1111: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("(tuple{})", &crate::prelude::concat(&each_1111)))))
            },
            crate::check::types::Ty::TyArray(e_pd) => {
                let e_pdx = (**e_pd).clone();
                crate::prelude::call_then(start_ty_sexp_f(e_pdx.clone()), move |ty_sexp_f_1167: Text| prism_rtl::Turn::Finished(Text::from(format!("(array {})", &ty_sexp_f_1167))))
            },
            crate::check::types::Ty::TyMap(k_pe, v_pf) => {
                let k_pex = (**k_pe).clone();
                let v_pfx = (**v_pf).clone();
                crate::prelude::call_then(start_ty_sexp_f(k_pex.clone()), move |ty_sexp_f_1202: Text| crate::prelude::call_then(start_ty_sexp_f(v_pfx.clone()), move |ty_sexp_f_1213: Text| prism_rtl::Turn::Finished(Text::from(format!("(map {} {})", &ty_sexp_f_1202, &ty_sexp_f_1213)))))
            },
            crate::check::types::Ty::TySig(s_pg, i_ph) => {
                let i_phx = (**i_ph).clone();
                let s_pgx = s_pg.clone();
                crate::prelude::call_then(start_ty_sexp_f(i_phx.clone()), move |ty_sexp_f_1248: Text| prism_rtl::Turn::Finished(Text::from(format!("({} {})", &s_pgx, &ty_sexp_f_1248))))
            },
            crate::check::types::Ty::TyAt(i_pi, rw_pj) => {
                let i_pix = (**i_pi).clone();
                let rw_pjx = rw_pj.clone();
                crate::prelude::call_then(start_ty_sexp_f(i_pix.clone()), move |ty_sexp_f_1281: Text| prism_rtl::Turn::Finished(Text::from(format!("(@ {} {})", &ty_sexp_f_1281, &row_sexp_f(&rw_pjx)))))
            },
            crate::check::types::Ty::TyElem(rw_pk, o_pl) => {
                let o_plx = (**o_pl).clone();
                let rw_pkx = rw_pk.clone();
                crate::prelude::call_then(start_ty_sexp_f(o_plx.clone()), move |ty_sexp_f_1348: Text| prism_rtl::Turn::Finished(Text::from(format!("(element {} {})", &row_sexp_f(&rw_pkx), &ty_sexp_f_1348))))
            },
            crate::check::types::Ty::TyElemAny(rw_pm) => prism_rtl::Turn::Finished(Text::from(format!("(elem {})", &row_sexp_f(rw_pm)))),
            crate::check::types::Ty::TyAssoc(n_pn, a_po) => {
                let a_pox = (**a_po).clone();
                let n_pnx = n_pn.clone();
                crate::prelude::call_then(start_ty_sexp_f(a_pox.clone()), move |ty_sexp_f_1431: Text| prism_rtl::Turn::Finished(Text::from(format!("(assoc {} {})", &n_pnx, &ty_sexp_f_1431))))
            },
            crate::check::types::Ty::TyAny(trs_pp) => prism_rtl::Turn::Finished(Text::from(format!("(any{})", &crate::prelude::concat(&crate::prelude::each(trs_pp, &(|x_pq: &Text| Text::from(format!(" ^{}", x_pq)))))))),
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished(Text::lit("unknown")),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TySexp, x`: what the function value is when passed to `@Run`.
pub fn start_ty_sexp_f(t_p0: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TySexp { t_p0 })
}

/// ```prism
/// ColSexp: fn Col -> Text
/// ```
pub fn col_sexp_f(col0: &crate::check::types::Col) -> Text {
    match col0 {
        crate::check::types::Col::CBound => Text::lit("bounded"),
        crate::check::types::Col::CUnbound => Text::lit("unbounded"),
        crate::check::types::Col::CRigid(n_p0) => Text::from(format!("(color {})", n_p0)),
        crate::check::types::Col::CQ(n_p1) => Text::from(format!("(color {})", n_p1)),
        crate::check::types::Col::CFlex(n_p2) => Text::from(format!("(color c{})", n_p2)),
    }
}

/// ```prism
/// RowSexp: fn Rw -> Text
/// ```
pub fn row_sexp_f(rw_p0: &crate::check::types::Rw) -> Text {
    let tail_p1 = match &rw_p0.tail_p {
        crate::check::types::Tail::TlClosed => Text::lit(""),
        crate::check::types::Tail::TlFlex(n_p3) => Text::from(format!(" (tail r{})", n_p3)),
        crate::check::types::Tail::TlRigid(n_p4) => Text::from(format!(" (tail {})", n_p4)),
        crate::check::types::Tail::TlQ(n_p5) => Text::from(format!(" (tail {})", n_p5)),
    };
    let minus_p2 = if &crate::prelude::len(&rw_p0.minus_p) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (minus{})", &crate::prelude::concat(&crate::prelude::each(&rw_p0.minus_p, &(|m_p6: &Text| Text::from(format!(" {}", m_p6)))))))
    };
    Text::from(format!("(row{}{}{})", &crate::prelude::concat(&crate::prelude::each(&rw_p0.fams_p, &(|f_p7: &Text| Text::from(format!(" {}.*", f_p7))))), &tail_p1, &minus_p2))
}

/// ```prism
/// SchemeSexp: unbounded fn Scheme -> Text
/// ```
pub fn scheme_sexp_f(sc_p0: &crate::check::types::Scheme) -> Text {
    let qs_p1 = if &crate::prelude::len(&sc_p0.qs_p) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (forall{})", &crate::prelude::concat(&crate::prelude::each(&sc_p0.qs_p, &(|q_p5: &Text| Text::from(format!(" {}", q_p5)))))))
    };
    let rqs_p2 = if &crate::prelude::len(&sc_p0.rqs_p) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (rows{})", &crate::prelude::concat(&crate::prelude::each(&sc_p0.rqs_p, &(|q_p6: &Text| Text::from(format!(" {}", q_p6)))))))
    };
    let cqs_p3 = if &crate::prelude::len(&sc_p0.cqs_p) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (colors{})", &crate::prelude::concat(&crate::prelude::each(&sc_p0.cqs_p, &(|q_p7: &Text| Text::from(format!(" {}", q_p7)))))))
    };
    let bs_p4 = if &crate::prelude::len(&sc_p0.bounds_p) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (where{})", &crate::prelude::concat(&crate::prelude::each(&sc_p0.bounds_p, &(|(v_p8, c_p9): &(Text, Text)| Text::from(format!(" {}:^{}", v_p8, c_p9)))))))
    };
    Text::from(format!("(scheme{}{}{}{} {})", &qs_p1, &rqs_p2, &cqs_p3, &bs_p4, &ty_sexp_f(&sc_p0.ty_p)))
}

/// The step machine of `SchemeSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SchemeSexp: unbounded fn Scheme -> Text
/// ```
pub struct SchemeSexp {
    pub sc_p0: crate::check::types::Scheme,
}

impl prism_rtl::Job<Text> for SchemeSexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let sc_p0 = &self.sc_p0;
        let qs_p1 = if &crate::prelude::len(&sc_p0.qs_p) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (forall{})", &crate::prelude::concat(&crate::prelude::each(&sc_p0.qs_p, &(|q_p5: &Text| Text::from(format!(" {}", q_p5)))))))
        };
        let rqs_p2 = if &crate::prelude::len(&sc_p0.rqs_p) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (rows{})", &crate::prelude::concat(&crate::prelude::each(&sc_p0.rqs_p, &(|q_p6: &Text| Text::from(format!(" {}", q_p6)))))))
        };
        let cqs_p3 = if &crate::prelude::len(&sc_p0.cqs_p) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (colors{})", &crate::prelude::concat(&crate::prelude::each(&sc_p0.cqs_p, &(|q_p7: &Text| Text::from(format!(" {}", q_p7)))))))
        };
        let bs_p4 = if &crate::prelude::len(&sc_p0.bounds_p) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (where{})", &crate::prelude::concat(&crate::prelude::each(&sc_p0.bounds_p, &(|(v_p8, c_p9): &(Text, Text)| Text::from(format!(" {}:^{}", v_p8, c_p9)))))))
        };
        let sc_p0x = sc_p0.clone();
        crate::prelude::call_then(start_ty_sexp_f(sc_p0x.ty_p.clone()), move |ty_sexp_f_2534: Text| prism_rtl::Turn::Finished(Text::from(format!("(scheme{}{}{}{} {})", &qs_p1, &rqs_p2, &cqs_p3, &bs_p4, &ty_sexp_f_2534))))
    }
}

/// `Start SchemeSexp, x`: what the function value is when passed to `@Run`.
pub fn start_scheme_sexp_f(sc_p0: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(SchemeSexp { sc_p0 })
}

/// ```prism
/// AtText: fn [Src], SrcAt -> Text
/// ```
pub fn at_text_f(srcs_p0: &Array<crate::check::errors::Src>, a_p1: &crate::check::typed::SrcAt) -> Text {
    match crate::prelude::index(srcs_p0, &a_p1.file_p) {
        None => Text::from(format!("?:{}", &a_p1.span_p.start_p)),
        Some(src_p2) => Text::from(format!("{}:{}-{}", &crate::check::errors::seg_at_f(&src_p2, &a_p1.span_p.start_p).path_p, &pos_text_f(&src_p2, &a_p1.span_p.start_p), &pos_text_f(&src_p2, &a_p1.span_p.end_p))),
    }
}

/// ```prism
/// PosText: fn Src, Nat -> Text
/// ```
pub fn pos_text_f(src_p0: &crate::check::errors::Src, offset_p1: &Nat) -> Text {
    let line_p2 = crate::check::errors::cline_of_f(&src_p0.starts_p, offset_p1);
    let col_p3 = crate::syntax::lexer::chars::column_of_f(&src_p0.text_p, &crate::prelude::or(&crate::prelude::index(&src_p0.starts_p, &line_p2), &Nat::from(0u32)), offset_p1);
    Text::from(format!("{}:{}", &(&crate::prelude::or(&(&line_p2).checked_sub(&crate::check::errors::seg_at_f(src_p0, offset_p1).line_p), &Nat::from(0u32)) + &Nat::from(1u32)), &(&col_p3 + &Nat::from(1u32))))
}

/// ```prism
/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
/// ```
pub fn typed_sexp_f(srcs_p0: &Array<crate::check::errors::Src>, trees_p1: &Array<crate::syntax::Module>, shown_p2: &Nat, tp_p3: &crate::check::typed::TProgram) -> Text {
    let tys_p4 = crate::prelude::fold(&tp_p3.exprs_p, &Map::new(), &(|m_pk: &Map<Text, crate::check::types::Ty>, n_pl: &crate::check::typed::TyNote| crate::prelude::insert(m_pk, &crate::check::typed::at_key_f(&n_pl.at_p), &n_pl.ty_p)));
    let files_p5 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(trees_p1)), &(|i_pm: &Nat| i_pm < shown_p2));
    let defs_p6 = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&tp_p3.defs_p, &(|d_pn: &crate::check::typed::DefNote| &d_pn.at_p.file_p < shown_p2)), {
        let srcs_p0x = srcs_p0.clone();
        Rc::new(move |p0: crate::check::typed::DefNote| {
            let srcs_p0xy = srcs_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let d_po = p0;
                crate::prelude::call_then(start_scheme_sexp_f(d_po.scheme_p.clone()), move |scheme_sexp_f_3620: Text| prism_rtl::Turn::Finished(Text::from(format!("  (def {} {} {})\n", &d_po.name_p, &at_text_f(&srcs_p0xy, &d_po.at_p), &scheme_sexp_f_3620))))
            }))
        }) as Rc<dyn Fn(crate::check::typed::DefNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let exprs_p7 = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(files_p5.clone(), {
        let srcs_p0x = srcs_p0.clone();
        let tys_p4x = tys_p4.clone();
        let trees_p1x = trees_p1.clone();
        Rc::new(move |p0: Nat| {
            let srcs_p0xy = srcs_p0x.clone();
            let tys_p4xy = tys_p4x.clone();
            let trees_p1xy = trees_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pp = p0;
                prism_rtl::Turn::More(Rc::new(ExprsOfFile { srcs_p0: srcs_p0xy.clone(), tys_p1: tys_p4xy.clone(), file_p2: i_pp.clone(), m_p3: crate::prelude::or(&crate::prelude::index(&trees_p1xy, &i_pp), &empty_mod_p()) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let mine_f8 = {
        let shown_p2x = shown_p2.clone();
        Rc::new(move |a_pq: &crate::check::typed::SrcAt| shown_f(a_pq, &shown_p2x)) as Rc<dyn Fn(&crate::check::typed::SrcAt) -> bool>
    };
    let apps_p9 = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3.apps_p, &(|x_pr: &crate::check::typed::AppNote| (&mine_f8)(&x_pr.at_p))), &(|x_ps: &crate::check::typed::AppNote| Text::from(format!("  (app {} {} {} {} (lifted{}) {} {})\n", &at_text_f(srcs_p0, &x_ps.at_p), &quote_f(&x_ps.callee_p), &x_ps.kind_p, &layer_word_f(&x_ps.layer_p), &crate::prelude::concat(&crate::prelude::each(&x_ps.lifted_p, &(|i_pt: &Nat| Text::from(format!(" {}", i_pt))))), &layer_word_f(&x_ps.inner_p), &col_sexp_f(&x_ps.color_p))))));
    let lifts_pa = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3.lifts_p, &(|x_pu: &crate::check::typed::LiftNote| (&mine_f8)(&x_pu.at_p))), &(|x_pv: &crate::check::typed::LiftNote| Text::from(format!("  (lift {} {}{})\n", &at_text_f(srcs_p0, &x_pv.at_p), &x_pv.sigil_p, &crate::prelude::concat(&crate::prelude::each(&x_pv.operands_p, &(|r_p10: &crate::syntax::Range| Text::from(format!(" {}", &at_text_f(srcs_p0, &crate::check::typed::SrcAt { file_p: x_pv.at_p.file_p.clone(), span_p: r_p10.clone() })))))))))));
    let fns_pb = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3.fns_p, &(|x_p11: &crate::check::typed::FnNote| (&mine_f8)(&x_p11.at_p))), &(|x_p12: &crate::check::typed::FnNote| Text::from(format!("  (fn {} {} {} {})\n", &quote_f(&x_p12.name_p), &at_text_f(srcs_p0, &x_p12.at_p), &col_sexp_f(&x_p12.declared_p), &col_sexp_f(&x_p12.body_p))))));
    let methods_pc = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3.methods_p, &(|x_p13: &crate::check::typed::MethodNote| (&mine_f8)(&x_p13.at_p))), &(|x_p14: &crate::check::typed::MethodNote| Text::from(format!("  (method {} {} ^{})\n", &at_text_f(srcs_p0, &x_p14.at_p), &x_p14.method_p, &x_p14.cls_p)))));
    let impls_pd = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&tp_p3.impls_p, &(|x_p15: &crate::check::typed::ImplNote| (&mine_f8)(&x_p15.at_p))), {
        let srcs_p0x = srcs_p0.clone();
        Rc::new(move |p0: crate::check::typed::ImplNote| {
            let srcs_p0xy = srcs_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_p16 = p0;
                crate::prelude::call_then(start_ty_sexp_f(x_p16.ty_p.clone()), move |ty_sexp_f_4583: Text| prism_rtl::Turn::Finished(Text::from(format!("  (impl {} ^{} {} {})\n", &at_text_f(&srcs_p0xy, &x_p16.at_p), &x_p16.cls_p, &ty_sexp_f_4583, &x_p16.how_p))))
            }))
        }) as Rc<dyn Fn(crate::check::typed::ImplNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let groups_pe = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3.groups_p, &(|x_p17: &crate::check::typed::GroupNote| (&mine_f8)(&x_p17.at_p))), &(|x_p18: &crate::check::typed::GroupNote| Text::from(format!("  (group {} {}{})\n", &x_p18.kind_p, &at_text_f(srcs_p0, &x_p18.at_p), &crate::prelude::concat(&crate::prelude::each(&x_p18.order_p, &(|c_p19: &Array<Nat>| Text::from(format!(" ({})", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(c_p19, &(|i_p1a: &Nat| Text::from(format!("{}", i_p1a)))), &Text::lit(" "))))))))))));
    let binders_pf = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&tp_p3.binders_p, &(|x_p1b: &crate::check::typed::BinderNote| (&mine_f8)(&x_p1b.at_p))), {
        let srcs_p0x = srcs_p0.clone();
        Rc::new(move |p0: crate::check::typed::BinderNote| {
            let srcs_p0xy = srcs_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_p1c = p0;
                crate::prelude::call_then(start_ty_sexp_f(x_p1c.ty_p.clone()), move |ty_sexp_f_4911: Text| prism_rtl::Turn::Finished(Text::from(format!("  (binder {} {} {})\n", &quote_f(&x_p1c.name_p), &at_text_f(&srcs_p0xy, &x_p1c.at_p), &ty_sexp_f_4911))))
            }))
        }) as Rc<dyn Fn(crate::check::typed::BinderNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let locals_pg = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3.locals_p, &(|x_p1d: &crate::check::typed::LocalNote| (&mine_f8)(&x_p1d.at_p))), &(|x_p1e: &crate::check::typed::LocalNote| Text::from(format!("  (local {} {})\n", &x_p1e.id_p, &at_text_f(srcs_p0, &x_p1e.at_p))))));
    let uses_ph = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3.uses_p, &(|x_p1f: &crate::check::typed::LocalNote| (&mine_f8)(&x_p1f.at_p))), &(|x_p1g: &crate::check::typed::LocalNote| Text::from(format!("  (use {} {})\n", &x_p1g.id_p, &at_text_f(srcs_p0, &x_p1g.at_p))))));
    let gens_pi = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3.gens_p, &(|x_p1h: &crate::check::typed::GenNote| (&mine_f8)(&x_p1h.at_p))), &(|x_p1i: &crate::check::typed::GenNote| Text::from(format!("  (gen {} {}{}{})\n", &quote_f(&x_p1i.name_p), &at_text_f(srcs_p0, &x_p1i.at_p), &crate::prelude::concat(&crate::prelude::each(&x_p1i.tys_p, &(|q_p1j: &Text| Text::from(format!(" {}", q_p1j))))), &crate::prelude::concat(&crate::prelude::each(&x_p1i.cols_p, &(|q_p1k: &Text| Text::from(format!(" {}", q_p1k))))))))));
    let insts_pj = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&tp_p3.insts_p, &(|x_p1l: &crate::check::typed::InstNote| (&mine_f8)(&x_p1l.at_p))), {
        let srcs_p0x = srcs_p0.clone();
        Rc::new(move |p0: crate::check::typed::InstNote| {
            let srcs_p0xy = srcs_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_p1m = p0;
                crate::prelude::call_value(crate::prelude::each_job(x_p1m.tys_p.clone(), Rc::new(move |p0: (Text, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (q_p1n, t_p1o) = p0;
                    crate::prelude::call_then(start_ty_sexp_f(t_p1o.clone()), move |ty_sexp_f_5486: Text| prism_rtl::Turn::Finished(Text::from(format!(" ({} {})", &q_p1n, &ty_sexp_f_5486))))
                }))) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5454: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("  (inst {} {}{}{})\n", &quote_f(&x_p1m.name_p), &at_text_f(&srcs_p0xy, &x_p1m.at_p), &crate::prelude::concat(&each_5454), &crate::prelude::concat(&crate::prelude::each(&x_p1m.cols_p, &(|(q_p1p, c_p1q): &(Text, crate::check::types::Col)| Text::from(format!(" ({} {})", q_p1p, &col_sexp_f(c_p1q))))))))))
            }))
        }) as Rc<dyn Fn(crate::check::typed::InstNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    Text::from(format!("(typed\n (defs\n{} )\n (exprs\n{} )\n (apps\n{} )\n (lifts\n{} )\n (fns\n{} )\n (methods\n{} )\n (impls\n{} )\n (groups\n{} )\n (binders\n{} )\n (locals\n{} )\n (uses\n{} )\n (gens\n{} )\n (insts\n{} ))\n", &defs_p6, &exprs_p7, &apps_p9, &lifts_pa, &fns_pb, &methods_pc, &impls_pd, &groups_pe, &binders_pf, &locals_pg, &uses_ph, &gens_pi, &insts_pj))
}

/// The step machine of `TypedSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
/// ```
pub struct TypedSexp {
    pub srcs_p0: Array<crate::check::errors::Src>,
    pub trees_p1: Array<crate::syntax::Module>,
    pub shown_p2: Nat,
    pub tp_p3: crate::check::typed::TProgram,
}

impl prism_rtl::Job<Text> for TypedSexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs_p0 = &self.srcs_p0;
        let trees_p1 = &self.trees_p1;
        let shown_p2 = &self.shown_p2;
        let tp_p3 = &self.tp_p3;
        let tys_p4 = crate::prelude::fold(&tp_p3.exprs_p, &Map::new(), &(|m_pk: &Map<Text, crate::check::types::Ty>, n_pl: &crate::check::typed::TyNote| crate::prelude::insert(m_pk, &crate::check::typed::at_key_f(&n_pl.at_p), &n_pl.ty_p)));
        let files_p5 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(trees_p1)), &(|i_pm: &Nat| i_pm < shown_p2));
        let shown_p2x = shown_p2.clone();
        let srcs_p0x = srcs_p0.clone();
        let tp_p3x = tp_p3.clone();
        let trees_p1x = trees_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(&tp_p3x.defs_p, &(|d_pn: &crate::check::typed::DefNote| &d_pn.at_p.file_p < &shown_p2x)), {
            let srcs_p0xx = srcs_p0x.clone();
            Rc::new(move |p0: crate::check::typed::DefNote| {
                let srcs_p0xxy = srcs_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let d_po = p0;
                    crate::prelude::call_then(start_scheme_sexp_f(d_po.scheme_p.clone()), move |scheme_sexp_f_3620: Text| prism_rtl::Turn::Finished(Text::from(format!("  (def {} {} {})\n", &d_po.name_p, &at_text_f(&srcs_p0xxy, &d_po.at_p), &scheme_sexp_f_3620))))
                }))
            }) as Rc<dyn Fn(crate::check::typed::DefNote) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_3530: Array<Text>| {
            let defs_p6 = crate::prelude::concat(&each_3530);
            crate::prelude::call_value(crate::prelude::each_job(files_p5.clone(), {
                let srcs_p0xx = srcs_p0x.clone();
                let tys_p4x = tys_p4.clone();
                let trees_p1xx = trees_p1x.clone();
                Rc::new(move |p0: Nat| {
                    let srcs_p0xxy = srcs_p0xx.clone();
                    let tys_p4xy = tys_p4x.clone();
                    let trees_p1xxy = trees_p1xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pp = p0;
                        prism_rtl::Turn::More(Rc::new(ExprsOfFile { srcs_p0: srcs_p0xxy.clone(), tys_p1: tys_p4xy.clone(), file_p2: i_pp.clone(), m_p3: crate::prelude::or(&crate::prelude::index(&trees_p1xxy, &i_pp), &empty_mod_p()) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_3670: Array<Text>| {
                let exprs_p7 = crate::prelude::concat(&each_3670);
                let mine_f8 = {
                    let shown_p2xx = shown_p2x.clone();
                    Rc::new(move |a_pq: &crate::check::typed::SrcAt| shown_f(a_pq, &shown_p2xx)) as Rc<dyn Fn(&crate::check::typed::SrcAt) -> bool>
                };
                let apps_p9 = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3x.apps_p, &(|x_pr: &crate::check::typed::AppNote| (&mine_f8)(&x_pr.at_p))), &(|x_ps: &crate::check::typed::AppNote| Text::from(format!("  (app {} {} {} {} (lifted{}) {} {})\n", &at_text_f(&srcs_p0x, &x_ps.at_p), &quote_f(&x_ps.callee_p), &x_ps.kind_p, &layer_word_f(&x_ps.layer_p), &crate::prelude::concat(&crate::prelude::each(&x_ps.lifted_p, &(|i_pt: &Nat| Text::from(format!(" {}", i_pt))))), &layer_word_f(&x_ps.inner_p), &col_sexp_f(&x_ps.color_p))))));
                let lifts_pa = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3x.lifts_p, &(|x_pu: &crate::check::typed::LiftNote| (&mine_f8)(&x_pu.at_p))), &(|x_pv: &crate::check::typed::LiftNote| Text::from(format!("  (lift {} {}{})\n", &at_text_f(&srcs_p0x, &x_pv.at_p), &x_pv.sigil_p, &crate::prelude::concat(&crate::prelude::each(&x_pv.operands_p, &(|r_p10: &crate::syntax::Range| Text::from(format!(" {}", &at_text_f(&srcs_p0x, &crate::check::typed::SrcAt { file_p: x_pv.at_p.file_p.clone(), span_p: r_p10.clone() })))))))))));
                let fns_pb = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3x.fns_p, &(|x_p11: &crate::check::typed::FnNote| (&mine_f8)(&x_p11.at_p))), &(|x_p12: &crate::check::typed::FnNote| Text::from(format!("  (fn {} {} {} {})\n", &quote_f(&x_p12.name_p), &at_text_f(&srcs_p0x, &x_p12.at_p), &col_sexp_f(&x_p12.declared_p), &col_sexp_f(&x_p12.body_p))))));
                let methods_pc = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3x.methods_p, &(|x_p13: &crate::check::typed::MethodNote| (&mine_f8)(&x_p13.at_p))), &(|x_p14: &crate::check::typed::MethodNote| Text::from(format!("  (method {} {} ^{})\n", &at_text_f(&srcs_p0x, &x_p14.at_p), &x_p14.method_p, &x_p14.cls_p)))));
                crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(&tp_p3x.impls_p, &(|x_p15: &crate::check::typed::ImplNote| (&mine_f8)(&x_p15.at_p))), {
                    let srcs_p0xx = srcs_p0x.clone();
                    Rc::new(move |p0: crate::check::typed::ImplNote| {
                        let srcs_p0xxy = srcs_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let x_p16 = p0;
                            crate::prelude::call_then(start_ty_sexp_f(x_p16.ty_p.clone()), move |ty_sexp_f_4583: Text| prism_rtl::Turn::Finished(Text::from(format!("  (impl {} ^{} {} {})\n", &at_text_f(&srcs_p0xxy, &x_p16.at_p), &x_p16.cls_p, &ty_sexp_f_4583, &x_p16.how_p))))
                        }))
                    }) as Rc<dyn Fn(crate::check::typed::ImplNote) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_4499: Array<Text>| {
                    let impls_pd = crate::prelude::concat(&each_4499);
                    let groups_pe = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3x.groups_p, &(|x_p17: &crate::check::typed::GroupNote| (&mine_f8)(&x_p17.at_p))), &(|x_p18: &crate::check::typed::GroupNote| Text::from(format!("  (group {} {}{})\n", &x_p18.kind_p, &at_text_f(&srcs_p0x, &x_p18.at_p), &crate::prelude::concat(&crate::prelude::each(&x_p18.order_p, &(|c_p19: &Array<Nat>| Text::from(format!(" ({})", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(c_p19, &(|i_p1a: &Nat| Text::from(format!("{}", i_p1a)))), &Text::lit(" "))))))))))));
                    crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(&tp_p3x.binders_p, &(|x_p1b: &crate::check::typed::BinderNote| (&mine_f8)(&x_p1b.at_p))), {
                        let srcs_p0xx = srcs_p0x.clone();
                        Rc::new(move |p0: crate::check::typed::BinderNote| {
                            let srcs_p0xxy = srcs_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let x_p1c = p0;
                                crate::prelude::call_then(start_ty_sexp_f(x_p1c.ty_p.clone()), move |ty_sexp_f_4911: Text| prism_rtl::Turn::Finished(Text::from(format!("  (binder {} {} {})\n", &quote_f(&x_p1c.name_p), &at_text_f(&srcs_p0xxy, &x_p1c.at_p), &ty_sexp_f_4911))))
                            }))
                        }) as Rc<dyn Fn(crate::check::typed::BinderNote) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_4817: Array<Text>| {
                        let binders_pf = crate::prelude::concat(&each_4817);
                        let locals_pg = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3x.locals_p, &(|x_p1d: &crate::check::typed::LocalNote| (&mine_f8)(&x_p1d.at_p))), &(|x_p1e: &crate::check::typed::LocalNote| Text::from(format!("  (local {} {})\n", &x_p1e.id_p, &at_text_f(&srcs_p0x, &x_p1e.at_p))))));
                        let uses_ph = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3x.uses_p, &(|x_p1f: &crate::check::typed::LocalNote| (&mine_f8)(&x_p1f.at_p))), &(|x_p1g: &crate::check::typed::LocalNote| Text::from(format!("  (use {} {})\n", &x_p1g.id_p, &at_text_f(&srcs_p0x, &x_p1g.at_p))))));
                        let gens_pi = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&tp_p3x.gens_p, &(|x_p1h: &crate::check::typed::GenNote| (&mine_f8)(&x_p1h.at_p))), &(|x_p1i: &crate::check::typed::GenNote| Text::from(format!("  (gen {} {}{}{})\n", &quote_f(&x_p1i.name_p), &at_text_f(&srcs_p0x, &x_p1i.at_p), &crate::prelude::concat(&crate::prelude::each(&x_p1i.tys_p, &(|q_p1j: &Text| Text::from(format!(" {}", q_p1j))))), &crate::prelude::concat(&crate::prelude::each(&x_p1i.cols_p, &(|q_p1k: &Text| Text::from(format!(" {}", q_p1k))))))))));
                        crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(&tp_p3x.insts_p, &(|x_p1l: &crate::check::typed::InstNote| (&mine_f8)(&x_p1l.at_p))), {
                            let srcs_p0xx = srcs_p0x.clone();
                            Rc::new(move |p0: crate::check::typed::InstNote| {
                                let srcs_p0xxy = srcs_p0xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let x_p1m = p0;
                                    crate::prelude::call_value(crate::prelude::each_job(x_p1m.tys_p.clone(), Rc::new(move |p0: (Text, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (q_p1n, t_p1o) = p0;
                                        crate::prelude::call_then(start_ty_sexp_f(t_p1o.clone()), move |ty_sexp_f_5486: Text| prism_rtl::Turn::Finished(Text::from(format!(" ({} {})", &q_p1n, &ty_sexp_f_5486))))
                                    }))) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5454: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("  (inst {} {}{}{})\n", &quote_f(&x_p1m.name_p), &at_text_f(&srcs_p0xxy, &x_p1m.at_p), &crate::prelude::concat(&each_5454), &crate::prelude::concat(&crate::prelude::each(&x_p1m.cols_p, &(|(q_p1p, c_p1q): &(Text, crate::check::types::Col)| Text::from(format!(" ({} {})", q_p1p, &col_sexp_f(c_p1q))))))))))
                                }))
                            }) as Rc<dyn Fn(crate::check::typed::InstNote) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_5357: Array<Text>| {
                            let insts_pj = crate::prelude::concat(&each_5357);
                            prism_rtl::Turn::Finished(Text::from(format!("(typed\n (defs\n{} )\n (exprs\n{} )\n (apps\n{} )\n (lifts\n{} )\n (fns\n{} )\n (methods\n{} )\n (impls\n{} )\n (groups\n{} )\n (binders\n{} )\n (locals\n{} )\n (uses\n{} )\n (gens\n{} )\n (insts\n{} ))\n", &defs_p6, &exprs_p7, &apps_p9, &lifts_pa, &fns_pb, &methods_pc, &impls_pd, &groups_pe, &binders_pf, &locals_pg, &uses_ph, &gens_pi, &insts_pj)))
                        })
                    })
                })
            })
        })
    }
}

/// `Start TypedSexp, x`: what the function value is when passed to `@Run`.
pub fn start_typed_sexp_f(srcs_p0: Array<crate::check::errors::Src>, trees_p1: Array<crate::syntax::Module>, shown_p2: Nat, tp_p3: crate::check::typed::TProgram) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypedSexp { srcs_p0, trees_p1, shown_p2, tp_p3 })
}

/// ```prism
/// Shown: fn SrcAt, Nat -> Bool
/// ```
pub fn shown_f(a_p0: &crate::check::typed::SrcAt, shown_p1: &Nat) -> bool {
    &a_p0.file_p < shown_p1
}

/// ```prism
/// let emptyMod
/// ```
pub fn empty_mod_p() -> crate::syntax::Module {
    crate::syntax::Module { name_o: None, emit_row_o: None, mods_p: Array::new(), uses_p: Array::new(), decls_p: Array::new(), template_o: None, span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }
}

/// ```prism
/// Quote: fn Text -> Text
/// ```
pub fn quote_f(t_p0: &Text) -> Text {
    Text::from(format!("\"{}\"", t_p0))
}

/// ```prism
/// LayerWord: fn Text -> Text
/// ```
pub fn layer_word_f(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("")) => Text::lit("-"),
        s_p0 => s_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
/// ```
pub fn exprs_of_file_f(srcs_p0: &Array<crate::check::errors::Src>, tys_p1: &Map<Text, crate::check::types::Ty>, file_p2: &Nat, m_p3: &crate::syntax::Module) -> Text {
    let es_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(m_p3.decls_p.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::Decl)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p5 = p0;
        let d_p6 = p1;
        crate::prelude::call_then(start_decl_exprs_f(d_p6.clone()), move |decl_exprs_f_6366: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &decl_exprs_f_6366)))
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>));
    crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(es_p4.clone(), {
        let srcs_p0x = srcs_p0.clone();
        let tys_p1x = tys_p1.clone();
        let file_p2x = file_p2.clone();
        Rc::new(move |p0: crate::syntax::Expr| {
            let srcs_p0xy = srcs_p0x.clone();
            let tys_p1xy = tys_p1x.clone();
            let file_p2xy = file_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let e_p7 = p0;
                prism_rtl::Turn::More(Rc::new(ExprLine { srcs_p0: srcs_p0xy.clone(), tys_p1: tys_p1xy.clone(), a_p2: crate::check::typed::SrcAt { file_p: file_p2xy.clone(), span_p: e_p7.span_p.clone() } }))
            }))
        }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Text>>>
    })))
}

/// The step machine of `ExprsOfFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
/// ```
pub struct ExprsOfFile {
    pub srcs_p0: Array<crate::check::errors::Src>,
    pub tys_p1: Map<Text, crate::check::types::Ty>,
    pub file_p2: Nat,
    pub m_p3: crate::syntax::Module,
}

impl prism_rtl::Job<Text> for ExprsOfFile {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs_p0 = &self.srcs_p0;
        let tys_p1 = &self.tys_p1;
        let file_p2 = &self.file_p2;
        let m_p3 = &self.m_p3;
        let file_p2x = file_p2.clone();
        let m_p3x = m_p3.clone();
        let srcs_p0x = srcs_p0.clone();
        let tys_p1x = tys_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(m_p3x.decls_p.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::Decl)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p5 = p0;
            let d_p6 = p1;
            crate::prelude::call_then(start_decl_exprs_f(d_p6.clone()), move |decl_exprs_f_6366: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &decl_exprs_f_6366)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>), move |fold_6323: Array<crate::syntax::Expr>| {
            let es_p4 = fold_6323;
            crate::prelude::call_value(crate::prelude::each_job(es_p4.clone(), {
                let srcs_p0xx = srcs_p0x.clone();
                let tys_p1xx = tys_p1x.clone();
                let file_p2xx = file_p2x.clone();
                Rc::new(move |p0: crate::syntax::Expr| {
                    let srcs_p0xxy = srcs_p0xx.clone();
                    let tys_p1xxy = tys_p1xx.clone();
                    let file_p2xxy = file_p2xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let e_p7 = p0;
                        prism_rtl::Turn::More(Rc::new(ExprLine { srcs_p0: srcs_p0xxy.clone(), tys_p1: tys_p1xxy.clone(), a_p2: crate::check::typed::SrcAt { file_p: file_p2xxy.clone(), span_p: e_p7.span_p.clone() } }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_6391: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::concat(&each_6391)))
        })
    }
}

/// `Start ExprsOfFile, x`: what the function value is when passed to `@Run`.
pub fn start_exprs_of_file_f(srcs_p0: Array<crate::check::errors::Src>, tys_p1: Map<Text, crate::check::types::Ty>, file_p2: Nat, m_p3: crate::syntax::Module) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ExprsOfFile { srcs_p0, tys_p1, file_p2, m_p3 })
}

/// ```prism
/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
/// ```
pub fn expr_line_f(srcs_p0: &Array<crate::check::errors::Src>, tys_p1: &Map<Text, crate::check::types::Ty>, a_p2: &crate::check::typed::SrcAt) -> Text {
    Text::from(format!("  (expr {} {})\n", &at_text_f(srcs_p0, a_p2), &ty_sexp_f(&crate::prelude::or(&crate::prelude::get(tys_p1, &crate::check::typed::at_key_f(a_p2)), &crate::check::types::Ty::TyErr))))
}

/// The step machine of `ExprLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
/// ```
pub struct ExprLine {
    pub srcs_p0: Array<crate::check::errors::Src>,
    pub tys_p1: Map<Text, crate::check::types::Ty>,
    pub a_p2: crate::check::typed::SrcAt,
}

impl prism_rtl::Job<Text> for ExprLine {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs_p0 = &self.srcs_p0;
        let tys_p1 = &self.tys_p1;
        let a_p2 = &self.a_p2;
        let a_p2x = a_p2.clone();
        let srcs_p0x = srcs_p0.clone();
        let tys_p1x = tys_p1.clone();
        crate::prelude::call_then(start_ty_sexp_f(crate::prelude::or(&crate::prelude::get(&tys_p1x, &crate::check::typed::at_key_f(&a_p2x)), &crate::check::types::Ty::TyErr)), move |ty_sexp_f_6570: Text| prism_rtl::Turn::Finished(Text::from(format!("  (expr {} {})\n", &at_text_f(&srcs_p0x, &a_p2x), &ty_sexp_f_6570))))
    }
}

/// `Start ExprLine, x`: what the function value is when passed to `@Run`.
pub fn start_expr_line_f(srcs_p0: Array<crate::check::errors::Src>, tys_p1: Map<Text, crate::check::types::Ty>, a_p2: crate::check::typed::SrcAt) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ExprLine { srcs_p0, tys_p1, a_p2 })
}

/// ```prism
/// DeclExprs: unbounded fn Decl -> [Expr]
/// ```
pub fn decl_exprs_f(d_p0: &crate::syntax::decls::Decl) -> Array<crate::syntax::Expr> {
    match &d_p0.kind_p {
        crate::syntax::decls::DeclKind::DFn(f_p1) => body_exprs_f(&f_p1.body_p),
        crate::syntax::decls::DeclKind::DLet(l_p2) => exprs_in_f(&l_p2.value_p),
        crate::syntax::decls::DeclKind::DWidget(w_p3) => stmts_exprs_f(&w_p3.body_p.stmts_p),
        crate::syntax::decls::DeclKind::DTrait(t_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(t_p4.items_p.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p5 = p0;
            let it_p6 = p1;
            match &it_p6 {
                crate::syntax::decls::TraitItem::TiFn(f_p7) => {
                    let f_p7x = f_p7.clone();
                    crate::prelude::call_then(start_body_exprs_f(f_p7x.body_p.clone()), move |body_exprs_f_6857: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &body_exprs_f_6857)))
                },
                _ => prism_rtl::Turn::Finished(acc_p5.clone()),
            }
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::decls::DeclKind::DImpl(i_p8) => crate::prelude::run_to_end(crate::prelude::fold_job(i_p8.items_p.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p9 = p0;
            let it_pa = p1;
            match &it_pa {
                crate::syntax::decls::TraitItem::TiFn(f_pb) => {
                    let f_pbx = f_pb.clone();
                    crate::prelude::call_then(start_body_exprs_f(f_pbx.body_p.clone()), move |body_exprs_f_6981: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p9, &body_exprs_f_6981)))
                },
                _ => prism_rtl::Turn::Finished(acc_p9.clone()),
            }
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::decls::DeclKind::DCheck(c_pc) => crate::prelude::run_to_end(crate::prelude::fold_job(c_pc.lines_p.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pd = p0;
            let l_pe = p1;
            crate::prelude::call_then(start_exprs_in_f(l_pe.expr_p.clone()), move |exprs_in_f_7079: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pd, &exprs_in_f_7079)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::decls::DeclKind::DTest(t_pf) => exprs_in_f(&t_pf.blueprint_p),
        _ => Array::new(),
    }
}

/// The step machine of `DeclExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeclExprs: unbounded fn Decl -> [Expr]
/// ```
pub struct DeclExprs {
    pub d_p0: crate::syntax::decls::Decl,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for DeclExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let d_p0 = &self.d_p0;
        match &d_p0.kind_p {
            crate::syntax::decls::DeclKind::DFn(f_p1) => prism_rtl::Turn::More(Rc::new(BodyExprs { fn_body0: f_p1.body_p.clone() })),
            crate::syntax::decls::DeclKind::DLet(l_p2) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: l_p2.value_p.clone() })),
            crate::syntax::decls::DeclKind::DWidget(w_p3) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts_p0: w_p3.body_p.stmts_p.clone() })),
            crate::syntax::decls::DeclKind::DTrait(t_p4) => crate::prelude::fold_job(t_p4.items_p.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let it_p6 = p1;
                match &it_p6 {
                    crate::syntax::decls::TraitItem::TiFn(f_p7) => {
                        let f_p7x = f_p7.clone();
                        crate::prelude::call_then(start_body_exprs_f(f_p7x.body_p.clone()), move |body_exprs_f_6857: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &body_exprs_f_6857)))
                    },
                    _ => prism_rtl::Turn::Finished(acc_p5.clone()),
                }
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle(),
            crate::syntax::decls::DeclKind::DImpl(i_p8) => crate::prelude::fold_job(i_p8.items_p.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p9 = p0;
                let it_pa = p1;
                match &it_pa {
                    crate::syntax::decls::TraitItem::TiFn(f_pb) => {
                        let f_pbx = f_pb.clone();
                        crate::prelude::call_then(start_body_exprs_f(f_pbx.body_p.clone()), move |body_exprs_f_6981: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p9, &body_exprs_f_6981)))
                    },
                    _ => prism_rtl::Turn::Finished(acc_p9.clone()),
                }
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle(),
            crate::syntax::decls::DeclKind::DCheck(c_pc) => crate::prelude::fold_job(c_pc.lines_p.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pd = p0;
                let l_pe = p1;
                crate::prelude::call_then(start_exprs_in_f(l_pe.expr_p.clone()), move |exprs_in_f_7079: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pd, &exprs_in_f_7079)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle(),
            crate::syntax::decls::DeclKind::DTest(t_pf) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: t_pf.blueprint_p.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start DeclExprs, x`: what the function value is when passed to `@Run`.
pub fn start_decl_exprs_f(d_p0: crate::syntax::decls::Decl) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(DeclExprs { d_p0 })
}

/// ```prism
/// BodyExprs: unbounded fn FnBody -> [Expr]
/// ```
pub fn body_exprs_f(fn_body0: &crate::syntax::decls::FnBody) -> Array<crate::syntax::Expr> {
    match fn_body0 {
        crate::syntax::decls::FnBody::BodyExpr(e_p0) => exprs_in_f(e_p0),
        crate::syntax::decls::FnBody::BodyBlock(b_p1) => stmts_exprs_f(&b_p1.stmts_p),
    }
}

/// The step machine of `BodyExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodyExprs: unbounded fn FnBody -> [Expr]
/// ```
pub struct BodyExprs {
    pub fn_body0: crate::syntax::decls::FnBody,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for BodyExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let fn_body0 = &self.fn_body0;
        match fn_body0 {
            crate::syntax::decls::FnBody::BodyExpr(e_p0) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: e_p0.clone() })),
            crate::syntax::decls::FnBody::BodyBlock(b_p1) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts_p0: b_p1.stmts_p.clone() })),
        }
    }
}

/// `Start BodyExprs, x`: what the function value is when passed to `@Run`.
pub fn start_body_exprs_f(fn_body0: crate::syntax::decls::FnBody) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(BodyExprs { fn_body0 })
}

/// ```prism
/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
/// ```
pub fn stmts_exprs_f(stmts_p0: &Array<crate::syntax::Stmt>) -> Array<crate::syntax::Expr> {
    crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p1 = p0;
        let s_p2 = p1;
        crate::prelude::call_then(start_stmt_exprs_f(s_p2.clone()), move |stmt_exprs_f_7382: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &stmt_exprs_f_7382)))
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>))
}

/// The step machine of `StmtsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
/// ```
pub struct StmtsExprs {
    pub stmts_p0: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for StmtsExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let stmts_p0 = &self.stmts_p0;
        crate::prelude::fold_job(stmts_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p1 = p0;
            let s_p2 = p1;
            crate::prelude::call_then(start_stmt_exprs_f(s_p2.clone()), move |stmt_exprs_f_7382: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &stmt_exprs_f_7382)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle()
    }
}

/// `Start StmtsExprs, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_exprs_f(stmts_p0: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(StmtsExprs { stmts_p0 })
}

/// ```prism
/// StmtExprs: unbounded fn Stmt -> [Expr]
/// ```
pub fn stmt_exprs_f(s_p0: &crate::syntax::Stmt) -> Array<crate::syntax::Expr> {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SBind(_, e_p1, t_o2) => match t_o2 {
            Some(x_p3) => crate::prelude::append(&exprs_in_f(e_p1), &exprs_in_f(x_p3)),
            None => exprs_in_f(e_p1),
        },
        crate::syntax::StmtKind::SIgnore(e_p4) => exprs_in_f(e_p4),
        crate::syntax::StmtKind::SLet(_, _, e_p5) => exprs_in_f(e_p5),
        crate::syntax::StmtKind::SFn(f_p6) => body_exprs_f(&f_p6.body_p),
        crate::syntax::StmtKind::SWidget(w_p7) => stmts_exprs_f(&w_p7.body_p.stmts_p),
        crate::syntax::StmtKind::SSet(t_p8, v_p9) => crate::prelude::append(&exprs_in_f(t_p8), &exprs_in_f(v_p9)),
        crate::syntax::StmtKind::SAccum(t_pa, _, v_pb) => crate::prelude::append(&exprs_in_f(t_pa), &exprs_in_f(v_pb)),
        crate::syntax::StmtKind::SRequire(c_pc) => exprs_in_f(c_pc),
        crate::syntax::StmtKind::SForbid(c_pd) => exprs_in_f(c_pd),
        crate::syntax::StmtKind::SWhile(c_pe, b_pf) => crate::prelude::append(&cond_exprs_f(c_pe), &stmts_exprs_f(&b_pf.stmts_p)),
        crate::syntax::StmtKind::SReturn(e_pg) => exprs_in_f(e_pg),
        crate::syntax::StmtKind::SExpr(e_ph) => exprs_in_f(e_ph),
        _ => Array::new(),
    }
}

/// The step machine of `StmtExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtExprs: unbounded fn Stmt -> [Expr]
/// ```
pub struct StmtExprs {
    pub s_p0: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for StmtExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let s_p0 = &self.s_p0;
        match &s_p0.kind_p {
            crate::syntax::StmtKind::SBind(_, e_p1, t_o2) => match t_o2 {
                Some(x_p3) => {
                    let e_p1x = e_p1.clone();
                    let x_p3x = x_p3.clone();
                    crate::prelude::call_then(start_exprs_in_f(e_p1x.clone()), move |exprs_in_f_7522: Array<crate::syntax::Expr>| crate::prelude::call_then(start_exprs_in_f(x_p3x.clone()), move |exprs_in_f_7535: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&exprs_in_f_7522, &exprs_in_f_7535))))
                },
                None => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: e_p1.clone() })),
            },
            crate::syntax::StmtKind::SIgnore(e_p4) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: e_p4.clone() })),
            crate::syntax::StmtKind::SLet(_, _, e_p5) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: e_p5.clone() })),
            crate::syntax::StmtKind::SFn(f_p6) => prism_rtl::Turn::More(Rc::new(BodyExprs { fn_body0: f_p6.body_p.clone() })),
            crate::syntax::StmtKind::SWidget(w_p7) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts_p0: w_p7.body_p.stmts_p.clone() })),
            crate::syntax::StmtKind::SSet(t_p8, v_p9) => {
                let t_p8x = t_p8.clone();
                let v_p9x = v_p9.clone();
                crate::prelude::call_then(start_exprs_in_f(t_p8x.clone()), move |exprs_in_f_7722: Array<crate::syntax::Expr>| crate::prelude::call_then(start_exprs_in_f(v_p9x.clone()), move |exprs_in_f_7735: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&exprs_in_f_7722, &exprs_in_f_7735))))
            },
            crate::syntax::StmtKind::SAccum(t_pa, _, v_pb) => {
                let t_pax = t_pa.clone();
                let v_pbx = v_pb.clone();
                crate::prelude::call_then(start_exprs_in_f(t_pax.clone()), move |exprs_in_f_7779: Array<crate::syntax::Expr>| crate::prelude::call_then(start_exprs_in_f(v_pbx.clone()), move |exprs_in_f_7792: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&exprs_in_f_7779, &exprs_in_f_7792))))
            },
            crate::syntax::StmtKind::SRequire(c_pc) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: c_pc.clone() })),
            crate::syntax::StmtKind::SForbid(c_pd) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: c_pd.clone() })),
            crate::syntax::StmtKind::SWhile(c_pe, b_pf) => {
                let b_pfx = b_pf.clone();
                let c_pex = c_pe.clone();
                crate::prelude::call_then(start_cond_exprs_f(c_pex.clone()), move |cond_exprs_f_7879: Array<crate::syntax::Expr>| crate::prelude::call_then(start_stmts_exprs_f(b_pfx.stmts_p.clone()), move |stmts_exprs_f_7894: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&cond_exprs_f_7879, &stmts_exprs_f_7894))))
            },
            crate::syntax::StmtKind::SReturn(e_pg) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: e_pg.clone() })),
            crate::syntax::StmtKind::SExpr(e_ph) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: e_ph.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start StmtExprs, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_exprs_f(s_p0: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(StmtExprs { s_p0 })
}

/// ```prism
/// CondExprs: unbounded fn Cond -> [Expr]
/// ```
pub fn cond_exprs_f(cond0: &crate::syntax::Cond) -> Array<crate::syntax::Expr> {
    match cond0 {
        crate::syntax::Cond::CondExpr(e_p0) => exprs_in_f(&**e_p0),
        crate::syntax::Cond::CondBind(_, e_p1, g_o2) => crate::prelude::append(&exprs_in_f(&**e_p1), &opt_exprs_f(&**g_o2)),
    }
}

/// The step machine of `CondExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondExprs: unbounded fn Cond -> [Expr]
/// ```
pub struct CondExprs {
    pub cond0: crate::syntax::Cond,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for CondExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let cond0 = &self.cond0;
        match cond0 {
            crate::syntax::Cond::CondExpr(e_p0) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: (**e_p0).clone() })),
            crate::syntax::Cond::CondBind(_, e_p1, g_o2) => {
                let g_o2x = (**g_o2).clone();
                let e_p1x = (**e_p1).clone();
                crate::prelude::call_then(start_exprs_in_f(e_p1x.clone()), move |exprs_in_f_8108: Array<crate::syntax::Expr>| crate::prelude::call_then(start_opt_exprs_f(g_o2x.clone()), move |opt_exprs_f_8121: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&exprs_in_f_8108, &opt_exprs_f_8121))))
            },
        }
    }
}

/// `Start CondExprs, x`: what the function value is when passed to `@Run`.
pub fn start_cond_exprs_f(cond0: crate::syntax::Cond) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(CondExprs { cond0 })
}

/// ```prism
/// ArgsExprs: unbounded fn [Arg] -> [Expr]
/// ```
pub fn args_exprs_f(args_p0: &Array<crate::syntax::Arg>) -> Array<crate::syntax::Expr> {
    crate::prelude::run_to_end(crate::prelude::fold_job(args_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arg)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p1 = p0;
        let a_p2 = p1;
        crate::prelude::call_then(start_exprs_in_f(a_p2.value_p.clone()), move |exprs_in_f_8235: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &exprs_in_f_8235)))
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>))
}

/// The step machine of `ArgsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgsExprs: unbounded fn [Arg] -> [Expr]
/// ```
pub struct ArgsExprs {
    pub args_p0: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for ArgsExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let args_p0 = &self.args_p0;
        crate::prelude::fold_job(args_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arg)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p1 = p0;
            let a_p2 = p1;
            crate::prelude::call_then(start_exprs_in_f(a_p2.value_p.clone()), move |exprs_in_f_8235: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &exprs_in_f_8235)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle()
    }
}

/// `Start ArgsExprs, x`: what the function value is when passed to `@Run`.
pub fn start_args_exprs_f(args_p0: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(ArgsExprs { args_p0 })
}

/// ```prism
/// BlockExprs: unbounded fn Block -> [Expr]
/// ```
pub fn block_exprs_f(b_p0: &crate::syntax::Block) -> Array<crate::syntax::Expr> {
    stmts_exprs_f(&b_p0.stmts_p)
}

/// The step machine of `BlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockExprs: unbounded fn Block -> [Expr]
/// ```
pub struct BlockExprs {
    pub b_p0: crate::syntax::Block,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for BlockExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let b_p0 = &self.b_p0;
        prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts_p0: b_p0.stmts_p.clone() }))
    }
}

/// `Start BlockExprs, x`: what the function value is when passed to `@Run`.
pub fn start_block_exprs_f(b_p0: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(BlockExprs { b_p0 })
}

/// ```prism
/// ExprsIn: unbounded fn Expr -> [Expr]
/// ```
pub fn exprs_in_f(e_p0: &crate::syntax::Expr) -> Array<crate::syntax::Expr> {
    let inner_p1 = match &*e_p0.kind_p {
        crate::syntax::ExprKind::ETuple(es_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(es_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let x_p4 = p1;
            crate::prelude::call_then(start_exprs_in_f(x_p4.clone()), move |exprs_in_f_8621: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &exprs_in_f_8621)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::EArray(es_p5) => crate::prelude::run_to_end(crate::prelude::fold_job(es_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p6 = p0;
            let x_p7 = p1;
            crate::prelude::call_then(start_exprs_in_f(x_p7.clone()), move |exprs_in_f_8689: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &exprs_in_f_8689)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::EMap(kvs_p8) => crate::prelude::run_to_end(crate::prelude::fold_job(kvs_p8.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p9 = p0;
            let (k_pa, v_pb) = p1;
            crate::prelude::call_then(start_exprs_in_f(k_pa.clone()), move |exprs_in_f_8772: Array<crate::syntax::Expr>| crate::prelude::call_then(start_exprs_in_f(v_pb.clone()), move |exprs_in_f_8786: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::append(&acc_p9, &exprs_in_f_8772), &exprs_in_f_8786))))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::EGroup(x_pc) => exprs_in_f(&**x_pc),
        crate::syntax::ExprKind::ECall(c_pd, args_pe, _, _) => crate::prelude::append(&exprs_in_f(&**c_pd), &args_exprs_f(args_pe)),
        crate::syntax::ExprKind::EBinary(_, l_pf, r_pg) => crate::prelude::append(&exprs_in_f(&**l_pf), &exprs_in_f(&**r_pg)),
        crate::syntax::ExprKind::EUnary(_, x_ph) => exprs_in_f(&**x_ph),
        crate::syntax::ExprKind::EFreeSigil(_, x_pi) => exprs_in_f(&**x_pi),
        crate::syntax::ExprKind::EField(r_pj, _, _) => exprs_in_f(&**r_pj),
        crate::syntax::ExprKind::EIndex(r_pk, i_pl) => crate::prelude::append(&exprs_in_f(&**r_pk), &exprs_in_f(&**i_pl)),
        crate::syntax::ExprKind::ETopicIndex(x_pm) => exprs_in_f(&**x_pm),
        crate::syntax::ExprKind::EMethod(r_pn, _, args_po) => crate::prelude::append(&exprs_in_f(&**r_pn), &args_exprs_f(args_po)),
        crate::syntax::ExprKind::ETypeArgs(x_pp, _) => exprs_in_f(&**x_pp),
        crate::syntax::ExprKind::ECast(x_pq, _, _) => exprs_in_f(&**x_pq),
        crate::syntax::ExprKind::ELambda(_, body_pr) => match &**body_pr {
            crate::syntax::LambdaBody::LbExpr(x_ps) => exprs_in_f(&**x_ps),
            crate::syntax::LambdaBody::LbBlock(b_pt) => block_exprs_f(b_pt),
        },
        crate::syntax::ExprKind::EIf(c_pu, t_pv, el_o10) => crate::prelude::append(&crate::prelude::append(&cond_exprs_f(&**c_pu), &block_exprs_f(t_pv)), &opt_block_exprs_f(el_o10)),
        crate::syntax::ExprKind::EMatch(s_p11, arms_p12) => crate::prelude::run_to_end(crate::prelude::fold_job(arms_p12.clone(), exprs_in_f(&**s_p11), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arm)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p13 = p0;
            let a_p14 = p1;
            crate::prelude::call_then(start_opt_exprs_f(a_p14.guard_o.clone()), move |opt_exprs_f_9600: Array<crate::syntax::Expr>| crate::prelude::call_then(start_block_exprs_f(a_p14.body_p.clone()), move |block_exprs_f_9622: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::append(&acc_p13, &opt_exprs_f_9600), &block_exprs_f_9622))))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::ERebuild(s_p15, b_p16) => crate::prelude::append(&exprs_in_f(&**s_p15), &block_exprs_f(b_p16)),
        crate::syntax::ExprKind::EFor(_, s_p17, b_p18) => crate::prelude::append(&exprs_in_f(&**s_p17), &block_exprs_f(b_p18)),
        crate::syntax::ExprKind::EGiven(b_p19) => block_exprs_f(b_p19),
        crate::syntax::ExprKind::EUpdate(t_p1a, b_p1b) => crate::prelude::append(&exprs_in_f(&**t_p1a), &block_exprs_f(b_p1b)),
        crate::syntax::ExprKind::EWidgetBlock(b_p1c) => block_exprs_f(b_p1c),
        crate::syntax::ExprKind::EAny(x_p1d) => exprs_in_f(&**x_p1d),
        crate::syntax::ExprKind::ELit(l_p1e) => match &l_p1e.kind_p {
            crate::syntax::LitKind::LText(segs_p1f) => crate::prelude::run_to_end(crate::prelude::fold_job(segs_p1f.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TextSeg)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p1g = p0;
                let sg_p1h = p1;
                match &sg_p1h {
                    crate::syntax::TextSeg::SegPlaceholder(x_p1i) => {
                        let x_p1ix = x_p1i.clone();
                        crate::prelude::call_then(start_exprs_in_f(x_p1ix.clone()), move |exprs_in_f_10051: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1g, &exprs_in_f_10051)))
                    },
                    _ => prism_rtl::Turn::Finished(acc_p1g.clone()),
                }
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TextSeg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            _ => Array::new(),
        },
        crate::syntax::ExprKind::ETemplate(t_p1j) => template_exprs_f(&t_p1j.parts_p),
        _ => Array::new(),
    };
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ERest => inner_p1.clone(),
        crate::syntax::ExprKind::EError => inner_p1.clone(),
        _ => crate::prelude::append(&Array::from(vec![e_p0.clone()]), &inner_p1),
    }
}

/// The step machine of `ExprsIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprsIn: unbounded fn Expr -> [Expr]
/// ```
pub struct ExprsIn {
    pub e_p0: crate::syntax::Expr,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for ExprsIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let e_p0 = &self.e_p0;
        let inner_p1 = match &*e_p0.kind_p {
            crate::syntax::ExprKind::ETuple(es_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(es_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let x_p4 = p1;
                crate::prelude::call_then(start_exprs_in_f(x_p4.clone()), move |exprs_in_f_8621: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &exprs_in_f_8621)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::EArray(es_p5) => crate::prelude::run_to_end(crate::prelude::fold_job(es_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let x_p7 = p1;
                crate::prelude::call_then(start_exprs_in_f(x_p7.clone()), move |exprs_in_f_8689: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &exprs_in_f_8689)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::EMap(kvs_p8) => crate::prelude::run_to_end(crate::prelude::fold_job(kvs_p8.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p9 = p0;
                let (k_pa, v_pb) = p1;
                crate::prelude::call_then(start_exprs_in_f(k_pa.clone()), move |exprs_in_f_8772: Array<crate::syntax::Expr>| crate::prelude::call_then(start_exprs_in_f(v_pb.clone()), move |exprs_in_f_8786: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::append(&acc_p9, &exprs_in_f_8772), &exprs_in_f_8786))))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::EGroup(x_pc) => exprs_in_f(&**x_pc),
            crate::syntax::ExprKind::ECall(c_pd, args_pe, _, _) => crate::prelude::append(&exprs_in_f(&**c_pd), &args_exprs_f(args_pe)),
            crate::syntax::ExprKind::EBinary(_, l_pf, r_pg) => crate::prelude::append(&exprs_in_f(&**l_pf), &exprs_in_f(&**r_pg)),
            crate::syntax::ExprKind::EUnary(_, x_ph) => exprs_in_f(&**x_ph),
            crate::syntax::ExprKind::EFreeSigil(_, x_pi) => exprs_in_f(&**x_pi),
            crate::syntax::ExprKind::EField(r_pj, _, _) => exprs_in_f(&**r_pj),
            crate::syntax::ExprKind::EIndex(r_pk, i_pl) => crate::prelude::append(&exprs_in_f(&**r_pk), &exprs_in_f(&**i_pl)),
            crate::syntax::ExprKind::ETopicIndex(x_pm) => exprs_in_f(&**x_pm),
            crate::syntax::ExprKind::EMethod(r_pn, _, args_po) => crate::prelude::append(&exprs_in_f(&**r_pn), &args_exprs_f(args_po)),
            crate::syntax::ExprKind::ETypeArgs(x_pp, _) => exprs_in_f(&**x_pp),
            crate::syntax::ExprKind::ECast(x_pq, _, _) => exprs_in_f(&**x_pq),
            crate::syntax::ExprKind::ELambda(_, body_pr) => match &**body_pr {
                crate::syntax::LambdaBody::LbExpr(x_ps) => exprs_in_f(&**x_ps),
                crate::syntax::LambdaBody::LbBlock(b_pt) => block_exprs_f(b_pt),
            },
            crate::syntax::ExprKind::EIf(c_pu, t_pv, el_o10) => crate::prelude::append(&crate::prelude::append(&cond_exprs_f(&**c_pu), &block_exprs_f(t_pv)), &opt_block_exprs_f(el_o10)),
            crate::syntax::ExprKind::EMatch(s_p11, arms_p12) => crate::prelude::run_to_end(crate::prelude::fold_job(arms_p12.clone(), exprs_in_f(&**s_p11), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arm)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p13 = p0;
                let a_p14 = p1;
                crate::prelude::call_then(start_opt_exprs_f(a_p14.guard_o.clone()), move |opt_exprs_f_9600: Array<crate::syntax::Expr>| crate::prelude::call_then(start_block_exprs_f(a_p14.body_p.clone()), move |block_exprs_f_9622: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::append(&acc_p13, &opt_exprs_f_9600), &block_exprs_f_9622))))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::ERebuild(s_p15, b_p16) => crate::prelude::append(&exprs_in_f(&**s_p15), &block_exprs_f(b_p16)),
            crate::syntax::ExprKind::EFor(_, s_p17, b_p18) => crate::prelude::append(&exprs_in_f(&**s_p17), &block_exprs_f(b_p18)),
            crate::syntax::ExprKind::EGiven(b_p19) => block_exprs_f(b_p19),
            crate::syntax::ExprKind::EUpdate(t_p1a, b_p1b) => crate::prelude::append(&exprs_in_f(&**t_p1a), &block_exprs_f(b_p1b)),
            crate::syntax::ExprKind::EWidgetBlock(b_p1c) => block_exprs_f(b_p1c),
            crate::syntax::ExprKind::EAny(x_p1d) => exprs_in_f(&**x_p1d),
            crate::syntax::ExprKind::ELit(l_p1e) => match &l_p1e.kind_p {
                crate::syntax::LitKind::LText(segs_p1f) => crate::prelude::run_to_end(crate::prelude::fold_job(segs_p1f.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TextSeg)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p1g = p0;
                    let sg_p1h = p1;
                    match &sg_p1h {
                        crate::syntax::TextSeg::SegPlaceholder(x_p1i) => {
                            let x_p1ix = x_p1i.clone();
                            crate::prelude::call_then(start_exprs_in_f(x_p1ix.clone()), move |exprs_in_f_10051: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1g, &exprs_in_f_10051)))
                        },
                        _ => prism_rtl::Turn::Finished(acc_p1g.clone()),
                    }
                }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TextSeg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
                _ => Array::new(),
            },
            crate::syntax::ExprKind::ETemplate(t_p1j) => template_exprs_f(&t_p1j.parts_p),
            _ => Array::new(),
        };
        match &*e_p0.kind_p {
            crate::syntax::ExprKind::ERest => prism_rtl::Turn::Finished(inner_p1.clone()),
            crate::syntax::ExprKind::EError => prism_rtl::Turn::Finished(inner_p1.clone()),
            _ => prism_rtl::Turn::Finished(crate::prelude::append(&Array::from(vec![e_p0.clone()]), &inner_p1)),
        }
    }
}

/// `Start ExprsIn, x`: what the function value is when passed to `@Run`.
pub fn start_exprs_in_f(e_p0: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(ExprsIn { e_p0 })
}

/// ```prism
/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
/// ```
pub fn template_exprs_f(parts_p0: &Array<crate::syntax::TemplatePart>) -> Array<crate::syntax::Expr> {
    crate::prelude::run_to_end(crate::prelude::fold_job(parts_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TemplatePart)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p1 = p0;
        let p_p2 = p1;
        match &p_p2 {
            crate::syntax::TemplatePart::TpPlaceholder(x_p3, _) => {
                let x_p3x = x_p3.clone();
                crate::prelude::call_then(start_exprs_in_f(x_p3x.clone()), move |exprs_in_f_10446: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &exprs_in_f_10446)))
            },
            crate::syntax::TemplatePart::TpBlock(b_p4) => {
                let b_p4x = b_p4.clone();
                crate::prelude::call_then(start_block_exprs_f(b_p4x.clone()), move |block_exprs_f_10485: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &block_exprs_f_10485)))
            },
            crate::syntax::TemplatePart::TpCall(_, args_p5, ps_o6, _) => {
                let ps_o6x = ps_o6.clone();
                let args_p5x = args_p5.clone();
                crate::prelude::call_then(start_args_exprs_f(args_p5x.clone()), move |args_exprs_f_10558: Array<crate::syntax::Expr>| crate::prelude::call_then(start_opt_parts_f(ps_o6x.clone()), move |opt_parts_f_10577: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::append(&acc_p1, &args_exprs_f_10558), &opt_parts_f_10577))))
            },
            _ => prism_rtl::Turn::Finished(acc_p1.clone()),
        }
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>))
}

/// The step machine of `TemplateExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
/// ```
pub struct TemplateExprs {
    pub parts_p0: Array<crate::syntax::TemplatePart>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for TemplateExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let parts_p0 = &self.parts_p0;
        crate::prelude::fold_job(parts_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TemplatePart)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p1 = p0;
            let p_p2 = p1;
            match &p_p2 {
                crate::syntax::TemplatePart::TpPlaceholder(x_p3, _) => {
                    let x_p3x = x_p3.clone();
                    crate::prelude::call_then(start_exprs_in_f(x_p3x.clone()), move |exprs_in_f_10446: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &exprs_in_f_10446)))
                },
                crate::syntax::TemplatePart::TpBlock(b_p4) => {
                    let b_p4x = b_p4.clone();
                    crate::prelude::call_then(start_block_exprs_f(b_p4x.clone()), move |block_exprs_f_10485: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &block_exprs_f_10485)))
                },
                crate::syntax::TemplatePart::TpCall(_, args_p5, ps_o6, _) => {
                    let ps_o6x = ps_o6.clone();
                    let args_p5x = args_p5.clone();
                    crate::prelude::call_then(start_args_exprs_f(args_p5x.clone()), move |args_exprs_f_10558: Array<crate::syntax::Expr>| crate::prelude::call_then(start_opt_parts_f(ps_o6x.clone()), move |opt_parts_f_10577: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::append(&acc_p1, &args_exprs_f_10558), &opt_parts_f_10577))))
                },
                _ => prism_rtl::Turn::Finished(acc_p1.clone()),
            }
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle()
    }
}

/// `Start TemplateExprs, x`: what the function value is when passed to `@Run`.
pub fn start_template_exprs_f(parts_p0: Array<crate::syntax::TemplatePart>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(TemplateExprs { parts_p0 })
}

/// ```prism
/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
/// ```
pub fn opt_parts_f(opt0: &Option<Array<crate::syntax::TemplatePart>>) -> Array<crate::syntax::Expr> {
    match opt0 {
        Some(ps_p0) => template_exprs_f(ps_p0),
        None => Array::new(),
    }
}

/// The step machine of `OptParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
/// ```
pub struct OptParts {
    pub opt0: Option<Array<crate::syntax::TemplatePart>>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for OptParts {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(ps_p0) => prism_rtl::Turn::More(Rc::new(TemplateExprs { parts_p0: ps_p0.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptParts, x`: what the function value is when passed to `@Run`.
pub fn start_opt_parts_f(opt0: Option<Array<crate::syntax::TemplatePart>>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(OptParts { opt0 })
}

/// ```prism
/// OptBlockExprs: unbounded fn ?Block -> [Expr]
/// ```
pub fn opt_block_exprs_f(opt0: &Option<crate::syntax::Block>) -> Array<crate::syntax::Expr> {
    match opt0 {
        Some(b_p0) => block_exprs_f(b_p0),
        None => Array::new(),
    }
}

/// The step machine of `OptBlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptBlockExprs: unbounded fn ?Block -> [Expr]
/// ```
pub struct OptBlockExprs {
    pub opt0: Option<crate::syntax::Block>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for OptBlockExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(b_p0) => prism_rtl::Turn::More(Rc::new(BlockExprs { b_p0: b_p0.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptBlockExprs, x`: what the function value is when passed to `@Run`.
pub fn start_opt_block_exprs_f(opt0: Option<crate::syntax::Block>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(OptBlockExprs { opt0 })
}

/// ```prism
/// OptExprs: unbounded fn ?Expr -> [Expr]
/// ```
pub fn opt_exprs_f(opt0: &Option<crate::syntax::Expr>) -> Array<crate::syntax::Expr> {
    match opt0 {
        Some(x_p0) => exprs_in_f(x_p0),
        None => Array::new(),
    }
}

/// The step machine of `OptExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptExprs: unbounded fn ?Expr -> [Expr]
/// ```
pub struct OptExprs {
    pub opt0: Option<crate::syntax::Expr>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for OptExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(x_p0) => prism_rtl::Turn::More(Rc::new(ExprsIn { e_p0: x_p0.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptExprs, x`: what the function value is when passed to `@Run`.
pub fn start_opt_exprs_f(opt0: Option<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(OptExprs { opt0 })
}
