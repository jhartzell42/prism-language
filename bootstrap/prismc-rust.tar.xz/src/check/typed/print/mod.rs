//! The module `Check.Typed.Print`, from `target/bootstrap/src/prismc/check/typed/print.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// TySexp: unbounded fn Ty -> Text
/// ```
pub fn ty_sexp(t: &crate::check::types::Ty) -> Text {
    match t {
        crate::check::types::Ty::TyFlex(n) => Text::from(format!("(var t{})", n)),
        crate::check::types::Ty::TyRigid(n) => Text::from(format!("(rigid {})", n)),
        crate::check::types::Ty::TyQ(n) => Text::from(format!("(q {})", n)),
        crate::check::types::Ty::TyCon(n, m820_3_1) if (m820_3_1.len() == 0) => n.clone(),
        crate::check::types::Ty::TyCon(n, args) => Text::from(format!("({}{})", n, &concat(&run_to_end(each_job(args.clone(), Rc::new(move |p0: crate::check::types::Ty| entered(once_job(move || {
            let a = p0;
            call_then(start_ty_sexp(a.clone()), move |ty_sexp_979: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_979))))
        }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>))))),
        crate::check::types::Ty::TyFn(c, ps, res) => Text::from(format!("(fn {} ({}) {})", &col_sexp(c), &crate::syntax::lexer::chars::join(&run_to_end(each_job(ps.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_ty_sexp(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" ")), &ty_sexp(&**res))),
        crate::check::types::Ty::TyTuple(ts) => Text::from(format!("(tuple{})", &concat(&run_to_end(each_job(ts.clone(), Rc::new(move |p0: crate::check::types::Ty| entered(once_job(move || {
            let a = p0;
            call_then(start_ty_sexp(a.clone()), move |ty_sexp_1128: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_1128))))
        }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>))))),
        crate::check::types::Ty::TyArray(e) => Text::from(format!("(array {})", &ty_sexp(&**e))),
        crate::check::types::Ty::TyMap(k, v_) => Text::from(format!("(map {} {})", &ty_sexp(&**k), &ty_sexp(&**v_))),
        crate::check::types::Ty::TySig(s, i) => Text::from(format!("({} {})", s, &ty_sexp(&**i))),
        crate::check::types::Ty::TyAt(i, rw) => Text::from(format!("(@ {} {})", &ty_sexp(&**i), &row_sexp(rw))),
        crate::check::types::Ty::TyElem(rw, o) => Text::from(format!("(element {} {})", &row_sexp(rw), &ty_sexp(&**o))),
        crate::check::types::Ty::TyElemAny(rw) => Text::from(format!("(elem {})", &row_sexp(rw))),
        crate::check::types::Ty::TyAssoc(n, a) => Text::from(format!("(assoc {} {})", n, &ty_sexp(&**a))),
        crate::check::types::Ty::TyAny(trs) => Text::from(format!("(any{})", &concat(&each(trs, &(|x: &Text| Text::from(format!(" ^{}", x))))))),
        crate::check::types::Ty::TyErr => Text::lit("unknown"),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TySexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TySexp: unbounded fn Ty -> Text
/// ```
pub struct TySexp {
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for TySexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(Text::from(format!("(var t{})", n))),
            crate::check::types::Ty::TyRigid(n) => prism_rtl::Turn::Finished(Text::from(format!("(rigid {})", n))),
            crate::check::types::Ty::TyQ(n) => prism_rtl::Turn::Finished(Text::from(format!("(q {})", n))),
            crate::check::types::Ty::TyCon(n, m820_3_1) if (m820_3_1.len() == 0) => prism_rtl::Turn::Finished(n.clone()),
            crate::check::types::Ty::TyCon(n, args) => {
                let args = args.clone();
                let n = n.clone();
                call_value(each_job(args.clone(), Rc::new(move |p0: crate::check::types::Ty| entered(once_job(move || {
                    let a = p0;
                    call_then(start_ty_sexp(a.clone()), move |ty_sexp_979: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_979))))
                }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_960: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({}{})", &n, &concat(&each_960)))))
            },
            crate::check::types::Ty::TyFn(c, ps, res) => {
                let c = c.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(each_job(ps.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_ty_sexp(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_1040: Array<Text>| call_then(start_ty_sexp(res.clone()), move |ty_sexp_1065: Text| prism_rtl::Turn::Finished(Text::from(format!("(fn {} ({}) {})", &col_sexp(&c), &crate::syntax::lexer::chars::join(&each_1040, &Text::lit(" ")), &ty_sexp_1065)))))
            },
            crate::check::types::Ty::TyTuple(ts) => {
                let ts = ts.clone();
                call_value(each_job(ts.clone(), Rc::new(move |p0: crate::check::types::Ty| entered(once_job(move || {
                    let a = p0;
                    call_then(start_ty_sexp(a.clone()), move |ty_sexp_1128: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_1128))))
                }))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_1111: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("(tuple{})", &concat(&each_1111)))))
            },
            crate::check::types::Ty::TyArray(e) => {
                let e = (**e).clone();
                call_then(start_ty_sexp(e.clone()), move |ty_sexp_1167: Text| prism_rtl::Turn::Finished(Text::from(format!("(array {})", &ty_sexp_1167))))
            },
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_ty_sexp(k.clone()), move |ty_sexp_1202: Text| call_then(start_ty_sexp(v_.clone()), move |ty_sexp_1213: Text| prism_rtl::Turn::Finished(Text::from(format!("(map {} {})", &ty_sexp_1202, &ty_sexp_1213)))))
            },
            crate::check::types::Ty::TySig(s, i) => {
                let i = (**i).clone();
                let s = s.clone();
                call_then(start_ty_sexp(i.clone()), move |ty_sexp_1248: Text| prism_rtl::Turn::Finished(Text::from(format!("({} {})", &s, &ty_sexp_1248))))
            },
            crate::check::types::Ty::TyAt(i, rw) => {
                let i = (**i).clone();
                let rw = rw.clone();
                call_then(start_ty_sexp(i.clone()), move |ty_sexp_1281: Text| prism_rtl::Turn::Finished(Text::from(format!("(@ {} {})", &ty_sexp_1281, &row_sexp(&rw)))))
            },
            crate::check::types::Ty::TyElem(rw, o) => {
                let o = (**o).clone();
                let rw = rw.clone();
                call_then(start_ty_sexp(o.clone()), move |ty_sexp_1348: Text| prism_rtl::Turn::Finished(Text::from(format!("(element {} {})", &row_sexp(&rw), &ty_sexp_1348))))
            },
            crate::check::types::Ty::TyElemAny(rw) => prism_rtl::Turn::Finished(Text::from(format!("(elem {})", &row_sexp(rw)))),
            crate::check::types::Ty::TyAssoc(n, a) => {
                let a = (**a).clone();
                let n = n.clone();
                call_then(start_ty_sexp(a.clone()), move |ty_sexp_1431: Text| prism_rtl::Turn::Finished(Text::from(format!("(assoc {} {})", &n, &ty_sexp_1431))))
            },
            crate::check::types::Ty::TyAny(trs) => prism_rtl::Turn::Finished(Text::from(format!("(any{})", &concat(&each(trs, &(|x: &Text| Text::from(format!(" ^{}", x)))))))),
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished(Text::lit("unknown")),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TySexp, x`: what the function value is when passed to `@Run`.
pub fn start_ty_sexp(t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TySexp { t })
}

/// ```prism
/// ColSexp: fn Col -> Text
/// ```
pub fn col_sexp(col0: &crate::check::types::Col) -> Text {
    match col0 {
        crate::check::types::Col::CBound => Text::lit("bounded"),
        crate::check::types::Col::CUnbound => Text::lit("unbounded"),
        crate::check::types::Col::CRigid(n) => Text::from(format!("(color {})", n)),
        crate::check::types::Col::CQ(n) => Text::from(format!("(color {})", n)),
        crate::check::types::Col::CFlex(n) => Text::from(format!("(color c{})", n)),
    }
}

/// ```prism
/// RowSexp: fn Rw -> Text
/// ```
pub fn row_sexp(rw: &crate::check::types::Rw) -> Text {
    let tail = match &rw.tail {
        crate::check::types::Tail::TlClosed => Text::lit(""),
        crate::check::types::Tail::TlFlex(n) => Text::from(format!(" (tail r{})", n)),
        crate::check::types::Tail::TlRigid(n) => Text::from(format!(" (tail {})", n)),
        crate::check::types::Tail::TlQ(n) => Text::from(format!(" (tail {})", n)),
    };
    let minus = if &len(&rw.minus) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (minus{})", &concat(&each(&rw.minus, &(|m: &Text| Text::from(format!(" {}", m)))))))
    };
    Text::from(format!("(row{}{}{})", &concat(&each(&rw.fams, &(|f: &Text| Text::from(format!(" {}.*", f))))), &tail, &minus))
}

/// ```prism
/// SchemeSexp: unbounded fn Scheme -> Text
/// ```
pub fn scheme_sexp(sc: &crate::check::types::Scheme) -> Text {
    let qs = if &len(&sc.qs) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (forall{})", &concat(&each(&sc.qs, &(|q: &Text| Text::from(format!(" {}", q)))))))
    };
    let rqs = if &len(&sc.rqs) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (rows{})", &concat(&each(&sc.rqs, &(|q: &Text| Text::from(format!(" {}", q)))))))
    };
    let cqs = if &len(&sc.cqs) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (colors{})", &concat(&each(&sc.cqs, &(|q: &Text| Text::from(format!(" {}", q)))))))
    };
    let bs = if &len(&sc.bounds) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (where{})", &concat(&each(&sc.bounds, &(|(v_, c): &(Text, Text)| Text::from(format!(" {}:^{}", v_, c)))))))
    };
    Text::from(format!("(scheme{}{}{}{} {})", &qs, &rqs, &cqs, &bs, &ty_sexp(&sc.ty)))
}

/// The step machine of `SchemeSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SchemeSexp: unbounded fn Scheme -> Text
/// ```
pub struct SchemeSexp {
    pub sc: crate::check::types::Scheme,
}

impl prism_rtl::Job<Text> for SchemeSexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let sc = &self.sc;
        let qs = if &len(&sc.qs) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (forall{})", &concat(&each(&sc.qs, &(|q: &Text| Text::from(format!(" {}", q)))))))
        };
        let rqs = if &len(&sc.rqs) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (rows{})", &concat(&each(&sc.rqs, &(|q: &Text| Text::from(format!(" {}", q)))))))
        };
        let cqs = if &len(&sc.cqs) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (colors{})", &concat(&each(&sc.cqs, &(|q: &Text| Text::from(format!(" {}", q)))))))
        };
        let bs = if &len(&sc.bounds) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (where{})", &concat(&each(&sc.bounds, &(|(v_, c): &(Text, Text)| Text::from(format!(" {}:^{}", v_, c)))))))
        };
        let sc = sc.clone();
        call_then(start_ty_sexp(sc.ty.clone()), move |ty_sexp_2534: Text| prism_rtl::Turn::Finished(Text::from(format!("(scheme{}{}{}{} {})", &qs, &rqs, &cqs, &bs, &ty_sexp_2534))))
    }
}

/// `Start SchemeSexp, x`: what the function value is when passed to `@Run`.
pub fn start_scheme_sexp(sc: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(SchemeSexp { sc })
}

/// ```prism
/// AtText: fn [Src], SrcAt -> Text
/// ```
pub fn at_text(srcs: &Array<crate::check::errors::Src>, a: &crate::check::typed::SrcAt) -> Text {
    match index(srcs, &a.file) {
        None => Text::from(format!("?:{}", &a.span.start)),
        Some(src) => Text::from(format!("{}:{}-{}", &crate::check::errors::seg_at(&src, &a.span.start).path_, &pos_text(&src, &a.span.start), &pos_text(&src, &a.span.end))),
    }
}

/// ```prism
/// PosText: fn Src, Nat -> Text
/// ```
pub fn pos_text(src: &crate::check::errors::Src, offset: &Nat) -> Text {
    let line = crate::check::errors::cline_of(&src.starts, offset);
    let col = crate::syntax::lexer::chars::column_of(&src.text, &or(&index(&src.starts, &line), &Nat::from(0u32)), offset);
    Text::from(format!("{}:{}", &(&or(&(&line).checked_sub(&crate::check::errors::seg_at(src, offset).line), &Nat::from(0u32)) + &Nat::from(1u32)), &(&col + &Nat::from(1u32))))
}

/// ```prism
/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
/// ```
pub fn typed_sexp(srcs: &Array<crate::check::errors::Src>, trees: &Array<crate::syntax::Module>, shown_: &Nat, tp: &crate::check::typed::TProgram) -> Text {
    let tys = fold(&tp.exprs, &Map::new(), &(|m: &Map<Text, crate::check::types::Ty>, n: &crate::check::typed::TyNote| insert(m, &crate::check::typed::at_key(&n.at), &n.ty)));
    let files = filter(&crate::check::errors::range0(&len(trees)), &(|i: &Nat| i < shown_));
    let defs = concat(&run_to_end(each_job(filter(&tp.defs, &(|d: &crate::check::typed::DefNote| &d.at.file < shown_)), {
        let srcs = srcs.clone();
        Rc::new(move |p0: crate::check::typed::DefNote| {
            let srcs = srcs.clone();
            entered(once_job(move || {
                let d = p0;
                call_then(start_scheme_sexp(d.scheme.clone()), move |scheme_sexp_3620: Text| prism_rtl::Turn::Finished(Text::from(format!("  (def {} {} {})\n", &d.name, &at_text(&srcs, &d.at), &scheme_sexp_3620))))
            }))
        }) as Rc<dyn Fn(crate::check::typed::DefNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let exprs = concat(&run_to_end(each_job(files.clone(), {
        let srcs = srcs.clone();
        let tys = tys.clone();
        let trees = trees.clone();
        Rc::new(move |p0: Nat| {
            let srcs = srcs.clone();
            let tys = tys.clone();
            let trees = trees.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ExprsOfFile { srcs: srcs.clone(), tys: tys.clone(), file: i.clone(), m: or(&index(&trees, &i), &empty_mod()) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let mine_fn = {
        let shown_ = shown_.clone();
        Rc::new(move |a: &crate::check::typed::SrcAt| shown(a, &shown_))
    };
    let apps = concat(&each(&filter(&tp.apps, &(|x: &crate::check::typed::AppNote| (&mine_fn)(&x.at))), &(|x: &crate::check::typed::AppNote| Text::from(format!("  (app {} {} {} {} (lifted{}) {} {})\n", &at_text(srcs, &x.at), &quote(&x.callee), &x.kind, &layer_word(&x.layer), &concat(&each(&x.lifted, &(|i: &Nat| Text::from(format!(" {}", i))))), &layer_word(&x.inner), &col_sexp(&x.color))))));
    let fns = concat(&each(&filter(&tp.fns, &(|x: &crate::check::typed::FnNote| (&mine_fn)(&x.at))), &(|x: &crate::check::typed::FnNote| Text::from(format!("  (fn {} {} {} {})\n", &quote(&x.name), &at_text(srcs, &x.at), &col_sexp(&x.declared), &col_sexp(&x.body))))));
    let methods = concat(&each(&filter(&tp.methods, &(|x: &crate::check::typed::MethodNote| (&mine_fn)(&x.at))), &(|x: &crate::check::typed::MethodNote| Text::from(format!("  (method {} {} ^{})\n", &at_text(srcs, &x.at), &x.method, &x.cls)))));
    let impls = concat(&run_to_end(each_job(filter(&tp.impls, &(|x: &crate::check::typed::ImplNote| (&mine_fn)(&x.at))), {
        let srcs = srcs.clone();
        Rc::new(move |p0: crate::check::typed::ImplNote| {
            let srcs = srcs.clone();
            entered(once_job(move || {
                let x = p0;
                call_then(start_ty_sexp(x.ty.clone()), move |ty_sexp_4390: Text| prism_rtl::Turn::Finished(Text::from(format!("  (impl {} ^{} {} {})\n", &at_text(&srcs, &x.at), &x.cls, &ty_sexp_4390, &x.how))))
            }))
        }) as Rc<dyn Fn(crate::check::typed::ImplNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let groups = concat(&each(&filter(&tp.groups, &(|x: &crate::check::typed::GroupNote| (&mine_fn)(&x.at))), &(|x: &crate::check::typed::GroupNote| Text::from(format!("  (group {} {}{})\n", &x.kind, &at_text(srcs, &x.at), &concat(&each(&x.order, &(|c: &Array<Nat>| Text::from(format!(" ({})", &crate::syntax::lexer::chars::join(&each(c, &(|i: &Nat| Text::from(format!("{}", i)))), &Text::lit(" "))))))))))));
    let binders = concat(&run_to_end(each_job(filter(&tp.binders, &(|x: &crate::check::typed::BinderNote| (&mine_fn)(&x.at))), {
        let srcs = srcs.clone();
        Rc::new(move |p0: crate::check::typed::BinderNote| {
            let srcs = srcs.clone();
            entered(once_job(move || {
                let x = p0;
                call_then(start_ty_sexp(x.ty.clone()), move |ty_sexp_4718: Text| prism_rtl::Turn::Finished(Text::from(format!("  (binder {} {} {})\n", &quote(&x.name), &at_text(&srcs, &x.at), &ty_sexp_4718))))
            }))
        }) as Rc<dyn Fn(crate::check::typed::BinderNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let gens = concat(&each(&filter(&tp.gens, &(|x: &crate::check::typed::GenNote| (&mine_fn)(&x.at))), &(|x: &crate::check::typed::GenNote| Text::from(format!("  (gen {} {}{}{})\n", &quote(&x.name), &at_text(srcs, &x.at), &concat(&each(&x.tys, &(|q: &Text| Text::from(format!(" {}", q))))), &concat(&each(&x.cols, &(|q: &Text| Text::from(format!(" {}", q))))))))));
    let insts = concat(&run_to_end(each_job(filter(&tp.insts, &(|x: &crate::check::typed::InstNote| (&mine_fn)(&x.at))), {
        let srcs = srcs.clone();
        Rc::new(move |p0: crate::check::typed::InstNote| {
            let srcs = srcs.clone();
            entered(once_job(move || {
                let x = p0;
                call_value(each_job(x.tys.clone(), Rc::new(move |p0: (Text, crate::check::types::Ty)| entered(once_job(move || {
                    let (q, t) = p0;
                    call_then(start_ty_sexp(t.clone()), move |ty_sexp_5073: Text| prism_rtl::Turn::Finished(Text::from(format!(" ({} {})", &q, &ty_sexp_5073))))
                }))) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5041: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("  (inst {} {}{}{})\n", &quote(&x.name), &at_text(&srcs, &x.at), &concat(&each_5041), &concat(&each(&x.cols, &(|(q, c): &(Text, crate::check::types::Col)| Text::from(format!(" ({} {})", q, &col_sexp(c))))))))))
            }))
        }) as Rc<dyn Fn(crate::check::typed::InstNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    Text::from(format!("(typed\n (defs\n{} )\n (exprs\n{} )\n (apps\n{} )\n (fns\n{} )\n (methods\n{} )\n (impls\n{} )\n (groups\n{} )\n (binders\n{} )\n (gens\n{} )\n (insts\n{} ))\n", &defs, &exprs, &apps, &fns, &methods, &impls, &groups, &binders, &gens, &insts))
}

/// The step machine of `TypedSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
/// ```
pub struct TypedSexp {
    pub srcs: Array<crate::check::errors::Src>,
    pub trees: Array<crate::syntax::Module>,
    pub shown_: Nat,
    pub tp: crate::check::typed::TProgram,
}

impl prism_rtl::Job<Text> for TypedSexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs = &self.srcs;
        let trees = &self.trees;
        let shown_ = &self.shown_;
        let tp = &self.tp;
        let tys = fold(&tp.exprs, &Map::new(), &(|m: &Map<Text, crate::check::types::Ty>, n: &crate::check::typed::TyNote| insert(m, &crate::check::typed::at_key(&n.at), &n.ty)));
        let files = filter(&crate::check::errors::range0(&len(trees)), &(|i: &Nat| i < shown_));
        let shown_ = shown_.clone();
        let srcs = srcs.clone();
        let tp = tp.clone();
        let trees = trees.clone();
        call_value(each_job(filter(&tp.defs, &(|d: &crate::check::typed::DefNote| &d.at.file < &shown_)), {
            let srcs = srcs.clone();
            Rc::new(move |p0: crate::check::typed::DefNote| {
                let srcs = srcs.clone();
                entered(once_job(move || {
                    let d = p0;
                    call_then(start_scheme_sexp(d.scheme.clone()), move |scheme_sexp_3620: Text| prism_rtl::Turn::Finished(Text::from(format!("  (def {} {} {})\n", &d.name, &at_text(&srcs, &d.at), &scheme_sexp_3620))))
                }))
            }) as Rc<dyn Fn(crate::check::typed::DefNote) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_3530: Array<Text>| {
            let defs = concat(&each_3530);
            call_value(each_job(files.clone(), {
                let srcs = srcs.clone();
                let tys = tys.clone();
                let trees = trees.clone();
                Rc::new(move |p0: Nat| {
                    let srcs = srcs.clone();
                    let tys = tys.clone();
                    let trees = trees.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(ExprsOfFile { srcs: srcs.clone(), tys: tys.clone(), file: i.clone(), m: or(&index(&trees, &i), &empty_mod()) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_3670: Array<Text>| {
                let exprs = concat(&each_3670);
                let mine_fn = {
                    let shown_ = shown_.clone();
                    Rc::new(move |a: &crate::check::typed::SrcAt| shown(a, &shown_))
                };
                let apps = concat(&each(&filter(&tp.apps, &(|x: &crate::check::typed::AppNote| (&mine_fn)(&x.at))), &(|x: &crate::check::typed::AppNote| Text::from(format!("  (app {} {} {} {} (lifted{}) {} {})\n", &at_text(&srcs, &x.at), &quote(&x.callee), &x.kind, &layer_word(&x.layer), &concat(&each(&x.lifted, &(|i: &Nat| Text::from(format!(" {}", i))))), &layer_word(&x.inner), &col_sexp(&x.color))))));
                let fns = concat(&each(&filter(&tp.fns, &(|x: &crate::check::typed::FnNote| (&mine_fn)(&x.at))), &(|x: &crate::check::typed::FnNote| Text::from(format!("  (fn {} {} {} {})\n", &quote(&x.name), &at_text(&srcs, &x.at), &col_sexp(&x.declared), &col_sexp(&x.body))))));
                let methods = concat(&each(&filter(&tp.methods, &(|x: &crate::check::typed::MethodNote| (&mine_fn)(&x.at))), &(|x: &crate::check::typed::MethodNote| Text::from(format!("  (method {} {} ^{})\n", &at_text(&srcs, &x.at), &x.method, &x.cls)))));
                call_value(each_job(filter(&tp.impls, &(|x: &crate::check::typed::ImplNote| (&mine_fn)(&x.at))), {
                    let srcs = srcs.clone();
                    Rc::new(move |p0: crate::check::typed::ImplNote| {
                        let srcs = srcs.clone();
                        entered(once_job(move || {
                            let x = p0;
                            call_then(start_ty_sexp(x.ty.clone()), move |ty_sexp_4390: Text| prism_rtl::Turn::Finished(Text::from(format!("  (impl {} ^{} {} {})\n", &at_text(&srcs, &x.at), &x.cls, &ty_sexp_4390, &x.how))))
                        }))
                    }) as Rc<dyn Fn(crate::check::typed::ImplNote) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_4306: Array<Text>| {
                    let impls = concat(&each_4306);
                    let groups = concat(&each(&filter(&tp.groups, &(|x: &crate::check::typed::GroupNote| (&mine_fn)(&x.at))), &(|x: &crate::check::typed::GroupNote| Text::from(format!("  (group {} {}{})\n", &x.kind, &at_text(&srcs, &x.at), &concat(&each(&x.order, &(|c: &Array<Nat>| Text::from(format!(" ({})", &crate::syntax::lexer::chars::join(&each(c, &(|i: &Nat| Text::from(format!("{}", i)))), &Text::lit(" "))))))))))));
                    call_value(each_job(filter(&tp.binders, &(|x: &crate::check::typed::BinderNote| (&mine_fn)(&x.at))), {
                        let srcs = srcs.clone();
                        Rc::new(move |p0: crate::check::typed::BinderNote| {
                            let srcs = srcs.clone();
                            entered(once_job(move || {
                                let x = p0;
                                call_then(start_ty_sexp(x.ty.clone()), move |ty_sexp_4718: Text| prism_rtl::Turn::Finished(Text::from(format!("  (binder {} {} {})\n", &quote(&x.name), &at_text(&srcs, &x.at), &ty_sexp_4718))))
                            }))
                        }) as Rc<dyn Fn(crate::check::typed::BinderNote) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_4624: Array<Text>| {
                        let binders = concat(&each_4624);
                        let gens = concat(&each(&filter(&tp.gens, &(|x: &crate::check::typed::GenNote| (&mine_fn)(&x.at))), &(|x: &crate::check::typed::GenNote| Text::from(format!("  (gen {} {}{}{})\n", &quote(&x.name), &at_text(&srcs, &x.at), &concat(&each(&x.tys, &(|q: &Text| Text::from(format!(" {}", q))))), &concat(&each(&x.cols, &(|q: &Text| Text::from(format!(" {}", q))))))))));
                        call_value(each_job(filter(&tp.insts, &(|x: &crate::check::typed::InstNote| (&mine_fn)(&x.at))), {
                            let srcs = srcs.clone();
                            Rc::new(move |p0: crate::check::typed::InstNote| {
                                let srcs = srcs.clone();
                                entered(once_job(move || {
                                    let x = p0;
                                    call_value(each_job(x.tys.clone(), Rc::new(move |p0: (Text, crate::check::types::Ty)| entered(once_job(move || {
                                        let (q, t) = p0;
                                        call_then(start_ty_sexp(t.clone()), move |ty_sexp_5073: Text| prism_rtl::Turn::Finished(Text::from(format!(" ({} {})", &q, &ty_sexp_5073))))
                                    }))) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5041: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("  (inst {} {}{}{})\n", &quote(&x.name), &at_text(&srcs, &x.at), &concat(&each_5041), &concat(&each(&x.cols, &(|(q, c): &(Text, crate::check::types::Col)| Text::from(format!(" ({} {})", q, &col_sexp(c))))))))))
                                }))
                            }) as Rc<dyn Fn(crate::check::typed::InstNote) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_4944: Array<Text>| {
                            let insts = concat(&each_4944);
                            prism_rtl::Turn::Finished(Text::from(format!("(typed\n (defs\n{} )\n (exprs\n{} )\n (apps\n{} )\n (fns\n{} )\n (methods\n{} )\n (impls\n{} )\n (groups\n{} )\n (binders\n{} )\n (gens\n{} )\n (insts\n{} ))\n", &defs, &exprs, &apps, &fns, &methods, &impls, &groups, &binders, &gens, &insts)))
                        })
                    })
                })
            })
        })
    }
}

/// `Start TypedSexp, x`: what the function value is when passed to `@Run`.
pub fn start_typed_sexp(srcs: Array<crate::check::errors::Src>, trees: Array<crate::syntax::Module>, shown_: Nat, tp: crate::check::typed::TProgram) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypedSexp { srcs, trees, shown_, tp })
}

/// ```prism
/// Shown: fn SrcAt, Nat -> Bool
/// ```
pub fn shown(a: &crate::check::typed::SrcAt, shown_: &Nat) -> bool {
    &a.file < shown_
}

/// ```prism
/// let emptyMod
/// ```
pub fn empty_mod() -> crate::syntax::Module {
    crate::syntax::Module { name: None, emit_row: None, mods: Array::new(), uses: Array::new(), decls: Array::new(), template: None, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// Quote: fn Text -> Text
/// ```
pub fn quote(t: &Text) -> Text {
    Text::from(format!("\"{}\"", t))
}

/// ```prism
/// LayerWord: fn Text -> Text
/// ```
pub fn layer_word(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("")) => Text::lit("-"),
        s => s.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
/// ```
pub fn exprs_of_file(srcs: &Array<crate::check::errors::Src>, tys: &Map<Text, crate::check::types::Ty>, file: &Nat, m: &crate::syntax::Module) -> Text {
    let es = run_to_end(fold_job(m.decls.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::Decl)| entered(once_job(move || {
        let acc = p0;
        let d = p1;
        call_then(start_decl_exprs(d.clone()), move |decl_exprs_5893: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &decl_exprs_5893)))
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>));
    concat(&run_to_end(each_job(es.clone(), {
        let srcs = srcs.clone();
        let tys = tys.clone();
        let file = file.clone();
        Rc::new(move |p0: crate::syntax::Expr| {
            let srcs = srcs.clone();
            let tys = tys.clone();
            let file = file.clone();
            entered(once_job(move || {
                let e = p0;
                prism_rtl::Turn::More(Rc::new(ExprLine { srcs: srcs.clone(), tys: tys.clone(), a: crate::check::typed::SrcAt { file: file.clone(), span: e.span.clone() } }))
            }))
        }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Text>>>
    })))
}

/// The step machine of `ExprsOfFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
/// ```
pub struct ExprsOfFile {
    pub srcs: Array<crate::check::errors::Src>,
    pub tys: Map<Text, crate::check::types::Ty>,
    pub file: Nat,
    pub m: crate::syntax::Module,
}

impl prism_rtl::Job<Text> for ExprsOfFile {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs = &self.srcs;
        let tys = &self.tys;
        let file = &self.file;
        let m = &self.m;
        let file = file.clone();
        let m = m.clone();
        let srcs = srcs.clone();
        let tys = tys.clone();
        call_value(fold_job(m.decls.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::Decl)| entered(once_job(move || {
            let acc = p0;
            let d = p1;
            call_then(start_decl_exprs(d.clone()), move |decl_exprs_5893: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &decl_exprs_5893)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>), move |fold_5850: Array<crate::syntax::Expr>| {
            let es = fold_5850;
            call_value(each_job(es.clone(), {
                let srcs = srcs.clone();
                let tys = tys.clone();
                let file = file.clone();
                Rc::new(move |p0: crate::syntax::Expr| {
                    let srcs = srcs.clone();
                    let tys = tys.clone();
                    let file = file.clone();
                    entered(once_job(move || {
                        let e = p0;
                        prism_rtl::Turn::More(Rc::new(ExprLine { srcs: srcs.clone(), tys: tys.clone(), a: crate::check::typed::SrcAt { file: file.clone(), span: e.span.clone() } }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_5918: Array<Text>| prism_rtl::Turn::Finished(concat(&each_5918)))
        })
    }
}

/// `Start ExprsOfFile, x`: what the function value is when passed to `@Run`.
pub fn start_exprs_of_file(srcs: Array<crate::check::errors::Src>, tys: Map<Text, crate::check::types::Ty>, file: Nat, m: crate::syntax::Module) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ExprsOfFile { srcs, tys, file, m })
}

/// ```prism
/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
/// ```
pub fn expr_line(srcs: &Array<crate::check::errors::Src>, tys: &Map<Text, crate::check::types::Ty>, a: &crate::check::typed::SrcAt) -> Text {
    Text::from(format!("  (expr {} {})\n", &at_text(srcs, a), &ty_sexp(&or(&get(tys, &crate::check::typed::at_key(a)), &crate::check::types::Ty::TyErr))))
}

/// The step machine of `ExprLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
/// ```
pub struct ExprLine {
    pub srcs: Array<crate::check::errors::Src>,
    pub tys: Map<Text, crate::check::types::Ty>,
    pub a: crate::check::typed::SrcAt,
}

impl prism_rtl::Job<Text> for ExprLine {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs = &self.srcs;
        let tys = &self.tys;
        let a = &self.a;
        let a = a.clone();
        let srcs = srcs.clone();
        let tys = tys.clone();
        call_then(start_ty_sexp(or(&get(&tys, &crate::check::typed::at_key(&a)), &crate::check::types::Ty::TyErr)), move |ty_sexp_6097: Text| prism_rtl::Turn::Finished(Text::from(format!("  (expr {} {})\n", &at_text(&srcs, &a), &ty_sexp_6097))))
    }
}

/// `Start ExprLine, x`: what the function value is when passed to `@Run`.
pub fn start_expr_line(srcs: Array<crate::check::errors::Src>, tys: Map<Text, crate::check::types::Ty>, a: crate::check::typed::SrcAt) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ExprLine { srcs, tys, a })
}

/// ```prism
/// DeclExprs: unbounded fn Decl -> [Expr]
/// ```
pub fn decl_exprs(d: &crate::syntax::decls::Decl) -> Array<crate::syntax::Expr> {
    match &d.kind {
        crate::syntax::decls::DeclKind::DFn(f) => body_exprs(&f.body),
        crate::syntax::decls::DeclKind::DLet(l) => exprs_in(&l.value),
        crate::syntax::decls::DeclKind::DWidget(w) => stmts_exprs(&w.body.stmts),
        crate::syntax::decls::DeclKind::DTrait(t) => run_to_end(fold_job(t.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)| entered(once_job(move || {
            let acc = p0;
            let it = p1;
            match &it {
                crate::syntax::decls::TraitItem::TiFn(f) => {
                    let f = f.clone();
                    call_then(start_body_exprs(f.body.clone()), move |body_exprs_6384: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_6384)))
                },
                _ => prism_rtl::Turn::Finished(acc.clone()),
            }
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::decls::DeclKind::DImpl(i) => run_to_end(fold_job(i.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)| entered(once_job(move || {
            let acc = p0;
            let it = p1;
            match &it {
                crate::syntax::decls::TraitItem::TiFn(f) => {
                    let f = f.clone();
                    call_then(start_body_exprs(f.body.clone()), move |body_exprs_6508: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_6508)))
                },
                _ => prism_rtl::Turn::Finished(acc.clone()),
            }
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::decls::DeclKind::DCheck(c) => run_to_end(fold_job(c.lines.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine)| entered(once_job(move || {
            let acc = p0;
            let l = p1;
            call_then(start_exprs_in(l.expr.clone()), move |exprs_in_6606: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_6606)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::decls::DeclKind::DTest(t) => exprs_in(&t.blueprint),
        _ => Array::new(),
    }
}

/// The step machine of `DeclExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeclExprs: unbounded fn Decl -> [Expr]
/// ```
pub struct DeclExprs {
    pub d: crate::syntax::decls::Decl,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for DeclExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let d = &self.d;
        match &d.kind {
            crate::syntax::decls::DeclKind::DFn(f) => prism_rtl::Turn::More(Rc::new(BodyExprs { fn_body0: f.body.clone() })),
            crate::syntax::decls::DeclKind::DLet(l) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: l.value.clone() })),
            crate::syntax::decls::DeclKind::DWidget(w) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts: w.body.stmts.clone() })),
            crate::syntax::decls::DeclKind::DTrait(t) => fold_job(t.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)| entered(once_job(move || {
                let acc = p0;
                let it = p1;
                match &it {
                    crate::syntax::decls::TraitItem::TiFn(f) => {
                        let f = f.clone();
                        call_then(start_body_exprs(f.body.clone()), move |body_exprs_6384: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_6384)))
                    },
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle(),
            crate::syntax::decls::DeclKind::DImpl(i) => fold_job(i.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)| entered(once_job(move || {
                let acc = p0;
                let it = p1;
                match &it {
                    crate::syntax::decls::TraitItem::TiFn(f) => {
                        let f = f.clone();
                        call_then(start_body_exprs(f.body.clone()), move |body_exprs_6508: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_6508)))
                    },
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle(),
            crate::syntax::decls::DeclKind::DCheck(c) => fold_job(c.lines.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine)| entered(once_job(move || {
                let acc = p0;
                let l = p1;
                call_then(start_exprs_in(l.expr.clone()), move |exprs_in_6606: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_6606)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle(),
            crate::syntax::decls::DeclKind::DTest(t) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: t.blueprint.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start DeclExprs, x`: what the function value is when passed to `@Run`.
pub fn start_decl_exprs(d: crate::syntax::decls::Decl) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(DeclExprs { d })
}

/// ```prism
/// BodyExprs: unbounded fn FnBody -> [Expr]
/// ```
pub fn body_exprs(fn_body0: &crate::syntax::decls::FnBody) -> Array<crate::syntax::Expr> {
    match fn_body0 {
        crate::syntax::decls::FnBody::BodyExpr(e) => exprs_in(e),
        crate::syntax::decls::FnBody::BodyBlock(b) => stmts_exprs(&b.stmts),
    }
}

/// The step machine of `BodyExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodyExprs: unbounded fn FnBody -> [Expr]
/// ```
pub struct BodyExprs {
    pub fn_body0: crate::syntax::decls::FnBody,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for BodyExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let fn_body0 = &self.fn_body0;
        match fn_body0 {
            crate::syntax::decls::FnBody::BodyExpr(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            crate::syntax::decls::FnBody::BodyBlock(b) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts: b.stmts.clone() })),
        }
    }
}

/// `Start BodyExprs, x`: what the function value is when passed to `@Run`.
pub fn start_body_exprs(fn_body0: crate::syntax::decls::FnBody) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(BodyExprs { fn_body0 })
}

/// ```prism
/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
/// ```
pub fn stmts_exprs(stmts: &Array<crate::syntax::Stmt>) -> Array<crate::syntax::Expr> {
    run_to_end(fold_job(stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Stmt)| entered(once_job(move || {
        let acc = p0;
        let s = p1;
        call_then(start_stmt_exprs(s.clone()), move |stmt_exprs_6909: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &stmt_exprs_6909)))
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>))
}

/// The step machine of `StmtsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
/// ```
pub struct StmtsExprs {
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for StmtsExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let stmts = &self.stmts;
        fold_job(stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Stmt)| entered(once_job(move || {
            let acc = p0;
            let s = p1;
            call_then(start_stmt_exprs(s.clone()), move |stmt_exprs_6909: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &stmt_exprs_6909)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle()
    }
}

/// `Start StmtsExprs, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_exprs(stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(StmtsExprs { stmts })
}

/// ```prism
/// StmtExprs: unbounded fn Stmt -> [Expr]
/// ```
pub fn stmt_exprs(s: &crate::syntax::Stmt) -> Array<crate::syntax::Expr> {
    match &s.kind {
        crate::syntax::StmtKind::SBind(_, e, t_opt) => match t_opt {
            Some(x) => append(&exprs_in(e), &exprs_in(x)),
            None => exprs_in(e),
        },
        crate::syntax::StmtKind::SIgnore(e) => exprs_in(e),
        crate::syntax::StmtKind::SLet(_, _, e) => exprs_in(e),
        crate::syntax::StmtKind::SFn(f) => body_exprs(&f.body),
        crate::syntax::StmtKind::SWidget(w) => stmts_exprs(&w.body.stmts),
        crate::syntax::StmtKind::SSet(t, v_) => append(&exprs_in(t), &exprs_in(v_)),
        crate::syntax::StmtKind::SAccum(t, _, v_) => append(&exprs_in(t), &exprs_in(v_)),
        crate::syntax::StmtKind::SRequire(c) => exprs_in(c),
        crate::syntax::StmtKind::SForbid(c) => exprs_in(c),
        crate::syntax::StmtKind::SWhile(c, b) => append(&cond_exprs(c), &stmts_exprs(&b.stmts)),
        crate::syntax::StmtKind::SReturn(e) => exprs_in(e),
        crate::syntax::StmtKind::SExpr(e) => exprs_in(e),
        _ => Array::new(),
    }
}

/// The step machine of `StmtExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtExprs: unbounded fn Stmt -> [Expr]
/// ```
pub struct StmtExprs {
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for StmtExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SBind(_, e, t_opt) => match t_opt {
                Some(x) => {
                    let e = e.clone();
                    let x = x.clone();
                    call_then(start_exprs_in(e.clone()), move |exprs_in_7049: Array<crate::syntax::Expr>| call_then(start_exprs_in(x.clone()), move |exprs_in_7062: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_7049, &exprs_in_7062))))
                },
                None => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            },
            crate::syntax::StmtKind::SIgnore(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            crate::syntax::StmtKind::SLet(_, _, e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            crate::syntax::StmtKind::SFn(f) => prism_rtl::Turn::More(Rc::new(BodyExprs { fn_body0: f.body.clone() })),
            crate::syntax::StmtKind::SWidget(w) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts: w.body.stmts.clone() })),
            crate::syntax::StmtKind::SSet(t, v_) => {
                let t = t.clone();
                let v_ = v_.clone();
                call_then(start_exprs_in(t.clone()), move |exprs_in_7249: Array<crate::syntax::Expr>| call_then(start_exprs_in(v_.clone()), move |exprs_in_7262: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_7249, &exprs_in_7262))))
            },
            crate::syntax::StmtKind::SAccum(t, _, v_) => {
                let t = t.clone();
                let v_ = v_.clone();
                call_then(start_exprs_in(t.clone()), move |exprs_in_7306: Array<crate::syntax::Expr>| call_then(start_exprs_in(v_.clone()), move |exprs_in_7319: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_7306, &exprs_in_7319))))
            },
            crate::syntax::StmtKind::SRequire(c) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: c.clone() })),
            crate::syntax::StmtKind::SForbid(c) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: c.clone() })),
            crate::syntax::StmtKind::SWhile(c, b) => {
                let b = b.clone();
                let c = c.clone();
                call_then(start_cond_exprs(c.clone()), move |cond_exprs_7406: Array<crate::syntax::Expr>| call_then(start_stmts_exprs(b.stmts.clone()), move |stmts_exprs_7421: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&cond_exprs_7406, &stmts_exprs_7421))))
            },
            crate::syntax::StmtKind::SReturn(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            crate::syntax::StmtKind::SExpr(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start StmtExprs, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_exprs(s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(StmtExprs { s })
}

/// ```prism
/// CondExprs: unbounded fn Cond -> [Expr]
/// ```
pub fn cond_exprs(cond0: &crate::syntax::Cond) -> Array<crate::syntax::Expr> {
    match cond0 {
        crate::syntax::Cond::CondExpr(e) => exprs_in(&**e),
        crate::syntax::Cond::CondBind(_, e, g_opt) => append(&exprs_in(&**e), &opt_exprs(&**g_opt)),
    }
}

/// The step machine of `CondExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondExprs: unbounded fn Cond -> [Expr]
/// ```
pub struct CondExprs {
    pub cond0: crate::syntax::Cond,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for CondExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let cond0 = &self.cond0;
        match cond0 {
            crate::syntax::Cond::CondExpr(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: (**e).clone() })),
            crate::syntax::Cond::CondBind(_, e, g_opt) => {
                let g_opt = (**g_opt).clone();
                let e = (**e).clone();
                call_then(start_exprs_in(e.clone()), move |exprs_in_7635: Array<crate::syntax::Expr>| call_then(start_opt_exprs(g_opt.clone()), move |opt_exprs_7648: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_7635, &opt_exprs_7648))))
            },
        }
    }
}

/// `Start CondExprs, x`: what the function value is when passed to `@Run`.
pub fn start_cond_exprs(cond0: crate::syntax::Cond) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(CondExprs { cond0 })
}

/// ```prism
/// ArgsExprs: unbounded fn [Arg] -> [Expr]
/// ```
pub fn args_exprs(args: &Array<crate::syntax::Arg>) -> Array<crate::syntax::Expr> {
    run_to_end(fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arg)| entered(once_job(move || {
        let acc = p0;
        let a = p1;
        call_then(start_exprs_in(a.value.clone()), move |exprs_in_7762: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_7762)))
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>))
}

/// The step machine of `ArgsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgsExprs: unbounded fn [Arg] -> [Expr]
/// ```
pub struct ArgsExprs {
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for ArgsExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let args = &self.args;
        fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arg)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_exprs_in(a.value.clone()), move |exprs_in_7762: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_7762)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle()
    }
}

/// `Start ArgsExprs, x`: what the function value is when passed to `@Run`.
pub fn start_args_exprs(args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(ArgsExprs { args })
}

/// ```prism
/// BlockExprs: unbounded fn Block -> [Expr]
/// ```
pub fn block_exprs(b: &crate::syntax::Block) -> Array<crate::syntax::Expr> {
    stmts_exprs(&b.stmts)
}

/// The step machine of `BlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockExprs: unbounded fn Block -> [Expr]
/// ```
pub struct BlockExprs {
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for BlockExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let b = &self.b;
        prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts: b.stmts.clone() }))
    }
}

/// `Start BlockExprs, x`: what the function value is when passed to `@Run`.
pub fn start_block_exprs(b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(BlockExprs { b })
}

/// ```prism
/// ExprsIn: unbounded fn Expr -> [Expr]
/// ```
pub fn exprs_in(e: &crate::syntax::Expr) -> Array<crate::syntax::Expr> {
    let inner = match &*e.kind {
        crate::syntax::ExprKind::ETuple(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| entered(once_job(move || {
            let acc = p0;
            let x = p1;
            call_then(start_exprs_in(x.clone()), move |exprs_in_8148: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_8148)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::EArray(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| entered(once_job(move || {
            let acc = p0;
            let x = p1;
            call_then(start_exprs_in(x.clone()), move |exprs_in_8216: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_8216)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::EMap(kvs) => run_to_end(fold_job(kvs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))| entered(once_job(move || {
            let acc = p0;
            let (k, v_) = p1;
            call_then(start_exprs_in(k.clone()), move |exprs_in_8299: Array<crate::syntax::Expr>| call_then(start_exprs_in(v_.clone()), move |exprs_in_8313: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &exprs_in_8299), &exprs_in_8313))))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::EGroup(x) => exprs_in(&**x),
        crate::syntax::ExprKind::ECall(c, args, _, _) => append(&exprs_in(&**c), &args_exprs(args)),
        crate::syntax::ExprKind::EBinary(_, l, r) => append(&exprs_in(&**l), &exprs_in(&**r)),
        crate::syntax::ExprKind::EUnary(_, x) => exprs_in(&**x),
        crate::syntax::ExprKind::EFreeSigil(_, x) => exprs_in(&**x),
        crate::syntax::ExprKind::EField(r, _, _) => exprs_in(&**r),
        crate::syntax::ExprKind::EIndex(r, i) => append(&exprs_in(&**r), &exprs_in(&**i)),
        crate::syntax::ExprKind::ETopicIndex(x) => exprs_in(&**x),
        crate::syntax::ExprKind::EMethod(r, _, args) => append(&exprs_in(&**r), &args_exprs(args)),
        crate::syntax::ExprKind::ETypeArgs(x, _) => exprs_in(&**x),
        crate::syntax::ExprKind::ECast(x, _, _) => exprs_in(&**x),
        crate::syntax::ExprKind::ELambda(_, body) => match &**body {
            crate::syntax::LambdaBody::LbExpr(x) => exprs_in(&**x),
            crate::syntax::LambdaBody::LbBlock(b) => block_exprs(b),
        },
        crate::syntax::ExprKind::EIf(c, t, el_opt) => append(&append(&cond_exprs(&**c), &block_exprs(t)), &opt_block_exprs(el_opt)),
        crate::syntax::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), exprs_in(&**s), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arm)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_opt_exprs(a.guard.clone()), move |opt_exprs_9127: Array<crate::syntax::Expr>| call_then(start_block_exprs(a.body.clone()), move |block_exprs_9149: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &opt_exprs_9127), &block_exprs_9149))))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::syntax::ExprKind::ERebuild(s, b) => append(&exprs_in(&**s), &block_exprs(b)),
        crate::syntax::ExprKind::EFor(_, s, b) => append(&exprs_in(&**s), &block_exprs(b)),
        crate::syntax::ExprKind::EGiven(b) => block_exprs(b),
        crate::syntax::ExprKind::EUpdate(t, b) => append(&exprs_in(&**t), &block_exprs(b)),
        crate::syntax::ExprKind::EWidgetBlock(b) => block_exprs(b),
        crate::syntax::ExprKind::EAny(x) => exprs_in(&**x),
        crate::syntax::ExprKind::ELit(l) => match &l.kind {
            crate::syntax::LitKind::LText(segs) => run_to_end(fold_job(segs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TextSeg)| entered(once_job(move || {
                let acc = p0;
                let sg = p1;
                match &sg {
                    crate::syntax::TextSeg::SegPlaceholder(x) => {
                        let x = x.clone();
                        call_then(start_exprs_in(x.clone()), move |exprs_in_9578: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_9578)))
                    },
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TextSeg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            _ => Array::new(),
        },
        crate::syntax::ExprKind::ETemplate(t) => template_exprs(&t.parts),
        _ => Array::new(),
    };
    match &*e.kind {
        crate::syntax::ExprKind::ERest => inner.clone(),
        crate::syntax::ExprKind::EError => inner.clone(),
        _ => append(&Array::from(vec![e.clone()]), &inner),
    }
}

/// The step machine of `ExprsIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprsIn: unbounded fn Expr -> [Expr]
/// ```
pub struct ExprsIn {
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for ExprsIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let e = &self.e;
        let inner = match &*e.kind {
            crate::syntax::ExprKind::ETuple(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| entered(once_job(move || {
                let acc = p0;
                let x = p1;
                call_then(start_exprs_in(x.clone()), move |exprs_in_8148: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_8148)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::EArray(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Expr)| entered(once_job(move || {
                let acc = p0;
                let x = p1;
                call_then(start_exprs_in(x.clone()), move |exprs_in_8216: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_8216)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::EMap(kvs) => run_to_end(fold_job(kvs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))| entered(once_job(move || {
                let acc = p0;
                let (k, v_) = p1;
                call_then(start_exprs_in(k.clone()), move |exprs_in_8299: Array<crate::syntax::Expr>| call_then(start_exprs_in(v_.clone()), move |exprs_in_8313: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &exprs_in_8299), &exprs_in_8313))))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::EGroup(x) => exprs_in(&**x),
            crate::syntax::ExprKind::ECall(c, args, _, _) => append(&exprs_in(&**c), &args_exprs(args)),
            crate::syntax::ExprKind::EBinary(_, l, r) => append(&exprs_in(&**l), &exprs_in(&**r)),
            crate::syntax::ExprKind::EUnary(_, x) => exprs_in(&**x),
            crate::syntax::ExprKind::EFreeSigil(_, x) => exprs_in(&**x),
            crate::syntax::ExprKind::EField(r, _, _) => exprs_in(&**r),
            crate::syntax::ExprKind::EIndex(r, i) => append(&exprs_in(&**r), &exprs_in(&**i)),
            crate::syntax::ExprKind::ETopicIndex(x) => exprs_in(&**x),
            crate::syntax::ExprKind::EMethod(r, _, args) => append(&exprs_in(&**r), &args_exprs(args)),
            crate::syntax::ExprKind::ETypeArgs(x, _) => exprs_in(&**x),
            crate::syntax::ExprKind::ECast(x, _, _) => exprs_in(&**x),
            crate::syntax::ExprKind::ELambda(_, body) => match &**body {
                crate::syntax::LambdaBody::LbExpr(x) => exprs_in(&**x),
                crate::syntax::LambdaBody::LbBlock(b) => block_exprs(b),
            },
            crate::syntax::ExprKind::EIf(c, t, el_opt) => append(&append(&cond_exprs(&**c), &block_exprs(t)), &opt_block_exprs(el_opt)),
            crate::syntax::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), exprs_in(&**s), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::Arm)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_opt_exprs(a.guard.clone()), move |opt_exprs_9127: Array<crate::syntax::Expr>| call_then(start_block_exprs(a.body.clone()), move |block_exprs_9149: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &opt_exprs_9127), &block_exprs_9149))))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::syntax::ExprKind::ERebuild(s, b) => append(&exprs_in(&**s), &block_exprs(b)),
            crate::syntax::ExprKind::EFor(_, s, b) => append(&exprs_in(&**s), &block_exprs(b)),
            crate::syntax::ExprKind::EGiven(b) => block_exprs(b),
            crate::syntax::ExprKind::EUpdate(t, b) => append(&exprs_in(&**t), &block_exprs(b)),
            crate::syntax::ExprKind::EWidgetBlock(b) => block_exprs(b),
            crate::syntax::ExprKind::EAny(x) => exprs_in(&**x),
            crate::syntax::ExprKind::ELit(l) => match &l.kind {
                crate::syntax::LitKind::LText(segs) => run_to_end(fold_job(segs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TextSeg)| entered(once_job(move || {
                    let acc = p0;
                    let sg = p1;
                    match &sg {
                        crate::syntax::TextSeg::SegPlaceholder(x) => {
                            let x = x.clone();
                            call_then(start_exprs_in(x.clone()), move |exprs_in_9578: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_9578)))
                        },
                        _ => prism_rtl::Turn::Finished(acc.clone()),
                    }
                }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TextSeg)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
                _ => Array::new(),
            },
            crate::syntax::ExprKind::ETemplate(t) => template_exprs(&t.parts),
            _ => Array::new(),
        };
        match &*e.kind {
            crate::syntax::ExprKind::ERest => prism_rtl::Turn::Finished(inner.clone()),
            crate::syntax::ExprKind::EError => prism_rtl::Turn::Finished(inner.clone()),
            _ => prism_rtl::Turn::Finished(append(&Array::from(vec![e.clone()]), &inner)),
        }
    }
}

/// `Start ExprsIn, x`: what the function value is when passed to `@Run`.
pub fn start_exprs_in(e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(ExprsIn { e })
}

/// ```prism
/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
/// ```
pub fn template_exprs(parts: &Array<crate::syntax::TemplatePart>) -> Array<crate::syntax::Expr> {
    run_to_end(fold_job(parts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TemplatePart)| entered(once_job(move || {
        let acc = p0;
        let p_ = p1;
        match &p_ {
            crate::syntax::TemplatePart::TpPlaceholder(x, _) => {
                let x = x.clone();
                call_then(start_exprs_in(x.clone()), move |exprs_in_9973: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_9973)))
            },
            crate::syntax::TemplatePart::TpBlock(b) => {
                let b = b.clone();
                call_then(start_block_exprs(b.clone()), move |block_exprs_10012: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &block_exprs_10012)))
            },
            crate::syntax::TemplatePart::TpCall(_, args, ps_opt, _) => {
                let ps_opt = ps_opt.clone();
                let args = args.clone();
                call_then(start_args_exprs(args.clone()), move |args_exprs_10085: Array<crate::syntax::Expr>| call_then(start_opt_parts(ps_opt.clone()), move |opt_parts_10104: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &args_exprs_10085), &opt_parts_10104))))
            },
            _ => prism_rtl::Turn::Finished(acc.clone()),
        }
    }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>))
}

/// The step machine of `TemplateExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
/// ```
pub struct TemplateExprs {
    pub parts: Array<crate::syntax::TemplatePart>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for TemplateExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let parts = &self.parts;
        fold_job(parts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::TemplatePart)| entered(once_job(move || {
            let acc = p0;
            let p_ = p1;
            match &p_ {
                crate::syntax::TemplatePart::TpPlaceholder(x, _) => {
                    let x = x.clone();
                    call_then(start_exprs_in(x.clone()), move |exprs_in_9973: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_9973)))
                },
                crate::syntax::TemplatePart::TpBlock(b) => {
                    let b = b.clone();
                    call_then(start_block_exprs(b.clone()), move |block_exprs_10012: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &block_exprs_10012)))
                },
                crate::syntax::TemplatePart::TpCall(_, args, ps_opt, _) => {
                    let ps_opt = ps_opt.clone();
                    let args = args.clone();
                    call_then(start_args_exprs(args.clone()), move |args_exprs_10085: Array<crate::syntax::Expr>| call_then(start_opt_parts(ps_opt.clone()), move |opt_parts_10104: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &args_exprs_10085), &opt_parts_10104))))
                },
                _ => prism_rtl::Turn::Finished(acc.clone()),
            }
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>).cycle()
    }
}

/// `Start TemplateExprs, x`: what the function value is when passed to `@Run`.
pub fn start_template_exprs(parts: Array<crate::syntax::TemplatePart>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(TemplateExprs { parts })
}

/// ```prism
/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
/// ```
pub fn opt_parts(opt0: &Option<Array<crate::syntax::TemplatePart>>) -> Array<crate::syntax::Expr> {
    match opt0 {
        Some(ps) => template_exprs(ps),
        None => Array::new(),
    }
}

/// The step machine of `OptParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
/// ```
pub struct OptParts {
    pub opt0: Option<Array<crate::syntax::TemplatePart>>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for OptParts {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(ps) => prism_rtl::Turn::More(Rc::new(TemplateExprs { parts: ps.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptParts, x`: what the function value is when passed to `@Run`.
pub fn start_opt_parts(opt0: Option<Array<crate::syntax::TemplatePart>>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(OptParts { opt0 })
}

/// ```prism
/// OptBlockExprs: unbounded fn ?Block -> [Expr]
/// ```
pub fn opt_block_exprs(opt0: &Option<crate::syntax::Block>) -> Array<crate::syntax::Expr> {
    match opt0 {
        Some(b) => block_exprs(b),
        None => Array::new(),
    }
}

/// The step machine of `OptBlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptBlockExprs: unbounded fn ?Block -> [Expr]
/// ```
pub struct OptBlockExprs {
    pub opt0: Option<crate::syntax::Block>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for OptBlockExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(b) => prism_rtl::Turn::More(Rc::new(BlockExprs { b: b.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptBlockExprs, x`: what the function value is when passed to `@Run`.
pub fn start_opt_block_exprs(opt0: Option<crate::syntax::Block>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(OptBlockExprs { opt0 })
}

/// ```prism
/// OptExprs: unbounded fn ?Expr -> [Expr]
/// ```
pub fn opt_exprs(opt0: &Option<crate::syntax::Expr>) -> Array<crate::syntax::Expr> {
    match opt0 {
        Some(x) => exprs_in(x),
        None => Array::new(),
    }
}

/// The step machine of `OptExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptExprs: unbounded fn ?Expr -> [Expr]
/// ```
pub struct OptExprs {
    pub opt0: Option<crate::syntax::Expr>,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for OptExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(x) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: x.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptExprs, x`: what the function value is when passed to `@Run`.
pub fn start_opt_exprs(opt0: Option<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(OptExprs { opt0 })
}
