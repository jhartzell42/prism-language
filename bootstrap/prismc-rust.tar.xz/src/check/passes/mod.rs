//! The module `Check.Passes`, from `target/bootstrap/src/prismc/check/passes/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod borrows;
pub mod cycles;

/// `Ctor`:
///
/// ```prism
/// type Ctor = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Ctor {
    pub name_p: Text,
    pub arity_p: Nat,
    pub args_p: Array<crate::check::types::Ty>,
    pub shown_p: Text,
}

impl Show for Ctor {
    fn show(&self, p: &mut Printer) {
        p.record("Ctor", &[("name", &self.name_p), ("arity", &self.arity_p), ("args", &self.args_p), ("shown", &self.shown_p)]);
    }
}

impl ToPod for Ctor {
    fn to_pod(&self) -> Pod {
        Pod::record("Ctor", vec![("name", self.name_p.to_pod()), ("arity", self.arity_p.to_pod()), ("args", self.args_p.to_pod()), ("shown", self.shown_p.to_pod())])
    }
}

impl FromPod for Ctor {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Ctor { name_p: FromPod::from_pod(field(p, "name")?)?, arity_p: FromPod::from_pod(field(p, "arity")?)?, args_p: FromPod::from_pod(field(p, "args")?)?, shown_p: FromPod::from_pod(field(p, "shown")?)? })
    }
}

/// `Pat`:
///
/// ```prism
/// type Pat = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Pat {
    PtAny,
    PtCon(Text, Array<Pat>),
    PtLit(Text),
    PtFam(Text),
}

impl Show for Pat {
    fn show(&self, p: &mut Printer) {
        match self {
            Pat::PtAny => p.choice("PtAny", &[]),
            Pat::PtCon(a0, a1) => p.choice("PtCon", &[a0, a1]),
            Pat::PtLit(a0) => p.choice("PtLit", &[a0]),
            Pat::PtFam(a0) => p.choice("PtFam", &[a0]),
        }
    }
}

impl ToPod for Pat {
    fn to_pod(&self) -> Pod {
        match self {
            Pat::PtAny => Pod::Choice("PtAny".into(), vec![]),
            Pat::PtCon(a0, a1) => Pod::Choice("PtCon".into(), vec![a0.to_pod(), a1.to_pod()]),
            Pat::PtLit(a0) => Pod::Choice("PtLit".into(), vec![a0.to_pod()]),
            Pat::PtFam(a0) => Pod::Choice("PtFam".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Pat {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "PtAny" && a.len() == 0 => Ok(Pat::PtAny),
            Pod::Choice(c, a) if &**c == "PtCon" && a.len() == 2 => Ok(Pat::PtCon(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "PtLit" && a.len() == 1 => Ok(Pat::PtLit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PtFam" && a.len() == 1 => Ok(Pat::PtFam(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Pat", other),
        }
    }
}

/// ```prism
/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
/// ```
pub fn ctors_of_o(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty) -> Option<Array<Ctor>> {
    match crate::check::types::recording::walk_f(st_p1, t_p2) {
        crate::check::types::Ty::TyCon(m2894_0_0, m2894_0_1) if (&m2894_0_0 == &Text::lit("Bool")) && ((&m2894_0_1).len() == 0) => Some(Array::from(vec![Ctor { name_p: Text::lit("True"), arity_p: Nat::from(0u32), args_p: Array::new(), shown_p: Text::lit("True") }, Ctor { name_p: Text::lit("False"), arity_p: Nat::from(0u32), args_p: Array::new(), shown_p: Text::lit("False") }])),
        crate::check::types::Ty::TyCon(m2894_1_0, m2894_1_1) if (&m2894_1_0 == &Text::lit("unit")) && ((&m2894_1_1).len() == 0) => Some(Array::from(vec![Ctor { name_p: Text::lit("unit"), arity_p: Nat::from(0u32), args_p: Array::new(), shown_p: Text::lit("unit") }])),
        crate::check::types::Ty::TySig(m2894_2_0, i_p3) if (&m2894_2_0 == &Text::lit("?")) => Some(Array::from(vec![Ctor { name_p: Text::lit("?"), arity_p: Nat::from(1u32), args_p: Array::from(vec![(*i_p3).clone()]), shown_p: Text::lit("? _") }, Ctor { name_p: Text::lit("nil"), arity_p: Nat::from(0u32), args_p: Array::new(), shown_p: Text::lit("nil") }])),
        crate::check::types::Ty::TySig(m2894_3_0, i_p4) if (&m2894_3_0 == &Text::lit("~")) => Some(Array::from(vec![Ctor { name_p: Text::lit("~"), arity_p: Nat::from(1u32), args_p: Array::from(vec![(*i_p4).clone()]), shown_p: Text::lit("~ _") }, Ctor { name_p: Text::lit("Error"), arity_p: Nat::from(2u32), args_p: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text_p()]), shown_p: Text::lit("Error(..)") }])),
        crate::check::types::Ty::TyTuple(ts_p5) => Some(Array::from(vec![Ctor { name_p: Text::lit("tuple"), arity_p: crate::prelude::len(&ts_p5), args_p: ts_p5.clone(), shown_p: Text::from(format!("(({}))", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&ts_p5, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", ")))) }])),
        crate::check::types::Ty::TyCon(m2894_5_0, m2894_5_1) if (&m2894_5_0 == &Text::lit("Prelude.Error")) && ((&m2894_5_1).len() == 0) => Some(Array::from(vec![Ctor { name_p: Text::lit("Error"), arity_p: Nat::from(2u32), args_p: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text_p()]), shown_p: Text::lit("Error(..)") }])),
        crate::check::types::Ty::TyCon(n_p6, args_p7) => match crate::prelude::get(&env_p0.g_p.types_p, &n_p6) {
            Some(ti_p8) => match &ti_p8.body_p {
                crate::check::env::TyBody::BChoice(cases_p9) => Some(crate::prelude::run_to_end(crate::prelude::each_job(cases_p9.clone(), {
                    let ti_p8x = ti_p8.clone();
                    let args_p7x = args_p7.clone();
                    Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                        let ti_p8xy = ti_p8x.clone();
                        let args_p7xy = args_p7x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (cn_pa, cargs_pb) = p0;
                            prism_rtl::Turn::More(Rc::new(CtorOfCase { ti_p0: ti_p8xy.clone(), cn_p1: cn_pa.clone(), cargs_p2: cargs_pb.clone(), args_p3: args_p7xy.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<Ctor>>>
                }))),
                crate::check::env::TyBody::BRecord(fields_pc) => Some(Array::from(vec![Ctor { name_p: n_p6.clone(), arity_p: crate::prelude::len(fields_pc), args_p: crate::prelude::run_to_end(crate::prelude::each_job(fields_pc.clone(), {
                    let ti_p8x = ti_p8.clone();
                    let args_p7x = args_p7.clone();
                    Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                        let ti_p8xy = ti_p8x.clone();
                        let args_p7xy = args_p7x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (_, ft_pd) = p0;
                            prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: crate::check::env::reading::param_inst_f(&ti_p8xy.params_p, &args_p7xy), t_p1: ft_pd.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                })), shown_p: Text::from(format!("{}(..)", &crate::check::types::bare_name_f(&n_p6))) }])),
                crate::check::env::TyBody::BRowKind => if is_root_module_f(env_p0) {
                    Some(crate::prelude::each(&tags_of_kind_f(env_p0, &n_p6), &(|tg_pe: &crate::check::env::TagInfo| tag_ctor_f(tg_pe))))
                } else {
                    None
                },
                _ => None,
            },
            None => if (&n_p6 == &Text::lit("Fault")) || (&n_p6 == &Text::lit("Prelude.Fault")) {
                if is_root_module_f(env_p0) {
                    Some(crate::prelude::each(&tags_of_kind_f(env_p0, &Text::lit("Prelude.Fault")), &(|tg_pf: &crate::check::env::TagInfo| tag_ctor_f(tg_pf))))
                } else {
                    None
                }
            } else {
                None
            },
        },
        crate::check::types::Ty::TyElem(rw_pg, _) => {
            let w_ph = crate::check::types::recording::walk_row_f(st_p1, &rw_pg);
            if &w_ph.tail_p != &crate::check::types::Tail::TlClosed {
                None
            } else {
                Some(crate::prelude::each(&tags_of_row_f(env_p0, &w_ph), &(|tg_pi: &crate::check::env::TagInfo| tag_ctor_f(tg_pi))))
            }
        },
        crate::check::types::Ty::TyElemAny(rw_pj) => {
            let w_pk = crate::check::types::recording::walk_row_f(st_p1, &rw_pj);
            if &w_pk.tail_p != &crate::check::types::Tail::TlClosed {
                None
            } else {
                Some(crate::prelude::each(&tags_of_row_f(env_p0, &w_pk), &(|tg_pl: &crate::check::env::TagInfo| tag_ctor_f(tg_pl))))
            }
        },
        _ => None,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CtorsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
/// ```
pub struct CtorsOf {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<Option<Array<Ctor>>> for CtorsOf {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<Ctor>>> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), t_p2x.clone()), move |walk_f_2900: crate::check::types::Ty| match walk_f_2900 {
            crate::check::types::Ty::TyCon(m2894_0_0, m2894_0_1) if (&m2894_0_0 == &Text::lit("Bool")) && ((&m2894_0_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name_p: Text::lit("True"), arity_p: Nat::from(0u32), args_p: Array::new(), shown_p: Text::lit("True") }, Ctor { name_p: Text::lit("False"), arity_p: Nat::from(0u32), args_p: Array::new(), shown_p: Text::lit("False") }]))),
            crate::check::types::Ty::TyCon(m2894_1_0, m2894_1_1) if (&m2894_1_0 == &Text::lit("unit")) && ((&m2894_1_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name_p: Text::lit("unit"), arity_p: Nat::from(0u32), args_p: Array::new(), shown_p: Text::lit("unit") }]))),
            crate::check::types::Ty::TySig(m2894_2_0, i_p3) if (&m2894_2_0 == &Text::lit("?")) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name_p: Text::lit("?"), arity_p: Nat::from(1u32), args_p: Array::from(vec![(*i_p3).clone()]), shown_p: Text::lit("? _") }, Ctor { name_p: Text::lit("nil"), arity_p: Nat::from(0u32), args_p: Array::new(), shown_p: Text::lit("nil") }]))),
            crate::check::types::Ty::TySig(m2894_3_0, i_p4) if (&m2894_3_0 == &Text::lit("~")) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name_p: Text::lit("~"), arity_p: Nat::from(1u32), args_p: Array::from(vec![(*i_p4).clone()]), shown_p: Text::lit("~ _") }, Ctor { name_p: Text::lit("Error"), arity_p: Nat::from(2u32), args_p: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text_p()]), shown_p: Text::lit("Error(..)") }]))),
            crate::check::types::Ty::TyTuple(ts_p5) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name_p: Text::lit("tuple"), arity_p: crate::prelude::len(&ts_p5), args_p: ts_p5.clone(), shown_p: Text::from(format!("(({}))", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&ts_p5, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", ")))) }]))),
            crate::check::types::Ty::TyCon(m2894_5_0, m2894_5_1) if (&m2894_5_0 == &Text::lit("Prelude.Error")) && ((&m2894_5_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name_p: Text::lit("Error"), arity_p: Nat::from(2u32), args_p: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text_p()]), shown_p: Text::lit("Error(..)") }]))),
            crate::check::types::Ty::TyCon(n_p6, args_p7) => match crate::prelude::get(&env_p0x.g_p.types_p, &n_p6) {
                Some(ti_p8) => match &ti_p8.body_p {
                    crate::check::env::TyBody::BChoice(cases_p9) => prism_rtl::Turn::Finished(Some(crate::prelude::run_to_end(crate::prelude::each_job(cases_p9.clone(), {
                        let ti_p8x = ti_p8.clone();
                        let args_p7x = args_p7.clone();
                        Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                            let ti_p8xy = ti_p8x.clone();
                            let args_p7xy = args_p7x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (cn_pa, cargs_pb) = p0;
                                prism_rtl::Turn::More(Rc::new(CtorOfCase { ti_p0: ti_p8xy.clone(), cn_p1: cn_pa.clone(), cargs_p2: cargs_pb.clone(), args_p3: args_p7xy.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<Ctor>>>
                    })))),
                    crate::check::env::TyBody::BRecord(fields_pc) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name_p: n_p6.clone(), arity_p: crate::prelude::len(fields_pc), args_p: crate::prelude::run_to_end(crate::prelude::each_job(fields_pc.clone(), {
                        let ti_p8x = ti_p8.clone();
                        let args_p7x = args_p7.clone();
                        Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                            let ti_p8xy = ti_p8x.clone();
                            let args_p7xy = args_p7x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (_, ft_pd) = p0;
                                prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: crate::check::env::reading::param_inst_f(&ti_p8xy.params_p, &args_p7xy), t_p1: ft_pd.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                    })), shown_p: Text::from(format!("{}(..)", &crate::check::types::bare_name_f(&n_p6))) }]))),
                    crate::check::env::TyBody::BRowKind => if is_root_module_f(&env_p0x) {
                        prism_rtl::Turn::Finished(Some(crate::prelude::each(&tags_of_kind_f(&env_p0x, &n_p6), &(|tg_pe: &crate::check::env::TagInfo| tag_ctor_f(tg_pe)))))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    },
                    _ => prism_rtl::Turn::Finished(None),
                },
                None => if (&n_p6 == &Text::lit("Fault")) || (&n_p6 == &Text::lit("Prelude.Fault")) {
                    if is_root_module_f(&env_p0x) {
                        prism_rtl::Turn::Finished(Some(crate::prelude::each(&tags_of_kind_f(&env_p0x, &Text::lit("Prelude.Fault")), &(|tg_pf: &crate::check::env::TagInfo| tag_ctor_f(tg_pf)))))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    }
                } else {
                    prism_rtl::Turn::Finished(None)
                },
            },
            crate::check::types::Ty::TyElem(rw_pg, _) => crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_pg.clone()), move |walk_row_f_4329: crate::check::types::Rw| {
                let w_ph = walk_row_f_4329;
                if &w_ph.tail_p != &crate::check::types::Tail::TlClosed {
                    prism_rtl::Turn::Finished(None)
                } else {
                    prism_rtl::Turn::Finished(Some(crate::prelude::each(&tags_of_row_f(&env_p0x, &w_ph), &(|tg_pi: &crate::check::env::TagInfo| tag_ctor_f(tg_pi)))))
                }
            }),
            crate::check::types::Ty::TyElemAny(rw_pj) => crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_pj.clone()), move |walk_row_f_4473: crate::check::types::Rw| {
                let w_pk = walk_row_f_4473;
                if &w_pk.tail_p != &crate::check::types::Tail::TlClosed {
                    prism_rtl::Turn::Finished(None)
                } else {
                    prism_rtl::Turn::Finished(Some(crate::prelude::each(&tags_of_row_f(&env_p0x, &w_pk), &(|tg_pl: &crate::check::env::TagInfo| tag_ctor_f(tg_pl)))))
                }
            }),
            _ => prism_rtl::Turn::Finished(None),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start CtorsOf, x`: what the function value is when passed to `@Run`.
pub fn start_ctors_of_o(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Option<Array<Ctor>>>> {
    Rc::new(CtorsOf { env_p0, st_p1, t_p2 })
}

/// ```prism
/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
/// ```
pub fn ctor_of_case_f(ti_p0: &crate::check::env::TyInfo, cn_p1: &Text, cargs_p2: &Array<crate::check::types::Ty>, args_p3: &Array<crate::check::types::Ty>) -> Ctor {
    let qk_p4 = crate::check::env::qual_key_f(&ti_p0.home_p, cn_p1);
    Ctor { name_p: qk_p4.clone(), arity_p: crate::prelude::len(cargs_p2), args_p: crate::prelude::run_to_end(crate::prelude::each_job(cargs_p2.clone(), {
        let ti_p0x = ti_p0.clone();
        let args_p3x = args_p3.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let ti_p0xy = ti_p0x.clone();
            let args_p3xy = args_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let a_p5 = p0;
                prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: crate::check::env::reading::param_inst_f(&ti_p0xy.params_p, &args_p3xy), t_p1: a_p5.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
    })), shown_p: if &crate::prelude::len(cargs_p2) == &Nat::from(0u32) {
        cn_p1.clone()
    } else {
        Text::from(format!("{} {}", cn_p1, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(cargs_p2, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", "))))
    } }
}

/// The step machine of `CtorOfCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
/// ```
pub struct CtorOfCase {
    pub ti_p0: crate::check::env::TyInfo,
    pub cn_p1: Text,
    pub cargs_p2: Array<crate::check::types::Ty>,
    pub args_p3: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<Ctor> for CtorOfCase {
    fn cycle(&self) -> prism_rtl::Turn<Ctor> {
        let ti_p0 = &self.ti_p0;
        let cn_p1 = &self.cn_p1;
        let cargs_p2 = &self.cargs_p2;
        let args_p3 = &self.args_p3;
        let qk_p4 = crate::check::env::qual_key_f(&ti_p0.home_p, cn_p1);
        let args_p3x = args_p3.clone();
        let cargs_p2x = cargs_p2.clone();
        let cn_p1x = cn_p1.clone();
        let ti_p0x = ti_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(cargs_p2x.clone(), {
            let ti_p0xx = ti_p0x.clone();
            let args_p3xx = args_p3x.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let ti_p0xxy = ti_p0xx.clone();
                let args_p3xxy = args_p3xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p5 = p0;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: crate::check::env::reading::param_inst_f(&ti_p0xxy.params_p, &args_p3xxy), t_p1: a_p5.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }), move |each_4772: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(Ctor { name_p: qk_p4.clone(), arity_p: crate::prelude::len(&cargs_p2x), args_p: each_4772, shown_p: if &crate::prelude::len(&cargs_p2x) == &Nat::from(0u32) {
            cn_p1x.clone()
        } else {
            Text::from(format!("{} {}", &cn_p1x, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&cargs_p2x, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", "))))
        } }))
    }
}

/// `Start CtorOfCase, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_of_case_f(ti_p0: crate::check::env::TyInfo, cn_p1: Text, cargs_p2: Array<crate::check::types::Ty>, args_p3: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<Ctor>> {
    Rc::new(CtorOfCase { ti_p0, cn_p1, cargs_p2, args_p3 })
}

/// ```prism
/// TagCtor: fn TagInfo -> Ctor
/// ```
pub fn tag_ctor_f(tg_p0: &crate::check::env::TagInfo) -> Ctor {
    Ctor { name_p: Text::from(format!("tag:{}", &tg_p0.name_p)), arity_p: crate::prelude::len(&tg_p0.fields_p), args_p: crate::prelude::each(&tg_p0.fields_p, &(|(_, ft_p1): &(Text, crate::check::types::Ty)| crate::check::types::Ty::TyErr)), shown_p: tg_p0.name_p.clone() }
}

/// ```prism
/// IsRootModule: fn Env -> Bool
/// ```
pub fn is_root_module_f(env_p0: &crate::check::expr::Env) -> bool {
    &env_p0.home_p == &Text::lit("")
}

/// ```prism
/// TagsOfKind: fn Env, Text -> [TagInfo]
/// ```
pub fn tags_of_kind_f(env_p0: &crate::check::expr::Env, kind_p1: &Text) -> Array<crate::check::env::TagInfo> {
    crate::prelude::filter(&crate::prelude::values(&env_p0.g_p.tags_p), &(|tg_p2: &crate::check::env::TagInfo| (&tg_p2.kind_p == kind_p1) || ((&crate::check::types::bare_name_f(&tg_p2.kind_p) == &Text::lit("Fault")) && (&crate::check::types::bare_name_f(kind_p1) == &Text::lit("Fault")))))
}

/// ```prism
/// TagsOfRow: fn Env, Rw -> [TagInfo]
/// ```
pub fn tags_of_row_f(env_p0: &crate::check::expr::Env, w_p1: &crate::check::types::Rw) -> Array<crate::check::env::TagInfo> {
    crate::prelude::filter(&crate::prelude::values(&env_p0.g_p.tags_p), &(|tg_p2: &crate::check::env::TagInfo| ((&tg_p2.kind_p == &Text::lit("Element")) && crate::check::types::has_text_f(&w_p1.fams_p, &tg_p2.family_p)) && !crate::check::types::has_text_f(&w_p1.minus_p, &tg_p2.name_p)))
}

/// ```prism
/// ToPat: unbounded fn Env, Pattern -> Pat
/// ```
pub fn to_pat_f(env_p0: &crate::check::expr::Env, p_p1: &crate::syntax::Pattern_) -> Pat {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => {
            let bare_p3 = crate::prelude::or(&crate::prelude::index(&n_p2.path_p, &Nat::from(0u32)), &Text::lit(""));
            if (&crate::prelude::len(&n_p2.path_p) > &Nat::from(1u32)) && crate::check::env::has_key_f(&env_p0.g_p.tags_p, &crate::check::env::dotted_f(&n_p2.path_p)) {
                Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted_f(&n_p2.path_p))), Array::new())
            } else {
                if (crate::check::env::is_upper_text_f(&bare_p3) && (&crate::prelude::len_text(&n_p2.sigils_p) == &Nat::from(0u32))) && crate::check::expr::patterns::is_ctor_name_f(env_p0, n_p2) {
                    Pat::PtCon(ctor_key_f(env_p0, n_p2), Array::new())
                } else {
                    Pat::PtAny
                }
            }
        },
        crate::syntax::PatternKind::PIgnore => Pat::PtAny,
        crate::syntax::PatternKind::PLit(l_p4) => Pat::PtLit(lit_text_f(l_p4)),
        crate::syntax::PatternKind::PNeg(l_p5) => Pat::PtLit(Text::from(format!("-{}", &lit_text_f(l_p5)))),
        crate::syntax::PatternKind::PUnit => Pat::PtCon(Text::lit("unit"), Array::new()),
        crate::syntax::PatternKind::PNil => Pat::PtCon(Text::lit("nil"), Array::new()),
        crate::syntax::PatternKind::PCtor(n_p6, args_p7) => if crate::check::env::has_key_f(&env_p0.g_p.tags_p, &crate::check::env::dotted_f(&n_p6.path_p)) {
            Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted_f(&n_p6.path_p))), Array::new())
        } else {
            Pat::PtCon(ctor_key_f(env_p0, n_p6), crate::prelude::run_to_end(crate::prelude::each_job(args_p7.clone(), {
                let env_p0x = env_p0.clone();
                Rc::new(move |p0: crate::syntax::Pattern_| {
                    let env_p0xy = env_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p8 = p0;
                        prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0xy.clone(), p_p1: a_p8.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
        crate::syntax::PatternKind::PRecord(n_p9, fields_pa, _) => record_pat_f(env_p0, n_p9, fields_pa),
        crate::syntax::PatternKind::PSigil(s_pb, q_pc) => Pat::PtCon(s_pb.clone(), Array::from(vec![to_pat_f(env_p0, &**q_pc)])),
        crate::syntax::PatternKind::PTuple(ps_pd) => Pat::PtCon(Text::lit("tuple"), crate::prelude::run_to_end(crate::prelude::each_job(ps_pd.clone(), {
            let env_p0x = env_p0.clone();
            Rc::new(move |p0: crate::syntax::Pattern_| {
                let env_p0xy = env_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let q_pe = p0;
                    prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0xy.clone(), p_p1: q_pe.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
        }))),
        crate::syntax::PatternKind::PArray(ps_pf) => Pat::PtCon(Text::from(format!("len{}", &crate::prelude::len(ps_pf))), crate::prelude::run_to_end(crate::prelude::each_job(ps_pf.clone(), {
            let env_p0x = env_p0.clone();
            Rc::new(move |p0: crate::syntax::Pattern_| {
                let env_p0xy = env_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let q_pg = p0;
                    prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0xy.clone(), p_p1: q_pg.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
        }))),
        crate::syntax::PatternKind::PGroup(q_ph) => to_pat_f(env_p0, &**q_ph),
        crate::syntax::PatternKind::PFamily(q_pi) => Pat::PtFam(crate::check::env::dotted_f(&q_pi.path_p)),
    }
}

/// The step machine of `ToPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPat: unbounded fn Env, Pattern -> Pat
/// ```
pub struct ToPat {
    pub env_p0: crate::check::expr::Env,
    pub p_p1: crate::syntax::Pattern_,
}

impl prism_rtl::Job<Pat> for ToPat {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env_p0 = &self.env_p0;
        let p_p1 = &self.p_p1;
        match &*p_p1.kind_p {
            crate::syntax::PatternKind::PName(n_p2) => {
                let bare_p3 = crate::prelude::or(&crate::prelude::index(&n_p2.path_p, &Nat::from(0u32)), &Text::lit(""));
                if (&crate::prelude::len(&n_p2.path_p) > &Nat::from(1u32)) && crate::check::env::has_key_f(&env_p0.g_p.tags_p, &crate::check::env::dotted_f(&n_p2.path_p)) {
                    prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted_f(&n_p2.path_p))), Array::new()))
                } else {
                    if (crate::check::env::is_upper_text_f(&bare_p3) && (&crate::prelude::len_text(&n_p2.sigils_p) == &Nat::from(0u32))) && crate::check::expr::patterns::is_ctor_name_f(env_p0, n_p2) {
                        prism_rtl::Turn::Finished(Pat::PtCon(ctor_key_f(env_p0, n_p2), Array::new()))
                    } else {
                        prism_rtl::Turn::Finished(Pat::PtAny)
                    }
                }
            },
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(Pat::PtAny),
            crate::syntax::PatternKind::PLit(l_p4) => prism_rtl::Turn::Finished(Pat::PtLit(lit_text_f(l_p4))),
            crate::syntax::PatternKind::PNeg(l_p5) => prism_rtl::Turn::Finished(Pat::PtLit(Text::from(format!("-{}", &lit_text_f(l_p5))))),
            crate::syntax::PatternKind::PUnit => prism_rtl::Turn::Finished(Pat::PtCon(Text::lit("unit"), Array::new())),
            crate::syntax::PatternKind::PNil => prism_rtl::Turn::Finished(Pat::PtCon(Text::lit("nil"), Array::new())),
            crate::syntax::PatternKind::PCtor(n_p6, args_p7) => if crate::check::env::has_key_f(&env_p0.g_p.tags_p, &crate::check::env::dotted_f(&n_p6.path_p)) {
                prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted_f(&n_p6.path_p))), Array::new()))
            } else {
                {
                    let args_p7x = args_p7.clone();
                    let env_p0x = env_p0.clone();
                    let n_p6x = n_p6.clone();
                    crate::prelude::call_value(crate::prelude::each_job(args_p7x.clone(), {
                        let env_p0xx = env_p0x.clone();
                        Rc::new(move |p0: crate::syntax::Pattern_| {
                            let env_p0xxy = env_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_p8 = p0;
                                prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0xxy.clone(), p_p1: a_p8.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                    }), move |each_6274: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(ctor_key_f(&env_p0x, &n_p6x), each_6274)))
                }
            },
            crate::syntax::PatternKind::PRecord(n_p9, fields_pa, _) => prism_rtl::Turn::More(Rc::new(RecordPat { env_p0: env_p0.clone(), n_p1: n_p9.clone(), fields_p2: fields_pa.clone() })),
            crate::syntax::PatternKind::PSigil(s_pb, q_pc) => {
                let env_p0x = env_p0.clone();
                let q_pcx = (**q_pc).clone();
                let s_pbx = s_pb.clone();
                crate::prelude::call_then(start_to_pat_f(env_p0x.clone(), q_pcx.clone()), move |to_pat_f_6389: Pat| prism_rtl::Turn::Finished(Pat::PtCon(s_pbx.clone(), Array::from(vec![to_pat_f_6389]))))
            },
            crate::syntax::PatternKind::PTuple(ps_pd) => {
                let env_p0x = env_p0.clone();
                let ps_pdx = ps_pd.clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_pdx.clone(), {
                    let env_p0xx = env_p0x.clone();
                    Rc::new(move |p0: crate::syntax::Pattern_| {
                        let env_p0xxy = env_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let q_pe = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0xxy.clone(), p_p1: q_pe.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_6436: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::lit("tuple"), each_6436)))
            },
            crate::syntax::PatternKind::PArray(ps_pf) => {
                let env_p0x = env_p0.clone();
                let ps_pfx = ps_pf.clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_pfx.clone(), {
                    let env_p0xx = env_p0x.clone();
                    Rc::new(move |p0: crate::syntax::Pattern_| {
                        let env_p0xxy = env_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let q_pg = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0xxy.clone(), p_p1: q_pg.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_6501: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("len{}", &crate::prelude::len(&ps_pfx))), each_6501)))
            },
            crate::syntax::PatternKind::PGroup(q_ph) => prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0.clone(), p_p1: (**q_ph).clone() })),
            crate::syntax::PatternKind::PFamily(q_pi) => prism_rtl::Turn::Finished(Pat::PtFam(crate::check::env::dotted_f(&q_pi.path_p))),
        }
    }
}

/// `Start ToPat, x`: what the function value is when passed to `@Run`.
pub fn start_to_pat_f(env_p0: crate::check::expr::Env, p_p1: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(ToPat { env_p0, p_p1 })
}

/// ```prism
/// LitText: fn Literal -> Text
/// ```
pub fn lit_text_f(l_p0: &crate::syntax::Literal) -> Text {
    match &l_p0.kind_p {
        crate::syntax::LitKind::LInt(d_p1) => d_p1.clone(),
        crate::syntax::LitKind::LFloat(d_p2) => d_p2.clone(),
        crate::syntax::LitKind::LChar(c_p3) => Text::from(format!("\'{}\'", c_p3)),
        crate::syntax::LitKind::LText(segs_p4) => crate::prelude::concat(&crate::prelude::each(segs_p4, &lit_seg_text_f)),
        crate::syntax::LitKind::LDuration(d_p5, u_p6) => Text::from(format!("{}{}", d_p5, u_p6)),
        crate::syntax::LitKind::LRegex(r_p7) => Text::from(format!("%/{}/", &r_p7.pattern_p)),
    }
}

/// ```prism
/// LitSegText: fn TextSeg -> Text
/// ```
pub fn lit_seg_text_f(text_seg0: &crate::syntax::TextSeg) -> Text {
    match text_seg0 {
        crate::syntax::TextSeg::SegPlain(t_p0) => t_p0.clone(),
        _ => Text::lit("{}"),
    }
}

/// ```prism
/// CtorKey: fn Env, SName -> Text
/// ```
pub fn ctor_key_f(env_p0: &crate::check::expr::Env, n_p1: &crate::syntax::SName) -> Text {
    let (qk_o2, _) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p1);
    crate::prelude::or(&qk_o2, &crate::check::env::sname_key_f(n_p1))
}

/// ```prism
/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
/// ```
pub fn record_pat_f(env_p0: &crate::check::expr::Env, n_p1: &crate::syntax::SName, fields_p2: &Array<crate::syntax::FieldPat>) -> Pat {
    let name_p3 = crate::check::env::dotted_f(&n_p1.path_p);
    match crate::prelude::get(&env_p0.g_p.tags_p, &name_p3) {
        Some(tg_p4) => {
            let names_p5 = crate::prelude::each(&tg_p4.fields_p, &(|(f_p6, _): &(Text, crate::check::types::Ty)| f_p6.clone()));
            Pat::PtCon(Text::from(format!("tag:{}", &name_p3)), crate::prelude::run_to_end(crate::prelude::each_job(names_p5.clone(), {
                let env_p0x = env_p0.clone();
                let fields_p2x = fields_p2.clone();
                let names_p5x = names_p5.clone();
                Rc::new(move |p0: Text| {
                    let env_p0xy = env_p0x.clone();
                    let fields_p2xy = fields_p2x.clone();
                    let names_p5xy = names_p5x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p7 = p0;
                        prism_rtl::Turn::More(Rc::new(FieldPatFor { env_p0: env_p0xy.clone(), fields_p1: fields_p2xy.clone(), names_p2: names_p5xy.clone(), f_p3: f_p7.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
        None => {
            let qk_p8 = ctor_key_f(env_p0, n_p1);
            let fnames_p9 = if &crate::check::types::bare_name_f(&qk_p8) == &Text::lit("Error") {
                Array::from(vec![Text::lit("kind"), Text::lit("message")])
            } else {
                crate::prelude::or(&crate::prelude::get(&env_p0.g_p.ctors_p, &qk_p8), &dummy_ctor_p()).fields_p.clone()
            };
            let pkey_pa = if &crate::check::types::bare_name_f(&qk_p8) == &Text::lit("Error") {
                Text::lit("Error")
            } else {
                qk_p8.clone()
            };
            Pat::PtCon(pkey_pa.clone(), crate::prelude::run_to_end(crate::prelude::each_job(fnames_p9.clone(), {
                let env_p0x = env_p0.clone();
                let fields_p2x = fields_p2.clone();
                let fnames_p9x = fnames_p9.clone();
                Rc::new(move |p0: Text| {
                    let env_p0xy = env_p0x.clone();
                    let fields_p2xy = fields_p2x.clone();
                    let fnames_p9xy = fnames_p9x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_pb = p0;
                        prism_rtl::Turn::More(Rc::new(FieldPatFor { env_p0: env_p0xy.clone(), fields_p1: fields_p2xy.clone(), names_p2: fnames_p9xy.clone(), f_p3: f_pb.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
    }
}

/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
/// ```
pub struct RecordPat {
    pub env_p0: crate::check::expr::Env,
    pub n_p1: crate::syntax::SName,
    pub fields_p2: Array<crate::syntax::FieldPat>,
}

impl prism_rtl::Job<Pat> for RecordPat {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env_p0 = &self.env_p0;
        let n_p1 = &self.n_p1;
        let fields_p2 = &self.fields_p2;
        let name_p3 = crate::check::env::dotted_f(&n_p1.path_p);
        match crate::prelude::get(&env_p0.g_p.tags_p, &name_p3) {
            Some(tg_p4) => {
                let names_p5 = crate::prelude::each(&tg_p4.fields_p, &(|(f_p6, _): &(Text, crate::check::types::Ty)| f_p6.clone()));
                let env_p0x = env_p0.clone();
                let fields_p2x = fields_p2.clone();
                crate::prelude::call_value(crate::prelude::each_job(names_p5.clone(), {
                    let env_p0xx = env_p0x.clone();
                    let fields_p2xx = fields_p2x.clone();
                    let names_p5x = names_p5.clone();
                    Rc::new(move |p0: Text| {
                        let env_p0xxy = env_p0xx.clone();
                        let fields_p2xxy = fields_p2xx.clone();
                        let names_p5xy = names_p5x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_p7 = p0;
                            prism_rtl::Turn::More(Rc::new(FieldPatFor { env_p0: env_p0xxy.clone(), fields_p1: fields_p2xxy.clone(), names_p2: names_p5xy.clone(), f_p3: f_p7.clone() }))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_7371: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &name_p3)), each_7371)))
            },
            None => {
                let qk_p8 = ctor_key_f(env_p0, n_p1);
                let fnames_p9 = if &crate::check::types::bare_name_f(&qk_p8) == &Text::lit("Error") {
                    Array::from(vec![Text::lit("kind"), Text::lit("message")])
                } else {
                    crate::prelude::or(&crate::prelude::get(&env_p0.g_p.ctors_p, &qk_p8), &dummy_ctor_p()).fields_p.clone()
                };
                let pkey_pa = if &crate::check::types::bare_name_f(&qk_p8) == &Text::lit("Error") {
                    Text::lit("Error")
                } else {
                    qk_p8.clone()
                };
                let env_p0x = env_p0.clone();
                let fields_p2x = fields_p2.clone();
                crate::prelude::call_value(crate::prelude::each_job(fnames_p9.clone(), {
                    let env_p0xx = env_p0x.clone();
                    let fields_p2xx = fields_p2x.clone();
                    let fnames_p9x = fnames_p9.clone();
                    Rc::new(move |p0: Text| {
                        let env_p0xxy = env_p0xx.clone();
                        let fields_p2xxy = fields_p2xx.clone();
                        let fnames_p9xy = fnames_p9x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_pb = p0;
                            prism_rtl::Turn::More(Rc::new(FieldPatFor { env_p0: env_p0xxy.clone(), fields_p1: fields_p2xxy.clone(), names_p2: fnames_p9xy.clone(), f_p3: f_pb.clone() }))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_7687: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(pkey_pa.clone(), each_7687)))
            },
        }
    }
}

/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
pub fn start_record_pat_f(env_p0: crate::check::expr::Env, n_p1: crate::syntax::SName, fields_p2: Array<crate::syntax::FieldPat>) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(RecordPat { env_p0, n_p1, fields_p2 })
}

/// ```prism
/// let dummyCtor
/// ```
pub fn dummy_ctor_p() -> crate::check::env::CtorInfo {
    crate::check::env::CtorInfo { name_p: Text::lit(""), owner_p: Text::lit(""), params_p: Array::new(), args_p: Array::new(), fields_p: Array::new(), ty_p: crate::check::types::Ty::TyErr, index_p: Nat::from(0u32) }
}

/// ```prism
/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
/// ```
pub fn field_pat_for_f(env_p0: &crate::check::expr::Env, fields_p1: &Array<crate::syntax::FieldPat>, names_p2: &Array<Text>, f_p3: &Text) -> Pat {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(fields_p1)), Pat::PtAny, {
        let fields_p1x = fields_p1.clone();
        let names_p2x = names_p2.clone();
        let f_p3x = f_p3.clone();
        let env_p0x = env_p0.clone();
        Rc::new(move |(p0, p1): (Pat, Nat)| {
            let fields_p1xy = fields_p1x.clone();
            let names_p2xy = names_p2x.clone();
            let f_p3xy = f_p3x.clone();
            let env_p0xy = env_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p4 = p0;
                let i_p5 = p1;
                match crate::prelude::index(&fields_p1xy, &i_p5) {
                    Some(fp_p6) => if &crate::check::expr::patterns::field_pat_name_f(&fp_p6, &names_p2xy, &i_p5) == &f_p3xy {
                        prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0xy.clone(), p_p1: fp_p6.pattern_p.clone() }))
                    } else {
                        prism_rtl::Turn::Finished(acc_p4.clone())
                    },
                    None => prism_rtl::Turn::Finished(acc_p4.clone()),
                }
            }))
        }) as Rc<dyn Fn((Pat, Nat)) -> Rc<dyn prism_rtl::Job<Pat>>>
    }))
}

/// The step machine of `FieldPatFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
/// ```
pub struct FieldPatFor {
    pub env_p0: crate::check::expr::Env,
    pub fields_p1: Array<crate::syntax::FieldPat>,
    pub names_p2: Array<Text>,
    pub f_p3: Text,
}

impl prism_rtl::Job<Pat> for FieldPatFor {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env_p0 = &self.env_p0;
        let fields_p1 = &self.fields_p1;
        let names_p2 = &self.names_p2;
        let f_p3 = &self.f_p3;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(fields_p1)), Pat::PtAny, {
            let fields_p1x = fields_p1.clone();
            let names_p2x = names_p2.clone();
            let f_p3x = f_p3.clone();
            let env_p0x = env_p0.clone();
            Rc::new(move |(p0, p1): (Pat, Nat)| {
                let fields_p1xy = fields_p1x.clone();
                let names_p2xy = names_p2x.clone();
                let f_p3xy = f_p3x.clone();
                let env_p0xy = env_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p4 = p0;
                    let i_p5 = p1;
                    match crate::prelude::index(&fields_p1xy, &i_p5) {
                        Some(fp_p6) => if &crate::check::expr::patterns::field_pat_name_f(&fp_p6, &names_p2xy, &i_p5) == &f_p3xy {
                            prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0xy.clone(), p_p1: fp_p6.pattern_p.clone() }))
                        } else {
                            prism_rtl::Turn::Finished(acc_p4.clone())
                        },
                        None => prism_rtl::Turn::Finished(acc_p4.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Pat, Nat)) -> Rc<dyn prism_rtl::Job<Pat>>>
        }).cycle()
    }
}

/// `Start FieldPatFor, x`: what the function value is when passed to `@Run`.
pub fn start_field_pat_for_f(env_p0: crate::check::expr::Env, fields_p1: Array<crate::syntax::FieldPat>, names_p2: Array<Text>, f_p3: Text) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(FieldPatFor { env_p0, fields_p1, names_p2, f_p3 })
}

/// ```prism
/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
/// ```
pub fn useful_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, rows_p2: &Array<Array<Pat>>, q_p3: &Array<Pat>, tys_p4: &Array<crate::check::types::Ty>) -> bool {
    match crate::prelude::index(q_p3, &Nat::from(0u32)) {
        None => &crate::prelude::len(rows_p2) == &Nat::from(0u32),
        Some(q1_p5) => {
            let t1_p6 = crate::prelude::or(&crate::prelude::index(tys_p4, &Nat::from(0u32)), &crate::check::types::Ty::TyErr);
            let rest_p7 = crate::prelude::drop(tys_p4, &Nat::from(1u32));
            match &q1_p5 {
                Pat::PtCon(c_p8, args_p9) => {
                    let ctor_pa = ctor_named_f(env_p0, st_p1, &t1_p6, c_p8, &crate::prelude::len(args_p9));
                    useful_f(env_p0, st_p1, &specialize_f(rows_p2, &ctor_pa), &crate::prelude::append(args_p9, &crate::prelude::drop(q_p3, &Nat::from(1u32))), &crate::prelude::append(&ctor_pa.args_p, &rest_p7))
                },
                Pat::PtLit(l_pb) => useful_f(env_p0, st_p1, &specialize_lit_f(rows_p2, l_pb), &crate::prelude::drop(q_p3, &Nat::from(1u32)), &rest_p7),
                Pat::PtFam(f_pc) => match ctors_of_o(env_p0, st_p1, &t1_p6) {
                    Some(cs_pd) => crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(&cs_pd, &(|c_pe: &Ctor| &ctor_family_f(c_pe) == f_pc)), false, {
                        let env_p0x = env_p0.clone();
                        let st_p1x = st_p1.clone();
                        let rows_p2x = rows_p2.clone();
                        let q_p3x = q_p3.clone();
                        let rest_p7x = rest_p7.clone();
                        Rc::new(move |(p0, p1): (bool, Ctor)| {
                            let env_p0xy = env_p0x.clone();
                            let st_p1xy = st_p1x.clone();
                            let rows_p2xy = rows_p2x.clone();
                            let q_p3xy = q_p3x.clone();
                            let rest_p7xy = rest_p7x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let seen_pf = p0;
                                let c_pg = p1;
                                prism_rtl::Turn::Finished(seen_pf || useful_f(&env_p0xy, &st_p1xy, &specialize_f(&rows_p2xy, &c_pg), &crate::prelude::append(&wilds_f(&c_pg.arity_p), &crate::prelude::drop(&q_p3xy, &Nat::from(1u32))), &crate::prelude::append(&c_pg.args_p, &rest_p7xy)))
                            }))
                        }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                    })),
                    None => useful_f(env_p0, st_p1, &default_rows_f(rows_p2), &crate::prelude::drop(q_p3, &Nat::from(1u32)), &rest_p7),
                },
                Pat::PtAny => {
                    let heads_ph = head_names_f(rows_p2);
                    match ctors_of_o(env_p0, st_p1, &t1_p6) {
                        Some(cs_pi) => if complete_f(&cs_pi, &heads_ph, rows_p2) {
                            crate::prelude::run_to_end(crate::prelude::fold_job(cs_pi.clone(), false, {
                                let env_p0x = env_p0.clone();
                                let st_p1x = st_p1.clone();
                                let rows_p2x = rows_p2.clone();
                                let q_p3x = q_p3.clone();
                                let rest_p7x = rest_p7.clone();
                                Rc::new(move |(p0, p1): (bool, Ctor)| {
                                    let env_p0xy = env_p0x.clone();
                                    let st_p1xy = st_p1x.clone();
                                    let rows_p2xy = rows_p2x.clone();
                                    let q_p3xy = q_p3x.clone();
                                    let rest_p7xy = rest_p7x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let seen_pj = p0;
                                        let c_pk = p1;
                                        prism_rtl::Turn::Finished(seen_pj || useful_f(&env_p0xy, &st_p1xy, &specialize_f(&rows_p2xy, &c_pk), &crate::prelude::append(&wilds_f(&c_pk.arity_p), &crate::prelude::drop(&q_p3xy, &Nat::from(1u32))), &crate::prelude::append(&c_pk.args_p, &rest_p7xy)))
                                    }))
                                }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }))
                        } else {
                            useful_f(env_p0, st_p1, &default_rows_f(rows_p2), &crate::prelude::drop(q_p3, &Nat::from(1u32)), &rest_p7)
                        },
                        None => useful_f(env_p0, st_p1, &default_rows_f(rows_p2), &crate::prelude::drop(q_p3, &Nat::from(1u32)), &rest_p7),
                    }
                },
            }
        },
    }
}

/// The step machine of `Useful`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
/// ```
pub struct Useful {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub rows_p2: Array<Array<Pat>>,
    pub q_p3: Array<Pat>,
    pub tys_p4: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<bool> for Useful {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let rows_p2 = &self.rows_p2;
        let q_p3 = &self.q_p3;
        let tys_p4 = &self.tys_p4;
        match crate::prelude::index(q_p3, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(&crate::prelude::len(rows_p2) == &Nat::from(0u32)),
            Some(q1_p5) => {
                let t1_p6 = crate::prelude::or(&crate::prelude::index(tys_p4, &Nat::from(0u32)), &crate::check::types::Ty::TyErr);
                let rest_p7 = crate::prelude::drop(tys_p4, &Nat::from(1u32));
                match &q1_p5 {
                    Pat::PtCon(c_p8, args_p9) => {
                        let args_p9x = args_p9.clone();
                        let c_p8x = c_p8.clone();
                        let env_p0x = env_p0.clone();
                        let q_p3x = q_p3.clone();
                        let rows_p2x = rows_p2.clone();
                        let st_p1x = st_p1.clone();
                        crate::prelude::call_then(start_ctor_named_f(env_p0x.clone(), st_p1x.clone(), t1_p6.clone(), c_p8x.clone(), crate::prelude::len(&args_p9x)), move |ctor_named_f_8483: Ctor| {
                            let ctor_pa = ctor_named_f_8483;
                            prism_rtl::Turn::More(Rc::new(Useful { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), rows_p2: specialize_f(&rows_p2x, &ctor_pa), q_p3: crate::prelude::append(&args_p9x, &crate::prelude::drop(&q_p3x, &Nat::from(1u32))), tys_p4: crate::prelude::append(&ctor_pa.args_p, &rest_p7) }))
                        })
                    },
                    Pat::PtLit(l_pb) => prism_rtl::Turn::More(Rc::new(Useful { env_p0: env_p0.clone(), st_p1: st_p1.clone(), rows_p2: specialize_lit_f(rows_p2, l_pb), q_p3: crate::prelude::drop(q_p3, &Nat::from(1u32)), tys_p4: rest_p7.clone() })),
                    Pat::PtFam(f_pc) => {
                        let env_p0x = env_p0.clone();
                        let f_pcx = f_pc.clone();
                        let q_p3x = q_p3.clone();
                        let rows_p2x = rows_p2.clone();
                        let st_p1x = st_p1.clone();
                        crate::prelude::call_then(start_ctors_of_o(env_p0x.clone(), st_p1x.clone(), t1_p6.clone()), move |ctors_of_o_8737: Option<Array<Ctor>>| match ctors_of_o_8737 {
                            Some(cs_pd) => crate::prelude::fold_job(crate::prelude::filter(&cs_pd, &(|c_pe: &Ctor| &ctor_family_f(c_pe) == &f_pcx)), false, {
                                let env_p0xx = env_p0x.clone();
                                let st_p1xx = st_p1x.clone();
                                let rows_p2xx = rows_p2x.clone();
                                let q_p3xx = q_p3x.clone();
                                let rest_p7x = rest_p7.clone();
                                Rc::new(move |(p0, p1): (bool, Ctor)| {
                                    let env_p0xxy = env_p0xx.clone();
                                    let st_p1xxy = st_p1xx.clone();
                                    let rows_p2xxy = rows_p2xx.clone();
                                    let q_p3xxy = q_p3xx.clone();
                                    let rest_p7xy = rest_p7x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let seen_pf = p0;
                                        let c_pg = p1;
                                        prism_rtl::Turn::Finished(seen_pf || useful_f(&env_p0xxy, &st_p1xxy, &specialize_f(&rows_p2xxy, &c_pg), &crate::prelude::append(&wilds_f(&c_pg.arity_p), &crate::prelude::drop(&q_p3xxy, &Nat::from(1u32))), &crate::prelude::append(&c_pg.args_p, &rest_p7xy)))
                                    }))
                                }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }).cycle(),
                            None => prism_rtl::Turn::More(Rc::new(Useful { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), rows_p2: default_rows_f(&rows_p2x), q_p3: crate::prelude::drop(&q_p3x, &Nat::from(1u32)), tys_p4: rest_p7.clone() })),
                        })
                    },
                    Pat::PtAny => {
                        let heads_ph = head_names_f(rows_p2);
                        let env_p0x = env_p0.clone();
                        let q_p3x = q_p3.clone();
                        let rows_p2x = rows_p2.clone();
                        let st_p1x = st_p1.clone();
                        crate::prelude::call_then(start_ctors_of_o(env_p0x.clone(), st_p1x.clone(), t1_p6.clone()), move |ctors_of_o_9109: Option<Array<Ctor>>| match ctors_of_o_9109 {
                            Some(cs_pi) => if complete_f(&cs_pi, &heads_ph, &rows_p2x) {
                                crate::prelude::fold_job(cs_pi.clone(), false, {
                                    let env_p0xx = env_p0x.clone();
                                    let st_p1xx = st_p1x.clone();
                                    let rows_p2xx = rows_p2x.clone();
                                    let q_p3xx = q_p3x.clone();
                                    let rest_p7x = rest_p7.clone();
                                    Rc::new(move |(p0, p1): (bool, Ctor)| {
                                        let env_p0xxy = env_p0xx.clone();
                                        let st_p1xxy = st_p1xx.clone();
                                        let rows_p2xxy = rows_p2xx.clone();
                                        let q_p3xxy = q_p3xx.clone();
                                        let rest_p7xy = rest_p7x.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let seen_pj = p0;
                                            let c_pk = p1;
                                            prism_rtl::Turn::Finished(seen_pj || useful_f(&env_p0xxy, &st_p1xxy, &specialize_f(&rows_p2xxy, &c_pk), &crate::prelude::append(&wilds_f(&c_pk.arity_p), &crate::prelude::drop(&q_p3xxy, &Nat::from(1u32))), &crate::prelude::append(&c_pk.args_p, &rest_p7xy)))
                                        }))
                                    }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                                }).cycle()
                            } else {
                                prism_rtl::Turn::More(Rc::new(Useful { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), rows_p2: default_rows_f(&rows_p2x), q_p3: crate::prelude::drop(&q_p3x, &Nat::from(1u32)), tys_p4: rest_p7.clone() }))
                            },
                            None => prism_rtl::Turn::More(Rc::new(Useful { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), rows_p2: default_rows_f(&rows_p2x), q_p3: crate::prelude::drop(&q_p3x, &Nat::from(1u32)), tys_p4: rest_p7.clone() })),
                        })
                    },
                }
            },
        }
    }
}

/// `Start Useful, x`: what the function value is when passed to `@Run`.
pub fn start_useful_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, rows_p2: Array<Array<Pat>>, q_p3: Array<Pat>, tys_p4: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Useful { env_p0, st_p1, rows_p2, q_p3, tys_p4 })
}

/// ```prism
/// CtorFamily: fn Ctor -> Text
/// ```
pub fn ctor_family_f(c_p0: &Ctor) -> Text {
    if crate::syntax::lexer::chars::has_prefix_f(&c_p0.name_p, &Text::lit("tag:")) {
        crate::check::env::dotted_f(&crate::syntax::lexer::chars::pop_f(&crate::prelude::split_on(&crate::syntax::lexer::chars::drop_prefix_f(&c_p0.name_p, &Text::lit("tag:")), &Text::lit("."))))
    } else {
        Text::lit("")
    }
}

/// ```prism
/// Wilds: fn Nat -> [Pat]
/// ```
pub fn wilds_f(n_p0: &Nat) -> Array<Pat> {
    crate::prelude::each(&crate::check::errors::range0_f(n_p0), &(|_: &Nat| Pat::PtAny))
}

/// ```prism
/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
/// ```
pub fn ctor_named_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty, c_p3: &Text, arity_p4: &Nat) -> Ctor {
    match ctors_of_o(env_p0, st_p1, t_p2) {
        Some(cs_p5) => match find_ctor_o(&cs_p5, c_p3) {
            Some(found_p6) => found_p6,
            None => Ctor { name_p: c_p3.clone(), arity_p: arity_p4.clone(), args_p: crate::prelude::each(&crate::check::errors::range0_f(arity_p4), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown_p: c_p3.clone() },
        },
        None => Ctor { name_p: c_p3.clone(), arity_p: arity_p4.clone(), args_p: crate::prelude::each(&crate::check::errors::range0_f(arity_p4), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown_p: c_p3.clone() },
    }
}

/// The step machine of `CtorNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
/// ```
pub struct CtorNamed {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
    pub c_p3: Text,
    pub arity_p4: Nat,
}

impl prism_rtl::Job<Ctor> for CtorNamed {
    fn cycle(&self) -> prism_rtl::Turn<Ctor> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let c_p3 = &self.c_p3;
        let arity_p4 = &self.arity_p4;
        let arity_p4x = arity_p4.clone();
        let c_p3x = c_p3.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(start_ctors_of_o(env_p0x.clone(), st_p1x.clone(), t_p2x.clone()), move |ctors_of_o_9906: Option<Array<Ctor>>| match ctors_of_o_9906 {
            Some(cs_p5) => match find_ctor_o(&cs_p5, &c_p3x) {
                Some(found_p6) => prism_rtl::Turn::Finished(found_p6.clone()),
                None => prism_rtl::Turn::Finished(Ctor { name_p: c_p3x.clone(), arity_p: arity_p4x.clone(), args_p: crate::prelude::each(&crate::check::errors::range0_f(&arity_p4x), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown_p: c_p3x.clone() }),
            },
            None => prism_rtl::Turn::Finished(Ctor { name_p: c_p3x.clone(), arity_p: arity_p4x.clone(), args_p: crate::prelude::each(&crate::check::errors::range0_f(&arity_p4x), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown_p: c_p3x.clone() }),
        })
    }
}

/// `Start CtorNamed, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_named_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty, c_p3: Text, arity_p4: Nat) -> Rc<dyn prism_rtl::Job<Ctor>> {
    Rc::new(CtorNamed { env_p0, st_p1, t_p2, c_p3, arity_p4 })
}

/// ```prism
/// ?FindCtor: fn [Ctor], Text -> ?Ctor
/// ```
pub fn find_ctor_o(cs_p0: &Array<Ctor>, c_p1: &Text) -> Option<Ctor> {
    crate::prelude::fold(cs_p0, &None, &(|found_o2: &Option<Ctor>, x_p3: &Ctor| match found_o2 {
        Some(f_p4) => Some(f_p4.clone()),
        None => if (&x_p3.name_p == c_p1) || (&crate::check::types::bare_name_f(&x_p3.name_p) == &crate::check::types::bare_name_f(c_p1)) {
            Some(x_p3.clone())
        } else {
            None
        },
    }))
}

/// ```prism
/// Specialize: fn [ [Pat] ], Ctor -> [ [Pat] ]
/// ```
pub fn specialize_f(rows_p0: &Array<Array<Pat>>, c_p1: &Ctor) -> Array<Array<Pat>> {
    crate::prelude::fold(rows_p0, &Array::new(), &(|acc_p2: &Array<Array<Pat>>, prow_p3: &Array<Pat>| match crate::prelude::index(prow_p3, &Nat::from(0u32)) {
        Some(Pat::PtCon(d_p4, args_p5)) => if (&d_p4 == &c_p1.name_p) || (&crate::check::types::bare_name_f(&d_p4) == &crate::check::types::bare_name_f(&c_p1.name_p)) {
            crate::prelude::push(acc_p2, &crate::prelude::append(&pad_f(&args_p5, &c_p1.arity_p), &crate::prelude::drop(prow_p3, &Nat::from(1u32))))
        } else {
            acc_p2.clone()
        },
        Some(Pat::PtAny) => crate::prelude::push(acc_p2, &crate::prelude::append(&wilds_f(&c_p1.arity_p), &crate::prelude::drop(prow_p3, &Nat::from(1u32)))),
        Some(Pat::PtFam(f_p6)) => if &ctor_family_f(c_p1) == &f_p6 {
            crate::prelude::push(acc_p2, &crate::prelude::append(&wilds_f(&c_p1.arity_p), &crate::prelude::drop(prow_p3, &Nat::from(1u32))))
        } else {
            acc_p2.clone()
        },
        _ => acc_p2.clone(),
    }))
}

/// ```prism
/// Pad: fn [Pat], Nat -> [Pat]
/// ```
pub fn pad_f(args_p0: &Array<Pat>, n_p1: &Nat) -> Array<Pat> {
    if &crate::prelude::len(args_p0) >= n_p1 {
        crate::prelude::take(args_p0, n_p1)
    } else {
        crate::prelude::append(args_p0, &wilds_f(&crate::prelude::or(&n_p1.checked_sub(&crate::prelude::len(args_p0)), &Nat::from(0u32))))
    }
}

/// ```prism
/// SpecializeLit: fn [ [Pat] ], Text -> [ [Pat] ]
/// ```
pub fn specialize_lit_f(rows_p0: &Array<Array<Pat>>, l_p1: &Text) -> Array<Array<Pat>> {
    crate::prelude::fold(rows_p0, &Array::new(), &(|acc_p2: &Array<Array<Pat>>, prow_p3: &Array<Pat>| match crate::prelude::index(prow_p3, &Nat::from(0u32)) {
        Some(Pat::PtLit(m_p4)) => if &m_p4 == l_p1 {
            crate::prelude::push(acc_p2, &crate::prelude::drop(prow_p3, &Nat::from(1u32)))
        } else {
            acc_p2.clone()
        },
        Some(Pat::PtAny) => crate::prelude::push(acc_p2, &crate::prelude::drop(prow_p3, &Nat::from(1u32))),
        _ => acc_p2.clone(),
    }))
}

/// ```prism
/// DefaultRows: fn [ [Pat] ] -> [ [Pat] ]
/// ```
pub fn default_rows_f(rows_p0: &Array<Array<Pat>>) -> Array<Array<Pat>> {
    crate::prelude::fold(rows_p0, &Array::new(), &(|acc_p1: &Array<Array<Pat>>, prow_p2: &Array<Pat>| match crate::prelude::index(prow_p2, &Nat::from(0u32)) {
        Some(Pat::PtAny) => crate::prelude::push(acc_p1, &crate::prelude::drop(prow_p2, &Nat::from(1u32))),
        _ => acc_p1.clone(),
    }))
}

/// ```prism
/// HeadNames: fn [ [Pat] ] -> [Text]
/// ```
pub fn head_names_f(rows_p0: &Array<Array<Pat>>) -> Array<Text> {
    crate::prelude::fold(rows_p0, &Array::new(), &(|acc_p1: &Array<Text>, prow_p2: &Array<Pat>| match crate::prelude::index(prow_p2, &Nat::from(0u32)) {
        Some(Pat::PtCon(c_p3, _)) => crate::check::types::add_text_f(acc_p1, &c_p3),
        Some(Pat::PtFam(f_p4)) => crate::check::types::add_text_f(acc_p1, &Text::from(format!("fam:{}", &f_p4))),
        _ => acc_p1.clone(),
    }))
}

/// ```prism
/// Complete: fn [Ctor], [Text], [ [Pat] ] -> Bool
/// ```
pub fn complete_f(cs_p0: &Array<Ctor>, heads_p1: &Array<Text>, rows_p2: &Array<Array<Pat>>) -> bool {
    (&crate::prelude::len(cs_p0) > &Nat::from(0u32)) && crate::prelude::fold(cs_p0, &true, &(|ok_p3: &bool, c_p4: &Ctor| *ok_p3 && ((crate::check::types::has_text_f(heads_p1, &c_p4.name_p) || crate::check::types::has_text_f(&crate::prelude::each(heads_p1, &(|h_p5: &Text| crate::check::types::bare_name_f(h_p5))), &crate::check::types::bare_name_f(&c_p4.name_p))) || crate::check::types::has_text_f(heads_p1, &Text::from(format!("fam:{}", &ctor_family_f(c_p4)))))))
}

/// ```prism
/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
/// ```
pub fn witness_o(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, rows_p2: &Array<Array<Pat>>, tys_p3: &Array<crate::check::types::Ty>) -> Option<Array<Text>> {
    match crate::prelude::index(tys_p3, &Nat::from(0u32)) {
        None => if &crate::prelude::len(rows_p2) == &Nat::from(0u32) {
            Some(Array::new())
        } else {
            None
        },
        Some(t1_p4) => {
            let rest_p5 = crate::prelude::drop(tys_p3, &Nat::from(1u32));
            let heads_p6 = head_names_f(rows_p2);
            match ctors_of_o(env_p0, st_p1, &t1_p4) {
                Some(cs_p7) => if complete_f(&cs_p7, &heads_p6, rows_p2) {
                    crate::prelude::run_to_end(crate::prelude::fold_job(cs_p7.clone(), None, {
                        let env_p0x = env_p0.clone();
                        let st_p1x = st_p1.clone();
                        let rows_p2x = rows_p2.clone();
                        let rest_p5x = rest_p5.clone();
                        Rc::new(move |(p0, p1): (Option<Array<Text>>, Ctor)| {
                            let env_p0xy = env_p0x.clone();
                            let st_p1xy = st_p1x.clone();
                            let rows_p2xy = rows_p2x.clone();
                            let rest_p5xy = rest_p5x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let found_o8 = p0;
                                let c_p9 = p1;
                                match &found_o8 {
                                    Some(f_pa) => prism_rtl::Turn::Finished(Some(f_pa.clone())),
                                    None => crate::prelude::call_then(start_witness_o(env_p0xy.clone(), st_p1xy.clone(), specialize_f(&rows_p2xy, &c_p9), crate::prelude::append(&c_p9.args_p, &rest_p5xy)), move |witness_o_12482: Option<Array<Text>>| match witness_o_12482 {
                                        Some(w_pb) => prism_rtl::Turn::Finished(Some(crate::prelude::append(&Array::from(vec![show_witness_f(&c_p9, &crate::prelude::take(&w_pb, &c_p9.arity_p))]), &crate::prelude::drop(&w_pb, &c_p9.arity_p)))),
                                        None => prism_rtl::Turn::Finished(None),
                                    }),
                                }
                            }))
                        }) as Rc<dyn Fn((Option<Array<Text>>, Ctor)) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>>>
                    }))
                } else {
                    match witness_o(env_p0, st_p1, &default_rows_f(rows_p2), &rest_p5) {
                        Some(w_pc) => {
                            let missing_pd = crate::prelude::filter(&cs_p7, &(|c_pf: &Ctor| !(crate::check::types::has_text_f(&heads_p6, &c_pf.name_p) || crate::check::types::has_text_f(&heads_p6, &Text::from(format!("fam:{}", &ctor_family_f(c_pf)))))));
                            let shown_pe = match crate::prelude::index(&missing_pd, &Nat::from(0u32)) {
                                Some(c_pg) => c_pg.shown_p.clone(),
                                None => Text::lit("_"),
                            };
                            Some(crate::prelude::append(&Array::from(vec![shown_pe.clone()]), &w_pc))
                        },
                        None => None,
                    }
                },
                None => match witness_o(env_p0, st_p1, &default_rows_f(rows_p2), &rest_p5) {
                    Some(w_ph) => Some(crate::prelude::append(&Array::from(vec![Text::lit("_")]), &w_ph)),
                    None => None,
                },
            }
        },
    }
}

/// The step machine of `Witness`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
/// ```
pub struct Witness {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub rows_p2: Array<Array<Pat>>,
    pub tys_p3: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<Option<Array<Text>>> for Witness {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<Text>>> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let rows_p2 = &self.rows_p2;
        let tys_p3 = &self.tys_p3;
        match crate::prelude::index(tys_p3, &Nat::from(0u32)) {
            None => if &crate::prelude::len(rows_p2) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(Some(Array::new()))
            } else {
                prism_rtl::Turn::Finished(None)
            },
            Some(t1_p4) => {
                let rest_p5 = crate::prelude::drop(tys_p3, &Nat::from(1u32));
                let heads_p6 = head_names_f(rows_p2);
                let env_p0x = env_p0.clone();
                let rows_p2x = rows_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_ctors_of_o(env_p0x.clone(), st_p1x.clone(), t1_p4.clone()), move |ctors_of_o_12268: Option<Array<Ctor>>| match ctors_of_o_12268 {
                    Some(cs_p7) => if complete_f(&cs_p7, &heads_p6, &rows_p2x) {
                        crate::prelude::fold_job(cs_p7.clone(), None, {
                            let env_p0xx = env_p0x.clone();
                            let st_p1xx = st_p1x.clone();
                            let rows_p2xx = rows_p2x.clone();
                            let rest_p5x = rest_p5.clone();
                            Rc::new(move |(p0, p1): (Option<Array<Text>>, Ctor)| {
                                let env_p0xxy = env_p0xx.clone();
                                let st_p1xxy = st_p1xx.clone();
                                let rows_p2xxy = rows_p2xx.clone();
                                let rest_p5xy = rest_p5x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let found_o8 = p0;
                                    let c_p9 = p1;
                                    match &found_o8 {
                                        Some(f_pa) => prism_rtl::Turn::Finished(Some(f_pa.clone())),
                                        None => crate::prelude::call_then(start_witness_o(env_p0xxy.clone(), st_p1xxy.clone(), specialize_f(&rows_p2xxy, &c_p9), crate::prelude::append(&c_p9.args_p, &rest_p5xy)), move |witness_o_12482: Option<Array<Text>>| match witness_o_12482 {
                                            Some(w_pb) => prism_rtl::Turn::Finished(Some(crate::prelude::append(&Array::from(vec![show_witness_f(&c_p9, &crate::prelude::take(&w_pb, &c_p9.arity_p))]), &crate::prelude::drop(&w_pb, &c_p9.arity_p)))),
                                            None => prism_rtl::Turn::Finished(None),
                                        }),
                                    }
                                }))
                            }) as Rc<dyn Fn((Option<Array<Text>>, Ctor)) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>>>
                        }).cycle()
                    } else {
                        crate::prelude::call_then(start_witness_o(env_p0x.clone(), st_p1x.clone(), default_rows_f(&rows_p2x), rest_p5.clone()), move |witness_o_12712: Option<Array<Text>>| match witness_o_12712 {
                            Some(w_pc) => {
                                let missing_pd = crate::prelude::filter(&cs_p7, &(|c_pf: &Ctor| !(crate::check::types::has_text_f(&heads_p6, &c_pf.name_p) || crate::check::types::has_text_f(&heads_p6, &Text::from(format!("fam:{}", &ctor_family_f(c_pf)))))));
                                let shown_pe = match crate::prelude::index(&missing_pd, &Nat::from(0u32)) {
                                    Some(c_pg) => c_pg.shown_p.clone(),
                                    None => Text::lit("_"),
                                };
                                prism_rtl::Turn::Finished(Some(crate::prelude::append(&Array::from(vec![shown_pe.clone()]), &w_pc)))
                            },
                            None => prism_rtl::Turn::Finished(None),
                        })
                    },
                    None => crate::prelude::call_then(start_witness_o(env_p0x.clone(), st_p1x.clone(), default_rows_f(&rows_p2x), rest_p5.clone()), move |witness_o_13138: Option<Array<Text>>| match witness_o_13138 {
                        Some(w_ph) => prism_rtl::Turn::Finished(Some(crate::prelude::append(&Array::from(vec![Text::lit("_")]), &w_ph))),
                        None => prism_rtl::Turn::Finished(None),
                    }),
                })
            },
        }
    }
}

/// `Start Witness, x`: what the function value is when passed to `@Run`.
pub fn start_witness_o(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, rows_p2: Array<Array<Pat>>, tys_p3: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>> {
    Rc::new(Witness { env_p0, st_p1, rows_p2, tys_p3 })
}

/// ```prism
/// ShowWitness: fn Ctor, [Text] -> Text
/// ```
pub fn show_witness_f(c_p0: &Ctor, args_p1: &Array<Text>) -> Text {
    if &c_p0.name_p == &Text::lit("?") {
        Text::from(format!("? {}", &crate::prelude::or(&crate::prelude::index(args_p1, &Nat::from(0u32)), &Text::lit("_"))))
    } else {
        if &c_p0.name_p == &Text::lit("~") {
            Text::from(format!("~ {}", &crate::prelude::or(&crate::prelude::index(args_p1, &Nat::from(0u32)), &Text::lit("_"))))
        } else {
            if &c_p0.name_p == &Text::lit("tuple") {
                Text::from(format!("(({}))", &crate::syntax::lexer::chars::join_f(args_p1, &Text::lit(", "))))
            } else {
                if (&crate::prelude::len(args_p1) == &Nat::from(0u32)) || crate::prelude::fold(args_p1, &true, &(|ok_p2: &bool, a_p3: &Text| *ok_p2 && (a_p3 == &Text::lit("_")))) {
                    c_p0.shown_p.clone()
                } else {
                    Text::from(format!("{} {}", &crate::check::types::bare_name_f(&c_p0.name_p), &crate::syntax::lexer::chars::join_f(args_p1, &Text::lit(", "))))
                }
            }
        }
    }
}

/// ```prism
/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
/// ```
pub fn match_coverage_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty, arms_p3: &Array<crate::syntax::Arm>, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    let has_otherwise_p5 = crate::prelude::fold(arms_p3, &false, &(|seen_p7: &bool, a_p8: &crate::syntax::Arm| *seen_p7 || (&a_p8.pattern_o == &None)));
    let tys_p6 = Array::from(vec![t_p2.clone()]);
    let (rows_pi, st2_pj) = crate::prelude::run_to_end(crate::prelude::fold_job(arms_p3.clone(), (Array::new(), st_p1.clone()), {
        let env_p0x = env_p0.clone();
        let tys_p6x = tys_p6.clone();
        let t_p2x = t_p2.clone();
        Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)| {
            let env_p0xy = env_p0x.clone();
            let tys_p6xy = tys_p6x.clone();
            let t_p2xy = t_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p9, s_pa) = p0;
                let arm_pb = p1;
                {
                    let q_pc = match &arm_pb.pattern_o {
                        Some(p_ph) => Array::from(vec![to_pat_f(&env_p0xy, p_ph)]),
                        None => Array::from(vec![Pat::PtAny]),
                    };
                    crate::prelude::call_then(start_useful_f(env_p0xy.clone(), s_pa.clone(), acc_p9.clone(), q_pc.clone(), tys_p6xy.clone()), move |useful_f_14224: bool| {
                        let reachable_pd = useful_f_14224;
                        crate::prelude::call_then(start_owns_row_f(env_p0xy.clone(), s_pa.clone(), t_p2xy.clone()), move |owns_row_f_14273: bool| {
                            let owns_all_pe = owns_row_f_14273;
                            let s2_pf = if reachable_pd {
                                s_pa.clone()
                            } else {
                                if (&arm_pb.pattern_o == &None) && !owns_all_pe {
                                    s_pa.clone()
                                } else {
                                    crate::check::types::recording::err_fix_f(&s_pa, &Text::lit("unreachable"), &arm_span_f(&arm_pb), &Text::lit("this arm is never reached"), &Text::lit("remove it, or put it above the arm that covers it"))
                                }
                            };
                            let acc2_pg = if &arm_pb.guard_o == &None {
                                crate::prelude::push(&acc_p9, &q_pc)
                            } else {
                                acc_p9.clone()
                            };
                            prism_rtl::Turn::Finished((acc2_pg.clone(), s2_pf.clone()))
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
    }));
    if has_otherwise_p5 {
        st2_pj.clone()
    } else {
        if is_open_row_f(env_p0, &st2_pj, t_p2) {
            crate::check::types::recording::err_fix_f(&st2_pj, &Text::lit("row-not-closed"), span_p4, &Text::from(format!("a match over `{}` needs `otherwise:`", &crate::check::types::show_ty_f(&st2_pj, t_p2))), &Text::lit("add an `otherwise:` arm: the row\'s variable may hold tags this match cannot name"))
        } else {
            match witness_o(env_p0, &st2_pj, &rows_pi, &tys_p6) {
                Some(w_pk) => crate::check::types::recording::err_fix_f(&st2_pj, &Text::lit("not-exhaustive"), span_p4, &Text::from(format!("this match misses `{}`", &crate::syntax::lexer::chars::join_f(&w_pk, &Text::lit(", ")))), &Text::lit("add an arm for it, or `otherwise:`")),
                None => st2_pj.clone(),
            }
        }
    }
}

/// The step machine of `MatchCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
/// ```
pub struct MatchCoverage {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
    pub arms_p3: Array<crate::syntax::Arm>,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for MatchCoverage {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let arms_p3 = &self.arms_p3;
        let span_p4 = &self.span_p4;
        let has_otherwise_p5 = crate::prelude::fold(arms_p3, &false, &(|seen_p7: &bool, a_p8: &crate::syntax::Arm| *seen_p7 || (&a_p8.pattern_o == &None)));
        let tys_p6 = Array::from(vec![t_p2.clone()]);
        let arms_p3x = arms_p3.clone();
        let env_p0x = env_p0.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_value(crate::prelude::fold_job(arms_p3x.clone(), (Array::new(), st_p1x.clone()), {
            let env_p0xx = env_p0x.clone();
            let tys_p6x = tys_p6.clone();
            let t_p2xx = t_p2x.clone();
            Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)| {
                let env_p0xxy = env_p0xx.clone();
                let tys_p6xy = tys_p6x.clone();
                let t_p2xxy = t_p2xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p9, s_pa) = p0;
                    let arm_pb = p1;
                    {
                        let q_pc = match &arm_pb.pattern_o {
                            Some(p_ph) => Array::from(vec![to_pat_f(&env_p0xxy, p_ph)]),
                            None => Array::from(vec![Pat::PtAny]),
                        };
                        crate::prelude::call_then(start_useful_f(env_p0xxy.clone(), s_pa.clone(), acc_p9.clone(), q_pc.clone(), tys_p6xy.clone()), move |useful_f_14224: bool| {
                            let reachable_pd = useful_f_14224;
                            crate::prelude::call_then(start_owns_row_f(env_p0xxy.clone(), s_pa.clone(), t_p2xxy.clone()), move |owns_row_f_14273: bool| {
                                let owns_all_pe = owns_row_f_14273;
                                let s2_pf = if reachable_pd {
                                    s_pa.clone()
                                } else {
                                    if (&arm_pb.pattern_o == &None) && !owns_all_pe {
                                        s_pa.clone()
                                    } else {
                                        crate::check::types::recording::err_fix_f(&s_pa, &Text::lit("unreachable"), &arm_span_f(&arm_pb), &Text::lit("this arm is never reached"), &Text::lit("remove it, or put it above the arm that covers it"))
                                    }
                                };
                                let acc2_pg = if &arm_pb.guard_o == &None {
                                    crate::prelude::push(&acc_p9, &q_pc)
                                } else {
                                    acc_p9.clone()
                                };
                                prism_rtl::Turn::Finished((acc2_pg.clone(), s2_pf.clone()))
                            })
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
        }), move |fold_14057: (Array<Array<Pat>>, crate::check::types::St)| {
            let (rows_pi, st2_pj) = fold_14057;
            if has_otherwise_p5 {
                prism_rtl::Turn::Finished(st2_pj.clone())
            } else {
                crate::prelude::call_then(start_is_open_row_f(env_p0x.clone(), st2_pj.clone(), t_p2x.clone()), move |is_open_row_f_14621: bool| if is_open_row_f_14621 {
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(st2_pj.clone(), t_p2x.clone()), move |show_ty_f_14696: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st2_pj, &Text::lit("row-not-closed"), &span_p4x, &Text::from(format!("a match over `{}` needs `otherwise:`", &show_ty_f_14696)), &Text::lit("add an `otherwise:` arm: the row\'s variable may hold tags this match cannot name"))))
                } else {
                    crate::prelude::call_then(start_witness_o(env_p0x.clone(), st2_pj.clone(), rows_pi.clone(), tys_p6.clone()), move |witness_o_14832: Option<Array<Text>>| match witness_o_14832 {
                        Some(w_pk) => prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st2_pj, &Text::lit("not-exhaustive"), &span_p4x, &Text::from(format!("this match misses `{}`", &crate::syntax::lexer::chars::join_f(&w_pk, &Text::lit(", ")))), &Text::lit("add an arm for it, or `otherwise:`"))),
                        None => prism_rtl::Turn::Finished(st2_pj.clone()),
                    })
                })
            }
        })
    }
}

/// `Start MatchCoverage, x`: what the function value is when passed to `@Run`.
pub fn start_match_coverage_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty, arms_p3: Array<crate::syntax::Arm>, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(MatchCoverage { env_p0, st_p1, t_p2, arms_p3, span_p4 })
}

/// ```prism
/// ArmSpan: fn Arm -> Range
/// ```
pub fn arm_span_f(a_p0: &crate::syntax::Arm) -> crate::syntax::Range {
    match &a_p0.pattern_o {
        Some(p_p1) => p_p1.span_p.clone(),
        None => a_p0.span_p.clone(),
    }
}

/// ```prism
/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub fn is_open_row_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk_f(st_p1, t_p2) {
        crate::check::types::Ty::TyElem(rw_p3, _) => &crate::check::types::recording::walk_row_f(st_p1, &rw_p3).tail_p != &crate::check::types::Tail::TlClosed,
        crate::check::types::Ty::TyElemAny(rw_p4) => &crate::check::types::recording::walk_row_f(st_p1, &rw_p4).tail_p != &crate::check::types::Tail::TlClosed,
        crate::check::types::Ty::TyCon(n_p5, m15254_2_1) if ((&m15254_2_1).len() == 0) => match crate::prelude::get(&env_p0.g_p.types_p, &n_p5) {
            Some(ti_p6) => (&ti_p6.body_p == &crate::check::env::TyBody::BRowKind) && !is_root_module_f(env_p0),
            None => ((&n_p5 == &Text::lit("Fault")) || (&n_p5 == &Text::lit("Prelude.Fault"))) && !is_root_module_f(env_p0),
        },
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `IsOpenRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub struct IsOpenRow {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for IsOpenRow {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), t_p2x.clone()), move |walk_f_15260: crate::check::types::Ty| match walk_f_15260 {
            crate::check::types::Ty::TyElem(rw_p3, _) => crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_p3.clone()), move |walk_row_f_15296: crate::check::types::Rw| prism_rtl::Turn::Finished(&walk_row_f_15296.tail_p != &crate::check::types::Tail::TlClosed)),
            crate::check::types::Ty::TyElemAny(rw_p4) => crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_p4.clone()), move |walk_row_f_15348: crate::check::types::Rw| prism_rtl::Turn::Finished(&walk_row_f_15348.tail_p != &crate::check::types::Tail::TlClosed)),
            crate::check::types::Ty::TyCon(n_p5, m15254_2_1) if ((&m15254_2_1).len() == 0) => match crate::prelude::get(&env_p0x.g_p.types_p, &n_p5) {
                Some(ti_p6) => prism_rtl::Turn::Finished((&ti_p6.body_p == &crate::check::env::TyBody::BRowKind) && !is_root_module_f(&env_p0x)),
                None => prism_rtl::Turn::Finished(((&n_p5 == &Text::lit("Fault")) || (&n_p5 == &Text::lit("Prelude.Fault"))) && !is_root_module_f(&env_p0x)),
            },
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start IsOpenRow, x`: what the function value is when passed to `@Run`.
pub fn start_is_open_row_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsOpenRow { env_p0, st_p1, t_p2 })
}

/// ```prism
/// OwnsRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub fn owns_row_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk_f(st_p1, t_p2) {
        crate::check::types::Ty::TyElem(rw_p3, _) => crate::prelude::fold(&crate::check::types::recording::walk_row_f(st_p1, &rw_p3).fams_p, &true, &(|ok_p4: &bool, f_p5: &Text| *ok_p4 && (&crate::prelude::or(&crate::prelude::get(&env_p0.g_p.fam_owner_p, f_p5), &Text::lit("")) == &env_p0.home_p))),
        crate::check::types::Ty::TyCon(n_p6, m15723_1_1) if ((&m15723_1_1).len() == 0) => match crate::prelude::get(&env_p0.g_p.types_p, &n_p6) {
            Some(ti_p7) => &ti_p7.body_p != &crate::check::env::TyBody::BRowKind,
            None => !((&n_p6 == &Text::lit("Fault")) || (&n_p6 == &Text::lit("Prelude.Fault"))),
        },
        _ => true,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `OwnsRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OwnsRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub struct OwnsRow {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for OwnsRow {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), t_p2x.clone()), move |walk_f_15729: crate::check::types::Ty| match walk_f_15729 {
            crate::check::types::Ty::TyElem(rw_p3, _) => crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_p3.clone()), move |walk_row_f_15770: crate::check::types::Rw| prism_rtl::Turn::Finished(crate::prelude::fold(&walk_row_f_15770.fams_p, &true, &(|ok_p4: &bool, f_p5: &Text| *ok_p4 && (&crate::prelude::or(&crate::prelude::get(&env_p0x.g_p.fam_owner_p, f_p5), &Text::lit("")) == &env_p0x.home_p))))),
            crate::check::types::Ty::TyCon(n_p6, m15723_1_1) if ((&m15723_1_1).len() == 0) => match crate::prelude::get(&env_p0x.g_p.types_p, &n_p6) {
                Some(ti_p7) => prism_rtl::Turn::Finished(&ti_p7.body_p != &crate::check::env::TyBody::BRowKind),
                None => prism_rtl::Turn::Finished(!((&n_p6 == &Text::lit("Fault")) || (&n_p6 == &Text::lit("Prelude.Fault")))),
            },
            _ => prism_rtl::Turn::Finished(true),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start OwnsRow, x`: what the function value is when passed to `@Run`.
pub fn start_owns_row_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(OwnsRow { env_p0, st_p1, t_p2 })
}

/// ```prism
/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
/// ```
pub fn clause_coverage_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, clauses_p2: &Array<crate::syntax::decls::FnClause>, params_p3: &Array<crate::check::types::Ty>, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    let (rows_pc, st2_pd) = crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p2.clone(), (Array::new(), st_p1.clone()), {
        let env_p0x = env_p0.clone();
        let params_p3x = params_p3.clone();
        Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::decls::FnClause)| {
            let env_p0xy = env_p0x.clone();
            let params_p3xy = params_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p5, s_p6) = p0;
                let c_p7 = p1;
                crate::prelude::call_value(crate::prelude::each_job(c_p7.params_p.clone(), {
                    let env_p0xyx = env_p0xy.clone();
                    Rc::new(move |p0: crate::syntax::Pattern_| {
                        let env_p0xyxy = env_p0xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let p_pb = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0xyxy.clone(), p_p1: p_pb.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_16266: Array<Pat>| {
                    let q_p8 = each_16266;
                    let reachable_p9 = (&crate::prelude::len(&q_p8) != &crate::prelude::len(&params_p3xy)) || useful_f(&env_p0xy, &s_p6, &acc_p5, &q_p8, &params_p3xy);
                    let s2_pa = if reachable_p9 {
                        s_p6.clone()
                    } else {
                        crate::check::types::recording::err_fix_f(&s_p6, &Text::lit("unreachable"), &c_p7.span_p, &Text::lit("this clause is never reached"), &Text::lit("remove it, or put it above the clause that covers it"))
                    };
                    prism_rtl::Turn::Finished((crate::prelude::push(&acc_p5, &q_p8), s2_pa.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
    }));
    if &crate::prelude::len(params_p3) == &Nat::from(0u32) {
        st2_pd.clone()
    } else {
        match witness_o(env_p0, &st2_pd, &rows_pc, params_p3) {
            Some(w_pe) => crate::check::types::recording::err_fix_f(&st2_pd, &Text::lit("not-exhaustive"), span_p4, &Text::from(format!("these clauses miss `{}`", &crate::syntax::lexer::chars::join_f(&w_pe, &Text::lit(", ")))), &Text::lit("add a clause for it")),
            None => st2_pd.clone(),
        }
    }
}

/// The step machine of `ClauseCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
/// ```
pub struct ClauseCoverage {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub clauses_p2: Array<crate::syntax::decls::FnClause>,
    pub params_p3: Array<crate::check::types::Ty>,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for ClauseCoverage {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let clauses_p2 = &self.clauses_p2;
        let params_p3 = &self.params_p3;
        let span_p4 = &self.span_p4;
        let clauses_p2x = clauses_p2.clone();
        let env_p0x = env_p0.clone();
        let params_p3x = params_p3.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(clauses_p2x.clone(), (Array::new(), st_p1x.clone()), {
            let env_p0xx = env_p0x.clone();
            let params_p3xx = params_p3x.clone();
            Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::decls::FnClause)| {
                let env_p0xxy = env_p0xx.clone();
                let params_p3xxy = params_p3xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p5, s_p6) = p0;
                    let c_p7 = p1;
                    crate::prelude::call_value(crate::prelude::each_job(c_p7.params_p.clone(), {
                        let env_p0xxyx = env_p0xxy.clone();
                        Rc::new(move |p0: crate::syntax::Pattern_| {
                            let env_p0xxyxy = env_p0xxyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let p_pb = p0;
                                prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0xxyxy.clone(), p_p1: p_pb.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                    }), move |each_16266: Array<Pat>| {
                        let q_p8 = each_16266;
                        let reachable_p9 = (&crate::prelude::len(&q_p8) != &crate::prelude::len(&params_p3xxy)) || useful_f(&env_p0xxy, &s_p6, &acc_p5, &q_p8, &params_p3xxy);
                        let s2_pa = if reachable_p9 {
                            s_p6.clone()
                        } else {
                            crate::check::types::recording::err_fix_f(&s_p6, &Text::lit("unreachable"), &c_p7.span_p, &Text::lit("this clause is never reached"), &Text::lit("remove it, or put it above the clause that covers it"))
                        };
                        prism_rtl::Turn::Finished((crate::prelude::push(&acc_p5, &q_p8), s2_pa.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
        }), move |fold_16205: (Array<Array<Pat>>, crate::check::types::St)| {
            let (rows_pc, st2_pd) = fold_16205;
            if &crate::prelude::len(&params_p3x) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(st2_pd.clone())
            } else {
                crate::prelude::call_then(start_witness_o(env_p0x.clone(), st2_pd.clone(), rows_pc.clone(), params_p3x.clone()), move |witness_o_16615: Option<Array<Text>>| match witness_o_16615 {
                    Some(w_pe) => prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st2_pd, &Text::lit("not-exhaustive"), &span_p4x, &Text::from(format!("these clauses miss `{}`", &crate::syntax::lexer::chars::join_f(&w_pe, &Text::lit(", ")))), &Text::lit("add a clause for it"))),
                    None => prism_rtl::Turn::Finished(st2_pd.clone()),
                })
            }
        })
    }
}

/// `Start ClauseCoverage, x`: what the function value is when passed to `@Run`.
pub fn start_clause_coverage_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, clauses_p2: Array<crate::syntax::decls::FnClause>, params_p3: Array<crate::check::types::Ty>, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ClauseCoverage { env_p0, st_p1, clauses_p2, params_p3, span_p4 })
}

/// ```prism
/// DischargeIncls: unbounded fn G, St, Nat -> St
/// ```
pub fn discharge_incls_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, from_p2: &Nat) -> crate::check::types::St {
    let batch_p3 = crate::prelude::drop(&st_p1.incls_p, from_p2);
    crate::prelude::run_to_end(crate::prelude::fold_job(batch_p3.clone(), st_p1.clone(), {
        let g_p0x = g_p0.clone();
        let batch_p3x = batch_p3.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Incl)| {
            let g_p0xy = g_p0x.clone();
            let batch_p3xy = batch_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p4 = p0;
                let inc_p5 = p1;
                crate::prelude::call_then(start_through_f(s_p4.clone(), inc_p5.clone(), batch_p3xy.clone()), move |through_f_17456: crate::check::types::Incl| prism_rtl::Turn::More(Rc::new(DischargeOne { g_p0: g_p0xy.clone(), st_p1: s_p4.clone(), inc_p2: through_f_17456 })))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `DischargeIncls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DischargeIncls: unbounded fn G, St, Nat -> St
/// ```
pub struct DischargeIncls {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub from_p2: Nat,
}

impl prism_rtl::Job<crate::check::types::St> for DischargeIncls {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let from_p2 = &self.from_p2;
        let batch_p3 = crate::prelude::drop(&st_p1.incls_p, from_p2);
        crate::prelude::fold_job(batch_p3.clone(), st_p1.clone(), {
            let g_p0x = g_p0.clone();
            let batch_p3x = batch_p3.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Incl)| {
                let g_p0xy = g_p0x.clone();
                let batch_p3xy = batch_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p4 = p0;
                    let inc_p5 = p1;
                    crate::prelude::call_then(start_through_f(s_p4.clone(), inc_p5.clone(), batch_p3xy.clone()), move |through_f_17456: crate::check::types::Incl| prism_rtl::Turn::More(Rc::new(DischargeOne { g_p0: g_p0xy.clone(), st_p1: s_p4.clone(), inc_p2: through_f_17456 })))
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start DischargeIncls, x`: what the function value is when passed to `@Run`.
pub fn start_discharge_incls_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, from_p2: Nat) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DischargeIncls { g_p0, st_p1, from_p2 })
}

/// ```prism
/// Through: unbounded fn St, Incl, [Incl] -> Incl
/// ```
pub fn through_f(st_p0: &crate::check::types::St, inc_p1: &crate::check::types::Incl, batch_p2: &Array<crate::check::types::Incl>) -> crate::check::types::Incl {
    let sup_p3 = crate::check::types::recording::walk_row_f(st_p0, &inc_p1.sup_p);
    match &sup_p3.tail_p {
        crate::check::types::Tail::TlFlex(n_p4) => if &crate::prelude::len(&sup_p3.fams_p) > &Nat::from(0u32) {
            inc_p1.clone()
        } else {
            crate::prelude::run_to_end(crate::prelude::fold_job(batch_p2.clone(), inc_p1.clone(), {
                let st_p0x = st_p0.clone();
                let n_p4x = n_p4.clone();
                let inc_p1x = inc_p1.clone();
                Rc::new(move |(p0, p1): (crate::check::types::Incl, crate::check::types::Incl)| {
                    let st_p0xy = st_p0x.clone();
                    let n_p4xy = n_p4x.clone();
                    let inc_p1xy = inc_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p5 = p0;
                        let other_p6 = p1;
                        crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p0xy.clone(), other_p6.sub_p.clone()), move |walk_row_f_17970: crate::check::types::Rw| {
                            let sub_p7 = walk_row_f_17970;
                            if ((&crate::prelude::len(&sub_p7.fams_p) == &Nat::from(0u32)) && (&sub_p7.tail_p == &crate::check::types::Tail::TlFlex(n_p4xy.clone()))) && (&other_p6 != &inc_p1xy) {
                                prism_rtl::Turn::Finished({
                                    let mut this: crate::check::types::Incl = acc_p5.clone();
                                    this.sup_p = other_p6.sup_p.clone();
                                    this
                                })
                            } else {
                                prism_rtl::Turn::Finished(acc_p5.clone())
                            }
                        })
                    }))
                }) as Rc<dyn Fn((crate::check::types::Incl, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::Incl>>>
            }))
        },
        _ => inc_p1.clone(),
    }
}

/// The step machine of `Through`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Through: unbounded fn St, Incl, [Incl] -> Incl
/// ```
pub struct Through {
    pub st_p0: crate::check::types::St,
    pub inc_p1: crate::check::types::Incl,
    pub batch_p2: Array<crate::check::types::Incl>,
}

impl prism_rtl::Job<crate::check::types::Incl> for Through {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Incl> {
        let st_p0 = &self.st_p0;
        let inc_p1 = &self.inc_p1;
        let batch_p2 = &self.batch_p2;
        let batch_p2x = batch_p2.clone();
        let inc_p1x = inc_p1.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p0x.clone(), inc_p1x.sup_p.clone()), move |walk_row_f_17798: crate::check::types::Rw| {
            let sup_p3 = walk_row_f_17798;
            match &sup_p3.tail_p {
                crate::check::types::Tail::TlFlex(n_p4) => if &crate::prelude::len(&sup_p3.fams_p) > &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(inc_p1x.clone())
                } else {
                    crate::prelude::fold_job(batch_p2x.clone(), inc_p1x.clone(), {
                        let st_p0xx = st_p0x.clone();
                        let n_p4x = n_p4.clone();
                        let inc_p1xx = inc_p1x.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::Incl, crate::check::types::Incl)| {
                            let st_p0xxy = st_p0xx.clone();
                            let n_p4xy = n_p4x.clone();
                            let inc_p1xxy = inc_p1xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_p5 = p0;
                                let other_p6 = p1;
                                crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p0xxy.clone(), other_p6.sub_p.clone()), move |walk_row_f_17970: crate::check::types::Rw| {
                                    let sub_p7 = walk_row_f_17970;
                                    if ((&crate::prelude::len(&sub_p7.fams_p) == &Nat::from(0u32)) && (&sub_p7.tail_p == &crate::check::types::Tail::TlFlex(n_p4xy.clone()))) && (&other_p6 != &inc_p1xxy) {
                                        prism_rtl::Turn::Finished({
                                            let mut this: crate::check::types::Incl = acc_p5.clone();
                                            this.sup_p = other_p6.sup_p.clone();
                                            this
                                        })
                                    } else {
                                        prism_rtl::Turn::Finished(acc_p5.clone())
                                    }
                                })
                            }))
                        }) as Rc<dyn Fn((crate::check::types::Incl, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::Incl>>>
                    }).cycle()
                },
                _ => prism_rtl::Turn::Finished(inc_p1x.clone()),
            }
        })
    }
}

/// `Start Through, x`: what the function value is when passed to `@Run`.
pub fn start_through_f(st_p0: crate::check::types::St, inc_p1: crate::check::types::Incl, batch_p2: Array<crate::check::types::Incl>) -> Rc<dyn prism_rtl::Job<crate::check::types::Incl>> {
    Rc::new(Through { st_p0, inc_p1, batch_p2 })
}

/// ```prism
/// DischargeOne: unbounded fn G, St, Incl -> St
/// ```
pub fn discharge_one_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, inc_p2: &crate::check::types::Incl) -> crate::check::types::St {
    let sub_p3 = crate::check::types::recording::walk_row_f(st_p1, &inc_p2.sub_p);
    let sup_p4 = crate::check::types::recording::walk_row_f(st_p1, &inc_p2.sup_p);
    let st1_p5 = match &sub_p3.tail_p {
        crate::check::types::Tail::TlFlex(n_p9) => close_tail_f(st_p1, n_p9),
        _ => st_p1.clone(),
    };
    let sub2_p6 = crate::check::types::recording::walk_row_f(&st1_p5, &inc_p2.sub_p);
    let left_p7 = crate::prelude::filter(&sub2_p6.fams_p, &(|f_pa: &Text| !crate::check::types::has_text_f(&sup_p4.fams_p, f_pa) && (&crate::prelude::len(&tags_left_f(g_p0, f_pa, &sub2_p6.minus_p)) > &Nat::from(0u32))));
    let tail_bad_p8 = match (sub2_p6.tail_p.clone(), sup_p4.tail_p.clone()) {
        (crate::check::types::Tail::TlRigid(a_pb), crate::check::types::Tail::TlRigid(b_pc)) => &a_pb != &b_pc,
        (crate::check::types::Tail::TlRigid(_), _) => true,
        _ => false,
    };
    if (&crate::prelude::len(&left_p7) == &Nat::from(0u32)) && !tail_bad_p8 {
        st1_p5.clone()
    } else {
        {
            let s0_pd = {
                let mut this: crate::check::types::St = st1_p5.clone();
                this.file_p = inc_p2.file_p.clone();
                this
            };
            let tags_pe = crate::prelude::fold(&left_p7, &Array::new(), &(|acc_pg: &Array<Text>, f_ph: &Text| crate::prelude::append(acc_pg, &tags_left_f(g_p0, f_ph, &sub2_p6.minus_p))));
            let s1_pf = if inc_p2.forward_p {
                crate::check::types::recording::err_fix_f(&s0_pd, &Text::lit("forwarding"), &inc_p2.span_p, &Text::from(format!("forwarding {} from a scope that emits {}", &crate::syntax::lexer::chars::join_f(&tags_pe, &Text::lit(", ")), &crate::check::types::show_row_f(&sup_p4))), &Text::from(format!("answer {} above this arm, for example `{}(..): @ never`", &(if &crate::prelude::len(&tags_pe) == &Nat::from(1u32) {
                    Text::lit("it")
                } else {
                    Text::lit("them")
                }), &crate::prelude::or(&crate::prelude::index(&tags_pe, &Nat::from(0u32)), &Text::lit("")))))
            } else {
                crate::check::types::recording::err_fix_f(&s0_pd, &Text::lit("row-outside"), &inc_p2.span_p, &Text::from(format!("a child that emits `{}` in a scope that emits `{}`", &crate::check::types::show_row_f(&sub2_p6), &crate::check::types::show_row_f(&sup_p4))), &Text::lit("widen the scope\'s `emit` row, or host the child with `@HostDocument`"))
            };
            {
                let mut this: crate::check::types::St = s1_pf.clone();
                this.file_p = st1_p5.file_p.clone();
                this
            }
        }
    }
}

/// The step machine of `DischargeOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DischargeOne: unbounded fn G, St, Incl -> St
/// ```
pub struct DischargeOne {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub inc_p2: crate::check::types::Incl,
}

impl prism_rtl::Job<crate::check::types::St> for DischargeOne {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let inc_p2 = &self.inc_p2;
        let g_p0x = g_p0.clone();
        let inc_p2x = inc_p2.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), inc_p2x.sub_p.clone()), move |walk_row_f_18289: crate::check::types::Rw| {
            let sub_p3 = walk_row_f_18289;
            crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), inc_p2x.sup_p.clone()), move |walk_row_f_18323: crate::check::types::Rw| {
                let sup_p4 = walk_row_f_18323;
                let st1_p5 = match &sub_p3.tail_p {
                    crate::check::types::Tail::TlFlex(n_p9) => close_tail_f(&st_p1x, n_p9),
                    _ => st_p1x.clone(),
                };
                crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st1_p5.clone(), inc_p2x.sub_p.clone()), move |walk_row_f_18444: crate::check::types::Rw| {
                    let sub2_p6 = walk_row_f_18444;
                    let left_p7 = crate::prelude::filter(&sub2_p6.fams_p, &(|f_pa: &Text| !crate::check::types::has_text_f(&sup_p4.fams_p, f_pa) && (&crate::prelude::len(&tags_left_f(&g_p0x, f_pa, &sub2_p6.minus_p)) > &Nat::from(0u32))));
                    let tail_bad_p8 = match (sub2_p6.tail_p.clone(), sup_p4.tail_p.clone()) {
                        (crate::check::types::Tail::TlRigid(a_pb), crate::check::types::Tail::TlRigid(b_pc)) => &a_pb != &b_pc,
                        (crate::check::types::Tail::TlRigid(_), _) => true,
                        _ => false,
                    };
                    if (&crate::prelude::len(&left_p7) == &Nat::from(0u32)) && !tail_bad_p8 {
                        prism_rtl::Turn::Finished(st1_p5.clone())
                    } else {
                        {
                            let s0_pd = {
                                let mut this: crate::check::types::St = st1_p5.clone();
                                this.file_p = inc_p2x.file_p.clone();
                                this
                            };
                            let tags_pe = crate::prelude::fold(&left_p7, &Array::new(), &(|acc_pg: &Array<Text>, f_ph: &Text| crate::prelude::append(acc_pg, &tags_left_f(&g_p0x, f_ph, &sub2_p6.minus_p))));
                            let s1_pf = if inc_p2x.forward_p {
                                crate::check::types::recording::err_fix_f(&s0_pd, &Text::lit("forwarding"), &inc_p2x.span_p, &Text::from(format!("forwarding {} from a scope that emits {}", &crate::syntax::lexer::chars::join_f(&tags_pe, &Text::lit(", ")), &crate::check::types::show_row_f(&sup_p4))), &Text::from(format!("answer {} above this arm, for example `{}(..): @ never`", &(if &crate::prelude::len(&tags_pe) == &Nat::from(1u32) {
                                    Text::lit("it")
                                } else {
                                    Text::lit("them")
                                }), &crate::prelude::or(&crate::prelude::index(&tags_pe, &Nat::from(0u32)), &Text::lit("")))))
                            } else {
                                crate::check::types::recording::err_fix_f(&s0_pd, &Text::lit("row-outside"), &inc_p2x.span_p, &Text::from(format!("a child that emits `{}` in a scope that emits `{}`", &crate::check::types::show_row_f(&sub2_p6), &crate::check::types::show_row_f(&sup_p4))), &Text::lit("widen the scope\'s `emit` row, or host the child with `@HostDocument`"))
                            };
                            prism_rtl::Turn::Finished({
                                let mut this: crate::check::types::St = s1_pf.clone();
                                this.file_p = st1_p5.file_p.clone();
                                this
                            })
                        }
                    }
                })
            })
        })
    }
}

/// `Start DischargeOne, x`: what the function value is when passed to `@Run`.
pub fn start_discharge_one_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, inc_p2: crate::check::types::Incl) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DischargeOne { g_p0, st_p1, inc_p2 })
}

/// ```prism
/// TagsLeft: fn G, Text, [Text] -> [Text]
/// ```
pub fn tags_left_f(g_p0: &crate::check::env::G, fam_p1: &Text, minus_p2: &Array<Text>) -> Array<Text> {
    crate::prelude::filter(&crate::prelude::or(&crate::prelude::get(&g_p0.families_p, fam_p1), &Array::new()), &(|t_p3: &Text| !crate::check::types::has_text_f(minus_p2, t_p3) && is_element_tag_f(g_p0, t_p3)))
}

/// ```prism
/// IsElementTag: fn G, Text -> Bool
/// ```
pub fn is_element_tag_f(g_p0: &crate::check::env::G, t_p1: &Text) -> bool {
    match crate::prelude::get(&g_p0.tags_p, t_p1) {
        Some(tg_p2) => &tg_p2.kind_p == &Text::lit("Element"),
        None => false,
    }
}

/// ```prism
/// CloseTail: fn St, Nat -> St
/// ```
pub fn close_tail_f(st_p0: &crate::check::types::St, n_p1: &Nat) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.rows_p = crate::prelude::insert(&this.rows_p, n_p1, &crate::check::types::empty_row_p());
    this
}
