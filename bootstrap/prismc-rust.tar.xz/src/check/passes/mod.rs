//! The module `Check.Passes`, from `target/bootstrap/src/prismc/check/passes/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Ctor`:
///
/// ```prism
/// type Ctor = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Ctor {
    pub name: Text,
    pub arity: Nat,
    pub args: Array<crate::check::types::Ty>,
    pub shown: Text,
}

impl Show for Ctor {
    fn show(&self, p: &mut Printer) {
        p.record("Ctor", &[("name", &self.name), ("arity", &self.arity), ("args", &self.args), ("shown", &self.shown)]);
    }
}

impl ToPod for Ctor {
    fn to_pod(&self) -> Pod {
        Pod::record("Ctor", vec![("name", self.name.to_pod()), ("arity", self.arity.to_pod()), ("args", self.args.to_pod()), ("shown", self.shown.to_pod())])
    }
}

impl FromPod for Ctor {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Ctor { name: FromPod::from_pod(field(p, "name")?)?, arity: FromPod::from_pod(field(p, "arity")?)?, args: FromPod::from_pod(field(p, "args")?)?, shown: FromPod::from_pod(field(p, "shown")?)? })
    }
}

/// `PCx`:
///
/// ```prism
/// type PCx = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct PCx {
    pub g: crate::check::env::G,
    pub home: Text,
    pub lams: Map<Nat, crate::syntax::Expr>,
    pub base: Map<Text, crate::check::shrink::Rel>,
}

impl Show for PCx {
    fn show(&self, p: &mut Printer) {
        p.record("PCx", &[("g", &self.g), ("home", &self.home), ("lams", &self.lams), ("base", &self.base)]);
    }
}

impl ToPod for PCx {
    fn to_pod(&self) -> Pod {
        Pod::record("PCx", vec![("g", self.g.to_pod()), ("home", self.home.to_pod()), ("lams", self.lams.to_pod()), ("base", self.base.to_pod())])
    }
}

impl FromPod for PCx {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(PCx { g: FromPod::from_pod(field(p, "g")?)?, home: FromPod::from_pod(field(p, "home")?)?, lams: FromPod::from_pod(field(p, "lams")?)?, base: FromPod::from_pod(field(p, "base")?)? })
    }
}

/// `Pat`:
///
/// ```prism
/// type Pat = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Pat {
    PtAny,
    PtCon(Text, Array<Pat>),
    PtLit(Text),
    PtFam(Text),
}

impl Show for Pat {
    fn show(&self, p: &mut Printer) {
        match self {
            Pat::PtAny => p.choice("PtAny", &[]),
            Pat::PtCon(a0, a1) => p.choice("PtCon", &[a0, a1]),
            Pat::PtLit(a0) => p.choice("PtLit", &[a0]),
            Pat::PtFam(a0) => p.choice("PtFam", &[a0]),
        }
    }
}

impl ToPod for Pat {
    fn to_pod(&self) -> Pod {
        match self {
            Pat::PtAny => Pod::Choice("PtAny".into(), vec![]),
            Pat::PtCon(a0, a1) => Pod::Choice("PtCon".into(), vec![a0.to_pod(), a1.to_pod()]),
            Pat::PtLit(a0) => Pod::Choice("PtLit".into(), vec![a0.to_pod()]),
            Pat::PtFam(a0) => Pod::Choice("PtFam".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Pat {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "PtAny" && a.len() == 0 => Ok(Pat::PtAny),
            Pod::Choice(c, a) if &**c == "PtCon" && a.len() == 2 => Ok(Pat::PtCon(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "PtLit" && a.len() == 1 => Ok(Pat::PtLit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PtFam" && a.len() == 1 => Ok(Pat::PtFam(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Pat", other),
        }
    }
}

/// ```prism
/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
/// ```
pub fn ctors_of(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::check::types::Ty) -> Option<Array<Ctor>> {
    match crate::check::types::walk(st, t) {
        crate::check::types::Ty::TyCon(m2108_0_0, m2108_0_1) if (&m2108_0_0 == &Text::lit("Bool")) && ((&m2108_0_1).len() == 0) => Some(Array::from(vec![Ctor { name: Text::lit("True"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("True") }, Ctor { name: Text::lit("False"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("False") }])),
        crate::check::types::Ty::TyCon(m2108_1_0, m2108_1_1) if (&m2108_1_0 == &Text::lit("unit")) && ((&m2108_1_1).len() == 0) => Some(Array::from(vec![Ctor { name: Text::lit("unit"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("unit") }])),
        crate::check::types::Ty::TySig(m2108_2_0, i) if (&m2108_2_0 == &Text::lit("?")) => Some(Array::from(vec![Ctor { name: Text::lit("?"), arity: Nat::from(1u32), args: Array::from(vec![(*i).clone()]), shown: Text::lit("? _") }, Ctor { name: Text::lit("nil"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("nil") }])),
        crate::check::types::Ty::TySig(m2108_3_0, i) if (&m2108_3_0 == &Text::lit("~")) => Some(Array::from(vec![Ctor { name: Text::lit("~"), arity: Nat::from(1u32), args: Array::from(vec![(*i).clone()]), shown: Text::lit("~ _") }, Ctor { name: Text::lit("Error"), arity: Nat::from(2u32), args: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text()]), shown: Text::lit("Error(..)") }])),
        crate::check::types::Ty::TyTuple(ts) => Some(Array::from(vec![Ctor { name: Text::lit("tuple"), arity: len(&ts), args: ts.clone(), shown: Text::from(format!("(({}))", &crate::syntax::lexer::join(&each(&ts, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", ")))) }])),
        crate::check::types::Ty::TyCon(m2108_5_0, m2108_5_1) if (&m2108_5_0 == &Text::lit("Prelude.Error")) && ((&m2108_5_1).len() == 0) => Some(Array::from(vec![Ctor { name: Text::lit("Error"), arity: Nat::from(2u32), args: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text()]), shown: Text::lit("Error(..)") }])),
        crate::check::types::Ty::TyCon(n, args) => match get(&env.g.types, &n) {
            Some(ti) => match &ti.body {
                crate::check::env::TyBody::BChoice(cases) => Some(run_to_end(each_job(cases.clone(), {
                    let ti = ti.clone();
                    let args = args.clone();
                    Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                        let ti = ti.clone();
                        let args = args.clone();
                        entered(once_job(move || {
                            let (cn, cargs) = p0;
                            prism_rtl::Turn::More(Rc::new(CtorOfCase { ti: ti.clone(), cn: cn.clone(), cargs: cargs.clone(), args: args.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<Ctor>>>
                }))),
                crate::check::env::TyBody::BRecord(fields) => Some(Array::from(vec![Ctor { name: n.clone(), arity: len(fields), args: run_to_end(each_job(fields.clone(), {
                    let ti = ti.clone();
                    let args = args.clone();
                    Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                        let ti = ti.clone();
                        let args = args.clone();
                        entered(once_job(move || {
                            let (_, ft) = p0;
                            prism_rtl::Turn::More(Rc::new(crate::check::types::SubstQ { m: crate::check::env::param_inst(&ti.params, &args), t: ft.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                })), shown: Text::from(format!("{}(..)", &crate::check::types::bare_name(&n))) }])),
                crate::check::env::TyBody::BRowKind => if is_root_module(env) {
                    Some(each(&tags_of_kind(env, &n), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg))))
                } else {
                    None
                },
                _ => None,
            },
            None => if (&n == &Text::lit("Fault")) || (&n == &Text::lit("Prelude.Fault")) {
                if is_root_module(env) {
                    Some(each(&tags_of_kind(env, &Text::lit("Prelude.Fault")), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg))))
                } else {
                    None
                }
            } else {
                None
            },
        },
        crate::check::types::Ty::TyElem(rw, _) => {
            let w = crate::check::types::walk_row(st, &rw);
            if &w.tail != &crate::check::types::Tail::TlClosed {
                None
            } else {
                Some(each(&tags_of_row(env, &w), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg))))
            }
        },
        crate::check::types::Ty::TyElemAny(rw) => {
            let w = crate::check::types::walk_row(st, &rw);
            if &w.tail != &crate::check::types::Tail::TlClosed {
                None
            } else {
                Some(each(&tags_of_row(env, &w), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg))))
            }
        },
        _ => None,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CtorsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
/// ```
pub struct CtorsOf {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Option<Array<Ctor>>> for CtorsOf {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<Ctor>>> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::start_walk(st.clone(), t.clone()), move |walk_2114: crate::check::types::Ty| match walk_2114 {
            crate::check::types::Ty::TyCon(m2108_0_0, m2108_0_1) if (&m2108_0_0 == &Text::lit("Bool")) && ((&m2108_0_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("True"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("True") }, Ctor { name: Text::lit("False"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("False") }]))),
            crate::check::types::Ty::TyCon(m2108_1_0, m2108_1_1) if (&m2108_1_0 == &Text::lit("unit")) && ((&m2108_1_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("unit"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("unit") }]))),
            crate::check::types::Ty::TySig(m2108_2_0, i) if (&m2108_2_0 == &Text::lit("?")) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("?"), arity: Nat::from(1u32), args: Array::from(vec![(*i).clone()]), shown: Text::lit("? _") }, Ctor { name: Text::lit("nil"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("nil") }]))),
            crate::check::types::Ty::TySig(m2108_3_0, i) if (&m2108_3_0 == &Text::lit("~")) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("~"), arity: Nat::from(1u32), args: Array::from(vec![(*i).clone()]), shown: Text::lit("~ _") }, Ctor { name: Text::lit("Error"), arity: Nat::from(2u32), args: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text()]), shown: Text::lit("Error(..)") }]))),
            crate::check::types::Ty::TyTuple(ts) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("tuple"), arity: len(&ts), args: ts.clone(), shown: Text::from(format!("(({}))", &crate::syntax::lexer::join(&each(&ts, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", ")))) }]))),
            crate::check::types::Ty::TyCon(m2108_5_0, m2108_5_1) if (&m2108_5_0 == &Text::lit("Prelude.Error")) && ((&m2108_5_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("Error"), arity: Nat::from(2u32), args: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text()]), shown: Text::lit("Error(..)") }]))),
            crate::check::types::Ty::TyCon(n, args) => match get(&env.g.types, &n) {
                Some(ti) => match &ti.body {
                    crate::check::env::TyBody::BChoice(cases) => prism_rtl::Turn::Finished(Some(run_to_end(each_job(cases.clone(), {
                        let ti = ti.clone();
                        let args = args.clone();
                        Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                            let ti = ti.clone();
                            let args = args.clone();
                            entered(once_job(move || {
                                let (cn, cargs) = p0;
                                prism_rtl::Turn::More(Rc::new(CtorOfCase { ti: ti.clone(), cn: cn.clone(), cargs: cargs.clone(), args: args.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<Ctor>>>
                    })))),
                    crate::check::env::TyBody::BRecord(fields) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: n.clone(), arity: len(fields), args: run_to_end(each_job(fields.clone(), {
                        let ti = ti.clone();
                        let args = args.clone();
                        Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                            let ti = ti.clone();
                            let args = args.clone();
                            entered(once_job(move || {
                                let (_, ft) = p0;
                                prism_rtl::Turn::More(Rc::new(crate::check::types::SubstQ { m: crate::check::env::param_inst(&ti.params, &args), t: ft.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                    })), shown: Text::from(format!("{}(..)", &crate::check::types::bare_name(&n))) }]))),
                    crate::check::env::TyBody::BRowKind => if is_root_module(&env) {
                        prism_rtl::Turn::Finished(Some(each(&tags_of_kind(&env, &n), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg)))))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    },
                    _ => prism_rtl::Turn::Finished(None),
                },
                None => if (&n == &Text::lit("Fault")) || (&n == &Text::lit("Prelude.Fault")) {
                    if is_root_module(&env) {
                        prism_rtl::Turn::Finished(Some(each(&tags_of_kind(&env, &Text::lit("Prelude.Fault")), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg)))))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    }
                } else {
                    prism_rtl::Turn::Finished(None)
                },
            },
            crate::check::types::Ty::TyElem(rw, _) => call_then(crate::check::types::start_walk_row(st.clone(), rw.clone()), move |walk_row_3543: crate::check::types::Rw| {
                let w = walk_row_3543;
                if &w.tail != &crate::check::types::Tail::TlClosed {
                    prism_rtl::Turn::Finished(None)
                } else {
                    prism_rtl::Turn::Finished(Some(each(&tags_of_row(&env, &w), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg)))))
                }
            }),
            crate::check::types::Ty::TyElemAny(rw) => call_then(crate::check::types::start_walk_row(st.clone(), rw.clone()), move |walk_row_3687: crate::check::types::Rw| {
                let w = walk_row_3687;
                if &w.tail != &crate::check::types::Tail::TlClosed {
                    prism_rtl::Turn::Finished(None)
                } else {
                    prism_rtl::Turn::Finished(Some(each(&tags_of_row(&env, &w), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg)))))
                }
            }),
            _ => prism_rtl::Turn::Finished(None),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start CtorsOf, x`: what the function value is when passed to `@Run`.
pub fn start_ctors_of(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Option<Array<Ctor>>>> {
    Rc::new(CtorsOf { env, st, t })
}

/// ```prism
/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
/// ```
pub fn ctor_of_case(ti: &crate::check::env::TyInfo, cn: &Text, cargs: &Array<crate::check::types::Ty>, args: &Array<crate::check::types::Ty>) -> Ctor {
    let qk = crate::check::env::qual_key(&ti.home, cn);
    Ctor { name: qk.clone(), arity: len(cargs), args: run_to_end(each_job(cargs.clone(), {
        let ti = ti.clone();
        let args = args.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let ti = ti.clone();
            let args = args.clone();
            entered(once_job(move || {
                let a = p0;
                prism_rtl::Turn::More(Rc::new(crate::check::types::SubstQ { m: crate::check::env::param_inst(&ti.params, &args), t: a.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
    })), shown: if &len(cargs) == &Nat::from(0u32) {
        cn.clone()
    } else {
        Text::from(format!("{} {}", cn, &crate::syntax::lexer::join(&each(cargs, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", "))))
    } }
}

/// The step machine of `CtorOfCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
/// ```
pub struct CtorOfCase {
    pub ti: crate::check::env::TyInfo,
    pub cn: Text,
    pub cargs: Array<crate::check::types::Ty>,
    pub args: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<Ctor> for CtorOfCase {
    fn cycle(&self) -> prism_rtl::Turn<Ctor> {
        let ti = &self.ti;
        let cn = &self.cn;
        let cargs = &self.cargs;
        let args = &self.args;
        let qk = crate::check::env::qual_key(&ti.home, cn);
        let args = args.clone();
        let cargs = cargs.clone();
        let cn = cn.clone();
        let ti = ti.clone();
        call_value(each_job(cargs.clone(), {
            let ti = ti.clone();
            let args = args.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let ti = ti.clone();
                let args = args.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::SubstQ { m: crate::check::env::param_inst(&ti.params, &args), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }), move |each_3986: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(Ctor { name: qk.clone(), arity: len(&cargs), args: each_3986, shown: if &len(&cargs) == &Nat::from(0u32) {
            cn.clone()
        } else {
            Text::from(format!("{} {}", &cn, &crate::syntax::lexer::join(&each(&cargs, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", "))))
        } }))
    }
}

/// `Start CtorOfCase, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_of_case(ti: crate::check::env::TyInfo, cn: Text, cargs: Array<crate::check::types::Ty>, args: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<Ctor>> {
    Rc::new(CtorOfCase { ti, cn, cargs, args })
}

/// ```prism
/// TagCtor: fn TagInfo -> Ctor
/// ```
pub fn tag_ctor(tg: &crate::check::env::TagInfo) -> Ctor {
    Ctor { name: Text::from(format!("tag:{}", &tg.name)), arity: len(&tg.fields), args: each(&tg.fields, &(|(_, ft): &(Text, crate::check::types::Ty)| crate::check::types::Ty::TyErr)), shown: tg.name.clone() }
}

/// ```prism
/// IsRootModule: fn Env -> Bool
/// ```
pub fn is_root_module(env: &crate::check::expr::Env) -> bool {
    &env.home == &Text::lit("")
}

/// ```prism
/// TagsOfKind: fn Env, Text -> [TagInfo]
/// ```
pub fn tags_of_kind(env: &crate::check::expr::Env, kind: &Text) -> Array<crate::check::env::TagInfo> {
    filter(&values(&env.g.tags), &(|tg: &crate::check::env::TagInfo| (&tg.kind == kind) || ((&crate::check::types::bare_name(&tg.kind) == &Text::lit("Fault")) && (&crate::check::types::bare_name(kind) == &Text::lit("Fault")))))
}

/// ```prism
/// TagsOfRow: fn Env, Rw -> [TagInfo]
/// ```
pub fn tags_of_row(env: &crate::check::expr::Env, w: &crate::check::types::Rw) -> Array<crate::check::env::TagInfo> {
    filter(&values(&env.g.tags), &(|tg: &crate::check::env::TagInfo| ((&tg.kind == &Text::lit("Element")) && crate::check::types::has_text(&w.fams, &tg.family)) && !crate::check::types::has_text(&w.minus, &tg.name)))
}

/// ```prism
/// ToPat: unbounded fn Env, Pattern -> Pat
/// ```
pub fn to_pat(env: &crate::check::expr::Env, p_: &crate::syntax::Pattern_) -> Pat {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => {
            let bare = or(&index(&n.path_, &Nat::from(0u32)), &Text::lit(""));
            if (&len(&n.path_) > &Nat::from(1u32)) && crate::check::env::has_key(&env.g.tags, &crate::check::env::dotted(&n.path_)) {
                Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted(&n.path_))), Array::new())
            } else {
                if (crate::check::env::is_upper_text(&bare) && (&len_text(&n.sigils) == &Nat::from(0u32))) && crate::check::expr::is_ctor_name(env, n) {
                    Pat::PtCon(ctor_key(env, n), Array::new())
                } else {
                    Pat::PtAny
                }
            }
        },
        crate::syntax::PatternKind::PIgnore => Pat::PtAny,
        crate::syntax::PatternKind::PLit(l) => Pat::PtLit(lit_text(l)),
        crate::syntax::PatternKind::PNeg(l) => Pat::PtLit(Text::from(format!("-{}", &lit_text(l)))),
        crate::syntax::PatternKind::PUnit => Pat::PtCon(Text::lit("unit"), Array::new()),
        crate::syntax::PatternKind::PNil => Pat::PtCon(Text::lit("nil"), Array::new()),
        crate::syntax::PatternKind::PCtor(n, args) => if crate::check::env::has_key(&env.g.tags, &crate::check::env::dotted(&n.path_)) {
            Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted(&n.path_))), Array::new())
        } else {
            Pat::PtCon(ctor_key(env, n), run_to_end(each_job(args.clone(), {
                let env = env.clone();
                Rc::new(move |p0: crate::syntax::Pattern_| {
                    let env = env.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: a.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
        crate::syntax::PatternKind::PRecord(n, fields, _) => record_pat(env, n, fields),
        crate::syntax::PatternKind::PSigil(s, q) => Pat::PtCon(s.clone(), Array::from(vec![to_pat(env, &**q)])),
        crate::syntax::PatternKind::PTuple(ps) => Pat::PtCon(Text::lit("tuple"), run_to_end(each_job(ps.clone(), {
            let env = env.clone();
            Rc::new(move |p0: crate::syntax::Pattern_| {
                let env = env.clone();
                entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: q.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
        }))),
        crate::syntax::PatternKind::PArray(ps) => Pat::PtCon(Text::from(format!("len{}", &len(ps))), run_to_end(each_job(ps.clone(), {
            let env = env.clone();
            Rc::new(move |p0: crate::syntax::Pattern_| {
                let env = env.clone();
                entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: q.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
        }))),
        crate::syntax::PatternKind::PGroup(q) => to_pat(env, &**q),
        crate::syntax::PatternKind::PFamily(q) => Pat::PtFam(crate::check::env::dotted(&q.path_)),
    }
}

/// The step machine of `ToPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPat: unbounded fn Env, Pattern -> Pat
/// ```
pub struct ToPat {
    pub env: crate::check::expr::Env,
    pub p_: crate::syntax::Pattern_,
}

impl prism_rtl::Job<Pat> for ToPat {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env = &self.env;
        let p_ = &self.p_;
        match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => {
                let bare = or(&index(&n.path_, &Nat::from(0u32)), &Text::lit(""));
                if (&len(&n.path_) > &Nat::from(1u32)) && crate::check::env::has_key(&env.g.tags, &crate::check::env::dotted(&n.path_)) {
                    prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted(&n.path_))), Array::new()))
                } else {
                    if (crate::check::env::is_upper_text(&bare) && (&len_text(&n.sigils) == &Nat::from(0u32))) && crate::check::expr::is_ctor_name(env, n) {
                        prism_rtl::Turn::Finished(Pat::PtCon(ctor_key(env, n), Array::new()))
                    } else {
                        prism_rtl::Turn::Finished(Pat::PtAny)
                    }
                }
            },
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(Pat::PtAny),
            crate::syntax::PatternKind::PLit(l) => prism_rtl::Turn::Finished(Pat::PtLit(lit_text(l))),
            crate::syntax::PatternKind::PNeg(l) => prism_rtl::Turn::Finished(Pat::PtLit(Text::from(format!("-{}", &lit_text(l))))),
            crate::syntax::PatternKind::PUnit => prism_rtl::Turn::Finished(Pat::PtCon(Text::lit("unit"), Array::new())),
            crate::syntax::PatternKind::PNil => prism_rtl::Turn::Finished(Pat::PtCon(Text::lit("nil"), Array::new())),
            crate::syntax::PatternKind::PCtor(n, args) => if crate::check::env::has_key(&env.g.tags, &crate::check::env::dotted(&n.path_)) {
                prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted(&n.path_))), Array::new()))
            } else {
                {
                    let args = args.clone();
                    let env = env.clone();
                    let n = n.clone();
                    call_value(each_job(args.clone(), {
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Pattern_| {
                            let env = env.clone();
                            entered(once_job(move || {
                                let a = p0;
                                prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: a.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                    }), move |each_5488: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(ctor_key(&env, &n), each_5488)))
                }
            },
            crate::syntax::PatternKind::PRecord(n, fields, _) => prism_rtl::Turn::More(Rc::new(RecordPat { env: env.clone(), n: n.clone(), fields: fields.clone() })),
            crate::syntax::PatternKind::PSigil(s, q) => {
                let env = env.clone();
                let q = (**q).clone();
                let s = s.clone();
                call_then(start_to_pat(env.clone(), q.clone()), move |to_pat_5603: Pat| prism_rtl::Turn::Finished(Pat::PtCon(s.clone(), Array::from(vec![to_pat_5603]))))
            },
            crate::syntax::PatternKind::PTuple(ps) => {
                let env = env.clone();
                let ps = ps.clone();
                call_value(each_job(ps.clone(), {
                    let env = env.clone();
                    Rc::new(move |p0: crate::syntax::Pattern_| {
                        let env = env.clone();
                        entered(once_job(move || {
                            let q = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: q.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_5650: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::lit("tuple"), each_5650)))
            },
            crate::syntax::PatternKind::PArray(ps) => {
                let env = env.clone();
                let ps = ps.clone();
                call_value(each_job(ps.clone(), {
                    let env = env.clone();
                    Rc::new(move |p0: crate::syntax::Pattern_| {
                        let env = env.clone();
                        entered(once_job(move || {
                            let q = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: q.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_5715: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("len{}", &len(&ps))), each_5715)))
            },
            crate::syntax::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: (**q).clone() })),
            crate::syntax::PatternKind::PFamily(q) => prism_rtl::Turn::Finished(Pat::PtFam(crate::check::env::dotted(&q.path_))),
        }
    }
}

/// `Start ToPat, x`: what the function value is when passed to `@Run`.
pub fn start_to_pat(env: crate::check::expr::Env, p_: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(ToPat { env, p_ })
}

/// ```prism
/// LitText: fn Literal -> Text
/// ```
pub fn lit_text(l: &crate::syntax::Literal) -> Text {
    match &l.kind {
        crate::syntax::LitKind::LInt(d) => d.clone(),
        crate::syntax::LitKind::LFloat(d) => d.clone(),
        crate::syntax::LitKind::LChar(c) => Text::from(format!("'{}'", c)),
        crate::syntax::LitKind::LText(segs) => concat(&each(segs, &lit_seg_text)),
        crate::syntax::LitKind::LDuration(d, u) => Text::from(format!("{}{}", d, u)),
    }
}

/// ```prism
/// LitSegText: fn TextSeg -> Text
/// ```
pub fn lit_seg_text(text_seg0: &crate::syntax::TextSeg) -> Text {
    match text_seg0 {
        crate::syntax::TextSeg::SegPlain(t) => t.clone(),
        _ => Text::lit("{}"),
    }
}

/// ```prism
/// CtorKey: fn Env, SName -> Text
/// ```
pub fn ctor_key(env: &crate::check::expr::Env, n: &crate::syntax::SName) -> Text {
    let (qk_opt, _) = crate::check::env::resolve_value(&env.g, &env.home, n);
    or(&qk_opt, &crate::check::env::sname_key(n))
}

/// ```prism
/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
/// ```
pub fn record_pat(env: &crate::check::expr::Env, n: &crate::syntax::SName, fields: &Array<crate::syntax::FieldPat>) -> Pat {
    let name = crate::check::env::dotted(&n.path_);
    match get(&env.g.tags, &name) {
        Some(tg) => {
            let names = each(&tg.fields, &(|(f, _): &(Text, crate::check::types::Ty)| f.clone()));
            Pat::PtCon(Text::from(format!("tag:{}", &name)), run_to_end(each_job(names.clone(), {
                let env = env.clone();
                let fields = fields.clone();
                let names = names.clone();
                Rc::new(move |p0: Text| {
                    let env = env.clone();
                    let fields = fields.clone();
                    let names = names.clone();
                    entered(once_job(move || {
                        let f = p0;
                        prism_rtl::Turn::More(Rc::new(FieldPatFor { env: env.clone(), fields: fields.clone(), names: names.clone(), f: f.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
        None => {
            let qk = ctor_key(env, n);
            let fnames = if &crate::check::types::bare_name(&qk) == &Text::lit("Error") {
                Array::from(vec![Text::lit("kind"), Text::lit("message")])
            } else {
                or(&get(&env.g.ctors, &qk), &dummy_ctor()).fields.clone()
            };
            let pkey = if &crate::check::types::bare_name(&qk) == &Text::lit("Error") {
                Text::lit("Error")
            } else {
                qk.clone()
            };
            Pat::PtCon(pkey.clone(), run_to_end(each_job(fnames.clone(), {
                let env = env.clone();
                let fields = fields.clone();
                let fnames = fnames.clone();
                Rc::new(move |p0: Text| {
                    let env = env.clone();
                    let fields = fields.clone();
                    let fnames = fnames.clone();
                    entered(once_job(move || {
                        let f = p0;
                        prism_rtl::Turn::More(Rc::new(FieldPatFor { env: env.clone(), fields: fields.clone(), names: fnames.clone(), f: f.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
    }
}

/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
/// ```
pub struct RecordPat {
    pub env: crate::check::expr::Env,
    pub n: crate::syntax::SName,
    pub fields: Array<crate::syntax::FieldPat>,
}

impl prism_rtl::Job<Pat> for RecordPat {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env = &self.env;
        let n = &self.n;
        let fields = &self.fields;
        let name = crate::check::env::dotted(&n.path_);
        match get(&env.g.tags, &name) {
            Some(tg) => {
                let names = each(&tg.fields, &(|(f, _): &(Text, crate::check::types::Ty)| f.clone()));
                let env = env.clone();
                let fields = fields.clone();
                call_value(each_job(names.clone(), {
                    let env = env.clone();
                    let fields = fields.clone();
                    let names = names.clone();
                    Rc::new(move |p0: Text| {
                        let env = env.clone();
                        let fields = fields.clone();
                        let names = names.clone();
                        entered(once_job(move || {
                            let f = p0;
                            prism_rtl::Turn::More(Rc::new(FieldPatFor { env: env.clone(), fields: fields.clone(), names: names.clone(), f: f.clone() }))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_6554: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &name)), each_6554)))
            },
            None => {
                let qk = ctor_key(env, n);
                let fnames = if &crate::check::types::bare_name(&qk) == &Text::lit("Error") {
                    Array::from(vec![Text::lit("kind"), Text::lit("message")])
                } else {
                    or(&get(&env.g.ctors, &qk), &dummy_ctor()).fields.clone()
                };
                let pkey = if &crate::check::types::bare_name(&qk) == &Text::lit("Error") {
                    Text::lit("Error")
                } else {
                    qk.clone()
                };
                let env = env.clone();
                let fields = fields.clone();
                call_value(each_job(fnames.clone(), {
                    let env = env.clone();
                    let fields = fields.clone();
                    let fnames = fnames.clone();
                    Rc::new(move |p0: Text| {
                        let env = env.clone();
                        let fields = fields.clone();
                        let fnames = fnames.clone();
                        entered(once_job(move || {
                            let f = p0;
                            prism_rtl::Turn::More(Rc::new(FieldPatFor { env: env.clone(), fields: fields.clone(), names: fnames.clone(), f: f.clone() }))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_6870: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(pkey.clone(), each_6870)))
            },
        }
    }
}

/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
pub fn start_record_pat(env: crate::check::expr::Env, n: crate::syntax::SName, fields: Array<crate::syntax::FieldPat>) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(RecordPat { env, n, fields })
}

/// ```prism
/// let dummyCtor
/// ```
pub fn dummy_ctor() -> crate::check::env::CtorInfo {
    crate::check::env::CtorInfo { name: Text::lit(""), owner: Text::lit(""), params: Array::new(), args: Array::new(), fields: Array::new(), ty: crate::check::types::Ty::TyErr, index: Nat::from(0u32) }
}

/// ```prism
/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
/// ```
pub fn field_pat_for(env: &crate::check::expr::Env, fields: &Array<crate::syntax::FieldPat>, names: &Array<Text>, f: &Text) -> Pat {
    run_to_end(fold_job(crate::check::errors::range0(&len(fields)), Pat::PtAny, {
        let fields = fields.clone();
        let names = names.clone();
        let f = f.clone();
        let env = env.clone();
        Rc::new(move |(p0, p1): (Pat, Nat)| {
            let fields = fields.clone();
            let names = names.clone();
            let f = f.clone();
            let env = env.clone();
            entered(once_job(move || {
                let acc = p0;
                let i = p1;
                match index(&fields, &i) {
                    Some(fp) => if &crate::check::expr::field_pat_name(&fp, &names, &i) == &f {
                        prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: fp.pattern.clone() }))
                    } else {
                        prism_rtl::Turn::Finished(acc.clone())
                    },
                    None => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))
        }) as Rc<dyn Fn((Pat, Nat)) -> Rc<dyn prism_rtl::Job<Pat>>>
    }))
}

/// The step machine of `FieldPatFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
/// ```
pub struct FieldPatFor {
    pub env: crate::check::expr::Env,
    pub fields: Array<crate::syntax::FieldPat>,
    pub names: Array<Text>,
    pub f: Text,
}

impl prism_rtl::Job<Pat> for FieldPatFor {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env = &self.env;
        let fields = &self.fields;
        let names = &self.names;
        let f = &self.f;
        fold_job(crate::check::errors::range0(&len(fields)), Pat::PtAny, {
            let fields = fields.clone();
            let names = names.clone();
            let f = f.clone();
            let env = env.clone();
            Rc::new(move |(p0, p1): (Pat, Nat)| {
                let fields = fields.clone();
                let names = names.clone();
                let f = f.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let i = p1;
                    match index(&fields, &i) {
                        Some(fp) => if &crate::check::expr::field_pat_name(&fp, &names, &i) == &f {
                            prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: fp.pattern.clone() }))
                        } else {
                            prism_rtl::Turn::Finished(acc.clone())
                        },
                        None => prism_rtl::Turn::Finished(acc.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Pat, Nat)) -> Rc<dyn prism_rtl::Job<Pat>>>
        }).cycle()
    }
}

/// `Start FieldPatFor, x`: what the function value is when passed to `@Run`.
pub fn start_field_pat_for(env: crate::check::expr::Env, fields: Array<crate::syntax::FieldPat>, names: Array<Text>, f: Text) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(FieldPatFor { env, fields, names, f })
}

/// ```prism
/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
/// ```
pub fn useful(env: &crate::check::expr::Env, st: &crate::check::types::St, rows: &Array<Array<Pat>>, q: &Array<Pat>, tys: &Array<crate::check::types::Ty>) -> bool {
    match index(q, &Nat::from(0u32)) {
        None => &len(rows) == &Nat::from(0u32),
        Some(q1) => {
            let t1 = or(&index(tys, &Nat::from(0u32)), &crate::check::types::Ty::TyErr);
            let rest = drop(tys, &Nat::from(1u32));
            match &q1 {
                Pat::PtCon(c, args) => {
                    let ctor = ctor_named(env, st, &t1, c, &len(args));
                    useful(env, st, &specialize(rows, &ctor), &append(args, &drop(q, &Nat::from(1u32))), &append(&ctor.args, &rest))
                },
                Pat::PtLit(l) => useful(env, st, &specialize_lit(rows, l), &drop(q, &Nat::from(1u32)), &rest),
                Pat::PtFam(f) => match ctors_of(env, st, &t1) {
                    Some(cs) => run_to_end(fold_job(filter(&cs, &(|c: &Ctor| &ctor_family(c) == f)), false, {
                        let env = env.clone();
                        let st = st.clone();
                        let rows = rows.clone();
                        let q = q.clone();
                        let rest = rest.clone();
                        Rc::new(move |(p0, p1): (bool, Ctor)| {
                            let env = env.clone();
                            let st = st.clone();
                            let rows = rows.clone();
                            let q = q.clone();
                            let rest = rest.clone();
                            entered(once_job(move || {
                                let seen = p0;
                                let c = p1;
                                prism_rtl::Turn::Finished(seen || useful(&env, &st, &specialize(&rows, &c), &append(&wilds(&c.arity), &drop(&q, &Nat::from(1u32))), &append(&c.args, &rest)))
                            }))
                        }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                    })),
                    None => useful(env, st, &default_rows(rows), &drop(q, &Nat::from(1u32)), &rest),
                },
                Pat::PtAny => {
                    let heads = head_names(rows);
                    match ctors_of(env, st, &t1) {
                        Some(cs) => if complete(&cs, &heads, rows) {
                            run_to_end(fold_job(cs.clone(), false, {
                                let env = env.clone();
                                let st = st.clone();
                                let rows = rows.clone();
                                let q = q.clone();
                                let rest = rest.clone();
                                Rc::new(move |(p0, p1): (bool, Ctor)| {
                                    let env = env.clone();
                                    let st = st.clone();
                                    let rows = rows.clone();
                                    let q = q.clone();
                                    let rest = rest.clone();
                                    entered(once_job(move || {
                                        let seen = p0;
                                        let c = p1;
                                        prism_rtl::Turn::Finished(seen || useful(&env, &st, &specialize(&rows, &c), &append(&wilds(&c.arity), &drop(&q, &Nat::from(1u32))), &append(&c.args, &rest)))
                                    }))
                                }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }))
                        } else {
                            useful(env, st, &default_rows(rows), &drop(q, &Nat::from(1u32)), &rest)
                        },
                        None => useful(env, st, &default_rows(rows), &drop(q, &Nat::from(1u32)), &rest),
                    }
                },
            }
        },
    }
}

/// The step machine of `Useful`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
/// ```
pub struct Useful {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub rows: Array<Array<Pat>>,
    pub q: Array<Pat>,
    pub tys: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<bool> for Useful {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env = &self.env;
        let st = &self.st;
        let rows = &self.rows;
        let q = &self.q;
        let tys = &self.tys;
        match index(q, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(&len(rows) == &Nat::from(0u32)),
            Some(q1) => {
                let t1 = or(&index(tys, &Nat::from(0u32)), &crate::check::types::Ty::TyErr);
                let rest = drop(tys, &Nat::from(1u32));
                match &q1 {
                    Pat::PtCon(c, args) => {
                        let args = args.clone();
                        let c = c.clone();
                        let env = env.clone();
                        let q = q.clone();
                        let rows = rows.clone();
                        let st = st.clone();
                        call_then(start_ctor_named(env.clone(), st.clone(), t1.clone(), c.clone(), len(&args)), move |ctor_named_7666: Ctor| {
                            let ctor = ctor_named_7666;
                            prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: specialize(&rows, &ctor), q: append(&args, &drop(&q, &Nat::from(1u32))), tys: append(&ctor.args, &rest) }))
                        })
                    },
                    Pat::PtLit(l) => prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: specialize_lit(rows, l), q: drop(q, &Nat::from(1u32)), tys: rest.clone() })),
                    Pat::PtFam(f) => {
                        let env = env.clone();
                        let f = f.clone();
                        let q = q.clone();
                        let rows = rows.clone();
                        let st = st.clone();
                        call_then(start_ctors_of(env.clone(), st.clone(), t1.clone()), move |ctors_of_7920: Option<Array<Ctor>>| match ctors_of_7920 {
                            Some(cs) => fold_job(filter(&cs, &(|c: &Ctor| &ctor_family(c) == &f)), false, {
                                let env = env.clone();
                                let st = st.clone();
                                let rows = rows.clone();
                                let q = q.clone();
                                let rest = rest.clone();
                                Rc::new(move |(p0, p1): (bool, Ctor)| {
                                    let env = env.clone();
                                    let st = st.clone();
                                    let rows = rows.clone();
                                    let q = q.clone();
                                    let rest = rest.clone();
                                    entered(once_job(move || {
                                        let seen = p0;
                                        let c = p1;
                                        prism_rtl::Turn::Finished(seen || useful(&env, &st, &specialize(&rows, &c), &append(&wilds(&c.arity), &drop(&q, &Nat::from(1u32))), &append(&c.args, &rest)))
                                    }))
                                }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }).cycle(),
                            None => prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: default_rows(&rows), q: drop(&q, &Nat::from(1u32)), tys: rest.clone() })),
                        })
                    },
                    Pat::PtAny => {
                        let heads = head_names(rows);
                        let env = env.clone();
                        let q = q.clone();
                        let rows = rows.clone();
                        let st = st.clone();
                        call_then(start_ctors_of(env.clone(), st.clone(), t1.clone()), move |ctors_of_8292: Option<Array<Ctor>>| match ctors_of_8292 {
                            Some(cs) => if complete(&cs, &heads, &rows) {
                                fold_job(cs.clone(), false, {
                                    let env = env.clone();
                                    let st = st.clone();
                                    let rows = rows.clone();
                                    let q = q.clone();
                                    let rest = rest.clone();
                                    Rc::new(move |(p0, p1): (bool, Ctor)| {
                                        let env = env.clone();
                                        let st = st.clone();
                                        let rows = rows.clone();
                                        let q = q.clone();
                                        let rest = rest.clone();
                                        entered(once_job(move || {
                                            let seen = p0;
                                            let c = p1;
                                            prism_rtl::Turn::Finished(seen || useful(&env, &st, &specialize(&rows, &c), &append(&wilds(&c.arity), &drop(&q, &Nat::from(1u32))), &append(&c.args, &rest)))
                                        }))
                                    }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                                }).cycle()
                            } else {
                                prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: default_rows(&rows), q: drop(&q, &Nat::from(1u32)), tys: rest.clone() }))
                            },
                            None => prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: default_rows(&rows), q: drop(&q, &Nat::from(1u32)), tys: rest.clone() })),
                        })
                    },
                }
            },
        }
    }
}

/// `Start Useful, x`: what the function value is when passed to `@Run`.
pub fn start_useful(env: crate::check::expr::Env, st: crate::check::types::St, rows: Array<Array<Pat>>, q: Array<Pat>, tys: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Useful { env, st, rows, q, tys })
}

/// ```prism
/// CtorFamily: fn Ctor -> Text
/// ```
pub fn ctor_family(c: &Ctor) -> Text {
    if crate::syntax::lexer::has_prefix(&c.name, &Text::lit("tag:")) {
        crate::check::env::dotted(&crate::syntax::lexer::pop(&split(&crate::syntax::lexer::drop_prefix(&c.name, &Text::lit("tag:")), &Text::lit("."))))
    } else {
        Text::lit("")
    }
}

/// ```prism
/// Wilds: fn Nat -> [Pat]
/// ```
pub fn wilds(n: &Nat) -> Array<Pat> {
    each(&crate::check::errors::range0(n), &(|_: &Nat| Pat::PtAny))
}

/// ```prism
/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
/// ```
pub fn ctor_named(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::check::types::Ty, c: &Text, arity: &Nat) -> Ctor {
    match ctors_of(env, st, t) {
        Some(cs) => match find_ctor(&cs, c) {
            Some(found) => found.clone(),
            None => Ctor { name: c.clone(), arity: arity.clone(), args: each(&crate::check::errors::range0(arity), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown: c.clone() },
        },
        None => Ctor { name: c.clone(), arity: arity.clone(), args: each(&crate::check::errors::range0(arity), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown: c.clone() },
    }
}

/// The step machine of `CtorNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
/// ```
pub struct CtorNamed {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub c: Text,
    pub arity: Nat,
}

impl prism_rtl::Job<Ctor> for CtorNamed {
    fn cycle(&self) -> prism_rtl::Turn<Ctor> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let c = &self.c;
        let arity = &self.arity;
        let arity = arity.clone();
        let c = c.clone();
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_ctors_of(env.clone(), st.clone(), t.clone()), move |ctors_of_9087: Option<Array<Ctor>>| match ctors_of_9087 {
            Some(cs) => match find_ctor(&cs, &c) {
                Some(found) => prism_rtl::Turn::Finished(found.clone()),
                None => prism_rtl::Turn::Finished(Ctor { name: c.clone(), arity: arity.clone(), args: each(&crate::check::errors::range0(&arity), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown: c.clone() }),
            },
            None => prism_rtl::Turn::Finished(Ctor { name: c.clone(), arity: arity.clone(), args: each(&crate::check::errors::range0(&arity), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown: c.clone() }),
        })
    }
}

/// `Start CtorNamed, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_named(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::check::types::Ty, c: Text, arity: Nat) -> Rc<dyn prism_rtl::Job<Ctor>> {
    Rc::new(CtorNamed { env, st, t, c, arity })
}

/// ```prism
/// ?FindCtor: fn [Ctor], Text -> ?Ctor
/// ```
pub fn find_ctor(cs: &Array<Ctor>, c: &Text) -> Option<Ctor> {
    fold(cs, &None, &(|found_opt: &Option<Ctor>, x: &Ctor| match found_opt {
        Some(f) => Some(f.clone()),
        None => if (&x.name == c) || (&crate::check::types::bare_name(&x.name) == &crate::check::types::bare_name(c)) {
            Some(x.clone())
        } else {
            None
        },
    }))
}

/// ```prism
/// Specialize: fn [ [Pat] ], Ctor -> [ [Pat] ]
/// ```
pub fn specialize(rows: &Array<Array<Pat>>, c: &Ctor) -> Array<Array<Pat>> {
    fold(rows, &Array::new(), &(|acc: &Array<Array<Pat>>, prow: &Array<Pat>| match index(prow, &Nat::from(0u32)) {
        Some(Pat::PtCon(d, args)) => if (&d == &c.name) || (&crate::check::types::bare_name(&d) == &crate::check::types::bare_name(&c.name)) {
            push(acc, &append(&pad(&args, &c.arity), &drop(prow, &Nat::from(1u32))))
        } else {
            acc.clone()
        },
        Some(Pat::PtAny) => push(acc, &append(&wilds(&c.arity), &drop(prow, &Nat::from(1u32)))),
        Some(Pat::PtFam(f)) => if &ctor_family(c) == &f {
            push(acc, &append(&wilds(&c.arity), &drop(prow, &Nat::from(1u32))))
        } else {
            acc.clone()
        },
        _ => acc.clone(),
    }))
}

/// ```prism
/// Pad: fn [Pat], Nat -> [Pat]
/// ```
pub fn pad(args: &Array<Pat>, n: &Nat) -> Array<Pat> {
    if &len(args) >= n {
        take(args, n)
    } else {
        append(args, &wilds(&or(&n.checked_sub(&len(args)), &Nat::from(0u32))))
    }
}

/// ```prism
/// SpecializeLit: fn [ [Pat] ], Text -> [ [Pat] ]
/// ```
pub fn specialize_lit(rows: &Array<Array<Pat>>, l: &Text) -> Array<Array<Pat>> {
    fold(rows, &Array::new(), &(|acc: &Array<Array<Pat>>, prow: &Array<Pat>| match index(prow, &Nat::from(0u32)) {
        Some(Pat::PtLit(m)) => if &m == l { push(acc, &drop(prow, &Nat::from(1u32))) } else { acc.clone() },
        Some(Pat::PtAny) => push(acc, &drop(prow, &Nat::from(1u32))),
        _ => acc.clone(),
    }))
}

/// ```prism
/// DefaultRows: fn [ [Pat] ] -> [ [Pat] ]
/// ```
pub fn default_rows(rows: &Array<Array<Pat>>) -> Array<Array<Pat>> {
    fold(rows, &Array::new(), &(|acc: &Array<Array<Pat>>, prow: &Array<Pat>| match index(prow, &Nat::from(0u32)) {
        Some(Pat::PtAny) => push(acc, &drop(prow, &Nat::from(1u32))),
        _ => acc.clone(),
    }))
}

/// ```prism
/// HeadNames: fn [ [Pat] ] -> [Text]
/// ```
pub fn head_names(rows: &Array<Array<Pat>>) -> Array<Text> {
    fold(rows, &Array::new(), &(|acc: &Array<Text>, prow: &Array<Pat>| match index(prow, &Nat::from(0u32)) {
        Some(Pat::PtCon(c, _)) => crate::check::types::add_text(acc, &c),
        Some(Pat::PtFam(f)) => crate::check::types::add_text(acc, &Text::from(format!("fam:{}", &f))),
        _ => acc.clone(),
    }))
}

/// ```prism
/// Complete: fn [Ctor], [Text], [ [Pat] ] -> Bool
/// ```
pub fn complete(cs: &Array<Ctor>, heads: &Array<Text>, rows: &Array<Array<Pat>>) -> bool {
    (&len(cs) > &Nat::from(0u32)) && fold(cs, &true, &(|ok: &bool, c: &Ctor| *ok && ((crate::check::types::has_text(heads, &c.name) || crate::check::types::has_text(&each(heads, &(|h: &Text| crate::check::types::bare_name(h))), &crate::check::types::bare_name(&c.name))) || crate::check::types::has_text(heads, &Text::from(format!("fam:{}", &ctor_family(c)))))))
}

/// ```prism
/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
/// ```
pub fn witness(env: &crate::check::expr::Env, st: &crate::check::types::St, rows: &Array<Array<Pat>>, tys: &Array<crate::check::types::Ty>) -> Option<Array<Text>> {
    match index(tys, &Nat::from(0u32)) {
        None => if &len(rows) == &Nat::from(0u32) { Some(Array::new()) } else { None },
        Some(t1) => {
            let rest = drop(tys, &Nat::from(1u32));
            let heads = head_names(rows);
            match ctors_of(env, st, &t1) {
                Some(cs) => if complete(&cs, &heads, rows) {
                    run_to_end(fold_job(cs.clone(), None, {
                        let env = env.clone();
                        let st = st.clone();
                        let rows = rows.clone();
                        let rest = rest.clone();
                        Rc::new(move |(p0, p1): (Option<Array<Text>>, Ctor)| {
                            let env = env.clone();
                            let st = st.clone();
                            let rows = rows.clone();
                            let rest = rest.clone();
                            entered(once_job(move || {
                                let found_opt = p0;
                                let c = p1;
                                match &found_opt {
                                    Some(f) => prism_rtl::Turn::Finished(Some(f.clone())),
                                    None => call_then(start_witness(env.clone(), st.clone(), specialize(&rows, &c), append(&c.args, &rest)), move |witness_11663: Option<Array<Text>>| match witness_11663 {
                                        Some(w) => prism_rtl::Turn::Finished(Some(append(&Array::from(vec![show_witness(&c, &take(&w, &c.arity))]), &drop(&w, &c.arity)))),
                                        None => prism_rtl::Turn::Finished(None),
                                    }),
                                }
                            }))
                        }) as Rc<dyn Fn((Option<Array<Text>>, Ctor)) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>>>
                    }))
                } else {
                    match witness(env, st, &default_rows(rows), &rest) {
                        Some(w) => {
                            let missing = filter(&cs, &(|c: &Ctor| !(crate::check::types::has_text(&heads, &c.name) || crate::check::types::has_text(&heads, &Text::from(format!("fam:{}", &ctor_family(c)))))));
                            let shown = match index(&missing, &Nat::from(0u32)) {
                                Some(c) => c.shown.clone(),
                                None => Text::lit("_"),
                            };
                            Some(append(&Array::from(vec![shown.clone()]), &w))
                        },
                        None => None,
                    }
                },
                None => match witness(env, st, &default_rows(rows), &rest) {
                    Some(w) => Some(append(&Array::from(vec![Text::lit("_")]), &w)),
                    None => None,
                },
            }
        },
    }
}

/// The step machine of `Witness`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
/// ```
pub struct Witness {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub rows: Array<Array<Pat>>,
    pub tys: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<Option<Array<Text>>> for Witness {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<Text>>> {
        let env = &self.env;
        let st = &self.st;
        let rows = &self.rows;
        let tys = &self.tys;
        match index(tys, &Nat::from(0u32)) {
            None => if &len(rows) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(Some(Array::new()))
            } else {
                prism_rtl::Turn::Finished(None)
            },
            Some(t1) => {
                let rest = drop(tys, &Nat::from(1u32));
                let heads = head_names(rows);
                let env = env.clone();
                let rows = rows.clone();
                let st = st.clone();
                call_then(start_ctors_of(env.clone(), st.clone(), t1.clone()), move |ctors_of_11449: Option<Array<Ctor>>| match ctors_of_11449 {
                    Some(cs) => if complete(&cs, &heads, &rows) {
                        fold_job(cs.clone(), None, {
                            let env = env.clone();
                            let st = st.clone();
                            let rows = rows.clone();
                            let rest = rest.clone();
                            Rc::new(move |(p0, p1): (Option<Array<Text>>, Ctor)| {
                                let env = env.clone();
                                let st = st.clone();
                                let rows = rows.clone();
                                let rest = rest.clone();
                                entered(once_job(move || {
                                    let found_opt = p0;
                                    let c = p1;
                                    match &found_opt {
                                        Some(f) => prism_rtl::Turn::Finished(Some(f.clone())),
                                        None => call_then(start_witness(env.clone(), st.clone(), specialize(&rows, &c), append(&c.args, &rest)), move |witness_11663: Option<Array<Text>>| match witness_11663 {
                                            Some(w) => prism_rtl::Turn::Finished(Some(append(&Array::from(vec![show_witness(&c, &take(&w, &c.arity))]), &drop(&w, &c.arity)))),
                                            None => prism_rtl::Turn::Finished(None),
                                        }),
                                    }
                                }))
                            }) as Rc<dyn Fn((Option<Array<Text>>, Ctor)) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>>>
                        }).cycle()
                    } else {
                        call_then(start_witness(env.clone(), st.clone(), default_rows(&rows), rest.clone()), move |witness_11893: Option<Array<Text>>| match witness_11893 {
                            Some(w) => {
                                let missing = filter(&cs, &(|c: &Ctor| !(crate::check::types::has_text(&heads, &c.name) || crate::check::types::has_text(&heads, &Text::from(format!("fam:{}", &ctor_family(c)))))));
                                let shown = match index(&missing, &Nat::from(0u32)) {
                                    Some(c) => c.shown.clone(),
                                    None => Text::lit("_"),
                                };
                                prism_rtl::Turn::Finished(Some(append(&Array::from(vec![shown.clone()]), &w)))
                            },
                            None => prism_rtl::Turn::Finished(None),
                        })
                    },
                    None => call_then(start_witness(env.clone(), st.clone(), default_rows(&rows), rest.clone()), move |witness_12319: Option<Array<Text>>| match witness_12319 {
                        Some(w) => prism_rtl::Turn::Finished(Some(append(&Array::from(vec![Text::lit("_")]), &w))),
                        None => prism_rtl::Turn::Finished(None),
                    }),
                })
            },
        }
    }
}

/// `Start Witness, x`: what the function value is when passed to `@Run`.
pub fn start_witness(env: crate::check::expr::Env, st: crate::check::types::St, rows: Array<Array<Pat>>, tys: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>> {
    Rc::new(Witness { env, st, rows, tys })
}

/// ```prism
/// ShowWitness: fn Ctor, [Text] -> Text
/// ```
pub fn show_witness(c: &Ctor, args: &Array<Text>) -> Text {
    if &c.name == &Text::lit("?") {
        Text::from(format!("? {}", &or(&index(args, &Nat::from(0u32)), &Text::lit("_"))))
    } else {
        if &c.name == &Text::lit("~") {
            Text::from(format!("~ {}", &or(&index(args, &Nat::from(0u32)), &Text::lit("_"))))
        } else {
            if &c.name == &Text::lit("tuple") {
                Text::from(format!("(({}))", &crate::syntax::lexer::join(args, &Text::lit(", "))))
            } else {
                if (&len(args) == &Nat::from(0u32)) || fold(args, &true, &(|ok: &bool, a: &Text| *ok && (a == &Text::lit("_")))) {
                    c.shown.clone()
                } else {
                    Text::from(format!("{} {}", &crate::check::types::bare_name(&c.name), &crate::syntax::lexer::join(args, &Text::lit(", "))))
                }
            }
        }
    }
}

/// ```prism
/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
/// ```
pub fn match_coverage(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::check::types::Ty, arms: &Array<crate::syntax::Arm>, span: &crate::syntax::Range) -> crate::check::types::St {
    let has_otherwise = fold(arms, &false, &(|seen: &bool, a: &crate::syntax::Arm| *seen || (&a.pattern == &None)));
    let tys = Array::from(vec![t.clone()]);
    let (rows, st2) = run_to_end(fold_job(arms.clone(), (Array::new(), st.clone()), {
        let env = env.clone();
        let tys = tys.clone();
        let t = t.clone();
        Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)| {
            let env = env.clone();
            let tys = tys.clone();
            let t = t.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let arm = p1;
                {
                    let q = match &arm.pattern {
                        Some(p_) => Array::from(vec![to_pat(&env, p_)]),
                        None => Array::from(vec![Pat::PtAny]),
                    };
                    call_then(start_useful(env.clone(), s.clone(), acc.clone(), q.clone(), tys.clone()), move |useful_13405: bool| {
                        let reachable = useful_13405;
                        call_then(start_owns_row(env.clone(), s.clone(), t.clone()), move |owns_row_13454: bool| {
                            let owns_all = owns_row_13454;
                            let s2 = if reachable {
                                s.clone()
                            } else {
                                if (&arm.pattern == &None) && !owns_all {
                                    s.clone()
                                } else {
                                    crate::check::types::err_fix(&s, &Text::lit("unreachable"), &arm_span(&arm), &Text::lit("this arm is never reached"), &Text::lit("remove it, or put it above the arm that covers it"))
                                }
                            };
                            let acc2 = if &arm.guard == &None { push(&acc, &q) } else { acc.clone() };
                            prism_rtl::Turn::Finished((acc2.clone(), s2.clone()))
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
    }));
    if has_otherwise {
        st2.clone()
    } else {
        if is_open_row(env, &st2, t) {
            crate::check::types::err_fix(&st2, &Text::lit("row-not-closed"), span, &Text::from(format!("a match over `{}` needs `otherwise:`", &crate::check::types::show_ty(&st2, t))), &Text::lit("add an `otherwise:` arm: the row's variable may hold tags this match cannot name"))
        } else {
            match witness(env, &st2, &rows, &tys) {
                Some(w) => crate::check::types::err_fix(&st2, &Text::lit("not-exhaustive"), span, &Text::from(format!("this match misses `{}`", &crate::syntax::lexer::join(&w, &Text::lit(", ")))), &Text::lit("add an arm for it, or `otherwise:`")),
                None => st2.clone(),
            }
        }
    }
}

/// The step machine of `MatchCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
/// ```
pub struct MatchCoverage {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub arms: Array<crate::syntax::Arm>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for MatchCoverage {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let arms = &self.arms;
        let span = &self.span;
        let has_otherwise = fold(arms, &false, &(|seen: &bool, a: &crate::syntax::Arm| *seen || (&a.pattern == &None)));
        let tys = Array::from(vec![t.clone()]);
        let arms = arms.clone();
        let env = env.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_value(fold_job(arms.clone(), (Array::new(), st.clone()), {
            let env = env.clone();
            let tys = tys.clone();
            let t = t.clone();
            Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)| {
                let env = env.clone();
                let tys = tys.clone();
                let t = t.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let arm = p1;
                    {
                        let q = match &arm.pattern {
                            Some(p_) => Array::from(vec![to_pat(&env, p_)]),
                            None => Array::from(vec![Pat::PtAny]),
                        };
                        call_then(start_useful(env.clone(), s.clone(), acc.clone(), q.clone(), tys.clone()), move |useful_13405: bool| {
                            let reachable = useful_13405;
                            call_then(start_owns_row(env.clone(), s.clone(), t.clone()), move |owns_row_13454: bool| {
                                let owns_all = owns_row_13454;
                                let s2 = if reachable {
                                    s.clone()
                                } else {
                                    if (&arm.pattern == &None) && !owns_all {
                                        s.clone()
                                    } else {
                                        crate::check::types::err_fix(&s, &Text::lit("unreachable"), &arm_span(&arm), &Text::lit("this arm is never reached"), &Text::lit("remove it, or put it above the arm that covers it"))
                                    }
                                };
                                let acc2 = if &arm.guard == &None { push(&acc, &q) } else { acc.clone() };
                                prism_rtl::Turn::Finished((acc2.clone(), s2.clone()))
                            })
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
        }), move |fold_13238: (Array<Array<Pat>>, crate::check::types::St)| {
            let (rows, st2) = fold_13238;
            if has_otherwise {
                prism_rtl::Turn::Finished(st2.clone())
            } else {
                call_then(start_is_open_row(env.clone(), st2.clone(), t.clone()), move |is_open_row_13802: bool| if is_open_row_13802 {
                    call_then(crate::check::types::start_show_ty(st2.clone(), t.clone()), move |show_ty_13877: Text| prism_rtl::Turn::Finished(crate::check::types::err_fix(&st2, &Text::lit("row-not-closed"), &span, &Text::from(format!("a match over `{}` needs `otherwise:`", &show_ty_13877)), &Text::lit("add an `otherwise:` arm: the row's variable may hold tags this match cannot name"))))
                } else {
                    call_then(start_witness(env.clone(), st2.clone(), rows.clone(), tys.clone()), move |witness_14013: Option<Array<Text>>| match witness_14013 {
                        Some(w) => prism_rtl::Turn::Finished(crate::check::types::err_fix(&st2, &Text::lit("not-exhaustive"), &span, &Text::from(format!("this match misses `{}`", &crate::syntax::lexer::join(&w, &Text::lit(", ")))), &Text::lit("add an arm for it, or `otherwise:`"))),
                        None => prism_rtl::Turn::Finished(st2.clone()),
                    })
                })
            }
        })
    }
}

/// `Start MatchCoverage, x`: what the function value is when passed to `@Run`.
pub fn start_match_coverage(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::check::types::Ty, arms: Array<crate::syntax::Arm>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(MatchCoverage { env, st, t, arms, span })
}

/// ```prism
/// ArmSpan: fn Arm -> Range
/// ```
pub fn arm_span(a: &crate::syntax::Arm) -> crate::syntax::Range {
    match &a.pattern {
        Some(p_) => p_.span.clone(),
        None => a.span.clone(),
    }
}

/// ```prism
/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub fn is_open_row(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::check::types::Ty) -> bool {
    match crate::check::types::walk(st, t) {
        crate::check::types::Ty::TyElem(rw, _) => &crate::check::types::walk_row(st, &rw).tail != &crate::check::types::Tail::TlClosed,
        crate::check::types::Ty::TyElemAny(rw) => &crate::check::types::walk_row(st, &rw).tail != &crate::check::types::Tail::TlClosed,
        crate::check::types::Ty::TyCon(n, m14435_2_1) if ((&m14435_2_1).len() == 0) => match get(&env.g.types, &n) {
            Some(ti) => (&ti.body == &crate::check::env::TyBody::BRowKind) && !is_root_module(env),
            None => ((&n == &Text::lit("Fault")) || (&n == &Text::lit("Prelude.Fault"))) && !is_root_module(env),
        },
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `IsOpenRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub struct IsOpenRow {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for IsOpenRow {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::start_walk(st.clone(), t.clone()), move |walk_14441: crate::check::types::Ty| match walk_14441 {
            crate::check::types::Ty::TyElem(rw, _) => call_then(crate::check::types::start_walk_row(st.clone(), rw.clone()), move |walk_row_14477: crate::check::types::Rw| prism_rtl::Turn::Finished(&walk_row_14477.tail != &crate::check::types::Tail::TlClosed)),
            crate::check::types::Ty::TyElemAny(rw) => call_then(crate::check::types::start_walk_row(st.clone(), rw.clone()), move |walk_row_14529: crate::check::types::Rw| prism_rtl::Turn::Finished(&walk_row_14529.tail != &crate::check::types::Tail::TlClosed)),
            crate::check::types::Ty::TyCon(n, m14435_2_1) if ((&m14435_2_1).len() == 0) => match get(&env.g.types, &n) {
                Some(ti) => prism_rtl::Turn::Finished((&ti.body == &crate::check::env::TyBody::BRowKind) && !is_root_module(&env)),
                None => prism_rtl::Turn::Finished(((&n == &Text::lit("Fault")) || (&n == &Text::lit("Prelude.Fault"))) && !is_root_module(&env)),
            },
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start IsOpenRow, x`: what the function value is when passed to `@Run`.
pub fn start_is_open_row(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsOpenRow { env, st, t })
}

/// ```prism
/// OwnsRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub fn owns_row(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::check::types::Ty) -> bool {
    match crate::check::types::walk(st, t) {
        crate::check::types::Ty::TyElem(rw, _) => fold(&crate::check::types::walk_row(st, &rw).fams, &true, &(|ok: &bool, f: &Text| *ok && (&or(&get(&env.g.fam_owner, f), &Text::lit("")) == &env.home))),
        crate::check::types::Ty::TyCon(n, m14904_1_1) if ((&m14904_1_1).len() == 0) => match get(&env.g.types, &n) {
            Some(ti) => &ti.body != &crate::check::env::TyBody::BRowKind,
            None => !((&n == &Text::lit("Fault")) || (&n == &Text::lit("Prelude.Fault"))),
        },
        _ => true,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `OwnsRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OwnsRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub struct OwnsRow {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for OwnsRow {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::start_walk(st.clone(), t.clone()), move |walk_14910: crate::check::types::Ty| match walk_14910 {
            crate::check::types::Ty::TyElem(rw, _) => call_then(crate::check::types::start_walk_row(st.clone(), rw.clone()), move |walk_row_14951: crate::check::types::Rw| prism_rtl::Turn::Finished(fold(&walk_row_14951.fams, &true, &(|ok: &bool, f: &Text| *ok && (&or(&get(&env.g.fam_owner, f), &Text::lit("")) == &env.home))))),
            crate::check::types::Ty::TyCon(n, m14904_1_1) if ((&m14904_1_1).len() == 0) => match get(&env.g.types, &n) {
                Some(ti) => prism_rtl::Turn::Finished(&ti.body != &crate::check::env::TyBody::BRowKind),
                None => prism_rtl::Turn::Finished(!((&n == &Text::lit("Fault")) || (&n == &Text::lit("Prelude.Fault")))),
            },
            _ => prism_rtl::Turn::Finished(true),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start OwnsRow, x`: what the function value is when passed to `@Run`.
pub fn start_owns_row(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(OwnsRow { env, st, t })
}

/// ```prism
/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
/// ```
pub fn clause_coverage(env: &crate::check::expr::Env, st: &crate::check::types::St, clauses: &Array<crate::syntax::FnClause>, params: &Array<crate::check::types::Ty>, span: &crate::syntax::Range) -> crate::check::types::St {
    let (rows, st2) = run_to_end(fold_job(clauses.clone(), (Array::new(), st.clone()), {
        let env = env.clone();
        let params = params.clone();
        Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::FnClause)| {
            let env = env.clone();
            let params = params.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let c = p1;
                call_value(each_job(c.params.clone(), {
                    let env = env.clone();
                    Rc::new(move |p0: crate::syntax::Pattern_| {
                        let env = env.clone();
                        entered(once_job(move || {
                            let p_ = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: p_.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_15447: Array<Pat>| {
                    let q = each_15447;
                    let reachable = (&len(&q) != &len(&params)) || useful(&env, &s, &acc, &q, &params);
                    let s2 = if reachable {
                        s.clone()
                    } else {
                        crate::check::types::err_fix(&s, &Text::lit("unreachable"), &c.span, &Text::lit("this clause is never reached"), &Text::lit("remove it, or put it above the clause that covers it"))
                    };
                    prism_rtl::Turn::Finished((push(&acc, &q), s2.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
    }));
    if &len(params) == &Nat::from(0u32) {
        st2.clone()
    } else {
        match witness(env, &st2, &rows, params) {
            Some(w) => crate::check::types::err_fix(&st2, &Text::lit("not-exhaustive"), span, &Text::from(format!("these clauses miss `{}`", &crate::syntax::lexer::join(&w, &Text::lit(", ")))), &Text::lit("add a clause for it")),
            None => st2.clone(),
        }
    }
}

/// The step machine of `ClauseCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
/// ```
pub struct ClauseCoverage {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub clauses: Array<crate::syntax::FnClause>,
    pub params: Array<crate::check::types::Ty>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for ClauseCoverage {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let clauses = &self.clauses;
        let params = &self.params;
        let span = &self.span;
        let clauses = clauses.clone();
        let env = env.clone();
        let params = params.clone();
        let span = span.clone();
        let st = st.clone();
        call_value(fold_job(clauses.clone(), (Array::new(), st.clone()), {
            let env = env.clone();
            let params = params.clone();
            Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::FnClause)| {
                let env = env.clone();
                let params = params.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let c = p1;
                    call_value(each_job(c.params.clone(), {
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Pattern_| {
                            let env = env.clone();
                            entered(once_job(move || {
                                let p_ = p0;
                                prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: p_.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                    }), move |each_15447: Array<Pat>| {
                        let q = each_15447;
                        let reachable = (&len(&q) != &len(&params)) || useful(&env, &s, &acc, &q, &params);
                        let s2 = if reachable {
                            s.clone()
                        } else {
                            crate::check::types::err_fix(&s, &Text::lit("unreachable"), &c.span, &Text::lit("this clause is never reached"), &Text::lit("remove it, or put it above the clause that covers it"))
                        };
                        prism_rtl::Turn::Finished((push(&acc, &q), s2.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
        }), move |fold_15386: (Array<Array<Pat>>, crate::check::types::St)| {
            let (rows, st2) = fold_15386;
            if &len(&params) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(st2.clone())
            } else {
                call_then(start_witness(env.clone(), st2.clone(), rows.clone(), params.clone()), move |witness_15796: Option<Array<Text>>| match witness_15796 {
                    Some(w) => prism_rtl::Turn::Finished(crate::check::types::err_fix(&st2, &Text::lit("not-exhaustive"), &span, &Text::from(format!("these clauses miss `{}`", &crate::syntax::lexer::join(&w, &Text::lit(", ")))), &Text::lit("add a clause for it"))),
                    None => prism_rtl::Turn::Finished(st2.clone()),
                })
            }
        })
    }
}

/// `Start ClauseCoverage, x`: what the function value is when passed to `@Run`.
pub fn start_clause_coverage(env: crate::check::expr::Env, st: crate::check::types::St, clauses: Array<crate::syntax::FnClause>, params: Array<crate::check::types::Ty>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ClauseCoverage { env, st, clauses, params, span })
}

/// ```prism
/// DischargeIncls: unbounded fn G, St, Nat -> St
/// ```
pub fn discharge_incls(g: &crate::check::env::G, st: &crate::check::types::St, from: &Nat) -> crate::check::types::St {
    let batch = drop(&st.incls, from);
    run_to_end(fold_job(batch.clone(), st.clone(), {
        let g = g.clone();
        let batch = batch.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Incl)| {
            let g = g.clone();
            let batch = batch.clone();
            entered(once_job(move || {
                let s = p0;
                let inc = p1;
                call_then(start_through(s.clone(), inc.clone(), batch.clone()), move |through_16637: crate::check::types::Incl| prism_rtl::Turn::More(Rc::new(DischargeOne { g: g.clone(), st: s.clone(), inc: through_16637 })))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `DischargeIncls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DischargeIncls: unbounded fn G, St, Nat -> St
/// ```
pub struct DischargeIncls {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub from: Nat,
}

impl prism_rtl::Job<crate::check::types::St> for DischargeIncls {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let from = &self.from;
        let batch = drop(&st.incls, from);
        fold_job(batch.clone(), st.clone(), {
            let g = g.clone();
            let batch = batch.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Incl)| {
                let g = g.clone();
                let batch = batch.clone();
                entered(once_job(move || {
                    let s = p0;
                    let inc = p1;
                    call_then(start_through(s.clone(), inc.clone(), batch.clone()), move |through_16637: crate::check::types::Incl| prism_rtl::Turn::More(Rc::new(DischargeOne { g: g.clone(), st: s.clone(), inc: through_16637 })))
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start DischargeIncls, x`: what the function value is when passed to `@Run`.
pub fn start_discharge_incls(g: crate::check::env::G, st: crate::check::types::St, from: Nat) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DischargeIncls { g, st, from })
}

/// ```prism
/// Through: unbounded fn St, Incl, [Incl] -> Incl
/// ```
pub fn through(st: &crate::check::types::St, inc: &crate::check::types::Incl, batch: &Array<crate::check::types::Incl>) -> crate::check::types::Incl {
    let sup = crate::check::types::walk_row(st, &inc.sup);
    match &sup.tail {
        crate::check::types::Tail::TlFlex(n) => if &len(&sup.fams) > &Nat::from(0u32) {
            inc.clone()
        } else {
            run_to_end(fold_job(batch.clone(), inc.clone(), {
                let st = st.clone();
                let n = n.clone();
                let inc = inc.clone();
                Rc::new(move |(p0, p1): (crate::check::types::Incl, crate::check::types::Incl)| {
                    let st = st.clone();
                    let n = n.clone();
                    let inc = inc.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let other = p1;
                        call_then(crate::check::types::start_walk_row(st.clone(), other.sub.clone()), move |walk_row_17151: crate::check::types::Rw| {
                            let sub = walk_row_17151;
                            if ((&len(&sub.fams) == &Nat::from(0u32)) && (&sub.tail == &crate::check::types::Tail::TlFlex(n.clone()))) && (&other != &inc) {
                                prism_rtl::Turn::Finished({
                                    let mut this: crate::check::types::Incl = acc.clone();
                                    this.sup = other.sup.clone();
                                    this
                                })
                            } else {
                                prism_rtl::Turn::Finished(acc.clone())
                            }
                        })
                    }))
                }) as Rc<dyn Fn((crate::check::types::Incl, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::Incl>>>
            }))
        },
        _ => inc.clone(),
    }
}

/// The step machine of `Through`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Through: unbounded fn St, Incl, [Incl] -> Incl
/// ```
pub struct Through {
    pub st: crate::check::types::St,
    pub inc: crate::check::types::Incl,
    pub batch: Array<crate::check::types::Incl>,
}

impl prism_rtl::Job<crate::check::types::Incl> for Through {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Incl> {
        let st = &self.st;
        let inc = &self.inc;
        let batch = &self.batch;
        let batch = batch.clone();
        let inc = inc.clone();
        let st = st.clone();
        call_then(crate::check::types::start_walk_row(st.clone(), inc.sup.clone()), move |walk_row_16979: crate::check::types::Rw| {
            let sup = walk_row_16979;
            match &sup.tail {
                crate::check::types::Tail::TlFlex(n) => if &len(&sup.fams) > &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(inc.clone())
                } else {
                    fold_job(batch.clone(), inc.clone(), {
                        let st = st.clone();
                        let n = n.clone();
                        let inc = inc.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::Incl, crate::check::types::Incl)| {
                            let st = st.clone();
                            let n = n.clone();
                            let inc = inc.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let other = p1;
                                call_then(crate::check::types::start_walk_row(st.clone(), other.sub.clone()), move |walk_row_17151: crate::check::types::Rw| {
                                    let sub = walk_row_17151;
                                    if ((&len(&sub.fams) == &Nat::from(0u32)) && (&sub.tail == &crate::check::types::Tail::TlFlex(n.clone()))) && (&other != &inc) {
                                        prism_rtl::Turn::Finished({
                                            let mut this: crate::check::types::Incl = acc.clone();
                                            this.sup = other.sup.clone();
                                            this
                                        })
                                    } else {
                                        prism_rtl::Turn::Finished(acc.clone())
                                    }
                                })
                            }))
                        }) as Rc<dyn Fn((crate::check::types::Incl, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::Incl>>>
                    }).cycle()
                },
                _ => prism_rtl::Turn::Finished(inc.clone()),
            }
        })
    }
}

/// `Start Through, x`: what the function value is when passed to `@Run`.
pub fn start_through(st: crate::check::types::St, inc: crate::check::types::Incl, batch: Array<crate::check::types::Incl>) -> Rc<dyn prism_rtl::Job<crate::check::types::Incl>> {
    Rc::new(Through { st, inc, batch })
}

/// ```prism
/// DischargeOne: unbounded fn G, St, Incl -> St
/// ```
pub fn discharge_one(g: &crate::check::env::G, st: &crate::check::types::St, inc: &crate::check::types::Incl) -> crate::check::types::St {
    let sub = crate::check::types::walk_row(st, &inc.sub);
    let sup = crate::check::types::walk_row(st, &inc.sup);
    let st1 = match &sub.tail {
        crate::check::types::Tail::TlFlex(n) => close_tail(st, n),
        _ => st.clone(),
    };
    let sub2 = crate::check::types::walk_row(&st1, &inc.sub);
    let left = filter(&sub2.fams, &(|f: &Text| !crate::check::types::has_text(&sup.fams, f) && (&len(&tags_left(g, f, &sub2.minus)) > &Nat::from(0u32))));
    let tail_bad = match (sub2.tail.clone(), sup.tail.clone()) {
        (crate::check::types::Tail::TlRigid(a), crate::check::types::Tail::TlRigid(b)) => &a != &b,
        (crate::check::types::Tail::TlRigid(_), _) => true,
        _ => false,
    };
    if (&len(&left) == &Nat::from(0u32)) && !tail_bad {
        st1.clone()
    } else {
        {
            let s0 = {
                let mut this: crate::check::types::St = st1.clone();
                this.file = inc.file.clone();
                this
            };
            let tags = fold(&left, &Array::new(), &(|acc: &Array<Text>, f: &Text| append(acc, &tags_left(g, f, &sub2.minus))));
            let s1 = if inc.forward {
                crate::check::types::err_fix(&s0, &Text::lit("forwarding"), &inc.span, &Text::from(format!("forwarding {} from a scope that emits {}", &crate::syntax::lexer::join(&tags, &Text::lit(", ")), &crate::check::types::show_row(&sup))), &Text::from(format!("answer {} above this arm, for example `{}(..): @ never`", &(if &len(&tags) == &Nat::from(1u32) { Text::lit("it") } else { Text::lit("them") }), &or(&index(&tags, &Nat::from(0u32)), &Text::lit("")))))
            } else {
                crate::check::types::err_fix(&s0, &Text::lit("row-outside"), &inc.span, &Text::from(format!("a child that emits `{}` in a scope that emits `{}`", &crate::check::types::show_row(&sub2), &crate::check::types::show_row(&sup))), &Text::lit("widen the scope's `emit` row, or host the child with `@HostDocument`"))
            };
            {
                let mut this: crate::check::types::St = s1.clone();
                this.file = st1.file.clone();
                this
            }
        }
    }
}

/// The step machine of `DischargeOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DischargeOne: unbounded fn G, St, Incl -> St
/// ```
pub struct DischargeOne {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub inc: crate::check::types::Incl,
}

impl prism_rtl::Job<crate::check::types::St> for DischargeOne {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let inc = &self.inc;
        let g = g.clone();
        let inc = inc.clone();
        let st = st.clone();
        call_then(crate::check::types::start_walk_row(st.clone(), inc.sub.clone()), move |walk_row_17470: crate::check::types::Rw| {
            let sub = walk_row_17470;
            call_then(crate::check::types::start_walk_row(st.clone(), inc.sup.clone()), move |walk_row_17504: crate::check::types::Rw| {
                let sup = walk_row_17504;
                let st1 = match &sub.tail {
                    crate::check::types::Tail::TlFlex(n) => close_tail(&st, n),
                    _ => st.clone(),
                };
                call_then(crate::check::types::start_walk_row(st1.clone(), inc.sub.clone()), move |walk_row_17625: crate::check::types::Rw| {
                    let sub2 = walk_row_17625;
                    let left = filter(&sub2.fams, &(|f: &Text| !crate::check::types::has_text(&sup.fams, f) && (&len(&tags_left(&g, f, &sub2.minus)) > &Nat::from(0u32))));
                    let tail_bad = match (sub2.tail.clone(), sup.tail.clone()) {
                        (crate::check::types::Tail::TlRigid(a), crate::check::types::Tail::TlRigid(b)) => &a != &b,
                        (crate::check::types::Tail::TlRigid(_), _) => true,
                        _ => false,
                    };
                    if (&len(&left) == &Nat::from(0u32)) && !tail_bad {
                        prism_rtl::Turn::Finished(st1.clone())
                    } else {
                        {
                            let s0 = {
                                let mut this: crate::check::types::St = st1.clone();
                                this.file = inc.file.clone();
                                this
                            };
                            let tags = fold(&left, &Array::new(), &(|acc: &Array<Text>, f: &Text| append(acc, &tags_left(&g, f, &sub2.minus))));
                            let s1 = if inc.forward {
                                crate::check::types::err_fix(&s0, &Text::lit("forwarding"), &inc.span, &Text::from(format!("forwarding {} from a scope that emits {}", &crate::syntax::lexer::join(&tags, &Text::lit(", ")), &crate::check::types::show_row(&sup))), &Text::from(format!("answer {} above this arm, for example `{}(..): @ never`", &(if &len(&tags) == &Nat::from(1u32) { Text::lit("it") } else { Text::lit("them") }), &or(&index(&tags, &Nat::from(0u32)), &Text::lit("")))))
                            } else {
                                crate::check::types::err_fix(&s0, &Text::lit("row-outside"), &inc.span, &Text::from(format!("a child that emits `{}` in a scope that emits `{}`", &crate::check::types::show_row(&sub2), &crate::check::types::show_row(&sup))), &Text::lit("widen the scope's `emit` row, or host the child with `@HostDocument`"))
                            };
                            prism_rtl::Turn::Finished({
                                let mut this: crate::check::types::St = s1.clone();
                                this.file = st1.file.clone();
                                this
                            })
                        }
                    }
                })
            })
        })
    }
}

/// `Start DischargeOne, x`: what the function value is when passed to `@Run`.
pub fn start_discharge_one(g: crate::check::env::G, st: crate::check::types::St, inc: crate::check::types::Incl) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DischargeOne { g, st, inc })
}

/// ```prism
/// TagsLeft: fn G, Text, [Text] -> [Text]
/// ```
pub fn tags_left(g: &crate::check::env::G, fam: &Text, minus: &Array<Text>) -> Array<Text> {
    filter(&or(&get(&g.families, fam), &Array::new()), &(|t: &Text| !crate::check::types::has_text(minus, t) && is_element_tag(g, t)))
}

/// ```prism
/// IsElementTag: fn G, Text -> Bool
/// ```
pub fn is_element_tag(g: &crate::check::env::G, t: &Text) -> bool {
    match get(&g.tags, t) {
        Some(tg) => &tg.kind == &Text::lit("Element"),
        None => false,
    }
}

/// ```prism
/// CloseTail: fn St, Nat -> St
/// ```
pub fn close_tail(st: &crate::check::types::St, n: &Nat) -> crate::check::types::St {
    let mut this: crate::check::types::St = st.clone();
    this.rows = insert(&this.rows, n, &crate::check::types::empty_row());
    this
}

/// ```prism
/// IsDelayedWidget: fn Text -> Bool
/// ```
pub fn is_delayed_widget(n: &Text) -> bool {
    crate::check::types::has_text(&Array::from(vec![Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")]), n)
}

/// ```prism
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
/// ```
pub fn block_prompt_cycles(env: &crate::check::expr::Env, st: &crate::check::types::St, b: &crate::syntax::Block) -> crate::check::types::St {
    let defs = run_to_end(fold_job(b.stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| entered(once_job(move || {
        let acc = p0;
        let s = p1;
        call_then(start_stmt_defs(s.clone()), move |stmt_defs_20203: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &stmt_defs_20203)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let cx_ = PCx { g: env.g.clone(), home: env.home.clone(), lams: let_lambdas(&b.stmts), base: prompt_base(env, &b.stmts) };
    let edges_ = run_to_end(fold_job(b.stmts.clone(), Array::new(), {
        let env = env.clone();
        let st = st.clone();
        let cx_ = cx_.clone();
        let defs = defs.clone();
        Rc::new(move |(p0, p1): (Array<(Text, Text)>, crate::syntax::Stmt)| {
            let env = env.clone();
            let st = st.clone();
            let cx_ = cx_.clone();
            let defs = defs.clone();
            entered(once_job(move || {
                let acc = p0;
                let s = p1;
                call_then(start_prompt_edges(env.clone(), st.clone(), cx_.clone(), s.clone(), defs.clone()), move |prompt_edges_20374: Array<(Text, Text)>| prism_rtl::Turn::Finished(append(&acc, &prompt_edges_20374)))
            }))
        }) as Rc<dyn Fn((Array<(Text, Text)>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>>>
    }));
    let cyc = find_cycle(&defs, &edges_);
    if &len(&cyc) == &Nat::from(0u32) {
        st.clone()
    } else {
        {
            let span = run_to_end(fold_job(b.stmts.clone(), b.span.clone(), {
                let cyc = cyc.clone();
                Rc::new(move |(p0, p1): (crate::syntax::Range, crate::syntax::Stmt)| {
                    let cyc = cyc.clone();
                    entered(once_job(move || {
                        let sp = p0;
                        let s = p1;
                        call_then(start_stmt_defs(s.clone()), move |stmt_defs_20542: Array<Text>| if crate::check::types::has_text(&stmt_defs_20542, &or(&index(&cyc, &Nat::from(0u32)), &Text::lit(""))) {
                            prism_rtl::Turn::Finished(s.span.clone())
                        } else {
                            prism_rtl::Turn::Finished(sp.clone())
                        })
                    }))
                }) as Rc<dyn Fn((crate::syntax::Range, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::syntax::Range>>>
            }));
            crate::check::types::err_fix(st, &Text::lit("prompt-cycle"), &span, &Text::from(format!("a prompt cycle: {}", &crate::syntax::lexer::join(&each(&cyc, &(|n: &Text| Text::from(format!("`{}`", n)))), &Text::lit(", ")))), &Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened"))
        }
    }
}

/// The step machine of `BlockPromptCycles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
/// ```
pub struct BlockPromptCycles {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<crate::check::types::St> for BlockPromptCycles {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let b = b.clone();
        let env = env.clone();
        let st = st.clone();
        call_value(fold_job(b.stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| entered(once_job(move || {
            let acc = p0;
            let s = p1;
            call_then(start_stmt_defs(s.clone()), move |stmt_defs_20203: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &stmt_defs_20203)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_20160: Array<Text>| {
            let defs = fold_20160;
            call_then(start_let_lambdas(b.stmts.clone()), move |let_lambdas_20262: Map<Nat, crate::syntax::Expr>| call_then(start_prompt_base(env.clone(), b.stmts.clone()), move |prompt_base_20289: Map<Text, crate::check::shrink::Rel>| {
                let cx_ = PCx { g: env.g.clone(), home: env.home.clone(), lams: let_lambdas_20262, base: prompt_base_20289 };
                call_value(fold_job(b.stmts.clone(), Array::new(), {
                    let env = env.clone();
                    let st = st.clone();
                    let cx_ = cx_.clone();
                    let defs = defs.clone();
                    Rc::new(move |(p0, p1): (Array<(Text, Text)>, crate::syntax::Stmt)| {
                        let env = env.clone();
                        let st = st.clone();
                        let cx_ = cx_.clone();
                        let defs = defs.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let s = p1;
                            call_then(start_prompt_edges(env.clone(), st.clone(), cx_.clone(), s.clone(), defs.clone()), move |prompt_edges_20374: Array<(Text, Text)>| prism_rtl::Turn::Finished(append(&acc, &prompt_edges_20374)))
                        }))
                    }) as Rc<dyn Fn((Array<(Text, Text)>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>>>
                }), move |fold_20331: Array<(Text, Text)>| {
                    let edges_ = fold_20331;
                    call_then(start_find_cycle(defs.clone(), edges_.clone()), move |find_cycle_20422: Array<Text>| {
                        let cyc = find_cycle_20422;
                        if &len(&cyc) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(st.clone())
                        } else {
                            call_value(fold_job(b.stmts.clone(), b.span.clone(), {
                                let cyc = cyc.clone();
                                Rc::new(move |(p0, p1): (crate::syntax::Range, crate::syntax::Stmt)| {
                                    let cyc = cyc.clone();
                                    entered(once_job(move || {
                                        let sp = p0;
                                        let s = p1;
                                        call_then(start_stmt_defs(s.clone()), move |stmt_defs_20542: Array<Text>| if crate::check::types::has_text(&stmt_defs_20542, &or(&index(&cyc, &Nat::from(0u32)), &Text::lit(""))) {
                                            prism_rtl::Turn::Finished(s.span.clone())
                                        } else {
                                            prism_rtl::Turn::Finished(sp.clone())
                                        })
                                    }))
                                }) as Rc<dyn Fn((crate::syntax::Range, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::syntax::Range>>>
                            }), move |fold_20499: crate::syntax::Range| {
                                let span = fold_20499;
                                prism_rtl::Turn::Finished(crate::check::types::err_fix(&st, &Text::lit("prompt-cycle"), &span, &Text::from(format!("a prompt cycle: {}", &crate::syntax::lexer::join(&each(&cyc, &(|n: &Text| Text::from(format!("`{}`", n)))), &Text::lit(", ")))), &Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened")))
                            })
                        }
                    })
                })
            }))
        })
    }
}

/// `Start BlockPromptCycles, x`: what the function value is when passed to `@Run`.
pub fn start_block_prompt_cycles(env: crate::check::expr::Env, st: crate::check::types::St, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(BlockPromptCycles { env, st, b })
}

/// ```prism
/// StmtDefs: unbounded fn Stmt -> [Text]
/// ```
pub fn stmt_defs(s: &crate::syntax::Stmt) -> Array<Text> {
    match &s.kind {
        crate::syntax::StmtKind::SBind(p_, _, _) => crate::check::env::pattern_names(p_),
        crate::syntax::StmtKind::SLet(p_, _, _) => crate::check::env::pattern_names(p_),
        _ => Array::new(),
    }
}

/// The step machine of `StmtDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtDefs: unbounded fn Stmt -> [Text]
/// ```
pub struct StmtDefs {
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<Text>> for StmtDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SBind(p_, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::PatternNames { p_: p_.clone() })),
            crate::syntax::StmtKind::SLet(p_, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::PatternNames { p_: p_.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start StmtDefs, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_defs(s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(StmtDefs { s })
}

/// ```prism
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
/// ```
pub fn prompt_edges(env: &crate::check::expr::Env, st: &crate::check::types::St, cx_: &PCx, s: &crate::syntax::Stmt, defs: &Array<Text>) -> Array<(Text, Text)> {
    match &s.kind {
        crate::syntax::StmtKind::SBind(_, _, Some(_)) => Array::new(),
        crate::syntax::StmtKind::SBind(p_, e, None) => edges(&crate::check::env::pattern_names(p_), &prompt_reads(cx_, e, defs)),
        crate::syntax::StmtKind::SLet(p_, _, e) => {
            let names = crate::check::env::pattern_names(p_);
            let layer = run_to_end(fold_job(names.clone(), Text::lit(""), {
                let env = env.clone();
                let st = st.clone();
                Rc::new(move |(p0, p1): (Text, Text)| {
                    let env = env.clone();
                    let st = st.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let n = p1;
                        match get(&env.locals, &n) {
                            Some(sc) => prism_rtl::Turn::More(Rc::new(crate::check::types::HeadSigil { st: st.clone(), t: sc.ty.clone() })),
                            None => prism_rtl::Turn::Finished(acc.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            edges(&names, &run_to_end(filter_job(prompt_reads(cx_, e, defs), {
                let env = env.clone();
                let st = st.clone();
                let layer = layer.clone();
                Rc::new(move |p0: Text| {
                    let env = env.clone();
                    let st = st.clone();
                    let layer = layer.clone();
                    entered(once_job(move || {
                        let n = p0;
                        prism_rtl::Turn::More(Rc::new(ReadIsPrompt { env: env.clone(), st: st.clone(), n: n.clone(), layer: layer.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
            })))
        },
        _ => Array::new(),
    }
}

/// The step machine of `PromptEdges`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
/// ```
pub struct PromptEdges {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub cx_: PCx,
    pub s: crate::syntax::Stmt,
    pub defs: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for PromptEdges {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let env = &self.env;
        let st = &self.st;
        let cx_ = &self.cx_;
        let s = &self.s;
        let defs = &self.defs;
        match &s.kind {
            crate::syntax::StmtKind::SBind(_, _, Some(_)) => prism_rtl::Turn::Finished(Array::new()),
            crate::syntax::StmtKind::SBind(p_, e, None) => {
                let cx_ = cx_.clone();
                let defs = defs.clone();
                let e = e.clone();
                let p_ = p_.clone();
                call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_21266: Array<Text>| call_then(start_prompt_reads(cx_.clone(), e.clone(), defs.clone()), move |prompt_reads_21284: Array<Text>| prism_rtl::Turn::Finished(edges(&pattern_names_21266, &prompt_reads_21284))))
            },
            crate::syntax::StmtKind::SLet(p_, _, e) => {
                let cx_ = cx_.clone();
                let defs = defs.clone();
                let e = e.clone();
                let env = env.clone();
                let p_ = p_.clone();
                let st = st.clone();
                call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_21352: Array<Text>| {
                    let names = pattern_names_21352;
                    call_value(fold_job(names.clone(), Text::lit(""), {
                        let env = env.clone();
                        let st = st.clone();
                        Rc::new(move |(p0, p1): (Text, Text)| {
                            let env = env.clone();
                            let st = st.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let n = p1;
                                match get(&env.locals, &n) {
                                    Some(sc) => prism_rtl::Turn::More(Rc::new(crate::check::types::HeadSigil { st: st.clone(), t: sc.ty.clone() })),
                                    None => prism_rtl::Turn::Finished(acc.clone()),
                                }
                            }))
                        }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |fold_21387: Text| {
                        let layer = fold_21387;
                        call_then(start_prompt_reads(cx_.clone(), e.clone(), defs.clone()), move |prompt_reads_21523: Array<Text>| call_value(filter_job(prompt_reads_21523, {
                            let env = env.clone();
                            let st = st.clone();
                            let layer = layer.clone();
                            Rc::new(move |p0: Text| {
                                let env = env.clone();
                                let st = st.clone();
                                let layer = layer.clone();
                                entered(once_job(move || {
                                    let n = p0;
                                    prism_rtl::Turn::More(Rc::new(ReadIsPrompt { env: env.clone(), st: st.clone(), n: n.clone(), layer: layer.clone() }))
                                }))
                            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |filter_21515: Array<Text>| prism_rtl::Turn::Finished(edges(&names, &filter_21515))))
                    })
                })
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PromptEdges, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_edges(env: crate::check::expr::Env, st: crate::check::types::St, cx_: PCx, s: crate::syntax::Stmt, defs: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(PromptEdges { env, st, cx_, s, defs })
}

/// ```prism
/// Edges: fn [Text], [Text] -> [((Text, Text))]
/// ```
pub fn edges(froms: &Array<Text>, tos: &Array<Text>) -> Array<(Text, Text)> {
    fold(froms, &Array::new(), &(|acc: &Array<(Text, Text)>, f: &Text| append(acc, &each(tos, &(|t: &Text| (f.clone(), t.clone()))))))
}

/// ```prism
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
/// ```
pub fn read_is_prompt(env: &crate::check::expr::Env, st: &crate::check::types::St, n: &Text, layer: &Text) -> bool {
    match get(&env.locals, n) {
        Some(sc) => {
            let h = crate::check::types::head_sigil(st, &sc.ty);
            if layer == &Text::lit("!") {
                (&h == &Text::lit("!")) || (&h == &Text::lit("@"))
            } else {
                if layer == &Text::lit("$") {
                    (&h == &Text::lit("$")) || (&h == &Text::lit("!"))
                } else {
                    match crate::check::types::walk(st, &sc.ty) {
                        crate::check::types::Ty::TyFn(_, _, _) => false,
                        _ => crate::check::env::is_lower_text(&crate::syntax::lexer::drop_prefix(n, &crate::check::types::marks_of(n))) && (&h == &Text::lit("")),
                    }
                }
            }
        },
        None => false,
    }
}

/// The step machine of `ReadIsPrompt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
/// ```
pub struct ReadIsPrompt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub n: Text,
    pub layer: Text,
}

impl prism_rtl::Job<bool> for ReadIsPrompt {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let layer = &self.layer;
        match get(&env.locals, n) {
            Some(sc) => {
                let layer = layer.clone();
                let n = n.clone();
                let st = st.clone();
                call_then(crate::check::types::start_head_sigil(st.clone(), sc.ty.clone()), move |head_sigil_22010: Text| {
                    let h = head_sigil_22010;
                    if &layer == &Text::lit("!") {
                        prism_rtl::Turn::Finished((&h == &Text::lit("!")) || (&h == &Text::lit("@")))
                    } else {
                        if &layer == &Text::lit("$") {
                            prism_rtl::Turn::Finished((&h == &Text::lit("$")) || (&h == &Text::lit("!")))
                        } else {
                            call_then(crate::check::types::start_walk(st.clone(), sc.ty.clone()), move |walk_22148: crate::check::types::Ty| match walk_22148 {
                                crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::Finished(false),
                                _ => prism_rtl::Turn::Finished(crate::check::env::is_lower_text(&crate::syntax::lexer::drop_prefix(&n, &crate::check::types::marks_of(&n))) && (&h == &Text::lit(""))),
                            })
                        }
                    }
                })
            },
            None => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start ReadIsPrompt, x`: what the function value is when passed to `@Run`.
pub fn start_read_is_prompt(env: crate::check::expr::Env, st: crate::check::types::St, n: Text, layer: Text) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(ReadIsPrompt { env, st, n, layer })
}

/// ```prism
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
/// ```
pub fn prompt_base(env: &crate::check::expr::Env, stmts: &Array<crate::syntax::Stmt>) -> Map<Text, crate::check::shrink::Rel> {
    let pre = crate::check::shrink::prelude_seeds(&env.g, &env.home);
    let seeds = fold(&keys(&pre), &pre, &(|m: &Map<Text, crate::check::shrink::Rel>, k: &Text| if crate::check::env::has_key(&env.locals, &crate::syntax::lexer::drop_prefix(k, &Text::lit("pre:"))) {
        remove(m, k)
    } else {
        m.clone()
    }));
    fold(stmts, &seeds, &(|m: &Map<Text, crate::check::shrink::Rel>, s: &crate::syntax::Stmt| lam_let_rels(s, m)))
}

/// The step machine of `PromptBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
/// ```
pub struct PromptBase {
    pub env: crate::check::expr::Env,
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for PromptBase {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let env = &self.env;
        let stmts = &self.stmts;
        let pre = crate::check::shrink::prelude_seeds(&env.g, &env.home);
        let seeds = fold(&keys(&pre), &pre, &(|m: &Map<Text, crate::check::shrink::Rel>, k: &Text| if crate::check::env::has_key(&env.locals, &crate::syntax::lexer::drop_prefix(k, &Text::lit("pre:"))) {
            remove(m, k)
        } else {
            m.clone()
        }));
        prism_rtl::Turn::Finished(fold(stmts, &seeds, &(|m: &Map<Text, crate::check::shrink::Rel>, s: &crate::syntax::Stmt| lam_let_rels(s, m))))
    }
}

/// `Start PromptBase, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_base(env: crate::check::expr::Env, stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(PromptBase { env, stmts })
}

/// ```prism
/// LamLetRels: fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn lam_let_rels(s: &crate::syntax::Stmt, m: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    match &s.kind {
        crate::syntax::StmtKind::SLet(p_, _, e) => match ((*p_.kind).clone(), lambda_of(e)) {
            (crate::syntax::PatternKind::PName(n), Some(lam)) => insert(m, &Text::from(format!("lamlet:{}", &crate::check::env::sname_key(&n))), &crate::check::shrink::Rel { param: lam.span.start.clone(), strict: false }),
            _ => m.clone(),
        },
        _ => m.clone(),
    }
}

/// ```prism
/// ?LambdaOf: fn Expr -> ?Expr
/// ```
pub fn lambda_of(e: &crate::syntax::Expr) -> Option<crate::syntax::Expr> {
    match &*e.kind {
        crate::syntax::ExprKind::ELambda(_, _) => Some(e.clone()),
        crate::syntax::ExprKind::EGroup(x) => lambda_of(&**x),
        _ => None,
    }
}

/// ```prism
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
/// ```
pub fn let_lambdas(stmts: &Array<crate::syntax::Stmt>) -> Map<Nat, crate::syntax::Expr> {
    fold(&crate::check::shrink::stmts_spots(stmts, &Map::new()), &Map::new(), &(|m: &Map<Nat, crate::syntax::Expr>, sp: &crate::check::shrink::Spot| match sp {
        crate::check::shrink::Spot::SpotStmt(s, _) => match &s.kind {
            crate::syntax::StmtKind::SLet(_, _, e) => match lambda_of(e) {
                Some(lam) => insert(m, &lam.span.start, &lam),
                None => m.clone(),
            },
            _ => m.clone(),
        },
        _ => m.clone(),
    }))
}

/// The step machine of `LetLambdas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
/// ```
pub struct LetLambdas {
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Map<Nat, crate::syntax::Expr>> for LetLambdas {
    fn cycle(&self) -> prism_rtl::Turn<Map<Nat, crate::syntax::Expr>> {
        let stmts = &self.stmts;
        let stmts = stmts.clone();
        call_then(crate::check::shrink::start_stmts_spots(stmts.clone(), Map::new()), move |stmts_spots_23872: Array<crate::check::shrink::Spot>| prism_rtl::Turn::Finished(fold(&stmts_spots_23872, &Map::new(), &(|m: &Map<Nat, crate::syntax::Expr>, sp: &crate::check::shrink::Spot| match sp {
            crate::check::shrink::Spot::SpotStmt(s, _) => match &s.kind {
                crate::syntax::StmtKind::SLet(_, _, e) => match lambda_of(e) {
                    Some(lam) => insert(m, &lam.span.start, &lam),
                    None => m.clone(),
                },
                _ => m.clone(),
            },
            _ => m.clone(),
        }))))
    }
}

/// `Start LetLambdas, x`: what the function value is when passed to `@Run`.
pub fn start_let_lambdas(stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Map<Nat, crate::syntax::Expr>>> {
    Rc::new(LetLambdas { stmts })
}

/// ```prism
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
/// ```
pub fn prompt_reads(cx_: &PCx, e: &crate::syntax::Expr, defs: &Array<Text>) -> Array<Text> {
    let spots = prompt_spots(cx_, e, &cx_.base);
    run_to_end(fold_job(spots.clone(), Array::new(), {
        let defs = defs.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::Spot)| {
            let defs = defs.clone();
            entered(once_job(move || {
                let acc = p0;
                let sp = p1;
                call_then(crate::check::shrink::start_spot_sites(sp.clone()), move |spot_sites_25221: Array<crate::check::shrink::Site>| prism_rtl::Turn::Finished(fold(&spot_sites_25221, &acc, &(|a2: &Array<Text>, site: &crate::check::shrink::Site| if crate::check::types::has_text(&defs, &site.callee) && !crate::check::shrink::is_local(&site.rels, &site.callee) {
                    crate::check::types::add_text(a2, &site.callee)
                } else {
                    a2.clone()
                }))))
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::check::shrink::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `PromptReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
/// ```
pub struct PromptReads {
    pub cx_: PCx,
    pub e: crate::syntax::Expr,
    pub defs: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for PromptReads {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cx_ = &self.cx_;
        let e = &self.e;
        let defs = &self.defs;
        let cx_ = cx_.clone();
        let defs = defs.clone();
        let e = e.clone();
        call_then(start_prompt_spots(cx_.clone(), e.clone(), cx_.base.clone()), move |prompt_spots_25155: Array<crate::check::shrink::Spot>| {
            let spots = prompt_spots_25155;
            fold_job(spots.clone(), Array::new(), {
                let defs = defs.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::Spot)| {
                    let defs = defs.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let sp = p1;
                        call_then(crate::check::shrink::start_spot_sites(sp.clone()), move |spot_sites_25221: Array<crate::check::shrink::Site>| prism_rtl::Turn::Finished(fold(&spot_sites_25221, &acc, &(|a2: &Array<Text>, site: &crate::check::shrink::Site| if crate::check::types::has_text(&defs, &site.callee) && !crate::check::shrink::is_local(&site.rels, &site.callee) {
                            crate::check::types::add_text(a2, &site.callee)
                        } else {
                            a2.clone()
                        }))))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::shrink::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle()
        })
    }
}

/// `Start PromptReads, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_reads(cx_: PCx, e: crate::syntax::Expr, defs: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PromptReads { cx_, e, defs })
}

/// ```prism
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
/// ```
pub fn prompt_spots(cx_: &PCx, e: &crate::syntax::Expr, m: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::Spot> {
    run_to_end(fold_job(prompt_kids(cx_, e, m), Array::from(vec![crate::check::shrink::Spot::SpotExpr(e.clone(), m.clone())]), {
        let cx_ = cx_.clone();
        Rc::new(move |(p0, p1): (Array<crate::check::shrink::Spot>, crate::check::shrink::Kid)| {
            let cx_ = cx_.clone();
            entered(once_job(move || {
                let acc = p0;
                let k = p1;
                prism_rtl::Turn::Finished(append(&acc, &prompt_kid_spots(&cx_, &k)))
            }))
        }) as Rc<dyn Fn((Array<crate::check::shrink::Spot>, crate::check::shrink::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Spot>>>>
    }))
}

/// The step machine of `PromptSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
/// ```
pub struct PromptSpots {
    pub cx_: PCx,
    pub e: crate::syntax::Expr,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<crate::check::shrink::Spot>> for PromptSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::shrink::Spot>> {
        let cx_ = &self.cx_;
        let e = &self.e;
        let m = &self.m;
        fold_job(prompt_kids(cx_, e, m), Array::from(vec![crate::check::shrink::Spot::SpotExpr(e.clone(), m.clone())]), {
            let cx_ = cx_.clone();
            Rc::new(move |(p0, p1): (Array<crate::check::shrink::Spot>, crate::check::shrink::Kid)| {
                let cx_ = cx_.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let k = p1;
                    prism_rtl::Turn::Finished(append(&acc, &prompt_kid_spots(&cx_, &k)))
                }))
            }) as Rc<dyn Fn((Array<crate::check::shrink::Spot>, crate::check::shrink::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Spot>>>>
        }).cycle()
    }
}

/// `Start PromptSpots, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_spots(cx_: PCx, e: crate::syntax::Expr, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Spot>>> {
    Rc::new(PromptSpots { cx_, e, m })
}

/// ```prism
/// PromptKids: unbounded fn PCx, Expr, (Text ==> Rel) -> [Kid]
/// ```
pub fn prompt_kids(cx_: &PCx, e: &crate::syntax::Expr, m: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::Kid> {
    match &*e.kind {
        crate::syntax::ExprKind::ELambda(_, _) => Array::new(),
        crate::syntax::ExprKind::ERebuild(_, body) => row_kids(body, m, &Array::new()),
        crate::syntax::ExprKind::EFor(binders_opt, _, body) => row_kids(body, m, &for_binder_names(binders_opt)),
        crate::syntax::ExprKind::EWidgetBlock(_) => Array::new(),
        crate::syntax::ExprKind::ECall(c, _, _, _) => prompt_call_kids(cx_, e, &crate::check::shrink::callee_name(&**c), m),
        crate::syntax::ExprKind::EMethod(_, n, _) => prompt_call_kids(cx_, e, &Some(crate::check::env::sname_key(n)), m),
        _ => crate::check::shrink::expr_kids(e, m),
    }
}

/// ```prism
/// RowKids: unbounded fn Block, (Text ==> Rel), [Text] -> [Kid]
/// ```
pub fn row_kids(body: &crate::syntax::Block, m: &Map<Text, crate::check::shrink::Rel>, binders: &Array<Text>) -> Array<crate::check::shrink::Kid> {
    let lines = filter(&body.stmts, &(|s: &crate::syntax::Stmt| match &s.kind {
        crate::syntax::StmtKind::SBind(_, _, Some(_)) => false,
        _ => true,
    }));
    let own = run_to_end(fold_job(body.stmts.clone(), append(binders, &Array::from(vec![Text::lit("_"), Text::lit("$_")])), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| entered(once_job(move || {
        let acc = p0;
        let s = p1;
        call_then(start_stmt_defs(s.clone()), move |stmt_defs_26892: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &stmt_defs_26892)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    Array::from(vec![crate::check::shrink::Kid::KidStmts(lines.clone(), crate::check::shrink::hide(m, &own))])
}

/// ```prism
/// ForBinderNames: unbounded fn ?ForBinders -> [Text]
/// ```
pub fn for_binder_names(binders_opt: &Option<crate::syntax::ForBinders>) -> Array<Text> {
    match binders_opt {
        Some(fb) => match &fb.second {
            Some(second) => append(&crate::check::env::pattern_names(&fb.first), &crate::check::env::pattern_names(second)),
            None => crate::check::env::pattern_names(&fb.first),
        },
        None => Array::new(),
    }
}

/// ```prism
/// PromptCallKids: unbounded fn PCx, Expr, ?Text, (Text ==> Rel) -> [Kid]
/// ```
pub fn prompt_call_kids(cx_: &PCx, e: &crate::syntax::Expr, n_opt: &Option<Text>, m: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::Kid> {
    match n_opt {
        Some(n) => {
            let called = follow_lam_let(cx_, n, m);
            if crate::check::shrink::is_local(m, n) {
                append(&called, &open_lambdas(cx_, &crate::check::shrink::expr_kids(e, m)))
            } else {
                if &len(&called) > &Nat::from(0u32) {
                    append(&called, &open_lambdas(cx_, &crate::check::shrink::expr_kids(e, m)))
                } else {
                    match crate::check::shrink::resolve_callee(&cx_.g, &cx_.home, n) {
                        Some(k) => if crate::check::shrink::is_prelude_key(&cx_.g, &k) && is_delayed_widget(&crate::syntax::lexer::drop_prefix(&k, &Text::lit("Prelude."))) {
                            Array::new()
                        } else {
                            if crate::check::shrink::is_prelude_key(&cx_.g, &k) && crate::syntax::lexer::has_prefix(&k, &Text::lit("Prelude.@")) {
                                crate::check::shrink::expr_kids(e, m)
                            } else {
                                open_lambdas(cx_, &crate::check::shrink::expr_kids(e, m))
                            }
                        },
                        None => open_lambdas(cx_, &crate::check::shrink::expr_kids(e, m)),
                    }
                }
            }
        },
        None => open_lambdas(cx_, &crate::check::shrink::expr_kids(e, m)),
    }
}

/// ```prism
/// OpenLambdas: unbounded fn PCx, [Kid] -> [Kid]
/// ```
pub fn open_lambdas(cx_: &PCx, kids: &Array<crate::check::shrink::Kid>) -> Array<crate::check::shrink::Kid> {
    run_to_end(fold_job(kids.clone(), Array::new(), {
        let cx_ = cx_.clone();
        Rc::new(move |(p0, p1): (Array<crate::check::shrink::Kid>, crate::check::shrink::Kid)| {
            let cx_ = cx_.clone();
            entered(once_job(move || {
                let acc = p0;
                let k = p1;
                match &k {
                    crate::check::shrink::Kid::KidExpr(x, m) => match &*x.kind {
                        crate::syntax::ExprKind::ELambda(ps_opt, body) => {
                            let ps_opt = ps_opt.clone();
                            let body = (**body).clone();
                            let m = m.clone();
                            call_then(crate::check::shrink::start_patterns_names(or(&ps_opt, &Array::new())), move |patterns_names_28511: Array<Text>| prism_rtl::Turn::Finished(push(&acc, &crate::check::shrink::lambda_kid(&body, &crate::check::shrink::hide(&m, &patterns_names_28511)))))
                        },
                        crate::syntax::ExprKind::EName(n) => prism_rtl::Turn::Finished(append(&push(&acc, &k), &follow_lam_let(&cx_, &crate::check::env::sname_key(n), m))),
                        _ => prism_rtl::Turn::Finished(push(&acc, &k)),
                    },
                    _ => prism_rtl::Turn::Finished(push(&acc, &k)),
                }
            }))
        }) as Rc<dyn Fn((Array<crate::check::shrink::Kid>, crate::check::shrink::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Kid>>>>
    }))
}

/// ```prism
/// FollowLamLet: unbounded fn PCx, Text, (Text ==> Rel) -> [Kid]
/// ```
pub fn follow_lam_let(cx_: &PCx, n: &Text, m: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::Kid> {
    match get(m, &Text::from(format!("lamlet:{}", n))) {
        Some(r) => if crate::check::env::has_key(m, &Text::from(format!("seen:{}", &r.param))) {
            Array::new()
        } else {
            match get(&cx_.lams, &r.param) {
                Some(lam) => match &*lam.kind {
                    crate::syntax::ExprKind::ELambda(ps_opt, body) => {
                        let seen = fold(&keys(m), &cx_.base, &(|m2: &Map<Text, crate::check::shrink::Rel>, k: &Text| if crate::syntax::lexer::has_prefix(k, &Text::lit("seen:")) {
                            insert(m2, k, &crate::check::shrink::no_rel())
                        } else {
                            m2.clone()
                        }));
                        Array::from(vec![crate::check::shrink::lambda_kid(&**body, &crate::check::shrink::hide(&insert(&seen, &Text::from(format!("seen:{}", &r.param)), &crate::check::shrink::no_rel()), &crate::check::shrink::patterns_names(&or(ps_opt, &Array::new()))))])
                    },
                    _ => Array::new(),
                },
                None => Array::new(),
            }
        },
        None => Array::new(),
    }
}

/// ```prism
/// PromptKidSpots: unbounded fn PCx, Kid -> [Spot]
/// ```
pub fn prompt_kid_spots(cx_: &PCx, k: &crate::check::shrink::Kid) -> Array<crate::check::shrink::Spot> {
    match k {
        crate::check::shrink::Kid::KidExpr(x, m) => prompt_spots(cx_, x, m),
        crate::check::shrink::Kid::KidStmts(ss, m) => {
            let bm = crate::check::shrink::block_rels(ss, m);
            run_to_end(fold_job(ss.clone(), Array::new(), {
                let cx_ = cx_.clone();
                let bm = bm.clone();
                Rc::new(move |(p0, p1): (Array<crate::check::shrink::Spot>, crate::syntax::Stmt)| {
                    let cx_ = cx_.clone();
                    let bm = bm.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let s = p1;
                        prism_rtl::Turn::Finished(append(&acc, &prompt_stmt_spots(&cx_, &s, &bm)))
                    }))
                }) as Rc<dyn Fn((Array<crate::check::shrink::Spot>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Spot>>>>
            }))
        },
    }
}

/// ```prism
/// PromptStmtSpots: unbounded fn PCx, Stmt, (Text ==> Rel) -> [Spot]
/// ```
pub fn prompt_stmt_spots(cx_: &PCx, s: &crate::syntax::Stmt, m: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::Spot> {
    match &s.kind {
        crate::syntax::StmtKind::SFn(_) => Array::from(vec![crate::check::shrink::Spot::SpotStmt(s.clone(), m.clone())]),
        crate::syntax::StmtKind::SWidget(_) => Array::from(vec![crate::check::shrink::Spot::SpotStmt(s.clone(), m.clone())]),
        _ => run_to_end(fold_job(crate::check::shrink::stmt_kids(s, m), Array::from(vec![crate::check::shrink::Spot::SpotStmt(s.clone(), m.clone())]), {
            let cx_ = cx_.clone();
            Rc::new(move |(p0, p1): (Array<crate::check::shrink::Spot>, crate::check::shrink::Kid)| {
                let cx_ = cx_.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let k = p1;
                    prism_rtl::Turn::Finished(append(&acc, &prompt_kid_spots(&cx_, &k)))
                }))
            }) as Rc<dyn Fn((Array<crate::check::shrink::Spot>, crate::check::shrink::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Spot>>>>
        })),
    }
}

/// ```prism
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
/// ```
pub fn find_cycle(defs: &Array<Text>, edges_: &Array<(Text, Text)>) -> Array<Text> {
    run_to_end(fold_job(defs.clone(), Array::new(), {
        let defs = defs.clone();
        let edges_ = edges_.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
            let defs = defs.clone();
            let edges_ = edges_.clone();
            entered(once_job(move || {
                let found = p0;
                let d = p1;
                if &len(&found) > &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(found.clone())
                } else {
                    prism_rtl::Turn::More(Rc::new(CycleThrough { defs: defs.clone(), edges_: edges_.clone(), d: d.clone() }))
                }
            }))
        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `FindCycle`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
/// ```
pub struct FindCycle {
    pub defs: Array<Text>,
    pub edges_: Array<(Text, Text)>,
}

impl prism_rtl::Job<Array<Text>> for FindCycle {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let defs = &self.defs;
        let edges_ = &self.edges_;
        fold_job(defs.clone(), Array::new(), {
            let defs = defs.clone();
            let edges_ = edges_.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                let defs = defs.clone();
                let edges_ = edges_.clone();
                entered(once_job(move || {
                    let found = p0;
                    let d = p1;
                    if &len(&found) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(found.clone())
                    } else {
                        prism_rtl::Turn::More(Rc::new(CycleThrough { defs: defs.clone(), edges_: edges_.clone(), d: d.clone() }))
                    }
                }))
            }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start FindCycle, x`: what the function value is when passed to `@Run`.
pub fn start_find_cycle(defs: Array<Text>, edges_: Array<(Text, Text)>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(FindCycle { defs, edges_ })
}

/// ```prism
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
/// ```
pub fn cycle_through(defs: &Array<Text>, edges_: &Array<(Text, Text)>, d: &Text) -> Array<Text> {
    let fwd = reach_from(edges_, d);
    if crate::check::types::has_text(&fwd, d) {
        run_to_end(filter_job(defs.clone(), {
            let fwd = fwd.clone();
            let edges_ = edges_.clone();
            let d = d.clone();
            Rc::new(move |p0: Text| {
                let fwd = fwd.clone();
                let edges_ = edges_.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let x = p0;
                    prism_rtl::Turn::Finished(crate::check::types::has_text(&fwd, &x) && crate::check::types::has_text(&reach_from(&edges_, &x), &d))
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
        }))
    } else {
        Array::new()
    }
}

/// The step machine of `CycleThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
/// ```
pub struct CycleThrough {
    pub defs: Array<Text>,
    pub edges_: Array<(Text, Text)>,
    pub d: Text,
}

impl prism_rtl::Job<Array<Text>> for CycleThrough {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let defs = &self.defs;
        let edges_ = &self.edges_;
        let d = &self.d;
        let d = d.clone();
        let defs = defs.clone();
        let edges_ = edges_.clone();
        call_then(start_reach_from(edges_.clone(), d.clone()), move |reach_from_30531: Array<Text>| {
            let fwd = reach_from_30531;
            if crate::check::types::has_text(&fwd, &d) {
                filter_job(defs.clone(), {
                    let fwd = fwd.clone();
                    let edges_ = edges_.clone();
                    let d = d.clone();
                    Rc::new(move |p0: Text| {
                        let fwd = fwd.clone();
                        let edges_ = edges_.clone();
                        let d = d.clone();
                        entered(once_job(move || {
                            let x = p0;
                            prism_rtl::Turn::Finished(crate::check::types::has_text(&fwd, &x) && crate::check::types::has_text(&reach_from(&edges_, &x), &d))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle()
            } else {
                prism_rtl::Turn::Finished(Array::new())
            }
        })
    }
}

/// `Start CycleThrough, x`: what the function value is when passed to `@Run`.
pub fn start_cycle_through(defs: Array<Text>, edges_: Array<(Text, Text)>, d: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CycleThrough { defs, edges_, d })
}

/// ```prism
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
/// ```
pub fn reach_from(edges_: &Array<(Text, Text)>, d: &Text) -> Array<Text> {
    reach(edges_, &each(&filter(edges_, &(|(f, _): &(Text, Text)| f == d)), &(|(_, t): &(Text, Text)| t.clone())), &Array::new())
}

/// The step machine of `ReachFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
/// ```
pub struct ReachFrom {
    pub edges_: Array<(Text, Text)>,
    pub d: Text,
}

impl prism_rtl::Job<Array<Text>> for ReachFrom {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let edges_ = &self.edges_;
        let d = &self.d;
        prism_rtl::Turn::Finished(reach(edges_, &each(&filter(edges_, &(|(f, _): &(Text, Text)| f == d)), &(|(_, t): &(Text, Text)| t.clone())), &Array::new()))
    }
}

/// `Start ReachFrom, x`: what the function value is when passed to `@Run`.
pub fn start_reach_from(edges_: Array<(Text, Text)>, d: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReachFrom { edges_, d })
}

/// ```prism
/// Reach: unbounded fn [((Text, Text))], [Text], [Text] -> [Text]
/// ```
pub fn reach(edges_: &Array<(Text, Text)>, frontier: &Array<Text>, seen: &Array<Text>) -> Array<Text> {
    match index(frontier, &Nat::from(0u32)) {
        None => seen.clone(),
        Some(x) => if crate::check::types::has_text(seen, &x) {
            reach(edges_, &drop(frontier, &Nat::from(1u32)), seen)
        } else {
            reach(edges_, &append(&drop(frontier, &Nat::from(1u32)), &each(&filter(edges_, &(|(f, _): &(Text, Text)| f == &x)), &(|(_, t): &(Text, Text)| t.clone()))), &push(seen, &x))
        },
    }
}

/// ```prism
/// IsLocalType: unbounded fn St, Ty -> Bool
/// ```
pub fn is_local_type(st: &crate::check::types::St, t: &crate::check::types::Ty) -> bool {
    match crate::check::types::walk(st, t) {
        crate::check::types::Ty::TyCon(m31590_0_0, _) if (&m31590_0_0 == &Text::lit("Buffer")) => true,
        crate::check::types::Ty::TyCon(m31590_1_0, _) if (&m31590_1_0 == &Text::lit("Table")) => true,
        crate::check::types::Ty::TyArray(e) => is_local_type(st, &*e),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), false, {
            let st = st.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(seen || is_local_type(&st, &x))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyMap(k, v_) => is_local_type(st, &*k) || is_local_type(st, &*v_),
        crate::check::types::Ty::TySig(_, i) => is_local_type(st, &*i),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `IsLocalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsLocalType: unbounded fn St, Ty -> Bool
/// ```
pub struct IsLocalType {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for IsLocalType {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::start_walk(st.clone(), t.clone()), move |walk_31596: crate::check::types::Ty| match walk_31596 {
            crate::check::types::Ty::TyCon(m31590_0_0, _) if (&m31590_0_0 == &Text::lit("Buffer")) => prism_rtl::Turn::Finished(true),
            crate::check::types::Ty::TyCon(m31590_1_0, _) if (&m31590_1_0 == &Text::lit("Table")) => prism_rtl::Turn::Finished(true),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(IsLocalType { st: st.clone(), t: (*e).clone() })),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), false, {
                let st = st.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(seen || is_local_type(&st, &x))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::check::types::Ty::TyMap(k, v_) => call_then(start_is_local_type(st.clone(), (*k).clone()), move |is_local_type_31792: bool| prism_rtl::Turn::Finished(is_local_type_31792 || is_local_type(&st, &*v_))),
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(IsLocalType { st: st.clone(), t: (*i).clone() })),
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start IsLocalType, x`: what the function value is when passed to `@Run`.
pub fn start_is_local_type(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsLocalType { st, t })
}

/// ```prism
/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
/// ```
pub fn and_block_checks(env: &crate::check::expr::Env, st: &crate::check::types::St, b: &crate::syntax::Block, t: &crate::check::types::Ty) -> crate::check::types::St {
    let st1 = if is_local_type(st, t) {
        crate::check::types::err_fix(st, &Text::lit("local-escapes"), &b.span, &Text::from(format!("a `{}` cannot leave its block", &block_local_name(st, t))), &Text::lit("`Freeze` it into a plain value first"))
    } else {
        st.clone()
    };
    let st2 = escape_stmts(env, &st1, &b.stmts);
    let (_, st3) = frozen_stmts(env, &st2, &b.stmts, &Map::new());
    borrow_stmts(env, &st3, &b.stmts, &Array::new())
}

/// The step machine of `AndBlockChecks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
/// ```
pub struct AndBlockChecks {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub b: crate::syntax::Block,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for AndBlockChecks {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let t = &self.t;
        let b = b.clone();
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_is_local_type(st.clone(), t.clone()), move |is_local_type_32146: bool| {
            let st1 = if is_local_type_32146 {
                crate::check::types::err_fix(&st, &Text::lit("local-escapes"), &b.span, &Text::from(format!("a `{}` cannot leave its block", &block_local_name(&st, &t))), &Text::lit("`Freeze` it into a plain value first"))
            } else {
                st.clone()
            };
            call_then(start_escape_stmts(env.clone(), st1.clone(), b.stmts.clone()), move |escape_stmts_32316: crate::check::types::St| {
                let st2 = escape_stmts_32316;
                call_then(start_frozen_stmts(env.clone(), st2.clone(), b.stmts.clone(), Map::new()), move |frozen_stmts_32372: (Map<Text, Nat>, crate::check::types::St)| {
                    let (_, st3) = frozen_stmts_32372;
                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: st3.clone(), stmts: b.stmts.clone(), lent: Array::new() }))
                })
            })
        })
    }
}

/// `Start AndBlockChecks, x`: what the function value is when passed to `@Run`.
pub fn start_and_block_checks(env: crate::check::expr::Env, st: crate::check::types::St, b: crate::syntax::Block, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(AndBlockChecks { env, st, b, t })
}

/// ```prism
/// BlockLocalName: unbounded fn St, Ty -> Text
/// ```
pub fn block_local_name(st: &crate::check::types::St, t: &crate::check::types::Ty) -> Text {
    match crate::check::types::walk(st, t) {
        crate::check::types::Ty::TyCon(n, _) => n.clone(),
        _ => Text::lit("Buffer"),
    }
}

/// The step machine of `BlockLocalName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockLocalName: unbounded fn St, Ty -> Text
/// ```
pub struct BlockLocalName {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for BlockLocalName {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::start_walk(st.clone(), t.clone()), move |walk_32523: crate::check::types::Ty| match walk_32523 {
            crate::check::types::Ty::TyCon(n, _) => prism_rtl::Turn::Finished(n.clone()),
            _ => prism_rtl::Turn::Finished(Text::lit("Buffer")),
        })
    }
}

/// `Start BlockLocalName, x`: what the function value is when passed to `@Run`.
pub fn start_block_local_name(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(BlockLocalName { st, t })
}

/// ```prism
/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
/// ```
pub fn escape_stmts(env: &crate::check::expr::Env, st: &crate::check::types::St, stmts: &Array<crate::syntax::Stmt>) -> crate::check::types::St {
    run_to_end(fold_job(stmts.clone(), st.clone(), {
        let env = env.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
            let env = env.clone();
            entered(once_job(move || {
                let s = p0;
                let stmt = p1;
                match &stmt.kind {
                    crate::syntax::StmtKind::SLet(p_, _, e) => match &*p_.kind {
                        crate::syntax::PatternKind::PName(n) => if crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")) {
                            prism_rtl::Turn::Finished(s.clone())
                        } else {
                            match get(&env.locals, &crate::check::env::sname_key(n)) {
                                Some(_) => prism_rtl::Turn::Finished(s.clone()),
                                None => if calls_local_maker(&env, e) {
                                    prism_rtl::Turn::Finished(crate::check::types::err_fix(&s, &Text::lit("local-escapes"), &stmt.span, &Text::from(format!("a `Buffer` cannot leave its block: `{}` is no `&` local", &crate::check::env::sname_key(n))), &Text::from(format!("write `let &{} = ...`", &crate::check::env::sname_key(n)))))
                                } else {
                                    prism_rtl::Turn::Finished(s.clone())
                                },
                            }
                        },
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    },
                    crate::syntax::StmtKind::SWhile(_, body) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone() })),
                    crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                        crate::syntax::ExprKind::EIf(_, tb, eb_opt) => {
                            let eb_opt = eb_opt.clone();
                            let tb = tb.clone();
                            call_then(start_escape_stmts(env.clone(), s.clone(), tb.stmts.clone()), move |escape_stmts_33232: crate::check::types::St| {
                                let s2 = escape_stmts_33232;
                                match &eb_opt {
                                    Some(x) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s2.clone(), stmts: x.stmts.clone() })),
                                    None => prism_rtl::Turn::Finished(s2.clone()),
                                }
                            })
                        },
                        crate::syntax::ExprKind::EMatch(_, arms) => fold_job(arms.clone(), s.clone(), {
                            let env = env.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                let env = env.clone();
                                entered(once_job(move || {
                                    let s3 = p0;
                                    let a = p1;
                                    prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s3.clone(), stmts: a.body.stmts.clone() }))
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle(),
                        crate::syntax::ExprKind::EFor(_, _, body) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone() })),
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    },
                    _ => prism_rtl::Turn::Finished(s.clone()),
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `EscapeStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
/// ```
pub struct EscapeStmts {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<crate::check::types::St> for EscapeStmts {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        fold_job(stmts.clone(), st.clone(), {
            let env = env.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
                let env = env.clone();
                entered(once_job(move || {
                    let s = p0;
                    let stmt = p1;
                    match &stmt.kind {
                        crate::syntax::StmtKind::SLet(p_, _, e) => match &*p_.kind {
                            crate::syntax::PatternKind::PName(n) => if crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")) {
                                prism_rtl::Turn::Finished(s.clone())
                            } else {
                                match get(&env.locals, &crate::check::env::sname_key(n)) {
                                    Some(_) => prism_rtl::Turn::Finished(s.clone()),
                                    None => if calls_local_maker(&env, e) {
                                        prism_rtl::Turn::Finished(crate::check::types::err_fix(&s, &Text::lit("local-escapes"), &stmt.span, &Text::from(format!("a `Buffer` cannot leave its block: `{}` is no `&` local", &crate::check::env::sname_key(n))), &Text::from(format!("write `let &{} = ...`", &crate::check::env::sname_key(n)))))
                                    } else {
                                        prism_rtl::Turn::Finished(s.clone())
                                    },
                                }
                            },
                            _ => prism_rtl::Turn::Finished(s.clone()),
                        },
                        crate::syntax::StmtKind::SWhile(_, body) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone() })),
                        crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                            crate::syntax::ExprKind::EIf(_, tb, eb_opt) => {
                                let eb_opt = eb_opt.clone();
                                let tb = tb.clone();
                                call_then(start_escape_stmts(env.clone(), s.clone(), tb.stmts.clone()), move |escape_stmts_33232: crate::check::types::St| {
                                    let s2 = escape_stmts_33232;
                                    match &eb_opt {
                                        Some(x) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s2.clone(), stmts: x.stmts.clone() })),
                                        None => prism_rtl::Turn::Finished(s2.clone()),
                                    }
                                })
                            },
                            crate::syntax::ExprKind::EMatch(_, arms) => fold_job(arms.clone(), s.clone(), {
                                let env = env.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                    let env = env.clone();
                                    entered(once_job(move || {
                                        let s3 = p0;
                                        let a = p1;
                                        prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s3.clone(), stmts: a.body.stmts.clone() }))
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }).cycle(),
                            crate::syntax::ExprKind::EFor(_, _, body) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone() })),
                            _ => prism_rtl::Turn::Finished(s.clone()),
                        },
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    }
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start EscapeStmts, x`: what the function value is when passed to `@Run`.
pub fn start_escape_stmts(env: crate::check::expr::Env, st: crate::check::types::St, stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(EscapeStmts { env, st, stmts })
}

/// ```prism
/// CallsLocalMaker: fn Env, Expr -> Bool
/// ```
pub fn calls_local_maker(env: &crate::check::expr::Env, e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::ECall(c, _, _, _) => &maker_of(env, &**c) != &None,
        crate::syntax::ExprKind::EName(_) => match maker_of(env, e) {
            Some(k) => &k != &Text::lit("Buffer.Numbered"),
            None => false,
        },
        crate::syntax::ExprKind::EGroup(x) => calls_local_maker(env, &**x),
        _ => false,
    }
}

/// ```prism
/// ?MakerOf: fn Env, Expr -> ?Text
/// ```
pub fn maker_of(env: &crate::check::expr::Env, c: &crate::syntax::Expr) -> Option<Text> {
    match crate::check::shrink::callee_name(c) {
        Some(n) => if crate::check::env::has_key(&env.locals, &n) {
            None
        } else {
            match crate::check::shrink::resolve_name(&env.g, &env.home, &n) {
                Some(k) => if crate::check::expr::is_local_maker(&k) && (&or(&get(&env.g.vals, &k), &crate::check::dummy_val()).sort == &Text::lit("builtin")) {
                    Some(k.clone())
                } else {
                    None
                },
                None => None,
            }
        },
        None => None,
    }
}

/// ```prism
/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
/// ```
pub fn frozen_stmts(env: &crate::check::expr::Env, st: &crate::check::types::St, stmts: &Array<crate::syntax::Stmt>, frozen: &Map<Text, Nat>) -> (Map<Text, Nat>, crate::check::types::St) {
    let pre = crate::check::shrink::prelude_seeds(&env.g, &env.home);
    let seeds = fold(&keys(&pre), &pre, &(|m: &Map<Text, crate::check::shrink::Rel>, k: &Text| if crate::check::env::has_key(&env.locals, &crate::syntax::lexer::drop_prefix(k, &Text::lit("pre:"))) {
        remove(m, k)
    } else {
        m.clone()
    }));
    let bm = crate::check::shrink::block_rels(stmts, &seeds);
    run_to_end(fold_job(stmts.clone(), (frozen.clone(), st.clone()), {
        let bm = bm.clone();
        let env = env.clone();
        Rc::new(move |(p0, p1): ((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)| {
            let bm = bm.clone();
            let env = env.clone();
            entered(once_job(move || {
                let (fz, s) = p0;
                let stmt = p1;
                call_then(crate::check::shrink::start_stmt_spots(stmt.clone(), bm.clone()), move |stmt_spots_35097: Array<crate::check::shrink::Spot>| {
                    let spots = stmt_spots_35097;
                    let reads = fold(&spots, &Array::new(), &(|acc: &Array<(Text, crate::syntax::Range)>, sp: &crate::check::shrink::Spot| append(acc, &spot_refs(sp))));
                    let s2 = fold(&reads, &s, &(|s1: &crate::check::types::St, (n, sp): &(Text, crate::syntax::Range)| match get(&fz, n) {
                        Some(line) => crate::check::types::err_fix(s1, &Text::lit("frozen"), sp, &Text::from(format!("`{}` was frozen on line {}", n, &(&line + &Nat::from(1u32)))), &Text::lit("use the frozen value, or make a new local")),
                        None => s1.clone(),
                    }));
                    let fz1 = match &stmt.kind {
                        crate::syntax::StmtKind::SLet(p_, _, _) => fold(&crate::check::env::pattern_names(p_), &fz, &(|m: &Map<Text, Nat>, n: &Text| remove(m, n))),
                        _ => fz.clone(),
                    };
                    call_value(fold_job(spots.clone(), fz1.clone(), {
                        let env = env.clone();
                        let stmt = stmt.clone();
                        Rc::new(move |(p0, p1): (Map<Text, Nat>, crate::check::shrink::Spot)| {
                            let env = env.clone();
                            let stmt = stmt.clone();
                            entered(once_job(move || {
                                let m = p0;
                                let sp = p1;
                                call_then(start_spot_freezes(sp.clone()), move |spot_freezes_35595: Array<Text>| prism_rtl::Turn::Finished(fold(&spot_freezes_35595, &m, &(|m2: &Map<Text, Nat>, n: &Text| insert(m2, n, &crate::check::errors::cline_of(&env.src.starts, &stmt.span.start))))))
                            }))
                        }) as Rc<dyn Fn((Map<Text, Nat>, crate::check::shrink::Spot)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
                    }), move |fold_35563: Map<Text, Nat>| {
                        let fz2 = fold_35563;
                        prism_rtl::Turn::Finished((fz2.clone(), s2.clone()))
                    })
                })
            }))
        }) as Rc<dyn Fn(((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)>>>
    }))
}

/// The step machine of `FrozenStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
/// ```
pub struct FrozenStmts {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub stmts: Array<crate::syntax::Stmt>,
    pub frozen: Map<Text, Nat>,
}

impl prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)> for FrozenStmts {
    fn cycle(&self) -> prism_rtl::Turn<(Map<Text, Nat>, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        let frozen = &self.frozen;
        let pre = crate::check::shrink::prelude_seeds(&env.g, &env.home);
        let seeds = fold(&keys(&pre), &pre, &(|m: &Map<Text, crate::check::shrink::Rel>, k: &Text| if crate::check::env::has_key(&env.locals, &crate::syntax::lexer::drop_prefix(k, &Text::lit("pre:"))) {
            remove(m, k)
        } else {
            m.clone()
        }));
        let env = env.clone();
        let frozen = frozen.clone();
        let st = st.clone();
        let stmts = stmts.clone();
        call_then(crate::check::shrink::start_block_rels(stmts.clone(), seeds.clone()), move |block_rels_35003: Map<Text, crate::check::shrink::Rel>| {
            let bm = block_rels_35003;
            fold_job(stmts.clone(), (frozen.clone(), st.clone()), {
                let bm = bm.clone();
                let env = env.clone();
                Rc::new(move |(p0, p1): ((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)| {
                    let bm = bm.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let (fz, s) = p0;
                        let stmt = p1;
                        call_then(crate::check::shrink::start_stmt_spots(stmt.clone(), bm.clone()), move |stmt_spots_35097: Array<crate::check::shrink::Spot>| {
                            let spots = stmt_spots_35097;
                            let reads = fold(&spots, &Array::new(), &(|acc: &Array<(Text, crate::syntax::Range)>, sp: &crate::check::shrink::Spot| append(acc, &spot_refs(sp))));
                            let s2 = fold(&reads, &s, &(|s1: &crate::check::types::St, (n, sp): &(Text, crate::syntax::Range)| match get(&fz, n) {
                                Some(line) => crate::check::types::err_fix(s1, &Text::lit("frozen"), sp, &Text::from(format!("`{}` was frozen on line {}", n, &(&line + &Nat::from(1u32)))), &Text::lit("use the frozen value, or make a new local")),
                                None => s1.clone(),
                            }));
                            let fz1 = match &stmt.kind {
                                crate::syntax::StmtKind::SLet(p_, _, _) => fold(&crate::check::env::pattern_names(p_), &fz, &(|m: &Map<Text, Nat>, n: &Text| remove(m, n))),
                                _ => fz.clone(),
                            };
                            call_value(fold_job(spots.clone(), fz1.clone(), {
                                let env = env.clone();
                                let stmt = stmt.clone();
                                Rc::new(move |(p0, p1): (Map<Text, Nat>, crate::check::shrink::Spot)| {
                                    let env = env.clone();
                                    let stmt = stmt.clone();
                                    entered(once_job(move || {
                                        let m = p0;
                                        let sp = p1;
                                        call_then(start_spot_freezes(sp.clone()), move |spot_freezes_35595: Array<Text>| prism_rtl::Turn::Finished(fold(&spot_freezes_35595, &m, &(|m2: &Map<Text, Nat>, n: &Text| insert(m2, n, &crate::check::errors::cline_of(&env.src.starts, &stmt.span.start))))))
                                    }))
                                }) as Rc<dyn Fn((Map<Text, Nat>, crate::check::shrink::Spot)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
                            }), move |fold_35563: Map<Text, Nat>| {
                                let fz2 = fold_35563;
                                prism_rtl::Turn::Finished((fz2.clone(), s2.clone()))
                            })
                        })
                    }))
                }) as Rc<dyn Fn(((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)>>>
            }).cycle()
        })
    }
}

/// `Start FrozenStmts, x`: what the function value is when passed to `@Run`.
pub fn start_frozen_stmts(env: crate::check::expr::Env, st: crate::check::types::St, stmts: Array<crate::syntax::Stmt>, frozen: Map<Text, Nat>) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)>> {
    Rc::new(FrozenStmts { env, st, stmts, frozen })
}

/// ```prism
/// SpotRefs: fn Spot -> [((Text, Range))]
/// ```
pub fn spot_refs(spot0: &crate::check::shrink::Spot) -> Array<(Text, crate::syntax::Range)> {
    match spot0 {
        crate::check::shrink::Spot::SpotExpr(e, _) => match &*e.kind {
            crate::syntax::ExprKind::EName(n) => if crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")) {
                Array::from(vec![(crate::check::env::sname_key(n), n.span.clone())])
            } else {
                Array::new()
            },
            _ => Array::new(),
        },
        crate::check::shrink::Spot::SpotStmt(_, _) => Array::new(),
    }
}

/// ```prism
/// SpotFreezes: unbounded fn Spot -> [Text]
/// ```
pub fn spot_freezes(spot0: &crate::check::shrink::Spot) -> Array<Text> {
    match spot0 {
        crate::check::shrink::Spot::SpotExpr(e, m) => match crate::check::shrink::call_of(e) {
            Some((c, args)) => match crate::check::shrink::callee_name(&c) {
                Some(n) => if crate::check::shrink::pre_is(m, &n, &Text::lit("Freeze")) {
                    run_to_end(fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Arg)| entered(once_job(move || {
                        let acc = p0;
                        let a = p1;
                        prism_rtl::Turn::Finished(append(&acc, &each(&refs_in(&a.value), &(|(n2, _): &(Text, crate::syntax::Range)| n2.clone()))))
                    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
                } else {
                    Array::new()
                },
                None => Array::new(),
            },
            None => Array::new(),
        },
        crate::check::shrink::Spot::SpotStmt(_, _) => Array::new(),
    }
}

/// The step machine of `SpotFreezes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotFreezes: unbounded fn Spot -> [Text]
/// ```
pub struct SpotFreezes {
    pub spot0: crate::check::shrink::Spot,
}

impl prism_rtl::Job<Array<Text>> for SpotFreezes {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let spot0 = &self.spot0;
        match spot0 {
            crate::check::shrink::Spot::SpotExpr(e, m) => match crate::check::shrink::call_of(e) {
                Some((c, args)) => match crate::check::shrink::callee_name(&c) {
                    Some(n) => if crate::check::shrink::pre_is(m, &n, &Text::lit("Freeze")) {
                        fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Arg)| entered(once_job(move || {
                            let acc = p0;
                            let a = p1;
                            prism_rtl::Turn::Finished(append(&acc, &each(&refs_in(&a.value), &(|(n2, _): &(Text, crate::syntax::Range)| n2.clone()))))
                        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
                    } else {
                        prism_rtl::Turn::Finished(Array::new())
                    },
                    None => prism_rtl::Turn::Finished(Array::new()),
                },
                None => prism_rtl::Turn::Finished(Array::new()),
            },
            crate::check::shrink::Spot::SpotStmt(_, _) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start SpotFreezes, x`: what the function value is when passed to `@Run`.
pub fn start_spot_freezes(spot0: crate::check::shrink::Spot) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotFreezes { spot0 })
}

/// ```prism
/// RefsIn: unbounded fn Expr -> [((Text, Range))]
/// ```
pub fn refs_in(e: &crate::syntax::Expr) -> Array<(Text, crate::syntax::Range)> {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => if crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")) {
            Array::from(vec![(crate::check::env::sname_key(n), n.span.clone())])
        } else {
            Array::new()
        },
        crate::syntax::ExprKind::ECall(c, args, _, _) => run_to_end(fold_job(args.clone(), refs_in(&**c), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Arg)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            prism_rtl::Turn::Finished(append(&acc, &refs_in(&a.value)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::ExprKind::EBinary(_, l, r) => append(&refs_in(&**l), &refs_in(&**r)),
        crate::syntax::ExprKind::EUnary(_, x) => refs_in(&**x),
        crate::syntax::ExprKind::EFreeSigil(_, x) => refs_in(&**x),
        crate::syntax::ExprKind::EField(r, _, _) => refs_in(&**r),
        crate::syntax::ExprKind::EIndex(r, i) => append(&refs_in(&**r), &refs_in(&**i)),
        crate::syntax::ExprKind::EGroup(x) => refs_in(&**x),
        crate::syntax::ExprKind::ETuple(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)| entered(once_job(move || {
            let acc = p0;
            let x = p1;
            prism_rtl::Turn::Finished(append(&acc, &refs_in(&x)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::ExprKind::EArray(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)| entered(once_job(move || {
            let acc = p0;
            let x = p1;
            prism_rtl::Turn::Finished(append(&acc, &refs_in(&x)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        _ => Array::new(),
    }
}

/// ```prism
/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
/// ```
pub fn borrow_stmts(env: &crate::check::expr::Env, st: &crate::check::types::St, stmts: &Array<crate::syntax::Stmt>, lent: &Array<Array<Text>>) -> crate::check::types::St {
    run_to_end(fold_job(stmts.clone(), st.clone(), {
        let env = env.clone();
        let lent = lent.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
            let env = env.clone();
            let lent = lent.clone();
            entered(once_job(move || {
                let s = p0;
                let stmt = p1;
                match &stmt.kind {
                    crate::syntax::StmtKind::SSet(t, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env: env.clone(), st: s.clone(), t: t.clone(), lent: lent.clone() })),
                    crate::syntax::StmtKind::SAccum(t, _, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env: env.clone(), st: s.clone(), t: t.clone(), lent: lent.clone() })),
                    crate::syntax::StmtKind::SWhile(_, body) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone(), lent: lent.clone() })),
                    crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                        crate::syntax::ExprKind::EFor(binders_opt, source, body) => {
                            let binders_opt = binders_opt.clone();
                            let body = body.clone();
                            let source = (**source).clone();
                            call_then(start_ref_path(source.clone()), move |ref_path_37536: Array<Text>| {
                                let path_ = ref_path_37536;
                                let lent2 = if (&len(&path_) > &Nat::from(0u32)) && (&binders_opt != &None) {
                                    push(&lent, &path_)
                                } else {
                                    lent.clone()
                                };
                                prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone(), lent: lent2.clone() }))
                            })
                        },
                        crate::syntax::ExprKind::EIf(_, tb, eb_opt) => {
                            let eb_opt = eb_opt.clone();
                            let tb = tb.clone();
                            call_then(start_borrow_stmts(env.clone(), s.clone(), tb.stmts.clone(), lent.clone()), move |borrow_stmts_37741: crate::check::types::St| {
                                let s2 = borrow_stmts_37741;
                                match &eb_opt {
                                    Some(x) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s2.clone(), stmts: x.stmts.clone(), lent: lent.clone() })),
                                    None => prism_rtl::Turn::Finished(s2.clone()),
                                }
                            })
                        },
                        crate::syntax::ExprKind::EMatch(_, arms) => fold_job(arms.clone(), s.clone(), {
                            let env = env.clone();
                            let lent = lent.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                let env = env.clone();
                                let lent = lent.clone();
                                entered(once_job(move || {
                                    let s3 = p0;
                                    let a = p1;
                                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s3.clone(), stmts: a.body.stmts.clone(), lent: lent.clone() }))
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle(),
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    },
                    _ => prism_rtl::Turn::Finished(s.clone()),
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `BorrowStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
/// ```
pub struct BorrowStmts {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub stmts: Array<crate::syntax::Stmt>,
    pub lent: Array<Array<Text>>,
}

impl prism_rtl::Job<crate::check::types::St> for BorrowStmts {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        let lent = &self.lent;
        fold_job(stmts.clone(), st.clone(), {
            let env = env.clone();
            let lent = lent.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
                let env = env.clone();
                let lent = lent.clone();
                entered(once_job(move || {
                    let s = p0;
                    let stmt = p1;
                    match &stmt.kind {
                        crate::syntax::StmtKind::SSet(t, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env: env.clone(), st: s.clone(), t: t.clone(), lent: lent.clone() })),
                        crate::syntax::StmtKind::SAccum(t, _, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env: env.clone(), st: s.clone(), t: t.clone(), lent: lent.clone() })),
                        crate::syntax::StmtKind::SWhile(_, body) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone(), lent: lent.clone() })),
                        crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                            crate::syntax::ExprKind::EFor(binders_opt, source, body) => {
                                let binders_opt = binders_opt.clone();
                                let body = body.clone();
                                let source = (**source).clone();
                                call_then(start_ref_path(source.clone()), move |ref_path_37536: Array<Text>| {
                                    let path_ = ref_path_37536;
                                    let lent2 = if (&len(&path_) > &Nat::from(0u32)) && (&binders_opt != &None) {
                                        push(&lent, &path_)
                                    } else {
                                        lent.clone()
                                    };
                                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone(), lent: lent2.clone() }))
                                })
                            },
                            crate::syntax::ExprKind::EIf(_, tb, eb_opt) => {
                                let eb_opt = eb_opt.clone();
                                let tb = tb.clone();
                                call_then(start_borrow_stmts(env.clone(), s.clone(), tb.stmts.clone(), lent.clone()), move |borrow_stmts_37741: crate::check::types::St| {
                                    let s2 = borrow_stmts_37741;
                                    match &eb_opt {
                                        Some(x) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s2.clone(), stmts: x.stmts.clone(), lent: lent.clone() })),
                                        None => prism_rtl::Turn::Finished(s2.clone()),
                                    }
                                })
                            },
                            crate::syntax::ExprKind::EMatch(_, arms) => fold_job(arms.clone(), s.clone(), {
                                let env = env.clone();
                                let lent = lent.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                    let env = env.clone();
                                    let lent = lent.clone();
                                    entered(once_job(move || {
                                        let s3 = p0;
                                        let a = p1;
                                        prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s3.clone(), stmts: a.body.stmts.clone(), lent: lent.clone() }))
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }).cycle(),
                            _ => prism_rtl::Turn::Finished(s.clone()),
                        },
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    }
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start BorrowStmts, x`: what the function value is when passed to `@Run`.
pub fn start_borrow_stmts(env: crate::check::expr::Env, st: crate::check::types::St, stmts: Array<crate::syntax::Stmt>, lent: Array<Array<Text>>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(BorrowStmts { env, st, stmts, lent })
}

/// ```prism
/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
/// ```
pub fn check_lent(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::syntax::Expr, lent: &Array<Array<Text>>) -> crate::check::types::St {
    let path_ = ref_path(t);
    fold(lent, st, &(|s: &crate::check::types::St, l: &Array<Text>| if ((&len(&path_) > &Nat::from(0u32)) && is_prefix(l, &path_)) || is_prefix(&path_, l) {
        crate::check::types::err_fix(s, &Text::lit("borrow-overlap"), &t.span, &Text::from(format!("`{}` is lent to the `for`", &crate::syntax::lexer::join(l, &Text::lit(".")))), &Text::lit("set it after the loop, or loop over a copy"))
    } else {
        s.clone()
    }))
}

/// The step machine of `CheckLent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
/// ```
pub struct CheckLent {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Expr,
    pub lent: Array<Array<Text>>,
}

impl prism_rtl::Job<crate::check::types::St> for CheckLent {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let lent = &self.lent;
        let lent = lent.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_ref_path(t.clone()), move |ref_path_38112: Array<Text>| {
            let path_ = ref_path_38112;
            prism_rtl::Turn::Finished(fold(&lent, &st, &(|s: &crate::check::types::St, l: &Array<Text>| if ((&len(&path_) > &Nat::from(0u32)) && is_prefix(l, &path_)) || is_prefix(&path_, l) {
                crate::check::types::err_fix(s, &Text::lit("borrow-overlap"), &t.span, &Text::from(format!("`{}` is lent to the `for`", &crate::syntax::lexer::join(l, &Text::lit(".")))), &Text::lit("set it after the loop, or loop over a copy"))
            } else {
                s.clone()
            })))
        })
    }
}

/// `Start CheckLent, x`: what the function value is when passed to `@Run`.
pub fn start_check_lent(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::syntax::Expr, lent: Array<Array<Text>>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckLent { env, st, t, lent })
}

/// ```prism
/// IsPrefix: fn [Text], [Text] -> Bool
/// ```
pub fn is_prefix(a: &Array<Text>, b: &Array<Text>) -> bool {
    (&len(a) <= &len(b)) && (&take(b, &len(a)) == a)
}

/// ```prism
/// RefPath: unbounded fn Expr -> [Text]
/// ```
pub fn ref_path(e: &crate::syntax::Expr) -> Array<Text> {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => if crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")) {
            Array::from(vec![crate::check::env::sname_key(n)])
        } else {
            Array::new()
        },
        crate::syntax::ExprKind::EField(r, _, f) => {
            let p_ = ref_path(&**r);
            if &len(&p_) > &Nat::from(0u32) { push(&p_, &f.name) } else { p_.clone() }
        },
        crate::syntax::ExprKind::EIndex(r, _) => {
            let p_ = ref_path(&**r);
            if &len(&p_) > &Nat::from(0u32) { push(&p_, &Text::lit("[]")) } else { p_.clone() }
        },
        crate::syntax::ExprKind::EGroup(x) => ref_path(&**x),
        _ => Array::new(),
    }
}

/// The step machine of `RefPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RefPath: unbounded fn Expr -> [Text]
/// ```
pub struct RefPath {
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<Array<Text>> for RefPath {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EName(n) => if crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")) {
                prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::sname_key(n)]))
            } else {
                prism_rtl::Turn::Finished(Array::new())
            },
            crate::syntax::ExprKind::EField(r, _, f) => {
                let f = f.clone();
                let r = (**r).clone();
                call_then(start_ref_path(r.clone()), move |ref_path_38702: Array<Text>| {
                    let p_ = ref_path_38702;
                    if &len(&p_) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(push(&p_, &f.name))
                    } else {
                        prism_rtl::Turn::Finished(p_.clone())
                    }
                })
            },
            crate::syntax::ExprKind::EIndex(r, _) => {
                let r = (**r).clone();
                call_then(start_ref_path(r.clone()), move |ref_path_38797: Array<Text>| {
                    let p_ = ref_path_38797;
                    if &len(&p_) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(push(&p_, &Text::lit("[]")))
                    } else {
                        prism_rtl::Turn::Finished(p_.clone())
                    }
                })
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(RefPath { e: (**x).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start RefPath, x`: what the function value is when passed to `@Run`.
pub fn start_ref_path(e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RefPath { e })
}
