//! The module `Check.Passes`, from `target/bootstrap/src/prismc/check/passes/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod borrows;
pub mod cycles;

/// `Ctor`:
///
/// ```prism
/// type Ctor = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Ctor {
    pub name: Text,
    pub arity: Nat,
    pub args: Array<crate::check::types::Ty>,
    pub shown: Text,
}

impl Show for Ctor {
    fn show(&self, p: &mut Printer) {
        p.record("Ctor", &[("name", &self.name), ("arity", &self.arity), ("args", &self.args), ("shown", &self.shown)]);
    }
}

impl ToPod for Ctor {
    fn to_pod(&self) -> Pod {
        Pod::record("Ctor", vec![("name", self.name.to_pod()), ("arity", self.arity.to_pod()), ("args", self.args.to_pod()), ("shown", self.shown.to_pod())])
    }
}

impl FromPod for Ctor {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Ctor { name: FromPod::from_pod(field(p, "name")?)?, arity: FromPod::from_pod(field(p, "arity")?)?, args: FromPod::from_pod(field(p, "args")?)?, shown: FromPod::from_pod(field(p, "shown")?)? })
    }
}

/// `Pat`:
///
/// ```prism
/// type Pat = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Pat {
    PtAny,
    PtCon(Text, Array<Pat>),
    PtLit(Text),
    PtFam(Text),
}

impl Show for Pat {
    fn show(&self, p: &mut Printer) {
        match self {
            Pat::PtAny => p.choice("PtAny", &[]),
            Pat::PtCon(a0, a1) => p.choice("PtCon", &[a0, a1]),
            Pat::PtLit(a0) => p.choice("PtLit", &[a0]),
            Pat::PtFam(a0) => p.choice("PtFam", &[a0]),
        }
    }
}

impl ToPod for Pat {
    fn to_pod(&self) -> Pod {
        match self {
            Pat::PtAny => Pod::Choice("PtAny".into(), vec![]),
            Pat::PtCon(a0, a1) => Pod::Choice("PtCon".into(), vec![a0.to_pod(), a1.to_pod()]),
            Pat::PtLit(a0) => Pod::Choice("PtLit".into(), vec![a0.to_pod()]),
            Pat::PtFam(a0) => Pod::Choice("PtFam".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Pat {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "PtAny" && a.len() == 0 => Ok(Pat::PtAny),
            Pod::Choice(c, a) if &**c == "PtCon" && a.len() == 2 => Ok(Pat::PtCon(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "PtLit" && a.len() == 1 => Ok(Pat::PtLit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PtFam" && a.len() == 1 => Ok(Pat::PtFam(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Pat", other),
        }
    }
}

/// ```prism
/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
/// ```
pub fn ctors_of(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::check::types::Ty) -> Option<Array<Ctor>> {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyCon(m2894_0_0, m2894_0_1) if (&m2894_0_0 == &Text::lit("Bool")) && ((&m2894_0_1).len() == 0) => Some(Array::from(vec![Ctor { name: Text::lit("True"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("True") }, Ctor { name: Text::lit("False"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("False") }])),
        crate::check::types::Ty::TyCon(m2894_1_0, m2894_1_1) if (&m2894_1_0 == &Text::lit("unit")) && ((&m2894_1_1).len() == 0) => Some(Array::from(vec![Ctor { name: Text::lit("unit"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("unit") }])),
        crate::check::types::Ty::TySig(m2894_2_0, i) if (&m2894_2_0 == &Text::lit("?")) => Some(Array::from(vec![Ctor { name: Text::lit("?"), arity: Nat::from(1u32), args: Array::from(vec![(*i).clone()]), shown: Text::lit("? _") }, Ctor { name: Text::lit("nil"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("nil") }])),
        crate::check::types::Ty::TySig(m2894_3_0, i) if (&m2894_3_0 == &Text::lit("~")) => Some(Array::from(vec![Ctor { name: Text::lit("~"), arity: Nat::from(1u32), args: Array::from(vec![(*i).clone()]), shown: Text::lit("~ _") }, Ctor { name: Text::lit("Error"), arity: Nat::from(2u32), args: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text()]), shown: Text::lit("Error(..)") }])),
        crate::check::types::Ty::TyTuple(ts) => Some(Array::from(vec![Ctor { name: Text::lit("tuple"), arity: len(&ts), args: ts.clone(), shown: Text::from(format!("(({}))", &crate::syntax::lexer::chars::join(&each(&ts, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", ")))) }])),
        crate::check::types::Ty::TyCon(m2894_5_0, m2894_5_1) if (&m2894_5_0 == &Text::lit("Prelude.Error")) && ((&m2894_5_1).len() == 0) => Some(Array::from(vec![Ctor { name: Text::lit("Error"), arity: Nat::from(2u32), args: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text()]), shown: Text::lit("Error(..)") }])),
        crate::check::types::Ty::TyCon(n, args) => match get(&env.g.types, &n) {
            Some(ti) => match &ti.body {
                crate::check::env::TyBody::BChoice(cases) => Some(run_to_end(each_job(cases.clone(), {
                    let ti = ti.clone();
                    let args = args.clone();
                    Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                        let ti = ti.clone();
                        let args = args.clone();
                        entered(once_job(move || {
                            let (cn, cargs) = p0;
                            prism_rtl::Turn::More(Rc::new(CtorOfCase { ti: ti.clone(), cn: cn.clone(), cargs: cargs.clone(), args: args.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<Ctor>>>
                }))),
                crate::check::env::TyBody::BRecord(fields) => Some(Array::from(vec![Ctor { name: n.clone(), arity: len(fields), args: run_to_end(each_job(fields.clone(), {
                    let ti = ti.clone();
                    let args = args.clone();
                    Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                        let ti = ti.clone();
                        let args = args.clone();
                        entered(once_job(move || {
                            let (_, ft) = p0;
                            prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m: crate::check::env::reading::param_inst(&ti.params, &args), t: ft.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                })), shown: Text::from(format!("{}(..)", &crate::check::types::bare_name(&n))) }])),
                crate::check::env::TyBody::BRowKind => if is_root_module(env) {
                    Some(each(&tags_of_kind(env, &n), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg))))
                } else {
                    None
                },
                _ => None,
            },
            None => if (&n == &Text::lit("Fault")) || (&n == &Text::lit("Prelude.Fault")) {
                if is_root_module(env) {
                    Some(each(&tags_of_kind(env, &Text::lit("Prelude.Fault")), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg))))
                } else {
                    None
                }
            } else {
                None
            },
        },
        crate::check::types::Ty::TyElem(rw, _) => {
            let w = crate::check::types::recording::walk_row(st, &rw);
            if &w.tail != &crate::check::types::Tail::TlClosed {
                None
            } else {
                Some(each(&tags_of_row(env, &w), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg))))
            }
        },
        crate::check::types::Ty::TyElemAny(rw) => {
            let w = crate::check::types::recording::walk_row(st, &rw);
            if &w.tail != &crate::check::types::Tail::TlClosed {
                None
            } else {
                Some(each(&tags_of_row(env, &w), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg))))
            }
        },
        _ => None,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CtorsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
/// ```
pub struct CtorsOf {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Option<Array<Ctor>>> for CtorsOf {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<Ctor>>> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_2900: crate::check::types::Ty| match walk_2900 {
            crate::check::types::Ty::TyCon(m2894_0_0, m2894_0_1) if (&m2894_0_0 == &Text::lit("Bool")) && ((&m2894_0_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("True"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("True") }, Ctor { name: Text::lit("False"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("False") }]))),
            crate::check::types::Ty::TyCon(m2894_1_0, m2894_1_1) if (&m2894_1_0 == &Text::lit("unit")) && ((&m2894_1_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("unit"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("unit") }]))),
            crate::check::types::Ty::TySig(m2894_2_0, i) if (&m2894_2_0 == &Text::lit("?")) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("?"), arity: Nat::from(1u32), args: Array::from(vec![(*i).clone()]), shown: Text::lit("? _") }, Ctor { name: Text::lit("nil"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("nil") }]))),
            crate::check::types::Ty::TySig(m2894_3_0, i) if (&m2894_3_0 == &Text::lit("~")) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("~"), arity: Nat::from(1u32), args: Array::from(vec![(*i).clone()]), shown: Text::lit("~ _") }, Ctor { name: Text::lit("Error"), arity: Nat::from(2u32), args: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text()]), shown: Text::lit("Error(..)") }]))),
            crate::check::types::Ty::TyTuple(ts) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("tuple"), arity: len(&ts), args: ts.clone(), shown: Text::from(format!("(({}))", &crate::syntax::lexer::chars::join(&each(&ts, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", ")))) }]))),
            crate::check::types::Ty::TyCon(m2894_5_0, m2894_5_1) if (&m2894_5_0 == &Text::lit("Prelude.Error")) && ((&m2894_5_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("Error"), arity: Nat::from(2u32), args: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text()]), shown: Text::lit("Error(..)") }]))),
            crate::check::types::Ty::TyCon(n, args) => match get(&env.g.types, &n) {
                Some(ti) => match &ti.body {
                    crate::check::env::TyBody::BChoice(cases) => prism_rtl::Turn::Finished(Some(run_to_end(each_job(cases.clone(), {
                        let ti = ti.clone();
                        let args = args.clone();
                        Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                            let ti = ti.clone();
                            let args = args.clone();
                            entered(once_job(move || {
                                let (cn, cargs) = p0;
                                prism_rtl::Turn::More(Rc::new(CtorOfCase { ti: ti.clone(), cn: cn.clone(), cargs: cargs.clone(), args: args.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<Ctor>>>
                    })))),
                    crate::check::env::TyBody::BRecord(fields) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: n.clone(), arity: len(fields), args: run_to_end(each_job(fields.clone(), {
                        let ti = ti.clone();
                        let args = args.clone();
                        Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                            let ti = ti.clone();
                            let args = args.clone();
                            entered(once_job(move || {
                                let (_, ft) = p0;
                                prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m: crate::check::env::reading::param_inst(&ti.params, &args), t: ft.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                    })), shown: Text::from(format!("{}(..)", &crate::check::types::bare_name(&n))) }]))),
                    crate::check::env::TyBody::BRowKind => if is_root_module(&env) {
                        prism_rtl::Turn::Finished(Some(each(&tags_of_kind(&env, &n), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg)))))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    },
                    _ => prism_rtl::Turn::Finished(None),
                },
                None => if (&n == &Text::lit("Fault")) || (&n == &Text::lit("Prelude.Fault")) {
                    if is_root_module(&env) {
                        prism_rtl::Turn::Finished(Some(each(&tags_of_kind(&env, &Text::lit("Prelude.Fault")), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg)))))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    }
                } else {
                    prism_rtl::Turn::Finished(None)
                },
            },
            crate::check::types::Ty::TyElem(rw, _) => call_then(crate::check::types::recording::start_walk_row(st.clone(), rw.clone()), move |walk_row_4329: crate::check::types::Rw| {
                let w = walk_row_4329;
                if &w.tail != &crate::check::types::Tail::TlClosed {
                    prism_rtl::Turn::Finished(None)
                } else {
                    prism_rtl::Turn::Finished(Some(each(&tags_of_row(&env, &w), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg)))))
                }
            }),
            crate::check::types::Ty::TyElemAny(rw) => call_then(crate::check::types::recording::start_walk_row(st.clone(), rw.clone()), move |walk_row_4473: crate::check::types::Rw| {
                let w = walk_row_4473;
                if &w.tail != &crate::check::types::Tail::TlClosed {
                    prism_rtl::Turn::Finished(None)
                } else {
                    prism_rtl::Turn::Finished(Some(each(&tags_of_row(&env, &w), &(|tg: &crate::check::env::TagInfo| tag_ctor(tg)))))
                }
            }),
            _ => prism_rtl::Turn::Finished(None),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start CtorsOf, x`: what the function value is when passed to `@Run`.
pub fn start_ctors_of(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Option<Array<Ctor>>>> {
    Rc::new(CtorsOf { env, st, t })
}

/// ```prism
/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
/// ```
pub fn ctor_of_case(ti: &crate::check::env::TyInfo, cn: &Text, cargs: &Array<crate::check::types::Ty>, args: &Array<crate::check::types::Ty>) -> Ctor {
    let qk = crate::check::env::qual_key(&ti.home, cn);
    Ctor { name: qk.clone(), arity: len(cargs), args: run_to_end(each_job(cargs.clone(), {
        let ti = ti.clone();
        let args = args.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let ti = ti.clone();
            let args = args.clone();
            entered(once_job(move || {
                let a = p0;
                prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m: crate::check::env::reading::param_inst(&ti.params, &args), t: a.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
    })), shown: if &len(cargs) == &Nat::from(0u32) {
        cn.clone()
    } else {
        Text::from(format!("{} {}", cn, &crate::syntax::lexer::chars::join(&each(cargs, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", "))))
    } }
}

/// The step machine of `CtorOfCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
/// ```
pub struct CtorOfCase {
    pub ti: crate::check::env::TyInfo,
    pub cn: Text,
    pub cargs: Array<crate::check::types::Ty>,
    pub args: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<Ctor> for CtorOfCase {
    fn cycle(&self) -> prism_rtl::Turn<Ctor> {
        let ti = &self.ti;
        let cn = &self.cn;
        let cargs = &self.cargs;
        let args = &self.args;
        let qk = crate::check::env::qual_key(&ti.home, cn);
        let args = args.clone();
        let cargs = cargs.clone();
        let cn = cn.clone();
        let ti = ti.clone();
        call_value(each_job(cargs.clone(), {
            let ti = ti.clone();
            let args = args.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let ti = ti.clone();
                let args = args.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m: crate::check::env::reading::param_inst(&ti.params, &args), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }), move |each_4772: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(Ctor { name: qk.clone(), arity: len(&cargs), args: each_4772, shown: if &len(&cargs) == &Nat::from(0u32) {
            cn.clone()
        } else {
            Text::from(format!("{} {}", &cn, &crate::syntax::lexer::chars::join(&each(&cargs, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", "))))
        } }))
    }
}

/// `Start CtorOfCase, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_of_case(ti: crate::check::env::TyInfo, cn: Text, cargs: Array<crate::check::types::Ty>, args: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<Ctor>> {
    Rc::new(CtorOfCase { ti, cn, cargs, args })
}

/// ```prism
/// TagCtor: fn TagInfo -> Ctor
/// ```
pub fn tag_ctor(tg: &crate::check::env::TagInfo) -> Ctor {
    Ctor { name: Text::from(format!("tag:{}", &tg.name)), arity: len(&tg.fields), args: each(&tg.fields, &(|(_, ft): &(Text, crate::check::types::Ty)| crate::check::types::Ty::TyErr)), shown: tg.name.clone() }
}

/// ```prism
/// IsRootModule: fn Env -> Bool
/// ```
pub fn is_root_module(env: &crate::check::expr::Env) -> bool {
    &env.home == &Text::lit("")
}

/// ```prism
/// TagsOfKind: fn Env, Text -> [TagInfo]
/// ```
pub fn tags_of_kind(env: &crate::check::expr::Env, kind: &Text) -> Array<crate::check::env::TagInfo> {
    filter(&values(&env.g.tags), &(|tg: &crate::check::env::TagInfo| (&tg.kind == kind) || ((&crate::check::types::bare_name(&tg.kind) == &Text::lit("Fault")) && (&crate::check::types::bare_name(kind) == &Text::lit("Fault")))))
}

/// ```prism
/// TagsOfRow: fn Env, Rw -> [TagInfo]
/// ```
pub fn tags_of_row(env: &crate::check::expr::Env, w: &crate::check::types::Rw) -> Array<crate::check::env::TagInfo> {
    filter(&values(&env.g.tags), &(|tg: &crate::check::env::TagInfo| ((&tg.kind == &Text::lit("Element")) && crate::check::types::has_text(&w.fams, &tg.family)) && !crate::check::types::has_text(&w.minus, &tg.name)))
}

/// ```prism
/// ToPat: unbounded fn Env, Pattern -> Pat
/// ```
pub fn to_pat(env: &crate::check::expr::Env, p_: &crate::syntax::Pattern_) -> Pat {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => {
            let bare = or(&index(&n.path_, &Nat::from(0u32)), &Text::lit(""));
            if (&len(&n.path_) > &Nat::from(1u32)) && crate::check::env::has_key(&env.g.tags, &crate::check::env::dotted(&n.path_)) {
                Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted(&n.path_))), Array::new())
            } else {
                if (crate::check::env::is_upper_text(&bare) && (&len_text(&n.sigils) == &Nat::from(0u32))) && crate::check::expr::patterns::is_ctor_name(env, n) {
                    Pat::PtCon(ctor_key(env, n), Array::new())
                } else {
                    Pat::PtAny
                }
            }
        },
        crate::syntax::PatternKind::PIgnore => Pat::PtAny,
        crate::syntax::PatternKind::PLit(l) => Pat::PtLit(lit_text(l)),
        crate::syntax::PatternKind::PNeg(l) => Pat::PtLit(Text::from(format!("-{}", &lit_text(l)))),
        crate::syntax::PatternKind::PUnit => Pat::PtCon(Text::lit("unit"), Array::new()),
        crate::syntax::PatternKind::PNil => Pat::PtCon(Text::lit("nil"), Array::new()),
        crate::syntax::PatternKind::PCtor(n, args) => if crate::check::env::has_key(&env.g.tags, &crate::check::env::dotted(&n.path_)) {
            Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted(&n.path_))), Array::new())
        } else {
            Pat::PtCon(ctor_key(env, n), run_to_end(each_job(args.clone(), {
                let env = env.clone();
                Rc::new(move |p0: crate::syntax::Pattern_| {
                    let env = env.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: a.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
        crate::syntax::PatternKind::PRecord(n, fields, _) => record_pat(env, n, fields),
        crate::syntax::PatternKind::PSigil(s, q) => Pat::PtCon(s.clone(), Array::from(vec![to_pat(env, &**q)])),
        crate::syntax::PatternKind::PTuple(ps) => Pat::PtCon(Text::lit("tuple"), run_to_end(each_job(ps.clone(), {
            let env = env.clone();
            Rc::new(move |p0: crate::syntax::Pattern_| {
                let env = env.clone();
                entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: q.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
        }))),
        crate::syntax::PatternKind::PArray(ps) => Pat::PtCon(Text::from(format!("len{}", &len(ps))), run_to_end(each_job(ps.clone(), {
            let env = env.clone();
            Rc::new(move |p0: crate::syntax::Pattern_| {
                let env = env.clone();
                entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: q.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
        }))),
        crate::syntax::PatternKind::PGroup(q) => to_pat(env, &**q),
        crate::syntax::PatternKind::PFamily(q) => Pat::PtFam(crate::check::env::dotted(&q.path_)),
    }
}

/// The step machine of `ToPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPat: unbounded fn Env, Pattern -> Pat
/// ```
pub struct ToPat {
    pub env: crate::check::expr::Env,
    pub p_: crate::syntax::Pattern_,
}

impl prism_rtl::Job<Pat> for ToPat {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env = &self.env;
        let p_ = &self.p_;
        match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => {
                let bare = or(&index(&n.path_, &Nat::from(0u32)), &Text::lit(""));
                if (&len(&n.path_) > &Nat::from(1u32)) && crate::check::env::has_key(&env.g.tags, &crate::check::env::dotted(&n.path_)) {
                    prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted(&n.path_))), Array::new()))
                } else {
                    if (crate::check::env::is_upper_text(&bare) && (&len_text(&n.sigils) == &Nat::from(0u32))) && crate::check::expr::patterns::is_ctor_name(env, n) {
                        prism_rtl::Turn::Finished(Pat::PtCon(ctor_key(env, n), Array::new()))
                    } else {
                        prism_rtl::Turn::Finished(Pat::PtAny)
                    }
                }
            },
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(Pat::PtAny),
            crate::syntax::PatternKind::PLit(l) => prism_rtl::Turn::Finished(Pat::PtLit(lit_text(l))),
            crate::syntax::PatternKind::PNeg(l) => prism_rtl::Turn::Finished(Pat::PtLit(Text::from(format!("-{}", &lit_text(l))))),
            crate::syntax::PatternKind::PUnit => prism_rtl::Turn::Finished(Pat::PtCon(Text::lit("unit"), Array::new())),
            crate::syntax::PatternKind::PNil => prism_rtl::Turn::Finished(Pat::PtCon(Text::lit("nil"), Array::new())),
            crate::syntax::PatternKind::PCtor(n, args) => if crate::check::env::has_key(&env.g.tags, &crate::check::env::dotted(&n.path_)) {
                prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted(&n.path_))), Array::new()))
            } else {
                {
                    let args = args.clone();
                    let env = env.clone();
                    let n = n.clone();
                    call_value(each_job(args.clone(), {
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Pattern_| {
                            let env = env.clone();
                            entered(once_job(move || {
                                let a = p0;
                                prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: a.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                    }), move |each_6274: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(ctor_key(&env, &n), each_6274)))
                }
            },
            crate::syntax::PatternKind::PRecord(n, fields, _) => prism_rtl::Turn::More(Rc::new(RecordPat { env: env.clone(), n: n.clone(), fields: fields.clone() })),
            crate::syntax::PatternKind::PSigil(s, q) => {
                let env = env.clone();
                let q = (**q).clone();
                let s = s.clone();
                call_then(start_to_pat(env.clone(), q.clone()), move |to_pat_6389: Pat| prism_rtl::Turn::Finished(Pat::PtCon(s.clone(), Array::from(vec![to_pat_6389]))))
            },
            crate::syntax::PatternKind::PTuple(ps) => {
                let env = env.clone();
                let ps = ps.clone();
                call_value(each_job(ps.clone(), {
                    let env = env.clone();
                    Rc::new(move |p0: crate::syntax::Pattern_| {
                        let env = env.clone();
                        entered(once_job(move || {
                            let q = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: q.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_6436: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::lit("tuple"), each_6436)))
            },
            crate::syntax::PatternKind::PArray(ps) => {
                let env = env.clone();
                let ps = ps.clone();
                call_value(each_job(ps.clone(), {
                    let env = env.clone();
                    Rc::new(move |p0: crate::syntax::Pattern_| {
                        let env = env.clone();
                        entered(once_job(move || {
                            let q = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: q.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_6501: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("len{}", &len(&ps))), each_6501)))
            },
            crate::syntax::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: (**q).clone() })),
            crate::syntax::PatternKind::PFamily(q) => prism_rtl::Turn::Finished(Pat::PtFam(crate::check::env::dotted(&q.path_))),
        }
    }
}

/// `Start ToPat, x`: what the function value is when passed to `@Run`.
pub fn start_to_pat(env: crate::check::expr::Env, p_: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(ToPat { env, p_ })
}

/// ```prism
/// LitText: fn Literal -> Text
/// ```
pub fn lit_text(l: &crate::syntax::Literal) -> Text {
    match &l.kind {
        crate::syntax::LitKind::LInt(d) => d.clone(),
        crate::syntax::LitKind::LFloat(d) => d.clone(),
        crate::syntax::LitKind::LChar(c) => Text::from(format!("'{}'", c)),
        crate::syntax::LitKind::LText(segs) => concat(&each(segs, &lit_seg_text)),
        crate::syntax::LitKind::LDuration(d, u) => Text::from(format!("{}{}", d, u)),
    }
}

/// ```prism
/// LitSegText: fn TextSeg -> Text
/// ```
pub fn lit_seg_text(text_seg0: &crate::syntax::TextSeg) -> Text {
    match text_seg0 {
        crate::syntax::TextSeg::SegPlain(t) => t.clone(),
        _ => Text::lit("{}"),
    }
}

/// ```prism
/// CtorKey: fn Env, SName -> Text
/// ```
pub fn ctor_key(env: &crate::check::expr::Env, n: &crate::syntax::SName) -> Text {
    let (qk_opt, _) = crate::check::env::names::resolve_value(&env.g, &env.home, n);
    or(&qk_opt, &crate::check::env::sname_key(n))
}

/// ```prism
/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
/// ```
pub fn record_pat(env: &crate::check::expr::Env, n: &crate::syntax::SName, fields: &Array<crate::syntax::FieldPat>) -> Pat {
    let name = crate::check::env::dotted(&n.path_);
    match get(&env.g.tags, &name) {
        Some(tg) => {
            let names = each(&tg.fields, &(|(f, _): &(Text, crate::check::types::Ty)| f.clone()));
            Pat::PtCon(Text::from(format!("tag:{}", &name)), run_to_end(each_job(names.clone(), {
                let env = env.clone();
                let fields = fields.clone();
                let names = names.clone();
                Rc::new(move |p0: Text| {
                    let env = env.clone();
                    let fields = fields.clone();
                    let names = names.clone();
                    entered(once_job(move || {
                        let f = p0;
                        prism_rtl::Turn::More(Rc::new(FieldPatFor { env: env.clone(), fields: fields.clone(), names: names.clone(), f: f.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
        None => {
            let qk = ctor_key(env, n);
            let fnames = if &crate::check::types::bare_name(&qk) == &Text::lit("Error") {
                Array::from(vec![Text::lit("kind"), Text::lit("message")])
            } else {
                or(&get(&env.g.ctors, &qk), &dummy_ctor()).fields.clone()
            };
            let pkey = if &crate::check::types::bare_name(&qk) == &Text::lit("Error") {
                Text::lit("Error")
            } else {
                qk.clone()
            };
            Pat::PtCon(pkey.clone(), run_to_end(each_job(fnames.clone(), {
                let env = env.clone();
                let fields = fields.clone();
                let fnames = fnames.clone();
                Rc::new(move |p0: Text| {
                    let env = env.clone();
                    let fields = fields.clone();
                    let fnames = fnames.clone();
                    entered(once_job(move || {
                        let f = p0;
                        prism_rtl::Turn::More(Rc::new(FieldPatFor { env: env.clone(), fields: fields.clone(), names: fnames.clone(), f: f.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
    }
}

/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
/// ```
pub struct RecordPat {
    pub env: crate::check::expr::Env,
    pub n: crate::syntax::SName,
    pub fields: Array<crate::syntax::FieldPat>,
}

impl prism_rtl::Job<Pat> for RecordPat {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env = &self.env;
        let n = &self.n;
        let fields = &self.fields;
        let name = crate::check::env::dotted(&n.path_);
        match get(&env.g.tags, &name) {
            Some(tg) => {
                let names = each(&tg.fields, &(|(f, _): &(Text, crate::check::types::Ty)| f.clone()));
                let env = env.clone();
                let fields = fields.clone();
                call_value(each_job(names.clone(), {
                    let env = env.clone();
                    let fields = fields.clone();
                    let names = names.clone();
                    Rc::new(move |p0: Text| {
                        let env = env.clone();
                        let fields = fields.clone();
                        let names = names.clone();
                        entered(once_job(move || {
                            let f = p0;
                            prism_rtl::Turn::More(Rc::new(FieldPatFor { env: env.clone(), fields: fields.clone(), names: names.clone(), f: f.clone() }))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_7340: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &name)), each_7340)))
            },
            None => {
                let qk = ctor_key(env, n);
                let fnames = if &crate::check::types::bare_name(&qk) == &Text::lit("Error") {
                    Array::from(vec![Text::lit("kind"), Text::lit("message")])
                } else {
                    or(&get(&env.g.ctors, &qk), &dummy_ctor()).fields.clone()
                };
                let pkey = if &crate::check::types::bare_name(&qk) == &Text::lit("Error") {
                    Text::lit("Error")
                } else {
                    qk.clone()
                };
                let env = env.clone();
                let fields = fields.clone();
                call_value(each_job(fnames.clone(), {
                    let env = env.clone();
                    let fields = fields.clone();
                    let fnames = fnames.clone();
                    Rc::new(move |p0: Text| {
                        let env = env.clone();
                        let fields = fields.clone();
                        let fnames = fnames.clone();
                        entered(once_job(move || {
                            let f = p0;
                            prism_rtl::Turn::More(Rc::new(FieldPatFor { env: env.clone(), fields: fields.clone(), names: fnames.clone(), f: f.clone() }))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_7656: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(pkey.clone(), each_7656)))
            },
        }
    }
}

/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
pub fn start_record_pat(env: crate::check::expr::Env, n: crate::syntax::SName, fields: Array<crate::syntax::FieldPat>) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(RecordPat { env, n, fields })
}

/// ```prism
/// let dummyCtor
/// ```
pub fn dummy_ctor() -> crate::check::env::CtorInfo {
    crate::check::env::CtorInfo { name: Text::lit(""), owner: Text::lit(""), params: Array::new(), args: Array::new(), fields: Array::new(), ty: crate::check::types::Ty::TyErr, index: Nat::from(0u32) }
}

/// ```prism
/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
/// ```
pub fn field_pat_for(env: &crate::check::expr::Env, fields: &Array<crate::syntax::FieldPat>, names: &Array<Text>, f: &Text) -> Pat {
    run_to_end(fold_job(crate::check::errors::range0(&len(fields)), Pat::PtAny, {
        let fields = fields.clone();
        let names = names.clone();
        let f = f.clone();
        let env = env.clone();
        Rc::new(move |(p0, p1): (Pat, Nat)| {
            let fields = fields.clone();
            let names = names.clone();
            let f = f.clone();
            let env = env.clone();
            entered(once_job(move || {
                let acc = p0;
                let i = p1;
                match index(&fields, &i) {
                    Some(fp) => if &crate::check::expr::patterns::field_pat_name(&fp, &names, &i) == &f {
                        prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: fp.pattern.clone() }))
                    } else {
                        prism_rtl::Turn::Finished(acc.clone())
                    },
                    None => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))
        }) as Rc<dyn Fn((Pat, Nat)) -> Rc<dyn prism_rtl::Job<Pat>>>
    }))
}

/// The step machine of `FieldPatFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
/// ```
pub struct FieldPatFor {
    pub env: crate::check::expr::Env,
    pub fields: Array<crate::syntax::FieldPat>,
    pub names: Array<Text>,
    pub f: Text,
}

impl prism_rtl::Job<Pat> for FieldPatFor {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env = &self.env;
        let fields = &self.fields;
        let names = &self.names;
        let f = &self.f;
        fold_job(crate::check::errors::range0(&len(fields)), Pat::PtAny, {
            let fields = fields.clone();
            let names = names.clone();
            let f = f.clone();
            let env = env.clone();
            Rc::new(move |(p0, p1): (Pat, Nat)| {
                let fields = fields.clone();
                let names = names.clone();
                let f = f.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let i = p1;
                    match index(&fields, &i) {
                        Some(fp) => if &crate::check::expr::patterns::field_pat_name(&fp, &names, &i) == &f {
                            prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: fp.pattern.clone() }))
                        } else {
                            prism_rtl::Turn::Finished(acc.clone())
                        },
                        None => prism_rtl::Turn::Finished(acc.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Pat, Nat)) -> Rc<dyn prism_rtl::Job<Pat>>>
        }).cycle()
    }
}

/// `Start FieldPatFor, x`: what the function value is when passed to `@Run`.
pub fn start_field_pat_for(env: crate::check::expr::Env, fields: Array<crate::syntax::FieldPat>, names: Array<Text>, f: Text) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(FieldPatFor { env, fields, names, f })
}

/// ```prism
/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
/// ```
pub fn useful(env: &crate::check::expr::Env, st: &crate::check::types::St, rows: &Array<Array<Pat>>, q: &Array<Pat>, tys: &Array<crate::check::types::Ty>) -> bool {
    match index(q, &Nat::from(0u32)) {
        None => &len(rows) == &Nat::from(0u32),
        Some(q1) => {
            let t1 = or(&index(tys, &Nat::from(0u32)), &crate::check::types::Ty::TyErr);
            let rest = drop(tys, &Nat::from(1u32));
            match &q1 {
                Pat::PtCon(c, args) => {
                    let ctor = ctor_named(env, st, &t1, c, &len(args));
                    useful(env, st, &specialize(rows, &ctor), &append(args, &drop(q, &Nat::from(1u32))), &append(&ctor.args, &rest))
                },
                Pat::PtLit(l) => useful(env, st, &specialize_lit(rows, l), &drop(q, &Nat::from(1u32)), &rest),
                Pat::PtFam(f) => match ctors_of(env, st, &t1) {
                    Some(cs) => run_to_end(fold_job(filter(&cs, &(|c: &Ctor| &ctor_family(c) == f)), false, {
                        let env = env.clone();
                        let st = st.clone();
                        let rows = rows.clone();
                        let q = q.clone();
                        let rest = rest.clone();
                        Rc::new(move |(p0, p1): (bool, Ctor)| {
                            let env = env.clone();
                            let st = st.clone();
                            let rows = rows.clone();
                            let q = q.clone();
                            let rest = rest.clone();
                            entered(once_job(move || {
                                let seen = p0;
                                let c = p1;
                                prism_rtl::Turn::Finished(seen || useful(&env, &st, &specialize(&rows, &c), &append(&wilds(&c.arity), &drop(&q, &Nat::from(1u32))), &append(&c.args, &rest)))
                            }))
                        }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                    })),
                    None => useful(env, st, &default_rows(rows), &drop(q, &Nat::from(1u32)), &rest),
                },
                Pat::PtAny => {
                    let heads = head_names(rows);
                    match ctors_of(env, st, &t1) {
                        Some(cs) => if complete(&cs, &heads, rows) {
                            run_to_end(fold_job(cs.clone(), false, {
                                let env = env.clone();
                                let st = st.clone();
                                let rows = rows.clone();
                                let q = q.clone();
                                let rest = rest.clone();
                                Rc::new(move |(p0, p1): (bool, Ctor)| {
                                    let env = env.clone();
                                    let st = st.clone();
                                    let rows = rows.clone();
                                    let q = q.clone();
                                    let rest = rest.clone();
                                    entered(once_job(move || {
                                        let seen = p0;
                                        let c = p1;
                                        prism_rtl::Turn::Finished(seen || useful(&env, &st, &specialize(&rows, &c), &append(&wilds(&c.arity), &drop(&q, &Nat::from(1u32))), &append(&c.args, &rest)))
                                    }))
                                }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }))
                        } else {
                            useful(env, st, &default_rows(rows), &drop(q, &Nat::from(1u32)), &rest)
                        },
                        None => useful(env, st, &default_rows(rows), &drop(q, &Nat::from(1u32)), &rest),
                    }
                },
            }
        },
    }
}

/// The step machine of `Useful`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
/// ```
pub struct Useful {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub rows: Array<Array<Pat>>,
    pub q: Array<Pat>,
    pub tys: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<bool> for Useful {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env = &self.env;
        let st = &self.st;
        let rows = &self.rows;
        let q = &self.q;
        let tys = &self.tys;
        match index(q, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(&len(rows) == &Nat::from(0u32)),
            Some(q1) => {
                let t1 = or(&index(tys, &Nat::from(0u32)), &crate::check::types::Ty::TyErr);
                let rest = drop(tys, &Nat::from(1u32));
                match &q1 {
                    Pat::PtCon(c, args) => {
                        let args = args.clone();
                        let c = c.clone();
                        let env = env.clone();
                        let q = q.clone();
                        let rows = rows.clone();
                        let st = st.clone();
                        call_then(start_ctor_named(env.clone(), st.clone(), t1.clone(), c.clone(), len(&args)), move |ctor_named_8452: Ctor| {
                            let ctor = ctor_named_8452;
                            prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: specialize(&rows, &ctor), q: append(&args, &drop(&q, &Nat::from(1u32))), tys: append(&ctor.args, &rest) }))
                        })
                    },
                    Pat::PtLit(l) => prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: specialize_lit(rows, l), q: drop(q, &Nat::from(1u32)), tys: rest.clone() })),
                    Pat::PtFam(f) => {
                        let env = env.clone();
                        let f = f.clone();
                        let q = q.clone();
                        let rows = rows.clone();
                        let st = st.clone();
                        call_then(start_ctors_of(env.clone(), st.clone(), t1.clone()), move |ctors_of_8706: Option<Array<Ctor>>| match ctors_of_8706 {
                            Some(cs) => fold_job(filter(&cs, &(|c: &Ctor| &ctor_family(c) == &f)), false, {
                                let env = env.clone();
                                let st = st.clone();
                                let rows = rows.clone();
                                let q = q.clone();
                                let rest = rest.clone();
                                Rc::new(move |(p0, p1): (bool, Ctor)| {
                                    let env = env.clone();
                                    let st = st.clone();
                                    let rows = rows.clone();
                                    let q = q.clone();
                                    let rest = rest.clone();
                                    entered(once_job(move || {
                                        let seen = p0;
                                        let c = p1;
                                        prism_rtl::Turn::Finished(seen || useful(&env, &st, &specialize(&rows, &c), &append(&wilds(&c.arity), &drop(&q, &Nat::from(1u32))), &append(&c.args, &rest)))
                                    }))
                                }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }).cycle(),
                            None => prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: default_rows(&rows), q: drop(&q, &Nat::from(1u32)), tys: rest.clone() })),
                        })
                    },
                    Pat::PtAny => {
                        let heads = head_names(rows);
                        let env = env.clone();
                        let q = q.clone();
                        let rows = rows.clone();
                        let st = st.clone();
                        call_then(start_ctors_of(env.clone(), st.clone(), t1.clone()), move |ctors_of_9078: Option<Array<Ctor>>| match ctors_of_9078 {
                            Some(cs) => if complete(&cs, &heads, &rows) {
                                fold_job(cs.clone(), false, {
                                    let env = env.clone();
                                    let st = st.clone();
                                    let rows = rows.clone();
                                    let q = q.clone();
                                    let rest = rest.clone();
                                    Rc::new(move |(p0, p1): (bool, Ctor)| {
                                        let env = env.clone();
                                        let st = st.clone();
                                        let rows = rows.clone();
                                        let q = q.clone();
                                        let rest = rest.clone();
                                        entered(once_job(move || {
                                            let seen = p0;
                                            let c = p1;
                                            prism_rtl::Turn::Finished(seen || useful(&env, &st, &specialize(&rows, &c), &append(&wilds(&c.arity), &drop(&q, &Nat::from(1u32))), &append(&c.args, &rest)))
                                        }))
                                    }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                                }).cycle()
                            } else {
                                prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: default_rows(&rows), q: drop(&q, &Nat::from(1u32)), tys: rest.clone() }))
                            },
                            None => prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: default_rows(&rows), q: drop(&q, &Nat::from(1u32)), tys: rest.clone() })),
                        })
                    },
                }
            },
        }
    }
}

/// `Start Useful, x`: what the function value is when passed to `@Run`.
pub fn start_useful(env: crate::check::expr::Env, st: crate::check::types::St, rows: Array<Array<Pat>>, q: Array<Pat>, tys: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Useful { env, st, rows, q, tys })
}

/// ```prism
/// CtorFamily: fn Ctor -> Text
/// ```
pub fn ctor_family(c: &Ctor) -> Text {
    if crate::syntax::lexer::chars::has_prefix(&c.name, &Text::lit("tag:")) {
        crate::check::env::dotted(&crate::syntax::lexer::chars::pop(&split(&crate::syntax::lexer::chars::drop_prefix(&c.name, &Text::lit("tag:")), &Text::lit("."))))
    } else {
        Text::lit("")
    }
}

/// ```prism
/// Wilds: fn Nat -> [Pat]
/// ```
pub fn wilds(n: &Nat) -> Array<Pat> {
    each(&crate::check::errors::range0(n), &(|_: &Nat| Pat::PtAny))
}

/// ```prism
/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
/// ```
pub fn ctor_named(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::check::types::Ty, c: &Text, arity: &Nat) -> Ctor {
    match ctors_of(env, st, t) {
        Some(cs) => match find_ctor(&cs, c) {
            Some(found) => found.clone(),
            None => Ctor { name: c.clone(), arity: arity.clone(), args: each(&crate::check::errors::range0(arity), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown: c.clone() },
        },
        None => Ctor { name: c.clone(), arity: arity.clone(), args: each(&crate::check::errors::range0(arity), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown: c.clone() },
    }
}

/// The step machine of `CtorNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
/// ```
pub struct CtorNamed {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub c: Text,
    pub arity: Nat,
}

impl prism_rtl::Job<Ctor> for CtorNamed {
    fn cycle(&self) -> prism_rtl::Turn<Ctor> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let c = &self.c;
        let arity = &self.arity;
        let arity = arity.clone();
        let c = c.clone();
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_ctors_of(env.clone(), st.clone(), t.clone()), move |ctors_of_9873: Option<Array<Ctor>>| match ctors_of_9873 {
            Some(cs) => match find_ctor(&cs, &c) {
                Some(found) => prism_rtl::Turn::Finished(found.clone()),
                None => prism_rtl::Turn::Finished(Ctor { name: c.clone(), arity: arity.clone(), args: each(&crate::check::errors::range0(&arity), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown: c.clone() }),
            },
            None => prism_rtl::Turn::Finished(Ctor { name: c.clone(), arity: arity.clone(), args: each(&crate::check::errors::range0(&arity), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown: c.clone() }),
        })
    }
}

/// `Start CtorNamed, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_named(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::check::types::Ty, c: Text, arity: Nat) -> Rc<dyn prism_rtl::Job<Ctor>> {
    Rc::new(CtorNamed { env, st, t, c, arity })
}

/// ```prism
/// ?FindCtor: fn [Ctor], Text -> ?Ctor
/// ```
pub fn find_ctor(cs: &Array<Ctor>, c: &Text) -> Option<Ctor> {
    fold(cs, &None, &(|found_opt: &Option<Ctor>, x: &Ctor| match found_opt {
        Some(f) => Some(f.clone()),
        None => if (&x.name == c) || (&crate::check::types::bare_name(&x.name) == &crate::check::types::bare_name(c)) {
            Some(x.clone())
        } else {
            None
        },
    }))
}

/// ```prism
/// Specialize: fn [ [Pat] ], Ctor -> [ [Pat] ]
/// ```
pub fn specialize(rows: &Array<Array<Pat>>, c: &Ctor) -> Array<Array<Pat>> {
    fold(rows, &Array::new(), &(|acc: &Array<Array<Pat>>, prow: &Array<Pat>| match index(prow, &Nat::from(0u32)) {
        Some(Pat::PtCon(d, args)) => if (&d == &c.name) || (&crate::check::types::bare_name(&d) == &crate::check::types::bare_name(&c.name)) {
            push(acc, &append(&pad(&args, &c.arity), &drop(prow, &Nat::from(1u32))))
        } else {
            acc.clone()
        },
        Some(Pat::PtAny) => push(acc, &append(&wilds(&c.arity), &drop(prow, &Nat::from(1u32)))),
        Some(Pat::PtFam(f)) => if &ctor_family(c) == &f {
            push(acc, &append(&wilds(&c.arity), &drop(prow, &Nat::from(1u32))))
        } else {
            acc.clone()
        },
        _ => acc.clone(),
    }))
}

/// ```prism
/// Pad: fn [Pat], Nat -> [Pat]
/// ```
pub fn pad(args: &Array<Pat>, n: &Nat) -> Array<Pat> {
    if &len(args) >= n {
        take(args, n)
    } else {
        append(args, &wilds(&or(&n.checked_sub(&len(args)), &Nat::from(0u32))))
    }
}

/// ```prism
/// SpecializeLit: fn [ [Pat] ], Text -> [ [Pat] ]
/// ```
pub fn specialize_lit(rows: &Array<Array<Pat>>, l: &Text) -> Array<Array<Pat>> {
    fold(rows, &Array::new(), &(|acc: &Array<Array<Pat>>, prow: &Array<Pat>| match index(prow, &Nat::from(0u32)) {
        Some(Pat::PtLit(m)) => if &m == l { push(acc, &drop(prow, &Nat::from(1u32))) } else { acc.clone() },
        Some(Pat::PtAny) => push(acc, &drop(prow, &Nat::from(1u32))),
        _ => acc.clone(),
    }))
}

/// ```prism
/// DefaultRows: fn [ [Pat] ] -> [ [Pat] ]
/// ```
pub fn default_rows(rows: &Array<Array<Pat>>) -> Array<Array<Pat>> {
    fold(rows, &Array::new(), &(|acc: &Array<Array<Pat>>, prow: &Array<Pat>| match index(prow, &Nat::from(0u32)) {
        Some(Pat::PtAny) => push(acc, &drop(prow, &Nat::from(1u32))),
        _ => acc.clone(),
    }))
}

/// ```prism
/// HeadNames: fn [ [Pat] ] -> [Text]
/// ```
pub fn head_names(rows: &Array<Array<Pat>>) -> Array<Text> {
    fold(rows, &Array::new(), &(|acc: &Array<Text>, prow: &Array<Pat>| match index(prow, &Nat::from(0u32)) {
        Some(Pat::PtCon(c, _)) => crate::check::types::add_text(acc, &c),
        Some(Pat::PtFam(f)) => crate::check::types::add_text(acc, &Text::from(format!("fam:{}", &f))),
        _ => acc.clone(),
    }))
}

/// ```prism
/// Complete: fn [Ctor], [Text], [ [Pat] ] -> Bool
/// ```
pub fn complete(cs: &Array<Ctor>, heads: &Array<Text>, rows: &Array<Array<Pat>>) -> bool {
    (&len(cs) > &Nat::from(0u32)) && fold(cs, &true, &(|ok: &bool, c: &Ctor| *ok && ((crate::check::types::has_text(heads, &c.name) || crate::check::types::has_text(&each(heads, &(|h: &Text| crate::check::types::bare_name(h))), &crate::check::types::bare_name(&c.name))) || crate::check::types::has_text(heads, &Text::from(format!("fam:{}", &ctor_family(c)))))))
}

/// ```prism
/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
/// ```
pub fn witness(env: &crate::check::expr::Env, st: &crate::check::types::St, rows: &Array<Array<Pat>>, tys: &Array<crate::check::types::Ty>) -> Option<Array<Text>> {
    match index(tys, &Nat::from(0u32)) {
        None => if &len(rows) == &Nat::from(0u32) { Some(Array::new()) } else { None },
        Some(t1) => {
            let rest = drop(tys, &Nat::from(1u32));
            let heads = head_names(rows);
            match ctors_of(env, st, &t1) {
                Some(cs) => if complete(&cs, &heads, rows) {
                    run_to_end(fold_job(cs.clone(), None, {
                        let env = env.clone();
                        let st = st.clone();
                        let rows = rows.clone();
                        let rest = rest.clone();
                        Rc::new(move |(p0, p1): (Option<Array<Text>>, Ctor)| {
                            let env = env.clone();
                            let st = st.clone();
                            let rows = rows.clone();
                            let rest = rest.clone();
                            entered(once_job(move || {
                                let found_opt = p0;
                                let c = p1;
                                match &found_opt {
                                    Some(f) => prism_rtl::Turn::Finished(Some(f.clone())),
                                    None => call_then(start_witness(env.clone(), st.clone(), specialize(&rows, &c), append(&c.args, &rest)), move |witness_12449: Option<Array<Text>>| match witness_12449 {
                                        Some(w) => prism_rtl::Turn::Finished(Some(append(&Array::from(vec![show_witness(&c, &take(&w, &c.arity))]), &drop(&w, &c.arity)))),
                                        None => prism_rtl::Turn::Finished(None),
                                    }),
                                }
                            }))
                        }) as Rc<dyn Fn((Option<Array<Text>>, Ctor)) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>>>
                    }))
                } else {
                    match witness(env, st, &default_rows(rows), &rest) {
                        Some(w) => {
                            let missing = filter(&cs, &(|c: &Ctor| !(crate::check::types::has_text(&heads, &c.name) || crate::check::types::has_text(&heads, &Text::from(format!("fam:{}", &ctor_family(c)))))));
                            let shown = match index(&missing, &Nat::from(0u32)) {
                                Some(c) => c.shown.clone(),
                                None => Text::lit("_"),
                            };
                            Some(append(&Array::from(vec![shown.clone()]), &w))
                        },
                        None => None,
                    }
                },
                None => match witness(env, st, &default_rows(rows), &rest) {
                    Some(w) => Some(append(&Array::from(vec![Text::lit("_")]), &w)),
                    None => None,
                },
            }
        },
    }
}

/// The step machine of `Witness`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
/// ```
pub struct Witness {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub rows: Array<Array<Pat>>,
    pub tys: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<Option<Array<Text>>> for Witness {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<Text>>> {
        let env = &self.env;
        let st = &self.st;
        let rows = &self.rows;
        let tys = &self.tys;
        match index(tys, &Nat::from(0u32)) {
            None => if &len(rows) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(Some(Array::new()))
            } else {
                prism_rtl::Turn::Finished(None)
            },
            Some(t1) => {
                let rest = drop(tys, &Nat::from(1u32));
                let heads = head_names(rows);
                let env = env.clone();
                let rows = rows.clone();
                let st = st.clone();
                call_then(start_ctors_of(env.clone(), st.clone(), t1.clone()), move |ctors_of_12235: Option<Array<Ctor>>| match ctors_of_12235 {
                    Some(cs) => if complete(&cs, &heads, &rows) {
                        fold_job(cs.clone(), None, {
                            let env = env.clone();
                            let st = st.clone();
                            let rows = rows.clone();
                            let rest = rest.clone();
                            Rc::new(move |(p0, p1): (Option<Array<Text>>, Ctor)| {
                                let env = env.clone();
                                let st = st.clone();
                                let rows = rows.clone();
                                let rest = rest.clone();
                                entered(once_job(move || {
                                    let found_opt = p0;
                                    let c = p1;
                                    match &found_opt {
                                        Some(f) => prism_rtl::Turn::Finished(Some(f.clone())),
                                        None => call_then(start_witness(env.clone(), st.clone(), specialize(&rows, &c), append(&c.args, &rest)), move |witness_12449: Option<Array<Text>>| match witness_12449 {
                                            Some(w) => prism_rtl::Turn::Finished(Some(append(&Array::from(vec![show_witness(&c, &take(&w, &c.arity))]), &drop(&w, &c.arity)))),
                                            None => prism_rtl::Turn::Finished(None),
                                        }),
                                    }
                                }))
                            }) as Rc<dyn Fn((Option<Array<Text>>, Ctor)) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>>>
                        }).cycle()
                    } else {
                        call_then(start_witness(env.clone(), st.clone(), default_rows(&rows), rest.clone()), move |witness_12679: Option<Array<Text>>| match witness_12679 {
                            Some(w) => {
                                let missing = filter(&cs, &(|c: &Ctor| !(crate::check::types::has_text(&heads, &c.name) || crate::check::types::has_text(&heads, &Text::from(format!("fam:{}", &ctor_family(c)))))));
                                let shown = match index(&missing, &Nat::from(0u32)) {
                                    Some(c) => c.shown.clone(),
                                    None => Text::lit("_"),
                                };
                                prism_rtl::Turn::Finished(Some(append(&Array::from(vec![shown.clone()]), &w)))
                            },
                            None => prism_rtl::Turn::Finished(None),
                        })
                    },
                    None => call_then(start_witness(env.clone(), st.clone(), default_rows(&rows), rest.clone()), move |witness_13105: Option<Array<Text>>| match witness_13105 {
                        Some(w) => prism_rtl::Turn::Finished(Some(append(&Array::from(vec![Text::lit("_")]), &w))),
                        None => prism_rtl::Turn::Finished(None),
                    }),
                })
            },
        }
    }
}

/// `Start Witness, x`: what the function value is when passed to `@Run`.
pub fn start_witness(env: crate::check::expr::Env, st: crate::check::types::St, rows: Array<Array<Pat>>, tys: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>> {
    Rc::new(Witness { env, st, rows, tys })
}

/// ```prism
/// ShowWitness: fn Ctor, [Text] -> Text
/// ```
pub fn show_witness(c: &Ctor, args: &Array<Text>) -> Text {
    if &c.name == &Text::lit("?") {
        Text::from(format!("? {}", &or(&index(args, &Nat::from(0u32)), &Text::lit("_"))))
    } else {
        if &c.name == &Text::lit("~") {
            Text::from(format!("~ {}", &or(&index(args, &Nat::from(0u32)), &Text::lit("_"))))
        } else {
            if &c.name == &Text::lit("tuple") {
                Text::from(format!("(({}))", &crate::syntax::lexer::chars::join(args, &Text::lit(", "))))
            } else {
                if (&len(args) == &Nat::from(0u32)) || fold(args, &true, &(|ok: &bool, a: &Text| *ok && (a == &Text::lit("_")))) {
                    c.shown.clone()
                } else {
                    Text::from(format!("{} {}", &crate::check::types::bare_name(&c.name), &crate::syntax::lexer::chars::join(args, &Text::lit(", "))))
                }
            }
        }
    }
}

/// ```prism
/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
/// ```
pub fn match_coverage(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::check::types::Ty, arms: &Array<crate::syntax::Arm>, span: &crate::syntax::Range) -> crate::check::types::St {
    let has_otherwise = fold(arms, &false, &(|seen: &bool, a: &crate::syntax::Arm| *seen || (&a.pattern == &None)));
    let tys = Array::from(vec![t.clone()]);
    let (rows, st2) = run_to_end(fold_job(arms.clone(), (Array::new(), st.clone()), {
        let env = env.clone();
        let tys = tys.clone();
        let t = t.clone();
        Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)| {
            let env = env.clone();
            let tys = tys.clone();
            let t = t.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let arm = p1;
                {
                    let q = match &arm.pattern {
                        Some(p_) => Array::from(vec![to_pat(&env, p_)]),
                        None => Array::from(vec![Pat::PtAny]),
                    };
                    call_then(start_useful(env.clone(), s.clone(), acc.clone(), q.clone(), tys.clone()), move |useful_14191: bool| {
                        let reachable = useful_14191;
                        call_then(start_owns_row(env.clone(), s.clone(), t.clone()), move |owns_row_14240: bool| {
                            let owns_all = owns_row_14240;
                            let s2 = if reachable {
                                s.clone()
                            } else {
                                if (&arm.pattern == &None) && !owns_all {
                                    s.clone()
                                } else {
                                    crate::check::types::recording::err_fix(&s, &Text::lit("unreachable"), &arm_span(&arm), &Text::lit("this arm is never reached"), &Text::lit("remove it, or put it above the arm that covers it"))
                                }
                            };
                            let acc2 = if &arm.guard == &None { push(&acc, &q) } else { acc.clone() };
                            prism_rtl::Turn::Finished((acc2.clone(), s2.clone()))
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
    }));
    if has_otherwise {
        st2.clone()
    } else {
        if is_open_row(env, &st2, t) {
            crate::check::types::recording::err_fix(&st2, &Text::lit("row-not-closed"), span, &Text::from(format!("a match over `{}` needs `otherwise:`", &crate::check::types::show_ty(&st2, t))), &Text::lit("add an `otherwise:` arm: the row's variable may hold tags this match cannot name"))
        } else {
            match witness(env, &st2, &rows, &tys) {
                Some(w) => crate::check::types::recording::err_fix(&st2, &Text::lit("not-exhaustive"), span, &Text::from(format!("this match misses `{}`", &crate::syntax::lexer::chars::join(&w, &Text::lit(", ")))), &Text::lit("add an arm for it, or `otherwise:`")),
                None => st2.clone(),
            }
        }
    }
}

/// The step machine of `MatchCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
/// ```
pub struct MatchCoverage {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub arms: Array<crate::syntax::Arm>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for MatchCoverage {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let arms = &self.arms;
        let span = &self.span;
        let has_otherwise = fold(arms, &false, &(|seen: &bool, a: &crate::syntax::Arm| *seen || (&a.pattern == &None)));
        let tys = Array::from(vec![t.clone()]);
        let arms = arms.clone();
        let env = env.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_value(fold_job(arms.clone(), (Array::new(), st.clone()), {
            let env = env.clone();
            let tys = tys.clone();
            let t = t.clone();
            Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)| {
                let env = env.clone();
                let tys = tys.clone();
                let t = t.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let arm = p1;
                    {
                        let q = match &arm.pattern {
                            Some(p_) => Array::from(vec![to_pat(&env, p_)]),
                            None => Array::from(vec![Pat::PtAny]),
                        };
                        call_then(start_useful(env.clone(), s.clone(), acc.clone(), q.clone(), tys.clone()), move |useful_14191: bool| {
                            let reachable = useful_14191;
                            call_then(start_owns_row(env.clone(), s.clone(), t.clone()), move |owns_row_14240: bool| {
                                let owns_all = owns_row_14240;
                                let s2 = if reachable {
                                    s.clone()
                                } else {
                                    if (&arm.pattern == &None) && !owns_all {
                                        s.clone()
                                    } else {
                                        crate::check::types::recording::err_fix(&s, &Text::lit("unreachable"), &arm_span(&arm), &Text::lit("this arm is never reached"), &Text::lit("remove it, or put it above the arm that covers it"))
                                    }
                                };
                                let acc2 = if &arm.guard == &None { push(&acc, &q) } else { acc.clone() };
                                prism_rtl::Turn::Finished((acc2.clone(), s2.clone()))
                            })
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
        }), move |fold_14024: (Array<Array<Pat>>, crate::check::types::St)| {
            let (rows, st2) = fold_14024;
            if has_otherwise {
                prism_rtl::Turn::Finished(st2.clone())
            } else {
                call_then(start_is_open_row(env.clone(), st2.clone(), t.clone()), move |is_open_row_14588: bool| if is_open_row_14588 {
                    call_then(crate::check::types::start_show_ty(st2.clone(), t.clone()), move |show_ty_14663: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st2, &Text::lit("row-not-closed"), &span, &Text::from(format!("a match over `{}` needs `otherwise:`", &show_ty_14663)), &Text::lit("add an `otherwise:` arm: the row's variable may hold tags this match cannot name"))))
                } else {
                    call_then(start_witness(env.clone(), st2.clone(), rows.clone(), tys.clone()), move |witness_14799: Option<Array<Text>>| match witness_14799 {
                        Some(w) => prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st2, &Text::lit("not-exhaustive"), &span, &Text::from(format!("this match misses `{}`", &crate::syntax::lexer::chars::join(&w, &Text::lit(", ")))), &Text::lit("add an arm for it, or `otherwise:`"))),
                        None => prism_rtl::Turn::Finished(st2.clone()),
                    })
                })
            }
        })
    }
}

/// `Start MatchCoverage, x`: what the function value is when passed to `@Run`.
pub fn start_match_coverage(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::check::types::Ty, arms: Array<crate::syntax::Arm>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(MatchCoverage { env, st, t, arms, span })
}

/// ```prism
/// ArmSpan: fn Arm -> Range
/// ```
pub fn arm_span(a: &crate::syntax::Arm) -> crate::syntax::Range {
    match &a.pattern {
        Some(p_) => p_.span.clone(),
        None => a.span.clone(),
    }
}

/// ```prism
/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub fn is_open_row(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyElem(rw, _) => &crate::check::types::recording::walk_row(st, &rw).tail != &crate::check::types::Tail::TlClosed,
        crate::check::types::Ty::TyElemAny(rw) => &crate::check::types::recording::walk_row(st, &rw).tail != &crate::check::types::Tail::TlClosed,
        crate::check::types::Ty::TyCon(n, m15221_2_1) if ((&m15221_2_1).len() == 0) => match get(&env.g.types, &n) {
            Some(ti) => (&ti.body == &crate::check::env::TyBody::BRowKind) && !is_root_module(env),
            None => ((&n == &Text::lit("Fault")) || (&n == &Text::lit("Prelude.Fault"))) && !is_root_module(env),
        },
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `IsOpenRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub struct IsOpenRow {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for IsOpenRow {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_15227: crate::check::types::Ty| match walk_15227 {
            crate::check::types::Ty::TyElem(rw, _) => call_then(crate::check::types::recording::start_walk_row(st.clone(), rw.clone()), move |walk_row_15263: crate::check::types::Rw| prism_rtl::Turn::Finished(&walk_row_15263.tail != &crate::check::types::Tail::TlClosed)),
            crate::check::types::Ty::TyElemAny(rw) => call_then(crate::check::types::recording::start_walk_row(st.clone(), rw.clone()), move |walk_row_15315: crate::check::types::Rw| prism_rtl::Turn::Finished(&walk_row_15315.tail != &crate::check::types::Tail::TlClosed)),
            crate::check::types::Ty::TyCon(n, m15221_2_1) if ((&m15221_2_1).len() == 0) => match get(&env.g.types, &n) {
                Some(ti) => prism_rtl::Turn::Finished((&ti.body == &crate::check::env::TyBody::BRowKind) && !is_root_module(&env)),
                None => prism_rtl::Turn::Finished(((&n == &Text::lit("Fault")) || (&n == &Text::lit("Prelude.Fault"))) && !is_root_module(&env)),
            },
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start IsOpenRow, x`: what the function value is when passed to `@Run`.
pub fn start_is_open_row(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsOpenRow { env, st, t })
}

/// ```prism
/// OwnsRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub fn owns_row(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyElem(rw, _) => fold(&crate::check::types::recording::walk_row(st, &rw).fams, &true, &(|ok: &bool, f: &Text| *ok && (&or(&get(&env.g.fam_owner, f), &Text::lit("")) == &env.home))),
        crate::check::types::Ty::TyCon(n, m15690_1_1) if ((&m15690_1_1).len() == 0) => match get(&env.g.types, &n) {
            Some(ti) => &ti.body != &crate::check::env::TyBody::BRowKind,
            None => !((&n == &Text::lit("Fault")) || (&n == &Text::lit("Prelude.Fault"))),
        },
        _ => true,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `OwnsRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OwnsRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub struct OwnsRow {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for OwnsRow {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_15696: crate::check::types::Ty| match walk_15696 {
            crate::check::types::Ty::TyElem(rw, _) => call_then(crate::check::types::recording::start_walk_row(st.clone(), rw.clone()), move |walk_row_15737: crate::check::types::Rw| prism_rtl::Turn::Finished(fold(&walk_row_15737.fams, &true, &(|ok: &bool, f: &Text| *ok && (&or(&get(&env.g.fam_owner, f), &Text::lit("")) == &env.home))))),
            crate::check::types::Ty::TyCon(n, m15690_1_1) if ((&m15690_1_1).len() == 0) => match get(&env.g.types, &n) {
                Some(ti) => prism_rtl::Turn::Finished(&ti.body != &crate::check::env::TyBody::BRowKind),
                None => prism_rtl::Turn::Finished(!((&n == &Text::lit("Fault")) || (&n == &Text::lit("Prelude.Fault")))),
            },
            _ => prism_rtl::Turn::Finished(true),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start OwnsRow, x`: what the function value is when passed to `@Run`.
pub fn start_owns_row(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(OwnsRow { env, st, t })
}

/// ```prism
/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
/// ```
pub fn clause_coverage(env: &crate::check::expr::Env, st: &crate::check::types::St, clauses: &Array<crate::syntax::decls::FnClause>, params: &Array<crate::check::types::Ty>, span: &crate::syntax::Range) -> crate::check::types::St {
    let (rows, st2) = run_to_end(fold_job(clauses.clone(), (Array::new(), st.clone()), {
        let env = env.clone();
        let params = params.clone();
        Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::decls::FnClause)| {
            let env = env.clone();
            let params = params.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let c = p1;
                call_value(each_job(c.params.clone(), {
                    let env = env.clone();
                    Rc::new(move |p0: crate::syntax::Pattern_| {
                        let env = env.clone();
                        entered(once_job(move || {
                            let p_ = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: p_.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_16233: Array<Pat>| {
                    let q = each_16233;
                    let reachable = (&len(&q) != &len(&params)) || useful(&env, &s, &acc, &q, &params);
                    let s2 = if reachable {
                        s.clone()
                    } else {
                        crate::check::types::recording::err_fix(&s, &Text::lit("unreachable"), &c.span, &Text::lit("this clause is never reached"), &Text::lit("remove it, or put it above the clause that covers it"))
                    };
                    prism_rtl::Turn::Finished((push(&acc, &q), s2.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
    }));
    if &len(params) == &Nat::from(0u32) {
        st2.clone()
    } else {
        match witness(env, &st2, &rows, params) {
            Some(w) => crate::check::types::recording::err_fix(&st2, &Text::lit("not-exhaustive"), span, &Text::from(format!("these clauses miss `{}`", &crate::syntax::lexer::chars::join(&w, &Text::lit(", ")))), &Text::lit("add a clause for it")),
            None => st2.clone(),
        }
    }
}

/// The step machine of `ClauseCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
/// ```
pub struct ClauseCoverage {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub clauses: Array<crate::syntax::decls::FnClause>,
    pub params: Array<crate::check::types::Ty>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for ClauseCoverage {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let clauses = &self.clauses;
        let params = &self.params;
        let span = &self.span;
        let clauses = clauses.clone();
        let env = env.clone();
        let params = params.clone();
        let span = span.clone();
        let st = st.clone();
        call_value(fold_job(clauses.clone(), (Array::new(), st.clone()), {
            let env = env.clone();
            let params = params.clone();
            Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::decls::FnClause)| {
                let env = env.clone();
                let params = params.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let c = p1;
                    call_value(each_job(c.params.clone(), {
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Pattern_| {
                            let env = env.clone();
                            entered(once_job(move || {
                                let p_ = p0;
                                prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: p_.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                    }), move |each_16233: Array<Pat>| {
                        let q = each_16233;
                        let reachable = (&len(&q) != &len(&params)) || useful(&env, &s, &acc, &q, &params);
                        let s2 = if reachable {
                            s.clone()
                        } else {
                            crate::check::types::recording::err_fix(&s, &Text::lit("unreachable"), &c.span, &Text::lit("this clause is never reached"), &Text::lit("remove it, or put it above the clause that covers it"))
                        };
                        prism_rtl::Turn::Finished((push(&acc, &q), s2.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
        }), move |fold_16172: (Array<Array<Pat>>, crate::check::types::St)| {
            let (rows, st2) = fold_16172;
            if &len(&params) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(st2.clone())
            } else {
                call_then(start_witness(env.clone(), st2.clone(), rows.clone(), params.clone()), move |witness_16582: Option<Array<Text>>| match witness_16582 {
                    Some(w) => prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st2, &Text::lit("not-exhaustive"), &span, &Text::from(format!("these clauses miss `{}`", &crate::syntax::lexer::chars::join(&w, &Text::lit(", ")))), &Text::lit("add a clause for it"))),
                    None => prism_rtl::Turn::Finished(st2.clone()),
                })
            }
        })
    }
}

/// `Start ClauseCoverage, x`: what the function value is when passed to `@Run`.
pub fn start_clause_coverage(env: crate::check::expr::Env, st: crate::check::types::St, clauses: Array<crate::syntax::decls::FnClause>, params: Array<crate::check::types::Ty>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ClauseCoverage { env, st, clauses, params, span })
}

/// ```prism
/// DischargeIncls: unbounded fn G, St, Nat -> St
/// ```
pub fn discharge_incls(g: &crate::check::env::G, st: &crate::check::types::St, from: &Nat) -> crate::check::types::St {
    let batch = drop(&st.incls, from);
    run_to_end(fold_job(batch.clone(), st.clone(), {
        let g = g.clone();
        let batch = batch.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Incl)| {
            let g = g.clone();
            let batch = batch.clone();
            entered(once_job(move || {
                let s = p0;
                let inc = p1;
                call_then(start_through(s.clone(), inc.clone(), batch.clone()), move |through_17423: crate::check::types::Incl| prism_rtl::Turn::More(Rc::new(DischargeOne { g: g.clone(), st: s.clone(), inc: through_17423 })))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `DischargeIncls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DischargeIncls: unbounded fn G, St, Nat -> St
/// ```
pub struct DischargeIncls {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub from: Nat,
}

impl prism_rtl::Job<crate::check::types::St> for DischargeIncls {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let from = &self.from;
        let batch = drop(&st.incls, from);
        fold_job(batch.clone(), st.clone(), {
            let g = g.clone();
            let batch = batch.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Incl)| {
                let g = g.clone();
                let batch = batch.clone();
                entered(once_job(move || {
                    let s = p0;
                    let inc = p1;
                    call_then(start_through(s.clone(), inc.clone(), batch.clone()), move |through_17423: crate::check::types::Incl| prism_rtl::Turn::More(Rc::new(DischargeOne { g: g.clone(), st: s.clone(), inc: through_17423 })))
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start DischargeIncls, x`: what the function value is when passed to `@Run`.
pub fn start_discharge_incls(g: crate::check::env::G, st: crate::check::types::St, from: Nat) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DischargeIncls { g, st, from })
}

/// ```prism
/// Through: unbounded fn St, Incl, [Incl] -> Incl
/// ```
pub fn through(st: &crate::check::types::St, inc: &crate::check::types::Incl, batch: &Array<crate::check::types::Incl>) -> crate::check::types::Incl {
    let sup = crate::check::types::recording::walk_row(st, &inc.sup);
    match &sup.tail {
        crate::check::types::Tail::TlFlex(n) => if &len(&sup.fams) > &Nat::from(0u32) {
            inc.clone()
        } else {
            run_to_end(fold_job(batch.clone(), inc.clone(), {
                let st = st.clone();
                let n = n.clone();
                let inc = inc.clone();
                Rc::new(move |(p0, p1): (crate::check::types::Incl, crate::check::types::Incl)| {
                    let st = st.clone();
                    let n = n.clone();
                    let inc = inc.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let other = p1;
                        call_then(crate::check::types::recording::start_walk_row(st.clone(), other.sub.clone()), move |walk_row_17937: crate::check::types::Rw| {
                            let sub = walk_row_17937;
                            if ((&len(&sub.fams) == &Nat::from(0u32)) && (&sub.tail == &crate::check::types::Tail::TlFlex(n.clone()))) && (&other != &inc) {
                                prism_rtl::Turn::Finished({
                                    let mut this: crate::check::types::Incl = acc.clone();
                                    this.sup = other.sup.clone();
                                    this
                                })
                            } else {
                                prism_rtl::Turn::Finished(acc.clone())
                            }
                        })
                    }))
                }) as Rc<dyn Fn((crate::check::types::Incl, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::Incl>>>
            }))
        },
        _ => inc.clone(),
    }
}

/// The step machine of `Through`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Through: unbounded fn St, Incl, [Incl] -> Incl
/// ```
pub struct Through {
    pub st: crate::check::types::St,
    pub inc: crate::check::types::Incl,
    pub batch: Array<crate::check::types::Incl>,
}

impl prism_rtl::Job<crate::check::types::Incl> for Through {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Incl> {
        let st = &self.st;
        let inc = &self.inc;
        let batch = &self.batch;
        let batch = batch.clone();
        let inc = inc.clone();
        let st = st.clone();
        call_then(crate::check::types::recording::start_walk_row(st.clone(), inc.sup.clone()), move |walk_row_17765: crate::check::types::Rw| {
            let sup = walk_row_17765;
            match &sup.tail {
                crate::check::types::Tail::TlFlex(n) => if &len(&sup.fams) > &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(inc.clone())
                } else {
                    fold_job(batch.clone(), inc.clone(), {
                        let st = st.clone();
                        let n = n.clone();
                        let inc = inc.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::Incl, crate::check::types::Incl)| {
                            let st = st.clone();
                            let n = n.clone();
                            let inc = inc.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let other = p1;
                                call_then(crate::check::types::recording::start_walk_row(st.clone(), other.sub.clone()), move |walk_row_17937: crate::check::types::Rw| {
                                    let sub = walk_row_17937;
                                    if ((&len(&sub.fams) == &Nat::from(0u32)) && (&sub.tail == &crate::check::types::Tail::TlFlex(n.clone()))) && (&other != &inc) {
                                        prism_rtl::Turn::Finished({
                                            let mut this: crate::check::types::Incl = acc.clone();
                                            this.sup = other.sup.clone();
                                            this
                                        })
                                    } else {
                                        prism_rtl::Turn::Finished(acc.clone())
                                    }
                                })
                            }))
                        }) as Rc<dyn Fn((crate::check::types::Incl, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::Incl>>>
                    }).cycle()
                },
                _ => prism_rtl::Turn::Finished(inc.clone()),
            }
        })
    }
}

/// `Start Through, x`: what the function value is when passed to `@Run`.
pub fn start_through(st: crate::check::types::St, inc: crate::check::types::Incl, batch: Array<crate::check::types::Incl>) -> Rc<dyn prism_rtl::Job<crate::check::types::Incl>> {
    Rc::new(Through { st, inc, batch })
}

/// ```prism
/// DischargeOne: unbounded fn G, St, Incl -> St
/// ```
pub fn discharge_one(g: &crate::check::env::G, st: &crate::check::types::St, inc: &crate::check::types::Incl) -> crate::check::types::St {
    let sub = crate::check::types::recording::walk_row(st, &inc.sub);
    let sup = crate::check::types::recording::walk_row(st, &inc.sup);
    let st1 = match &sub.tail {
        crate::check::types::Tail::TlFlex(n) => close_tail(st, n),
        _ => st.clone(),
    };
    let sub2 = crate::check::types::recording::walk_row(&st1, &inc.sub);
    let left = filter(&sub2.fams, &(|f: &Text| !crate::check::types::has_text(&sup.fams, f) && (&len(&tags_left(g, f, &sub2.minus)) > &Nat::from(0u32))));
    let tail_bad = match (sub2.tail.clone(), sup.tail.clone()) {
        (crate::check::types::Tail::TlRigid(a), crate::check::types::Tail::TlRigid(b)) => &a != &b,
        (crate::check::types::Tail::TlRigid(_), _) => true,
        _ => false,
    };
    if (&len(&left) == &Nat::from(0u32)) && !tail_bad {
        st1.clone()
    } else {
        {
            let s0 = {
                let mut this: crate::check::types::St = st1.clone();
                this.file = inc.file.clone();
                this
            };
            let tags = fold(&left, &Array::new(), &(|acc: &Array<Text>, f: &Text| append(acc, &tags_left(g, f, &sub2.minus))));
            let s1 = if inc.forward {
                crate::check::types::recording::err_fix(&s0, &Text::lit("forwarding"), &inc.span, &Text::from(format!("forwarding {} from a scope that emits {}", &crate::syntax::lexer::chars::join(&tags, &Text::lit(", ")), &crate::check::types::show_row(&sup))), &Text::from(format!("answer {} above this arm, for example `{}(..): @ never`", &(if &len(&tags) == &Nat::from(1u32) { Text::lit("it") } else { Text::lit("them") }), &or(&index(&tags, &Nat::from(0u32)), &Text::lit("")))))
            } else {
                crate::check::types::recording::err_fix(&s0, &Text::lit("row-outside"), &inc.span, &Text::from(format!("a child that emits `{}` in a scope that emits `{}`", &crate::check::types::show_row(&sub2), &crate::check::types::show_row(&sup))), &Text::lit("widen the scope's `emit` row, or host the child with `@HostDocument`"))
            };
            {
                let mut this: crate::check::types::St = s1.clone();
                this.file = st1.file.clone();
                this
            }
        }
    }
}

/// The step machine of `DischargeOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DischargeOne: unbounded fn G, St, Incl -> St
/// ```
pub struct DischargeOne {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub inc: crate::check::types::Incl,
}

impl prism_rtl::Job<crate::check::types::St> for DischargeOne {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let inc = &self.inc;
        let g = g.clone();
        let inc = inc.clone();
        let st = st.clone();
        call_then(crate::check::types::recording::start_walk_row(st.clone(), inc.sub.clone()), move |walk_row_18256: crate::check::types::Rw| {
            let sub = walk_row_18256;
            call_then(crate::check::types::recording::start_walk_row(st.clone(), inc.sup.clone()), move |walk_row_18290: crate::check::types::Rw| {
                let sup = walk_row_18290;
                let st1 = match &sub.tail {
                    crate::check::types::Tail::TlFlex(n) => close_tail(&st, n),
                    _ => st.clone(),
                };
                call_then(crate::check::types::recording::start_walk_row(st1.clone(), inc.sub.clone()), move |walk_row_18411: crate::check::types::Rw| {
                    let sub2 = walk_row_18411;
                    let left = filter(&sub2.fams, &(|f: &Text| !crate::check::types::has_text(&sup.fams, f) && (&len(&tags_left(&g, f, &sub2.minus)) > &Nat::from(0u32))));
                    let tail_bad = match (sub2.tail.clone(), sup.tail.clone()) {
                        (crate::check::types::Tail::TlRigid(a), crate::check::types::Tail::TlRigid(b)) => &a != &b,
                        (crate::check::types::Tail::TlRigid(_), _) => true,
                        _ => false,
                    };
                    if (&len(&left) == &Nat::from(0u32)) && !tail_bad {
                        prism_rtl::Turn::Finished(st1.clone())
                    } else {
                        {
                            let s0 = {
                                let mut this: crate::check::types::St = st1.clone();
                                this.file = inc.file.clone();
                                this
                            };
                            let tags = fold(&left, &Array::new(), &(|acc: &Array<Text>, f: &Text| append(acc, &tags_left(&g, f, &sub2.minus))));
                            let s1 = if inc.forward {
                                crate::check::types::recording::err_fix(&s0, &Text::lit("forwarding"), &inc.span, &Text::from(format!("forwarding {} from a scope that emits {}", &crate::syntax::lexer::chars::join(&tags, &Text::lit(", ")), &crate::check::types::show_row(&sup))), &Text::from(format!("answer {} above this arm, for example `{}(..): @ never`", &(if &len(&tags) == &Nat::from(1u32) { Text::lit("it") } else { Text::lit("them") }), &or(&index(&tags, &Nat::from(0u32)), &Text::lit("")))))
                            } else {
                                crate::check::types::recording::err_fix(&s0, &Text::lit("row-outside"), &inc.span, &Text::from(format!("a child that emits `{}` in a scope that emits `{}`", &crate::check::types::show_row(&sub2), &crate::check::types::show_row(&sup))), &Text::lit("widen the scope's `emit` row, or host the child with `@HostDocument`"))
                            };
                            prism_rtl::Turn::Finished({
                                let mut this: crate::check::types::St = s1.clone();
                                this.file = st1.file.clone();
                                this
                            })
                        }
                    }
                })
            })
        })
    }
}

/// `Start DischargeOne, x`: what the function value is when passed to `@Run`.
pub fn start_discharge_one(g: crate::check::env::G, st: crate::check::types::St, inc: crate::check::types::Incl) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DischargeOne { g, st, inc })
}

/// ```prism
/// TagsLeft: fn G, Text, [Text] -> [Text]
/// ```
pub fn tags_left(g: &crate::check::env::G, fam: &Text, minus: &Array<Text>) -> Array<Text> {
    filter(&or(&get(&g.families, fam), &Array::new()), &(|t: &Text| !crate::check::types::has_text(minus, t) && is_element_tag(g, t)))
}

/// ```prism
/// IsElementTag: fn G, Text -> Bool
/// ```
pub fn is_element_tag(g: &crate::check::env::G, t: &Text) -> bool {
    match get(&g.tags, t) {
        Some(tg) => &tg.kind == &Text::lit("Element"),
        None => false,
    }
}

/// ```prism
/// CloseTail: fn St, Nat -> St
/// ```
pub fn close_tail(st: &crate::check::types::St, n: &Nat) -> crate::check::types::St {
    let mut this: crate::check::types::St = st.clone();
    this.rows = insert(&this.rows, n, &crate::check::types::empty_row());
    this
}
