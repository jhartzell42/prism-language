//! The module `Check.Passes`, from `target/bootstrap/src/prismc/check/passes/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod borrows;
pub mod cycles;

/// `Ctor`:
///
/// ```prism
/// type Ctor = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Ctor {
    pub name: Text,
    pub arity: Nat,
    pub args: Array<crate::check::types::Ty>,
    pub shown: Text,
}

impl Show for Ctor {
    fn show(&self, p: &mut Printer) {
        p.record("Ctor", &[("name", &self.name), ("arity", &self.arity), ("args", &self.args), ("shown", &self.shown)]);
    }
}

impl ToPod for Ctor {
    fn to_pod(&self) -> Pod {
        Pod::record("Ctor", vec![("name", self.name.to_pod()), ("arity", self.arity.to_pod()), ("args", self.args.to_pod()), ("shown", self.shown.to_pod())])
    }
}

impl FromPod for Ctor {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Ctor { name: FromPod::from_pod(field(p, "name")?)?, arity: FromPod::from_pod(field(p, "arity")?)?, args: FromPod::from_pod(field(p, "args")?)?, shown: FromPod::from_pod(field(p, "shown")?)? })
    }
}

/// `Pat`:
///
/// ```prism
/// type Pat = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Pat {
    PtAny,
    PtCon(Text, Array<Pat>),
    PtLit(Text),
    PtFam(Text),
}

impl Show for Pat {
    fn show(&self, p: &mut Printer) {
        match self {
            Pat::PtAny => p.choice("PtAny", &[]),
            Pat::PtCon(a0, a1) => p.choice("PtCon", &[a0, a1]),
            Pat::PtLit(a0) => p.choice("PtLit", &[a0]),
            Pat::PtFam(a0) => p.choice("PtFam", &[a0]),
        }
    }
}

impl ToPod for Pat {
    fn to_pod(&self) -> Pod {
        match self {
            Pat::PtAny => Pod::Choice("PtAny".into(), vec![]),
            Pat::PtCon(a0, a1) => Pod::Choice("PtCon".into(), vec![a0.to_pod(), a1.to_pod()]),
            Pat::PtLit(a0) => Pod::Choice("PtLit".into(), vec![a0.to_pod()]),
            Pat::PtFam(a0) => Pod::Choice("PtFam".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Pat {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "PtAny" && a.len() == 0 => Ok(Pat::PtAny),
            Pod::Choice(c, a) if &**c == "PtCon" && a.len() == 2 => Ok(Pat::PtCon(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "PtLit" && a.len() == 1 => Ok(Pat::PtLit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PtFam" && a.len() == 1 => Ok(Pat::PtFam(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Pat", other),
        }
    }
}

/// ```prism
/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
/// ```
pub fn ctors_of(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty) -> Option<Array<Ctor>> {
    match crate::check::types::recording::walk(st_p1, t_p2) {
        crate::check::types::Ty::TyCon(m2894_0_0, m2894_0_1) if (&m2894_0_0 == &Text::lit("Bool")) && ((&m2894_0_1).len() == 0) => Some(Array::from(vec![Ctor { name: Text::lit("True"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("True") }, Ctor { name: Text::lit("False"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("False") }])),
        crate::check::types::Ty::TyCon(m2894_1_0, m2894_1_1) if (&m2894_1_0 == &Text::lit("unit")) && ((&m2894_1_1).len() == 0) => Some(Array::from(vec![Ctor { name: Text::lit("unit"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("unit") }])),
        crate::check::types::Ty::TySig(m2894_2_0, i_p3) if (&m2894_2_0 == &Text::lit("?")) => Some(Array::from(vec![Ctor { name: Text::lit("?"), arity: Nat::from(1u32), args: Array::from(vec![(*i_p3).clone()]), shown: Text::lit("? _") }, Ctor { name: Text::lit("nil"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("nil") }])),
        crate::check::types::Ty::TySig(m2894_3_0, i_p4) if (&m2894_3_0 == &Text::lit("~")) => Some(Array::from(vec![Ctor { name: Text::lit("~"), arity: Nat::from(1u32), args: Array::from(vec![(*i_p4).clone()]), shown: Text::lit("~ _") }, Ctor { name: Text::lit("Error"), arity: Nat::from(2u32), args: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text()]), shown: Text::lit("Error(..)") }])),
        crate::check::types::Ty::TyTuple(ts_p5) => Some(Array::from(vec![Ctor { name: Text::lit("tuple"), arity: len(&ts_p5), args: ts_p5.clone(), shown: Text::from(format!("(({}))", &crate::syntax::lexer::chars::join(&each(&ts_p5, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", ")))) }])),
        crate::check::types::Ty::TyCon(m2894_5_0, m2894_5_1) if (&m2894_5_0 == &Text::lit("Prelude.Error")) && ((&m2894_5_1).len() == 0) => Some(Array::from(vec![Ctor { name: Text::lit("Error"), arity: Nat::from(2u32), args: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text()]), shown: Text::lit("Error(..)") }])),
        crate::check::types::Ty::TyCon(n_p6, args_p7) => match get(&env_p0.g.types, &n_p6) {
            Some(ti_p8) => match &ti_p8.body {
                crate::check::env::TyBody::BChoice(cases_p9) => Some(run_to_end(each_job(cases_p9.clone(), {
                    let ti_p8 = ti_p8.clone();
                    let args_p7 = args_p7.clone();
                    Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                        let ti_p8 = ti_p8.clone();
                        let args_p7 = args_p7.clone();
                        entered(once_job(move || {
                            let (cn_pa, cargs_pb) = p0;
                            prism_rtl::Turn::More(Rc::new(CtorOfCase { ti_p0: ti_p8.clone(), cn_p1: cn_pa.clone(), cargs_p2: cargs_pb.clone(), args_p3: args_p7.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<Ctor>>>
                }))),
                crate::check::env::TyBody::BRecord(fields_pc) => Some(Array::from(vec![Ctor { name: n_p6.clone(), arity: len(fields_pc), args: run_to_end(each_job(fields_pc.clone(), {
                    let ti_p8 = ti_p8.clone();
                    let args_p7 = args_p7.clone();
                    Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                        let ti_p8 = ti_p8.clone();
                        let args_p7 = args_p7.clone();
                        entered(once_job(move || {
                            let (_, ft_pd) = p0;
                            prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: crate::check::env::reading::param_inst(&ti_p8.params, &args_p7), t_p1: ft_pd.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                })), shown: Text::from(format!("{}(..)", &crate::check::types::bare_name(&n_p6))) }])),
                crate::check::env::TyBody::BRowKind => if is_root_module(env_p0) {
                    Some(each(&tags_of_kind(env_p0, &n_p6), &(|tg_pe: &crate::check::env::TagInfo| tag_ctor(tg_pe))))
                } else {
                    None
                },
                _ => None,
            },
            None => if (&n_p6 == &Text::lit("Fault")) || (&n_p6 == &Text::lit("Prelude.Fault")) {
                if is_root_module(env_p0) {
                    Some(each(&tags_of_kind(env_p0, &Text::lit("Prelude.Fault")), &(|tg_pf: &crate::check::env::TagInfo| tag_ctor(tg_pf))))
                } else {
                    None
                }
            } else {
                None
            },
        },
        crate::check::types::Ty::TyElem(rw_pg, _) => {
            let w_ph = crate::check::types::recording::walk_row(st_p1, &rw_pg);
            if &w_ph.tail != &crate::check::types::Tail::TlClosed {
                None
            } else {
                Some(each(&tags_of_row(env_p0, &w_ph), &(|tg_pi: &crate::check::env::TagInfo| tag_ctor(tg_pi))))
            }
        },
        crate::check::types::Ty::TyElemAny(rw_pj) => {
            let w_pk = crate::check::types::recording::walk_row(st_p1, &rw_pj);
            if &w_pk.tail != &crate::check::types::Tail::TlClosed {
                None
            } else {
                Some(each(&tags_of_row(env_p0, &w_pk), &(|tg_pl: &crate::check::env::TagInfo| tag_ctor(tg_pl))))
            }
        },
        _ => None,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CtorsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
/// ```
pub struct CtorsOf {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<Option<Array<Ctor>>> for CtorsOf {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<Ctor>>> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let env_p0 = env_p0.clone();
        let st_p1 = st_p1.clone();
        let t_p2 = t_p2.clone();
        call_then(crate::check::types::recording::start_walk(st_p1.clone(), t_p2.clone()), move |walk_2900: crate::check::types::Ty| match walk_2900 {
            crate::check::types::Ty::TyCon(m2894_0_0, m2894_0_1) if (&m2894_0_0 == &Text::lit("Bool")) && ((&m2894_0_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("True"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("True") }, Ctor { name: Text::lit("False"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("False") }]))),
            crate::check::types::Ty::TyCon(m2894_1_0, m2894_1_1) if (&m2894_1_0 == &Text::lit("unit")) && ((&m2894_1_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("unit"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("unit") }]))),
            crate::check::types::Ty::TySig(m2894_2_0, i_p3) if (&m2894_2_0 == &Text::lit("?")) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("?"), arity: Nat::from(1u32), args: Array::from(vec![(*i_p3).clone()]), shown: Text::lit("? _") }, Ctor { name: Text::lit("nil"), arity: Nat::from(0u32), args: Array::new(), shown: Text::lit("nil") }]))),
            crate::check::types::Ty::TySig(m2894_3_0, i_p4) if (&m2894_3_0 == &Text::lit("~")) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("~"), arity: Nat::from(1u32), args: Array::from(vec![(*i_p4).clone()]), shown: Text::lit("~ _") }, Ctor { name: Text::lit("Error"), arity: Nat::from(2u32), args: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text()]), shown: Text::lit("Error(..)") }]))),
            crate::check::types::Ty::TyTuple(ts_p5) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("tuple"), arity: len(&ts_p5), args: ts_p5.clone(), shown: Text::from(format!("(({}))", &crate::syntax::lexer::chars::join(&each(&ts_p5, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", ")))) }]))),
            crate::check::types::Ty::TyCon(m2894_5_0, m2894_5_1) if (&m2894_5_0 == &Text::lit("Prelude.Error")) && ((&m2894_5_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::lit("Error"), arity: Nat::from(2u32), args: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("Prelude.Fault"), Array::new()), crate::check::types::t_text()]), shown: Text::lit("Error(..)") }]))),
            crate::check::types::Ty::TyCon(n_p6, args_p7) => match get(&env_p0.g.types, &n_p6) {
                Some(ti_p8) => match &ti_p8.body {
                    crate::check::env::TyBody::BChoice(cases_p9) => prism_rtl::Turn::Finished(Some(run_to_end(each_job(cases_p9.clone(), {
                        let ti_p8 = ti_p8.clone();
                        let args_p7 = args_p7.clone();
                        Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                            let ti_p8 = ti_p8.clone();
                            let args_p7 = args_p7.clone();
                            entered(once_job(move || {
                                let (cn_pa, cargs_pb) = p0;
                                prism_rtl::Turn::More(Rc::new(CtorOfCase { ti_p0: ti_p8.clone(), cn_p1: cn_pa.clone(), cargs_p2: cargs_pb.clone(), args_p3: args_p7.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<Ctor>>>
                    })))),
                    crate::check::env::TyBody::BRecord(fields_pc) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: n_p6.clone(), arity: len(fields_pc), args: run_to_end(each_job(fields_pc.clone(), {
                        let ti_p8 = ti_p8.clone();
                        let args_p7 = args_p7.clone();
                        Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                            let ti_p8 = ti_p8.clone();
                            let args_p7 = args_p7.clone();
                            entered(once_job(move || {
                                let (_, ft_pd) = p0;
                                prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: crate::check::env::reading::param_inst(&ti_p8.params, &args_p7), t_p1: ft_pd.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                    })), shown: Text::from(format!("{}(..)", &crate::check::types::bare_name(&n_p6))) }]))),
                    crate::check::env::TyBody::BRowKind => if is_root_module(&env_p0) {
                        prism_rtl::Turn::Finished(Some(each(&tags_of_kind(&env_p0, &n_p6), &(|tg_pe: &crate::check::env::TagInfo| tag_ctor(tg_pe)))))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    },
                    _ => prism_rtl::Turn::Finished(None),
                },
                None => if (&n_p6 == &Text::lit("Fault")) || (&n_p6 == &Text::lit("Prelude.Fault")) {
                    if is_root_module(&env_p0) {
                        prism_rtl::Turn::Finished(Some(each(&tags_of_kind(&env_p0, &Text::lit("Prelude.Fault")), &(|tg_pf: &crate::check::env::TagInfo| tag_ctor(tg_pf)))))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    }
                } else {
                    prism_rtl::Turn::Finished(None)
                },
            },
            crate::check::types::Ty::TyElem(rw_pg, _) => call_then(crate::check::types::recording::start_walk_row(st_p1.clone(), rw_pg.clone()), move |walk_row_4329: crate::check::types::Rw| {
                let w_ph = walk_row_4329;
                if &w_ph.tail != &crate::check::types::Tail::TlClosed {
                    prism_rtl::Turn::Finished(None)
                } else {
                    prism_rtl::Turn::Finished(Some(each(&tags_of_row(&env_p0, &w_ph), &(|tg_pi: &crate::check::env::TagInfo| tag_ctor(tg_pi)))))
                }
            }),
            crate::check::types::Ty::TyElemAny(rw_pj) => call_then(crate::check::types::recording::start_walk_row(st_p1.clone(), rw_pj.clone()), move |walk_row_4473: crate::check::types::Rw| {
                let w_pk = walk_row_4473;
                if &w_pk.tail != &crate::check::types::Tail::TlClosed {
                    prism_rtl::Turn::Finished(None)
                } else {
                    prism_rtl::Turn::Finished(Some(each(&tags_of_row(&env_p0, &w_pk), &(|tg_pl: &crate::check::env::TagInfo| tag_ctor(tg_pl)))))
                }
            }),
            _ => prism_rtl::Turn::Finished(None),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start CtorsOf, x`: what the function value is when passed to `@Run`.
pub fn start_ctors_of(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Option<Array<Ctor>>>> {
    Rc::new(CtorsOf { env_p0, st_p1, t_p2 })
}

/// ```prism
/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
/// ```
pub fn ctor_of_case(ti_p0: &crate::check::env::TyInfo, cn_p1: &Text, cargs_p2: &Array<crate::check::types::Ty>, args_p3: &Array<crate::check::types::Ty>) -> Ctor {
    let qk_p4 = crate::check::env::qual_key(&ti_p0.home, cn_p1);
    Ctor { name: qk_p4.clone(), arity: len(cargs_p2), args: run_to_end(each_job(cargs_p2.clone(), {
        let ti_p0 = ti_p0.clone();
        let args_p3 = args_p3.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let ti_p0 = ti_p0.clone();
            let args_p3 = args_p3.clone();
            entered(once_job(move || {
                let a_p5 = p0;
                prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: crate::check::env::reading::param_inst(&ti_p0.params, &args_p3), t_p1: a_p5.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
    })), shown: if &len(cargs_p2) == &Nat::from(0u32) {
        cn_p1.clone()
    } else {
        Text::from(format!("{} {}", cn_p1, &crate::syntax::lexer::chars::join(&each(cargs_p2, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", "))))
    } }
}

/// The step machine of `CtorOfCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
/// ```
pub struct CtorOfCase {
    pub ti_p0: crate::check::env::TyInfo,
    pub cn_p1: Text,
    pub cargs_p2: Array<crate::check::types::Ty>,
    pub args_p3: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<Ctor> for CtorOfCase {
    fn cycle(&self) -> prism_rtl::Turn<Ctor> {
        let ti_p0 = &self.ti_p0;
        let cn_p1 = &self.cn_p1;
        let cargs_p2 = &self.cargs_p2;
        let args_p3 = &self.args_p3;
        let qk_p4 = crate::check::env::qual_key(&ti_p0.home, cn_p1);
        let args_p3 = args_p3.clone();
        let cargs_p2 = cargs_p2.clone();
        let cn_p1 = cn_p1.clone();
        let ti_p0 = ti_p0.clone();
        call_value(each_job(cargs_p2.clone(), {
            let ti_p0 = ti_p0.clone();
            let args_p3 = args_p3.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let ti_p0 = ti_p0.clone();
                let args_p3 = args_p3.clone();
                entered(once_job(move || {
                    let a_p5 = p0;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: crate::check::env::reading::param_inst(&ti_p0.params, &args_p3), t_p1: a_p5.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }), move |each_4772: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(Ctor { name: qk_p4.clone(), arity: len(&cargs_p2), args: each_4772, shown: if &len(&cargs_p2) == &Nat::from(0u32) {
            cn_p1.clone()
        } else {
            Text::from(format!("{} {}", &cn_p1, &crate::syntax::lexer::chars::join(&each(&cargs_p2, &(|_: &crate::check::types::Ty| Text::lit("_"))), &Text::lit(", "))))
        } }))
    }
}

/// `Start CtorOfCase, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_of_case(ti_p0: crate::check::env::TyInfo, cn_p1: Text, cargs_p2: Array<crate::check::types::Ty>, args_p3: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<Ctor>> {
    Rc::new(CtorOfCase { ti_p0, cn_p1, cargs_p2, args_p3 })
}

/// ```prism
/// TagCtor: fn TagInfo -> Ctor
/// ```
pub fn tag_ctor(tg_p0: &crate::check::env::TagInfo) -> Ctor {
    Ctor { name: Text::from(format!("tag:{}", &tg_p0.name)), arity: len(&tg_p0.fields), args: each(&tg_p0.fields, &(|(_, ft_p1): &(Text, crate::check::types::Ty)| crate::check::types::Ty::TyErr)), shown: tg_p0.name.clone() }
}

/// ```prism
/// IsRootModule: fn Env -> Bool
/// ```
pub fn is_root_module(env_p0: &crate::check::expr::Env) -> bool {
    &env_p0.home == &Text::lit("")
}

/// ```prism
/// TagsOfKind: fn Env, Text -> [TagInfo]
/// ```
pub fn tags_of_kind(env_p0: &crate::check::expr::Env, kind_p1: &Text) -> Array<crate::check::env::TagInfo> {
    filter(&values(&env_p0.g.tags), &(|tg_p2: &crate::check::env::TagInfo| (&tg_p2.kind == kind_p1) || ((&crate::check::types::bare_name(&tg_p2.kind) == &Text::lit("Fault")) && (&crate::check::types::bare_name(kind_p1) == &Text::lit("Fault")))))
}

/// ```prism
/// TagsOfRow: fn Env, Rw -> [TagInfo]
/// ```
pub fn tags_of_row(env_p0: &crate::check::expr::Env, w_p1: &crate::check::types::Rw) -> Array<crate::check::env::TagInfo> {
    filter(&values(&env_p0.g.tags), &(|tg_p2: &crate::check::env::TagInfo| ((&tg_p2.kind == &Text::lit("Element")) && crate::check::types::has_text(&w_p1.fams, &tg_p2.family)) && !crate::check::types::has_text(&w_p1.minus, &tg_p2.name)))
}

/// ```prism
/// ToPat: unbounded fn Env, Pattern -> Pat
/// ```
pub fn to_pat(env_p0: &crate::check::expr::Env, p_p1: &crate::syntax::Pattern_) -> Pat {
    match &*p_p1.kind {
        crate::syntax::PatternKind::PName(n_p2) => {
            let bare_p3 = or(&index(&n_p2.path_, &Nat::from(0u32)), &Text::lit(""));
            if (&len(&n_p2.path_) > &Nat::from(1u32)) && crate::check::env::has_key(&env_p0.g.tags, &crate::check::env::dotted(&n_p2.path_)) {
                Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted(&n_p2.path_))), Array::new())
            } else {
                if (crate::check::env::is_upper_text(&bare_p3) && (&len_text(&n_p2.sigils) == &Nat::from(0u32))) && crate::check::expr::patterns::is_ctor_name(env_p0, n_p2) {
                    Pat::PtCon(ctor_key(env_p0, n_p2), Array::new())
                } else {
                    Pat::PtAny
                }
            }
        },
        crate::syntax::PatternKind::PIgnore => Pat::PtAny,
        crate::syntax::PatternKind::PLit(l_p4) => Pat::PtLit(lit_text(l_p4)),
        crate::syntax::PatternKind::PNeg(l_p5) => Pat::PtLit(Text::from(format!("-{}", &lit_text(l_p5)))),
        crate::syntax::PatternKind::PUnit => Pat::PtCon(Text::lit("unit"), Array::new()),
        crate::syntax::PatternKind::PNil => Pat::PtCon(Text::lit("nil"), Array::new()),
        crate::syntax::PatternKind::PCtor(n_p6, args_p7) => if crate::check::env::has_key(&env_p0.g.tags, &crate::check::env::dotted(&n_p6.path_)) {
            Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted(&n_p6.path_))), Array::new())
        } else {
            Pat::PtCon(ctor_key(env_p0, n_p6), run_to_end(each_job(args_p7.clone(), {
                let env_p0 = env_p0.clone();
                Rc::new(move |p0: crate::syntax::Pattern_| {
                    let env_p0 = env_p0.clone();
                    entered(once_job(move || {
                        let a_p8 = p0;
                        prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0.clone(), p_p1: a_p8.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
        crate::syntax::PatternKind::PRecord(n_p9, fields_pa, _) => record_pat(env_p0, n_p9, fields_pa),
        crate::syntax::PatternKind::PSigil(s_pb, q_pc) => Pat::PtCon(s_pb.clone(), Array::from(vec![to_pat(env_p0, &**q_pc)])),
        crate::syntax::PatternKind::PTuple(ps_pd) => Pat::PtCon(Text::lit("tuple"), run_to_end(each_job(ps_pd.clone(), {
            let env_p0 = env_p0.clone();
            Rc::new(move |p0: crate::syntax::Pattern_| {
                let env_p0 = env_p0.clone();
                entered(once_job(move || {
                    let q_pe = p0;
                    prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0.clone(), p_p1: q_pe.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
        }))),
        crate::syntax::PatternKind::PArray(ps_pf) => Pat::PtCon(Text::from(format!("len{}", &len(ps_pf))), run_to_end(each_job(ps_pf.clone(), {
            let env_p0 = env_p0.clone();
            Rc::new(move |p0: crate::syntax::Pattern_| {
                let env_p0 = env_p0.clone();
                entered(once_job(move || {
                    let q_pg = p0;
                    prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0.clone(), p_p1: q_pg.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
        }))),
        crate::syntax::PatternKind::PGroup(q_ph) => to_pat(env_p0, &**q_ph),
        crate::syntax::PatternKind::PFamily(q_pi) => Pat::PtFam(crate::check::env::dotted(&q_pi.path_)),
    }
}

/// The step machine of `ToPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPat: unbounded fn Env, Pattern -> Pat
/// ```
pub struct ToPat {
    pub env_p0: crate::check::expr::Env,
    pub p_p1: crate::syntax::Pattern_,
}

impl prism_rtl::Job<Pat> for ToPat {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env_p0 = &self.env_p0;
        let p_p1 = &self.p_p1;
        match &*p_p1.kind {
            crate::syntax::PatternKind::PName(n_p2) => {
                let bare_p3 = or(&index(&n_p2.path_, &Nat::from(0u32)), &Text::lit(""));
                if (&len(&n_p2.path_) > &Nat::from(1u32)) && crate::check::env::has_key(&env_p0.g.tags, &crate::check::env::dotted(&n_p2.path_)) {
                    prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted(&n_p2.path_))), Array::new()))
                } else {
                    if (crate::check::env::is_upper_text(&bare_p3) && (&len_text(&n_p2.sigils) == &Nat::from(0u32))) && crate::check::expr::patterns::is_ctor_name(env_p0, n_p2) {
                        prism_rtl::Turn::Finished(Pat::PtCon(ctor_key(env_p0, n_p2), Array::new()))
                    } else {
                        prism_rtl::Turn::Finished(Pat::PtAny)
                    }
                }
            },
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(Pat::PtAny),
            crate::syntax::PatternKind::PLit(l_p4) => prism_rtl::Turn::Finished(Pat::PtLit(lit_text(l_p4))),
            crate::syntax::PatternKind::PNeg(l_p5) => prism_rtl::Turn::Finished(Pat::PtLit(Text::from(format!("-{}", &lit_text(l_p5))))),
            crate::syntax::PatternKind::PUnit => prism_rtl::Turn::Finished(Pat::PtCon(Text::lit("unit"), Array::new())),
            crate::syntax::PatternKind::PNil => prism_rtl::Turn::Finished(Pat::PtCon(Text::lit("nil"), Array::new())),
            crate::syntax::PatternKind::PCtor(n_p6, args_p7) => if crate::check::env::has_key(&env_p0.g.tags, &crate::check::env::dotted(&n_p6.path_)) {
                prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &crate::check::env::dotted(&n_p6.path_))), Array::new()))
            } else {
                {
                    let args_p7 = args_p7.clone();
                    let env_p0 = env_p0.clone();
                    let n_p6 = n_p6.clone();
                    call_value(each_job(args_p7.clone(), {
                        let env_p0 = env_p0.clone();
                        Rc::new(move |p0: crate::syntax::Pattern_| {
                            let env_p0 = env_p0.clone();
                            entered(once_job(move || {
                                let a_p8 = p0;
                                prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0.clone(), p_p1: a_p8.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                    }), move |each_6274: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(ctor_key(&env_p0, &n_p6), each_6274)))
                }
            },
            crate::syntax::PatternKind::PRecord(n_p9, fields_pa, _) => prism_rtl::Turn::More(Rc::new(RecordPat { env_p0: env_p0.clone(), n_p1: n_p9.clone(), fields_p2: fields_pa.clone() })),
            crate::syntax::PatternKind::PSigil(s_pb, q_pc) => {
                let env_p0 = env_p0.clone();
                let q_pc = (**q_pc).clone();
                let s_pb = s_pb.clone();
                call_then(start_to_pat(env_p0.clone(), q_pc.clone()), move |to_pat_6389: Pat| prism_rtl::Turn::Finished(Pat::PtCon(s_pb.clone(), Array::from(vec![to_pat_6389]))))
            },
            crate::syntax::PatternKind::PTuple(ps_pd) => {
                let env_p0 = env_p0.clone();
                let ps_pd = ps_pd.clone();
                call_value(each_job(ps_pd.clone(), {
                    let env_p0 = env_p0.clone();
                    Rc::new(move |p0: crate::syntax::Pattern_| {
                        let env_p0 = env_p0.clone();
                        entered(once_job(move || {
                            let q_pe = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0.clone(), p_p1: q_pe.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_6436: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::lit("tuple"), each_6436)))
            },
            crate::syntax::PatternKind::PArray(ps_pf) => {
                let env_p0 = env_p0.clone();
                let ps_pf = ps_pf.clone();
                call_value(each_job(ps_pf.clone(), {
                    let env_p0 = env_p0.clone();
                    Rc::new(move |p0: crate::syntax::Pattern_| {
                        let env_p0 = env_p0.clone();
                        entered(once_job(move || {
                            let q_pg = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0.clone(), p_p1: q_pg.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_6501: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("len{}", &len(&ps_pf))), each_6501)))
            },
            crate::syntax::PatternKind::PGroup(q_ph) => prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0.clone(), p_p1: (**q_ph).clone() })),
            crate::syntax::PatternKind::PFamily(q_pi) => prism_rtl::Turn::Finished(Pat::PtFam(crate::check::env::dotted(&q_pi.path_))),
        }
    }
}

/// `Start ToPat, x`: what the function value is when passed to `@Run`.
pub fn start_to_pat(env_p0: crate::check::expr::Env, p_p1: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(ToPat { env_p0, p_p1 })
}

/// ```prism
/// LitText: fn Literal -> Text
/// ```
pub fn lit_text(l_p0: &crate::syntax::Literal) -> Text {
    match &l_p0.kind {
        crate::syntax::LitKind::LInt(d_p1) => d_p1.clone(),
        crate::syntax::LitKind::LFloat(d_p2) => d_p2.clone(),
        crate::syntax::LitKind::LChar(c_p3) => Text::from(format!("\'{}\'", c_p3)),
        crate::syntax::LitKind::LText(segs_p4) => concat(&each(segs_p4, &lit_seg_text)),
        crate::syntax::LitKind::LDuration(d_p5, u_p6) => Text::from(format!("{}{}", d_p5, u_p6)),
        crate::syntax::LitKind::LRegex(r_p7) => Text::from(format!("%/{}/", &r_p7.pattern)),
    }
}

/// ```prism
/// LitSegText: fn TextSeg -> Text
/// ```
pub fn lit_seg_text(text_seg0: &crate::syntax::TextSeg) -> Text {
    match text_seg0 {
        crate::syntax::TextSeg::SegPlain(t_p0) => t_p0.clone(),
        _ => Text::lit("{}"),
    }
}

/// ```prism
/// CtorKey: fn Env, SName -> Text
/// ```
pub fn ctor_key(env_p0: &crate::check::expr::Env, n_p1: &crate::syntax::SName) -> Text {
    let (qk_o2, _) = crate::check::env::names::resolve_value(&env_p0.g, &env_p0.home, n_p1);
    or(&qk_o2, &crate::check::env::sname_key(n_p1))
}

/// ```prism
/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
/// ```
pub fn record_pat(env_p0: &crate::check::expr::Env, n_p1: &crate::syntax::SName, fields_p2: &Array<crate::syntax::FieldPat>) -> Pat {
    let name_p3 = crate::check::env::dotted(&n_p1.path_);
    match get(&env_p0.g.tags, &name_p3) {
        Some(tg_p4) => {
            let names_p5 = each(&tg_p4.fields, &(|(f_p6, _): &(Text, crate::check::types::Ty)| f_p6.clone()));
            Pat::PtCon(Text::from(format!("tag:{}", &name_p3)), run_to_end(each_job(names_p5.clone(), {
                let env_p0 = env_p0.clone();
                let fields_p2 = fields_p2.clone();
                let names_p5 = names_p5.clone();
                Rc::new(move |p0: Text| {
                    let env_p0 = env_p0.clone();
                    let fields_p2 = fields_p2.clone();
                    let names_p5 = names_p5.clone();
                    entered(once_job(move || {
                        let f_p7 = p0;
                        prism_rtl::Turn::More(Rc::new(FieldPatFor { env_p0: env_p0.clone(), fields_p1: fields_p2.clone(), names_p2: names_p5.clone(), f_p3: f_p7.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
        None => {
            let qk_p8 = ctor_key(env_p0, n_p1);
            let fnames_p9 = if &crate::check::types::bare_name(&qk_p8) == &Text::lit("Error") {
                Array::from(vec![Text::lit("kind"), Text::lit("message")])
            } else {
                or(&get(&env_p0.g.ctors, &qk_p8), &dummy_ctor()).fields.clone()
            };
            let pkey_pa = if &crate::check::types::bare_name(&qk_p8) == &Text::lit("Error") {
                Text::lit("Error")
            } else {
                qk_p8.clone()
            };
            Pat::PtCon(pkey_pa.clone(), run_to_end(each_job(fnames_p9.clone(), {
                let env_p0 = env_p0.clone();
                let fields_p2 = fields_p2.clone();
                let fnames_p9 = fnames_p9.clone();
                Rc::new(move |p0: Text| {
                    let env_p0 = env_p0.clone();
                    let fields_p2 = fields_p2.clone();
                    let fnames_p9 = fnames_p9.clone();
                    entered(once_job(move || {
                        let f_pb = p0;
                        prism_rtl::Turn::More(Rc::new(FieldPatFor { env_p0: env_p0.clone(), fields_p1: fields_p2.clone(), names_p2: fnames_p9.clone(), f_p3: f_pb.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
    }
}

/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
/// ```
pub struct RecordPat {
    pub env_p0: crate::check::expr::Env,
    pub n_p1: crate::syntax::SName,
    pub fields_p2: Array<crate::syntax::FieldPat>,
}

impl prism_rtl::Job<Pat> for RecordPat {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env_p0 = &self.env_p0;
        let n_p1 = &self.n_p1;
        let fields_p2 = &self.fields_p2;
        let name_p3 = crate::check::env::dotted(&n_p1.path_);
        match get(&env_p0.g.tags, &name_p3) {
            Some(tg_p4) => {
                let names_p5 = each(&tg_p4.fields, &(|(f_p6, _): &(Text, crate::check::types::Ty)| f_p6.clone()));
                let env_p0 = env_p0.clone();
                let fields_p2 = fields_p2.clone();
                call_value(each_job(names_p5.clone(), {
                    let env_p0 = env_p0.clone();
                    let fields_p2 = fields_p2.clone();
                    let names_p5 = names_p5.clone();
                    Rc::new(move |p0: Text| {
                        let env_p0 = env_p0.clone();
                        let fields_p2 = fields_p2.clone();
                        let names_p5 = names_p5.clone();
                        entered(once_job(move || {
                            let f_p7 = p0;
                            prism_rtl::Turn::More(Rc::new(FieldPatFor { env_p0: env_p0.clone(), fields_p1: fields_p2.clone(), names_p2: names_p5.clone(), f_p3: f_p7.clone() }))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_7371: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &name_p3)), each_7371)))
            },
            None => {
                let qk_p8 = ctor_key(env_p0, n_p1);
                let fnames_p9 = if &crate::check::types::bare_name(&qk_p8) == &Text::lit("Error") {
                    Array::from(vec![Text::lit("kind"), Text::lit("message")])
                } else {
                    or(&get(&env_p0.g.ctors, &qk_p8), &dummy_ctor()).fields.clone()
                };
                let pkey_pa = if &crate::check::types::bare_name(&qk_p8) == &Text::lit("Error") {
                    Text::lit("Error")
                } else {
                    qk_p8.clone()
                };
                let env_p0 = env_p0.clone();
                let fields_p2 = fields_p2.clone();
                call_value(each_job(fnames_p9.clone(), {
                    let env_p0 = env_p0.clone();
                    let fields_p2 = fields_p2.clone();
                    let fnames_p9 = fnames_p9.clone();
                    Rc::new(move |p0: Text| {
                        let env_p0 = env_p0.clone();
                        let fields_p2 = fields_p2.clone();
                        let fnames_p9 = fnames_p9.clone();
                        entered(once_job(move || {
                            let f_pb = p0;
                            prism_rtl::Turn::More(Rc::new(FieldPatFor { env_p0: env_p0.clone(), fields_p1: fields_p2.clone(), names_p2: fnames_p9.clone(), f_p3: f_pb.clone() }))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_7687: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(pkey_pa.clone(), each_7687)))
            },
        }
    }
}

/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
pub fn start_record_pat(env_p0: crate::check::expr::Env, n_p1: crate::syntax::SName, fields_p2: Array<crate::syntax::FieldPat>) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(RecordPat { env_p0, n_p1, fields_p2 })
}

/// ```prism
/// let dummyCtor
/// ```
pub fn dummy_ctor() -> crate::check::env::CtorInfo {
    crate::check::env::CtorInfo { name: Text::lit(""), owner: Text::lit(""), params: Array::new(), args: Array::new(), fields: Array::new(), ty: crate::check::types::Ty::TyErr, index: Nat::from(0u32) }
}

/// ```prism
/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
/// ```
pub fn field_pat_for(env_p0: &crate::check::expr::Env, fields_p1: &Array<crate::syntax::FieldPat>, names_p2: &Array<Text>, f_p3: &Text) -> Pat {
    run_to_end(fold_job(crate::check::errors::range0(&len(fields_p1)), Pat::PtAny, {
        let fields_p1 = fields_p1.clone();
        let names_p2 = names_p2.clone();
        let f_p3 = f_p3.clone();
        let env_p0 = env_p0.clone();
        Rc::new(move |(p0, p1): (Pat, Nat)| {
            let fields_p1 = fields_p1.clone();
            let names_p2 = names_p2.clone();
            let f_p3 = f_p3.clone();
            let env_p0 = env_p0.clone();
            entered(once_job(move || {
                let acc_p4 = p0;
                let i_p5 = p1;
                match index(&fields_p1, &i_p5) {
                    Some(fp_p6) => if &crate::check::expr::patterns::field_pat_name(&fp_p6, &names_p2, &i_p5) == &f_p3 {
                        prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0.clone(), p_p1: fp_p6.pattern.clone() }))
                    } else {
                        prism_rtl::Turn::Finished(acc_p4.clone())
                    },
                    None => prism_rtl::Turn::Finished(acc_p4.clone()),
                }
            }))
        }) as Rc<dyn Fn((Pat, Nat)) -> Rc<dyn prism_rtl::Job<Pat>>>
    }))
}

/// The step machine of `FieldPatFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
/// ```
pub struct FieldPatFor {
    pub env_p0: crate::check::expr::Env,
    pub fields_p1: Array<crate::syntax::FieldPat>,
    pub names_p2: Array<Text>,
    pub f_p3: Text,
}

impl prism_rtl::Job<Pat> for FieldPatFor {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env_p0 = &self.env_p0;
        let fields_p1 = &self.fields_p1;
        let names_p2 = &self.names_p2;
        let f_p3 = &self.f_p3;
        fold_job(crate::check::errors::range0(&len(fields_p1)), Pat::PtAny, {
            let fields_p1 = fields_p1.clone();
            let names_p2 = names_p2.clone();
            let f_p3 = f_p3.clone();
            let env_p0 = env_p0.clone();
            Rc::new(move |(p0, p1): (Pat, Nat)| {
                let fields_p1 = fields_p1.clone();
                let names_p2 = names_p2.clone();
                let f_p3 = f_p3.clone();
                let env_p0 = env_p0.clone();
                entered(once_job(move || {
                    let acc_p4 = p0;
                    let i_p5 = p1;
                    match index(&fields_p1, &i_p5) {
                        Some(fp_p6) => if &crate::check::expr::patterns::field_pat_name(&fp_p6, &names_p2, &i_p5) == &f_p3 {
                            prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0.clone(), p_p1: fp_p6.pattern.clone() }))
                        } else {
                            prism_rtl::Turn::Finished(acc_p4.clone())
                        },
                        None => prism_rtl::Turn::Finished(acc_p4.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Pat, Nat)) -> Rc<dyn prism_rtl::Job<Pat>>>
        }).cycle()
    }
}

/// `Start FieldPatFor, x`: what the function value is when passed to `@Run`.
pub fn start_field_pat_for(env_p0: crate::check::expr::Env, fields_p1: Array<crate::syntax::FieldPat>, names_p2: Array<Text>, f_p3: Text) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(FieldPatFor { env_p0, fields_p1, names_p2, f_p3 })
}

/// ```prism
/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
/// ```
pub fn useful(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, rows_p2: &Array<Array<Pat>>, q_p3: &Array<Pat>, tys_p4: &Array<crate::check::types::Ty>) -> bool {
    match index(q_p3, &Nat::from(0u32)) {
        None => &len(rows_p2) == &Nat::from(0u32),
        Some(q1_p5) => {
            let t1_p6 = or(&index(tys_p4, &Nat::from(0u32)), &crate::check::types::Ty::TyErr);
            let rest_p7 = drop(tys_p4, &Nat::from(1u32));
            match &q1_p5 {
                Pat::PtCon(c_p8, args_p9) => {
                    let ctor_pa = ctor_named(env_p0, st_p1, &t1_p6, c_p8, &len(args_p9));
                    useful(env_p0, st_p1, &specialize(rows_p2, &ctor_pa), &append(args_p9, &drop(q_p3, &Nat::from(1u32))), &append(&ctor_pa.args, &rest_p7))
                },
                Pat::PtLit(l_pb) => useful(env_p0, st_p1, &specialize_lit(rows_p2, l_pb), &drop(q_p3, &Nat::from(1u32)), &rest_p7),
                Pat::PtFam(f_pc) => match ctors_of(env_p0, st_p1, &t1_p6) {
                    Some(cs_pd) => run_to_end(fold_job(filter(&cs_pd, &(|c_pe: &Ctor| &ctor_family(c_pe) == f_pc)), false, {
                        let env_p0 = env_p0.clone();
                        let st_p1 = st_p1.clone();
                        let rows_p2 = rows_p2.clone();
                        let q_p3 = q_p3.clone();
                        let rest_p7 = rest_p7.clone();
                        Rc::new(move |(p0, p1): (bool, Ctor)| {
                            let env_p0 = env_p0.clone();
                            let st_p1 = st_p1.clone();
                            let rows_p2 = rows_p2.clone();
                            let q_p3 = q_p3.clone();
                            let rest_p7 = rest_p7.clone();
                            entered(once_job(move || {
                                let seen_pf = p0;
                                let c_pg = p1;
                                prism_rtl::Turn::Finished(seen_pf || useful(&env_p0, &st_p1, &specialize(&rows_p2, &c_pg), &append(&wilds(&c_pg.arity), &drop(&q_p3, &Nat::from(1u32))), &append(&c_pg.args, &rest_p7)))
                            }))
                        }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                    })),
                    None => useful(env_p0, st_p1, &default_rows(rows_p2), &drop(q_p3, &Nat::from(1u32)), &rest_p7),
                },
                Pat::PtAny => {
                    let heads_ph = head_names(rows_p2);
                    match ctors_of(env_p0, st_p1, &t1_p6) {
                        Some(cs_pi) => if complete(&cs_pi, &heads_ph, rows_p2) {
                            run_to_end(fold_job(cs_pi.clone(), false, {
                                let env_p0 = env_p0.clone();
                                let st_p1 = st_p1.clone();
                                let rows_p2 = rows_p2.clone();
                                let q_p3 = q_p3.clone();
                                let rest_p7 = rest_p7.clone();
                                Rc::new(move |(p0, p1): (bool, Ctor)| {
                                    let env_p0 = env_p0.clone();
                                    let st_p1 = st_p1.clone();
                                    let rows_p2 = rows_p2.clone();
                                    let q_p3 = q_p3.clone();
                                    let rest_p7 = rest_p7.clone();
                                    entered(once_job(move || {
                                        let seen_pj = p0;
                                        let c_pk = p1;
                                        prism_rtl::Turn::Finished(seen_pj || useful(&env_p0, &st_p1, &specialize(&rows_p2, &c_pk), &append(&wilds(&c_pk.arity), &drop(&q_p3, &Nat::from(1u32))), &append(&c_pk.args, &rest_p7)))
                                    }))
                                }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }))
                        } else {
                            useful(env_p0, st_p1, &default_rows(rows_p2), &drop(q_p3, &Nat::from(1u32)), &rest_p7)
                        },
                        None => useful(env_p0, st_p1, &default_rows(rows_p2), &drop(q_p3, &Nat::from(1u32)), &rest_p7),
                    }
                },
            }
        },
    }
}

/// The step machine of `Useful`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
/// ```
pub struct Useful {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub rows_p2: Array<Array<Pat>>,
    pub q_p3: Array<Pat>,
    pub tys_p4: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<bool> for Useful {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let rows_p2 = &self.rows_p2;
        let q_p3 = &self.q_p3;
        let tys_p4 = &self.tys_p4;
        match index(q_p3, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(&len(rows_p2) == &Nat::from(0u32)),
            Some(q1_p5) => {
                let t1_p6 = or(&index(tys_p4, &Nat::from(0u32)), &crate::check::types::Ty::TyErr);
                let rest_p7 = drop(tys_p4, &Nat::from(1u32));
                match &q1_p5 {
                    Pat::PtCon(c_p8, args_p9) => {
                        let args_p9 = args_p9.clone();
                        let c_p8 = c_p8.clone();
                        let env_p0 = env_p0.clone();
                        let q_p3 = q_p3.clone();
                        let rows_p2 = rows_p2.clone();
                        let st_p1 = st_p1.clone();
                        call_then(start_ctor_named(env_p0.clone(), st_p1.clone(), t1_p6.clone(), c_p8.clone(), len(&args_p9)), move |ctor_named_8483: Ctor| {
                            let ctor_pa = ctor_named_8483;
                            prism_rtl::Turn::More(Rc::new(Useful { env_p0: env_p0.clone(), st_p1: st_p1.clone(), rows_p2: specialize(&rows_p2, &ctor_pa), q_p3: append(&args_p9, &drop(&q_p3, &Nat::from(1u32))), tys_p4: append(&ctor_pa.args, &rest_p7) }))
                        })
                    },
                    Pat::PtLit(l_pb) => prism_rtl::Turn::More(Rc::new(Useful { env_p0: env_p0.clone(), st_p1: st_p1.clone(), rows_p2: specialize_lit(rows_p2, l_pb), q_p3: drop(q_p3, &Nat::from(1u32)), tys_p4: rest_p7.clone() })),
                    Pat::PtFam(f_pc) => {
                        let env_p0 = env_p0.clone();
                        let f_pc = f_pc.clone();
                        let q_p3 = q_p3.clone();
                        let rows_p2 = rows_p2.clone();
                        let st_p1 = st_p1.clone();
                        call_then(start_ctors_of(env_p0.clone(), st_p1.clone(), t1_p6.clone()), move |ctors_of_8737: Option<Array<Ctor>>| match ctors_of_8737 {
                            Some(cs_pd) => fold_job(filter(&cs_pd, &(|c_pe: &Ctor| &ctor_family(c_pe) == &f_pc)), false, {
                                let env_p0 = env_p0.clone();
                                let st_p1 = st_p1.clone();
                                let rows_p2 = rows_p2.clone();
                                let q_p3 = q_p3.clone();
                                let rest_p7 = rest_p7.clone();
                                Rc::new(move |(p0, p1): (bool, Ctor)| {
                                    let env_p0 = env_p0.clone();
                                    let st_p1 = st_p1.clone();
                                    let rows_p2 = rows_p2.clone();
                                    let q_p3 = q_p3.clone();
                                    let rest_p7 = rest_p7.clone();
                                    entered(once_job(move || {
                                        let seen_pf = p0;
                                        let c_pg = p1;
                                        prism_rtl::Turn::Finished(seen_pf || useful(&env_p0, &st_p1, &specialize(&rows_p2, &c_pg), &append(&wilds(&c_pg.arity), &drop(&q_p3, &Nat::from(1u32))), &append(&c_pg.args, &rest_p7)))
                                    }))
                                }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }).cycle(),
                            None => prism_rtl::Turn::More(Rc::new(Useful { env_p0: env_p0.clone(), st_p1: st_p1.clone(), rows_p2: default_rows(&rows_p2), q_p3: drop(&q_p3, &Nat::from(1u32)), tys_p4: rest_p7.clone() })),
                        })
                    },
                    Pat::PtAny => {
                        let heads_ph = head_names(rows_p2);
                        let env_p0 = env_p0.clone();
                        let q_p3 = q_p3.clone();
                        let rows_p2 = rows_p2.clone();
                        let st_p1 = st_p1.clone();
                        call_then(start_ctors_of(env_p0.clone(), st_p1.clone(), t1_p6.clone()), move |ctors_of_9109: Option<Array<Ctor>>| match ctors_of_9109 {
                            Some(cs_pi) => if complete(&cs_pi, &heads_ph, &rows_p2) {
                                fold_job(cs_pi.clone(), false, {
                                    let env_p0 = env_p0.clone();
                                    let st_p1 = st_p1.clone();
                                    let rows_p2 = rows_p2.clone();
                                    let q_p3 = q_p3.clone();
                                    let rest_p7 = rest_p7.clone();
                                    Rc::new(move |(p0, p1): (bool, Ctor)| {
                                        let env_p0 = env_p0.clone();
                                        let st_p1 = st_p1.clone();
                                        let rows_p2 = rows_p2.clone();
                                        let q_p3 = q_p3.clone();
                                        let rest_p7 = rest_p7.clone();
                                        entered(once_job(move || {
                                            let seen_pj = p0;
                                            let c_pk = p1;
                                            prism_rtl::Turn::Finished(seen_pj || useful(&env_p0, &st_p1, &specialize(&rows_p2, &c_pk), &append(&wilds(&c_pk.arity), &drop(&q_p3, &Nat::from(1u32))), &append(&c_pk.args, &rest_p7)))
                                        }))
                                    }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                                }).cycle()
                            } else {
                                prism_rtl::Turn::More(Rc::new(Useful { env_p0: env_p0.clone(), st_p1: st_p1.clone(), rows_p2: default_rows(&rows_p2), q_p3: drop(&q_p3, &Nat::from(1u32)), tys_p4: rest_p7.clone() }))
                            },
                            None => prism_rtl::Turn::More(Rc::new(Useful { env_p0: env_p0.clone(), st_p1: st_p1.clone(), rows_p2: default_rows(&rows_p2), q_p3: drop(&q_p3, &Nat::from(1u32)), tys_p4: rest_p7.clone() })),
                        })
                    },
                }
            },
        }
    }
}

/// `Start Useful, x`: what the function value is when passed to `@Run`.
pub fn start_useful(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, rows_p2: Array<Array<Pat>>, q_p3: Array<Pat>, tys_p4: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Useful { env_p0, st_p1, rows_p2, q_p3, tys_p4 })
}

/// ```prism
/// CtorFamily: fn Ctor -> Text
/// ```
pub fn ctor_family(c_p0: &Ctor) -> Text {
    if crate::syntax::lexer::chars::has_prefix(&c_p0.name, &Text::lit("tag:")) {
        crate::check::env::dotted(&crate::syntax::lexer::chars::pop(&split_on(&crate::syntax::lexer::chars::drop_prefix(&c_p0.name, &Text::lit("tag:")), &Text::lit("."))))
    } else {
        Text::lit("")
    }
}

/// ```prism
/// Wilds: fn Nat -> [Pat]
/// ```
pub fn wilds(n_p0: &Nat) -> Array<Pat> {
    each(&crate::check::errors::range0(n_p0), &(|_: &Nat| Pat::PtAny))
}

/// ```prism
/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
/// ```
pub fn ctor_named(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty, c_p3: &Text, arity_p4: &Nat) -> Ctor {
    match ctors_of(env_p0, st_p1, t_p2) {
        Some(cs_p5) => match find_ctor(&cs_p5, c_p3) {
            Some(found_p6) => found_p6,
            None => Ctor { name: c_p3.clone(), arity: arity_p4.clone(), args: each(&crate::check::errors::range0(arity_p4), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown: c_p3.clone() },
        },
        None => Ctor { name: c_p3.clone(), arity: arity_p4.clone(), args: each(&crate::check::errors::range0(arity_p4), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown: c_p3.clone() },
    }
}

/// The step machine of `CtorNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
/// ```
pub struct CtorNamed {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
    pub c_p3: Text,
    pub arity_p4: Nat,
}

impl prism_rtl::Job<Ctor> for CtorNamed {
    fn cycle(&self) -> prism_rtl::Turn<Ctor> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let c_p3 = &self.c_p3;
        let arity_p4 = &self.arity_p4;
        let arity_p4 = arity_p4.clone();
        let c_p3 = c_p3.clone();
        let env_p0 = env_p0.clone();
        let st_p1 = st_p1.clone();
        let t_p2 = t_p2.clone();
        call_then(start_ctors_of(env_p0.clone(), st_p1.clone(), t_p2.clone()), move |ctors_of_9906: Option<Array<Ctor>>| match ctors_of_9906 {
            Some(cs_p5) => match find_ctor(&cs_p5, &c_p3) {
                Some(found_p6) => prism_rtl::Turn::Finished(found_p6.clone()),
                None => prism_rtl::Turn::Finished(Ctor { name: c_p3.clone(), arity: arity_p4.clone(), args: each(&crate::check::errors::range0(&arity_p4), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown: c_p3.clone() }),
            },
            None => prism_rtl::Turn::Finished(Ctor { name: c_p3.clone(), arity: arity_p4.clone(), args: each(&crate::check::errors::range0(&arity_p4), &(|_: &Nat| crate::check::types::Ty::TyErr)), shown: c_p3.clone() }),
        })
    }
}

/// `Start CtorNamed, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_named(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty, c_p3: Text, arity_p4: Nat) -> Rc<dyn prism_rtl::Job<Ctor>> {
    Rc::new(CtorNamed { env_p0, st_p1, t_p2, c_p3, arity_p4 })
}

/// ```prism
/// ?FindCtor: fn [Ctor], Text -> ?Ctor
/// ```
pub fn find_ctor(cs_p0: &Array<Ctor>, c_p1: &Text) -> Option<Ctor> {
    fold(cs_p0, &None, &(|found_o2: &Option<Ctor>, x_p3: &Ctor| match found_o2 {
        Some(f_p4) => Some(f_p4.clone()),
        None => if (&x_p3.name == c_p1) || (&crate::check::types::bare_name(&x_p3.name) == &crate::check::types::bare_name(c_p1)) {
            Some(x_p3.clone())
        } else {
            None
        },
    }))
}

/// ```prism
/// Specialize: fn [ [Pat] ], Ctor -> [ [Pat] ]
/// ```
pub fn specialize(rows_p0: &Array<Array<Pat>>, c_p1: &Ctor) -> Array<Array<Pat>> {
    fold(rows_p0, &Array::new(), &(|acc_p2: &Array<Array<Pat>>, prow_p3: &Array<Pat>| match index(prow_p3, &Nat::from(0u32)) {
        Some(Pat::PtCon(d_p4, args_p5)) => if (&d_p4 == &c_p1.name) || (&crate::check::types::bare_name(&d_p4) == &crate::check::types::bare_name(&c_p1.name)) {
            push(acc_p2, &append(&pad(&args_p5, &c_p1.arity), &drop(prow_p3, &Nat::from(1u32))))
        } else {
            acc_p2.clone()
        },
        Some(Pat::PtAny) => push(acc_p2, &append(&wilds(&c_p1.arity), &drop(prow_p3, &Nat::from(1u32)))),
        Some(Pat::PtFam(f_p6)) => if &ctor_family(c_p1) == &f_p6 {
            push(acc_p2, &append(&wilds(&c_p1.arity), &drop(prow_p3, &Nat::from(1u32))))
        } else {
            acc_p2.clone()
        },
        _ => acc_p2.clone(),
    }))
}

/// ```prism
/// Pad: fn [Pat], Nat -> [Pat]
/// ```
pub fn pad(args_p0: &Array<Pat>, n_p1: &Nat) -> Array<Pat> {
    if &len(args_p0) >= n_p1 {
        take(args_p0, n_p1)
    } else {
        append(args_p0, &wilds(&or(&n_p1.checked_sub(&len(args_p0)), &Nat::from(0u32))))
    }
}

/// ```prism
/// SpecializeLit: fn [ [Pat] ], Text -> [ [Pat] ]
/// ```
pub fn specialize_lit(rows_p0: &Array<Array<Pat>>, l_p1: &Text) -> Array<Array<Pat>> {
    fold(rows_p0, &Array::new(), &(|acc_p2: &Array<Array<Pat>>, prow_p3: &Array<Pat>| match index(prow_p3, &Nat::from(0u32)) {
        Some(Pat::PtLit(m_p4)) => if &m_p4 == l_p1 {
            push(acc_p2, &drop(prow_p3, &Nat::from(1u32)))
        } else {
            acc_p2.clone()
        },
        Some(Pat::PtAny) => push(acc_p2, &drop(prow_p3, &Nat::from(1u32))),
        _ => acc_p2.clone(),
    }))
}

/// ```prism
/// DefaultRows: fn [ [Pat] ] -> [ [Pat] ]
/// ```
pub fn default_rows(rows_p0: &Array<Array<Pat>>) -> Array<Array<Pat>> {
    fold(rows_p0, &Array::new(), &(|acc_p1: &Array<Array<Pat>>, prow_p2: &Array<Pat>| match index(prow_p2, &Nat::from(0u32)) {
        Some(Pat::PtAny) => push(acc_p1, &drop(prow_p2, &Nat::from(1u32))),
        _ => acc_p1.clone(),
    }))
}

/// ```prism
/// HeadNames: fn [ [Pat] ] -> [Text]
/// ```
pub fn head_names(rows_p0: &Array<Array<Pat>>) -> Array<Text> {
    fold(rows_p0, &Array::new(), &(|acc_p1: &Array<Text>, prow_p2: &Array<Pat>| match index(prow_p2, &Nat::from(0u32)) {
        Some(Pat::PtCon(c_p3, _)) => crate::check::types::add_text(acc_p1, &c_p3),
        Some(Pat::PtFam(f_p4)) => crate::check::types::add_text(acc_p1, &Text::from(format!("fam:{}", &f_p4))),
        _ => acc_p1.clone(),
    }))
}

/// ```prism
/// Complete: fn [Ctor], [Text], [ [Pat] ] -> Bool
/// ```
pub fn complete(cs_p0: &Array<Ctor>, heads_p1: &Array<Text>, rows_p2: &Array<Array<Pat>>) -> bool {
    (&len(cs_p0) > &Nat::from(0u32)) && fold(cs_p0, &true, &(|ok_p3: &bool, c_p4: &Ctor| *ok_p3 && ((crate::check::types::has_text(heads_p1, &c_p4.name) || crate::check::types::has_text(&each(heads_p1, &(|h_p5: &Text| crate::check::types::bare_name(h_p5))), &crate::check::types::bare_name(&c_p4.name))) || crate::check::types::has_text(heads_p1, &Text::from(format!("fam:{}", &ctor_family(c_p4)))))))
}

/// ```prism
/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
/// ```
pub fn witness(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, rows_p2: &Array<Array<Pat>>, tys_p3: &Array<crate::check::types::Ty>) -> Option<Array<Text>> {
    match index(tys_p3, &Nat::from(0u32)) {
        None => if &len(rows_p2) == &Nat::from(0u32) { Some(Array::new()) } else { None },
        Some(t1_p4) => {
            let rest_p5 = drop(tys_p3, &Nat::from(1u32));
            let heads_p6 = head_names(rows_p2);
            match ctors_of(env_p0, st_p1, &t1_p4) {
                Some(cs_p7) => if complete(&cs_p7, &heads_p6, rows_p2) {
                    run_to_end(fold_job(cs_p7.clone(), None, {
                        let env_p0 = env_p0.clone();
                        let st_p1 = st_p1.clone();
                        let rows_p2 = rows_p2.clone();
                        let rest_p5 = rest_p5.clone();
                        Rc::new(move |(p0, p1): (Option<Array<Text>>, Ctor)| {
                            let env_p0 = env_p0.clone();
                            let st_p1 = st_p1.clone();
                            let rows_p2 = rows_p2.clone();
                            let rest_p5 = rest_p5.clone();
                            entered(once_job(move || {
                                let found_o8 = p0;
                                let c_p9 = p1;
                                match &found_o8 {
                                    Some(f_pa) => prism_rtl::Turn::Finished(Some(f_pa.clone())),
                                    None => call_then(start_witness(env_p0.clone(), st_p1.clone(), specialize(&rows_p2, &c_p9), append(&c_p9.args, &rest_p5)), move |witness_12482: Option<Array<Text>>| match witness_12482 {
                                        Some(w_pb) => prism_rtl::Turn::Finished(Some(append(&Array::from(vec![show_witness(&c_p9, &take(&w_pb, &c_p9.arity))]), &drop(&w_pb, &c_p9.arity)))),
                                        None => prism_rtl::Turn::Finished(None),
                                    }),
                                }
                            }))
                        }) as Rc<dyn Fn((Option<Array<Text>>, Ctor)) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>>>
                    }))
                } else {
                    match witness(env_p0, st_p1, &default_rows(rows_p2), &rest_p5) {
                        Some(w_pc) => {
                            let missing_pd = filter(&cs_p7, &(|c_pf: &Ctor| !(crate::check::types::has_text(&heads_p6, &c_pf.name) || crate::check::types::has_text(&heads_p6, &Text::from(format!("fam:{}", &ctor_family(c_pf)))))));
                            let shown_pe = match index(&missing_pd, &Nat::from(0u32)) {
                                Some(c_pg) => c_pg.shown.clone(),
                                None => Text::lit("_"),
                            };
                            Some(append(&Array::from(vec![shown_pe.clone()]), &w_pc))
                        },
                        None => None,
                    }
                },
                None => match witness(env_p0, st_p1, &default_rows(rows_p2), &rest_p5) {
                    Some(w_ph) => Some(append(&Array::from(vec![Text::lit("_")]), &w_ph)),
                    None => None,
                },
            }
        },
    }
}

/// The step machine of `Witness`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
/// ```
pub struct Witness {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub rows_p2: Array<Array<Pat>>,
    pub tys_p3: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<Option<Array<Text>>> for Witness {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<Text>>> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let rows_p2 = &self.rows_p2;
        let tys_p3 = &self.tys_p3;
        match index(tys_p3, &Nat::from(0u32)) {
            None => if &len(rows_p2) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(Some(Array::new()))
            } else {
                prism_rtl::Turn::Finished(None)
            },
            Some(t1_p4) => {
                let rest_p5 = drop(tys_p3, &Nat::from(1u32));
                let heads_p6 = head_names(rows_p2);
                let env_p0 = env_p0.clone();
                let rows_p2 = rows_p2.clone();
                let st_p1 = st_p1.clone();
                call_then(start_ctors_of(env_p0.clone(), st_p1.clone(), t1_p4.clone()), move |ctors_of_12268: Option<Array<Ctor>>| match ctors_of_12268 {
                    Some(cs_p7) => if complete(&cs_p7, &heads_p6, &rows_p2) {
                        fold_job(cs_p7.clone(), None, {
                            let env_p0 = env_p0.clone();
                            let st_p1 = st_p1.clone();
                            let rows_p2 = rows_p2.clone();
                            let rest_p5 = rest_p5.clone();
                            Rc::new(move |(p0, p1): (Option<Array<Text>>, Ctor)| {
                                let env_p0 = env_p0.clone();
                                let st_p1 = st_p1.clone();
                                let rows_p2 = rows_p2.clone();
                                let rest_p5 = rest_p5.clone();
                                entered(once_job(move || {
                                    let found_o8 = p0;
                                    let c_p9 = p1;
                                    match &found_o8 {
                                        Some(f_pa) => prism_rtl::Turn::Finished(Some(f_pa.clone())),
                                        None => call_then(start_witness(env_p0.clone(), st_p1.clone(), specialize(&rows_p2, &c_p9), append(&c_p9.args, &rest_p5)), move |witness_12482: Option<Array<Text>>| match witness_12482 {
                                            Some(w_pb) => prism_rtl::Turn::Finished(Some(append(&Array::from(vec![show_witness(&c_p9, &take(&w_pb, &c_p9.arity))]), &drop(&w_pb, &c_p9.arity)))),
                                            None => prism_rtl::Turn::Finished(None),
                                        }),
                                    }
                                }))
                            }) as Rc<dyn Fn((Option<Array<Text>>, Ctor)) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>>>
                        }).cycle()
                    } else {
                        call_then(start_witness(env_p0.clone(), st_p1.clone(), default_rows(&rows_p2), rest_p5.clone()), move |witness_12712: Option<Array<Text>>| match witness_12712 {
                            Some(w_pc) => {
                                let missing_pd = filter(&cs_p7, &(|c_pf: &Ctor| !(crate::check::types::has_text(&heads_p6, &c_pf.name) || crate::check::types::has_text(&heads_p6, &Text::from(format!("fam:{}", &ctor_family(c_pf)))))));
                                let shown_pe = match index(&missing_pd, &Nat::from(0u32)) {
                                    Some(c_pg) => c_pg.shown.clone(),
                                    None => Text::lit("_"),
                                };
                                prism_rtl::Turn::Finished(Some(append(&Array::from(vec![shown_pe.clone()]), &w_pc)))
                            },
                            None => prism_rtl::Turn::Finished(None),
                        })
                    },
                    None => call_then(start_witness(env_p0.clone(), st_p1.clone(), default_rows(&rows_p2), rest_p5.clone()), move |witness_13138: Option<Array<Text>>| match witness_13138 {
                        Some(w_ph) => prism_rtl::Turn::Finished(Some(append(&Array::from(vec![Text::lit("_")]), &w_ph))),
                        None => prism_rtl::Turn::Finished(None),
                    }),
                })
            },
        }
    }
}

/// `Start Witness, x`: what the function value is when passed to `@Run`.
pub fn start_witness(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, rows_p2: Array<Array<Pat>>, tys_p3: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>> {
    Rc::new(Witness { env_p0, st_p1, rows_p2, tys_p3 })
}

/// ```prism
/// ShowWitness: fn Ctor, [Text] -> Text
/// ```
pub fn show_witness(c_p0: &Ctor, args_p1: &Array<Text>) -> Text {
    if &c_p0.name == &Text::lit("?") {
        Text::from(format!("? {}", &or(&index(args_p1, &Nat::from(0u32)), &Text::lit("_"))))
    } else {
        if &c_p0.name == &Text::lit("~") {
            Text::from(format!("~ {}", &or(&index(args_p1, &Nat::from(0u32)), &Text::lit("_"))))
        } else {
            if &c_p0.name == &Text::lit("tuple") {
                Text::from(format!("(({}))", &crate::syntax::lexer::chars::join(args_p1, &Text::lit(", "))))
            } else {
                if (&len(args_p1) == &Nat::from(0u32)) || fold(args_p1, &true, &(|ok_p2: &bool, a_p3: &Text| *ok_p2 && (a_p3 == &Text::lit("_")))) {
                    c_p0.shown.clone()
                } else {
                    Text::from(format!("{} {}", &crate::check::types::bare_name(&c_p0.name), &crate::syntax::lexer::chars::join(args_p1, &Text::lit(", "))))
                }
            }
        }
    }
}

/// ```prism
/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
/// ```
pub fn match_coverage(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty, arms_p3: &Array<crate::syntax::Arm>, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    let has_otherwise_p5 = fold(arms_p3, &false, &(|seen_p7: &bool, a_p8: &crate::syntax::Arm| *seen_p7 || (&a_p8.pattern == &None)));
    let tys_p6 = Array::from(vec![t_p2.clone()]);
    let (rows_pi, st2_pj) = run_to_end(fold_job(arms_p3.clone(), (Array::new(), st_p1.clone()), {
        let env_p0 = env_p0.clone();
        let tys_p6 = tys_p6.clone();
        let t_p2 = t_p2.clone();
        Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)| {
            let env_p0 = env_p0.clone();
            let tys_p6 = tys_p6.clone();
            let t_p2 = t_p2.clone();
            entered(once_job(move || {
                let (acc_p9, s_pa) = p0;
                let arm_pb = p1;
                {
                    let q_pc = match &arm_pb.pattern {
                        Some(p_ph) => Array::from(vec![to_pat(&env_p0, p_ph)]),
                        None => Array::from(vec![Pat::PtAny]),
                    };
                    call_then(start_useful(env_p0.clone(), s_pa.clone(), acc_p9.clone(), q_pc.clone(), tys_p6.clone()), move |useful_14224: bool| {
                        let reachable_pd = useful_14224;
                        call_then(start_owns_row(env_p0.clone(), s_pa.clone(), t_p2.clone()), move |owns_row_14273: bool| {
                            let owns_all_pe = owns_row_14273;
                            let s2_pf = if reachable_pd {
                                s_pa.clone()
                            } else {
                                if (&arm_pb.pattern == &None) && !owns_all_pe {
                                    s_pa.clone()
                                } else {
                                    crate::check::types::recording::err_fix(&s_pa, &Text::lit("unreachable"), &arm_span(&arm_pb), &Text::lit("this arm is never reached"), &Text::lit("remove it, or put it above the arm that covers it"))
                                }
                            };
                            let acc2_pg = if &arm_pb.guard == &None { push(&acc_p9, &q_pc) } else { acc_p9.clone() };
                            prism_rtl::Turn::Finished((acc2_pg.clone(), s2_pf.clone()))
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
    }));
    if has_otherwise_p5 {
        st2_pj.clone()
    } else {
        if is_open_row(env_p0, &st2_pj, t_p2) {
            crate::check::types::recording::err_fix(&st2_pj, &Text::lit("row-not-closed"), span_p4, &Text::from(format!("a match over `{}` needs `otherwise:`", &crate::check::types::show_ty(&st2_pj, t_p2))), &Text::lit("add an `otherwise:` arm: the row\'s variable may hold tags this match cannot name"))
        } else {
            match witness(env_p0, &st2_pj, &rows_pi, &tys_p6) {
                Some(w_pk) => crate::check::types::recording::err_fix(&st2_pj, &Text::lit("not-exhaustive"), span_p4, &Text::from(format!("this match misses `{}`", &crate::syntax::lexer::chars::join(&w_pk, &Text::lit(", ")))), &Text::lit("add an arm for it, or `otherwise:`")),
                None => st2_pj.clone(),
            }
        }
    }
}

/// The step machine of `MatchCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
/// ```
pub struct MatchCoverage {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
    pub arms_p3: Array<crate::syntax::Arm>,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for MatchCoverage {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let arms_p3 = &self.arms_p3;
        let span_p4 = &self.span_p4;
        let has_otherwise_p5 = fold(arms_p3, &false, &(|seen_p7: &bool, a_p8: &crate::syntax::Arm| *seen_p7 || (&a_p8.pattern == &None)));
        let tys_p6 = Array::from(vec![t_p2.clone()]);
        let arms_p3 = arms_p3.clone();
        let env_p0 = env_p0.clone();
        let span_p4 = span_p4.clone();
        let st_p1 = st_p1.clone();
        let t_p2 = t_p2.clone();
        call_value(fold_job(arms_p3.clone(), (Array::new(), st_p1.clone()), {
            let env_p0 = env_p0.clone();
            let tys_p6 = tys_p6.clone();
            let t_p2 = t_p2.clone();
            Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)| {
                let env_p0 = env_p0.clone();
                let tys_p6 = tys_p6.clone();
                let t_p2 = t_p2.clone();
                entered(once_job(move || {
                    let (acc_p9, s_pa) = p0;
                    let arm_pb = p1;
                    {
                        let q_pc = match &arm_pb.pattern {
                            Some(p_ph) => Array::from(vec![to_pat(&env_p0, p_ph)]),
                            None => Array::from(vec![Pat::PtAny]),
                        };
                        call_then(start_useful(env_p0.clone(), s_pa.clone(), acc_p9.clone(), q_pc.clone(), tys_p6.clone()), move |useful_14224: bool| {
                            let reachable_pd = useful_14224;
                            call_then(start_owns_row(env_p0.clone(), s_pa.clone(), t_p2.clone()), move |owns_row_14273: bool| {
                                let owns_all_pe = owns_row_14273;
                                let s2_pf = if reachable_pd {
                                    s_pa.clone()
                                } else {
                                    if (&arm_pb.pattern == &None) && !owns_all_pe {
                                        s_pa.clone()
                                    } else {
                                        crate::check::types::recording::err_fix(&s_pa, &Text::lit("unreachable"), &arm_span(&arm_pb), &Text::lit("this arm is never reached"), &Text::lit("remove it, or put it above the arm that covers it"))
                                    }
                                };
                                let acc2_pg = if &arm_pb.guard == &None { push(&acc_p9, &q_pc) } else { acc_p9.clone() };
                                prism_rtl::Turn::Finished((acc2_pg.clone(), s2_pf.clone()))
                            })
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
        }), move |fold_14057: (Array<Array<Pat>>, crate::check::types::St)| {
            let (rows_pi, st2_pj) = fold_14057;
            if has_otherwise_p5 {
                prism_rtl::Turn::Finished(st2_pj.clone())
            } else {
                call_then(start_is_open_row(env_p0.clone(), st2_pj.clone(), t_p2.clone()), move |is_open_row_14621: bool| if is_open_row_14621 {
                    call_then(crate::check::types::start_show_ty(st2_pj.clone(), t_p2.clone()), move |show_ty_14696: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st2_pj, &Text::lit("row-not-closed"), &span_p4, &Text::from(format!("a match over `{}` needs `otherwise:`", &show_ty_14696)), &Text::lit("add an `otherwise:` arm: the row\'s variable may hold tags this match cannot name"))))
                } else {
                    call_then(start_witness(env_p0.clone(), st2_pj.clone(), rows_pi.clone(), tys_p6.clone()), move |witness_14832: Option<Array<Text>>| match witness_14832 {
                        Some(w_pk) => prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st2_pj, &Text::lit("not-exhaustive"), &span_p4, &Text::from(format!("this match misses `{}`", &crate::syntax::lexer::chars::join(&w_pk, &Text::lit(", ")))), &Text::lit("add an arm for it, or `otherwise:`"))),
                        None => prism_rtl::Turn::Finished(st2_pj.clone()),
                    })
                })
            }
        })
    }
}

/// `Start MatchCoverage, x`: what the function value is when passed to `@Run`.
pub fn start_match_coverage(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty, arms_p3: Array<crate::syntax::Arm>, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(MatchCoverage { env_p0, st_p1, t_p2, arms_p3, span_p4 })
}

/// ```prism
/// ArmSpan: fn Arm -> Range
/// ```
pub fn arm_span(a_p0: &crate::syntax::Arm) -> crate::syntax::Range {
    match &a_p0.pattern {
        Some(p_p1) => p_p1.span.clone(),
        None => a_p0.span.clone(),
    }
}

/// ```prism
/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub fn is_open_row(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk(st_p1, t_p2) {
        crate::check::types::Ty::TyElem(rw_p3, _) => &crate::check::types::recording::walk_row(st_p1, &rw_p3).tail != &crate::check::types::Tail::TlClosed,
        crate::check::types::Ty::TyElemAny(rw_p4) => &crate::check::types::recording::walk_row(st_p1, &rw_p4).tail != &crate::check::types::Tail::TlClosed,
        crate::check::types::Ty::TyCon(n_p5, m15254_2_1) if ((&m15254_2_1).len() == 0) => match get(&env_p0.g.types, &n_p5) {
            Some(ti_p6) => (&ti_p6.body == &crate::check::env::TyBody::BRowKind) && !is_root_module(env_p0),
            None => ((&n_p5 == &Text::lit("Fault")) || (&n_p5 == &Text::lit("Prelude.Fault"))) && !is_root_module(env_p0),
        },
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `IsOpenRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub struct IsOpenRow {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for IsOpenRow {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let env_p0 = env_p0.clone();
        let st_p1 = st_p1.clone();
        let t_p2 = t_p2.clone();
        call_then(crate::check::types::recording::start_walk(st_p1.clone(), t_p2.clone()), move |walk_15260: crate::check::types::Ty| match walk_15260 {
            crate::check::types::Ty::TyElem(rw_p3, _) => call_then(crate::check::types::recording::start_walk_row(st_p1.clone(), rw_p3.clone()), move |walk_row_15296: crate::check::types::Rw| prism_rtl::Turn::Finished(&walk_row_15296.tail != &crate::check::types::Tail::TlClosed)),
            crate::check::types::Ty::TyElemAny(rw_p4) => call_then(crate::check::types::recording::start_walk_row(st_p1.clone(), rw_p4.clone()), move |walk_row_15348: crate::check::types::Rw| prism_rtl::Turn::Finished(&walk_row_15348.tail != &crate::check::types::Tail::TlClosed)),
            crate::check::types::Ty::TyCon(n_p5, m15254_2_1) if ((&m15254_2_1).len() == 0) => match get(&env_p0.g.types, &n_p5) {
                Some(ti_p6) => prism_rtl::Turn::Finished((&ti_p6.body == &crate::check::env::TyBody::BRowKind) && !is_root_module(&env_p0)),
                None => prism_rtl::Turn::Finished(((&n_p5 == &Text::lit("Fault")) || (&n_p5 == &Text::lit("Prelude.Fault"))) && !is_root_module(&env_p0)),
            },
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start IsOpenRow, x`: what the function value is when passed to `@Run`.
pub fn start_is_open_row(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsOpenRow { env_p0, st_p1, t_p2 })
}

/// ```prism
/// OwnsRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub fn owns_row(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk(st_p1, t_p2) {
        crate::check::types::Ty::TyElem(rw_p3, _) => fold(&crate::check::types::recording::walk_row(st_p1, &rw_p3).fams, &true, &(|ok_p4: &bool, f_p5: &Text| *ok_p4 && (&or(&get(&env_p0.g.fam_owner, f_p5), &Text::lit("")) == &env_p0.home))),
        crate::check::types::Ty::TyCon(n_p6, m15723_1_1) if ((&m15723_1_1).len() == 0) => match get(&env_p0.g.types, &n_p6) {
            Some(ti_p7) => &ti_p7.body != &crate::check::env::TyBody::BRowKind,
            None => !((&n_p6 == &Text::lit("Fault")) || (&n_p6 == &Text::lit("Prelude.Fault"))),
        },
        _ => true,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `OwnsRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OwnsRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub struct OwnsRow {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for OwnsRow {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let env_p0 = env_p0.clone();
        let st_p1 = st_p1.clone();
        let t_p2 = t_p2.clone();
        call_then(crate::check::types::recording::start_walk(st_p1.clone(), t_p2.clone()), move |walk_15729: crate::check::types::Ty| match walk_15729 {
            crate::check::types::Ty::TyElem(rw_p3, _) => call_then(crate::check::types::recording::start_walk_row(st_p1.clone(), rw_p3.clone()), move |walk_row_15770: crate::check::types::Rw| prism_rtl::Turn::Finished(fold(&walk_row_15770.fams, &true, &(|ok_p4: &bool, f_p5: &Text| *ok_p4 && (&or(&get(&env_p0.g.fam_owner, f_p5), &Text::lit("")) == &env_p0.home))))),
            crate::check::types::Ty::TyCon(n_p6, m15723_1_1) if ((&m15723_1_1).len() == 0) => match get(&env_p0.g.types, &n_p6) {
                Some(ti_p7) => prism_rtl::Turn::Finished(&ti_p7.body != &crate::check::env::TyBody::BRowKind),
                None => prism_rtl::Turn::Finished(!((&n_p6 == &Text::lit("Fault")) || (&n_p6 == &Text::lit("Prelude.Fault")))),
            },
            _ => prism_rtl::Turn::Finished(true),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start OwnsRow, x`: what the function value is when passed to `@Run`.
pub fn start_owns_row(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(OwnsRow { env_p0, st_p1, t_p2 })
}

/// ```prism
/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
/// ```
pub fn clause_coverage(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, clauses_p2: &Array<crate::syntax::decls::FnClause>, params_p3: &Array<crate::check::types::Ty>, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    let (rows_pc, st2_pd) = run_to_end(fold_job(clauses_p2.clone(), (Array::new(), st_p1.clone()), {
        let env_p0 = env_p0.clone();
        let params_p3 = params_p3.clone();
        Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::decls::FnClause)| {
            let env_p0 = env_p0.clone();
            let params_p3 = params_p3.clone();
            entered(once_job(move || {
                let (acc_p5, s_p6) = p0;
                let c_p7 = p1;
                call_value(each_job(c_p7.params.clone(), {
                    let env_p0 = env_p0.clone();
                    Rc::new(move |p0: crate::syntax::Pattern_| {
                        let env_p0 = env_p0.clone();
                        entered(once_job(move || {
                            let p_pb = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0.clone(), p_p1: p_pb.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_16266: Array<Pat>| {
                    let q_p8 = each_16266;
                    let reachable_p9 = (&len(&q_p8) != &len(&params_p3)) || useful(&env_p0, &s_p6, &acc_p5, &q_p8, &params_p3);
                    let s2_pa = if reachable_p9 {
                        s_p6.clone()
                    } else {
                        crate::check::types::recording::err_fix(&s_p6, &Text::lit("unreachable"), &c_p7.span, &Text::lit("this clause is never reached"), &Text::lit("remove it, or put it above the clause that covers it"))
                    };
                    prism_rtl::Turn::Finished((push(&acc_p5, &q_p8), s2_pa.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
    }));
    if &len(params_p3) == &Nat::from(0u32) {
        st2_pd.clone()
    } else {
        match witness(env_p0, &st2_pd, &rows_pc, params_p3) {
            Some(w_pe) => crate::check::types::recording::err_fix(&st2_pd, &Text::lit("not-exhaustive"), span_p4, &Text::from(format!("these clauses miss `{}`", &crate::syntax::lexer::chars::join(&w_pe, &Text::lit(", ")))), &Text::lit("add a clause for it")),
            None => st2_pd.clone(),
        }
    }
}

/// The step machine of `ClauseCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
/// ```
pub struct ClauseCoverage {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub clauses_p2: Array<crate::syntax::decls::FnClause>,
    pub params_p3: Array<crate::check::types::Ty>,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for ClauseCoverage {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let clauses_p2 = &self.clauses_p2;
        let params_p3 = &self.params_p3;
        let span_p4 = &self.span_p4;
        let clauses_p2 = clauses_p2.clone();
        let env_p0 = env_p0.clone();
        let params_p3 = params_p3.clone();
        let span_p4 = span_p4.clone();
        let st_p1 = st_p1.clone();
        call_value(fold_job(clauses_p2.clone(), (Array::new(), st_p1.clone()), {
            let env_p0 = env_p0.clone();
            let params_p3 = params_p3.clone();
            Rc::new(move |(p0, p1): ((Array<Array<Pat>>, crate::check::types::St), crate::syntax::decls::FnClause)| {
                let env_p0 = env_p0.clone();
                let params_p3 = params_p3.clone();
                entered(once_job(move || {
                    let (acc_p5, s_p6) = p0;
                    let c_p7 = p1;
                    call_value(each_job(c_p7.params.clone(), {
                        let env_p0 = env_p0.clone();
                        Rc::new(move |p0: crate::syntax::Pattern_| {
                            let env_p0 = env_p0.clone();
                            entered(once_job(move || {
                                let p_pb = p0;
                                prism_rtl::Turn::More(Rc::new(ToPat { env_p0: env_p0.clone(), p_p1: p_pb.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                    }), move |each_16266: Array<Pat>| {
                        let q_p8 = each_16266;
                        let reachable_p9 = (&len(&q_p8) != &len(&params_p3)) || useful(&env_p0, &s_p6, &acc_p5, &q_p8, &params_p3);
                        let s2_pa = if reachable_p9 {
                            s_p6.clone()
                        } else {
                            crate::check::types::recording::err_fix(&s_p6, &Text::lit("unreachable"), &c_p7.span, &Text::lit("this clause is never reached"), &Text::lit("remove it, or put it above the clause that covers it"))
                        };
                        prism_rtl::Turn::Finished((push(&acc_p5, &q_p8), s2_pa.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<Array<Pat>>, crate::check::types::St), crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, crate::check::types::St)>>>
        }), move |fold_16205: (Array<Array<Pat>>, crate::check::types::St)| {
            let (rows_pc, st2_pd) = fold_16205;
            if &len(&params_p3) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(st2_pd.clone())
            } else {
                call_then(start_witness(env_p0.clone(), st2_pd.clone(), rows_pc.clone(), params_p3.clone()), move |witness_16615: Option<Array<Text>>| match witness_16615 {
                    Some(w_pe) => prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st2_pd, &Text::lit("not-exhaustive"), &span_p4, &Text::from(format!("these clauses miss `{}`", &crate::syntax::lexer::chars::join(&w_pe, &Text::lit(", ")))), &Text::lit("add a clause for it"))),
                    None => prism_rtl::Turn::Finished(st2_pd.clone()),
                })
            }
        })
    }
}

/// `Start ClauseCoverage, x`: what the function value is when passed to `@Run`.
pub fn start_clause_coverage(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, clauses_p2: Array<crate::syntax::decls::FnClause>, params_p3: Array<crate::check::types::Ty>, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ClauseCoverage { env_p0, st_p1, clauses_p2, params_p3, span_p4 })
}

/// ```prism
/// DischargeIncls: unbounded fn G, St, Nat -> St
/// ```
pub fn discharge_incls(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, from_p2: &Nat) -> crate::check::types::St {
    let batch_p3 = drop(&st_p1.incls, from_p2);
    run_to_end(fold_job(batch_p3.clone(), st_p1.clone(), {
        let g_p0 = g_p0.clone();
        let batch_p3 = batch_p3.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Incl)| {
            let g_p0 = g_p0.clone();
            let batch_p3 = batch_p3.clone();
            entered(once_job(move || {
                let s_p4 = p0;
                let inc_p5 = p1;
                call_then(start_through(s_p4.clone(), inc_p5.clone(), batch_p3.clone()), move |through_17456: crate::check::types::Incl| prism_rtl::Turn::More(Rc::new(DischargeOne { g_p0: g_p0.clone(), st_p1: s_p4.clone(), inc_p2: through_17456 })))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `DischargeIncls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DischargeIncls: unbounded fn G, St, Nat -> St
/// ```
pub struct DischargeIncls {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub from_p2: Nat,
}

impl prism_rtl::Job<crate::check::types::St> for DischargeIncls {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let from_p2 = &self.from_p2;
        let batch_p3 = drop(&st_p1.incls, from_p2);
        fold_job(batch_p3.clone(), st_p1.clone(), {
            let g_p0 = g_p0.clone();
            let batch_p3 = batch_p3.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Incl)| {
                let g_p0 = g_p0.clone();
                let batch_p3 = batch_p3.clone();
                entered(once_job(move || {
                    let s_p4 = p0;
                    let inc_p5 = p1;
                    call_then(start_through(s_p4.clone(), inc_p5.clone(), batch_p3.clone()), move |through_17456: crate::check::types::Incl| prism_rtl::Turn::More(Rc::new(DischargeOne { g_p0: g_p0.clone(), st_p1: s_p4.clone(), inc_p2: through_17456 })))
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start DischargeIncls, x`: what the function value is when passed to `@Run`.
pub fn start_discharge_incls(g_p0: crate::check::env::G, st_p1: crate::check::types::St, from_p2: Nat) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DischargeIncls { g_p0, st_p1, from_p2 })
}

/// ```prism
/// Through: unbounded fn St, Incl, [Incl] -> Incl
/// ```
pub fn through(st_p0: &crate::check::types::St, inc_p1: &crate::check::types::Incl, batch_p2: &Array<crate::check::types::Incl>) -> crate::check::types::Incl {
    let sup_p3 = crate::check::types::recording::walk_row(st_p0, &inc_p1.sup);
    match &sup_p3.tail {
        crate::check::types::Tail::TlFlex(n_p4) => if &len(&sup_p3.fams) > &Nat::from(0u32) {
            inc_p1.clone()
        } else {
            run_to_end(fold_job(batch_p2.clone(), inc_p1.clone(), {
                let st_p0 = st_p0.clone();
                let n_p4 = n_p4.clone();
                let inc_p1 = inc_p1.clone();
                Rc::new(move |(p0, p1): (crate::check::types::Incl, crate::check::types::Incl)| {
                    let st_p0 = st_p0.clone();
                    let n_p4 = n_p4.clone();
                    let inc_p1 = inc_p1.clone();
                    entered(once_job(move || {
                        let acc_p5 = p0;
                        let other_p6 = p1;
                        call_then(crate::check::types::recording::start_walk_row(st_p0.clone(), other_p6.sub.clone()), move |walk_row_17970: crate::check::types::Rw| {
                            let sub_p7 = walk_row_17970;
                            if ((&len(&sub_p7.fams) == &Nat::from(0u32)) && (&sub_p7.tail == &crate::check::types::Tail::TlFlex(n_p4.clone()))) && (&other_p6 != &inc_p1) {
                                prism_rtl::Turn::Finished({
                                    let mut this: crate::check::types::Incl = acc_p5.clone();
                                    this.sup = other_p6.sup.clone();
                                    this
                                })
                            } else {
                                prism_rtl::Turn::Finished(acc_p5.clone())
                            }
                        })
                    }))
                }) as Rc<dyn Fn((crate::check::types::Incl, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::Incl>>>
            }))
        },
        _ => inc_p1.clone(),
    }
}

/// The step machine of `Through`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Through: unbounded fn St, Incl, [Incl] -> Incl
/// ```
pub struct Through {
    pub st_p0: crate::check::types::St,
    pub inc_p1: crate::check::types::Incl,
    pub batch_p2: Array<crate::check::types::Incl>,
}

impl prism_rtl::Job<crate::check::types::Incl> for Through {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Incl> {
        let st_p0 = &self.st_p0;
        let inc_p1 = &self.inc_p1;
        let batch_p2 = &self.batch_p2;
        let batch_p2 = batch_p2.clone();
        let inc_p1 = inc_p1.clone();
        let st_p0 = st_p0.clone();
        call_then(crate::check::types::recording::start_walk_row(st_p0.clone(), inc_p1.sup.clone()), move |walk_row_17798: crate::check::types::Rw| {
            let sup_p3 = walk_row_17798;
            match &sup_p3.tail {
                crate::check::types::Tail::TlFlex(n_p4) => if &len(&sup_p3.fams) > &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(inc_p1.clone())
                } else {
                    fold_job(batch_p2.clone(), inc_p1.clone(), {
                        let st_p0 = st_p0.clone();
                        let n_p4 = n_p4.clone();
                        let inc_p1 = inc_p1.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::Incl, crate::check::types::Incl)| {
                            let st_p0 = st_p0.clone();
                            let n_p4 = n_p4.clone();
                            let inc_p1 = inc_p1.clone();
                            entered(once_job(move || {
                                let acc_p5 = p0;
                                let other_p6 = p1;
                                call_then(crate::check::types::recording::start_walk_row(st_p0.clone(), other_p6.sub.clone()), move |walk_row_17970: crate::check::types::Rw| {
                                    let sub_p7 = walk_row_17970;
                                    if ((&len(&sub_p7.fams) == &Nat::from(0u32)) && (&sub_p7.tail == &crate::check::types::Tail::TlFlex(n_p4.clone()))) && (&other_p6 != &inc_p1) {
                                        prism_rtl::Turn::Finished({
                                            let mut this: crate::check::types::Incl = acc_p5.clone();
                                            this.sup = other_p6.sup.clone();
                                            this
                                        })
                                    } else {
                                        prism_rtl::Turn::Finished(acc_p5.clone())
                                    }
                                })
                            }))
                        }) as Rc<dyn Fn((crate::check::types::Incl, crate::check::types::Incl)) -> Rc<dyn prism_rtl::Job<crate::check::types::Incl>>>
                    }).cycle()
                },
                _ => prism_rtl::Turn::Finished(inc_p1.clone()),
            }
        })
    }
}

/// `Start Through, x`: what the function value is when passed to `@Run`.
pub fn start_through(st_p0: crate::check::types::St, inc_p1: crate::check::types::Incl, batch_p2: Array<crate::check::types::Incl>) -> Rc<dyn prism_rtl::Job<crate::check::types::Incl>> {
    Rc::new(Through { st_p0, inc_p1, batch_p2 })
}

/// ```prism
/// DischargeOne: unbounded fn G, St, Incl -> St
/// ```
pub fn discharge_one(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, inc_p2: &crate::check::types::Incl) -> crate::check::types::St {
    let sub_p3 = crate::check::types::recording::walk_row(st_p1, &inc_p2.sub);
    let sup_p4 = crate::check::types::recording::walk_row(st_p1, &inc_p2.sup);
    let st1_p5 = match &sub_p3.tail {
        crate::check::types::Tail::TlFlex(n_p9) => close_tail(st_p1, n_p9),
        _ => st_p1.clone(),
    };
    let sub2_p6 = crate::check::types::recording::walk_row(&st1_p5, &inc_p2.sub);
    let left_p7 = filter(&sub2_p6.fams, &(|f_pa: &Text| !crate::check::types::has_text(&sup_p4.fams, f_pa) && (&len(&tags_left(g_p0, f_pa, &sub2_p6.minus)) > &Nat::from(0u32))));
    let tail_bad_p8 = match (sub2_p6.tail.clone(), sup_p4.tail.clone()) {
        (crate::check::types::Tail::TlRigid(a_pb), crate::check::types::Tail::TlRigid(b_pc)) => &a_pb != &b_pc,
        (crate::check::types::Tail::TlRigid(_), _) => true,
        _ => false,
    };
    if (&len(&left_p7) == &Nat::from(0u32)) && !tail_bad_p8 {
        st1_p5.clone()
    } else {
        {
            let s0_pd = {
                let mut this: crate::check::types::St = st1_p5.clone();
                this.file = inc_p2.file.clone();
                this
            };
            let tags_pe = fold(&left_p7, &Array::new(), &(|acc_pg: &Array<Text>, f_ph: &Text| append(acc_pg, &tags_left(g_p0, f_ph, &sub2_p6.minus))));
            let s1_pf = if inc_p2.forward {
                crate::check::types::recording::err_fix(&s0_pd, &Text::lit("forwarding"), &inc_p2.span, &Text::from(format!("forwarding {} from a scope that emits {}", &crate::syntax::lexer::chars::join(&tags_pe, &Text::lit(", ")), &crate::check::types::show_row(&sup_p4))), &Text::from(format!("answer {} above this arm, for example `{}(..): @ never`", &(if &len(&tags_pe) == &Nat::from(1u32) { Text::lit("it") } else { Text::lit("them") }), &or(&index(&tags_pe, &Nat::from(0u32)), &Text::lit("")))))
            } else {
                crate::check::types::recording::err_fix(&s0_pd, &Text::lit("row-outside"), &inc_p2.span, &Text::from(format!("a child that emits `{}` in a scope that emits `{}`", &crate::check::types::show_row(&sub2_p6), &crate::check::types::show_row(&sup_p4))), &Text::lit("widen the scope\'s `emit` row, or host the child with `@HostDocument`"))
            };
            {
                let mut this: crate::check::types::St = s1_pf.clone();
                this.file = st1_p5.file.clone();
                this
            }
        }
    }
}

/// The step machine of `DischargeOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DischargeOne: unbounded fn G, St, Incl -> St
/// ```
pub struct DischargeOne {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub inc_p2: crate::check::types::Incl,
}

impl prism_rtl::Job<crate::check::types::St> for DischargeOne {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let inc_p2 = &self.inc_p2;
        let g_p0 = g_p0.clone();
        let inc_p2 = inc_p2.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::types::recording::start_walk_row(st_p1.clone(), inc_p2.sub.clone()), move |walk_row_18289: crate::check::types::Rw| {
            let sub_p3 = walk_row_18289;
            call_then(crate::check::types::recording::start_walk_row(st_p1.clone(), inc_p2.sup.clone()), move |walk_row_18323: crate::check::types::Rw| {
                let sup_p4 = walk_row_18323;
                let st1_p5 = match &sub_p3.tail {
                    crate::check::types::Tail::TlFlex(n_p9) => close_tail(&st_p1, n_p9),
                    _ => st_p1.clone(),
                };
                call_then(crate::check::types::recording::start_walk_row(st1_p5.clone(), inc_p2.sub.clone()), move |walk_row_18444: crate::check::types::Rw| {
                    let sub2_p6 = walk_row_18444;
                    let left_p7 = filter(&sub2_p6.fams, &(|f_pa: &Text| !crate::check::types::has_text(&sup_p4.fams, f_pa) && (&len(&tags_left(&g_p0, f_pa, &sub2_p6.minus)) > &Nat::from(0u32))));
                    let tail_bad_p8 = match (sub2_p6.tail.clone(), sup_p4.tail.clone()) {
                        (crate::check::types::Tail::TlRigid(a_pb), crate::check::types::Tail::TlRigid(b_pc)) => &a_pb != &b_pc,
                        (crate::check::types::Tail::TlRigid(_), _) => true,
                        _ => false,
                    };
                    if (&len(&left_p7) == &Nat::from(0u32)) && !tail_bad_p8 {
                        prism_rtl::Turn::Finished(st1_p5.clone())
                    } else {
                        {
                            let s0_pd = {
                                let mut this: crate::check::types::St = st1_p5.clone();
                                this.file = inc_p2.file.clone();
                                this
                            };
                            let tags_pe = fold(&left_p7, &Array::new(), &(|acc_pg: &Array<Text>, f_ph: &Text| append(acc_pg, &tags_left(&g_p0, f_ph, &sub2_p6.minus))));
                            let s1_pf = if inc_p2.forward {
                                crate::check::types::recording::err_fix(&s0_pd, &Text::lit("forwarding"), &inc_p2.span, &Text::from(format!("forwarding {} from a scope that emits {}", &crate::syntax::lexer::chars::join(&tags_pe, &Text::lit(", ")), &crate::check::types::show_row(&sup_p4))), &Text::from(format!("answer {} above this arm, for example `{}(..): @ never`", &(if &len(&tags_pe) == &Nat::from(1u32) { Text::lit("it") } else { Text::lit("them") }), &or(&index(&tags_pe, &Nat::from(0u32)), &Text::lit("")))))
                            } else {
                                crate::check::types::recording::err_fix(&s0_pd, &Text::lit("row-outside"), &inc_p2.span, &Text::from(format!("a child that emits `{}` in a scope that emits `{}`", &crate::check::types::show_row(&sub2_p6), &crate::check::types::show_row(&sup_p4))), &Text::lit("widen the scope\'s `emit` row, or host the child with `@HostDocument`"))
                            };
                            prism_rtl::Turn::Finished({
                                let mut this: crate::check::types::St = s1_pf.clone();
                                this.file = st1_p5.file.clone();
                                this
                            })
                        }
                    }
                })
            })
        })
    }
}

/// `Start DischargeOne, x`: what the function value is when passed to `@Run`.
pub fn start_discharge_one(g_p0: crate::check::env::G, st_p1: crate::check::types::St, inc_p2: crate::check::types::Incl) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DischargeOne { g_p0, st_p1, inc_p2 })
}

/// ```prism
/// TagsLeft: fn G, Text, [Text] -> [Text]
/// ```
pub fn tags_left(g_p0: &crate::check::env::G, fam_p1: &Text, minus_p2: &Array<Text>) -> Array<Text> {
    filter(&or(&get(&g_p0.families, fam_p1), &Array::new()), &(|t_p3: &Text| !crate::check::types::has_text(minus_p2, t_p3) && is_element_tag(g_p0, t_p3)))
}

/// ```prism
/// IsElementTag: fn G, Text -> Bool
/// ```
pub fn is_element_tag(g_p0: &crate::check::env::G, t_p1: &Text) -> bool {
    match get(&g_p0.tags, t_p1) {
        Some(tg_p2) => &tg_p2.kind == &Text::lit("Element"),
        None => false,
    }
}

/// ```prism
/// CloseTail: fn St, Nat -> St
/// ```
pub fn close_tail(st_p0: &crate::check::types::St, n_p1: &Nat) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.rows = insert(&this.rows, n_p1, &crate::check::types::empty_row());
    this
}
