//! The module `Check.Passes.Cycles`, from `target/bootstrap/src/prismc/check/passes/cycles.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `PCx`:
///
/// ```prism
/// type PCx = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct PCx {
    pub g_p: crate::check::env::G,
    pub home_p: Text,
    pub lams_p: Map<Nat, crate::syntax::Expr>,
    pub base_p: Map<Text, crate::check::shrink::Rel>,
}

impl Show for PCx {
    fn show(&self, p: &mut Printer) {
        p.record("PCx", &[("g", &self.g_p), ("home", &self.home_p), ("lams", &self.lams_p), ("base", &self.base_p)]);
    }
}

impl ToPod for PCx {
    fn to_pod(&self) -> Pod {
        Pod::record("PCx", vec![("g", self.g_p.to_pod()), ("home", self.home_p.to_pod()), ("lams", self.lams_p.to_pod()), ("base", self.base_p.to_pod())])
    }
}

impl FromPod for PCx {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(PCx { g_p: FromPod::from_pod(field(p, "g")?)?, home_p: FromPod::from_pod(field(p, "home")?)?, lams_p: FromPod::from_pod(field(p, "lams")?)?, base_p: FromPod::from_pod(field(p, "base")?)? })
    }
}

/// ```prism
/// IsDelayedWidget: fn Text -> Bool
/// ```
pub fn is_delayed_widget_f(n_p0: &Text) -> bool {
    crate::check::types::has_text_f(&Array::from(vec![Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")]), n_p0)
}

/// ```prism
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
/// ```
pub fn block_prompt_cycles_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block) -> crate::check::types::St {
    let defs_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(b_p2.stmts_p.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p7 = p0;
        let s_p8 = p1;
        crate::prelude::call_then(start_stmt_defs_f(s_p8.clone()), move |stmt_defs_f_2204: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p7, &stmt_defs_f_2204)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let cx_p4 = PCx { g_p: env_p0.g_p.clone(), home_p: env_p0.home_p.clone(), lams_p: let_lambdas_f(&b_p2.stmts_p), base_p: prompt_base_f(env_p0, &b_p2.stmts_p) };
    let edges_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(b_p2.stmts_p.clone(), Array::new(), {
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        let cx_p4x = cx_p4.clone();
        let defs_p3x = defs_p3.clone();
        Rc::new(move |(p0, p1): (Array<(Text, Text)>, crate::syntax::Stmt)| {
            let env_p0xy = env_p0x.clone();
            let st_p1xy = st_p1x.clone();
            let cx_p4xy = cx_p4x.clone();
            let defs_p3xy = defs_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p9 = p0;
                let s_pa = p1;
                crate::prelude::call_then(start_prompt_edges_f(env_p0xy.clone(), st_p1xy.clone(), cx_p4xy.clone(), s_pa.clone(), defs_p3xy.clone()), move |prompt_edges_f_2375: Array<(Text, Text)>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p9, &prompt_edges_f_2375)))
            }))
        }) as Rc<dyn Fn((Array<(Text, Text)>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>>>
    }));
    let cyc_p6 = find_cycle_f(&defs_p3, &edges_p5);
    if &crate::prelude::len(&cyc_p6) == &Nat::from(0u32) {
        st_p1.clone()
    } else {
        {
            let span_pb = crate::prelude::run_to_end(crate::prelude::fold_job(b_p2.stmts_p.clone(), b_p2.span_p.clone(), {
                let cyc_p6x = cyc_p6.clone();
                Rc::new(move |(p0, p1): (crate::syntax::Range, crate::syntax::Stmt)| {
                    let cyc_p6xy = cyc_p6x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let sp_pc = p0;
                        let s_pd = p1;
                        crate::prelude::call_then(start_stmt_defs_f(s_pd.clone()), move |stmt_defs_f_2543: Array<Text>| if crate::check::types::has_text_f(&stmt_defs_f_2543, &crate::prelude::or(&crate::prelude::index(&cyc_p6xy, &Nat::from(0u32)), &Text::lit(""))) {
                            prism_rtl::Turn::Finished(s_pd.span_p.clone())
                        } else {
                            prism_rtl::Turn::Finished(sp_pc.clone())
                        })
                    }))
                }) as Rc<dyn Fn((crate::syntax::Range, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::syntax::Range>>>
            }));
            crate::check::types::recording::err_fix_f(st_p1, &Text::lit("prompt-cycle"), &span_pb, &Text::from(format!("a prompt cycle: {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&cyc_p6, &(|n_pe: &Text| Text::from(format!("`{}`", n_pe)))), &Text::lit(", ")))), &Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened"))
        }
    }
}

/// The step machine of `BlockPromptCycles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
/// ```
pub struct BlockPromptCycles {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
}

impl prism_rtl::Job<crate::check::types::St> for BlockPromptCycles {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        let b_p2x = b_p2.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(b_p2x.stmts_p.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p7 = p0;
            let s_p8 = p1;
            crate::prelude::call_then(start_stmt_defs_f(s_p8.clone()), move |stmt_defs_f_2204: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p7, &stmt_defs_f_2204)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_2161: Array<Text>| {
            let defs_p3 = fold_2161;
            crate::prelude::call_then(start_let_lambdas_f(b_p2x.stmts_p.clone()), move |let_lambdas_f_2263: Map<Nat, crate::syntax::Expr>| crate::prelude::call_then(start_prompt_base_f(env_p0x.clone(), b_p2x.stmts_p.clone()), move |prompt_base_f_2290: Map<Text, crate::check::shrink::Rel>| {
                let cx_p4 = PCx { g_p: env_p0x.g_p.clone(), home_p: env_p0x.home_p.clone(), lams_p: let_lambdas_f_2263, base_p: prompt_base_f_2290 };
                crate::prelude::call_value(crate::prelude::fold_job(b_p2x.stmts_p.clone(), Array::new(), {
                    let env_p0xx = env_p0x.clone();
                    let st_p1xx = st_p1x.clone();
                    let cx_p4x = cx_p4.clone();
                    let defs_p3x = defs_p3.clone();
                    Rc::new(move |(p0, p1): (Array<(Text, Text)>, crate::syntax::Stmt)| {
                        let env_p0xxy = env_p0xx.clone();
                        let st_p1xxy = st_p1xx.clone();
                        let cx_p4xy = cx_p4x.clone();
                        let defs_p3xy = defs_p3x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_p9 = p0;
                            let s_pa = p1;
                            crate::prelude::call_then(start_prompt_edges_f(env_p0xxy.clone(), st_p1xxy.clone(), cx_p4xy.clone(), s_pa.clone(), defs_p3xy.clone()), move |prompt_edges_f_2375: Array<(Text, Text)>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p9, &prompt_edges_f_2375)))
                        }))
                    }) as Rc<dyn Fn((Array<(Text, Text)>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>>>
                }), move |fold_2332: Array<(Text, Text)>| {
                    let edges_p5 = fold_2332;
                    crate::prelude::call_then(start_find_cycle_f(defs_p3.clone(), edges_p5.clone()), move |find_cycle_f_2423: Array<Text>| {
                        let cyc_p6 = find_cycle_f_2423;
                        if &crate::prelude::len(&cyc_p6) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(st_p1x.clone())
                        } else {
                            crate::prelude::call_value(crate::prelude::fold_job(b_p2x.stmts_p.clone(), b_p2x.span_p.clone(), {
                                let cyc_p6x = cyc_p6.clone();
                                Rc::new(move |(p0, p1): (crate::syntax::Range, crate::syntax::Stmt)| {
                                    let cyc_p6xy = cyc_p6x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let sp_pc = p0;
                                        let s_pd = p1;
                                        crate::prelude::call_then(start_stmt_defs_f(s_pd.clone()), move |stmt_defs_f_2543: Array<Text>| if crate::check::types::has_text_f(&stmt_defs_f_2543, &crate::prelude::or(&crate::prelude::index(&cyc_p6xy, &Nat::from(0u32)), &Text::lit(""))) {
                                            prism_rtl::Turn::Finished(s_pd.span_p.clone())
                                        } else {
                                            prism_rtl::Turn::Finished(sp_pc.clone())
                                        })
                                    }))
                                }) as Rc<dyn Fn((crate::syntax::Range, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::syntax::Range>>>
                            }), move |fold_2500: crate::syntax::Range| {
                                let span_pb = fold_2500;
                                prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &Text::lit("prompt-cycle"), &span_pb, &Text::from(format!("a prompt cycle: {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&cyc_p6, &(|n_pe: &Text| Text::from(format!("`{}`", n_pe)))), &Text::lit(", ")))), &Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened")))
                            })
                        }
                    })
                })
            }))
        })
    }
}

/// `Start BlockPromptCycles, x`: what the function value is when passed to `@Run`.
pub fn start_block_prompt_cycles_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(BlockPromptCycles { env_p0, st_p1, b_p2 })
}

/// ```prism
/// StmtDefs: unbounded fn Stmt -> [Text]
/// ```
pub fn stmt_defs_f(s_p0: &crate::syntax::Stmt) -> Array<Text> {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SBind(p_p1, _, _) => crate::check::env::names::pattern_names_f(p_p1),
        crate::syntax::StmtKind::SLet(p_p2, _, _) => crate::check::env::names::pattern_names_f(p_p2),
        _ => Array::new(),
    }
}

/// The step machine of `StmtDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtDefs: unbounded fn Stmt -> [Text]
/// ```
pub struct StmtDefs {
    pub s_p0: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<Text>> for StmtDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s_p0 = &self.s_p0;
        match &s_p0.kind_p {
            crate::syntax::StmtKind::SBind(p_p1, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::names::PatternNames { p_p0: p_p1.clone() })),
            crate::syntax::StmtKind::SLet(p_p2, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::names::PatternNames { p_p0: p_p2.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start StmtDefs, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_defs_f(s_p0: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(StmtDefs { s_p0 })
}

/// ```prism
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
/// ```
pub fn prompt_edges_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, cx_p2: &PCx, s_p3: &crate::syntax::Stmt, defs_p4: &Array<Text>) -> Array<(Text, Text)> {
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SBind(_, _, Some(_)) => Array::new(),
        crate::syntax::StmtKind::SBind(p_p5, e_p6, None) => edges_f(&crate::check::env::names::pattern_names_f(p_p5), &prompt_reads_f(cx_p2, e_p6, defs_p4)),
        crate::syntax::StmtKind::SLet(p_p7, _, e_p8) => {
            let names_p9 = crate::check::env::names::pattern_names_f(p_p7);
            let layer_pa = crate::prelude::run_to_end(crate::prelude::fold_job(names_p9.clone(), Text::lit(""), {
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                Rc::new(move |(p0, p1): (Text, Text)| {
                    let env_p0xy = env_p0x.clone();
                    let st_p1xy = st_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pb = p0;
                        let n_pc = p1;
                        match crate::prelude::get(&env_p0xy.locals_p, &n_pc) {
                            Some(sc_pd) => prism_rtl::Turn::More(Rc::new(crate::check::types::HeadSigil { st_p0: st_p1xy.clone(), t_p1: sc_pd.ty_p.clone() })),
                            None => prism_rtl::Turn::Finished(acc_pb.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            edges_f(&names_p9, &crate::prelude::run_to_end(crate::prelude::filter_job(prompt_reads_f(cx_p2, e_p8, defs_p4), {
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let layer_pax = layer_pa.clone();
                Rc::new(move |p0: Text| {
                    let env_p0xy = env_p0x.clone();
                    let st_p1xy = st_p1x.clone();
                    let layer_paxy = layer_pax.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let n_pe = p0;
                        prism_rtl::Turn::More(Rc::new(ReadIsPrompt { env_p0: env_p0xy.clone(), st_p1: st_p1xy.clone(), n_p2: n_pe.clone(), layer_p3: layer_paxy.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
            })))
        },
        _ => Array::new(),
    }
}

/// The step machine of `PromptEdges`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
/// ```
pub struct PromptEdges {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub cx_p2: PCx,
    pub s_p3: crate::syntax::Stmt,
    pub defs_p4: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for PromptEdges {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let cx_p2 = &self.cx_p2;
        let s_p3 = &self.s_p3;
        let defs_p4 = &self.defs_p4;
        match &s_p3.kind_p {
            crate::syntax::StmtKind::SBind(_, _, Some(_)) => prism_rtl::Turn::Finished(Array::new()),
            crate::syntax::StmtKind::SBind(p_p5, e_p6, None) => {
                let cx_p2x = cx_p2.clone();
                let defs_p4x = defs_p4.clone();
                let e_p6x = e_p6.clone();
                let p_p5x = p_p5.clone();
                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p5x.clone()), move |pattern_names_f_3267: Array<Text>| crate::prelude::call_then(start_prompt_reads_f(cx_p2x.clone(), e_p6x.clone(), defs_p4x.clone()), move |prompt_reads_f_3285: Array<Text>| prism_rtl::Turn::Finished(edges_f(&pattern_names_f_3267, &prompt_reads_f_3285))))
            },
            crate::syntax::StmtKind::SLet(p_p7, _, e_p8) => {
                let cx_p2x = cx_p2.clone();
                let defs_p4x = defs_p4.clone();
                let e_p8x = e_p8.clone();
                let env_p0x = env_p0.clone();
                let p_p7x = p_p7.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p7x.clone()), move |pattern_names_f_3353: Array<Text>| {
                    let names_p9 = pattern_names_f_3353;
                    crate::prelude::call_value(crate::prelude::fold_job(names_p9.clone(), Text::lit(""), {
                        let env_p0xx = env_p0x.clone();
                        let st_p1xx = st_p1x.clone();
                        Rc::new(move |(p0, p1): (Text, Text)| {
                            let env_p0xxy = env_p0xx.clone();
                            let st_p1xxy = st_p1xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_pb = p0;
                                let n_pc = p1;
                                match crate::prelude::get(&env_p0xxy.locals_p, &n_pc) {
                                    Some(sc_pd) => prism_rtl::Turn::More(Rc::new(crate::check::types::HeadSigil { st_p0: st_p1xxy.clone(), t_p1: sc_pd.ty_p.clone() })),
                                    None => prism_rtl::Turn::Finished(acc_pb.clone()),
                                }
                            }))
                        }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |fold_3388: Text| {
                        let layer_pa = fold_3388;
                        crate::prelude::call_then(start_prompt_reads_f(cx_p2x.clone(), e_p8x.clone(), defs_p4x.clone()), move |prompt_reads_f_3524: Array<Text>| crate::prelude::call_value(crate::prelude::filter_job(prompt_reads_f_3524, {
                            let env_p0xx = env_p0x.clone();
                            let st_p1xx = st_p1x.clone();
                            let layer_pax = layer_pa.clone();
                            Rc::new(move |p0: Text| {
                                let env_p0xxy = env_p0xx.clone();
                                let st_p1xxy = st_p1xx.clone();
                                let layer_paxy = layer_pax.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let n_pe = p0;
                                    prism_rtl::Turn::More(Rc::new(ReadIsPrompt { env_p0: env_p0xxy.clone(), st_p1: st_p1xxy.clone(), n_p2: n_pe.clone(), layer_p3: layer_paxy.clone() }))
                                }))
                            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |filter_3516: Array<Text>| prism_rtl::Turn::Finished(edges_f(&names_p9, &filter_3516))))
                    })
                })
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PromptEdges, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_edges_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, cx_p2: PCx, s_p3: crate::syntax::Stmt, defs_p4: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(PromptEdges { env_p0, st_p1, cx_p2, s_p3, defs_p4 })
}

/// ```prism
/// Edges: fn [Text], [Text] -> [((Text, Text))]
/// ```
pub fn edges_f(froms_p0: &Array<Text>, tos_p1: &Array<Text>) -> Array<(Text, Text)> {
    crate::prelude::fold(froms_p0, &Array::new(), &(|acc_p2: &Array<(Text, Text)>, f_p3: &Text| crate::prelude::append(acc_p2, &crate::prelude::each(tos_p1, &(|t_p4: &Text| (f_p3.clone(), t_p4.clone()))))))
}

/// ```prism
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
/// ```
pub fn read_is_prompt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, n_p2: &Text, layer_p3: &Text) -> bool {
    match crate::prelude::get(&env_p0.locals_p, n_p2) {
        Some(sc_p4) => {
            let h_p5 = crate::check::types::head_sigil_f(st_p1, &sc_p4.ty_p);
            if layer_p3 == &Text::lit("!") {
                (&h_p5 == &Text::lit("!")) || (&h_p5 == &Text::lit("@"))
            } else {
                if layer_p3 == &Text::lit("$") {
                    (&h_p5 == &Text::lit("$")) || (&h_p5 == &Text::lit("!"))
                } else {
                    match crate::check::types::recording::walk_f(st_p1, &sc_p4.ty_p) {
                        crate::check::types::Ty::TyFn(_, _, _) => false,
                        _ => crate::check::env::is_lower_text_f(&crate::syntax::lexer::chars::drop_prefix_f(n_p2, &crate::check::types::unify::marks_of_f(n_p2))) && (&h_p5 == &Text::lit("")),
                    }
                }
            }
        },
        None => false,
    }
}

/// The step machine of `ReadIsPrompt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
/// ```
pub struct ReadIsPrompt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: Text,
    pub layer_p3: Text,
}

impl prism_rtl::Job<bool> for ReadIsPrompt {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let layer_p3 = &self.layer_p3;
        match crate::prelude::get(&env_p0.locals_p, n_p2) {
            Some(sc_p4) => {
                let layer_p3x = layer_p3.clone();
                let n_p2x = n_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), sc_p4.ty_p.clone()), move |head_sigil_f_4011: Text| {
                    let h_p5 = head_sigil_f_4011;
                    if &layer_p3x == &Text::lit("!") {
                        prism_rtl::Turn::Finished((&h_p5 == &Text::lit("!")) || (&h_p5 == &Text::lit("@")))
                    } else {
                        if &layer_p3x == &Text::lit("$") {
                            prism_rtl::Turn::Finished((&h_p5 == &Text::lit("$")) || (&h_p5 == &Text::lit("!")))
                        } else {
                            crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), sc_p4.ty_p.clone()), move |walk_f_4149: crate::check::types::Ty| match walk_f_4149 {
                                crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::Finished(false),
                                _ => prism_rtl::Turn::Finished(crate::check::env::is_lower_text_f(&crate::syntax::lexer::chars::drop_prefix_f(&n_p2x, &crate::check::types::unify::marks_of_f(&n_p2x))) && (&h_p5 == &Text::lit(""))),
                            })
                        }
                    }
                })
            },
            None => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start ReadIsPrompt, x`: what the function value is when passed to `@Run`.
pub fn start_read_is_prompt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, n_p2: Text, layer_p3: Text) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(ReadIsPrompt { env_p0, st_p1, n_p2, layer_p3 })
}

/// ```prism
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
/// ```
pub fn prompt_base_f(env_p0: &crate::check::expr::Env, stmts_p1: &Array<crate::syntax::Stmt>) -> Map<Text, crate::check::shrink::Rel> {
    let pre_p2 = crate::check::shrink::relations::prelude_seeds_f(&env_p0.g_p, &env_p0.home_p);
    let seeds_p3 = crate::prelude::fold(&crate::prelude::keys(&pre_p2), &pre_p2, &(|m_p4: &Map<Text, crate::check::shrink::Rel>, k_p5: &Text| if crate::check::env::has_key_f(&env_p0.locals_p, &crate::syntax::lexer::chars::drop_prefix_f(k_p5, &Text::lit("pre:"))) {
        crate::prelude::remove(m_p4, k_p5)
    } else {
        m_p4.clone()
    }));
    crate::prelude::fold(stmts_p1, &seeds_p3, &(|m_p6: &Map<Text, crate::check::shrink::Rel>, s_p7: &crate::syntax::Stmt| lam_let_rels_f(s_p7, m_p6)))
}

/// The step machine of `PromptBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
/// ```
pub struct PromptBase {
    pub env_p0: crate::check::expr::Env,
    pub stmts_p1: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for PromptBase {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let env_p0 = &self.env_p0;
        let stmts_p1 = &self.stmts_p1;
        let pre_p2 = crate::check::shrink::relations::prelude_seeds_f(&env_p0.g_p, &env_p0.home_p);
        let seeds_p3 = crate::prelude::fold(&crate::prelude::keys(&pre_p2), &pre_p2, &(|m_p4: &Map<Text, crate::check::shrink::Rel>, k_p5: &Text| if crate::check::env::has_key_f(&env_p0.locals_p, &crate::syntax::lexer::chars::drop_prefix_f(k_p5, &Text::lit("pre:"))) {
            crate::prelude::remove(m_p4, k_p5)
        } else {
            m_p4.clone()
        }));
        prism_rtl::Turn::Finished(crate::prelude::fold(stmts_p1, &seeds_p3, &(|m_p6: &Map<Text, crate::check::shrink::Rel>, s_p7: &crate::syntax::Stmt| lam_let_rels_f(s_p7, m_p6))))
    }
}

/// `Start PromptBase, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_base_f(env_p0: crate::check::expr::Env, stmts_p1: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(PromptBase { env_p0, stmts_p1 })
}

/// ```prism
/// LamLetRels: fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn lam_let_rels_f(s_p0: &crate::syntax::Stmt, m_p1: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SLet(p_p2, _, e_p3) => match ((*p_p2.kind_p).clone(), lambda_of_o(e_p3)) {
            (crate::syntax::PatternKind::PName(n_p4), Some(lam_p5)) => crate::prelude::insert(m_p1, &Text::from(format!("lamlet:{}", &crate::check::env::sname_key_f(&n_p4))), &crate::check::shrink::Rel { param_p: lam_p5.span_p.start_p.clone(), strict_p: false }),
            _ => m_p1.clone(),
        },
        _ => m_p1.clone(),
    }
}

/// ```prism
/// ?LambdaOf: fn Expr -> ?Expr
/// ```
pub fn lambda_of_o(e_p0: &crate::syntax::Expr) -> Option<crate::syntax::Expr> {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ELambda(_, _) => Some(e_p0.clone()),
        crate::syntax::ExprKind::EGroup(x_p1) => lambda_of_o(&**x_p1),
        _ => None,
    }
}

/// ```prism
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
/// ```
pub fn let_lambdas_f(stmts_p0: &Array<crate::syntax::Stmt>) -> Map<Nat, crate::syntax::Expr> {
    crate::prelude::fold(&crate::check::shrink::walk::stmts_spots_f(stmts_p0, &Map::new()), &Map::new(), &(|m_p1: &Map<Nat, crate::syntax::Expr>, sp_p2: &crate::check::shrink::walk::Spot| match sp_p2 {
        crate::check::shrink::walk::Spot::SpotStmt(s_p3, _) => match &s_p3.kind_p {
            crate::syntax::StmtKind::SLet(_, _, e_p4) => match lambda_of_o(e_p4) {
                Some(lam_p5) => crate::prelude::insert(m_p1, &lam_p5.span_p.start_p, &lam_p5),
                None => m_p1.clone(),
            },
            _ => m_p1.clone(),
        },
        _ => m_p1.clone(),
    }))
}

/// The step machine of `LetLambdas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
/// ```
pub struct LetLambdas {
    pub stmts_p0: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Map<Nat, crate::syntax::Expr>> for LetLambdas {
    fn cycle(&self) -> prism_rtl::Turn<Map<Nat, crate::syntax::Expr>> {
        let stmts_p0 = &self.stmts_p0;
        let stmts_p0x = stmts_p0.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_stmts_spots_f(stmts_p0x.clone(), Map::new()), move |stmts_spots_f_5873: Array<crate::check::shrink::walk::Spot>| prism_rtl::Turn::Finished(crate::prelude::fold(&stmts_spots_f_5873, &Map::new(), &(|m_p1: &Map<Nat, crate::syntax::Expr>, sp_p2: &crate::check::shrink::walk::Spot| match sp_p2 {
            crate::check::shrink::walk::Spot::SpotStmt(s_p3, _) => match &s_p3.kind_p {
                crate::syntax::StmtKind::SLet(_, _, e_p4) => match lambda_of_o(e_p4) {
                    Some(lam_p5) => crate::prelude::insert(m_p1, &lam_p5.span_p.start_p, &lam_p5),
                    None => m_p1.clone(),
                },
                _ => m_p1.clone(),
            },
            _ => m_p1.clone(),
        }))))
    }
}

/// `Start LetLambdas, x`: what the function value is when passed to `@Run`.
pub fn start_let_lambdas_f(stmts_p0: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Map<Nat, crate::syntax::Expr>>> {
    Rc::new(LetLambdas { stmts_p0 })
}

/// ```prism
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
/// ```
pub fn prompt_reads_f(cx_p0: &PCx, e_p1: &crate::syntax::Expr, defs_p2: &Array<Text>) -> Array<Text> {
    let spots_p3 = prompt_spots_f(cx_p0, e_p1, &cx_p0.base_p);
    crate::prelude::run_to_end(crate::prelude::fold_job(spots_p3.clone(), Array::new(), {
        let defs_p2x = defs_p2.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::walk::Spot)| {
            let defs_p2xy = defs_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p4 = p0;
                let sp_p5 = p1;
                crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5.clone()), move |spot_sites_f_7222: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(crate::prelude::fold(&spot_sites_f_7222, &acc_p4, &(|a2_p6: &Array<Text>, site_p7: &crate::check::shrink::walk::Site| if crate::check::types::has_text_f(&defs_p2xy, &site_p7.callee_p) && !crate::check::shrink::relations::is_local_f(&site_p7.rels_p, &site_p7.callee_p) {
                    crate::check::types::add_text_f(a2_p6, &site_p7.callee_p)
                } else {
                    a2_p6.clone()
                }))))
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `PromptReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
/// ```
pub struct PromptReads {
    pub cx_p0: PCx,
    pub e_p1: crate::syntax::Expr,
    pub defs_p2: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for PromptReads {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cx_p0 = &self.cx_p0;
        let e_p1 = &self.e_p1;
        let defs_p2 = &self.defs_p2;
        let cx_p0x = cx_p0.clone();
        let defs_p2x = defs_p2.clone();
        let e_p1x = e_p1.clone();
        crate::prelude::call_then(start_prompt_spots_f(cx_p0x.clone(), e_p1x.clone(), cx_p0x.base_p.clone()), move |prompt_spots_f_7156: Array<crate::check::shrink::walk::Spot>| {
            let spots_p3 = prompt_spots_f_7156;
            crate::prelude::fold_job(spots_p3.clone(), Array::new(), {
                let defs_p2xx = defs_p2x.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::walk::Spot)| {
                    let defs_p2xxy = defs_p2xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p4 = p0;
                        let sp_p5 = p1;
                        crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5.clone()), move |spot_sites_f_7222: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(crate::prelude::fold(&spot_sites_f_7222, &acc_p4, &(|a2_p6: &Array<Text>, site_p7: &crate::check::shrink::walk::Site| if crate::check::types::has_text_f(&defs_p2xxy, &site_p7.callee_p) && !crate::check::shrink::relations::is_local_f(&site_p7.rels_p, &site_p7.callee_p) {
                            crate::check::types::add_text_f(a2_p6, &site_p7.callee_p)
                        } else {
                            a2_p6.clone()
                        }))))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle()
        })
    }
}

/// `Start PromptReads, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_reads_f(cx_p0: PCx, e_p1: crate::syntax::Expr, defs_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PromptReads { cx_p0, e_p1, defs_p2 })
}

/// ```prism
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
/// ```
pub fn prompt_spots_f(cx_p0: &PCx, e_p1: &crate::syntax::Expr, m_p2: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Spot> {
    crate::prelude::run_to_end(crate::prelude::fold_job(prompt_kids_f(cx_p0, e_p1, m_p2), Array::from(vec![crate::check::shrink::walk::Spot::SpotExpr(e_p1.clone(), m_p2.clone())]), {
        let cx_p0x = cx_p0.clone();
        Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)| {
            let cx_p0xy = cx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let k_p4 = p1;
                prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &prompt_kid_spots_f(&cx_p0xy, &k_p4)))
            }))
        }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>>>
    }))
}

/// The step machine of `PromptSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
/// ```
pub struct PromptSpots {
    pub cx_p0: PCx,
    pub e_p1: crate::syntax::Expr,
    pub m_p2: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<crate::check::shrink::walk::Spot>> for PromptSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::shrink::walk::Spot>> {
        let cx_p0 = &self.cx_p0;
        let e_p1 = &self.e_p1;
        let m_p2 = &self.m_p2;
        crate::prelude::fold_job(prompt_kids_f(cx_p0, e_p1, m_p2), Array::from(vec![crate::check::shrink::walk::Spot::SpotExpr(e_p1.clone(), m_p2.clone())]), {
            let cx_p0x = cx_p0.clone();
            Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)| {
                let cx_p0xy = cx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p3 = p0;
                    let k_p4 = p1;
                    prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &prompt_kid_spots_f(&cx_p0xy, &k_p4)))
                }))
            }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>>>
        }).cycle()
    }
}

/// `Start PromptSpots, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_spots_f(cx_p0: PCx, e_p1: crate::syntax::Expr, m_p2: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>> {
    Rc::new(PromptSpots { cx_p0, e_p1, m_p2 })
}

/// ```prism
/// PromptKids: unbounded fn PCx, Expr, (Text ==> Rel) -> [Kid]
/// ```
pub fn prompt_kids_f(cx_p0: &PCx, e_p1: &crate::syntax::Expr, m_p2: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Kid> {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::ELambda(_, _) => Array::new(),
        crate::syntax::ExprKind::ERebuild(_, body_p3) => row_kids_f(body_p3, m_p2, &Array::new()),
        crate::syntax::ExprKind::EFor(binders_o4, _, body_p5) => row_kids_f(body_p5, m_p2, &for_binder_names_f(binders_o4)),
        crate::syntax::ExprKind::EWidgetBlock(_) => Array::new(),
        crate::syntax::ExprKind::ECall(c_p6, _, _, _) => prompt_call_kids_f(cx_p0, e_p1, &crate::check::shrink::walk::callee_name_o(&**c_p6), m_p2),
        crate::syntax::ExprKind::EMethod(_, n_p7, _) => prompt_call_kids_f(cx_p0, e_p1, &Some(crate::check::env::sname_key_f(n_p7)), m_p2),
        _ => crate::check::shrink::walk::expr_kids_f(e_p1, m_p2),
    }
}

/// ```prism
/// RowKids: unbounded fn Block, (Text ==> Rel), [Text] -> [Kid]
/// ```
pub fn row_kids_f(body_p0: &crate::syntax::Block, m_p1: &Map<Text, crate::check::shrink::Rel>, binders_p2: &Array<Text>) -> Array<crate::check::shrink::walk::Kid> {
    let lines_p3 = crate::prelude::filter(&body_p0.stmts_p, &(|s_p5: &crate::syntax::Stmt| match &s_p5.kind_p {
        crate::syntax::StmtKind::SBind(_, _, Some(_)) => false,
        _ => true,
    }));
    let own_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(body_p0.stmts_p.clone(), crate::prelude::append(binders_p2, &Array::from(vec![Text::lit("_"), Text::lit("$_")])), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p6 = p0;
        let s_p7 = p1;
        crate::prelude::call_then(start_stmt_defs_f(s_p7.clone()), move |stmt_defs_f_8893: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &stmt_defs_f_8893)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    Array::from(vec![crate::check::shrink::walk::Kid::KidStmts(lines_p3.clone(), crate::check::shrink::relations::hide_f(m_p1, &own_p4))])
}

/// ```prism
/// ForBinderNames: unbounded fn ?ForBinders -> [Text]
/// ```
pub fn for_binder_names_f(binders_o0: &Option<crate::syntax::ForBinders>) -> Array<Text> {
    match binders_o0 {
        Some(fb_p1) => match &fb_p1.second_o {
            Some(second_p2) => crate::prelude::append(&crate::check::env::names::pattern_names_f(&fb_p1.first_p), &crate::check::env::names::pattern_names_f(second_p2)),
            None => crate::check::env::names::pattern_names_f(&fb_p1.first_p),
        },
        None => Array::new(),
    }
}

/// ```prism
/// PromptCallKids: unbounded fn PCx, Expr, ?Text, (Text ==> Rel) -> [Kid]
/// ```
pub fn prompt_call_kids_f(cx_p0: &PCx, e_p1: &crate::syntax::Expr, n_o2: &Option<Text>, m_p3: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Kid> {
    match n_o2 {
        Some(n_p4) => {
            let called_p5 = follow_lam_let_f(cx_p0, n_p4, m_p3);
            if crate::check::shrink::relations::is_local_f(m_p3, n_p4) {
                crate::prelude::append(&called_p5, &open_lambdas_f(cx_p0, &crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)))
            } else {
                if &crate::prelude::len(&called_p5) > &Nat::from(0u32) {
                    crate::prelude::append(&called_p5, &open_lambdas_f(cx_p0, &crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)))
                } else {
                    match crate::check::shrink::locals::resolve_callee_o(&cx_p0.g_p, &cx_p0.home_p, n_p4) {
                        Some(k_p6) => if crate::check::shrink::relations::is_prelude_key_f(&cx_p0.g_p, &k_p6) && is_delayed_widget_f(&crate::syntax::lexer::chars::drop_prefix_f(&k_p6, &Text::lit("Prelude."))) {
                            Array::new()
                        } else {
                            if crate::check::shrink::relations::is_prelude_key_f(&cx_p0.g_p, &k_p6) && crate::syntax::lexer::chars::has_prefix_f(&k_p6, &Text::lit("Prelude.@")) {
                                crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)
                            } else {
                                open_lambdas_f(cx_p0, &crate::check::shrink::walk::expr_kids_f(e_p1, m_p3))
                            }
                        },
                        None => open_lambdas_f(cx_p0, &crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)),
                    }
                }
            }
        },
        None => open_lambdas_f(cx_p0, &crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)),
    }
}

/// ```prism
/// OpenLambdas: unbounded fn PCx, [Kid] -> [Kid]
/// ```
pub fn open_lambdas_f(cx_p0: &PCx, kids_p1: &Array<crate::check::shrink::walk::Kid>) -> Array<crate::check::shrink::walk::Kid> {
    crate::prelude::run_to_end(crate::prelude::fold_job(kids_p1.clone(), Array::new(), {
        let cx_p0x = cx_p0.clone();
        Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Kid>, crate::check::shrink::walk::Kid)| {
            let cx_p0xy = cx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p2 = p0;
                let k_p3 = p1;
                match &k_p3 {
                    crate::check::shrink::walk::Kid::KidExpr(x_p4, m_p5) => match &*x_p4.kind_p {
                        crate::syntax::ExprKind::ELambda(ps_o6, body_p7) => {
                            let ps_o6x = ps_o6.clone();
                            let body_p7x = (**body_p7).clone();
                            let m_p5x = m_p5.clone();
                            crate::prelude::call_then(crate::check::shrink::walk::start_patterns_names_f(crate::prelude::or(&ps_o6x, &Array::new())), move |patterns_names_f_10512: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::push(&acc_p2, &crate::check::shrink::walk::lambda_kid_f(&body_p7x, &crate::check::shrink::relations::hide_f(&m_p5x, &patterns_names_f_10512)))))
                        },
                        crate::syntax::ExprKind::EName(n_p8) => prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::push(&acc_p2, &k_p3), &follow_lam_let_f(&cx_p0xy, &crate::check::env::sname_key_f(n_p8), m_p5))),
                        _ => prism_rtl::Turn::Finished(crate::prelude::push(&acc_p2, &k_p3)),
                    },
                    _ => prism_rtl::Turn::Finished(crate::prelude::push(&acc_p2, &k_p3)),
                }
            }))
        }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Kid>, crate::check::shrink::walk::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Kid>>>>
    }))
}

/// ```prism
/// FollowLamLet: unbounded fn PCx, Text, (Text ==> Rel) -> [Kid]
/// ```
pub fn follow_lam_let_f(cx_p0: &PCx, n_p1: &Text, m_p2: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Kid> {
    match crate::prelude::get(m_p2, &Text::from(format!("lamlet:{}", n_p1))) {
        Some(r_p3) => if crate::check::env::has_key_f(m_p2, &Text::from(format!("seen:{}", &r_p3.param_p))) {
            Array::new()
        } else {
            match crate::prelude::get(&cx_p0.lams_p, &r_p3.param_p) {
                Some(lam_p4) => match &*lam_p4.kind_p {
                    crate::syntax::ExprKind::ELambda(ps_o5, body_p6) => {
                        let seen_p7 = crate::prelude::fold(&crate::prelude::keys(m_p2), &cx_p0.base_p, &(|m2_p8: &Map<Text, crate::check::shrink::Rel>, k_p9: &Text| if crate::syntax::lexer::chars::has_prefix_f(k_p9, &Text::lit("seen:")) {
                            crate::prelude::insert(m2_p8, k_p9, &crate::check::shrink::relations::no_rel_p())
                        } else {
                            m2_p8.clone()
                        }));
                        Array::from(vec![crate::check::shrink::walk::lambda_kid_f(&**body_p6, &crate::check::shrink::relations::hide_f(&crate::prelude::insert(&seen_p7, &Text::from(format!("seen:{}", &r_p3.param_p)), &crate::check::shrink::relations::no_rel_p()), &crate::check::shrink::walk::patterns_names_f(&crate::prelude::or(ps_o5, &Array::new()))))])
                    },
                    _ => Array::new(),
                },
                None => Array::new(),
            }
        },
        None => Array::new(),
    }
}

/// ```prism
/// PromptKidSpots: unbounded fn PCx, Kid -> [Spot]
/// ```
pub fn prompt_kid_spots_f(cx_p0: &PCx, k_p1: &crate::check::shrink::walk::Kid) -> Array<crate::check::shrink::walk::Spot> {
    match k_p1 {
        crate::check::shrink::walk::Kid::KidExpr(x_p2, m_p3) => prompt_spots_f(cx_p0, x_p2, m_p3),
        crate::check::shrink::walk::Kid::KidStmts(ss_p4, m_p5) => {
            let bm_p6 = crate::check::shrink::relations::block_rels_f(ss_p4, m_p5);
            crate::prelude::run_to_end(crate::prelude::fold_job(ss_p4.clone(), Array::new(), {
                let cx_p0x = cx_p0.clone();
                let bm_p6x = bm_p6.clone();
                Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Spot>, crate::syntax::Stmt)| {
                    let cx_p0xy = cx_p0x.clone();
                    let bm_p6xy = bm_p6x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p7 = p0;
                        let s_p8 = p1;
                        prism_rtl::Turn::Finished(crate::prelude::append(&acc_p7, &prompt_stmt_spots_f(&cx_p0xy, &s_p8, &bm_p6xy)))
                    }))
                }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Spot>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>>>
            }))
        },
    }
}

/// ```prism
/// PromptStmtSpots: unbounded fn PCx, Stmt, (Text ==> Rel) -> [Spot]
/// ```
pub fn prompt_stmt_spots_f(cx_p0: &PCx, s_p1: &crate::syntax::Stmt, m_p2: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Spot> {
    match &s_p1.kind_p {
        crate::syntax::StmtKind::SFn(_) => Array::from(vec![crate::check::shrink::walk::Spot::SpotStmt(s_p1.clone(), m_p2.clone())]),
        crate::syntax::StmtKind::SWidget(_) => Array::from(vec![crate::check::shrink::walk::Spot::SpotStmt(s_p1.clone(), m_p2.clone())]),
        _ => crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmt_kids_f(s_p1, m_p2), Array::from(vec![crate::check::shrink::walk::Spot::SpotStmt(s_p1.clone(), m_p2.clone())]), {
            let cx_p0x = cx_p0.clone();
            Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)| {
                let cx_p0xy = cx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p3 = p0;
                    let k_p4 = p1;
                    prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &prompt_kid_spots_f(&cx_p0xy, &k_p4)))
                }))
            }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>>>
        })),
    }
}

/// ```prism
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
/// ```
pub fn find_cycle_f(defs_p0: &Array<Text>, edges_p1: &Array<(Text, Text)>) -> Array<Text> {
    crate::prelude::run_to_end(crate::prelude::fold_job(defs_p0.clone(), Array::new(), {
        let defs_p0x = defs_p0.clone();
        let edges_p1x = edges_p1.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
            let defs_p0xy = defs_p0x.clone();
            let edges_p1xy = edges_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let found_p2 = p0;
                let d_p3 = p1;
                if &crate::prelude::len(&found_p2) > &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(found_p2.clone())
                } else {
                    prism_rtl::Turn::More(Rc::new(CycleThrough { defs_p0: defs_p0xy.clone(), edges_p1: edges_p1xy.clone(), d_p2: d_p3.clone() }))
                }
            }))
        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `FindCycle`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
/// ```
pub struct FindCycle {
    pub defs_p0: Array<Text>,
    pub edges_p1: Array<(Text, Text)>,
}

impl prism_rtl::Job<Array<Text>> for FindCycle {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let defs_p0 = &self.defs_p0;
        let edges_p1 = &self.edges_p1;
        crate::prelude::fold_job(defs_p0.clone(), Array::new(), {
            let defs_p0x = defs_p0.clone();
            let edges_p1x = edges_p1.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                let defs_p0xy = defs_p0x.clone();
                let edges_p1xy = edges_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_p2 = p0;
                    let d_p3 = p1;
                    if &crate::prelude::len(&found_p2) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(found_p2.clone())
                    } else {
                        prism_rtl::Turn::More(Rc::new(CycleThrough { defs_p0: defs_p0xy.clone(), edges_p1: edges_p1xy.clone(), d_p2: d_p3.clone() }))
                    }
                }))
            }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start FindCycle, x`: what the function value is when passed to `@Run`.
pub fn start_find_cycle_f(defs_p0: Array<Text>, edges_p1: Array<(Text, Text)>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(FindCycle { defs_p0, edges_p1 })
}

/// ```prism
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
/// ```
pub fn cycle_through_f(defs_p0: &Array<Text>, edges_p1: &Array<(Text, Text)>, d_p2: &Text) -> Array<Text> {
    let fwd_p3 = reach_from_f(edges_p1, d_p2);
    if crate::check::types::has_text_f(&fwd_p3, d_p2) {
        crate::prelude::run_to_end(crate::prelude::filter_job(defs_p0.clone(), {
            let fwd_p3x = fwd_p3.clone();
            let edges_p1x = edges_p1.clone();
            let d_p2x = d_p2.clone();
            Rc::new(move |p0: Text| {
                let fwd_p3xy = fwd_p3x.clone();
                let edges_p1xy = edges_p1x.clone();
                let d_p2xy = d_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let x_p4 = p0;
                    prism_rtl::Turn::Finished(crate::check::types::has_text_f(&fwd_p3xy, &x_p4) && crate::check::types::has_text_f(&reach_from_f(&edges_p1xy, &x_p4), &d_p2xy))
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
        }))
    } else {
        Array::new()
    }
}

/// The step machine of `CycleThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
/// ```
pub struct CycleThrough {
    pub defs_p0: Array<Text>,
    pub edges_p1: Array<(Text, Text)>,
    pub d_p2: Text,
}

impl prism_rtl::Job<Array<Text>> for CycleThrough {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let defs_p0 = &self.defs_p0;
        let edges_p1 = &self.edges_p1;
        let d_p2 = &self.d_p2;
        let d_p2x = d_p2.clone();
        let defs_p0x = defs_p0.clone();
        let edges_p1x = edges_p1.clone();
        crate::prelude::call_then(start_reach_from_f(edges_p1x.clone(), d_p2x.clone()), move |reach_from_f_12532: Array<Text>| {
            let fwd_p3 = reach_from_f_12532;
            if crate::check::types::has_text_f(&fwd_p3, &d_p2x) {
                crate::prelude::filter_job(defs_p0x.clone(), {
                    let fwd_p3x = fwd_p3.clone();
                    let edges_p1xx = edges_p1x.clone();
                    let d_p2xx = d_p2x.clone();
                    Rc::new(move |p0: Text| {
                        let fwd_p3xy = fwd_p3x.clone();
                        let edges_p1xxy = edges_p1xx.clone();
                        let d_p2xxy = d_p2xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let x_p4 = p0;
                            prism_rtl::Turn::Finished(crate::check::types::has_text_f(&fwd_p3xy, &x_p4) && crate::check::types::has_text_f(&reach_from_f(&edges_p1xxy, &x_p4), &d_p2xxy))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle()
            } else {
                prism_rtl::Turn::Finished(Array::new())
            }
        })
    }
}

/// `Start CycleThrough, x`: what the function value is when passed to `@Run`.
pub fn start_cycle_through_f(defs_p0: Array<Text>, edges_p1: Array<(Text, Text)>, d_p2: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CycleThrough { defs_p0, edges_p1, d_p2 })
}

/// ```prism
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
/// ```
pub fn reach_from_f(edges_p0: &Array<(Text, Text)>, d_p1: &Text) -> Array<Text> {
    reach_f(edges_p0, &crate::prelude::each(&crate::prelude::filter(edges_p0, &(|(f_p2, _): &(Text, Text)| f_p2 == d_p1)), &(|(_, t_p3): &(Text, Text)| t_p3.clone())), &Array::new())
}

/// The step machine of `ReachFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
/// ```
pub struct ReachFrom {
    pub edges_p0: Array<(Text, Text)>,
    pub d_p1: Text,
}

impl prism_rtl::Job<Array<Text>> for ReachFrom {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let edges_p0 = &self.edges_p0;
        let d_p1 = &self.d_p1;
        prism_rtl::Turn::Finished(reach_f(edges_p0, &crate::prelude::each(&crate::prelude::filter(edges_p0, &(|(f_p2, _): &(Text, Text)| f_p2 == d_p1)), &(|(_, t_p3): &(Text, Text)| t_p3.clone())), &Array::new()))
    }
}

/// `Start ReachFrom, x`: what the function value is when passed to `@Run`.
pub fn start_reach_from_f(edges_p0: Array<(Text, Text)>, d_p1: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReachFrom { edges_p0, d_p1 })
}

/// ```prism
/// Reach: unbounded fn [((Text, Text))], [Text], [Text] -> [Text]
/// ```
pub fn reach_f(edges_p0: &Array<(Text, Text)>, frontier_p1: &Array<Text>, seen_p2: &Array<Text>) -> Array<Text> {
    match crate::prelude::index(frontier_p1, &Nat::from(0u32)) {
        None => seen_p2.clone(),
        Some(x_p3) => if crate::check::types::has_text_f(seen_p2, &x_p3) {
            reach_f(edges_p0, &crate::prelude::drop(frontier_p1, &Nat::from(1u32)), seen_p2)
        } else {
            reach_f(edges_p0, &crate::prelude::append(&crate::prelude::drop(frontier_p1, &Nat::from(1u32)), &crate::prelude::each(&crate::prelude::filter(edges_p0, &(|(f_p4, _): &(Text, Text)| f_p4 == &x_p3)), &(|(_, t_p5): &(Text, Text)| t_p5.clone()))), &crate::prelude::push(seen_p2, &x_p3))
        },
    }
}
