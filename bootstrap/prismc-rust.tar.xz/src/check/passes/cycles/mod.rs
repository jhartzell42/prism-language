//! The module `Check.Passes.Cycles`, from `target/bootstrap/src/prismc/check/passes/cycles.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `PCx`:
///
/// ```prism
/// type PCx = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct PCx {
    pub g: crate::check::env::G,
    pub home: Text,
    pub lams: Map<Nat, crate::syntax::Expr>,
    pub base: Map<Text, crate::check::shrink::Rel>,
}

impl Show for PCx {
    fn show(&self, p: &mut Printer) {
        p.record("PCx", &[("g", &self.g), ("home", &self.home), ("lams", &self.lams), ("base", &self.base)]);
    }
}

impl ToPod for PCx {
    fn to_pod(&self) -> Pod {
        Pod::record("PCx", vec![("g", self.g.to_pod()), ("home", self.home.to_pod()), ("lams", self.lams.to_pod()), ("base", self.base.to_pod())])
    }
}

impl FromPod for PCx {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(PCx { g: FromPod::from_pod(field(p, "g")?)?, home: FromPod::from_pod(field(p, "home")?)?, lams: FromPod::from_pod(field(p, "lams")?)?, base: FromPod::from_pod(field(p, "base")?)? })
    }
}

/// ```prism
/// IsDelayedWidget: fn Text -> Bool
/// ```
pub fn is_delayed_widget(n_p0: &Text) -> bool {
    crate::check::types::has_text(&Array::from(vec![Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")]), n_p0)
}

/// ```prism
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
/// ```
pub fn block_prompt_cycles(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block) -> crate::check::types::St {
    let defs_p3 = run_to_end(fold_job(b_p2.stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| entered(once_job(move || {
        let acc_p7 = p0;
        let s_p8 = p1;
        call_then(start_stmt_defs(s_p8.clone()), move |stmt_defs_2204: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p7, &stmt_defs_2204)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let cx_p4 = PCx { g: env_p0.g.clone(), home: env_p0.home.clone(), lams: let_lambdas(&b_p2.stmts), base: prompt_base(env_p0, &b_p2.stmts) };
    let edges_p5 = run_to_end(fold_job(b_p2.stmts.clone(), Array::new(), {
        let env_p0 = env_p0.clone();
        let st_p1 = st_p1.clone();
        let cx_p4 = cx_p4.clone();
        let defs_p3 = defs_p3.clone();
        Rc::new(move |(p0, p1): (Array<(Text, Text)>, crate::syntax::Stmt)| {
            let env_p0 = env_p0.clone();
            let st_p1 = st_p1.clone();
            let cx_p4 = cx_p4.clone();
            let defs_p3 = defs_p3.clone();
            entered(once_job(move || {
                let acc_p9 = p0;
                let s_pa = p1;
                call_then(start_prompt_edges(env_p0.clone(), st_p1.clone(), cx_p4.clone(), s_pa.clone(), defs_p3.clone()), move |prompt_edges_2375: Array<(Text, Text)>| prism_rtl::Turn::Finished(append(&acc_p9, &prompt_edges_2375)))
            }))
        }) as Rc<dyn Fn((Array<(Text, Text)>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>>>
    }));
    let cyc_p6 = find_cycle(&defs_p3, &edges_p5);
    if &len(&cyc_p6) == &Nat::from(0u32) {
        st_p1.clone()
    } else {
        {
            let span_pb = run_to_end(fold_job(b_p2.stmts.clone(), b_p2.span.clone(), {
                let cyc_p6 = cyc_p6.clone();
                Rc::new(move |(p0, p1): (crate::syntax::Range, crate::syntax::Stmt)| {
                    let cyc_p6 = cyc_p6.clone();
                    entered(once_job(move || {
                        let sp_pc = p0;
                        let s_pd = p1;
                        call_then(start_stmt_defs(s_pd.clone()), move |stmt_defs_2543: Array<Text>| if crate::check::types::has_text(&stmt_defs_2543, &or(&index(&cyc_p6, &Nat::from(0u32)), &Text::lit(""))) {
                            prism_rtl::Turn::Finished(s_pd.span.clone())
                        } else {
                            prism_rtl::Turn::Finished(sp_pc.clone())
                        })
                    }))
                }) as Rc<dyn Fn((crate::syntax::Range, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::syntax::Range>>>
            }));
            crate::check::types::recording::err_fix(st_p1, &Text::lit("prompt-cycle"), &span_pb, &Text::from(format!("a prompt cycle: {}", &crate::syntax::lexer::chars::join(&each(&cyc_p6, &(|n_pe: &Text| Text::from(format!("`{}`", n_pe)))), &Text::lit(", ")))), &Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened"))
        }
    }
}

/// The step machine of `BlockPromptCycles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
/// ```
pub struct BlockPromptCycles {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
}

impl prism_rtl::Job<crate::check::types::St> for BlockPromptCycles {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        let b_p2 = b_p2.clone();
        let env_p0 = env_p0.clone();
        let st_p1 = st_p1.clone();
        call_value(fold_job(b_p2.stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| entered(once_job(move || {
            let acc_p7 = p0;
            let s_p8 = p1;
            call_then(start_stmt_defs(s_p8.clone()), move |stmt_defs_2204: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p7, &stmt_defs_2204)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_2161: Array<Text>| {
            let defs_p3 = fold_2161;
            call_then(start_let_lambdas(b_p2.stmts.clone()), move |let_lambdas_2263: Map<Nat, crate::syntax::Expr>| call_then(start_prompt_base(env_p0.clone(), b_p2.stmts.clone()), move |prompt_base_2290: Map<Text, crate::check::shrink::Rel>| {
                let cx_p4 = PCx { g: env_p0.g.clone(), home: env_p0.home.clone(), lams: let_lambdas_2263, base: prompt_base_2290 };
                call_value(fold_job(b_p2.stmts.clone(), Array::new(), {
                    let env_p0 = env_p0.clone();
                    let st_p1 = st_p1.clone();
                    let cx_p4 = cx_p4.clone();
                    let defs_p3 = defs_p3.clone();
                    Rc::new(move |(p0, p1): (Array<(Text, Text)>, crate::syntax::Stmt)| {
                        let env_p0 = env_p0.clone();
                        let st_p1 = st_p1.clone();
                        let cx_p4 = cx_p4.clone();
                        let defs_p3 = defs_p3.clone();
                        entered(once_job(move || {
                            let acc_p9 = p0;
                            let s_pa = p1;
                            call_then(start_prompt_edges(env_p0.clone(), st_p1.clone(), cx_p4.clone(), s_pa.clone(), defs_p3.clone()), move |prompt_edges_2375: Array<(Text, Text)>| prism_rtl::Turn::Finished(append(&acc_p9, &prompt_edges_2375)))
                        }))
                    }) as Rc<dyn Fn((Array<(Text, Text)>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>>>
                }), move |fold_2332: Array<(Text, Text)>| {
                    let edges_p5 = fold_2332;
                    call_then(start_find_cycle(defs_p3.clone(), edges_p5.clone()), move |find_cycle_2423: Array<Text>| {
                        let cyc_p6 = find_cycle_2423;
                        if &len(&cyc_p6) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(st_p1.clone())
                        } else {
                            call_value(fold_job(b_p2.stmts.clone(), b_p2.span.clone(), {
                                let cyc_p6 = cyc_p6.clone();
                                Rc::new(move |(p0, p1): (crate::syntax::Range, crate::syntax::Stmt)| {
                                    let cyc_p6 = cyc_p6.clone();
                                    entered(once_job(move || {
                                        let sp_pc = p0;
                                        let s_pd = p1;
                                        call_then(start_stmt_defs(s_pd.clone()), move |stmt_defs_2543: Array<Text>| if crate::check::types::has_text(&stmt_defs_2543, &or(&index(&cyc_p6, &Nat::from(0u32)), &Text::lit(""))) {
                                            prism_rtl::Turn::Finished(s_pd.span.clone())
                                        } else {
                                            prism_rtl::Turn::Finished(sp_pc.clone())
                                        })
                                    }))
                                }) as Rc<dyn Fn((crate::syntax::Range, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::syntax::Range>>>
                            }), move |fold_2500: crate::syntax::Range| {
                                let span_pb = fold_2500;
                                prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st_p1, &Text::lit("prompt-cycle"), &span_pb, &Text::from(format!("a prompt cycle: {}", &crate::syntax::lexer::chars::join(&each(&cyc_p6, &(|n_pe: &Text| Text::from(format!("`{}`", n_pe)))), &Text::lit(", ")))), &Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened")))
                            })
                        }
                    })
                })
            }))
        })
    }
}

/// `Start BlockPromptCycles, x`: what the function value is when passed to `@Run`.
pub fn start_block_prompt_cycles(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(BlockPromptCycles { env_p0, st_p1, b_p2 })
}

/// ```prism
/// StmtDefs: unbounded fn Stmt -> [Text]
/// ```
pub fn stmt_defs(s_p0: &crate::syntax::Stmt) -> Array<Text> {
    match &s_p0.kind {
        crate::syntax::StmtKind::SBind(p_p1, _, _) => crate::check::env::names::pattern_names(p_p1),
        crate::syntax::StmtKind::SLet(p_p2, _, _) => crate::check::env::names::pattern_names(p_p2),
        _ => Array::new(),
    }
}

/// The step machine of `StmtDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtDefs: unbounded fn Stmt -> [Text]
/// ```
pub struct StmtDefs {
    pub s_p0: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<Text>> for StmtDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s_p0 = &self.s_p0;
        match &s_p0.kind {
            crate::syntax::StmtKind::SBind(p_p1, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::names::PatternNames { p_p0: p_p1.clone() })),
            crate::syntax::StmtKind::SLet(p_p2, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::names::PatternNames { p_p0: p_p2.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start StmtDefs, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_defs(s_p0: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(StmtDefs { s_p0 })
}

/// ```prism
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
/// ```
pub fn prompt_edges(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, cx_p2: &PCx, s_p3: &crate::syntax::Stmt, defs_p4: &Array<Text>) -> Array<(Text, Text)> {
    match &s_p3.kind {
        crate::syntax::StmtKind::SBind(_, _, Some(_)) => Array::new(),
        crate::syntax::StmtKind::SBind(p_p5, e_p6, None) => edges(&crate::check::env::names::pattern_names(p_p5), &prompt_reads(cx_p2, e_p6, defs_p4)),
        crate::syntax::StmtKind::SLet(p_p7, _, e_p8) => {
            let names_p9 = crate::check::env::names::pattern_names(p_p7);
            let layer_pa = run_to_end(fold_job(names_p9.clone(), Text::lit(""), {
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                Rc::new(move |(p0, p1): (Text, Text)| {
                    let env_p0 = env_p0.clone();
                    let st_p1 = st_p1.clone();
                    entered(once_job(move || {
                        let acc_pb = p0;
                        let n_pc = p1;
                        match get(&env_p0.locals, &n_pc) {
                            Some(sc_pd) => prism_rtl::Turn::More(Rc::new(crate::check::types::HeadSigil { st_p0: st_p1.clone(), t_p1: sc_pd.ty.clone() })),
                            None => prism_rtl::Turn::Finished(acc_pb.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            edges(&names_p9, &run_to_end(filter_job(prompt_reads(cx_p2, e_p8, defs_p4), {
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                let layer_pa = layer_pa.clone();
                Rc::new(move |p0: Text| {
                    let env_p0 = env_p0.clone();
                    let st_p1 = st_p1.clone();
                    let layer_pa = layer_pa.clone();
                    entered(once_job(move || {
                        let n_pe = p0;
                        prism_rtl::Turn::More(Rc::new(ReadIsPrompt { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_pe.clone(), layer_p3: layer_pa.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
            })))
        },
        _ => Array::new(),
    }
}

/// The step machine of `PromptEdges`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
/// ```
pub struct PromptEdges {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub cx_p2: PCx,
    pub s_p3: crate::syntax::Stmt,
    pub defs_p4: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for PromptEdges {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let cx_p2 = &self.cx_p2;
        let s_p3 = &self.s_p3;
        let defs_p4 = &self.defs_p4;
        match &s_p3.kind {
            crate::syntax::StmtKind::SBind(_, _, Some(_)) => prism_rtl::Turn::Finished(Array::new()),
            crate::syntax::StmtKind::SBind(p_p5, e_p6, None) => {
                let cx_p2 = cx_p2.clone();
                let defs_p4 = defs_p4.clone();
                let e_p6 = e_p6.clone();
                let p_p5 = p_p5.clone();
                call_then(crate::check::env::names::start_pattern_names(p_p5.clone()), move |pattern_names_3267: Array<Text>| call_then(start_prompt_reads(cx_p2.clone(), e_p6.clone(), defs_p4.clone()), move |prompt_reads_3285: Array<Text>| prism_rtl::Turn::Finished(edges(&pattern_names_3267, &prompt_reads_3285))))
            },
            crate::syntax::StmtKind::SLet(p_p7, _, e_p8) => {
                let cx_p2 = cx_p2.clone();
                let defs_p4 = defs_p4.clone();
                let e_p8 = e_p8.clone();
                let env_p0 = env_p0.clone();
                let p_p7 = p_p7.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::env::names::start_pattern_names(p_p7.clone()), move |pattern_names_3353: Array<Text>| {
                    let names_p9 = pattern_names_3353;
                    call_value(fold_job(names_p9.clone(), Text::lit(""), {
                        let env_p0 = env_p0.clone();
                        let st_p1 = st_p1.clone();
                        Rc::new(move |(p0, p1): (Text, Text)| {
                            let env_p0 = env_p0.clone();
                            let st_p1 = st_p1.clone();
                            entered(once_job(move || {
                                let acc_pb = p0;
                                let n_pc = p1;
                                match get(&env_p0.locals, &n_pc) {
                                    Some(sc_pd) => prism_rtl::Turn::More(Rc::new(crate::check::types::HeadSigil { st_p0: st_p1.clone(), t_p1: sc_pd.ty.clone() })),
                                    None => prism_rtl::Turn::Finished(acc_pb.clone()),
                                }
                            }))
                        }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |fold_3388: Text| {
                        let layer_pa = fold_3388;
                        call_then(start_prompt_reads(cx_p2.clone(), e_p8.clone(), defs_p4.clone()), move |prompt_reads_3524: Array<Text>| call_value(filter_job(prompt_reads_3524, {
                            let env_p0 = env_p0.clone();
                            let st_p1 = st_p1.clone();
                            let layer_pa = layer_pa.clone();
                            Rc::new(move |p0: Text| {
                                let env_p0 = env_p0.clone();
                                let st_p1 = st_p1.clone();
                                let layer_pa = layer_pa.clone();
                                entered(once_job(move || {
                                    let n_pe = p0;
                                    prism_rtl::Turn::More(Rc::new(ReadIsPrompt { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_pe.clone(), layer_p3: layer_pa.clone() }))
                                }))
                            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |filter_3516: Array<Text>| prism_rtl::Turn::Finished(edges(&names_p9, &filter_3516))))
                    })
                })
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PromptEdges, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_edges(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, cx_p2: PCx, s_p3: crate::syntax::Stmt, defs_p4: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(PromptEdges { env_p0, st_p1, cx_p2, s_p3, defs_p4 })
}

/// ```prism
/// Edges: fn [Text], [Text] -> [((Text, Text))]
/// ```
pub fn edges(froms_p0: &Array<Text>, tos_p1: &Array<Text>) -> Array<(Text, Text)> {
    fold(froms_p0, &Array::new(), &(|acc_p2: &Array<(Text, Text)>, f_p3: &Text| append(acc_p2, &each(tos_p1, &(|t_p4: &Text| (f_p3.clone(), t_p4.clone()))))))
}

/// ```prism
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
/// ```
pub fn read_is_prompt(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, n_p2: &Text, layer_p3: &Text) -> bool {
    match get(&env_p0.locals, n_p2) {
        Some(sc_p4) => {
            let h_p5 = crate::check::types::head_sigil(st_p1, &sc_p4.ty);
            if layer_p3 == &Text::lit("!") {
                (&h_p5 == &Text::lit("!")) || (&h_p5 == &Text::lit("@"))
            } else {
                if layer_p3 == &Text::lit("$") {
                    (&h_p5 == &Text::lit("$")) || (&h_p5 == &Text::lit("!"))
                } else {
                    match crate::check::types::recording::walk(st_p1, &sc_p4.ty) {
                        crate::check::types::Ty::TyFn(_, _, _) => false,
                        _ => crate::check::env::is_lower_text(&crate::syntax::lexer::chars::drop_prefix(n_p2, &crate::check::types::unify::marks_of(n_p2))) && (&h_p5 == &Text::lit("")),
                    }
                }
            }
        },
        None => false,
    }
}

/// The step machine of `ReadIsPrompt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
/// ```
pub struct ReadIsPrompt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: Text,
    pub layer_p3: Text,
}

impl prism_rtl::Job<bool> for ReadIsPrompt {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let layer_p3 = &self.layer_p3;
        match get(&env_p0.locals, n_p2) {
            Some(sc_p4) => {
                let layer_p3 = layer_p3.clone();
                let n_p2 = n_p2.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::types::start_head_sigil(st_p1.clone(), sc_p4.ty.clone()), move |head_sigil_4011: Text| {
                    let h_p5 = head_sigil_4011;
                    if &layer_p3 == &Text::lit("!") {
                        prism_rtl::Turn::Finished((&h_p5 == &Text::lit("!")) || (&h_p5 == &Text::lit("@")))
                    } else {
                        if &layer_p3 == &Text::lit("$") {
                            prism_rtl::Turn::Finished((&h_p5 == &Text::lit("$")) || (&h_p5 == &Text::lit("!")))
                        } else {
                            call_then(crate::check::types::recording::start_walk(st_p1.clone(), sc_p4.ty.clone()), move |walk_4149: crate::check::types::Ty| match walk_4149 {
                                crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::Finished(false),
                                _ => prism_rtl::Turn::Finished(crate::check::env::is_lower_text(&crate::syntax::lexer::chars::drop_prefix(&n_p2, &crate::check::types::unify::marks_of(&n_p2))) && (&h_p5 == &Text::lit(""))),
                            })
                        }
                    }
                })
            },
            None => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start ReadIsPrompt, x`: what the function value is when passed to `@Run`.
pub fn start_read_is_prompt(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, n_p2: Text, layer_p3: Text) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(ReadIsPrompt { env_p0, st_p1, n_p2, layer_p3 })
}

/// ```prism
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
/// ```
pub fn prompt_base(env_p0: &crate::check::expr::Env, stmts_p1: &Array<crate::syntax::Stmt>) -> Map<Text, crate::check::shrink::Rel> {
    let pre_p2 = crate::check::shrink::relations::prelude_seeds(&env_p0.g, &env_p0.home);
    let seeds_p3 = fold(&keys(&pre_p2), &pre_p2, &(|m_p4: &Map<Text, crate::check::shrink::Rel>, k_p5: &Text| if crate::check::env::has_key(&env_p0.locals, &crate::syntax::lexer::chars::drop_prefix(k_p5, &Text::lit("pre:"))) {
        remove(m_p4, k_p5)
    } else {
        m_p4.clone()
    }));
    fold(stmts_p1, &seeds_p3, &(|m_p6: &Map<Text, crate::check::shrink::Rel>, s_p7: &crate::syntax::Stmt| lam_let_rels(s_p7, m_p6)))
}

/// The step machine of `PromptBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
/// ```
pub struct PromptBase {
    pub env_p0: crate::check::expr::Env,
    pub stmts_p1: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for PromptBase {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let env_p0 = &self.env_p0;
        let stmts_p1 = &self.stmts_p1;
        let pre_p2 = crate::check::shrink::relations::prelude_seeds(&env_p0.g, &env_p0.home);
        let seeds_p3 = fold(&keys(&pre_p2), &pre_p2, &(|m_p4: &Map<Text, crate::check::shrink::Rel>, k_p5: &Text| if crate::check::env::has_key(&env_p0.locals, &crate::syntax::lexer::chars::drop_prefix(k_p5, &Text::lit("pre:"))) {
            remove(m_p4, k_p5)
        } else {
            m_p4.clone()
        }));
        prism_rtl::Turn::Finished(fold(stmts_p1, &seeds_p3, &(|m_p6: &Map<Text, crate::check::shrink::Rel>, s_p7: &crate::syntax::Stmt| lam_let_rels(s_p7, m_p6))))
    }
}

/// `Start PromptBase, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_base(env_p0: crate::check::expr::Env, stmts_p1: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(PromptBase { env_p0, stmts_p1 })
}

/// ```prism
/// LamLetRels: fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn lam_let_rels(s_p0: &crate::syntax::Stmt, m_p1: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    match &s_p0.kind {
        crate::syntax::StmtKind::SLet(p_p2, _, e_p3) => match ((*p_p2.kind).clone(), lambda_of(e_p3)) {
            (crate::syntax::PatternKind::PName(n_p4), Some(lam_p5)) => insert(m_p1, &Text::from(format!("lamlet:{}", &crate::check::env::sname_key(&n_p4))), &crate::check::shrink::Rel { param: lam_p5.span.start.clone(), strict: false }),
            _ => m_p1.clone(),
        },
        _ => m_p1.clone(),
    }
}

/// ```prism
/// ?LambdaOf: fn Expr -> ?Expr
/// ```
pub fn lambda_of(e_p0: &crate::syntax::Expr) -> Option<crate::syntax::Expr> {
    match &*e_p0.kind {
        crate::syntax::ExprKind::ELambda(_, _) => Some(e_p0.clone()),
        crate::syntax::ExprKind::EGroup(x_p1) => lambda_of(&**x_p1),
        _ => None,
    }
}

/// ```prism
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
/// ```
pub fn let_lambdas(stmts_p0: &Array<crate::syntax::Stmt>) -> Map<Nat, crate::syntax::Expr> {
    fold(&crate::check::shrink::walk::stmts_spots(stmts_p0, &Map::new()), &Map::new(), &(|m_p1: &Map<Nat, crate::syntax::Expr>, sp_p2: &crate::check::shrink::walk::Spot| match sp_p2 {
        crate::check::shrink::walk::Spot::SpotStmt(s_p3, _) => match &s_p3.kind {
            crate::syntax::StmtKind::SLet(_, _, e_p4) => match lambda_of(e_p4) {
                Some(lam_p5) => insert(m_p1, &lam_p5.span.start, &lam_p5),
                None => m_p1.clone(),
            },
            _ => m_p1.clone(),
        },
        _ => m_p1.clone(),
    }))
}

/// The step machine of `LetLambdas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
/// ```
pub struct LetLambdas {
    pub stmts_p0: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Map<Nat, crate::syntax::Expr>> for LetLambdas {
    fn cycle(&self) -> prism_rtl::Turn<Map<Nat, crate::syntax::Expr>> {
        let stmts_p0 = &self.stmts_p0;
        let stmts_p0 = stmts_p0.clone();
        call_then(crate::check::shrink::walk::start_stmts_spots(stmts_p0.clone(), Map::new()), move |stmts_spots_5873: Array<crate::check::shrink::walk::Spot>| prism_rtl::Turn::Finished(fold(&stmts_spots_5873, &Map::new(), &(|m_p1: &Map<Nat, crate::syntax::Expr>, sp_p2: &crate::check::shrink::walk::Spot| match sp_p2 {
            crate::check::shrink::walk::Spot::SpotStmt(s_p3, _) => match &s_p3.kind {
                crate::syntax::StmtKind::SLet(_, _, e_p4) => match lambda_of(e_p4) {
                    Some(lam_p5) => insert(m_p1, &lam_p5.span.start, &lam_p5),
                    None => m_p1.clone(),
                },
                _ => m_p1.clone(),
            },
            _ => m_p1.clone(),
        }))))
    }
}

/// `Start LetLambdas, x`: what the function value is when passed to `@Run`.
pub fn start_let_lambdas(stmts_p0: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Map<Nat, crate::syntax::Expr>>> {
    Rc::new(LetLambdas { stmts_p0 })
}

/// ```prism
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
/// ```
pub fn prompt_reads(cx_p0: &PCx, e_p1: &crate::syntax::Expr, defs_p2: &Array<Text>) -> Array<Text> {
    let spots_p3 = prompt_spots(cx_p0, e_p1, &cx_p0.base);
    run_to_end(fold_job(spots_p3.clone(), Array::new(), {
        let defs_p2 = defs_p2.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::walk::Spot)| {
            let defs_p2 = defs_p2.clone();
            entered(once_job(move || {
                let acc_p4 = p0;
                let sp_p5 = p1;
                call_then(crate::check::shrink::walk::start_spot_sites(sp_p5.clone()), move |spot_sites_7222: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(fold(&spot_sites_7222, &acc_p4, &(|a2_p6: &Array<Text>, site_p7: &crate::check::shrink::walk::Site| if crate::check::types::has_text(&defs_p2, &site_p7.callee) && !crate::check::shrink::relations::is_local(&site_p7.rels, &site_p7.callee) {
                    crate::check::types::add_text(a2_p6, &site_p7.callee)
                } else {
                    a2_p6.clone()
                }))))
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `PromptReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
/// ```
pub struct PromptReads {
    pub cx_p0: PCx,
    pub e_p1: crate::syntax::Expr,
    pub defs_p2: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for PromptReads {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cx_p0 = &self.cx_p0;
        let e_p1 = &self.e_p1;
        let defs_p2 = &self.defs_p2;
        let cx_p0 = cx_p0.clone();
        let defs_p2 = defs_p2.clone();
        let e_p1 = e_p1.clone();
        call_then(start_prompt_spots(cx_p0.clone(), e_p1.clone(), cx_p0.base.clone()), move |prompt_spots_7156: Array<crate::check::shrink::walk::Spot>| {
            let spots_p3 = prompt_spots_7156;
            fold_job(spots_p3.clone(), Array::new(), {
                let defs_p2 = defs_p2.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::walk::Spot)| {
                    let defs_p2 = defs_p2.clone();
                    entered(once_job(move || {
                        let acc_p4 = p0;
                        let sp_p5 = p1;
                        call_then(crate::check::shrink::walk::start_spot_sites(sp_p5.clone()), move |spot_sites_7222: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(fold(&spot_sites_7222, &acc_p4, &(|a2_p6: &Array<Text>, site_p7: &crate::check::shrink::walk::Site| if crate::check::types::has_text(&defs_p2, &site_p7.callee) && !crate::check::shrink::relations::is_local(&site_p7.rels, &site_p7.callee) {
                            crate::check::types::add_text(a2_p6, &site_p7.callee)
                        } else {
                            a2_p6.clone()
                        }))))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle()
        })
    }
}

/// `Start PromptReads, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_reads(cx_p0: PCx, e_p1: crate::syntax::Expr, defs_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PromptReads { cx_p0, e_p1, defs_p2 })
}

/// ```prism
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
/// ```
pub fn prompt_spots(cx_p0: &PCx, e_p1: &crate::syntax::Expr, m_p2: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Spot> {
    run_to_end(fold_job(prompt_kids(cx_p0, e_p1, m_p2), Array::from(vec![crate::check::shrink::walk::Spot::SpotExpr(e_p1.clone(), m_p2.clone())]), {
        let cx_p0 = cx_p0.clone();
        Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)| {
            let cx_p0 = cx_p0.clone();
            entered(once_job(move || {
                let acc_p3 = p0;
                let k_p4 = p1;
                prism_rtl::Turn::Finished(append(&acc_p3, &prompt_kid_spots(&cx_p0, &k_p4)))
            }))
        }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>>>
    }))
}

/// The step machine of `PromptSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
/// ```
pub struct PromptSpots {
    pub cx_p0: PCx,
    pub e_p1: crate::syntax::Expr,
    pub m_p2: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<crate::check::shrink::walk::Spot>> for PromptSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::shrink::walk::Spot>> {
        let cx_p0 = &self.cx_p0;
        let e_p1 = &self.e_p1;
        let m_p2 = &self.m_p2;
        fold_job(prompt_kids(cx_p0, e_p1, m_p2), Array::from(vec![crate::check::shrink::walk::Spot::SpotExpr(e_p1.clone(), m_p2.clone())]), {
            let cx_p0 = cx_p0.clone();
            Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)| {
                let cx_p0 = cx_p0.clone();
                entered(once_job(move || {
                    let acc_p3 = p0;
                    let k_p4 = p1;
                    prism_rtl::Turn::Finished(append(&acc_p3, &prompt_kid_spots(&cx_p0, &k_p4)))
                }))
            }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>>>
        }).cycle()
    }
}

/// `Start PromptSpots, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_spots(cx_p0: PCx, e_p1: crate::syntax::Expr, m_p2: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>> {
    Rc::new(PromptSpots { cx_p0, e_p1, m_p2 })
}

/// ```prism
/// PromptKids: unbounded fn PCx, Expr, (Text ==> Rel) -> [Kid]
/// ```
pub fn prompt_kids(cx_p0: &PCx, e_p1: &crate::syntax::Expr, m_p2: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Kid> {
    match &*e_p1.kind {
        crate::syntax::ExprKind::ELambda(_, _) => Array::new(),
        crate::syntax::ExprKind::ERebuild(_, body_p3) => row_kids(body_p3, m_p2, &Array::new()),
        crate::syntax::ExprKind::EFor(binders_o4, _, body_p5) => row_kids(body_p5, m_p2, &for_binder_names(binders_o4)),
        crate::syntax::ExprKind::EWidgetBlock(_) => Array::new(),
        crate::syntax::ExprKind::ECall(c_p6, _, _, _) => prompt_call_kids(cx_p0, e_p1, &crate::check::shrink::walk::callee_name(&**c_p6), m_p2),
        crate::syntax::ExprKind::EMethod(_, n_p7, _) => prompt_call_kids(cx_p0, e_p1, &Some(crate::check::env::sname_key(n_p7)), m_p2),
        _ => crate::check::shrink::walk::expr_kids(e_p1, m_p2),
    }
}

/// ```prism
/// RowKids: unbounded fn Block, (Text ==> Rel), [Text] -> [Kid]
/// ```
pub fn row_kids(body_p0: &crate::syntax::Block, m_p1: &Map<Text, crate::check::shrink::Rel>, binders_p2: &Array<Text>) -> Array<crate::check::shrink::walk::Kid> {
    let lines_p3 = filter(&body_p0.stmts, &(|s_p5: &crate::syntax::Stmt| match &s_p5.kind {
        crate::syntax::StmtKind::SBind(_, _, Some(_)) => false,
        _ => true,
    }));
    let own_p4 = run_to_end(fold_job(body_p0.stmts.clone(), append(binders_p2, &Array::from(vec![Text::lit("_"), Text::lit("$_")])), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| entered(once_job(move || {
        let acc_p6 = p0;
        let s_p7 = p1;
        call_then(start_stmt_defs(s_p7.clone()), move |stmt_defs_8893: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p6, &stmt_defs_8893)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    Array::from(vec![crate::check::shrink::walk::Kid::KidStmts(lines_p3.clone(), crate::check::shrink::relations::hide(m_p1, &own_p4))])
}

/// ```prism
/// ForBinderNames: unbounded fn ?ForBinders -> [Text]
/// ```
pub fn for_binder_names(binders_o0: &Option<crate::syntax::ForBinders>) -> Array<Text> {
    match binders_o0 {
        Some(fb_p1) => match &fb_p1.second {
            Some(second_p2) => append(&crate::check::env::names::pattern_names(&fb_p1.first), &crate::check::env::names::pattern_names(second_p2)),
            None => crate::check::env::names::pattern_names(&fb_p1.first),
        },
        None => Array::new(),
    }
}

/// ```prism
/// PromptCallKids: unbounded fn PCx, Expr, ?Text, (Text ==> Rel) -> [Kid]
/// ```
pub fn prompt_call_kids(cx_p0: &PCx, e_p1: &crate::syntax::Expr, n_o2: &Option<Text>, m_p3: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Kid> {
    match n_o2 {
        Some(n_p4) => {
            let called_p5 = follow_lam_let(cx_p0, n_p4, m_p3);
            if crate::check::shrink::relations::is_local(m_p3, n_p4) {
                append(&called_p5, &open_lambdas(cx_p0, &crate::check::shrink::walk::expr_kids(e_p1, m_p3)))
            } else {
                if &len(&called_p5) > &Nat::from(0u32) {
                    append(&called_p5, &open_lambdas(cx_p0, &crate::check::shrink::walk::expr_kids(e_p1, m_p3)))
                } else {
                    match crate::check::shrink::locals::resolve_callee(&cx_p0.g, &cx_p0.home, n_p4) {
                        Some(k_p6) => if crate::check::shrink::relations::is_prelude_key(&cx_p0.g, &k_p6) && is_delayed_widget(&crate::syntax::lexer::chars::drop_prefix(&k_p6, &Text::lit("Prelude."))) {
                            Array::new()
                        } else {
                            if crate::check::shrink::relations::is_prelude_key(&cx_p0.g, &k_p6) && crate::syntax::lexer::chars::has_prefix(&k_p6, &Text::lit("Prelude.@")) {
                                crate::check::shrink::walk::expr_kids(e_p1, m_p3)
                            } else {
                                open_lambdas(cx_p0, &crate::check::shrink::walk::expr_kids(e_p1, m_p3))
                            }
                        },
                        None => open_lambdas(cx_p0, &crate::check::shrink::walk::expr_kids(e_p1, m_p3)),
                    }
                }
            }
        },
        None => open_lambdas(cx_p0, &crate::check::shrink::walk::expr_kids(e_p1, m_p3)),
    }
}

/// ```prism
/// OpenLambdas: unbounded fn PCx, [Kid] -> [Kid]
/// ```
pub fn open_lambdas(cx_p0: &PCx, kids_p1: &Array<crate::check::shrink::walk::Kid>) -> Array<crate::check::shrink::walk::Kid> {
    run_to_end(fold_job(kids_p1.clone(), Array::new(), {
        let cx_p0 = cx_p0.clone();
        Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Kid>, crate::check::shrink::walk::Kid)| {
            let cx_p0 = cx_p0.clone();
            entered(once_job(move || {
                let acc_p2 = p0;
                let k_p3 = p1;
                match &k_p3 {
                    crate::check::shrink::walk::Kid::KidExpr(x_p4, m_p5) => match &*x_p4.kind {
                        crate::syntax::ExprKind::ELambda(ps_o6, body_p7) => {
                            let ps_o6 = ps_o6.clone();
                            let body_p7 = (**body_p7).clone();
                            let m_p5 = m_p5.clone();
                            call_then(crate::check::shrink::walk::start_patterns_names(or(&ps_o6, &Array::new())), move |patterns_names_10512: Array<Text>| prism_rtl::Turn::Finished(push(&acc_p2, &crate::check::shrink::walk::lambda_kid(&body_p7, &crate::check::shrink::relations::hide(&m_p5, &patterns_names_10512)))))
                        },
                        crate::syntax::ExprKind::EName(n_p8) => prism_rtl::Turn::Finished(append(&push(&acc_p2, &k_p3), &follow_lam_let(&cx_p0, &crate::check::env::sname_key(n_p8), m_p5))),
                        _ => prism_rtl::Turn::Finished(push(&acc_p2, &k_p3)),
                    },
                    _ => prism_rtl::Turn::Finished(push(&acc_p2, &k_p3)),
                }
            }))
        }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Kid>, crate::check::shrink::walk::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Kid>>>>
    }))
}

/// ```prism
/// FollowLamLet: unbounded fn PCx, Text, (Text ==> Rel) -> [Kid]
/// ```
pub fn follow_lam_let(cx_p0: &PCx, n_p1: &Text, m_p2: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Kid> {
    match get(m_p2, &Text::from(format!("lamlet:{}", n_p1))) {
        Some(r_p3) => if crate::check::env::has_key(m_p2, &Text::from(format!("seen:{}", &r_p3.param))) {
            Array::new()
        } else {
            match get(&cx_p0.lams, &r_p3.param) {
                Some(lam_p4) => match &*lam_p4.kind {
                    crate::syntax::ExprKind::ELambda(ps_o5, body_p6) => {
                        let seen_p7 = fold(&keys(m_p2), &cx_p0.base, &(|m2_p8: &Map<Text, crate::check::shrink::Rel>, k_p9: &Text| if crate::syntax::lexer::chars::has_prefix(k_p9, &Text::lit("seen:")) {
                            insert(m2_p8, k_p9, &crate::check::shrink::relations::no_rel())
                        } else {
                            m2_p8.clone()
                        }));
                        Array::from(vec![crate::check::shrink::walk::lambda_kid(&**body_p6, &crate::check::shrink::relations::hide(&insert(&seen_p7, &Text::from(format!("seen:{}", &r_p3.param)), &crate::check::shrink::relations::no_rel()), &crate::check::shrink::walk::patterns_names(&or(ps_o5, &Array::new()))))])
                    },
                    _ => Array::new(),
                },
                None => Array::new(),
            }
        },
        None => Array::new(),
    }
}

/// ```prism
/// PromptKidSpots: unbounded fn PCx, Kid -> [Spot]
/// ```
pub fn prompt_kid_spots(cx_p0: &PCx, k_p1: &crate::check::shrink::walk::Kid) -> Array<crate::check::shrink::walk::Spot> {
    match k_p1 {
        crate::check::shrink::walk::Kid::KidExpr(x_p2, m_p3) => prompt_spots(cx_p0, x_p2, m_p3),
        crate::check::shrink::walk::Kid::KidStmts(ss_p4, m_p5) => {
            let bm_p6 = crate::check::shrink::relations::block_rels(ss_p4, m_p5);
            run_to_end(fold_job(ss_p4.clone(), Array::new(), {
                let cx_p0 = cx_p0.clone();
                let bm_p6 = bm_p6.clone();
                Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Spot>, crate::syntax::Stmt)| {
                    let cx_p0 = cx_p0.clone();
                    let bm_p6 = bm_p6.clone();
                    entered(once_job(move || {
                        let acc_p7 = p0;
                        let s_p8 = p1;
                        prism_rtl::Turn::Finished(append(&acc_p7, &prompt_stmt_spots(&cx_p0, &s_p8, &bm_p6)))
                    }))
                }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Spot>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>>>
            }))
        },
    }
}

/// ```prism
/// PromptStmtSpots: unbounded fn PCx, Stmt, (Text ==> Rel) -> [Spot]
/// ```
pub fn prompt_stmt_spots(cx_p0: &PCx, s_p1: &crate::syntax::Stmt, m_p2: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Spot> {
    match &s_p1.kind {
        crate::syntax::StmtKind::SFn(_) => Array::from(vec![crate::check::shrink::walk::Spot::SpotStmt(s_p1.clone(), m_p2.clone())]),
        crate::syntax::StmtKind::SWidget(_) => Array::from(vec![crate::check::shrink::walk::Spot::SpotStmt(s_p1.clone(), m_p2.clone())]),
        _ => run_to_end(fold_job(crate::check::shrink::walk::stmt_kids(s_p1, m_p2), Array::from(vec![crate::check::shrink::walk::Spot::SpotStmt(s_p1.clone(), m_p2.clone())]), {
            let cx_p0 = cx_p0.clone();
            Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)| {
                let cx_p0 = cx_p0.clone();
                entered(once_job(move || {
                    let acc_p3 = p0;
                    let k_p4 = p1;
                    prism_rtl::Turn::Finished(append(&acc_p3, &prompt_kid_spots(&cx_p0, &k_p4)))
                }))
            }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>>>
        })),
    }
}

/// ```prism
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
/// ```
pub fn find_cycle(defs_p0: &Array<Text>, edges_p1: &Array<(Text, Text)>) -> Array<Text> {
    run_to_end(fold_job(defs_p0.clone(), Array::new(), {
        let defs_p0 = defs_p0.clone();
        let edges_p1 = edges_p1.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
            let defs_p0 = defs_p0.clone();
            let edges_p1 = edges_p1.clone();
            entered(once_job(move || {
                let found_p2 = p0;
                let d_p3 = p1;
                if &len(&found_p2) > &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(found_p2.clone())
                } else {
                    prism_rtl::Turn::More(Rc::new(CycleThrough { defs_p0: defs_p0.clone(), edges_p1: edges_p1.clone(), d_p2: d_p3.clone() }))
                }
            }))
        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `FindCycle`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
/// ```
pub struct FindCycle {
    pub defs_p0: Array<Text>,
    pub edges_p1: Array<(Text, Text)>,
}

impl prism_rtl::Job<Array<Text>> for FindCycle {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let defs_p0 = &self.defs_p0;
        let edges_p1 = &self.edges_p1;
        fold_job(defs_p0.clone(), Array::new(), {
            let defs_p0 = defs_p0.clone();
            let edges_p1 = edges_p1.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                let defs_p0 = defs_p0.clone();
                let edges_p1 = edges_p1.clone();
                entered(once_job(move || {
                    let found_p2 = p0;
                    let d_p3 = p1;
                    if &len(&found_p2) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(found_p2.clone())
                    } else {
                        prism_rtl::Turn::More(Rc::new(CycleThrough { defs_p0: defs_p0.clone(), edges_p1: edges_p1.clone(), d_p2: d_p3.clone() }))
                    }
                }))
            }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start FindCycle, x`: what the function value is when passed to `@Run`.
pub fn start_find_cycle(defs_p0: Array<Text>, edges_p1: Array<(Text, Text)>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(FindCycle { defs_p0, edges_p1 })
}

/// ```prism
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
/// ```
pub fn cycle_through(defs_p0: &Array<Text>, edges_p1: &Array<(Text, Text)>, d_p2: &Text) -> Array<Text> {
    let fwd_p3 = reach_from(edges_p1, d_p2);
    if crate::check::types::has_text(&fwd_p3, d_p2) {
        run_to_end(filter_job(defs_p0.clone(), {
            let fwd_p3 = fwd_p3.clone();
            let edges_p1 = edges_p1.clone();
            let d_p2 = d_p2.clone();
            Rc::new(move |p0: Text| {
                let fwd_p3 = fwd_p3.clone();
                let edges_p1 = edges_p1.clone();
                let d_p2 = d_p2.clone();
                entered(once_job(move || {
                    let x_p4 = p0;
                    prism_rtl::Turn::Finished(crate::check::types::has_text(&fwd_p3, &x_p4) && crate::check::types::has_text(&reach_from(&edges_p1, &x_p4), &d_p2))
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
        }))
    } else {
        Array::new()
    }
}

/// The step machine of `CycleThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
/// ```
pub struct CycleThrough {
    pub defs_p0: Array<Text>,
    pub edges_p1: Array<(Text, Text)>,
    pub d_p2: Text,
}

impl prism_rtl::Job<Array<Text>> for CycleThrough {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let defs_p0 = &self.defs_p0;
        let edges_p1 = &self.edges_p1;
        let d_p2 = &self.d_p2;
        let d_p2 = d_p2.clone();
        let defs_p0 = defs_p0.clone();
        let edges_p1 = edges_p1.clone();
        call_then(start_reach_from(edges_p1.clone(), d_p2.clone()), move |reach_from_12532: Array<Text>| {
            let fwd_p3 = reach_from_12532;
            if crate::check::types::has_text(&fwd_p3, &d_p2) {
                filter_job(defs_p0.clone(), {
                    let fwd_p3 = fwd_p3.clone();
                    let edges_p1 = edges_p1.clone();
                    let d_p2 = d_p2.clone();
                    Rc::new(move |p0: Text| {
                        let fwd_p3 = fwd_p3.clone();
                        let edges_p1 = edges_p1.clone();
                        let d_p2 = d_p2.clone();
                        entered(once_job(move || {
                            let x_p4 = p0;
                            prism_rtl::Turn::Finished(crate::check::types::has_text(&fwd_p3, &x_p4) && crate::check::types::has_text(&reach_from(&edges_p1, &x_p4), &d_p2))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle()
            } else {
                prism_rtl::Turn::Finished(Array::new())
            }
        })
    }
}

/// `Start CycleThrough, x`: what the function value is when passed to `@Run`.
pub fn start_cycle_through(defs_p0: Array<Text>, edges_p1: Array<(Text, Text)>, d_p2: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CycleThrough { defs_p0, edges_p1, d_p2 })
}

/// ```prism
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
/// ```
pub fn reach_from(edges_p0: &Array<(Text, Text)>, d_p1: &Text) -> Array<Text> {
    reach(edges_p0, &each(&filter(edges_p0, &(|(f_p2, _): &(Text, Text)| f_p2 == d_p1)), &(|(_, t_p3): &(Text, Text)| t_p3.clone())), &Array::new())
}

/// The step machine of `ReachFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
/// ```
pub struct ReachFrom {
    pub edges_p0: Array<(Text, Text)>,
    pub d_p1: Text,
}

impl prism_rtl::Job<Array<Text>> for ReachFrom {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let edges_p0 = &self.edges_p0;
        let d_p1 = &self.d_p1;
        prism_rtl::Turn::Finished(reach(edges_p0, &each(&filter(edges_p0, &(|(f_p2, _): &(Text, Text)| f_p2 == d_p1)), &(|(_, t_p3): &(Text, Text)| t_p3.clone())), &Array::new()))
    }
}

/// `Start ReachFrom, x`: what the function value is when passed to `@Run`.
pub fn start_reach_from(edges_p0: Array<(Text, Text)>, d_p1: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReachFrom { edges_p0, d_p1 })
}

/// ```prism
/// Reach: unbounded fn [((Text, Text))], [Text], [Text] -> [Text]
/// ```
pub fn reach(edges_p0: &Array<(Text, Text)>, frontier_p1: &Array<Text>, seen_p2: &Array<Text>) -> Array<Text> {
    match index(frontier_p1, &Nat::from(0u32)) {
        None => seen_p2.clone(),
        Some(x_p3) => if crate::check::types::has_text(seen_p2, &x_p3) {
            reach(edges_p0, &drop(frontier_p1, &Nat::from(1u32)), seen_p2)
        } else {
            reach(edges_p0, &append(&drop(frontier_p1, &Nat::from(1u32)), &each(&filter(edges_p0, &(|(f_p4, _): &(Text, Text)| f_p4 == &x_p3)), &(|(_, t_p5): &(Text, Text)| t_p5.clone()))), &push(seen_p2, &x_p3))
        },
    }
}
