//! The module `Check.Passes.Cycles`, from `target/bootstrap/src/prismc/check/passes/cycles.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `PCx`:
///
/// ```prism
/// type PCx = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct PCx {
    pub g: crate::check::env::G,
    pub home: Text,
    pub lams: Map<Nat, crate::syntax::Expr>,
    pub base: Map<Text, crate::check::shrink::Rel>,
}

impl Show for PCx {
    fn show(&self, p: &mut Printer) {
        p.record("PCx", &[("g", &self.g), ("home", &self.home), ("lams", &self.lams), ("base", &self.base)]);
    }
}

impl ToPod for PCx {
    fn to_pod(&self) -> Pod {
        Pod::record("PCx", vec![("g", self.g.to_pod()), ("home", self.home.to_pod()), ("lams", self.lams.to_pod()), ("base", self.base.to_pod())])
    }
}

impl FromPod for PCx {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(PCx { g: FromPod::from_pod(field(p, "g")?)?, home: FromPod::from_pod(field(p, "home")?)?, lams: FromPod::from_pod(field(p, "lams")?)?, base: FromPod::from_pod(field(p, "base")?)? })
    }
}

/// ```prism
/// IsDelayedWidget: fn Text -> Bool
/// ```
pub fn is_delayed_widget(n: &Text) -> bool {
    crate::check::types::has_text(&Array::from(vec![Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")]), n)
}

/// ```prism
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
/// ```
pub fn block_prompt_cycles(env: &crate::check::expr::Env, st: &crate::check::types::St, b: &crate::syntax::Block) -> crate::check::types::St {
    let defs = run_to_end(fold_job(b.stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| entered(once_job(move || {
        let acc = p0;
        let s = p1;
        call_then(start_stmt_defs(s.clone()), move |stmt_defs_2204: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &stmt_defs_2204)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let cx_ = PCx { g: env.g.clone(), home: env.home.clone(), lams: let_lambdas(&b.stmts), base: prompt_base(env, &b.stmts) };
    let edges_ = run_to_end(fold_job(b.stmts.clone(), Array::new(), {
        let env = env.clone();
        let st = st.clone();
        let cx_ = cx_.clone();
        let defs = defs.clone();
        Rc::new(move |(p0, p1): (Array<(Text, Text)>, crate::syntax::Stmt)| {
            let env = env.clone();
            let st = st.clone();
            let cx_ = cx_.clone();
            let defs = defs.clone();
            entered(once_job(move || {
                let acc = p0;
                let s = p1;
                call_then(start_prompt_edges(env.clone(), st.clone(), cx_.clone(), s.clone(), defs.clone()), move |prompt_edges_2375: Array<(Text, Text)>| prism_rtl::Turn::Finished(append(&acc, &prompt_edges_2375)))
            }))
        }) as Rc<dyn Fn((Array<(Text, Text)>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>>>
    }));
    let cyc = find_cycle(&defs, &edges_);
    if &len(&cyc) == &Nat::from(0u32) {
        st.clone()
    } else {
        {
            let span = run_to_end(fold_job(b.stmts.clone(), b.span.clone(), {
                let cyc = cyc.clone();
                Rc::new(move |(p0, p1): (crate::syntax::Range, crate::syntax::Stmt)| {
                    let cyc = cyc.clone();
                    entered(once_job(move || {
                        let sp = p0;
                        let s = p1;
                        call_then(start_stmt_defs(s.clone()), move |stmt_defs_2543: Array<Text>| if crate::check::types::has_text(&stmt_defs_2543, &or(&index(&cyc, &Nat::from(0u32)), &Text::lit(""))) {
                            prism_rtl::Turn::Finished(s.span.clone())
                        } else {
                            prism_rtl::Turn::Finished(sp.clone())
                        })
                    }))
                }) as Rc<dyn Fn((crate::syntax::Range, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::syntax::Range>>>
            }));
            crate::check::types::recording::err_fix(st, &Text::lit("prompt-cycle"), &span, &Text::from(format!("a prompt cycle: {}", &crate::syntax::lexer::chars::join(&each(&cyc, &(|n: &Text| Text::from(format!("`{}`", n)))), &Text::lit(", ")))), &Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened"))
        }
    }
}

/// The step machine of `BlockPromptCycles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
/// ```
pub struct BlockPromptCycles {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<crate::check::types::St> for BlockPromptCycles {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let b = b.clone();
        let env = env.clone();
        let st = st.clone();
        call_value(fold_job(b.stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| entered(once_job(move || {
            let acc = p0;
            let s = p1;
            call_then(start_stmt_defs(s.clone()), move |stmt_defs_2204: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &stmt_defs_2204)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_2161: Array<Text>| {
            let defs = fold_2161;
            call_then(start_let_lambdas(b.stmts.clone()), move |let_lambdas_2263: Map<Nat, crate::syntax::Expr>| call_then(start_prompt_base(env.clone(), b.stmts.clone()), move |prompt_base_2290: Map<Text, crate::check::shrink::Rel>| {
                let cx_ = PCx { g: env.g.clone(), home: env.home.clone(), lams: let_lambdas_2263, base: prompt_base_2290 };
                call_value(fold_job(b.stmts.clone(), Array::new(), {
                    let env = env.clone();
                    let st = st.clone();
                    let cx_ = cx_.clone();
                    let defs = defs.clone();
                    Rc::new(move |(p0, p1): (Array<(Text, Text)>, crate::syntax::Stmt)| {
                        let env = env.clone();
                        let st = st.clone();
                        let cx_ = cx_.clone();
                        let defs = defs.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let s = p1;
                            call_then(start_prompt_edges(env.clone(), st.clone(), cx_.clone(), s.clone(), defs.clone()), move |prompt_edges_2375: Array<(Text, Text)>| prism_rtl::Turn::Finished(append(&acc, &prompt_edges_2375)))
                        }))
                    }) as Rc<dyn Fn((Array<(Text, Text)>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>>>
                }), move |fold_2332: Array<(Text, Text)>| {
                    let edges_ = fold_2332;
                    call_then(start_find_cycle(defs.clone(), edges_.clone()), move |find_cycle_2423: Array<Text>| {
                        let cyc = find_cycle_2423;
                        if &len(&cyc) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(st.clone())
                        } else {
                            call_value(fold_job(b.stmts.clone(), b.span.clone(), {
                                let cyc = cyc.clone();
                                Rc::new(move |(p0, p1): (crate::syntax::Range, crate::syntax::Stmt)| {
                                    let cyc = cyc.clone();
                                    entered(once_job(move || {
                                        let sp = p0;
                                        let s = p1;
                                        call_then(start_stmt_defs(s.clone()), move |stmt_defs_2543: Array<Text>| if crate::check::types::has_text(&stmt_defs_2543, &or(&index(&cyc, &Nat::from(0u32)), &Text::lit(""))) {
                                            prism_rtl::Turn::Finished(s.span.clone())
                                        } else {
                                            prism_rtl::Turn::Finished(sp.clone())
                                        })
                                    }))
                                }) as Rc<dyn Fn((crate::syntax::Range, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::syntax::Range>>>
                            }), move |fold_2500: crate::syntax::Range| {
                                let span = fold_2500;
                                prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st, &Text::lit("prompt-cycle"), &span, &Text::from(format!("a prompt cycle: {}", &crate::syntax::lexer::chars::join(&each(&cyc, &(|n: &Text| Text::from(format!("`{}`", n)))), &Text::lit(", ")))), &Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened")))
                            })
                        }
                    })
                })
            }))
        })
    }
}

/// `Start BlockPromptCycles, x`: what the function value is when passed to `@Run`.
pub fn start_block_prompt_cycles(env: crate::check::expr::Env, st: crate::check::types::St, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(BlockPromptCycles { env, st, b })
}

/// ```prism
/// StmtDefs: unbounded fn Stmt -> [Text]
/// ```
pub fn stmt_defs(s: &crate::syntax::Stmt) -> Array<Text> {
    match &s.kind {
        crate::syntax::StmtKind::SBind(p_, _, _) => crate::check::env::names::pattern_names(p_),
        crate::syntax::StmtKind::SLet(p_, _, _) => crate::check::env::names::pattern_names(p_),
        _ => Array::new(),
    }
}

/// The step machine of `StmtDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtDefs: unbounded fn Stmt -> [Text]
/// ```
pub struct StmtDefs {
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<Text>> for StmtDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SBind(p_, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::names::PatternNames { p_: p_.clone() })),
            crate::syntax::StmtKind::SLet(p_, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::names::PatternNames { p_: p_.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start StmtDefs, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_defs(s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(StmtDefs { s })
}

/// ```prism
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
/// ```
pub fn prompt_edges(env: &crate::check::expr::Env, st: &crate::check::types::St, cx_: &PCx, s: &crate::syntax::Stmt, defs: &Array<Text>) -> Array<(Text, Text)> {
    match &s.kind {
        crate::syntax::StmtKind::SBind(_, _, Some(_)) => Array::new(),
        crate::syntax::StmtKind::SBind(p_, e, None) => edges(&crate::check::env::names::pattern_names(p_), &prompt_reads(cx_, e, defs)),
        crate::syntax::StmtKind::SLet(p_, _, e) => {
            let names = crate::check::env::names::pattern_names(p_);
            let layer = run_to_end(fold_job(names.clone(), Text::lit(""), {
                let env = env.clone();
                let st = st.clone();
                Rc::new(move |(p0, p1): (Text, Text)| {
                    let env = env.clone();
                    let st = st.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let n = p1;
                        match get(&env.locals, &n) {
                            Some(sc) => prism_rtl::Turn::More(Rc::new(crate::check::types::HeadSigil { st: st.clone(), t: sc.ty.clone() })),
                            None => prism_rtl::Turn::Finished(acc.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            edges(&names, &run_to_end(filter_job(prompt_reads(cx_, e, defs), {
                let env = env.clone();
                let st = st.clone();
                let layer = layer.clone();
                Rc::new(move |p0: Text| {
                    let env = env.clone();
                    let st = st.clone();
                    let layer = layer.clone();
                    entered(once_job(move || {
                        let n = p0;
                        prism_rtl::Turn::More(Rc::new(ReadIsPrompt { env: env.clone(), st: st.clone(), n: n.clone(), layer: layer.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
            })))
        },
        _ => Array::new(),
    }
}

/// The step machine of `PromptEdges`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
/// ```
pub struct PromptEdges {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub cx_: PCx,
    pub s: crate::syntax::Stmt,
    pub defs: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for PromptEdges {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let env = &self.env;
        let st = &self.st;
        let cx_ = &self.cx_;
        let s = &self.s;
        let defs = &self.defs;
        match &s.kind {
            crate::syntax::StmtKind::SBind(_, _, Some(_)) => prism_rtl::Turn::Finished(Array::new()),
            crate::syntax::StmtKind::SBind(p_, e, None) => {
                let cx_ = cx_.clone();
                let defs = defs.clone();
                let e = e.clone();
                let p_ = p_.clone();
                call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_3267: Array<Text>| call_then(start_prompt_reads(cx_.clone(), e.clone(), defs.clone()), move |prompt_reads_3285: Array<Text>| prism_rtl::Turn::Finished(edges(&pattern_names_3267, &prompt_reads_3285))))
            },
            crate::syntax::StmtKind::SLet(p_, _, e) => {
                let cx_ = cx_.clone();
                let defs = defs.clone();
                let e = e.clone();
                let env = env.clone();
                let p_ = p_.clone();
                let st = st.clone();
                call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_3353: Array<Text>| {
                    let names = pattern_names_3353;
                    call_value(fold_job(names.clone(), Text::lit(""), {
                        let env = env.clone();
                        let st = st.clone();
                        Rc::new(move |(p0, p1): (Text, Text)| {
                            let env = env.clone();
                            let st = st.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let n = p1;
                                match get(&env.locals, &n) {
                                    Some(sc) => prism_rtl::Turn::More(Rc::new(crate::check::types::HeadSigil { st: st.clone(), t: sc.ty.clone() })),
                                    None => prism_rtl::Turn::Finished(acc.clone()),
                                }
                            }))
                        }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |fold_3388: Text| {
                        let layer = fold_3388;
                        call_then(start_prompt_reads(cx_.clone(), e.clone(), defs.clone()), move |prompt_reads_3524: Array<Text>| call_value(filter_job(prompt_reads_3524, {
                            let env = env.clone();
                            let st = st.clone();
                            let layer = layer.clone();
                            Rc::new(move |p0: Text| {
                                let env = env.clone();
                                let st = st.clone();
                                let layer = layer.clone();
                                entered(once_job(move || {
                                    let n = p0;
                                    prism_rtl::Turn::More(Rc::new(ReadIsPrompt { env: env.clone(), st: st.clone(), n: n.clone(), layer: layer.clone() }))
                                }))
                            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |filter_3516: Array<Text>| prism_rtl::Turn::Finished(edges(&names, &filter_3516))))
                    })
                })
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PromptEdges, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_edges(env: crate::check::expr::Env, st: crate::check::types::St, cx_: PCx, s: crate::syntax::Stmt, defs: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(PromptEdges { env, st, cx_, s, defs })
}

/// ```prism
/// Edges: fn [Text], [Text] -> [((Text, Text))]
/// ```
pub fn edges(froms: &Array<Text>, tos: &Array<Text>) -> Array<(Text, Text)> {
    fold(froms, &Array::new(), &(|acc: &Array<(Text, Text)>, f: &Text| append(acc, &each(tos, &(|t: &Text| (f.clone(), t.clone()))))))
}

/// ```prism
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
/// ```
pub fn read_is_prompt(env: &crate::check::expr::Env, st: &crate::check::types::St, n: &Text, layer: &Text) -> bool {
    match get(&env.locals, n) {
        Some(sc) => {
            let h = crate::check::types::head_sigil(st, &sc.ty);
            if layer == &Text::lit("!") {
                (&h == &Text::lit("!")) || (&h == &Text::lit("@"))
            } else {
                if layer == &Text::lit("$") {
                    (&h == &Text::lit("$")) || (&h == &Text::lit("!"))
                } else {
                    match crate::check::types::recording::walk(st, &sc.ty) {
                        crate::check::types::Ty::TyFn(_, _, _) => false,
                        _ => crate::check::env::is_lower_text(&crate::syntax::lexer::chars::drop_prefix(n, &crate::check::types::unify::marks_of(n))) && (&h == &Text::lit("")),
                    }
                }
            }
        },
        None => false,
    }
}

/// The step machine of `ReadIsPrompt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
/// ```
pub struct ReadIsPrompt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub n: Text,
    pub layer: Text,
}

impl prism_rtl::Job<bool> for ReadIsPrompt {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let layer = &self.layer;
        match get(&env.locals, n) {
            Some(sc) => {
                let layer = layer.clone();
                let n = n.clone();
                let st = st.clone();
                call_then(crate::check::types::start_head_sigil(st.clone(), sc.ty.clone()), move |head_sigil_4011: Text| {
                    let h = head_sigil_4011;
                    if &layer == &Text::lit("!") {
                        prism_rtl::Turn::Finished((&h == &Text::lit("!")) || (&h == &Text::lit("@")))
                    } else {
                        if &layer == &Text::lit("$") {
                            prism_rtl::Turn::Finished((&h == &Text::lit("$")) || (&h == &Text::lit("!")))
                        } else {
                            call_then(crate::check::types::recording::start_walk(st.clone(), sc.ty.clone()), move |walk_4149: crate::check::types::Ty| match walk_4149 {
                                crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::Finished(false),
                                _ => prism_rtl::Turn::Finished(crate::check::env::is_lower_text(&crate::syntax::lexer::chars::drop_prefix(&n, &crate::check::types::unify::marks_of(&n))) && (&h == &Text::lit(""))),
                            })
                        }
                    }
                })
            },
            None => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start ReadIsPrompt, x`: what the function value is when passed to `@Run`.
pub fn start_read_is_prompt(env: crate::check::expr::Env, st: crate::check::types::St, n: Text, layer: Text) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(ReadIsPrompt { env, st, n, layer })
}

/// ```prism
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
/// ```
pub fn prompt_base(env: &crate::check::expr::Env, stmts: &Array<crate::syntax::Stmt>) -> Map<Text, crate::check::shrink::Rel> {
    let pre = crate::check::shrink::relations::prelude_seeds(&env.g, &env.home);
    let seeds = fold(&keys(&pre), &pre, &(|m: &Map<Text, crate::check::shrink::Rel>, k: &Text| if crate::check::env::has_key(&env.locals, &crate::syntax::lexer::chars::drop_prefix(k, &Text::lit("pre:"))) {
        remove(m, k)
    } else {
        m.clone()
    }));
    fold(stmts, &seeds, &(|m: &Map<Text, crate::check::shrink::Rel>, s: &crate::syntax::Stmt| lam_let_rels(s, m)))
}

/// The step machine of `PromptBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
/// ```
pub struct PromptBase {
    pub env: crate::check::expr::Env,
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for PromptBase {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let env = &self.env;
        let stmts = &self.stmts;
        let pre = crate::check::shrink::relations::prelude_seeds(&env.g, &env.home);
        let seeds = fold(&keys(&pre), &pre, &(|m: &Map<Text, crate::check::shrink::Rel>, k: &Text| if crate::check::env::has_key(&env.locals, &crate::syntax::lexer::chars::drop_prefix(k, &Text::lit("pre:"))) {
            remove(m, k)
        } else {
            m.clone()
        }));
        prism_rtl::Turn::Finished(fold(stmts, &seeds, &(|m: &Map<Text, crate::check::shrink::Rel>, s: &crate::syntax::Stmt| lam_let_rels(s, m))))
    }
}

/// `Start PromptBase, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_base(env: crate::check::expr::Env, stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(PromptBase { env, stmts })
}

/// ```prism
/// LamLetRels: fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn lam_let_rels(s: &crate::syntax::Stmt, m: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    match &s.kind {
        crate::syntax::StmtKind::SLet(p_, _, e) => match ((*p_.kind).clone(), lambda_of(e)) {
            (crate::syntax::PatternKind::PName(n), Some(lam)) => insert(m, &Text::from(format!("lamlet:{}", &crate::check::env::sname_key(&n))), &crate::check::shrink::Rel { param: lam.span.start.clone(), strict: false }),
            _ => m.clone(),
        },
        _ => m.clone(),
    }
}

/// ```prism
/// ?LambdaOf: fn Expr -> ?Expr
/// ```
pub fn lambda_of(e: &crate::syntax::Expr) -> Option<crate::syntax::Expr> {
    match &*e.kind {
        crate::syntax::ExprKind::ELambda(_, _) => Some(e.clone()),
        crate::syntax::ExprKind::EGroup(x) => lambda_of(&**x),
        _ => None,
    }
}

/// ```prism
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
/// ```
pub fn let_lambdas(stmts: &Array<crate::syntax::Stmt>) -> Map<Nat, crate::syntax::Expr> {
    fold(&crate::check::shrink::walk::stmts_spots(stmts, &Map::new()), &Map::new(), &(|m: &Map<Nat, crate::syntax::Expr>, sp: &crate::check::shrink::walk::Spot| match sp {
        crate::check::shrink::walk::Spot::SpotStmt(s, _) => match &s.kind {
            crate::syntax::StmtKind::SLet(_, _, e) => match lambda_of(e) {
                Some(lam) => insert(m, &lam.span.start, &lam),
                None => m.clone(),
            },
            _ => m.clone(),
        },
        _ => m.clone(),
    }))
}

/// The step machine of `LetLambdas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
/// ```
pub struct LetLambdas {
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Map<Nat, crate::syntax::Expr>> for LetLambdas {
    fn cycle(&self) -> prism_rtl::Turn<Map<Nat, crate::syntax::Expr>> {
        let stmts = &self.stmts;
        let stmts = stmts.clone();
        call_then(crate::check::shrink::walk::start_stmts_spots(stmts.clone(), Map::new()), move |stmts_spots_5873: Array<crate::check::shrink::walk::Spot>| prism_rtl::Turn::Finished(fold(&stmts_spots_5873, &Map::new(), &(|m: &Map<Nat, crate::syntax::Expr>, sp: &crate::check::shrink::walk::Spot| match sp {
            crate::check::shrink::walk::Spot::SpotStmt(s, _) => match &s.kind {
                crate::syntax::StmtKind::SLet(_, _, e) => match lambda_of(e) {
                    Some(lam) => insert(m, &lam.span.start, &lam),
                    None => m.clone(),
                },
                _ => m.clone(),
            },
            _ => m.clone(),
        }))))
    }
}

/// `Start LetLambdas, x`: what the function value is when passed to `@Run`.
pub fn start_let_lambdas(stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Map<Nat, crate::syntax::Expr>>> {
    Rc::new(LetLambdas { stmts })
}

/// ```prism
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
/// ```
pub fn prompt_reads(cx_: &PCx, e: &crate::syntax::Expr, defs: &Array<Text>) -> Array<Text> {
    let spots = prompt_spots(cx_, e, &cx_.base);
    run_to_end(fold_job(spots.clone(), Array::new(), {
        let defs = defs.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::walk::Spot)| {
            let defs = defs.clone();
            entered(once_job(move || {
                let acc = p0;
                let sp = p1;
                call_then(crate::check::shrink::walk::start_spot_sites(sp.clone()), move |spot_sites_7222: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(fold(&spot_sites_7222, &acc, &(|a2: &Array<Text>, site: &crate::check::shrink::walk::Site| if crate::check::types::has_text(&defs, &site.callee) && !crate::check::shrink::relations::is_local(&site.rels, &site.callee) {
                    crate::check::types::add_text(a2, &site.callee)
                } else {
                    a2.clone()
                }))))
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `PromptReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
/// ```
pub struct PromptReads {
    pub cx_: PCx,
    pub e: crate::syntax::Expr,
    pub defs: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for PromptReads {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cx_ = &self.cx_;
        let e = &self.e;
        let defs = &self.defs;
        let cx_ = cx_.clone();
        let defs = defs.clone();
        let e = e.clone();
        call_then(start_prompt_spots(cx_.clone(), e.clone(), cx_.base.clone()), move |prompt_spots_7156: Array<crate::check::shrink::walk::Spot>| {
            let spots = prompt_spots_7156;
            fold_job(spots.clone(), Array::new(), {
                let defs = defs.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::walk::Spot)| {
                    let defs = defs.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let sp = p1;
                        call_then(crate::check::shrink::walk::start_spot_sites(sp.clone()), move |spot_sites_7222: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(fold(&spot_sites_7222, &acc, &(|a2: &Array<Text>, site: &crate::check::shrink::walk::Site| if crate::check::types::has_text(&defs, &site.callee) && !crate::check::shrink::relations::is_local(&site.rels, &site.callee) {
                            crate::check::types::add_text(a2, &site.callee)
                        } else {
                            a2.clone()
                        }))))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle()
        })
    }
}

/// `Start PromptReads, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_reads(cx_: PCx, e: crate::syntax::Expr, defs: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PromptReads { cx_, e, defs })
}

/// ```prism
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
/// ```
pub fn prompt_spots(cx_: &PCx, e: &crate::syntax::Expr, m: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Spot> {
    run_to_end(fold_job(prompt_kids(cx_, e, m), Array::from(vec![crate::check::shrink::walk::Spot::SpotExpr(e.clone(), m.clone())]), {
        let cx_ = cx_.clone();
        Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)| {
            let cx_ = cx_.clone();
            entered(once_job(move || {
                let acc = p0;
                let k = p1;
                prism_rtl::Turn::Finished(append(&acc, &prompt_kid_spots(&cx_, &k)))
            }))
        }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>>>
    }))
}

/// The step machine of `PromptSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
/// ```
pub struct PromptSpots {
    pub cx_: PCx,
    pub e: crate::syntax::Expr,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<crate::check::shrink::walk::Spot>> for PromptSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::shrink::walk::Spot>> {
        let cx_ = &self.cx_;
        let e = &self.e;
        let m = &self.m;
        fold_job(prompt_kids(cx_, e, m), Array::from(vec![crate::check::shrink::walk::Spot::SpotExpr(e.clone(), m.clone())]), {
            let cx_ = cx_.clone();
            Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)| {
                let cx_ = cx_.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let k = p1;
                    prism_rtl::Turn::Finished(append(&acc, &prompt_kid_spots(&cx_, &k)))
                }))
            }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>>>
        }).cycle()
    }
}

/// `Start PromptSpots, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_spots(cx_: PCx, e: crate::syntax::Expr, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>> {
    Rc::new(PromptSpots { cx_, e, m })
}

/// ```prism
/// PromptKids: unbounded fn PCx, Expr, (Text ==> Rel) -> [Kid]
/// ```
pub fn prompt_kids(cx_: &PCx, e: &crate::syntax::Expr, m: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Kid> {
    match &*e.kind {
        crate::syntax::ExprKind::ELambda(_, _) => Array::new(),
        crate::syntax::ExprKind::ERebuild(_, body) => row_kids(body, m, &Array::new()),
        crate::syntax::ExprKind::EFor(binders_opt, _, body) => row_kids(body, m, &for_binder_names(binders_opt)),
        crate::syntax::ExprKind::EWidgetBlock(_) => Array::new(),
        crate::syntax::ExprKind::ECall(c, _, _, _) => prompt_call_kids(cx_, e, &crate::check::shrink::walk::callee_name(&**c), m),
        crate::syntax::ExprKind::EMethod(_, n, _) => prompt_call_kids(cx_, e, &Some(crate::check::env::sname_key(n)), m),
        _ => crate::check::shrink::walk::expr_kids(e, m),
    }
}

/// ```prism
/// RowKids: unbounded fn Block, (Text ==> Rel), [Text] -> [Kid]
/// ```
pub fn row_kids(body: &crate::syntax::Block, m: &Map<Text, crate::check::shrink::Rel>, binders: &Array<Text>) -> Array<crate::check::shrink::walk::Kid> {
    let lines = filter(&body.stmts, &(|s: &crate::syntax::Stmt| match &s.kind {
        crate::syntax::StmtKind::SBind(_, _, Some(_)) => false,
        _ => true,
    }));
    let own = run_to_end(fold_job(body.stmts.clone(), append(binders, &Array::from(vec![Text::lit("_"), Text::lit("$_")])), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| entered(once_job(move || {
        let acc = p0;
        let s = p1;
        call_then(start_stmt_defs(s.clone()), move |stmt_defs_8893: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &stmt_defs_8893)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    Array::from(vec![crate::check::shrink::walk::Kid::KidStmts(lines.clone(), crate::check::shrink::relations::hide(m, &own))])
}

/// ```prism
/// ForBinderNames: unbounded fn ?ForBinders -> [Text]
/// ```
pub fn for_binder_names(binders_opt: &Option<crate::syntax::ForBinders>) -> Array<Text> {
    match binders_opt {
        Some(fb) => match &fb.second {
            Some(second) => append(&crate::check::env::names::pattern_names(&fb.first), &crate::check::env::names::pattern_names(second)),
            None => crate::check::env::names::pattern_names(&fb.first),
        },
        None => Array::new(),
    }
}

/// ```prism
/// PromptCallKids: unbounded fn PCx, Expr, ?Text, (Text ==> Rel) -> [Kid]
/// ```
pub fn prompt_call_kids(cx_: &PCx, e: &crate::syntax::Expr, n_opt: &Option<Text>, m: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Kid> {
    match n_opt {
        Some(n) => {
            let called = follow_lam_let(cx_, n, m);
            if crate::check::shrink::relations::is_local(m, n) {
                append(&called, &open_lambdas(cx_, &crate::check::shrink::walk::expr_kids(e, m)))
            } else {
                if &len(&called) > &Nat::from(0u32) {
                    append(&called, &open_lambdas(cx_, &crate::check::shrink::walk::expr_kids(e, m)))
                } else {
                    match crate::check::shrink::locals::resolve_callee(&cx_.g, &cx_.home, n) {
                        Some(k) => if crate::check::shrink::relations::is_prelude_key(&cx_.g, &k) && is_delayed_widget(&crate::syntax::lexer::chars::drop_prefix(&k, &Text::lit("Prelude."))) {
                            Array::new()
                        } else {
                            if crate::check::shrink::relations::is_prelude_key(&cx_.g, &k) && crate::syntax::lexer::chars::has_prefix(&k, &Text::lit("Prelude.@")) {
                                crate::check::shrink::walk::expr_kids(e, m)
                            } else {
                                open_lambdas(cx_, &crate::check::shrink::walk::expr_kids(e, m))
                            }
                        },
                        None => open_lambdas(cx_, &crate::check::shrink::walk::expr_kids(e, m)),
                    }
                }
            }
        },
        None => open_lambdas(cx_, &crate::check::shrink::walk::expr_kids(e, m)),
    }
}

/// ```prism
/// OpenLambdas: unbounded fn PCx, [Kid] -> [Kid]
/// ```
pub fn open_lambdas(cx_: &PCx, kids: &Array<crate::check::shrink::walk::Kid>) -> Array<crate::check::shrink::walk::Kid> {
    run_to_end(fold_job(kids.clone(), Array::new(), {
        let cx_ = cx_.clone();
        Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Kid>, crate::check::shrink::walk::Kid)| {
            let cx_ = cx_.clone();
            entered(once_job(move || {
                let acc = p0;
                let k = p1;
                match &k {
                    crate::check::shrink::walk::Kid::KidExpr(x, m) => match &*x.kind {
                        crate::syntax::ExprKind::ELambda(ps_opt, body) => {
                            let ps_opt = ps_opt.clone();
                            let body = (**body).clone();
                            let m = m.clone();
                            call_then(crate::check::shrink::walk::start_patterns_names(or(&ps_opt, &Array::new())), move |patterns_names_10512: Array<Text>| prism_rtl::Turn::Finished(push(&acc, &crate::check::shrink::walk::lambda_kid(&body, &crate::check::shrink::relations::hide(&m, &patterns_names_10512)))))
                        },
                        crate::syntax::ExprKind::EName(n) => prism_rtl::Turn::Finished(append(&push(&acc, &k), &follow_lam_let(&cx_, &crate::check::env::sname_key(n), m))),
                        _ => prism_rtl::Turn::Finished(push(&acc, &k)),
                    },
                    _ => prism_rtl::Turn::Finished(push(&acc, &k)),
                }
            }))
        }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Kid>, crate::check::shrink::walk::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Kid>>>>
    }))
}

/// ```prism
/// FollowLamLet: unbounded fn PCx, Text, (Text ==> Rel) -> [Kid]
/// ```
pub fn follow_lam_let(cx_: &PCx, n: &Text, m: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Kid> {
    match get(m, &Text::from(format!("lamlet:{}", n))) {
        Some(r) => if crate::check::env::has_key(m, &Text::from(format!("seen:{}", &r.param))) {
            Array::new()
        } else {
            match get(&cx_.lams, &r.param) {
                Some(lam) => match &*lam.kind {
                    crate::syntax::ExprKind::ELambda(ps_opt, body) => {
                        let seen = fold(&keys(m), &cx_.base, &(|m2: &Map<Text, crate::check::shrink::Rel>, k: &Text| if crate::syntax::lexer::chars::has_prefix(k, &Text::lit("seen:")) {
                            insert(m2, k, &crate::check::shrink::relations::no_rel())
                        } else {
                            m2.clone()
                        }));
                        Array::from(vec![crate::check::shrink::walk::lambda_kid(&**body, &crate::check::shrink::relations::hide(&insert(&seen, &Text::from(format!("seen:{}", &r.param)), &crate::check::shrink::relations::no_rel()), &crate::check::shrink::walk::patterns_names(&or(ps_opt, &Array::new()))))])
                    },
                    _ => Array::new(),
                },
                None => Array::new(),
            }
        },
        None => Array::new(),
    }
}

/// ```prism
/// PromptKidSpots: unbounded fn PCx, Kid -> [Spot]
/// ```
pub fn prompt_kid_spots(cx_: &PCx, k: &crate::check::shrink::walk::Kid) -> Array<crate::check::shrink::walk::Spot> {
    match k {
        crate::check::shrink::walk::Kid::KidExpr(x, m) => prompt_spots(cx_, x, m),
        crate::check::shrink::walk::Kid::KidStmts(ss, m) => {
            let bm = crate::check::shrink::relations::block_rels(ss, m);
            run_to_end(fold_job(ss.clone(), Array::new(), {
                let cx_ = cx_.clone();
                let bm = bm.clone();
                Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Spot>, crate::syntax::Stmt)| {
                    let cx_ = cx_.clone();
                    let bm = bm.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let s = p1;
                        prism_rtl::Turn::Finished(append(&acc, &prompt_stmt_spots(&cx_, &s, &bm)))
                    }))
                }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Spot>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>>>
            }))
        },
    }
}

/// ```prism
/// PromptStmtSpots: unbounded fn PCx, Stmt, (Text ==> Rel) -> [Spot]
/// ```
pub fn prompt_stmt_spots(cx_: &PCx, s: &crate::syntax::Stmt, m: &Map<Text, crate::check::shrink::Rel>) -> Array<crate::check::shrink::walk::Spot> {
    match &s.kind {
        crate::syntax::StmtKind::SFn(_) => Array::from(vec![crate::check::shrink::walk::Spot::SpotStmt(s.clone(), m.clone())]),
        crate::syntax::StmtKind::SWidget(_) => Array::from(vec![crate::check::shrink::walk::Spot::SpotStmt(s.clone(), m.clone())]),
        _ => run_to_end(fold_job(crate::check::shrink::walk::stmt_kids(s, m), Array::from(vec![crate::check::shrink::walk::Spot::SpotStmt(s.clone(), m.clone())]), {
            let cx_ = cx_.clone();
            Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)| {
                let cx_ = cx_.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let k = p1;
                    prism_rtl::Turn::Finished(append(&acc, &prompt_kid_spots(&cx_, &k)))
                }))
            }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Spot>>>>
        })),
    }
}

/// ```prism
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
/// ```
pub fn find_cycle(defs: &Array<Text>, edges_: &Array<(Text, Text)>) -> Array<Text> {
    run_to_end(fold_job(defs.clone(), Array::new(), {
        let defs = defs.clone();
        let edges_ = edges_.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
            let defs = defs.clone();
            let edges_ = edges_.clone();
            entered(once_job(move || {
                let found = p0;
                let d = p1;
                if &len(&found) > &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(found.clone())
                } else {
                    prism_rtl::Turn::More(Rc::new(CycleThrough { defs: defs.clone(), edges_: edges_.clone(), d: d.clone() }))
                }
            }))
        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `FindCycle`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
/// ```
pub struct FindCycle {
    pub defs: Array<Text>,
    pub edges_: Array<(Text, Text)>,
}

impl prism_rtl::Job<Array<Text>> for FindCycle {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let defs = &self.defs;
        let edges_ = &self.edges_;
        fold_job(defs.clone(), Array::new(), {
            let defs = defs.clone();
            let edges_ = edges_.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                let defs = defs.clone();
                let edges_ = edges_.clone();
                entered(once_job(move || {
                    let found = p0;
                    let d = p1;
                    if &len(&found) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(found.clone())
                    } else {
                        prism_rtl::Turn::More(Rc::new(CycleThrough { defs: defs.clone(), edges_: edges_.clone(), d: d.clone() }))
                    }
                }))
            }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start FindCycle, x`: what the function value is when passed to `@Run`.
pub fn start_find_cycle(defs: Array<Text>, edges_: Array<(Text, Text)>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(FindCycle { defs, edges_ })
}

/// ```prism
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
/// ```
pub fn cycle_through(defs: &Array<Text>, edges_: &Array<(Text, Text)>, d: &Text) -> Array<Text> {
    let fwd = reach_from(edges_, d);
    if crate::check::types::has_text(&fwd, d) {
        run_to_end(filter_job(defs.clone(), {
            let fwd = fwd.clone();
            let edges_ = edges_.clone();
            let d = d.clone();
            Rc::new(move |p0: Text| {
                let fwd = fwd.clone();
                let edges_ = edges_.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let x = p0;
                    prism_rtl::Turn::Finished(crate::check::types::has_text(&fwd, &x) && crate::check::types::has_text(&reach_from(&edges_, &x), &d))
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
        }))
    } else {
        Array::new()
    }
}

/// The step machine of `CycleThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
/// ```
pub struct CycleThrough {
    pub defs: Array<Text>,
    pub edges_: Array<(Text, Text)>,
    pub d: Text,
}

impl prism_rtl::Job<Array<Text>> for CycleThrough {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let defs = &self.defs;
        let edges_ = &self.edges_;
        let d = &self.d;
        let d = d.clone();
        let defs = defs.clone();
        let edges_ = edges_.clone();
        call_then(start_reach_from(edges_.clone(), d.clone()), move |reach_from_12532: Array<Text>| {
            let fwd = reach_from_12532;
            if crate::check::types::has_text(&fwd, &d) {
                filter_job(defs.clone(), {
                    let fwd = fwd.clone();
                    let edges_ = edges_.clone();
                    let d = d.clone();
                    Rc::new(move |p0: Text| {
                        let fwd = fwd.clone();
                        let edges_ = edges_.clone();
                        let d = d.clone();
                        entered(once_job(move || {
                            let x = p0;
                            prism_rtl::Turn::Finished(crate::check::types::has_text(&fwd, &x) && crate::check::types::has_text(&reach_from(&edges_, &x), &d))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle()
            } else {
                prism_rtl::Turn::Finished(Array::new())
            }
        })
    }
}

/// `Start CycleThrough, x`: what the function value is when passed to `@Run`.
pub fn start_cycle_through(defs: Array<Text>, edges_: Array<(Text, Text)>, d: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CycleThrough { defs, edges_, d })
}

/// ```prism
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
/// ```
pub fn reach_from(edges_: &Array<(Text, Text)>, d: &Text) -> Array<Text> {
    reach(edges_, &each(&filter(edges_, &(|(f, _): &(Text, Text)| f == d)), &(|(_, t): &(Text, Text)| t.clone())), &Array::new())
}

/// The step machine of `ReachFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
/// ```
pub struct ReachFrom {
    pub edges_: Array<(Text, Text)>,
    pub d: Text,
}

impl prism_rtl::Job<Array<Text>> for ReachFrom {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let edges_ = &self.edges_;
        let d = &self.d;
        prism_rtl::Turn::Finished(reach(edges_, &each(&filter(edges_, &(|(f, _): &(Text, Text)| f == d)), &(|(_, t): &(Text, Text)| t.clone())), &Array::new()))
    }
}

/// `Start ReachFrom, x`: what the function value is when passed to `@Run`.
pub fn start_reach_from(edges_: Array<(Text, Text)>, d: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReachFrom { edges_, d })
}

/// ```prism
/// Reach: unbounded fn [((Text, Text))], [Text], [Text] -> [Text]
/// ```
pub fn reach(edges_: &Array<(Text, Text)>, frontier: &Array<Text>, seen: &Array<Text>) -> Array<Text> {
    match index(frontier, &Nat::from(0u32)) {
        None => seen.clone(),
        Some(x) => if crate::check::types::has_text(seen, &x) {
            reach(edges_, &drop(frontier, &Nat::from(1u32)), seen)
        } else {
            reach(edges_, &append(&drop(frontier, &Nat::from(1u32)), &each(&filter(edges_, &(|(f, _): &(Text, Text)| f == &x)), &(|(_, t): &(Text, Text)| t.clone()))), &push(seen, &x))
        },
    }
}
