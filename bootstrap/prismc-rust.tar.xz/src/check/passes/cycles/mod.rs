//! The module `Check.Passes.Cycles`, from `target/bootstrap/src/prismc/check/passes/cycles.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `PCx`:
///
/// ```prism
/// type PCx = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct PCx {
    pub g_p: crate::check::env::G,
    pub home_p: crate::prelude::Text,
    pub lams_p: crate::prelude::Map<crate::prelude::Nat, crate::syntax::Expr>,
    pub base_p: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub path_p: crate::prelude::Array<crate::prelude::Text>,
    pub reach_p: bool,
    pub supplied_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>,
    pub names_p: crate::prelude::Array<crate::prelude::Text>,
}

impl crate::prelude::Show for PCx {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("PCx", &[("g", &self.g_p), ("home", &self.home_p), ("lams", &self.lams_p), ("base", &self.base_p), ("path", &self.path_p), ("reach", &self.reach_p), ("supplied", &self.supplied_p), ("names", &self.names_p)]);
    }
}

impl crate::prelude::ToPod for PCx {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("PCx", vec![("g", self.g_p.to_pod()), ("home", self.home_p.to_pod()), ("lams", self.lams_p.to_pod()), ("base", self.base_p.to_pod()), ("path", self.path_p.to_pod()), ("reach", self.reach_p.to_pod()), ("supplied", self.supplied_p.to_pod()), ("names", self.names_p.to_pod())])
    }
}

impl crate::prelude::FromPod for PCx {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(PCx { g_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "g")?)?, home_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "home")?)?, lams_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lams")?)?, base_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "base")?)?, path_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "path")?)?, reach_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "reach")?)?, supplied_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "supplied")?)?, names_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "names")?)? })
    }
}

/// ```prism
/// IsDelayedWidget: fn Text -> Bool
/// ```
pub fn is_delayed_widget_f(n_p0: &crate::prelude::Text) -> bool {
    crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("@Defer"), crate::prelude::Text::lit("@Later"), crate::prelude::Text::lit("@Run"), crate::prelude::Text::lit("@Machine"), crate::prelude::Text::lit("@started")]), n_p0)
}

/// ```prism
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
/// ```
pub fn block_prompt_cycles_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block) -> crate::check::types::St {
    let defs_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(b_p2.stmts_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p6 = p0;
        let s_p7 = p1;
        crate::prelude::call_then(start_stmt_defs_f(s_p7.clone()), move |stmt_defs_f_2204: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &stmt_defs_f_2204)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
    let cx_p4 = PCx { g_p: env_p0.g_p.clone(), home_p: env_p0.home_p.clone(), lams_p: let_lambdas_f(&b_p2.stmts_p), base_p: prompt_base_f(env_p0, &b_p2.stmts_p), path_p: crate::prelude::Array::new(), reach_p: false, supplied_p: crate::prelude::Map::new(), names_p: crate::prelude::keys(&env_p0.locals_p) };
    let cyc_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(parameter_uses_f(&cx_p4, env_p0, b_p2), crate::prelude::Array::new(), {
        let cx_p4x = cx_p4.clone();
        let defs_p3x = defs_p3.clone();
        let b_p2x = b_p2.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>)| {
            let cx_p4xy = cx_p4x.clone();
            let defs_p3xy = defs_p3x.clone();
            let b_p2xy = b_p2x.clone();
            let env_p0xy = env_p0x.clone();
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let found_p8 = p0;
                let supplied_p9 = p1;
                if &crate::prelude::len(&found_p8) > &crate::prelude::Nat::from(0u32) {
                    ::prism_rtl::Turn::Finished(found_p8.clone())
                } else {
                    {
                        let cxu_pa = {
                            let mut this: PCx = cx_p4xy.clone();
                            this.supplied_p = supplied_p9.clone();
                            this
                        };
                        crate::prelude::call_value(crate::prelude::fold_job(b_p2xy.stmts_p.clone(), crate::prelude::Array::new(), {
                            let env_p0xyx = env_p0xy.clone();
                            let st_p1xyx = st_p1xy.clone();
                            let cxu_pax = cxu_pa.clone();
                            let defs_p3xyx = defs_p3xy.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::syntax::Stmt)| {
                                let env_p0xyxy = env_p0xyx.clone();
                                let st_p1xyxy = st_p1xyx.clone();
                                let cxu_paxy = cxu_pax.clone();
                                let defs_p3xyxy = defs_p3xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_pb = p0;
                                    let s_pc = p1;
                                    crate::prelude::call_then(start_prompt_edges_f(env_p0xyxy.clone(), st_p1xyxy.clone(), cxu_paxy.clone(), s_pc.clone(), defs_p3xyxy.clone()), move |prompt_edges_f_2884: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pb, &prompt_edges_f_2884)))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>>>>
                        }), move |fold_2841: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>| ::prism_rtl::Turn::More(::std::rc::Rc::new(FindCycle { defs_p0: defs_p3xy.clone(), edges_p1: fold_2841 })))
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }));
    if &crate::prelude::len(&cyc_p5) == &crate::prelude::Nat::from(0u32) {
        st_p1.clone()
    } else {
        {
            let span_pd = crate::prelude::run_to_end(crate::prelude::fold_job(b_p2.stmts_p.clone(), b_p2.span_p.clone(), {
                let cyc_p5x = cyc_p5.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::syntax::Range, crate::syntax::Stmt)| {
                    let cyc_p5xy = cyc_p5x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let sp_pe = p0;
                        let s_pf = p1;
                        crate::prelude::call_then(start_stmt_defs_f(s_pf.clone()), move |stmt_defs_f_3018: crate::prelude::Array<crate::prelude::Text>| if crate::check::types::has_text_f(&stmt_defs_f_3018, &crate::prelude::or(&crate::prelude::index(&cyc_p5xy, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""))) {
                            ::prism_rtl::Turn::Finished(s_pf.span_p.clone())
                        } else {
                            ::prism_rtl::Turn::Finished(sp_pe.clone())
                        })
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::syntax::Range, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::Range>>>
            }));
            crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("prompt-cycle"), &span_pd, &crate::prelude::Text::from(format!("a prompt cycle: {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&cyc_p5, &(|n_pg: &crate::prelude::Text| crate::prelude::Text::from(format!("`{}`", n_pg)))), &crate::prelude::Text::lit(", ")))), &crate::prelude::Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened"))
        }
    }
}

/// The step machine of `BlockPromptCycles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
/// ```
pub struct BlockPromptCycles {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
}

impl ::prism_rtl::Job<crate::check::types::St> for BlockPromptCycles {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        let b_p2x = b_p2.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(b_p2x.stmts_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p6 = p0;
            let s_p7 = p1;
            crate::prelude::call_then(start_stmt_defs_f(s_p7.clone()), move |stmt_defs_f_2204: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &stmt_defs_f_2204)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_2161: crate::prelude::Array<crate::prelude::Text>| {
            let defs_p3 = fold_2161;
            crate::prelude::call_then(start_let_lambdas_f(b_p2x.stmts_p.clone()), move |let_lambdas_f_2263: crate::prelude::Map<crate::prelude::Nat, crate::syntax::Expr>| crate::prelude::call_then(start_prompt_base_f(env_p0x.clone(), b_p2x.stmts_p.clone()), move |prompt_base_f_2290: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                let cx_p4 = PCx { g_p: env_p0x.g_p.clone(), home_p: env_p0x.home_p.clone(), lams_p: let_lambdas_f_2263, base_p: prompt_base_f_2290, path_p: crate::prelude::Array::new(), reach_p: false, supplied_p: crate::prelude::Map::new(), names_p: crate::prelude::keys(&env_p0x.locals_p) };
                crate::prelude::call_then(start_parameter_uses_f(cx_p4.clone(), env_p0x.clone(), b_p2x.clone()), move |parameter_uses_f_2639: crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>| crate::prelude::call_value(crate::prelude::fold_job(parameter_uses_f_2639, crate::prelude::Array::new(), {
                    let cx_p4x = cx_p4.clone();
                    let defs_p3x = defs_p3.clone();
                    let b_p2xx = b_p2x.clone();
                    let env_p0xx = env_p0x.clone();
                    let st_p1xx = st_p1x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>)| {
                        let cx_p4xy = cx_p4x.clone();
                        let defs_p3xy = defs_p3x.clone();
                        let b_p2xxy = b_p2xx.clone();
                        let env_p0xxy = env_p0xx.clone();
                        let st_p1xxy = st_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let found_p8 = p0;
                            let supplied_p9 = p1;
                            if &crate::prelude::len(&found_p8) > &crate::prelude::Nat::from(0u32) {
                                ::prism_rtl::Turn::Finished(found_p8.clone())
                            } else {
                                {
                                    let cxu_pa = {
                                        let mut this: PCx = cx_p4xy.clone();
                                        this.supplied_p = supplied_p9.clone();
                                        this
                                    };
                                    crate::prelude::call_value(crate::prelude::fold_job(b_p2xxy.stmts_p.clone(), crate::prelude::Array::new(), {
                                        let env_p0xxyx = env_p0xxy.clone();
                                        let st_p1xxyx = st_p1xxy.clone();
                                        let cxu_pax = cxu_pa.clone();
                                        let defs_p3xyx = defs_p3xy.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::syntax::Stmt)| {
                                            let env_p0xxyxy = env_p0xxyx.clone();
                                            let st_p1xxyxy = st_p1xxyx.clone();
                                            let cxu_paxy = cxu_pax.clone();
                                            let defs_p3xyxy = defs_p3xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let acc_pb = p0;
                                                let s_pc = p1;
                                                crate::prelude::call_then(start_prompt_edges_f(env_p0xxyxy.clone(), st_p1xxyxy.clone(), cxu_paxy.clone(), s_pc.clone(), defs_p3xyxy.clone()), move |prompt_edges_f_2884: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pb, &prompt_edges_f_2884)))
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>>>>
                                    }), move |fold_2841: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>| ::prism_rtl::Turn::More(::std::rc::Rc::new(FindCycle { defs_p0: defs_p3xy.clone(), edges_p1: fold_2841 })))
                                }
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }), move |fold_2633: crate::prelude::Array<crate::prelude::Text>| {
                    let cyc_p5 = fold_2633;
                    if &crate::prelude::len(&cyc_p5) == &crate::prelude::Nat::from(0u32) {
                        ::prism_rtl::Turn::Finished(st_p1x.clone())
                    } else {
                        crate::prelude::call_value(crate::prelude::fold_job(b_p2x.stmts_p.clone(), b_p2x.span_p.clone(), {
                            let cyc_p5x = cyc_p5.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::syntax::Range, crate::syntax::Stmt)| {
                                let cyc_p5xy = cyc_p5x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let sp_pe = p0;
                                    let s_pf = p1;
                                    crate::prelude::call_then(start_stmt_defs_f(s_pf.clone()), move |stmt_defs_f_3018: crate::prelude::Array<crate::prelude::Text>| if crate::check::types::has_text_f(&stmt_defs_f_3018, &crate::prelude::or(&crate::prelude::index(&cyc_p5xy, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""))) {
                                        ::prism_rtl::Turn::Finished(s_pf.span_p.clone())
                                    } else {
                                        ::prism_rtl::Turn::Finished(sp_pe.clone())
                                    })
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::syntax::Range, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::Range>>>
                        }), move |fold_2975: crate::syntax::Range| {
                            let span_pd = fold_2975;
                            ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("prompt-cycle"), &span_pd, &crate::prelude::Text::from(format!("a prompt cycle: {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&cyc_p5, &(|n_pg: &crate::prelude::Text| crate::prelude::Text::from(format!("`{}`", n_pg)))), &crate::prelude::Text::lit(", ")))), &crate::prelude::Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened")))
                        })
                    }
                }))
            }))
        })
    }
}

/// `Start BlockPromptCycles, x`: what the function value is when passed to `@Run`.
pub fn start_block_prompt_cycles_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(BlockPromptCycles { env_p0, st_p1, b_p2 })
}

/// ```prism
/// StmtDefs: unbounded fn Stmt -> [Text]
/// ```
pub fn stmt_defs_f(s_p0: &crate::syntax::Stmt) -> crate::prelude::Array<crate::prelude::Text> {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SBind(p_p1, _, _) => crate::check::env::names::pattern_names_f(p_p1),
        crate::syntax::StmtKind::SLet(p_p2, _, _) => crate::check::env::names::pattern_names_f(p_p2),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `StmtDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtDefs: unbounded fn Stmt -> [Text]
/// ```
pub struct StmtDefs {
    pub s_p0: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for StmtDefs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let s_p0 = &self.s_p0;
        match &s_p0.kind_p {
            crate::syntax::StmtKind::SBind(p_p1, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::names::PatternNames { p_p0: p_p1.clone() })),
            crate::syntax::StmtKind::SLet(p_p2, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::names::PatternNames { p_p0: p_p2.clone() })),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start StmtDefs, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_defs_f(s_p0: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(StmtDefs { s_p0 })
}

/// ```prism
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
/// ```
pub fn prompt_edges_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, cx_p2: &PCx, s_p3: &crate::syntax::Stmt, defs_p4: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)> {
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SBind(_, _, ::std::option::Option::Some(_)) => crate::prelude::Array::new(),
        crate::syntax::StmtKind::SBind(p_p5, e_p6, ::std::option::Option::None) => edges_f(&crate::check::env::names::pattern_names_f(p_p5), &prompt_reads_f(cx_p2, e_p6, defs_p4)),
        crate::syntax::StmtKind::SLet(p_p7, _, e_p8) => {
            let names_p9 = crate::check::env::names::pattern_names_f(p_p7);
            let layer_pa = crate::prelude::run_to_end(crate::prelude::fold_job(names_p9.clone(), crate::prelude::Text::lit(""), {
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Text, crate::prelude::Text)| {
                    let env_p0xy = env_p0x.clone();
                    let st_p1xy = st_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pb = p0;
                        let n_pc = p1;
                        match crate::prelude::get(&env_p0xy.locals_p, &n_pc) {
                            ::std::option::Option::Some(sc_pd) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::HeadSigil { st_p0: st_p1xy.clone(), t_p1: sc_pd.ty_p.clone() })),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_pb.clone()),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }));
            edges_f(&names_p9, &crate::prelude::run_to_end(crate::prelude::filter_job(prompt_reads_f(cx_p2, e_p8, defs_p4), {
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let layer_pax = layer_pa.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                    let env_p0xy = env_p0x.clone();
                    let st_p1xy = st_p1x.clone();
                    let layer_paxy = layer_pax.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let n_pe = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadIsPrompt { env_p0: env_p0xy.clone(), st_p1: st_p1xy.clone(), n_p2: n_pe.clone(), layer_p3: layer_paxy.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            })))
        },
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `PromptEdges`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
/// ```
pub struct PromptEdges {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub cx_p2: PCx,
    pub s_p3: crate::syntax::Stmt,
    pub defs_p4: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>> for PromptEdges {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let cx_p2 = &self.cx_p2;
        let s_p3 = &self.s_p3;
        let defs_p4 = &self.defs_p4;
        match &s_p3.kind_p {
            crate::syntax::StmtKind::SBind(_, _, ::std::option::Option::Some(_)) => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
            crate::syntax::StmtKind::SBind(p_p5, e_p6, ::std::option::Option::None) => {
                let cx_p2x = cx_p2.clone();
                let defs_p4x = defs_p4.clone();
                let e_p6x = e_p6.clone();
                let p_p5x = p_p5.clone();
                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p5x.clone()), move |pattern_names_f_3742: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_prompt_reads_f(cx_p2x.clone(), e_p6x.clone(), defs_p4x.clone()), move |prompt_reads_f_3760: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(edges_f(&pattern_names_f_3742, &prompt_reads_f_3760))))
            },
            crate::syntax::StmtKind::SLet(p_p7, _, e_p8) => {
                let cx_p2x = cx_p2.clone();
                let defs_p4x = defs_p4.clone();
                let e_p8x = e_p8.clone();
                let env_p0x = env_p0.clone();
                let p_p7x = p_p7.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p7x.clone()), move |pattern_names_f_3828: crate::prelude::Array<crate::prelude::Text>| {
                    let names_p9 = pattern_names_f_3828;
                    crate::prelude::call_value(crate::prelude::fold_job(names_p9.clone(), crate::prelude::Text::lit(""), {
                        let env_p0xx = env_p0x.clone();
                        let st_p1xx = st_p1x.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Text, crate::prelude::Text)| {
                            let env_p0xxy = env_p0xx.clone();
                            let st_p1xxy = st_p1xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_pb = p0;
                                let n_pc = p1;
                                match crate::prelude::get(&env_p0xxy.locals_p, &n_pc) {
                                    ::std::option::Option::Some(sc_pd) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::HeadSigil { st_p0: st_p1xxy.clone(), t_p1: sc_pd.ty_p.clone() })),
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_pb.clone()),
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                    }), move |fold_3863: crate::prelude::Text| {
                        let layer_pa = fold_3863;
                        crate::prelude::call_then(start_prompt_reads_f(cx_p2x.clone(), e_p8x.clone(), defs_p4x.clone()), move |prompt_reads_f_3999: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_value(crate::prelude::filter_job(prompt_reads_f_3999, {
                            let env_p0xx = env_p0x.clone();
                            let st_p1xx = st_p1x.clone();
                            let layer_pax = layer_pa.clone();
                            ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                                let env_p0xxy = env_p0xx.clone();
                                let st_p1xxy = st_p1xx.clone();
                                let layer_paxy = layer_pax.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let n_pe = p0;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadIsPrompt { env_p0: env_p0xxy.clone(), st_p1: st_p1xxy.clone(), n_p2: n_pe.clone(), layer_p3: layer_paxy.clone() }))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                        }), move |filter_3991: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(edges_f(&names_p9, &filter_3991))))
                    })
                })
            },
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start PromptEdges, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_edges_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, cx_p2: PCx, s_p3: crate::syntax::Stmt, defs_p4: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>>> {
    ::std::rc::Rc::new(PromptEdges { env_p0, st_p1, cx_p2, s_p3, defs_p4 })
}

/// ```prism
/// Edges: fn [Text], [Text] -> [((Text, Text))]
/// ```
pub fn edges_f(froms_p0: &crate::prelude::Array<crate::prelude::Text>, tos_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)> {
    crate::prelude::fold(froms_p0, &crate::prelude::Array::new(), &(|acc_p2: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, f_p3: &crate::prelude::Text| crate::prelude::append(acc_p2, &crate::prelude::each(tos_p1, &(|t_p4: &crate::prelude::Text| (f_p3.clone(), t_p4.clone()))))))
}

/// ```prism
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
/// ```
pub fn read_is_prompt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, n_p2: &crate::prelude::Text, layer_p3: &crate::prelude::Text) -> bool {
    match crate::prelude::get(&env_p0.locals_p, n_p2) {
        ::std::option::Option::Some(sc_p4) => {
            let h_p5 = crate::check::types::head_sigil_f(st_p1, &sc_p4.ty_p);
            if layer_p3 == &crate::prelude::Text::lit("!") {
                (&h_p5 == &crate::prelude::Text::lit("!")) || (&h_p5 == &crate::prelude::Text::lit("@"))
            } else {
                if layer_p3 == &crate::prelude::Text::lit("$") {
                    (&h_p5 == &crate::prelude::Text::lit("$")) || (&h_p5 == &crate::prelude::Text::lit("!"))
                } else {
                    match crate::check::types::recording::walk_f(st_p1, &sc_p4.ty_p) {
                        crate::check::types::Ty::TyFn(_, _, _) => false,
                        _ => crate::check::env::is_lower_text_f(&crate::syntax::lexer::chars::drop_prefix_f(n_p2, &crate::check::types::unify::marks_of_f(n_p2))) && (&h_p5 == &crate::prelude::Text::lit("")),
                    }
                }
            }
        },
        ::std::option::Option::None => false,
    }
}

/// The step machine of `ReadIsPrompt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
/// ```
pub struct ReadIsPrompt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::prelude::Text,
    pub layer_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<bool> for ReadIsPrompt {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let layer_p3 = &self.layer_p3;
        match crate::prelude::get(&env_p0.locals_p, n_p2) {
            ::std::option::Option::Some(sc_p4) => {
                let layer_p3x = layer_p3.clone();
                let n_p2x = n_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), sc_p4.ty_p.clone()), move |head_sigil_f_4486: crate::prelude::Text| {
                    let h_p5 = head_sigil_f_4486;
                    if &layer_p3x == &crate::prelude::Text::lit("!") {
                        ::prism_rtl::Turn::Finished((&h_p5 == &crate::prelude::Text::lit("!")) || (&h_p5 == &crate::prelude::Text::lit("@")))
                    } else {
                        if &layer_p3x == &crate::prelude::Text::lit("$") {
                            ::prism_rtl::Turn::Finished((&h_p5 == &crate::prelude::Text::lit("$")) || (&h_p5 == &crate::prelude::Text::lit("!")))
                        } else {
                            crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), sc_p4.ty_p.clone()), move |walk_f_4624: crate::check::types::Ty| match walk_f_4624 {
                                crate::check::types::Ty::TyFn(_, _, _) => ::prism_rtl::Turn::Finished(false),
                                _ => ::prism_rtl::Turn::Finished(crate::check::env::is_lower_text_f(&crate::syntax::lexer::chars::drop_prefix_f(&n_p2x, &crate::check::types::unify::marks_of_f(&n_p2x))) && (&h_p5 == &crate::prelude::Text::lit(""))),
                            })
                        }
                    }
                })
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start ReadIsPrompt, x`: what the function value is when passed to `@Run`.
pub fn start_read_is_prompt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, n_p2: crate::prelude::Text, layer_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(ReadIsPrompt { env_p0, st_p1, n_p2, layer_p3 })
}

/// ```prism
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
/// ```
pub fn prompt_base_f(env_p0: &crate::check::expr::Env, stmts_p1: &crate::prelude::Array<crate::syntax::Stmt>) -> crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel> {
    let pre_p2 = crate::check::shrink::relations::prelude_seeds_f(&env_p0.g_p, &env_p0.home_p);
    let seeds_p3 = crate::prelude::fold(&crate::prelude::keys(&pre_p2), &pre_p2, &(|m_p4: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, k_p5: &crate::prelude::Text| if crate::check::env::has_key_f(&env_p0.locals_p, &crate::syntax::lexer::chars::drop_prefix_f(k_p5, &crate::prelude::Text::lit("pre:"))) {
        crate::prelude::remove(m_p4, k_p5)
    } else {
        m_p4.clone()
    }));
    crate::prelude::fold(stmts_p1, &seeds_p3, &(|m_p6: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, s_p7: &crate::syntax::Stmt| lam_let_rels_f(s_p7, m_p6)))
}

/// The step machine of `PromptBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
/// ```
pub struct PromptBase {
    pub env_p0: crate::check::expr::Env,
    pub stmts_p1: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>> for PromptBase {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>> {
        let env_p0 = &self.env_p0;
        let stmts_p1 = &self.stmts_p1;
        let pre_p2 = crate::check::shrink::relations::prelude_seeds_f(&env_p0.g_p, &env_p0.home_p);
        let seeds_p3 = crate::prelude::fold(&crate::prelude::keys(&pre_p2), &pre_p2, &(|m_p4: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, k_p5: &crate::prelude::Text| if crate::check::env::has_key_f(&env_p0.locals_p, &crate::syntax::lexer::chars::drop_prefix_f(k_p5, &crate::prelude::Text::lit("pre:"))) {
            crate::prelude::remove(m_p4, k_p5)
        } else {
            m_p4.clone()
        }));
        ::prism_rtl::Turn::Finished(crate::prelude::fold(stmts_p1, &seeds_p3, &(|m_p6: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, s_p7: &crate::syntax::Stmt| lam_let_rels_f(s_p7, m_p6))))
    }
}

/// `Start PromptBase, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_base_f(env_p0: crate::check::expr::Env, stmts_p1: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>> {
    ::std::rc::Rc::new(PromptBase { env_p0, stmts_p1 })
}

/// ```prism
/// LamLetRels: fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn lam_let_rels_f(s_p0: &crate::syntax::Stmt, m_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel> {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SLet(p_p2, _, e_p3) => match ((*p_p2.kind_p).clone(), lambda_of_o(e_p3)) {
            (crate::syntax::PatternKind::PName(n_p4), ::std::option::Option::Some(lam_p5)) => crate::prelude::insert(m_p1, &crate::prelude::Text::from(format!("lamlet:{}", &crate::check::env::sname_key_f(&n_p4))), &crate::check::shrink::Rel { param_p: lam_p5.span_p.start_p.clone(), strict_p: false }),
            _ => m_p1.clone(),
        },
        _ => m_p1.clone(),
    }
}

/// ```prism
/// ?LambdaOf: fn Expr -> ?Expr
/// ```
pub fn lambda_of_o(e_p0: &crate::syntax::Expr) -> ::std::option::Option<crate::syntax::Expr> {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ELambda(_, _) => ::std::option::Option::Some(e_p0.clone()),
        crate::syntax::ExprKind::EGroup(x_p1) => lambda_of_o(&**x_p1),
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
/// ```
pub fn let_lambdas_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>) -> crate::prelude::Map<crate::prelude::Nat, crate::syntax::Expr> {
    crate::prelude::fold(&crate::check::shrink::walk::stmts_spots_f(stmts_p0, &crate::prelude::Map::new()), &crate::prelude::Map::new(), &(|m_p1: &crate::prelude::Map<crate::prelude::Nat, crate::syntax::Expr>, sp_p2: &crate::check::shrink::walk::Spot| match sp_p2 {
        crate::check::shrink::walk::Spot::SpotStmt(s_p3, _) => match &s_p3.kind_p {
            crate::syntax::StmtKind::SLet(_, _, e_p4) => match lambda_of_o(e_p4) {
                ::std::option::Option::Some(lam_p5) => crate::prelude::insert(m_p1, &lam_p5.span_p.start_p, &lam_p5),
                ::std::option::Option::None => m_p1.clone(),
            },
            _ => m_p1.clone(),
        },
        _ => m_p1.clone(),
    }))
}

/// The step machine of `LetLambdas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
/// ```
pub struct LetLambdas {
    pub stmts_p0: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Nat, crate::syntax::Expr>> for LetLambdas {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Nat, crate::syntax::Expr>> {
        let stmts_p0 = &self.stmts_p0;
        let stmts_p0x = stmts_p0.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_stmts_spots_f(stmts_p0x.clone(), crate::prelude::Map::new()), move |stmts_spots_f_6923: crate::prelude::Array<crate::check::shrink::walk::Spot>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&stmts_spots_f_6923, &crate::prelude::Map::new(), &(|m_p1: &crate::prelude::Map<crate::prelude::Nat, crate::syntax::Expr>, sp_p2: &crate::check::shrink::walk::Spot| match sp_p2 {
            crate::check::shrink::walk::Spot::SpotStmt(s_p3, _) => match &s_p3.kind_p {
                crate::syntax::StmtKind::SLet(_, _, e_p4) => match lambda_of_o(e_p4) {
                    ::std::option::Option::Some(lam_p5) => crate::prelude::insert(m_p1, &lam_p5.span_p.start_p, &lam_p5),
                    ::std::option::Option::None => m_p1.clone(),
                },
                _ => m_p1.clone(),
            },
            _ => m_p1.clone(),
        }))))
    }
}

/// `Start LetLambdas, x`: what the function value is when passed to `@Run`.
pub fn start_let_lambdas_f(stmts_p0: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Nat, crate::syntax::Expr>>> {
    ::std::rc::Rc::new(LetLambdas { stmts_p0 })
}

/// ```prism
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
/// ```
pub fn prompt_reads_f(cx_p0: &PCx, e_p1: &crate::syntax::Expr, defs_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    let spots_p3 = prompt_spots_f(cx_p0, e_p1, &cx_p0.base_p);
    crate::prelude::run_to_end(crate::prelude::fold_job(spots_p3.clone(), crate::prelude::Array::new(), {
        let defs_p2x = defs_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::shrink::walk::Spot)| {
            let defs_p2xy = defs_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p4 = p0;
                let sp_p5 = p1;
                crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5.clone()), move |spot_sites_f_8294: crate::prelude::Array<crate::check::shrink::walk::Site>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&spot_sites_f_8294, &acc_p4, &(|a2_p6: &crate::prelude::Array<crate::prelude::Text>, site_p7: &crate::check::shrink::walk::Site| if crate::check::types::has_text_f(&defs_p2xy, &site_p7.callee_p) && !crate::check::shrink::relations::is_local_f(&site_p7.rels_p, &site_p7.callee_p) {
                    crate::check::types::add_text_f(a2_p6, &site_p7.callee_p)
                } else {
                    a2_p6.clone()
                }))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }))
}

/// The step machine of `PromptReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
/// ```
pub struct PromptReads {
    pub cx_p0: PCx,
    pub e_p1: crate::syntax::Expr,
    pub defs_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for PromptReads {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let cx_p0 = &self.cx_p0;
        let e_p1 = &self.e_p1;
        let defs_p2 = &self.defs_p2;
        let spots_p3 = prompt_spots_f(cx_p0, e_p1, &cx_p0.base_p);
        crate::prelude::fold_job(spots_p3.clone(), crate::prelude::Array::new(), {
            let defs_p2x = defs_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::shrink::walk::Spot)| {
                let defs_p2xy = defs_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p4 = p0;
                    let sp_p5 = p1;
                    crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5.clone()), move |spot_sites_f_8294: crate::prelude::Array<crate::check::shrink::walk::Site>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&spot_sites_f_8294, &acc_p4, &(|a2_p6: &crate::prelude::Array<crate::prelude::Text>, site_p7: &crate::check::shrink::walk::Site| if crate::check::types::has_text_f(&defs_p2xy, &site_p7.callee_p) && !crate::check::shrink::relations::is_local_f(&site_p7.rels_p, &site_p7.callee_p) {
                        crate::check::types::add_text_f(a2_p6, &site_p7.callee_p)
                    } else {
                        a2_p6.clone()
                    }))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }).cycle()
    }
}

/// `Start PromptReads, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_reads_f(cx_p0: PCx, e_p1: crate::syntax::Expr, defs_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(PromptReads { cx_p0, e_p1, defs_p2 })
}

/// ```prism
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
/// ```
pub fn prompt_spots_f(cx_p0: &PCx, e_p1: &crate::syntax::Expr, m_p2: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<crate::check::shrink::walk::Spot> {
    crate::prelude::run_to_end(crate::prelude::fold_job(prompt_kids_f(cx_p0, e_p1, m_p2), crate::prelude::Array::from(vec![crate::check::shrink::walk::Spot::SpotExpr(e_p1.clone(), m_p2.clone())]), {
        let cx_p0x = cx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)| {
            let cx_p0xy = cx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let k_p4 = p1;
                ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &prompt_kid_spots_f(&cx_p0xy, &k_p4)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Spot>>>>
    }))
}

/// ```prism
/// PromptKids: unbounded fn PCx, Expr, (Text ==> Rel) -> [Kid]
/// ```
pub fn prompt_kids_f(cx_p0: &PCx, e_p1: &crate::syntax::Expr, m_p2: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<crate::check::shrink::walk::Kid> {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::ELambda(_, _) => crate::prelude::Array::new(),
        crate::syntax::ExprKind::ERebuild(source_p3, body_p4) => row_kids_from_f(cx_p0, &**source_p3, body_p4, m_p2, &crate::prelude::Array::new()),
        crate::syntax::ExprKind::EFor(binders_o5, source_p6, body_p7) => row_kids_from_f(cx_p0, &**source_p6, body_p7, m_p2, &for_binder_names_f(binders_o5)),
        crate::syntax::ExprKind::EWidgetBlock(_) => crate::prelude::Array::new(),
        crate::syntax::ExprKind::ECall(c_p8, _, _, _) => prompt_call_kids_f(cx_p0, e_p1, &crate::check::shrink::walk::callee_name_o(&**c_p8), m_p2),
        crate::syntax::ExprKind::EMethod(_, n_p9, _) => prompt_call_kids_f(cx_p0, e_p1, &::std::option::Option::Some(crate::check::env::sname_key_f(n_p9)), m_p2),
        _ => crate::check::shrink::walk::expr_kids_f(e_p1, m_p2),
    }
}

/// ```prism
/// RowKids: unbounded fn PCx, Block, (Text ==> Rel), [Text] -> [Kid]
/// ```
pub fn row_kids_f(cx_p0: &PCx, body_p1: &crate::syntax::Block, m_p2: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, binders_p3: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::check::shrink::walk::Kid> {
    let lines_p4 = crate::prelude::filter(&body_p1.stmts_p, &(|s_p7: &crate::syntax::Stmt| match &s_p7.kind_p {
        crate::syntax::StmtKind::SBind(_, _, ::std::option::Option::Some(_)) => false,
        _ => true,
    }));
    let own_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(body_p1.stmts_p.clone(), crate::prelude::append(binders_p3, &crate::prelude::Array::from(vec![crate::prelude::Text::lit("_"), crate::prelude::Text::lit("$_")])), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p8 = p0;
        let s_p9 = p1;
        crate::prelude::call_then(start_stmt_defs_f(s_p9.clone()), move |stmt_defs_f_10409: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p8, &stmt_defs_f_10409)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
    let inner_p6 = crate::check::shrink::relations::hide_f(m_p2, &own_p5);
    if cx_p0.reach_p {
        crate::prelude::Array::from(vec![crate::check::shrink::walk::Kid::KidStmts(body_p1.stmts_p.clone(), inner_p6.clone())])
    } else {
        match row_result_o(body_p1) {
            ::std::option::Option::None => crate::prelude::Array::from(vec![crate::check::shrink::walk::Kid::KidStmts(lines_p4.clone(), inner_p6.clone())]),
            ::std::option::Option::Some(last_pa) => {
                let reached_pb = row_reach_f(cx_p0, body_p1, &last_pa, m_p2);
                let kept_pc = crate::prelude::run_to_end(crate::prelude::filter_job(lines_p4.clone(), {
                    let last_pax = last_pa.clone();
                    let reached_pbx = reached_pb.clone();
                    ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| {
                        let last_paxy = last_pax.clone();
                        let reached_pbxy = reached_pbx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let s_pd = p0;
                            if &s_pd.span_p == &last_paxy.span_p {
                                ::prism_rtl::Turn::Finished(true)
                            } else {
                                crate::prelude::call_then(start_stmt_defs_f(s_pd.clone()), move |stmt_defs_f_10797: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&stmt_defs_f_10797, &false, &(|found_pe: &bool, n_pf: &crate::prelude::Text| *found_pe || crate::check::types::has_text_f(&reached_pbxy, n_pf)))))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }));
                crate::prelude::Array::from(vec![crate::check::shrink::walk::Kid::KidStmts(kept_pc.clone(), inner_p6.clone())])
            },
        }
    }
}

/// ```prism
/// RowKidsFrom: unbounded fn PCx, Expr, Block, (Text ==> Rel), [Text] -> [Kid]
/// ```
pub fn row_kids_from_f(cx_p0: &PCx, source_p1: &crate::syntax::Expr, body_p2: &crate::syntax::Block, m_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, binders_p4: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::check::shrink::walk::Kid> {
    let rows_p5 = row_kids_f(cx_p0, body_p2, m_p3, binders_p4);
    if cx_p0.reach_p {
        crate::prelude::push(&rows_p5, &crate::check::shrink::walk::Kid::KidExpr(source_p1.clone(), m_p3.clone()))
    } else {
        rows_p5.clone()
    }
}

/// ```prism
/// ?RowResult: fn Block -> ?Stmt
/// ```
pub fn row_result_o(body_p0: &crate::syntax::Block) -> ::std::option::Option<crate::syntax::Stmt> {
    match crate::syntax::lexer::chars::last_o(&body_p0.stmts_p) {
        ::std::option::Option::Some(last_p1) => match &last_p1.kind_p {
            crate::syntax::StmtKind::SExpr(_) => ::std::option::Option::Some(last_p1.clone()),
            _ => ::std::option::Option::None,
        },
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// RowReach: unbounded fn PCx, Block, Stmt, (Text ==> Rel) -> [Text]
/// ```
pub fn row_reach_f(cx_p0: &PCx, body_p1: &crate::syntax::Block, last_p2: &crate::syntax::Stmt, m_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<crate::prelude::Text> {
    let defs_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(body_p1.stmts_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_pa = p0;
        let s_pb = p1;
        crate::prelude::call_then(start_stmt_defs_f(s_pb.clone()), move |stmt_defs_f_12360: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pa, &stmt_defs_f_12360)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
    let shown_p5 = crate::prelude::fold(&defs_p4, m_p3, &(|m2_pc: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, n_pd: &crate::prelude::Text| crate::prelude::remove(m2_pc, &crate::prelude::Text::from(format!("local:{}", n_pd)))));
    let base_p6 = crate::prelude::fold(&body_p1.stmts_p, &shown_p5, &(|m2_pe: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, s_pf: &crate::syntax::Stmt| lam_let_rels_f(s_pf, m2_pe)));
    let inner_p7 = {
        let mut this: PCx = cx_p0.clone();
        this.base_p = base_p6.clone();
        this.reach_p = true;
        this
    };
    let edges_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(body_p1.stmts_p.clone(), crate::prelude::Array::new(), {
        let inner_p7x = inner_p7.clone();
        let defs_p4x = defs_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::syntax::Stmt)| {
            let inner_p7xy = inner_p7x.clone();
            let defs_p4xy = defs_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pg = p0;
                let s_ph = p1;
                ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pg, &reach_edges_f(&inner_p7xy, &s_ph, &defs_p4xy)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>>>>
    }));
    let start_p9 = match &last_p2.kind_p {
        crate::syntax::StmtKind::SExpr(result_pi) => prompt_reads_f(&inner_p7, result_pi, &defs_p4),
        _ => crate::prelude::Array::new(),
    };
    reach_f(&edges_p8, &start_p9, &crate::prelude::Array::new())
}

/// ```prism
/// ReachEdges: unbounded fn PCx, Stmt, [Text] -> [((Text, Text))]
/// ```
pub fn reach_edges_f(cx_p0: &PCx, s_p1: &crate::syntax::Stmt, defs_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)> {
    match &s_p1.kind_p {
        crate::syntax::StmtKind::SBind(p_p3, _, ::std::option::Option::Some(step_p4)) => edges_f(&crate::check::env::names::pattern_names_f(p_p3), &prompt_reads_f(cx_p0, step_p4, defs_p2)),
        crate::syntax::StmtKind::SBind(p_p5, e_p6, ::std::option::Option::None) => edges_f(&crate::check::env::names::pattern_names_f(p_p5), &prompt_reads_f(cx_p0, e_p6, defs_p2)),
        crate::syntax::StmtKind::SLet(p_p7, _, e_p8) => edges_f(&crate::check::env::names::pattern_names_f(p_p7), &prompt_reads_f(cx_p0, e_p8, defs_p2)),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// ForBinderNames: unbounded fn ?ForBinders -> [Text]
/// ```
pub fn for_binder_names_f(binders_o0: &::std::option::Option<crate::syntax::ForBinders>) -> crate::prelude::Array<crate::prelude::Text> {
    match binders_o0 {
        ::std::option::Option::Some(fb_p1) => match &fb_p1.second_o {
            ::std::option::Option::Some(second_p2) => crate::prelude::append(&crate::check::env::names::pattern_names_f(&fb_p1.first_p), &crate::check::env::names::pattern_names_f(second_p2)),
            ::std::option::Option::None => crate::check::env::names::pattern_names_f(&fb_p1.first_p),
        },
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// ```prism
/// PromptCallKids: unbounded fn PCx, Expr, ?Text, (Text ==> Rel) -> [Kid]
/// ```
pub fn prompt_call_kids_f(cx_p0: &PCx, e_p1: &crate::syntax::Expr, n_o2: &::std::option::Option<crate::prelude::Text>, m_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<crate::check::shrink::walk::Kid> {
    match n_o2 {
        ::std::option::Option::Some(n_p4) => {
            let called_p5 = follow_lam_let_f(cx_p0, n_p4, m_p3);
            if crate::check::shrink::relations::is_local_f(m_p3, n_p4) {
                crate::prelude::append(&called_p5, &open_lambdas_f(cx_p0, &crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)))
            } else {
                if &crate::prelude::len(&called_p5) > &crate::prelude::Nat::from(0u32) {
                    crate::prelude::append(&called_p5, &open_lambdas_f(cx_p0, &crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)))
                } else {
                    match crate::prelude::get(&cx_p0.supplied_p, n_p4) {
                        ::std::option::Option::Some(flags_p6) => by_flags_f(cx_p0, e_p1, &flags_p6, m_p3),
                        ::std::option::Option::None => match crate::check::shrink::locals::resolve_callee_o(&cx_p0.g_p, &cx_p0.home_p, n_p4) {
                            ::std::option::Option::Some(k_p7) => if crate::check::shrink::relations::is_prelude_key_f(&cx_p0.g_p, &k_p7) && is_delayed_widget_f(&crate::syntax::lexer::chars::drop_prefix_f(&k_p7, &crate::prelude::Text::lit("Prelude."))) {
                                crate::prelude::Array::new()
                            } else {
                                if crate::check::shrink::relations::is_prelude_key_f(&cx_p0.g_p, &k_p7) && crate::syntax::lexer::chars::has_prefix_f(&k_p7, &crate::prelude::Text::lit("Prelude.@")) {
                                    crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)
                                } else {
                                    match &*e_p1.kind_p {
                                        crate::syntax::ExprKind::ECall(_, args_p8, _, _) => match prompt_summary_at_o(cx_p0, &k_p7, args_p8, m_p3) {
                                            ::std::option::Option::Some(flags_p9) => by_flags_f(cx_p0, e_p1, &flags_p9, m_p3),
                                            ::std::option::Option::None => open_lambdas_f(cx_p0, &crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)),
                                        },
                                        _ => open_lambdas_f(cx_p0, &crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)),
                                    }
                                }
                            },
                            ::std::option::Option::None => open_lambdas_f(cx_p0, &crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)),
                        },
                    }
                }
            }
        },
        ::std::option::Option::None => open_lambdas_f(cx_p0, &crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)),
    }
}

/// ```prism
/// ByFlags: unbounded fn PCx, Expr, [Bool], (Text ==> Rel) -> [Kid]
/// ```
pub fn by_flags_f(cx_p0: &PCx, e_p1: &crate::syntax::Expr, flags_p2: &crate::prelude::Array<bool>, m_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<crate::check::shrink::walk::Kid> {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::ECall(_, args_p4, _, _) => if crate::prelude::fold(args_p4, &false, &(|named_p5: &bool, a_p6: &crate::syntax::Arg| *named_p5 || (&a_p6.name_o != &::std::option::Option::None))) {
            open_lambdas_f(cx_p0, &crate::check::shrink::walk::expr_kids_f(e_p1, m_p3))
        } else {
            open_lambdas_f(cx_p0, &crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(args_p4)), &crate::prelude::Array::new(), &(|acc_p7: &crate::prelude::Array<crate::check::shrink::walk::Kid>, i_p8: &crate::prelude::Nat| if crate::prelude::or(&crate::prelude::index(flags_p2, i_p8), &true) {
                crate::prelude::push(acc_p7, &crate::check::shrink::walk::Kid::KidExpr(crate::prelude::or(&crate::prelude::index(args_p4, i_p8), &dummy_arg_p_p()).value_p.clone(), m_p3.clone()))
            } else {
                acc_p7.clone()
            })))
        },
        _ => open_lambdas_f(cx_p0, &crate::check::shrink::walk::expr_kids_f(e_p1, m_p3)),
    }
}

/// ```prism
/// OpenLambdas: unbounded fn PCx, [Kid] -> [Kid]
/// ```
pub fn open_lambdas_f(cx_p0: &PCx, kids_p1: &crate::prelude::Array<crate::check::shrink::walk::Kid>) -> crate::prelude::Array<crate::check::shrink::walk::Kid> {
    crate::prelude::run_to_end(crate::prelude::fold_job(kids_p1.clone(), crate::prelude::Array::new(), {
        let cx_p0x = cx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::walk::Kid>, crate::check::shrink::walk::Kid)| {
            let cx_p0xy = cx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p2 = p0;
                let k_p3 = p1;
                match &k_p3 {
                    crate::check::shrink::walk::Kid::KidExpr(x_p4, m_p5) => match &*x_p4.kind_p {
                        crate::syntax::ExprKind::ELambda(ps_o6, body_p7) => {
                            let ps_o6x = ps_o6.clone();
                            let body_p7x = (**body_p7).clone();
                            let m_p5x = m_p5.clone();
                            crate::prelude::call_then(crate::check::shrink::walk::start_patterns_names_f(crate::prelude::or(&ps_o6x, &crate::prelude::Array::new())), move |patterns_names_f_15946: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p2, &crate::check::shrink::walk::lambda_kid_f(&body_p7x, &crate::check::shrink::relations::hide_f(&m_p5x, &patterns_names_f_15946)))))
                        },
                        crate::syntax::ExprKind::EName(n_p8) => ::prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::push(&acc_p2, &k_p3), &follow_lam_let_f(&cx_p0xy, &crate::check::env::sname_key_f(n_p8), m_p5))),
                        _ => ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p2, &k_p3)),
                    },
                    _ => ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p2, &k_p3)),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::walk::Kid>, crate::check::shrink::walk::Kid)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Kid>>>>
    }))
}

/// ```prism
/// FollowLamLet: unbounded fn PCx, Text, (Text ==> Rel) -> [Kid]
/// ```
pub fn follow_lam_let_f(cx_p0: &PCx, n_p1: &crate::prelude::Text, m_p2: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<crate::check::shrink::walk::Kid> {
    match crate::prelude::get(m_p2, &crate::prelude::Text::from(format!("lamlet:{}", n_p1))) {
        ::std::option::Option::Some(r_p3) => if crate::check::env::has_key_f(m_p2, &crate::prelude::Text::from(format!("seen:{}", &r_p3.param_p))) {
            crate::prelude::Array::new()
        } else {
            match crate::prelude::get(&cx_p0.lams_p, &r_p3.param_p) {
                ::std::option::Option::Some(lam_p4) => match &*lam_p4.kind_p {
                    crate::syntax::ExprKind::ELambda(ps_o5, body_p6) => {
                        let seen_p7 = crate::prelude::fold(&crate::prelude::keys(m_p2), &cx_p0.base_p, &(|m2_p8: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, k_p9: &crate::prelude::Text| if crate::syntax::lexer::chars::has_prefix_f(k_p9, &crate::prelude::Text::lit("seen:")) {
                            crate::prelude::insert(m2_p8, k_p9, &crate::check::shrink::relations::no_rel_p())
                        } else {
                            m2_p8.clone()
                        }));
                        crate::prelude::Array::from(vec![crate::check::shrink::walk::lambda_kid_f(&**body_p6, &crate::check::shrink::relations::hide_f(&crate::prelude::insert(&seen_p7, &crate::prelude::Text::from(format!("seen:{}", &r_p3.param_p)), &crate::check::shrink::relations::no_rel_p()), &crate::check::shrink::walk::patterns_names_f(&crate::prelude::or(ps_o5, &crate::prelude::Array::new()))))])
                    },
                    _ => crate::prelude::Array::new(),
                },
                ::std::option::Option::None => crate::prelude::Array::new(),
            }
        },
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// ```prism
/// PromptKidSpots: unbounded fn PCx, Kid -> [Spot]
/// ```
pub fn prompt_kid_spots_f(cx_p0: &PCx, k_p1: &crate::check::shrink::walk::Kid) -> crate::prelude::Array<crate::check::shrink::walk::Spot> {
    match k_p1 {
        crate::check::shrink::walk::Kid::KidExpr(x_p2, m_p3) => prompt_spots_f(cx_p0, x_p2, m_p3),
        crate::check::shrink::walk::Kid::KidStmts(ss_p4, m_p5) => {
            let bm_p6 = crate::check::shrink::relations::block_rels_f(ss_p4, m_p5);
            crate::prelude::run_to_end(crate::prelude::fold_job(ss_p4.clone(), crate::prelude::Array::new(), {
                let cx_p0x = cx_p0.clone();
                let bm_p6x = bm_p6.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::walk::Spot>, crate::syntax::Stmt)| {
                    let cx_p0xy = cx_p0x.clone();
                    let bm_p6xy = bm_p6x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p7 = p0;
                        let s_p8 = p1;
                        ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p7, &prompt_stmt_spots_f(&cx_p0xy, &s_p8, &bm_p6xy)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::walk::Spot>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Spot>>>>
            }))
        },
    }
}

/// ```prism
/// PromptStmtSpots: unbounded fn PCx, Stmt, (Text ==> Rel) -> [Spot]
/// ```
pub fn prompt_stmt_spots_f(cx_p0: &PCx, s_p1: &crate::syntax::Stmt, m_p2: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<crate::check::shrink::walk::Spot> {
    match &s_p1.kind_p {
        crate::syntax::StmtKind::SFn(_) => crate::prelude::Array::from(vec![crate::check::shrink::walk::Spot::SpotStmt(s_p1.clone(), m_p2.clone())]),
        crate::syntax::StmtKind::SWidget(_) => crate::prelude::Array::from(vec![crate::check::shrink::walk::Spot::SpotStmt(s_p1.clone(), m_p2.clone())]),
        _ => crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmt_kids_f(s_p1, m_p2), crate::prelude::Array::from(vec![crate::check::shrink::walk::Spot::SpotStmt(s_p1.clone(), m_p2.clone())]), {
            let cx_p0x = cx_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)| {
                let cx_p0xy = cx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p3 = p0;
                    let k_p4 = p1;
                    ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &prompt_kid_spots_f(&cx_p0xy, &k_p4)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Spot>>>>
        })),
    }
}

/// ```prism
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
/// ```
pub fn find_cycle_f(defs_p0: &crate::prelude::Array<crate::prelude::Text>, edges_p1: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::run_to_end(crate::prelude::fold_job(defs_p0.clone(), crate::prelude::Array::new(), {
        let defs_p0x = defs_p0.clone();
        let edges_p1x = edges_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| {
            let defs_p0xy = defs_p0x.clone();
            let edges_p1xy = edges_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let found_p2 = p0;
                let d_p3 = p1;
                if &crate::prelude::len(&found_p2) > &crate::prelude::Nat::from(0u32) {
                    ::prism_rtl::Turn::Finished(found_p2.clone())
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(CycleThrough { defs_p0: defs_p0xy.clone(), edges_p1: edges_p1xy.clone(), d_p2: d_p3.clone() }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }))
}

/// The step machine of `FindCycle`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
/// ```
pub struct FindCycle {
    pub defs_p0: crate::prelude::Array<crate::prelude::Text>,
    pub edges_p1: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for FindCycle {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let defs_p0 = &self.defs_p0;
        let edges_p1 = &self.edges_p1;
        crate::prelude::fold_job(defs_p0.clone(), crate::prelude::Array::new(), {
            let defs_p0x = defs_p0.clone();
            let edges_p1x = edges_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| {
                let defs_p0xy = defs_p0x.clone();
                let edges_p1xy = edges_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_p2 = p0;
                    let d_p3 = p1;
                    if &crate::prelude::len(&found_p2) > &crate::prelude::Nat::from(0u32) {
                        ::prism_rtl::Turn::Finished(found_p2.clone())
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(CycleThrough { defs_p0: defs_p0xy.clone(), edges_p1: edges_p1xy.clone(), d_p2: d_p3.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }).cycle()
    }
}

/// `Start FindCycle, x`: what the function value is when passed to `@Run`.
pub fn start_find_cycle_f(defs_p0: crate::prelude::Array<crate::prelude::Text>, edges_p1: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(FindCycle { defs_p0, edges_p1 })
}

/// ```prism
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
/// ```
pub fn cycle_through_f(defs_p0: &crate::prelude::Array<crate::prelude::Text>, edges_p1: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, d_p2: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    let fwd_p3 = reach_from_f(edges_p1, d_p2);
    if crate::check::types::has_text_f(&fwd_p3, d_p2) {
        crate::prelude::run_to_end(crate::prelude::filter_job(defs_p0.clone(), {
            let fwd_p3x = fwd_p3.clone();
            let edges_p1x = edges_p1.clone();
            let d_p2x = d_p2.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                let fwd_p3xy = fwd_p3x.clone();
                let edges_p1xy = edges_p1x.clone();
                let d_p2xy = d_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let x_p4 = p0;
                    ::prism_rtl::Turn::Finished(crate::check::types::has_text_f(&fwd_p3xy, &x_p4) && crate::check::types::has_text_f(&reach_from_f(&edges_p1xy, &x_p4), &d_p2xy))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }))
    } else {
        crate::prelude::Array::new()
    }
}

/// The step machine of `CycleThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
/// ```
pub struct CycleThrough {
    pub defs_p0: crate::prelude::Array<crate::prelude::Text>,
    pub edges_p1: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    pub d_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for CycleThrough {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let defs_p0 = &self.defs_p0;
        let edges_p1 = &self.edges_p1;
        let d_p2 = &self.d_p2;
        let fwd_p3 = reach_from_f(edges_p1, d_p2);
        if crate::check::types::has_text_f(&fwd_p3, d_p2) {
            crate::prelude::filter_job(defs_p0.clone(), {
                let fwd_p3x = fwd_p3.clone();
                let edges_p1x = edges_p1.clone();
                let d_p2x = d_p2.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                    let fwd_p3xy = fwd_p3x.clone();
                    let edges_p1xy = edges_p1x.clone();
                    let d_p2xy = d_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let x_p4 = p0;
                        ::prism_rtl::Turn::Finished(crate::check::types::has_text_f(&fwd_p3xy, &x_p4) && crate::check::types::has_text_f(&reach_from_f(&edges_p1xy, &x_p4), &d_p2xy))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle()
        } else {
            ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
        }
    }
}

/// `Start CycleThrough, x`: what the function value is when passed to `@Run`.
pub fn start_cycle_through_f(defs_p0: crate::prelude::Array<crate::prelude::Text>, edges_p1: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, d_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(CycleThrough { defs_p0, edges_p1, d_p2 })
}

/// ```prism
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
/// ```
pub fn reach_from_f(edges_p0: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, d_p1: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    reach_f(edges_p0, &crate::prelude::each(&crate::prelude::filter(edges_p0, &(|(f_p2, _): &(crate::prelude::Text, crate::prelude::Text)| f_p2 == d_p1)), &(|(_, t_p3): &(crate::prelude::Text, crate::prelude::Text)| t_p3.clone())), &crate::prelude::Array::new())
}

/// ```prism
/// Reach: unbounded fn [((Text, Text))], [Text], [Text] -> [Text]
/// ```
pub fn reach_f(edges_p0: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, frontier_p1: &crate::prelude::Array<crate::prelude::Text>, seen_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    match crate::prelude::index(frontier_p1, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::None => seen_p2.clone(),
        ::std::option::Option::Some(x_p3) => if crate::check::types::has_text_f(seen_p2, &x_p3) {
            reach_f(edges_p0, &crate::prelude::drop(frontier_p1, &crate::prelude::Nat::from(1u32)), seen_p2)
        } else {
            reach_f(edges_p0, &crate::prelude::append(&crate::prelude::drop(frontier_p1, &crate::prelude::Nat::from(1u32)), &crate::prelude::each(&crate::prelude::filter(edges_p0, &(|(f_p4, _): &(crate::prelude::Text, crate::prelude::Text)| f_p4 == &x_p3)), &(|(_, t_p5): &(crate::prelude::Text, crate::prelude::Text)| t_p5.clone()))), &crate::prelude::push(seen_p2, &x_p3))
        },
    }
}

/// ```prism
/// ?PromptSummary: unbounded fn PCx, Text -> ?[Bool]
/// ```
pub fn prompt_summary_o(cx_p0: &PCx, k_p1: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Array<bool>> {
    prompt_summary_at_o(cx_p0, k_p1, &crate::prelude::Array::new(), &crate::prelude::Map::new())
}

/// ```prism
/// ?PromptSummaryAt: unbounded fn PCx, Text, [Arg], (Text ==> Rel) -> ?[Bool]
/// ```
pub fn prompt_summary_at_o(cx_p0: &PCx, k_p1: &crate::prelude::Text, args_p2: &crate::prelude::Array<crate::syntax::Arg>, m_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::option::Option<crate::prelude::Array<bool>> {
    if crate::check::types::has_text_f(&cx_p0.path_p, k_p1) || !crate::syntax::lexer::chars::has_prefix_f(&crate::check::types::bare_name_f(k_p1), &crate::prelude::Text::lit("@")) {
        ::std::option::Option::None
    } else {
        'm19867: {
            let scrutinee = &crate::prelude::filter(&cx_p0.g_p.defs_p, &(|d_p4: &crate::check::env::Def| &d_p4.qk_p == k_p1));
            if let m19867_0 = scrutinee && (m19867_0.len() == 1) && let ::std::option::Option::Some(d_p5) = crate::prelude::index(m19867_0, &crate::prelude::Nat::from(0u32)) {
                break 'm19867 'm19918: {
                    let scrutinee = &d_p5.body_p;
                    if let crate::check::env::DefBody::DbFn(m19918_0_0) = scrutinee && (m19918_0_0.len() == 1) && let ::std::option::Option::Some(c_p6) = crate::prelude::index(m19918_0_0, &crate::prelude::Nat::from(0u32)) {
                        break 'm19918 match &c_p6.body_p {
                            crate::syntax::decls::FnBody::BodyBlock(b_p7) => block_summary_o(cx_p0, k_p1, &d_p5.home_p, &c_p6.params_p, b_p7, &given_at_f(cx_p0, &cx_p0.home_p, &c_p6.params_p, args_p2, m_p3, &cx_p0.names_p)),
                            _ => ::std::option::Option::None,
                        };
                    }
                    ::std::option::Option::None
                };
            }
            ::std::option::Option::None
        }
    }
}

/// ```prism
/// GivenAt: unbounded fn PCx, Text, [Pattern], [Arg], (Text ==> Rel), [Text] -> (Text ==> [Bool])
/// ```
pub fn given_at_f(cx_p0: &PCx, home_p1: &crate::prelude::Text, params_p2: &crate::prelude::Array<crate::syntax::Pattern>, args_p3: &crate::prelude::Array<crate::syntax::Arg>, rels_p4: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, bound_p5: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>> {
    if crate::prelude::fold(args_p3, &false, &(|named_p6: &bool, a_p7: &crate::syntax::Arg| *named_p6 || (&a_p7.name_o != &::std::option::Option::None))) {
        crate::prelude::Map::new()
    } else {
        crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(params_p2)), crate::prelude::Map::new(), {
            let params_p2x = params_p2.clone();
            let args_p3x = args_p3.clone();
            let rels_p4x = rels_p4.clone();
            let bound_p5x = bound_p5.clone();
            let cx_p0x = cx_p0.clone();
            let home_p1x = home_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>, crate::prelude::Nat)| {
                let params_p2xy = params_p2x.clone();
                let args_p3xy = args_p3x.clone();
                let rels_p4xy = rels_p4x.clone();
                let bound_p5xy = bound_p5x.clone();
                let cx_p0xy = cx_p0x.clone();
                let home_p1xy = home_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let supplied_p8 = p0;
                    let i_p9 = p1;
                    match (crate::prelude::index(&params_p2xy, &i_p9), crate::prelude::index(&args_p3xy, &i_p9)) {
                        (::std::option::Option::Some(parameter_pa), ::std::option::Option::Some(a_pb)) => crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(parameter_pa.clone()), move |pattern_names_f_20804: crate::prelude::Array<crate::prelude::Text>| 'm20796: {
                            let scrutinee = &(pattern_names_f_20804, given_name_o(&a_pb.value_p));
                            if let (m20796_0_0, ::std::option::Option::Some(n_pd)) = scrutinee && (m20796_0_0.len() == 1) && let ::std::option::Option::Some(name_pc) = crate::prelude::index(m20796_0_0, &crate::prelude::Nat::from(0u32)) {
                                break 'm20796 if crate::check::shrink::relations::is_local_f(&rels_p4xy, n_pd) || crate::check::types::has_text_f(&bound_p5xy, n_pd) {
                                    ::prism_rtl::Turn::Finished(supplied_p8.clone())
                                } else {
                                    match crate::check::shrink::locals::resolve_callee_o(&cx_p0xy.g_p, &home_p1xy, n_pd) {
                                        ::std::option::Option::Some(function_pe) => match prompt_summary_o(&cx_p0xy, &function_pe) {
                                            ::std::option::Option::Some(flags_pf) => ::prism_rtl::Turn::Finished(crate::prelude::insert(&supplied_p8, &name_pc, &flags_pf)),
                                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(supplied_p8.clone()),
                                        },
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(supplied_p8.clone()),
                                    }
                                };
                            }
                            ::prism_rtl::Turn::Finished(supplied_p8.clone())
                        }),
                        _ => ::prism_rtl::Turn::Finished(supplied_p8.clone()),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>>>
        }))
    }
}

/// The step machine of `GivenAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivenAt: unbounded fn PCx, Text, [Pattern], [Arg], (Text ==> Rel), [Text] -> (Text ==> [Bool])
/// ```
pub struct GivenAt {
    pub cx_p0: PCx,
    pub home_p1: crate::prelude::Text,
    pub params_p2: crate::prelude::Array<crate::syntax::Pattern>,
    pub args_p3: crate::prelude::Array<crate::syntax::Arg>,
    pub rels_p4: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub bound_p5: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>> for GivenAt {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>> {
        let cx_p0 = &self.cx_p0;
        let home_p1 = &self.home_p1;
        let params_p2 = &self.params_p2;
        let args_p3 = &self.args_p3;
        let rels_p4 = &self.rels_p4;
        let bound_p5 = &self.bound_p5;
        if crate::prelude::fold(args_p3, &false, &(|named_p6: &bool, a_p7: &crate::syntax::Arg| *named_p6 || (&a_p7.name_o != &::std::option::Option::None))) {
            ::prism_rtl::Turn::Finished(crate::prelude::Map::new())
        } else {
            crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(params_p2)), crate::prelude::Map::new(), {
                let params_p2x = params_p2.clone();
                let args_p3x = args_p3.clone();
                let rels_p4x = rels_p4.clone();
                let bound_p5x = bound_p5.clone();
                let cx_p0x = cx_p0.clone();
                let home_p1x = home_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>, crate::prelude::Nat)| {
                    let params_p2xy = params_p2x.clone();
                    let args_p3xy = args_p3x.clone();
                    let rels_p4xy = rels_p4x.clone();
                    let bound_p5xy = bound_p5x.clone();
                    let cx_p0xy = cx_p0x.clone();
                    let home_p1xy = home_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let supplied_p8 = p0;
                        let i_p9 = p1;
                        match (crate::prelude::index(&params_p2xy, &i_p9), crate::prelude::index(&args_p3xy, &i_p9)) {
                            (::std::option::Option::Some(parameter_pa), ::std::option::Option::Some(a_pb)) => crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(parameter_pa.clone()), move |pattern_names_f_20804: crate::prelude::Array<crate::prelude::Text>| 'm20796: {
                                let scrutinee = &(pattern_names_f_20804, given_name_o(&a_pb.value_p));
                                if let (m20796_0_0, ::std::option::Option::Some(n_pd)) = scrutinee && (m20796_0_0.len() == 1) && let ::std::option::Option::Some(name_pc) = crate::prelude::index(m20796_0_0, &crate::prelude::Nat::from(0u32)) {
                                    break 'm20796 if crate::check::shrink::relations::is_local_f(&rels_p4xy, n_pd) || crate::check::types::has_text_f(&bound_p5xy, n_pd) {
                                        ::prism_rtl::Turn::Finished(supplied_p8.clone())
                                    } else {
                                        match crate::check::shrink::locals::resolve_callee_o(&cx_p0xy.g_p, &home_p1xy, n_pd) {
                                            ::std::option::Option::Some(function_pe) => match prompt_summary_o(&cx_p0xy, &function_pe) {
                                                ::std::option::Option::Some(flags_pf) => ::prism_rtl::Turn::Finished(crate::prelude::insert(&supplied_p8, &name_pc, &flags_pf)),
                                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(supplied_p8.clone()),
                                            },
                                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(supplied_p8.clone()),
                                        }
                                    };
                                }
                                ::prism_rtl::Turn::Finished(supplied_p8.clone())
                            }),
                            _ => ::prism_rtl::Turn::Finished(supplied_p8.clone()),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>>>
            }).cycle()
        }
    }
}

/// `Start GivenAt, x`: what the function value is when passed to `@Run`.
pub fn start_given_at_f(cx_p0: PCx, home_p1: crate::prelude::Text, params_p2: crate::prelude::Array<crate::syntax::Pattern>, args_p3: crate::prelude::Array<crate::syntax::Arg>, rels_p4: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, bound_p5: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>> {
    ::std::rc::Rc::new(GivenAt { cx_p0, home_p1, params_p2, args_p3, rels_p4, bound_p5 })
}

/// ```prism
/// ?GivenName: fn Expr -> ?Text
/// ```
pub fn given_name_o(e_p0: &crate::syntax::Expr) -> ::std::option::Option<crate::prelude::Text> {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::EName(n_p1) => ::std::option::Option::Some(crate::check::env::sname_key_f(n_p1)),
        crate::syntax::ExprKind::EGroup(x_p2) => given_name_o(&**x_p2),
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// ParameterUses: unbounded fn PCx, Env, Block -> [(Text ==> [Bool])]
/// ```
pub fn parameter_uses_f(cx_p0: &PCx, env_p1: &crate::check::expr::Env, b_p2: &crate::syntax::Block) -> crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>> {
    'm21938: {
        let scrutinee = &crate::prelude::filter(&env_p1.g_p.defs_p, &(|d_p3: &crate::check::env::Def| (&d_p3.file_p == &env_p1.file_p) && is_body_of_f(d_p3, b_p2)));
        if let m21938_0 = scrutinee && (m21938_0.len() == 1) && let ::std::option::Option::Some(d_p4) = crate::prelude::index(m21938_0, &crate::prelude::Nat::from(0u32)) {
            break 'm21938 'm22017: {
                let scrutinee = &d_p4.body_p;
                if let crate::check::env::DefBody::DbFn(m22017_0_0) = scrutinee && (m22017_0_0.len() == 1) && let ::std::option::Option::Some(c_p5) = crate::prelude::index(m22017_0_0, &crate::prelude::Nat::from(0u32)) {
                    break 'm22017 if !calls_parameter_f(&c_p5.params_p, b_p2) {
                        crate::prelude::Array::from(vec![crate::prelude::Map::new()])
                    } else {
                        {
                            let uses_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(cx_p0.g_p.defs_p.clone(), crate::prelude::Array::new(), {
                                let cx_p0x = cx_p0.clone();
                                let d_p4x = d_p4.clone();
                                let c_p5x = c_p5.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>, crate::check::env::Def)| {
                                    let cx_p0xy = cx_p0x.clone();
                                    let d_p4xy = d_p4x.clone();
                                    let c_p5xy = c_p5x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let acc_p7 = p0;
                                        let user_p8 = p1;
                                        crate::prelude::call_then(start_def_sites_f(user_p8.clone()), move |def_sites_f_22193: crate::prelude::Array<crate::check::shrink::walk::Site>| crate::prelude::fold_job(def_sites_f_22193, acc_p7.clone(), {
                                            let cx_p0xyx = cx_p0xy.clone();
                                            let user_p8x = user_p8.clone();
                                            let d_p4xyx = d_p4xy.clone();
                                            let c_p5xyx = c_p5xy.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>, crate::check::shrink::walk::Site)| {
                                                let cx_p0xyxy = cx_p0xyx.clone();
                                                let user_p8xy = user_p8x.clone();
                                                let d_p4xyxy = d_p4xyx.clone();
                                                let c_p5xyxy = c_p5xyx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let found_p9 = p0;
                                                    let site_pa = p1;
                                                    if crate::check::shrink::relations::is_local_f(&site_pa.rels_p, &site_pa.callee_p) || (&crate::check::shrink::locals::resolve_callee_o(&cx_p0xyxy.g_p, &user_p8xy.home_p, &site_pa.callee_p) != &::std::option::Option::Some(d_p4xyxy.qk_p.clone())) {
                                                        ::prism_rtl::Turn::Finished(found_p9.clone())
                                                    } else {
                                                        crate::prelude::call_then(start_given_at_f(cx_p0xyxy.clone(), user_p8xy.home_p.clone(), c_p5xyxy.params_p.clone(), site_pa.args_p.clone(), site_pa.rels_p.clone(), crate::prelude::Array::new()), move |given_at_f_22390: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>| ::prism_rtl::Turn::Finished(crate::prelude::push(&found_p9, &given_at_f_22390)))
                                                    }
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>, crate::check::shrink::walk::Site)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>>>>
                                        }).cycle())
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>>>>
                            }));
                            if &crate::prelude::len(&uses_p6) == &crate::prelude::Nat::from(0u32) {
                                crate::prelude::Array::from(vec![crate::prelude::Map::new()])
                            } else {
                                uses_p6.clone()
                            }
                        }
                    };
                }
                crate::prelude::Array::from(vec![crate::prelude::Map::new()])
            };
        }
        crate::prelude::Array::from(vec![crate::prelude::Map::new()])
    }
}

/// The step machine of `ParameterUses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParameterUses: unbounded fn PCx, Env, Block -> [(Text ==> [Bool])]
/// ```
pub struct ParameterUses {
    pub cx_p0: PCx,
    pub env_p1: crate::check::expr::Env,
    pub b_p2: crate::syntax::Block,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>> for ParameterUses {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>> {
        let cx_p0 = &self.cx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        'm21938: {
            let scrutinee = &crate::prelude::filter(&env_p1.g_p.defs_p, &(|d_p3: &crate::check::env::Def| (&d_p3.file_p == &env_p1.file_p) && is_body_of_f(d_p3, b_p2)));
            if let m21938_0 = scrutinee && (m21938_0.len() == 1) && let ::std::option::Option::Some(d_p4) = crate::prelude::index(m21938_0, &crate::prelude::Nat::from(0u32)) {
                break 'm21938 'm22017: {
                    let scrutinee = &d_p4.body_p;
                    if let crate::check::env::DefBody::DbFn(m22017_0_0) = scrutinee && (m22017_0_0.len() == 1) && let ::std::option::Option::Some(c_p5) = crate::prelude::index(m22017_0_0, &crate::prelude::Nat::from(0u32)) {
                        break 'm22017 {
                            let b_p2x = b_p2.clone();
                            let cx_p0x = cx_p0.clone();
                            crate::prelude::call_then(start_calls_parameter_f(c_p5.params_p.clone(), b_p2x.clone()), move |calls_parameter_f_22071: bool| if !calls_parameter_f_22071 {
                                ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::prelude::Map::new()]))
                            } else {
                                crate::prelude::call_value(crate::prelude::fold_job(cx_p0x.g_p.defs_p.clone(), crate::prelude::Array::new(), {
                                    let cx_p0xx = cx_p0x.clone();
                                    let d_p4x = d_p4.clone();
                                    let c_p5x = c_p5.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>, crate::check::env::Def)| {
                                        let cx_p0xxy = cx_p0xx.clone();
                                        let d_p4xy = d_p4x.clone();
                                        let c_p5xy = c_p5x.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let acc_p7 = p0;
                                            let user_p8 = p1;
                                            crate::prelude::call_then(start_def_sites_f(user_p8.clone()), move |def_sites_f_22193: crate::prelude::Array<crate::check::shrink::walk::Site>| crate::prelude::fold_job(def_sites_f_22193, acc_p7.clone(), {
                                                let cx_p0xxyx = cx_p0xxy.clone();
                                                let user_p8x = user_p8.clone();
                                                let d_p4xyx = d_p4xy.clone();
                                                let c_p5xyx = c_p5xy.clone();
                                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>, crate::check::shrink::walk::Site)| {
                                                    let cx_p0xxyxy = cx_p0xxyx.clone();
                                                    let user_p8xy = user_p8x.clone();
                                                    let d_p4xyxy = d_p4xyx.clone();
                                                    let c_p5xyxy = c_p5xyx.clone();
                                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let found_p9 = p0;
                                                        let site_pa = p1;
                                                        if crate::check::shrink::relations::is_local_f(&site_pa.rels_p, &site_pa.callee_p) || (&crate::check::shrink::locals::resolve_callee_o(&cx_p0xxyxy.g_p, &user_p8xy.home_p, &site_pa.callee_p) != &::std::option::Option::Some(d_p4xyxy.qk_p.clone())) {
                                                            ::prism_rtl::Turn::Finished(found_p9.clone())
                                                        } else {
                                                            crate::prelude::call_then(start_given_at_f(cx_p0xxyxy.clone(), user_p8xy.home_p.clone(), c_p5xyxy.params_p.clone(), site_pa.args_p.clone(), site_pa.rels_p.clone(), crate::prelude::Array::new()), move |given_at_f_22390: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>| ::prism_rtl::Turn::Finished(crate::prelude::push(&found_p9, &given_at_f_22390)))
                                                        }
                                                    }))
                                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>, crate::check::shrink::walk::Site)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>>>>
                                            }).cycle())
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>>>>
                                }), move |fold_22152: crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>| {
                                    let uses_p6 = fold_22152;
                                    if &crate::prelude::len(&uses_p6) == &crate::prelude::Nat::from(0u32) {
                                        ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::prelude::Map::new()]))
                                    } else {
                                        ::prism_rtl::Turn::Finished(uses_p6.clone())
                                    }
                                })
                            })
                        };
                    }
                    ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::prelude::Map::new()]))
                };
            }
            ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::prelude::Map::new()]))
        }
    }
}

/// `Start ParameterUses, x`: what the function value is when passed to `@Run`.
pub fn start_parameter_uses_f(cx_p0: PCx, env_p1: crate::check::expr::Env, b_p2: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>>> {
    ::std::rc::Rc::new(ParameterUses { cx_p0, env_p1, b_p2 })
}

/// ```prism
/// IsBodyOf: fn Def, Block -> Bool
/// ```
pub fn is_body_of_f(d_p0: &crate::check::env::Def, b_p1: &crate::syntax::Block) -> bool {
    crate::syntax::lexer::chars::has_prefix_f(&crate::check::types::bare_name_f(&d_p0.qk_p), &crate::prelude::Text::lit("@")) && 'm22726: {
        let scrutinee = &d_p0.body_p;
        if let crate::check::env::DefBody::DbFn(m22726_0_0) = scrutinee && (m22726_0_0.len() == 1) && let ::std::option::Option::Some(c_p2) = crate::prelude::index(m22726_0_0, &crate::prelude::Nat::from(0u32)) {
            break 'm22726 match &c_p2.body_p {
                crate::syntax::decls::FnBody::BodyBlock(body_p3) => &body_p3.span_p == &b_p1.span_p,
                _ => false,
            };
        }
        false
    }
}

/// ```prism
/// CallsParameter: unbounded fn [Pattern], Block -> Bool
/// ```
pub fn calls_parameter_f(params_p0: &crate::prelude::Array<crate::syntax::Pattern>, b_p1: &crate::syntax::Block) -> bool {
    let names_p2 = crate::check::shrink::walk::patterns_names_f(params_p0);
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmts_spots_f(&b_p1.stmts_p, &crate::prelude::Map::new()), false, {
        let names_p2x = names_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
            let names_p2xy = names_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let called_p3 = p0;
                let spot_p4 = p1;
                if called_p3 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(spot_p4.clone()), move |spot_sites_f_23128: crate::prelude::Array<crate::check::shrink::walk::Site>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&spot_sites_f_23128, &false, &(|found_p5: &bool, site_p6: &crate::check::shrink::walk::Site| *found_p5 || (((&crate::prelude::len(&site_p6.args_p) > &crate::prelude::Nat::from(0u32)) && crate::check::types::has_text_f(&names_p2xy, &site_p6.callee_p)) && !crate::check::shrink::relations::is_local_f(&site_p6.rels_p, &site_p6.callee_p))))))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `CallsParameter`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallsParameter: unbounded fn [Pattern], Block -> Bool
/// ```
pub struct CallsParameter {
    pub params_p0: crate::prelude::Array<crate::syntax::Pattern>,
    pub b_p1: crate::syntax::Block,
}

impl ::prism_rtl::Job<bool> for CallsParameter {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let params_p0 = &self.params_p0;
        let b_p1 = &self.b_p1;
        let b_p1x = b_p1.clone();
        let params_p0x = params_p0.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_patterns_names_f(params_p0x.clone()), move |patterns_names_f_23033: crate::prelude::Array<crate::prelude::Text>| {
            let names_p2 = patterns_names_f_23033;
            crate::prelude::call_then(crate::check::shrink::walk::start_stmts_spots_f(b_p1x.stmts_p.clone(), crate::prelude::Map::new()), move |stmts_spots_f_23064: crate::prelude::Array<crate::check::shrink::walk::Spot>| crate::prelude::fold_job(stmts_spots_f_23064, false, {
                let names_p2x = names_p2.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                    let names_p2xy = names_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let called_p3 = p0;
                        let spot_p4 = p1;
                        if called_p3 {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(spot_p4.clone()), move |spot_sites_f_23128: crate::prelude::Array<crate::check::shrink::walk::Site>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&spot_sites_f_23128, &false, &(|found_p5: &bool, site_p6: &crate::check::shrink::walk::Site| *found_p5 || (((&crate::prelude::len(&site_p6.args_p) > &crate::prelude::Nat::from(0u32)) && crate::check::types::has_text_f(&names_p2xy, &site_p6.callee_p)) && !crate::check::shrink::relations::is_local_f(&site_p6.rels_p, &site_p6.callee_p))))))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle())
        })
    }
}

/// `Start CallsParameter, x`: what the function value is when passed to `@Run`.
pub fn start_calls_parameter_f(params_p0: crate::prelude::Array<crate::syntax::Pattern>, b_p1: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(CallsParameter { params_p0, b_p1 })
}

/// ```prism
/// DefSites: unbounded fn Def -> [Site]
/// ```
pub fn def_sites_f(d_p0: &crate::check::env::Def) -> crate::prelude::Array<crate::check::shrink::walk::Site> {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbFn(clauses_p1) => clauses_sites_f(clauses_p1),
        crate::check::env::DefBody::DbMethod(clauses_p2, _, _) => clauses_sites_f(clauses_p2),
        crate::check::env::DefBody::DbDefault(clauses_p3, _) => clauses_sites_f(clauses_p3),
        crate::check::env::DefBody::DbWidget(w_p4) => spots_sites_f(&crate::check::shrink::walk::stmts_spots_f(&w_p4.body_p.stmts_p, &crate::prelude::Map::new())),
        crate::check::env::DefBody::DbLet(l_p5) => spots_sites_f(&crate::check::shrink::walk::expr_spots_f(&l_p5.value_p, &crate::prelude::Map::new())),
        crate::check::env::DefBody::DbTest(t_p6) => spots_sites_f(&crate::check::shrink::walk::expr_spots_f(&t_p6.blueprint_p, &crate::prelude::Map::new())),
        crate::check::env::DefBody::DbCheck(c_p7) => crate::prelude::run_to_end(crate::prelude::fold_job(c_p7.lines_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::walk::Site>, crate::syntax::decls::CheckLine)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p8 = p0;
            let line_p9 = p1;
            crate::prelude::call_then(crate::check::shrink::walk::start_expr_spots_f(line_p9.expr_p.clone(), crate::prelude::Map::new()), move |expr_spots_f_23799: crate::prelude::Array<crate::check::shrink::walk::Spot>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p8, &spots_sites_f(&expr_spots_f_23799))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::walk::Site>, crate::syntax::decls::CheckLine)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Site>>>>)),
    }
}

/// The step machine of `DefSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefSites: unbounded fn Def -> [Site]
/// ```
pub struct DefSites {
    pub d_p0: crate::check::env::Def,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Site>> for DefSites {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::check::shrink::walk::Site>> {
        let d_p0 = &self.d_p0;
        match &d_p0.body_p {
            crate::check::env::DefBody::DbFn(clauses_p1) => ::prism_rtl::Turn::Finished(clauses_sites_f(clauses_p1)),
            crate::check::env::DefBody::DbMethod(clauses_p2, _, _) => ::prism_rtl::Turn::Finished(clauses_sites_f(clauses_p2)),
            crate::check::env::DefBody::DbDefault(clauses_p3, _) => ::prism_rtl::Turn::Finished(clauses_sites_f(clauses_p3)),
            crate::check::env::DefBody::DbWidget(w_p4) => {
                let w_p4x = w_p4.clone();
                crate::prelude::call_then(crate::check::shrink::walk::start_stmts_spots_f(w_p4x.body_p.stmts_p.clone(), crate::prelude::Map::new()), move |stmts_spots_f_23596: crate::prelude::Array<crate::check::shrink::walk::Spot>| ::prism_rtl::Turn::Finished(spots_sites_f(&stmts_spots_f_23596)))
            },
            crate::check::env::DefBody::DbLet(l_p5) => {
                let l_p5x = l_p5.clone();
                crate::prelude::call_then(crate::check::shrink::walk::start_expr_spots_f(l_p5x.value_p.clone(), crate::prelude::Map::new()), move |expr_spots_f_23650: crate::prelude::Array<crate::check::shrink::walk::Spot>| ::prism_rtl::Turn::Finished(spots_sites_f(&expr_spots_f_23650)))
            },
            crate::check::env::DefBody::DbTest(t_p6) => {
                let t_p6x = t_p6.clone();
                crate::prelude::call_then(crate::check::shrink::walk::start_expr_spots_f(t_p6x.blueprint_p.clone(), crate::prelude::Map::new()), move |expr_spots_f_23699: crate::prelude::Array<crate::check::shrink::walk::Spot>| ::prism_rtl::Turn::Finished(spots_sites_f(&expr_spots_f_23699)))
            },
            crate::check::env::DefBody::DbCheck(c_p7) => crate::prelude::fold_job(c_p7.lines_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::walk::Site>, crate::syntax::decls::CheckLine)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p8 = p0;
                let line_p9 = p1;
                crate::prelude::call_then(crate::check::shrink::walk::start_expr_spots_f(line_p9.expr_p.clone(), crate::prelude::Map::new()), move |expr_spots_f_23799: crate::prelude::Array<crate::check::shrink::walk::Spot>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p8, &spots_sites_f(&expr_spots_f_23799))))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::walk::Site>, crate::syntax::decls::CheckLine)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Site>>>>).cycle(),
        }
    }
}

/// `Start DefSites, x`: what the function value is when passed to `@Run`.
pub fn start_def_sites_f(d_p0: crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Site>>> {
    ::std::rc::Rc::new(DefSites { d_p0 })
}

/// ```prism
/// ClausesSites: unbounded fn [FnClause] -> [Site]
/// ```
pub fn clauses_sites_f(clauses_p0: &crate::prelude::Array<crate::syntax::decls::FnClause>) -> crate::prelude::Array<crate::check::shrink::walk::Site> {
    crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p0.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p1 = p0;
        let c_p2 = p1;
        crate::prelude::call_then(crate::check::shrink::walk::start_patterns_names_f(c_p2.params_p.clone()), move |patterns_names_f_23972: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(crate::check::shrink::walk::start_body_sites_f(c_p2.body_p.clone(), crate::check::shrink::relations::hide_f(&crate::prelude::Map::new(), &patterns_names_f_23972)), move |body_sites_f_23943: crate::prelude::Array<crate::check::shrink::walk::Site>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &body_sites_f_23943))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Site>>>>))
}

/// ```prism
/// SpotsSites: unbounded fn [Spot] -> [Site]
/// ```
pub fn spots_sites_f(spots_p0: &crate::prelude::Array<crate::check::shrink::walk::Spot>) -> crate::prelude::Array<crate::check::shrink::walk::Site> {
    crate::prelude::run_to_end(crate::prelude::fold_job(spots_p0.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p1 = p0;
        let spot_p2 = p1;
        crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(spot_p2.clone()), move |spot_sites_f_24107: crate::prelude::Array<crate::check::shrink::walk::Site>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &spot_sites_f_24107)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Site>>>>))
}

/// ```prism
/// ?BlockSummary: unbounded fn PCx, Text, Text, [Pattern], Block, (Text ==> [Bool]) -> ?[Bool]
/// ```
pub fn block_summary_o(cx_p0: &PCx, k_p1: &crate::prelude::Text, home_p2: &crate::prelude::Text, params_p3: &crate::prelude::Array<crate::syntax::Pattern>, b_p4: &crate::syntax::Block, supplied_p5: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>) -> ::std::option::Option<crate::prelude::Array<bool>> {
    match crate::syntax::lexer::chars::last_o(&b_p4.stmts_p) {
        ::std::option::Option::Some(last_p6) => match &last_p6.kind_p {
            crate::syntax::StmtKind::SExpr(result_p7) => {
                let param_names_p8 = crate::prelude::run_to_end(crate::prelude::each_job(params_p3.clone(), ::std::rc::Rc::new(move |p0: crate::syntax::Pattern| crate::prelude::entered(crate::prelude::once_job(move || {
                    let p_pe = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::names::PatternNames { p_p0: p_pe.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
                let defs_p9 = crate::prelude::run_to_end(crate::prelude::fold_job(b_p4.stmts_p.clone(), crate::prelude::fold(&param_names_p8, &crate::prelude::Array::new(), &(|acc_pf: &crate::prelude::Array<crate::prelude::Text>, ns_pg: &crate::prelude::Array<crate::prelude::Text>| crate::prelude::append(acc_pf, ns_pg))), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_ph = p0;
                    let s_pi = p1;
                    crate::prelude::call_then(start_stmt_defs_f(s_pi.clone()), move |stmt_defs_f_24514: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_ph, &stmt_defs_f_24514)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
                let base_pa = crate::prelude::fold(&b_p4.stmts_p, &crate::check::shrink::relations::prelude_seeds_f(&cx_p0.g_p, home_p2), &(|m_pj: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, s_pk: &crate::syntax::Stmt| lam_let_rels_f(s_pk, m_pj)));
                let inner_pb = PCx { g_p: cx_p0.g_p.clone(), home_p: home_p2.clone(), lams_p: let_lambdas_f(&b_p4.stmts_p), base_p: base_pa.clone(), path_p: crate::prelude::push(&cx_p0.path_p, k_p1), reach_p: cx_p0.reach_p, supplied_p: supplied_p5.clone(), names_p: defs_p9.clone() };
                let edges_pc = crate::prelude::run_to_end(crate::prelude::fold_job(b_p4.stmts_p.clone(), crate::prelude::Array::new(), {
                    let inner_pbx = inner_pb.clone();
                    let defs_p9x = defs_p9.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::syntax::Stmt)| {
                        let inner_pbxy = inner_pbx.clone();
                        let defs_p9xy = defs_p9x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pl = p0;
                            let s_pm = p1;
                            ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pl, &summary_edges_f(&inner_pbxy, &s_pm, &defs_p9xy)))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>>>>
                }));
                let reached_pd = reach_f(&edges_pc, &prompt_reads_f(&inner_pb, result_p7, &defs_p9), &crate::prelude::Array::new());
                ::std::option::Option::Some(crate::prelude::each(&param_names_p8, &(|ns_pn: &crate::prelude::Array<crate::prelude::Text>| crate::prelude::fold(ns_pn, &false, &(|f_po: &bool, n_pp: &crate::prelude::Text| *f_po || crate::check::types::has_text_f(&reached_pd, n_pp))))))
            },
            _ => ::std::option::Option::None,
        },
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// SummaryEdges: unbounded fn PCx, Stmt, [Text] -> [((Text, Text))]
/// ```
pub fn summary_edges_f(cx_p0: &PCx, s_p1: &crate::syntax::Stmt, defs_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)> {
    match &s_p1.kind_p {
        crate::syntax::StmtKind::SBind(_, _, ::std::option::Option::Some(_)) => crate::prelude::Array::new(),
        crate::syntax::StmtKind::SBind(p_p3, e_p4, ::std::option::Option::None) => edges_f(&crate::check::env::names::pattern_names_f(p_p3), &prompt_reads_f(cx_p0, e_p4, defs_p2)),
        crate::syntax::StmtKind::SLet(p_p5, _, e_p6) => edges_f(&crate::check::env::names::pattern_names_f(p_p5), &prompt_reads_f(cx_p0, e_p6, defs_p2)),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// let dummyArgP
/// ```
pub fn dummy_arg_p_p() -> crate::syntax::Arg {
    crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }, span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}
