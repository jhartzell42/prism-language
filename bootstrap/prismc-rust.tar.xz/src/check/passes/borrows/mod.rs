//! The module `Check.Passes.Borrows`, from `target/bootstrap/src/prismc/check/passes/borrows.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// IsLocalType: unbounded fn St, Ty -> Bool
/// ```
pub fn is_local_type(st: &crate::check::types::St, t: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyCon(m1393_0_0, _) if (&m1393_0_0 == &Text::lit("Buffer")) => true,
        crate::check::types::Ty::TyCon(m1393_1_0, _) if (&m1393_1_0 == &Text::lit("Table")) => true,
        crate::check::types::Ty::TyArray(e) => is_local_type(st, &*e),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), false, {
            let st = st.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(seen || is_local_type(&st, &x))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyMap(k, v_) => is_local_type(st, &*k) || is_local_type(st, &*v_),
        crate::check::types::Ty::TySig(_, i) => is_local_type(st, &*i),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `IsLocalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsLocalType: unbounded fn St, Ty -> Bool
/// ```
pub struct IsLocalType {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for IsLocalType {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_1399: crate::check::types::Ty| match walk_1399 {
            crate::check::types::Ty::TyCon(m1393_0_0, _) if (&m1393_0_0 == &Text::lit("Buffer")) => prism_rtl::Turn::Finished(true),
            crate::check::types::Ty::TyCon(m1393_1_0, _) if (&m1393_1_0 == &Text::lit("Table")) => prism_rtl::Turn::Finished(true),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(IsLocalType { st: st.clone(), t: (*e).clone() })),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), false, {
                let st = st.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(seen || is_local_type(&st, &x))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::check::types::Ty::TyMap(k, v_) => call_then(start_is_local_type(st.clone(), (*k).clone()), move |is_local_type_1595: bool| prism_rtl::Turn::Finished(is_local_type_1595 || is_local_type(&st, &*v_))),
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(IsLocalType { st: st.clone(), t: (*i).clone() })),
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start IsLocalType, x`: what the function value is when passed to `@Run`.
pub fn start_is_local_type(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsLocalType { st, t })
}

/// ```prism
/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
/// ```
pub fn and_block_checks(env: &crate::check::expr::Env, st: &crate::check::types::St, b: &crate::syntax::Block, t: &crate::check::types::Ty) -> crate::check::types::St {
    let st1 = if is_local_type(st, t) {
        crate::check::types::recording::err_fix(st, &Text::lit("local-escapes"), &b.span, &Text::from(format!("a `{}` cannot leave its block", &block_local_name(st, t))), &Text::lit("`Freeze` it into a plain value first"))
    } else {
        st.clone()
    };
    let st2 = escape_stmts(env, &st1, &b.stmts);
    let (_, st3) = frozen_stmts(env, &st2, &b.stmts, &Map::new());
    borrow_stmts(env, &st3, &b.stmts, &Array::new())
}

/// The step machine of `AndBlockChecks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
/// ```
pub struct AndBlockChecks {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub b: crate::syntax::Block,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for AndBlockChecks {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let t = &self.t;
        let b = b.clone();
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_is_local_type(st.clone(), t.clone()), move |is_local_type_1949: bool| {
            let st1 = if is_local_type_1949 {
                crate::check::types::recording::err_fix(&st, &Text::lit("local-escapes"), &b.span, &Text::from(format!("a `{}` cannot leave its block", &block_local_name(&st, &t))), &Text::lit("`Freeze` it into a plain value first"))
            } else {
                st.clone()
            };
            call_then(start_escape_stmts(env.clone(), st1.clone(), b.stmts.clone()), move |escape_stmts_2119: crate::check::types::St| {
                let st2 = escape_stmts_2119;
                call_then(start_frozen_stmts(env.clone(), st2.clone(), b.stmts.clone(), Map::new()), move |frozen_stmts_2175: (Map<Text, Nat>, crate::check::types::St)| {
                    let (_, st3) = frozen_stmts_2175;
                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: st3.clone(), stmts: b.stmts.clone(), lent: Array::new() }))
                })
            })
        })
    }
}

/// `Start AndBlockChecks, x`: what the function value is when passed to `@Run`.
pub fn start_and_block_checks(env: crate::check::expr::Env, st: crate::check::types::St, b: crate::syntax::Block, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(AndBlockChecks { env, st, b, t })
}

/// ```prism
/// BlockLocalName: unbounded fn St, Ty -> Text
/// ```
pub fn block_local_name(st: &crate::check::types::St, t: &crate::check::types::Ty) -> Text {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyCon(n, _) => n,
        _ => Text::lit("Buffer"),
    }
}

/// The step machine of `BlockLocalName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockLocalName: unbounded fn St, Ty -> Text
/// ```
pub struct BlockLocalName {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for BlockLocalName {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_2326: crate::check::types::Ty| match walk_2326 {
            crate::check::types::Ty::TyCon(n, _) => prism_rtl::Turn::Finished(n.clone()),
            _ => prism_rtl::Turn::Finished(Text::lit("Buffer")),
        })
    }
}

/// `Start BlockLocalName, x`: what the function value is when passed to `@Run`.
pub fn start_block_local_name(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(BlockLocalName { st, t })
}

/// ```prism
/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
/// ```
pub fn escape_stmts(env: &crate::check::expr::Env, st: &crate::check::types::St, stmts: &Array<crate::syntax::Stmt>) -> crate::check::types::St {
    run_to_end(fold_job(stmts.clone(), st.clone(), {
        let env = env.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
            let env = env.clone();
            entered(once_job(move || {
                let s = p0;
                let stmt = p1;
                match &stmt.kind {
                    crate::syntax::StmtKind::SLet(p_, _, e) => match &*p_.kind {
                        crate::syntax::PatternKind::PName(n) => if crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")) {
                            prism_rtl::Turn::Finished(s.clone())
                        } else {
                            match get(&env.locals, &crate::check::env::sname_key(n)) {
                                Some(_) => prism_rtl::Turn::Finished(s.clone()),
                                None => if calls_local_maker(&env, e) {
                                    prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s, &Text::lit("local-escapes"), &stmt.span, &Text::from(format!("a `Buffer` cannot leave its block: `{}` is no `&` local", &crate::check::env::sname_key(n))), &Text::from(format!("write `let &{} = ...`", &crate::check::env::sname_key(n)))))
                                } else {
                                    prism_rtl::Turn::Finished(s.clone())
                                },
                            }
                        },
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    },
                    crate::syntax::StmtKind::SWhile(_, body) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone() })),
                    crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                        crate::syntax::ExprKind::EIf(_, tb, eb_opt) => {
                            let eb_opt = eb_opt.clone();
                            let tb = tb.clone();
                            call_then(start_escape_stmts(env.clone(), s.clone(), tb.stmts.clone()), move |escape_stmts_3035: crate::check::types::St| {
                                let s2 = escape_stmts_3035;
                                match &eb_opt {
                                    Some(x) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s2.clone(), stmts: x.stmts.clone() })),
                                    None => prism_rtl::Turn::Finished(s2.clone()),
                                }
                            })
                        },
                        crate::syntax::ExprKind::EMatch(_, arms) => fold_job(arms.clone(), s.clone(), {
                            let env = env.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                let env = env.clone();
                                entered(once_job(move || {
                                    let s3 = p0;
                                    let a = p1;
                                    prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s3.clone(), stmts: a.body.stmts.clone() }))
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle(),
                        crate::syntax::ExprKind::EFor(_, _, body) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone() })),
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    },
                    _ => prism_rtl::Turn::Finished(s.clone()),
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `EscapeStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
/// ```
pub struct EscapeStmts {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<crate::check::types::St> for EscapeStmts {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        fold_job(stmts.clone(), st.clone(), {
            let env = env.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
                let env = env.clone();
                entered(once_job(move || {
                    let s = p0;
                    let stmt = p1;
                    match &stmt.kind {
                        crate::syntax::StmtKind::SLet(p_, _, e) => match &*p_.kind {
                            crate::syntax::PatternKind::PName(n) => if crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")) {
                                prism_rtl::Turn::Finished(s.clone())
                            } else {
                                match get(&env.locals, &crate::check::env::sname_key(n)) {
                                    Some(_) => prism_rtl::Turn::Finished(s.clone()),
                                    None => if calls_local_maker(&env, e) {
                                        prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s, &Text::lit("local-escapes"), &stmt.span, &Text::from(format!("a `Buffer` cannot leave its block: `{}` is no `&` local", &crate::check::env::sname_key(n))), &Text::from(format!("write `let &{} = ...`", &crate::check::env::sname_key(n)))))
                                    } else {
                                        prism_rtl::Turn::Finished(s.clone())
                                    },
                                }
                            },
                            _ => prism_rtl::Turn::Finished(s.clone()),
                        },
                        crate::syntax::StmtKind::SWhile(_, body) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone() })),
                        crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                            crate::syntax::ExprKind::EIf(_, tb, eb_opt) => {
                                let eb_opt = eb_opt.clone();
                                let tb = tb.clone();
                                call_then(start_escape_stmts(env.clone(), s.clone(), tb.stmts.clone()), move |escape_stmts_3035: crate::check::types::St| {
                                    let s2 = escape_stmts_3035;
                                    match &eb_opt {
                                        Some(x) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s2.clone(), stmts: x.stmts.clone() })),
                                        None => prism_rtl::Turn::Finished(s2.clone()),
                                    }
                                })
                            },
                            crate::syntax::ExprKind::EMatch(_, arms) => fold_job(arms.clone(), s.clone(), {
                                let env = env.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                    let env = env.clone();
                                    entered(once_job(move || {
                                        let s3 = p0;
                                        let a = p1;
                                        prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s3.clone(), stmts: a.body.stmts.clone() }))
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }).cycle(),
                            crate::syntax::ExprKind::EFor(_, _, body) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone() })),
                            _ => prism_rtl::Turn::Finished(s.clone()),
                        },
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    }
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start EscapeStmts, x`: what the function value is when passed to `@Run`.
pub fn start_escape_stmts(env: crate::check::expr::Env, st: crate::check::types::St, stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(EscapeStmts { env, st, stmts })
}

/// ```prism
/// CallsLocalMaker: fn Env, Expr -> Bool
/// ```
pub fn calls_local_maker(env: &crate::check::expr::Env, e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::ECall(c, _, _, _) => &maker_of(env, &**c) != &None,
        crate::syntax::ExprKind::EName(_) => match maker_of(env, e) {
            Some(k) => &k != &Text::lit("Buffer.Numbered"),
            None => false,
        },
        crate::syntax::ExprKind::EGroup(x) => calls_local_maker(env, &**x),
        _ => false,
    }
}

/// ```prism
/// ?MakerOf: fn Env, Expr -> ?Text
/// ```
pub fn maker_of(env: &crate::check::expr::Env, c: &crate::syntax::Expr) -> Option<Text> {
    match crate::check::shrink::walk::callee_name(c) {
        Some(n) => if crate::check::env::has_key(&env.locals, &n) {
            None
        } else {
            match crate::check::shrink::locals::resolve_name(&env.g, &env.home, &n) {
                Some(k) => if crate::check::expr::calls::is_local_maker(&k) && (&or(&get(&env.g.vals, &k), &crate::check::dummy_val()).sort == &Text::lit("builtin")) {
                    Some(k.clone())
                } else {
                    None
                },
                None => None,
            }
        },
        None => None,
    }
}

/// ```prism
/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
/// ```
pub fn frozen_stmts(env: &crate::check::expr::Env, st: &crate::check::types::St, stmts: &Array<crate::syntax::Stmt>, frozen: &Map<Text, Nat>) -> (Map<Text, Nat>, crate::check::types::St) {
    let pre = crate::check::shrink::relations::prelude_seeds(&env.g, &env.home);
    let seeds = fold(&keys(&pre), &pre, &(|m: &Map<Text, crate::check::shrink::Rel>, k: &Text| if crate::check::env::has_key(&env.locals, &crate::syntax::lexer::chars::drop_prefix(k, &Text::lit("pre:"))) {
        remove(m, k)
    } else {
        m.clone()
    }));
    let bm = crate::check::shrink::relations::block_rels(stmts, &seeds);
    run_to_end(fold_job(stmts.clone(), (frozen.clone(), st.clone()), {
        let bm = bm.clone();
        let env = env.clone();
        Rc::new(move |(p0, p1): ((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)| {
            let bm = bm.clone();
            let env = env.clone();
            entered(once_job(move || {
                let (fz, s) = p0;
                let stmt = p1;
                call_then(crate::check::shrink::walk::start_stmt_spots(stmt.clone(), bm.clone()), move |stmt_spots_4900: Array<crate::check::shrink::walk::Spot>| {
                    let spots = stmt_spots_4900;
                    let reads = fold(&spots, &Array::new(), &(|acc: &Array<(Text, crate::syntax::Range)>, sp: &crate::check::shrink::walk::Spot| append(acc, &spot_refs(sp))));
                    let s2 = fold(&reads, &s, &(|s1: &crate::check::types::St, (n, sp): &(Text, crate::syntax::Range)| match get(&fz, n) {
                        Some(line) => crate::check::types::recording::err_fix(s1, &Text::lit("frozen"), sp, &Text::from(format!("`{}` was frozen on line {}", n, &(&line + &Nat::from(1u32)))), &Text::lit("use the frozen value, or make a new local")),
                        None => s1.clone(),
                    }));
                    let fz1 = match &stmt.kind {
                        crate::syntax::StmtKind::SLet(p_, _, _) => fold(&crate::check::env::names::pattern_names(p_), &fz, &(|m: &Map<Text, Nat>, n: &Text| remove(m, n))),
                        _ => fz.clone(),
                    };
                    call_value(fold_job(spots.clone(), fz1.clone(), {
                        let env = env.clone();
                        let stmt = stmt.clone();
                        Rc::new(move |(p0, p1): (Map<Text, Nat>, crate::check::shrink::walk::Spot)| {
                            let env = env.clone();
                            let stmt = stmt.clone();
                            entered(once_job(move || {
                                let m = p0;
                                let sp = p1;
                                call_then(start_spot_freezes(sp.clone()), move |spot_freezes_5398: Array<Text>| prism_rtl::Turn::Finished(fold(&spot_freezes_5398, &m, &(|m2: &Map<Text, Nat>, n: &Text| insert(m2, n, &crate::check::errors::cline_of(&env.src.starts, &stmt.span.start))))))
                            }))
                        }) as Rc<dyn Fn((Map<Text, Nat>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
                    }), move |fold_5366: Map<Text, Nat>| {
                        let fz2 = fold_5366;
                        prism_rtl::Turn::Finished((fz2.clone(), s2.clone()))
                    })
                })
            }))
        }) as Rc<dyn Fn(((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)>>>
    }))
}

/// The step machine of `FrozenStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
/// ```
pub struct FrozenStmts {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub stmts: Array<crate::syntax::Stmt>,
    pub frozen: Map<Text, Nat>,
}

impl prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)> for FrozenStmts {
    fn cycle(&self) -> prism_rtl::Turn<(Map<Text, Nat>, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        let frozen = &self.frozen;
        let pre = crate::check::shrink::relations::prelude_seeds(&env.g, &env.home);
        let seeds = fold(&keys(&pre), &pre, &(|m: &Map<Text, crate::check::shrink::Rel>, k: &Text| if crate::check::env::has_key(&env.locals, &crate::syntax::lexer::chars::drop_prefix(k, &Text::lit("pre:"))) {
            remove(m, k)
        } else {
            m.clone()
        }));
        let env = env.clone();
        let frozen = frozen.clone();
        let st = st.clone();
        let stmts = stmts.clone();
        call_then(crate::check::shrink::relations::start_block_rels(stmts.clone(), seeds.clone()), move |block_rels_4806: Map<Text, crate::check::shrink::Rel>| {
            let bm = block_rels_4806;
            fold_job(stmts.clone(), (frozen.clone(), st.clone()), {
                let bm = bm.clone();
                let env = env.clone();
                Rc::new(move |(p0, p1): ((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)| {
                    let bm = bm.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let (fz, s) = p0;
                        let stmt = p1;
                        call_then(crate::check::shrink::walk::start_stmt_spots(stmt.clone(), bm.clone()), move |stmt_spots_4900: Array<crate::check::shrink::walk::Spot>| {
                            let spots = stmt_spots_4900;
                            let reads = fold(&spots, &Array::new(), &(|acc: &Array<(Text, crate::syntax::Range)>, sp: &crate::check::shrink::walk::Spot| append(acc, &spot_refs(sp))));
                            let s2 = fold(&reads, &s, &(|s1: &crate::check::types::St, (n, sp): &(Text, crate::syntax::Range)| match get(&fz, n) {
                                Some(line) => crate::check::types::recording::err_fix(s1, &Text::lit("frozen"), sp, &Text::from(format!("`{}` was frozen on line {}", n, &(&line + &Nat::from(1u32)))), &Text::lit("use the frozen value, or make a new local")),
                                None => s1.clone(),
                            }));
                            let fz1 = match &stmt.kind {
                                crate::syntax::StmtKind::SLet(p_, _, _) => fold(&crate::check::env::names::pattern_names(p_), &fz, &(|m: &Map<Text, Nat>, n: &Text| remove(m, n))),
                                _ => fz.clone(),
                            };
                            call_value(fold_job(spots.clone(), fz1.clone(), {
                                let env = env.clone();
                                let stmt = stmt.clone();
                                Rc::new(move |(p0, p1): (Map<Text, Nat>, crate::check::shrink::walk::Spot)| {
                                    let env = env.clone();
                                    let stmt = stmt.clone();
                                    entered(once_job(move || {
                                        let m = p0;
                                        let sp = p1;
                                        call_then(start_spot_freezes(sp.clone()), move |spot_freezes_5398: Array<Text>| prism_rtl::Turn::Finished(fold(&spot_freezes_5398, &m, &(|m2: &Map<Text, Nat>, n: &Text| insert(m2, n, &crate::check::errors::cline_of(&env.src.starts, &stmt.span.start))))))
                                    }))
                                }) as Rc<dyn Fn((Map<Text, Nat>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
                            }), move |fold_5366: Map<Text, Nat>| {
                                let fz2 = fold_5366;
                                prism_rtl::Turn::Finished((fz2.clone(), s2.clone()))
                            })
                        })
                    }))
                }) as Rc<dyn Fn(((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)>>>
            }).cycle()
        })
    }
}

/// `Start FrozenStmts, x`: what the function value is when passed to `@Run`.
pub fn start_frozen_stmts(env: crate::check::expr::Env, st: crate::check::types::St, stmts: Array<crate::syntax::Stmt>, frozen: Map<Text, Nat>) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)>> {
    Rc::new(FrozenStmts { env, st, stmts, frozen })
}

/// ```prism
/// SpotRefs: fn Spot -> [((Text, Range))]
/// ```
pub fn spot_refs(spot0: &crate::check::shrink::walk::Spot) -> Array<(Text, crate::syntax::Range)> {
    match spot0 {
        crate::check::shrink::walk::Spot::SpotExpr(e, _) => match &*e.kind {
            crate::syntax::ExprKind::EName(n) => if crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")) {
                Array::from(vec![(crate::check::env::sname_key(n), n.span.clone())])
            } else {
                Array::new()
            },
            _ => Array::new(),
        },
        crate::check::shrink::walk::Spot::SpotStmt(_, _) => Array::new(),
    }
}

/// ```prism
/// SpotFreezes: unbounded fn Spot -> [Text]
/// ```
pub fn spot_freezes(spot0: &crate::check::shrink::walk::Spot) -> Array<Text> {
    match spot0 {
        crate::check::shrink::walk::Spot::SpotExpr(e, m) => match crate::check::shrink::walk::call_of(e) {
            Some((c, args)) => match crate::check::shrink::walk::callee_name(&c) {
                Some(n) => if crate::check::shrink::relations::pre_is(m, &n, &Text::lit("Freeze")) {
                    run_to_end(fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Arg)| entered(once_job(move || {
                        let acc = p0;
                        let a = p1;
                        prism_rtl::Turn::Finished(append(&acc, &each(&refs_in(&a.value), &(|(n2, _): &(Text, crate::syntax::Range)| n2.clone()))))
                    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
                } else {
                    Array::new()
                },
                None => Array::new(),
            },
            None => Array::new(),
        },
        crate::check::shrink::walk::Spot::SpotStmt(_, _) => Array::new(),
    }
}

/// The step machine of `SpotFreezes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotFreezes: unbounded fn Spot -> [Text]
/// ```
pub struct SpotFreezes {
    pub spot0: crate::check::shrink::walk::Spot,
}

impl prism_rtl::Job<Array<Text>> for SpotFreezes {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let spot0 = &self.spot0;
        match spot0 {
            crate::check::shrink::walk::Spot::SpotExpr(e, m) => match crate::check::shrink::walk::call_of(e) {
                Some((c, args)) => match crate::check::shrink::walk::callee_name(&c) {
                    Some(n) => if crate::check::shrink::relations::pre_is(m, &n, &Text::lit("Freeze")) {
                        fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Arg)| entered(once_job(move || {
                            let acc = p0;
                            let a = p1;
                            prism_rtl::Turn::Finished(append(&acc, &each(&refs_in(&a.value), &(|(n2, _): &(Text, crate::syntax::Range)| n2.clone()))))
                        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
                    } else {
                        prism_rtl::Turn::Finished(Array::new())
                    },
                    None => prism_rtl::Turn::Finished(Array::new()),
                },
                None => prism_rtl::Turn::Finished(Array::new()),
            },
            crate::check::shrink::walk::Spot::SpotStmt(_, _) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start SpotFreezes, x`: what the function value is when passed to `@Run`.
pub fn start_spot_freezes(spot0: crate::check::shrink::walk::Spot) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotFreezes { spot0 })
}

/// ```prism
/// RefsIn: unbounded fn Expr -> [((Text, Range))]
/// ```
pub fn refs_in(e: &crate::syntax::Expr) -> Array<(Text, crate::syntax::Range)> {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => if crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")) {
            Array::from(vec![(crate::check::env::sname_key(n), n.span.clone())])
        } else {
            Array::new()
        },
        crate::syntax::ExprKind::ECall(c, args, _, _) => run_to_end(fold_job(args.clone(), refs_in(&**c), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Arg)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            prism_rtl::Turn::Finished(append(&acc, &refs_in(&a.value)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::ExprKind::EBinary(_, l, r) => append(&refs_in(&**l), &refs_in(&**r)),
        crate::syntax::ExprKind::EUnary(_, x) => refs_in(&**x),
        crate::syntax::ExprKind::EFreeSigil(_, x) => refs_in(&**x),
        crate::syntax::ExprKind::EField(r, _, _) => refs_in(&**r),
        crate::syntax::ExprKind::EIndex(r, i) => append(&refs_in(&**r), &refs_in(&**i)),
        crate::syntax::ExprKind::EGroup(x) => refs_in(&**x),
        crate::syntax::ExprKind::ETuple(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)| entered(once_job(move || {
            let acc = p0;
            let x = p1;
            prism_rtl::Turn::Finished(append(&acc, &refs_in(&x)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::ExprKind::EArray(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)| entered(once_job(move || {
            let acc = p0;
            let x = p1;
            prism_rtl::Turn::Finished(append(&acc, &refs_in(&x)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        _ => Array::new(),
    }
}

/// ```prism
/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
/// ```
pub fn borrow_stmts(env: &crate::check::expr::Env, st: &crate::check::types::St, stmts: &Array<crate::syntax::Stmt>, lent: &Array<Array<Text>>) -> crate::check::types::St {
    run_to_end(fold_job(stmts.clone(), st.clone(), {
        let env = env.clone();
        let lent = lent.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
            let env = env.clone();
            let lent = lent.clone();
            entered(once_job(move || {
                let s = p0;
                let stmt = p1;
                match &stmt.kind {
                    crate::syntax::StmtKind::SSet(t, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env: env.clone(), st: s.clone(), t: t.clone(), lent: lent.clone() })),
                    crate::syntax::StmtKind::SAccum(t, _, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env: env.clone(), st: s.clone(), t: t.clone(), lent: lent.clone() })),
                    crate::syntax::StmtKind::SWhile(_, body) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone(), lent: lent.clone() })),
                    crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                        crate::syntax::ExprKind::EFor(binders_opt, source, body) => {
                            let binders_opt = binders_opt.clone();
                            let body = body.clone();
                            let source = (**source).clone();
                            call_then(start_ref_path(source.clone()), move |ref_path_7339: Array<Text>| {
                                let path_ = ref_path_7339;
                                let lent2 = if (&len(&path_) > &Nat::from(0u32)) && (&binders_opt != &None) {
                                    push(&lent, &path_)
                                } else {
                                    lent.clone()
                                };
                                prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone(), lent: lent2.clone() }))
                            })
                        },
                        crate::syntax::ExprKind::EIf(_, tb, eb_opt) => {
                            let eb_opt = eb_opt.clone();
                            let tb = tb.clone();
                            call_then(start_borrow_stmts(env.clone(), s.clone(), tb.stmts.clone(), lent.clone()), move |borrow_stmts_7544: crate::check::types::St| {
                                let s2 = borrow_stmts_7544;
                                match &eb_opt {
                                    Some(x) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s2.clone(), stmts: x.stmts.clone(), lent: lent.clone() })),
                                    None => prism_rtl::Turn::Finished(s2.clone()),
                                }
                            })
                        },
                        crate::syntax::ExprKind::EMatch(_, arms) => fold_job(arms.clone(), s.clone(), {
                            let env = env.clone();
                            let lent = lent.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                let env = env.clone();
                                let lent = lent.clone();
                                entered(once_job(move || {
                                    let s3 = p0;
                                    let a = p1;
                                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s3.clone(), stmts: a.body.stmts.clone(), lent: lent.clone() }))
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle(),
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    },
                    _ => prism_rtl::Turn::Finished(s.clone()),
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `BorrowStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
/// ```
pub struct BorrowStmts {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub stmts: Array<crate::syntax::Stmt>,
    pub lent: Array<Array<Text>>,
}

impl prism_rtl::Job<crate::check::types::St> for BorrowStmts {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        let lent = &self.lent;
        fold_job(stmts.clone(), st.clone(), {
            let env = env.clone();
            let lent = lent.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
                let env = env.clone();
                let lent = lent.clone();
                entered(once_job(move || {
                    let s = p0;
                    let stmt = p1;
                    match &stmt.kind {
                        crate::syntax::StmtKind::SSet(t, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env: env.clone(), st: s.clone(), t: t.clone(), lent: lent.clone() })),
                        crate::syntax::StmtKind::SAccum(t, _, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env: env.clone(), st: s.clone(), t: t.clone(), lent: lent.clone() })),
                        crate::syntax::StmtKind::SWhile(_, body) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone(), lent: lent.clone() })),
                        crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                            crate::syntax::ExprKind::EFor(binders_opt, source, body) => {
                                let binders_opt = binders_opt.clone();
                                let body = body.clone();
                                let source = (**source).clone();
                                call_then(start_ref_path(source.clone()), move |ref_path_7339: Array<Text>| {
                                    let path_ = ref_path_7339;
                                    let lent2 = if (&len(&path_) > &Nat::from(0u32)) && (&binders_opt != &None) {
                                        push(&lent, &path_)
                                    } else {
                                        lent.clone()
                                    };
                                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone(), lent: lent2.clone() }))
                                })
                            },
                            crate::syntax::ExprKind::EIf(_, tb, eb_opt) => {
                                let eb_opt = eb_opt.clone();
                                let tb = tb.clone();
                                call_then(start_borrow_stmts(env.clone(), s.clone(), tb.stmts.clone(), lent.clone()), move |borrow_stmts_7544: crate::check::types::St| {
                                    let s2 = borrow_stmts_7544;
                                    match &eb_opt {
                                        Some(x) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s2.clone(), stmts: x.stmts.clone(), lent: lent.clone() })),
                                        None => prism_rtl::Turn::Finished(s2.clone()),
                                    }
                                })
                            },
                            crate::syntax::ExprKind::EMatch(_, arms) => fold_job(arms.clone(), s.clone(), {
                                let env = env.clone();
                                let lent = lent.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                    let env = env.clone();
                                    let lent = lent.clone();
                                    entered(once_job(move || {
                                        let s3 = p0;
                                        let a = p1;
                                        prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s3.clone(), stmts: a.body.stmts.clone(), lent: lent.clone() }))
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }).cycle(),
                            _ => prism_rtl::Turn::Finished(s.clone()),
                        },
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    }
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start BorrowStmts, x`: what the function value is when passed to `@Run`.
pub fn start_borrow_stmts(env: crate::check::expr::Env, st: crate::check::types::St, stmts: Array<crate::syntax::Stmt>, lent: Array<Array<Text>>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(BorrowStmts { env, st, stmts, lent })
}

/// ```prism
/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
/// ```
pub fn check_lent(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::syntax::Expr, lent: &Array<Array<Text>>) -> crate::check::types::St {
    let path_ = ref_path(t);
    fold(lent, st, &(|s: &crate::check::types::St, l: &Array<Text>| if ((&len(&path_) > &Nat::from(0u32)) && is_prefix(l, &path_)) || is_prefix(&path_, l) {
        crate::check::types::recording::err_fix(s, &Text::lit("borrow-overlap"), &t.span, &Text::from(format!("`{}` is lent to the `for`", &crate::syntax::lexer::chars::join(l, &Text::lit(".")))), &Text::lit("set it after the loop, or loop over a copy"))
    } else {
        s.clone()
    }))
}

/// The step machine of `CheckLent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
/// ```
pub struct CheckLent {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Expr,
    pub lent: Array<Array<Text>>,
}

impl prism_rtl::Job<crate::check::types::St> for CheckLent {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let lent = &self.lent;
        let lent = lent.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_ref_path(t.clone()), move |ref_path_7915: Array<Text>| {
            let path_ = ref_path_7915;
            prism_rtl::Turn::Finished(fold(&lent, &st, &(|s: &crate::check::types::St, l: &Array<Text>| if ((&len(&path_) > &Nat::from(0u32)) && is_prefix(l, &path_)) || is_prefix(&path_, l) {
                crate::check::types::recording::err_fix(s, &Text::lit("borrow-overlap"), &t.span, &Text::from(format!("`{}` is lent to the `for`", &crate::syntax::lexer::chars::join(l, &Text::lit(".")))), &Text::lit("set it after the loop, or loop over a copy"))
            } else {
                s.clone()
            })))
        })
    }
}

/// `Start CheckLent, x`: what the function value is when passed to `@Run`.
pub fn start_check_lent(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::syntax::Expr, lent: Array<Array<Text>>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckLent { env, st, t, lent })
}

/// ```prism
/// IsPrefix: fn [Text], [Text] -> Bool
/// ```
pub fn is_prefix(a: &Array<Text>, b: &Array<Text>) -> bool {
    (&len(a) <= &len(b)) && (&take(b, &len(a)) == a)
}

/// ```prism
/// RefPath: unbounded fn Expr -> [Text]
/// ```
pub fn ref_path(e: &crate::syntax::Expr) -> Array<Text> {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => if crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")) {
            Array::from(vec![crate::check::env::sname_key(n)])
        } else {
            Array::new()
        },
        crate::syntax::ExprKind::EField(r, _, f) => {
            let p_ = ref_path(&**r);
            if &len(&p_) > &Nat::from(0u32) { push(&p_, &f.name) } else { p_.clone() }
        },
        crate::syntax::ExprKind::EIndex(r, _) => {
            let p_ = ref_path(&**r);
            if &len(&p_) > &Nat::from(0u32) { push(&p_, &Text::lit("[]")) } else { p_.clone() }
        },
        crate::syntax::ExprKind::EGroup(x) => ref_path(&**x),
        _ => Array::new(),
    }
}

/// The step machine of `RefPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RefPath: unbounded fn Expr -> [Text]
/// ```
pub struct RefPath {
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<Array<Text>> for RefPath {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EName(n) => if crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")) {
                prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::sname_key(n)]))
            } else {
                prism_rtl::Turn::Finished(Array::new())
            },
            crate::syntax::ExprKind::EField(r, _, f) => {
                let f = f.clone();
                let r = (**r).clone();
                call_then(start_ref_path(r.clone()), move |ref_path_8505: Array<Text>| {
                    let p_ = ref_path_8505;
                    if &len(&p_) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(push(&p_, &f.name))
                    } else {
                        prism_rtl::Turn::Finished(p_.clone())
                    }
                })
            },
            crate::syntax::ExprKind::EIndex(r, _) => {
                let r = (**r).clone();
                call_then(start_ref_path(r.clone()), move |ref_path_8600: Array<Text>| {
                    let p_ = ref_path_8600;
                    if &len(&p_) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(push(&p_, &Text::lit("[]")))
                    } else {
                        prism_rtl::Turn::Finished(p_.clone())
                    }
                })
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(RefPath { e: (**x).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start RefPath, x`: what the function value is when passed to `@Run`.
pub fn start_ref_path(e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RefPath { e })
}
