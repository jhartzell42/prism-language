//! The module `Check.Passes.Borrows`, from `target/bootstrap/src/prismc/check/passes/borrows.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// IsLocalType: unbounded fn St, Ty -> Bool
/// ```
pub fn is_local_type(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk(st_p0, t_p1) {
        crate::check::types::Ty::TyCon(m1393_0_0, _) if (&m1393_0_0 == &Text::lit("Buffer")) => true,
        crate::check::types::Ty::TyCon(m1393_1_0, _) if (&m1393_1_0 == &Text::lit("Table")) => true,
        crate::check::types::Ty::TyArray(e_p2) => is_local_type(st_p0, &*e_p2),
        crate::check::types::Ty::TyTuple(ts_p3) => run_to_end(fold_job(ts_p3.clone(), false, {
            let st_p0 = st_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let seen_p4 = p0;
                    let x_p5 = p1;
                    prism_rtl::Turn::Finished(seen_p4 || is_local_type(&st_p0, &x_p5))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyMap(k_p6, v_p7) => is_local_type(st_p0, &*k_p6) || is_local_type(st_p0, &*v_p7),
        crate::check::types::Ty::TySig(_, i_p8) => is_local_type(st_p0, &*i_p8),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `IsLocalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsLocalType: unbounded fn St, Ty -> Bool
/// ```
pub struct IsLocalType {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for IsLocalType {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), t_p1.clone()), move |walk_1399: crate::check::types::Ty| match walk_1399 {
            crate::check::types::Ty::TyCon(m1393_0_0, _) if (&m1393_0_0 == &Text::lit("Buffer")) => prism_rtl::Turn::Finished(true),
            crate::check::types::Ty::TyCon(m1393_1_0, _) if (&m1393_1_0 == &Text::lit("Table")) => prism_rtl::Turn::Finished(true),
            crate::check::types::Ty::TyArray(e_p2) => prism_rtl::Turn::More(Rc::new(IsLocalType { st_p0: st_p0.clone(), t_p1: (*e_p2).clone() })),
            crate::check::types::Ty::TyTuple(ts_p3) => fold_job(ts_p3.clone(), false, {
                let st_p0 = st_p0.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let seen_p4 = p0;
                        let x_p5 = p1;
                        prism_rtl::Turn::Finished(seen_p4 || is_local_type(&st_p0, &x_p5))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::check::types::Ty::TyMap(k_p6, v_p7) => call_then(start_is_local_type(st_p0.clone(), (*k_p6).clone()), move |is_local_type_1595: bool| prism_rtl::Turn::Finished(is_local_type_1595 || is_local_type(&st_p0, &*v_p7))),
            crate::check::types::Ty::TySig(_, i_p8) => prism_rtl::Turn::More(Rc::new(IsLocalType { st_p0: st_p0.clone(), t_p1: (*i_p8).clone() })),
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start IsLocalType, x`: what the function value is when passed to `@Run`.
pub fn start_is_local_type(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsLocalType { st_p0, t_p1 })
}

/// ```prism
/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
/// ```
pub fn and_block_checks(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block, t_p3: &crate::check::types::Ty) -> crate::check::types::St {
    let st1_p4 = if is_local_type(st_p1, t_p3) {
        crate::check::types::recording::err_fix(st_p1, &Text::lit("local-escapes"), &b_p2.span, &Text::from(format!("a `{}` cannot leave its block", &block_local_name(st_p1, t_p3))), &Text::lit("`Freeze` it into a plain value first"))
    } else {
        st_p1.clone()
    };
    let st2_p5 = escape_stmts(env_p0, &st1_p4, &b_p2.stmts);
    let (_, st3_p6) = frozen_stmts(env_p0, &st2_p5, &b_p2.stmts, &Map::new());
    borrow_stmts(env_p0, &st3_p6, &b_p2.stmts, &Array::new())
}

/// The step machine of `AndBlockChecks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
/// ```
pub struct AndBlockChecks {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
    pub t_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for AndBlockChecks {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        let t_p3 = &self.t_p3;
        let b_p2 = b_p2.clone();
        let env_p0 = env_p0.clone();
        let st_p1 = st_p1.clone();
        let t_p3 = t_p3.clone();
        call_then(start_is_local_type(st_p1.clone(), t_p3.clone()), move |is_local_type_1949: bool| {
            let st1_p4 = if is_local_type_1949 {
                crate::check::types::recording::err_fix(&st_p1, &Text::lit("local-escapes"), &b_p2.span, &Text::from(format!("a `{}` cannot leave its block", &block_local_name(&st_p1, &t_p3))), &Text::lit("`Freeze` it into a plain value first"))
            } else {
                st_p1.clone()
            };
            call_then(start_escape_stmts(env_p0.clone(), st1_p4.clone(), b_p2.stmts.clone()), move |escape_stmts_2119: crate::check::types::St| {
                let st2_p5 = escape_stmts_2119;
                call_then(start_frozen_stmts(env_p0.clone(), st2_p5.clone(), b_p2.stmts.clone(), Map::new()), move |frozen_stmts_2175: (Map<Text, Nat>, crate::check::types::St)| {
                    let (_, st3_p6) = frozen_stmts_2175;
                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0.clone(), st_p1: st3_p6.clone(), stmts_p2: b_p2.stmts.clone(), lent_p3: Array::new() }))
                })
            })
        })
    }
}

/// `Start AndBlockChecks, x`: what the function value is when passed to `@Run`.
pub fn start_and_block_checks(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block, t_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(AndBlockChecks { env_p0, st_p1, b_p2, t_p3 })
}

/// ```prism
/// BlockLocalName: unbounded fn St, Ty -> Text
/// ```
pub fn block_local_name(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> Text {
    match crate::check::types::recording::walk(st_p0, t_p1) {
        crate::check::types::Ty::TyCon(n_p2, _) => n_p2,
        _ => Text::lit("Buffer"),
    }
}

/// The step machine of `BlockLocalName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockLocalName: unbounded fn St, Ty -> Text
/// ```
pub struct BlockLocalName {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for BlockLocalName {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), t_p1.clone()), move |walk_2326: crate::check::types::Ty| match walk_2326 {
            crate::check::types::Ty::TyCon(n_p2, _) => prism_rtl::Turn::Finished(n_p2.clone()),
            _ => prism_rtl::Turn::Finished(Text::lit("Buffer")),
        })
    }
}

/// `Start BlockLocalName, x`: what the function value is when passed to `@Run`.
pub fn start_block_local_name(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(BlockLocalName { st_p0, t_p1 })
}

/// ```prism
/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
/// ```
pub fn escape_stmts(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, stmts_p2: &Array<crate::syntax::Stmt>) -> crate::check::types::St {
    run_to_end(fold_job(stmts_p2.clone(), st_p1.clone(), {
        let env_p0 = env_p0.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
            let env_p0 = env_p0.clone();
            entered(once_job(move || {
                let s_p3 = p0;
                let stmt_p4 = p1;
                match &stmt_p4.kind {
                    crate::syntax::StmtKind::SLet(p_p5, _, e_p6) => match &*p_p5.kind {
                        crate::syntax::PatternKind::PName(n_p7) => if crate::syntax::lexer::chars::has_prefix(&n_p7.sigils, &Text::lit("&")) {
                            prism_rtl::Turn::Finished(s_p3.clone())
                        } else {
                            match get(&env_p0.locals, &crate::check::env::sname_key(n_p7)) {
                                Some(_) => prism_rtl::Turn::Finished(s_p3.clone()),
                                None => if calls_local_maker(&env_p0, e_p6) {
                                    prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s_p3, &Text::lit("local-escapes"), &stmt_p4.span, &Text::from(format!("a `Buffer` cannot leave its block: `{}` is no `&` local", &crate::check::env::sname_key(n_p7))), &Text::from(format!("write `let &{} = ...`", &crate::check::env::sname_key(n_p7)))))
                                } else {
                                    prism_rtl::Turn::Finished(s_p3.clone())
                                },
                            }
                        },
                        _ => prism_rtl::Turn::Finished(s_p3.clone()),
                    },
                    crate::syntax::StmtKind::SWhile(_, body_p8) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0.clone(), st_p1: s_p3.clone(), stmts_p2: body_p8.stmts.clone() })),
                    crate::syntax::StmtKind::SExpr(e_p9) => match &*e_p9.kind {
                        crate::syntax::ExprKind::EIf(_, tb_pa, eb_ob) => {
                            let eb_ob = eb_ob.clone();
                            let tb_pa = tb_pa.clone();
                            call_then(start_escape_stmts(env_p0.clone(), s_p3.clone(), tb_pa.stmts.clone()), move |escape_stmts_3035: crate::check::types::St| {
                                let s2_pc = escape_stmts_3035;
                                match &eb_ob {
                                    Some(x_pd) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0.clone(), st_p1: s2_pc.clone(), stmts_p2: x_pd.stmts.clone() })),
                                    None => prism_rtl::Turn::Finished(s2_pc.clone()),
                                }
                            })
                        },
                        crate::syntax::ExprKind::EMatch(_, arms_pe) => fold_job(arms_pe.clone(), s_p3.clone(), {
                            let env_p0 = env_p0.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                let env_p0 = env_p0.clone();
                                entered(once_job(move || {
                                    let s3_pf = p0;
                                    let a_pg = p1;
                                    prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0.clone(), st_p1: s3_pf.clone(), stmts_p2: a_pg.body.stmts.clone() }))
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle(),
                        crate::syntax::ExprKind::EFor(_, _, body_ph) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0.clone(), st_p1: s_p3.clone(), stmts_p2: body_ph.stmts.clone() })),
                        _ => prism_rtl::Turn::Finished(s_p3.clone()),
                    },
                    _ => prism_rtl::Turn::Finished(s_p3.clone()),
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `EscapeStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
/// ```
pub struct EscapeStmts {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub stmts_p2: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<crate::check::types::St> for EscapeStmts {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let stmts_p2 = &self.stmts_p2;
        fold_job(stmts_p2.clone(), st_p1.clone(), {
            let env_p0 = env_p0.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
                let env_p0 = env_p0.clone();
                entered(once_job(move || {
                    let s_p3 = p0;
                    let stmt_p4 = p1;
                    match &stmt_p4.kind {
                        crate::syntax::StmtKind::SLet(p_p5, _, e_p6) => match &*p_p5.kind {
                            crate::syntax::PatternKind::PName(n_p7) => if crate::syntax::lexer::chars::has_prefix(&n_p7.sigils, &Text::lit("&")) {
                                prism_rtl::Turn::Finished(s_p3.clone())
                            } else {
                                match get(&env_p0.locals, &crate::check::env::sname_key(n_p7)) {
                                    Some(_) => prism_rtl::Turn::Finished(s_p3.clone()),
                                    None => if calls_local_maker(&env_p0, e_p6) {
                                        prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s_p3, &Text::lit("local-escapes"), &stmt_p4.span, &Text::from(format!("a `Buffer` cannot leave its block: `{}` is no `&` local", &crate::check::env::sname_key(n_p7))), &Text::from(format!("write `let &{} = ...`", &crate::check::env::sname_key(n_p7)))))
                                    } else {
                                        prism_rtl::Turn::Finished(s_p3.clone())
                                    },
                                }
                            },
                            _ => prism_rtl::Turn::Finished(s_p3.clone()),
                        },
                        crate::syntax::StmtKind::SWhile(_, body_p8) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0.clone(), st_p1: s_p3.clone(), stmts_p2: body_p8.stmts.clone() })),
                        crate::syntax::StmtKind::SExpr(e_p9) => match &*e_p9.kind {
                            crate::syntax::ExprKind::EIf(_, tb_pa, eb_ob) => {
                                let eb_ob = eb_ob.clone();
                                let tb_pa = tb_pa.clone();
                                call_then(start_escape_stmts(env_p0.clone(), s_p3.clone(), tb_pa.stmts.clone()), move |escape_stmts_3035: crate::check::types::St| {
                                    let s2_pc = escape_stmts_3035;
                                    match &eb_ob {
                                        Some(x_pd) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0.clone(), st_p1: s2_pc.clone(), stmts_p2: x_pd.stmts.clone() })),
                                        None => prism_rtl::Turn::Finished(s2_pc.clone()),
                                    }
                                })
                            },
                            crate::syntax::ExprKind::EMatch(_, arms_pe) => fold_job(arms_pe.clone(), s_p3.clone(), {
                                let env_p0 = env_p0.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                    let env_p0 = env_p0.clone();
                                    entered(once_job(move || {
                                        let s3_pf = p0;
                                        let a_pg = p1;
                                        prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0.clone(), st_p1: s3_pf.clone(), stmts_p2: a_pg.body.stmts.clone() }))
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }).cycle(),
                            crate::syntax::ExprKind::EFor(_, _, body_ph) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0.clone(), st_p1: s_p3.clone(), stmts_p2: body_ph.stmts.clone() })),
                            _ => prism_rtl::Turn::Finished(s_p3.clone()),
                        },
                        _ => prism_rtl::Turn::Finished(s_p3.clone()),
                    }
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start EscapeStmts, x`: what the function value is when passed to `@Run`.
pub fn start_escape_stmts(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, stmts_p2: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(EscapeStmts { env_p0, st_p1, stmts_p2 })
}

/// ```prism
/// CallsLocalMaker: fn Env, Expr -> Bool
/// ```
pub fn calls_local_maker(env_p0: &crate::check::expr::Env, e_p1: &crate::syntax::Expr) -> bool {
    match &*e_p1.kind {
        crate::syntax::ExprKind::ECall(c_p2, _, _, _) => &maker_of(env_p0, &**c_p2) != &None,
        crate::syntax::ExprKind::EName(_) => match maker_of(env_p0, e_p1) {
            Some(k_p3) => &k_p3 != &Text::lit("Buffer.Numbered"),
            None => false,
        },
        crate::syntax::ExprKind::EGroup(x_p4) => calls_local_maker(env_p0, &**x_p4),
        _ => false,
    }
}

/// ```prism
/// ?MakerOf: fn Env, Expr -> ?Text
/// ```
pub fn maker_of(env_p0: &crate::check::expr::Env, c_p1: &crate::syntax::Expr) -> Option<Text> {
    match crate::check::shrink::walk::callee_name(c_p1) {
        Some(n_p2) => if crate::check::env::has_key(&env_p0.locals, &n_p2) {
            None
        } else {
            match crate::check::shrink::locals::resolve_name(&env_p0.g, &env_p0.home, &n_p2) {
                Some(k_p3) => if crate::check::expr::calls::is_local_maker(&k_p3) && (&or(&get(&env_p0.g.vals, &k_p3), &crate::check::dummy_val()).sort == &Text::lit("builtin")) {
                    Some(k_p3.clone())
                } else {
                    None
                },
                None => None,
            }
        },
        None => None,
    }
}

/// ```prism
/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
/// ```
pub fn frozen_stmts(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, stmts_p2: &Array<crate::syntax::Stmt>, frozen_p3: &Map<Text, Nat>) -> (Map<Text, Nat>, crate::check::types::St) {
    let pre_p4 = crate::check::shrink::relations::prelude_seeds(&env_p0.g, &env_p0.home);
    let seeds_p5 = fold(&keys(&pre_p4), &pre_p4, &(|m_p7: &Map<Text, crate::check::shrink::Rel>, k_p8: &Text| if crate::check::env::has_key(&env_p0.locals, &crate::syntax::lexer::chars::drop_prefix(k_p8, &Text::lit("pre:"))) {
        remove(m_p7, k_p8)
    } else {
        m_p7.clone()
    }));
    let bm_p6 = crate::check::shrink::relations::block_rels(stmts_p2, &seeds_p5);
    run_to_end(fold_job(stmts_p2.clone(), (frozen_p3.clone(), st_p1.clone()), {
        let bm_p6 = bm_p6.clone();
        let env_p0 = env_p0.clone();
        Rc::new(move |(p0, p1): ((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)| {
            let bm_p6 = bm_p6.clone();
            let env_p0 = env_p0.clone();
            entered(once_job(move || {
                let (fz_p9, s_pa) = p0;
                let stmt_pb = p1;
                call_then(crate::check::shrink::walk::start_stmt_spots(stmt_pb.clone(), bm_p6.clone()), move |stmt_spots_4900: Array<crate::check::shrink::walk::Spot>| {
                    let spots_pc = stmt_spots_4900;
                    let reads_pd = fold(&spots_pc, &Array::new(), &(|acc_ph: &Array<(Text, crate::syntax::Range)>, sp_pi: &crate::check::shrink::walk::Spot| append(acc_ph, &spot_refs(sp_pi))));
                    let s2_pe = fold(&reads_pd, &s_pa, &(|s1_pj: &crate::check::types::St, (n_pk, sp_pl): &(Text, crate::syntax::Range)| match get(&fz_p9, n_pk) {
                        Some(line_pm) => crate::check::types::recording::err_fix(s1_pj, &Text::lit("frozen"), sp_pl, &Text::from(format!("`{}` was frozen on line {}", n_pk, &(&line_pm + &Nat::from(1u32)))), &Text::lit("use the frozen value, or make a new local")),
                        None => s1_pj.clone(),
                    }));
                    let fz1_pf = match &stmt_pb.kind {
                        crate::syntax::StmtKind::SLet(p_pn, _, _) => fold(&crate::check::env::names::pattern_names(p_pn), &fz_p9, &(|m_po: &Map<Text, Nat>, n_pp: &Text| remove(m_po, n_pp))),
                        _ => fz_p9.clone(),
                    };
                    call_value(fold_job(spots_pc.clone(), fz1_pf.clone(), {
                        let env_p0 = env_p0.clone();
                        let stmt_pb = stmt_pb.clone();
                        Rc::new(move |(p0, p1): (Map<Text, Nat>, crate::check::shrink::walk::Spot)| {
                            let env_p0 = env_p0.clone();
                            let stmt_pb = stmt_pb.clone();
                            entered(once_job(move || {
                                let m_pq = p0;
                                let sp_pr = p1;
                                call_then(start_spot_freezes(sp_pr.clone()), move |spot_freezes_5398: Array<Text>| prism_rtl::Turn::Finished(fold(&spot_freezes_5398, &m_pq, &(|m2_ps: &Map<Text, Nat>, n_pt: &Text| insert(m2_ps, n_pt, &crate::check::errors::cline_of(&env_p0.src.starts, &stmt_pb.span.start))))))
                            }))
                        }) as Rc<dyn Fn((Map<Text, Nat>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
                    }), move |fold_5366: Map<Text, Nat>| {
                        let fz2_pg = fold_5366;
                        prism_rtl::Turn::Finished((fz2_pg.clone(), s2_pe.clone()))
                    })
                })
            }))
        }) as Rc<dyn Fn(((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)>>>
    }))
}

/// The step machine of `FrozenStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
/// ```
pub struct FrozenStmts {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub stmts_p2: Array<crate::syntax::Stmt>,
    pub frozen_p3: Map<Text, Nat>,
}

impl prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)> for FrozenStmts {
    fn cycle(&self) -> prism_rtl::Turn<(Map<Text, Nat>, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let stmts_p2 = &self.stmts_p2;
        let frozen_p3 = &self.frozen_p3;
        let pre_p4 = crate::check::shrink::relations::prelude_seeds(&env_p0.g, &env_p0.home);
        let seeds_p5 = fold(&keys(&pre_p4), &pre_p4, &(|m_p7: &Map<Text, crate::check::shrink::Rel>, k_p8: &Text| if crate::check::env::has_key(&env_p0.locals, &crate::syntax::lexer::chars::drop_prefix(k_p8, &Text::lit("pre:"))) {
            remove(m_p7, k_p8)
        } else {
            m_p7.clone()
        }));
        let env_p0 = env_p0.clone();
        let frozen_p3 = frozen_p3.clone();
        let st_p1 = st_p1.clone();
        let stmts_p2 = stmts_p2.clone();
        call_then(crate::check::shrink::relations::start_block_rels(stmts_p2.clone(), seeds_p5.clone()), move |block_rels_4806: Map<Text, crate::check::shrink::Rel>| {
            let bm_p6 = block_rels_4806;
            fold_job(stmts_p2.clone(), (frozen_p3.clone(), st_p1.clone()), {
                let bm_p6 = bm_p6.clone();
                let env_p0 = env_p0.clone();
                Rc::new(move |(p0, p1): ((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)| {
                    let bm_p6 = bm_p6.clone();
                    let env_p0 = env_p0.clone();
                    entered(once_job(move || {
                        let (fz_p9, s_pa) = p0;
                        let stmt_pb = p1;
                        call_then(crate::check::shrink::walk::start_stmt_spots(stmt_pb.clone(), bm_p6.clone()), move |stmt_spots_4900: Array<crate::check::shrink::walk::Spot>| {
                            let spots_pc = stmt_spots_4900;
                            let reads_pd = fold(&spots_pc, &Array::new(), &(|acc_ph: &Array<(Text, crate::syntax::Range)>, sp_pi: &crate::check::shrink::walk::Spot| append(acc_ph, &spot_refs(sp_pi))));
                            let s2_pe = fold(&reads_pd, &s_pa, &(|s1_pj: &crate::check::types::St, (n_pk, sp_pl): &(Text, crate::syntax::Range)| match get(&fz_p9, n_pk) {
                                Some(line_pm) => crate::check::types::recording::err_fix(s1_pj, &Text::lit("frozen"), sp_pl, &Text::from(format!("`{}` was frozen on line {}", n_pk, &(&line_pm + &Nat::from(1u32)))), &Text::lit("use the frozen value, or make a new local")),
                                None => s1_pj.clone(),
                            }));
                            let fz1_pf = match &stmt_pb.kind {
                                crate::syntax::StmtKind::SLet(p_pn, _, _) => fold(&crate::check::env::names::pattern_names(p_pn), &fz_p9, &(|m_po: &Map<Text, Nat>, n_pp: &Text| remove(m_po, n_pp))),
                                _ => fz_p9.clone(),
                            };
                            call_value(fold_job(spots_pc.clone(), fz1_pf.clone(), {
                                let env_p0 = env_p0.clone();
                                let stmt_pb = stmt_pb.clone();
                                Rc::new(move |(p0, p1): (Map<Text, Nat>, crate::check::shrink::walk::Spot)| {
                                    let env_p0 = env_p0.clone();
                                    let stmt_pb = stmt_pb.clone();
                                    entered(once_job(move || {
                                        let m_pq = p0;
                                        let sp_pr = p1;
                                        call_then(start_spot_freezes(sp_pr.clone()), move |spot_freezes_5398: Array<Text>| prism_rtl::Turn::Finished(fold(&spot_freezes_5398, &m_pq, &(|m2_ps: &Map<Text, Nat>, n_pt: &Text| insert(m2_ps, n_pt, &crate::check::errors::cline_of(&env_p0.src.starts, &stmt_pb.span.start))))))
                                    }))
                                }) as Rc<dyn Fn((Map<Text, Nat>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
                            }), move |fold_5366: Map<Text, Nat>| {
                                let fz2_pg = fold_5366;
                                prism_rtl::Turn::Finished((fz2_pg.clone(), s2_pe.clone()))
                            })
                        })
                    }))
                }) as Rc<dyn Fn(((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)>>>
            }).cycle()
        })
    }
}

/// `Start FrozenStmts, x`: what the function value is when passed to `@Run`.
pub fn start_frozen_stmts(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, stmts_p2: Array<crate::syntax::Stmt>, frozen_p3: Map<Text, Nat>) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)>> {
    Rc::new(FrozenStmts { env_p0, st_p1, stmts_p2, frozen_p3 })
}

/// ```prism
/// SpotRefs: fn Spot -> [((Text, Range))]
/// ```
pub fn spot_refs(spot0: &crate::check::shrink::walk::Spot) -> Array<(Text, crate::syntax::Range)> {
    match spot0 {
        crate::check::shrink::walk::Spot::SpotExpr(e_p0, _) => match &*e_p0.kind {
            crate::syntax::ExprKind::EName(n_p1) => if crate::syntax::lexer::chars::has_prefix(&n_p1.sigils, &Text::lit("&")) {
                Array::from(vec![(crate::check::env::sname_key(n_p1), n_p1.span.clone())])
            } else {
                Array::new()
            },
            _ => Array::new(),
        },
        crate::check::shrink::walk::Spot::SpotStmt(_, _) => Array::new(),
    }
}

/// ```prism
/// SpotFreezes: unbounded fn Spot -> [Text]
/// ```
pub fn spot_freezes(spot0: &crate::check::shrink::walk::Spot) -> Array<Text> {
    match spot0 {
        crate::check::shrink::walk::Spot::SpotExpr(e_p0, m_p1) => match crate::check::shrink::walk::call_of(e_p0) {
            Some((c_p2, args_p3)) => match crate::check::shrink::walk::callee_name(&c_p2) {
                Some(n_p4) => if crate::check::shrink::relations::pre_is(m_p1, &n_p4, &Text::lit("Freeze")) {
                    run_to_end(fold_job(args_p3.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Arg)| entered(once_job(move || {
                        let acc_p5 = p0;
                        let a_p6 = p1;
                        prism_rtl::Turn::Finished(append(&acc_p5, &each(&refs_in(&a_p6.value), &(|(n2_p7, _): &(Text, crate::syntax::Range)| n2_p7.clone()))))
                    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
                } else {
                    Array::new()
                },
                None => Array::new(),
            },
            None => Array::new(),
        },
        crate::check::shrink::walk::Spot::SpotStmt(_, _) => Array::new(),
    }
}

/// The step machine of `SpotFreezes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotFreezes: unbounded fn Spot -> [Text]
/// ```
pub struct SpotFreezes {
    pub spot0: crate::check::shrink::walk::Spot,
}

impl prism_rtl::Job<Array<Text>> for SpotFreezes {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let spot0 = &self.spot0;
        match spot0 {
            crate::check::shrink::walk::Spot::SpotExpr(e_p0, m_p1) => match crate::check::shrink::walk::call_of(e_p0) {
                Some((c_p2, args_p3)) => match crate::check::shrink::walk::callee_name(&c_p2) {
                    Some(n_p4) => if crate::check::shrink::relations::pre_is(m_p1, &n_p4, &Text::lit("Freeze")) {
                        fold_job(args_p3.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Arg)| entered(once_job(move || {
                            let acc_p5 = p0;
                            let a_p6 = p1;
                            prism_rtl::Turn::Finished(append(&acc_p5, &each(&refs_in(&a_p6.value), &(|(n2_p7, _): &(Text, crate::syntax::Range)| n2_p7.clone()))))
                        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
                    } else {
                        prism_rtl::Turn::Finished(Array::new())
                    },
                    None => prism_rtl::Turn::Finished(Array::new()),
                },
                None => prism_rtl::Turn::Finished(Array::new()),
            },
            crate::check::shrink::walk::Spot::SpotStmt(_, _) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start SpotFreezes, x`: what the function value is when passed to `@Run`.
pub fn start_spot_freezes(spot0: crate::check::shrink::walk::Spot) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotFreezes { spot0 })
}

/// ```prism
/// RefsIn: unbounded fn Expr -> [((Text, Range))]
/// ```
pub fn refs_in(e_p0: &crate::syntax::Expr) -> Array<(Text, crate::syntax::Range)> {
    match &*e_p0.kind {
        crate::syntax::ExprKind::EName(n_p1) => if crate::syntax::lexer::chars::has_prefix(&n_p1.sigils, &Text::lit("&")) {
            Array::from(vec![(crate::check::env::sname_key(n_p1), n_p1.span.clone())])
        } else {
            Array::new()
        },
        crate::syntax::ExprKind::ECall(c_p2, args_p3, _, _) => run_to_end(fold_job(args_p3.clone(), refs_in(&**c_p2), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Arg)| entered(once_job(move || {
            let acc_p4 = p0;
            let a_p5 = p1;
            prism_rtl::Turn::Finished(append(&acc_p4, &refs_in(&a_p5.value)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::ExprKind::EBinary(_, l_p6, r_p7) => append(&refs_in(&**l_p6), &refs_in(&**r_p7)),
        crate::syntax::ExprKind::EUnary(_, x_p8) => refs_in(&**x_p8),
        crate::syntax::ExprKind::EFreeSigil(_, x_p9) => refs_in(&**x_p9),
        crate::syntax::ExprKind::EField(r_pa, _, _) => refs_in(&**r_pa),
        crate::syntax::ExprKind::EIndex(r_pb, i_pc) => append(&refs_in(&**r_pb), &refs_in(&**i_pc)),
        crate::syntax::ExprKind::EGroup(x_pd) => refs_in(&**x_pd),
        crate::syntax::ExprKind::ETuple(es_pe) => run_to_end(fold_job(es_pe.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)| entered(once_job(move || {
            let acc_pf = p0;
            let x_pg = p1;
            prism_rtl::Turn::Finished(append(&acc_pf, &refs_in(&x_pg)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::ExprKind::EArray(es_ph) => run_to_end(fold_job(es_ph.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)| entered(once_job(move || {
            let acc_pi = p0;
            let x_pj = p1;
            prism_rtl::Turn::Finished(append(&acc_pi, &refs_in(&x_pj)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        _ => Array::new(),
    }
}

/// ```prism
/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
/// ```
pub fn borrow_stmts(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, stmts_p2: &Array<crate::syntax::Stmt>, lent_p3: &Array<Array<Text>>) -> crate::check::types::St {
    run_to_end(fold_job(stmts_p2.clone(), st_p1.clone(), {
        let env_p0 = env_p0.clone();
        let lent_p3 = lent_p3.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
            let env_p0 = env_p0.clone();
            let lent_p3 = lent_p3.clone();
            entered(once_job(move || {
                let s_p4 = p0;
                let stmt_p5 = p1;
                match &stmt_p5.kind {
                    crate::syntax::StmtKind::SSet(t_p6, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env_p0: env_p0.clone(), st_p1: s_p4.clone(), t_p2: t_p6.clone(), lent_p3: lent_p3.clone() })),
                    crate::syntax::StmtKind::SAccum(t_p7, _, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env_p0: env_p0.clone(), st_p1: s_p4.clone(), t_p2: t_p7.clone(), lent_p3: lent_p3.clone() })),
                    crate::syntax::StmtKind::SWhile(_, body_p8) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0.clone(), st_p1: s_p4.clone(), stmts_p2: body_p8.stmts.clone(), lent_p3: lent_p3.clone() })),
                    crate::syntax::StmtKind::SExpr(e_p9) => match &*e_p9.kind {
                        crate::syntax::ExprKind::EFor(binders_oa, source_pb, body_pc) => {
                            let binders_oa = binders_oa.clone();
                            let body_pc = body_pc.clone();
                            let source_pb = (**source_pb).clone();
                            call_then(start_ref_path(source_pb.clone()), move |ref_path_7339: Array<Text>| {
                                let path_pd = ref_path_7339;
                                let lent2_pe = if (&len(&path_pd) > &Nat::from(0u32)) && (&binders_oa != &None) {
                                    push(&lent_p3, &path_pd)
                                } else {
                                    lent_p3.clone()
                                };
                                prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0.clone(), st_p1: s_p4.clone(), stmts_p2: body_pc.stmts.clone(), lent_p3: lent2_pe.clone() }))
                            })
                        },
                        crate::syntax::ExprKind::EIf(_, tb_pf, eb_og) => {
                            let eb_og = eb_og.clone();
                            let tb_pf = tb_pf.clone();
                            call_then(start_borrow_stmts(env_p0.clone(), s_p4.clone(), tb_pf.stmts.clone(), lent_p3.clone()), move |borrow_stmts_7544: crate::check::types::St| {
                                let s2_ph = borrow_stmts_7544;
                                match &eb_og {
                                    Some(x_pi) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0.clone(), st_p1: s2_ph.clone(), stmts_p2: x_pi.stmts.clone(), lent_p3: lent_p3.clone() })),
                                    None => prism_rtl::Turn::Finished(s2_ph.clone()),
                                }
                            })
                        },
                        crate::syntax::ExprKind::EMatch(_, arms_pj) => fold_job(arms_pj.clone(), s_p4.clone(), {
                            let env_p0 = env_p0.clone();
                            let lent_p3 = lent_p3.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                let env_p0 = env_p0.clone();
                                let lent_p3 = lent_p3.clone();
                                entered(once_job(move || {
                                    let s3_pk = p0;
                                    let a_pl = p1;
                                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0.clone(), st_p1: s3_pk.clone(), stmts_p2: a_pl.body.stmts.clone(), lent_p3: lent_p3.clone() }))
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle(),
                        _ => prism_rtl::Turn::Finished(s_p4.clone()),
                    },
                    _ => prism_rtl::Turn::Finished(s_p4.clone()),
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `BorrowStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
/// ```
pub struct BorrowStmts {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub stmts_p2: Array<crate::syntax::Stmt>,
    pub lent_p3: Array<Array<Text>>,
}

impl prism_rtl::Job<crate::check::types::St> for BorrowStmts {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let stmts_p2 = &self.stmts_p2;
        let lent_p3 = &self.lent_p3;
        fold_job(stmts_p2.clone(), st_p1.clone(), {
            let env_p0 = env_p0.clone();
            let lent_p3 = lent_p3.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
                let env_p0 = env_p0.clone();
                let lent_p3 = lent_p3.clone();
                entered(once_job(move || {
                    let s_p4 = p0;
                    let stmt_p5 = p1;
                    match &stmt_p5.kind {
                        crate::syntax::StmtKind::SSet(t_p6, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env_p0: env_p0.clone(), st_p1: s_p4.clone(), t_p2: t_p6.clone(), lent_p3: lent_p3.clone() })),
                        crate::syntax::StmtKind::SAccum(t_p7, _, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env_p0: env_p0.clone(), st_p1: s_p4.clone(), t_p2: t_p7.clone(), lent_p3: lent_p3.clone() })),
                        crate::syntax::StmtKind::SWhile(_, body_p8) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0.clone(), st_p1: s_p4.clone(), stmts_p2: body_p8.stmts.clone(), lent_p3: lent_p3.clone() })),
                        crate::syntax::StmtKind::SExpr(e_p9) => match &*e_p9.kind {
                            crate::syntax::ExprKind::EFor(binders_oa, source_pb, body_pc) => {
                                let binders_oa = binders_oa.clone();
                                let body_pc = body_pc.clone();
                                let source_pb = (**source_pb).clone();
                                call_then(start_ref_path(source_pb.clone()), move |ref_path_7339: Array<Text>| {
                                    let path_pd = ref_path_7339;
                                    let lent2_pe = if (&len(&path_pd) > &Nat::from(0u32)) && (&binders_oa != &None) {
                                        push(&lent_p3, &path_pd)
                                    } else {
                                        lent_p3.clone()
                                    };
                                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0.clone(), st_p1: s_p4.clone(), stmts_p2: body_pc.stmts.clone(), lent_p3: lent2_pe.clone() }))
                                })
                            },
                            crate::syntax::ExprKind::EIf(_, tb_pf, eb_og) => {
                                let eb_og = eb_og.clone();
                                let tb_pf = tb_pf.clone();
                                call_then(start_borrow_stmts(env_p0.clone(), s_p4.clone(), tb_pf.stmts.clone(), lent_p3.clone()), move |borrow_stmts_7544: crate::check::types::St| {
                                    let s2_ph = borrow_stmts_7544;
                                    match &eb_og {
                                        Some(x_pi) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0.clone(), st_p1: s2_ph.clone(), stmts_p2: x_pi.stmts.clone(), lent_p3: lent_p3.clone() })),
                                        None => prism_rtl::Turn::Finished(s2_ph.clone()),
                                    }
                                })
                            },
                            crate::syntax::ExprKind::EMatch(_, arms_pj) => fold_job(arms_pj.clone(), s_p4.clone(), {
                                let env_p0 = env_p0.clone();
                                let lent_p3 = lent_p3.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                    let env_p0 = env_p0.clone();
                                    let lent_p3 = lent_p3.clone();
                                    entered(once_job(move || {
                                        let s3_pk = p0;
                                        let a_pl = p1;
                                        prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0.clone(), st_p1: s3_pk.clone(), stmts_p2: a_pl.body.stmts.clone(), lent_p3: lent_p3.clone() }))
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }).cycle(),
                            _ => prism_rtl::Turn::Finished(s_p4.clone()),
                        },
                        _ => prism_rtl::Turn::Finished(s_p4.clone()),
                    }
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start BorrowStmts, x`: what the function value is when passed to `@Run`.
pub fn start_borrow_stmts(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, stmts_p2: Array<crate::syntax::Stmt>, lent_p3: Array<Array<Text>>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(BorrowStmts { env_p0, st_p1, stmts_p2, lent_p3 })
}

/// ```prism
/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
/// ```
pub fn check_lent(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Expr, lent_p3: &Array<Array<Text>>) -> crate::check::types::St {
    let path_p4 = ref_path(t_p2);
    fold(lent_p3, st_p1, &(|s_p5: &crate::check::types::St, l_p6: &Array<Text>| if ((&len(&path_p4) > &Nat::from(0u32)) && is_prefix(l_p6, &path_p4)) || is_prefix(&path_p4, l_p6) {
        crate::check::types::recording::err_fix(s_p5, &Text::lit("borrow-overlap"), &t_p2.span, &Text::from(format!("`{}` is lent to the `for`", &crate::syntax::lexer::chars::join(l_p6, &Text::lit(".")))), &Text::lit("set it after the loop, or loop over a copy"))
    } else {
        s_p5.clone()
    }))
}

/// The step machine of `CheckLent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
/// ```
pub struct CheckLent {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Expr,
    pub lent_p3: Array<Array<Text>>,
}

impl prism_rtl::Job<crate::check::types::St> for CheckLent {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let lent_p3 = &self.lent_p3;
        let lent_p3 = lent_p3.clone();
        let st_p1 = st_p1.clone();
        let t_p2 = t_p2.clone();
        call_then(start_ref_path(t_p2.clone()), move |ref_path_7915: Array<Text>| {
            let path_p4 = ref_path_7915;
            prism_rtl::Turn::Finished(fold(&lent_p3, &st_p1, &(|s_p5: &crate::check::types::St, l_p6: &Array<Text>| if ((&len(&path_p4) > &Nat::from(0u32)) && is_prefix(l_p6, &path_p4)) || is_prefix(&path_p4, l_p6) {
                crate::check::types::recording::err_fix(s_p5, &Text::lit("borrow-overlap"), &t_p2.span, &Text::from(format!("`{}` is lent to the `for`", &crate::syntax::lexer::chars::join(l_p6, &Text::lit(".")))), &Text::lit("set it after the loop, or loop over a copy"))
            } else {
                s_p5.clone()
            })))
        })
    }
}

/// `Start CheckLent, x`: what the function value is when passed to `@Run`.
pub fn start_check_lent(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::syntax::Expr, lent_p3: Array<Array<Text>>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckLent { env_p0, st_p1, t_p2, lent_p3 })
}

/// ```prism
/// IsPrefix: fn [Text], [Text] -> Bool
/// ```
pub fn is_prefix(a_p0: &Array<Text>, b_p1: &Array<Text>) -> bool {
    (&len(a_p0) <= &len(b_p1)) && (&take(b_p1, &len(a_p0)) == a_p0)
}

/// ```prism
/// RefPath: unbounded fn Expr -> [Text]
/// ```
pub fn ref_path(e_p0: &crate::syntax::Expr) -> Array<Text> {
    match &*e_p0.kind {
        crate::syntax::ExprKind::EName(n_p1) => if crate::syntax::lexer::chars::has_prefix(&n_p1.sigils, &Text::lit("&")) {
            Array::from(vec![crate::check::env::sname_key(n_p1)])
        } else {
            Array::new()
        },
        crate::syntax::ExprKind::EField(r_p2, _, f_p3) => {
            let p_p4 = ref_path(&**r_p2);
            if &len(&p_p4) > &Nat::from(0u32) { push(&p_p4, &f_p3.name) } else { p_p4.clone() }
        },
        crate::syntax::ExprKind::EIndex(r_p5, _) => {
            let p_p6 = ref_path(&**r_p5);
            if &len(&p_p6) > &Nat::from(0u32) {
                push(&p_p6, &Text::lit("[]"))
            } else {
                p_p6.clone()
            }
        },
        crate::syntax::ExprKind::EGroup(x_p7) => ref_path(&**x_p7),
        _ => Array::new(),
    }
}

/// The step machine of `RefPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RefPath: unbounded fn Expr -> [Text]
/// ```
pub struct RefPath {
    pub e_p0: crate::syntax::Expr,
}

impl prism_rtl::Job<Array<Text>> for RefPath {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let e_p0 = &self.e_p0;
        match &*e_p0.kind {
            crate::syntax::ExprKind::EName(n_p1) => if crate::syntax::lexer::chars::has_prefix(&n_p1.sigils, &Text::lit("&")) {
                prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::sname_key(n_p1)]))
            } else {
                prism_rtl::Turn::Finished(Array::new())
            },
            crate::syntax::ExprKind::EField(r_p2, _, f_p3) => {
                let f_p3 = f_p3.clone();
                let r_p2 = (**r_p2).clone();
                call_then(start_ref_path(r_p2.clone()), move |ref_path_8505: Array<Text>| {
                    let p_p4 = ref_path_8505;
                    if &len(&p_p4) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(push(&p_p4, &f_p3.name))
                    } else {
                        prism_rtl::Turn::Finished(p_p4.clone())
                    }
                })
            },
            crate::syntax::ExprKind::EIndex(r_p5, _) => {
                let r_p5 = (**r_p5).clone();
                call_then(start_ref_path(r_p5.clone()), move |ref_path_8600: Array<Text>| {
                    let p_p6 = ref_path_8600;
                    if &len(&p_p6) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(push(&p_p6, &Text::lit("[]")))
                    } else {
                        prism_rtl::Turn::Finished(p_p6.clone())
                    }
                })
            },
            crate::syntax::ExprKind::EGroup(x_p7) => prism_rtl::Turn::More(Rc::new(RefPath { e_p0: (**x_p7).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start RefPath, x`: what the function value is when passed to `@Run`.
pub fn start_ref_path(e_p0: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RefPath { e_p0 })
}
