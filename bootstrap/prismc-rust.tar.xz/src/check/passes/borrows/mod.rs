//! The module `Check.Passes.Borrows`, from `target/bootstrap/src/prismc/check/passes/borrows.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// IsLocalType: unbounded fn St, Ty -> Bool
/// ```
pub fn is_local_type_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TyCon(m1393_0_0, _) if (&m1393_0_0 == &Text::lit("Buffer")) => true,
        crate::check::types::Ty::TyCon(m1393_1_0, _) if (&m1393_1_0 == &Text::lit("Table")) => true,
        crate::check::types::Ty::TyArray(e_p2) => is_local_type_f(st_p0, &*e_p2),
        crate::check::types::Ty::TyTuple(ts_p3) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p3.clone(), false, {
            let st_p0x = st_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_p4 = p0;
                    let x_p5 = p1;
                    prism_rtl::Turn::Finished(seen_p4 || is_local_type_f(&st_p0xy, &x_p5))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyMap(k_p6, v_p7) => is_local_type_f(st_p0, &*k_p6) || is_local_type_f(st_p0, &*v_p7),
        crate::check::types::Ty::TySig(_, i_p8) => is_local_type_f(st_p0, &*i_p8),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `IsLocalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsLocalType: unbounded fn St, Ty -> Bool
/// ```
pub struct IsLocalType {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for IsLocalType {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_1399: crate::check::types::Ty| match walk_f_1399 {
            crate::check::types::Ty::TyCon(m1393_0_0, _) if (&m1393_0_0 == &Text::lit("Buffer")) => prism_rtl::Turn::Finished(true),
            crate::check::types::Ty::TyCon(m1393_1_0, _) if (&m1393_1_0 == &Text::lit("Table")) => prism_rtl::Turn::Finished(true),
            crate::check::types::Ty::TyArray(e_p2) => prism_rtl::Turn::More(Rc::new(IsLocalType { st_p0: st_p0x.clone(), t_p1: (*e_p2).clone() })),
            crate::check::types::Ty::TyTuple(ts_p3) => crate::prelude::fold_job(ts_p3.clone(), false, {
                let st_p0xx = st_p0x.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let seen_p4 = p0;
                        let x_p5 = p1;
                        prism_rtl::Turn::Finished(seen_p4 || is_local_type_f(&st_p0xxy, &x_p5))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::check::types::Ty::TyMap(k_p6, v_p7) => crate::prelude::call_then(start_is_local_type_f(st_p0x.clone(), (*k_p6).clone()), move |is_local_type_f_1595: bool| prism_rtl::Turn::Finished(is_local_type_f_1595 || is_local_type_f(&st_p0x, &*v_p7))),
            crate::check::types::Ty::TySig(_, i_p8) => prism_rtl::Turn::More(Rc::new(IsLocalType { st_p0: st_p0x.clone(), t_p1: (*i_p8).clone() })),
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start IsLocalType, x`: what the function value is when passed to `@Run`.
pub fn start_is_local_type_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsLocalType { st_p0, t_p1 })
}

/// ```prism
/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
/// ```
pub fn and_block_checks_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block, t_p3: &crate::check::types::Ty) -> crate::check::types::St {
    let st1_p4 = if is_local_type_f(st_p1, t_p3) {
        crate::check::types::recording::err_fix_f(st_p1, &Text::lit("local-escapes"), &b_p2.span_p, &Text::from(format!("a `{}` cannot leave its block", &block_local_name_f(st_p1, t_p3))), &Text::lit("`Freeze` it into a plain value first"))
    } else {
        st_p1.clone()
    };
    let st2_p5 = escape_stmts_f(env_p0, &st1_p4, &b_p2.stmts_p);
    let (_, st3_p6) = frozen_stmts_f(env_p0, &st2_p5, &b_p2.stmts_p, &Map::new());
    borrow_stmts_f(env_p0, &st3_p6, &b_p2.stmts_p, &Array::new())
}

/// The step machine of `AndBlockChecks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
/// ```
pub struct AndBlockChecks {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
    pub t_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for AndBlockChecks {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        let t_p3 = &self.t_p3;
        let b_p2x = b_p2.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        let t_p3x = t_p3.clone();
        crate::prelude::call_then(start_is_local_type_f(st_p1x.clone(), t_p3x.clone()), move |is_local_type_f_1949: bool| {
            let st1_p4 = if is_local_type_f_1949 {
                crate::check::types::recording::err_fix_f(&st_p1x, &Text::lit("local-escapes"), &b_p2x.span_p, &Text::from(format!("a `{}` cannot leave its block", &block_local_name_f(&st_p1x, &t_p3x))), &Text::lit("`Freeze` it into a plain value first"))
            } else {
                st_p1x.clone()
            };
            crate::prelude::call_then(start_escape_stmts_f(env_p0x.clone(), st1_p4.clone(), b_p2x.stmts_p.clone()), move |escape_stmts_f_2119: crate::check::types::St| {
                let st2_p5 = escape_stmts_f_2119;
                crate::prelude::call_then(start_frozen_stmts_f(env_p0x.clone(), st2_p5.clone(), b_p2x.stmts_p.clone(), Map::new()), move |frozen_stmts_f_2175: (Map<Text, Nat>, crate::check::types::St)| {
                    let (_, st3_p6) = frozen_stmts_f_2175;
                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0x.clone(), st_p1: st3_p6.clone(), stmts_p2: b_p2x.stmts_p.clone(), lent_p3: Array::new() }))
                })
            })
        })
    }
}

/// `Start AndBlockChecks, x`: what the function value is when passed to `@Run`.
pub fn start_and_block_checks_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block, t_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(AndBlockChecks { env_p0, st_p1, b_p2, t_p3 })
}

/// ```prism
/// BlockLocalName: unbounded fn St, Ty -> Text
/// ```
pub fn block_local_name_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> Text {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TyCon(n_p2, _) => n_p2,
        _ => Text::lit("Buffer"),
    }
}

/// The step machine of `BlockLocalName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockLocalName: unbounded fn St, Ty -> Text
/// ```
pub struct BlockLocalName {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for BlockLocalName {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_2326: crate::check::types::Ty| match walk_f_2326 {
            crate::check::types::Ty::TyCon(n_p2, _) => prism_rtl::Turn::Finished(n_p2.clone()),
            _ => prism_rtl::Turn::Finished(Text::lit("Buffer")),
        })
    }
}

/// `Start BlockLocalName, x`: what the function value is when passed to `@Run`.
pub fn start_block_local_name_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(BlockLocalName { st_p0, t_p1 })
}

/// ```prism
/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
/// ```
pub fn escape_stmts_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, stmts_p2: &Array<crate::syntax::Stmt>) -> crate::check::types::St {
    crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p2.clone(), st_p1.clone(), {
        let env_p0x = env_p0.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
            let env_p0xy = env_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p3 = p0;
                let stmt_p4 = p1;
                match &stmt_p4.kind_p {
                    crate::syntax::StmtKind::SLet(p_p5, _, e_p6) => match &*p_p5.kind_p {
                        crate::syntax::PatternKind::PName(n_p7) => if crate::syntax::lexer::chars::has_prefix_f(&n_p7.sigils_p, &Text::lit("&")) {
                            prism_rtl::Turn::Finished(s_p3.clone())
                        } else {
                            match crate::prelude::get(&env_p0xy.locals_p, &crate::check::env::sname_key_f(n_p7)) {
                                Some(_) => prism_rtl::Turn::Finished(s_p3.clone()),
                                None => if calls_local_maker_f(&env_p0xy, e_p6) {
                                    prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s_p3, &Text::lit("local-escapes"), &stmt_p4.span_p, &Text::from(format!("a `Buffer` cannot leave its block: `{}` is no `&` local", &crate::check::env::sname_key_f(n_p7))), &Text::from(format!("write `let &{} = ...`", &crate::check::env::sname_key_f(n_p7)))))
                                } else {
                                    prism_rtl::Turn::Finished(s_p3.clone())
                                },
                            }
                        },
                        _ => prism_rtl::Turn::Finished(s_p3.clone()),
                    },
                    crate::syntax::StmtKind::SWhile(_, body_p8) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0xy.clone(), st_p1: s_p3.clone(), stmts_p2: body_p8.stmts_p.clone() })),
                    crate::syntax::StmtKind::SExpr(e_p9) => match &*e_p9.kind_p {
                        crate::syntax::ExprKind::EIf(_, tb_pa, eb_ob) => {
                            let eb_obx = eb_ob.clone();
                            let tb_pax = tb_pa.clone();
                            crate::prelude::call_then(start_escape_stmts_f(env_p0xy.clone(), s_p3.clone(), tb_pax.stmts_p.clone()), move |escape_stmts_f_3035: crate::check::types::St| {
                                let s2_pc = escape_stmts_f_3035;
                                match &eb_obx {
                                    Some(x_pd) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0xy.clone(), st_p1: s2_pc.clone(), stmts_p2: x_pd.stmts_p.clone() })),
                                    None => prism_rtl::Turn::Finished(s2_pc.clone()),
                                }
                            })
                        },
                        crate::syntax::ExprKind::EMatch(_, arms_pe) => crate::prelude::fold_job(arms_pe.clone(), s_p3.clone(), {
                            let env_p0xyx = env_p0xy.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                let env_p0xyxy = env_p0xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s3_pf = p0;
                                    let a_pg = p1;
                                    prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0xyxy.clone(), st_p1: s3_pf.clone(), stmts_p2: a_pg.body_p.stmts_p.clone() }))
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle(),
                        crate::syntax::ExprKind::EFor(_, _, body_ph) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0xy.clone(), st_p1: s_p3.clone(), stmts_p2: body_ph.stmts_p.clone() })),
                        _ => prism_rtl::Turn::Finished(s_p3.clone()),
                    },
                    _ => prism_rtl::Turn::Finished(s_p3.clone()),
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `EscapeStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
/// ```
pub struct EscapeStmts {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub stmts_p2: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<crate::check::types::St> for EscapeStmts {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let stmts_p2 = &self.stmts_p2;
        crate::prelude::fold_job(stmts_p2.clone(), st_p1.clone(), {
            let env_p0x = env_p0.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
                let env_p0xy = env_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p3 = p0;
                    let stmt_p4 = p1;
                    match &stmt_p4.kind_p {
                        crate::syntax::StmtKind::SLet(p_p5, _, e_p6) => match &*p_p5.kind_p {
                            crate::syntax::PatternKind::PName(n_p7) => if crate::syntax::lexer::chars::has_prefix_f(&n_p7.sigils_p, &Text::lit("&")) {
                                prism_rtl::Turn::Finished(s_p3.clone())
                            } else {
                                match crate::prelude::get(&env_p0xy.locals_p, &crate::check::env::sname_key_f(n_p7)) {
                                    Some(_) => prism_rtl::Turn::Finished(s_p3.clone()),
                                    None => if calls_local_maker_f(&env_p0xy, e_p6) {
                                        prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s_p3, &Text::lit("local-escapes"), &stmt_p4.span_p, &Text::from(format!("a `Buffer` cannot leave its block: `{}` is no `&` local", &crate::check::env::sname_key_f(n_p7))), &Text::from(format!("write `let &{} = ...`", &crate::check::env::sname_key_f(n_p7)))))
                                    } else {
                                        prism_rtl::Turn::Finished(s_p3.clone())
                                    },
                                }
                            },
                            _ => prism_rtl::Turn::Finished(s_p3.clone()),
                        },
                        crate::syntax::StmtKind::SWhile(_, body_p8) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0xy.clone(), st_p1: s_p3.clone(), stmts_p2: body_p8.stmts_p.clone() })),
                        crate::syntax::StmtKind::SExpr(e_p9) => match &*e_p9.kind_p {
                            crate::syntax::ExprKind::EIf(_, tb_pa, eb_ob) => {
                                let eb_obx = eb_ob.clone();
                                let tb_pax = tb_pa.clone();
                                crate::prelude::call_then(start_escape_stmts_f(env_p0xy.clone(), s_p3.clone(), tb_pax.stmts_p.clone()), move |escape_stmts_f_3035: crate::check::types::St| {
                                    let s2_pc = escape_stmts_f_3035;
                                    match &eb_obx {
                                        Some(x_pd) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0xy.clone(), st_p1: s2_pc.clone(), stmts_p2: x_pd.stmts_p.clone() })),
                                        None => prism_rtl::Turn::Finished(s2_pc.clone()),
                                    }
                                })
                            },
                            crate::syntax::ExprKind::EMatch(_, arms_pe) => crate::prelude::fold_job(arms_pe.clone(), s_p3.clone(), {
                                let env_p0xyx = env_p0xy.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                    let env_p0xyxy = env_p0xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let s3_pf = p0;
                                        let a_pg = p1;
                                        prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0xyxy.clone(), st_p1: s3_pf.clone(), stmts_p2: a_pg.body_p.stmts_p.clone() }))
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }).cycle(),
                            crate::syntax::ExprKind::EFor(_, _, body_ph) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env_p0: env_p0xy.clone(), st_p1: s_p3.clone(), stmts_p2: body_ph.stmts_p.clone() })),
                            _ => prism_rtl::Turn::Finished(s_p3.clone()),
                        },
                        _ => prism_rtl::Turn::Finished(s_p3.clone()),
                    }
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start EscapeStmts, x`: what the function value is when passed to `@Run`.
pub fn start_escape_stmts_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, stmts_p2: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(EscapeStmts { env_p0, st_p1, stmts_p2 })
}

/// ```prism
/// CallsLocalMaker: fn Env, Expr -> Bool
/// ```
pub fn calls_local_maker_f(env_p0: &crate::check::expr::Env, e_p1: &crate::syntax::Expr) -> bool {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::ECall(c_p2, _, _, _) => &maker_of_o(env_p0, &**c_p2) != &None,
        crate::syntax::ExprKind::EName(_) => match maker_of_o(env_p0, e_p1) {
            Some(k_p3) => &k_p3 != &Text::lit("Buffer.Numbered"),
            None => false,
        },
        crate::syntax::ExprKind::EGroup(x_p4) => calls_local_maker_f(env_p0, &**x_p4),
        _ => false,
    }
}

/// ```prism
/// ?MakerOf: fn Env, Expr -> ?Text
/// ```
pub fn maker_of_o(env_p0: &crate::check::expr::Env, c_p1: &crate::syntax::Expr) -> Option<Text> {
    match crate::check::shrink::walk::callee_name_o(c_p1) {
        Some(n_p2) => if crate::check::env::has_key_f(&env_p0.locals_p, &n_p2) {
            None
        } else {
            match crate::check::shrink::locals::resolve_name_o(&env_p0.g_p, &env_p0.home_p, &n_p2) {
                Some(k_p3) => if crate::check::expr::calls::is_local_maker_f(&k_p3) && (&crate::prelude::or(&crate::prelude::get(&env_p0.g_p.vals_p, &k_p3), &crate::check::dummy_val_p()).sort_p == &Text::lit("builtin")) {
                    Some(k_p3.clone())
                } else {
                    None
                },
                None => None,
            }
        },
        None => None,
    }
}

/// ```prism
/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
/// ```
pub fn frozen_stmts_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, stmts_p2: &Array<crate::syntax::Stmt>, frozen_p3: &Map<Text, Nat>) -> (Map<Text, Nat>, crate::check::types::St) {
    let pre_p4 = crate::check::shrink::relations::prelude_seeds_f(&env_p0.g_p, &env_p0.home_p);
    let seeds_p5 = crate::prelude::fold(&crate::prelude::keys(&pre_p4), &pre_p4, &(|m_p7: &Map<Text, crate::check::shrink::Rel>, k_p8: &Text| if crate::check::env::has_key_f(&env_p0.locals_p, &crate::syntax::lexer::chars::drop_prefix_f(k_p8, &Text::lit("pre:"))) {
        crate::prelude::remove(m_p7, k_p8)
    } else {
        m_p7.clone()
    }));
    let bm_p6 = crate::check::shrink::relations::block_rels_f(stmts_p2, &seeds_p5);
    crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p2.clone(), (frozen_p3.clone(), st_p1.clone()), {
        let bm_p6x = bm_p6.clone();
        let env_p0x = env_p0.clone();
        Rc::new(move |(p0, p1): ((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)| {
            let bm_p6xy = bm_p6x.clone();
            let env_p0xy = env_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (fz_p9, s_pa) = p0;
                let stmt_pb = p1;
                crate::prelude::call_then(crate::check::shrink::walk::start_stmt_spots_f(stmt_pb.clone(), bm_p6xy.clone()), move |stmt_spots_f_4900: Array<crate::check::shrink::walk::Spot>| {
                    let spots_pc = stmt_spots_f_4900;
                    let reads_pd = crate::prelude::fold(&spots_pc, &Array::new(), &(|acc_ph: &Array<(Text, crate::syntax::Range)>, sp_pi: &crate::check::shrink::walk::Spot| crate::prelude::append(acc_ph, &spot_refs_f(sp_pi))));
                    let s2_pe = crate::prelude::fold(&reads_pd, &s_pa, &(|s1_pj: &crate::check::types::St, (n_pk, sp_pl): &(Text, crate::syntax::Range)| match crate::prelude::get(&fz_p9, n_pk) {
                        Some(line_pm) => crate::check::types::recording::err_fix_f(s1_pj, &Text::lit("frozen"), sp_pl, &Text::from(format!("`{}` was frozen on line {}", n_pk, &(&line_pm + &Nat::from(1u32)))), &Text::lit("use the frozen value, or make a new local")),
                        None => s1_pj.clone(),
                    }));
                    let fz1_pf = match &stmt_pb.kind_p {
                        crate::syntax::StmtKind::SLet(p_pn, _, _) => crate::prelude::fold(&crate::check::env::names::pattern_names_f(p_pn), &fz_p9, &(|m_po: &Map<Text, Nat>, n_pp: &Text| crate::prelude::remove(m_po, n_pp))),
                        _ => fz_p9.clone(),
                    };
                    crate::prelude::call_value(crate::prelude::fold_job(spots_pc.clone(), fz1_pf.clone(), {
                        let env_p0xyx = env_p0xy.clone();
                        let stmt_pbx = stmt_pb.clone();
                        Rc::new(move |(p0, p1): (Map<Text, Nat>, crate::check::shrink::walk::Spot)| {
                            let env_p0xyxy = env_p0xyx.clone();
                            let stmt_pbxy = stmt_pbx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let m_pq = p0;
                                let sp_pr = p1;
                                crate::prelude::call_then(start_spot_freezes_f(sp_pr.clone()), move |spot_freezes_f_5398: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::fold(&spot_freezes_f_5398, &m_pq, &(|m2_ps: &Map<Text, Nat>, n_pt: &Text| crate::prelude::insert(m2_ps, n_pt, &crate::check::errors::cline_of_f(&env_p0xyxy.src_p.starts_p, &stmt_pbxy.span_p.start_p))))))
                            }))
                        }) as Rc<dyn Fn((Map<Text, Nat>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
                    }), move |fold_5366: Map<Text, Nat>| {
                        let fz2_pg = fold_5366;
                        prism_rtl::Turn::Finished((fz2_pg.clone(), s2_pe.clone()))
                    })
                })
            }))
        }) as Rc<dyn Fn(((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)>>>
    }))
}

/// The step machine of `FrozenStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
/// ```
pub struct FrozenStmts {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub stmts_p2: Array<crate::syntax::Stmt>,
    pub frozen_p3: Map<Text, Nat>,
}

impl prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)> for FrozenStmts {
    fn cycle(&self) -> prism_rtl::Turn<(Map<Text, Nat>, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let stmts_p2 = &self.stmts_p2;
        let frozen_p3 = &self.frozen_p3;
        let pre_p4 = crate::check::shrink::relations::prelude_seeds_f(&env_p0.g_p, &env_p0.home_p);
        let seeds_p5 = crate::prelude::fold(&crate::prelude::keys(&pre_p4), &pre_p4, &(|m_p7: &Map<Text, crate::check::shrink::Rel>, k_p8: &Text| if crate::check::env::has_key_f(&env_p0.locals_p, &crate::syntax::lexer::chars::drop_prefix_f(k_p8, &Text::lit("pre:"))) {
            crate::prelude::remove(m_p7, k_p8)
        } else {
            m_p7.clone()
        }));
        let env_p0x = env_p0.clone();
        let frozen_p3x = frozen_p3.clone();
        let st_p1x = st_p1.clone();
        let stmts_p2x = stmts_p2.clone();
        crate::prelude::call_then(crate::check::shrink::relations::start_block_rels_f(stmts_p2x.clone(), seeds_p5.clone()), move |block_rels_f_4806: Map<Text, crate::check::shrink::Rel>| {
            let bm_p6 = block_rels_f_4806;
            crate::prelude::fold_job(stmts_p2x.clone(), (frozen_p3x.clone(), st_p1x.clone()), {
                let bm_p6x = bm_p6.clone();
                let env_p0xx = env_p0x.clone();
                Rc::new(move |(p0, p1): ((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)| {
                    let bm_p6xy = bm_p6x.clone();
                    let env_p0xxy = env_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (fz_p9, s_pa) = p0;
                        let stmt_pb = p1;
                        crate::prelude::call_then(crate::check::shrink::walk::start_stmt_spots_f(stmt_pb.clone(), bm_p6xy.clone()), move |stmt_spots_f_4900: Array<crate::check::shrink::walk::Spot>| {
                            let spots_pc = stmt_spots_f_4900;
                            let reads_pd = crate::prelude::fold(&spots_pc, &Array::new(), &(|acc_ph: &Array<(Text, crate::syntax::Range)>, sp_pi: &crate::check::shrink::walk::Spot| crate::prelude::append(acc_ph, &spot_refs_f(sp_pi))));
                            let s2_pe = crate::prelude::fold(&reads_pd, &s_pa, &(|s1_pj: &crate::check::types::St, (n_pk, sp_pl): &(Text, crate::syntax::Range)| match crate::prelude::get(&fz_p9, n_pk) {
                                Some(line_pm) => crate::check::types::recording::err_fix_f(s1_pj, &Text::lit("frozen"), sp_pl, &Text::from(format!("`{}` was frozen on line {}", n_pk, &(&line_pm + &Nat::from(1u32)))), &Text::lit("use the frozen value, or make a new local")),
                                None => s1_pj.clone(),
                            }));
                            let fz1_pf = match &stmt_pb.kind_p {
                                crate::syntax::StmtKind::SLet(p_pn, _, _) => crate::prelude::fold(&crate::check::env::names::pattern_names_f(p_pn), &fz_p9, &(|m_po: &Map<Text, Nat>, n_pp: &Text| crate::prelude::remove(m_po, n_pp))),
                                _ => fz_p9.clone(),
                            };
                            crate::prelude::call_value(crate::prelude::fold_job(spots_pc.clone(), fz1_pf.clone(), {
                                let env_p0xxyx = env_p0xxy.clone();
                                let stmt_pbx = stmt_pb.clone();
                                Rc::new(move |(p0, p1): (Map<Text, Nat>, crate::check::shrink::walk::Spot)| {
                                    let env_p0xxyxy = env_p0xxyx.clone();
                                    let stmt_pbxy = stmt_pbx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let m_pq = p0;
                                        let sp_pr = p1;
                                        crate::prelude::call_then(start_spot_freezes_f(sp_pr.clone()), move |spot_freezes_f_5398: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::fold(&spot_freezes_f_5398, &m_pq, &(|m2_ps: &Map<Text, Nat>, n_pt: &Text| crate::prelude::insert(m2_ps, n_pt, &crate::check::errors::cline_of_f(&env_p0xxyxy.src_p.starts_p, &stmt_pbxy.span_p.start_p))))))
                                    }))
                                }) as Rc<dyn Fn((Map<Text, Nat>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
                            }), move |fold_5366: Map<Text, Nat>| {
                                let fz2_pg = fold_5366;
                                prism_rtl::Turn::Finished((fz2_pg.clone(), s2_pe.clone()))
                            })
                        })
                    }))
                }) as Rc<dyn Fn(((Map<Text, Nat>, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)>>>
            }).cycle()
        })
    }
}

/// `Start FrozenStmts, x`: what the function value is when passed to `@Run`.
pub fn start_frozen_stmts_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, stmts_p2: Array<crate::syntax::Stmt>, frozen_p3: Map<Text, Nat>) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, crate::check::types::St)>> {
    Rc::new(FrozenStmts { env_p0, st_p1, stmts_p2, frozen_p3 })
}

/// ```prism
/// SpotRefs: fn Spot -> [((Text, Range))]
/// ```
pub fn spot_refs_f(spot0: &crate::check::shrink::walk::Spot) -> Array<(Text, crate::syntax::Range)> {
    match spot0 {
        crate::check::shrink::walk::Spot::SpotExpr(e_p0, _) => match &*e_p0.kind_p {
            crate::syntax::ExprKind::EName(n_p1) => if crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &Text::lit("&")) {
                Array::from(vec![(crate::check::env::sname_key_f(n_p1), n_p1.span_p.clone())])
            } else {
                Array::new()
            },
            _ => Array::new(),
        },
        crate::check::shrink::walk::Spot::SpotStmt(_, _) => Array::new(),
    }
}

/// ```prism
/// SpotFreezes: unbounded fn Spot -> [Text]
/// ```
pub fn spot_freezes_f(spot0: &crate::check::shrink::walk::Spot) -> Array<Text> {
    match spot0 {
        crate::check::shrink::walk::Spot::SpotExpr(e_p0, m_p1) => match crate::check::shrink::walk::call_of_o(e_p0) {
            Some((c_p2, args_p3)) => match crate::check::shrink::walk::callee_name_o(&c_p2) {
                Some(n_p4) => if crate::check::shrink::relations::pre_is_f(m_p1, &n_p4, &Text::lit("Freeze")) {
                    crate::prelude::run_to_end(crate::prelude::fold_job(args_p3.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Arg)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p5 = p0;
                        let a_p6 = p1;
                        prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &crate::prelude::each(&refs_in_f(&a_p6.value_p), &(|(n2_p7, _): &(Text, crate::syntax::Range)| n2_p7.clone()))))
                    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
                } else {
                    Array::new()
                },
                None => Array::new(),
            },
            None => Array::new(),
        },
        crate::check::shrink::walk::Spot::SpotStmt(_, _) => Array::new(),
    }
}

/// The step machine of `SpotFreezes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotFreezes: unbounded fn Spot -> [Text]
/// ```
pub struct SpotFreezes {
    pub spot0: crate::check::shrink::walk::Spot,
}

impl prism_rtl::Job<Array<Text>> for SpotFreezes {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let spot0 = &self.spot0;
        match spot0 {
            crate::check::shrink::walk::Spot::SpotExpr(e_p0, m_p1) => match crate::check::shrink::walk::call_of_o(e_p0) {
                Some((c_p2, args_p3)) => match crate::check::shrink::walk::callee_name_o(&c_p2) {
                    Some(n_p4) => if crate::check::shrink::relations::pre_is_f(m_p1, &n_p4, &Text::lit("Freeze")) {
                        crate::prelude::fold_job(args_p3.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Arg)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_p5 = p0;
                            let a_p6 = p1;
                            prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &crate::prelude::each(&refs_in_f(&a_p6.value_p), &(|(n2_p7, _): &(Text, crate::syntax::Range)| n2_p7.clone()))))
                        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
                    } else {
                        prism_rtl::Turn::Finished(Array::new())
                    },
                    None => prism_rtl::Turn::Finished(Array::new()),
                },
                None => prism_rtl::Turn::Finished(Array::new()),
            },
            crate::check::shrink::walk::Spot::SpotStmt(_, _) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start SpotFreezes, x`: what the function value is when passed to `@Run`.
pub fn start_spot_freezes_f(spot0: crate::check::shrink::walk::Spot) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotFreezes { spot0 })
}

/// ```prism
/// RefsIn: unbounded fn Expr -> [((Text, Range))]
/// ```
pub fn refs_in_f(e_p0: &crate::syntax::Expr) -> Array<(Text, crate::syntax::Range)> {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::EName(n_p1) => if crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &Text::lit("&")) {
            Array::from(vec![(crate::check::env::sname_key_f(n_p1), n_p1.span_p.clone())])
        } else {
            Array::new()
        },
        crate::syntax::ExprKind::ECall(c_p2, args_p3, _, _) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p3.clone(), refs_in_f(&**c_p2), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Arg)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p4 = p0;
            let a_p5 = p1;
            prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &refs_in_f(&a_p5.value_p)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::ExprKind::EBinary(_, l_p6, r_p7) => crate::prelude::append(&refs_in_f(&**l_p6), &refs_in_f(&**r_p7)),
        crate::syntax::ExprKind::EUnary(_, x_p8) => refs_in_f(&**x_p8),
        crate::syntax::ExprKind::EFreeSigil(_, x_p9) => refs_in_f(&**x_p9),
        crate::syntax::ExprKind::EField(r_pa, _, _) => refs_in_f(&**r_pa),
        crate::syntax::ExprKind::EIndex(r_pb, i_pc) => crate::prelude::append(&refs_in_f(&**r_pb), &refs_in_f(&**i_pc)),
        crate::syntax::ExprKind::EGroup(x_pd) => refs_in_f(&**x_pd),
        crate::syntax::ExprKind::ETuple(es_pe) => crate::prelude::run_to_end(crate::prelude::fold_job(es_pe.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pf = p0;
            let x_pg = p1;
            prism_rtl::Turn::Finished(crate::prelude::append(&acc_pf, &refs_in_f(&x_pg)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::ExprKind::EArray(es_ph) => crate::prelude::run_to_end(crate::prelude::fold_job(es_ph.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pi = p0;
            let x_pj = p1;
            prism_rtl::Turn::Finished(crate::prelude::append(&acc_pi, &refs_in_f(&x_pj)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        _ => Array::new(),
    }
}

/// ```prism
/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
/// ```
pub fn borrow_stmts_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, stmts_p2: &Array<crate::syntax::Stmt>, lent_p3: &Array<Array<Text>>) -> crate::check::types::St {
    crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p2.clone(), st_p1.clone(), {
        let env_p0x = env_p0.clone();
        let lent_p3x = lent_p3.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
            let env_p0xy = env_p0x.clone();
            let lent_p3xy = lent_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p4 = p0;
                let stmt_p5 = p1;
                match &stmt_p5.kind_p {
                    crate::syntax::StmtKind::SSet(t_p6, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env_p0: env_p0xy.clone(), st_p1: s_p4.clone(), t_p2: t_p6.clone(), lent_p3: lent_p3xy.clone() })),
                    crate::syntax::StmtKind::SAccum(t_p7, _, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env_p0: env_p0xy.clone(), st_p1: s_p4.clone(), t_p2: t_p7.clone(), lent_p3: lent_p3xy.clone() })),
                    crate::syntax::StmtKind::SWhile(_, body_p8) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0xy.clone(), st_p1: s_p4.clone(), stmts_p2: body_p8.stmts_p.clone(), lent_p3: lent_p3xy.clone() })),
                    crate::syntax::StmtKind::SExpr(e_p9) => match &*e_p9.kind_p {
                        crate::syntax::ExprKind::EFor(binders_oa, source_pb, body_pc) => {
                            let binders_oax = binders_oa.clone();
                            let body_pcx = body_pc.clone();
                            let source_pbx = (**source_pb).clone();
                            crate::prelude::call_then(start_ref_path_f(source_pbx.clone()), move |ref_path_f_7339: Array<Text>| {
                                let path_pd = ref_path_f_7339;
                                let lent2_pe = if (&crate::prelude::len(&path_pd) > &Nat::from(0u32)) && (&binders_oax != &None) {
                                    crate::prelude::push(&lent_p3xy, &path_pd)
                                } else {
                                    lent_p3xy.clone()
                                };
                                prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0xy.clone(), st_p1: s_p4.clone(), stmts_p2: body_pcx.stmts_p.clone(), lent_p3: lent2_pe.clone() }))
                            })
                        },
                        crate::syntax::ExprKind::EIf(_, tb_pf, eb_og) => {
                            let eb_ogx = eb_og.clone();
                            let tb_pfx = tb_pf.clone();
                            crate::prelude::call_then(start_borrow_stmts_f(env_p0xy.clone(), s_p4.clone(), tb_pfx.stmts_p.clone(), lent_p3xy.clone()), move |borrow_stmts_f_7544: crate::check::types::St| {
                                let s2_ph = borrow_stmts_f_7544;
                                match &eb_ogx {
                                    Some(x_pi) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0xy.clone(), st_p1: s2_ph.clone(), stmts_p2: x_pi.stmts_p.clone(), lent_p3: lent_p3xy.clone() })),
                                    None => prism_rtl::Turn::Finished(s2_ph.clone()),
                                }
                            })
                        },
                        crate::syntax::ExprKind::EMatch(_, arms_pj) => crate::prelude::fold_job(arms_pj.clone(), s_p4.clone(), {
                            let env_p0xyx = env_p0xy.clone();
                            let lent_p3xyx = lent_p3xy.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                let env_p0xyxy = env_p0xyx.clone();
                                let lent_p3xyxy = lent_p3xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s3_pk = p0;
                                    let a_pl = p1;
                                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0xyxy.clone(), st_p1: s3_pk.clone(), stmts_p2: a_pl.body_p.stmts_p.clone(), lent_p3: lent_p3xyxy.clone() }))
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle(),
                        _ => prism_rtl::Turn::Finished(s_p4.clone()),
                    },
                    _ => prism_rtl::Turn::Finished(s_p4.clone()),
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `BorrowStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
/// ```
pub struct BorrowStmts {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub stmts_p2: Array<crate::syntax::Stmt>,
    pub lent_p3: Array<Array<Text>>,
}

impl prism_rtl::Job<crate::check::types::St> for BorrowStmts {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let stmts_p2 = &self.stmts_p2;
        let lent_p3 = &self.lent_p3;
        crate::prelude::fold_job(stmts_p2.clone(), st_p1.clone(), {
            let env_p0x = env_p0.clone();
            let lent_p3x = lent_p3.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Stmt)| {
                let env_p0xy = env_p0x.clone();
                let lent_p3xy = lent_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p4 = p0;
                    let stmt_p5 = p1;
                    match &stmt_p5.kind_p {
                        crate::syntax::StmtKind::SSet(t_p6, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env_p0: env_p0xy.clone(), st_p1: s_p4.clone(), t_p2: t_p6.clone(), lent_p3: lent_p3xy.clone() })),
                        crate::syntax::StmtKind::SAccum(t_p7, _, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env_p0: env_p0xy.clone(), st_p1: s_p4.clone(), t_p2: t_p7.clone(), lent_p3: lent_p3xy.clone() })),
                        crate::syntax::StmtKind::SWhile(_, body_p8) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0xy.clone(), st_p1: s_p4.clone(), stmts_p2: body_p8.stmts_p.clone(), lent_p3: lent_p3xy.clone() })),
                        crate::syntax::StmtKind::SExpr(e_p9) => match &*e_p9.kind_p {
                            crate::syntax::ExprKind::EFor(binders_oa, source_pb, body_pc) => {
                                let binders_oax = binders_oa.clone();
                                let body_pcx = body_pc.clone();
                                let source_pbx = (**source_pb).clone();
                                crate::prelude::call_then(start_ref_path_f(source_pbx.clone()), move |ref_path_f_7339: Array<Text>| {
                                    let path_pd = ref_path_f_7339;
                                    let lent2_pe = if (&crate::prelude::len(&path_pd) > &Nat::from(0u32)) && (&binders_oax != &None) {
                                        crate::prelude::push(&lent_p3xy, &path_pd)
                                    } else {
                                        lent_p3xy.clone()
                                    };
                                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0xy.clone(), st_p1: s_p4.clone(), stmts_p2: body_pcx.stmts_p.clone(), lent_p3: lent2_pe.clone() }))
                                })
                            },
                            crate::syntax::ExprKind::EIf(_, tb_pf, eb_og) => {
                                let eb_ogx = eb_og.clone();
                                let tb_pfx = tb_pf.clone();
                                crate::prelude::call_then(start_borrow_stmts_f(env_p0xy.clone(), s_p4.clone(), tb_pfx.stmts_p.clone(), lent_p3xy.clone()), move |borrow_stmts_f_7544: crate::check::types::St| {
                                    let s2_ph = borrow_stmts_f_7544;
                                    match &eb_ogx {
                                        Some(x_pi) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0xy.clone(), st_p1: s2_ph.clone(), stmts_p2: x_pi.stmts_p.clone(), lent_p3: lent_p3xy.clone() })),
                                        None => prism_rtl::Turn::Finished(s2_ph.clone()),
                                    }
                                })
                            },
                            crate::syntax::ExprKind::EMatch(_, arms_pj) => crate::prelude::fold_job(arms_pj.clone(), s_p4.clone(), {
                                let env_p0xyx = env_p0xy.clone();
                                let lent_p3xyx = lent_p3xy.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                                    let env_p0xyxy = env_p0xyx.clone();
                                    let lent_p3xyxy = lent_p3xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let s3_pk = p0;
                                        let a_pl = p1;
                                        prism_rtl::Turn::More(Rc::new(BorrowStmts { env_p0: env_p0xyxy.clone(), st_p1: s3_pk.clone(), stmts_p2: a_pl.body_p.stmts_p.clone(), lent_p3: lent_p3xyxy.clone() }))
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }).cycle(),
                            _ => prism_rtl::Turn::Finished(s_p4.clone()),
                        },
                        _ => prism_rtl::Turn::Finished(s_p4.clone()),
                    }
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start BorrowStmts, x`: what the function value is when passed to `@Run`.
pub fn start_borrow_stmts_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, stmts_p2: Array<crate::syntax::Stmt>, lent_p3: Array<Array<Text>>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(BorrowStmts { env_p0, st_p1, stmts_p2, lent_p3 })
}

/// ```prism
/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
/// ```
pub fn check_lent_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Expr, lent_p3: &Array<Array<Text>>) -> crate::check::types::St {
    let path_p4 = ref_path_f(t_p2);
    crate::prelude::fold(lent_p3, st_p1, &(|s_p5: &crate::check::types::St, l_p6: &Array<Text>| if ((&crate::prelude::len(&path_p4) > &Nat::from(0u32)) && is_prefix_f(l_p6, &path_p4)) || is_prefix_f(&path_p4, l_p6) {
        crate::check::types::recording::err_fix_f(s_p5, &Text::lit("borrow-overlap"), &t_p2.span_p, &Text::from(format!("`{}` is lent to the `for`", &crate::syntax::lexer::chars::join_f(l_p6, &Text::lit(".")))), &Text::lit("set it after the loop, or loop over a copy"))
    } else {
        s_p5.clone()
    }))
}

/// The step machine of `CheckLent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
/// ```
pub struct CheckLent {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Expr,
    pub lent_p3: Array<Array<Text>>,
}

impl prism_rtl::Job<crate::check::types::St> for CheckLent {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let lent_p3 = &self.lent_p3;
        let lent_p3x = lent_p3.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(start_ref_path_f(t_p2x.clone()), move |ref_path_f_7915: Array<Text>| {
            let path_p4 = ref_path_f_7915;
            prism_rtl::Turn::Finished(crate::prelude::fold(&lent_p3x, &st_p1x, &(|s_p5: &crate::check::types::St, l_p6: &Array<Text>| if ((&crate::prelude::len(&path_p4) > &Nat::from(0u32)) && is_prefix_f(l_p6, &path_p4)) || is_prefix_f(&path_p4, l_p6) {
                crate::check::types::recording::err_fix_f(s_p5, &Text::lit("borrow-overlap"), &t_p2x.span_p, &Text::from(format!("`{}` is lent to the `for`", &crate::syntax::lexer::chars::join_f(l_p6, &Text::lit(".")))), &Text::lit("set it after the loop, or loop over a copy"))
            } else {
                s_p5.clone()
            })))
        })
    }
}

/// `Start CheckLent, x`: what the function value is when passed to `@Run`.
pub fn start_check_lent_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::syntax::Expr, lent_p3: Array<Array<Text>>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckLent { env_p0, st_p1, t_p2, lent_p3 })
}

/// ```prism
/// IsPrefix: fn [Text], [Text] -> Bool
/// ```
pub fn is_prefix_f(a_p0: &Array<Text>, b_p1: &Array<Text>) -> bool {
    (&crate::prelude::len(a_p0) <= &crate::prelude::len(b_p1)) && (&crate::prelude::take(b_p1, &crate::prelude::len(a_p0)) == a_p0)
}

/// ```prism
/// RefPath: unbounded fn Expr -> [Text]
/// ```
pub fn ref_path_f(e_p0: &crate::syntax::Expr) -> Array<Text> {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::EName(n_p1) => if crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &Text::lit("&")) {
            Array::from(vec![crate::check::env::sname_key_f(n_p1)])
        } else {
            Array::new()
        },
        crate::syntax::ExprKind::EField(r_p2, _, f_p3) => {
            let p_p4 = ref_path_f(&**r_p2);
            if &crate::prelude::len(&p_p4) > &Nat::from(0u32) {
                crate::prelude::push(&p_p4, &f_p3.name_p)
            } else {
                p_p4.clone()
            }
        },
        crate::syntax::ExprKind::EIndex(r_p5, _) => {
            let p_p6 = ref_path_f(&**r_p5);
            if &crate::prelude::len(&p_p6) > &Nat::from(0u32) {
                crate::prelude::push(&p_p6, &Text::lit("[]"))
            } else {
                p_p6.clone()
            }
        },
        crate::syntax::ExprKind::EGroup(x_p7) => ref_path_f(&**x_p7),
        _ => Array::new(),
    }
}

/// The step machine of `RefPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RefPath: unbounded fn Expr -> [Text]
/// ```
pub struct RefPath {
    pub e_p0: crate::syntax::Expr,
}

impl prism_rtl::Job<Array<Text>> for RefPath {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let e_p0 = &self.e_p0;
        match &*e_p0.kind_p {
            crate::syntax::ExprKind::EName(n_p1) => if crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &Text::lit("&")) {
                prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::sname_key_f(n_p1)]))
            } else {
                prism_rtl::Turn::Finished(Array::new())
            },
            crate::syntax::ExprKind::EField(r_p2, _, f_p3) => {
                let f_p3x = f_p3.clone();
                let r_p2x = (**r_p2).clone();
                crate::prelude::call_then(start_ref_path_f(r_p2x.clone()), move |ref_path_f_8505: Array<Text>| {
                    let p_p4 = ref_path_f_8505;
                    if &crate::prelude::len(&p_p4) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(crate::prelude::push(&p_p4, &f_p3x.name_p))
                    } else {
                        prism_rtl::Turn::Finished(p_p4.clone())
                    }
                })
            },
            crate::syntax::ExprKind::EIndex(r_p5, _) => {
                let r_p5x = (**r_p5).clone();
                crate::prelude::call_then(start_ref_path_f(r_p5x.clone()), move |ref_path_f_8600: Array<Text>| {
                    let p_p6 = ref_path_f_8600;
                    if &crate::prelude::len(&p_p6) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(crate::prelude::push(&p_p6, &Text::lit("[]")))
                    } else {
                        prism_rtl::Turn::Finished(p_p6.clone())
                    }
                })
            },
            crate::syntax::ExprKind::EGroup(x_p7) => prism_rtl::Turn::More(Rc::new(RefPath { e_p0: (**x_p7).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start RefPath, x`: what the function value is when passed to `@Run`.
pub fn start_ref_path_f(e_p0: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RefPath { e_p0 })
}
