//! The module `Check.Env`, from `target/bootstrap/src/prismc/check/env/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod decls;
pub mod names;
pub mod reading;
pub mod traits;

/// `CtorInfo`:
///
/// ```prism
/// type CtorInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CtorInfo {
    pub name: Text,
    pub owner: Text,
    pub params: Array<Text>,
    pub args: Array<crate::check::types::Ty>,
    pub fields: Array<Text>,
    pub ty: crate::check::types::Ty,
    pub index: Nat,
}

impl Show for CtorInfo {
    fn show(&self, p: &mut Printer) {
        p.record("CtorInfo", &[("name", &self.name), ("owner", &self.owner), ("params", &self.params), ("args", &self.args), ("fields", &self.fields), ("ty", &self.ty), ("index", &self.index)]);
    }
}

impl ToPod for CtorInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("CtorInfo", vec![("name", self.name.to_pod()), ("owner", self.owner.to_pod()), ("params", self.params.to_pod()), ("args", self.args.to_pod()), ("fields", self.fields.to_pod()), ("ty", self.ty.to_pod()), ("index", self.index.to_pod())])
    }
}

impl FromPod for CtorInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CtorInfo { name: FromPod::from_pod(field(p, "name")?)?, owner: FromPod::from_pod(field(p, "owner")?)?, params: FromPod::from_pod(field(p, "params")?)?, args: FromPod::from_pod(field(p, "args")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, index: FromPod::from_pod(field(p, "index")?)? })
    }
}

/// `Def`:
///
/// ```prism
/// type Def = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Def {
    pub qk: Text,
    pub name: Text,
    pub home: Text,
    pub file: Nat,
    pub span: crate::syntax::Range,
    pub body: DefBody,
}

impl Show for Def {
    fn show(&self, p: &mut Printer) {
        p.record("Def", &[("qk", &self.qk), ("name", &self.name), ("home", &self.home), ("file", &self.file), ("span", &self.span), ("body", &self.body)]);
    }
}

impl ToPod for Def {
    fn to_pod(&self) -> Pod {
        Pod::record("Def", vec![("qk", self.qk.to_pod()), ("name", self.name.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod()), ("body", self.body.to_pod())])
    }
}

impl FromPod for Def {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Def { qk: FromPod::from_pod(field(p, "qk")?)?, name: FromPod::from_pod(field(p, "name")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)?, body: FromPod::from_pod(field(p, "body")?)? })
    }
}

/// `DefBody`:
///
/// ```prism
/// type DefBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum DefBody {
    DbFn(Array<crate::syntax::decls::FnClause>),
    DbLet(crate::syntax::decls::LetDecl),
    DbWidget(crate::syntax::decls::WidgetDecl),
    DbMethod(Array<crate::syntax::decls::FnClause>, Text, ImplInfo),
    DbDefault(Array<crate::syntax::decls::FnClause>, Text),
    DbCheck(crate::syntax::decls::CheckDecl),
    DbTest(crate::syntax::decls::TestDecl),
}

impl Show for DefBody {
    fn show(&self, p: &mut Printer) {
        match self {
            DefBody::DbFn(a0) => p.choice("DbFn", &[a0]),
            DefBody::DbLet(a0) => p.choice("DbLet", &[a0]),
            DefBody::DbWidget(a0) => p.choice("DbWidget", &[a0]),
            DefBody::DbMethod(a0, a1, a2) => p.choice("DbMethod", &[a0, a1, a2]),
            DefBody::DbDefault(a0, a1) => p.choice("DbDefault", &[a0, a1]),
            DefBody::DbCheck(a0) => p.choice("DbCheck", &[a0]),
            DefBody::DbTest(a0) => p.choice("DbTest", &[a0]),
        }
    }
}

impl ToPod for DefBody {
    fn to_pod(&self) -> Pod {
        match self {
            DefBody::DbFn(a0) => Pod::Choice("DbFn".into(), vec![a0.to_pod()]),
            DefBody::DbLet(a0) => Pod::Choice("DbLet".into(), vec![a0.to_pod()]),
            DefBody::DbWidget(a0) => Pod::Choice("DbWidget".into(), vec![a0.to_pod()]),
            DefBody::DbMethod(a0, a1, a2) => Pod::Choice("DbMethod".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            DefBody::DbDefault(a0, a1) => Pod::Choice("DbDefault".into(), vec![a0.to_pod(), a1.to_pod()]),
            DefBody::DbCheck(a0) => Pod::Choice("DbCheck".into(), vec![a0.to_pod()]),
            DefBody::DbTest(a0) => Pod::Choice("DbTest".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for DefBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DbFn" && a.len() == 1 => Ok(DefBody::DbFn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbLet" && a.len() == 1 => Ok(DefBody::DbLet(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbWidget" && a.len() == 1 => Ok(DefBody::DbWidget(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbMethod" && a.len() == 3 => Ok(DefBody::DbMethod(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "DbDefault" && a.len() == 2 => Ok(DefBody::DbDefault(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "DbCheck" && a.len() == 1 => Ok(DefBody::DbCheck(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbTest" && a.len() == 1 => Ok(DefBody::DbTest(FromPod::from_pod(&a[0])?)),
            other => mismatch("a DefBody", other),
        }
    }
}

/// `G`:
///
/// ```prism
/// type G = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct G {
    pub mods: Map<Text, ModInfo>,
    pub types: Map<Text, TyInfo>,
    pub ctors: Map<Text, CtorInfo>,
    pub tags: Map<Text, TagInfo>,
    pub families: Map<Text, Array<Text>>,
    pub fam_owner: Map<Text, Text>,
    pub vals: Map<Text, ValInfo>,
    pub traits: Map<Text, TraitInfo>,
    pub impls: Map<Text, Array<ImplInfo>>,
    pub bare: Map<Text, Map<Text, Array<Text>>>,
    pub bare_types: Map<Text, Map<Text, Array<Text>>>,
    pub bare_traits: Map<Text, Map<Text, Array<Text>>>,
    pub srcs: Array<crate::check::errors::Src>,
    pub defs: Array<Def>,
    pub program_row: crate::check::types::Rw,
    pub elem_fams: Array<Text>,
    pub root_module: Option<Text>,
    pub app_root: bool,
    pub fn_at: Map<Text, Nat>,
    pub prelude_from: Nat,
}

impl Show for G {
    fn show(&self, p: &mut Printer) {
        p.record("G", &[("mods", &self.mods), ("types", &self.types), ("ctors", &self.ctors), ("tags", &self.tags), ("families", &self.families), ("fam_owner", &self.fam_owner), ("vals", &self.vals), ("traits", &self.traits), ("impls", &self.impls), ("bare", &self.bare), ("bare_types", &self.bare_types), ("bare_traits", &self.bare_traits), ("srcs", &self.srcs), ("defs", &self.defs), ("program_row", &self.program_row), ("elem_fams", &self.elem_fams), ("root_module", &self.root_module), ("app_root", &self.app_root), ("fn_at", &self.fn_at), ("prelude_from", &self.prelude_from)]);
    }
}

impl ToPod for G {
    fn to_pod(&self) -> Pod {
        Pod::record("G", vec![("mods", self.mods.to_pod()), ("types", self.types.to_pod()), ("ctors", self.ctors.to_pod()), ("tags", self.tags.to_pod()), ("families", self.families.to_pod()), ("fam_owner", self.fam_owner.to_pod()), ("vals", self.vals.to_pod()), ("traits", self.traits.to_pod()), ("impls", self.impls.to_pod()), ("bare", self.bare.to_pod()), ("bare_types", self.bare_types.to_pod()), ("bare_traits", self.bare_traits.to_pod()), ("srcs", self.srcs.to_pod()), ("defs", self.defs.to_pod()), ("program_row", self.program_row.to_pod()), ("elem_fams", self.elem_fams.to_pod()), ("root_module", self.root_module.to_pod()), ("app_root", self.app_root.to_pod()), ("fn_at", self.fn_at.to_pod()), ("prelude_from", self.prelude_from.to_pod())])
    }
}

impl FromPod for G {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(G { mods: FromPod::from_pod(field(p, "mods")?)?, types: FromPod::from_pod(field(p, "types")?)?, ctors: FromPod::from_pod(field(p, "ctors")?)?, tags: FromPod::from_pod(field(p, "tags")?)?, families: FromPod::from_pod(field(p, "families")?)?, fam_owner: FromPod::from_pod(field(p, "fam_owner")?)?, vals: FromPod::from_pod(field(p, "vals")?)?, traits: FromPod::from_pod(field(p, "traits")?)?, impls: FromPod::from_pod(field(p, "impls")?)?, bare: FromPod::from_pod(field(p, "bare")?)?, bare_types: FromPod::from_pod(field(p, "bare_types")?)?, bare_traits: FromPod::from_pod(field(p, "bare_traits")?)?, srcs: FromPod::from_pod(field(p, "srcs")?)?, defs: FromPod::from_pod(field(p, "defs")?)?, program_row: FromPod::from_pod(field(p, "program_row")?)?, elem_fams: FromPod::from_pod(field(p, "elem_fams")?)?, root_module: FromPod::from_pod(field(p, "root_module")?)?, app_root: FromPod::from_pod(field(p, "app_root")?)?, fn_at: FromPod::from_pod(field(p, "fn_at")?)?, prelude_from: FromPod::from_pod(field(p, "prelude_from")?)? })
    }
}

/// `ImplInfo`:
///
/// ```prism
/// type ImplInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ImplInfo {
    pub cls: Text,
    pub head: crate::check::types::Ty,
    pub qs: Array<Text>,
    pub bounds: Array<(Text, Text)>,
    pub home: Text,
    pub file: Nat,
    pub span: crate::syntax::Range,
    pub derived: bool,
    pub assocs: Array<(Text, crate::check::types::Ty)>,
    pub methods: Array<Text>,
}

impl Show for ImplInfo {
    fn show(&self, p: &mut Printer) {
        p.record("ImplInfo", &[("cls", &self.cls), ("head", &self.head), ("qs", &self.qs), ("bounds", &self.bounds), ("home", &self.home), ("file", &self.file), ("span", &self.span), ("derived", &self.derived), ("assocs", &self.assocs), ("methods", &self.methods)]);
    }
}

impl ToPod for ImplInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("ImplInfo", vec![("cls", self.cls.to_pod()), ("head", self.head.to_pod()), ("qs", self.qs.to_pod()), ("bounds", self.bounds.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod()), ("derived", self.derived.to_pod()), ("assocs", self.assocs.to_pod()), ("methods", self.methods.to_pod())])
    }
}

impl FromPod for ImplInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ImplInfo { cls: FromPod::from_pod(field(p, "cls")?)?, head: FromPod::from_pod(field(p, "head")?)?, qs: FromPod::from_pod(field(p, "qs")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)?, derived: FromPod::from_pod(field(p, "derived")?)?, assocs: FromPod::from_pod(field(p, "assocs")?)?, methods: FromPod::from_pod(field(p, "methods")?)? })
    }
}

/// `ModInfo`:
///
/// ```prism
/// type ModInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ModInfo {
    pub name: Text,
    pub file: Nat,
    pub emit_rw: crate::check::types::Rw,
    pub row_var: Text,
    pub uses: Array<(Text, bool)>,
    pub root: bool,
    pub tree: crate::syntax::Module,
}

impl Show for ModInfo {
    fn show(&self, p: &mut Printer) {
        p.record("ModInfo", &[("name", &self.name), ("file", &self.file), ("emit_rw", &self.emit_rw), ("row_var", &self.row_var), ("uses", &self.uses), ("root", &self.root), ("tree", &self.tree)]);
    }
}

impl ToPod for ModInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("ModInfo", vec![("name", self.name.to_pod()), ("file", self.file.to_pod()), ("emit_rw", self.emit_rw.to_pod()), ("row_var", self.row_var.to_pod()), ("uses", self.uses.to_pod()), ("root", self.root.to_pod()), ("tree", self.tree.to_pod())])
    }
}

impl FromPod for ModInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ModInfo { name: FromPod::from_pod(field(p, "name")?)?, file: FromPod::from_pod(field(p, "file")?)?, emit_rw: FromPod::from_pod(field(p, "emit_rw")?)?, row_var: FromPod::from_pod(field(p, "row_var")?)?, uses: FromPod::from_pod(field(p, "uses")?)?, root: FromPod::from_pod(field(p, "root")?)?, tree: FromPod::from_pod(field(p, "tree")?)? })
    }
}

/// `TagInfo`:
///
/// ```prism
/// type TagInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TagInfo {
    pub name: Text,
    pub family: Text,
    pub kind: Text,
    pub out: crate::check::types::Ty,
    pub qs: Array<Text>,
    pub rqs: Array<Text>,
    pub bounds: Array<(Text, Text)>,
    pub fields: Array<(Text, crate::check::types::Ty)>,
    pub home: Text,
    pub file: Nat,
    pub span: crate::syntax::Range,
}

impl Show for TagInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TagInfo", &[("name", &self.name), ("family", &self.family), ("kind", &self.kind), ("out", &self.out), ("qs", &self.qs), ("rqs", &self.rqs), ("bounds", &self.bounds), ("fields", &self.fields), ("home", &self.home), ("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for TagInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TagInfo", vec![("name", self.name.to_pod()), ("family", self.family.to_pod()), ("kind", self.kind.to_pod()), ("out", self.out.to_pod()), ("qs", self.qs.to_pod()), ("rqs", self.rqs.to_pod()), ("bounds", self.bounds.to_pod()), ("fields", self.fields.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TagInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TagInfo { name: FromPod::from_pod(field(p, "name")?)?, family: FromPod::from_pod(field(p, "family")?)?, kind: FromPod::from_pod(field(p, "kind")?)?, out: FromPod::from_pod(field(p, "out")?)?, qs: FromPod::from_pod(field(p, "qs")?)?, rqs: FromPod::from_pod(field(p, "rqs")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TraitInfo`:
///
/// ```prism
/// type TraitInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TraitInfo {
    pub name: Text,
    pub home: Text,
    pub param: Text,
    pub supers: Array<Text>,
    pub methods: Array<Text>,
    pub defaults: Array<Text>,
    pub assocs: Array<Text>,
    pub file: Nat,
    pub span: crate::syntax::Range,
}

impl Show for TraitInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TraitInfo", &[("name", &self.name), ("home", &self.home), ("param", &self.param), ("supers", &self.supers), ("methods", &self.methods), ("defaults", &self.defaults), ("assocs", &self.assocs), ("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for TraitInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TraitInfo", vec![("name", self.name.to_pod()), ("home", self.home.to_pod()), ("param", self.param.to_pod()), ("supers", self.supers.to_pod()), ("methods", self.methods.to_pod()), ("defaults", self.defaults.to_pod()), ("assocs", self.assocs.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TraitInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TraitInfo { name: FromPod::from_pod(field(p, "name")?)?, home: FromPod::from_pod(field(p, "home")?)?, param: FromPod::from_pod(field(p, "param")?)?, supers: FromPod::from_pod(field(p, "supers")?)?, methods: FromPod::from_pod(field(p, "methods")?)?, defaults: FromPod::from_pod(field(p, "defaults")?)?, assocs: FromPod::from_pod(field(p, "assocs")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TyBody`:
///
/// ```prism
/// type TyBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TyBody {
    BRecord(Array<(Text, crate::check::types::Ty)>),
    BChoice(Array<(Text, Array<crate::check::types::Ty>)>),
    BRowKind,
    BAlias(crate::check::types::Ty),
    BOpaque,
    BPrim,
}

impl Show for TyBody {
    fn show(&self, p: &mut Printer) {
        match self {
            TyBody::BRecord(a0) => p.choice("BRecord", &[a0]),
            TyBody::BChoice(a0) => p.choice("BChoice", &[a0]),
            TyBody::BRowKind => p.choice("BRowKind", &[]),
            TyBody::BAlias(a0) => p.choice("BAlias", &[a0]),
            TyBody::BOpaque => p.choice("BOpaque", &[]),
            TyBody::BPrim => p.choice("BPrim", &[]),
        }
    }
}

impl ToPod for TyBody {
    fn to_pod(&self) -> Pod {
        match self {
            TyBody::BRecord(a0) => Pod::Choice("BRecord".into(), vec![a0.to_pod()]),
            TyBody::BChoice(a0) => Pod::Choice("BChoice".into(), vec![a0.to_pod()]),
            TyBody::BRowKind => Pod::Choice("BRowKind".into(), vec![]),
            TyBody::BAlias(a0) => Pod::Choice("BAlias".into(), vec![a0.to_pod()]),
            TyBody::BOpaque => Pod::Choice("BOpaque".into(), vec![]),
            TyBody::BPrim => Pod::Choice("BPrim".into(), vec![]),
        }
    }
}

impl FromPod for TyBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "BRecord" && a.len() == 1 => Ok(TyBody::BRecord(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BChoice" && a.len() == 1 => Ok(TyBody::BChoice(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BRowKind" && a.len() == 0 => Ok(TyBody::BRowKind),
            Pod::Choice(c, a) if &**c == "BAlias" && a.len() == 1 => Ok(TyBody::BAlias(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BOpaque" && a.len() == 0 => Ok(TyBody::BOpaque),
            Pod::Choice(c, a) if &**c == "BPrim" && a.len() == 0 => Ok(TyBody::BPrim),
            other => mismatch("a TyBody", other),
        }
    }
}

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyInfo {
    pub name: Text,
    pub home: Text,
    pub params: Array<Text>,
    pub body: TyBody,
    pub derives: Array<Text>,
    pub file: Nat,
    pub span: crate::syntax::Range,
}

impl Show for TyInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TyInfo", &[("name", &self.name), ("home", &self.home), ("params", &self.params), ("body", &self.body), ("derives", &self.derives), ("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for TyInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TyInfo", vec![("name", self.name.to_pod()), ("home", self.home.to_pod()), ("params", self.params.to_pod()), ("body", self.body.to_pod()), ("derives", self.derives.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TyInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyInfo { name: FromPod::from_pod(field(p, "name")?)?, home: FromPod::from_pod(field(p, "home")?)?, params: FromPod::from_pod(field(p, "params")?)?, body: FromPod::from_pod(field(p, "body")?)?, derives: FromPod::from_pod(field(p, "derives")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `ValInfo`:
///
/// ```prism
/// type ValInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ValInfo {
    pub qk: Text,
    pub scheme: crate::check::types::Scheme,
    pub sort: Text,
    pub has_sig: bool,
    pub home: Text,
    pub file: Nat,
    pub span: crate::syntax::Range,
}

impl Show for ValInfo {
    fn show(&self, p: &mut Printer) {
        p.record("ValInfo", &[("qk", &self.qk), ("scheme", &self.scheme), ("sort", &self.sort), ("has_sig", &self.has_sig), ("home", &self.home), ("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for ValInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("ValInfo", vec![("qk", self.qk.to_pod()), ("scheme", self.scheme.to_pod()), ("sort", self.sort.to_pod()), ("has_sig", self.has_sig.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for ValInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ValInfo { qk: FromPod::from_pod(field(p, "qk")?)?, scheme: FromPod::from_pod(field(p, "scheme")?)?, sort: FromPod::from_pod(field(p, "sort")?)?, has_sig: FromPod::from_pod(field(p, "has_sig")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// ```prism
/// IsRegexType: fn Text -> Bool
/// ```
pub fn is_regex_type(n_p0: &Text) -> bool {
    (n_p0 == &Text::lit("Regex")) || (n_p0 == &Text::lit("RegexReplacement"))
}

/// ```prism
/// IsPrimType: fn Text -> Bool
/// ```
pub fn is_prim_type(n_p0: &Text) -> bool {
    crate::check::types::has_text(&Array::from(vec![Text::lit("Bool"), Text::lit("unit"), Text::lit("Char"), Text::lit("Text"), Text::lit("Nat"), Text::lit("Int"), Text::lit("U8"), Text::lit("Float"), Text::lit("Path"), Text::lit("Duration"), Text::lit("Cursor"), Text::lit("Regex"), Text::lit("RegexReplacement")]), n_p0)
}

/// ```prism
/// QualKey: fn Text, Text -> Text
/// ```
pub fn qual_key(m_p0: &Text, name_p1: &Text) -> Text {
    if m_p0 == &Text::lit("") {
        name_p1.clone()
    } else {
        Text::from(format!("{}.{}", m_p0, name_p1))
    }
}

/// ```prism
/// Dotted: fn [Text] -> Text
/// ```
pub fn dotted(parts_p0: &Array<Text>) -> Text {
    crate::syntax::lexer::chars::join(parts_p0, &Text::lit("."))
}

/// ```prism
/// SNameKey: fn SName -> Text
/// ```
pub fn sname_key(n_p0: &crate::syntax::SName) -> Text {
    Text::from(format!("{}{}", &n_p0.sigils, &dotted(&n_p0.path_)))
}

/// ```prism
/// DefNameText: fn DefName -> Text
/// ```
pub fn def_name_text(def_name0: &crate::syntax::decls::DefName) -> Text {
    match def_name0 {
        crate::syntax::decls::DefName::DefSName(n_p0) => sname_key(n_p0),
        crate::syntax::decls::DefName::DefOp(o_p1, _) => o_p1.clone(),
    }
}

/// ```prism
/// DefNameSpan: fn DefName -> Range
/// ```
pub fn def_name_span(def_name0: &crate::syntax::decls::DefName) -> crate::syntax::Range {
    match def_name0 {
        crate::syntax::decls::DefName::DefSName(n_p0) => n_p0.span.clone(),
        crate::syntax::decls::DefName::DefOp(_, r_p1) => r_p1.clone(),
    }
}

/// ```prism
/// IsLowerText: fn Text -> Bool
/// ```
pub fn is_lower_text(t_p0: &Text) -> bool {
    crate::syntax::lexer::chars::is_lower(&crate::syntax::lexer::chars::head(t_p0))
}

/// ```prism
/// IsUpperText: fn Text -> Bool
/// ```
pub fn is_upper_text(t_p0: &Text) -> bool {
    crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::head(t_p0))
}

/// ```prism
/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
/// ```
pub fn build_g(srcs_p0: &Array<crate::check::errors::Src>, trees_p1: &Array<crate::syntax::Module>) -> (G, crate::check::types::St) {
    let g0_p2 = G { mods: Map::new(), types: Map::new(), ctors: Map::new(), tags: Map::new(), families: Map::new(), fam_owner: Map::new(), vals: Map::new(), traits: Map::new(), impls: Map::new(), bare: Map::new(), bare_types: Map::new(), bare_traits: Map::new(), srcs: srcs_p0.clone(), defs: Array::new(), program_row: crate::check::types::empty_row(), elem_fams: Array::new(), root_module: None, app_root: app_root(srcs_p0, trees_p1), fn_at: Map::new(), prelude_from: len(trees_p1) };
    let st0_p3 = crate::check::types::new_st(&Nat::from(0u32));
    let (g1_pb, st1_pc) = fold(&crate::check::errors::range0(&len(trees_p1)), &(g0_p2.clone(), st0_p3.clone()), &(|(g_p8, st_p9): &(G, crate::check::types::St), i_pa: &Nat| add_module(g_p8, st_p9, i_pa, &or(&index(trees_p1, i_pa), &empty_module()))));
    let g2_p4 = add_builtins(&g1_pb);
    let (g3_pg, st3_ph) = run_to_end(fold_job(keys(&g2_p4.mods), (g2_p4.clone(), st1_pc.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
        let (g_pd, st_pe) = p0;
        let m_pf = p1;
        prism_rtl::Turn::More(Rc::new(crate::check::env::names::CollectNames { g_p0: g_pd.clone(), st_p1: st_pe.clone(), m_p2: m_pf.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let g4_p5 = {
        let mut this: G = g3_pg.clone();
        this.program_row = crate::check::env::names::program_row(&this);
        this
    };
    let (g6_pl, st6_pm) = run_to_end(fold_job(keys(&g4_p5.mods), (g4_p5.clone(), st3_ph.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
        let (g_pi, st_pj) = p0;
        let m_pk = p1;
        prism_rtl::Turn::More(Rc::new(crate::check::env::names::BuildTables { g_p0: g_pi.clone(), st_p1: st_pj.clone(), m_p2: m_pk.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let (g6b_pq, st6b_pr) = run_to_end(fold_job(keys(&g6_pl.mods), (g6_pl.clone(), st6_pm.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
        let (g_pn, st_po) = p0;
        let m_pp = p1;
        prism_rtl::Turn::More(Rc::new(crate::check::env::decls::ConvertTypes { g_p0: g_pn.clone(), st_p1: st_po.clone(), m_p2: m_pp.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let (g7_pv, st7_p10) = run_to_end(fold_job(keys(&g6b_pq.mods), (g6b_pq.clone(), st6b_pr.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
        let (g_ps, st_pt) = p0;
        let m_pu = p1;
        prism_rtl::Turn::More(Rc::new(crate::check::env::decls::ConvertDecls { g_p0: g_ps.clone(), st_p1: st_pt.clone(), m_p2: m_pu.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let g8_p6 = crate::check::env::traits::derived_impls(&g7_pv);
    let st8_p7 = crate::check::env::traits::coherence(&g8_p6, &crate::check::env::traits::derived_dynamics(&g8_p6, &st7_p10));
    (g8_p6.clone(), st8_p7.clone())
}

/// The step machine of `BuildG`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
/// ```
pub struct BuildG {
    pub srcs_p0: Array<crate::check::errors::Src>,
    pub trees_p1: Array<crate::syntax::Module>,
}

impl prism_rtl::Job<(G, crate::check::types::St)> for BuildG {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St)> {
        let srcs_p0 = &self.srcs_p0;
        let trees_p1 = &self.trees_p1;
        let g0_p2 = G { mods: Map::new(), types: Map::new(), ctors: Map::new(), tags: Map::new(), families: Map::new(), fam_owner: Map::new(), vals: Map::new(), traits: Map::new(), impls: Map::new(), bare: Map::new(), bare_types: Map::new(), bare_traits: Map::new(), srcs: srcs_p0.clone(), defs: Array::new(), program_row: crate::check::types::empty_row(), elem_fams: Array::new(), root_module: None, app_root: app_root(srcs_p0, trees_p1), fn_at: Map::new(), prelude_from: len(trees_p1) };
        let st0_p3 = crate::check::types::new_st(&Nat::from(0u32));
        let (g1_pb, st1_pc) = fold(&crate::check::errors::range0(&len(trees_p1)), &(g0_p2.clone(), st0_p3.clone()), &(|(g_p8, st_p9): &(G, crate::check::types::St), i_pa: &Nat| add_module(g_p8, st_p9, i_pa, &or(&index(trees_p1, i_pa), &empty_module()))));
        let g2_p4 = add_builtins(&g1_pb);
        call_value(fold_job(keys(&g2_p4.mods), (g2_p4.clone(), st1_pc.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
            let (g_pd, st_pe) = p0;
            let m_pf = p1;
            prism_rtl::Turn::More(Rc::new(crate::check::env::names::CollectNames { g_p0: g_pd.clone(), st_p1: st_pe.clone(), m_p2: m_pf.clone() }))
        }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_5901: (G, crate::check::types::St)| {
            let (g3_pg, st3_ph) = fold_5901;
            let g4_p5 = {
                let mut this: G = g3_pg.clone();
                this.program_row = crate::check::env::names::program_row(&this);
                this
            };
            call_value(fold_job(keys(&g4_p5.mods), (g4_p5.clone(), st3_ph.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
                let (g_pi, st_pj) = p0;
                let m_pk = p1;
                prism_rtl::Turn::More(Rc::new(crate::check::env::names::BuildTables { g_p0: g_pi.clone(), st_p1: st_pj.clone(), m_p2: m_pk.clone() }))
            }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_6058: (G, crate::check::types::St)| {
                let (g6_pl, st6_pm) = fold_6058;
                call_value(fold_job(keys(&g6_pl.mods), (g6_pl.clone(), st6_pm.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
                    let (g_pn, st_po) = p0;
                    let m_pp = p1;
                    prism_rtl::Turn::More(Rc::new(crate::check::env::decls::ConvertTypes { g_p0: g_pn.clone(), st_p1: st_po.clone(), m_p2: m_pp.clone() }))
                }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_6153: (G, crate::check::types::St)| {
                    let (g6b_pq, st6b_pr) = fold_6153;
                    call_value(fold_job(keys(&g6b_pq.mods), (g6b_pq.clone(), st6b_pr.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
                        let (g_ps, st_pt) = p0;
                        let m_pu = p1;
                        prism_rtl::Turn::More(Rc::new(crate::check::env::decls::ConvertDecls { g_p0: g_ps.clone(), st_p1: st_pt.clone(), m_p2: m_pu.clone() }))
                    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_6247: (G, crate::check::types::St)| {
                        let (g7_pv, st7_p10) = fold_6247;
                        let g8_p6 = crate::check::env::traits::derived_impls(&g7_pv);
                        call_then(crate::check::env::traits::start_coherence(g8_p6.clone(), crate::check::env::traits::derived_dynamics(&g8_p6, &st7_p10)), move |coherence_6365: crate::check::types::St| {
                            let st8_p7 = coherence_6365;
                            prism_rtl::Turn::Finished((g8_p6.clone(), st8_p7.clone()))
                        })
                    })
                })
            })
        })
    }
}

/// `Start BuildG, x`: what the function value is when passed to `@Run`.
pub fn start_build_g(srcs_p0: Array<crate::check::errors::Src>, trees_p1: Array<crate::syntax::Module>) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>> {
    Rc::new(BuildG { srcs_p0, trees_p1 })
}

/// ```prism
/// let emptyModule
/// ```
pub fn empty_module() -> crate::syntax::Module {
    crate::syntax::Module { name: None, emit_row: None, mods: Array::new(), uses: Array::new(), decls: Array::new(), template: None, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// ModName: fn Module -> Text
/// ```
pub fn mod_name(m_p0: &crate::syntax::Module) -> Text {
    match &m_p0.name {
        Some(q_p1) => dotted(&q_p1.path_),
        None => Text::lit(""),
    }
}

/// ```prism
/// AppRoot: fn [Src], [Module] -> Bool
/// ```
pub fn app_root(srcs_p0: &Array<crate::check::errors::Src>, trees_p1: &Array<crate::syntax::Module>) -> bool {
    fold(&crate::check::errors::range0(&len(trees_p1)), &false, &(|seen_p2: &bool, i_p3: &Nat| {
        let t_p4 = or(&index(trees_p1, i_p3), &empty_module());
        let name_p5 = mod_name(&t_p4);
        if &name_p5 == &Text::lit("App") {
            false
        } else {
            if (&name_p5 == &Text::lit("")) && (&crate::check::errors::seg_at(&or(&index(srcs_p0, i_p3), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))), &Nat::from(0u32)).role != &Text::lit("loose")) {
                true
            } else {
                *seen_p2
            }
        }
    }))
}

/// ```prism
/// UseName: fn G, Text -> Text
/// ```
pub fn use_name(g_p0: &G, u_p1: &Text) -> Text {
    if g_p0.app_root && (u_p1 == &Text::lit("App")) { Text::lit("") } else { u_p1.clone() }
}

/// ```prism
/// QualModule: fn G, [Text] -> Text
/// ```
pub fn qual_module(g_p0: &G, parts_p1: &Array<Text>) -> Text {
    use_name(g_p0, &dotted(parts_p1))
}

/// ```prism
/// AddModule: fn G, St, Nat, Module -> ((G, St))
/// ```
pub fn add_module(g_p0: &G, st_p1: &crate::check::types::St, i_p2: &Nat, tree_p3: &crate::syntax::Module) -> (G, crate::check::types::St) {
    let name_p4 = mod_name(tree_p3);
    let s_p5 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.file = i_p2.clone();
        this
    };
    if has_key(&g_p0.mods, &name_p4) {
        {
            let what_p6 = if &name_p4 == &Text::lit("") {
                Text::lit("two files have no `module` line")
            } else {
                Text::from(format!("two files declare `module {}`", &name_p4))
            };
            (g_p0.clone(), crate::check::types::recording::err(&s_p5, &Text::lit("collision"), &tree_p3.span, &what_p6))
        }
    } else {
        {
            let info_p7 = ModInfo { name: name_p4.clone(), file: i_p2.clone(), emit_rw: crate::check::types::empty_row(), row_var: Text::lit(""), uses: each(&tree_p3.uses, &(|u_p9: &crate::syntax::Use| (use_name(g_p0, &dotted(&u_p9.target.path_)), u_p9.star))), root: &name_p4 == &Text::lit(""), tree: tree_p3.clone() };
            let g2_p8 = {
                let mut this: G = g_p0.clone();
                this.mods = insert(&this.mods, &name_p4, &info_p7);
                if &name_p4 == &Text::lit("") {
                    this.root_module = Some(Text::lit(""));
                }
                this
            };
            (g2_p8.clone(), s_p5.clone())
        }
    }
}

/// ```prism
/// HasKey: fn (Text ==> a), Text -> Bool
/// ```
pub fn has_key<A: Clone + 'static>(m_p0: &Map<Text, A>, k_p1: &Text) -> bool {
    match get(m_p0, k_p1) {
        Some(_) => true,
        None => false,
    }
}

/// ```prism
/// AddBuiltins: fn G -> G
/// ```
pub fn add_builtins(g_p0: &G) -> G {
    let bool_ctor_f1 = Rc::new(move |n_p6: &Text, i_p7: &Nat| CtorInfo { name: n_p6.clone(), owner: Text::lit("Bool"), params: Array::new(), args: Array::new(), fields: Array::new(), ty: crate::check::types::t_bool(), index: i_p7.clone() }) as Rc<dyn Fn(&Text, &Nat) -> CtorInfo>;
    let pre_p2 = crate::check::types::Scheme { qs: Array::from(vec![Text::lit("a")]), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(crate::check::types::Ty::TyQ(Text::lit("a")))) };
    let numbered_p3 = crate::check::types::schemes::mono(&crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, Array::from(vec![crate::check::types::t_nat()]), Rc::new(crate::check::types::Ty::TyCon(Text::lit("Buffer"), Array::from(vec![crate::check::types::t_nat()])))));
    let buf_empty_p4 = crate::check::types::Scheme { qs: Array::from(vec![Text::lit("a")]), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: crate::check::types::Ty::TyCon(Text::lit("Buffer"), Array::from(vec![crate::check::types::Ty::TyQ(Text::lit("a"))])) };
    let tab_empty_p5 = crate::check::types::Scheme { qs: Array::from(vec![Text::lit("k"), Text::lit("v")]), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: crate::check::types::Ty::TyCon(Text::lit("Table"), Array::from(vec![crate::check::types::Ty::TyQ(Text::lit("k")), crate::check::types::Ty::TyQ(Text::lit("v"))])) };
    let mut this: G = g_p0.clone();
    this.ctors = insert(&insert(&this.ctors, &Text::lit("True"), &(&bool_ctor_f1)(&Text::lit("True"), &Nat::from(0u32))), &Text::lit("False"), &(&bool_ctor_f1)(&Text::lit("False"), &Nat::from(1u32)));
    this.vals = insert(&this.vals, &Text::lit("Prelude.never"), &builtin(&Text::lit("Prelude.never"), &pre_p2));
    this.vals = insert(&this.vals, &Text::lit("Buffer.Numbered"), &builtin(&Text::lit("Buffer.Numbered"), &numbered_p3));
    this.vals = insert(&this.vals, &Text::lit("Buffer.Empty"), &builtin(&Text::lit("Buffer.Empty"), &buf_empty_p4));
    this.vals = insert(&this.vals, &Text::lit("Table.Empty"), &builtin(&Text::lit("Table.Empty"), &tab_empty_p5));
    this
}

/// ```prism
/// Builtin: fn Text, Scheme -> ValInfo
/// ```
pub fn builtin(qk_p0: &Text, sc_p1: &crate::check::types::Scheme) -> ValInfo {
    ValInfo { qk: qk_p0.clone(), scheme: sc_p1.clone(), sort: Text::lit("builtin"), has_sig: true, home: Text::lit("Prelude"), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}
