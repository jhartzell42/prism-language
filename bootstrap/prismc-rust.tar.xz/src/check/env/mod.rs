//! The module `Check.Env`, from `target/bootstrap/src/prismc/check/env/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `CtorInfo`:
///
/// ```prism
/// type CtorInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CtorInfo {
    pub name: Text,
    pub owner: Text,
    pub params: Array<Text>,
    pub args: Array<crate::check::types::Ty>,
    pub fields: Array<Text>,
    pub ty: crate::check::types::Ty,
    pub index: Nat,
}

impl Show for CtorInfo {
    fn show(&self, p: &mut Printer) {
        p.record("CtorInfo", &[("name", &self.name), ("owner", &self.owner), ("params", &self.params), ("args", &self.args), ("fields", &self.fields), ("ty", &self.ty), ("index", &self.index)]);
    }
}

impl ToPod for CtorInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("CtorInfo", vec![("name", self.name.to_pod()), ("owner", self.owner.to_pod()), ("params", self.params.to_pod()), ("args", self.args.to_pod()), ("fields", self.fields.to_pod()), ("ty", self.ty.to_pod()), ("index", self.index.to_pod())])
    }
}

impl FromPod for CtorInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CtorInfo { name: FromPod::from_pod(field(p, "name")?)?, owner: FromPod::from_pod(field(p, "owner")?)?, params: FromPod::from_pod(field(p, "params")?)?, args: FromPod::from_pod(field(p, "args")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, index: FromPod::from_pod(field(p, "index")?)? })
    }
}

/// `Cx`:
///
/// ```prism
/// type Cx = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Cx_ {
    pub g: G,
    pub home: Text,
    pub scope: crate::check::types::Rw,
    pub row_vars: Array<Text>,
    pub unwritten: crate::check::types::Col,
}

impl Show for Cx_ {
    fn show(&self, p: &mut Printer) {
        p.record("Cx", &[("g", &self.g), ("home", &self.home), ("scope", &self.scope), ("row_vars", &self.row_vars), ("unwritten", &self.unwritten)]);
    }
}

impl ToPod for Cx_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Cx", vec![("g", self.g.to_pod()), ("home", self.home.to_pod()), ("scope", self.scope.to_pod()), ("row_vars", self.row_vars.to_pod()), ("unwritten", self.unwritten.to_pod())])
    }
}

impl FromPod for Cx_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Cx_ { g: FromPod::from_pod(field(p, "g")?)?, home: FromPod::from_pod(field(p, "home")?)?, scope: FromPod::from_pod(field(p, "scope")?)?, row_vars: FromPod::from_pod(field(p, "row_vars")?)?, unwritten: FromPod::from_pod(field(p, "unwritten")?)? })
    }
}

/// `Def`:
///
/// ```prism
/// type Def = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Def {
    pub qk: Text,
    pub name: Text,
    pub home: Text,
    pub file: Nat,
    pub span: crate::syntax::Range,
    pub body: DefBody,
}

impl Show for Def {
    fn show(&self, p: &mut Printer) {
        p.record("Def", &[("qk", &self.qk), ("name", &self.name), ("home", &self.home), ("file", &self.file), ("span", &self.span), ("body", &self.body)]);
    }
}

impl ToPod for Def {
    fn to_pod(&self) -> Pod {
        Pod::record("Def", vec![("qk", self.qk.to_pod()), ("name", self.name.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod()), ("body", self.body.to_pod())])
    }
}

impl FromPod for Def {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Def { qk: FromPod::from_pod(field(p, "qk")?)?, name: FromPod::from_pod(field(p, "name")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)?, body: FromPod::from_pod(field(p, "body")?)? })
    }
}

/// `DefBody`:
///
/// ```prism
/// type DefBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum DefBody {
    DbFn(Array<crate::syntax::FnClause>),
    DbLet(crate::syntax::LetDecl),
    DbWidget(crate::syntax::WidgetDecl),
    DbMethod(Array<crate::syntax::FnClause>, Text, ImplInfo),
    DbDefault(Array<crate::syntax::FnClause>, Text),
    DbCheck(crate::syntax::CheckDecl),
    DbTest(crate::syntax::TestDecl),
}

impl Show for DefBody {
    fn show(&self, p: &mut Printer) {
        match self {
            DefBody::DbFn(a0) => p.choice("DbFn", &[a0]),
            DefBody::DbLet(a0) => p.choice("DbLet", &[a0]),
            DefBody::DbWidget(a0) => p.choice("DbWidget", &[a0]),
            DefBody::DbMethod(a0, a1, a2) => p.choice("DbMethod", &[a0, a1, a2]),
            DefBody::DbDefault(a0, a1) => p.choice("DbDefault", &[a0, a1]),
            DefBody::DbCheck(a0) => p.choice("DbCheck", &[a0]),
            DefBody::DbTest(a0) => p.choice("DbTest", &[a0]),
        }
    }
}

impl ToPod for DefBody {
    fn to_pod(&self) -> Pod {
        match self {
            DefBody::DbFn(a0) => Pod::Choice("DbFn".into(), vec![a0.to_pod()]),
            DefBody::DbLet(a0) => Pod::Choice("DbLet".into(), vec![a0.to_pod()]),
            DefBody::DbWidget(a0) => Pod::Choice("DbWidget".into(), vec![a0.to_pod()]),
            DefBody::DbMethod(a0, a1, a2) => Pod::Choice("DbMethod".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            DefBody::DbDefault(a0, a1) => Pod::Choice("DbDefault".into(), vec![a0.to_pod(), a1.to_pod()]),
            DefBody::DbCheck(a0) => Pod::Choice("DbCheck".into(), vec![a0.to_pod()]),
            DefBody::DbTest(a0) => Pod::Choice("DbTest".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for DefBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DbFn" && a.len() == 1 => Ok(DefBody::DbFn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbLet" && a.len() == 1 => Ok(DefBody::DbLet(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbWidget" && a.len() == 1 => Ok(DefBody::DbWidget(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbMethod" && a.len() == 3 => Ok(DefBody::DbMethod(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "DbDefault" && a.len() == 2 => Ok(DefBody::DbDefault(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "DbCheck" && a.len() == 1 => Ok(DefBody::DbCheck(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbTest" && a.len() == 1 => Ok(DefBody::DbTest(FromPod::from_pod(&a[0])?)),
            other => mismatch("a DefBody", other),
        }
    }
}

/// `G`:
///
/// ```prism
/// type G = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct G {
    pub mods: Map<Text, ModInfo>,
    pub types: Map<Text, TyInfo>,
    pub ctors: Map<Text, CtorInfo>,
    pub tags: Map<Text, TagInfo>,
    pub families: Map<Text, Array<Text>>,
    pub fam_owner: Map<Text, Text>,
    pub vals: Map<Text, ValInfo>,
    pub traits: Map<Text, TraitInfo>,
    pub impls: Map<Text, Array<ImplInfo>>,
    pub bare: Map<Text, Map<Text, Array<Text>>>,
    pub bare_types: Map<Text, Map<Text, Array<Text>>>,
    pub bare_traits: Map<Text, Map<Text, Array<Text>>>,
    pub srcs: Array<crate::check::errors::Src>,
    pub defs: Array<Def>,
    pub program_row: crate::check::types::Rw,
    pub elem_fams: Array<Text>,
    pub root_module: Option<Text>,
    pub app_root: bool,
    pub fn_at: Map<Text, Nat>,
    pub prelude_from: Nat,
}

impl Show for G {
    fn show(&self, p: &mut Printer) {
        p.record("G", &[("mods", &self.mods), ("types", &self.types), ("ctors", &self.ctors), ("tags", &self.tags), ("families", &self.families), ("fam_owner", &self.fam_owner), ("vals", &self.vals), ("traits", &self.traits), ("impls", &self.impls), ("bare", &self.bare), ("bare_types", &self.bare_types), ("bare_traits", &self.bare_traits), ("srcs", &self.srcs), ("defs", &self.defs), ("program_row", &self.program_row), ("elem_fams", &self.elem_fams), ("root_module", &self.root_module), ("app_root", &self.app_root), ("fn_at", &self.fn_at), ("prelude_from", &self.prelude_from)]);
    }
}

impl ToPod for G {
    fn to_pod(&self) -> Pod {
        Pod::record("G", vec![("mods", self.mods.to_pod()), ("types", self.types.to_pod()), ("ctors", self.ctors.to_pod()), ("tags", self.tags.to_pod()), ("families", self.families.to_pod()), ("fam_owner", self.fam_owner.to_pod()), ("vals", self.vals.to_pod()), ("traits", self.traits.to_pod()), ("impls", self.impls.to_pod()), ("bare", self.bare.to_pod()), ("bare_types", self.bare_types.to_pod()), ("bare_traits", self.bare_traits.to_pod()), ("srcs", self.srcs.to_pod()), ("defs", self.defs.to_pod()), ("program_row", self.program_row.to_pod()), ("elem_fams", self.elem_fams.to_pod()), ("root_module", self.root_module.to_pod()), ("app_root", self.app_root.to_pod()), ("fn_at", self.fn_at.to_pod()), ("prelude_from", self.prelude_from.to_pod())])
    }
}

impl FromPod for G {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(G { mods: FromPod::from_pod(field(p, "mods")?)?, types: FromPod::from_pod(field(p, "types")?)?, ctors: FromPod::from_pod(field(p, "ctors")?)?, tags: FromPod::from_pod(field(p, "tags")?)?, families: FromPod::from_pod(field(p, "families")?)?, fam_owner: FromPod::from_pod(field(p, "fam_owner")?)?, vals: FromPod::from_pod(field(p, "vals")?)?, traits: FromPod::from_pod(field(p, "traits")?)?, impls: FromPod::from_pod(field(p, "impls")?)?, bare: FromPod::from_pod(field(p, "bare")?)?, bare_types: FromPod::from_pod(field(p, "bare_types")?)?, bare_traits: FromPod::from_pod(field(p, "bare_traits")?)?, srcs: FromPod::from_pod(field(p, "srcs")?)?, defs: FromPod::from_pod(field(p, "defs")?)?, program_row: FromPod::from_pod(field(p, "program_row")?)?, elem_fams: FromPod::from_pod(field(p, "elem_fams")?)?, root_module: FromPod::from_pod(field(p, "root_module")?)?, app_root: FromPod::from_pod(field(p, "app_root")?)?, fn_at: FromPod::from_pod(field(p, "fn_at")?)?, prelude_from: FromPod::from_pod(field(p, "prelude_from")?)? })
    }
}

/// `ImplInfo`:
///
/// ```prism
/// type ImplInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ImplInfo {
    pub cls: Text,
    pub head: crate::check::types::Ty,
    pub qs: Array<Text>,
    pub bounds: Array<(Text, Text)>,
    pub home: Text,
    pub file: Nat,
    pub span: crate::syntax::Range,
    pub derived: bool,
    pub assocs: Array<(Text, crate::check::types::Ty)>,
    pub methods: Array<Text>,
}

impl Show for ImplInfo {
    fn show(&self, p: &mut Printer) {
        p.record("ImplInfo", &[("cls", &self.cls), ("head", &self.head), ("qs", &self.qs), ("bounds", &self.bounds), ("home", &self.home), ("file", &self.file), ("span", &self.span), ("derived", &self.derived), ("assocs", &self.assocs), ("methods", &self.methods)]);
    }
}

impl ToPod for ImplInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("ImplInfo", vec![("cls", self.cls.to_pod()), ("head", self.head.to_pod()), ("qs", self.qs.to_pod()), ("bounds", self.bounds.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod()), ("derived", self.derived.to_pod()), ("assocs", self.assocs.to_pod()), ("methods", self.methods.to_pod())])
    }
}

impl FromPod for ImplInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ImplInfo { cls: FromPod::from_pod(field(p, "cls")?)?, head: FromPod::from_pod(field(p, "head")?)?, qs: FromPod::from_pod(field(p, "qs")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)?, derived: FromPod::from_pod(field(p, "derived")?)?, assocs: FromPod::from_pod(field(p, "assocs")?)?, methods: FromPod::from_pod(field(p, "methods")?)? })
    }
}

/// `ModInfo`:
///
/// ```prism
/// type ModInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ModInfo {
    pub name: Text,
    pub file: Nat,
    pub emit_rw: crate::check::types::Rw,
    pub row_var: Text,
    pub uses: Array<(Text, bool)>,
    pub root: bool,
    pub tree: crate::syntax::Module,
}

impl Show for ModInfo {
    fn show(&self, p: &mut Printer) {
        p.record("ModInfo", &[("name", &self.name), ("file", &self.file), ("emit_rw", &self.emit_rw), ("row_var", &self.row_var), ("uses", &self.uses), ("root", &self.root), ("tree", &self.tree)]);
    }
}

impl ToPod for ModInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("ModInfo", vec![("name", self.name.to_pod()), ("file", self.file.to_pod()), ("emit_rw", self.emit_rw.to_pod()), ("row_var", self.row_var.to_pod()), ("uses", self.uses.to_pod()), ("root", self.root.to_pod()), ("tree", self.tree.to_pod())])
    }
}

impl FromPod for ModInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ModInfo { name: FromPod::from_pod(field(p, "name")?)?, file: FromPod::from_pod(field(p, "file")?)?, emit_rw: FromPod::from_pod(field(p, "emit_rw")?)?, row_var: FromPod::from_pod(field(p, "row_var")?)?, uses: FromPod::from_pod(field(p, "uses")?)?, root: FromPod::from_pod(field(p, "root")?)?, tree: FromPod::from_pod(field(p, "tree")?)? })
    }
}

/// `TagInfo`:
///
/// ```prism
/// type TagInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TagInfo {
    pub name: Text,
    pub family: Text,
    pub kind: Text,
    pub out: crate::check::types::Ty,
    pub qs: Array<Text>,
    pub rqs: Array<Text>,
    pub bounds: Array<(Text, Text)>,
    pub fields: Array<(Text, crate::check::types::Ty)>,
    pub home: Text,
    pub file: Nat,
    pub span: crate::syntax::Range,
}

impl Show for TagInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TagInfo", &[("name", &self.name), ("family", &self.family), ("kind", &self.kind), ("out", &self.out), ("qs", &self.qs), ("rqs", &self.rqs), ("bounds", &self.bounds), ("fields", &self.fields), ("home", &self.home), ("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for TagInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TagInfo", vec![("name", self.name.to_pod()), ("family", self.family.to_pod()), ("kind", self.kind.to_pod()), ("out", self.out.to_pod()), ("qs", self.qs.to_pod()), ("rqs", self.rqs.to_pod()), ("bounds", self.bounds.to_pod()), ("fields", self.fields.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TagInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TagInfo { name: FromPod::from_pod(field(p, "name")?)?, family: FromPod::from_pod(field(p, "family")?)?, kind: FromPod::from_pod(field(p, "kind")?)?, out: FromPod::from_pod(field(p, "out")?)?, qs: FromPod::from_pod(field(p, "qs")?)?, rqs: FromPod::from_pod(field(p, "rqs")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TraitInfo`:
///
/// ```prism
/// type TraitInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TraitInfo {
    pub name: Text,
    pub home: Text,
    pub param: Text,
    pub supers: Array<Text>,
    pub methods: Array<Text>,
    pub defaults: Array<Text>,
    pub assocs: Array<Text>,
    pub file: Nat,
    pub span: crate::syntax::Range,
}

impl Show for TraitInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TraitInfo", &[("name", &self.name), ("home", &self.home), ("param", &self.param), ("supers", &self.supers), ("methods", &self.methods), ("defaults", &self.defaults), ("assocs", &self.assocs), ("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for TraitInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TraitInfo", vec![("name", self.name.to_pod()), ("home", self.home.to_pod()), ("param", self.param.to_pod()), ("supers", self.supers.to_pod()), ("methods", self.methods.to_pod()), ("defaults", self.defaults.to_pod()), ("assocs", self.assocs.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TraitInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TraitInfo { name: FromPod::from_pod(field(p, "name")?)?, home: FromPod::from_pod(field(p, "home")?)?, param: FromPod::from_pod(field(p, "param")?)?, supers: FromPod::from_pod(field(p, "supers")?)?, methods: FromPod::from_pod(field(p, "methods")?)?, defaults: FromPod::from_pod(field(p, "defaults")?)?, assocs: FromPod::from_pod(field(p, "assocs")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TyBody`:
///
/// ```prism
/// type TyBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TyBody {
    BRecord(Array<(Text, crate::check::types::Ty)>),
    BChoice(Array<(Text, Array<crate::check::types::Ty>)>),
    BRowKind,
    BAlias(crate::check::types::Ty),
    BOpaque,
    BPrim,
}

impl Show for TyBody {
    fn show(&self, p: &mut Printer) {
        match self {
            TyBody::BRecord(a0) => p.choice("BRecord", &[a0]),
            TyBody::BChoice(a0) => p.choice("BChoice", &[a0]),
            TyBody::BRowKind => p.choice("BRowKind", &[]),
            TyBody::BAlias(a0) => p.choice("BAlias", &[a0]),
            TyBody::BOpaque => p.choice("BOpaque", &[]),
            TyBody::BPrim => p.choice("BPrim", &[]),
        }
    }
}

impl ToPod for TyBody {
    fn to_pod(&self) -> Pod {
        match self {
            TyBody::BRecord(a0) => Pod::Choice("BRecord".into(), vec![a0.to_pod()]),
            TyBody::BChoice(a0) => Pod::Choice("BChoice".into(), vec![a0.to_pod()]),
            TyBody::BRowKind => Pod::Choice("BRowKind".into(), vec![]),
            TyBody::BAlias(a0) => Pod::Choice("BAlias".into(), vec![a0.to_pod()]),
            TyBody::BOpaque => Pod::Choice("BOpaque".into(), vec![]),
            TyBody::BPrim => Pod::Choice("BPrim".into(), vec![]),
        }
    }
}

impl FromPod for TyBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "BRecord" && a.len() == 1 => Ok(TyBody::BRecord(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BChoice" && a.len() == 1 => Ok(TyBody::BChoice(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BRowKind" && a.len() == 0 => Ok(TyBody::BRowKind),
            Pod::Choice(c, a) if &**c == "BAlias" && a.len() == 1 => Ok(TyBody::BAlias(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BOpaque" && a.len() == 0 => Ok(TyBody::BOpaque),
            Pod::Choice(c, a) if &**c == "BPrim" && a.len() == 0 => Ok(TyBody::BPrim),
            other => mismatch("a TyBody", other),
        }
    }
}

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyInfo {
    pub name: Text,
    pub home: Text,
    pub params: Array<Text>,
    pub body: TyBody,
    pub derives: Array<Text>,
    pub file: Nat,
    pub span: crate::syntax::Range,
}

impl Show for TyInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TyInfo", &[("name", &self.name), ("home", &self.home), ("params", &self.params), ("body", &self.body), ("derives", &self.derives), ("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for TyInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TyInfo", vec![("name", self.name.to_pod()), ("home", self.home.to_pod()), ("params", self.params.to_pod()), ("body", self.body.to_pod()), ("derives", self.derives.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TyInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyInfo { name: FromPod::from_pod(field(p, "name")?)?, home: FromPod::from_pod(field(p, "home")?)?, params: FromPod::from_pod(field(p, "params")?)?, body: FromPod::from_pod(field(p, "body")?)?, derives: FromPod::from_pod(field(p, "derives")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `ValInfo`:
///
/// ```prism
/// type ValInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ValInfo {
    pub qk: Text,
    pub scheme: crate::check::types::Scheme,
    pub sort: Text,
    pub has_sig: bool,
    pub home: Text,
    pub file: Nat,
    pub span: crate::syntax::Range,
}

impl Show for ValInfo {
    fn show(&self, p: &mut Printer) {
        p.record("ValInfo", &[("qk", &self.qk), ("scheme", &self.scheme), ("sort", &self.sort), ("has_sig", &self.has_sig), ("home", &self.home), ("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for ValInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("ValInfo", vec![("qk", self.qk.to_pod()), ("scheme", self.scheme.to_pod()), ("sort", self.sort.to_pod()), ("has_sig", self.has_sig.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for ValInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ValInfo { qk: FromPod::from_pod(field(p, "qk")?)?, scheme: FromPod::from_pod(field(p, "scheme")?)?, sort: FromPod::from_pod(field(p, "sort")?)?, has_sig: FromPod::from_pod(field(p, "has_sig")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// ```prism
/// IsPrimType: fn Text -> Bool
/// ```
pub fn is_prim_type(n: &Text) -> bool {
    crate::check::types::has_text(&Array::from(vec![Text::lit("Bool"), Text::lit("unit"), Text::lit("Char"), Text::lit("Text"), Text::lit("Nat"), Text::lit("Int"), Text::lit("U8"), Text::lit("Float"), Text::lit("Path"), Text::lit("Duration"), Text::lit("Cursor")]), n)
}

/// ```prism
/// QualKey: fn Text, Text -> Text
/// ```
pub fn qual_key(m: &Text, name: &Text) -> Text {
    if m == &Text::lit("") { name.clone() } else { Text::from(format!("{}.{}", m, name)) }
}

/// ```prism
/// Dotted: fn [Text] -> Text
/// ```
pub fn dotted(parts: &Array<Text>) -> Text {
    crate::syntax::lexer::join(parts, &Text::lit("."))
}

/// ```prism
/// SNameKey: fn SName -> Text
/// ```
pub fn sname_key(n: &crate::syntax::SName) -> Text {
    Text::from(format!("{}{}", &n.sigils, &dotted(&n.path_)))
}

/// ```prism
/// DefNameText: fn DefName -> Text
/// ```
pub fn def_name_text(def_name0: &crate::syntax::DefName) -> Text {
    match def_name0 {
        crate::syntax::DefName::DefSName(n) => sname_key(n),
        crate::syntax::DefName::DefOp(o, _) => o.clone(),
    }
}

/// ```prism
/// DefNameSpan: fn DefName -> Range
/// ```
pub fn def_name_span(def_name0: &crate::syntax::DefName) -> crate::syntax::Range {
    match def_name0 {
        crate::syntax::DefName::DefSName(n) => n.span.clone(),
        crate::syntax::DefName::DefOp(_, r) => r.clone(),
    }
}

/// ```prism
/// IsLowerText: fn Text -> Bool
/// ```
pub fn is_lower_text(t: &Text) -> bool {
    crate::syntax::lexer::is_lower(&crate::syntax::lexer::head(t))
}

/// ```prism
/// IsUpperText: fn Text -> Bool
/// ```
pub fn is_upper_text(t: &Text) -> bool {
    crate::syntax::lexer::is_upper(&crate::syntax::lexer::head(t))
}

/// ```prism
/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
/// ```
pub fn build_g(srcs: &Array<crate::check::errors::Src>, trees: &Array<crate::syntax::Module>) -> (G, crate::check::types::St) {
    let g0 = G { mods: Map::new(), types: Map::new(), ctors: Map::new(), tags: Map::new(), families: Map::new(), fam_owner: Map::new(), vals: Map::new(), traits: Map::new(), impls: Map::new(), bare: Map::new(), bare_types: Map::new(), bare_traits: Map::new(), srcs: srcs.clone(), defs: Array::new(), program_row: crate::check::types::empty_row(), elem_fams: Array::new(), root_module: None, app_root: app_root(srcs, trees), fn_at: Map::new(), prelude_from: len(trees) };
    let st0 = crate::check::types::new_st(&Nat::from(0u32));
    let (g1, st1) = fold(&crate::check::errors::range0(&len(trees)), &(g0.clone(), st0.clone()), &(|(g, st): &(G, crate::check::types::St), i: &Nat| add_module(g, st, i, &or(&index(trees, i), &empty_module()))));
    let g2 = add_builtins(&g1);
    let (g3, st3) = run_to_end(fold_job(keys(&g2.mods), (g2.clone(), st1.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
        let (g, st) = p0;
        let m = p1;
        prism_rtl::Turn::More(Rc::new(CollectNames { g: g.clone(), st: st.clone(), m: m.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let g4 = {
        let mut this: G = g3.clone();
        this.program_row = program_row(&this);
        this
    };
    let (g6, st6) = run_to_end(fold_job(keys(&g4.mods), (g4.clone(), st3.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
        let (g, st) = p0;
        let m = p1;
        prism_rtl::Turn::More(Rc::new(BuildTables { g: g.clone(), st: st.clone(), m: m.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let (g6b, st6b) = run_to_end(fold_job(keys(&g6.mods), (g6.clone(), st6.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
        let (g, st) = p0;
        let m = p1;
        prism_rtl::Turn::More(Rc::new(ConvertTypes { g: g.clone(), st: st.clone(), m: m.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let (g7, st7) = run_to_end(fold_job(keys(&g6b.mods), (g6b.clone(), st6b.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
        let (g, st) = p0;
        let m = p1;
        prism_rtl::Turn::More(Rc::new(ConvertDecls { g: g.clone(), st: st.clone(), m: m.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let g8 = derived_impls(&g7);
    let st8 = coherence(&g8, &st7);
    (g8.clone(), st8.clone())
}

/// The step machine of `BuildG`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
/// ```
pub struct BuildG {
    pub srcs: Array<crate::check::errors::Src>,
    pub trees: Array<crate::syntax::Module>,
}

impl prism_rtl::Job<(G, crate::check::types::St)> for BuildG {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St)> {
        let srcs = &self.srcs;
        let trees = &self.trees;
        let g0 = G { mods: Map::new(), types: Map::new(), ctors: Map::new(), tags: Map::new(), families: Map::new(), fam_owner: Map::new(), vals: Map::new(), traits: Map::new(), impls: Map::new(), bare: Map::new(), bare_types: Map::new(), bare_traits: Map::new(), srcs: srcs.clone(), defs: Array::new(), program_row: crate::check::types::empty_row(), elem_fams: Array::new(), root_module: None, app_root: app_root(srcs, trees), fn_at: Map::new(), prelude_from: len(trees) };
        let st0 = crate::check::types::new_st(&Nat::from(0u32));
        let (g1, st1) = fold(&crate::check::errors::range0(&len(trees)), &(g0.clone(), st0.clone()), &(|(g, st): &(G, crate::check::types::St), i: &Nat| add_module(g, st, i, &or(&index(trees, i), &empty_module()))));
        let g2 = add_builtins(&g1);
        call_value(fold_job(keys(&g2.mods), (g2.clone(), st1.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
            let (g, st) = p0;
            let m = p1;
            prism_rtl::Turn::More(Rc::new(CollectNames { g: g.clone(), st: st.clone(), m: m.clone() }))
        }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_5332: (G, crate::check::types::St)| {
            let (g3, st3) = fold_5332;
            let g4 = {
                let mut this: G = g3.clone();
                this.program_row = program_row(&this);
                this
            };
            call_value(fold_job(keys(&g4.mods), (g4.clone(), st3.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
                let (g, st) = p0;
                let m = p1;
                prism_rtl::Turn::More(Rc::new(BuildTables { g: g.clone(), st: st.clone(), m: m.clone() }))
            }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_5489: (G, crate::check::types::St)| {
                let (g6, st6) = fold_5489;
                call_value(fold_job(keys(&g6.mods), (g6.clone(), st6.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
                    let (g, st) = p0;
                    let m = p1;
                    prism_rtl::Turn::More(Rc::new(ConvertTypes { g: g.clone(), st: st.clone(), m: m.clone() }))
                }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_5584: (G, crate::check::types::St)| {
                    let (g6b, st6b) = fold_5584;
                    call_value(fold_job(keys(&g6b.mods), (g6b.clone(), st6b.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
                        let (g, st) = p0;
                        let m = p1;
                        prism_rtl::Turn::More(Rc::new(ConvertDecls { g: g.clone(), st: st.clone(), m: m.clone() }))
                    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_5678: (G, crate::check::types::St)| {
                        let (g7, st7) = fold_5678;
                        let g8 = derived_impls(&g7);
                        call_then(start_coherence(g8.clone(), st7.clone()), move |coherence_5796: crate::check::types::St| {
                            let st8 = coherence_5796;
                            prism_rtl::Turn::Finished((g8.clone(), st8.clone()))
                        })
                    })
                })
            })
        })
    }
}

/// `Start BuildG, x`: what the function value is when passed to `@Run`.
pub fn start_build_g(srcs: Array<crate::check::errors::Src>, trees: Array<crate::syntax::Module>) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>> {
    Rc::new(BuildG { srcs, trees })
}

/// ```prism
/// let emptyModule
/// ```
pub fn empty_module() -> crate::syntax::Module {
    crate::syntax::Module { name: None, emit_row: None, mods: Array::new(), uses: Array::new(), decls: Array::new(), template: None, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// ModName: fn Module -> Text
/// ```
pub fn mod_name(m: &crate::syntax::Module) -> Text {
    match &m.name {
        Some(q) => dotted(&q.path_),
        None => Text::lit(""),
    }
}

/// ```prism
/// AppRoot: fn [Src], [Module] -> Bool
/// ```
pub fn app_root(srcs: &Array<crate::check::errors::Src>, trees: &Array<crate::syntax::Module>) -> bool {
    fold(&crate::check::errors::range0(&len(trees)), &false, &(|seen: &bool, i: &Nat| {
        let t = or(&index(trees, i), &empty_module());
        let name = mod_name(&t);
        if &name == &Text::lit("App") {
            false
        } else {
            if (&name == &Text::lit("")) && (&crate::check::errors::seg_at(&or(&index(srcs, i), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))), &Nat::from(0u32)).role != &Text::lit("loose")) {
                true
            } else {
                *seen
            }
        }
    }))
}

/// ```prism
/// UseName: fn G, Text -> Text
/// ```
pub fn use_name(g: &G, u: &Text) -> Text {
    if g.app_root && (u == &Text::lit("App")) { Text::lit("") } else { u.clone() }
}

/// ```prism
/// QualModule: fn G, [Text] -> Text
/// ```
pub fn qual_module(g: &G, parts: &Array<Text>) -> Text {
    use_name(g, &dotted(parts))
}

/// ```prism
/// AddModule: fn G, St, Nat, Module -> ((G, St))
/// ```
pub fn add_module(g: &G, st: &crate::check::types::St, i: &Nat, tree: &crate::syntax::Module) -> (G, crate::check::types::St) {
    let name = mod_name(tree);
    let s = {
        let mut this: crate::check::types::St = st.clone();
        this.file = i.clone();
        this
    };
    if has_key(&g.mods, &name) {
        {
            let what = if &name == &Text::lit("") {
                Text::lit("two files have no `module` line")
            } else {
                Text::from(format!("two files declare `module {}`", &name))
            };
            (g.clone(), crate::check::types::err(&s, &Text::lit("collision"), &tree.span, &what))
        }
    } else {
        {
            let info = ModInfo { name: name.clone(), file: i.clone(), emit_rw: crate::check::types::empty_row(), row_var: Text::lit(""), uses: each(&tree.uses, &(|u: &crate::syntax::Use| (use_name(g, &dotted(&u.target.path_)), u.star))), root: &name == &Text::lit(""), tree: tree.clone() };
            let g2 = {
                let mut this: G = g.clone();
                this.mods = insert(&this.mods, &name, &info);
                if &name == &Text::lit("") {
                    this.root_module = Some(Text::lit(""));
                }
                this
            };
            (g2.clone(), s.clone())
        }
    }
}

/// ```prism
/// HasKey: fn (Text ==> a), Text -> Bool
/// ```
pub fn has_key<A: Clone + 'static>(m: &Map<Text, A>, k: &Text) -> bool {
    match get(m, k) {
        Some(_) => true,
        None => false,
    }
}

/// ```prism
/// AddBuiltins: fn G -> G
/// ```
pub fn add_builtins(g: &G) -> G {
    let bool_ctor_fn = Rc::new(move |n: &Text, i: &Nat| CtorInfo { name: n.clone(), owner: Text::lit("Bool"), params: Array::new(), args: Array::new(), fields: Array::new(), ty: crate::check::types::t_bool(), index: i.clone() });
    let pre = crate::check::types::Scheme { qs: Array::from(vec![Text::lit("a")]), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(crate::check::types::Ty::TyQ(Text::lit("a")))) };
    let numbered_ = crate::check::types::mono(&crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, Array::from(vec![crate::check::types::t_nat()]), Rc::new(crate::check::types::Ty::TyCon(Text::lit("Buffer"), Array::from(vec![crate::check::types::t_nat()])))));
    let buf_empty = crate::check::types::Scheme { qs: Array::from(vec![Text::lit("a")]), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: crate::check::types::Ty::TyCon(Text::lit("Buffer"), Array::from(vec![crate::check::types::Ty::TyQ(Text::lit("a"))])) };
    let tab_empty = crate::check::types::Scheme { qs: Array::from(vec![Text::lit("k"), Text::lit("v")]), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: crate::check::types::Ty::TyCon(Text::lit("Table"), Array::from(vec![crate::check::types::Ty::TyQ(Text::lit("k")), crate::check::types::Ty::TyQ(Text::lit("v"))])) };
    let mut this: G = g.clone();
    this.ctors = insert(&insert(&this.ctors, &Text::lit("True"), &(&bool_ctor_fn)(&Text::lit("True"), &Nat::from(0u32))), &Text::lit("False"), &(&bool_ctor_fn)(&Text::lit("False"), &Nat::from(1u32)));
    this.vals = insert(&this.vals, &Text::lit("Prelude.never"), &builtin(&Text::lit("Prelude.never"), &pre));
    this.vals = insert(&this.vals, &Text::lit("Buffer.Numbered"), &builtin(&Text::lit("Buffer.Numbered"), &numbered_));
    this.vals = insert(&this.vals, &Text::lit("Buffer.Empty"), &builtin(&Text::lit("Buffer.Empty"), &buf_empty));
    this.vals = insert(&this.vals, &Text::lit("Table.Empty"), &builtin(&Text::lit("Table.Empty"), &tab_empty));
    this
}

/// ```prism
/// Builtin: fn Text, Scheme -> ValInfo
/// ```
pub fn builtin(qk: &Text, sc: &crate::check::types::Scheme) -> ValInfo {
    ValInfo { qk: qk.clone(), scheme: sc.clone(), sort: Text::lit("builtin"), has_sig: true, home: Text::lit("Prelude"), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// CollectNames: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn collect_names(g: &G, st: &crate::check::types::St, m: &Text) -> (G, crate::check::types::St) {
    match get(&g.mods, m) {
        None => (g.clone(), st.clone()),
        Some(info) => {
            let s0 = {
                let mut this: crate::check::types::St = st.clone();
                this.file = info.file.clone();
                this
            };
            let (g2, s2, _) = run_to_end(fold_job(info.tree.decls.clone(), (g.clone(), s0.clone(), None), {
                let info = info.clone();
                Rc::new(move |(p0, p1): ((G, crate::check::types::St, Option<Text>), crate::syntax::Decl)| {
                    let info = info.clone();
                    entered(once_job(move || {
                        let (gg, s, last_type_opt) = p0;
                        let d = p1;
                        prism_rtl::Turn::More(Rc::new(CollectDecl { g: gg.clone(), st: s.clone(), info: info.clone(), d: d.clone(), last_type_opt: last_type_opt.clone() }))
                    }))
                }) as Rc<dyn Fn(((G, crate::check::types::St, Option<Text>), crate::syntax::Decl)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St, Option<Text>)>>>
            }));
            (g2.clone(), s2.clone())
        },
    }
}

/// The step machine of `CollectNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollectNames: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct CollectNames {
    pub g: G,
    pub st: crate::check::types::St,
    pub m: Text,
}

impl prism_rtl::Job<(G, crate::check::types::St)> for CollectNames {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let m = &self.m;
        match get(&g.mods, m) {
            None => prism_rtl::Turn::Finished((g.clone(), st.clone())),
            Some(info) => {
                let s0 = {
                    let mut this: crate::check::types::St = st.clone();
                    this.file = info.file.clone();
                    this
                };
                let g = g.clone();
                call_value(fold_job(info.tree.decls.clone(), (g.clone(), s0.clone(), None), {
                    let info = info.clone();
                    Rc::new(move |(p0, p1): ((G, crate::check::types::St, Option<Text>), crate::syntax::Decl)| {
                        let info = info.clone();
                        entered(once_job(move || {
                            let (gg, s, last_type_opt) = p0;
                            let d = p1;
                            prism_rtl::Turn::More(Rc::new(CollectDecl { g: gg.clone(), st: s.clone(), info: info.clone(), d: d.clone(), last_type_opt: last_type_opt.clone() }))
                        }))
                    }) as Rc<dyn Fn(((G, crate::check::types::St, Option<Text>), crate::syntax::Decl)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St, Option<Text>)>>>
                }), move |fold_9816: (G, crate::check::types::St, Option<Text>)| {
                    let (g2, s2, _) = fold_9816;
                    prism_rtl::Turn::Finished((g2.clone(), s2.clone()))
                })
            },
        }
    }
}

/// `Start CollectNames, x`: what the function value is when passed to `@Run`.
pub fn start_collect_names(g: G, st: crate::check::types::St, m: Text) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>> {
    Rc::new(CollectNames { g, st, m })
}

/// ```prism
/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
/// ```
pub fn collect_decl(g: &G, st: &crate::check::types::St, info: &ModInfo, d: &crate::syntax::Decl, last_type_opt: &Option<Text>) -> (G, crate::check::types::St, Option<Text>) {
    match &d.kind {
        crate::syntax::DeclKind::DType(t) => {
            let name = qual_key(&info.name, &dotted(&t.name.path_));
            let ti = TyInfo { name: name.clone(), home: info.name.clone(), params: each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone())), body: TyBody::BOpaque, derives: Array::new(), file: info.file.clone(), span: d.span.clone() };
            if has_key(&g.types, &name) {
                (g.clone(), crate::check::types::err(st, &Text::lit("collision"), &d.span, &Text::from(format!("a second type `{}`", &dotted(&t.name.path_)))), last_type_opt.clone())
            } else {
                {
                    let upd = {
                        let mut this: G = g.clone();
                        this.types = insert(&this.types, &name, &ti);
                        this
                    };
                    (upd.clone(), st.clone(), Some(name.clone()))
                }
            }
        },
        crate::syntax::DeclKind::DDerive(trs) => match last_type_opt {
            Some(tn) => {
                let upd = {
                    let mut this: G = g.clone();
                    this.types = insert(&this.types, tn, &add_derives(&or(&get(&g.types, tn), &dummy_ty_info()), &each(trs, &(|tr: &crate::syntax::TraitRef| dotted(&tr.path_)))));
                    this
                };
                (upd.clone(), st.clone(), last_type_opt.clone())
            },
            None => (g.clone(), crate::check::types::err(st, &Text::lit("mismatch"), &d.span, &Text::lit("a `derive` line follows a type declaration")), None),
        },
        crate::syntax::DeclKind::DTag(t) => {
            let name = dotted(&t.name.path_);
            let family = dotted(&take(&t.name.path_, &crate::syntax::lexer::dec(&len(&t.name.path_))));
            let tags = or(&get(&g.families, &family), &Array::new());
            let owner = or(&get(&g.fam_owner, &family), &info.name);
            let st2 = if &owner != &info.name {
                crate::check::types::err(st, &Text::lit("collision"), &d.span, &Text::from(format!("the family `{}` is declared in {}; every tag of a family is declared in its family's module", &family, &(if &owner == &Text::lit("") {
                    Text::lit("the root")
                } else {
                    Text::from(format!("`{}`", &owner))
                }))))
            } else {
                st.clone()
            };
            let is_elem = match &*t.of_type.kind {
                crate::syntax::TypeKind::TName(n, _) => &dotted(&n.path_) == &Text::lit("Element"),
                _ => false,
            };
            let g2 = {
                let mut this: G = g.clone();
                this.families = insert(&this.families, &family, &push(&tags, &name));
                this.fam_owner = insert(&this.fam_owner, &family, &owner);
                if is_elem {
                    this.elem_fams = crate::check::types::add_text(&this.elem_fams, &family);
                }
                this
            };
            (g2.clone(), st2.clone(), None)
        },
        crate::syntax::DeclKind::DTrait(t) => {
            let name = qual_key(&info.name, &dotted(&t.name.path_));
            let ti = TraitInfo { name: name.clone(), home: info.name.clone(), param: or(&index(&each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone())), &Nat::from(0u32)), &Text::lit("a")), supers: Array::new(), methods: Array::new(), defaults: Array::new(), assocs: Array::new(), file: info.file.clone(), span: d.span.clone() };
            let upd = {
                let mut this: G = g.clone();
                this.traits = insert(&this.traits, &name, &ti);
                this
            };
            (upd.clone(), st.clone(), None)
        },
        _ => (g.clone(), st.clone(), None),
    }
}

/// The step machine of `CollectDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
/// ```
pub struct CollectDecl {
    pub g: G,
    pub st: crate::check::types::St,
    pub info: ModInfo,
    pub d: crate::syntax::Decl,
    pub last_type_opt: Option<Text>,
}

impl prism_rtl::Job<(G, crate::check::types::St, Option<Text>)> for CollectDecl {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St, Option<Text>)> {
        let g = &self.g;
        let st = &self.st;
        let info = &self.info;
        let d = &self.d;
        let last_type_opt = &self.last_type_opt;
        match &d.kind {
            crate::syntax::DeclKind::DType(t) => {
                let name = qual_key(&info.name, &dotted(&t.name.path_));
                let ti = TyInfo { name: name.clone(), home: info.name.clone(), params: each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone())), body: TyBody::BOpaque, derives: Array::new(), file: info.file.clone(), span: d.span.clone() };
                if has_key(&g.types, &name) {
                    prism_rtl::Turn::Finished((g.clone(), crate::check::types::err(st, &Text::lit("collision"), &d.span, &Text::from(format!("a second type `{}`", &dotted(&t.name.path_)))), last_type_opt.clone()))
                } else {
                    {
                        let upd = {
                            let mut this: G = g.clone();
                            this.types = insert(&this.types, &name, &ti);
                            this
                        };
                        prism_rtl::Turn::Finished((upd.clone(), st.clone(), Some(name.clone())))
                    }
                }
            },
            crate::syntax::DeclKind::DDerive(trs) => match last_type_opt {
                Some(tn) => {
                    let upd = {
                        let mut this: G = g.clone();
                        this.types = insert(&this.types, tn, &add_derives(&or(&get(&g.types, tn), &dummy_ty_info()), &each(trs, &(|tr: &crate::syntax::TraitRef| dotted(&tr.path_)))));
                        this
                    };
                    prism_rtl::Turn::Finished((upd.clone(), st.clone(), last_type_opt.clone()))
                },
                None => prism_rtl::Turn::Finished((g.clone(), crate::check::types::err(st, &Text::lit("mismatch"), &d.span, &Text::lit("a `derive` line follows a type declaration")), None)),
            },
            crate::syntax::DeclKind::DTag(t) => {
                let name = dotted(&t.name.path_);
                let family = dotted(&take(&t.name.path_, &crate::syntax::lexer::dec(&len(&t.name.path_))));
                let tags = or(&get(&g.families, &family), &Array::new());
                let owner = or(&get(&g.fam_owner, &family), &info.name);
                let st2 = if &owner != &info.name {
                    crate::check::types::err(st, &Text::lit("collision"), &d.span, &Text::from(format!("the family `{}` is declared in {}; every tag of a family is declared in its family's module", &family, &(if &owner == &Text::lit("") {
                        Text::lit("the root")
                    } else {
                        Text::from(format!("`{}`", &owner))
                    }))))
                } else {
                    st.clone()
                };
                let is_elem = match &*t.of_type.kind {
                    crate::syntax::TypeKind::TName(n, _) => &dotted(&n.path_) == &Text::lit("Element"),
                    _ => false,
                };
                let g2 = {
                    let mut this: G = g.clone();
                    this.families = insert(&this.families, &family, &push(&tags, &name));
                    this.fam_owner = insert(&this.fam_owner, &family, &owner);
                    if is_elem {
                        this.elem_fams = crate::check::types::add_text(&this.elem_fams, &family);
                    }
                    this
                };
                prism_rtl::Turn::Finished((g2.clone(), st2.clone(), None))
            },
            crate::syntax::DeclKind::DTrait(t) => {
                let name = qual_key(&info.name, &dotted(&t.name.path_));
                let ti = TraitInfo { name: name.clone(), home: info.name.clone(), param: or(&index(&each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone())), &Nat::from(0u32)), &Text::lit("a")), supers: Array::new(), methods: Array::new(), defaults: Array::new(), assocs: Array::new(), file: info.file.clone(), span: d.span.clone() };
                let upd = {
                    let mut this: G = g.clone();
                    this.traits = insert(&this.traits, &name, &ti);
                    this
                };
                prism_rtl::Turn::Finished((upd.clone(), st.clone(), None))
            },
            _ => prism_rtl::Turn::Finished((g.clone(), st.clone(), None)),
        }
    }
}

/// `Start CollectDecl, x`: what the function value is when passed to `@Run`.
pub fn start_collect_decl(g: G, st: crate::check::types::St, info: ModInfo, d: crate::syntax::Decl, last_type_opt: Option<Text>) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St, Option<Text>)>> {
    Rc::new(CollectDecl { g, st, info, d, last_type_opt })
}

/// ```prism
/// let dummyTyInfo
/// ```
pub fn dummy_ty_info() -> TyInfo {
    TyInfo { name: Text::lit(""), home: Text::lit(""), params: Array::new(), body: TyBody::BOpaque, derives: Array::new(), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// AddDerives: fn TyInfo, [Text] -> TyInfo
/// ```
pub fn add_derives(ti: &TyInfo, trs: &Array<Text>) -> TyInfo {
    let mut this: TyInfo = ti.clone();
    this.derives = append(&this.derives, trs);
    this
}

/// ```prism
/// ProgramRow: fn G -> Rw
/// ```
pub fn program_row(g: &G) -> crate::check::types::Rw {
    crate::check::types::closed(&g.elem_fams)
}

/// ```prism
/// BuildTables: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn build_tables(g: &G, st: &crate::check::types::St, m: &Text) -> (G, crate::check::types::St) {
    match get(&g.mods, m) {
        None => (g.clone(), st.clone()),
        Some(info) => {
            let s0 = {
                let mut this: crate::check::types::St = st.clone();
                this.file = info.file.clone();
                this
            };
            let s1 = fold(&info.uses, &s0, &(|s: &crate::check::types::St, (u, _): &(Text, bool)| if has_key(&g.mods, u) || (u == &Text::lit("Prelude")) {
                s.clone()
            } else {
                crate::check::types::err(s, &Text::lit("unknown-name"), &info.tree.span, &Text::from(format!("no module `{}` among the program's files", u)))
            }));
            let starred = fold(&info.uses, &Array::new(), &(|acc: &Array<Text>, (u, star): &(Text, bool)| if *star && (u != m) { push(acc, u) } else { acc.clone() }));
            let sources = crate::check::types::add_text(&append(&Array::from(vec![m.clone()]), &starred), &Text::lit("Prelude"));
            let vals = run_to_end(fold_job(sources.clone(), Map::new(), {
                let g = g.clone();
                Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                    let g = g.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let src = p1;
                        prism_rtl::Turn::More(Rc::new(BareValuesOf { g: g.clone(), src: src.clone(), acc: acc.clone() }))
                    }))
                }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
            }));
            let tys = fold(&sources, &Map::new(), &(|acc: &Map<Text, Array<Text>>, src: &Text| bare_types_of(g, src, acc)));
            let trs = fold(&sources, &Map::new(), &(|acc: &Map<Text, Array<Text>>, src: &Text| bare_traits_of(g, src, acc)));
            let (rw, rv, s2) = module_row(g, &s1, &info);
            let info2 = {
                let mut this: ModInfo = info.clone();
                this.emit_rw = rw.clone();
                this.row_var = rv.clone();
                this
            };
            let upd = {
                let mut this: G = g.clone();
                this.bare = insert(&this.bare, m, &vals);
                this.bare_types = insert(&this.bare_types, m, &tys);
                this.bare_traits = insert(&this.bare_traits, m, &trs);
                this.mods = insert(&this.mods, m, &info2);
                this
            };
            (upd.clone(), s2.clone())
        },
    }
}

/// The step machine of `BuildTables`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildTables: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct BuildTables {
    pub g: G,
    pub st: crate::check::types::St,
    pub m: Text,
}

impl prism_rtl::Job<(G, crate::check::types::St)> for BuildTables {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let m = &self.m;
        match get(&g.mods, m) {
            None => prism_rtl::Turn::Finished((g.clone(), st.clone())),
            Some(info) => {
                let s0 = {
                    let mut this: crate::check::types::St = st.clone();
                    this.file = info.file.clone();
                    this
                };
                let s1 = fold(&info.uses, &s0, &(|s: &crate::check::types::St, (u, _): &(Text, bool)| if has_key(&g.mods, u) || (u == &Text::lit("Prelude")) {
                    s.clone()
                } else {
                    crate::check::types::err(s, &Text::lit("unknown-name"), &info.tree.span, &Text::from(format!("no module `{}` among the program's files", u)))
                }));
                let starred = fold(&info.uses, &Array::new(), &(|acc: &Array<Text>, (u, star): &(Text, bool)| if *star && (u != m) { push(acc, u) } else { acc.clone() }));
                let sources = crate::check::types::add_text(&append(&Array::from(vec![m.clone()]), &starred), &Text::lit("Prelude"));
                let g = g.clone();
                let m = m.clone();
                call_value(fold_job(sources.clone(), Map::new(), {
                    let g = g.clone();
                    Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                        let g = g.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let src = p1;
                            prism_rtl::Turn::More(Rc::new(BareValuesOf { g: g.clone(), src: src.clone(), acc: acc.clone() }))
                        }))
                    }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
                }), move |fold_13397: Map<Text, Array<Text>>| {
                    let vals = fold_13397;
                    let tys = fold(&sources, &Map::new(), &(|acc: &Map<Text, Array<Text>>, src: &Text| bare_types_of(&g, src, acc)));
                    let trs = fold(&sources, &Map::new(), &(|acc: &Map<Text, Array<Text>>, src: &Text| bare_traits_of(&g, src, acc)));
                    call_then(start_module_row(g.clone(), s1.clone(), info.clone()), move |module_row_13626: (crate::check::types::Rw, Text, crate::check::types::St)| {
                        let (rw, rv, s2) = module_row_13626;
                        let info2 = {
                            let mut this: ModInfo = info.clone();
                            this.emit_rw = rw.clone();
                            this.row_var = rv.clone();
                            this
                        };
                        let upd = {
                            let mut this: G = g.clone();
                            this.bare = insert(&this.bare, &m, &vals);
                            this.bare_types = insert(&this.bare_types, &m, &tys);
                            this.bare_traits = insert(&this.bare_traits, &m, &trs);
                            this.mods = insert(&this.mods, &m, &info2);
                            this
                        };
                        prism_rtl::Turn::Finished((upd.clone(), s2.clone()))
                    })
                })
            },
        }
    }
}

/// `Start BuildTables, x`: what the function value is when passed to `@Run`.
pub fn start_build_tables(g: G, st: crate::check::types::St, m: Text) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>> {
    Rc::new(BuildTables { g, st, m })
}

/// ```prism
/// AddBare: fn (Text ==> [Text]), Text, Text -> (Text ==> [Text])
/// ```
pub fn add_bare(acc: &Map<Text, Array<Text>>, name: &Text, qk: &Text) -> Map<Text, Array<Text>> {
    let have = or(&get(acc, name), &Array::new());
    if crate::check::types::has_text(&have, qk) {
        acc.clone()
    } else {
        insert(acc, name, &push(&have, qk))
    }
}

/// ```prism
/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_values_of(g: &G, src: &Text, acc: &Map<Text, Array<Text>>) -> Map<Text, Array<Text>> {
    match get(&g.mods, src) {
        None => acc.clone(),
        Some(info) => run_to_end(fold_job(info.tree.decls.clone(), acc.clone(), {
            let src = src.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::syntax::Decl)| {
                let src = src.clone();
                entered(once_job(move || {
                    let a = p0;
                    let d = p1;
                    prism_rtl::Turn::More(Rc::new(BareOfDecl { m: src.clone(), acc: a.clone(), d: d.clone() }))
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::syntax::Decl)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        })),
    }
}

/// The step machine of `BareValuesOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub struct BareValuesOf {
    pub g: G,
    pub src: Text,
    pub acc: Map<Text, Array<Text>>,
}

impl prism_rtl::Job<Map<Text, Array<Text>>> for BareValuesOf {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<Text>>> {
        let g = &self.g;
        let src = &self.src;
        let acc = &self.acc;
        match get(&g.mods, src) {
            None => prism_rtl::Turn::Finished(acc.clone()),
            Some(info) => fold_job(info.tree.decls.clone(), acc.clone(), {
                let src = src.clone();
                Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::syntax::Decl)| {
                    let src = src.clone();
                    entered(once_job(move || {
                        let a = p0;
                        let d = p1;
                        prism_rtl::Turn::More(Rc::new(BareOfDecl { m: src.clone(), acc: a.clone(), d: d.clone() }))
                    }))
                }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::syntax::Decl)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
            }).cycle(),
        }
    }
}

/// `Start BareValuesOf, x`: what the function value is when passed to `@Run`.
pub fn start_bare_values_of(g: G, src: Text, acc: Map<Text, Array<Text>>) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>> {
    Rc::new(BareValuesOf { g, src, acc })
}

/// ```prism
/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
/// ```
pub fn bare_of_decl(m: &Text, acc: &Map<Text, Array<Text>>, d: &crate::syntax::Decl) -> Map<Text, Array<Text>> {
    match &d.kind {
        crate::syntax::DeclKind::DSignature(s) => add_bare(acc, &def_name_text(&s.name), &qual_key(m, &def_name_text(&s.name))),
        crate::syntax::DeclKind::DFn(f) => add_bare(acc, &def_name_text(&f.name), &qual_key(m, &def_name_text(&f.name))),
        crate::syntax::DeclKind::DLet(l) => fold(&pattern_names(&l.pattern), acc, &(|a: &Map<Text, Array<Text>>, n: &Text| add_bare(a, n, &qual_key(m, n)))),
        crate::syntax::DeclKind::DWidget(w) => add_bare(acc, &sname_key(&w.name), &qual_key(m, &sname_key(&w.name))),
        crate::syntax::DeclKind::DType(t) => fold(&ctor_names_of(t), acc, &(|a: &Map<Text, Array<Text>>, c: &Text| add_bare(a, c, &qual_key(m, c)))),
        crate::syntax::DeclKind::DTrait(t) => fold(&t.items, acc, &(|a: &Map<Text, Array<Text>>, it: &crate::syntax::TraitItem| match it {
            crate::syntax::TraitItem::TiSignature(s) => add_bare(a, &def_name_text(&s.name), &qual_key(m, &def_name_text(&s.name))),
            _ => a.clone(),
        })),
        _ => acc.clone(),
    }
}

/// The step machine of `BareOfDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
/// ```
pub struct BareOfDecl {
    pub m: Text,
    pub acc: Map<Text, Array<Text>>,
    pub d: crate::syntax::Decl,
}

impl prism_rtl::Job<Map<Text, Array<Text>>> for BareOfDecl {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<Text>>> {
        let m = &self.m;
        let acc = &self.acc;
        let d = &self.d;
        match &d.kind {
            crate::syntax::DeclKind::DSignature(s) => prism_rtl::Turn::Finished(add_bare(acc, &def_name_text(&s.name), &qual_key(m, &def_name_text(&s.name)))),
            crate::syntax::DeclKind::DFn(f) => prism_rtl::Turn::Finished(add_bare(acc, &def_name_text(&f.name), &qual_key(m, &def_name_text(&f.name)))),
            crate::syntax::DeclKind::DLet(l) => {
                let acc = acc.clone();
                let l = l.clone();
                let m = m.clone();
                call_then(start_pattern_names(l.pattern.clone()), move |pattern_names_14771: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_14771, &acc, &(|a: &Map<Text, Array<Text>>, n: &Text| add_bare(a, n, &qual_key(&m, n))))))
            },
            crate::syntax::DeclKind::DWidget(w) => prism_rtl::Turn::Finished(add_bare(acc, &sname_key(&w.name), &qual_key(m, &sname_key(&w.name)))),
            crate::syntax::DeclKind::DType(t) => prism_rtl::Turn::Finished(fold(&ctor_names_of(t), acc, &(|a: &Map<Text, Array<Text>>, c: &Text| add_bare(a, c, &qual_key(m, c))))),
            crate::syntax::DeclKind::DTrait(t) => prism_rtl::Turn::Finished(fold(&t.items, acc, &(|a: &Map<Text, Array<Text>>, it: &crate::syntax::TraitItem| match it {
                crate::syntax::TraitItem::TiSignature(s) => add_bare(a, &def_name_text(&s.name), &qual_key(m, &def_name_text(&s.name))),
                _ => a.clone(),
            }))),
            _ => prism_rtl::Turn::Finished(acc.clone()),
        }
    }
}

/// `Start BareOfDecl, x`: what the function value is when passed to `@Run`.
pub fn start_bare_of_decl(m: Text, acc: Map<Text, Array<Text>>, d: crate::syntax::Decl) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>> {
    Rc::new(BareOfDecl { m, acc, d })
}

/// ```prism
/// CtorNamesOf: fn TypeDecl -> [Text]
/// ```
pub fn ctor_names_of(t: &crate::syntax::TypeDecl) -> Array<Text> {
    match &t.body {
        Some(crate::syntax::TypeBody::TbRecord(_)) => Array::from(vec![dotted(&t.name.path_)]),
        Some(crate::syntax::TypeBody::TbChoice(cs)) => each(cs, &(|c: &crate::syntax::Case_| sname_key(&c.name))),
        Some(crate::syntax::TypeBody::TbNewtype(c)) => Array::from(vec![sname_key(&c.name)]),
        Some(crate::syntax::TypeBody::TbUnit(i)) => Array::from(vec![i.name.clone()]),
        _ => Array::new(),
    }
}

/// ```prism
/// PatternNames: unbounded fn Pattern -> [Text]
/// ```
pub fn pattern_names(p_: &crate::syntax::Pattern_) -> Array<Text> {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => Array::from(vec![sname_key(n)]),
        crate::syntax::PatternKind::PCtor(_, ps) => run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc = p0;
            let q = p1;
            call_then(start_pattern_names(q.clone()), move |pattern_names_15647: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_15647)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PRecord(_, fs, _) => run_to_end(fold_job(fs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::FieldPat)| entered(once_job(move || {
            let acc = p0;
            let f = p1;
            call_then(start_pattern_names(f.pattern.clone()), move |pattern_names_15733: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_15733)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PSigil(_, q) => pattern_names(&**q),
        crate::syntax::PatternKind::PTuple(ps) => run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc = p0;
            let q = p1;
            call_then(start_pattern_names(q.clone()), move |pattern_names_15847: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_15847)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PArray(ps) => run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc = p0;
            let q = p1;
            call_then(start_pattern_names(q.clone()), move |pattern_names_15916: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_15916)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PGroup(q) => pattern_names(&**q),
        _ => Array::new(),
    }
}

/// The step machine of `PatternNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatternNames: unbounded fn Pattern -> [Text]
/// ```
pub struct PatternNames {
    pub p_: crate::syntax::Pattern_,
}

impl prism_rtl::Job<Array<Text>> for PatternNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let p_ = &self.p_;
        match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::Finished(Array::from(vec![sname_key(n)])),
            crate::syntax::PatternKind::PCtor(_, ps) => fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc = p0;
                let q = p1;
                call_then(start_pattern_names(q.clone()), move |pattern_names_15647: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_15647)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PRecord(_, fs, _) => fold_job(fs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::FieldPat)| entered(once_job(move || {
                let acc = p0;
                let f = p1;
                call_then(start_pattern_names(f.pattern.clone()), move |pattern_names_15733: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_15733)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PSigil(_, q) => prism_rtl::Turn::More(Rc::new(PatternNames { p_: (**q).clone() })),
            crate::syntax::PatternKind::PTuple(ps) => fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc = p0;
                let q = p1;
                call_then(start_pattern_names(q.clone()), move |pattern_names_15847: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_15847)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PArray(ps) => fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc = p0;
                let q = p1;
                call_then(start_pattern_names(q.clone()), move |pattern_names_15916: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_15916)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(PatternNames { p_: (**q).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatternNames, x`: what the function value is when passed to `@Run`.
pub fn start_pattern_names(p_: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatternNames { p_ })
}

/// ```prism
/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
/// ```
pub fn pattern_binders(p_: &crate::syntax::Pattern_) -> Array<(Text, crate::syntax::Range)> {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => Array::from(vec![(sname_key(n), n.span.clone())]),
        crate::syntax::PatternKind::PCtor(_, ps) => run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc = p0;
            let q = p1;
            call_then(start_pattern_binders(q.clone()), move |pattern_binders_16236: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_16236)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PRecord(_, fs, _) => run_to_end(fold_job(fs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)| entered(once_job(move || {
            let acc = p0;
            let f = p1;
            call_then(start_pattern_binders(f.pattern.clone()), move |pattern_binders_16324: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_16324)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PSigil(_, q) => pattern_binders(&**q),
        crate::syntax::PatternKind::PTuple(ps) => run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc = p0;
            let q = p1;
            call_then(start_pattern_binders(q.clone()), move |pattern_binders_16442: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_16442)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PArray(ps) => run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc = p0;
            let q = p1;
            call_then(start_pattern_binders(q.clone()), move |pattern_binders_16513: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_16513)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PGroup(q) => pattern_binders(&**q),
        _ => Array::new(),
    }
}

/// The step machine of `PatternBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
/// ```
pub struct PatternBinders {
    pub p_: crate::syntax::Pattern_,
}

impl prism_rtl::Job<Array<(Text, crate::syntax::Range)>> for PatternBinders {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, crate::syntax::Range)>> {
        let p_ = &self.p_;
        match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::Finished(Array::from(vec![(sname_key(n), n.span.clone())])),
            crate::syntax::PatternKind::PCtor(_, ps) => fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc = p0;
                let q = p1;
                call_then(start_pattern_binders(q.clone()), move |pattern_binders_16236: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_16236)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PRecord(_, fs, _) => fold_job(fs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)| entered(once_job(move || {
                let acc = p0;
                let f = p1;
                call_then(start_pattern_binders(f.pattern.clone()), move |pattern_binders_16324: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_16324)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PSigil(_, q) => prism_rtl::Turn::More(Rc::new(PatternBinders { p_: (**q).clone() })),
            crate::syntax::PatternKind::PTuple(ps) => fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc = p0;
                let q = p1;
                call_then(start_pattern_binders(q.clone()), move |pattern_binders_16442: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_16442)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PArray(ps) => fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc = p0;
                let q = p1;
                call_then(start_pattern_binders(q.clone()), move |pattern_binders_16513: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_16513)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(PatternBinders { p_: (**q).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatternBinders, x`: what the function value is when passed to `@Run`.
pub fn start_pattern_binders(p_: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>> {
    Rc::new(PatternBinders { p_ })
}

/// ```prism
/// BareTypesOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_types_of(g: &G, src: &Text, acc: &Map<Text, Array<Text>>) -> Map<Text, Array<Text>> {
    fold(&keys(&g.types), acc, &(|a: &Map<Text, Array<Text>>, k: &Text| match get(&g.types, k) {
        Some(ti) => if &ti.home == src {
            add_bare(a, &crate::check::types::bare_name(&ti.name), k)
        } else {
            a.clone()
        },
        None => a.clone(),
    }))
}

/// ```prism
/// BareTraitsOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_traits_of(g: &G, src: &Text, acc: &Map<Text, Array<Text>>) -> Map<Text, Array<Text>> {
    fold(&keys(&g.traits), acc, &(|a: &Map<Text, Array<Text>>, k: &Text| match get(&g.traits, k) {
        Some(ti) => if &ti.home == src {
            add_bare(a, &crate::check::types::bare_name(&ti.name), k)
        } else {
            a.clone()
        },
        None => a.clone(),
    }))
}

/// ```prism
/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
/// ```
pub fn module_row(g: &G, st: &crate::check::types::St, info: &ModInfo) -> (crate::check::types::Rw, Text, crate::check::types::St) {
    match &info.tree.emit_row {
        None => if info.root {
            (g.program_row.clone(), Text::lit(""), st.clone())
        } else {
            (crate::check::types::empty_row(), Text::lit(""), crate::check::types::err(st, &Text::lit("emit-element"), &info.tree.span, &Text::lit("a library writes its own row; this one writes no `emit` line")))
        },
        Some(row_decl) => {
            let (fams, vars, s2) = fold(&row_decl.terms, &(Array::new(), Array::new(), st.clone()), &(|(fs, vs, s): &(Array<Text>, Array<Text>, crate::check::types::St), term: &crate::syntax::RowTerm| row_term_of(g, s, info, term, fs, vs)));
            let s3 = if &len(&vars) > &Nat::from(1u32) {
                crate::check::types::err_fix(&s2, &Text::lit("row-two-tails"), &row_decl.span, &Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::join(&vars, &Text::lit(" | ")))), &Text::lit("keep one variable"))
            } else {
                s2.clone()
            };
            let tail = match index(&vars, &Nat::from(0u32)) {
                Some(v_) => crate::check::types::Tail::TlQ(v_.clone()),
                None => crate::check::types::Tail::TlClosed,
            };
            (crate::check::types::Rw { fams: crate::check::types::sort_texts(&fams), minus: Array::new(), tail: tail.clone() }, or(&index(&vars, &Nat::from(0u32)), &Text::lit("")), s3.clone())
        },
    }
}

/// The step machine of `ModuleRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
/// ```
pub struct ModuleRow {
    pub g: G,
    pub st: crate::check::types::St,
    pub info: ModInfo,
}

impl prism_rtl::Job<(crate::check::types::Rw, Text, crate::check::types::St)> for ModuleRow {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Rw, Text, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let info = &self.info;
        match &info.tree.emit_row {
            None => if info.root {
                prism_rtl::Turn::Finished((g.program_row.clone(), Text::lit(""), st.clone()))
            } else {
                prism_rtl::Turn::Finished((crate::check::types::empty_row(), Text::lit(""), crate::check::types::err(st, &Text::lit("emit-element"), &info.tree.span, &Text::lit("a library writes its own row; this one writes no `emit` line"))))
            },
            Some(row_decl) => {
                let (fams, vars, s2) = fold(&row_decl.terms, &(Array::new(), Array::new(), st.clone()), &(|(fs, vs, s): &(Array<Text>, Array<Text>, crate::check::types::St), term: &crate::syntax::RowTerm| row_term_of(g, s, info, term, fs, vs)));
                let s3 = if &len(&vars) > &Nat::from(1u32) {
                    crate::check::types::err_fix(&s2, &Text::lit("row-two-tails"), &row_decl.span, &Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::join(&vars, &Text::lit(" | ")))), &Text::lit("keep one variable"))
                } else {
                    s2.clone()
                };
                let tail = match index(&vars, &Nat::from(0u32)) {
                    Some(v_) => crate::check::types::Tail::TlQ(v_.clone()),
                    None => crate::check::types::Tail::TlClosed,
                };
                prism_rtl::Turn::Finished((crate::check::types::Rw { fams: crate::check::types::sort_texts(&fams), minus: Array::new(), tail: tail.clone() }, or(&index(&vars, &Nat::from(0u32)), &Text::lit("")), s3.clone()))
            },
        }
    }
}

/// `Start ModuleRow, x`: what the function value is when passed to `@Run`.
pub fn start_module_row(g: G, st: crate::check::types::St, info: ModInfo) -> Rc<dyn prism_rtl::Job<(crate::check::types::Rw, Text, crate::check::types::St)>> {
    Rc::new(ModuleRow { g, st, info })
}

/// ```prism
/// RowTermOf: fn G, St, ModInfo, RowTerm, [Text], [Text] -> (([Text], [Text], St))
/// ```
pub fn row_term_of(g: &G, s: &crate::check::types::St, info: &ModInfo, term: &crate::syntax::RowTerm, fs: &Array<Text>, vs: &Array<Text>) -> (Array<Text>, Array<Text>, crate::check::types::St) {
    match term {
        crate::syntax::RowTerm::RFamily(q) => (push(fs, &dotted(&q.path_)), vs.clone(), check_family(g, s, &dotted(&q.path_), &q.span)),
        crate::syntax::RowTerm::RVar(v_) => (fs.clone(), push(vs, &v_.name), s.clone()),
        crate::syntax::RowTerm::RType(t) => match &*t.kind {
            crate::syntax::TypeKind::TName(n, m18313_0_1) if (m18313_0_1.len() == 0) => {
                let name = dotted(&n.path_);
                if (&name == &Text::lit("Element")) && info.root {
                    (append(fs, &g.program_row.fams), vs.clone(), s.clone())
                } else {
                    if &name == &Text::lit("Element") {
                        (fs.clone(), vs.clone(), crate::check::types::err(s, &Text::lit("emit-element"), &t.span, &Text::lit("a library writes its own row; `emit Element` names the program's")))
                    } else {
                        if has_key(&g.tags, &name) || (&len(&n.path_) > &Nat::from(1u32)) {
                            (fs.clone(), vs.clone(), crate::check::types::err_fix(s, &Text::lit("row-single-tag"), &t.span, &Text::from(format!("a row names families, not tags: `{}`", &name)), &Text::from(format!("write `{}.*`", &dotted(&take(&n.path_, &crate::syntax::lexer::dec(&len(&n.path_))))))))
                        } else {
                            (fs.clone(), vs.clone(), crate::check::types::err(s, &Text::lit("kind"), &t.span, &Text::from(format!("`{}` is not a row", &name))))
                        }
                    }
                }
            },
            _ => (fs.clone(), vs.clone(), crate::check::types::err(s, &Text::lit("kind"), &t.span, &Text::lit("this is not a row"))),
            _ => unreachable!("no arm matched"),
        },
    }
}

/// ```prism
/// CheckFamily: fn G, St, Text, Range -> St
/// ```
pub fn check_family(g: &G, s: &crate::check::types::St, fam: &Text, span: &crate::syntax::Range) -> crate::check::types::St {
    if has_key(&g.families, fam) {
        s.clone()
    } else {
        crate::check::types::err(s, &Text::lit("unknown-name"), span, &Text::from(format!("no family `{}`: no module declares a `{}.` tag", fam, fam)))
    }
}

/// ```prism
/// ResolveValue: fn G, Text, SName -> ((?Text, Text))
/// ```
pub fn resolve_value(g: &G, m: &Text, n: &crate::syntax::SName) -> (Option<Text>, Text) {
    let marks = n.sigils.clone();
    if &len(&n.path_) == &Nat::from(1u32) {
        {
            let name = Text::from(format!("{}{}", &marks, &or(&index(&n.path_, &Nat::from(0u32)), &Text::lit(""))));
            let table = or(&get(&g.bare, m), &Map::new());
            let keys_ = or(&get(&table, &name), &Array::new());
            if &len(&keys_) == &Nat::from(1u32) {
                (index(&keys_, &Nat::from(0u32)), Text::lit(""))
            } else {
                if &len(&keys_) > &Nat::from(1u32) {
                    (Some(own_first(m, &keys_)), Text::lit("collision"))
                } else {
                    if &name == &Text::lit("never") {
                        (Some(Text::lit("Prelude.never")), Text::lit(""))
                    } else {
                        if has_key(&g.ctors, &name) {
                            (Some(name.clone()), Text::lit(""))
                        } else {
                            (None, Text::lit("unknown"))
                        }
                    }
                }
            }
        }
    } else {
        {
            let qual = qual_module(g, &take(&n.path_, &crate::syntax::lexer::dec(&len(&n.path_))));
            let last = or(&crate::syntax::lexer::last(&n.path_), &Text::lit(""));
            let qk = qual_key(&qual, &Text::from(format!("{}{}", &marks, &last)));
            if (&len_text(&marks) == &Nat::from(0u32)) && has_key(&g.tags, &dotted(&n.path_)) {
                (Some(dotted(&n.path_)), Text::lit("tag"))
            } else {
                if has_key(&g.vals, &qk) || has_key(&g.ctors, &qk) {
                    (Some(qk.clone()), Text::lit(""))
                } else {
                    (None, Text::lit("unknown"))
                }
            }
        }
    }
}

/// ```prism
/// ResolveType: fn G, Text, [Text] -> ((?Text, Text))
/// ```
pub fn resolve_type(g: &G, m: &Text, path_: &Array<Text>) -> (Option<Text>, Text) {
    if &len(path_) == &Nat::from(1u32) {
        {
            let keys_ = or(&get(&or(&get(&g.bare_types, m), &Map::new()), &or(&index(path_, &Nat::from(0u32)), &Text::lit(""))), &Array::new());
            if &len(&keys_) == &Nat::from(1u32) {
                (index(&keys_, &Nat::from(0u32)), Text::lit(""))
            } else {
                if &len(&keys_) > &Nat::from(1u32) {
                    (Some(own_first(m, &keys_)), Text::lit("collision"))
                } else {
                    (None, Text::lit("unknown"))
                }
            }
        }
    } else {
        {
            let qk = qual_key(&qual_module(g, &take(path_, &crate::syntax::lexer::dec(&len(path_)))), &or(&crate::syntax::lexer::last(path_), &Text::lit("")));
            if has_key(&g.types, &qk) {
                (Some(qk.clone()), Text::lit(""))
            } else {
                (None, Text::lit("unknown"))
            }
        }
    }
}

/// ```prism
/// OwnFirst: fn Text, [Text] -> Text
/// ```
pub fn own_first(m: &Text, keys_: &Array<Text>) -> Text {
    let own = filter(keys_, &(|k: &Text| (&qual_key(m, &crate::check::types::bare_name(k)) == k) || ((m == &Text::lit("")) && !crate::syntax::lexer::contains(k, &Text::lit(".")))));
    or(&index(&own, &Nat::from(0u32)), &or(&index(keys_, &Nat::from(0u32)), &Text::lit("")))
}

/// ```prism
/// ?ResolveTrait: fn G, Text, [Text] -> ?Text
/// ```
pub fn resolve_trait(g: &G, m: &Text, path_: &Array<Text>) -> Option<Text> {
    if &len(path_) == &Nat::from(1u32) {
        {
            let keys_ = or(&get(&or(&get(&g.bare_traits, m), &Map::new()), &or(&index(path_, &Nat::from(0u32)), &Text::lit(""))), &Array::new());
            index(&keys_, &Nat::from(0u32))
        }
    } else {
        {
            let qk = qual_key(&qual_module(g, &take(path_, &crate::syntax::lexer::dec(&len(path_)))), &or(&crate::syntax::lexer::last(path_), &Text::lit("")));
            if has_key(&g.traits, &qk) { Some(qk.clone()) } else { None }
        }
    }
}

/// ```prism
/// CxOf: fn G, Text -> Cx
/// ```
pub fn cx_of(g: &G, m: &Text) -> Cx_ {
    let info = or(&get(&g.mods, m), &or(&get(&g.mods, &Text::lit("")), &dummy_mod()));
    Cx_ { g: g.clone(), home: m.clone(), scope: info.emit_rw.clone(), row_vars: if &info.row_var == &Text::lit("") {
        Array::new()
    } else {
        Array::from(vec![info.row_var.clone()])
    }, unwritten: crate::check::types::Col::CBound }
}

/// ```prism
/// let dummyMod
/// ```
pub fn dummy_mod() -> ModInfo {
    ModInfo { name: Text::lit(""), file: Nat::from(0u32), emit_rw: crate::check::types::empty_row(), row_var: Text::lit(""), uses: Array::new(), root: false, tree: empty_module() }
}

/// ```prism
/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
/// ```
pub fn conv_type(cx_: &Cx_, st: &crate::check::types::St, t: &crate::syntax::Type) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, args) => {
            let (base, st2) = conv_named(cx_, st, n, args, &t.span);
            (crate::check::types::with_marks(&n.sigils, &base, &cx_.scope), st2.clone())
        },
        crate::syntax::TypeKind::TSigiled(sigils, inner) => {
            let (i, st2) = conv_type(cx_, st, &**inner);
            (crate::check::types::with_marks(sigils, &i, &cx_.scope), st2.clone())
        },
        crate::syntax::TypeKind::TArray(e, _) => {
            let (i, st2) = conv_type(cx_, st, &**e);
            (crate::check::types::Ty::TyArray(Rc::new(i.clone())), st2.clone())
        },
        crate::syntax::TypeKind::TTuple(ts) => {
            let (xs, st2) = conv_types(cx_, st, ts);
            (crate::check::types::Ty::TyTuple(xs.clone()), st2.clone())
        },
        crate::syntax::TypeKind::TGroup(x) => conv_type(cx_, st, &**x),
        crate::syntax::TypeKind::TMap(k, v_) => {
            let (kk, st2) = conv_type(cx_, st, &**k);
            let (vv, st3) = conv_type(cx_, &st2, &**v_);
            (crate::check::types::Ty::TyMap(Rc::new(kk.clone()), Rc::new(vv.clone())), st3.clone())
        },
        crate::syntax::TypeKind::TFn(color, ps, res) => {
            let (xs, st2) = conv_types(cx_, st, ps);
            let (r, st3) = conv_type(cx_, &st2, &**res);
            let c = match color {
                crate::syntax::Color::Bounded => cx_.unwritten.clone(),
                crate::syntax::Color::Unbounded => crate::check::types::Col::CUnbound,
                crate::syntax::Color::ColorVar(v_) => if &v_.name == &Text::lit("bounded") {
                    crate::check::types::Col::CBound
                } else {
                    crate::check::types::Col::CQ(v_.name.clone())
                },
            };
            (crate::check::types::Ty::TyFn(c.clone(), xs.clone(), Rc::new(r.clone())), st3.clone())
        },
        crate::syntax::TypeKind::TEmit(ty, row_t) => {
            let (rw, st2) = conv_row(cx_, st, &**row_t);
            let inner = {
                let mut this: Cx_ = cx_.clone();
                this.scope = rw.clone();
                this
            };
            conv_type(&inner, &st2, &**ty)
        },
        crate::syntax::TypeKind::TUnit(sigils) => (crate::check::types::with_marks(sigils, &crate::check::types::t_unit(), &cx_.scope), st.clone()),
        crate::syntax::TypeKind::TAny(tr) => match resolve_trait(&cx_.g, &cx_.home, &tr.path_) {
            Some(k) => (crate::check::types::Ty::TyAny(Array::from(vec![k.clone()])), st.clone()),
            None => (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unknown-name"), &tr.span, &Text::from(format!("no trait `^{}`", &dotted(&tr.path_))))),
        },
        crate::syntax::TypeKind::TAbsent => (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unsupported"), &t.span, &Text::lit("this checker does not implement sparse tuples"))),
        crate::syntax::TypeKind::TNonEmpty(_) => (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unsupported"), &t.span, &Text::lit("this checker does not implement non-empty arrays"))),
        crate::syntax::TypeKind::THole(_) => (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unsupported"), &t.span, &Text::lit("this checker does not implement higher-kinded traits"))),
        crate::syntax::TypeKind::TFamily(q) => (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("kind"), &t.span, &Text::from(format!("`{}.*` is a row, not a type", &dotted(&q.path_))))),
        crate::syntax::TypeKind::TRowUnion(_) => (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("kind"), &t.span, &Text::lit("a row is not a type"))),
    }
}

/// The step machine of `ConvType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
/// ```
pub struct ConvType {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ConvType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TName(n, args) => {
                let args = args.clone();
                let cx_ = cx_.clone();
                let n = n.clone();
                let st = st.clone();
                let t = t.clone();
                call_then(start_conv_named(cx_.clone(), st.clone(), n.clone(), args.clone(), t.span.clone()), move |conv_named_22543: (crate::check::types::Ty, crate::check::types::St)| {
                    let (base, st2) = conv_named_22543;
                    prism_rtl::Turn::Finished((crate::check::types::with_marks(&n.sigils, &base, &cx_.scope), st2.clone()))
                })
            },
            crate::syntax::TypeKind::TSigiled(sigils, inner) => {
                let cx_ = cx_.clone();
                let inner = (**inner).clone();
                let sigils = sigils.clone();
                let st = st.clone();
                call_then(start_conv_type(cx_.clone(), st.clone(), inner.clone()), move |conv_type_22684: (crate::check::types::Ty, crate::check::types::St)| {
                    let (i, st2) = conv_type_22684;
                    prism_rtl::Turn::Finished((crate::check::types::with_marks(&sigils, &i, &cx_.scope), st2.clone()))
                })
            },
            crate::syntax::TypeKind::TArray(e, _) => {
                let cx_ = cx_.clone();
                let e = (**e).clone();
                let st = st.clone();
                call_then(start_conv_type(cx_.clone(), st.clone(), e.clone()), move |conv_type_22803: (crate::check::types::Ty, crate::check::types::St)| {
                    let (i, st2) = conv_type_22803;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyArray(Rc::new(i.clone())), st2.clone()))
                })
            },
            crate::syntax::TypeKind::TTuple(ts) => {
                let cx_ = cx_.clone();
                let st = st.clone();
                let ts = ts.clone();
                call_then(start_conv_types(cx_.clone(), st.clone(), ts.clone()), move |conv_types_22890: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (xs, st2) = conv_types_22890;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyTuple(xs.clone()), st2.clone()))
                })
            },
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(ConvType { cx_: cx_.clone(), st: st.clone(), t: (**x).clone() })),
            crate::syntax::TypeKind::TMap(k, v_) => {
                let cx_ = cx_.clone();
                let k = (**k).clone();
                let st = st.clone();
                let v_ = (**v_).clone();
                call_then(start_conv_type(cx_.clone(), st.clone(), k.clone()), move |conv_type_23013: (crate::check::types::Ty, crate::check::types::St)| {
                    let (kk, st2) = conv_type_23013;
                    call_then(start_conv_type(cx_.clone(), st2.clone(), v_.clone()), move |conv_type_23058: (crate::check::types::Ty, crate::check::types::St)| {
                        let (vv, st3) = conv_type_23058;
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyMap(Rc::new(kk.clone()), Rc::new(vv.clone())), st3.clone()))
                    })
                })
            },
            crate::syntax::TypeKind::TFn(color, ps, res) => {
                let color = color.clone();
                let cx_ = cx_.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                let st = st.clone();
                call_then(start_conv_types(cx_.clone(), st.clone(), ps.clone()), move |conv_types_23160: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (xs, st2) = conv_types_23160;
                    call_then(start_conv_type(cx_.clone(), st2.clone(), res.clone()), move |conv_type_23206: (crate::check::types::Ty, crate::check::types::St)| {
                        let (r, st3) = conv_type_23206;
                        let c = match &color {
                            crate::syntax::Color::Bounded => cx_.unwritten.clone(),
                            crate::syntax::Color::Unbounded => crate::check::types::Col::CUnbound,
                            crate::syntax::Color::ColorVar(v_) => if &v_.name == &Text::lit("bounded") {
                                crate::check::types::Col::CBound
                            } else {
                                crate::check::types::Col::CQ(v_.name.clone())
                            },
                        };
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyFn(c.clone(), xs.clone(), Rc::new(r.clone())), st3.clone()))
                    })
                })
            },
            crate::syntax::TypeKind::TEmit(ty, row_t) => {
                let cx_ = cx_.clone();
                let row_t = (**row_t).clone();
                let st = st.clone();
                let ty = (**ty).clone();
                call_then(start_conv_row(cx_.clone(), st.clone(), row_t.clone()), move |conv_row_23473: (crate::check::types::Rw, crate::check::types::St)| {
                    let (rw, st2) = conv_row_23473;
                    let inner = {
                        let mut this: Cx_ = cx_.clone();
                        this.scope = rw.clone();
                        this
                    };
                    prism_rtl::Turn::More(Rc::new(ConvType { cx_: inner.clone(), st: st2.clone(), t: ty.clone() }))
                })
            },
            crate::syntax::TypeKind::TUnit(sigils) => prism_rtl::Turn::Finished((crate::check::types::with_marks(sigils, &crate::check::types::t_unit(), &cx_.scope), st.clone())),
            crate::syntax::TypeKind::TAny(tr) => match resolve_trait(&cx_.g, &cx_.home, &tr.path_) {
                Some(k) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyAny(Array::from(vec![k.clone()])), st.clone())),
                None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unknown-name"), &tr.span, &Text::from(format!("no trait `^{}`", &dotted(&tr.path_)))))),
            },
            crate::syntax::TypeKind::TAbsent => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unsupported"), &t.span, &Text::lit("this checker does not implement sparse tuples")))),
            crate::syntax::TypeKind::TNonEmpty(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unsupported"), &t.span, &Text::lit("this checker does not implement non-empty arrays")))),
            crate::syntax::TypeKind::THole(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unsupported"), &t.span, &Text::lit("this checker does not implement higher-kinded traits")))),
            crate::syntax::TypeKind::TFamily(q) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("kind"), &t.span, &Text::from(format!("`{}.*` is a row, not a type", &dotted(&q.path_)))))),
            crate::syntax::TypeKind::TRowUnion(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("kind"), &t.span, &Text::lit("a row is not a type")))),
        }
    }
}

/// `Start ConvType, x`: what the function value is when passed to `@Run`.
pub fn start_conv_type(cx_: Cx_, st: crate::check::types::St, t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(ConvType { cx_, st, t })
}

/// ```prism
/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
/// ```
pub fn conv_types(cx_: &Cx_, st: &crate::check::types::St, ts: &Array<crate::syntax::Type>) -> (Array<crate::check::types::Ty>, crate::check::types::St) {
    run_to_end(fold_job(ts.clone(), (Array::new(), st.clone()), {
        let cx_ = cx_.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)| {
            let cx_ = cx_.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let x = p1;
                call_then(start_conv_type(cx_.clone(), s.clone(), x.clone()), move |conv_type_24483: (crate::check::types::Ty, crate::check::types::St)| {
                    let (y, s2) = conv_type_24483;
                    prism_rtl::Turn::Finished((push(&acc, &y), s2.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }))
}

/// The step machine of `ConvTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
/// ```
pub struct ConvTypes {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub ts: Array<crate::syntax::Type>,
}

impl prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)> for ConvTypes {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Ty>, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let ts = &self.ts;
        fold_job(ts.clone(), (Array::new(), st.clone()), {
            let cx_ = cx_.clone();
            Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)| {
                let cx_ = cx_.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let x = p1;
                    call_then(start_conv_type(cx_.clone(), s.clone(), x.clone()), move |conv_type_24483: (crate::check::types::Ty, crate::check::types::St)| {
                        let (y, s2) = conv_type_24483;
                        prism_rtl::Turn::Finished((push(&acc, &y), s2.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start ConvTypes, x`: what the function value is when passed to `@Run`.
pub fn start_conv_types(cx_: Cx_, st: crate::check::types::St, ts: Array<crate::syntax::Type>) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>> {
    Rc::new(ConvTypes { cx_, st, ts })
}

/// ```prism
/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
/// ```
pub fn conv_named(cx_: &Cx_, st: &crate::check::types::St, n: &crate::syntax::SName, args: &Array<crate::syntax::Type>, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let name = dotted(&n.path_);
    if (&len(&n.path_) == &Nat::from(1u32)) && is_lower_text(&name) {
        if &len(args) > &Nat::from(0u32) {
            (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement higher-kinded traits")))
        } else {
            (crate::check::types::Ty::TyQ(name.clone()), st.clone())
        }
    } else {
        if (&name == &Text::lit("Element")) || (&name == &Text::lit("Prelude.Element")) {
            match len(args) {
                m25080_0 if (&m25080_0 == &Nat::from(0u32)) => (crate::check::types::Ty::TyElem(cx_.scope.clone(), Rc::new(crate::check::types::t_unit())), st.clone()),
                m25080_1 if (&m25080_1 == &Nat::from(1u32)) => {
                    let (o, st2) = conv_type(cx_, st, &or(&index(args, &Nat::from(0u32)), &dummy_type()));
                    (crate::check::types::Ty::TyElem(cx_.scope.clone(), Rc::new(o.clone())), st2.clone())
                },
                m25080_2 if (&m25080_2 == &Nat::from(2u32)) => {
                    let (rw, st2) = conv_row(cx_, st, &or(&index(args, &Nat::from(0u32)), &dummy_type()));
                    let (o, st3) = conv_type(cx_, &st2, &or(&index(args, &Nat::from(1u32)), &dummy_type()));
                    (crate::check::types::Ty::TyElem(rw.clone(), Rc::new(o.clone())), st3.clone())
                },
                _ => (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("kind"), span, &Text::from(format!("`Element` takes a row and a type; here it has {}", &crate::check::errors::count_word(&len(args)))))),
                _ => unreachable!("no arm matched"),
            }
        } else {
            if &name == &Text::lit("Elem") {
                match len(args) {
                    m25649_0 if (&m25649_0 == &Nat::from(0u32)) => (crate::check::types::Ty::TyElemAny(cx_.scope.clone()), st.clone()),
                    m25649_1 if (&m25649_1 == &Nat::from(1u32)) => {
                        let (rw, st2) = conv_row(cx_, st, &or(&index(args, &Nat::from(0u32)), &dummy_type()));
                        (crate::check::types::Ty::TyElemAny(rw.clone()), st2.clone())
                    },
                    _ => (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("kind"), span, &Text::from(format!("`Elem` takes a row; here it has {}", &crate::check::errors::count_word(&len(args)))))),
                    _ => unreachable!("no arm matched"),
                }
            } else {
                if (&name == &Text::lit("Answer")) || (&name == &Text::lit("Wired")) {
                    (crate::check::types::Ty::TyCon(name.clone(), Array::new()), st.clone())
                } else {
                    if &name == &Text::lit("Instant") {
                        (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement `Instant`")))
                    } else {
                        if crate::check::types::has_text(&Array::from(vec![Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")]), &name) {
                            (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement sized integers other than `U8`")))
                        } else {
                            if is_prim_type(&name) {
                                if &len(args) == &Nat::from(0u32) {
                                    (crate::check::types::Ty::TyCon(name.clone(), Array::new()), st.clone())
                                } else {
                                    (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("kind"), span, &Text::from(format!("`{}` takes no type; here it has {}", &name, &crate::check::errors::count_word(&len(args))))))
                                }
                            } else {
                                if (&name == &Text::lit("Buffer")) || (&name == &Text::lit("Table")) {
                                    {
                                        let want = if &name == &Text::lit("Buffer") { Nat::from(1u32) } else { Nat::from(2u32) };
                                        let (xs, st2) = conv_types(cx_, st, args);
                                        if &len(args) == &want {
                                            (crate::check::types::Ty::TyCon(name.clone(), xs.clone()), st2.clone())
                                        } else {
                                            (crate::check::types::Ty::TyErr, crate::check::types::err(&st2, &Text::lit("kind"), span, &Text::from(format!("`{}` takes {} types; here it has {}", &name, &crate::check::errors::count_word(&want), &crate::check::errors::count_word(&len(args))))))
                                        }
                                    }
                                } else {
                                    {
                                        let (key_opt, why) = resolve_type(&cx_.g, &cx_.home, &n.path_);
                                        match &key_opt {
                                            None => (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unknown-name"), span, &Text::from(format!("no type `{}`", &name)))),
                                            Some(qk) => {
                                                let ti = or(&get(&cx_.g.types, qk), &dummy_ty_info());
                                                let st1 = if &why == &Text::lit("collision") {
                                                    crate::check::types::err_fix(st, &Text::lit("collision"), span, &Text::from(format!("`{}` is declared by two modules this file reaches by a bare name", &name)), &Text::from(format!("write it qualified, `{}`, or rename this file's own", qk)))
                                                } else {
                                                    st.clone()
                                                };
                                                let (xs, st2) = conv_types(cx_, &st1, args);
                                                if &len(&xs) != &len(&ti.params) {
                                                    (crate::check::types::Ty::TyErr, crate::check::types::err(&st2, &Text::lit("kind"), span, &Text::from(format!("`{}` takes {} type{}; here it has {}", &name, &crate::check::errors::count_word(&len(&ti.params)), &(if &len(&ti.params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(&xs))))))
                                                } else {
                                                    match &ti.body {
                                                        TyBody::BAlias(body) => (crate::check::types::subst_q(&param_inst(&ti.params, &xs), body), st2.clone()),
                                                        TyBody::BRowKind => (crate::check::types::Ty::TyCon(qk.clone(), xs.clone()), st2.clone()),
                                                        _ => (crate::check::types::Ty::TyCon(qk.clone(), xs.clone()), st2.clone()),
                                                    }
                                                }
                                            },
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `ConvNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
/// ```
pub struct ConvNamed {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub n: crate::syntax::SName,
    pub args: Array<crate::syntax::Type>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ConvNamed {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let n = &self.n;
        let args = &self.args;
        let span = &self.span;
        let name = dotted(&n.path_);
        if (&len(&n.path_) == &Nat::from(1u32)) && is_lower_text(&name) {
            if &len(args) > &Nat::from(0u32) {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement higher-kinded traits"))))
            } else {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyQ(name.clone()), st.clone()))
            }
        } else {
            if (&name == &Text::lit("Element")) || (&name == &Text::lit("Prelude.Element")) {
                match len(args) {
                    m25080_0 if (&m25080_0 == &Nat::from(0u32)) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(cx_.scope.clone(), Rc::new(crate::check::types::t_unit())), st.clone())),
                    m25080_1 if (&m25080_1 == &Nat::from(1u32)) => {
                        let args = args.clone();
                        let cx_ = cx_.clone();
                        let st = st.clone();
                        call_then(start_conv_type(cx_.clone(), st.clone(), or(&index(&args, &Nat::from(0u32)), &dummy_type())), move |conv_type_25192: (crate::check::types::Ty, crate::check::types::St)| {
                            let (o, st2) = conv_type_25192;
                            prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(cx_.scope.clone(), Rc::new(o.clone())), st2.clone()))
                        })
                    },
                    m25080_2 if (&m25080_2 == &Nat::from(2u32)) => {
                        let args = args.clone();
                        let cx_ = cx_.clone();
                        let st = st.clone();
                        call_then(start_conv_row(cx_.clone(), st.clone(), or(&index(&args, &Nat::from(0u32)), &dummy_type())), move |conv_row_25328: (crate::check::types::Rw, crate::check::types::St)| {
                            let (rw, st2) = conv_row_25328;
                            call_then(start_conv_type(cx_.clone(), st2.clone(), or(&index(&args, &Nat::from(1u32)), &dummy_type())), move |conv_type_25401: (crate::check::types::Ty, crate::check::types::St)| {
                                let (o, st3) = conv_type_25401;
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(rw.clone(), Rc::new(o.clone())), st3.clone()))
                            })
                        })
                    },
                    _ => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("kind"), span, &Text::from(format!("`Element` takes a row and a type; here it has {}", &crate::check::errors::count_word(&len(args))))))),
                    _ => unreachable!("no arm matched"),
                }
            } else {
                if &name == &Text::lit("Elem") {
                    match len(args) {
                        m25649_0 if (&m25649_0 == &Nat::from(0u32)) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyElemAny(cx_.scope.clone()), st.clone())),
                        m25649_1 if (&m25649_1 == &Nat::from(1u32)) => {
                            let args = args.clone();
                            let cx_ = cx_.clone();
                            let st = st.clone();
                            call_then(start_conv_row(cx_.clone(), st.clone(), or(&index(&args, &Nat::from(0u32)), &dummy_type())), move |conv_row_25756: (crate::check::types::Rw, crate::check::types::St)| {
                                let (rw, st2) = conv_row_25756;
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyElemAny(rw.clone()), st2.clone()))
                            })
                        },
                        _ => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("kind"), span, &Text::from(format!("`Elem` takes a row; here it has {}", &crate::check::errors::count_word(&len(args))))))),
                        _ => unreachable!("no arm matched"),
                    }
                } else {
                    if (&name == &Text::lit("Answer")) || (&name == &Text::lit("Wired")) {
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(name.clone(), Array::new()), st.clone()))
                    } else {
                        if &name == &Text::lit("Instant") {
                            prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement `Instant`"))))
                        } else {
                            if crate::check::types::has_text(&Array::from(vec![Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")]), &name) {
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement sized integers other than `U8`"))))
                            } else {
                                if is_prim_type(&name) {
                                    if &len(args) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(name.clone(), Array::new()), st.clone()))
                                    } else {
                                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("kind"), span, &Text::from(format!("`{}` takes no type; here it has {}", &name, &crate::check::errors::count_word(&len(args)))))))
                                    }
                                } else {
                                    if (&name == &Text::lit("Buffer")) || (&name == &Text::lit("Table")) {
                                        {
                                            let want = if &name == &Text::lit("Buffer") { Nat::from(1u32) } else { Nat::from(2u32) };
                                            let args = args.clone();
                                            let cx_ = cx_.clone();
                                            let span = span.clone();
                                            let st = st.clone();
                                            call_then(start_conv_types(cx_.clone(), st.clone(), args.clone()), move |conv_types_26691: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                                                let (xs, st2) = conv_types_26691;
                                                if &len(&args) == &want {
                                                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(name.clone(), xs.clone()), st2.clone()))
                                                } else {
                                                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(&st2, &Text::lit("kind"), &span, &Text::from(format!("`{}` takes {} types; here it has {}", &name, &crate::check::errors::count_word(&want), &crate::check::errors::count_word(&len(&args)))))))
                                                }
                                            })
                                        }
                                    } else {
                                        {
                                            let (key_opt, why) = resolve_type(&cx_.g, &cx_.home, &n.path_);
                                            match &key_opt {
                                                None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unknown-name"), span, &Text::from(format!("no type `{}`", &name))))),
                                                Some(qk) => {
                                                    let ti = or(&get(&cx_.g.types, qk), &dummy_ty_info());
                                                    let st1 = if &why == &Text::lit("collision") {
                                                        crate::check::types::err_fix(st, &Text::lit("collision"), span, &Text::from(format!("`{}` is declared by two modules this file reaches by a bare name", &name)), &Text::from(format!("write it qualified, `{}`, or rename this file's own", qk)))
                                                    } else {
                                                        st.clone()
                                                    };
                                                    let args = args.clone();
                                                    let cx_ = cx_.clone();
                                                    let qk = qk.clone();
                                                    let span = span.clone();
                                                    call_then(start_conv_types(cx_.clone(), st1.clone(), args.clone()), move |conv_types_27392: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                                                        let (xs, st2) = conv_types_27392;
                                                        if &len(&xs) != &len(&ti.params) {
                                                            prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(&st2, &Text::lit("kind"), &span, &Text::from(format!("`{}` takes {} type{}; here it has {}", &name, &crate::check::errors::count_word(&len(&ti.params)), &(if &len(&ti.params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(&xs)))))))
                                                        } else {
                                                            match &ti.body {
                                                                TyBody::BAlias(body) => {
                                                                    let body = body.clone();
                                                                    call_then(crate::check::types::start_subst_q(param_inst(&ti.params, &xs), body.clone()), move |subst_q_27716: crate::check::types::Ty| prism_rtl::Turn::Finished((subst_q_27716, st2.clone())))
                                                                },
                                                                TyBody::BRowKind => prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(qk.clone(), xs.clone()), st2.clone())),
                                                                _ => prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(qk.clone(), xs.clone()), st2.clone())),
                                                            }
                                                        }
                                                    })
                                                },
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// `Start ConvNamed, x`: what the function value is when passed to `@Run`.
pub fn start_conv_named(cx_: Cx_, st: crate::check::types::St, n: crate::syntax::SName, args: Array<crate::syntax::Type>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(ConvNamed { cx_, st, n, args, span })
}

/// ```prism
/// let dummyType
/// ```
pub fn dummy_type() -> crate::syntax::Type {
    crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TAbsent), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// ParamInst: fn [Text], [Ty] -> Inst
/// ```
pub fn param_inst(ps: &Array<Text>, xs: &Array<crate::check::types::Ty>) -> crate::check::types::Inst {
    crate::check::types::Inst { tys: fold(&crate::check::errors::range0(&len(ps)), &Map::new(), &(|m: &Map<Text, crate::check::types::Ty>, i: &Nat| insert(m, &or(&index(ps, i), &Text::lit("")), &or(&index(xs, i), &crate::check::types::Ty::TyErr)))), rows: Map::new(), cols: Map::new() }
}

/// ```prism
/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
/// ```
pub fn conv_row(cx_: &Cx_, st: &crate::check::types::St, t: &crate::syntax::Type) -> (crate::check::types::Rw, crate::check::types::St) {
    let (fams, vars, st2) = row_parts(cx_, st, t);
    let st3 = if &len(&vars) > &Nat::from(1u32) {
        crate::check::types::err_fix(&st2, &Text::lit("row-two-tails"), &t.span, &Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::join(&vars, &Text::lit(" | ")))), &Text::lit("keep one variable"))
    } else {
        st2.clone()
    };
    let tail = match index(&vars, &Nat::from(0u32)) {
        Some(v_) => crate::check::types::Tail::TlQ(v_.clone()),
        None => crate::check::types::Tail::TlClosed,
    };
    (crate::check::types::Rw { fams: crate::check::types::sort_texts(&fams), minus: Array::new(), tail: tail.clone() }, st3.clone())
}

/// The step machine of `ConvRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
/// ```
pub struct ConvRow {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<(crate::check::types::Rw, crate::check::types::St)> for ConvRow {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Rw, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let t = &self.t;
        let cx_ = cx_.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_row_parts(cx_.clone(), st.clone(), t.clone()), move |row_parts_28275: (Array<Text>, Array<Text>, crate::check::types::St)| {
            let (fams, vars, st2) = row_parts_28275;
            let st3 = if &len(&vars) > &Nat::from(1u32) {
                crate::check::types::err_fix(&st2, &Text::lit("row-two-tails"), &t.span, &Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::join(&vars, &Text::lit(" | ")))), &Text::lit("keep one variable"))
            } else {
                st2.clone()
            };
            let tail = match index(&vars, &Nat::from(0u32)) {
                Some(v_) => crate::check::types::Tail::TlQ(v_.clone()),
                None => crate::check::types::Tail::TlClosed,
            };
            prism_rtl::Turn::Finished((crate::check::types::Rw { fams: crate::check::types::sort_texts(&fams), minus: Array::new(), tail: tail.clone() }, st3.clone()))
        })
    }
}

/// `Start ConvRow, x`: what the function value is when passed to `@Run`.
pub fn start_conv_row(cx_: Cx_, st: crate::check::types::St, t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(crate::check::types::Rw, crate::check::types::St)>> {
    Rc::new(ConvRow { cx_, st, t })
}

/// ```prism
/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
/// ```
pub fn row_parts(cx_: &Cx_, st: &crate::check::types::St, t: &crate::syntax::Type) -> (Array<Text>, Array<Text>, crate::check::types::St) {
    match &*t.kind {
        crate::syntax::TypeKind::TRowUnion(ts) => run_to_end(fold_job(ts.clone(), (Array::new(), Array::new(), st.clone()), {
            let cx_ = cx_.clone();
            Rc::new(move |(p0, p1): ((Array<Text>, Array<Text>, crate::check::types::St), crate::syntax::Type)| {
                let cx_ = cx_.clone();
                entered(once_job(move || {
                    let (fs, vs, s) = p0;
                    let x = p1;
                    call_then(start_row_parts(cx_.clone(), s.clone(), x.clone()), move |row_parts_28782: (Array<Text>, Array<Text>, crate::check::types::St)| {
                        let (f2, v2, s2) = row_parts_28782;
                        prism_rtl::Turn::Finished((append(&fs, &f2), append(&vs, &v2), s2.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<Text>, Array<Text>, crate::check::types::St), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<Text>, crate::check::types::St)>>>
        })),
        crate::syntax::TypeKind::TGroup(x) => row_parts(cx_, st, &**x),
        crate::syntax::TypeKind::TFamily(q) => (Array::from(vec![dotted(&q.path_)]), Array::new(), check_family(&cx_.g, st, &dotted(&q.path_), &q.span)),
        crate::syntax::TypeKind::TName(n, m28672_3_1) if (m28672_3_1.len() == 0) => {
            let name = dotted(&n.path_);
            if (&len(&n.path_) == &Nat::from(1u32)) && is_lower_text(&name) {
                (Array::new(), Array::from(vec![name.clone()]), st.clone())
            } else {
                if &name == &Text::lit("Element") {
                    (cx_.scope.fams.clone(), tail_names(&cx_.scope.tail), st.clone())
                } else {
                    (Array::new(), Array::new(), crate::check::types::err_fix(st, &Text::lit("row-single-tag"), &t.span, &Text::from(format!("a row names families, not tags: `{}`", &name)), &Text::from(format!("write `{}.*`", &dotted(&take(&n.path_, &crate::syntax::lexer::dec(&len(&n.path_))))))))
                }
            }
        },
        _ => (Array::new(), Array::new(), crate::check::types::err(st, &Text::lit("kind"), &t.span, &Text::lit("this is not a row"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
/// ```
pub struct RowParts {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<(Array<Text>, Array<Text>, crate::check::types::St)> for RowParts {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, Array<Text>, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TRowUnion(ts) => fold_job(ts.clone(), (Array::new(), Array::new(), st.clone()), {
                let cx_ = cx_.clone();
                Rc::new(move |(p0, p1): ((Array<Text>, Array<Text>, crate::check::types::St), crate::syntax::Type)| {
                    let cx_ = cx_.clone();
                    entered(once_job(move || {
                        let (fs, vs, s) = p0;
                        let x = p1;
                        call_then(start_row_parts(cx_.clone(), s.clone(), x.clone()), move |row_parts_28782: (Array<Text>, Array<Text>, crate::check::types::St)| {
                            let (f2, v2, s2) = row_parts_28782;
                            prism_rtl::Turn::Finished((append(&fs, &f2), append(&vs, &v2), s2.clone()))
                        })
                    }))
                }) as Rc<dyn Fn(((Array<Text>, Array<Text>, crate::check::types::St), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<Text>, crate::check::types::St)>>>
            }).cycle(),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(RowParts { cx_: cx_.clone(), st: st.clone(), t: (**x).clone() })),
            crate::syntax::TypeKind::TFamily(q) => prism_rtl::Turn::Finished((Array::from(vec![dotted(&q.path_)]), Array::new(), check_family(&cx_.g, st, &dotted(&q.path_), &q.span))),
            crate::syntax::TypeKind::TName(n, m28672_3_1) if (m28672_3_1.len() == 0) => {
                let name = dotted(&n.path_);
                if (&len(&n.path_) == &Nat::from(1u32)) && is_lower_text(&name) {
                    prism_rtl::Turn::Finished((Array::new(), Array::from(vec![name.clone()]), st.clone()))
                } else {
                    if &name == &Text::lit("Element") {
                        prism_rtl::Turn::Finished((cx_.scope.fams.clone(), tail_names(&cx_.scope.tail), st.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Array::new(), Array::new(), crate::check::types::err_fix(st, &Text::lit("row-single-tag"), &t.span, &Text::from(format!("a row names families, not tags: `{}`", &name)), &Text::from(format!("write `{}.*`", &dotted(&take(&n.path_, &crate::syntax::lexer::dec(&len(&n.path_)))))))))
                    }
                }
            },
            _ => prism_rtl::Turn::Finished((Array::new(), Array::new(), crate::check::types::err(st, &Text::lit("kind"), &t.span, &Text::lit("this is not a row")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start RowParts, x`: what the function value is when passed to `@Run`.
pub fn start_row_parts(cx_: Cx_, st: crate::check::types::St, t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<Text>, crate::check::types::St)>> {
    Rc::new(RowParts { cx_, st, t })
}

/// ```prism
/// TailNames: fn Tail -> [Text]
/// ```
pub fn tail_names(tail0: &crate::check::types::Tail) -> Array<Text> {
    match tail0 {
        crate::check::types::Tail::TlQ(v_) => Array::from(vec![v_.clone()]),
        crate::check::types::Tail::TlRigid(v_) => Array::from(vec![v_.clone()]),
        _ => Array::new(),
    }
}

/// ```prism
/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
/// ```
pub fn sig_scheme(cx_: &Cx_, st: &crate::check::types::St, t: &crate::syntax::Type, bounds: &Array<crate::syntax::Bound>) -> (crate::check::types::Scheme, crate::check::types::St) {
    let row_vars = crate::check::types::union_texts(&cx_.row_vars, &row_vars_of_type(t));
    let cx2 = {
        let mut this: Cx_ = cx_.clone();
        this.row_vars = row_vars.clone();
        this.unwritten = crate::check::types::Col::CBound;
        this
    };
    let written = color_vars_of_type(t);
    let (ty, defaults, joins, st2) = sig_type(&cx2, st, t, &written);
    let tvs = filter(&type_vars_of_type(t), &(|v_: &Text| !crate::check::types::has_text(&row_vars, v_)));
    let cqs = fold(&defaults, &written, &(|acc: &Array<Text>, v_: &Text| crate::check::types::add_text(acc, v_)));
    let (bs, st3) = conv_bounds(cx_, &st2, bounds);
    let rows_used = run_to_end(filter_job(row_vars.clone(), {
        let t = t.clone();
        Rc::new(move |p0: Text| {
            let t = t.clone();
            entered(once_job(move || {
                let v_ = p0;
                call_then(start_row_vars_of_type(t.clone()), move |row_vars_of_type_30303: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::has_text(&row_vars_of_type_30303, &v_) || uses_scope(&t)))
            }))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    (crate::check::types::Scheme { qs: tvs.clone(), plain_qs: Array::new(), rqs: rows_used.clone(), cqs: cqs.clone(), cjoins: joins.clone(), bounds: bs.clone(), ty: ty.clone() }, st3.clone())
}

/// The step machine of `SigScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
/// ```
pub struct SigScheme {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Type,
    pub bounds: Array<crate::syntax::Bound>,
}

impl prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)> for SigScheme {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Scheme, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let t = &self.t;
        let bounds = &self.bounds;
        let bounds = bounds.clone();
        let cx_ = cx_.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_row_vars_of_type(t.clone()), move |row_vars_of_type_29864: Array<Text>| {
            let row_vars = crate::check::types::union_texts(&cx_.row_vars, &row_vars_of_type_29864);
            let cx2 = {
                let mut this: Cx_ = cx_.clone();
                this.row_vars = row_vars.clone();
                this.unwritten = crate::check::types::Col::CBound;
                this
            };
            call_then(start_color_vars_of_type(t.clone()), move |color_vars_of_type_29985: Array<Text>| {
                let written = color_vars_of_type_29985;
                call_then(start_sig_type(cx2.clone(), st.clone(), t.clone(), written.clone()), move |sig_type_30042: (crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)| {
                    let (ty, defaults, joins, st2) = sig_type_30042;
                    call_then(start_type_vars_of_type(t.clone()), move |type_vars_of_type_30092: Array<Text>| {
                        let tvs = filter(&type_vars_of_type_30092, &(|v_: &Text| !crate::check::types::has_text(&row_vars, v_)));
                        let cqs = fold(&defaults, &written, &(|acc: &Array<Text>, v_: &Text| crate::check::types::add_text(acc, v_)));
                        let (bs, st3) = conv_bounds(&cx_, &st2, &bounds);
                        call_value(filter_job(row_vars.clone(), {
                            let t = t.clone();
                            Rc::new(move |p0: Text| {
                                let t = t.clone();
                                entered(once_job(move || {
                                    let v_ = p0;
                                    call_then(start_row_vars_of_type(t.clone()), move |row_vars_of_type_30303: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::has_text(&row_vars_of_type_30303, &v_) || uses_scope(&t)))
                                }))
                            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |filter_30272: Array<Text>| {
                            let rows_used = filter_30272;
                            prism_rtl::Turn::Finished((crate::check::types::Scheme { qs: tvs.clone(), plain_qs: Array::new(), rqs: rows_used.clone(), cqs: cqs.clone(), cjoins: joins.clone(), bounds: bs.clone(), ty: ty.clone() }, st3.clone()))
                        })
                    })
                })
            })
        })
    }
}

/// `Start SigScheme, x`: what the function value is when passed to `@Run`.
pub fn start_sig_scheme(cx_: Cx_, st: crate::check::types::St, t: crate::syntax::Type, bounds: Array<crate::syntax::Bound>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)>> {
    Rc::new(SigScheme { cx_, st, t, bounds })
}

/// ```prism
/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub fn sig_type(cx_: &Cx_, st: &crate::check::types::St, t: &crate::syntax::Type, written: &Array<Text>) -> (crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St) {
    match &*t.kind {
        crate::syntax::TypeKind::TGroup(x) => sig_type(cx_, st, &**x, written),
        crate::syntax::TypeKind::TFn(color, ps, res) => if mentions_time(t) || !takes_closure(t) {
            bounded_sig(cx_, st, t)
        } else {
            closure_sig(cx_, st, color, ps, &**res, written)
        },
        _ => bounded_sig(cx_, st, t),
    }
}

/// The step machine of `SigType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub struct SigType {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Type,
    pub written: Array<Text>,
}

impl prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> for SigType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let t = &self.t;
        let written = &self.written;
        match &*t.kind {
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(SigType { cx_: cx_.clone(), st: st.clone(), t: (**x).clone(), written: written.clone() })),
            crate::syntax::TypeKind::TFn(color, ps, res) => {
                let color = color.clone();
                let cx_ = cx_.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                let st = st.clone();
                let t = t.clone();
                let written = written.clone();
                call_then(start_mentions_time(t.clone()), move |mentions_time_31445: bool| if mentions_time_31445 || !takes_closure(&t) {
                    prism_rtl::Turn::More(Rc::new(BoundedSig { cx_: cx_.clone(), st: st.clone(), t: t.clone() }))
                } else {
                    prism_rtl::Turn::More(Rc::new(ClosureSig { cx_: cx_.clone(), st: st.clone(), color: color.clone(), ps: ps.clone(), res: res.clone(), written: written.clone() }))
                })
            },
            _ => prism_rtl::Turn::More(Rc::new(BoundedSig { cx_: cx_.clone(), st: st.clone(), t: t.clone() })),
        }
    }
}

/// `Start SigType, x`: what the function value is when passed to `@Run`.
pub fn start_sig_type(cx_: Cx_, st: crate::check::types::St, t: crate::syntax::Type, written: Array<Text>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)>> {
    Rc::new(SigType { cx_, st, t, written })
}

/// ```prism
/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub fn bounded_sig(cx_: &Cx_, st: &crate::check::types::St, t: &crate::syntax::Type) -> (crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St) {
    let (ty, st2) = conv_type(cx_, st, t);
    (ty.clone(), Array::new(), Array::new(), st2.clone())
}

/// The step machine of `BoundedSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub struct BoundedSig {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> for BoundedSig {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let t = &self.t;
        let cx_ = cx_.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_conv_type(cx_.clone(), st.clone(), t.clone()), move |conv_type_31726: (crate::check::types::Ty, crate::check::types::St)| {
            let (ty, st2) = conv_type_31726;
            prism_rtl::Turn::Finished((ty.clone(), Array::new(), Array::new(), st2.clone()))
        })
    }
}

/// `Start BoundedSig, x`: what the function value is when passed to `@Run`.
pub fn start_bounded_sig(cx_: Cx_, st: crate::check::types::St, t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)>> {
    Rc::new(BoundedSig { cx_, st, t })
}

/// ```prism
/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub fn closure_sig(cx_: &Cx_, st: &crate::check::types::St, color: &crate::syntax::Color, ps: &Array<crate::syntax::Type>, res: &crate::syntax::Type, written: &Array<Text>) -> (crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St) {
    let (outer_set, outer_w) = written_col(color);
    let bounded_outer = outer_set && (&outer_w == &crate::check::types::Col::CBound);
    let n_default = len(&run_to_end(filter_job(ps.clone(), Rc::new(move |p0: crate::syntax::Type| entered(once_job(move || {
        let p_ = p0;
        call_then(start_is_fn_type(p_.clone()), move |is_fn_type_32064: bool| prism_rtl::Turn::Finished(is_fn_type_32064 && !writes_col(&top_color(&p_))))
    }))) as Rc<dyn Fn(crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>>>)));
    let names = fresh_col_names(written, &(if bounded_outer { Nat::from(0u32) } else { n_default.clone() }));
    let (pcols, _) = run_to_end(fold_job(ps.clone(), (Array::new(), Nat::from(0u32)), {
        let bounded_outer = bounded_outer;
        let names = names.clone();
        Rc::new(move |(p0, p1): ((Array<(bool, crate::check::types::Col)>, Nat), crate::syntax::Type)| {
            let bounded_outer = bounded_outer;
            let names = names.clone();
            entered(once_job(move || {
                let (acc, k) = p0;
                let p_ = p1;
                call_then(start_is_fn_type(p_.clone()), move |is_fn_type_32341: bool| if !is_fn_type_32341 {
                    prism_rtl::Turn::Finished((push(&acc, &(false, crate::check::types::Col::CBound)), k.clone()))
                } else {
                    call_then(start_top_color(p_.clone()), move |top_color_32446: crate::syntax::Color| {
                        let (set, c) = written_col(&top_color_32446);
                        if set {
                            prism_rtl::Turn::Finished((push(&acc, &(true, c.clone())), k.clone()))
                        } else {
                            if bounded_outer {
                                prism_rtl::Turn::Finished((push(&acc, &(true, crate::check::types::Col::CBound)), k.clone()))
                            } else {
                                prism_rtl::Turn::Finished((push(&acc, &(true, crate::check::types::Col::CQ(or(&index(&names, &k), &Text::lit("u"))))), &k + &Nat::from(1u32)))
                            }
                        }
                    })
                })
            }))
        }) as Rc<dyn Fn(((Array<(bool, crate::check::types::Col)>, Nat), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<(bool, crate::check::types::Col)>, Nat)>>>
    }));
    let vars = fold(&pcols, &Array::new(), &(|acc: &Array<Text>, (_, c): &(bool, crate::check::types::Col)| match c {
        crate::check::types::Col::CQ(v_) => crate::check::types::add_text(acc, v_),
        _ => acc.clone(),
    }));
    let any_unbounded = fold(&pcols, &false, &(|seen: &bool, (_, c): &(bool, crate::check::types::Col)| *seen || (c == &crate::check::types::Col::CUnbound)));
    let spare = fresh_col_names(&append(written, &names), &Nat::from(1u32));
    let outer_name = if (outer_set || any_unbounded) || (&len(&vars) < &Nat::from(2u32)) {
        Text::lit("")
    } else {
        or(&index(&spare, &Nat::from(0u32)), &Text::lit("u"))
    };
    let outer = if outer_set {
        outer_w.clone()
    } else {
        if any_unbounded {
            crate::check::types::Col::CUnbound
        } else {
            if &len(&vars) == &Nat::from(0u32) {
                crate::check::types::Col::CBound
            } else {
                if &len(&vars) == &Nat::from(1u32) {
                    crate::check::types::Col::CQ(or(&index(&vars, &Nat::from(0u32)), &Text::lit("u")))
                } else {
                    crate::check::types::Col::CQ(outer_name.clone())
                }
            }
        }
    };
    let joins = match &outer {
        crate::check::types::Col::CQ(hi) => each(&filter(&vars, &(|v_: &Text| v_ != hi)), &(|v_: &Text| (v_.clone(), hi.clone()))),
        _ => Array::new(),
    };
    let cx_outer = with_unwritten(cx_, &outer);
    let (xs, st2) = run_to_end(fold_job(crate::check::errors::range0(&len(ps)), (Array::new(), st.clone()), {
        let ps = ps.clone();
        let res = res.clone();
        let pcols = pcols.clone();
        let cx_ = cx_.clone();
        let cx_outer = cx_outer.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
            let ps = ps.clone();
            let res = res.clone();
            let pcols = pcols.clone();
            let cx_ = cx_.clone();
            let cx_outer = cx_outer.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let i = p1;
                {
                    let p_ = or(&index(&ps, &i), &res);
                    let (is_fn, c) = or(&index(&pcols, &i), &(false, crate::check::types::Col::CBound));
                    let pcx = if is_fn { with_unwritten(&cx_, &c) } else { cx_outer.clone() };
                    call_then(start_conv_type(pcx.clone(), s.clone(), p_.clone()), move |conv_type_33615: (crate::check::types::Ty, crate::check::types::St)| {
                        let (y, s2) = conv_type_33615;
                        prism_rtl::Turn::Finished((push(&acc, &y), s2.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }));
    let (r, st3) = conv_type(&cx_outer, &st2, res);
    let added = if &outer_name == &Text::lit("") { names.clone() } else { push(&names, &outer_name) };
    (crate::check::types::Ty::TyFn(outer.clone(), xs.clone(), Rc::new(r.clone())), added.clone(), joins.clone(), st3.clone())
}

/// The step machine of `ClosureSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub struct ClosureSig {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub color: crate::syntax::Color,
    pub ps: Array<crate::syntax::Type>,
    pub res: crate::syntax::Type,
    pub written: Array<Text>,
}

impl prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> for ClosureSig {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let color = &self.color;
        let ps = &self.ps;
        let res = &self.res;
        let written = &self.written;
        let (outer_set, outer_w) = written_col(color);
        let bounded_outer = outer_set && (&outer_w == &crate::check::types::Col::CBound);
        let color = color.clone();
        let cx_ = cx_.clone();
        let ps = ps.clone();
        let res = res.clone();
        let st = st.clone();
        let written = written.clone();
        call_value(filter_job(ps.clone(), Rc::new(move |p0: crate::syntax::Type| entered(once_job(move || {
            let p_ = p0;
            call_then(start_is_fn_type(p_.clone()), move |is_fn_type_32064: bool| prism_rtl::Turn::Finished(is_fn_type_32064 && !writes_col(&top_color(&p_))))
        }))) as Rc<dyn Fn(crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>>>), move |filter_32047: Array<crate::syntax::Type>| {
            let n_default = len(&filter_32047);
            call_then(start_fresh_col_names(written.clone(), if bounded_outer { Nat::from(0u32) } else { n_default.clone() }), move |fresh_col_names_32126: Array<Text>| {
                let names = fresh_col_names_32126;
                call_value(fold_job(ps.clone(), (Array::new(), Nat::from(0u32)), {
                    let bounded_outer = bounded_outer;
                    let names = names.clone();
                    Rc::new(move |(p0, p1): ((Array<(bool, crate::check::types::Col)>, Nat), crate::syntax::Type)| {
                        let bounded_outer = bounded_outer;
                        let names = names.clone();
                        entered(once_job(move || {
                            let (acc, k) = p0;
                            let p_ = p1;
                            call_then(start_is_fn_type(p_.clone()), move |is_fn_type_32341: bool| if !is_fn_type_32341 {
                                prism_rtl::Turn::Finished((push(&acc, &(false, crate::check::types::Col::CBound)), k.clone()))
                            } else {
                                call_then(start_top_color(p_.clone()), move |top_color_32446: crate::syntax::Color| {
                                    let (set, c) = written_col(&top_color_32446);
                                    if set {
                                        prism_rtl::Turn::Finished((push(&acc, &(true, c.clone())), k.clone()))
                                    } else {
                                        if bounded_outer {
                                            prism_rtl::Turn::Finished((push(&acc, &(true, crate::check::types::Col::CBound)), k.clone()))
                                        } else {
                                            prism_rtl::Turn::Finished((push(&acc, &(true, crate::check::types::Col::CQ(or(&index(&names, &k), &Text::lit("u"))))), &k + &Nat::from(1u32)))
                                        }
                                    }
                                })
                            })
                        }))
                    }) as Rc<dyn Fn(((Array<(bool, crate::check::types::Col)>, Nat), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<(bool, crate::check::types::Col)>, Nat)>>>
                }), move |fold_32286: (Array<(bool, crate::check::types::Col)>, Nat)| {
                    let (pcols, _) = fold_32286;
                    let vars = fold(&pcols, &Array::new(), &(|acc: &Array<Text>, (_, c): &(bool, crate::check::types::Col)| match c {
                        crate::check::types::Col::CQ(v_) => crate::check::types::add_text(acc, v_),
                        _ => acc.clone(),
                    }));
                    let any_unbounded = fold(&pcols, &false, &(|seen: &bool, (_, c): &(bool, crate::check::types::Col)| *seen || (c == &crate::check::types::Col::CUnbound)));
                    call_then(start_fresh_col_names(append(&written, &names), Nat::from(1u32)), move |fresh_col_names_32874: Array<Text>| {
                        let spare = fresh_col_names_32874;
                        let outer_name = if (outer_set || any_unbounded) || (&len(&vars) < &Nat::from(2u32)) {
                            Text::lit("")
                        } else {
                            or(&index(&spare, &Nat::from(0u32)), &Text::lit("u"))
                        };
                        let outer = if outer_set {
                            outer_w.clone()
                        } else {
                            if any_unbounded {
                                crate::check::types::Col::CUnbound
                            } else {
                                if &len(&vars) == &Nat::from(0u32) {
                                    crate::check::types::Col::CBound
                                } else {
                                    if &len(&vars) == &Nat::from(1u32) {
                                        crate::check::types::Col::CQ(or(&index(&vars, &Nat::from(0u32)), &Text::lit("u")))
                                    } else {
                                        crate::check::types::Col::CQ(outer_name.clone())
                                    }
                                }
                            }
                        };
                        let joins = match &outer {
                            crate::check::types::Col::CQ(hi) => each(&filter(&vars, &(|v_: &Text| v_ != hi)), &(|v_: &Text| (v_.clone(), hi.clone()))),
                            _ => Array::new(),
                        };
                        let cx_outer = with_unwritten(&cx_, &outer);
                        call_value(fold_job(crate::check::errors::range0(&len(&ps)), (Array::new(), st.clone()), {
                            let ps = ps.clone();
                            let res = res.clone();
                            let pcols = pcols.clone();
                            let cx_ = cx_.clone();
                            let cx_outer = cx_outer.clone();
                            Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
                                let ps = ps.clone();
                                let res = res.clone();
                                let pcols = pcols.clone();
                                let cx_ = cx_.clone();
                                let cx_outer = cx_outer.clone();
                                entered(once_job(move || {
                                    let (acc, s) = p0;
                                    let i = p1;
                                    {
                                        let p_ = or(&index(&ps, &i), &res);
                                        let (is_fn, c) = or(&index(&pcols, &i), &(false, crate::check::types::Col::CBound));
                                        let pcx = if is_fn { with_unwritten(&cx_, &c) } else { cx_outer.clone() };
                                        call_then(start_conv_type(pcx.clone(), s.clone(), p_.clone()), move |conv_type_33615: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (y, s2) = conv_type_33615;
                                            prism_rtl::Turn::Finished((push(&acc, &y), s2.clone()))
                                        })
                                    }
                                }))
                            }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
                        }), move |fold_33388: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                            let (xs, st2) = fold_33388;
                            call_then(start_conv_type(cx_outer.clone(), st2.clone(), res.clone()), move |conv_type_33685: (crate::check::types::Ty, crate::check::types::St)| {
                                let (r, st3) = conv_type_33685;
                                let added = if &outer_name == &Text::lit("") { names.clone() } else { push(&names, &outer_name) };
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyFn(outer.clone(), xs.clone(), Rc::new(r.clone())), added.clone(), joins.clone(), st3.clone()))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start ClosureSig, x`: what the function value is when passed to `@Run`.
pub fn start_closure_sig(cx_: Cx_, st: crate::check::types::St, color: crate::syntax::Color, ps: Array<crate::syntax::Type>, res: crate::syntax::Type, written: Array<Text>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)>> {
    Rc::new(ClosureSig { cx_, st, color, ps, res, written })
}

/// ```prism
/// WrittenCol: fn Color -> ((Bool, Col))
/// ```
pub fn written_col(color0: &crate::syntax::Color) -> (bool, crate::check::types::Col) {
    match color0 {
        crate::syntax::Color::Bounded => (false, crate::check::types::Col::CBound),
        crate::syntax::Color::Unbounded => (true, crate::check::types::Col::CUnbound),
        crate::syntax::Color::ColorVar(v_) => if &v_.name == &Text::lit("bounded") {
            (true, crate::check::types::Col::CBound)
        } else {
            (true, crate::check::types::Col::CQ(v_.name.clone()))
        },
    }
}

/// ```prism
/// WithUnwritten: fn Cx, Col -> Cx
/// ```
pub fn with_unwritten(cx_: &Cx_, c: &crate::check::types::Col) -> Cx_ {
    let mut this: Cx_ = cx_.clone();
    this.unwritten = c.clone();
    this
}

/// ```prism
/// WritesCol: fn Color -> Bool
/// ```
pub fn writes_col(color0: &crate::syntax::Color) -> bool {
    match color0 {
        crate::syntax::Color::Bounded => false,
        _ => true,
    }
}

/// ```prism
/// TopColor: unbounded fn Type -> Color
/// ```
pub fn top_color(t: &crate::syntax::Type) -> crate::syntax::Color {
    match &*t.kind {
        crate::syntax::TypeKind::TFn(c, _, _) => c.clone(),
        crate::syntax::TypeKind::TGroup(x) => top_color(&**x),
        _ => crate::syntax::Color::Bounded,
    }
}

/// The step machine of `TopColor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TopColor: unbounded fn Type -> Color
/// ```
pub struct TopColor {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<crate::syntax::Color> for TopColor {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::Color> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TFn(c, _, _) => prism_rtl::Turn::Finished(c.clone()),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(TopColor { t: (**x).clone() })),
            _ => prism_rtl::Turn::Finished(crate::syntax::Color::Bounded),
        }
    }
}

/// `Start TopColor, x`: what the function value is when passed to `@Run`.
pub fn start_top_color(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<crate::syntax::Color>> {
    Rc::new(TopColor { t })
}

/// ```prism
/// FreshColNames: unbounded fn [Text], Nat -> [Text]
/// ```
pub fn fresh_col_names(taken: &Array<Text>, n: &Nat) -> Array<Text> {
    let (names, _) = run_to_end(fold_job(crate::check::errors::range0(n), (Array::new(), Nat::from(1u32)), {
        let taken = taken.clone();
        let n = n.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, Nat), Nat)| {
            let taken = taken.clone();
            let n = n.clone();
            entered(once_job(move || {
                let (acc, k) = p0;
                let _ = p1;
                {
                    let k2 = next_free_col(&append(&taken, &acc), &(if &n == &Nat::from(1u32) { Nat::from(0u32) } else { k.clone() }));
                    prism_rtl::Turn::Finished((push(&acc, &sig_col_name(&k2)), &k2 + &Nat::from(1u32)))
                }
            }))
        }) as Rc<dyn Fn(((Array<Text>, Nat), Nat)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Nat)>>>
    }));
    names.clone()
}

/// The step machine of `FreshColNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreshColNames: unbounded fn [Text], Nat -> [Text]
/// ```
pub struct FreshColNames {
    pub taken: Array<Text>,
    pub n: Nat,
}

impl prism_rtl::Job<Array<Text>> for FreshColNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let taken = &self.taken;
        let n = &self.n;
        let n = n.clone();
        let taken = taken.clone();
        call_value(fold_job(crate::check::errors::range0(&n), (Array::new(), Nat::from(1u32)), {
            let taken = taken.clone();
            let n = n.clone();
            Rc::new(move |(p0, p1): ((Array<Text>, Nat), Nat)| {
                let taken = taken.clone();
                let n = n.clone();
                entered(once_job(move || {
                    let (acc, k) = p0;
                    let _ = p1;
                    {
                        let k2 = next_free_col(&append(&taken, &acc), &(if &n == &Nat::from(1u32) { Nat::from(0u32) } else { k.clone() }));
                        prism_rtl::Turn::Finished((push(&acc, &sig_col_name(&k2)), &k2 + &Nat::from(1u32)))
                    }
                }))
            }) as Rc<dyn Fn(((Array<Text>, Nat), Nat)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Nat)>>>
        }), move |fold_34753: (Array<Text>, Nat)| {
            let (names, _) = fold_34753;
            prism_rtl::Turn::Finished(names.clone())
        })
    }
}

/// `Start FreshColNames, x`: what the function value is when passed to `@Run`.
pub fn start_fresh_col_names(taken: Array<Text>, n: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(FreshColNames { taken, n })
}

/// ```prism
/// NextFreeCol: unbounded fn [Text], Nat -> Nat
/// ```
pub fn next_free_col(taken: &Array<Text>, k: &Nat) -> Nat {
    if crate::check::types::has_text(taken, &sig_col_name(k)) {
        next_free_col(taken, &(k + &Nat::from(1u32)))
    } else {
        k.clone()
    }
}

/// ```prism
/// SigColName: fn Nat -> Text
/// ```
pub fn sig_col_name(n0: &Nat) -> Text {
    match n0 {
        c0_0 if (c0_0 == &Nat::from(0u32)) => Text::lit("u"),
        k => Text::from(format!("u{}", k)),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ConvBounds: fn Cx, St, [Bound] -> (([((Text, Text))], St))
/// ```
pub fn conv_bounds(cx_: &Cx_, st: &crate::check::types::St, bounds: &Array<crate::syntax::Bound>) -> (Array<(Text, Text)>, crate::check::types::St) {
    fold(bounds, &(Array::new(), st.clone()), &(|(acc, s): &(Array<(Text, Text)>, crate::check::types::St), b: &crate::syntax::Bound| fold(&b.traits, &(acc.clone(), s.clone()), &(|(a2, s2): &(Array<(Text, Text)>, crate::check::types::St), tr: &crate::syntax::TraitRef| match resolve_trait(&cx_.g, &cx_.home, &tr.path_) {
        Some(k) => (push(a2, &(b.var.name.clone(), k.clone())), s2.clone()),
        None => (a2.clone(), crate::check::types::err(s2, &Text::lit("unknown-name"), &tr.span, &Text::from(format!("no trait `^{}`", &dotted(&tr.path_))))),
    }))))
}

/// ```prism
/// MentionsTime: unbounded fn Type -> Bool
/// ```
pub fn mentions_time(t: &crate::syntax::Type) -> bool {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, args) => ((crate::syntax::lexer::contains(&n.sigils, &Text::lit("$")) || crate::syntax::lexer::contains(&n.sigils, &Text::lit("!"))) || crate::syntax::lexer::contains(&n.sigils, &Text::lit("@"))) || run_to_end(fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || mentions_time(&a))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TSigiled(s, i) => ((crate::syntax::lexer::contains(s, &Text::lit("$")) || crate::syntax::lexer::contains(s, &Text::lit("!"))) || crate::syntax::lexer::contains(s, &Text::lit("@"))) || mentions_time(&**i),
        crate::syntax::TypeKind::TUnit(s) => (crate::syntax::lexer::contains(s, &Text::lit("$")) || crate::syntax::lexer::contains(s, &Text::lit("!"))) || crate::syntax::lexer::contains(s, &Text::lit("@")),
        crate::syntax::TypeKind::TArray(e, _) => mentions_time(&**e),
        crate::syntax::TypeKind::TTuple(ts) => run_to_end(fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || mentions_time(&a))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TGroup(x) => mentions_time(&**x),
        crate::syntax::TypeKind::TMap(k, v_) => mentions_time(&**k) || mentions_time(&**v_),
        crate::syntax::TypeKind::TFn(_, ps, res) => run_to_end(fold_job(ps.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || mentions_time(&a))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)) || mentions_time(&**res),
        crate::syntax::TypeKind::TEmit(ty, _) => true,
        _ => false,
    }
}

/// The step machine of `MentionsTime`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MentionsTime: unbounded fn Type -> Bool
/// ```
pub struct MentionsTime {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<bool> for MentionsTime {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TName(n, args) => prism_rtl::Turn::Finished(((crate::syntax::lexer::contains(&n.sigils, &Text::lit("$")) || crate::syntax::lexer::contains(&n.sigils, &Text::lit("!"))) || crate::syntax::lexer::contains(&n.sigils, &Text::lit("@"))) || run_to_end(fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
                let seen = p0;
                let a = p1;
                prism_rtl::Turn::Finished(seen || mentions_time(&a))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>))),
            crate::syntax::TypeKind::TSigiled(s, i) => prism_rtl::Turn::Finished(((crate::syntax::lexer::contains(s, &Text::lit("$")) || crate::syntax::lexer::contains(s, &Text::lit("!"))) || crate::syntax::lexer::contains(s, &Text::lit("@"))) || mentions_time(&**i)),
            crate::syntax::TypeKind::TUnit(s) => prism_rtl::Turn::Finished((crate::syntax::lexer::contains(s, &Text::lit("$")) || crate::syntax::lexer::contains(s, &Text::lit("!"))) || crate::syntax::lexer::contains(s, &Text::lit("@"))),
            crate::syntax::TypeKind::TArray(e, _) => prism_rtl::Turn::More(Rc::new(MentionsTime { t: (**e).clone() })),
            crate::syntax::TypeKind::TTuple(ts) => fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
                let seen = p0;
                let a = p1;
                prism_rtl::Turn::Finished(seen || mentions_time(&a))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(MentionsTime { t: (**x).clone() })),
            crate::syntax::TypeKind::TMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_mentions_time(k.clone()), move |mentions_time_36133: bool| prism_rtl::Turn::Finished(mentions_time_36133 || mentions_time(&v_)))
            },
            crate::syntax::TypeKind::TFn(_, ps, res) => {
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(fold_job(ps.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
                    let seen = p0;
                    let a = p1;
                    prism_rtl::Turn::Finished(seen || mentions_time(&a))
                }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_36193: bool| prism_rtl::Turn::Finished(fold_36193 || mentions_time(&res)))
            },
            crate::syntax::TypeKind::TEmit(ty, _) => prism_rtl::Turn::Finished(true),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start MentionsTime, x`: what the function value is when passed to `@Run`.
pub fn start_mentions_time(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(MentionsTime { t })
}

/// ```prism
/// TakesClosure: unbounded fn Type -> Bool
/// ```
pub fn takes_closure(t: &crate::syntax::Type) -> bool {
    match &*t.kind {
        crate::syntax::TypeKind::TFn(_, ps, _) => run_to_end(fold_job(ps.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
            let seen = p0;
            let p_ = p1;
            prism_rtl::Turn::Finished(seen || is_fn_type(&p_))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        _ => false,
    }
}

/// The step machine of `TakesClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TakesClosure: unbounded fn Type -> Bool
/// ```
pub struct TakesClosure {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<bool> for TakesClosure {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TFn(_, ps, _) => fold_job(ps.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
                let seen = p0;
                let p_ = p1;
                prism_rtl::Turn::Finished(seen || is_fn_type(&p_))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start TakesClosure, x`: what the function value is when passed to `@Run`.
pub fn start_takes_closure(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(TakesClosure { t })
}

/// ```prism
/// IsFnType: unbounded fn Type -> Bool
/// ```
pub fn is_fn_type(t: &crate::syntax::Type) -> bool {
    match &*t.kind {
        crate::syntax::TypeKind::TFn(_, _, _) => true,
        crate::syntax::TypeKind::TGroup(x) => is_fn_type(&**x),
        _ => false,
    }
}

/// The step machine of `IsFnType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsFnType: unbounded fn Type -> Bool
/// ```
pub struct IsFnType {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<bool> for IsFnType {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TFn(_, _, _) => prism_rtl::Turn::Finished(true),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(IsFnType { t: (**x).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsFnType, x`: what the function value is when passed to `@Run`.
pub fn start_is_fn_type(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsFnType { t })
}

/// ```prism
/// UsesScope: unbounded fn Type -> Bool
/// ```
pub fn uses_scope(t: &crate::syntax::Type) -> bool {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, args) => ((crate::syntax::lexer::contains(&n.sigils, &Text::lit("@")) || ((&dotted(&n.path_) == &Text::lit("Element")) && (&len(args) < &Nat::from(2u32)))) || ((&dotted(&n.path_) == &Text::lit("Elem")) && (&len(args) == &Nat::from(0u32)))) || run_to_end(fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || uses_scope(&a))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TSigiled(s, i) => crate::syntax::lexer::contains(s, &Text::lit("@")) || uses_scope(&**i),
        crate::syntax::TypeKind::TUnit(s) => crate::syntax::lexer::contains(s, &Text::lit("@")),
        crate::syntax::TypeKind::TArray(e, _) => uses_scope(&**e),
        crate::syntax::TypeKind::TTuple(ts) => run_to_end(fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || uses_scope(&a))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TGroup(x) => uses_scope(&**x),
        crate::syntax::TypeKind::TMap(k, v_) => uses_scope(&**k) || uses_scope(&**v_),
        crate::syntax::TypeKind::TFn(_, ps, res) => run_to_end(fold_job(ps.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || uses_scope(&a))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)) || uses_scope(&**res),
        crate::syntax::TypeKind::TEmit(ty, row_t) => uses_scope(&**row_t),
        _ => false,
    }
}

/// The step machine of `UsesScope`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UsesScope: unbounded fn Type -> Bool
/// ```
pub struct UsesScope {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<bool> for UsesScope {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TName(n, args) => prism_rtl::Turn::Finished(((crate::syntax::lexer::contains(&n.sigils, &Text::lit("@")) || ((&dotted(&n.path_) == &Text::lit("Element")) && (&len(args) < &Nat::from(2u32)))) || ((&dotted(&n.path_) == &Text::lit("Elem")) && (&len(args) == &Nat::from(0u32)))) || run_to_end(fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
                let seen = p0;
                let a = p1;
                prism_rtl::Turn::Finished(seen || uses_scope(&a))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>))),
            crate::syntax::TypeKind::TSigiled(s, i) => prism_rtl::Turn::Finished(crate::syntax::lexer::contains(s, &Text::lit("@")) || uses_scope(&**i)),
            crate::syntax::TypeKind::TUnit(s) => prism_rtl::Turn::Finished(crate::syntax::lexer::contains(s, &Text::lit("@"))),
            crate::syntax::TypeKind::TArray(e, _) => prism_rtl::Turn::More(Rc::new(UsesScope { t: (**e).clone() })),
            crate::syntax::TypeKind::TTuple(ts) => fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
                let seen = p0;
                let a = p1;
                prism_rtl::Turn::Finished(seen || uses_scope(&a))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(UsesScope { t: (**x).clone() })),
            crate::syntax::TypeKind::TMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_uses_scope(k.clone()), move |uses_scope_37200: bool| prism_rtl::Turn::Finished(uses_scope_37200 || uses_scope(&v_)))
            },
            crate::syntax::TypeKind::TFn(_, ps, res) => {
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(fold_job(ps.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
                    let seen = p0;
                    let a = p1;
                    prism_rtl::Turn::Finished(seen || uses_scope(&a))
                }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_37254: bool| prism_rtl::Turn::Finished(fold_37254 || uses_scope(&res)))
            },
            crate::syntax::TypeKind::TEmit(ty, row_t) => prism_rtl::Turn::More(Rc::new(UsesScope { t: (**row_t).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start UsesScope, x`: what the function value is when passed to `@Run`.
pub fn start_uses_scope(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(UsesScope { t })
}

/// ```prism
/// RowVarsOfType: unbounded fn Type -> [Text]
/// ```
pub fn row_vars_of_type(t: &crate::syntax::Type) -> Array<Text> {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, args) => {
            let name = dotted(&n.path_);
            let own = if ((&name == &Text::lit("Element")) && (&len(args) == &Nat::from(2u32))) || ((&name == &Text::lit("Elem")) && (&len(args) == &Nat::from(1u32))) {
                row_names_in(&or(&index(args, &Nat::from(0u32)), &dummy_type()))
            } else {
                Array::new()
            };
            let rest = if (&name == &Text::lit("Element")) && (&len(args) == &Nat::from(2u32)) {
                drop(args, &Nat::from(1u32))
            } else {
                if &name == &Text::lit("Elem") { Array::new() } else { args.clone() }
            };
            run_to_end(fold_job(rest.clone(), own.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_row_vars_of_type(a.clone()), move |row_vars_of_type_37874: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_vars_of_type_37874)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
        },
        crate::syntax::TypeKind::TSigiled(_, i) => row_vars_of_type(&**i),
        crate::syntax::TypeKind::TArray(e, _) => row_vars_of_type(&**e),
        crate::syntax::TypeKind::TTuple(ts) => run_to_end(fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_row_vars_of_type(a.clone()), move |row_vars_of_type_38026: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_vars_of_type_38026)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TGroup(x) => row_vars_of_type(&**x),
        crate::syntax::TypeKind::TMap(k, v_) => crate::check::types::union_texts(&row_vars_of_type(&**k), &row_vars_of_type(&**v_)),
        crate::syntax::TypeKind::TFn(_, ps, res) => run_to_end(fold_job(ps.clone(), row_vars_of_type(&**res), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_row_vars_of_type(a.clone()), move |row_vars_of_type_38218: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_vars_of_type_38218)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TEmit(ty, row_t) => crate::check::types::union_texts(&row_vars_of_type(&**ty), &row_names_in(&**row_t)),
        _ => Array::new(),
    }
}

/// The step machine of `RowVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowVarsOfType: unbounded fn Type -> [Text]
/// ```
pub struct RowVarsOfType {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for RowVarsOfType {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TName(n, args) => {
                let name = dotted(&n.path_);
                let own = if ((&name == &Text::lit("Element")) && (&len(args) == &Nat::from(2u32))) || ((&name == &Text::lit("Elem")) && (&len(args) == &Nat::from(1u32))) {
                    row_names_in(&or(&index(args, &Nat::from(0u32)), &dummy_type()))
                } else {
                    Array::new()
                };
                let rest = if (&name == &Text::lit("Element")) && (&len(args) == &Nat::from(2u32)) {
                    drop(args, &Nat::from(1u32))
                } else {
                    if &name == &Text::lit("Elem") { Array::new() } else { args.clone() }
                };
                fold_job(rest.clone(), own.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_row_vars_of_type(a.clone()), move |row_vars_of_type_37874: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_vars_of_type_37874)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
            },
            crate::syntax::TypeKind::TSigiled(_, i) => prism_rtl::Turn::More(Rc::new(RowVarsOfType { t: (**i).clone() })),
            crate::syntax::TypeKind::TArray(e, _) => prism_rtl::Turn::More(Rc::new(RowVarsOfType { t: (**e).clone() })),
            crate::syntax::TypeKind::TTuple(ts) => fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_row_vars_of_type(a.clone()), move |row_vars_of_type_38026: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_vars_of_type_38026)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(RowVarsOfType { t: (**x).clone() })),
            crate::syntax::TypeKind::TMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_row_vars_of_type(k.clone()), move |row_vars_of_type_38100: Array<Text>| call_then(start_row_vars_of_type(v_.clone()), move |row_vars_of_type_38119: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&row_vars_of_type_38100, &row_vars_of_type_38119))))
            },
            crate::syntax::TypeKind::TFn(_, ps, res) => {
                let ps = ps.clone();
                let res = (**res).clone();
                call_then(start_row_vars_of_type(res.clone()), move |row_vars_of_type_38171: Array<Text>| fold_job(ps.clone(), row_vars_of_type_38171, Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_row_vars_of_type(a.clone()), move |row_vars_of_type_38218: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_vars_of_type_38218)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            crate::syntax::TypeKind::TEmit(ty, row_t) => {
                let row_t = (**row_t).clone();
                let ty = (**ty).clone();
                call_then(start_row_vars_of_type(ty.clone()), move |row_vars_of_type_38267: Array<Text>| call_then(start_row_names_in(row_t.clone()), move |row_names_in_38287: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&row_vars_of_type_38267, &row_names_in_38287))))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start RowVarsOfType, x`: what the function value is when passed to `@Run`.
pub fn start_row_vars_of_type(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RowVarsOfType { t })
}

/// ```prism
/// RowNamesIn: unbounded fn Type -> [Text]
/// ```
pub fn row_names_in(t: &crate::syntax::Type) -> Array<Text> {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, m38383_0_1) if (m38383_0_1.len() == 0) => if (&len(&n.path_) == &Nat::from(1u32)) && is_lower_text(&dotted(&n.path_)) {
            Array::from(vec![dotted(&n.path_)])
        } else {
            Array::new()
        },
        crate::syntax::TypeKind::TRowUnion(ts) => run_to_end(fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_row_names_in(a.clone()), move |row_names_in_38561: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_names_in_38561)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TGroup(x) => row_names_in(&**x),
        _ => Array::new(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RowNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowNamesIn: unbounded fn Type -> [Text]
/// ```
pub struct RowNamesIn {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for RowNamesIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TName(n, m38383_0_1) if (m38383_0_1.len() == 0) => if (&len(&n.path_) == &Nat::from(1u32)) && is_lower_text(&dotted(&n.path_)) {
                prism_rtl::Turn::Finished(Array::from(vec![dotted(&n.path_)]))
            } else {
                prism_rtl::Turn::Finished(Array::new())
            },
            crate::syntax::TypeKind::TRowUnion(ts) => fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_row_names_in(a.clone()), move |row_names_in_38561: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_names_in_38561)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(RowNamesIn { t: (**x).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start RowNamesIn, x`: what the function value is when passed to `@Run`.
pub fn start_row_names_in(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RowNamesIn { t })
}

/// ```prism
/// TypeVarsOfType: unbounded fn Type -> [Text]
/// ```
pub fn type_vars_of_type(t: &crate::syntax::Type) -> Array<Text> {
    type_vars_into(&Array::new(), t)
}

/// The step machine of `TypeVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeVarsOfType: unbounded fn Type -> [Text]
/// ```
pub struct TypeVarsOfType {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for TypeVarsOfType {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: Array::new(), t: t.clone() }))
    }
}

/// `Start TypeVarsOfType, x`: what the function value is when passed to `@Run`.
pub fn start_type_vars_of_type(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TypeVarsOfType { t })
}

/// ```prism
/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
/// ```
pub fn type_vars_into(acc: &Array<Text>, t: &crate::syntax::Type) -> Array<Text> {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, args) => {
            let name = dotted(&n.path_);
            let here = if ((&len(&n.path_) == &Nat::from(1u32)) && is_lower_text(&name)) && (&len(args) == &Nat::from(0u32)) {
                crate::check::types::add_text(acc, &name)
            } else {
                acc.clone()
            };
            let rest = if (&name == &Text::lit("Element")) && (&len(args) == &Nat::from(2u32)) {
                drop(args, &Nat::from(1u32))
            } else {
                if &name == &Text::lit("Elem") { Array::new() } else { args.clone() }
            };
            run_to_end(fold_job(rest.clone(), here.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let a = p0;
                let x = p1;
                prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: a.clone(), t: x.clone() }))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
        },
        crate::syntax::TypeKind::TSigiled(_, i) => type_vars_into(acc, &**i),
        crate::syntax::TypeKind::TArray(e, _) => type_vars_into(acc, &**e),
        crate::syntax::TypeKind::TTuple(ts) => run_to_end(fold_job(ts.clone(), acc.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let a = p0;
            let x = p1;
            prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: a.clone(), t: x.clone() }))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TGroup(x) => type_vars_into(acc, &**x),
        crate::syntax::TypeKind::TMap(k, v_) => type_vars_into(&type_vars_into(acc, &**k), &**v_),
        crate::syntax::TypeKind::TFn(_, ps, res) => type_vars_into(&run_to_end(fold_job(ps.clone(), acc.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let a = p0;
            let x = p1;
            prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: a.clone(), t: x.clone() }))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)), &**res),
        crate::syntax::TypeKind::TEmit(ty, _) => type_vars_into(acc, &**ty),
        _ => acc.clone(),
    }
}

/// The step machine of `TypeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
/// ```
pub struct TypeVarsInto {
    pub acc: Array<Text>,
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for TypeVarsInto {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let acc = &self.acc;
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TName(n, args) => {
                let name = dotted(&n.path_);
                let here = if ((&len(&n.path_) == &Nat::from(1u32)) && is_lower_text(&name)) && (&len(args) == &Nat::from(0u32)) {
                    crate::check::types::add_text(acc, &name)
                } else {
                    acc.clone()
                };
                let rest = if (&name == &Text::lit("Element")) && (&len(args) == &Nat::from(2u32)) {
                    drop(args, &Nat::from(1u32))
                } else {
                    if &name == &Text::lit("Elem") { Array::new() } else { args.clone() }
                };
                fold_job(rest.clone(), here.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: a.clone(), t: x.clone() }))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
            },
            crate::syntax::TypeKind::TSigiled(_, i) => prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: acc.clone(), t: (**i).clone() })),
            crate::syntax::TypeKind::TArray(e, _) => prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: acc.clone(), t: (**e).clone() })),
            crate::syntax::TypeKind::TTuple(ts) => fold_job(ts.clone(), acc.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let a = p0;
                let x = p1;
                prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: a.clone(), t: x.clone() }))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: acc.clone(), t: (**x).clone() })),
            crate::syntax::TypeKind::TMap(k, v_) => {
                let acc = acc.clone();
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_type_vars_into(acc.clone(), k.clone()), move |type_vars_into_39418: Array<Text>| prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: type_vars_into_39418, t: v_.clone() })))
            },
            crate::syntax::TypeKind::TFn(_, ps, res) => {
                let acc = acc.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(fold_job(ps.clone(), acc.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: a.clone(), t: x.clone() }))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_39481: Array<Text>| prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: fold_39481, t: res.clone() })))
            },
            crate::syntax::TypeKind::TEmit(ty, _) => prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: acc.clone(), t: (**ty).clone() })),
            _ => prism_rtl::Turn::Finished(acc.clone()),
        }
    }
}

/// `Start TypeVarsInto, x`: what the function value is when passed to `@Run`.
pub fn start_type_vars_into(acc: Array<Text>, t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TypeVarsInto { acc, t })
}

/// ```prism
/// ColorVarsOfType: unbounded fn Type -> [Text]
/// ```
pub fn color_vars_of_type(t: &crate::syntax::Type) -> Array<Text> {
    match &*t.kind {
        crate::syntax::TypeKind::TFn(crate::syntax::Color::ColorVar(v_), ps, res) => {
            let inner = run_to_end(fold_job(ps.clone(), color_vars_of_type(&**res), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_39782: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_39782)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
            if &v_.name == &Text::lit("bounded") {
                inner.clone()
            } else {
                crate::check::types::add_text(&inner, &v_.name)
            }
        },
        crate::syntax::TypeKind::TFn(_, ps, res) => run_to_end(fold_job(ps.clone(), color_vars_of_type(&**res), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_39951: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_39951)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TName(_, args) => run_to_end(fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_40038: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_40038)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TSigiled(_, i) => color_vars_of_type(&**i),
        crate::syntax::TypeKind::TArray(e, _) => color_vars_of_type(&**e),
        crate::syntax::TypeKind::TTuple(ts) => run_to_end(fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_40196: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_40196)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TGroup(x) => color_vars_of_type(&**x),
        crate::syntax::TypeKind::TMap(k, v_) => crate::check::types::union_texts(&color_vars_of_type(&**k), &color_vars_of_type(&**v_)),
        crate::syntax::TypeKind::TEmit(ty, _) => color_vars_of_type(&**ty),
        _ => Array::new(),
    }
}

/// The step machine of `ColorVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ColorVarsOfType: unbounded fn Type -> [Text]
/// ```
pub struct ColorVarsOfType {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for ColorVarsOfType {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TFn(crate::syntax::Color::ColorVar(v_), ps, res) => {
                let ps = ps.clone();
                let res = (**res).clone();
                let v_ = v_.clone();
                call_then(start_color_vars_of_type(res.clone()), move |color_vars_of_type_39733: Array<Text>| call_value(fold_job(ps.clone(), color_vars_of_type_39733, Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_39782: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_39782)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_39723: Array<Text>| {
                    let inner = fold_39723;
                    if &v_.name == &Text::lit("bounded") {
                        prism_rtl::Turn::Finished(inner.clone())
                    } else {
                        prism_rtl::Turn::Finished(crate::check::types::add_text(&inner, &v_.name))
                    }
                }))
            },
            crate::syntax::TypeKind::TFn(_, ps, res) => {
                let ps = ps.clone();
                let res = (**res).clone();
                call_then(start_color_vars_of_type(res.clone()), move |color_vars_of_type_39902: Array<Text>| fold_job(ps.clone(), color_vars_of_type_39902, Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_39951: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_39951)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            crate::syntax::TypeKind::TName(_, args) => fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_40038: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_40038)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TSigiled(_, i) => prism_rtl::Turn::More(Rc::new(ColorVarsOfType { t: (**i).clone() })),
            crate::syntax::TypeKind::TArray(e, _) => prism_rtl::Turn::More(Rc::new(ColorVarsOfType { t: (**e).clone() })),
            crate::syntax::TypeKind::TTuple(ts) => fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_40196: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_40196)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(ColorVarsOfType { t: (**x).clone() })),
            crate::syntax::TypeKind::TMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_color_vars_of_type(k.clone()), move |color_vars_of_type_40274: Array<Text>| call_then(start_color_vars_of_type(v_.clone()), move |color_vars_of_type_40295: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&color_vars_of_type_40274, &color_vars_of_type_40295))))
            },
            crate::syntax::TypeKind::TEmit(ty, _) => prism_rtl::Turn::More(Rc::new(ColorVarsOfType { t: (**ty).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ColorVarsOfType, x`: what the function value is when passed to `@Run`.
pub fn start_color_vars_of_type(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ColorVarsOfType { t })
}

/// ```prism
/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn convert_types(g: &G, st: &crate::check::types::St, m: &Text) -> (G, crate::check::types::St) {
    match get(&g.mods, m) {
        None => (g.clone(), st.clone()),
        Some(info) => {
            let s0 = {
                let mut this: crate::check::types::St = st.clone();
                this.file = info.file.clone();
                this
            };
            run_to_end(fold_job(info.tree.decls.clone(), (g.clone(), s0.clone()), {
                let info = info.clone();
                Rc::new(move |(p0, p1): ((G, crate::check::types::St), crate::syntax::Decl)| {
                    let info = info.clone();
                    entered(once_job(move || {
                        let (gg, s) = p0;
                        let d = p1;
                        prism_rtl::Turn::More(Rc::new(ConvertTypeDecl { g: gg.clone(), st: s.clone(), info: info.clone(), d: d.clone() }))
                    }))
                }) as Rc<dyn Fn(((G, crate::check::types::St), crate::syntax::Decl)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>
            }))
        },
    }
}

/// The step machine of `ConvertTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct ConvertTypes {
    pub g: G,
    pub st: crate::check::types::St,
    pub m: Text,
}

impl prism_rtl::Job<(G, crate::check::types::St)> for ConvertTypes {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let m = &self.m;
        match get(&g.mods, m) {
            None => prism_rtl::Turn::Finished((g.clone(), st.clone())),
            Some(info) => {
                let s0 = {
                    let mut this: crate::check::types::St = st.clone();
                    this.file = info.file.clone();
                    this
                };
                fold_job(info.tree.decls.clone(), (g.clone(), s0.clone()), {
                    let info = info.clone();
                    Rc::new(move |(p0, p1): ((G, crate::check::types::St), crate::syntax::Decl)| {
                        let info = info.clone();
                        entered(once_job(move || {
                            let (gg, s) = p0;
                            let d = p1;
                            prism_rtl::Turn::More(Rc::new(ConvertTypeDecl { g: gg.clone(), st: s.clone(), info: info.clone(), d: d.clone() }))
                        }))
                    }) as Rc<dyn Fn(((G, crate::check::types::St), crate::syntax::Decl)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>
                }).cycle()
            },
        }
    }
}

/// `Start ConvertTypes, x`: what the function value is when passed to `@Run`.
pub fn start_convert_types(g: G, st: crate::check::types::St, m: Text) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>> {
    Rc::new(ConvertTypes { g, st, m })
}

/// ```prism
/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn convert_decls(g: &G, st: &crate::check::types::St, m: &Text) -> (G, crate::check::types::St) {
    match get(&g.mods, m) {
        None => (g.clone(), st.clone()),
        Some(info) => {
            let s1 = {
                let mut this: crate::check::types::St = st.clone();
                this.file = info.file.clone();
                this
            };
            let (g2, s2) = run_to_end(fold_job(info.tree.decls.clone(), (g.clone(), s1.clone()), {
                let info = info.clone();
                Rc::new(move |(p0, p1): ((G, crate::check::types::St), crate::syntax::Decl)| {
                    let info = info.clone();
                    entered(once_job(move || {
                        let (gg, s) = p0;
                        let d = p1;
                        prism_rtl::Turn::More(Rc::new(ConvertDecl { g: gg.clone(), st: s.clone(), info: info.clone(), d: d.clone() }))
                    }))
                }) as Rc<dyn Fn(((G, crate::check::types::St), crate::syntax::Decl)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>
            }));
            let s3 = missing_signatures(&g2, &s2, &info);
            (g2.clone(), s3.clone())
        },
    }
}

/// The step machine of `ConvertDecls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct ConvertDecls {
    pub g: G,
    pub st: crate::check::types::St,
    pub m: Text,
}

impl prism_rtl::Job<(G, crate::check::types::St)> for ConvertDecls {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let m = &self.m;
        match get(&g.mods, m) {
            None => prism_rtl::Turn::Finished((g.clone(), st.clone())),
            Some(info) => {
                let s1 = {
                    let mut this: crate::check::types::St = st.clone();
                    this.file = info.file.clone();
                    this
                };
                let g = g.clone();
                call_value(fold_job(info.tree.decls.clone(), (g.clone(), s1.clone()), {
                    let info = info.clone();
                    Rc::new(move |(p0, p1): ((G, crate::check::types::St), crate::syntax::Decl)| {
                        let info = info.clone();
                        entered(once_job(move || {
                            let (gg, s) = p0;
                            let d = p1;
                            prism_rtl::Turn::More(Rc::new(ConvertDecl { g: gg.clone(), st: s.clone(), info: info.clone(), d: d.clone() }))
                        }))
                    }) as Rc<dyn Fn(((G, crate::check::types::St), crate::syntax::Decl)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>
                }), move |fold_41196: (G, crate::check::types::St)| {
                    let (g2, s2) = fold_41196;
                    let s3 = missing_signatures(&g2, &s2, &info);
                    prism_rtl::Turn::Finished((g2.clone(), s3.clone()))
                })
            },
        }
    }
}

/// `Start ConvertDecls, x`: what the function value is when passed to `@Run`.
pub fn start_convert_decls(g: G, st: crate::check::types::St, m: Text) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>> {
    Rc::new(ConvertDecls { g, st, m })
}

/// ```prism
/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub fn convert_type_decl(g: &G, st: &crate::check::types::St, info: &ModInfo, d: &crate::syntax::Decl) -> (G, crate::check::types::St) {
    match &d.kind {
        crate::syntax::DeclKind::DType(t) => {
            let name = qual_key(&info.name, &dotted(&t.name.path_));
            let ti = or(&get(&g.types, &name), &dummy_ty_info());
            let cx_ = cx_of(g, &info.name);
            let params = each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone()));
            let self_ = crate::check::types::Ty::TyCon(name.clone(), each(&params, &(|p_: &Text| crate::check::types::Ty::TyQ(p_.clone()))));
            match &t.body {
                None => (g.clone(), st.clone()),
                Some(body) => match body {
                    crate::syntax::TypeBody::TbRecord(fs) => {
                        let (fields, st2) = run_to_end(fold_job(fs.clone(), (Array::new(), st.clone()), {
                            let cx_ = cx_.clone();
                            Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::Field)| {
                                let cx_ = cx_.clone();
                                entered(once_job(move || {
                                    let (acc, s) = p0;
                                    let f = p1;
                                    call_then(start_conv_type(cx_.clone(), s.clone(), f.ty.clone()), move |conv_type_41947: (crate::check::types::Ty, crate::check::types::St)| {
                                        let (ft, s2) = conv_type_41947;
                                        prism_rtl::Turn::Finished((push(&acc, &(f.name.name.clone(), ft.clone())), s2.clone()))
                                    })
                                }))
                            }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::Field)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
                        }));
                        let ctor = CtorInfo { name: name.clone(), owner: name.clone(), params: params.clone(), args: each(&fields, &(|(_, ft): &(Text, crate::check::types::Ty)| ft.clone())), fields: each(&fields, &(|(fname, _): &(Text, crate::check::types::Ty)| fname.clone())), ty: self_.clone(), index: Nat::from(0u32) };
                        let upd = {
                            let mut this: G = g.clone();
                            this.types = insert(&this.types, &name, &with_body(&ti, &TyBody::BRecord(fields.clone())));
                            this.ctors = insert(&this.ctors, &name, &ctor);
                            this
                        };
                        (upd.clone(), st2.clone())
                    },
                    crate::syntax::TypeBody::TbChoice(cs) => conv_cases(g, st, &cx_, &ti, &name, &params, &self_, cs),
                    crate::syntax::TypeBody::TbNewtype(c) => conv_cases(g, st, &cx_, &ti, &name, &params, &self_, &Array::from(vec![c.clone()])),
                    crate::syntax::TypeBody::TbUnit(i) => {
                        let ctor = CtorInfo { name: qual_key(&info.name, &i.name), owner: name.clone(), params: params.clone(), args: Array::new(), fields: Array::new(), ty: self_.clone(), index: Nat::from(0u32) };
                        let upd = {
                            let mut this: G = g.clone();
                            this.types = insert(&this.types, &name, &with_body(&ti, &TyBody::BChoice(Array::from(vec![(i.name.clone(), Array::new())]))));
                            this.ctors = insert(&this.ctors, &qual_key(&info.name, &i.name), &ctor);
                            this
                        };
                        (upd.clone(), st.clone())
                    },
                    crate::syntax::TypeBody::TbRow => {
                        let upd = {
                            let mut this: G = g.clone();
                            this.types = insert(&this.types, &name, &with_body(&ti, &TyBody::BRowKind));
                            this
                        };
                        (upd.clone(), st.clone())
                    },
                    crate::syntax::TypeBody::TbAlias(a) => {
                        let (at_, st2) = conv_type(&cx_, st, a);
                        let upd = {
                            let mut this: G = g.clone();
                            this.types = insert(&this.types, &name, &with_body(&ti, &TyBody::BAlias(at_.clone())));
                            this
                        };
                        (upd.clone(), st2.clone())
                    },
                },
            }
        },
        _ => (g.clone(), st.clone()),
    }
}

/// The step machine of `ConvertTypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub struct ConvertTypeDecl {
    pub g: G,
    pub st: crate::check::types::St,
    pub info: ModInfo,
    pub d: crate::syntax::Decl,
}

impl prism_rtl::Job<(G, crate::check::types::St)> for ConvertTypeDecl {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let info = &self.info;
        let d = &self.d;
        match &d.kind {
            crate::syntax::DeclKind::DType(t) => {
                let name = qual_key(&info.name, &dotted(&t.name.path_));
                let ti = or(&get(&g.types, &name), &dummy_ty_info());
                let cx_ = cx_of(g, &info.name);
                let params = each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone()));
                let self_ = crate::check::types::Ty::TyCon(name.clone(), each(&params, &(|p_: &Text| crate::check::types::Ty::TyQ(p_.clone()))));
                match &t.body {
                    None => prism_rtl::Turn::Finished((g.clone(), st.clone())),
                    Some(body) => match body {
                        crate::syntax::TypeBody::TbRecord(fs) => {
                            let fs = fs.clone();
                            let g = g.clone();
                            let st = st.clone();
                            call_value(fold_job(fs.clone(), (Array::new(), st.clone()), {
                                let cx_ = cx_.clone();
                                Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::Field)| {
                                    let cx_ = cx_.clone();
                                    entered(once_job(move || {
                                        let (acc, s) = p0;
                                        let f = p1;
                                        call_then(start_conv_type(cx_.clone(), s.clone(), f.ty.clone()), move |conv_type_41947: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (ft, s2) = conv_type_41947;
                                            prism_rtl::Turn::Finished((push(&acc, &(f.name.name.clone(), ft.clone())), s2.clone()))
                                        })
                                    }))
                                }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::Field)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
                            }), move |fold_41866: (Array<(Text, crate::check::types::Ty)>, crate::check::types::St)| {
                                let (fields, st2) = fold_41866;
                                let ctor = CtorInfo { name: name.clone(), owner: name.clone(), params: params.clone(), args: each(&fields, &(|(_, ft): &(Text, crate::check::types::Ty)| ft.clone())), fields: each(&fields, &(|(fname, _): &(Text, crate::check::types::Ty)| fname.clone())), ty: self_.clone(), index: Nat::from(0u32) };
                                let upd = {
                                    let mut this: G = g.clone();
                                    this.types = insert(&this.types, &name, &with_body(&ti, &TyBody::BRecord(fields.clone())));
                                    this.ctors = insert(&this.ctors, &name, &ctor);
                                    this
                                };
                                prism_rtl::Turn::Finished((upd.clone(), st2.clone()))
                            })
                        },
                        crate::syntax::TypeBody::TbChoice(cs) => prism_rtl::Turn::More(Rc::new(ConvCases { g: g.clone(), st: st.clone(), cx_: cx_.clone(), ti: ti.clone(), name: name.clone(), params: params.clone(), self_: self_.clone(), cs: cs.clone() })),
                        crate::syntax::TypeBody::TbNewtype(c) => prism_rtl::Turn::More(Rc::new(ConvCases { g: g.clone(), st: st.clone(), cx_: cx_.clone(), ti: ti.clone(), name: name.clone(), params: params.clone(), self_: self_.clone(), cs: Array::from(vec![c.clone()]) })),
                        crate::syntax::TypeBody::TbUnit(i) => {
                            let ctor = CtorInfo { name: qual_key(&info.name, &i.name), owner: name.clone(), params: params.clone(), args: Array::new(), fields: Array::new(), ty: self_.clone(), index: Nat::from(0u32) };
                            let upd = {
                                let mut this: G = g.clone();
                                this.types = insert(&this.types, &name, &with_body(&ti, &TyBody::BChoice(Array::from(vec![(i.name.clone(), Array::new())]))));
                                this.ctors = insert(&this.ctors, &qual_key(&info.name, &i.name), &ctor);
                                this
                            };
                            prism_rtl::Turn::Finished((upd.clone(), st.clone()))
                        },
                        crate::syntax::TypeBody::TbRow => {
                            let upd = {
                                let mut this: G = g.clone();
                                this.types = insert(&this.types, &name, &with_body(&ti, &TyBody::BRowKind));
                                this
                            };
                            prism_rtl::Turn::Finished((upd.clone(), st.clone()))
                        },
                        crate::syntax::TypeBody::TbAlias(a) => {
                            let a = a.clone();
                            let g = g.clone();
                            let st = st.clone();
                            call_then(start_conv_type(cx_.clone(), st.clone(), a.clone()), move |conv_type_43281: (crate::check::types::Ty, crate::check::types::St)| {
                                let (at_, st2) = conv_type_43281;
                                let upd = {
                                    let mut this: G = g.clone();
                                    this.types = insert(&this.types, &name, &with_body(&ti, &TyBody::BAlias(at_.clone())));
                                    this
                                };
                                prism_rtl::Turn::Finished((upd.clone(), st2.clone()))
                            })
                        },
                    },
                }
            },
            _ => prism_rtl::Turn::Finished((g.clone(), st.clone())),
        }
    }
}

/// `Start ConvertTypeDecl, x`: what the function value is when passed to `@Run`.
pub fn start_convert_type_decl(g: G, st: crate::check::types::St, info: ModInfo, d: crate::syntax::Decl) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>> {
    Rc::new(ConvertTypeDecl { g, st, info, d })
}

/// ```prism
/// WithBody: fn TyInfo, TyBody -> TyInfo
/// ```
pub fn with_body(ti: &TyInfo, b: &TyBody) -> TyInfo {
    let mut this: TyInfo = ti.clone();
    this.body = b.clone();
    this
}

/// ```prism
/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
/// ```
pub fn conv_cases(g: &G, st: &crate::check::types::St, cx_: &Cx_, ti: &TyInfo, name: &Text, params: &Array<Text>, self_: &crate::check::types::Ty, cs: &Array<crate::syntax::Case_>) -> (G, crate::check::types::St) {
    let (cases, st2) = run_to_end(fold_job(cs.clone(), (Array::new(), st.clone()), {
        let cx_ = cx_.clone();
        Rc::new(move |(p0, p1): ((Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::Case_)| {
            let cx_ = cx_.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let c = p1;
                {
                    let s1 = match &c.indexed {
                        Some(_) => crate::check::types::err(&s, &Text::lit("unsupported"), &c.span, &Text::lit("this checker does not implement indexed choices for user types")),
                        None => s.clone(),
                    };
                    call_then(start_conv_types(cx_.clone(), s1.clone(), c.args.clone()), move |conv_types_43968: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                        let (args, s2) = conv_types_43968;
                        prism_rtl::Turn::Finished((push(&acc, &(sname_key(&c.name), args.clone())), s2.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::Case_)) -> Rc<dyn prism_rtl::Job<(Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St)>>>
    }));
    let g2 = fold(&crate::check::errors::range0(&len(&cases)), g, &(|gg: &G, i: &Nat| {
        let (cn, args) = or(&index(&cases, i), &(Text::lit(""), Array::new()));
        let qk = qual_key(&ti.home, &cn);
        {
            let mut this: G = gg.clone();
            this.ctors = insert(&this.ctors, &qk, &CtorInfo { name: qk.clone(), owner: name.clone(), params: params.clone(), args: args.clone(), fields: Array::new(), ty: self_.clone(), index: i.clone() });
            this
        }
    }));
    let upd = {
        let mut this: G = g2.clone();
        this.types = insert(&this.types, name, &with_body(ti, &TyBody::BChoice(cases.clone())));
        this
    };
    (upd.clone(), st2.clone())
}

/// The step machine of `ConvCases`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
/// ```
pub struct ConvCases {
    pub g: G,
    pub st: crate::check::types::St,
    pub cx_: Cx_,
    pub ti: TyInfo,
    pub name: Text,
    pub params: Array<Text>,
    pub self_: crate::check::types::Ty,
    pub cs: Array<crate::syntax::Case_>,
}

impl prism_rtl::Job<(G, crate::check::types::St)> for ConvCases {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let cx_ = &self.cx_;
        let ti = &self.ti;
        let name = &self.name;
        let params = &self.params;
        let self_ = &self.self_;
        let cs = &self.cs;
        let cs = cs.clone();
        let cx_ = cx_.clone();
        let g = g.clone();
        let name = name.clone();
        let params = params.clone();
        let self_ = self_.clone();
        let st = st.clone();
        let ti = ti.clone();
        call_value(fold_job(cs.clone(), (Array::new(), st.clone()), {
            let cx_ = cx_.clone();
            Rc::new(move |(p0, p1): ((Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::Case_)| {
                let cx_ = cx_.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let c = p1;
                    {
                        let s1 = match &c.indexed {
                            Some(_) => crate::check::types::err(&s, &Text::lit("unsupported"), &c.span, &Text::lit("this checker does not implement indexed choices for user types")),
                            None => s.clone(),
                        };
                        call_then(start_conv_types(cx_.clone(), s1.clone(), c.args.clone()), move |conv_types_43968: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                            let (args, s2) = conv_types_43968;
                            prism_rtl::Turn::Finished((push(&acc, &(sname_key(&c.name), args.clone())), s2.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::Case_)) -> Rc<dyn prism_rtl::Job<(Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St)>>>
        }), move |fold_43730: (Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St)| {
            let (cases, st2) = fold_43730;
            let g2 = fold(&crate::check::errors::range0(&len(&cases)), &g, &(|gg: &G, i: &Nat| {
                let (cn, args) = or(&index(&cases, i), &(Text::lit(""), Array::new()));
                let qk = qual_key(&ti.home, &cn);
                {
                    let mut this: G = gg.clone();
                    this.ctors = insert(&this.ctors, &qk, &CtorInfo { name: qk.clone(), owner: name.clone(), params: params.clone(), args: args.clone(), fields: Array::new(), ty: self_.clone(), index: i.clone() });
                    this
                }
            }));
            let upd = {
                let mut this: G = g2.clone();
                this.types = insert(&this.types, &name, &with_body(&ti, &TyBody::BChoice(cases.clone())));
                this
            };
            prism_rtl::Turn::Finished((upd.clone(), st2.clone()))
        })
    }
}

/// `Start ConvCases, x`: what the function value is when passed to `@Run`.
pub fn start_conv_cases(g: G, st: crate::check::types::St, cx_: Cx_, ti: TyInfo, name: Text, params: Array<Text>, self_: crate::check::types::Ty, cs: Array<crate::syntax::Case_>) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>> {
    Rc::new(ConvCases { g, st, cx_, ti, name, params, self_, cs })
}

/// ```prism
/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub fn convert_decl(g: &G, st: &crate::check::types::St, info: &ModInfo, d: &crate::syntax::Decl) -> (G, crate::check::types::St) {
    match &d.kind {
        crate::syntax::DeclKind::DSignature(s) => {
            let qk = qual_key(&info.name, &def_name_text(&s.name));
            let cx_ = cx_of(g, &info.name);
            let (sc, st1) = sig_scheme(&cx_, st, &s.ty, &s.bounds);
            let st2 = lens_check(&st1, &def_name_text(&s.name), &s.ty, &def_name_span(&s.name));
            let st3 = check_mark_function(&st2, &def_name_text(&s.name), &sc.ty, &def_name_span(&s.name));
            if has_key(&g.vals, &qk) {
                (g.clone(), crate::check::types::err(&st3, &Text::lit("collision"), &d.span, &Text::from(format!("a second signature for `{}`", &def_name_text(&s.name)))))
            } else {
                {
                    let upd = {
                        let mut this: G = g.clone();
                        this.vals = insert(&this.vals, &qk, &ValInfo { qk: qk.clone(), scheme: sc.clone(), sort: Text::lit("fn"), has_sig: true, home: info.name.clone(), file: info.file.clone(), span: d.span.clone() });
                        this
                    };
                    (upd.clone(), st3.clone())
                }
            }
        },
        crate::syntax::DeclKind::DFn(f) => {
            let qk = qual_key(&info.name, &def_name_text(&f.name));
            (add_clause(g, info, &qk, &def_name_text(&f.name), f, &d.span, st), st.clone())
        },
        crate::syntax::DeclKind::DLet(l) => {
            let names = pattern_names(&l.pattern);
            let qk = qual_key(&info.name, &or(&index(&names, &Nat::from(0u32)), &Text::lit("")));
            let def = Def { qk: qk.clone(), name: or(&index(&names, &Nat::from(0u32)), &Text::lit("")), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: DefBody::DbLet(l.clone()) };
            let upd = {
                let mut this: G = g.clone();
                this.defs = push(&this.defs, &def);
                this
            };
            (upd.clone(), st.clone())
        },
        crate::syntax::DeclKind::DWidget(w) => {
            let qk = qual_key(&info.name, &sname_key(&w.name));
            let def = Def { qk: qk.clone(), name: sname_key(&w.name), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: DefBody::DbWidget(w.clone()) };
            let upd = {
                let mut this: G = g.clone();
                this.defs = push(&this.defs, &def);
                this
            };
            (upd.clone(), st.clone())
        },
        crate::syntax::DeclKind::DTag(t) => conv_tag(g, st, info, t, &d.span),
        crate::syntax::DeclKind::DTrait(t) => conv_trait(g, st, info, t, &d.span),
        crate::syntax::DeclKind::DImpl(i) => conv_impl(g, st, info, i, &d.span),
        crate::syntax::DeclKind::DCheck(c) => {
            let upd = {
                let mut this: G = g.clone();
                this.defs = push(&this.defs, &Def { qk: qual_key(&info.name, &Text::from(format!("check {}", &c.name.name))), name: c.name.name.clone(), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: DefBody::DbCheck(c.clone()) });
                this
            };
            (upd.clone(), st.clone())
        },
        crate::syntax::DeclKind::DTest(t) => {
            let upd = {
                let mut this: G = g.clone();
                this.defs = push(&this.defs, &Def { qk: qual_key(&info.name, &Text::from(format!("test {}", &t.name.name))), name: t.name.name.clone(), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: DefBody::DbTest(t.clone()) });
                this
            };
            (upd.clone(), st.clone())
        },
        crate::syntax::DeclKind::DStmt(s) => match &s.kind {
            crate::syntax::StmtKind::SEmit(_) => (g.clone(), st.clone()),
            _ => (g.clone(), crate::check::types::err(st, &Text::lit("unsupported"), &d.span, &Text::lit("a statement at the top of a file: nothing at top level is built"))),
        },
        _ => (g.clone(), st.clone()),
    }
}

/// The step machine of `ConvertDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub struct ConvertDecl {
    pub g: G,
    pub st: crate::check::types::St,
    pub info: ModInfo,
    pub d: crate::syntax::Decl,
}

impl prism_rtl::Job<(G, crate::check::types::St)> for ConvertDecl {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let info = &self.info;
        let d = &self.d;
        match &d.kind {
            crate::syntax::DeclKind::DSignature(s) => {
                let qk = qual_key(&info.name, &def_name_text(&s.name));
                let cx_ = cx_of(g, &info.name);
                let d = d.clone();
                let g = g.clone();
                let info = info.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(start_sig_scheme(cx_.clone(), st.clone(), s.ty.clone(), s.bounds.clone()), move |sig_scheme_44699: (crate::check::types::Scheme, crate::check::types::St)| {
                    let (sc, st1) = sig_scheme_44699;
                    let st2 = lens_check(&st1, &def_name_text(&s.name), &s.ty, &def_name_span(&s.name));
                    call_then(start_check_mark_function(st2.clone(), def_name_text(&s.name), sc.ty.clone(), def_name_span(&s.name)), move |check_mark_function_44832: crate::check::types::St| {
                        let st3 = check_mark_function_44832;
                        if has_key(&g.vals, &qk) {
                            prism_rtl::Turn::Finished((g.clone(), crate::check::types::err(&st3, &Text::lit("collision"), &d.span, &Text::from(format!("a second signature for `{}`", &def_name_text(&s.name))))))
                        } else {
                            {
                                let upd = {
                                    let mut this: G = g.clone();
                                    this.vals = insert(&this.vals, &qk, &ValInfo { qk: qk.clone(), scheme: sc.clone(), sort: Text::lit("fn"), has_sig: true, home: info.name.clone(), file: info.file.clone(), span: d.span.clone() });
                                    this
                                };
                                prism_rtl::Turn::Finished((upd.clone(), st3.clone()))
                            }
                        }
                    })
                })
            },
            crate::syntax::DeclKind::DFn(f) => {
                let qk = qual_key(&info.name, &def_name_text(&f.name));
                prism_rtl::Turn::Finished((add_clause(g, info, &qk, &def_name_text(&f.name), f, &d.span, st), st.clone()))
            },
            crate::syntax::DeclKind::DLet(l) => {
                let d = d.clone();
                let g = g.clone();
                let info = info.clone();
                let l = l.clone();
                let st = st.clone();
                call_then(start_pattern_names(l.pattern.clone()), move |pattern_names_45412: Array<Text>| {
                    let names = pattern_names_45412;
                    let qk = qual_key(&info.name, &or(&index(&names, &Nat::from(0u32)), &Text::lit("")));
                    let def = Def { qk: qk.clone(), name: or(&index(&names, &Nat::from(0u32)), &Text::lit("")), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: DefBody::DbLet(l.clone()) };
                    let upd = {
                        let mut this: G = g.clone();
                        this.defs = push(&this.defs, &def);
                        this
                    };
                    prism_rtl::Turn::Finished((upd.clone(), st.clone()))
                })
            },
            crate::syntax::DeclKind::DWidget(w) => {
                let qk = qual_key(&info.name, &sname_key(&w.name));
                let def = Def { qk: qk.clone(), name: sname_key(&w.name), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: DefBody::DbWidget(w.clone()) };
                let upd = {
                    let mut this: G = g.clone();
                    this.defs = push(&this.defs, &def);
                    this
                };
                prism_rtl::Turn::Finished((upd.clone(), st.clone()))
            },
            crate::syntax::DeclKind::DTag(t) => prism_rtl::Turn::More(Rc::new(ConvTag { g: g.clone(), st: st.clone(), info: info.clone(), t: t.clone(), span: d.span.clone() })),
            crate::syntax::DeclKind::DTrait(t) => prism_rtl::Turn::More(Rc::new(ConvTrait { g: g.clone(), st: st.clone(), info: info.clone(), t: t.clone(), span: d.span.clone() })),
            crate::syntax::DeclKind::DImpl(i) => prism_rtl::Turn::More(Rc::new(ConvImpl { g: g.clone(), st: st.clone(), info: info.clone(), i: i.clone(), span: d.span.clone() })),
            crate::syntax::DeclKind::DCheck(c) => {
                let upd = {
                    let mut this: G = g.clone();
                    this.defs = push(&this.defs, &Def { qk: qual_key(&info.name, &Text::from(format!("check {}", &c.name.name))), name: c.name.name.clone(), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: DefBody::DbCheck(c.clone()) });
                    this
                };
                prism_rtl::Turn::Finished((upd.clone(), st.clone()))
            },
            crate::syntax::DeclKind::DTest(t) => {
                let upd = {
                    let mut this: G = g.clone();
                    this.defs = push(&this.defs, &Def { qk: qual_key(&info.name, &Text::from(format!("test {}", &t.name.name))), name: t.name.name.clone(), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: DefBody::DbTest(t.clone()) });
                    this
                };
                prism_rtl::Turn::Finished((upd.clone(), st.clone()))
            },
            crate::syntax::DeclKind::DStmt(s) => match &s.kind {
                crate::syntax::StmtKind::SEmit(_) => prism_rtl::Turn::Finished((g.clone(), st.clone())),
                _ => prism_rtl::Turn::Finished((g.clone(), crate::check::types::err(st, &Text::lit("unsupported"), &d.span, &Text::lit("a statement at the top of a file: nothing at top level is built")))),
            },
            _ => prism_rtl::Turn::Finished((g.clone(), st.clone())),
        }
    }
}

/// `Start ConvertDecl, x`: what the function value is when passed to `@Run`.
pub fn start_convert_decl(g: G, st: crate::check::types::St, info: ModInfo, d: crate::syntax::Decl) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>> {
    Rc::new(ConvertDecl { g, st, info, d })
}

/// ```prism
/// AddClause: fn G, ModInfo, Text, Text, FnClause, Range, St -> G
/// ```
pub fn add_clause(g: &G, info: &ModInfo, qk: &Text, name: &Text, f: &crate::syntax::FnClause, span: &crate::syntax::Range, st: &crate::check::types::St) -> G {
    match get(&g.fn_at, qk) {
        Some(i) => {
            let mut this: G = g.clone();
            this.defs = insert2(&this.defs, &i, &add_to_fn(&or(&index(&this.defs, &i), &dummy_def()), f));
            this
        },
        None => {
            let mut this: G = g.clone();
            this.fn_at = insert(&this.fn_at, qk, &len(&this.defs));
            this.defs = push(&this.defs, &Def { qk: qk.clone(), name: name.clone(), home: info.name.clone(), file: info.file.clone(), span: span.clone(), body: DefBody::DbFn(Array::from(vec![f.clone()])) });
            this
        },
    }
}

/// ```prism
/// let dummyDef
/// ```
pub fn dummy_def() -> Def {
    Def { qk: Text::lit(""), name: Text::lit(""), home: Text::lit(""), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }, body: DefBody::DbFn(Array::new()) }
}

/// ```prism
/// IsFnDef: fn Def -> Bool
/// ```
pub fn is_fn_def(d: &Def) -> bool {
    match &d.body {
        DefBody::DbFn(_) => true,
        _ => false,
    }
}

/// ```prism
/// AddToFn: fn Def, FnClause -> Def
/// ```
pub fn add_to_fn(d: &Def, f: &crate::syntax::FnClause) -> Def {
    match &d.body {
        DefBody::DbFn(fs) => {
            let mut this: Def = d.clone();
            this.body = DefBody::DbFn(push(fs, f));
            this
        },
        _ => d.clone(),
    }
}

/// ```prism
/// Insert2: fn [a], Nat, a -> [a]
/// ```
pub fn insert2<A: Clone + 'static>(xs: &Array<A>, i: &Nat, x: &A) -> Array<A> {
    append(&push(&take(xs, i), x), &drop(xs, &(i + &Nat::from(1u32))))
}

/// ```prism
/// LensCheck: fn St, Text, Type, Range -> St
/// ```
pub fn lens_check(st: &crate::check::types::St, name: &Text, t: &crate::syntax::Type, span: &crate::syntax::Range) -> crate::check::types::St {
    if !crate::syntax::lexer::has_prefix(name, &Text::lit("&")) {
        st.clone()
    } else {
        match &*t.kind {
            crate::syntax::TypeKind::TFn(_, ps, _) => {
                let refs = filter(ps, &(|p_: &crate::syntax::Type| is_ref_type(p_)));
                if &len(&refs) > &Nat::from(1u32) {
                    crate::check::types::err_fix(st, &Text::lit("lens-arity"), span, &Text::lit("a lens takes one reference"), &Text::lit("take the second part as a plain value"))
                } else {
                    crate::check::types::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement named lenses and `Over`"))
                }
            },
            _ => st.clone(),
        }
    }
}

/// ```prism
/// IsRefType: fn Type -> Bool
/// ```
pub fn is_ref_type(t: &crate::syntax::Type) -> bool {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, _) => crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")),
        crate::syntax::TypeKind::TSigiled(s, _) => crate::syntax::lexer::has_prefix(s, &Text::lit("&")),
        _ => false,
    }
}

/// ```prism
/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
/// ```
pub fn check_mark_function(st: &crate::check::types::St, name: &Text, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> crate::check::types::St {
    match t {
        crate::check::types::Ty::TyFn(_, _, res) => {
            let want = crate::check::types::head_sigil(st, &**res);
            let marks = crate::check::types::marks_of(name);
            let shown = crate::syntax::lexer::head(&marks);
            let bare = crate::syntax::lexer::drop_prefix(name, &marks);
            if (((&shown == &want) || (&len_text(&marks) > &Nat::from(1u32))) || (&bare == &Text::lit(""))) || !is_upper_text(&bare) {
                st.clone()
            } else {
                crate::check::types::err_fix(st, &Text::lit("mark-function"), span, &Text::from(format!("`{}` returns `{}`; name it `{}{}`", name, &crate::check::types::show_ty(st, &**res), &want, &bare)), &Text::from(format!("rename to `{}{}`", &want, &bare)))
            }
        },
        _ => st.clone(),
    }
}

/// The step machine of `CheckMarkFunction`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
/// ```
pub struct CheckMarkFunction {
    pub st: crate::check::types::St,
    pub name: Text,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for CheckMarkFunction {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let name = &self.name;
        let t = &self.t;
        let span = &self.span;
        match t {
            crate::check::types::Ty::TyFn(_, _, res) => {
                let name = name.clone();
                let res = (**res).clone();
                let span = span.clone();
                let st = st.clone();
                call_then(crate::check::types::start_head_sigil(st.clone(), res.clone()), move |head_sigil_48852: Text| {
                    let want = head_sigil_48852;
                    let marks = crate::check::types::marks_of(&name);
                    let shown = crate::syntax::lexer::head(&marks);
                    let bare = crate::syntax::lexer::drop_prefix(&name, &marks);
                    if (((&shown == &want) || (&len_text(&marks) > &Nat::from(1u32))) || (&bare == &Text::lit(""))) || !is_upper_text(&bare) {
                        prism_rtl::Turn::Finished(st.clone())
                    } else {
                        call_then(crate::check::types::start_show_ty(st.clone(), res.clone()), move |show_ty_49132: Text| prism_rtl::Turn::Finished(crate::check::types::err_fix(&st, &Text::lit("mark-function"), &span, &Text::from(format!("`{}` returns `{}`; name it `{}{}`", &name, &show_ty_49132, &want, &bare)), &Text::from(format!("rename to `{}{}`", &want, &bare)))))
                    }
                })
            },
            _ => prism_rtl::Turn::Finished(st.clone()),
        }
    }
}

/// `Start CheckMarkFunction, x`: what the function value is when passed to `@Run`.
pub fn start_check_mark_function(st: crate::check::types::St, name: Text, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckMarkFunction { st, name, t, span })
}

/// ```prism
/// MissingSignatures: fn G, St, ModInfo -> St
/// ```
pub fn missing_signatures(g: &G, st: &crate::check::types::St, info: &ModInfo) -> crate::check::types::St {
    fold(&g.defs, st, &(|s: &crate::check::types::St, d: &Def| if ((&d.home == &info.name) && is_fn_def(d)) && !has_key(&g.vals, &d.qk) {
        crate::check::types::err_fix(s, &Text::lit("no-signature"), &d.span, &Text::from(format!("`{}` has no signature line", &d.name)), &Text::from(format!("write `{}: fn ... -> ...` above it", &d.name)))
    } else {
        s.clone()
    }))
}

/// ```prism
/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
/// ```
pub fn conv_tag(g: &G, st: &crate::check::types::St, info: &ModInfo, t: &crate::syntax::TagDecl, span: &crate::syntax::Range) -> (G, crate::check::types::St) {
    let name = dotted(&t.name.path_);
    let family = dotted(&take(&t.name.path_, &crate::syntax::lexer::dec(&len(&t.name.path_))));
    let cx_ = cx_of(g, &info.name);
    let (kind, out, st2) = tag_kind(g, &cx_, st, &t.of_type);
    let (fields, st3) = run_to_end(fold_job(t.fields.clone(), (Array::new(), st2.clone()), {
        let cx_ = cx_.clone();
        Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::Field)| {
            let cx_ = cx_.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let f = p1;
                call_then(start_conv_type(cx_.clone(), s.clone(), f.ty.clone()), move |conv_type_50044: (crate::check::types::Ty, crate::check::types::St)| {
                    let (ft, s2) = conv_type_50044;
                    prism_rtl::Turn::Finished((push(&acc, &(f.name.name.clone(), ft.clone())), s2.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::Field)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
    }));
    let qs = run_to_end(fold_job(t.fields.clone(), type_vars_of_type(&t.of_type), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Field)| entered(once_job(move || {
        let acc = p0;
        let f = p1;
        call_then(start_type_vars_of_type(f.ty.clone()), move |type_vars_of_type_50195: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_vars_of_type_50195)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Field)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let (bs, st4) = conv_bounds(&cx_, &st3, &t.bounds);
    let tg = TagInfo { name: name.clone(), family: family.clone(), kind: kind.clone(), out: out.clone(), qs: qs.clone(), rqs: if &info.row_var == &Text::lit("") {
        Array::new()
    } else {
        Array::from(vec![info.row_var.clone()])
    }, bounds: bs.clone(), fields: fields.clone(), home: info.name.clone(), file: info.file.clone(), span: span.clone() };
    let upd = {
        let mut this: G = g.clone();
        this.tags = insert(&this.tags, &name, &tg);
        this
    };
    (upd.clone(), st4.clone())
}

/// The step machine of `ConvTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
/// ```
pub struct ConvTag {
    pub g: G,
    pub st: crate::check::types::St,
    pub info: ModInfo,
    pub t: crate::syntax::TagDecl,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(G, crate::check::types::St)> for ConvTag {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let info = &self.info;
        let t = &self.t;
        let span = &self.span;
        let name = dotted(&t.name.path_);
        let family = dotted(&take(&t.name.path_, &crate::syntax::lexer::dec(&len(&t.name.path_))));
        let cx_ = cx_of(g, &info.name);
        let g = g.clone();
        let info = info.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_tag_kind(g.clone(), cx_.clone(), st.clone(), t.of_type.clone()), move |tag_kind_49918: (Text, crate::check::types::Ty, crate::check::types::St)| {
            let (kind, out, st2) = tag_kind_49918;
            call_value(fold_job(t.fields.clone(), (Array::new(), st2.clone()), {
                let cx_ = cx_.clone();
                Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::Field)| {
                    let cx_ = cx_.clone();
                    entered(once_job(move || {
                        let (acc, s) = p0;
                        let f = p1;
                        call_then(start_conv_type(cx_.clone(), s.clone(), f.ty.clone()), move |conv_type_50044: (crate::check::types::Ty, crate::check::types::St)| {
                            let (ft, s2) = conv_type_50044;
                            prism_rtl::Turn::Finished((push(&acc, &(f.name.name.clone(), ft.clone())), s2.clone()))
                        })
                    }))
                }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::Field)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
            }), move |fold_49972: (Array<(Text, crate::check::types::Ty)>, crate::check::types::St)| {
                let (fields, st3) = fold_49972;
                call_then(start_type_vars_of_type(t.of_type.clone()), move |type_vars_of_type_50142: Array<Text>| call_value(fold_job(t.fields.clone(), type_vars_of_type_50142, Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Field)| entered(once_job(move || {
                    let acc = p0;
                    let f = p1;
                    call_then(start_type_vars_of_type(f.ty.clone()), move |type_vars_of_type_50195: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_vars_of_type_50195)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Field)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_50126: Array<Text>| {
                    let qs = fold_50126;
                    let (bs, st4) = conv_bounds(&cx_, &st3, &t.bounds);
                    let tg = TagInfo { name: name.clone(), family: family.clone(), kind: kind.clone(), out: out.clone(), qs: qs.clone(), rqs: if &info.row_var == &Text::lit("") {
                        Array::new()
                    } else {
                        Array::from(vec![info.row_var.clone()])
                    }, bounds: bs.clone(), fields: fields.clone(), home: info.name.clone(), file: info.file.clone(), span: span.clone() };
                    let upd = {
                        let mut this: G = g.clone();
                        this.tags = insert(&this.tags, &name, &tg);
                        this
                    };
                    prism_rtl::Turn::Finished((upd.clone(), st4.clone()))
                }))
            })
        })
    }
}

/// `Start ConvTag, x`: what the function value is when passed to `@Run`.
pub fn start_conv_tag(g: G, st: crate::check::types::St, info: ModInfo, t: crate::syntax::TagDecl, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>> {
    Rc::new(ConvTag { g, st, info, t, span })
}

/// ```prism
/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
/// ```
pub fn tag_kind(g: &G, cx_: &Cx_, st: &crate::check::types::St, t: &crate::syntax::Type) -> (Text, crate::check::types::Ty, crate::check::types::St) {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, args) => {
            let name = dotted(&n.path_);
            if &name == &Text::lit("Element") {
                match index(args, &Nat::from(0u32)) {
                    Some(o) => {
                        let (ot, s2) = conv_type(cx_, st, &o);
                        (Text::lit("Element"), ot.clone(), s2.clone())
                    },
                    None => (Text::lit("Element"), crate::check::types::t_unit(), st.clone()),
                }
            } else {
                {
                    let (key_opt, _) = resolve_type(g, &cx_.home, &n.path_);
                    match &key_opt {
                        Some(k) => match &or(&get(&g.types, k), &dummy_ty_info()).body {
                            TyBody::BRowKind => (k.clone(), crate::check::types::t_unit(), st.clone()),
                            _ => (k.clone(), crate::check::types::t_unit(), crate::check::types::err(st, &Text::lit("kind"), &t.span, &Text::from(format!("`{}` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`", &name)))),
                        },
                        None => (Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unknown-name"), &t.span, &Text::from(format!("no row kind `{}`", &name)))),
                    }
                }
            }
        },
        crate::syntax::TypeKind::TGroup(x) => tag_kind(g, cx_, st, &**x),
        _ => (Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("kind"), &t.span, &Text::lit("a tag joins a row kind"))),
    }
}

/// The step machine of `TagKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
/// ```
pub struct TagKind {
    pub g: G,
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<(Text, crate::check::types::Ty, crate::check::types::St)> for TagKind {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::Ty, crate::check::types::St)> {
        let g = &self.g;
        let cx_ = &self.cx_;
        let st = &self.st;
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TName(n, args) => {
                let name = dotted(&n.path_);
                if &name == &Text::lit("Element") {
                    match index(args, &Nat::from(0u32)) {
                        Some(o) => {
                            let cx_ = cx_.clone();
                            let st = st.clone();
                            call_then(start_conv_type(cx_.clone(), st.clone(), o.clone()), move |conv_type_50905: (crate::check::types::Ty, crate::check::types::St)| {
                                let (ot, s2) = conv_type_50905;
                                prism_rtl::Turn::Finished((Text::lit("Element"), ot.clone(), s2.clone()))
                            })
                        },
                        None => prism_rtl::Turn::Finished((Text::lit("Element"), crate::check::types::t_unit(), st.clone())),
                    }
                } else {
                    {
                        let (key_opt, _) = resolve_type(g, &cx_.home, &n.path_);
                        match &key_opt {
                            Some(k) => match &or(&get(&g.types, k), &dummy_ty_info()).body {
                                TyBody::BRowKind => prism_rtl::Turn::Finished((k.clone(), crate::check::types::t_unit(), st.clone())),
                                _ => prism_rtl::Turn::Finished((k.clone(), crate::check::types::t_unit(), crate::check::types::err(st, &Text::lit("kind"), &t.span, &Text::from(format!("`{}` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`", &name))))),
                            },
                            None => prism_rtl::Turn::Finished((Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("unknown-name"), &t.span, &Text::from(format!("no row kind `{}`", &name))))),
                        }
                    }
                }
            },
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(TagKind { g: g.clone(), cx_: cx_.clone(), st: st.clone(), t: (**x).clone() })),
            _ => prism_rtl::Turn::Finished((Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("kind"), &t.span, &Text::lit("a tag joins a row kind")))),
        }
    }
}

/// `Start TagKind, x`: what the function value is when passed to `@Run`.
pub fn start_tag_kind(g: G, cx_: Cx_, st: crate::check::types::St, t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(TagKind { g, cx_, st, t })
}

/// ```prism
/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
/// ```
pub fn conv_trait(g: &G, st: &crate::check::types::St, info: &ModInfo, t: &crate::syntax::TraitDecl, span: &crate::syntax::Range) -> (G, crate::check::types::St) {
    let name = qual_key(&info.name, &dotted(&t.name.path_));
    let param = or(&index(&each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone())), &Nat::from(0u32)), &Text::lit("a"));
    let st1 = if &len(&t.params) > &Nat::from(1u32) {
        crate::check::types::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement traits of several types"))
    } else {
        st.clone()
    };
    let cx_ = cx_of(g, &info.name);
    let (supers, st2) = conv_bounds(&cx_, &st1, &t.bounds);
    let (g3, st3, methods, defaults, assocs) = run_to_end(fold_job(t.items.clone(), (g.clone(), st2.clone(), Array::new(), Array::new(), Array::new()), {
        let info = info.clone();
        let cx_ = cx_.clone();
        let param = param.clone();
        let name = name.clone();
        Rc::new(move |(p0, p1): ((G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>), crate::syntax::TraitItem)| {
            let info = info.clone();
            let cx_ = cx_.clone();
            let param = param.clone();
            let name = name.clone();
            entered(once_job(move || {
                let (gg, s, ms, ds, assoc_acc) = p0;
                let it = p1;
                match &it {
                    crate::syntax::TraitItem::TiSignature(sg) => {
                        let mname = def_name_text(&sg.name);
                        let qk = qual_key(&info.name, &mname);
                        let sg = sg.clone();
                        call_then(start_sig_scheme(cx_.clone(), s.clone(), sg.ty.clone(), sg.bounds.clone()), move |sig_scheme_52471: (crate::check::types::Scheme, crate::check::types::St)| {
                            let (sc, s2) = sig_scheme_52471;
                            let sc2 = {
                                let mut this: crate::check::types::Scheme = sc.clone();
                                this.qs = if crate::check::types::has_text(&this.qs, &param) {
                                    this.qs.clone()
                                } else {
                                    append(&Array::from(vec![param.clone()]), &this.qs)
                                };
                                this.bounds = append(&Array::from(vec![(param.clone(), name.clone())]), &this.bounds);
                                this
                            };
                            let upd = {
                                let mut this: G = gg.clone();
                                this.vals = insert(&this.vals, &qk, &ValInfo { qk: qk.clone(), scheme: sc2.clone(), sort: Text::lit("method"), has_sig: true, home: info.name.clone(), file: info.file.clone(), span: sg.span.clone() });
                                this
                            };
                            prism_rtl::Turn::Finished((upd.clone(), s2.clone(), push(&ms, &qk), ds.clone(), assoc_acc.clone()))
                        })
                    },
                    crate::syntax::TraitItem::TiFn(f) => {
                        let qk = qual_key(&info.name, &def_name_text(&f.name));
                        let def = Def { qk: qk.clone(), name: def_name_text(&f.name), home: info.name.clone(), file: info.file.clone(), span: f.span.clone(), body: DefBody::DbDefault(Array::from(vec![f.clone()]), name.clone()) };
                        let upd = {
                            let mut this: G = gg.clone();
                            this.defs = push(&this.defs, &def);
                            this
                        };
                        prism_rtl::Turn::Finished((upd.clone(), s.clone(), ms.clone(), push(&ds, &qk), assoc_acc.clone()))
                    },
                    crate::syntax::TraitItem::TiAssocType(n, _, _, _) => prism_rtl::Turn::Finished((gg.clone(), s.clone(), ms.clone(), ds.clone(), push(&assoc_acc, &n.name))),
                    crate::syntax::TraitItem::TiAssocRow(_, r) => prism_rtl::Turn::Finished((gg.clone(), crate::check::types::err(&s, &Text::lit("unsupported"), r, &Text::lit("this checker does not implement associated rows")), ms.clone(), ds.clone(), assoc_acc.clone())),
                }
            }))
        }) as Rc<dyn Fn(((G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>), crate::syntax::TraitItem)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>)>>>
    }));
    let ti = TraitInfo { name: name.clone(), home: info.name.clone(), param: param.clone(), supers: each(&supers, &(|(_, k): &(Text, Text)| k.clone())), methods: methods.clone(), defaults: defaults.clone(), assocs: assocs.clone(), file: info.file.clone(), span: span.clone() };
    let upd3 = {
        let mut this: G = g3.clone();
        this.traits = insert(&this.traits, &name, &ti);
        this
    };
    (upd3.clone(), st3.clone())
}

/// The step machine of `ConvTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
/// ```
pub struct ConvTrait {
    pub g: G,
    pub st: crate::check::types::St,
    pub info: ModInfo,
    pub t: crate::syntax::TraitDecl,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(G, crate::check::types::St)> for ConvTrait {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let info = &self.info;
        let t = &self.t;
        let span = &self.span;
        let name = qual_key(&info.name, &dotted(&t.name.path_));
        let param = or(&index(&each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone())), &Nat::from(0u32)), &Text::lit("a"));
        let st1 = if &len(&t.params) > &Nat::from(1u32) {
            crate::check::types::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement traits of several types"))
        } else {
            st.clone()
        };
        let cx_ = cx_of(g, &info.name);
        let (supers, st2) = conv_bounds(&cx_, &st1, &t.bounds);
        let g = g.clone();
        let info = info.clone();
        let span = span.clone();
        let t = t.clone();
        call_value(fold_job(t.items.clone(), (g.clone(), st2.clone(), Array::new(), Array::new(), Array::new()), {
            let info = info.clone();
            let cx_ = cx_.clone();
            let param = param.clone();
            let name = name.clone();
            Rc::new(move |(p0, p1): ((G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>), crate::syntax::TraitItem)| {
                let info = info.clone();
                let cx_ = cx_.clone();
                let param = param.clone();
                let name = name.clone();
                entered(once_job(move || {
                    let (gg, s, ms, ds, assoc_acc) = p0;
                    let it = p1;
                    match &it {
                        crate::syntax::TraitItem::TiSignature(sg) => {
                            let mname = def_name_text(&sg.name);
                            let qk = qual_key(&info.name, &mname);
                            let sg = sg.clone();
                            call_then(start_sig_scheme(cx_.clone(), s.clone(), sg.ty.clone(), sg.bounds.clone()), move |sig_scheme_52471: (crate::check::types::Scheme, crate::check::types::St)| {
                                let (sc, s2) = sig_scheme_52471;
                                let sc2 = {
                                    let mut this: crate::check::types::Scheme = sc.clone();
                                    this.qs = if crate::check::types::has_text(&this.qs, &param) {
                                        this.qs.clone()
                                    } else {
                                        append(&Array::from(vec![param.clone()]), &this.qs)
                                    };
                                    this.bounds = append(&Array::from(vec![(param.clone(), name.clone())]), &this.bounds);
                                    this
                                };
                                let upd = {
                                    let mut this: G = gg.clone();
                                    this.vals = insert(&this.vals, &qk, &ValInfo { qk: qk.clone(), scheme: sc2.clone(), sort: Text::lit("method"), has_sig: true, home: info.name.clone(), file: info.file.clone(), span: sg.span.clone() });
                                    this
                                };
                                prism_rtl::Turn::Finished((upd.clone(), s2.clone(), push(&ms, &qk), ds.clone(), assoc_acc.clone()))
                            })
                        },
                        crate::syntax::TraitItem::TiFn(f) => {
                            let qk = qual_key(&info.name, &def_name_text(&f.name));
                            let def = Def { qk: qk.clone(), name: def_name_text(&f.name), home: info.name.clone(), file: info.file.clone(), span: f.span.clone(), body: DefBody::DbDefault(Array::from(vec![f.clone()]), name.clone()) };
                            let upd = {
                                let mut this: G = gg.clone();
                                this.defs = push(&this.defs, &def);
                                this
                            };
                            prism_rtl::Turn::Finished((upd.clone(), s.clone(), ms.clone(), push(&ds, &qk), assoc_acc.clone()))
                        },
                        crate::syntax::TraitItem::TiAssocType(n, _, _, _) => prism_rtl::Turn::Finished((gg.clone(), s.clone(), ms.clone(), ds.clone(), push(&assoc_acc, &n.name))),
                        crate::syntax::TraitItem::TiAssocRow(_, r) => prism_rtl::Turn::Finished((gg.clone(), crate::check::types::err(&s, &Text::lit("unsupported"), r, &Text::lit("this checker does not implement associated rows")), ms.clone(), ds.clone(), assoc_acc.clone())),
                    }
                }))
            }) as Rc<dyn Fn(((G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>), crate::syntax::TraitItem)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>)>>>
        }), move |fold_52239: (G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>)| {
            let (g3, st3, methods, defaults, assocs) = fold_52239;
            let ti = TraitInfo { name: name.clone(), home: info.name.clone(), param: param.clone(), supers: each(&supers, &(|(_, k): &(Text, Text)| k.clone())), methods: methods.clone(), defaults: defaults.clone(), assocs: assocs.clone(), file: info.file.clone(), span: span.clone() };
            let upd3 = {
                let mut this: G = g3.clone();
                this.traits = insert(&this.traits, &name, &ti);
                this
            };
            prism_rtl::Turn::Finished((upd3.clone(), st3.clone()))
        })
    }
}

/// `Start ConvTrait, x`: what the function value is when passed to `@Run`.
pub fn start_conv_trait(g: G, st: crate::check::types::St, info: ModInfo, t: crate::syntax::TraitDecl, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>> {
    Rc::new(ConvTrait { g, st, info, t, span })
}

/// ```prism
/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
/// ```
pub fn conv_impl(g: &G, st: &crate::check::types::St, info: &ModInfo, i: &crate::syntax::ImplDecl, span: &crate::syntax::Range) -> (G, crate::check::types::St) {
    match resolve_trait(g, &info.name, &i.trait_ref.path_) {
        None => (g.clone(), crate::check::types::err(st, &Text::lit("unknown-name"), &i.trait_ref.span, &Text::from(format!("no trait `^{}`", &dotted(&i.trait_ref.path_))))),
        Some(cls) => {
            let cx_ = cx_of(g, &info.name);
            let (head, st2) = conv_type(&cx_, st, &i.ty);
            let (bs, st3) = conv_bounds(&cx_, &st2, &i.bounds);
            let (assocs, st4) = run_to_end(fold_job(i.items.clone(), (Array::new(), st3.clone()), {
                let cx_ = cx_.clone();
                Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::TraitItem)| {
                    let cx_ = cx_.clone();
                    entered(once_job(move || {
                        let (acc, s) = p0;
                        let it = p1;
                        match &it {
                            crate::syntax::TraitItem::TiAssocType(n, _, Some(v_), _) => {
                                let n = n.clone();
                                let v_ = v_.clone();
                                call_then(start_conv_type(cx_.clone(), s.clone(), v_.clone()), move |conv_type_54488: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (vt, s2) = conv_type_54488;
                                    prism_rtl::Turn::Finished((push(&acc, &(n.name.clone(), vt.clone())), s2.clone()))
                                })
                            },
                            _ => prism_rtl::Turn::Finished((acc.clone(), s.clone())),
                        }
                    }))
                }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::TraitItem)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
            }));
            let names = fold(&i.items, &Array::new(), &(|acc: &Array<Text>, it: &crate::syntax::TraitItem| match it {
                crate::syntax::TraitItem::TiFn(f) => crate::check::types::add_text(acc, &def_name_text(&f.name)),
                _ => acc.clone(),
            }));
            let im = ImplInfo { cls: cls.clone(), head: head.clone(), qs: type_vars_of_type(&i.ty), bounds: bs.clone(), home: info.name.clone(), file: info.file.clone(), span: span.clone(), derived: false, assocs: assocs.clone(), methods: names.clone() };
            let g2 = {
                let mut this: G = g.clone();
                this.impls = insert(&this.impls, &cls, &push(&or(&get(&this.impls, &cls), &Array::new()), &im));
                this
            };
            let g3 = fold(&names, &g2, &(|gg: &G, mname: &Text| {
                let clauses = fold(&i.items, &Array::new(), &(|acc: &Array<crate::syntax::FnClause>, it: &crate::syntax::TraitItem| match it {
                    crate::syntax::TraitItem::TiFn(f) => if &def_name_text(&f.name) == mname { push(acc, f) } else { acc.clone() },
                    _ => acc.clone(),
                }));
                {
                    let mut this: G = gg.clone();
                    this.defs = push(&this.defs, &Def { qk: Text::from(format!("{} impl {}", &cls, mname)), name: mname.clone(), home: info.name.clone(), file: info.file.clone(), span: span.clone(), body: DefBody::DbMethod(clauses.clone(), cls.clone(), im.clone()) });
                    this
                }
            }));
            (g3.clone(), st4.clone())
        },
    }
}

/// The step machine of `ConvImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
/// ```
pub struct ConvImpl {
    pub g: G,
    pub st: crate::check::types::St,
    pub info: ModInfo,
    pub i: crate::syntax::ImplDecl,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(G, crate::check::types::St)> for ConvImpl {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let info = &self.info;
        let i = &self.i;
        let span = &self.span;
        match resolve_trait(g, &info.name, &i.trait_ref.path_) {
            None => prism_rtl::Turn::Finished((g.clone(), crate::check::types::err(st, &Text::lit("unknown-name"), &i.trait_ref.span, &Text::from(format!("no trait `^{}`", &dotted(&i.trait_ref.path_)))))),
            Some(cls) => {
                let cx_ = cx_of(g, &info.name);
                let g = g.clone();
                let i = i.clone();
                let info = info.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(start_conv_type(cx_.clone(), st.clone(), i.ty.clone()), move |conv_type_54241: (crate::check::types::Ty, crate::check::types::St)| {
                    let (head, st2) = conv_type_54241;
                    let (bs, st3) = conv_bounds(&cx_, &st2, &i.bounds);
                    call_value(fold_job(i.items.clone(), (Array::new(), st3.clone()), {
                        let cx_ = cx_.clone();
                        Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::TraitItem)| {
                            let cx_ = cx_.clone();
                            entered(once_job(move || {
                                let (acc, s) = p0;
                                let it = p1;
                                match &it {
                                    crate::syntax::TraitItem::TiAssocType(n, _, Some(v_), _) => {
                                        let n = n.clone();
                                        let v_ = v_.clone();
                                        call_then(start_conv_type(cx_.clone(), s.clone(), v_.clone()), move |conv_type_54488: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (vt, s2) = conv_type_54488;
                                            prism_rtl::Turn::Finished((push(&acc, &(n.name.clone(), vt.clone())), s2.clone()))
                                        })
                                    },
                                    _ => prism_rtl::Turn::Finished((acc.clone(), s.clone())),
                                }
                            }))
                        }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::TraitItem)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
                    }), move |fold_54348: (Array<(Text, crate::check::types::Ty)>, crate::check::types::St)| {
                        let (assocs, st4) = fold_54348;
                        let names = fold(&i.items, &Array::new(), &(|acc: &Array<Text>, it: &crate::syntax::TraitItem| match it {
                            crate::syntax::TraitItem::TiFn(f) => crate::check::types::add_text(acc, &def_name_text(&f.name)),
                            _ => acc.clone(),
                        }));
                        call_then(start_type_vars_of_type(i.ty.clone()), move |type_vars_of_type_54783: Array<Text>| {
                            let im = ImplInfo { cls: cls.clone(), head: head.clone(), qs: type_vars_of_type_54783, bounds: bs.clone(), home: info.name.clone(), file: info.file.clone(), span: span.clone(), derived: false, assocs: assocs.clone(), methods: names.clone() };
                            let g2 = {
                                let mut this: G = g.clone();
                                this.impls = insert(&this.impls, &cls, &push(&or(&get(&this.impls, &cls), &Array::new()), &im));
                                this
                            };
                            let g3 = fold(&names, &g2, &(|gg: &G, mname: &Text| {
                                let clauses = fold(&i.items, &Array::new(), &(|acc: &Array<crate::syntax::FnClause>, it: &crate::syntax::TraitItem| match it {
                                    crate::syntax::TraitItem::TiFn(f) => if &def_name_text(&f.name) == mname { push(acc, f) } else { acc.clone() },
                                    _ => acc.clone(),
                                }));
                                {
                                    let mut this: G = gg.clone();
                                    this.defs = push(&this.defs, &Def { qk: Text::from(format!("{} impl {}", &cls, mname)), name: mname.clone(), home: info.name.clone(), file: info.file.clone(), span: span.clone(), body: DefBody::DbMethod(clauses.clone(), cls.clone(), im.clone()) });
                                    this
                                }
                            }));
                            prism_rtl::Turn::Finished((g3.clone(), st4.clone()))
                        })
                    })
                })
            },
        }
    }
}

/// `Start ConvImpl, x`: what the function value is when passed to `@Run`.
pub fn start_conv_impl(g: G, st: crate::check::types::St, info: ModInfo, i: crate::syntax::ImplDecl, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>> {
    Rc::new(ConvImpl { g, st, info, i, span })
}

/// ```prism
/// DerivedImpls: fn G -> G
/// ```
pub fn derived_impls(g: &G) -> G {
    fold(&keys(&g.types), g, &(|gg: &G, k: &Text| match get(&gg.types, k) {
        Some(ti) => fold(&ti.derives, gg, &(|g2: &G, tr: &Text| match resolve_trait(g2, &ti.home, &split(tr, &Text::lit("."))) {
            Some(cls) => {
                let im = ImplInfo { cls: cls.clone(), head: crate::check::types::Ty::TyCon(ti.name.clone(), each(&ti.params, &(|p_: &Text| crate::check::types::Ty::TyQ(p_.clone())))), qs: ti.params.clone(), bounds: each(&ti.params, &(|p_: &Text| (p_.clone(), cls.clone()))), home: ti.home.clone(), file: ti.file.clone(), span: ti.span.clone(), derived: true, assocs: Array::new(), methods: Array::new() };
                {
                    let mut this: G = g2.clone();
                    this.impls = insert(&this.impls, &cls, &push(&or(&get(&this.impls, &cls), &Array::new()), &im));
                    this
                }
            },
            None => g2.clone(),
        })),
        None => gg.clone(),
    }))
}

/// ```prism
/// Coherence: unbounded fn G, St -> St
/// ```
pub fn coherence(g: &G, st: &crate::check::types::St) -> crate::check::types::St {
    run_to_end(fold_job(keys(&g.impls), st.clone(), {
        let g = g.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
            let g = g.clone();
            entered(once_job(move || {
                let s = p0;
                let cls = p1;
                {
                    let impls = or(&get(&g.impls, &cls), &Array::new());
                    call_value(fold_job(impls.clone(), s.clone(), {
                        let g = g.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::St, ImplInfo)| {
                            let g = g.clone();
                            entered(once_job(move || {
                                let s1 = p0;
                                let i = p1;
                                prism_rtl::Turn::More(Rc::new(CheckOrphan { g: g.clone(), st: s1.clone(), i: i.clone() }))
                            }))
                        }) as Rc<dyn Fn((crate::check::types::St, ImplInfo)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_56616: crate::check::types::St| {
                        let s2 = fold_56616;
                        fold_job(crate::check::errors::range0(&len(&impls)), s2.clone(), {
                            let impls = impls.clone();
                            let g = g.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                let impls = impls.clone();
                                let g = g.clone();
                                entered(once_job(move || {
                                    let s3 = p0;
                                    let a = p1;
                                    fold_job(crate::check::errors::range0(&len(&impls)), s3.clone(), {
                                        let a = a.clone();
                                        let g = g.clone();
                                        let impls = impls.clone();
                                        Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                            let a = a.clone();
                                            let g = g.clone();
                                            let impls = impls.clone();
                                            entered(once_job(move || {
                                                let s4 = p0;
                                                let b = p1;
                                                if &a < &b {
                                                    prism_rtl::Turn::More(Rc::new(CheckPair { g: g.clone(), st: s4.clone(), a: or(&index(&impls, &a), &dummy_impl()), b: or(&index(&impls, &b), &dummy_impl()) }))
                                                } else {
                                                    prism_rtl::Turn::Finished(s4.clone())
                                                }
                                            }))
                                        }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                                    }).cycle()
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle()
                    })
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `Coherence`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Coherence: unbounded fn G, St -> St
/// ```
pub struct Coherence {
    pub g: G,
    pub st: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for Coherence {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        fold_job(keys(&g.impls), st.clone(), {
            let g = g.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
                let g = g.clone();
                entered(once_job(move || {
                    let s = p0;
                    let cls = p1;
                    {
                        let impls = or(&get(&g.impls, &cls), &Array::new());
                        call_value(fold_job(impls.clone(), s.clone(), {
                            let g = g.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, ImplInfo)| {
                                let g = g.clone();
                                entered(once_job(move || {
                                    let s1 = p0;
                                    let i = p1;
                                    prism_rtl::Turn::More(Rc::new(CheckOrphan { g: g.clone(), st: s1.clone(), i: i.clone() }))
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, ImplInfo)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }), move |fold_56616: crate::check::types::St| {
                            let s2 = fold_56616;
                            fold_job(crate::check::errors::range0(&len(&impls)), s2.clone(), {
                                let impls = impls.clone();
                                let g = g.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                    let impls = impls.clone();
                                    let g = g.clone();
                                    entered(once_job(move || {
                                        let s3 = p0;
                                        let a = p1;
                                        fold_job(crate::check::errors::range0(&len(&impls)), s3.clone(), {
                                            let a = a.clone();
                                            let g = g.clone();
                                            let impls = impls.clone();
                                            Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                                let a = a.clone();
                                                let g = g.clone();
                                                let impls = impls.clone();
                                                entered(once_job(move || {
                                                    let s4 = p0;
                                                    let b = p1;
                                                    if &a < &b {
                                                        prism_rtl::Turn::More(Rc::new(CheckPair { g: g.clone(), st: s4.clone(), a: or(&index(&impls, &a), &dummy_impl()), b: or(&index(&impls, &b), &dummy_impl()) }))
                                                    } else {
                                                        prism_rtl::Turn::Finished(s4.clone())
                                                    }
                                                }))
                                            }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                                        }).cycle()
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }).cycle()
                        })
                    }
                }))
            }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start Coherence, x`: what the function value is when passed to `@Run`.
pub fn start_coherence(g: G, st: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Coherence { g, st })
}

/// ```prism
/// let dummyImpl
/// ```
pub fn dummy_impl() -> ImplInfo {
    ImplInfo { cls: Text::lit(""), head: crate::check::types::Ty::TyErr, qs: Array::new(), bounds: Array::new(), home: Text::lit(""), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }, derived: false, assocs: Array::new(), methods: Array::new() }
}

/// ```prism
/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub fn check_pair(g: &G, st: &crate::check::types::St, a: &ImplInfo, b: &ImplInfo) -> crate::check::types::St {
    if !heads_may_meet(&a.head, &b.head) {
        st.clone()
    } else {
        if (&a.file < &b.file) || ((&a.file == &b.file) && (&a.span.start <= &b.span.start)) {
            check_pair_in(g, st, a, b)
        } else {
            check_pair_in(g, st, b, a)
        }
    }
}

/// The step machine of `CheckPair`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub struct CheckPair {
    pub g: G,
    pub st: crate::check::types::St,
    pub a: ImplInfo,
    pub b: ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckPair {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let a = &self.a;
        let b = &self.b;
        if !heads_may_meet(&a.head, &b.head) {
            prism_rtl::Turn::Finished(st.clone())
        } else {
            if (&a.file < &b.file) || ((&a.file == &b.file) && (&a.span.start <= &b.span.start)) {
                prism_rtl::Turn::More(Rc::new(CheckPairIn { g: g.clone(), st: st.clone(), a: a.clone(), b: b.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(CheckPairIn { g: g.clone(), st: st.clone(), a: b.clone(), b: a.clone() }))
            }
        }
    }
}

/// `Start CheckPair, x`: what the function value is when passed to `@Run`.
pub fn start_check_pair(g: G, st: crate::check::types::St, a: ImplInfo, b: ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckPair { g, st, a, b })
}

/// ```prism
/// HeadsMayMeet: fn Ty, Ty -> Bool
/// ```
pub fn heads_may_meet(ty0: &crate::check::types::Ty, ty1: &crate::check::types::Ty) -> bool {
    match (ty0, ty1) {
        (crate::check::types::Ty::TyCon(x, _), crate::check::types::Ty::TyCon(y, _)) => x == y,
        (_, _) => true,
    }
}

/// ```prism
/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub fn check_pair_in(g: &G, st: &crate::check::types::St, a: &ImplInfo, b: &ImplInfo) -> crate::check::types::St {
    let s0 = {
        let mut this: crate::check::types::St = st.clone();
        this.file = b.file.clone();
        this
    };
    let (ta, s1) = crate::check::types::instantiate(&s0, &crate::check::types::Scheme { qs: a.qs.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: a.head.clone() }, &b.span);
    let (tb, s2) = crate::check::types::instantiate(&s1, &crate::check::types::Scheme { qs: b.qs.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: b.head.clone() }, &b.span);
    let (ok, s3) = crate::check::types::try_unify(&s2, &ta, &tb, &b.span);
    if !ok {
        st.clone()
    } else {
        {
            let same = ((&len(&a.qs) == &Nat::from(0u32)) && (&len(&b.qs) == &Nat::from(0u32))) || (&shape_of(&a.head) == &shape_of(&b.head));
            let code = if same { Text::lit("impl-duplicate") } else { Text::lit("impl-overlap") };
            let first_at = crate::check::errors::src_place(&or(&index(&g.srcs, &a.file), &crate::check::errors::mk_src(&Text::lit("?"), &Text::lit(""))), &a.span.start);
            crate::check::types::err_fix(&s0, &code, &b.span, &Text::from(format!("a second impl of `^{}` for `{}`", &crate::check::types::bare_name(&a.cls), &crate::check::types::show_ty(&s0, &b.head))), &Text::from(format!("the first is at {}; keep one", &first_at)))
        }
    }
}

/// The step machine of `CheckPairIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub struct CheckPairIn {
    pub g: G,
    pub st: crate::check::types::St,
    pub a: ImplInfo,
    pub b: ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckPairIn {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let a = &self.a;
        let b = &self.b;
        let s0 = {
            let mut this: crate::check::types::St = st.clone();
            this.file = b.file.clone();
            this
        };
        let a = a.clone();
        let b = b.clone();
        let g = g.clone();
        let st = st.clone();
        call_then(crate::check::types::start_instantiate(s0.clone(), crate::check::types::Scheme { qs: a.qs.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: a.head.clone() }, b.span.clone()), move |instantiate_57633: (crate::check::types::Ty, crate::check::types::St)| {
            let (ta, s1) = instantiate_57633;
            call_then(crate::check::types::start_instantiate(s1.clone(), crate::check::types::Scheme { qs: b.qs.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: b.head.clone() }, b.span.clone()), move |instantiate_57767: (crate::check::types::Ty, crate::check::types::St)| {
                let (tb, s2) = instantiate_57767;
                call_then(crate::check::types::start_try_unify(s2.clone(), ta.clone(), tb.clone(), b.span.clone()), move |try_unify_57901: (bool, crate::check::types::St)| {
                    let (ok, s3) = try_unify_57901;
                    if !ok {
                        prism_rtl::Turn::Finished(st.clone())
                    } else {
                        {
                            let same = ((&len(&a.qs) == &Nat::from(0u32)) && (&len(&b.qs) == &Nat::from(0u32))) || (&shape_of(&a.head) == &shape_of(&b.head));
                            let code = if same { Text::lit("impl-duplicate") } else { Text::lit("impl-overlap") };
                            let first_at = crate::check::errors::src_place(&or(&index(&g.srcs, &a.file), &crate::check::errors::mk_src(&Text::lit("?"), &Text::lit(""))), &a.span.start);
                            call_then(crate::check::types::start_show_ty(s0.clone(), b.head.clone()), move |show_ty_58277: Text| prism_rtl::Turn::Finished(crate::check::types::err_fix(&s0, &code, &b.span, &Text::from(format!("a second impl of `^{}` for `{}`", &crate::check::types::bare_name(&a.cls), &show_ty_58277)), &Text::from(format!("the first is at {}; keep one", &first_at)))))
                        }
                    }
                })
            })
        })
    }
}

/// `Start CheckPairIn, x`: what the function value is when passed to `@Run`.
pub fn start_check_pair_in(g: G, st: crate::check::types::St, a: ImplInfo, b: ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckPairIn { g, st, a, b })
}

/// ```prism
/// ShapeOf: unbounded fn Ty -> Text
/// ```
pub fn shape_of(t: &crate::check::types::Ty) -> Text {
    match t {
        crate::check::types::Ty::TyQ(_) => Text::lit("_"),
        crate::check::types::Ty::TyCon(n, args) => Text::from(format!("{}({})", n, &crate::syntax::lexer::join(&run_to_end(each_job(args.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_shape_of(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(",")))),
        crate::check::types::Ty::TyTuple(ts) => Text::from(format!("(({}))", &crate::syntax::lexer::join(&run_to_end(each_job(ts.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_shape_of(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(",")))),
        crate::check::types::Ty::TyArray(e) => Text::from(format!("[{}]", &shape_of(&**e))),
        crate::check::types::Ty::TyMap(k, v_) => Text::from(format!("{}==>{}", &shape_of(&**k), &shape_of(&**v_))),
        crate::check::types::Ty::TySig(s, i) => Text::from(format!("{}{}", s, &shape_of(&**i))),
        _ => Text::lit("?"),
    }
}

/// The step machine of `ShapeOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShapeOf: unbounded fn Ty -> Text
/// ```
pub struct ShapeOf {
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for ShapeOf {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyQ(_) => prism_rtl::Turn::Finished(Text::lit("_")),
            crate::check::types::Ty::TyCon(n, args) => {
                let args = args.clone();
                let n = n.clone();
                call_value(each_job(args.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_shape_of(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_58519: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &n, &crate::syntax::lexer::join(&each_58519, &Text::lit(","))))))
            },
            crate::check::types::Ty::TyTuple(ts) => {
                let ts = ts.clone();
                call_value(each_job(ts.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_shape_of(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_58573: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("(({}))", &crate::syntax::lexer::join(&each_58573, &Text::lit(","))))))
            },
            crate::check::types::Ty::TyArray(e) => {
                let e = (**e).clone();
                call_then(start_shape_of(e.clone()), move |shape_of_58618: Text| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &shape_of_58618))))
            },
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_shape_of(k.clone()), move |shape_of_58649: Text| call_then(start_shape_of(v_.clone()), move |shape_of_58663: Text| prism_rtl::Turn::Finished(Text::from(format!("{}==>{}", &shape_of_58649, &shape_of_58663)))))
            },
            crate::check::types::Ty::TySig(s, i) => {
                let i = (**i).clone();
                let s = s.clone();
                call_then(start_shape_of(i.clone()), move |shape_of_58696: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &s, &shape_of_58696))))
            },
            _ => prism_rtl::Turn::Finished(Text::lit("?")),
        }
    }
}

/// `Start ShapeOf, x`: what the function value is when passed to `@Run`.
pub fn start_shape_of(t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShapeOf { t })
}

/// ```prism
/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
/// ```
pub fn check_orphan(g: &G, st: &crate::check::types::St, i: &ImplInfo) -> crate::check::types::St {
    let trait_mod = or(&get(&g.traits, &i.cls), &dummy_trait()).home.clone();
    let owners = each(&type_names_in(&i.head), &(|n: &Text| or(&get(&g.types, n), &dummy_ty_info()).home.clone()));
    if (i.derived || (&i.home == &trait_mod)) || crate::check::types::has_text(&owners, &i.home) {
        st.clone()
    } else {
        {
            let s = {
                let mut this: crate::check::types::St = st.clone();
                this.file = i.file.clone();
                this
            };
            crate::check::types::err_fix(&s, &Text::lit("orphan"), &i.span, &Text::from(format!("{} declares neither `^{}` nor `{}`", &(if &i.home == &Text::lit("") {
                Text::lit("this file")
            } else {
                Text::from(format!("`{}`", &i.home))
            }), &crate::check::types::bare_name(&i.cls), &crate::check::types::show_ty(&s, &i.head))), &Text::lit("wrap the type in a newtype of this module, or move the impl"))
        }
    }
}

/// The step machine of `CheckOrphan`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
/// ```
pub struct CheckOrphan {
    pub g: G,
    pub st: crate::check::types::St,
    pub i: ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckOrphan {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let i = &self.i;
        let trait_mod = or(&get(&g.traits, &i.cls), &dummy_trait()).home.clone();
        let g = g.clone();
        let i = i.clone();
        let st = st.clone();
        call_then(start_type_names_in(i.head.clone()), move |type_names_in_59009: Array<Text>| {
            let owners = each(&type_names_in_59009, &(|n: &Text| or(&get(&g.types, n), &dummy_ty_info()).home.clone()));
            if (i.derived || (&i.home == &trait_mod)) || crate::check::types::has_text(&owners, &i.home) {
                prism_rtl::Turn::Finished(st.clone())
            } else {
                {
                    let s = {
                        let mut this: crate::check::types::St = st.clone();
                        this.file = i.file.clone();
                        this
                    };
                    call_then(crate::check::types::start_show_ty(s.clone(), i.head.clone()), move |show_ty_59335: Text| prism_rtl::Turn::Finished(crate::check::types::err_fix(&s, &Text::lit("orphan"), &i.span, &Text::from(format!("{} declares neither `^{}` nor `{}`", &(if &i.home == &Text::lit("") {
                        Text::lit("this file")
                    } else {
                        Text::from(format!("`{}`", &i.home))
                    }), &crate::check::types::bare_name(&i.cls), &show_ty_59335)), &Text::lit("wrap the type in a newtype of this module, or move the impl"))))
                }
            }
        })
    }
}

/// `Start CheckOrphan, x`: what the function value is when passed to `@Run`.
pub fn start_check_orphan(g: G, st: crate::check::types::St, i: ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckOrphan { g, st, i })
}

/// ```prism
/// let dummyTrait
/// ```
pub fn dummy_trait() -> TraitInfo {
    TraitInfo { name: Text::lit(""), home: Text::lit(""), param: Text::lit("a"), supers: Array::new(), methods: Array::new(), defaults: Array::new(), assocs: Array::new(), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// TypeNamesIn: unbounded fn Ty -> [Text]
/// ```
pub fn type_names_in(t: &crate::check::types::Ty) -> Array<Text> {
    match t {
        crate::check::types::Ty::TyCon(n, args) => run_to_end(fold_job(args.clone(), Array::from(vec![n.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_type_names_in(a.clone()), move |type_names_in_59698: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_names_in_59698)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_type_names_in(a.clone()), move |type_names_in_59771: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_names_in_59771)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyArray(e) => type_names_in(&**e),
        crate::check::types::Ty::TyMap(k, v_) => crate::check::types::union_texts(&type_names_in(&**k), &type_names_in(&**v_)),
        crate::check::types::Ty::TySig(_, i) => type_names_in(&**i),
        crate::check::types::Ty::TyFn(_, ps, r) => run_to_end(fold_job(ps.clone(), type_names_in(&**r), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_type_names_in(a.clone()), move |type_names_in_59987: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_names_in_59987)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        _ => Array::new(),
    }
}

/// The step machine of `TypeNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeNamesIn: unbounded fn Ty -> [Text]
/// ```
pub struct TypeNamesIn {
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Text>> for TypeNamesIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyCon(n, args) => fold_job(args.clone(), Array::from(vec![n.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_type_names_in(a.clone()), move |type_names_in_59698: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_names_in_59698)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_type_names_in(a.clone()), move |type_names_in_59771: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_names_in_59771)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(TypeNamesIn { t: (**e).clone() })),
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_type_names_in(k.clone()), move |type_names_in_59843: Array<Text>| call_then(start_type_names_in(v_.clone()), move |type_names_in_59860: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&type_names_in_59843, &type_names_in_59860))))
            },
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(TypeNamesIn { t: (**i).clone() })),
            crate::check::types::Ty::TyFn(_, ps, r) => {
                let ps = ps.clone();
                let r = (**r).clone();
                call_then(start_type_names_in(r.clone()), move |type_names_in_59944: Array<Text>| fold_job(ps.clone(), type_names_in_59944, Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_type_names_in(a.clone()), move |type_names_in_59987: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_names_in_59987)))
                }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start TypeNamesIn, x`: what the function value is when passed to `@Run`.
pub fn start_type_names_in(t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TypeNamesIn { t })
}

/// ```prism
/// SuperClosure: unbounded fn G, Text -> [Text]
/// ```
pub fn super_closure(g: &G, cls: &Text) -> Array<Text> {
    run_to_end(fold_job(or(&get(&g.traits, cls), &dummy_trait()).supers.clone(), Array::from(vec![cls.clone()]), {
        let g = g.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
            let g = g.clone();
            entered(once_job(move || {
                let acc = p0;
                let s = p1;
                call_then(start_super_closure(g.clone(), s.clone()), move |super_closure_60445: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &super_closure_60445)))
            }))
        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `SuperClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SuperClosure: unbounded fn G, Text -> [Text]
/// ```
pub struct SuperClosure {
    pub g: G,
    pub cls: Text,
}

impl prism_rtl::Job<Array<Text>> for SuperClosure {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let g = &self.g;
        let cls = &self.cls;
        fold_job(or(&get(&g.traits, cls), &dummy_trait()).supers.clone(), Array::from(vec![cls.clone()]), {
            let g = g.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                let g = g.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let s = p1;
                    call_then(start_super_closure(g.clone(), s.clone()), move |super_closure_60445: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &super_closure_60445)))
                }))
            }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start SuperClosure, x`: what the function value is when passed to `@Run`.
pub fn start_super_closure(g: G, cls: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SuperClosure { g, cls })
}

/// ```prism
/// WithFile: fn St, Nat -> St
/// ```
pub fn with_file(s: &crate::check::types::St, f: &Nat) -> crate::check::types::St {
    let mut this: crate::check::types::St = s.clone();
    this.file = f.clone();
    this
}

/// ```prism
/// BuiltinHas: fn Text, Text -> Bool
/// ```
pub fn builtin_has(cls: &Text, con: &Text) -> bool {
    let bare = crate::check::types::bare_name(cls);
    if &bare == &Text::lit("Num") {
        (((con == &Text::lit("Nat")) || (con == &Text::lit("Int"))) || (con == &Text::lit("U8"))) || (con == &Text::lit("Float"))
    } else {
        if ((&bare == &Text::lit("Eq")) || (&bare == &Text::lit("Ord"))) || (&bare == &Text::lit("Show")) {
            (is_prim_type(con) || (con == &Text::lit("Fault"))) || (con == &Text::lit("Prelude.Fault"))
        } else {
            false
        }
    }
}

/// ```prism
/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
/// ```
pub fn solve_wants(g: &G, st: &crate::check::types::St, givens: &Array<(Text, Text)>, final_: &bool) -> crate::check::types::St {
    let s4 = solve_rounds(g, st, givens, &Nat::from(0u32));
    if *final_ { default_wants(g, &s4, givens) } else { s4.clone() }
}

/// The step machine of `SolveWants`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
/// ```
pub struct SolveWants {
    pub g: G,
    pub st: crate::check::types::St,
    pub givens: Array<(Text, Text)>,
    pub final_: bool,
}

impl prism_rtl::Job<crate::check::types::St> for SolveWants {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let givens = &self.givens;
        let final_ = &self.final_;
        let final_ = *final_;
        let g = g.clone();
        let givens = givens.clone();
        let st = st.clone();
        call_then(start_solve_rounds(g.clone(), st.clone(), givens.clone(), Nat::from(0u32)), move |solve_rounds_61384: crate::check::types::St| {
            let s4 = solve_rounds_61384;
            if final_ {
                prism_rtl::Turn::More(Rc::new(DefaultWants { g: g.clone(), st: s4.clone(), givens: givens.clone() }))
            } else {
                prism_rtl::Turn::Finished(s4.clone())
            }
        })
    }
}

/// `Start SolveWants, x`: what the function value is when passed to `@Run`.
pub fn start_solve_wants(g: G, st: crate::check::types::St, givens: Array<(Text, Text)>, final_: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SolveWants { g, st, givens, final_ })
}

/// ```prism
/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
/// ```
pub fn solve_rounds(g: &G, st0: &crate::check::types::St, givens: &Array<(Text, Text)>, round: &Nat) -> crate::check::types::St {
    let st = resolve_fields(g, &crate::check::types::retry_deferred(st0), &false);
    let cleared = {
        let mut this: crate::check::types::St = st.clone();
        this.wants = Array::new();
        this
    };
    let (keep, s2) = run_to_end(fold_job(st.wants.clone(), (Array::new(), cleared.clone()), {
        let g = g.clone();
        let givens = givens.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)| {
            let g = g.clone();
            let givens = givens.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let w = p1;
                call_then(start_solve_one(g.clone(), s.clone(), givens.clone(), w.clone()), move |solve_one_61901: (Array<crate::check::types::Want>, crate::check::types::St)| {
                    let (left, s3) = solve_one_61901;
                    prism_rtl::Turn::Finished((append(&acc, &left), s3.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>>>
    }));
    let s4 = {
        let mut this: crate::check::types::St = s2.clone();
        this.wants = append(&keep, &this.wants);
        this
    };
    if (&s4.wants == &st.wants) || (round > &Nat::from(6u32)) {
        s4.clone()
    } else {
        solve_rounds(g, &s4, givens, &(round + &Nat::from(1u32)))
    }
}

/// The step machine of `SolveRounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
/// ```
pub struct SolveRounds {
    pub g: G,
    pub st0: crate::check::types::St,
    pub givens: Array<(Text, Text)>,
    pub round: Nat,
}

impl prism_rtl::Job<crate::check::types::St> for SolveRounds {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st0 = &self.st0;
        let givens = &self.givens;
        let round = &self.round;
        let g = g.clone();
        let givens = givens.clone();
        let round = round.clone();
        let st0 = st0.clone();
        call_then(crate::check::types::start_retry_deferred(st0.clone()), move |retry_deferred_61720: crate::check::types::St| call_then(start_resolve_fields(g.clone(), retry_deferred_61720, false), move |resolve_fields_61702: crate::check::types::St| {
            let st = resolve_fields_61702;
            let cleared = {
                let mut this: crate::check::types::St = st.clone();
                this.wants = Array::new();
                this
            };
            call_value(fold_job(st.wants.clone(), (Array::new(), cleared.clone()), {
                let g = g.clone();
                let givens = givens.clone();
                Rc::new(move |(p0, p1): ((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)| {
                    let g = g.clone();
                    let givens = givens.clone();
                    entered(once_job(move || {
                        let (acc, s) = p0;
                        let w = p1;
                        call_then(start_solve_one(g.clone(), s.clone(), givens.clone(), w.clone()), move |solve_one_61901: (Array<crate::check::types::Want>, crate::check::types::St)| {
                            let (left, s3) = solve_one_61901;
                            prism_rtl::Turn::Finished((append(&acc, &left), s3.clone()))
                        })
                    }))
                }) as Rc<dyn Fn(((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>>>
            }), move |fold_61823: (Array<crate::check::types::Want>, crate::check::types::St)| {
                let (keep, s2) = fold_61823;
                let s4 = {
                    let mut this: crate::check::types::St = s2.clone();
                    this.wants = append(&keep, &this.wants);
                    this
                };
                if (&s4.wants == &st.wants) || (&round > &Nat::from(6u32)) {
                    prism_rtl::Turn::Finished(s4.clone())
                } else {
                    prism_rtl::Turn::More(Rc::new(SolveRounds { g: g.clone(), st0: s4.clone(), givens: givens.clone(), round: &round + &Nat::from(1u32) }))
                }
            })
        }))
    }
}

/// `Start SolveRounds, x`: what the function value is when passed to `@Run`.
pub fn start_solve_rounds(g: G, st0: crate::check::types::St, givens: Array<(Text, Text)>, round: Nat) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SolveRounds { g, st0, givens, round })
}

/// ```prism
/// ResolveFields: unbounded fn G, St, Bool -> St
/// ```
pub fn resolve_fields(g: &G, st: &crate::check::types::St, final_: &bool) -> crate::check::types::St {
    let qs = st.field_qs.clone();
    let cleared = {
        let mut this: crate::check::types::St = st.clone();
        this.field_qs = Array::new();
        this
    };
    let done = run_to_end(fold_job(qs.clone(), cleared.clone(), {
        let g = g.clone();
        let final_ = *final_;
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::FieldQ)| {
            let g = g.clone();
            let final_ = final_;
            entered(once_job(move || {
                let s = p0;
                let q = p1;
                prism_rtl::Turn::More(Rc::new(ResolveField { g: g.clone(), st: s.clone(), q: q.clone(), final_ }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::FieldQ)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    with_file(&done, &st.file)
}

/// The step machine of `ResolveFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveFields: unbounded fn G, St, Bool -> St
/// ```
pub struct ResolveFields {
    pub g: G,
    pub st: crate::check::types::St,
    pub final_: bool,
}

impl prism_rtl::Job<crate::check::types::St> for ResolveFields {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let final_ = &self.final_;
        let qs = st.field_qs.clone();
        let cleared = {
            let mut this: crate::check::types::St = st.clone();
            this.field_qs = Array::new();
            this
        };
        let final_ = *final_;
        let g = g.clone();
        let st = st.clone();
        call_value(fold_job(qs.clone(), cleared.clone(), {
            let g = g.clone();
            let final_ = final_;
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::FieldQ)| {
                let g = g.clone();
                let final_ = final_;
                entered(once_job(move || {
                    let s = p0;
                    let q = p1;
                    prism_rtl::Turn::More(Rc::new(ResolveField { g: g.clone(), st: s.clone(), q: q.clone(), final_ }))
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::FieldQ)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }), move |fold_62425: crate::check::types::St| {
            let done = fold_62425;
            prism_rtl::Turn::Finished(with_file(&done, &st.file))
        })
    }
}

/// `Start ResolveFields, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_fields(g: G, st: crate::check::types::St, final_: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ResolveFields { g, st, final_ })
}

/// ```prism
/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
/// ```
pub fn resolve_field(g: &G, st: &crate::check::types::St, q: &crate::check::types::FieldQ, final_: &bool) -> crate::check::types::St {
    let s = with_file(st, &q.file);
    match crate::check::types::walk(&s, &q.recv) {
        crate::check::types::Ty::TyCon(n, args) => match get(&g.ctors, &n) {
            Some(c) => {
                let i_opt = fold(&crate::check::errors::range0(&len(&c.fields)), &None, &(|at_opt: &Option<Nat>, k: &Nat| if &index(&c.fields, k) == &Some(q.field.clone()) {
                    Some(k.clone())
                } else {
                    at_opt.clone()
                }));
                match &i_opt {
                    Some(i) => crate::check::types::unify(&s, &q.result, &crate::check::types::subst_q(&param_inst(&c.params, &args), &or(&index(&c.args, i), &crate::check::types::Ty::TyErr)), &q.span),
                    None => crate::check::types::err(&s, &Text::lit("mismatch"), &q.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&n), &q.field))),
                }
            },
            None => crate::check::types::err(&s, &Text::lit("mismatch"), &q.span, &Text::from(format!("`{}` has no fields", &crate::check::types::bare_name(&n)))),
        },
        crate::check::types::Ty::TyFlex(_) => if *final_ {
            crate::check::types::err_fix(&s, &Text::lit("ambiguous"), &q.span, &Text::from(format!("nothing decides which record `.{}` reads: {} have it", &q.field, &crate::syntax::lexer::join(&each(&q.owners, &(|o: &Text| Text::from(format!("`{}`", o)))), &Text::lit(", ")))), &Text::lit("annotate the value's type, or name it from a signature"))
        } else {
            {
                let mut this: crate::check::types::St = s.clone();
                this.field_qs = push(&this.field_qs, q);
                this
            }
        },
        crate::check::types::Ty::TyErr => s.clone(),
        other => crate::check::types::err(&s, &Text::lit("mismatch"), &q.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::show_ty(&s, &other), &q.field))),
    }
}

/// The step machine of `ResolveField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
/// ```
pub struct ResolveField {
    pub g: G,
    pub st: crate::check::types::St,
    pub q: crate::check::types::FieldQ,
    pub final_: bool,
}

impl prism_rtl::Job<crate::check::types::St> for ResolveField {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let q = &self.q;
        let final_ = &self.final_;
        let s = with_file(st, &q.file);
        let final_ = *final_;
        let g = g.clone();
        let q = q.clone();
        call_then(crate::check::types::start_walk(s.clone(), q.recv.clone()), move |walk_62635: crate::check::types::Ty| match walk_62635 {
            crate::check::types::Ty::TyCon(n, args) => match get(&g.ctors, &n) {
                Some(c) => {
                    let i_opt = fold(&crate::check::errors::range0(&len(&c.fields)), &None, &(|at_opt: &Option<Nat>, k: &Nat| if &index(&c.fields, k) == &Some(q.field.clone()) {
                        Some(k.clone())
                    } else {
                        at_opt.clone()
                    }));
                    match &i_opt {
                        Some(i) => {
                            let i = i.clone();
                            call_then(crate::check::types::start_subst_q(param_inst(&c.params, &args), or(&index(&c.args, &i), &crate::check::types::Ty::TyErr)), move |subst_q_62893: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(crate::check::types::Unify { st: s.clone(), expected: q.result.clone(), found: subst_q_62893, span: q.span.clone() })))
                        },
                        None => prism_rtl::Turn::Finished(crate::check::types::err(&s, &Text::lit("mismatch"), &q.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&n), &q.field)))),
                    }
                },
                None => prism_rtl::Turn::Finished(crate::check::types::err(&s, &Text::lit("mismatch"), &q.span, &Text::from(format!("`{}` has no fields", &crate::check::types::bare_name(&n))))),
            },
            crate::check::types::Ty::TyFlex(_) => if final_ {
                prism_rtl::Turn::Finished(crate::check::types::err_fix(&s, &Text::lit("ambiguous"), &q.span, &Text::from(format!("nothing decides which record `.{}` reads: {} have it", &q.field, &crate::syntax::lexer::join(&each(&q.owners, &(|o: &Text| Text::from(format!("`{}`", o)))), &Text::lit(", ")))), &Text::lit("annotate the value's type, or name it from a signature")))
            } else {
                prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = s.clone();
                    this.field_qs = push(&this.field_qs, &q);
                    this
                })
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished(s.clone()),
            other => call_then(crate::check::types::start_show_ty(s.clone(), other.clone()), move |show_ty_63503: Text| prism_rtl::Turn::Finished(crate::check::types::err(&s, &Text::lit("mismatch"), &q.span, &Text::from(format!("`{}` has no field `{}`", &show_ty_63503, &q.field))))),
        })
    }
}

/// `Start ResolveField, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_field(g: G, st: crate::check::types::St, q: crate::check::types::FieldQ, final_: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ResolveField { g, st, q, final_ })
}

/// ```prism
/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
/// ```
pub fn solve_one(g: &G, st: &crate::check::types::St, givens: &Array<(Text, Text)>, w: &crate::check::types::Want) -> (Array<crate::check::types::Want>, crate::check::types::St) {
    let t = crate::check::types::walk(st, &w.ty);
    let s0 = {
        let mut this: crate::check::types::St = st.clone();
        this.file = w.file.clone();
        this
    };
    let restore_fn = {
        let st = st.clone();
        Rc::new(move |s: &crate::check::types::St| with_file(s, &st.file))
    };
    match &t {
        crate::check::types::Ty::TyFlex(_) => (Array::from(vec![w.clone()]), st.clone()),
        crate::check::types::Ty::TyErr => (Array::new(), st.clone()),
        crate::check::types::Ty::TyRigid(v_) => if (crate::syntax::lexer::has_prefix(&w.cls, &Text::lit("Range ")) || (&w.cls == &Text::lit("Prelude.Sub"))) || (&w.cls == &Text::lit("Prelude.Signed")) {
            (Array::new(), st.clone())
        } else {
            if run_to_end(fold_job(givens.clone(), false, {
                let v_ = v_.clone();
                let g = g.clone();
                let w = w.clone();
                Rc::new(move |(p0, p1): (bool, (Text, Text))| {
                    let v_ = v_.clone();
                    let g = g.clone();
                    let w = w.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let (gv, gc) = p1;
                        prism_rtl::Turn::Finished(seen || ((&gv == &v_) && crate::check::types::has_text(&super_closure(&g, &gc), &w.cls)))
                    }))
                }) as Rc<dyn Fn((bool, (Text, Text))) -> Rc<dyn prism_rtl::Job<bool>>>
            })) {
                (Array::new(), solved(st, w, &t, &Text::lit("given")))
            } else {
                (Array::new(), (&restore_fn)(&crate::check::types::err_fix(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w.cls), v_)), &Text::from(format!("add `where {}: ^{}` to the signature", v_, &crate::check::types::bare_name(&w.cls))))))
            }
        },
        crate::check::types::Ty::TySig(s, inner) => if ((s == &Text::lit("?")) || (s == &Text::lit("~"))) && crate::check::types::has_text(&Array::from(vec![Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")]), &crate::check::types::bare_name(&w.cls)) {
            (Array::from(vec![crate::check::types::Want { cls: w.cls.clone(), ty: (**inner).clone(), file: w.file.clone(), span: w.span.clone(), level: w.level.clone() }]), solved(st, w, &t, &Text::lit("parts")))
        } else {
            (Array::new(), (&restore_fn)(&crate::check::types::err_fix(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w.cls), &crate::check::types::show_ty(st, &t))), &Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first"))))
        },
        crate::check::types::Ty::TyAt(_, _) => (Array::new(), (&restore_fn)(&crate::check::types::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w.cls), &crate::check::types::show_ty(st, &t)))))),
        crate::check::types::Ty::TyFn(_, _, _) => (Array::new(), (&restore_fn)(&crate::check::types::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`: functions do not compare or print", &crate::check::types::bare_name(&w.cls), &crate::check::types::show_ty(st, &t)))))),
        _ => solve_at_head(g, st, &s0, &{
            let f = restore_fn.clone();
            Rc::new(move |a0: crate::check::types::St| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }, givens, w, &t),
    }
}

/// The step machine of `SolveOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
/// ```
pub struct SolveOne {
    pub g: G,
    pub st: crate::check::types::St,
    pub givens: Array<(Text, Text)>,
    pub w: crate::check::types::Want,
}

impl prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)> for SolveOne {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Want>, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let givens = &self.givens;
        let w = &self.w;
        let g = g.clone();
        let givens = givens.clone();
        let st = st.clone();
        let w = w.clone();
        call_then(crate::check::types::start_walk(st.clone(), w.ty.clone()), move |walk_63751: crate::check::types::Ty| {
            let t = walk_63751;
            let s0 = {
                let mut this: crate::check::types::St = st.clone();
                this.file = w.file.clone();
                this
            };
            let restore_fn = {
                let st = st.clone();
                Rc::new(move |s: &crate::check::types::St| with_file(s, &st.file))
            };
            match &t {
                crate::check::types::Ty::TyFlex(_) => prism_rtl::Turn::Finished((Array::from(vec![w.clone()]), st.clone())),
                crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished((Array::new(), st.clone())),
                crate::check::types::Ty::TyRigid(v_) => if (crate::syntax::lexer::has_prefix(&w.cls, &Text::lit("Range ")) || (&w.cls == &Text::lit("Prelude.Sub"))) || (&w.cls == &Text::lit("Prelude.Signed")) {
                    prism_rtl::Turn::Finished((Array::new(), st.clone()))
                } else {
                    {
                        let v_ = v_.clone();
                        call_value(fold_job(givens.clone(), false, {
                            let v_ = v_.clone();
                            let g = g.clone();
                            let w = w.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, Text))| {
                                let v_ = v_.clone();
                                let g = g.clone();
                                let w = w.clone();
                                entered(once_job(move || {
                                    let seen = p0;
                                    let (gv, gc) = p1;
                                    prism_rtl::Turn::Finished(seen || ((&gv == &v_) && crate::check::types::has_text(&super_closure(&g, &gc), &w.cls)))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, Text))) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |fold_64088: bool| if fold_64088 {
                            prism_rtl::Turn::Finished((Array::new(), solved(&st, &w, &t, &Text::lit("given"))))
                        } else {
                            prism_rtl::Turn::Finished((Array::new(), (&restore_fn)(&crate::check::types::err_fix(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w.cls), &v_)), &Text::from(format!("add `where {}: ^{}` to the signature", &v_, &crate::check::types::bare_name(&w.cls)))))))
                        })
                    }
                },
                crate::check::types::Ty::TySig(s, inner) => if ((s == &Text::lit("?")) || (s == &Text::lit("~"))) && crate::check::types::has_text(&Array::from(vec![Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")]), &crate::check::types::bare_name(&w.cls)) {
                    prism_rtl::Turn::Finished((Array::from(vec![crate::check::types::Want { cls: w.cls.clone(), ty: (**inner).clone(), file: w.file.clone(), span: w.span.clone(), level: w.level.clone() }]), solved(&st, &w, &t, &Text::lit("parts"))))
                } else {
                    call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_64715: Text| prism_rtl::Turn::Finished((Array::new(), (&restore_fn)(&crate::check::types::err_fix(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w.cls), &show_ty_64715)), &Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first"))))))
                },
                crate::check::types::Ty::TyAt(_, _) => call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_64937: Text| prism_rtl::Turn::Finished((Array::new(), (&restore_fn)(&crate::check::types::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w.cls), &show_ty_64937))))))),
                crate::check::types::Ty::TyFn(_, _, _) => call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_65075: Text| prism_rtl::Turn::Finished((Array::new(), (&restore_fn)(&crate::check::types::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`: functions do not compare or print", &crate::check::types::bare_name(&w.cls), &show_ty_65075))))))),
                _ => prism_rtl::Turn::More(Rc::new(SolveAtHead { g: g.clone(), st: st.clone(), s0: s0.clone(), restore_fn: {
                    let f = restore_fn.clone();
                    Rc::new(move |a0: crate::check::types::St| {
                        let f = f.clone();
                        once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                    }) as Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                }, givens: givens.clone(), w: w.clone(), t: t.clone() })),
            }
        })
    }
}

/// `Start SolveOne, x`: what the function value is when passed to `@Run`.
pub fn start_solve_one(g: G, st: crate::check::types::St, givens: Array<(Text, Text)>, w: crate::check::types::Want) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>> {
    Rc::new(SolveOne { g, st, givens, w })
}

/// ```prism
/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub fn solve_at_head(g: &G, st: &crate::check::types::St, s0: &crate::check::types::St, restore_fn: &Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens: &Array<(Text, Text)>, w: &crate::check::types::Want, t: &crate::check::types::Ty) -> (Array<crate::check::types::Want>, crate::check::types::St) {
    if crate::syntax::lexer::has_prefix(&w.cls, &Text::lit("Range ")) {
        (Array::new(), run_to_end(restore_fn(literal_range(s0, w, t))))
    } else {
        if (&w.cls == &Text::lit("Prelude.Sub")) || (&w.cls == &Text::lit("Prelude.Signed")) {
            (Array::new(), run_to_end(restore_fn(signed_at(s0, w, t))))
        } else {
            solve_class(g, st, s0, &restore_fn.clone(), givens, w, t)
        }
    }
}

/// The step machine of `SolveAtHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub struct SolveAtHead {
    pub g: G,
    pub st: crate::check::types::St,
    pub s0: crate::check::types::St,
    pub restore_fn: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>,
    pub givens: Array<(Text, Text)>,
    pub w: crate::check::types::Want,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)> for SolveAtHead {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Want>, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let s0 = &self.s0;
        let restore_fn = &self.restore_fn;
        let givens = &self.givens;
        let w = &self.w;
        let t = &self.t;
        if crate::syntax::lexer::has_prefix(&w.cls, &Text::lit("Range ")) {
            {
                let restore_fn = restore_fn.clone();
                let s0 = s0.clone();
                let t = t.clone();
                let w = w.clone();
                call_then(start_literal_range(s0.clone(), w.clone(), t.clone()), move |literal_range_65393: crate::check::types::St| call_value((&restore_fn)(literal_range_65393), move |restore_65384: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_65384))))
            }
        } else {
            if (&w.cls == &Text::lit("Prelude.Sub")) || (&w.cls == &Text::lit("Prelude.Signed")) {
                {
                    let restore_fn = restore_fn.clone();
                    let s0 = s0.clone();
                    let t = t.clone();
                    let w = w.clone();
                    call_then(start_signed_at(s0.clone(), w.clone(), t.clone()), move |signed_at_65501: crate::check::types::St| call_value((&restore_fn)(signed_at_65501), move |restore_65492: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_65492))))
                }
            } else {
                prism_rtl::Turn::More(Rc::new(SolveClass { g: g.clone(), st: st.clone(), s0: s0.clone(), restore_fn: restore_fn.clone(), givens: givens.clone(), w: w.clone(), t: t.clone() }))
            }
        }
    }
}

/// `Start SolveAtHead, x`: what the function value is when passed to `@Run`.
pub fn start_solve_at_head(g: G, st: crate::check::types::St, s0: crate::check::types::St, restore_fn: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens: Array<(Text, Text)>, w: crate::check::types::Want, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>> {
    Rc::new(SolveAtHead { g, st, s0, restore_fn, givens, w, t })
}

/// ```prism
/// LiteralRange: unbounded fn St, Want, Ty -> St
/// ```
pub fn literal_range(st: &crate::check::types::St, w: &crate::check::types::Want, t: &crate::check::types::Ty) -> crate::check::types::St {
    let lit = crate::syntax::lexer::drop_prefix(&w.cls, &Text::lit("Range "));
    let negative = crate::syntax::lexer::has_prefix(&lit, &Text::lit("-"));
    let digits = if negative { crate::syntax::lexer::after_first(&lit) } else { lit.clone() };
    let n_opt = parse_nat_opt(&digits);
    match t {
        crate::check::types::Ty::TyCon(m65899_0_0, m65899_0_1) if (m65899_0_0 == &Text::lit("Nat")) && (m65899_0_1.len() == 0) => if negative && (&digits != &Text::lit("0")) {
            crate::check::types::err(st, &Text::lit("literal-range"), &w.span, &Text::from(format!("`{}` does not fit `Nat`", &lit)))
        } else {
            st.clone()
        },
        crate::check::types::Ty::TyCon(m65899_1_0, m65899_1_1) if (m65899_1_0 == &Text::lit("U8")) && (m65899_1_1.len() == 0) => match &n_opt {
            Some(v_) => if negative || (v_ > &Nat::from(255u32)) {
                crate::check::types::err(st, &Text::lit("literal-range"), &w.span, &Text::from(format!("`{}` does not fit `U8`", &lit)))
            } else {
                st.clone()
            },
            None => st.clone(),
        },
        _ => st.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LiteralRange`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralRange: unbounded fn St, Want, Ty -> St
/// ```
pub struct LiteralRange {
    pub st: crate::check::types::St,
    pub w: crate::check::types::Want,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for LiteralRange {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let w = &self.w;
        let t = &self.t;
        let lit = crate::syntax::lexer::drop_prefix(&w.cls, &Text::lit("Range "));
        let negative = crate::syntax::lexer::has_prefix(&lit, &Text::lit("-"));
        let digits = if negative { crate::syntax::lexer::after_first(&lit) } else { lit.clone() };
        let n_opt = parse_nat_opt(&digits);
        match t {
            crate::check::types::Ty::TyCon(m65899_0_0, m65899_0_1) if (m65899_0_0 == &Text::lit("Nat")) && (m65899_0_1.len() == 0) => if negative && (&digits != &Text::lit("0")) {
                prism_rtl::Turn::Finished(crate::check::types::err(st, &Text::lit("literal-range"), &w.span, &Text::from(format!("`{}` does not fit `Nat`", &lit))))
            } else {
                prism_rtl::Turn::Finished(st.clone())
            },
            crate::check::types::Ty::TyCon(m65899_1_0, m65899_1_1) if (m65899_1_0 == &Text::lit("U8")) && (m65899_1_1.len() == 0) => match &n_opt {
                Some(v_) => if negative || (v_ > &Nat::from(255u32)) {
                    prism_rtl::Turn::Finished(crate::check::types::err(st, &Text::lit("literal-range"), &w.span, &Text::from(format!("`{}` does not fit `U8`", &lit))))
                } else {
                    prism_rtl::Turn::Finished(st.clone())
                },
                None => prism_rtl::Turn::Finished(st.clone()),
            },
            _ => prism_rtl::Turn::Finished(st.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LiteralRange, x`: what the function value is when passed to `@Run`.
pub fn start_literal_range(st: crate::check::types::St, w: crate::check::types::Want, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(LiteralRange { st, w, t })
}

/// ```prism
/// SignedAt: unbounded fn St, Want, Ty -> St
/// ```
pub fn signed_at(st: &crate::check::types::St, w: &crate::check::types::Want, t: &crate::check::types::Ty) -> crate::check::types::St {
    match t {
        crate::check::types::Ty::TyCon(m66370_0_0, m66370_0_1) if (m66370_0_0 == &Text::lit("Nat")) && (m66370_0_1.len() == 0) => if &w.cls == &Text::lit("Prelude.Sub") {
            crate::check::types::err_fix(st, &Text::lit("nat-minus"), &w.span, &Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), &Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`"))
        } else {
            st.clone()
        },
        crate::check::types::Ty::TyCon(m66370_1_0, m66370_1_1) if (m66370_1_0 == &Text::lit("U8")) && (m66370_1_1.len() == 0) => if &w.cls == &Text::lit("Prelude.Sub") { st.clone() } else { st.clone() },
        _ => st.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SignedAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SignedAt: unbounded fn St, Want, Ty -> St
/// ```
pub struct SignedAt {
    pub st: crate::check::types::St,
    pub w: crate::check::types::Want,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for SignedAt {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let w = &self.w;
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyCon(m66370_0_0, m66370_0_1) if (m66370_0_0 == &Text::lit("Nat")) && (m66370_0_1.len() == 0) => if &w.cls == &Text::lit("Prelude.Sub") {
                prism_rtl::Turn::Finished(crate::check::types::err_fix(st, &Text::lit("nat-minus"), &w.span, &Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), &Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`")))
            } else {
                prism_rtl::Turn::Finished(st.clone())
            },
            crate::check::types::Ty::TyCon(m66370_1_0, m66370_1_1) if (m66370_1_0 == &Text::lit("U8")) && (m66370_1_1.len() == 0) => if &w.cls == &Text::lit("Prelude.Sub") {
                prism_rtl::Turn::Finished(st.clone())
            } else {
                prism_rtl::Turn::Finished(st.clone())
            },
            _ => prism_rtl::Turn::Finished(st.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SignedAt, x`: what the function value is when passed to `@Run`.
pub fn start_signed_at(st: crate::check::types::St, w: crate::check::types::Want, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SignedAt { st, w, t })
}

/// ```prism
/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub fn solve_class(g: &G, st: &crate::check::types::St, s0: &crate::check::types::St, restore_fn: &Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens: &Array<(Text, Text)>, w: &crate::check::types::Want, t: &crate::check::types::Ty) -> (Array<crate::check::types::Want>, crate::check::types::St) {
    let bare = crate::check::types::bare_name(&w.cls);
    let parts_opt = match t {
        crate::check::types::Ty::TyTuple(ts) => Some(ts.clone()),
        crate::check::types::Ty::TyArray(e) => Some(Array::from(vec![(**e).clone()])),
        crate::check::types::Ty::TyMap(k, v_) => Some(Array::from(vec![(**k).clone(), (**v_).clone()])),
        _ => None,
    };
    let structural = ((&bare == &Text::lit("Eq")) || (&bare == &Text::lit("Ord"))) || (&bare == &Text::lit("Show"));
    match &parts_opt {
        Some(ps) => if structural {
            (each(ps, &(|p_: &crate::check::types::Ty| crate::check::types::Want { cls: w.cls.clone(), ty: p_.clone(), file: w.file.clone(), span: w.span.clone(), level: w.level.clone() })), solved(st, w, t, &Text::lit("parts")))
        } else {
            (Array::new(), run_to_end(restore_fn(crate::check::types::err(s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &crate::check::types::show_ty(st, t)))))))
        },
        None => match t {
            crate::check::types::Ty::TySig(_, _) => (Array::new(), st.clone()),
            crate::check::types::Ty::TyElem(_, _) => if (&bare == &Text::lit("Eq")) || (&bare == &Text::lit("Show")) {
                (Array::new(), solved(st, w, t, &Text::lit("builtin")))
            } else {
                (Array::new(), run_to_end(restore_fn(crate::check::types::err(s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &crate::check::types::show_ty(st, t)))))))
            },
            crate::check::types::Ty::TyElemAny(_) => if (&bare == &Text::lit("Eq")) || (&bare == &Text::lit("Show")) {
                (Array::new(), solved(st, w, t, &Text::lit("builtin")))
            } else {
                (Array::new(), run_to_end(restore_fn(crate::check::types::err(s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &crate::check::types::show_ty(st, t)))))))
            },
            crate::check::types::Ty::TyAny(trs) => if crate::check::types::has_text(trs, &w.cls) || run_to_end(fold_job(trs.clone(), false, {
                let g = g.clone();
                let w = w.clone();
                Rc::new(move |(p0, p1): (bool, Text)| {
                    let g = g.clone();
                    let w = w.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let tr = p1;
                        prism_rtl::Turn::Finished(seen || crate::check::types::has_text(&super_closure(&g, &tr), &w.cls))
                    }))
                }) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>
            })) {
                (Array::new(), solved(st, w, t, &Text::lit("packed")))
            } else {
                (Array::new(), run_to_end(restore_fn(crate::check::types::err(s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &crate::check::types::show_ty(st, t)))))))
            },
            crate::check::types::Ty::TyCon(con, args) => if builtin_has(&w.cls, con) {
                (Array::new(), solved(st, w, t, &Text::lit("builtin")))
            } else {
                match find_impl(g, st, &w.cls, t) {
                    Some((im, s2, how, ch)) => {
                        let wants = each(&im, &(|(ty, cls): &(crate::check::types::Ty, Text)| crate::check::types::Want { cls: cls.clone(), ty: ty.clone(), file: w.file.clone(), span: w.span.clone(), level: w.level.clone() }));
                        (wants.clone(), crate::check::types::note_choice(&solved(&s2, w, t, &how), &w.file, &w.span, &w.cls, &ch))
                    },
                    None => {
                        let fix = if (&bare == &Text::lit("Num")) && (con == &Text::lit("Text")) {
                            Text::lit("")
                        } else {
                            Text::from(format!("derive `^{}` on `{}`, or write `impl ^{} {}`", &bare, &crate::check::types::bare_name(con), &bare, &crate::check::types::bare_name(con)))
                        };
                        (Array::new(), run_to_end(restore_fn(crate::check::types::err_fix(s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &crate::check::types::show_ty(st, t))), &fix))))
                    },
                }
            },
            _ => (Array::new(), st.clone()),
        },
    }
}

/// The step machine of `SolveClass`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub struct SolveClass {
    pub g: G,
    pub st: crate::check::types::St,
    pub s0: crate::check::types::St,
    pub restore_fn: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>,
    pub givens: Array<(Text, Text)>,
    pub w: crate::check::types::Want,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)> for SolveClass {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Want>, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let s0 = &self.s0;
        let restore_fn = &self.restore_fn;
        let givens = &self.givens;
        let w = &self.w;
        let t = &self.t;
        let bare = crate::check::types::bare_name(&w.cls);
        let parts_opt = match t {
            crate::check::types::Ty::TyTuple(ts) => Some(ts.clone()),
            crate::check::types::Ty::TyArray(e) => Some(Array::from(vec![(**e).clone()])),
            crate::check::types::Ty::TyMap(k, v_) => Some(Array::from(vec![(**k).clone(), (**v_).clone()])),
            _ => None,
        };
        let structural = ((&bare == &Text::lit("Eq")) || (&bare == &Text::lit("Ord"))) || (&bare == &Text::lit("Show"));
        match &parts_opt {
            Some(ps) => if structural {
                prism_rtl::Turn::Finished((each(ps, &(|p_: &crate::check::types::Ty| crate::check::types::Want { cls: w.cls.clone(), ty: p_.clone(), file: w.file.clone(), span: w.span.clone(), level: w.level.clone() })), solved(st, w, t, &Text::lit("parts"))))
            } else {
                {
                    let restore_fn = restore_fn.clone();
                    let s0 = s0.clone();
                    let st = st.clone();
                    let t = t.clone();
                    let w = w.clone();
                    call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_67298: Text| call_value((&restore_fn)(crate::check::types::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &show_ty_67298)))), move |restore_67234: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_67234))))
                }
            },
            None => match t {
                crate::check::types::Ty::TySig(_, _) => prism_rtl::Turn::Finished((Array::new(), st.clone())),
                crate::check::types::Ty::TyElem(_, _) => if (&bare == &Text::lit("Eq")) || (&bare == &Text::lit("Show")) {
                    prism_rtl::Turn::Finished((Array::new(), solved(st, w, t, &Text::lit("builtin"))))
                } else {
                    {
                        let restore_fn = restore_fn.clone();
                        let s0 = s0.clone();
                        let st = st.clone();
                        let t = t.clone();
                        let w = w.clone();
                        call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_67573: Text| call_value((&restore_fn)(crate::check::types::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &show_ty_67573)))), move |restore_67509: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_67509))))
                    }
                },
                crate::check::types::Ty::TyElemAny(_) => if (&bare == &Text::lit("Eq")) || (&bare == &Text::lit("Show")) {
                    prism_rtl::Turn::Finished((Array::new(), solved(st, w, t, &Text::lit("builtin"))))
                } else {
                    {
                        let restore_fn = restore_fn.clone();
                        let s0 = s0.clone();
                        let st = st.clone();
                        let t = t.clone();
                        let w = w.clone();
                        call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_67774: Text| call_value((&restore_fn)(crate::check::types::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &show_ty_67774)))), move |restore_67710: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_67710))))
                    }
                },
                crate::check::types::Ty::TyAny(trs) => if crate::check::types::has_text(trs, &w.cls) || run_to_end(fold_job(trs.clone(), false, {
                    let g = g.clone();
                    let w = w.clone();
                    Rc::new(move |(p0, p1): (bool, Text)| {
                        let g = g.clone();
                        let w = w.clone();
                        entered(once_job(move || {
                            let seen = p0;
                            let tr = p1;
                            prism_rtl::Turn::Finished(seen || crate::check::types::has_text(&super_closure(&g, &tr), &w.cls))
                        }))
                    }) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>
                })) {
                    prism_rtl::Turn::Finished((Array::new(), solved(st, w, t, &Text::lit("packed"))))
                } else {
                    {
                        let restore_fn = restore_fn.clone();
                        let s0 = s0.clone();
                        let st = st.clone();
                        let t = t.clone();
                        let w = w.clone();
                        call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_68037: Text| call_value((&restore_fn)(crate::check::types::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &show_ty_68037)))), move |restore_67973: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_67973))))
                    }
                },
                crate::check::types::Ty::TyCon(con, args) => if builtin_has(&w.cls, con) {
                    prism_rtl::Turn::Finished((Array::new(), solved(st, w, t, &Text::lit("builtin"))))
                } else {
                    {
                        let restore_fn = restore_fn.clone();
                        let con = con.clone();
                        let g = g.clone();
                        let s0 = s0.clone();
                        let st = st.clone();
                        let t = t.clone();
                        let w = w.clone();
                        call_then(start_find_impl(g.clone(), st.clone(), w.cls.clone(), t.clone()), move |find_impl_68194: Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>| match find_impl_68194 {
                            Some((im, s2, how, ch)) => {
                                let wants = each(&im, &(|(ty, cls): &(crate::check::types::Ty, Text)| crate::check::types::Want { cls: cls.clone(), ty: ty.clone(), file: w.file.clone(), span: w.span.clone(), level: w.level.clone() }));
                                prism_rtl::Turn::Finished((wants.clone(), crate::check::types::note_choice(&solved(&s2, &w, &t, &how), &w.file, &w.span, &w.cls, &ch)))
                            },
                            None => {
                                let fix = if (&bare == &Text::lit("Num")) && (&con == &Text::lit("Text")) {
                                    Text::lit("")
                                } else {
                                    Text::from(format!("derive `^{}` on `{}`, or write `impl ^{} {}`", &bare, &crate::check::types::bare_name(&con), &bare, &crate::check::types::bare_name(&con)))
                                };
                                call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_68766: Text| call_value((&restore_fn)(crate::check::types::err_fix(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &show_ty_68766)), &fix)), move |restore_68699: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_68699))))
                            },
                        })
                    }
                },
                _ => prism_rtl::Turn::Finished((Array::new(), st.clone())),
            },
        }
    }
}

/// `Start SolveClass, x`: what the function value is when passed to `@Run`.
pub fn start_solve_class(g: G, st: crate::check::types::St, s0: crate::check::types::St, restore_fn: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens: Array<(Text, Text)>, w: crate::check::types::Want, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>> {
    Rc::new(SolveClass { g, st, s0, restore_fn, givens, w, t })
}

/// ```prism
/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
/// ```
pub fn find_impl(g: &G, st: &crate::check::types::St, cls: &Text, t: &crate::check::types::Ty) -> Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)> {
    run_to_end(fold_job(or(&get(&g.impls, cls), &Array::new()), None, {
        let st = st.clone();
        let t = t.clone();
        let g = g.clone();
        Rc::new(move |(p0, p1): (Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, ImplInfo)| {
            let st = st.clone();
            let t = t.clone();
            let g = g.clone();
            entered(once_job(move || {
                let found_opt = p0;
                let im = p1;
                match &found_opt {
                    Some(f) => prism_rtl::Turn::Finished(Some(f.clone())),
                    None => call_then(crate::check::types::start_zonk(st.clone(), t.clone()), move |zonk_69231: crate::check::types::Ty| match match_head(&im.head, &zonk_69231, &Map::new()) {
                        Some(m) => prism_rtl::Turn::Finished(Some((each(&im.bounds, &(|(v_, c): &(Text, Text)| (or(&get(&m, v_), &crate::check::types::Ty::TyErr), c.clone()))), st.clone(), impl_how(&g, &im), impl_choice(&im)))),
                        None => prism_rtl::Turn::Finished(None),
                    }),
                }
            }))
        }) as Rc<dyn Fn((Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, ImplInfo)) -> Rc<dyn prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>>>>
    }))
}

/// The step machine of `FindImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
/// ```
pub struct FindImpl {
    pub g: G,
    pub st: crate::check::types::St,
    pub cls: Text,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>> for FindImpl {
    fn cycle(&self) -> prism_rtl::Turn<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>> {
        let g = &self.g;
        let st = &self.st;
        let cls = &self.cls;
        let t = &self.t;
        fold_job(or(&get(&g.impls, cls), &Array::new()), None, {
            let st = st.clone();
            let t = t.clone();
            let g = g.clone();
            Rc::new(move |(p0, p1): (Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, ImplInfo)| {
                let st = st.clone();
                let t = t.clone();
                let g = g.clone();
                entered(once_job(move || {
                    let found_opt = p0;
                    let im = p1;
                    match &found_opt {
                        Some(f) => prism_rtl::Turn::Finished(Some(f.clone())),
                        None => call_then(crate::check::types::start_zonk(st.clone(), t.clone()), move |zonk_69231: crate::check::types::Ty| match match_head(&im.head, &zonk_69231, &Map::new()) {
                            Some(m) => prism_rtl::Turn::Finished(Some((each(&im.bounds, &(|(v_, c): &(Text, Text)| (or(&get(&m, v_), &crate::check::types::Ty::TyErr), c.clone()))), st.clone(), impl_how(&g, &im), impl_choice(&im)))),
                            None => prism_rtl::Turn::Finished(None),
                        }),
                    }
                }))
            }) as Rc<dyn Fn((Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, ImplInfo)) -> Rc<dyn prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>>>>
        }).cycle()
    }
}

/// `Start FindImpl, x`: what the function value is when passed to `@Run`.
pub fn start_find_impl(g: G, st: crate::check::types::St, cls: Text, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>>> {
    Rc::new(FindImpl { g, st, cls, t })
}

/// ```prism
/// ImplChoice: fn ImplInfo -> Text
/// ```
pub fn impl_choice(im: &ImplInfo) -> Text {
    match &im.head {
        crate::check::types::Ty::TyCon(n, _) => if im.derived {
            Text::from(format!("derived:{}", n))
        } else {
            Text::from(format!("impl:{}.{}", &im.file, &im.span.start))
        },
        _ => if im.derived {
            Text::lit("any")
        } else {
            Text::from(format!("impl:{}.{}", &im.file, &im.span.start))
        },
    }
}

/// ```prism
/// ImplHow: fn G, ImplInfo -> Text
/// ```
pub fn impl_how(g: &G, im: &ImplInfo) -> Text {
    let src = or(&index(&g.srcs, &im.file), &crate::check::errors::mk_src(&Text::lit("?"), &Text::lit("")));
    Text::from(format!("{} {}:{}", &(if im.derived { Text::lit("derived") } else { Text::lit("impl") }), &src.path_, &(&crate::check::errors::cline_of(&src.starts, &im.span.start) + &Nat::from(1u32))))
}

/// ```prism
/// Solved: fn St, Want, Ty, Text -> St
/// ```
pub fn solved(st: &crate::check::types::St, w: &crate::check::types::Want, t: &crate::check::types::Ty, how: &Text) -> crate::check::types::St {
    let s2 = crate::check::types::note_impl(st, &w.file, &w.span, &w.cls, t, how);
    if ((how == &Text::lit("given")) || (how == &Text::lit("packed"))) || (how == &Text::lit("quantified")) {
        crate::check::types::note_choice(&s2, &w.file, &w.span, &w.cls, &Text::lit("any"))
    } else {
        if (how == &Text::lit("builtin")) || (how == &Text::lit("parts")) {
            crate::check::types::note_choice(&s2, &w.file, &w.span, &w.cls, &Text::lit("none"))
        } else {
            s2.clone()
        }
    }
}

/// ```prism
/// ?MatchHead: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub fn match_head(pat: &crate::check::types::Ty, t: &crate::check::types::Ty, m: &Map<Text, crate::check::types::Ty>) -> Option<Map<Text, crate::check::types::Ty>> {
    match (pat.clone(), t.clone()) {
        (crate::check::types::Ty::TyQ(v_), x) => match get(m, &v_) {
            Some(y) => if &y == &x { Some(m.clone()) } else { None },
            None => Some(insert(m, &v_, &x)),
        },
        (crate::check::types::Ty::TyCon(a, xs), crate::check::types::Ty::TyCon(b, ys)) => if (&a == &b) && (&len(&xs) == &len(&ys)) { match_all(&xs, &ys, m) } else { None },
        (crate::check::types::Ty::TyTuple(xs), crate::check::types::Ty::TyTuple(ys)) => if &len(&xs) == &len(&ys) { match_all(&xs, &ys, m) } else { None },
        (crate::check::types::Ty::TyArray(x), crate::check::types::Ty::TyArray(y)) => match_head(&*x, &*y, m),
        (crate::check::types::Ty::TyMap(k1, v1), crate::check::types::Ty::TyMap(k2, v2)) => match_all(&Array::from(vec![(*k1).clone(), (*v1).clone()]), &Array::from(vec![(*k2).clone(), (*v2).clone()]), m),
        (crate::check::types::Ty::TySig(s1, i1), crate::check::types::Ty::TySig(s2, i2)) => if &s1 == &s2 { match_head(&*i1, &*i2, m) } else { None },
        _ => None,
    }
}

/// ```prism
/// ?MatchAll: unbounded fn [Ty], [Ty], (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub fn match_all(xs: &Array<crate::check::types::Ty>, ys: &Array<crate::check::types::Ty>, m: &Map<Text, crate::check::types::Ty>) -> Option<Map<Text, crate::check::types::Ty>> {
    run_to_end(fold_job(crate::check::errors::range0(&len(xs)), Some(m.clone()), {
        let xs = xs.clone();
        let ys = ys.clone();
        Rc::new(move |(p0, p1): (Option<Map<Text, crate::check::types::Ty>>, Nat)| {
            let xs = xs.clone();
            let ys = ys.clone();
            entered(once_job(move || {
                let acc_opt = p0;
                let i = p1;
                match &acc_opt {
                    Some(mm) => prism_rtl::Turn::Finished(match_head(&or(&index(&xs, &i), &crate::check::types::Ty::TyErr), &or(&index(&ys, &i), &crate::check::types::Ty::TyErr), mm)),
                    None => prism_rtl::Turn::Finished(None),
                }
            }))
        }) as Rc<dyn Fn((Option<Map<Text, crate::check::types::Ty>>, Nat)) -> Rc<dyn prism_rtl::Job<Option<Map<Text, crate::check::types::Ty>>>>>
    }))
}

/// ```prism
/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
/// ```
pub fn default_wants(g: &G, st: &crate::check::types::St, givens: &Array<(Text, Text)>) -> crate::check::types::St {
    let flex_vars = run_to_end(fold_job(st.wants.clone(), Array::new(), {
        let st = st.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Want)| {
            let st = st.clone();
            entered(once_job(move || {
                let acc = p0;
                let w = p1;
                call_then(crate::check::types::start_walk(st.clone(), w.ty.clone()), move |walk_71815: crate::check::types::Ty| match walk_71815 {
                    crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(crate::check::types::add_nat(&acc, &n)),
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                })
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    let s2 = run_to_end(fold_job(flex_vars.clone(), st.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| entered(once_job(move || {
        let s = p0;
        let v_ = p1;
        call_value(filter_job(s.wants.clone(), {
            let s = s.clone();
            let v_ = v_.clone();
            Rc::new(move |p0: crate::check::types::Want| {
                let s = s.clone();
                let v_ = v_.clone();
                entered(once_job(move || {
                    let w = p0;
                    call_then(crate::check::types::start_walk(s.clone(), w.ty.clone()), move |walk_71975: crate::check::types::Ty| prism_rtl::Turn::Finished(&walk_71975 == &crate::check::types::Ty::TyFlex(v_.clone())))
                }))
            }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |filter_71953: Array<crate::check::types::Want>| {
            let classes = each(&filter_71953, &(|w: &crate::check::types::Want| crate::check::types::bare_name(&w.cls)));
            let defaultable = crate::check::types::has_text(&classes, &Text::lit("Num")) && fold(&classes, &true, &(|ok: &bool, c: &Text| *ok && (crate::check::types::has_text(&Array::from(vec![Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")]), c) || crate::syntax::lexer::has_prefix(c, &Text::lit("Range ")))));
            if defaultable {
                prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = s.clone();
                    this.tys = insert(&this.tys, &v_, &crate::check::types::t_int());
                    this
                })
            } else {
                prism_rtl::Turn::Finished(s.clone())
            }
        })
    }))) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>));
    let s3 = solve_wants(g, &s2, givens, &false);
    let leftover = run_to_end(filter_job(s3.wants.clone(), {
        let s3 = s3.clone();
        Rc::new(move |p0: crate::check::types::Want| {
            let s3 = s3.clone();
            entered(once_job(move || {
                let w = p0;
                call_then(crate::check::types::start_is_flex_var(s3.clone(), w.ty.clone()), move |is_flex_var_72388: bool| prism_rtl::Turn::Finished(((is_flex_var_72388 && !crate::syntax::lexer::has_prefix(&w.cls, &Text::lit("Range "))) && (&w.cls != &Text::lit("Prelude.Sub"))) && (&w.cls != &Text::lit("Prelude.Signed"))))
            }))
        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let s4 = run_to_end(fold_job(leftover.clone(), s3.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Want)| entered(once_job(move || {
        let s = p0;
        let w = p1;
        {
            let s5 = {
                let mut this: crate::check::types::St = s.clone();
                this.file = w.file.clone();
                this
            };
            call_then(crate::check::types::start_show_ty(s.clone(), w.ty.clone()), move |show_ty_72659: Text| call_then(crate::check::types::start_show_ty(s.clone(), w.ty.clone()), move |show_ty_72699: Text| prism_rtl::Turn::Finished(crate::check::types::err_fix(&s5, &Text::lit("ambiguous"), &w.span, &Text::from(format!("nothing decides `{}` in `^{} {}`; annotate, or write a suffixed operator", &show_ty_72659, &crate::check::types::bare_name(&w.cls), &show_ty_72699)), &Text::lit("annotate the value's type")))))
        }
    }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>));
    let mut this: crate::check::types::St = s4.clone();
    this.wants = Array::new();
    this.file = st.file.clone();
    this
}

/// The step machine of `DefaultWants`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
/// ```
pub struct DefaultWants {
    pub g: G,
    pub st: crate::check::types::St,
    pub givens: Array<(Text, Text)>,
}

impl prism_rtl::Job<crate::check::types::St> for DefaultWants {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let givens = &self.givens;
        let g = g.clone();
        let givens = givens.clone();
        let st = st.clone();
        call_value(fold_job(st.wants.clone(), Array::new(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Want)| {
                let st = st.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let w = p1;
                    call_then(crate::check::types::start_walk(st.clone(), w.ty.clone()), move |walk_71815: crate::check::types::Ty| match walk_71815 {
                        crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(crate::check::types::add_nat(&acc, &n)),
                        _ => prism_rtl::Turn::Finished(acc.clone()),
                    })
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        }), move |fold_71778: Array<Nat>| {
            let flex_vars = fold_71778;
            call_value(fold_job(flex_vars.clone(), st.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| entered(once_job(move || {
                let s = p0;
                let v_ = p1;
                call_value(filter_job(s.wants.clone(), {
                    let s = s.clone();
                    let v_ = v_.clone();
                    Rc::new(move |p0: crate::check::types::Want| {
                        let s = s.clone();
                        let v_ = v_.clone();
                        entered(once_job(move || {
                            let w = p0;
                            call_then(crate::check::types::start_walk(s.clone(), w.ty.clone()), move |walk_71975: crate::check::types::Ty| prism_rtl::Turn::Finished(&walk_71975 == &crate::check::types::Ty::TyFlex(v_.clone())))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |filter_71953: Array<crate::check::types::Want>| {
                    let classes = each(&filter_71953, &(|w: &crate::check::types::Want| crate::check::types::bare_name(&w.cls)));
                    let defaultable = crate::check::types::has_text(&classes, &Text::lit("Num")) && fold(&classes, &true, &(|ok: &bool, c: &Text| *ok && (crate::check::types::has_text(&Array::from(vec![Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")]), c) || crate::syntax::lexer::has_prefix(c, &Text::lit("Range ")))));
                    if defaultable {
                        prism_rtl::Turn::Finished({
                            let mut this: crate::check::types::St = s.clone();
                            this.tys = insert(&this.tys, &v_, &crate::check::types::t_int());
                            this
                        })
                    } else {
                        prism_rtl::Turn::Finished(s.clone())
                    }
                })
            }))) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>), move |fold_71898: crate::check::types::St| {
                let s2 = fold_71898;
                call_then(start_solve_wants(g.clone(), s2.clone(), givens.clone(), false), move |solve_wants_72314: crate::check::types::St| {
                    let s3 = solve_wants_72314;
                    call_value(filter_job(s3.wants.clone(), {
                        let s3 = s3.clone();
                        Rc::new(move |p0: crate::check::types::Want| {
                            let s3 = s3.clone();
                            entered(once_job(move || {
                                let w = p0;
                                call_then(crate::check::types::start_is_flex_var(s3.clone(), w.ty.clone()), move |is_flex_var_72388: bool| prism_rtl::Turn::Finished(((is_flex_var_72388 && !crate::syntax::lexer::has_prefix(&w.cls, &Text::lit("Range "))) && (&w.cls != &Text::lit("Prelude.Sub"))) && (&w.cls != &Text::lit("Prelude.Signed"))))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |filter_72365: Array<crate::check::types::Want>| {
                        let leftover = filter_72365;
                        call_value(fold_job(leftover.clone(), s3.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Want)| entered(once_job(move || {
                            let s = p0;
                            let w = p1;
                            {
                                let s5 = {
                                    let mut this: crate::check::types::St = s.clone();
                                    this.file = w.file.clone();
                                    this
                                };
                                call_then(crate::check::types::start_show_ty(s.clone(), w.ty.clone()), move |show_ty_72659: Text| call_then(crate::check::types::start_show_ty(s.clone(), w.ty.clone()), move |show_ty_72699: Text| prism_rtl::Turn::Finished(crate::check::types::err_fix(&s5, &Text::lit("ambiguous"), &w.span, &Text::from(format!("nothing decides `{}` in `^{} {}`; annotate, or write a suffixed operator", &show_ty_72659, &crate::check::types::bare_name(&w.cls), &show_ty_72699)), &Text::lit("annotate the value's type")))))
                            }
                        }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>), move |fold_72516: crate::check::types::St| {
                            let s4 = fold_72516;
                            prism_rtl::Turn::Finished({
                                let mut this: crate::check::types::St = s4.clone();
                                this.wants = Array::new();
                                this.file = st.file.clone();
                                this
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start DefaultWants, x`: what the function value is when passed to `@Run`.
pub fn start_default_wants(g: G, st: crate::check::types::St, givens: Array<(Text, Text)>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DefaultWants { g, st, givens })
}
