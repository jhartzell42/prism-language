//! The module `Check.Env`, from `target/bootstrap/src/prismc/check/env/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod decls;
pub mod names;
pub mod reading;
pub mod traits;

/// `CtorInfo`:
///
/// ```prism
/// type CtorInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CtorInfo {
    pub name: Text,
    pub owner: Text,
    pub params: Array<Text>,
    pub args: Array<crate::check::types::Ty>,
    pub fields: Array<Text>,
    pub ty: crate::check::types::Ty,
    pub index: Nat,
}

impl Show for CtorInfo {
    fn show(&self, p: &mut Printer) {
        p.record("CtorInfo", &[("name", &self.name), ("owner", &self.owner), ("params", &self.params), ("args", &self.args), ("fields", &self.fields), ("ty", &self.ty), ("index", &self.index)]);
    }
}

impl ToPod for CtorInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("CtorInfo", vec![("name", self.name.to_pod()), ("owner", self.owner.to_pod()), ("params", self.params.to_pod()), ("args", self.args.to_pod()), ("fields", self.fields.to_pod()), ("ty", self.ty.to_pod()), ("index", self.index.to_pod())])
    }
}

impl FromPod for CtorInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CtorInfo { name: FromPod::from_pod(field(p, "name")?)?, owner: FromPod::from_pod(field(p, "owner")?)?, params: FromPod::from_pod(field(p, "params")?)?, args: FromPod::from_pod(field(p, "args")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, index: FromPod::from_pod(field(p, "index")?)? })
    }
}

/// `Def`:
///
/// ```prism
/// type Def = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Def {
    pub qk: Text,
    pub name: Text,
    pub home: Text,
    pub file: Nat,
    pub span: crate::syntax::Range,
    pub body: DefBody,
}

impl Show for Def {
    fn show(&self, p: &mut Printer) {
        p.record("Def", &[("qk", &self.qk), ("name", &self.name), ("home", &self.home), ("file", &self.file), ("span", &self.span), ("body", &self.body)]);
    }
}

impl ToPod for Def {
    fn to_pod(&self) -> Pod {
        Pod::record("Def", vec![("qk", self.qk.to_pod()), ("name", self.name.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod()), ("body", self.body.to_pod())])
    }
}

impl FromPod for Def {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Def { qk: FromPod::from_pod(field(p, "qk")?)?, name: FromPod::from_pod(field(p, "name")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)?, body: FromPod::from_pod(field(p, "body")?)? })
    }
}

/// `DefBody`:
///
/// ```prism
/// type DefBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum DefBody {
    DbFn(Array<crate::syntax::decls::FnClause>),
    DbLet(crate::syntax::decls::LetDecl),
    DbWidget(crate::syntax::decls::WidgetDecl),
    DbMethod(Array<crate::syntax::decls::FnClause>, Text, ImplInfo),
    DbDefault(Array<crate::syntax::decls::FnClause>, Text),
    DbCheck(crate::syntax::decls::CheckDecl),
    DbTest(crate::syntax::decls::TestDecl),
}

impl Show for DefBody {
    fn show(&self, p: &mut Printer) {
        match self {
            DefBody::DbFn(a0) => p.choice("DbFn", &[a0]),
            DefBody::DbLet(a0) => p.choice("DbLet", &[a0]),
            DefBody::DbWidget(a0) => p.choice("DbWidget", &[a0]),
            DefBody::DbMethod(a0, a1, a2) => p.choice("DbMethod", &[a0, a1, a2]),
            DefBody::DbDefault(a0, a1) => p.choice("DbDefault", &[a0, a1]),
            DefBody::DbCheck(a0) => p.choice("DbCheck", &[a0]),
            DefBody::DbTest(a0) => p.choice("DbTest", &[a0]),
        }
    }
}

impl ToPod for DefBody {
    fn to_pod(&self) -> Pod {
        match self {
            DefBody::DbFn(a0) => Pod::Choice("DbFn".into(), vec![a0.to_pod()]),
            DefBody::DbLet(a0) => Pod::Choice("DbLet".into(), vec![a0.to_pod()]),
            DefBody::DbWidget(a0) => Pod::Choice("DbWidget".into(), vec![a0.to_pod()]),
            DefBody::DbMethod(a0, a1, a2) => Pod::Choice("DbMethod".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            DefBody::DbDefault(a0, a1) => Pod::Choice("DbDefault".into(), vec![a0.to_pod(), a1.to_pod()]),
            DefBody::DbCheck(a0) => Pod::Choice("DbCheck".into(), vec![a0.to_pod()]),
            DefBody::DbTest(a0) => Pod::Choice("DbTest".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for DefBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DbFn" && a.len() == 1 => Ok(DefBody::DbFn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbLet" && a.len() == 1 => Ok(DefBody::DbLet(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbWidget" && a.len() == 1 => Ok(DefBody::DbWidget(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbMethod" && a.len() == 3 => Ok(DefBody::DbMethod(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "DbDefault" && a.len() == 2 => Ok(DefBody::DbDefault(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "DbCheck" && a.len() == 1 => Ok(DefBody::DbCheck(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbTest" && a.len() == 1 => Ok(DefBody::DbTest(FromPod::from_pod(&a[0])?)),
            other => mismatch("a DefBody", other),
        }
    }
}

/// `G`:
///
/// ```prism
/// type G = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct G {
    pub mods: Map<Text, ModInfo>,
    pub types: Map<Text, TyInfo>,
    pub ctors: Map<Text, CtorInfo>,
    pub tags: Map<Text, TagInfo>,
    pub families: Map<Text, Array<Text>>,
    pub fam_owner: Map<Text, Text>,
    pub vals: Map<Text, ValInfo>,
    pub traits: Map<Text, TraitInfo>,
    pub impls: Map<Text, Array<ImplInfo>>,
    pub bare: Map<Text, Map<Text, Array<Text>>>,
    pub bare_types: Map<Text, Map<Text, Array<Text>>>,
    pub bare_traits: Map<Text, Map<Text, Array<Text>>>,
    pub srcs: Array<crate::check::errors::Src>,
    pub defs: Array<Def>,
    pub program_row: crate::check::types::Rw,
    pub elem_fams: Array<Text>,
    pub root_module: Option<Text>,
    pub app_root: bool,
    pub fn_at: Map<Text, Nat>,
    pub prelude_from: Nat,
}

impl Show for G {
    fn show(&self, p: &mut Printer) {
        p.record("G", &[("mods", &self.mods), ("types", &self.types), ("ctors", &self.ctors), ("tags", &self.tags), ("families", &self.families), ("fam_owner", &self.fam_owner), ("vals", &self.vals), ("traits", &self.traits), ("impls", &self.impls), ("bare", &self.bare), ("bare_types", &self.bare_types), ("bare_traits", &self.bare_traits), ("srcs", &self.srcs), ("defs", &self.defs), ("program_row", &self.program_row), ("elem_fams", &self.elem_fams), ("root_module", &self.root_module), ("app_root", &self.app_root), ("fn_at", &self.fn_at), ("prelude_from", &self.prelude_from)]);
    }
}

impl ToPod for G {
    fn to_pod(&self) -> Pod {
        Pod::record("G", vec![("mods", self.mods.to_pod()), ("types", self.types.to_pod()), ("ctors", self.ctors.to_pod()), ("tags", self.tags.to_pod()), ("families", self.families.to_pod()), ("fam_owner", self.fam_owner.to_pod()), ("vals", self.vals.to_pod()), ("traits", self.traits.to_pod()), ("impls", self.impls.to_pod()), ("bare", self.bare.to_pod()), ("bare_types", self.bare_types.to_pod()), ("bare_traits", self.bare_traits.to_pod()), ("srcs", self.srcs.to_pod()), ("defs", self.defs.to_pod()), ("program_row", self.program_row.to_pod()), ("elem_fams", self.elem_fams.to_pod()), ("root_module", self.root_module.to_pod()), ("app_root", self.app_root.to_pod()), ("fn_at", self.fn_at.to_pod()), ("prelude_from", self.prelude_from.to_pod())])
    }
}

impl FromPod for G {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(G { mods: FromPod::from_pod(field(p, "mods")?)?, types: FromPod::from_pod(field(p, "types")?)?, ctors: FromPod::from_pod(field(p, "ctors")?)?, tags: FromPod::from_pod(field(p, "tags")?)?, families: FromPod::from_pod(field(p, "families")?)?, fam_owner: FromPod::from_pod(field(p, "fam_owner")?)?, vals: FromPod::from_pod(field(p, "vals")?)?, traits: FromPod::from_pod(field(p, "traits")?)?, impls: FromPod::from_pod(field(p, "impls")?)?, bare: FromPod::from_pod(field(p, "bare")?)?, bare_types: FromPod::from_pod(field(p, "bare_types")?)?, bare_traits: FromPod::from_pod(field(p, "bare_traits")?)?, srcs: FromPod::from_pod(field(p, "srcs")?)?, defs: FromPod::from_pod(field(p, "defs")?)?, program_row: FromPod::from_pod(field(p, "program_row")?)?, elem_fams: FromPod::from_pod(field(p, "elem_fams")?)?, root_module: FromPod::from_pod(field(p, "root_module")?)?, app_root: FromPod::from_pod(field(p, "app_root")?)?, fn_at: FromPod::from_pod(field(p, "fn_at")?)?, prelude_from: FromPod::from_pod(field(p, "prelude_from")?)? })
    }
}

/// `ImplInfo`:
///
/// ```prism
/// type ImplInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ImplInfo {
    pub cls: Text,
    pub head: crate::check::types::Ty,
    pub qs: Array<Text>,
    pub bounds: Array<(Text, Text)>,
    pub home: Text,
    pub file: Nat,
    pub span: crate::syntax::Range,
    pub derived: bool,
    pub assocs: Array<(Text, crate::check::types::Ty)>,
    pub methods: Array<Text>,
}

impl Show for ImplInfo {
    fn show(&self, p: &mut Printer) {
        p.record("ImplInfo", &[("cls", &self.cls), ("head", &self.head), ("qs", &self.qs), ("bounds", &self.bounds), ("home", &self.home), ("file", &self.file), ("span", &self.span), ("derived", &self.derived), ("assocs", &self.assocs), ("methods", &self.methods)]);
    }
}

impl ToPod for ImplInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("ImplInfo", vec![("cls", self.cls.to_pod()), ("head", self.head.to_pod()), ("qs", self.qs.to_pod()), ("bounds", self.bounds.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod()), ("derived", self.derived.to_pod()), ("assocs", self.assocs.to_pod()), ("methods", self.methods.to_pod())])
    }
}

impl FromPod for ImplInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ImplInfo { cls: FromPod::from_pod(field(p, "cls")?)?, head: FromPod::from_pod(field(p, "head")?)?, qs: FromPod::from_pod(field(p, "qs")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)?, derived: FromPod::from_pod(field(p, "derived")?)?, assocs: FromPod::from_pod(field(p, "assocs")?)?, methods: FromPod::from_pod(field(p, "methods")?)? })
    }
}

/// `ModInfo`:
///
/// ```prism
/// type ModInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ModInfo {
    pub name: Text,
    pub file: Nat,
    pub emit_rw: crate::check::types::Rw,
    pub row_var: Text,
    pub uses: Array<(Text, bool)>,
    pub root: bool,
    pub tree: crate::syntax::Module,
}

impl Show for ModInfo {
    fn show(&self, p: &mut Printer) {
        p.record("ModInfo", &[("name", &self.name), ("file", &self.file), ("emit_rw", &self.emit_rw), ("row_var", &self.row_var), ("uses", &self.uses), ("root", &self.root), ("tree", &self.tree)]);
    }
}

impl ToPod for ModInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("ModInfo", vec![("name", self.name.to_pod()), ("file", self.file.to_pod()), ("emit_rw", self.emit_rw.to_pod()), ("row_var", self.row_var.to_pod()), ("uses", self.uses.to_pod()), ("root", self.root.to_pod()), ("tree", self.tree.to_pod())])
    }
}

impl FromPod for ModInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ModInfo { name: FromPod::from_pod(field(p, "name")?)?, file: FromPod::from_pod(field(p, "file")?)?, emit_rw: FromPod::from_pod(field(p, "emit_rw")?)?, row_var: FromPod::from_pod(field(p, "row_var")?)?, uses: FromPod::from_pod(field(p, "uses")?)?, root: FromPod::from_pod(field(p, "root")?)?, tree: FromPod::from_pod(field(p, "tree")?)? })
    }
}

/// `TagInfo`:
///
/// ```prism
/// type TagInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TagInfo {
    pub name: Text,
    pub family: Text,
    pub kind: Text,
    pub out: crate::check::types::Ty,
    pub qs: Array<Text>,
    pub rqs: Array<Text>,
    pub bounds: Array<(Text, Text)>,
    pub fields: Array<(Text, crate::check::types::Ty)>,
    pub home: Text,
    pub file: Nat,
    pub span: crate::syntax::Range,
}

impl Show for TagInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TagInfo", &[("name", &self.name), ("family", &self.family), ("kind", &self.kind), ("out", &self.out), ("qs", &self.qs), ("rqs", &self.rqs), ("bounds", &self.bounds), ("fields", &self.fields), ("home", &self.home), ("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for TagInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TagInfo", vec![("name", self.name.to_pod()), ("family", self.family.to_pod()), ("kind", self.kind.to_pod()), ("out", self.out.to_pod()), ("qs", self.qs.to_pod()), ("rqs", self.rqs.to_pod()), ("bounds", self.bounds.to_pod()), ("fields", self.fields.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TagInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TagInfo { name: FromPod::from_pod(field(p, "name")?)?, family: FromPod::from_pod(field(p, "family")?)?, kind: FromPod::from_pod(field(p, "kind")?)?, out: FromPod::from_pod(field(p, "out")?)?, qs: FromPod::from_pod(field(p, "qs")?)?, rqs: FromPod::from_pod(field(p, "rqs")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TraitInfo`:
///
/// ```prism
/// type TraitInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TraitInfo {
    pub name: Text,
    pub home: Text,
    pub param: Text,
    pub supers: Array<Text>,
    pub methods: Array<Text>,
    pub defaults: Array<Text>,
    pub assocs: Array<Text>,
    pub file: Nat,
    pub span: crate::syntax::Range,
}

impl Show for TraitInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TraitInfo", &[("name", &self.name), ("home", &self.home), ("param", &self.param), ("supers", &self.supers), ("methods", &self.methods), ("defaults", &self.defaults), ("assocs", &self.assocs), ("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for TraitInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TraitInfo", vec![("name", self.name.to_pod()), ("home", self.home.to_pod()), ("param", self.param.to_pod()), ("supers", self.supers.to_pod()), ("methods", self.methods.to_pod()), ("defaults", self.defaults.to_pod()), ("assocs", self.assocs.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TraitInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TraitInfo { name: FromPod::from_pod(field(p, "name")?)?, home: FromPod::from_pod(field(p, "home")?)?, param: FromPod::from_pod(field(p, "param")?)?, supers: FromPod::from_pod(field(p, "supers")?)?, methods: FromPod::from_pod(field(p, "methods")?)?, defaults: FromPod::from_pod(field(p, "defaults")?)?, assocs: FromPod::from_pod(field(p, "assocs")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TyBody`:
///
/// ```prism
/// type TyBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TyBody {
    BRecord(Array<(Text, crate::check::types::Ty)>),
    BChoice(Array<(Text, Array<crate::check::types::Ty>)>),
    BRowKind,
    BAlias(crate::check::types::Ty),
    BOpaque,
    BPrim,
}

impl Show for TyBody {
    fn show(&self, p: &mut Printer) {
        match self {
            TyBody::BRecord(a0) => p.choice("BRecord", &[a0]),
            TyBody::BChoice(a0) => p.choice("BChoice", &[a0]),
            TyBody::BRowKind => p.choice("BRowKind", &[]),
            TyBody::BAlias(a0) => p.choice("BAlias", &[a0]),
            TyBody::BOpaque => p.choice("BOpaque", &[]),
            TyBody::BPrim => p.choice("BPrim", &[]),
        }
    }
}

impl ToPod for TyBody {
    fn to_pod(&self) -> Pod {
        match self {
            TyBody::BRecord(a0) => Pod::Choice("BRecord".into(), vec![a0.to_pod()]),
            TyBody::BChoice(a0) => Pod::Choice("BChoice".into(), vec![a0.to_pod()]),
            TyBody::BRowKind => Pod::Choice("BRowKind".into(), vec![]),
            TyBody::BAlias(a0) => Pod::Choice("BAlias".into(), vec![a0.to_pod()]),
            TyBody::BOpaque => Pod::Choice("BOpaque".into(), vec![]),
            TyBody::BPrim => Pod::Choice("BPrim".into(), vec![]),
        }
    }
}

impl FromPod for TyBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "BRecord" && a.len() == 1 => Ok(TyBody::BRecord(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BChoice" && a.len() == 1 => Ok(TyBody::BChoice(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BRowKind" && a.len() == 0 => Ok(TyBody::BRowKind),
            Pod::Choice(c, a) if &**c == "BAlias" && a.len() == 1 => Ok(TyBody::BAlias(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BOpaque" && a.len() == 0 => Ok(TyBody::BOpaque),
            Pod::Choice(c, a) if &**c == "BPrim" && a.len() == 0 => Ok(TyBody::BPrim),
            other => mismatch("a TyBody", other),
        }
    }
}

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyInfo {
    pub name: Text,
    pub home: Text,
    pub params: Array<Text>,
    pub body: TyBody,
    pub derives: Array<Text>,
    pub file: Nat,
    pub span: crate::syntax::Range,
}

impl Show for TyInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TyInfo", &[("name", &self.name), ("home", &self.home), ("params", &self.params), ("body", &self.body), ("derives", &self.derives), ("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for TyInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TyInfo", vec![("name", self.name.to_pod()), ("home", self.home.to_pod()), ("params", self.params.to_pod()), ("body", self.body.to_pod()), ("derives", self.derives.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TyInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyInfo { name: FromPod::from_pod(field(p, "name")?)?, home: FromPod::from_pod(field(p, "home")?)?, params: FromPod::from_pod(field(p, "params")?)?, body: FromPod::from_pod(field(p, "body")?)?, derives: FromPod::from_pod(field(p, "derives")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `ValInfo`:
///
/// ```prism
/// type ValInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ValInfo {
    pub qk: Text,
    pub scheme: crate::check::types::Scheme,
    pub sort: Text,
    pub has_sig: bool,
    pub home: Text,
    pub file: Nat,
    pub span: crate::syntax::Range,
}

impl Show for ValInfo {
    fn show(&self, p: &mut Printer) {
        p.record("ValInfo", &[("qk", &self.qk), ("scheme", &self.scheme), ("sort", &self.sort), ("has_sig", &self.has_sig), ("home", &self.home), ("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for ValInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("ValInfo", vec![("qk", self.qk.to_pod()), ("scheme", self.scheme.to_pod()), ("sort", self.sort.to_pod()), ("has_sig", self.has_sig.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for ValInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ValInfo { qk: FromPod::from_pod(field(p, "qk")?)?, scheme: FromPod::from_pod(field(p, "scheme")?)?, sort: FromPod::from_pod(field(p, "sort")?)?, has_sig: FromPod::from_pod(field(p, "has_sig")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// ```prism
/// IsPrimType: fn Text -> Bool
/// ```
pub fn is_prim_type(n: &Text) -> bool {
    crate::check::types::has_text(&Array::from(vec![Text::lit("Bool"), Text::lit("unit"), Text::lit("Char"), Text::lit("Text"), Text::lit("Nat"), Text::lit("Int"), Text::lit("U8"), Text::lit("Float"), Text::lit("Path"), Text::lit("Duration"), Text::lit("Cursor")]), n)
}

/// ```prism
/// QualKey: fn Text, Text -> Text
/// ```
pub fn qual_key(m: &Text, name: &Text) -> Text {
    if m == &Text::lit("") { name.clone() } else { Text::from(format!("{}.{}", m, name)) }
}

/// ```prism
/// Dotted: fn [Text] -> Text
/// ```
pub fn dotted(parts: &Array<Text>) -> Text {
    crate::syntax::lexer::chars::join(parts, &Text::lit("."))
}

/// ```prism
/// SNameKey: fn SName -> Text
/// ```
pub fn sname_key(n: &crate::syntax::SName) -> Text {
    Text::from(format!("{}{}", &n.sigils, &dotted(&n.path_)))
}

/// ```prism
/// DefNameText: fn DefName -> Text
/// ```
pub fn def_name_text(def_name0: &crate::syntax::decls::DefName) -> Text {
    match def_name0 {
        crate::syntax::decls::DefName::DefSName(n) => sname_key(n),
        crate::syntax::decls::DefName::DefOp(o, _) => o.clone(),
    }
}

/// ```prism
/// DefNameSpan: fn DefName -> Range
/// ```
pub fn def_name_span(def_name0: &crate::syntax::decls::DefName) -> crate::syntax::Range {
    match def_name0 {
        crate::syntax::decls::DefName::DefSName(n) => n.span.clone(),
        crate::syntax::decls::DefName::DefOp(_, r) => r.clone(),
    }
}

/// ```prism
/// IsLowerText: fn Text -> Bool
/// ```
pub fn is_lower_text(t: &Text) -> bool {
    crate::syntax::lexer::chars::is_lower(&crate::syntax::lexer::chars::head(t))
}

/// ```prism
/// IsUpperText: fn Text -> Bool
/// ```
pub fn is_upper_text(t: &Text) -> bool {
    crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::head(t))
}

/// ```prism
/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
/// ```
pub fn build_g(srcs: &Array<crate::check::errors::Src>, trees: &Array<crate::syntax::Module>) -> (G, crate::check::types::St) {
    let g0 = G { mods: Map::new(), types: Map::new(), ctors: Map::new(), tags: Map::new(), families: Map::new(), fam_owner: Map::new(), vals: Map::new(), traits: Map::new(), impls: Map::new(), bare: Map::new(), bare_types: Map::new(), bare_traits: Map::new(), srcs: srcs.clone(), defs: Array::new(), program_row: crate::check::types::empty_row(), elem_fams: Array::new(), root_module: None, app_root: app_root(srcs, trees), fn_at: Map::new(), prelude_from: len(trees) };
    let st0 = crate::check::types::new_st(&Nat::from(0u32));
    let (g1, st1) = fold(&crate::check::errors::range0(&len(trees)), &(g0.clone(), st0.clone()), &(|(g, st): &(G, crate::check::types::St), i: &Nat| add_module(g, st, i, &or(&index(trees, i), &empty_module()))));
    let g2 = add_builtins(&g1);
    let (g3, st3) = run_to_end(fold_job(keys(&g2.mods), (g2.clone(), st1.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
        let (g, st) = p0;
        let m = p1;
        prism_rtl::Turn::More(Rc::new(crate::check::env::names::CollectNames { g: g.clone(), st: st.clone(), m: m.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let g4 = {
        let mut this: G = g3.clone();
        this.program_row = crate::check::env::names::program_row(&this);
        this
    };
    let (g6, st6) = run_to_end(fold_job(keys(&g4.mods), (g4.clone(), st3.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
        let (g, st) = p0;
        let m = p1;
        prism_rtl::Turn::More(Rc::new(crate::check::env::names::BuildTables { g: g.clone(), st: st.clone(), m: m.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let (g6b, st6b) = run_to_end(fold_job(keys(&g6.mods), (g6.clone(), st6.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
        let (g, st) = p0;
        let m = p1;
        prism_rtl::Turn::More(Rc::new(crate::check::env::decls::ConvertTypes { g: g.clone(), st: st.clone(), m: m.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let (g7, st7) = run_to_end(fold_job(keys(&g6b.mods), (g6b.clone(), st6b.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
        let (g, st) = p0;
        let m = p1;
        prism_rtl::Turn::More(Rc::new(crate::check::env::decls::ConvertDecls { g: g.clone(), st: st.clone(), m: m.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let g8 = crate::check::env::traits::derived_impls(&g7);
    let st8 = crate::check::env::traits::coherence(&g8, &st7);
    (g8.clone(), st8.clone())
}

/// The step machine of `BuildG`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
/// ```
pub struct BuildG {
    pub srcs: Array<crate::check::errors::Src>,
    pub trees: Array<crate::syntax::Module>,
}

impl prism_rtl::Job<(G, crate::check::types::St)> for BuildG {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St)> {
        let srcs = &self.srcs;
        let trees = &self.trees;
        let g0 = G { mods: Map::new(), types: Map::new(), ctors: Map::new(), tags: Map::new(), families: Map::new(), fam_owner: Map::new(), vals: Map::new(), traits: Map::new(), impls: Map::new(), bare: Map::new(), bare_types: Map::new(), bare_traits: Map::new(), srcs: srcs.clone(), defs: Array::new(), program_row: crate::check::types::empty_row(), elem_fams: Array::new(), root_module: None, app_root: app_root(srcs, trees), fn_at: Map::new(), prelude_from: len(trees) };
        let st0 = crate::check::types::new_st(&Nat::from(0u32));
        let (g1, st1) = fold(&crate::check::errors::range0(&len(trees)), &(g0.clone(), st0.clone()), &(|(g, st): &(G, crate::check::types::St), i: &Nat| add_module(g, st, i, &or(&index(trees, i), &empty_module()))));
        let g2 = add_builtins(&g1);
        call_value(fold_job(keys(&g2.mods), (g2.clone(), st1.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
            let (g, st) = p0;
            let m = p1;
            prism_rtl::Turn::More(Rc::new(crate::check::env::names::CollectNames { g: g.clone(), st: st.clone(), m: m.clone() }))
        }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_5704: (G, crate::check::types::St)| {
            let (g3, st3) = fold_5704;
            let g4 = {
                let mut this: G = g3.clone();
                this.program_row = crate::check::env::names::program_row(&this);
                this
            };
            call_value(fold_job(keys(&g4.mods), (g4.clone(), st3.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
                let (g, st) = p0;
                let m = p1;
                prism_rtl::Turn::More(Rc::new(crate::check::env::names::BuildTables { g: g.clone(), st: st.clone(), m: m.clone() }))
            }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_5861: (G, crate::check::types::St)| {
                let (g6, st6) = fold_5861;
                call_value(fold_job(keys(&g6.mods), (g6.clone(), st6.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
                    let (g, st) = p0;
                    let m = p1;
                    prism_rtl::Turn::More(Rc::new(crate::check::env::decls::ConvertTypes { g: g.clone(), st: st.clone(), m: m.clone() }))
                }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_5956: (G, crate::check::types::St)| {
                    let (g6b, st6b) = fold_5956;
                    call_value(fold_job(keys(&g6b.mods), (g6b.clone(), st6b.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| entered(once_job(move || {
                        let (g, st) = p0;
                        let m = p1;
                        prism_rtl::Turn::More(Rc::new(crate::check::env::decls::ConvertDecls { g: g.clone(), st: st.clone(), m: m.clone() }))
                    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_6050: (G, crate::check::types::St)| {
                        let (g7, st7) = fold_6050;
                        let g8 = crate::check::env::traits::derived_impls(&g7);
                        call_then(crate::check::env::traits::start_coherence(g8.clone(), st7.clone()), move |coherence_6168: crate::check::types::St| {
                            let st8 = coherence_6168;
                            prism_rtl::Turn::Finished((g8.clone(), st8.clone()))
                        })
                    })
                })
            })
        })
    }
}

/// `Start BuildG, x`: what the function value is when passed to `@Run`.
pub fn start_build_g(srcs: Array<crate::check::errors::Src>, trees: Array<crate::syntax::Module>) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>> {
    Rc::new(BuildG { srcs, trees })
}

/// ```prism
/// let emptyModule
/// ```
pub fn empty_module() -> crate::syntax::Module {
    crate::syntax::Module { name: None, emit_row: None, mods: Array::new(), uses: Array::new(), decls: Array::new(), template: None, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// ModName: fn Module -> Text
/// ```
pub fn mod_name(m: &crate::syntax::Module) -> Text {
    match &m.name {
        Some(q) => dotted(&q.path_),
        None => Text::lit(""),
    }
}

/// ```prism
/// AppRoot: fn [Src], [Module] -> Bool
/// ```
pub fn app_root(srcs: &Array<crate::check::errors::Src>, trees: &Array<crate::syntax::Module>) -> bool {
    fold(&crate::check::errors::range0(&len(trees)), &false, &(|seen: &bool, i: &Nat| {
        let t = or(&index(trees, i), &empty_module());
        let name = mod_name(&t);
        if &name == &Text::lit("App") {
            false
        } else {
            if (&name == &Text::lit("")) && (&crate::check::errors::seg_at(&or(&index(srcs, i), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))), &Nat::from(0u32)).role != &Text::lit("loose")) {
                true
            } else {
                *seen
            }
        }
    }))
}

/// ```prism
/// UseName: fn G, Text -> Text
/// ```
pub fn use_name(g: &G, u: &Text) -> Text {
    if g.app_root && (u == &Text::lit("App")) { Text::lit("") } else { u.clone() }
}

/// ```prism
/// QualModule: fn G, [Text] -> Text
/// ```
pub fn qual_module(g: &G, parts: &Array<Text>) -> Text {
    use_name(g, &dotted(parts))
}

/// ```prism
/// AddModule: fn G, St, Nat, Module -> ((G, St))
/// ```
pub fn add_module(g: &G, st: &crate::check::types::St, i: &Nat, tree: &crate::syntax::Module) -> (G, crate::check::types::St) {
    let name = mod_name(tree);
    let s = {
        let mut this: crate::check::types::St = st.clone();
        this.file = i.clone();
        this
    };
    if has_key(&g.mods, &name) {
        {
            let what = if &name == &Text::lit("") {
                Text::lit("two files have no `module` line")
            } else {
                Text::from(format!("two files declare `module {}`", &name))
            };
            (g.clone(), crate::check::types::recording::err(&s, &Text::lit("collision"), &tree.span, &what))
        }
    } else {
        {
            let info = ModInfo { name: name.clone(), file: i.clone(), emit_rw: crate::check::types::empty_row(), row_var: Text::lit(""), uses: each(&tree.uses, &(|u: &crate::syntax::Use| (use_name(g, &dotted(&u.target.path_)), u.star))), root: &name == &Text::lit(""), tree: tree.clone() };
            let g2 = {
                let mut this: G = g.clone();
                this.mods = insert(&this.mods, &name, &info);
                if &name == &Text::lit("") {
                    this.root_module = Some(Text::lit(""));
                }
                this
            };
            (g2.clone(), s.clone())
        }
    }
}

/// ```prism
/// HasKey: fn (Text ==> a), Text -> Bool
/// ```
pub fn has_key<A: Clone + 'static>(m: &Map<Text, A>, k: &Text) -> bool {
    match get(m, k) {
        Some(_) => true,
        None => false,
    }
}

/// ```prism
/// AddBuiltins: fn G -> G
/// ```
pub fn add_builtins(g: &G) -> G {
    let bool_ctor_fn = Rc::new(move |n: &Text, i: &Nat| CtorInfo { name: n.clone(), owner: Text::lit("Bool"), params: Array::new(), args: Array::new(), fields: Array::new(), ty: crate::check::types::t_bool(), index: i.clone() });
    let pre = crate::check::types::Scheme { qs: Array::from(vec![Text::lit("a")]), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(crate::check::types::Ty::TyQ(Text::lit("a")))) };
    let numbered_ = crate::check::types::schemes::mono(&crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, Array::from(vec![crate::check::types::t_nat()]), Rc::new(crate::check::types::Ty::TyCon(Text::lit("Buffer"), Array::from(vec![crate::check::types::t_nat()])))));
    let buf_empty = crate::check::types::Scheme { qs: Array::from(vec![Text::lit("a")]), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: crate::check::types::Ty::TyCon(Text::lit("Buffer"), Array::from(vec![crate::check::types::Ty::TyQ(Text::lit("a"))])) };
    let tab_empty = crate::check::types::Scheme { qs: Array::from(vec![Text::lit("k"), Text::lit("v")]), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: crate::check::types::Ty::TyCon(Text::lit("Table"), Array::from(vec![crate::check::types::Ty::TyQ(Text::lit("k")), crate::check::types::Ty::TyQ(Text::lit("v"))])) };
    let mut this: G = g.clone();
    this.ctors = insert(&insert(&this.ctors, &Text::lit("True"), &(&bool_ctor_fn)(&Text::lit("True"), &Nat::from(0u32))), &Text::lit("False"), &(&bool_ctor_fn)(&Text::lit("False"), &Nat::from(1u32)));
    this.vals = insert(&this.vals, &Text::lit("Prelude.never"), &builtin(&Text::lit("Prelude.never"), &pre));
    this.vals = insert(&this.vals, &Text::lit("Buffer.Numbered"), &builtin(&Text::lit("Buffer.Numbered"), &numbered_));
    this.vals = insert(&this.vals, &Text::lit("Buffer.Empty"), &builtin(&Text::lit("Buffer.Empty"), &buf_empty));
    this.vals = insert(&this.vals, &Text::lit("Table.Empty"), &builtin(&Text::lit("Table.Empty"), &tab_empty));
    this
}

/// ```prism
/// Builtin: fn Text, Scheme -> ValInfo
/// ```
pub fn builtin(qk: &Text, sc: &crate::check::types::Scheme) -> ValInfo {
    ValInfo { qk: qk.clone(), scheme: sc.clone(), sort: Text::lit("builtin"), has_sig: true, home: Text::lit("Prelude"), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}
