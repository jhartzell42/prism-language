//! The module `Check.Env`, from `target/bootstrap/src/prismc/check/env/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod decls;
pub mod names;
pub mod reading;
pub mod traits;

/// `CtorInfo`:
///
/// ```prism
/// type CtorInfo = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct CtorInfo {
    pub name_p: crate::prelude::Text,
    pub owner_p: crate::prelude::Text,
    pub params_p: crate::prelude::Array<crate::prelude::Text>,
    pub args_p: crate::prelude::Array<crate::check::types::Ty>,
    pub fields_p: crate::prelude::Array<crate::prelude::Text>,
    pub ty_p: crate::check::types::Ty,
    pub index_p: crate::prelude::Nat,
}

impl crate::prelude::Show for CtorInfo {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("CtorInfo", &[("name", &self.name_p), ("owner", &self.owner_p), ("params", &self.params_p), ("args", &self.args_p), ("fields", &self.fields_p), ("ty", &self.ty_p), ("index", &self.index_p)]);
    }
}

impl crate::prelude::ToPod for CtorInfo {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("CtorInfo", vec![("name", self.name_p.to_pod()), ("owner", self.owner_p.to_pod()), ("params", self.params_p.to_pod()), ("args", self.args_p.to_pod()), ("fields", self.fields_p.to_pod()), ("ty", self.ty_p.to_pod()), ("index", self.index_p.to_pod())])
    }
}

impl crate::prelude::FromPod for CtorInfo {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(CtorInfo { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, owner_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "owner")?)?, params_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "params")?)?, args_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "args")?)?, fields_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fields")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)?, index_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "index")?)? })
    }
}

/// `Def`:
///
/// ```prism
/// type Def = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Def {
    pub qk_p: crate::prelude::Text,
    pub name_p: crate::prelude::Text,
    pub home_p: crate::prelude::Text,
    pub file_p: crate::prelude::Nat,
    pub span_p: crate::syntax::Range,
    pub body_p: DefBody,
}

impl crate::prelude::Show for Def {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Def", &[("qk", &self.qk_p), ("name", &self.name_p), ("home", &self.home_p), ("file", &self.file_p), ("span", &self.span_p), ("body", &self.body_p)]);
    }
}

impl crate::prelude::ToPod for Def {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Def", vec![("qk", self.qk_p.to_pod()), ("name", self.name_p.to_pod()), ("home", self.home_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod()), ("body", self.body_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Def {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Def { qk_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "qk")?)?, name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, home_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "home")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)?, body_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "body")?)? })
    }
}

/// `DefBody`:
///
/// ```prism
/// type DefBody = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum DefBody {
    DbFn(crate::prelude::Array<crate::syntax::decls::FnClause>),
    DbLet(crate::syntax::decls::LetDecl),
    DbWidget(crate::syntax::decls::WidgetDecl),
    DbMethod(crate::prelude::Array<crate::syntax::decls::FnClause>, crate::prelude::Text, ImplInfo),
    DbDefault(crate::prelude::Array<crate::syntax::decls::FnClause>, crate::prelude::Text),
    DbCheck(crate::syntax::decls::CheckDecl),
    DbTest(crate::syntax::decls::TestDecl),
}

impl crate::prelude::Show for DefBody {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            DefBody::DbFn(a0) => p.choice("DbFn", &[a0]),
            DefBody::DbLet(a0) => p.choice("DbLet", &[a0]),
            DefBody::DbWidget(a0) => p.choice("DbWidget", &[a0]),
            DefBody::DbMethod(a0, a1, a2) => p.choice("DbMethod", &[a0, a1, a2]),
            DefBody::DbDefault(a0, a1) => p.choice("DbDefault", &[a0, a1]),
            DefBody::DbCheck(a0) => p.choice("DbCheck", &[a0]),
            DefBody::DbTest(a0) => p.choice("DbTest", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for DefBody {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            DefBody::DbFn(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DbFn", 0), vec![a0.to_pod()]),
            DefBody::DbLet(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DbLet", 1), vec![a0.to_pod()]),
            DefBody::DbWidget(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DbWidget", 2), vec![a0.to_pod()]),
            DefBody::DbMethod(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DbMethod", 3), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            DefBody::DbDefault(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DbDefault", 4), vec![a0.to_pod(), a1.to_pod()]),
            DefBody::DbCheck(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DbCheck", 5), vec![a0.to_pod()]),
            DefBody::DbTest(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DbTest", 6), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for DefBody {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "DbFn" && a.len() == 1 => ::std::result::Result::Ok(DefBody::DbFn(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DbLet" && a.len() == 1 => ::std::result::Result::Ok(DefBody::DbLet(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DbWidget" && a.len() == 1 => ::std::result::Result::Ok(DefBody::DbWidget(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DbMethod" && a.len() == 3 => ::std::result::Result::Ok(DefBody::DbMethod(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DbDefault" && a.len() == 2 => ::std::result::Result::Ok(DefBody::DbDefault(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DbCheck" && a.len() == 1 => ::std::result::Result::Ok(DefBody::DbCheck(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DbTest" && a.len() == 1 => ::std::result::Result::Ok(DefBody::DbTest(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a DefBody", other),
        }
    }
}

/// `G`:
///
/// ```prism
/// type G = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct G {
    pub mods_p: crate::prelude::Map<crate::prelude::Text, ModInfo>,
    pub types_p: crate::prelude::Map<crate::prelude::Text, TyInfo>,
    pub ctors_p: crate::prelude::Map<crate::prelude::Text, CtorInfo>,
    pub tags_p: crate::prelude::Map<crate::prelude::Text, TagInfo>,
    pub families_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>,
    pub fam_owner_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>,
    pub vals_p: crate::prelude::Map<crate::prelude::Text, ValInfo>,
    pub traits_p: crate::prelude::Map<crate::prelude::Text, TraitInfo>,
    pub impls_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<ImplInfo>>,
    pub bare_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>,
    pub bare_types_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>,
    pub bare_traits_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>,
    pub assoc_names_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>,
    pub srcs_p: crate::prelude::Array<crate::check::errors::Src>,
    pub defs_p: crate::prelude::Array<Def>,
    pub program_row_p: crate::check::types::Rw,
    pub elem_fams_p: crate::prelude::Array<crate::prelude::Text>,
    pub root_module_o: ::std::option::Option<crate::prelude::Text>,
    pub app_root_p: bool,
    pub fn_at_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>,
    pub prelude_from_p: crate::prelude::Nat,
}

impl crate::prelude::Show for G {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("G", &[("mods", &self.mods_p), ("types", &self.types_p), ("ctors", &self.ctors_p), ("tags", &self.tags_p), ("families", &self.families_p), ("famOwner", &self.fam_owner_p), ("vals", &self.vals_p), ("traits", &self.traits_p), ("impls", &self.impls_p), ("bare", &self.bare_p), ("bareTypes", &self.bare_types_p), ("bareTraits", &self.bare_traits_p), ("assocNames", &self.assoc_names_p), ("srcs", &self.srcs_p), ("defs", &self.defs_p), ("programRow", &self.program_row_p), ("elemFams", &self.elem_fams_p), ("rootModule", &self.root_module_o), ("appRoot", &self.app_root_p), ("fnAt", &self.fn_at_p), ("preludeFrom", &self.prelude_from_p)]);
    }
}

impl crate::prelude::ToPod for G {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("G", vec![("mods", self.mods_p.to_pod()), ("types", self.types_p.to_pod()), ("ctors", self.ctors_p.to_pod()), ("tags", self.tags_p.to_pod()), ("families", self.families_p.to_pod()), ("famOwner", self.fam_owner_p.to_pod()), ("vals", self.vals_p.to_pod()), ("traits", self.traits_p.to_pod()), ("impls", self.impls_p.to_pod()), ("bare", self.bare_p.to_pod()), ("bareTypes", self.bare_types_p.to_pod()), ("bareTraits", self.bare_traits_p.to_pod()), ("assocNames", self.assoc_names_p.to_pod()), ("srcs", self.srcs_p.to_pod()), ("defs", self.defs_p.to_pod()), ("programRow", self.program_row_p.to_pod()), ("elemFams", self.elem_fams_p.to_pod()), ("rootModule", self.root_module_o.to_pod()), ("appRoot", self.app_root_p.to_pod()), ("fnAt", self.fn_at_p.to_pod()), ("preludeFrom", self.prelude_from_p.to_pod())])
    }
}

impl crate::prelude::FromPod for G {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(G { mods_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "mods")?)?, types_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "types")?)?, ctors_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ctors")?)?, tags_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tags")?)?, families_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "families")?)?, fam_owner_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "famOwner")?)?, vals_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "vals")?)?, traits_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "traits")?)?, impls_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "impls")?)?, bare_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "bare")?)?, bare_types_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "bareTypes")?)?, bare_traits_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "bareTraits")?)?, assoc_names_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "assocNames")?)?, srcs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "srcs")?)?, defs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "defs")?)?, program_row_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "programRow")?)?, elem_fams_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "elemFams")?)?, root_module_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rootModule")?)?, app_root_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "appRoot")?)?, fn_at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fnAt")?)?, prelude_from_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "preludeFrom")?)? })
    }
}

/// `ImplInfo`:
///
/// ```prism
/// type ImplInfo = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ImplInfo {
    pub cls_p: crate::prelude::Text,
    pub head_p: crate::check::types::Ty,
    pub qs_p: crate::prelude::Array<crate::prelude::Text>,
    pub bounds_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    pub home_p: crate::prelude::Text,
    pub file_p: crate::prelude::Nat,
    pub span_p: crate::syntax::Range,
    pub derived_p: bool,
    pub assocs_p: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>,
    pub methods_p: crate::prelude::Array<crate::prelude::Text>,
}

impl crate::prelude::Show for ImplInfo {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ImplInfo", &[("cls", &self.cls_p), ("head", &self.head_p), ("qs", &self.qs_p), ("bounds", &self.bounds_p), ("home", &self.home_p), ("file", &self.file_p), ("span", &self.span_p), ("derived", &self.derived_p), ("assocs", &self.assocs_p), ("methods", &self.methods_p)]);
    }
}

impl crate::prelude::ToPod for ImplInfo {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ImplInfo", vec![("cls", self.cls_p.to_pod()), ("head", self.head_p.to_pod()), ("qs", self.qs_p.to_pod()), ("bounds", self.bounds_p.to_pod()), ("home", self.home_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod()), ("derived", self.derived_p.to_pod()), ("assocs", self.assocs_p.to_pod()), ("methods", self.methods_p.to_pod())])
    }
}

impl crate::prelude::FromPod for ImplInfo {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ImplInfo { cls_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cls")?)?, head_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "head")?)?, qs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "qs")?)?, bounds_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "bounds")?)?, home_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "home")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)?, derived_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "derived")?)?, assocs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "assocs")?)?, methods_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "methods")?)? })
    }
}

/// `ModInfo`:
///
/// ```prism
/// type ModInfo = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ModInfo {
    pub name_p: crate::prelude::Text,
    pub file_p: crate::prelude::Nat,
    pub emit_rw_p: crate::check::types::Rw,
    pub row_var_p: crate::prelude::Text,
    pub uses_p: crate::prelude::Array<(crate::prelude::Text, bool)>,
    pub root_p: bool,
    pub tree_p: crate::syntax::Module,
}

impl crate::prelude::Show for ModInfo {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ModInfo", &[("name", &self.name_p), ("file", &self.file_p), ("emitRw", &self.emit_rw_p), ("rowVar", &self.row_var_p), ("uses", &self.uses_p), ("root", &self.root_p), ("tree", &self.tree_p)]);
    }
}

impl crate::prelude::ToPod for ModInfo {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ModInfo", vec![("name", self.name_p.to_pod()), ("file", self.file_p.to_pod()), ("emitRw", self.emit_rw_p.to_pod()), ("rowVar", self.row_var_p.to_pod()), ("uses", self.uses_p.to_pod()), ("root", self.root_p.to_pod()), ("tree", self.tree_p.to_pod())])
    }
}

impl crate::prelude::FromPod for ModInfo {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ModInfo { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, emit_rw_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "emitRw")?)?, row_var_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rowVar")?)?, uses_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "uses")?)?, root_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "root")?)?, tree_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tree")?)? })
    }
}

/// `TagInfo`:
///
/// ```prism
/// type TagInfo = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TagInfo {
    pub name_p: crate::prelude::Text,
    pub family_p: crate::prelude::Text,
    pub kind_p: crate::prelude::Text,
    pub out_p: crate::check::types::Ty,
    pub qs_p: crate::prelude::Array<crate::prelude::Text>,
    pub rqs_p: crate::prelude::Array<crate::prelude::Text>,
    pub bounds_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    pub fields_p: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>,
    pub field_at_p: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>,
    pub home_p: crate::prelude::Text,
    pub file_p: crate::prelude::Nat,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for TagInfo {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TagInfo", &[("name", &self.name_p), ("family", &self.family_p), ("kind", &self.kind_p), ("out", &self.out_p), ("qs", &self.qs_p), ("rqs", &self.rqs_p), ("bounds", &self.bounds_p), ("fields", &self.fields_p), ("fieldAt", &self.field_at_p), ("home", &self.home_p), ("file", &self.file_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for TagInfo {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TagInfo", vec![("name", self.name_p.to_pod()), ("family", self.family_p.to_pod()), ("kind", self.kind_p.to_pod()), ("out", self.out_p.to_pod()), ("qs", self.qs_p.to_pod()), ("rqs", self.rqs_p.to_pod()), ("bounds", self.bounds_p.to_pod()), ("fields", self.fields_p.to_pod()), ("fieldAt", self.field_at_p.to_pod()), ("home", self.home_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TagInfo {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TagInfo { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, family_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "family")?)?, kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)?, out_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "out")?)?, qs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "qs")?)?, rqs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rqs")?)?, bounds_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "bounds")?)?, fields_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fields")?)?, field_at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fieldAt")?)?, home_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "home")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `TraitInfo`:
///
/// ```prism
/// type TraitInfo = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TraitInfo {
    pub name_p: crate::prelude::Text,
    pub home_p: crate::prelude::Text,
    pub param_p: crate::prelude::Text,
    pub supers_p: crate::prelude::Array<crate::prelude::Text>,
    pub methods_p: crate::prelude::Array<crate::prelude::Text>,
    pub defaults_p: crate::prelude::Array<crate::prelude::Text>,
    pub assocs_p: crate::prelude::Array<crate::prelude::Text>,
    pub assoc_defaults_p: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>,
    pub file_p: crate::prelude::Nat,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for TraitInfo {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TraitInfo", &[("name", &self.name_p), ("home", &self.home_p), ("param", &self.param_p), ("supers", &self.supers_p), ("methods", &self.methods_p), ("defaults", &self.defaults_p), ("assocs", &self.assocs_p), ("assocDefaults", &self.assoc_defaults_p), ("file", &self.file_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for TraitInfo {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TraitInfo", vec![("name", self.name_p.to_pod()), ("home", self.home_p.to_pod()), ("param", self.param_p.to_pod()), ("supers", self.supers_p.to_pod()), ("methods", self.methods_p.to_pod()), ("defaults", self.defaults_p.to_pod()), ("assocs", self.assocs_p.to_pod()), ("assocDefaults", self.assoc_defaults_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TraitInfo {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TraitInfo { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, home_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "home")?)?, param_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "param")?)?, supers_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "supers")?)?, methods_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "methods")?)?, defaults_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "defaults")?)?, assocs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "assocs")?)?, assoc_defaults_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "assocDefaults")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `TyBody`:
///
/// ```prism
/// type TyBody = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum TyBody {
    BRecord(crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>),
    BChoice(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)>),
    BRowKind,
    BAlias(crate::check::types::Ty),
    BOpaque,
    BPrim,
}

impl crate::prelude::Show for TyBody {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            TyBody::BRecord(a0) => p.choice("BRecord", &[a0]),
            TyBody::BChoice(a0) => p.choice("BChoice", &[a0]),
            TyBody::BRowKind => p.choice("BRowKind", &[]),
            TyBody::BAlias(a0) => p.choice("BAlias", &[a0]),
            TyBody::BOpaque => p.choice("BOpaque", &[]),
            TyBody::BPrim => p.choice("BPrim", &[]),
        }
    }
}

impl crate::prelude::ToPod for TyBody {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            TyBody::BRecord(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("BRecord", 0), vec![a0.to_pod()]),
            TyBody::BChoice(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("BChoice", 1), vec![a0.to_pod()]),
            TyBody::BRowKind => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("BRowKind", 2), vec![]),
            TyBody::BAlias(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("BAlias", 3), vec![a0.to_pod()]),
            TyBody::BOpaque => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("BOpaque", 4), vec![]),
            TyBody::BPrim => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("BPrim", 5), vec![]),
        }
    }
}

impl crate::prelude::FromPod for TyBody {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "BRecord" && a.len() == 1 => ::std::result::Result::Ok(TyBody::BRecord(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "BChoice" && a.len() == 1 => ::std::result::Result::Ok(TyBody::BChoice(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "BRowKind" && a.len() == 0 => ::std::result::Result::Ok(TyBody::BRowKind),
            crate::prelude::Pod::Choice(c, a) if &**c == "BAlias" && a.len() == 1 => ::std::result::Result::Ok(TyBody::BAlias(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "BOpaque" && a.len() == 0 => ::std::result::Result::Ok(TyBody::BOpaque),
            crate::prelude::Pod::Choice(c, a) if &**c == "BPrim" && a.len() == 0 => ::std::result::Result::Ok(TyBody::BPrim),
            other => ::prism_rtl::pod::mismatch("a TyBody", other),
        }
    }
}

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TyInfo {
    pub name_p: crate::prelude::Text,
    pub home_p: crate::prelude::Text,
    pub params_p: crate::prelude::Array<crate::prelude::Text>,
    pub body_p: TyBody,
    pub derives_p: crate::prelude::Array<crate::prelude::Text>,
    pub file_p: crate::prelude::Nat,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for TyInfo {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TyInfo", &[("name", &self.name_p), ("home", &self.home_p), ("params", &self.params_p), ("body", &self.body_p), ("derives", &self.derives_p), ("file", &self.file_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for TyInfo {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TyInfo", vec![("name", self.name_p.to_pod()), ("home", self.home_p.to_pod()), ("params", self.params_p.to_pod()), ("body", self.body_p.to_pod()), ("derives", self.derives_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TyInfo {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TyInfo { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, home_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "home")?)?, params_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "params")?)?, body_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "body")?)?, derives_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "derives")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `ValInfo`:
///
/// ```prism
/// type ValInfo = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ValInfo {
    pub qk_p: crate::prelude::Text,
    pub scheme_p: crate::check::types::Scheme,
    pub sort_p: crate::prelude::Text,
    pub has_sig_p: bool,
    pub home_p: crate::prelude::Text,
    pub file_p: crate::prelude::Nat,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for ValInfo {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ValInfo", &[("qk", &self.qk_p), ("scheme", &self.scheme_p), ("sort", &self.sort_p), ("hasSig", &self.has_sig_p), ("home", &self.home_p), ("file", &self.file_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for ValInfo {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ValInfo", vec![("qk", self.qk_p.to_pod()), ("scheme", self.scheme_p.to_pod()), ("sort", self.sort_p.to_pod()), ("hasSig", self.has_sig_p.to_pod()), ("home", self.home_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for ValInfo {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ValInfo { qk_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "qk")?)?, scheme_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "scheme")?)?, sort_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "sort")?)?, has_sig_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "hasSig")?)?, home_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "home")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// ```prism
/// IsRegexType: fn Text -> Bool
/// ```
pub fn is_regex_type_f(n_p0: &crate::prelude::Text) -> bool {
    (n_p0 == &crate::prelude::Text::lit("Regex")) || (n_p0 == &crate::prelude::Text::lit("RegexReplacement"))
}

/// ```prism
/// IsPrimType: fn Text -> Bool
/// ```
pub fn is_prim_type_f(n_p0: &crate::prelude::Text) -> bool {
    crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("Bool"), crate::prelude::Text::lit("unit"), crate::prelude::Text::lit("Char"), crate::prelude::Text::lit("Text"), crate::prelude::Text::lit("Nat"), crate::prelude::Text::lit("Int"), crate::prelude::Text::lit("U8"), crate::prelude::Text::lit("Float"), crate::prelude::Text::lit("Path"), crate::prelude::Text::lit("Duration"), crate::prelude::Text::lit("Cursor"), crate::prelude::Text::lit("Regex"), crate::prelude::Text::lit("RegexReplacement")]), n_p0)
}

/// ```prism
/// QualKey: fn Text, Text -> Text
/// ```
pub fn qual_key_f(m_p0: &crate::prelude::Text, name_p1: &crate::prelude::Text) -> crate::prelude::Text {
    if m_p0 == &crate::prelude::Text::lit("") {
        name_p1.clone()
    } else {
        crate::prelude::Text::from(format!("{}.{}", m_p0, name_p1))
    }
}

/// ```prism
/// Dotted: fn [Text] -> Text
/// ```
pub fn dotted_f(parts_p0: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(parts_p0, &crate::prelude::Text::lit("."))
}

/// ```prism
/// SNameKey: fn SName -> Text
/// ```
pub fn sname_key_f(n_p0: &crate::syntax::SName) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{}{}", &n_p0.sigils_p, &dotted_f(&n_p0.path_p)))
}

/// ```prism
/// DefNameText: fn DefName -> Text
/// ```
pub fn def_name_text_f(def_name0: &crate::syntax::decls::DefName) -> crate::prelude::Text {
    match def_name0 {
        crate::syntax::decls::DefName::DefSName(n_p0) => sname_key_f(n_p0),
        crate::syntax::decls::DefName::DefOp(o_p1, _) => o_p1.clone(),
    }
}

/// ```prism
/// DefNameSpan: fn DefName -> Range
/// ```
pub fn def_name_span_f(def_name0: &crate::syntax::decls::DefName) -> crate::syntax::Range {
    match def_name0 {
        crate::syntax::decls::DefName::DefSName(n_p0) => n_p0.span_p.clone(),
        crate::syntax::decls::DefName::DefOp(_, r_p1) => r_p1.clone(),
    }
}

/// ```prism
/// IsLensName: fn SName -> Bool
/// ```
pub fn is_lens_name_f(n_p0: &crate::syntax::SName) -> bool {
    crate::syntax::lexer::chars::has_prefix_f(&n_p0.sigils_p, &crate::prelude::Text::lit("&")) && is_upper_text_f(&crate::prelude::or(&crate::syntax::lexer::chars::last_o(&n_p0.path_p), &crate::prelude::Text::lit("")))
}

/// ```prism
/// ?LensApplied: fn Expr -> ?((SName, Expr))
/// ```
pub fn lens_applied_o(e_p0: &crate::syntax::Expr) -> ::std::option::Option<(crate::syntax::SName, crate::syntax::Expr)> {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ECall(callee_p1, args_p2, _, _) => match &*callee_p1.kind_p {
            crate::syntax::ExprKind::EName(n_p3) => match crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(a_p4) => if is_lens_name_f(n_p3) && (&crate::prelude::len(args_p2) == &crate::prelude::Nat::from(1u32)) {
                    ::std::option::Option::Some((n_p3.clone(), a_p4.value_p.clone()))
                } else {
                    ::std::option::Option::None
                },
                ::std::option::Option::None => ::std::option::Option::None,
            },
            _ => ::std::option::Option::None,
        },
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// IsLowerText: fn Text -> Bool
/// ```
pub fn is_lower_text_f(t_p0: &crate::prelude::Text) -> bool {
    crate::syntax::lexer::chars::is_lower_f(&crate::syntax::lexer::chars::head_f(t_p0))
}

/// ```prism
/// IsUpperText: fn Text -> Bool
/// ```
pub fn is_upper_text_f(t_p0: &crate::prelude::Text) -> bool {
    crate::syntax::lexer::chars::is_upper_f(&crate::syntax::lexer::chars::head_f(t_p0))
}

/// ```prism
/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
/// ```
pub fn build_g_f(srcs_p0: &crate::prelude::Array<crate::check::errors::Src>, trees_p1: &crate::prelude::Array<crate::syntax::Module>) -> (G, crate::check::types::St) {
    let g0_p2 = G { mods_p: crate::prelude::Map::new(), types_p: crate::prelude::Map::new(), ctors_p: crate::prelude::Map::new(), tags_p: crate::prelude::Map::new(), families_p: crate::prelude::Map::new(), fam_owner_p: crate::prelude::Map::new(), vals_p: crate::prelude::Map::new(), traits_p: crate::prelude::Map::new(), impls_p: crate::prelude::Map::new(), bare_p: crate::prelude::Map::new(), bare_types_p: crate::prelude::Map::new(), bare_traits_p: crate::prelude::Map::new(), assoc_names_p: crate::prelude::Map::new(), srcs_p: srcs_p0.clone(), defs_p: crate::prelude::Array::new(), program_row_p: crate::check::types::empty_row_p(), elem_fams_p: crate::prelude::Array::new(), root_module_o: ::std::option::Option::None, app_root_p: app_root_f(srcs_p0, trees_p1), fn_at_p: crate::prelude::Map::new(), prelude_from_p: crate::prelude::len(trees_p1) };
    let st0_p3 = crate::check::types::new_st_f(&crate::prelude::Nat::from(0u32));
    let (g1_pc, st1_pd) = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(trees_p1)), &(g0_p2.clone(), st0_p3.clone()), &(|(g_p9, st_pa): &(G, crate::check::types::St), i_pb: &crate::prelude::Nat| add_module_f(g_p9, st_pa, i_pb, &crate::prelude::or(&crate::prelude::index(trees_p1, i_pb), &empty_module_p()))));
    let g2_p4 = add_builtins_f(&g1_pc);
    let (g3_ph, st3_pi) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g2_p4.mods_p), (g2_p4.clone(), st1_pd.clone()), ::std::rc::Rc::new(move |(p0, p1): ((G, crate::check::types::St), crate::prelude::Text)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (g_pe, st_pf) = p0;
        let m_pg = p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::names::CollectNames { g_p0: g_pe.clone(), st_p1: st_pf.clone(), m_p2: m_pg.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((G, crate::check::types::St), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(G, crate::check::types::St)>>>));
    let g4_p5 = {
        let mut this: G = g3_ph.clone();
        this.program_row_p = crate::check::env::names::program_row_f(&this);
        this
    };
    let (g6_pm, st6_pn) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g4_p5.mods_p), (g4_p5.clone(), st3_pi.clone()), ::std::rc::Rc::new(move |(p0, p1): ((G, crate::check::types::St), crate::prelude::Text)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (g_pj, st_pk) = p0;
        let m_pl = p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::names::BuildTables { g_p0: g_pj.clone(), st_p1: st_pk.clone(), m_p2: m_pl.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((G, crate::check::types::St), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(G, crate::check::types::St)>>>));
    let (g6a_po, st6a_pp) = crate::check::env::decls::convert_aliases_f(&g6_pm, &st6_pn);
    let (g6b_pt, st6b_pu) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g6a_po.mods_p), (g6a_po.clone(), st6a_pp.clone()), ::std::rc::Rc::new(move |(p0, p1): ((G, crate::check::types::St), crate::prelude::Text)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (g_pq, st_pr) = p0;
        let m_ps = p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::decls::ConvertTypes { g_p0: g_pq.clone(), st_p1: st_pr.clone(), m_p2: m_ps.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((G, crate::check::types::St), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(G, crate::check::types::St)>>>));
    let (g7_p12, st7_p13) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g6b_pt.mods_p), (g6b_pt.clone(), st6b_pu.clone()), ::std::rc::Rc::new(move |(p0, p1): ((G, crate::check::types::St), crate::prelude::Text)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (g_pv, st_p10) = p0;
        let m_p11 = p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::decls::ConvertDecls { g_p0: g_pv.clone(), st_p1: st_p10.clone(), m_p2: m_p11.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((G, crate::check::types::St), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(G, crate::check::types::St)>>>));
    let st7a_p6 = crate::check::env::traits::tag_variables_print_f(&g7_p12, &crate::check::env::traits::trait_cycles_f(&g7_p12, &st7_p13));
    let g8_p7 = crate::check::env::traits::derived_impls_f(&g7_p12);
    let st8_p8 = crate::check::env::traits::fault_fields_plain_f(&g8_p7, &crate::check::env::traits::tag_fields_print_f(&g8_p7, &crate::check::env::traits::coherence_f(&g8_p7, &crate::check::env::traits::derived_fields_f(&g8_p7, &crate::check::env::traits::derived_dynamics_f(&g8_p7, &st7a_p6)))));
    crate::check::env::decls::impl_defaults_f(&g8_p7, &st8_p8)
}

/// The step machine of `BuildG`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
/// ```
pub struct BuildG {
    pub srcs_p0: crate::prelude::Array<crate::check::errors::Src>,
    pub trees_p1: crate::prelude::Array<crate::syntax::Module>,
}

impl ::prism_rtl::Job<(G, crate::check::types::St)> for BuildG {
    fn cycle(&self) -> ::prism_rtl::Turn<(G, crate::check::types::St)> {
        let srcs_p0 = &self.srcs_p0;
        let trees_p1 = &self.trees_p1;
        let g0_p2 = G { mods_p: crate::prelude::Map::new(), types_p: crate::prelude::Map::new(), ctors_p: crate::prelude::Map::new(), tags_p: crate::prelude::Map::new(), families_p: crate::prelude::Map::new(), fam_owner_p: crate::prelude::Map::new(), vals_p: crate::prelude::Map::new(), traits_p: crate::prelude::Map::new(), impls_p: crate::prelude::Map::new(), bare_p: crate::prelude::Map::new(), bare_types_p: crate::prelude::Map::new(), bare_traits_p: crate::prelude::Map::new(), assoc_names_p: crate::prelude::Map::new(), srcs_p: srcs_p0.clone(), defs_p: crate::prelude::Array::new(), program_row_p: crate::check::types::empty_row_p(), elem_fams_p: crate::prelude::Array::new(), root_module_o: ::std::option::Option::None, app_root_p: app_root_f(srcs_p0, trees_p1), fn_at_p: crate::prelude::Map::new(), prelude_from_p: crate::prelude::len(trees_p1) };
        let st0_p3 = crate::check::types::new_st_f(&crate::prelude::Nat::from(0u32));
        let (g1_pc, st1_pd) = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(trees_p1)), &(g0_p2.clone(), st0_p3.clone()), &(|(g_p9, st_pa): &(G, crate::check::types::St), i_pb: &crate::prelude::Nat| add_module_f(g_p9, st_pa, i_pb, &crate::prelude::or(&crate::prelude::index(trees_p1, i_pb), &empty_module_p()))));
        let g2_p4 = add_builtins_f(&g1_pc);
        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(&g2_p4.mods_p), (g2_p4.clone(), st1_pd.clone()), ::std::rc::Rc::new(move |(p0, p1): ((G, crate::check::types::St), crate::prelude::Text)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (g_pe, st_pf) = p0;
            let m_pg = p1;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::names::CollectNames { g_p0: g_pe.clone(), st_p1: st_pf.clone(), m_p2: m_pg.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((G, crate::check::types::St), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_7095: (G, crate::check::types::St)| {
            let (g3_ph, st3_pi) = fold_7095;
            let g4_p5 = {
                let mut this: G = g3_ph.clone();
                this.program_row_p = crate::check::env::names::program_row_f(&this);
                this
            };
            crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(&g4_p5.mods_p), (g4_p5.clone(), st3_pi.clone()), ::std::rc::Rc::new(move |(p0, p1): ((G, crate::check::types::St), crate::prelude::Text)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (g_pj, st_pk) = p0;
                let m_pl = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::names::BuildTables { g_p0: g_pj.clone(), st_p1: st_pk.clone(), m_p2: m_pl.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((G, crate::check::types::St), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_7252: (G, crate::check::types::St)| {
                let (g6_pm, st6_pn) = fold_7252;
                crate::prelude::call_then(crate::check::env::decls::start_convert_aliases_f(g6_pm.clone(), st6_pn.clone()), move |convert_aliases_f_7347: (G, crate::check::types::St)| {
                    let (g6a_po, st6a_pp) = convert_aliases_f_7347;
                    crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(&g6a_po.mods_p), (g6a_po.clone(), st6a_pp.clone()), ::std::rc::Rc::new(move |(p0, p1): ((G, crate::check::types::St), crate::prelude::Text)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let (g_pq, st_pr) = p0;
                        let m_ps = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::decls::ConvertTypes { g_p0: g_pq.clone(), st_p1: st_pr.clone(), m_p2: m_ps.clone() }))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((G, crate::check::types::St), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_7394: (G, crate::check::types::St)| {
                        let (g6b_pt, st6b_pu) = fold_7394;
                        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(&g6b_pt.mods_p), (g6b_pt.clone(), st6b_pu.clone()), ::std::rc::Rc::new(move |(p0, p1): ((G, crate::check::types::St), crate::prelude::Text)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let (g_pv, st_p10) = p0;
                            let m_p11 = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::decls::ConvertDecls { g_p0: g_pv.clone(), st_p1: st_p10.clone(), m_p2: m_p11.clone() }))
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((G, crate::check::types::St), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_7491: (G, crate::check::types::St)| {
                            let (g7_p12, st7_p13) = fold_7491;
                            crate::prelude::call_then(crate::check::env::traits::start_trait_cycles_f(g7_p12.clone(), st7_p13.clone()), move |trait_cycles_f_7604: crate::check::types::St| crate::prelude::call_then(crate::check::env::traits::start_tag_variables_print_f(g7_p12.clone(), trait_cycles_f_7604), move |tag_variables_print_f_7581: crate::check::types::St| {
                                let st7a_p6 = tag_variables_print_f_7581;
                                let g8_p7 = crate::check::env::traits::derived_impls_f(&g7_p12);
                                crate::prelude::call_then(crate::check::env::traits::start_derived_fields_f(g8_p7.clone(), crate::check::env::traits::derived_dynamics_f(&g8_p7, &st7a_p6)), move |derived_fields_f_7725: crate::check::types::St| crate::prelude::call_then(crate::check::env::traits::start_coherence_f(g8_p7.clone(), derived_fields_f_7725), move |coherence_f_7710: crate::check::types::St| crate::prelude::call_then(crate::check::env::traits::start_tag_fields_print_f(g8_p7.clone(), coherence_f_7710), move |tag_fields_print_f_7690: crate::check::types::St| crate::prelude::call_then(crate::check::env::traits::start_fault_fields_plain_f(g8_p7.clone(), tag_fields_print_f_7690), move |fault_fields_plain_f_7668: crate::check::types::St| {
                                    let st8_p8 = fault_fields_plain_f_7668;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::decls::ImplDefaults { g_p0: g8_p7.clone(), st_p1: st8_p8.clone() }))
                                }))))
                            }))
                        })
                    })
                })
            })
        })
    }
}

/// `Start BuildG, x`: what the function value is when passed to `@Run`.
pub fn start_build_g_f(srcs_p0: crate::prelude::Array<crate::check::errors::Src>, trees_p1: crate::prelude::Array<crate::syntax::Module>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(G, crate::check::types::St)>> {
    ::std::rc::Rc::new(BuildG { srcs_p0, trees_p1 })
}

/// ```prism
/// let emptyModule
/// ```
pub fn empty_module_p() -> crate::syntax::Module {
    crate::syntax::Module { name_o: ::std::option::Option::None, emit_row_o: ::std::option::Option::None, mods_p: crate::prelude::Array::new(), uses_p: crate::prelude::Array::new(), decls_p: crate::prelude::Array::new(), template_o: ::std::option::Option::None, span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// ModName: fn Module -> Text
/// ```
pub fn mod_name_f(m_p0: &crate::syntax::Module) -> crate::prelude::Text {
    match &m_p0.name_o {
        ::std::option::Option::Some(q_p1) => dotted_f(&q_p1.path_p),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// AppRoot: fn [Src], [Module] -> Bool
/// ```
pub fn app_root_f(srcs_p0: &crate::prelude::Array<crate::check::errors::Src>, trees_p1: &crate::prelude::Array<crate::syntax::Module>) -> bool {
    crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(trees_p1)), &false, &(|seen_p2: &bool, i_p3: &crate::prelude::Nat| {
        let t_p4 = crate::prelude::or(&crate::prelude::index(trees_p1, i_p3), &empty_module_p());
        let name_p5 = mod_name_f(&t_p4);
        if &name_p5 == &crate::prelude::Text::lit("App") {
            false
        } else {
            if (&name_p5 == &crate::prelude::Text::lit("")) && (&crate::check::errors::seg_at_f(&crate::prelude::or(&crate::prelude::index(srcs_p0, i_p3), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::lit(""))), &crate::prelude::Nat::from(0u32)).role_p != &crate::prelude::Text::lit("loose")) {
                true
            } else {
                *seen_p2
            }
        }
    }))
}

/// ```prism
/// UseName: fn G, Text -> Text
/// ```
pub fn use_name_f(g_p0: &G, u_p1: &crate::prelude::Text) -> crate::prelude::Text {
    if g_p0.app_root_p && (u_p1 == &crate::prelude::Text::lit("App")) {
        crate::prelude::Text::lit("")
    } else {
        u_p1.clone()
    }
}

/// ```prism
/// QualModule: fn G, [Text] -> Text
/// ```
pub fn qual_module_f(g_p0: &G, parts_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    use_name_f(g_p0, &dotted_f(parts_p1))
}

/// ```prism
/// AddModule: fn G, St, Nat, Module -> ((G, St))
/// ```
pub fn add_module_f(g_p0: &G, st_p1: &crate::check::types::St, i_p2: &crate::prelude::Nat, tree_p3: &crate::syntax::Module) -> (G, crate::check::types::St) {
    let name_p4 = mod_name_f(tree_p3);
    let s_p5 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.file_p = i_p2.clone();
        this
    };
    if has_key_f(&g_p0.mods_p, &name_p4) {
        {
            let what_p6 = if &name_p4 == &crate::prelude::Text::lit("") {
                crate::prelude::Text::lit("two files have no `module` line")
            } else {
                crate::prelude::Text::from(format!("two files declare `module {}`", &name_p4))
            };
            (g_p0.clone(), crate::check::types::recording::err_f(&s_p5, &crate::prelude::Text::lit("collision"), &tree_p3.span_p, &what_p6))
        }
    } else {
        {
            let info_p7 = ModInfo { name_p: name_p4.clone(), file_p: i_p2.clone(), emit_rw_p: crate::check::types::empty_row_p(), row_var_p: crate::prelude::Text::lit(""), uses_p: crate::prelude::each(&tree_p3.uses_p, &(|u_p9: &crate::syntax::Use| (use_name_f(g_p0, &dotted_f(&u_p9.target_p.path_p)), u_p9.star_p))), root_p: &name_p4 == &crate::prelude::Text::lit(""), tree_p: tree_p3.clone() };
            let g2_p8 = {
                let mut this: G = g_p0.clone();
                this.mods_p = crate::prelude::insert(&this.mods_p, &name_p4, &info_p7);
                if &name_p4 == &crate::prelude::Text::lit("") {
                    this.root_module_o = ::std::option::Option::Some(crate::prelude::Text::lit(""));
                }
                this
            };
            (g2_p8.clone(), s_p5.clone())
        }
    }
}

/// ```prism
/// HasKey: fn (Text ==> a), Text -> Bool
/// ```
pub fn has_key_f<A: ::std::clone::Clone + 'static>(m_p0: &crate::prelude::Map<crate::prelude::Text, A>, k_p1: &crate::prelude::Text) -> bool {
    match crate::prelude::get(m_p0, k_p1) {
        ::std::option::Option::Some(_) => true,
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// AddBuiltins: fn G -> G
/// ```
pub fn add_builtins_f(g_p0: &G) -> G {
    let bool_ctor_f1 = ::std::rc::Rc::new(move |n_p6: &crate::prelude::Text, i_p7: &crate::prelude::Nat| CtorInfo { name_p: n_p6.clone(), owner_p: crate::prelude::Text::lit("Bool"), params_p: crate::prelude::Array::new(), args_p: crate::prelude::Array::new(), fields_p: crate::prelude::Array::new(), ty_p: crate::check::types::t_bool_p(), index_p: i_p7.clone() }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Text, &crate::prelude::Nat) -> CtorInfo>;
    let pre_p2 = crate::check::types::Scheme { qs_p: crate::prelude::Array::from(vec![crate::prelude::Text::lit("a")]), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(crate::check::types::Ty::TyQ(crate::prelude::Text::lit("a")))) };
    let numbered_p3 = crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, crate::prelude::Array::from(vec![crate::check::types::t_nat_p()]), ::std::rc::Rc::new(crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Buffer"), crate::prelude::Array::from(vec![crate::check::types::t_nat_p()])))));
    let buf_empty_p4 = crate::check::types::Scheme { qs_p: crate::prelude::Array::from(vec![crate::prelude::Text::lit("a")]), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Buffer"), crate::prelude::Array::from(vec![crate::check::types::Ty::TyQ(crate::prelude::Text::lit("a"))])) };
    let tab_empty_p5 = crate::check::types::Scheme { qs_p: crate::prelude::Array::from(vec![crate::prelude::Text::lit("k"), crate::prelude::Text::lit("v")]), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Table"), crate::prelude::Array::from(vec![crate::check::types::Ty::TyQ(crate::prelude::Text::lit("k")), crate::check::types::Ty::TyQ(crate::prelude::Text::lit("v"))])) };
    let mut this: G = g_p0.clone();
    this.ctors_p = crate::prelude::insert(&crate::prelude::insert(&this.ctors_p, &crate::prelude::Text::lit("True"), &(&bool_ctor_f1)(&crate::prelude::Text::lit("True"), &crate::prelude::Nat::from(0u32))), &crate::prelude::Text::lit("False"), &(&bool_ctor_f1)(&crate::prelude::Text::lit("False"), &crate::prelude::Nat::from(1u32)));
    this.vals_p = crate::prelude::insert(&this.vals_p, &crate::prelude::Text::lit("Prelude.never"), &builtin_f(&crate::prelude::Text::lit("Prelude.never"), &pre_p2));
    this.vals_p = crate::prelude::insert(&this.vals_p, &crate::prelude::Text::lit("Buffer.Numbered"), &builtin_f(&crate::prelude::Text::lit("Buffer.Numbered"), &numbered_p3));
    this.vals_p = crate::prelude::insert(&this.vals_p, &crate::prelude::Text::lit("Buffer.Empty"), &builtin_f(&crate::prelude::Text::lit("Buffer.Empty"), &buf_empty_p4));
    this.vals_p = crate::prelude::insert(&this.vals_p, &crate::prelude::Text::lit("Table.Empty"), &builtin_f(&crate::prelude::Text::lit("Table.Empty"), &tab_empty_p5));
    this
}

/// ```prism
/// Builtin: fn Text, Scheme -> ValInfo
/// ```
pub fn builtin_f(qk_p0: &crate::prelude::Text, sc_p1: &crate::check::types::Scheme) -> ValInfo {
    ValInfo { qk_p: qk_p0.clone(), scheme_p: sc_p1.clone(), sort_p: crate::prelude::Text::lit("builtin"), has_sig_p: true, home_p: crate::prelude::Text::lit("Prelude"), file_p: crate::prelude::Nat::from(0u32), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}
