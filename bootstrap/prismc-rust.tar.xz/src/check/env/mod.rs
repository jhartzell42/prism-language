//! The module `Check.Env`, from `target/bootstrap/src/prismc/check/env/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod decls;
pub mod names;
pub mod reading;
pub mod traits;

/// `CtorInfo`:
///
/// ```prism
/// type CtorInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CtorInfo {
    pub name_p: Text,
    pub owner_p: Text,
    pub params_p: Array<Text>,
    pub args_p: Array<crate::check::types::Ty>,
    pub fields_p: Array<Text>,
    pub ty_p: crate::check::types::Ty,
    pub index_p: Nat,
}

impl Show for CtorInfo {
    fn show(&self, p: &mut Printer) {
        p.record("CtorInfo", &[("name", &self.name_p), ("owner", &self.owner_p), ("params", &self.params_p), ("args", &self.args_p), ("fields", &self.fields_p), ("ty", &self.ty_p), ("index", &self.index_p)]);
    }
}

impl ToPod for CtorInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("CtorInfo", vec![("name", self.name_p.to_pod()), ("owner", self.owner_p.to_pod()), ("params", self.params_p.to_pod()), ("args", self.args_p.to_pod()), ("fields", self.fields_p.to_pod()), ("ty", self.ty_p.to_pod()), ("index", self.index_p.to_pod())])
    }
}

impl FromPod for CtorInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CtorInfo { name_p: FromPod::from_pod(field(p, "name")?)?, owner_p: FromPod::from_pod(field(p, "owner")?)?, params_p: FromPod::from_pod(field(p, "params")?)?, args_p: FromPod::from_pod(field(p, "args")?)?, fields_p: FromPod::from_pod(field(p, "fields")?)?, ty_p: FromPod::from_pod(field(p, "ty")?)?, index_p: FromPod::from_pod(field(p, "index")?)? })
    }
}

/// `Def`:
///
/// ```prism
/// type Def = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Def {
    pub qk_p: Text,
    pub name_p: Text,
    pub home_p: Text,
    pub file_p: Nat,
    pub span_p: crate::syntax::Range,
    pub body_p: DefBody,
}

impl Show for Def {
    fn show(&self, p: &mut Printer) {
        p.record("Def", &[("qk", &self.qk_p), ("name", &self.name_p), ("home", &self.home_p), ("file", &self.file_p), ("span", &self.span_p), ("body", &self.body_p)]);
    }
}

impl ToPod for Def {
    fn to_pod(&self) -> Pod {
        Pod::record("Def", vec![("qk", self.qk_p.to_pod()), ("name", self.name_p.to_pod()), ("home", self.home_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod()), ("body", self.body_p.to_pod())])
    }
}

impl FromPod for Def {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Def { qk_p: FromPod::from_pod(field(p, "qk")?)?, name_p: FromPod::from_pod(field(p, "name")?)?, home_p: FromPod::from_pod(field(p, "home")?)?, file_p: FromPod::from_pod(field(p, "file")?)?, span_p: FromPod::from_pod(field(p, "span")?)?, body_p: FromPod::from_pod(field(p, "body")?)? })
    }
}

/// `DefBody`:
///
/// ```prism
/// type DefBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum DefBody {
    DbFn(Array<crate::syntax::decls::FnClause>),
    DbLet(crate::syntax::decls::LetDecl),
    DbWidget(crate::syntax::decls::WidgetDecl),
    DbMethod(Array<crate::syntax::decls::FnClause>, Text, ImplInfo),
    DbDefault(Array<crate::syntax::decls::FnClause>, Text),
    DbCheck(crate::syntax::decls::CheckDecl),
    DbTest(crate::syntax::decls::TestDecl),
}

impl Show for DefBody {
    fn show(&self, p: &mut Printer) {
        match self {
            DefBody::DbFn(a0) => p.choice("DbFn", &[a0]),
            DefBody::DbLet(a0) => p.choice("DbLet", &[a0]),
            DefBody::DbWidget(a0) => p.choice("DbWidget", &[a0]),
            DefBody::DbMethod(a0, a1, a2) => p.choice("DbMethod", &[a0, a1, a2]),
            DefBody::DbDefault(a0, a1) => p.choice("DbDefault", &[a0, a1]),
            DefBody::DbCheck(a0) => p.choice("DbCheck", &[a0]),
            DefBody::DbTest(a0) => p.choice("DbTest", &[a0]),
        }
    }
}

impl ToPod for DefBody {
    fn to_pod(&self) -> Pod {
        match self {
            DefBody::DbFn(a0) => Pod::Choice("DbFn".into(), vec![a0.to_pod()]),
            DefBody::DbLet(a0) => Pod::Choice("DbLet".into(), vec![a0.to_pod()]),
            DefBody::DbWidget(a0) => Pod::Choice("DbWidget".into(), vec![a0.to_pod()]),
            DefBody::DbMethod(a0, a1, a2) => Pod::Choice("DbMethod".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            DefBody::DbDefault(a0, a1) => Pod::Choice("DbDefault".into(), vec![a0.to_pod(), a1.to_pod()]),
            DefBody::DbCheck(a0) => Pod::Choice("DbCheck".into(), vec![a0.to_pod()]),
            DefBody::DbTest(a0) => Pod::Choice("DbTest".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for DefBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DbFn" && a.len() == 1 => Ok(DefBody::DbFn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbLet" && a.len() == 1 => Ok(DefBody::DbLet(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbWidget" && a.len() == 1 => Ok(DefBody::DbWidget(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbMethod" && a.len() == 3 => Ok(DefBody::DbMethod(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "DbDefault" && a.len() == 2 => Ok(DefBody::DbDefault(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "DbCheck" && a.len() == 1 => Ok(DefBody::DbCheck(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DbTest" && a.len() == 1 => Ok(DefBody::DbTest(FromPod::from_pod(&a[0])?)),
            other => mismatch("a DefBody", other),
        }
    }
}

/// `G`:
///
/// ```prism
/// type G = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct G {
    pub mods_p: Map<Text, ModInfo>,
    pub types_p: Map<Text, TyInfo>,
    pub ctors_p: Map<Text, CtorInfo>,
    pub tags_p: Map<Text, TagInfo>,
    pub families_p: Map<Text, Array<Text>>,
    pub fam_owner_p: Map<Text, Text>,
    pub vals_p: Map<Text, ValInfo>,
    pub traits_p: Map<Text, TraitInfo>,
    pub impls_p: Map<Text, Array<ImplInfo>>,
    pub bare_p: Map<Text, Map<Text, Array<Text>>>,
    pub bare_types_p: Map<Text, Map<Text, Array<Text>>>,
    pub bare_traits_p: Map<Text, Map<Text, Array<Text>>>,
    pub srcs_p: Array<crate::check::errors::Src>,
    pub defs_p: Array<Def>,
    pub program_row_p: crate::check::types::Rw,
    pub elem_fams_p: Array<Text>,
    pub root_module_o: Option<Text>,
    pub app_root_p: bool,
    pub fn_at_p: Map<Text, Nat>,
    pub prelude_from_p: Nat,
}

impl Show for G {
    fn show(&self, p: &mut Printer) {
        p.record("G", &[("mods", &self.mods_p), ("types", &self.types_p), ("ctors", &self.ctors_p), ("tags", &self.tags_p), ("families", &self.families_p), ("famOwner", &self.fam_owner_p), ("vals", &self.vals_p), ("traits", &self.traits_p), ("impls", &self.impls_p), ("bare", &self.bare_p), ("bareTypes", &self.bare_types_p), ("bareTraits", &self.bare_traits_p), ("srcs", &self.srcs_p), ("defs", &self.defs_p), ("programRow", &self.program_row_p), ("elemFams", &self.elem_fams_p), ("rootModule", &self.root_module_o), ("appRoot", &self.app_root_p), ("fnAt", &self.fn_at_p), ("preludeFrom", &self.prelude_from_p)]);
    }
}

impl ToPod for G {
    fn to_pod(&self) -> Pod {
        Pod::record("G", vec![("mods", self.mods_p.to_pod()), ("types", self.types_p.to_pod()), ("ctors", self.ctors_p.to_pod()), ("tags", self.tags_p.to_pod()), ("families", self.families_p.to_pod()), ("famOwner", self.fam_owner_p.to_pod()), ("vals", self.vals_p.to_pod()), ("traits", self.traits_p.to_pod()), ("impls", self.impls_p.to_pod()), ("bare", self.bare_p.to_pod()), ("bareTypes", self.bare_types_p.to_pod()), ("bareTraits", self.bare_traits_p.to_pod()), ("srcs", self.srcs_p.to_pod()), ("defs", self.defs_p.to_pod()), ("programRow", self.program_row_p.to_pod()), ("elemFams", self.elem_fams_p.to_pod()), ("rootModule", self.root_module_o.to_pod()), ("appRoot", self.app_root_p.to_pod()), ("fnAt", self.fn_at_p.to_pod()), ("preludeFrom", self.prelude_from_p.to_pod())])
    }
}

impl FromPod for G {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(G { mods_p: FromPod::from_pod(field(p, "mods")?)?, types_p: FromPod::from_pod(field(p, "types")?)?, ctors_p: FromPod::from_pod(field(p, "ctors")?)?, tags_p: FromPod::from_pod(field(p, "tags")?)?, families_p: FromPod::from_pod(field(p, "families")?)?, fam_owner_p: FromPod::from_pod(field(p, "famOwner")?)?, vals_p: FromPod::from_pod(field(p, "vals")?)?, traits_p: FromPod::from_pod(field(p, "traits")?)?, impls_p: FromPod::from_pod(field(p, "impls")?)?, bare_p: FromPod::from_pod(field(p, "bare")?)?, bare_types_p: FromPod::from_pod(field(p, "bareTypes")?)?, bare_traits_p: FromPod::from_pod(field(p, "bareTraits")?)?, srcs_p: FromPod::from_pod(field(p, "srcs")?)?, defs_p: FromPod::from_pod(field(p, "defs")?)?, program_row_p: FromPod::from_pod(field(p, "programRow")?)?, elem_fams_p: FromPod::from_pod(field(p, "elemFams")?)?, root_module_o: FromPod::from_pod(field(p, "rootModule")?)?, app_root_p: FromPod::from_pod(field(p, "appRoot")?)?, fn_at_p: FromPod::from_pod(field(p, "fnAt")?)?, prelude_from_p: FromPod::from_pod(field(p, "preludeFrom")?)? })
    }
}

/// `ImplInfo`:
///
/// ```prism
/// type ImplInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ImplInfo {
    pub cls_p: Text,
    pub head_p: crate::check::types::Ty,
    pub qs_p: Array<Text>,
    pub bounds_p: Array<(Text, Text)>,
    pub home_p: Text,
    pub file_p: Nat,
    pub span_p: crate::syntax::Range,
    pub derived_p: bool,
    pub assocs_p: Array<(Text, crate::check::types::Ty)>,
    pub methods_p: Array<Text>,
}

impl Show for ImplInfo {
    fn show(&self, p: &mut Printer) {
        p.record("ImplInfo", &[("cls", &self.cls_p), ("head", &self.head_p), ("qs", &self.qs_p), ("bounds", &self.bounds_p), ("home", &self.home_p), ("file", &self.file_p), ("span", &self.span_p), ("derived", &self.derived_p), ("assocs", &self.assocs_p), ("methods", &self.methods_p)]);
    }
}

impl ToPod for ImplInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("ImplInfo", vec![("cls", self.cls_p.to_pod()), ("head", self.head_p.to_pod()), ("qs", self.qs_p.to_pod()), ("bounds", self.bounds_p.to_pod()), ("home", self.home_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod()), ("derived", self.derived_p.to_pod()), ("assocs", self.assocs_p.to_pod()), ("methods", self.methods_p.to_pod())])
    }
}

impl FromPod for ImplInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ImplInfo { cls_p: FromPod::from_pod(field(p, "cls")?)?, head_p: FromPod::from_pod(field(p, "head")?)?, qs_p: FromPod::from_pod(field(p, "qs")?)?, bounds_p: FromPod::from_pod(field(p, "bounds")?)?, home_p: FromPod::from_pod(field(p, "home")?)?, file_p: FromPod::from_pod(field(p, "file")?)?, span_p: FromPod::from_pod(field(p, "span")?)?, derived_p: FromPod::from_pod(field(p, "derived")?)?, assocs_p: FromPod::from_pod(field(p, "assocs")?)?, methods_p: FromPod::from_pod(field(p, "methods")?)? })
    }
}

/// `ModInfo`:
///
/// ```prism
/// type ModInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ModInfo {
    pub name_p: Text,
    pub file_p: Nat,
    pub emit_rw_p: crate::check::types::Rw,
    pub row_var_p: Text,
    pub uses_p: Array<(Text, bool)>,
    pub root_p: bool,
    pub tree_p: crate::syntax::Module,
}

impl Show for ModInfo {
    fn show(&self, p: &mut Printer) {
        p.record("ModInfo", &[("name", &self.name_p), ("file", &self.file_p), ("emitRw", &self.emit_rw_p), ("rowVar", &self.row_var_p), ("uses", &self.uses_p), ("root", &self.root_p), ("tree", &self.tree_p)]);
    }
}

impl ToPod for ModInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("ModInfo", vec![("name", self.name_p.to_pod()), ("file", self.file_p.to_pod()), ("emitRw", self.emit_rw_p.to_pod()), ("rowVar", self.row_var_p.to_pod()), ("uses", self.uses_p.to_pod()), ("root", self.root_p.to_pod()), ("tree", self.tree_p.to_pod())])
    }
}

impl FromPod for ModInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ModInfo { name_p: FromPod::from_pod(field(p, "name")?)?, file_p: FromPod::from_pod(field(p, "file")?)?, emit_rw_p: FromPod::from_pod(field(p, "emitRw")?)?, row_var_p: FromPod::from_pod(field(p, "rowVar")?)?, uses_p: FromPod::from_pod(field(p, "uses")?)?, root_p: FromPod::from_pod(field(p, "root")?)?, tree_p: FromPod::from_pod(field(p, "tree")?)? })
    }
}

/// `TagInfo`:
///
/// ```prism
/// type TagInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TagInfo {
    pub name_p: Text,
    pub family_p: Text,
    pub kind_p: Text,
    pub out_p: crate::check::types::Ty,
    pub qs_p: Array<Text>,
    pub rqs_p: Array<Text>,
    pub bounds_p: Array<(Text, Text)>,
    pub fields_p: Array<(Text, crate::check::types::Ty)>,
    pub home_p: Text,
    pub file_p: Nat,
    pub span_p: crate::syntax::Range,
}

impl Show for TagInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TagInfo", &[("name", &self.name_p), ("family", &self.family_p), ("kind", &self.kind_p), ("out", &self.out_p), ("qs", &self.qs_p), ("rqs", &self.rqs_p), ("bounds", &self.bounds_p), ("fields", &self.fields_p), ("home", &self.home_p), ("file", &self.file_p), ("span", &self.span_p)]);
    }
}

impl ToPod for TagInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TagInfo", vec![("name", self.name_p.to_pod()), ("family", self.family_p.to_pod()), ("kind", self.kind_p.to_pod()), ("out", self.out_p.to_pod()), ("qs", self.qs_p.to_pod()), ("rqs", self.rqs_p.to_pod()), ("bounds", self.bounds_p.to_pod()), ("fields", self.fields_p.to_pod()), ("home", self.home_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for TagInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TagInfo { name_p: FromPod::from_pod(field(p, "name")?)?, family_p: FromPod::from_pod(field(p, "family")?)?, kind_p: FromPod::from_pod(field(p, "kind")?)?, out_p: FromPod::from_pod(field(p, "out")?)?, qs_p: FromPod::from_pod(field(p, "qs")?)?, rqs_p: FromPod::from_pod(field(p, "rqs")?)?, bounds_p: FromPod::from_pod(field(p, "bounds")?)?, fields_p: FromPod::from_pod(field(p, "fields")?)?, home_p: FromPod::from_pod(field(p, "home")?)?, file_p: FromPod::from_pod(field(p, "file")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TraitInfo`:
///
/// ```prism
/// type TraitInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TraitInfo {
    pub name_p: Text,
    pub home_p: Text,
    pub param_p: Text,
    pub supers_p: Array<Text>,
    pub methods_p: Array<Text>,
    pub defaults_p: Array<Text>,
    pub assocs_p: Array<Text>,
    pub file_p: Nat,
    pub span_p: crate::syntax::Range,
}

impl Show for TraitInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TraitInfo", &[("name", &self.name_p), ("home", &self.home_p), ("param", &self.param_p), ("supers", &self.supers_p), ("methods", &self.methods_p), ("defaults", &self.defaults_p), ("assocs", &self.assocs_p), ("file", &self.file_p), ("span", &self.span_p)]);
    }
}

impl ToPod for TraitInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TraitInfo", vec![("name", self.name_p.to_pod()), ("home", self.home_p.to_pod()), ("param", self.param_p.to_pod()), ("supers", self.supers_p.to_pod()), ("methods", self.methods_p.to_pod()), ("defaults", self.defaults_p.to_pod()), ("assocs", self.assocs_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for TraitInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TraitInfo { name_p: FromPod::from_pod(field(p, "name")?)?, home_p: FromPod::from_pod(field(p, "home")?)?, param_p: FromPod::from_pod(field(p, "param")?)?, supers_p: FromPod::from_pod(field(p, "supers")?)?, methods_p: FromPod::from_pod(field(p, "methods")?)?, defaults_p: FromPod::from_pod(field(p, "defaults")?)?, assocs_p: FromPod::from_pod(field(p, "assocs")?)?, file_p: FromPod::from_pod(field(p, "file")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TyBody`:
///
/// ```prism
/// type TyBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TyBody {
    BRecord(Array<(Text, crate::check::types::Ty)>),
    BChoice(Array<(Text, Array<crate::check::types::Ty>)>),
    BRowKind,
    BAlias(crate::check::types::Ty),
    BOpaque,
    BPrim,
}

impl Show for TyBody {
    fn show(&self, p: &mut Printer) {
        match self {
            TyBody::BRecord(a0) => p.choice("BRecord", &[a0]),
            TyBody::BChoice(a0) => p.choice("BChoice", &[a0]),
            TyBody::BRowKind => p.choice("BRowKind", &[]),
            TyBody::BAlias(a0) => p.choice("BAlias", &[a0]),
            TyBody::BOpaque => p.choice("BOpaque", &[]),
            TyBody::BPrim => p.choice("BPrim", &[]),
        }
    }
}

impl ToPod for TyBody {
    fn to_pod(&self) -> Pod {
        match self {
            TyBody::BRecord(a0) => Pod::Choice("BRecord".into(), vec![a0.to_pod()]),
            TyBody::BChoice(a0) => Pod::Choice("BChoice".into(), vec![a0.to_pod()]),
            TyBody::BRowKind => Pod::Choice("BRowKind".into(), vec![]),
            TyBody::BAlias(a0) => Pod::Choice("BAlias".into(), vec![a0.to_pod()]),
            TyBody::BOpaque => Pod::Choice("BOpaque".into(), vec![]),
            TyBody::BPrim => Pod::Choice("BPrim".into(), vec![]),
        }
    }
}

impl FromPod for TyBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "BRecord" && a.len() == 1 => Ok(TyBody::BRecord(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BChoice" && a.len() == 1 => Ok(TyBody::BChoice(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BRowKind" && a.len() == 0 => Ok(TyBody::BRowKind),
            Pod::Choice(c, a) if &**c == "BAlias" && a.len() == 1 => Ok(TyBody::BAlias(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BOpaque" && a.len() == 0 => Ok(TyBody::BOpaque),
            Pod::Choice(c, a) if &**c == "BPrim" && a.len() == 0 => Ok(TyBody::BPrim),
            other => mismatch("a TyBody", other),
        }
    }
}

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyInfo {
    pub name_p: Text,
    pub home_p: Text,
    pub params_p: Array<Text>,
    pub body_p: TyBody,
    pub derives_p: Array<Text>,
    pub file_p: Nat,
    pub span_p: crate::syntax::Range,
}

impl Show for TyInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TyInfo", &[("name", &self.name_p), ("home", &self.home_p), ("params", &self.params_p), ("body", &self.body_p), ("derives", &self.derives_p), ("file", &self.file_p), ("span", &self.span_p)]);
    }
}

impl ToPod for TyInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TyInfo", vec![("name", self.name_p.to_pod()), ("home", self.home_p.to_pod()), ("params", self.params_p.to_pod()), ("body", self.body_p.to_pod()), ("derives", self.derives_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for TyInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyInfo { name_p: FromPod::from_pod(field(p, "name")?)?, home_p: FromPod::from_pod(field(p, "home")?)?, params_p: FromPod::from_pod(field(p, "params")?)?, body_p: FromPod::from_pod(field(p, "body")?)?, derives_p: FromPod::from_pod(field(p, "derives")?)?, file_p: FromPod::from_pod(field(p, "file")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `ValInfo`:
///
/// ```prism
/// type ValInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ValInfo {
    pub qk_p: Text,
    pub scheme_p: crate::check::types::Scheme,
    pub sort_p: Text,
    pub has_sig_p: bool,
    pub home_p: Text,
    pub file_p: Nat,
    pub span_p: crate::syntax::Range,
}

impl Show for ValInfo {
    fn show(&self, p: &mut Printer) {
        p.record("ValInfo", &[("qk", &self.qk_p), ("scheme", &self.scheme_p), ("sort", &self.sort_p), ("hasSig", &self.has_sig_p), ("home", &self.home_p), ("file", &self.file_p), ("span", &self.span_p)]);
    }
}

impl ToPod for ValInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("ValInfo", vec![("qk", self.qk_p.to_pod()), ("scheme", self.scheme_p.to_pod()), ("sort", self.sort_p.to_pod()), ("hasSig", self.has_sig_p.to_pod()), ("home", self.home_p.to_pod()), ("file", self.file_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for ValInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ValInfo { qk_p: FromPod::from_pod(field(p, "qk")?)?, scheme_p: FromPod::from_pod(field(p, "scheme")?)?, sort_p: FromPod::from_pod(field(p, "sort")?)?, has_sig_p: FromPod::from_pod(field(p, "hasSig")?)?, home_p: FromPod::from_pod(field(p, "home")?)?, file_p: FromPod::from_pod(field(p, "file")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// ```prism
/// IsRegexType: fn Text -> Bool
/// ```
pub fn is_regex_type_f(n_p0: &Text) -> bool {
    (n_p0 == &Text::lit("Regex")) || (n_p0 == &Text::lit("RegexReplacement"))
}

/// ```prism
/// IsPrimType: fn Text -> Bool
/// ```
pub fn is_prim_type_f(n_p0: &Text) -> bool {
    crate::check::types::has_text_f(&Array::from(vec![Text::lit("Bool"), Text::lit("unit"), Text::lit("Char"), Text::lit("Text"), Text::lit("Nat"), Text::lit("Int"), Text::lit("U8"), Text::lit("Float"), Text::lit("Path"), Text::lit("Duration"), Text::lit("Cursor"), Text::lit("Regex"), Text::lit("RegexReplacement")]), n_p0)
}

/// ```prism
/// QualKey: fn Text, Text -> Text
/// ```
pub fn qual_key_f(m_p0: &Text, name_p1: &Text) -> Text {
    if m_p0 == &Text::lit("") {
        name_p1.clone()
    } else {
        Text::from(format!("{}.{}", m_p0, name_p1))
    }
}

/// ```prism
/// Dotted: fn [Text] -> Text
/// ```
pub fn dotted_f(parts_p0: &Array<Text>) -> Text {
    crate::syntax::lexer::chars::join_f(parts_p0, &Text::lit("."))
}

/// ```prism
/// SNameKey: fn SName -> Text
/// ```
pub fn sname_key_f(n_p0: &crate::syntax::SName) -> Text {
    Text::from(format!("{}{}", &n_p0.sigils_p, &dotted_f(&n_p0.path_p)))
}

/// ```prism
/// DefNameText: fn DefName -> Text
/// ```
pub fn def_name_text_f(def_name0: &crate::syntax::decls::DefName) -> Text {
    match def_name0 {
        crate::syntax::decls::DefName::DefSName(n_p0) => sname_key_f(n_p0),
        crate::syntax::decls::DefName::DefOp(o_p1, _) => o_p1.clone(),
    }
}

/// ```prism
/// DefNameSpan: fn DefName -> Range
/// ```
pub fn def_name_span_f(def_name0: &crate::syntax::decls::DefName) -> crate::syntax::Range {
    match def_name0 {
        crate::syntax::decls::DefName::DefSName(n_p0) => n_p0.span_p.clone(),
        crate::syntax::decls::DefName::DefOp(_, r_p1) => r_p1.clone(),
    }
}

/// ```prism
/// IsLowerText: fn Text -> Bool
/// ```
pub fn is_lower_text_f(t_p0: &Text) -> bool {
    crate::syntax::lexer::chars::is_lower_f(&crate::syntax::lexer::chars::head_f(t_p0))
}

/// ```prism
/// IsUpperText: fn Text -> Bool
/// ```
pub fn is_upper_text_f(t_p0: &Text) -> bool {
    crate::syntax::lexer::chars::is_upper_f(&crate::syntax::lexer::chars::head_f(t_p0))
}

/// ```prism
/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
/// ```
pub fn build_g_f(srcs_p0: &Array<crate::check::errors::Src>, trees_p1: &Array<crate::syntax::Module>) -> (G, crate::check::types::St) {
    let g0_p2 = G { mods_p: Map::new(), types_p: Map::new(), ctors_p: Map::new(), tags_p: Map::new(), families_p: Map::new(), fam_owner_p: Map::new(), vals_p: Map::new(), traits_p: Map::new(), impls_p: Map::new(), bare_p: Map::new(), bare_types_p: Map::new(), bare_traits_p: Map::new(), srcs_p: srcs_p0.clone(), defs_p: Array::new(), program_row_p: crate::check::types::empty_row_p(), elem_fams_p: Array::new(), root_module_o: None, app_root_p: app_root_f(srcs_p0, trees_p1), fn_at_p: Map::new(), prelude_from_p: crate::prelude::len(trees_p1) };
    let st0_p3 = crate::check::types::new_st_f(&Nat::from(0u32));
    let (g1_pb, st1_pc) = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(trees_p1)), &(g0_p2.clone(), st0_p3.clone()), &(|(g_p8, st_p9): &(G, crate::check::types::St), i_pa: &Nat| add_module_f(g_p8, st_p9, i_pa, &crate::prelude::or(&crate::prelude::index(trees_p1, i_pa), &empty_module_p()))));
    let g2_p4 = add_builtins_f(&g1_pb);
    let (g3_pg, st3_ph) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g2_p4.mods_p), (g2_p4.clone(), st1_pc.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (g_pd, st_pe) = p0;
        let m_pf = p1;
        prism_rtl::Turn::More(Rc::new(crate::check::env::names::CollectNames { g_p0: g_pd.clone(), st_p1: st_pe.clone(), m_p2: m_pf.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let g4_p5 = {
        let mut this: G = g3_pg.clone();
        this.program_row_p = crate::check::env::names::program_row_f(&this);
        this
    };
    let (g6_pl, st6_pm) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g4_p5.mods_p), (g4_p5.clone(), st3_ph.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (g_pi, st_pj) = p0;
        let m_pk = p1;
        prism_rtl::Turn::More(Rc::new(crate::check::env::names::BuildTables { g_p0: g_pi.clone(), st_p1: st_pj.clone(), m_p2: m_pk.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let (g6b_pq, st6b_pr) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g6_pl.mods_p), (g6_pl.clone(), st6_pm.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (g_pn, st_po) = p0;
        let m_pp = p1;
        prism_rtl::Turn::More(Rc::new(crate::check::env::decls::ConvertTypes { g_p0: g_pn.clone(), st_p1: st_po.clone(), m_p2: m_pp.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let (g7_pv, st7_p10) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g6b_pq.mods_p), (g6b_pq.clone(), st6b_pr.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (g_ps, st_pt) = p0;
        let m_pu = p1;
        prism_rtl::Turn::More(Rc::new(crate::check::env::decls::ConvertDecls { g_p0: g_ps.clone(), st_p1: st_pt.clone(), m_p2: m_pu.clone() }))
    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>));
    let g8_p6 = crate::check::env::traits::derived_impls_f(&g7_pv);
    let st8_p7 = crate::check::env::traits::coherence_f(&g8_p6, &crate::check::env::traits::derived_dynamics_f(&g8_p6, &st7_p10));
    (g8_p6.clone(), st8_p7.clone())
}

/// The step machine of `BuildG`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
/// ```
pub struct BuildG {
    pub srcs_p0: Array<crate::check::errors::Src>,
    pub trees_p1: Array<crate::syntax::Module>,
}

impl prism_rtl::Job<(G, crate::check::types::St)> for BuildG {
    fn cycle(&self) -> prism_rtl::Turn<(G, crate::check::types::St)> {
        let srcs_p0 = &self.srcs_p0;
        let trees_p1 = &self.trees_p1;
        let g0_p2 = G { mods_p: Map::new(), types_p: Map::new(), ctors_p: Map::new(), tags_p: Map::new(), families_p: Map::new(), fam_owner_p: Map::new(), vals_p: Map::new(), traits_p: Map::new(), impls_p: Map::new(), bare_p: Map::new(), bare_types_p: Map::new(), bare_traits_p: Map::new(), srcs_p: srcs_p0.clone(), defs_p: Array::new(), program_row_p: crate::check::types::empty_row_p(), elem_fams_p: Array::new(), root_module_o: None, app_root_p: app_root_f(srcs_p0, trees_p1), fn_at_p: Map::new(), prelude_from_p: crate::prelude::len(trees_p1) };
        let st0_p3 = crate::check::types::new_st_f(&Nat::from(0u32));
        let (g1_pb, st1_pc) = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(trees_p1)), &(g0_p2.clone(), st0_p3.clone()), &(|(g_p8, st_p9): &(G, crate::check::types::St), i_pa: &Nat| add_module_f(g_p8, st_p9, i_pa, &crate::prelude::or(&crate::prelude::index(trees_p1, i_pa), &empty_module_p()))));
        let g2_p4 = add_builtins_f(&g1_pb);
        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(&g2_p4.mods_p), (g2_p4.clone(), st1_pc.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (g_pd, st_pe) = p0;
            let m_pf = p1;
            prism_rtl::Turn::More(Rc::new(crate::check::env::names::CollectNames { g_p0: g_pd.clone(), st_p1: st_pe.clone(), m_p2: m_pf.clone() }))
        }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_5904: (G, crate::check::types::St)| {
            let (g3_pg, st3_ph) = fold_5904;
            let g4_p5 = {
                let mut this: G = g3_pg.clone();
                this.program_row_p = crate::check::env::names::program_row_f(&this);
                this
            };
            crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(&g4_p5.mods_p), (g4_p5.clone(), st3_ph.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (g_pi, st_pj) = p0;
                let m_pk = p1;
                prism_rtl::Turn::More(Rc::new(crate::check::env::names::BuildTables { g_p0: g_pi.clone(), st_p1: st_pj.clone(), m_p2: m_pk.clone() }))
            }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_6061: (G, crate::check::types::St)| {
                let (g6_pl, st6_pm) = fold_6061;
                crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(&g6_pl.mods_p), (g6_pl.clone(), st6_pm.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (g_pn, st_po) = p0;
                    let m_pp = p1;
                    prism_rtl::Turn::More(Rc::new(crate::check::env::decls::ConvertTypes { g_p0: g_pn.clone(), st_p1: st_po.clone(), m_p2: m_pp.clone() }))
                }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_6156: (G, crate::check::types::St)| {
                    let (g6b_pq, st6b_pr) = fold_6156;
                    crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(&g6b_pq.mods_p), (g6b_pq.clone(), st6b_pr.clone()), Rc::new(move |(p0, p1): ((G, crate::check::types::St), Text)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let (g_ps, st_pt) = p0;
                        let m_pu = p1;
                        prism_rtl::Turn::More(Rc::new(crate::check::env::decls::ConvertDecls { g_p0: g_ps.clone(), st_p1: st_pt.clone(), m_p2: m_pu.clone() }))
                    }))) as Rc<dyn Fn(((G, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>>>), move |fold_6250: (G, crate::check::types::St)| {
                        let (g7_pv, st7_p10) = fold_6250;
                        let g8_p6 = crate::check::env::traits::derived_impls_f(&g7_pv);
                        crate::prelude::call_then(crate::check::env::traits::start_coherence_f(g8_p6.clone(), crate::check::env::traits::derived_dynamics_f(&g8_p6, &st7_p10)), move |coherence_f_6368: crate::check::types::St| {
                            let st8_p7 = coherence_f_6368;
                            prism_rtl::Turn::Finished((g8_p6.clone(), st8_p7.clone()))
                        })
                    })
                })
            })
        })
    }
}

/// `Start BuildG, x`: what the function value is when passed to `@Run`.
pub fn start_build_g_f(srcs_p0: Array<crate::check::errors::Src>, trees_p1: Array<crate::syntax::Module>) -> Rc<dyn prism_rtl::Job<(G, crate::check::types::St)>> {
    Rc::new(BuildG { srcs_p0, trees_p1 })
}

/// ```prism
/// let emptyModule
/// ```
pub fn empty_module_p() -> crate::syntax::Module {
    crate::syntax::Module { name_o: None, emit_row_o: None, mods_p: Array::new(), uses_p: Array::new(), decls_p: Array::new(), template_o: None, span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }
}

/// ```prism
/// ModName: fn Module -> Text
/// ```
pub fn mod_name_f(m_p0: &crate::syntax::Module) -> Text {
    match &m_p0.name_o {
        Some(q_p1) => dotted_f(&q_p1.path_p),
        None => Text::lit(""),
    }
}

/// ```prism
/// AppRoot: fn [Src], [Module] -> Bool
/// ```
pub fn app_root_f(srcs_p0: &Array<crate::check::errors::Src>, trees_p1: &Array<crate::syntax::Module>) -> bool {
    crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(trees_p1)), &false, &(|seen_p2: &bool, i_p3: &Nat| {
        let t_p4 = crate::prelude::or(&crate::prelude::index(trees_p1, i_p3), &empty_module_p());
        let name_p5 = mod_name_f(&t_p4);
        if &name_p5 == &Text::lit("App") {
            false
        } else {
            if (&name_p5 == &Text::lit("")) && (&crate::check::errors::seg_at_f(&crate::prelude::or(&crate::prelude::index(srcs_p0, i_p3), &crate::check::errors::mk_src_f(&Text::lit(""), &Text::lit(""))), &Nat::from(0u32)).role_p != &Text::lit("loose")) {
                true
            } else {
                *seen_p2
            }
        }
    }))
}

/// ```prism
/// UseName: fn G, Text -> Text
/// ```
pub fn use_name_f(g_p0: &G, u_p1: &Text) -> Text {
    if g_p0.app_root_p && (u_p1 == &Text::lit("App")) {
        Text::lit("")
    } else {
        u_p1.clone()
    }
}

/// ```prism
/// QualModule: fn G, [Text] -> Text
/// ```
pub fn qual_module_f(g_p0: &G, parts_p1: &Array<Text>) -> Text {
    use_name_f(g_p0, &dotted_f(parts_p1))
}

/// ```prism
/// AddModule: fn G, St, Nat, Module -> ((G, St))
/// ```
pub fn add_module_f(g_p0: &G, st_p1: &crate::check::types::St, i_p2: &Nat, tree_p3: &crate::syntax::Module) -> (G, crate::check::types::St) {
    let name_p4 = mod_name_f(tree_p3);
    let s_p5 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.file_p = i_p2.clone();
        this
    };
    if has_key_f(&g_p0.mods_p, &name_p4) {
        {
            let what_p6 = if &name_p4 == &Text::lit("") {
                Text::lit("two files have no `module` line")
            } else {
                Text::from(format!("two files declare `module {}`", &name_p4))
            };
            (g_p0.clone(), crate::check::types::recording::err_f(&s_p5, &Text::lit("collision"), &tree_p3.span_p, &what_p6))
        }
    } else {
        {
            let info_p7 = ModInfo { name_p: name_p4.clone(), file_p: i_p2.clone(), emit_rw_p: crate::check::types::empty_row_p(), row_var_p: Text::lit(""), uses_p: crate::prelude::each(&tree_p3.uses_p, &(|u_p9: &crate::syntax::Use| (use_name_f(g_p0, &dotted_f(&u_p9.target_p.path_p)), u_p9.star_p))), root_p: &name_p4 == &Text::lit(""), tree_p: tree_p3.clone() };
            let g2_p8 = {
                let mut this: G = g_p0.clone();
                this.mods_p = crate::prelude::insert(&this.mods_p, &name_p4, &info_p7);
                if &name_p4 == &Text::lit("") {
                    this.root_module_o = Some(Text::lit(""));
                }
                this
            };
            (g2_p8.clone(), s_p5.clone())
        }
    }
}

/// ```prism
/// HasKey: fn (Text ==> a), Text -> Bool
/// ```
pub fn has_key_f<A: Clone + 'static>(m_p0: &Map<Text, A>, k_p1: &Text) -> bool {
    match crate::prelude::get(m_p0, k_p1) {
        Some(_) => true,
        None => false,
    }
}

/// ```prism
/// AddBuiltins: fn G -> G
/// ```
pub fn add_builtins_f(g_p0: &G) -> G {
    let bool_ctor_f1 = Rc::new(move |n_p6: &Text, i_p7: &Nat| CtorInfo { name_p: n_p6.clone(), owner_p: Text::lit("Bool"), params_p: Array::new(), args_p: Array::new(), fields_p: Array::new(), ty_p: crate::check::types::t_bool_p(), index_p: i_p7.clone() }) as Rc<dyn Fn(&Text, &Nat) -> CtorInfo>;
    let pre_p2 = crate::check::types::Scheme { qs_p: Array::from(vec![Text::lit("a")]), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(crate::check::types::Ty::TyQ(Text::lit("a")))) };
    let numbered_p3 = crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, Array::from(vec![crate::check::types::t_nat_p()]), Rc::new(crate::check::types::Ty::TyCon(Text::lit("Buffer"), Array::from(vec![crate::check::types::t_nat_p()])))));
    let buf_empty_p4 = crate::check::types::Scheme { qs_p: Array::from(vec![Text::lit("a")]), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: crate::check::types::Ty::TyCon(Text::lit("Buffer"), Array::from(vec![crate::check::types::Ty::TyQ(Text::lit("a"))])) };
    let tab_empty_p5 = crate::check::types::Scheme { qs_p: Array::from(vec![Text::lit("k"), Text::lit("v")]), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: crate::check::types::Ty::TyCon(Text::lit("Table"), Array::from(vec![crate::check::types::Ty::TyQ(Text::lit("k")), crate::check::types::Ty::TyQ(Text::lit("v"))])) };
    let mut this: G = g_p0.clone();
    this.ctors_p = crate::prelude::insert(&crate::prelude::insert(&this.ctors_p, &Text::lit("True"), &(&bool_ctor_f1)(&Text::lit("True"), &Nat::from(0u32))), &Text::lit("False"), &(&bool_ctor_f1)(&Text::lit("False"), &Nat::from(1u32)));
    this.vals_p = crate::prelude::insert(&this.vals_p, &Text::lit("Prelude.never"), &builtin_f(&Text::lit("Prelude.never"), &pre_p2));
    this.vals_p = crate::prelude::insert(&this.vals_p, &Text::lit("Buffer.Numbered"), &builtin_f(&Text::lit("Buffer.Numbered"), &numbered_p3));
    this.vals_p = crate::prelude::insert(&this.vals_p, &Text::lit("Buffer.Empty"), &builtin_f(&Text::lit("Buffer.Empty"), &buf_empty_p4));
    this.vals_p = crate::prelude::insert(&this.vals_p, &Text::lit("Table.Empty"), &builtin_f(&Text::lit("Table.Empty"), &tab_empty_p5));
    this
}

/// ```prism
/// Builtin: fn Text, Scheme -> ValInfo
/// ```
pub fn builtin_f(qk_p0: &Text, sc_p1: &crate::check::types::Scheme) -> ValInfo {
    ValInfo { qk_p: qk_p0.clone(), scheme_p: sc_p1.clone(), sort_p: Text::lit("builtin"), has_sig_p: true, home_p: Text::lit("Prelude"), file_p: Nat::from(0u32), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }
}
