//! The module `Check.Env.Traits`, from `target/bootstrap/src/prismc/check/env/traits.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// DerivedImpls: fn G -> G
/// ```
pub fn derived_impls(g_p0: &crate::check::env::G) -> crate::check::env::G {
    fold(&keys(&g_p0.types), g_p0, &(|gg_p1: &crate::check::env::G, k_p2: &Text| match get(&gg_p1.types, k_p2) {
        Some(ti_p3) => fold(&ti_p3.derives, gg_p1, &(|g2_p4: &crate::check::env::G, tr_p5: &Text| match crate::check::env::names::resolve_trait(g2_p4, &ti_p3.home, &split_on(tr_p5, &Text::lit("."))) {
            Some(cls_p6) => {
                let im_p7 = crate::check::env::ImplInfo { cls: cls_p6.clone(), head: crate::check::types::Ty::TyCon(ti_p3.name.clone(), each(&ti_p3.params, &(|p_p8: &Text| crate::check::types::Ty::TyQ(p_p8.clone())))), qs: ti_p3.params.clone(), bounds: each(&ti_p3.params, &(|p_p9: &Text| (p_p9.clone(), cls_p6.clone()))), home: ti_p3.home.clone(), file: ti_p3.file.clone(), span: ti_p3.span.clone(), derived: true, assocs: Array::new(), methods: Array::new() };
                {
                    let mut this: crate::check::env::G = g2_p4.clone();
                    this.impls = insert(&this.impls, &cls_p6, &push(&or(&get(&this.impls, &cls_p6), &Array::new()), &im_p7));
                    this
                }
            },
            None => g2_p4.clone(),
        })),
        None => gg_p1.clone(),
    }))
}

/// ```prism
/// DerivedDynamics: fn G, St -> St
/// ```
pub fn derived_dynamics(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> crate::check::types::St {
    fold(&keys(&g_p0.types), st_p1, &(|s_p2: &crate::check::types::St, k_p3: &Text| match get(&g_p0.types, k_p3) {
        Some(ti_p4) => {
            let held_p5 = filter(&ti_p4.derives, &(|d_p6: &Text| crate::check::types::has_text(&Array::from(vec![Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")]), &crate::check::types::bare_name(d_p6))));
            match field_holding(&ti_p4.body) {
                Some(f_p7) if (&len(&held_p5) > &Nat::from(0u32)) => with_file(&crate::check::types::recording::err_fix(&with_file(s_p2, &ti_p4.file), &Text::lit("derive-dynamic"), &ti_p4.span, &Text::from(format!("`derive ^{}` on `{}`, whose `{}` holds a dynamic or an event, which does not compare or print", &crate::check::types::bare_name(&or(&index(&held_p5, &Nat::from(0u32)), &Text::lit(""))), &crate::check::types::bare_name(&ti_p4.name), &f_p7)), &Text::lit("drop the derive")), &s_p2.file),
                _ => s_p2.clone(),
                _ => unreachable!("no arm matched"),
            }
        },
        None => s_p2.clone(),
    }))
}

/// ```prism
/// ?FieldHolding: fn TyBody -> ?Text
/// ```
pub fn field_holding(b_p0: &crate::check::env::TyBody) -> Option<Text> {
    match b_p0 {
        crate::check::env::TyBody::BRecord(fs_p1) => fold(fs_p1, &None, &(|found_o2: &Option<Text>, (f_p3, t_p4): &(Text, crate::check::types::Ty)| if (found_o2 == &None) && holds_layer(t_p4) {
            Some(f_p3.clone())
        } else {
            found_o2.clone()
        })),
        crate::check::env::TyBody::BChoice(cs_p5) => fold(cs_p5, &None, &(|found_o6: &Option<Text>, (c_p7, ts_p8): &(Text, Array<crate::check::types::Ty>)| if (found_o6 == &None) && fold(ts_p8, &false, &(|h_p9: &bool, t_pa: &crate::check::types::Ty| *h_p9 || holds_layer(t_pa))) {
            Some(c_p7.clone())
        } else {
            found_o6.clone()
        })),
        _ => None,
    }
}

/// ```prism
/// HoldsLayer: fn Ty -> Bool
/// ```
pub fn holds_layer(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TySig(m2957_0_0, _) if (m2957_0_0 == &Text::lit("$")) => true,
        crate::check::types::Ty::TySig(m2957_1_0, _) if (m2957_1_0 == &Text::lit("!")) => true,
        crate::check::types::Ty::TySig(_, i_p1) => holds_layer(&**i_p1),
        crate::check::types::Ty::TyTuple(ts_p2) => fold(ts_p2, &false, &(|h_p3: &bool, x_p4: &crate::check::types::Ty| *h_p3 || holds_layer(x_p4))),
        crate::check::types::Ty::TyArray(e_p5) => holds_layer(&**e_p5),
        crate::check::types::Ty::TyMap(k_p6, v_p7) => holds_layer(&**k_p6) || holds_layer(&**v_p7),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RowHoldsDynamics: fn G, Rw -> Bool
/// ```
pub fn row_holds_dynamics(g_p0: &crate::check::env::G, w_p1: &crate::check::types::Rw) -> bool {
    fold(&values(&g_p0.tags), &false, &(|h_p2: &bool, tg_p3: &crate::check::env::TagInfo| *h_p2 || ((((&tg_p3.kind == &Text::lit("Element")) && crate::check::types::has_text(&w_p1.fams, &tg_p3.family)) && !crate::check::types::has_text(&w_p1.minus, &tg_p3.name)) && fold(&tg_p3.fields, &false, &(|f_p4: &bool, (_, ft_p5): &(Text, crate::check::types::Ty)| *f_p4 || holds_layer(&unlive(ft_p5)))))))
}

/// ```prism
/// Unlive: fn Ty -> Ty
/// ```
pub fn unlive(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TySig(m3847_0_0, i_p1) if (m3847_0_0 == &Text::lit("$")) => (**i_p1).clone(),
        other_p2 => other_p2.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Coherence: unbounded fn G, St -> St
/// ```
pub fn coherence(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> crate::check::types::St {
    run_to_end(fold_job(keys(&g_p0.impls), st_p1.clone(), {
        let g_p0 = g_p0.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
            let g_p0 = g_p0.clone();
            entered(once_job(move || {
                let s_p2 = p0;
                let cls_p3 = p1;
                {
                    let impls_p4 = or(&get(&g_p0.impls, &cls_p3), &Array::new());
                    call_value(fold_job(impls_p4.clone(), s_p2.clone(), {
                        let g_p0 = g_p0.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::ImplInfo)| {
                            let g_p0 = g_p0.clone();
                            entered(once_job(move || {
                                let s1_p6 = p0;
                                let i_p7 = p1;
                                prism_rtl::Turn::More(Rc::new(CheckOrphan { g_p0: g_p0.clone(), st_p1: s1_p6.clone(), i_p2: i_p7.clone() }))
                            }))
                        }) as Rc<dyn Fn((crate::check::types::St, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_4037: crate::check::types::St| {
                        let s2_p5 = fold_4037;
                        fold_job(crate::check::errors::range0(&len(&impls_p4)), s2_p5.clone(), {
                            let impls_p4 = impls_p4.clone();
                            let g_p0 = g_p0.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                let impls_p4 = impls_p4.clone();
                                let g_p0 = g_p0.clone();
                                entered(once_job(move || {
                                    let s3_p8 = p0;
                                    let a_p9 = p1;
                                    fold_job(crate::check::errors::range0(&len(&impls_p4)), s3_p8.clone(), {
                                        let a_p9 = a_p9.clone();
                                        let g_p0 = g_p0.clone();
                                        let impls_p4 = impls_p4.clone();
                                        Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                            let a_p9 = a_p9.clone();
                                            let g_p0 = g_p0.clone();
                                            let impls_p4 = impls_p4.clone();
                                            entered(once_job(move || {
                                                let s4_pa = p0;
                                                let b_pb = p1;
                                                if &a_p9 < &b_pb {
                                                    prism_rtl::Turn::More(Rc::new(CheckPair { g_p0: g_p0.clone(), st_p1: s4_pa.clone(), a_p2: or(&index(&impls_p4, &a_p9), &dummy_impl()), b_p3: or(&index(&impls_p4, &b_pb), &dummy_impl()) }))
                                                } else {
                                                    prism_rtl::Turn::Finished(s4_pa.clone())
                                                }
                                            }))
                                        }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                                    }).cycle()
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle()
                    })
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `Coherence`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Coherence: unbounded fn G, St -> St
/// ```
pub struct Coherence {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for Coherence {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        fold_job(keys(&g_p0.impls), st_p1.clone(), {
            let g_p0 = g_p0.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
                let g_p0 = g_p0.clone();
                entered(once_job(move || {
                    let s_p2 = p0;
                    let cls_p3 = p1;
                    {
                        let impls_p4 = or(&get(&g_p0.impls, &cls_p3), &Array::new());
                        call_value(fold_job(impls_p4.clone(), s_p2.clone(), {
                            let g_p0 = g_p0.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::ImplInfo)| {
                                let g_p0 = g_p0.clone();
                                entered(once_job(move || {
                                    let s1_p6 = p0;
                                    let i_p7 = p1;
                                    prism_rtl::Turn::More(Rc::new(CheckOrphan { g_p0: g_p0.clone(), st_p1: s1_p6.clone(), i_p2: i_p7.clone() }))
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }), move |fold_4037: crate::check::types::St| {
                            let s2_p5 = fold_4037;
                            fold_job(crate::check::errors::range0(&len(&impls_p4)), s2_p5.clone(), {
                                let impls_p4 = impls_p4.clone();
                                let g_p0 = g_p0.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                    let impls_p4 = impls_p4.clone();
                                    let g_p0 = g_p0.clone();
                                    entered(once_job(move || {
                                        let s3_p8 = p0;
                                        let a_p9 = p1;
                                        fold_job(crate::check::errors::range0(&len(&impls_p4)), s3_p8.clone(), {
                                            let a_p9 = a_p9.clone();
                                            let g_p0 = g_p0.clone();
                                            let impls_p4 = impls_p4.clone();
                                            Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                                let a_p9 = a_p9.clone();
                                                let g_p0 = g_p0.clone();
                                                let impls_p4 = impls_p4.clone();
                                                entered(once_job(move || {
                                                    let s4_pa = p0;
                                                    let b_pb = p1;
                                                    if &a_p9 < &b_pb {
                                                        prism_rtl::Turn::More(Rc::new(CheckPair { g_p0: g_p0.clone(), st_p1: s4_pa.clone(), a_p2: or(&index(&impls_p4, &a_p9), &dummy_impl()), b_p3: or(&index(&impls_p4, &b_pb), &dummy_impl()) }))
                                                    } else {
                                                        prism_rtl::Turn::Finished(s4_pa.clone())
                                                    }
                                                }))
                                            }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                                        }).cycle()
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }).cycle()
                        })
                    }
                }))
            }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start Coherence, x`: what the function value is when passed to `@Run`.
pub fn start_coherence(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Coherence { g_p0, st_p1 })
}

/// ```prism
/// let dummyImpl
/// ```
pub fn dummy_impl() -> crate::check::env::ImplInfo {
    crate::check::env::ImplInfo { cls: Text::lit(""), head: crate::check::types::Ty::TyErr, qs: Array::new(), bounds: Array::new(), home: Text::lit(""), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }, derived: false, assocs: Array::new(), methods: Array::new() }
}

/// ```prism
/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub fn check_pair(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, a_p2: &crate::check::env::ImplInfo, b_p3: &crate::check::env::ImplInfo) -> crate::check::types::St {
    if !heads_may_meet(&a_p2.head, &b_p3.head) {
        st_p1.clone()
    } else {
        if (&a_p2.file < &b_p3.file) || ((&a_p2.file == &b_p3.file) && (&a_p2.span.start <= &b_p3.span.start)) {
            check_pair_in(g_p0, st_p1, a_p2, b_p3)
        } else {
            check_pair_in(g_p0, st_p1, b_p3, a_p2)
        }
    }
}

/// The step machine of `CheckPair`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub struct CheckPair {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub a_p2: crate::check::env::ImplInfo,
    pub b_p3: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckPair {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let a_p2 = &self.a_p2;
        let b_p3 = &self.b_p3;
        if !heads_may_meet(&a_p2.head, &b_p3.head) {
            prism_rtl::Turn::Finished(st_p1.clone())
        } else {
            if (&a_p2.file < &b_p3.file) || ((&a_p2.file == &b_p3.file) && (&a_p2.span.start <= &b_p3.span.start)) {
                prism_rtl::Turn::More(Rc::new(CheckPairIn { g_p0: g_p0.clone(), st_p1: st_p1.clone(), a_p2: a_p2.clone(), b_p3: b_p3.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(CheckPairIn { g_p0: g_p0.clone(), st_p1: st_p1.clone(), a_p2: b_p3.clone(), b_p3: a_p2.clone() }))
            }
        }
    }
}

/// `Start CheckPair, x`: what the function value is when passed to `@Run`.
pub fn start_check_pair(g_p0: crate::check::env::G, st_p1: crate::check::types::St, a_p2: crate::check::env::ImplInfo, b_p3: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckPair { g_p0, st_p1, a_p2, b_p3 })
}

/// ```prism
/// HeadsMayMeet: fn Ty, Ty -> Bool
/// ```
pub fn heads_may_meet(ty0: &crate::check::types::Ty, ty1: &crate::check::types::Ty) -> bool {
    match (ty0, ty1) {
        (crate::check::types::Ty::TyCon(x_p0, _), crate::check::types::Ty::TyCon(y_p1, _)) => x_p0 == y_p1,
        (_, _) => true,
    }
}

/// ```prism
/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub fn check_pair_in(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, a_p2: &crate::check::env::ImplInfo, b_p3: &crate::check::env::ImplInfo) -> crate::check::types::St {
    let s0_p4 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.file = b_p3.file.clone();
        this
    };
    let (ta_p5, s1_p6) = crate::check::types::schemes::instantiate(&s0_p4, &crate::check::types::Scheme { qs: a_p2.qs.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: a_p2.head.clone() }, &b_p3.span);
    let (tb_p7, s2_p8) = crate::check::types::schemes::instantiate(&s1_p6, &crate::check::types::Scheme { qs: b_p3.qs.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: b_p3.head.clone() }, &b_p3.span);
    let (ok_p9, s3_pa) = crate::check::types::unify::try_unify(&s2_p8, &ta_p5, &tb_p7, &b_p3.span);
    if !ok_p9 {
        st_p1.clone()
    } else {
        {
            let same_pb = ((&len(&a_p2.qs) == &Nat::from(0u32)) && (&len(&b_p3.qs) == &Nat::from(0u32))) || (&shape_of(&a_p2.head) == &shape_of(&b_p3.head));
            let code_pc = if same_pb { Text::lit("impl-duplicate") } else { Text::lit("impl-overlap") };
            let first_at_pd = crate::check::errors::src_place(&or(&index(&g_p0.srcs, &a_p2.file), &crate::check::errors::mk_src(&Text::lit("?"), &Text::lit(""))), &a_p2.span.start);
            crate::check::types::recording::err_fix(&s0_p4, &code_pc, &b_p3.span, &Text::from(format!("a second impl of `^{}` for `{}`", &crate::check::types::bare_name(&a_p2.cls), &crate::check::types::show_ty(&s0_p4, &b_p3.head))), &Text::from(format!("the first is at {}; keep one", &first_at_pd)))
        }
    }
}

/// The step machine of `CheckPairIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub struct CheckPairIn {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub a_p2: crate::check::env::ImplInfo,
    pub b_p3: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckPairIn {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let a_p2 = &self.a_p2;
        let b_p3 = &self.b_p3;
        let s0_p4 = {
            let mut this: crate::check::types::St = st_p1.clone();
            this.file = b_p3.file.clone();
            this
        };
        let a_p2 = a_p2.clone();
        let b_p3 = b_p3.clone();
        let g_p0 = g_p0.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::types::schemes::start_instantiate(s0_p4.clone(), crate::check::types::Scheme { qs: a_p2.qs.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: a_p2.head.clone() }, b_p3.span.clone()), move |instantiate_5054: (crate::check::types::Ty, crate::check::types::St)| {
            let (ta_p5, s1_p6) = instantiate_5054;
            call_then(crate::check::types::schemes::start_instantiate(s1_p6.clone(), crate::check::types::Scheme { qs: b_p3.qs.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: b_p3.head.clone() }, b_p3.span.clone()), move |instantiate_5188: (crate::check::types::Ty, crate::check::types::St)| {
                let (tb_p7, s2_p8) = instantiate_5188;
                call_then(crate::check::types::unify::start_try_unify(s2_p8.clone(), ta_p5.clone(), tb_p7.clone(), b_p3.span.clone()), move |try_unify_5322: (bool, crate::check::types::St)| {
                    let (ok_p9, s3_pa) = try_unify_5322;
                    if !ok_p9 {
                        prism_rtl::Turn::Finished(st_p1.clone())
                    } else {
                        {
                            let same_pb = ((&len(&a_p2.qs) == &Nat::from(0u32)) && (&len(&b_p3.qs) == &Nat::from(0u32))) || (&shape_of(&a_p2.head) == &shape_of(&b_p3.head));
                            let code_pc = if same_pb { Text::lit("impl-duplicate") } else { Text::lit("impl-overlap") };
                            let first_at_pd = crate::check::errors::src_place(&or(&index(&g_p0.srcs, &a_p2.file), &crate::check::errors::mk_src(&Text::lit("?"), &Text::lit(""))), &a_p2.span.start);
                            call_then(crate::check::types::start_show_ty(s0_p4.clone(), b_p3.head.clone()), move |show_ty_5698: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s0_p4, &code_pc, &b_p3.span, &Text::from(format!("a second impl of `^{}` for `{}`", &crate::check::types::bare_name(&a_p2.cls), &show_ty_5698)), &Text::from(format!("the first is at {}; keep one", &first_at_pd)))))
                        }
                    }
                })
            })
        })
    }
}

/// `Start CheckPairIn, x`: what the function value is when passed to `@Run`.
pub fn start_check_pair_in(g_p0: crate::check::env::G, st_p1: crate::check::types::St, a_p2: crate::check::env::ImplInfo, b_p3: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckPairIn { g_p0, st_p1, a_p2, b_p3 })
}

/// ```prism
/// ShapeOf: unbounded fn Ty -> Text
/// ```
pub fn shape_of(t_p0: &crate::check::types::Ty) -> Text {
    match t_p0 {
        crate::check::types::Ty::TyQ(_) => Text::lit("_"),
        crate::check::types::Ty::TyCon(n_p1, args_p2) => Text::from(format!("{}({})", n_p1, &crate::syntax::lexer::chars::join(&run_to_end(each_job(args_p2.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_shape_of(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(",")))),
        crate::check::types::Ty::TyTuple(ts_p3) => Text::from(format!("(({}))", &crate::syntax::lexer::chars::join(&run_to_end(each_job(ts_p3.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_shape_of(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(",")))),
        crate::check::types::Ty::TyArray(e_p4) => Text::from(format!("[{}]", &shape_of(&**e_p4))),
        crate::check::types::Ty::TyMap(k_p5, v_p6) => Text::from(format!("{}==>{}", &shape_of(&**k_p5), &shape_of(&**v_p6))),
        crate::check::types::Ty::TySig(s_p7, i_p8) => Text::from(format!("{}{}", s_p7, &shape_of(&**i_p8))),
        _ => Text::lit("?"),
    }
}

/// The step machine of `ShapeOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShapeOf: unbounded fn Ty -> Text
/// ```
pub struct ShapeOf {
    pub t_p0: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for ShapeOf {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyQ(_) => prism_rtl::Turn::Finished(Text::lit("_")),
            crate::check::types::Ty::TyCon(n_p1, args_p2) => {
                let args_p2 = args_p2.clone();
                let n_p1 = n_p1.clone();
                call_value(each_job(args_p2.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_shape_of(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5940: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &n_p1, &crate::syntax::lexer::chars::join(&each_5940, &Text::lit(","))))))
            },
            crate::check::types::Ty::TyTuple(ts_p3) => {
                let ts_p3 = ts_p3.clone();
                call_value(each_job(ts_p3.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_shape_of(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5994: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("(({}))", &crate::syntax::lexer::chars::join(&each_5994, &Text::lit(","))))))
            },
            crate::check::types::Ty::TyArray(e_p4) => {
                let e_p4 = (**e_p4).clone();
                call_then(start_shape_of(e_p4.clone()), move |shape_of_6039: Text| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &shape_of_6039))))
            },
            crate::check::types::Ty::TyMap(k_p5, v_p6) => {
                let k_p5 = (**k_p5).clone();
                let v_p6 = (**v_p6).clone();
                call_then(start_shape_of(k_p5.clone()), move |shape_of_6070: Text| call_then(start_shape_of(v_p6.clone()), move |shape_of_6084: Text| prism_rtl::Turn::Finished(Text::from(format!("{}==>{}", &shape_of_6070, &shape_of_6084)))))
            },
            crate::check::types::Ty::TySig(s_p7, i_p8) => {
                let i_p8 = (**i_p8).clone();
                let s_p7 = s_p7.clone();
                call_then(start_shape_of(i_p8.clone()), move |shape_of_6117: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &s_p7, &shape_of_6117))))
            },
            _ => prism_rtl::Turn::Finished(Text::lit("?")),
        }
    }
}

/// `Start ShapeOf, x`: what the function value is when passed to `@Run`.
pub fn start_shape_of(t_p0: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShapeOf { t_p0 })
}

/// ```prism
/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
/// ```
pub fn check_orphan(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, i_p2: &crate::check::env::ImplInfo) -> crate::check::types::St {
    let trait_mod_p3 = or(&get(&g_p0.traits, &i_p2.cls), &dummy_trait()).home.clone();
    let owners_p4 = each(&type_names_in(&i_p2.head), &(|n_p5: &Text| or(&get(&g_p0.types, n_p5), &crate::check::env::names::dummy_ty_info()).home.clone()));
    if (i_p2.derived || (&i_p2.home == &trait_mod_p3)) || crate::check::types::has_text(&owners_p4, &i_p2.home) {
        st_p1.clone()
    } else {
        {
            let s_p6 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file = i_p2.file.clone();
                this
            };
            crate::check::types::recording::err_fix(&s_p6, &Text::lit("orphan"), &i_p2.span, &Text::from(format!("{} declares neither `^{}` nor `{}`", &(if &i_p2.home == &Text::lit("") {
                Text::lit("this file")
            } else {
                Text::from(format!("`{}`", &i_p2.home))
            }), &crate::check::types::bare_name(&i_p2.cls), &crate::check::types::show_ty(&s_p6, &i_p2.head))), &Text::lit("wrap the type in a newtype of this module, or move the impl"))
        }
    }
}

/// The step machine of `CheckOrphan`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
/// ```
pub struct CheckOrphan {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub i_p2: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckOrphan {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let i_p2 = &self.i_p2;
        let trait_mod_p3 = or(&get(&g_p0.traits, &i_p2.cls), &dummy_trait()).home.clone();
        let g_p0 = g_p0.clone();
        let i_p2 = i_p2.clone();
        let st_p1 = st_p1.clone();
        call_then(start_type_names_in(i_p2.head.clone()), move |type_names_in_6430: Array<Text>| {
            let owners_p4 = each(&type_names_in_6430, &(|n_p5: &Text| or(&get(&g_p0.types, n_p5), &crate::check::env::names::dummy_ty_info()).home.clone()));
            if (i_p2.derived || (&i_p2.home == &trait_mod_p3)) || crate::check::types::has_text(&owners_p4, &i_p2.home) {
                prism_rtl::Turn::Finished(st_p1.clone())
            } else {
                {
                    let s_p6 = {
                        let mut this: crate::check::types::St = st_p1.clone();
                        this.file = i_p2.file.clone();
                        this
                    };
                    call_then(crate::check::types::start_show_ty(s_p6.clone(), i_p2.head.clone()), move |show_ty_6756: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s_p6, &Text::lit("orphan"), &i_p2.span, &Text::from(format!("{} declares neither `^{}` nor `{}`", &(if &i_p2.home == &Text::lit("") {
                        Text::lit("this file")
                    } else {
                        Text::from(format!("`{}`", &i_p2.home))
                    }), &crate::check::types::bare_name(&i_p2.cls), &show_ty_6756)), &Text::lit("wrap the type in a newtype of this module, or move the impl"))))
                }
            }
        })
    }
}

/// `Start CheckOrphan, x`: what the function value is when passed to `@Run`.
pub fn start_check_orphan(g_p0: crate::check::env::G, st_p1: crate::check::types::St, i_p2: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckOrphan { g_p0, st_p1, i_p2 })
}

/// ```prism
/// let dummyTrait
/// ```
pub fn dummy_trait() -> crate::check::env::TraitInfo {
    crate::check::env::TraitInfo { name: Text::lit(""), home: Text::lit(""), param: Text::lit("a"), supers: Array::new(), methods: Array::new(), defaults: Array::new(), assocs: Array::new(), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// TypeNamesIn: unbounded fn Ty -> [Text]
/// ```
pub fn type_names_in(t_p0: &crate::check::types::Ty) -> Array<Text> {
    match t_p0 {
        crate::check::types::Ty::TyCon(n_p1, args_p2) => run_to_end(fold_job(args_p2.clone(), Array::from(vec![n_p1.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc_p3 = p0;
            let a_p4 = p1;
            call_then(start_type_names_in(a_p4.clone()), move |type_names_in_7119: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_p3, &type_names_in_7119)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyTuple(ts_p5) => run_to_end(fold_job(ts_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc_p6 = p0;
            let a_p7 = p1;
            call_then(start_type_names_in(a_p7.clone()), move |type_names_in_7192: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_p6, &type_names_in_7192)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyArray(e_p8) => type_names_in(&**e_p8),
        crate::check::types::Ty::TyMap(k_p9, v_pa) => crate::check::types::union_texts(&type_names_in(&**k_p9), &type_names_in(&**v_pa)),
        crate::check::types::Ty::TySig(_, i_pb) => type_names_in(&**i_pb),
        crate::check::types::Ty::TyFn(_, ps_pc, r_pd) => run_to_end(fold_job(ps_pc.clone(), type_names_in(&**r_pd), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc_pe = p0;
            let a_pf = p1;
            call_then(start_type_names_in(a_pf.clone()), move |type_names_in_7408: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_pe, &type_names_in_7408)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        _ => Array::new(),
    }
}

/// The step machine of `TypeNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeNamesIn: unbounded fn Ty -> [Text]
/// ```
pub struct TypeNamesIn {
    pub t_p0: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Text>> for TypeNamesIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyCon(n_p1, args_p2) => fold_job(args_p2.clone(), Array::from(vec![n_p1.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                let acc_p3 = p0;
                let a_p4 = p1;
                call_then(start_type_names_in(a_p4.clone()), move |type_names_in_7119: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_p3, &type_names_in_7119)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyTuple(ts_p5) => fold_job(ts_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                let acc_p6 = p0;
                let a_p7 = p1;
                call_then(start_type_names_in(a_p7.clone()), move |type_names_in_7192: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_p6, &type_names_in_7192)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyArray(e_p8) => prism_rtl::Turn::More(Rc::new(TypeNamesIn { t_p0: (**e_p8).clone() })),
            crate::check::types::Ty::TyMap(k_p9, v_pa) => {
                let k_p9 = (**k_p9).clone();
                let v_pa = (**v_pa).clone();
                call_then(start_type_names_in(k_p9.clone()), move |type_names_in_7264: Array<Text>| call_then(start_type_names_in(v_pa.clone()), move |type_names_in_7281: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&type_names_in_7264, &type_names_in_7281))))
            },
            crate::check::types::Ty::TySig(_, i_pb) => prism_rtl::Turn::More(Rc::new(TypeNamesIn { t_p0: (**i_pb).clone() })),
            crate::check::types::Ty::TyFn(_, ps_pc, r_pd) => {
                let ps_pc = ps_pc.clone();
                let r_pd = (**r_pd).clone();
                call_then(start_type_names_in(r_pd.clone()), move |type_names_in_7365: Array<Text>| fold_job(ps_pc.clone(), type_names_in_7365, Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                    let acc_pe = p0;
                    let a_pf = p1;
                    call_then(start_type_names_in(a_pf.clone()), move |type_names_in_7408: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_pe, &type_names_in_7408)))
                }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start TypeNamesIn, x`: what the function value is when passed to `@Run`.
pub fn start_type_names_in(t_p0: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TypeNamesIn { t_p0 })
}

/// ```prism
/// SuperClosure: unbounded fn G, Text -> [Text]
/// ```
pub fn super_closure(g_p0: &crate::check::env::G, cls_p1: &Text) -> Array<Text> {
    run_to_end(fold_job(or(&get(&g_p0.traits, cls_p1), &dummy_trait()).supers.clone(), Array::from(vec![cls_p1.clone()]), {
        let g_p0 = g_p0.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
            let g_p0 = g_p0.clone();
            entered(once_job(move || {
                let acc_p2 = p0;
                let s_p3 = p1;
                call_then(start_super_closure(g_p0.clone(), s_p3.clone()), move |super_closure_7866: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_p2, &super_closure_7866)))
            }))
        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `SuperClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SuperClosure: unbounded fn G, Text -> [Text]
/// ```
pub struct SuperClosure {
    pub g_p0: crate::check::env::G,
    pub cls_p1: Text,
}

impl prism_rtl::Job<Array<Text>> for SuperClosure {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let g_p0 = &self.g_p0;
        let cls_p1 = &self.cls_p1;
        fold_job(or(&get(&g_p0.traits, cls_p1), &dummy_trait()).supers.clone(), Array::from(vec![cls_p1.clone()]), {
            let g_p0 = g_p0.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                let g_p0 = g_p0.clone();
                entered(once_job(move || {
                    let acc_p2 = p0;
                    let s_p3 = p1;
                    call_then(start_super_closure(g_p0.clone(), s_p3.clone()), move |super_closure_7866: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_p2, &super_closure_7866)))
                }))
            }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start SuperClosure, x`: what the function value is when passed to `@Run`.
pub fn start_super_closure(g_p0: crate::check::env::G, cls_p1: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SuperClosure { g_p0, cls_p1 })
}

/// ```prism
/// WithFile: fn St, Nat -> St
/// ```
pub fn with_file(s_p0: &crate::check::types::St, f_p1: &Nat) -> crate::check::types::St {
    let mut this: crate::check::types::St = s_p0.clone();
    this.file = f_p1.clone();
    this
}

/// ```prism
/// BuiltinHas: fn Text, Text -> Bool
/// ```
pub fn builtin_has(cls_p0: &Text, con_p1: &Text) -> bool {
    let bare_p2 = crate::check::types::bare_name(cls_p0);
    if &bare_p2 == &Text::lit("Num") {
        (((con_p1 == &Text::lit("Nat")) || (con_p1 == &Text::lit("Int"))) || (con_p1 == &Text::lit("U8"))) || (con_p1 == &Text::lit("Float"))
    } else {
        if (&bare_p2 == &Text::lit("Eq")) || (&bare_p2 == &Text::lit("Show")) {
            (crate::check::env::is_prim_type(con_p1) || (con_p1 == &Text::lit("Fault"))) || (con_p1 == &Text::lit("Prelude.Fault"))
        } else {
            if &bare_p2 == &Text::lit("Ord") {
                ((crate::check::env::is_prim_type(con_p1) && !crate::check::env::is_regex_type(con_p1)) || (con_p1 == &Text::lit("Fault"))) || (con_p1 == &Text::lit("Prelude.Fault"))
            } else {
                false
            }
        }
    }
}

/// ```prism
/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
/// ```
pub fn solve_wants(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, givens_p2: &Array<(Text, Text)>, final_p3: &bool) -> crate::check::types::St {
    let s4_p4 = solve_rounds(g_p0, st_p1, givens_p2, &Nat::from(0u32));
    if *final_p3 { default_wants(g_p0, &s4_p4, givens_p2) } else { s4_p4.clone() }
}

/// The step machine of `SolveWants`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
/// ```
pub struct SolveWants {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub givens_p2: Array<(Text, Text)>,
    pub final_p3: bool,
}

impl prism_rtl::Job<crate::check::types::St> for SolveWants {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let givens_p2 = &self.givens_p2;
        let final_p3 = &self.final_p3;
        let final_p3 = *final_p3;
        let g_p0 = g_p0.clone();
        let givens_p2 = givens_p2.clone();
        let st_p1 = st_p1.clone();
        call_then(start_solve_rounds(g_p0.clone(), st_p1.clone(), givens_p2.clone(), Nat::from(0u32)), move |solve_rounds_9008: crate::check::types::St| {
            let s4_p4 = solve_rounds_9008;
            if final_p3 {
                prism_rtl::Turn::More(Rc::new(DefaultWants { g_p0: g_p0.clone(), st_p1: s4_p4.clone(), givens_p2: givens_p2.clone() }))
            } else {
                prism_rtl::Turn::Finished(s4_p4.clone())
            }
        })
    }
}

/// `Start SolveWants, x`: what the function value is when passed to `@Run`.
pub fn start_solve_wants(g_p0: crate::check::env::G, st_p1: crate::check::types::St, givens_p2: Array<(Text, Text)>, final_p3: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SolveWants { g_p0, st_p1, givens_p2, final_p3 })
}

/// ```prism
/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
/// ```
pub fn solve_rounds(g_p0: &crate::check::env::G, st0_p1: &crate::check::types::St, givens_p2: &Array<(Text, Text)>, round_p3: &Nat) -> crate::check::types::St {
    let st_p4 = resolve_fields(g_p0, &crate::check::types::unify::retry_deferred(st0_p1), &false);
    let cleared_p5 = {
        let mut this: crate::check::types::St = st_p4.clone();
        this.wants = Array::new();
        this
    };
    let (keep_pc, s2_pd) = run_to_end(fold_job(st_p4.wants.clone(), (Array::new(), cleared_p5.clone()), {
        let g_p0 = g_p0.clone();
        let givens_p2 = givens_p2.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)| {
            let g_p0 = g_p0.clone();
            let givens_p2 = givens_p2.clone();
            entered(once_job(move || {
                let (acc_p7, s_p8) = p0;
                let w_p9 = p1;
                call_then(start_solve_one(g_p0.clone(), s_p8.clone(), givens_p2.clone(), w_p9.clone()), move |solve_one_9525: (Array<crate::check::types::Want>, crate::check::types::St)| {
                    let (left_pa, s3_pb) = solve_one_9525;
                    prism_rtl::Turn::Finished((append(&acc_p7, &left_pa), s3_pb.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>>>
    }));
    let s4_p6 = {
        let mut this: crate::check::types::St = s2_pd.clone();
        this.wants = append(&keep_pc, &this.wants);
        this
    };
    if (&s4_p6.wants == &st_p4.wants) || (round_p3 > &Nat::from(6u32)) {
        s4_p6.clone()
    } else {
        solve_rounds(g_p0, &s4_p6, givens_p2, &(round_p3 + &Nat::from(1u32)))
    }
}

/// The step machine of `SolveRounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
/// ```
pub struct SolveRounds {
    pub g_p0: crate::check::env::G,
    pub st0_p1: crate::check::types::St,
    pub givens_p2: Array<(Text, Text)>,
    pub round_p3: Nat,
}

impl prism_rtl::Job<crate::check::types::St> for SolveRounds {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st0_p1 = &self.st0_p1;
        let givens_p2 = &self.givens_p2;
        let round_p3 = &self.round_p3;
        let g_p0 = g_p0.clone();
        let givens_p2 = givens_p2.clone();
        let round_p3 = round_p3.clone();
        let st0_p1 = st0_p1.clone();
        call_then(crate::check::types::unify::start_retry_deferred(st0_p1.clone()), move |retry_deferred_9344: crate::check::types::St| call_then(start_resolve_fields(g_p0.clone(), retry_deferred_9344, false), move |resolve_fields_9326: crate::check::types::St| {
            let st_p4 = resolve_fields_9326;
            let cleared_p5 = {
                let mut this: crate::check::types::St = st_p4.clone();
                this.wants = Array::new();
                this
            };
            call_value(fold_job(st_p4.wants.clone(), (Array::new(), cleared_p5.clone()), {
                let g_p0 = g_p0.clone();
                let givens_p2 = givens_p2.clone();
                Rc::new(move |(p0, p1): ((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)| {
                    let g_p0 = g_p0.clone();
                    let givens_p2 = givens_p2.clone();
                    entered(once_job(move || {
                        let (acc_p7, s_p8) = p0;
                        let w_p9 = p1;
                        call_then(start_solve_one(g_p0.clone(), s_p8.clone(), givens_p2.clone(), w_p9.clone()), move |solve_one_9525: (Array<crate::check::types::Want>, crate::check::types::St)| {
                            let (left_pa, s3_pb) = solve_one_9525;
                            prism_rtl::Turn::Finished((append(&acc_p7, &left_pa), s3_pb.clone()))
                        })
                    }))
                }) as Rc<dyn Fn(((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>>>
            }), move |fold_9447: (Array<crate::check::types::Want>, crate::check::types::St)| {
                let (keep_pc, s2_pd) = fold_9447;
                let s4_p6 = {
                    let mut this: crate::check::types::St = s2_pd.clone();
                    this.wants = append(&keep_pc, &this.wants);
                    this
                };
                if (&s4_p6.wants == &st_p4.wants) || (&round_p3 > &Nat::from(6u32)) {
                    prism_rtl::Turn::Finished(s4_p6.clone())
                } else {
                    prism_rtl::Turn::More(Rc::new(SolveRounds { g_p0: g_p0.clone(), st0_p1: s4_p6.clone(), givens_p2: givens_p2.clone(), round_p3: &round_p3 + &Nat::from(1u32) }))
                }
            })
        }))
    }
}

/// `Start SolveRounds, x`: what the function value is when passed to `@Run`.
pub fn start_solve_rounds(g_p0: crate::check::env::G, st0_p1: crate::check::types::St, givens_p2: Array<(Text, Text)>, round_p3: Nat) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SolveRounds { g_p0, st0_p1, givens_p2, round_p3 })
}

/// ```prism
/// ResolveFields: unbounded fn G, St, Bool -> St
/// ```
pub fn resolve_fields(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, final_p2: &bool) -> crate::check::types::St {
    let qs_p3 = st_p1.field_qs.clone();
    let cleared_p4 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.field_qs = Array::new();
        this
    };
    let done_p5 = run_to_end(fold_job(qs_p3.clone(), cleared_p4.clone(), {
        let g_p0 = g_p0.clone();
        let final_p2 = *final_p2;
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::unify::FieldQ)| {
            let g_p0 = g_p0.clone();
            let final_p2 = final_p2;
            entered(once_job(move || {
                let s_p6 = p0;
                let q_p7 = p1;
                prism_rtl::Turn::More(Rc::new(ResolveField { g_p0: g_p0.clone(), st_p1: s_p6.clone(), q_p2: q_p7.clone(), final_p3: final_p2 }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::unify::FieldQ)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    with_file(&done_p5, &st_p1.file)
}

/// The step machine of `ResolveFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveFields: unbounded fn G, St, Bool -> St
/// ```
pub struct ResolveFields {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub final_p2: bool,
}

impl prism_rtl::Job<crate::check::types::St> for ResolveFields {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let final_p2 = &self.final_p2;
        let qs_p3 = st_p1.field_qs.clone();
        let cleared_p4 = {
            let mut this: crate::check::types::St = st_p1.clone();
            this.field_qs = Array::new();
            this
        };
        let final_p2 = *final_p2;
        let g_p0 = g_p0.clone();
        let st_p1 = st_p1.clone();
        call_value(fold_job(qs_p3.clone(), cleared_p4.clone(), {
            let g_p0 = g_p0.clone();
            let final_p2 = final_p2;
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::unify::FieldQ)| {
                let g_p0 = g_p0.clone();
                let final_p2 = final_p2;
                entered(once_job(move || {
                    let s_p6 = p0;
                    let q_p7 = p1;
                    prism_rtl::Turn::More(Rc::new(ResolveField { g_p0: g_p0.clone(), st_p1: s_p6.clone(), q_p2: q_p7.clone(), final_p3: final_p2 }))
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::unify::FieldQ)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }), move |fold_10049: crate::check::types::St| {
            let done_p5 = fold_10049;
            prism_rtl::Turn::Finished(with_file(&done_p5, &st_p1.file))
        })
    }
}

/// `Start ResolveFields, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_fields(g_p0: crate::check::env::G, st_p1: crate::check::types::St, final_p2: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ResolveFields { g_p0, st_p1, final_p2 })
}

/// ```prism
/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
/// ```
pub fn resolve_field(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, q_p2: &crate::check::types::unify::FieldQ, final_p3: &bool) -> crate::check::types::St {
    let s_p4 = with_file(st_p1, &q_p2.file);
    match crate::check::types::recording::walk(&s_p4, &q_p2.recv) {
        crate::check::types::Ty::TyCon(n_p5, args_p6) => match get(&g_p0.ctors, &n_p5) {
            Some(c_p7) => {
                let i_o8 = fold(&crate::check::errors::range0(&len(&c_p7.fields)), &None, &(|at_o9: &Option<Nat>, k_pa: &Nat| if &index(&c_p7.fields, k_pa) == &Some(q_p2.field.clone()) {
                    Some(k_pa.clone())
                } else {
                    at_o9.clone()
                }));
                match &i_o8 {
                    Some(i_pb) => crate::check::types::unify::unify(&s_p4, &q_p2.result, &crate::check::types::schemes::subst_q(&crate::check::env::reading::param_inst(&c_p7.params, &args_p6), &or(&index(&c_p7.args, i_pb), &crate::check::types::Ty::TyErr)), &q_p2.span),
                    None => crate::check::types::recording::err(&s_p4, &Text::lit("mismatch"), &q_p2.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&n_p5), &q_p2.field))),
                }
            },
            None => crate::check::types::recording::err(&s_p4, &Text::lit("mismatch"), &q_p2.span, &Text::from(format!("`{}` has no fields", &crate::check::types::bare_name(&n_p5)))),
        },
        crate::check::types::Ty::TyFlex(_) => if *final_p3 {
            crate::check::types::recording::err_fix(&s_p4, &Text::lit("ambiguous"), &q_p2.span, &Text::from(format!("nothing decides which record `.{}` reads: {} have it", &q_p2.field, &crate::syntax::lexer::chars::join(&each(&q_p2.owners, &(|o_pc: &Text| Text::from(format!("`{}`", o_pc)))), &Text::lit(", ")))), &Text::lit("annotate the value\'s type, or name it from a signature"))
        } else {
            {
                let mut this: crate::check::types::St = s_p4.clone();
                this.field_qs = push(&this.field_qs, q_p2);
                this
            }
        },
        crate::check::types::Ty::TyErr => s_p4.clone(),
        other_pd => crate::check::types::recording::err(&s_p4, &Text::lit("mismatch"), &q_p2.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::show_ty(&s_p4, &other_pd), &q_p2.field))),
    }
}

/// The step machine of `ResolveField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
/// ```
pub struct ResolveField {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub q_p2: crate::check::types::unify::FieldQ,
    pub final_p3: bool,
}

impl prism_rtl::Job<crate::check::types::St> for ResolveField {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let q_p2 = &self.q_p2;
        let final_p3 = &self.final_p3;
        let s_p4 = with_file(st_p1, &q_p2.file);
        let final_p3 = *final_p3;
        let g_p0 = g_p0.clone();
        let q_p2 = q_p2.clone();
        call_then(crate::check::types::recording::start_walk(s_p4.clone(), q_p2.recv.clone()), move |walk_10259: crate::check::types::Ty| match walk_10259 {
            crate::check::types::Ty::TyCon(n_p5, args_p6) => match get(&g_p0.ctors, &n_p5) {
                Some(c_p7) => {
                    let i_o8 = fold(&crate::check::errors::range0(&len(&c_p7.fields)), &None, &(|at_o9: &Option<Nat>, k_pa: &Nat| if &index(&c_p7.fields, k_pa) == &Some(q_p2.field.clone()) {
                        Some(k_pa.clone())
                    } else {
                        at_o9.clone()
                    }));
                    match &i_o8 {
                        Some(i_pb) => {
                            let i_pb = i_pb.clone();
                            call_then(crate::check::types::schemes::start_subst_q(crate::check::env::reading::param_inst(&c_p7.params, &args_p6), or(&index(&c_p7.args, &i_pb), &crate::check::types::Ty::TyErr)), move |subst_q_10517: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: s_p4.clone(), expected_p1: q_p2.result.clone(), found_p2: subst_q_10517, span_p3: q_p2.span.clone() })))
                        },
                        None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s_p4, &Text::lit("mismatch"), &q_p2.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&n_p5), &q_p2.field)))),
                    }
                },
                None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s_p4, &Text::lit("mismatch"), &q_p2.span, &Text::from(format!("`{}` has no fields", &crate::check::types::bare_name(&n_p5))))),
            },
            crate::check::types::Ty::TyFlex(_) => if final_p3 {
                prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s_p4, &Text::lit("ambiguous"), &q_p2.span, &Text::from(format!("nothing decides which record `.{}` reads: {} have it", &q_p2.field, &crate::syntax::lexer::chars::join(&each(&q_p2.owners, &(|o_pc: &Text| Text::from(format!("`{}`", o_pc)))), &Text::lit(", ")))), &Text::lit("annotate the value\'s type, or name it from a signature")))
            } else {
                prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = s_p4.clone();
                    this.field_qs = push(&this.field_qs, &q_p2);
                    this
                })
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished(s_p4.clone()),
            other_pd => call_then(crate::check::types::start_show_ty(s_p4.clone(), other_pd.clone()), move |show_ty_11127: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err(&s_p4, &Text::lit("mismatch"), &q_p2.span, &Text::from(format!("`{}` has no field `{}`", &show_ty_11127, &q_p2.field))))),
        })
    }
}

/// `Start ResolveField, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_field(g_p0: crate::check::env::G, st_p1: crate::check::types::St, q_p2: crate::check::types::unify::FieldQ, final_p3: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ResolveField { g_p0, st_p1, q_p2, final_p3 })
}

/// ```prism
/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
/// ```
pub fn solve_one(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, givens_p2: &Array<(Text, Text)>, w_p3: &crate::check::types::Want) -> (Array<crate::check::types::Want>, crate::check::types::St) {
    let t_p4 = crate::check::types::recording::walk(st_p1, &w_p3.ty);
    let s0_p5 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.file = w_p3.file.clone();
        this
    };
    let restore_f6 = {
        let st_p1 = st_p1.clone();
        Rc::new(move |s_p7: &crate::check::types::St| with_file(s_p7, &st_p1.file)) as Rc<dyn Fn(&crate::check::types::St) -> crate::check::types::St>
    };
    match &t_p4 {
        crate::check::types::Ty::TyFlex(_) => (Array::from(vec![w_p3.clone()]), st_p1.clone()),
        crate::check::types::Ty::TyErr => (Array::new(), st_p1.clone()),
        crate::check::types::Ty::TyRigid(v_p8) => if (crate::syntax::lexer::chars::has_prefix(&w_p3.cls, &Text::lit("Range ")) || (&w_p3.cls == &Text::lit("Prelude.Sub"))) || (&w_p3.cls == &Text::lit("Prelude.Signed")) {
            (Array::new(), st_p1.clone())
        } else {
            if run_to_end(fold_job(givens_p2.clone(), false, {
                let v_p8 = v_p8.clone();
                let g_p0 = g_p0.clone();
                let w_p3 = w_p3.clone();
                Rc::new(move |(p0, p1): (bool, (Text, Text))| {
                    let v_p8 = v_p8.clone();
                    let g_p0 = g_p0.clone();
                    let w_p3 = w_p3.clone();
                    entered(once_job(move || {
                        let seen_p9 = p0;
                        let (gv_pa, gc_pb) = p1;
                        prism_rtl::Turn::Finished(seen_p9 || ((&gv_pa == &v_p8) && crate::check::types::has_text(&super_closure(&g_p0, &gc_pb), &w_p3.cls)))
                    }))
                }) as Rc<dyn Fn((bool, (Text, Text))) -> Rc<dyn prism_rtl::Job<bool>>>
            })) {
                (Array::new(), solved(st_p1, w_p3, &t_p4, &Text::lit("given")))
            } else {
                (Array::new(), (&restore_f6)(&crate::check::types::recording::err_fix(&s0_p5, &Text::lit("no-impl"), &w_p3.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w_p3.cls), v_p8)), &Text::from(format!("add `where {}: ^{}` to the signature", v_p8, &crate::check::types::bare_name(&w_p3.cls))))))
            }
        },
        crate::check::types::Ty::TySig(s_pc, inner_pd) => if ((s_pc == &Text::lit("?")) || (s_pc == &Text::lit("~"))) && crate::check::types::has_text(&Array::from(vec![Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")]), &crate::check::types::bare_name(&w_p3.cls)) {
            (Array::from(vec![crate::check::types::Want { cls: w_p3.cls.clone(), ty: (**inner_pd).clone(), file: w_p3.file.clone(), span: w_p3.span.clone(), level: w_p3.level.clone() }]), solved(st_p1, w_p3, &t_p4, &Text::lit("parts")))
        } else {
            (Array::new(), (&restore_f6)(&crate::check::types::recording::err_fix(&s0_p5, &Text::lit("no-impl"), &w_p3.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w_p3.cls), &crate::check::types::show_ty(st_p1, &t_p4))), &Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first"))))
        },
        crate::check::types::Ty::TyAt(_, _) => (Array::new(), (&restore_f6)(&crate::check::types::recording::err(&s0_p5, &Text::lit("no-impl"), &w_p3.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w_p3.cls), &crate::check::types::show_ty(st_p1, &t_p4)))))),
        crate::check::types::Ty::TyFn(_, _, _) => (Array::new(), (&restore_f6)(&crate::check::types::recording::err(&s0_p5, &Text::lit("no-impl"), &w_p3.span, &Text::from(format!("no impl of `^{}` for `{}`: functions do not compare or print", &crate::check::types::bare_name(&w_p3.cls), &crate::check::types::show_ty(st_p1, &t_p4)))))),
        _ => solve_at_head(g_p0, st_p1, &s0_p5, &{
            let f = restore_f6.clone();
            Rc::new(move |a0: crate::check::types::St| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }, givens_p2, w_p3, &t_p4),
    }
}

/// The step machine of `SolveOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
/// ```
pub struct SolveOne {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub givens_p2: Array<(Text, Text)>,
    pub w_p3: crate::check::types::Want,
}

impl prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)> for SolveOne {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Want>, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let givens_p2 = &self.givens_p2;
        let w_p3 = &self.w_p3;
        let g_p0 = g_p0.clone();
        let givens_p2 = givens_p2.clone();
        let st_p1 = st_p1.clone();
        let w_p3 = w_p3.clone();
        call_then(crate::check::types::recording::start_walk(st_p1.clone(), w_p3.ty.clone()), move |walk_11375: crate::check::types::Ty| {
            let t_p4 = walk_11375;
            let s0_p5 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file = w_p3.file.clone();
                this
            };
            let restore_f6 = {
                let st_p1 = st_p1.clone();
                Rc::new(move |s_p7: &crate::check::types::St| with_file(s_p7, &st_p1.file)) as Rc<dyn Fn(&crate::check::types::St) -> crate::check::types::St>
            };
            match &t_p4 {
                crate::check::types::Ty::TyFlex(_) => prism_rtl::Turn::Finished((Array::from(vec![w_p3.clone()]), st_p1.clone())),
                crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished((Array::new(), st_p1.clone())),
                crate::check::types::Ty::TyRigid(v_p8) => if (crate::syntax::lexer::chars::has_prefix(&w_p3.cls, &Text::lit("Range ")) || (&w_p3.cls == &Text::lit("Prelude.Sub"))) || (&w_p3.cls == &Text::lit("Prelude.Signed")) {
                    prism_rtl::Turn::Finished((Array::new(), st_p1.clone()))
                } else {
                    {
                        let v_p8 = v_p8.clone();
                        call_value(fold_job(givens_p2.clone(), false, {
                            let v_p8 = v_p8.clone();
                            let g_p0 = g_p0.clone();
                            let w_p3 = w_p3.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, Text))| {
                                let v_p8 = v_p8.clone();
                                let g_p0 = g_p0.clone();
                                let w_p3 = w_p3.clone();
                                entered(once_job(move || {
                                    let seen_p9 = p0;
                                    let (gv_pa, gc_pb) = p1;
                                    prism_rtl::Turn::Finished(seen_p9 || ((&gv_pa == &v_p8) && crate::check::types::has_text(&super_closure(&g_p0, &gc_pb), &w_p3.cls)))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, Text))) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |fold_11712: bool| if fold_11712 {
                            prism_rtl::Turn::Finished((Array::new(), solved(&st_p1, &w_p3, &t_p4, &Text::lit("given"))))
                        } else {
                            prism_rtl::Turn::Finished((Array::new(), (&restore_f6)(&crate::check::types::recording::err_fix(&s0_p5, &Text::lit("no-impl"), &w_p3.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w_p3.cls), &v_p8)), &Text::from(format!("add `where {}: ^{}` to the signature", &v_p8, &crate::check::types::bare_name(&w_p3.cls)))))))
                        })
                    }
                },
                crate::check::types::Ty::TySig(s_pc, inner_pd) => if ((s_pc == &Text::lit("?")) || (s_pc == &Text::lit("~"))) && crate::check::types::has_text(&Array::from(vec![Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")]), &crate::check::types::bare_name(&w_p3.cls)) {
                    prism_rtl::Turn::Finished((Array::from(vec![crate::check::types::Want { cls: w_p3.cls.clone(), ty: (**inner_pd).clone(), file: w_p3.file.clone(), span: w_p3.span.clone(), level: w_p3.level.clone() }]), solved(&st_p1, &w_p3, &t_p4, &Text::lit("parts"))))
                } else {
                    call_then(crate::check::types::start_show_ty(st_p1.clone(), t_p4.clone()), move |show_ty_12339: Text| prism_rtl::Turn::Finished((Array::new(), (&restore_f6)(&crate::check::types::recording::err_fix(&s0_p5, &Text::lit("no-impl"), &w_p3.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w_p3.cls), &show_ty_12339)), &Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first"))))))
                },
                crate::check::types::Ty::TyAt(_, _) => call_then(crate::check::types::start_show_ty(st_p1.clone(), t_p4.clone()), move |show_ty_12561: Text| prism_rtl::Turn::Finished((Array::new(), (&restore_f6)(&crate::check::types::recording::err(&s0_p5, &Text::lit("no-impl"), &w_p3.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w_p3.cls), &show_ty_12561))))))),
                crate::check::types::Ty::TyFn(_, _, _) => call_then(crate::check::types::start_show_ty(st_p1.clone(), t_p4.clone()), move |show_ty_12699: Text| prism_rtl::Turn::Finished((Array::new(), (&restore_f6)(&crate::check::types::recording::err(&s0_p5, &Text::lit("no-impl"), &w_p3.span, &Text::from(format!("no impl of `^{}` for `{}`: functions do not compare or print", &crate::check::types::bare_name(&w_p3.cls), &show_ty_12699))))))),
                _ => prism_rtl::Turn::More(Rc::new(SolveAtHead { g_p0: g_p0.clone(), st_p1: st_p1.clone(), s0_p2: s0_p5.clone(), restore_f3: {
                    let f = restore_f6.clone();
                    Rc::new(move |a0: crate::check::types::St| {
                        let f = f.clone();
                        once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                    }) as Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                }, givens_p4: givens_p2.clone(), w_p5: w_p3.clone(), t_p6: t_p4.clone() })),
            }
        })
    }
}

/// `Start SolveOne, x`: what the function value is when passed to `@Run`.
pub fn start_solve_one(g_p0: crate::check::env::G, st_p1: crate::check::types::St, givens_p2: Array<(Text, Text)>, w_p3: crate::check::types::Want) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>> {
    Rc::new(SolveOne { g_p0, st_p1, givens_p2, w_p3 })
}

/// ```prism
/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub fn solve_at_head(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, s0_p2: &crate::check::types::St, restore_f3: &Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens_p4: &Array<(Text, Text)>, w_p5: &crate::check::types::Want, t_p6: &crate::check::types::Ty) -> (Array<crate::check::types::Want>, crate::check::types::St) {
    if crate::syntax::lexer::chars::has_prefix(&w_p5.cls, &Text::lit("Range ")) {
        (Array::new(), run_to_end(restore_f3(literal_range(s0_p2, w_p5, t_p6))))
    } else {
        if (&w_p5.cls == &Text::lit("Prelude.Sub")) || (&w_p5.cls == &Text::lit("Prelude.Signed")) {
            (Array::new(), run_to_end(restore_f3(signed_at(s0_p2, w_p5, t_p6))))
        } else {
            solve_class(g_p0, st_p1, s0_p2, &restore_f3.clone(), givens_p4, w_p5, t_p6)
        }
    }
}

/// The step machine of `SolveAtHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub struct SolveAtHead {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub s0_p2: crate::check::types::St,
    pub restore_f3: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>,
    pub givens_p4: Array<(Text, Text)>,
    pub w_p5: crate::check::types::Want,
    pub t_p6: crate::check::types::Ty,
}

impl prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)> for SolveAtHead {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Want>, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let s0_p2 = &self.s0_p2;
        let restore_f3 = &self.restore_f3;
        let givens_p4 = &self.givens_p4;
        let w_p5 = &self.w_p5;
        let t_p6 = &self.t_p6;
        if crate::syntax::lexer::chars::has_prefix(&w_p5.cls, &Text::lit("Range ")) {
            {
                let restore_f3 = restore_f3.clone();
                let s0_p2 = s0_p2.clone();
                let t_p6 = t_p6.clone();
                let w_p5 = w_p5.clone();
                call_then(start_literal_range(s0_p2.clone(), w_p5.clone(), t_p6.clone()), move |literal_range_13017: crate::check::types::St| call_value((&restore_f3)(literal_range_13017), move |restore_13008: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_13008))))
            }
        } else {
            if (&w_p5.cls == &Text::lit("Prelude.Sub")) || (&w_p5.cls == &Text::lit("Prelude.Signed")) {
                {
                    let restore_f3 = restore_f3.clone();
                    let s0_p2 = s0_p2.clone();
                    let t_p6 = t_p6.clone();
                    let w_p5 = w_p5.clone();
                    call_then(start_signed_at(s0_p2.clone(), w_p5.clone(), t_p6.clone()), move |signed_at_13125: crate::check::types::St| call_value((&restore_f3)(signed_at_13125), move |restore_13116: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_13116))))
                }
            } else {
                prism_rtl::Turn::More(Rc::new(SolveClass { g_p0: g_p0.clone(), st_p1: st_p1.clone(), s0_p2: s0_p2.clone(), restore_f3: restore_f3.clone(), givens_p4: givens_p4.clone(), w_p5: w_p5.clone(), t_p6: t_p6.clone() }))
            }
        }
    }
}

/// `Start SolveAtHead, x`: what the function value is when passed to `@Run`.
pub fn start_solve_at_head(g_p0: crate::check::env::G, st_p1: crate::check::types::St, s0_p2: crate::check::types::St, restore_f3: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens_p4: Array<(Text, Text)>, w_p5: crate::check::types::Want, t_p6: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>> {
    Rc::new(SolveAtHead { g_p0, st_p1, s0_p2, restore_f3, givens_p4, w_p5, t_p6 })
}

/// ```prism
/// LiteralRange: unbounded fn St, Want, Ty -> St
/// ```
pub fn literal_range(st_p0: &crate::check::types::St, w_p1: &crate::check::types::Want, t_p2: &crate::check::types::Ty) -> crate::check::types::St {
    let lit_p3 = crate::syntax::lexer::chars::drop_prefix(&w_p1.cls, &Text::lit("Range "));
    let negative_p4 = crate::syntax::lexer::chars::has_prefix(&lit_p3, &Text::lit("-"));
    let digits_p5 = if negative_p4 {
        crate::syntax::lexer::chars::after_first(&lit_p3)
    } else {
        lit_p3.clone()
    };
    let n_o6 = parse_nat_opt(&digits_p5);
    match t_p2 {
        crate::check::types::Ty::TyCon(m13523_0_0, m13523_0_1) if (m13523_0_0 == &Text::lit("Nat")) && (m13523_0_1.len() == 0) => if negative_p4 && (&digits_p5 != &Text::lit("0")) {
            crate::check::types::recording::err(st_p0, &Text::lit("literal-range"), &w_p1.span, &Text::from(format!("`{}` does not fit `Nat`", &lit_p3)))
        } else {
            st_p0.clone()
        },
        crate::check::types::Ty::TyCon(m13523_1_0, m13523_1_1) if (m13523_1_0 == &Text::lit("U8")) && (m13523_1_1.len() == 0) => match &n_o6 {
            Some(v_p7) => if negative_p4 || (v_p7 > &Nat::from(255u32)) {
                crate::check::types::recording::err(st_p0, &Text::lit("literal-range"), &w_p1.span, &Text::from(format!("`{}` does not fit `U8`", &lit_p3)))
            } else {
                st_p0.clone()
            },
            None => st_p0.clone(),
        },
        _ => st_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LiteralRange`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralRange: unbounded fn St, Want, Ty -> St
/// ```
pub struct LiteralRange {
    pub st_p0: crate::check::types::St,
    pub w_p1: crate::check::types::Want,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for LiteralRange {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let w_p1 = &self.w_p1;
        let t_p2 = &self.t_p2;
        let lit_p3 = crate::syntax::lexer::chars::drop_prefix(&w_p1.cls, &Text::lit("Range "));
        let negative_p4 = crate::syntax::lexer::chars::has_prefix(&lit_p3, &Text::lit("-"));
        let digits_p5 = if negative_p4 {
            crate::syntax::lexer::chars::after_first(&lit_p3)
        } else {
            lit_p3.clone()
        };
        let n_o6 = parse_nat_opt(&digits_p5);
        match t_p2 {
            crate::check::types::Ty::TyCon(m13523_0_0, m13523_0_1) if (m13523_0_0 == &Text::lit("Nat")) && (m13523_0_1.len() == 0) => if negative_p4 && (&digits_p5 != &Text::lit("0")) {
                prism_rtl::Turn::Finished(crate::check::types::recording::err(st_p0, &Text::lit("literal-range"), &w_p1.span, &Text::from(format!("`{}` does not fit `Nat`", &lit_p3))))
            } else {
                prism_rtl::Turn::Finished(st_p0.clone())
            },
            crate::check::types::Ty::TyCon(m13523_1_0, m13523_1_1) if (m13523_1_0 == &Text::lit("U8")) && (m13523_1_1.len() == 0) => match &n_o6 {
                Some(v_p7) => if negative_p4 || (v_p7 > &Nat::from(255u32)) {
                    prism_rtl::Turn::Finished(crate::check::types::recording::err(st_p0, &Text::lit("literal-range"), &w_p1.span, &Text::from(format!("`{}` does not fit `U8`", &lit_p3))))
                } else {
                    prism_rtl::Turn::Finished(st_p0.clone())
                },
                None => prism_rtl::Turn::Finished(st_p0.clone()),
            },
            _ => prism_rtl::Turn::Finished(st_p0.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LiteralRange, x`: what the function value is when passed to `@Run`.
pub fn start_literal_range(st_p0: crate::check::types::St, w_p1: crate::check::types::Want, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(LiteralRange { st_p0, w_p1, t_p2 })
}

/// ```prism
/// SignedAt: unbounded fn St, Want, Ty -> St
/// ```
pub fn signed_at(st_p0: &crate::check::types::St, w_p1: &crate::check::types::Want, t_p2: &crate::check::types::Ty) -> crate::check::types::St {
    match t_p2 {
        crate::check::types::Ty::TyCon(m13994_0_0, m13994_0_1) if (m13994_0_0 == &Text::lit("Nat")) && (m13994_0_1.len() == 0) => if &w_p1.cls == &Text::lit("Prelude.Sub") {
            crate::check::types::recording::err_fix(st_p0, &Text::lit("nat-minus"), &w_p1.span, &Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), &Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`"))
        } else {
            st_p0.clone()
        },
        crate::check::types::Ty::TyCon(m13994_1_0, m13994_1_1) if (m13994_1_0 == &Text::lit("U8")) && (m13994_1_1.len() == 0) => if &w_p1.cls == &Text::lit("Prelude.Sub") { st_p0.clone() } else { st_p0.clone() },
        _ => st_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SignedAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SignedAt: unbounded fn St, Want, Ty -> St
/// ```
pub struct SignedAt {
    pub st_p0: crate::check::types::St,
    pub w_p1: crate::check::types::Want,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for SignedAt {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let w_p1 = &self.w_p1;
        let t_p2 = &self.t_p2;
        match t_p2 {
            crate::check::types::Ty::TyCon(m13994_0_0, m13994_0_1) if (m13994_0_0 == &Text::lit("Nat")) && (m13994_0_1.len() == 0) => if &w_p1.cls == &Text::lit("Prelude.Sub") {
                prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(st_p0, &Text::lit("nat-minus"), &w_p1.span, &Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), &Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`")))
            } else {
                prism_rtl::Turn::Finished(st_p0.clone())
            },
            crate::check::types::Ty::TyCon(m13994_1_0, m13994_1_1) if (m13994_1_0 == &Text::lit("U8")) && (m13994_1_1.len() == 0) => if &w_p1.cls == &Text::lit("Prelude.Sub") {
                prism_rtl::Turn::Finished(st_p0.clone())
            } else {
                prism_rtl::Turn::Finished(st_p0.clone())
            },
            _ => prism_rtl::Turn::Finished(st_p0.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SignedAt, x`: what the function value is when passed to `@Run`.
pub fn start_signed_at(st_p0: crate::check::types::St, w_p1: crate::check::types::Want, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SignedAt { st_p0, w_p1, t_p2 })
}

/// ```prism
/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub fn solve_class(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, s0_p2: &crate::check::types::St, restore_f3: &Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens_p4: &Array<(Text, Text)>, w_p5: &crate::check::types::Want, t_p6: &crate::check::types::Ty) -> (Array<crate::check::types::Want>, crate::check::types::St) {
    let bare_p7 = crate::check::types::bare_name(&w_p5.cls);
    let parts_o8 = match t_p6 {
        crate::check::types::Ty::TyTuple(ts_pa) => Some(ts_pa.clone()),
        crate::check::types::Ty::TyArray(e_pb) => Some(Array::from(vec![(**e_pb).clone()])),
        crate::check::types::Ty::TyMap(k_pc, v_pd) => Some(Array::from(vec![(**k_pc).clone(), (**v_pd).clone()])),
        _ => None,
    };
    let structural_p9 = ((&bare_p7 == &Text::lit("Eq")) || (&bare_p7 == &Text::lit("Ord"))) || (&bare_p7 == &Text::lit("Show"));
    match &parts_o8 {
        Some(ps_pe) => if structural_p9 {
            (each(ps_pe, &(|p_pf: &crate::check::types::Ty| crate::check::types::Want { cls: w_p5.cls.clone(), ty: p_pf.clone(), file: w_p5.file.clone(), span: w_p5.span.clone(), level: w_p5.level.clone() })), solved(st_p1, w_p5, t_p6, &Text::lit("parts")))
        } else {
            (Array::new(), run_to_end(restore_f3(crate::check::types::recording::err(s0_p2, &Text::lit("no-impl"), &w_p5.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &crate::check::types::show_ty(st_p1, t_p6)))))))
        },
        None => match t_p6 {
            crate::check::types::Ty::TySig(_, _) => (Array::new(), st_p1.clone()),
            crate::check::types::Ty::TyElem(rw_pg, _) => elem_trait(g_p0, st_p1, s0_p2, &restore_f3.clone(), w_p5, t_p6, &bare_p7, rw_pg),
            crate::check::types::Ty::TyElemAny(rw_ph) => elem_trait(g_p0, st_p1, s0_p2, &restore_f3.clone(), w_p5, t_p6, &bare_p7, rw_ph),
            crate::check::types::Ty::TyAny(trs_pi) => if crate::check::types::has_text(trs_pi, &w_p5.cls) || run_to_end(fold_job(trs_pi.clone(), false, {
                let g_p0 = g_p0.clone();
                let w_p5 = w_p5.clone();
                Rc::new(move |(p0, p1): (bool, Text)| {
                    let g_p0 = g_p0.clone();
                    let w_p5 = w_p5.clone();
                    entered(once_job(move || {
                        let seen_pj = p0;
                        let tr_pk = p1;
                        prism_rtl::Turn::Finished(seen_pj || crate::check::types::has_text(&super_closure(&g_p0, &tr_pk), &w_p5.cls))
                    }))
                }) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>
            })) {
                (Array::new(), solved(st_p1, w_p5, t_p6, &Text::lit("packed")))
            } else {
                (Array::new(), run_to_end(restore_f3(crate::check::types::recording::err(s0_p2, &Text::lit("no-impl"), &w_p5.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &crate::check::types::show_ty(st_p1, t_p6)))))))
            },
            crate::check::types::Ty::TyCon(con_pl, args_pm) => if builtin_has(&w_p5.cls, con_pl) {
                (Array::new(), solved(st_p1, w_p5, t_p6, &Text::lit("builtin")))
            } else {
                match find_impl(g_p0, st_p1, &w_p5.cls, t_p6) {
                    Some((im_pn, s2_po, how_pp, ch_pq)) => {
                        let wants_pr = each(&im_pn, &(|(ty_ps, cls_pt): &(crate::check::types::Ty, Text)| crate::check::types::Want { cls: cls_pt.clone(), ty: ty_ps.clone(), file: w_p5.file.clone(), span: w_p5.span.clone(), level: w_p5.level.clone() }));
                        (wants_pr.clone(), crate::check::types::recording::note_choice(&solved(&s2_po, w_p5, t_p6, &how_pp), &w_p5.file, &w_p5.span, &w_p5.cls, &ch_pq))
                    },
                    None => {
                        let fix_pu = if ((&bare_p7 == &Text::lit("Num")) && (con_pl == &Text::lit("Text"))) || crate::check::env::is_regex_type(con_pl) {
                            Text::lit("")
                        } else {
                            Text::from(format!("derive `^{}` on `{}`, or write `impl ^{} {}`", &bare_p7, &crate::check::types::bare_name(con_pl), &bare_p7, &crate::check::types::bare_name(con_pl)))
                        };
                        (Array::new(), run_to_end(restore_f3(crate::check::types::recording::err_fix(s0_p2, &Text::lit("no-impl"), &w_p5.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &crate::check::types::show_ty(st_p1, t_p6))), &fix_pu))))
                    },
                }
            },
            _ => (Array::new(), st_p1.clone()),
        },
    }
}

/// The step machine of `SolveClass`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub struct SolveClass {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub s0_p2: crate::check::types::St,
    pub restore_f3: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>,
    pub givens_p4: Array<(Text, Text)>,
    pub w_p5: crate::check::types::Want,
    pub t_p6: crate::check::types::Ty,
}

impl prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)> for SolveClass {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Want>, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let s0_p2 = &self.s0_p2;
        let restore_f3 = &self.restore_f3;
        let givens_p4 = &self.givens_p4;
        let w_p5 = &self.w_p5;
        let t_p6 = &self.t_p6;
        let bare_p7 = crate::check::types::bare_name(&w_p5.cls);
        let parts_o8 = match t_p6 {
            crate::check::types::Ty::TyTuple(ts_pa) => Some(ts_pa.clone()),
            crate::check::types::Ty::TyArray(e_pb) => Some(Array::from(vec![(**e_pb).clone()])),
            crate::check::types::Ty::TyMap(k_pc, v_pd) => Some(Array::from(vec![(**k_pc).clone(), (**v_pd).clone()])),
            _ => None,
        };
        let structural_p9 = ((&bare_p7 == &Text::lit("Eq")) || (&bare_p7 == &Text::lit("Ord"))) || (&bare_p7 == &Text::lit("Show"));
        match &parts_o8 {
            Some(ps_pe) => if structural_p9 {
                prism_rtl::Turn::Finished((each(ps_pe, &(|p_pf: &crate::check::types::Ty| crate::check::types::Want { cls: w_p5.cls.clone(), ty: p_pf.clone(), file: w_p5.file.clone(), span: w_p5.span.clone(), level: w_p5.level.clone() })), solved(st_p1, w_p5, t_p6, &Text::lit("parts"))))
            } else {
                {
                    let restore_f3 = restore_f3.clone();
                    let s0_p2 = s0_p2.clone();
                    let st_p1 = st_p1.clone();
                    let t_p6 = t_p6.clone();
                    let w_p5 = w_p5.clone();
                    call_then(crate::check::types::start_show_ty(st_p1.clone(), t_p6.clone()), move |show_ty_14922: Text| call_value((&restore_f3)(crate::check::types::recording::err(&s0_p2, &Text::lit("no-impl"), &w_p5.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &show_ty_14922)))), move |restore_14858: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_14858))))
                }
            },
            None => match t_p6 {
                crate::check::types::Ty::TySig(_, _) => prism_rtl::Turn::Finished((Array::new(), st_p1.clone())),
                crate::check::types::Ty::TyElem(rw_pg, _) => prism_rtl::Turn::More(Rc::new(ElemTrait { g_p0: g_p0.clone(), st_p1: st_p1.clone(), s0_p2: s0_p2.clone(), restore_f3: restore_f3.clone(), w_p4: w_p5.clone(), t_p5: t_p6.clone(), bare_p6: bare_p7.clone(), rw_p7: rw_pg.clone() })),
                crate::check::types::Ty::TyElemAny(rw_ph) => prism_rtl::Turn::More(Rc::new(ElemTrait { g_p0: g_p0.clone(), st_p1: st_p1.clone(), s0_p2: s0_p2.clone(), restore_f3: restore_f3.clone(), w_p4: w_p5.clone(), t_p5: t_p6.clone(), bare_p6: bare_p7.clone(), rw_p7: rw_ph.clone() })),
                crate::check::types::Ty::TyAny(trs_pi) => if crate::check::types::has_text(trs_pi, &w_p5.cls) || run_to_end(fold_job(trs_pi.clone(), false, {
                    let g_p0 = g_p0.clone();
                    let w_p5 = w_p5.clone();
                    Rc::new(move |(p0, p1): (bool, Text)| {
                        let g_p0 = g_p0.clone();
                        let w_p5 = w_p5.clone();
                        entered(once_job(move || {
                            let seen_pj = p0;
                            let tr_pk = p1;
                            prism_rtl::Turn::Finished(seen_pj || crate::check::types::has_text(&super_closure(&g_p0, &tr_pk), &w_p5.cls))
                        }))
                    }) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>
                })) {
                    prism_rtl::Turn::Finished((Array::new(), solved(st_p1, w_p5, t_p6, &Text::lit("packed"))))
                } else {
                    {
                        let restore_f3 = restore_f3.clone();
                        let s0_p2 = s0_p2.clone();
                        let st_p1 = st_p1.clone();
                        let t_p6 = t_p6.clone();
                        let w_p5 = w_p5.clone();
                        call_then(crate::check::types::start_show_ty(st_p1.clone(), t_p6.clone()), move |show_ty_15401: Text| call_value((&restore_f3)(crate::check::types::recording::err(&s0_p2, &Text::lit("no-impl"), &w_p5.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &show_ty_15401)))), move |restore_15337: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_15337))))
                    }
                },
                crate::check::types::Ty::TyCon(con_pl, args_pm) => if builtin_has(&w_p5.cls, con_pl) {
                    prism_rtl::Turn::Finished((Array::new(), solved(st_p1, w_p5, t_p6, &Text::lit("builtin"))))
                } else {
                    {
                        let restore_f3 = restore_f3.clone();
                        let con_pl = con_pl.clone();
                        let g_p0 = g_p0.clone();
                        let s0_p2 = s0_p2.clone();
                        let st_p1 = st_p1.clone();
                        let t_p6 = t_p6.clone();
                        let w_p5 = w_p5.clone();
                        call_then(start_find_impl(g_p0.clone(), st_p1.clone(), w_p5.cls.clone(), t_p6.clone()), move |find_impl_15558: Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>| match find_impl_15558 {
                            Some((im_pn, s2_po, how_pp, ch_pq)) => {
                                let wants_pr = each(&im_pn, &(|(ty_ps, cls_pt): &(crate::check::types::Ty, Text)| crate::check::types::Want { cls: cls_pt.clone(), ty: ty_ps.clone(), file: w_p5.file.clone(), span: w_p5.span.clone(), level: w_p5.level.clone() }));
                                prism_rtl::Turn::Finished((wants_pr.clone(), crate::check::types::recording::note_choice(&solved(&s2_po, &w_p5, &t_p6, &how_pp), &w_p5.file, &w_p5.span, &w_p5.cls, &ch_pq)))
                            },
                            None => {
                                let fix_pu = if ((&bare_p7 == &Text::lit("Num")) && (&con_pl == &Text::lit("Text"))) || crate::check::env::is_regex_type(&con_pl) {
                                    Text::lit("")
                                } else {
                                    Text::from(format!("derive `^{}` on `{}`, or write `impl ^{} {}`", &bare_p7, &crate::check::types::bare_name(&con_pl), &bare_p7, &crate::check::types::bare_name(&con_pl)))
                                };
                                call_then(crate::check::types::start_show_ty(st_p1.clone(), t_p6.clone()), move |show_ty_16153: Text| call_value((&restore_f3)(crate::check::types::recording::err_fix(&s0_p2, &Text::lit("no-impl"), &w_p5.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &show_ty_16153)), &fix_pu)), move |restore_16086: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_16086))))
                            },
                        })
                    }
                },
                _ => prism_rtl::Turn::Finished((Array::new(), st_p1.clone())),
            },
        }
    }
}

/// `Start SolveClass, x`: what the function value is when passed to `@Run`.
pub fn start_solve_class(g_p0: crate::check::env::G, st_p1: crate::check::types::St, s0_p2: crate::check::types::St, restore_f3: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens_p4: Array<(Text, Text)>, w_p5: crate::check::types::Want, t_p6: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>> {
    Rc::new(SolveClass { g_p0, st_p1, s0_p2, restore_f3, givens_p4, w_p5, t_p6 })
}

/// ```prism
/// ElemTrait: unbounded fn G, St, St, (fn St -> St), Want, Ty, Text, Rw -> (([Want], St))
/// ```
pub fn elem_trait(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, s0_p2: &crate::check::types::St, restore_f3: &Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, w_p4: &crate::check::types::Want, t_p5: &crate::check::types::Ty, bare_p6: &Text, rw_p7: &crate::check::types::Rw) -> (Array<crate::check::types::Want>, crate::check::types::St) {
    if !((bare_p6 == &Text::lit("Eq")) || (bare_p6 == &Text::lit("Show"))) {
        (Array::new(), run_to_end(restore_f3(crate::check::types::recording::err(s0_p2, &Text::lit("no-impl"), &w_p4.span, &Text::from(format!("no impl of `^{}` for `{}`", bare_p6, &crate::check::types::show_ty(st_p1, t_p5)))))))
    } else {
        if row_holds_dynamics(g_p0, &crate::check::types::recording::walk_row(st_p1, rw_p7)) {
            (Array::new(), run_to_end(restore_f3(crate::check::types::recording::err_fix(s0_p2, &Text::lit("no-impl"), &w_p4.span, &Text::from(format!("no impl of `^{}` for `{}`: a tag of its row holds dynamics (a container\'s children, `$(Path ==> $Elem)`), which do not compare or print", bare_p6, &crate::check::types::show_ty(st_p1, t_p5))), &Text::lit("compare or show what the element holds, a field at a time")))))
        } else {
            (Array::new(), solved(st_p1, w_p4, t_p5, &Text::lit("builtin")))
        }
    }
}

/// The step machine of `ElemTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElemTrait: unbounded fn G, St, St, (fn St -> St), Want, Ty, Text, Rw -> (([Want], St))
/// ```
pub struct ElemTrait {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub s0_p2: crate::check::types::St,
    pub restore_f3: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>,
    pub w_p4: crate::check::types::Want,
    pub t_p5: crate::check::types::Ty,
    pub bare_p6: Text,
    pub rw_p7: crate::check::types::Rw,
}

impl prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)> for ElemTrait {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Want>, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let s0_p2 = &self.s0_p2;
        let restore_f3 = &self.restore_f3;
        let w_p4 = &self.w_p4;
        let t_p5 = &self.t_p5;
        let bare_p6 = &self.bare_p6;
        let rw_p7 = &self.rw_p7;
        if !((bare_p6 == &Text::lit("Eq")) || (bare_p6 == &Text::lit("Show"))) {
            {
                let restore_f3 = restore_f3.clone();
                let bare_p6 = bare_p6.clone();
                let s0_p2 = s0_p2.clone();
                let st_p1 = st_p1.clone();
                let t_p5 = t_p5.clone();
                let w_p4 = w_p4.clone();
                call_then(crate::check::types::start_show_ty(st_p1.clone(), t_p5.clone()), move |show_ty_16562: Text| call_value((&restore_f3)(crate::check::types::recording::err(&s0_p2, &Text::lit("no-impl"), &w_p4.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare_p6, &show_ty_16562)))), move |restore_16498: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_16498))))
            }
        } else {
            {
                let restore_f3 = restore_f3.clone();
                let bare_p6 = bare_p6.clone();
                let g_p0 = g_p0.clone();
                let rw_p7 = rw_p7.clone();
                let s0_p2 = s0_p2.clone();
                let st_p1 = st_p1.clone();
                let t_p5 = t_p5.clone();
                let w_p4 = w_p4.clone();
                call_then(crate::check::types::recording::start_walk_row(st_p1.clone(), rw_p7.clone()), move |walk_row_16615: crate::check::types::Rw| if row_holds_dynamics(&g_p0, &walk_row_16615) {
                    call_then(crate::check::types::start_show_ty(st_p1.clone(), t_p5.clone()), move |show_ty_16707: Text| call_value((&restore_f3)(crate::check::types::recording::err_fix(&s0_p2, &Text::lit("no-impl"), &w_p4.span, &Text::from(format!("no impl of `^{}` for `{}`: a tag of its row holds dynamics (a container\'s children, `$(Path ==> $Elem)`), which do not compare or print", &bare_p6, &show_ty_16707)), &Text::lit("compare or show what the element holds, a field at a time"))), move |restore_16640: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_16640))))
                } else {
                    prism_rtl::Turn::Finished((Array::new(), solved(&st_p1, &w_p4, &t_p5, &Text::lit("builtin"))))
                })
            }
        }
    }
}

/// `Start ElemTrait, x`: what the function value is when passed to `@Run`.
pub fn start_elem_trait(g_p0: crate::check::env::G, st_p1: crate::check::types::St, s0_p2: crate::check::types::St, restore_f3: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, w_p4: crate::check::types::Want, t_p5: crate::check::types::Ty, bare_p6: Text, rw_p7: crate::check::types::Rw) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>> {
    Rc::new(ElemTrait { g_p0, st_p1, s0_p2, restore_f3, w_p4, t_p5, bare_p6, rw_p7 })
}

/// ```prism
/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
/// ```
pub fn find_impl(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, cls_p2: &Text, t_p3: &crate::check::types::Ty) -> Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)> {
    run_to_end(fold_job(or(&get(&g_p0.impls, cls_p2), &Array::new()), None, {
        let st_p1 = st_p1.clone();
        let t_p3 = t_p3.clone();
        let g_p0 = g_p0.clone();
        Rc::new(move |(p0, p1): (Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, crate::check::env::ImplInfo)| {
            let st_p1 = st_p1.clone();
            let t_p3 = t_p3.clone();
            let g_p0 = g_p0.clone();
            entered(once_job(move || {
                let found_o4 = p0;
                let im_p5 = p1;
                match &found_o4 {
                    Some(f_p6) => prism_rtl::Turn::Finished(Some(f_p6.clone())),
                    None => call_then(crate::check::types::recording::start_zonk(st_p1.clone(), t_p3.clone()), move |zonk_17351: crate::check::types::Ty| match match_head(&im_p5.head, &zonk_17351, &Map::new()) {
                        Some(m_p7) => prism_rtl::Turn::Finished(Some((each(&im_p5.bounds, &(|(v_p8, c_p9): &(Text, Text)| (or(&get(&m_p7, v_p8), &crate::check::types::Ty::TyErr), c_p9.clone()))), st_p1.clone(), impl_how(&g_p0, &im_p5), impl_choice(&im_p5)))),
                        None => prism_rtl::Turn::Finished(None),
                    }),
                }
            }))
        }) as Rc<dyn Fn((Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>>>>
    }))
}

/// The step machine of `FindImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
/// ```
pub struct FindImpl {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub cls_p2: Text,
    pub t_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>> for FindImpl {
    fn cycle(&self) -> prism_rtl::Turn<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let cls_p2 = &self.cls_p2;
        let t_p3 = &self.t_p3;
        fold_job(or(&get(&g_p0.impls, cls_p2), &Array::new()), None, {
            let st_p1 = st_p1.clone();
            let t_p3 = t_p3.clone();
            let g_p0 = g_p0.clone();
            Rc::new(move |(p0, p1): (Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, crate::check::env::ImplInfo)| {
                let st_p1 = st_p1.clone();
                let t_p3 = t_p3.clone();
                let g_p0 = g_p0.clone();
                entered(once_job(move || {
                    let found_o4 = p0;
                    let im_p5 = p1;
                    match &found_o4 {
                        Some(f_p6) => prism_rtl::Turn::Finished(Some(f_p6.clone())),
                        None => call_then(crate::check::types::recording::start_zonk(st_p1.clone(), t_p3.clone()), move |zonk_17351: crate::check::types::Ty| match match_head(&im_p5.head, &zonk_17351, &Map::new()) {
                            Some(m_p7) => prism_rtl::Turn::Finished(Some((each(&im_p5.bounds, &(|(v_p8, c_p9): &(Text, Text)| (or(&get(&m_p7, v_p8), &crate::check::types::Ty::TyErr), c_p9.clone()))), st_p1.clone(), impl_how(&g_p0, &im_p5), impl_choice(&im_p5)))),
                            None => prism_rtl::Turn::Finished(None),
                        }),
                    }
                }))
            }) as Rc<dyn Fn((Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>>>>
        }).cycle()
    }
}

/// `Start FindImpl, x`: what the function value is when passed to `@Run`.
pub fn start_find_impl(g_p0: crate::check::env::G, st_p1: crate::check::types::St, cls_p2: Text, t_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>>> {
    Rc::new(FindImpl { g_p0, st_p1, cls_p2, t_p3 })
}

/// ```prism
/// ImplChoice: fn ImplInfo -> Text
/// ```
pub fn impl_choice(im_p0: &crate::check::env::ImplInfo) -> Text {
    match &im_p0.head {
        crate::check::types::Ty::TyCon(n_p1, _) => if im_p0.derived {
            Text::from(format!("derived:{}", n_p1))
        } else {
            Text::from(format!("impl:{}.{}", &im_p0.file, &im_p0.span.start))
        },
        _ => if im_p0.derived {
            Text::lit("any")
        } else {
            Text::from(format!("impl:{}.{}", &im_p0.file, &im_p0.span.start))
        },
    }
}

/// ```prism
/// ImplHow: fn G, ImplInfo -> Text
/// ```
pub fn impl_how(g_p0: &crate::check::env::G, im_p1: &crate::check::env::ImplInfo) -> Text {
    let src_p2 = or(&index(&g_p0.srcs, &im_p1.file), &crate::check::errors::mk_src(&Text::lit("?"), &Text::lit("")));
    Text::from(format!("{} {}:{}", &(if im_p1.derived { Text::lit("derived") } else { Text::lit("impl") }), &src_p2.path_, &(&crate::check::errors::cline_of(&src_p2.starts, &im_p1.span.start) + &Nat::from(1u32))))
}

/// ```prism
/// Solved: fn St, Want, Ty, Text -> St
/// ```
pub fn solved(st_p0: &crate::check::types::St, w_p1: &crate::check::types::Want, t_p2: &crate::check::types::Ty, how_p3: &Text) -> crate::check::types::St {
    let s2_p4 = crate::check::types::recording::note_impl(st_p0, &w_p1.file, &w_p1.span, &w_p1.cls, t_p2, how_p3);
    if ((how_p3 == &Text::lit("given")) || (how_p3 == &Text::lit("packed"))) || (how_p3 == &Text::lit("quantified")) {
        crate::check::types::recording::note_choice(&s2_p4, &w_p1.file, &w_p1.span, &w_p1.cls, &Text::lit("any"))
    } else {
        if (how_p3 == &Text::lit("builtin")) || (how_p3 == &Text::lit("parts")) {
            crate::check::types::recording::note_choice(&s2_p4, &w_p1.file, &w_p1.span, &w_p1.cls, &Text::lit("none"))
        } else {
            s2_p4.clone()
        }
    }
}

/// ```prism
/// ?MatchHead: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub fn match_head(pat_p0: &crate::check::types::Ty, t_p1: &crate::check::types::Ty, m_p2: &Map<Text, crate::check::types::Ty>) -> Option<Map<Text, crate::check::types::Ty>> {
    match (pat_p0.clone(), t_p1.clone()) {
        (crate::check::types::Ty::TyQ(v_p3), x_p4) => match get(m_p2, &v_p3) {
            Some(y_p5) => if &y_p5 == &x_p4 { Some(m_p2.clone()) } else { None },
            None => Some(insert(m_p2, &v_p3, &x_p4)),
        },
        (crate::check::types::Ty::TyCon(a_p6, xs_p7), crate::check::types::Ty::TyCon(b_p8, ys_p9)) => if (&a_p6 == &b_p8) && (&len(&xs_p7) == &len(&ys_p9)) {
            match_all(&xs_p7, &ys_p9, m_p2)
        } else {
            None
        },
        (crate::check::types::Ty::TyTuple(xs_pa), crate::check::types::Ty::TyTuple(ys_pb)) => if &len(&xs_pa) == &len(&ys_pb) { match_all(&xs_pa, &ys_pb, m_p2) } else { None },
        (crate::check::types::Ty::TyArray(x_pc), crate::check::types::Ty::TyArray(y_pd)) => match_head(&*x_pc, &*y_pd, m_p2),
        (crate::check::types::Ty::TyMap(k1_pe, v1_pf), crate::check::types::Ty::TyMap(k2_pg, v2_ph)) => match_all(&Array::from(vec![(*k1_pe).clone(), (*v1_pf).clone()]), &Array::from(vec![(*k2_pg).clone(), (*v2_ph).clone()]), m_p2),
        (crate::check::types::Ty::TySig(s1_pi, i1_pj), crate::check::types::Ty::TySig(s2_pk, i2_pl)) => if &s1_pi == &s2_pk { match_head(&*i1_pj, &*i2_pl, m_p2) } else { None },
        _ => None,
    }
}

/// ```prism
/// ?MatchAll: unbounded fn [Ty], [Ty], (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub fn match_all(xs_p0: &Array<crate::check::types::Ty>, ys_p1: &Array<crate::check::types::Ty>, m_p2: &Map<Text, crate::check::types::Ty>) -> Option<Map<Text, crate::check::types::Ty>> {
    run_to_end(fold_job(crate::check::errors::range0(&len(xs_p0)), Some(m_p2.clone()), {
        let xs_p0 = xs_p0.clone();
        let ys_p1 = ys_p1.clone();
        Rc::new(move |(p0, p1): (Option<Map<Text, crate::check::types::Ty>>, Nat)| {
            let xs_p0 = xs_p0.clone();
            let ys_p1 = ys_p1.clone();
            entered(once_job(move || {
                let acc_o3 = p0;
                let i_p4 = p1;
                match &acc_o3 {
                    Some(mm_p5) => prism_rtl::Turn::Finished(match_head(&or(&index(&xs_p0, &i_p4), &crate::check::types::Ty::TyErr), &or(&index(&ys_p1, &i_p4), &crate::check::types::Ty::TyErr), mm_p5)),
                    None => prism_rtl::Turn::Finished(None),
                }
            }))
        }) as Rc<dyn Fn((Option<Map<Text, crate::check::types::Ty>>, Nat)) -> Rc<dyn prism_rtl::Job<Option<Map<Text, crate::check::types::Ty>>>>>
    }))
}

/// ```prism
/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
/// ```
pub fn default_wants(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, givens_p2: &Array<(Text, Text)>) -> crate::check::types::St {
    let flex_vars_p3 = run_to_end(fold_job(st_p1.wants.clone(), Array::new(), {
        let st_p1 = st_p1.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Want)| {
            let st_p1 = st_p1.clone();
            entered(once_job(move || {
                let acc_p8 = p0;
                let w_p9 = p1;
                call_then(crate::check::types::recording::start_walk(st_p1.clone(), w_p9.ty.clone()), move |walk_19935: crate::check::types::Ty| match walk_19935 {
                    crate::check::types::Ty::TyFlex(n_pa) => prism_rtl::Turn::Finished(crate::check::types::add_nat(&acc_p8, &n_pa)),
                    _ => prism_rtl::Turn::Finished(acc_p8.clone()),
                })
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    let s2_p4 = run_to_end(fold_job(flex_vars_p3.clone(), st_p1.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| entered(once_job(move || {
        let s_pb = p0;
        let v_pc = p1;
        call_value(filter_job(s_pb.wants.clone(), {
            let s_pb = s_pb.clone();
            let v_pc = v_pc.clone();
            Rc::new(move |p0: crate::check::types::Want| {
                let s_pb = s_pb.clone();
                let v_pc = v_pc.clone();
                entered(once_job(move || {
                    let w_pf = p0;
                    call_then(crate::check::types::recording::start_walk(s_pb.clone(), w_pf.ty.clone()), move |walk_20095: crate::check::types::Ty| prism_rtl::Turn::Finished(&walk_20095 == &crate::check::types::Ty::TyFlex(v_pc.clone())))
                }))
            }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |filter_20073: Array<crate::check::types::Want>| {
            let classes_pd = each(&filter_20073, &(|w_pg: &crate::check::types::Want| crate::check::types::bare_name(&w_pg.cls)));
            let defaultable_pe = crate::check::types::has_text(&classes_pd, &Text::lit("Num")) && fold(&classes_pd, &true, &(|ok_ph: &bool, c_pi: &Text| *ok_ph && (crate::check::types::has_text(&Array::from(vec![Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")]), c_pi) || crate::syntax::lexer::chars::has_prefix(c_pi, &Text::lit("Range ")))));
            if defaultable_pe {
                prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = s_pb.clone();
                    this.tys = insert(&this.tys, &v_pc, &crate::check::types::t_int());
                    this
                })
            } else {
                prism_rtl::Turn::Finished(s_pb.clone())
            }
        })
    }))) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>));
    let s3_p5 = solve_wants(g_p0, &s2_p4, givens_p2, &false);
    let leftover_p6 = run_to_end(filter_job(s3_p5.wants.clone(), {
        let s3_p5 = s3_p5.clone();
        Rc::new(move |p0: crate::check::types::Want| {
            let s3_p5 = s3_p5.clone();
            entered(once_job(move || {
                let w_pj = p0;
                call_then(crate::check::types::start_is_flex_var(s3_p5.clone(), w_pj.ty.clone()), move |is_flex_var_20508: bool| prism_rtl::Turn::Finished(((is_flex_var_20508 && !crate::syntax::lexer::chars::has_prefix(&w_pj.cls, &Text::lit("Range "))) && (&w_pj.cls != &Text::lit("Prelude.Sub"))) && (&w_pj.cls != &Text::lit("Prelude.Signed"))))
            }))
        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let s4_p7 = run_to_end(fold_job(leftover_p6.clone(), s3_p5.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Want)| entered(once_job(move || {
        let s_pk = p0;
        let w_pl = p1;
        {
            let s5_pm = {
                let mut this: crate::check::types::St = s_pk.clone();
                this.file = w_pl.file.clone();
                this
            };
            call_then(crate::check::types::start_show_ty(s_pk.clone(), w_pl.ty.clone()), move |show_ty_20779: Text| call_then(crate::check::types::start_show_ty(s_pk.clone(), w_pl.ty.clone()), move |show_ty_20819: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s5_pm, &Text::lit("ambiguous"), &w_pl.span, &Text::from(format!("nothing decides `{}` in `^{} {}`; annotate, or write a suffixed operator", &show_ty_20779, &crate::check::types::bare_name(&w_pl.cls), &show_ty_20819)), &Text::lit("annotate the value\'s type")))))
        }
    }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>));
    let mut this: crate::check::types::St = s4_p7.clone();
    this.wants = Array::new();
    this.file = st_p1.file.clone();
    this
}

/// The step machine of `DefaultWants`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
/// ```
pub struct DefaultWants {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub givens_p2: Array<(Text, Text)>,
}

impl prism_rtl::Job<crate::check::types::St> for DefaultWants {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let givens_p2 = &self.givens_p2;
        let g_p0 = g_p0.clone();
        let givens_p2 = givens_p2.clone();
        let st_p1 = st_p1.clone();
        call_value(fold_job(st_p1.wants.clone(), Array::new(), {
            let st_p1 = st_p1.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Want)| {
                let st_p1 = st_p1.clone();
                entered(once_job(move || {
                    let acc_p8 = p0;
                    let w_p9 = p1;
                    call_then(crate::check::types::recording::start_walk(st_p1.clone(), w_p9.ty.clone()), move |walk_19935: crate::check::types::Ty| match walk_19935 {
                        crate::check::types::Ty::TyFlex(n_pa) => prism_rtl::Turn::Finished(crate::check::types::add_nat(&acc_p8, &n_pa)),
                        _ => prism_rtl::Turn::Finished(acc_p8.clone()),
                    })
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        }), move |fold_19898: Array<Nat>| {
            let flex_vars_p3 = fold_19898;
            call_value(fold_job(flex_vars_p3.clone(), st_p1.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| entered(once_job(move || {
                let s_pb = p0;
                let v_pc = p1;
                call_value(filter_job(s_pb.wants.clone(), {
                    let s_pb = s_pb.clone();
                    let v_pc = v_pc.clone();
                    Rc::new(move |p0: crate::check::types::Want| {
                        let s_pb = s_pb.clone();
                        let v_pc = v_pc.clone();
                        entered(once_job(move || {
                            let w_pf = p0;
                            call_then(crate::check::types::recording::start_walk(s_pb.clone(), w_pf.ty.clone()), move |walk_20095: crate::check::types::Ty| prism_rtl::Turn::Finished(&walk_20095 == &crate::check::types::Ty::TyFlex(v_pc.clone())))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |filter_20073: Array<crate::check::types::Want>| {
                    let classes_pd = each(&filter_20073, &(|w_pg: &crate::check::types::Want| crate::check::types::bare_name(&w_pg.cls)));
                    let defaultable_pe = crate::check::types::has_text(&classes_pd, &Text::lit("Num")) && fold(&classes_pd, &true, &(|ok_ph: &bool, c_pi: &Text| *ok_ph && (crate::check::types::has_text(&Array::from(vec![Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")]), c_pi) || crate::syntax::lexer::chars::has_prefix(c_pi, &Text::lit("Range ")))));
                    if defaultable_pe {
                        prism_rtl::Turn::Finished({
                            let mut this: crate::check::types::St = s_pb.clone();
                            this.tys = insert(&this.tys, &v_pc, &crate::check::types::t_int());
                            this
                        })
                    } else {
                        prism_rtl::Turn::Finished(s_pb.clone())
                    }
                })
            }))) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>), move |fold_20018: crate::check::types::St| {
                let s2_p4 = fold_20018;
                call_then(start_solve_wants(g_p0.clone(), s2_p4.clone(), givens_p2.clone(), false), move |solve_wants_20434: crate::check::types::St| {
                    let s3_p5 = solve_wants_20434;
                    call_value(filter_job(s3_p5.wants.clone(), {
                        let s3_p5 = s3_p5.clone();
                        Rc::new(move |p0: crate::check::types::Want| {
                            let s3_p5 = s3_p5.clone();
                            entered(once_job(move || {
                                let w_pj = p0;
                                call_then(crate::check::types::start_is_flex_var(s3_p5.clone(), w_pj.ty.clone()), move |is_flex_var_20508: bool| prism_rtl::Turn::Finished(((is_flex_var_20508 && !crate::syntax::lexer::chars::has_prefix(&w_pj.cls, &Text::lit("Range "))) && (&w_pj.cls != &Text::lit("Prelude.Sub"))) && (&w_pj.cls != &Text::lit("Prelude.Signed"))))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |filter_20485: Array<crate::check::types::Want>| {
                        let leftover_p6 = filter_20485;
                        call_value(fold_job(leftover_p6.clone(), s3_p5.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Want)| entered(once_job(move || {
                            let s_pk = p0;
                            let w_pl = p1;
                            {
                                let s5_pm = {
                                    let mut this: crate::check::types::St = s_pk.clone();
                                    this.file = w_pl.file.clone();
                                    this
                                };
                                call_then(crate::check::types::start_show_ty(s_pk.clone(), w_pl.ty.clone()), move |show_ty_20779: Text| call_then(crate::check::types::start_show_ty(s_pk.clone(), w_pl.ty.clone()), move |show_ty_20819: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s5_pm, &Text::lit("ambiguous"), &w_pl.span, &Text::from(format!("nothing decides `{}` in `^{} {}`; annotate, or write a suffixed operator", &show_ty_20779, &crate::check::types::bare_name(&w_pl.cls), &show_ty_20819)), &Text::lit("annotate the value\'s type")))))
                            }
                        }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>), move |fold_20636: crate::check::types::St| {
                            let s4_p7 = fold_20636;
                            prism_rtl::Turn::Finished({
                                let mut this: crate::check::types::St = s4_p7.clone();
                                this.wants = Array::new();
                                this.file = st_p1.file.clone();
                                this
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start DefaultWants, x`: what the function value is when passed to `@Run`.
pub fn start_default_wants(g_p0: crate::check::env::G, st_p1: crate::check::types::St, givens_p2: Array<(Text, Text)>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DefaultWants { g_p0, st_p1, givens_p2 })
}
