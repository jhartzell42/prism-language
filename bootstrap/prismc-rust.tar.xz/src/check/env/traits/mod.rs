//! The module `Check.Env.Traits`, from `target/bootstrap/src/prismc/check/env/traits.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// DerivedImpls: fn G -> G
/// ```
pub fn derived_impls_f(g_p0: &crate::check::env::G) -> crate::check::env::G {
    crate::prelude::fold(&crate::prelude::keys(&g_p0.types_p), g_p0, &(|gg_p1: &crate::check::env::G, k_p2: &crate::prelude::Text| match crate::prelude::get(&gg_p1.types_p, k_p2) {
        ::std::option::Option::Some(ti_p3) => crate::prelude::fold(&ti_p3.derives_p, gg_p1, &(|g2_p4: &crate::check::env::G, tr_p5: &crate::prelude::Text| match crate::check::env::names::resolve_trait_o(g2_p4, &ti_p3.home_p, &crate::prelude::split_on(tr_p5, &crate::prelude::Text::lit("."))) {
            ::std::option::Option::Some(cls_p6) => {
                let im_p7 = crate::check::env::ImplInfo { cls_p: cls_p6.clone(), head_p: crate::check::types::Ty::TyCon(ti_p3.name_p.clone(), crate::prelude::each(&ti_p3.params_p, &(|p_p8: &crate::prelude::Text| crate::check::types::Ty::TyQ(p_p8.clone())))), qs_p: ti_p3.params_p.clone(), bounds_p: crate::prelude::each(&ti_p3.params_p, &(|p_p9: &crate::prelude::Text| (p_p9.clone(), cls_p6.clone()))), home_p: ti_p3.home_p.clone(), file_p: ti_p3.file_p.clone(), span_p: ti_p3.span_p.clone(), derived_p: true, assocs_p: crate::prelude::Array::new(), methods_p: crate::prelude::Array::new() };
                {
                    let mut this: crate::check::env::G = g2_p4.clone();
                    this.impls_p = crate::prelude::insert(&this.impls_p, &cls_p6, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(&this.impls_p, &cls_p6), &crate::prelude::Array::new()), &im_p7));
                    this
                }
            },
            ::std::option::Option::None => g2_p4.clone(),
        })),
        ::std::option::Option::None => gg_p1.clone(),
    }))
}

/// ```prism
/// DerivedDynamics: fn G, St -> St
/// ```
pub fn derived_dynamics_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> crate::check::types::St {
    crate::prelude::fold(&crate::prelude::keys(&g_p0.types_p), st_p1, &(|s_p2: &crate::check::types::St, k_p3: &crate::prelude::Text| match crate::prelude::get(&g_p0.types_p, k_p3) {
        ::std::option::Option::Some(ti_p4) => {
            let held_p5 = crate::prelude::filter(&ti_p4.derives_p, &(|d_p6: &crate::prelude::Text| crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("Eq"), crate::prelude::Text::lit("Ord"), crate::prelude::Text::lit("Show")]), &crate::check::types::bare_name_f(d_p6))));
            match field_holding_o(&ti_p4.body_p) {
                ::std::option::Option::Some(f_p7) if (&crate::prelude::len(&held_p5) > &crate::prelude::Nat::from(0u32)) => with_file_f(&crate::check::types::recording::err_fix_f(&with_file_f(s_p2, &ti_p4.file_p), &crate::prelude::Text::lit("derive-dynamic"), &ti_p4.span_p, &crate::prelude::Text::from(format!("`derive ^{}` on `{}`, whose `{}` holds a dynamic or an event, which does not compare or print", &crate::check::types::bare_name_f(&crate::prelude::or(&crate::prelude::index(&held_p5, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""))), &crate::check::types::bare_name_f(&ti_p4.name_p), &f_p7)), &crate::prelude::Text::lit("drop the derive")), &s_p2.file_p),
                _ => s_p2.clone(),
                _ => unreachable!("no arm matched"),
            }
        },
        ::std::option::Option::None => s_p2.clone(),
    }))
}

/// ```prism
/// DerivedFields: unbounded fn G, St -> St
/// ```
pub fn derived_fields_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> crate::check::types::St {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g_p0.types_p), st_p1.clone(), {
        let g_p0x = g_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p2 = p0;
                let k_p3 = p1;
                match crate::prelude::get(&g_p0xy.types_p, &k_p3) {
                    ::std::option::Option::Some(ti_p4) => if &field_holding_o(&ti_p4.body_p) != &::std::option::Option::None {
                        ::prism_rtl::Turn::Finished(s_p2.clone())
                    } else {
                        crate::prelude::fold_job(ti_p4.derives_p.clone(), s_p2.clone(), {
                            let g_p0xyx = g_p0xy.clone();
                            let ti_p4x = ti_p4.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
                                let g_p0xyxy = g_p0xyx.clone();
                                let ti_p4xy = ti_p4x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s1_p5 = p0;
                                    let tr_p6 = p1;
                                    match crate::check::env::names::resolve_trait_o(&g_p0xyxy, &ti_p4xy.home_p, &crate::prelude::split_on(&tr_p6, &crate::prelude::Text::lit("."))) {
                                        ::std::option::Option::Some(cls_p7) => if crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("Eq"), crate::prelude::Text::lit("Ord"), crate::prelude::Text::lit("Show")]), &crate::check::types::bare_name_f(&cls_p7)) {
                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(DeriveFieldsHave { g_p0: g_p0xyxy.clone(), st_p1: s1_p5.clone(), ti_p2: ti_p4xy.clone(), cls_p3: cls_p7.clone() }))
                                        } else {
                                            ::prism_rtl::Turn::Finished(s1_p5.clone())
                                        },
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(s1_p5.clone()),
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                        }).cycle()
                    },
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p2.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `DerivedFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DerivedFields: unbounded fn G, St -> St
/// ```
pub struct DerivedFields {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::types::St> for DerivedFields {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        crate::prelude::fold_job(crate::prelude::keys(&g_p0.types_p), st_p1.clone(), {
            let g_p0x = g_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
                let g_p0xy = g_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p2 = p0;
                    let k_p3 = p1;
                    match crate::prelude::get(&g_p0xy.types_p, &k_p3) {
                        ::std::option::Option::Some(ti_p4) => if &field_holding_o(&ti_p4.body_p) != &::std::option::Option::None {
                            ::prism_rtl::Turn::Finished(s_p2.clone())
                        } else {
                            crate::prelude::fold_job(ti_p4.derives_p.clone(), s_p2.clone(), {
                                let g_p0xyx = g_p0xy.clone();
                                let ti_p4x = ti_p4.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
                                    let g_p0xyxy = g_p0xyx.clone();
                                    let ti_p4xy = ti_p4x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let s1_p5 = p0;
                                        let tr_p6 = p1;
                                        match crate::check::env::names::resolve_trait_o(&g_p0xyxy, &ti_p4xy.home_p, &crate::prelude::split_on(&tr_p6, &crate::prelude::Text::lit("."))) {
                                            ::std::option::Option::Some(cls_p7) => if crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("Eq"), crate::prelude::Text::lit("Ord"), crate::prelude::Text::lit("Show")]), &crate::check::types::bare_name_f(&cls_p7)) {
                                                ::prism_rtl::Turn::More(::std::rc::Rc::new(DeriveFieldsHave { g_p0: g_p0xyxy.clone(), st_p1: s1_p5.clone(), ti_p2: ti_p4xy.clone(), cls_p3: cls_p7.clone() }))
                                            } else {
                                                ::prism_rtl::Turn::Finished(s1_p5.clone())
                                            },
                                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(s1_p5.clone()),
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                            }).cycle()
                        },
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p2.clone()),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start DerivedFields, x`: what the function value is when passed to `@Run`.
pub fn start_derived_fields_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(DerivedFields { g_p0, st_p1 })
}

/// ```prism
/// DeriveFieldsHave: unbounded fn G, St, TyInfo, Text -> St
/// ```
pub fn derive_fields_have_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, ti_p2: &crate::check::env::TyInfo, cls_p3: &crate::prelude::Text) -> crate::check::types::St {
    let inst_p4 = crate::check::env::reading::param_inst_f(&ti_p2.params_p, &crate::prelude::each(&ti_p2.params_p, &(|p_p8: &crate::prelude::Text| crate::check::types::Ty::TyRigid(p_p8.clone()))));
    let fields_p5 = match &ti_p2.body_p {
        crate::check::env::TyBody::BRecord(fs_p9) => crate::prelude::each(fs_p9, &(|(f_pa, t_pb): &(crate::prelude::Text, crate::check::types::Ty)| (f_pa.clone(), crate::prelude::Text::lit("is"), t_pb.clone()))),
        crate::check::env::TyBody::BChoice(cs_pc) => crate::prelude::fold(cs_pc, &crate::prelude::Array::new(), &(|acc_pd: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::check::types::Ty)>, (c_pe, ts_pf): &(crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)| crate::prelude::append(acc_pd, &crate::prelude::each(ts_pf, &(|t_pg: &crate::check::types::Ty| (c_pe.clone(), crate::prelude::Text::lit("holds"), t_pg.clone())))))),
        _ => crate::prelude::Array::new(),
    };
    let givens_p6 = crate::prelude::each(&ti_p2.params_p, &(|p_ph: &crate::prelude::Text| (p_ph.clone(), cls_p3.clone())));
    let lacking_o7 = crate::prelude::run_to_end(crate::prelude::fold_job(fields_p5.clone(), ::std::option::Option::None, {
        let inst_p4x = inst_p4.clone();
        let st_p1x = st_p1.clone();
        let ti_p2x = ti_p2.clone();
        let cls_p3x = cls_p3.clone();
        let g_p0x = g_p0.clone();
        let givens_p6x = givens_p6.clone();
        ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<(crate::prelude::Text, crate::prelude::Text, crate::check::types::Ty)>, (crate::prelude::Text, crate::prelude::Text, crate::check::types::Ty))| {
            let inst_p4xy = inst_p4x.clone();
            let st_p1xy = st_p1x.clone();
            let ti_p2xy = ti_p2x.clone();
            let cls_p3xy = cls_p3x.clone();
            let g_p0xy = g_p0x.clone();
            let givens_p6xy = givens_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let found_oi = p0;
                let (f_pj, how_pk, t_pl) = p1;
                match &found_oi {
                    ::std::option::Option::Some(x_pm) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(x_pm.clone())),
                    ::std::option::Option::None => crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_p4xy.clone(), t_pl.clone()), move |subst_q_f_3702: crate::check::types::Ty| {
                        let ft_pn = subst_q_f_3702;
                        let trial_po = {
                            let mut this: crate::check::types::St = st_p1xy.clone();
                            this.file_p = ti_p2xy.file_p.clone();
                            this.diags_p = crate::prelude::Array::new();
                            this.wants_p = crate::prelude::Array::from(vec![crate::check::types::Want { cls_p: cls_p3xy.clone(), ty_p: ft_pn.clone(), file_p: ti_p2xy.file_p.clone(), span_p: ti_p2xy.span_p.clone(), level_p: crate::prelude::Nat::from(0u32) }]);
                            this
                        };
                        crate::prelude::call_then(start_solve_wants_f(g_p0xy.clone(), trial_po.clone(), givens_p6xy.clone(), false), move |solve_wants_f_3932: crate::check::types::St| {
                            let out_pp = solve_wants_f_3932;
                            if (&crate::prelude::len(&out_pp.diags_p) > &crate::prelude::Nat::from(0u32)) || (&crate::prelude::len(&out_pp.wants_p) > &crate::prelude::Nat::from(0u32)) {
                                ::prism_rtl::Turn::Finished(::std::option::Option::Some((f_pj.clone(), how_pk.clone(), ft_pn.clone())))
                            } else {
                                ::prism_rtl::Turn::Finished(::std::option::Option::None)
                            }
                        })
                    }),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<(crate::prelude::Text, crate::prelude::Text, crate::check::types::Ty)>, (crate::prelude::Text, crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Text, crate::prelude::Text, crate::check::types::Ty)>>>>
    }));
    match &lacking_o7 {
        ::std::option::Option::Some((f_pq, how_pr, ft_ps)) => {
            let bare_pt = crate::check::types::bare_name_f(cls_p3);
            let shown_pu = crate::check::types::show_ty_f(st_p1, ft_ps);
            with_file_f(&crate::check::types::recording::err_fix_f(&with_file_f(st_p1, &ti_p2.file_p), &crate::prelude::Text::lit("no-impl"), &ti_p2.span_p, &crate::prelude::Text::from(format!("`derive ^{}` on `{}`, whose `{}` {} `{}`, which has no `^{}`", &bare_pt, &crate::check::types::bare_name_f(&ti_p2.name_p), f_pq, how_pr, &shown_pu, &bare_pt)), &crate::prelude::Text::from(format!("derive `^{}` on `{}`, or drop the derive", &bare_pt, &shown_pu))), &st_p1.file_p)
        },
        ::std::option::Option::None => st_p1.clone(),
    }
}

/// The step machine of `DeriveFieldsHave`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeriveFieldsHave: unbounded fn G, St, TyInfo, Text -> St
/// ```
pub struct DeriveFieldsHave {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub ti_p2: crate::check::env::TyInfo,
    pub cls_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::check::types::St> for DeriveFieldsHave {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let ti_p2 = &self.ti_p2;
        let cls_p3 = &self.cls_p3;
        let inst_p4 = crate::check::env::reading::param_inst_f(&ti_p2.params_p, &crate::prelude::each(&ti_p2.params_p, &(|p_p8: &crate::prelude::Text| crate::check::types::Ty::TyRigid(p_p8.clone()))));
        let fields_p5 = match &ti_p2.body_p {
            crate::check::env::TyBody::BRecord(fs_p9) => crate::prelude::each(fs_p9, &(|(f_pa, t_pb): &(crate::prelude::Text, crate::check::types::Ty)| (f_pa.clone(), crate::prelude::Text::lit("is"), t_pb.clone()))),
            crate::check::env::TyBody::BChoice(cs_pc) => crate::prelude::fold(cs_pc, &crate::prelude::Array::new(), &(|acc_pd: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::check::types::Ty)>, (c_pe, ts_pf): &(crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)| crate::prelude::append(acc_pd, &crate::prelude::each(ts_pf, &(|t_pg: &crate::check::types::Ty| (c_pe.clone(), crate::prelude::Text::lit("holds"), t_pg.clone())))))),
            _ => crate::prelude::Array::new(),
        };
        let givens_p6 = crate::prelude::each(&ti_p2.params_p, &(|p_ph: &crate::prelude::Text| (p_ph.clone(), cls_p3.clone())));
        let cls_p3x = cls_p3.clone();
        let g_p0x = g_p0.clone();
        let st_p1x = st_p1.clone();
        let ti_p2x = ti_p2.clone();
        crate::prelude::call_value(crate::prelude::fold_job(fields_p5.clone(), ::std::option::Option::None, {
            let inst_p4x = inst_p4.clone();
            let st_p1xx = st_p1x.clone();
            let ti_p2xx = ti_p2x.clone();
            let cls_p3xx = cls_p3x.clone();
            let g_p0xx = g_p0x.clone();
            let givens_p6x = givens_p6.clone();
            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<(crate::prelude::Text, crate::prelude::Text, crate::check::types::Ty)>, (crate::prelude::Text, crate::prelude::Text, crate::check::types::Ty))| {
                let inst_p4xy = inst_p4x.clone();
                let st_p1xxy = st_p1xx.clone();
                let ti_p2xxy = ti_p2xx.clone();
                let cls_p3xxy = cls_p3xx.clone();
                let g_p0xxy = g_p0xx.clone();
                let givens_p6xy = givens_p6x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_oi = p0;
                    let (f_pj, how_pk, t_pl) = p1;
                    match &found_oi {
                        ::std::option::Option::Some(x_pm) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(x_pm.clone())),
                        ::std::option::Option::None => crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_p4xy.clone(), t_pl.clone()), move |subst_q_f_3702: crate::check::types::Ty| {
                            let ft_pn = subst_q_f_3702;
                            let trial_po = {
                                let mut this: crate::check::types::St = st_p1xxy.clone();
                                this.file_p = ti_p2xxy.file_p.clone();
                                this.diags_p = crate::prelude::Array::new();
                                this.wants_p = crate::prelude::Array::from(vec![crate::check::types::Want { cls_p: cls_p3xxy.clone(), ty_p: ft_pn.clone(), file_p: ti_p2xxy.file_p.clone(), span_p: ti_p2xxy.span_p.clone(), level_p: crate::prelude::Nat::from(0u32) }]);
                                this
                            };
                            crate::prelude::call_then(start_solve_wants_f(g_p0xxy.clone(), trial_po.clone(), givens_p6xy.clone(), false), move |solve_wants_f_3932: crate::check::types::St| {
                                let out_pp = solve_wants_f_3932;
                                if (&crate::prelude::len(&out_pp.diags_p) > &crate::prelude::Nat::from(0u32)) || (&crate::prelude::len(&out_pp.wants_p) > &crate::prelude::Nat::from(0u32)) {
                                    ::prism_rtl::Turn::Finished(::std::option::Option::Some((f_pj.clone(), how_pk.clone(), ft_pn.clone())))
                                } else {
                                    ::prism_rtl::Turn::Finished(::std::option::Option::None)
                                }
                            })
                        }),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<(crate::prelude::Text, crate::prelude::Text, crate::check::types::Ty)>, (crate::prelude::Text, crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Text, crate::prelude::Text, crate::check::types::Ty)>>>>
        }), move |fold_3594: ::std::option::Option<(crate::prelude::Text, crate::prelude::Text, crate::check::types::Ty)>| {
            let lacking_o7 = fold_3594;
            match &lacking_o7 {
                ::std::option::Option::Some((f_pq, how_pr, ft_ps)) => {
                    let bare_pt = crate::check::types::bare_name_f(&cls_p3x);
                    let f_pqx = f_pq.clone();
                    let ft_psx = ft_ps.clone();
                    let how_prx = how_pr.clone();
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), ft_psx.clone()), move |show_ty_f_4159: crate::prelude::Text| {
                        let shown_pu = show_ty_f_4159;
                        ::prism_rtl::Turn::Finished(with_file_f(&crate::check::types::recording::err_fix_f(&with_file_f(&st_p1x, &ti_p2x.file_p), &crate::prelude::Text::lit("no-impl"), &ti_p2x.span_p, &crate::prelude::Text::from(format!("`derive ^{}` on `{}`, whose `{}` {} `{}`, which has no `^{}`", &bare_pt, &crate::check::types::bare_name_f(&ti_p2x.name_p), &f_pqx, &how_prx, &shown_pu, &bare_pt)), &crate::prelude::Text::from(format!("derive `^{}` on `{}`, or drop the derive", &bare_pt, &shown_pu))), &st_p1x.file_p))
                    })
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(st_p1x.clone()),
            }
        })
    }
}

/// `Start DeriveFieldsHave, x`: what the function value is when passed to `@Run`.
pub fn start_derive_fields_have_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, ti_p2: crate::check::env::TyInfo, cls_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(DeriveFieldsHave { g_p0, st_p1, ti_p2, cls_p3 })
}

/// ```prism
/// ?FieldHolding: fn TyBody -> ?Text
/// ```
pub fn field_holding_o(b_p0: &crate::check::env::TyBody) -> ::std::option::Option<crate::prelude::Text> {
    match b_p0 {
        crate::check::env::TyBody::BRecord(fs_p1) => crate::prelude::fold(fs_p1, &::std::option::Option::None, &(|found_o2: &::std::option::Option<crate::prelude::Text>, (f_p3, t_p4): &(crate::prelude::Text, crate::check::types::Ty)| if (found_o2 == &::std::option::Option::None) && holds_layer_f(t_p4) {
            ::std::option::Option::Some(f_p3.clone())
        } else {
            found_o2.clone()
        })),
        crate::check::env::TyBody::BChoice(cs_p5) => crate::prelude::fold(cs_p5, &::std::option::Option::None, &(|found_o6: &::std::option::Option<crate::prelude::Text>, (c_p7, ts_p8): &(crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)| if (found_o6 == &::std::option::Option::None) && crate::prelude::fold(ts_p8, &false, &(|h_p9: &bool, t_pa: &crate::check::types::Ty| *h_p9 || holds_layer_f(t_pa))) {
            ::std::option::Option::Some(c_p7.clone())
        } else {
            found_o6.clone()
        })),
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// HoldsLayer: fn Ty -> Bool
/// ```
pub fn holds_layer_f(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TySig(m5012_0_0, _) if (m5012_0_0 == &crate::prelude::Text::lit("$")) => true,
        crate::check::types::Ty::TySig(m5012_1_0, _) if (m5012_1_0 == &crate::prelude::Text::lit("!")) => true,
        crate::check::types::Ty::TySig(_, i_p1) => holds_layer_f(&**i_p1),
        crate::check::types::Ty::TyTuple(ts_p2) => crate::prelude::fold(ts_p2, &false, &(|h_p3: &bool, x_p4: &crate::check::types::Ty| *h_p3 || holds_layer_f(x_p4))),
        crate::check::types::Ty::TyArray(e_p5) => holds_layer_f(&**e_p5),
        crate::check::types::Ty::TyMap(k_p6, v_p7) => holds_layer_f(&**k_p6) || holds_layer_f(&**v_p7),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RowHoldsDynamics: fn G, Rw -> Bool
/// ```
pub fn row_holds_dynamics_f(g_p0: &crate::check::env::G, w_p1: &crate::check::types::Rw) -> bool {
    crate::prelude::fold(&crate::prelude::values(&g_p0.tags_p), &false, &(|h_p2: &bool, tg_p3: &crate::check::env::TagInfo| *h_p2 || ((((&tg_p3.kind_p == &crate::prelude::Text::lit("Element")) && crate::check::types::has_text_f(&w_p1.fams_p, &tg_p3.family_p)) && !crate::check::types::has_text_f(&w_p1.minus_p, &tg_p3.name_p)) && crate::prelude::fold(&tg_p3.fields_p, &false, &(|f_p4: &bool, (_, ft_p5): &(crate::prelude::Text, crate::check::types::Ty)| *f_p4 || holds_layer_f(&unlive_f(ft_p5)))))))
}

/// ```prism
/// Unlive: fn Ty -> Ty
/// ```
pub fn unlive_f(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TySig(m5902_0_0, i_p1) if (m5902_0_0 == &crate::prelude::Text::lit("$")) => (**i_p1).clone(),
        other_p2 => other_p2.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Coherence: unbounded fn G, St -> St
/// ```
pub fn coherence_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> crate::check::types::St {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g_p0.impls_p), st_p1.clone(), {
        let g_p0x = g_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p2 = p0;
                let cls_p3 = p1;
                {
                    let impls_p4 = crate::prelude::or(&crate::prelude::get(&g_p0xy.impls_p, &cls_p3), &crate::prelude::Array::new());
                    crate::prelude::call_value(crate::prelude::fold_job(impls_p4.clone(), s_p2.clone(), {
                        let g_p0xyx = g_p0xy.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::ImplInfo)| {
                            let g_p0xyxy = g_p0xyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let s1_p6 = p0;
                                let i_p7 = p1;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckOrphan { g_p0: g_p0xyxy.clone(), st_p1: s1_p6.clone(), i_p2: i_p7.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_6092: crate::check::types::St| {
                        let s2_p5 = fold_6092;
                        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&impls_p4)), s2_p5.clone(), {
                            let impls_p4x = impls_p4.clone();
                            let g_p0xyx = g_p0xy.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Nat)| {
                                let impls_p4xy = impls_p4x.clone();
                                let g_p0xyxy = g_p0xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s3_p8 = p0;
                                    let a_p9 = p1;
                                    crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&impls_p4xy)), s3_p8.clone(), {
                                        let a_p9x = a_p9.clone();
                                        let g_p0xyxyx = g_p0xyxy.clone();
                                        let impls_p4xyx = impls_p4xy.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Nat)| {
                                            let a_p9xy = a_p9x.clone();
                                            let g_p0xyxyxy = g_p0xyxyx.clone();
                                            let impls_p4xyxy = impls_p4xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let s4_pa = p0;
                                                let b_pb = p1;
                                                if &a_p9xy < &b_pb {
                                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckPair { g_p0: g_p0xyxyxy.clone(), st_p1: s4_pa.clone(), a_p2: crate::prelude::or(&crate::prelude::index(&impls_p4xyxy, &a_p9xy), &dummy_impl_p()), b_p3: crate::prelude::or(&crate::prelude::index(&impls_p4xyxy, &b_pb), &dummy_impl_p()) }))
                                                } else {
                                                    ::prism_rtl::Turn::Finished(s4_pa.clone())
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                                    }).cycle()
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                        }).cycle()
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `Coherence`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Coherence: unbounded fn G, St -> St
/// ```
pub struct Coherence {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::types::St> for Coherence {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        crate::prelude::fold_job(crate::prelude::keys(&g_p0.impls_p), st_p1.clone(), {
            let g_p0x = g_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
                let g_p0xy = g_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p2 = p0;
                    let cls_p3 = p1;
                    {
                        let impls_p4 = crate::prelude::or(&crate::prelude::get(&g_p0xy.impls_p, &cls_p3), &crate::prelude::Array::new());
                        crate::prelude::call_value(crate::prelude::fold_job(impls_p4.clone(), s_p2.clone(), {
                            let g_p0xyx = g_p0xy.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::ImplInfo)| {
                                let g_p0xyxy = g_p0xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s1_p6 = p0;
                                    let i_p7 = p1;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckOrphan { g_p0: g_p0xyxy.clone(), st_p1: s1_p6.clone(), i_p2: i_p7.clone() }))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                        }), move |fold_6092: crate::check::types::St| {
                            let s2_p5 = fold_6092;
                            crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&impls_p4)), s2_p5.clone(), {
                                let impls_p4x = impls_p4.clone();
                                let g_p0xyx = g_p0xy.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Nat)| {
                                    let impls_p4xy = impls_p4x.clone();
                                    let g_p0xyxy = g_p0xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let s3_p8 = p0;
                                        let a_p9 = p1;
                                        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&impls_p4xy)), s3_p8.clone(), {
                                            let a_p9x = a_p9.clone();
                                            let g_p0xyxyx = g_p0xyxy.clone();
                                            let impls_p4xyx = impls_p4xy.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Nat)| {
                                                let a_p9xy = a_p9x.clone();
                                                let g_p0xyxyxy = g_p0xyxyx.clone();
                                                let impls_p4xyxy = impls_p4xyx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let s4_pa = p0;
                                                    let b_pb = p1;
                                                    if &a_p9xy < &b_pb {
                                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckPair { g_p0: g_p0xyxyxy.clone(), st_p1: s4_pa.clone(), a_p2: crate::prelude::or(&crate::prelude::index(&impls_p4xyxy, &a_p9xy), &dummy_impl_p()), b_p3: crate::prelude::or(&crate::prelude::index(&impls_p4xyxy, &b_pb), &dummy_impl_p()) }))
                                                    } else {
                                                        ::prism_rtl::Turn::Finished(s4_pa.clone())
                                                    }
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                                        }).cycle()
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                            }).cycle()
                        })
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start Coherence, x`: what the function value is when passed to `@Run`.
pub fn start_coherence_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(Coherence { g_p0, st_p1 })
}

/// ```prism
/// let dummyImpl
/// ```
pub fn dummy_impl_p() -> crate::check::env::ImplInfo {
    crate::check::env::ImplInfo { cls_p: crate::prelude::Text::lit(""), head_p: crate::check::types::Ty::TyErr, qs_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), home_p: crate::prelude::Text::lit(""), file_p: crate::prelude::Nat::from(0u32), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) }, derived_p: false, assocs_p: crate::prelude::Array::new(), methods_p: crate::prelude::Array::new() }
}

/// ```prism
/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub fn check_pair_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, a_p2: &crate::check::env::ImplInfo, b_p3: &crate::check::env::ImplInfo) -> crate::check::types::St {
    if !heads_may_meet_f(&a_p2.head_p, &b_p3.head_p) {
        st_p1.clone()
    } else {
        if (&a_p2.file_p < &b_p3.file_p) || ((&a_p2.file_p == &b_p3.file_p) && (&a_p2.span_p.start_p <= &b_p3.span_p.start_p)) {
            check_pair_in_f(g_p0, st_p1, a_p2, b_p3)
        } else {
            check_pair_in_f(g_p0, st_p1, b_p3, a_p2)
        }
    }
}

/// The step machine of `CheckPair`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub struct CheckPair {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub a_p2: crate::check::env::ImplInfo,
    pub b_p3: crate::check::env::ImplInfo,
}

impl ::prism_rtl::Job<crate::check::types::St> for CheckPair {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let a_p2 = &self.a_p2;
        let b_p3 = &self.b_p3;
        if !heads_may_meet_f(&a_p2.head_p, &b_p3.head_p) {
            ::prism_rtl::Turn::Finished(st_p1.clone())
        } else {
            if (&a_p2.file_p < &b_p3.file_p) || ((&a_p2.file_p == &b_p3.file_p) && (&a_p2.span_p.start_p <= &b_p3.span_p.start_p)) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckPairIn { g_p0: g_p0.clone(), st_p1: st_p1.clone(), a_p2: a_p2.clone(), b_p3: b_p3.clone() }))
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckPairIn { g_p0: g_p0.clone(), st_p1: st_p1.clone(), a_p2: b_p3.clone(), b_p3: a_p2.clone() }))
            }
        }
    }
}

/// `Start CheckPair, x`: what the function value is when passed to `@Run`.
pub fn start_check_pair_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, a_p2: crate::check::env::ImplInfo, b_p3: crate::check::env::ImplInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CheckPair { g_p0, st_p1, a_p2, b_p3 })
}

/// ```prism
/// HeadsMayMeet: fn Ty, Ty -> Bool
/// ```
pub fn heads_may_meet_f(ty0: &crate::check::types::Ty, ty1: &crate::check::types::Ty) -> bool {
    match (ty0, ty1) {
        (crate::check::types::Ty::TyCon(x_p0, _), crate::check::types::Ty::TyCon(y_p1, _)) => x_p0 == y_p1,
        (crate::check::types::Ty::TyErr, _) => false,
        (_, crate::check::types::Ty::TyErr) => false,
        (_, _) => true,
    }
}

/// ```prism
/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub fn check_pair_in_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, a_p2: &crate::check::env::ImplInfo, b_p3: &crate::check::env::ImplInfo) -> crate::check::types::St {
    let s0_p4 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.file_p = b_p3.file_p.clone();
        this
    };
    let (ta_p5, s1_p6) = crate::check::types::schemes::instantiate_f(&s0_p4, &crate::check::types::Scheme { qs_p: a_p2.qs_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: a_p2.head_p.clone() }, &b_p3.span_p);
    let (tb_p7, s2_p8) = crate::check::types::schemes::instantiate_f(&s1_p6, &crate::check::types::Scheme { qs_p: b_p3.qs_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: b_p3.head_p.clone() }, &b_p3.span_p);
    let (ok_p9, s3_pa) = crate::check::types::unify::try_unify_f(&s2_p8, &ta_p5, &tb_p7, &b_p3.span_p);
    if !ok_p9 {
        st_p1.clone()
    } else {
        {
            let same_pb = ((&crate::prelude::len(&a_p2.qs_p) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&b_p3.qs_p) == &crate::prelude::Nat::from(0u32))) || (&shape_of_f(&a_p2.head_p) == &shape_of_f(&b_p3.head_p));
            let code_pc = if same_pb {
                crate::prelude::Text::lit("impl-duplicate")
            } else {
                crate::prelude::Text::lit("impl-overlap")
            };
            let first_at_pd = crate::check::errors::src_place_f(&crate::prelude::or(&crate::prelude::index(&g_p0.srcs_p, &a_p2.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit("?"), &crate::prelude::Text::lit(""))), &a_p2.span_p.start_p);
            crate::check::types::recording::err_fix_f(&s0_p4, &code_pc, &b_p3.span_p, &crate::prelude::Text::from(format!("a second impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&a_p2.cls_p), &crate::check::types::show_ty_f(&s0_p4, &b_p3.head_p))), &crate::prelude::Text::from(format!("the first is at {}; keep one", &first_at_pd)))
        }
    }
}

/// The step machine of `CheckPairIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub struct CheckPairIn {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub a_p2: crate::check::env::ImplInfo,
    pub b_p3: crate::check::env::ImplInfo,
}

impl ::prism_rtl::Job<crate::check::types::St> for CheckPairIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let a_p2 = &self.a_p2;
        let b_p3 = &self.b_p3;
        let s0_p4 = {
            let mut this: crate::check::types::St = st_p1.clone();
            this.file_p = b_p3.file_p.clone();
            this
        };
        let a_p2x = a_p2.clone();
        let b_p3x = b_p3.clone();
        let g_p0x = g_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::schemes::start_instantiate_f(s0_p4.clone(), crate::check::types::Scheme { qs_p: a_p2x.qs_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: a_p2x.head_p.clone() }, b_p3x.span_p.clone()), move |instantiate_f_7278: (crate::check::types::Ty, crate::check::types::St)| {
            let (ta_p5, s1_p6) = instantiate_f_7278;
            crate::prelude::call_then(crate::check::types::schemes::start_instantiate_f(s1_p6.clone(), crate::check::types::Scheme { qs_p: b_p3x.qs_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: b_p3x.head_p.clone() }, b_p3x.span_p.clone()), move |instantiate_f_7422: (crate::check::types::Ty, crate::check::types::St)| {
                let (tb_p7, s2_p8) = instantiate_f_7422;
                crate::prelude::call_then(crate::check::types::unify::start_try_unify_f(s2_p8.clone(), ta_p5.clone(), tb_p7.clone(), b_p3x.span_p.clone()), move |try_unify_f_7566: (bool, crate::check::types::St)| {
                    let (ok_p9, s3_pa) = try_unify_f_7566;
                    if !ok_p9 {
                        ::prism_rtl::Turn::Finished(st_p1x.clone())
                    } else {
                        {
                            let a_p2xz = a_p2x.clone();
                            let b_p3xz = b_p3x.clone();
                            let g_p0xz = g_p0x.clone();
                            let s0_p4z = s0_p4.clone();
                            let k_let7630 = move |v7630: bool| {
                                let same_pb = v7630;
                                let code_pc = if same_pb {
                                    crate::prelude::Text::lit("impl-duplicate")
                                } else {
                                    crate::prelude::Text::lit("impl-overlap")
                                };
                                let first_at_pd = crate::check::errors::src_place_f(&crate::prelude::or(&crate::prelude::index(&g_p0xz.srcs_p, &a_p2xz.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit("?"), &crate::prelude::Text::lit(""))), &a_p2xz.span_p.start_p);
                                crate::prelude::call_then(crate::check::types::start_show_ty_f(s0_p4z.clone(), b_p3xz.head_p.clone()), move |show_ty_f_7942: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s0_p4z, &code_pc, &b_p3xz.span_p, &crate::prelude::Text::from(format!("a second impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&a_p2xz.cls_p), &show_ty_f_7942)), &crate::prelude::Text::from(format!("the first is at {}; keep one", &first_at_pd)))))
                            };
                            if (&crate::prelude::len(&a_p2x.qs_p) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&b_p3x.qs_p) == &crate::prelude::Nat::from(0u32)) {
                                k_let7630(true)
                            } else {
                                crate::prelude::call_then(start_shape_of_f(a_p2x.head_p.clone()), move |shape_of_f_7681: crate::prelude::Text| crate::prelude::call_then(start_shape_of_f(b_p3x.head_p.clone()), move |shape_of_f_7701: crate::prelude::Text| k_let7630(&shape_of_f_7681 == &shape_of_f_7701)))
                            }
                        }
                    }
                })
            })
        })
    }
}

/// `Start CheckPairIn, x`: what the function value is when passed to `@Run`.
pub fn start_check_pair_in_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, a_p2: crate::check::env::ImplInfo, b_p3: crate::check::env::ImplInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CheckPairIn { g_p0, st_p1, a_p2, b_p3 })
}

/// ```prism
/// ShapeOf: unbounded fn Ty -> Text
/// ```
pub fn shape_of_f(t_p0: &crate::check::types::Ty) -> crate::prelude::Text {
    match t_p0 {
        crate::check::types::Ty::TyQ(_) => crate::prelude::Text::lit("_"),
        crate::check::types::Ty::TyCon(n_p1, args_p2) => crate::prelude::Text::from(format!("{}({})", n_p1, &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(args_p2.clone(), ::std::rc::Rc::new(|a0: crate::check::types::Ty| crate::prelude::entered(start_shape_of_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(",")))),
        crate::check::types::Ty::TyTuple(ts_p3) => crate::prelude::Text::from(format!("(({}))", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ts_p3.clone(), ::std::rc::Rc::new(|a0: crate::check::types::Ty| crate::prelude::entered(start_shape_of_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(",")))),
        crate::check::types::Ty::TyArray(e_p4) => crate::prelude::Text::from(format!("[{}]", &shape_of_f(&**e_p4))),
        crate::check::types::Ty::TyMap(k_p5, v_p6) => crate::prelude::Text::from(format!("{}==>{}", &shape_of_f(&**k_p5), &shape_of_f(&**v_p6))),
        crate::check::types::Ty::TySig(s_p7, i_p8) => crate::prelude::Text::from(format!("{}{}", s_p7, &shape_of_f(&**i_p8))),
        _ => crate::prelude::Text::lit("?"),
    }
}

/// The step machine of `ShapeOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShapeOf: unbounded fn Ty -> Text
/// ```
pub struct ShapeOf {
    pub t_p0: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ShapeOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyQ(_) => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("_")),
            crate::check::types::Ty::TyCon(n_p1, args_p2) => {
                let args_p2x = args_p2.clone();
                let n_p1x = n_p1.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p2x.clone(), ::std::rc::Rc::new(|a0: crate::check::types::Ty| crate::prelude::entered(start_shape_of_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_8184: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({})", &n_p1x, &crate::syntax::lexer::chars::join_f(&each_8184, &crate::prelude::Text::lit(","))))))
            },
            crate::check::types::Ty::TyTuple(ts_p3) => {
                let ts_p3x = ts_p3.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_p3x.clone(), ::std::rc::Rc::new(|a0: crate::check::types::Ty| crate::prelude::entered(start_shape_of_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_8238: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("(({}))", &crate::syntax::lexer::chars::join_f(&each_8238, &crate::prelude::Text::lit(","))))))
            },
            crate::check::types::Ty::TyArray(e_p4) => {
                let e_p4x = (**e_p4).clone();
                crate::prelude::call_then(start_shape_of_f(e_p4x.clone()), move |shape_of_f_8283: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("[{}]", &shape_of_f_8283))))
            },
            crate::check::types::Ty::TyMap(k_p5, v_p6) => {
                let k_p5x = (**k_p5).clone();
                let v_p6x = (**v_p6).clone();
                crate::prelude::call_then(start_shape_of_f(k_p5x.clone()), move |shape_of_f_8314: crate::prelude::Text| crate::prelude::call_then(start_shape_of_f(v_p6x.clone()), move |shape_of_f_8328: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}==>{}", &shape_of_f_8314, &shape_of_f_8328)))))
            },
            crate::check::types::Ty::TySig(s_p7, i_p8) => {
                let i_p8x = (**i_p8).clone();
                let s_p7x = s_p7.clone();
                crate::prelude::call_then(start_shape_of_f(i_p8x.clone()), move |shape_of_f_8361: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}", &s_p7x, &shape_of_f_8361))))
            },
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("?")),
        }
    }
}

/// `Start ShapeOf, x`: what the function value is when passed to `@Run`.
pub fn start_shape_of_f(t_p0: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ShapeOf { t_p0 })
}

/// ```prism
/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
/// ```
pub fn check_orphan_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, i_p2: &crate::check::env::ImplInfo) -> crate::check::types::St {
    let trait_mod_p3 = crate::prelude::or(&crate::prelude::get(&g_p0.traits_p, &i_p2.cls_p), &dummy_trait_p()).home_p.clone();
    let owners_p4 = crate::prelude::each(&type_names_in_f(&i_p2.head_p), &(|n_p5: &crate::prelude::Text| crate::prelude::or(&crate::prelude::get(&g_p0.types_p, n_p5), &crate::check::env::names::dummy_ty_info_p()).home_p.clone()));
    if (i_p2.derived_p || (&i_p2.home_p == &trait_mod_p3)) || crate::check::types::has_text_f(&owners_p4, &i_p2.home_p) {
        st_p1.clone()
    } else {
        {
            let s_p6 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file_p = i_p2.file_p.clone();
                this
            };
            crate::check::types::recording::err_fix_f(&s_p6, &crate::prelude::Text::lit("orphan"), &i_p2.span_p, &crate::prelude::Text::from(format!("{} declares neither `^{}` nor `{}`", &(if &i_p2.home_p == &crate::prelude::Text::lit("") {
                crate::prelude::Text::lit("this file")
            } else {
                crate::prelude::Text::from(format!("`{}`", &i_p2.home_p))
            }), &crate::check::types::bare_name_f(&i_p2.cls_p), &crate::check::types::show_ty_f(&s_p6, &i_p2.head_p))), &crate::prelude::Text::lit("wrap the type in a newtype of this module, or move the impl"))
        }
    }
}

/// The step machine of `CheckOrphan`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
/// ```
pub struct CheckOrphan {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub i_p2: crate::check::env::ImplInfo,
}

impl ::prism_rtl::Job<crate::check::types::St> for CheckOrphan {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let i_p2 = &self.i_p2;
        let trait_mod_p3 = crate::prelude::or(&crate::prelude::get(&g_p0.traits_p, &i_p2.cls_p), &dummy_trait_p()).home_p.clone();
        let g_p0x = g_p0.clone();
        let i_p2x = i_p2.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_type_names_in_f(i_p2x.head_p.clone()), move |type_names_in_f_8674: crate::prelude::Array<crate::prelude::Text>| {
            let owners_p4 = crate::prelude::each(&type_names_in_f_8674, &(|n_p5: &crate::prelude::Text| crate::prelude::or(&crate::prelude::get(&g_p0x.types_p, n_p5), &crate::check::env::names::dummy_ty_info_p()).home_p.clone()));
            if (i_p2x.derived_p || (&i_p2x.home_p == &trait_mod_p3)) || crate::check::types::has_text_f(&owners_p4, &i_p2x.home_p) {
                ::prism_rtl::Turn::Finished(st_p1x.clone())
            } else {
                {
                    let s_p6 = {
                        let mut this: crate::check::types::St = st_p1x.clone();
                        this.file_p = i_p2x.file_p.clone();
                        this
                    };
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(s_p6.clone(), i_p2x.head_p.clone()), move |show_ty_f_9000: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s_p6, &crate::prelude::Text::lit("orphan"), &i_p2x.span_p, &crate::prelude::Text::from(format!("{} declares neither `^{}` nor `{}`", &(if &i_p2x.home_p == &crate::prelude::Text::lit("") {
                        crate::prelude::Text::lit("this file")
                    } else {
                        crate::prelude::Text::from(format!("`{}`", &i_p2x.home_p))
                    }), &crate::check::types::bare_name_f(&i_p2x.cls_p), &show_ty_f_9000)), &crate::prelude::Text::lit("wrap the type in a newtype of this module, or move the impl"))))
                }
            }
        })
    }
}

/// `Start CheckOrphan, x`: what the function value is when passed to `@Run`.
pub fn start_check_orphan_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, i_p2: crate::check::env::ImplInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CheckOrphan { g_p0, st_p1, i_p2 })
}

/// ```prism
/// let dummyTrait
/// ```
pub fn dummy_trait_p() -> crate::check::env::TraitInfo {
    crate::check::env::TraitInfo { name_p: crate::prelude::Text::lit(""), home_p: crate::prelude::Text::lit(""), param_p: crate::prelude::Text::lit("a"), supers_p: crate::prelude::Array::new(), methods_p: crate::prelude::Array::new(), defaults_p: crate::prelude::Array::new(), assocs_p: crate::prelude::Array::new(), assoc_defaults_p: crate::prelude::Array::new(), file_p: crate::prelude::Nat::from(0u32), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// TypeNamesIn: unbounded fn Ty -> [Text]
/// ```
pub fn type_names_in_f(t_p0: &crate::check::types::Ty) -> crate::prelude::Array<crate::prelude::Text> {
    match t_p0 {
        crate::check::types::Ty::TyCon(n_p1, args_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p2.clone(), crate::prelude::Array::from(vec![n_p1.clone()]), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let a_p4 = p1;
            crate::prelude::call_then(start_type_names_in_f(a_p4.clone()), move |type_names_in_f_9383: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &type_names_in_f_9383)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::check::types::Ty::TyTuple(ts_p5) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p5.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p6 = p0;
            let a_p7 = p1;
            crate::prelude::call_then(start_type_names_in_f(a_p7.clone()), move |type_names_in_f_9456: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p6, &type_names_in_f_9456)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::check::types::Ty::TyArray(e_p8) => type_names_in_f(&**e_p8),
        crate::check::types::Ty::TyMap(k_p9, v_pa) => crate::check::types::union_texts_f(&type_names_in_f(&**k_p9), &type_names_in_f(&**v_pa)),
        crate::check::types::Ty::TySig(_, i_pb) => type_names_in_f(&**i_pb),
        crate::check::types::Ty::TyFn(_, ps_pc, r_pd) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pc.clone(), type_names_in_f(&**r_pd), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pe = p0;
            let a_pf = p1;
            crate::prelude::call_then(start_type_names_in_f(a_pf.clone()), move |type_names_in_f_9672: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pe, &type_names_in_f_9672)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `TypeNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeNamesIn: unbounded fn Ty -> [Text]
/// ```
pub struct TypeNamesIn {
    pub t_p0: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for TypeNamesIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyCon(n_p1, args_p2) => crate::prelude::fold_job(args_p2.clone(), crate::prelude::Array::from(vec![n_p1.clone()]), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let a_p4 = p1;
                crate::prelude::call_then(start_type_names_in_f(a_p4.clone()), move |type_names_in_f_9383: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &type_names_in_f_9383)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::check::types::Ty::TyTuple(ts_p5) => crate::prelude::fold_job(ts_p5.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let a_p7 = p1;
                crate::prelude::call_then(start_type_names_in_f(a_p7.clone()), move |type_names_in_f_9456: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p6, &type_names_in_f_9456)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::check::types::Ty::TyArray(e_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeNamesIn { t_p0: (**e_p8).clone() })),
            crate::check::types::Ty::TyMap(k_p9, v_pa) => {
                let k_p9x = (**k_p9).clone();
                let v_pax = (**v_pa).clone();
                crate::prelude::call_then(start_type_names_in_f(k_p9x.clone()), move |type_names_in_f_9528: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_type_names_in_f(v_pax.clone()), move |type_names_in_f_9545: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&type_names_in_f_9528, &type_names_in_f_9545))))
            },
            crate::check::types::Ty::TySig(_, i_pb) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeNamesIn { t_p0: (**i_pb).clone() })),
            crate::check::types::Ty::TyFn(_, ps_pc, r_pd) => {
                let ps_pcx = ps_pc.clone();
                let r_pdx = (**r_pd).clone();
                crate::prelude::call_then(start_type_names_in_f(r_pdx.clone()), move |type_names_in_f_9629: crate::prelude::Array<crate::prelude::Text>| crate::prelude::fold_job(ps_pcx.clone(), type_names_in_f_9629, ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pe = p0;
                    let a_pf = p1;
                    crate::prelude::call_then(start_type_names_in_f(a_pf.clone()), move |type_names_in_f_9672: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pe, &type_names_in_f_9672)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle())
            },
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start TypeNamesIn, x`: what the function value is when passed to `@Run`.
pub fn start_type_names_in_f(t_p0: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(TypeNamesIn { t_p0 })
}

/// ```prism
/// SuperClosure: unbounded fn G, Text -> [Text]
/// ```
pub fn super_closure_f(g_p0: &crate::check::env::G, cls_p1: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    super_reach_f(g_p0, &crate::prelude::Array::from(vec![cls_p1.clone()]), &crate::prelude::Array::new())
}

/// The step machine of `SuperClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SuperClosure: unbounded fn G, Text -> [Text]
/// ```
pub struct SuperClosure {
    pub g_p0: crate::check::env::G,
    pub cls_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for SuperClosure {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let g_p0 = &self.g_p0;
        let cls_p1 = &self.cls_p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(SuperReach { g_p0: g_p0.clone(), frontier_p1: crate::prelude::Array::from(vec![cls_p1.clone()]), seen_p2: crate::prelude::Array::new() }))
    }
}

/// `Start SuperClosure, x`: what the function value is when passed to `@Run`.
pub fn start_super_closure_f(g_p0: crate::check::env::G, cls_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(SuperClosure { g_p0, cls_p1 })
}

/// ```prism
/// SuperReach: unbounded fn G, [Text], [Text] -> [Text]
/// ```
pub fn super_reach_f(g_p0: &crate::check::env::G, frontier_p1: &crate::prelude::Array<crate::prelude::Text>, seen_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    match crate::prelude::index(frontier_p1, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::None => seen_p2.clone(),
        ::std::option::Option::Some(cls_p3) => if crate::check::types::has_text_f(seen_p2, &cls_p3) {
            super_reach_f(g_p0, &crate::prelude::drop(frontier_p1, &crate::prelude::Nat::from(1u32)), seen_p2)
        } else {
            super_reach_f(g_p0, &crate::prelude::append(&crate::prelude::drop(frontier_p1, &crate::prelude::Nat::from(1u32)), &crate::prelude::or(&crate::prelude::get(&g_p0.traits_p, &cls_p3), &dummy_trait_p()).supers_p), &crate::prelude::push(seen_p2, &cls_p3))
        },
    }
}

/// The step machine of `SuperReach`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SuperReach: unbounded fn G, [Text], [Text] -> [Text]
/// ```
pub struct SuperReach {
    pub g_p0: crate::check::env::G,
    pub frontier_p1: crate::prelude::Array<crate::prelude::Text>,
    pub seen_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for SuperReach {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let g_p0 = &self.g_p0;
        let frontier_p1 = &self.frontier_p1;
        let seen_p2 = &self.seen_p2;
        match crate::prelude::index(frontier_p1, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(seen_p2.clone()),
            ::std::option::Option::Some(cls_p3) => if crate::check::types::has_text_f(seen_p2, &cls_p3) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(SuperReach { g_p0: g_p0.clone(), frontier_p1: crate::prelude::drop(frontier_p1, &crate::prelude::Nat::from(1u32)), seen_p2: seen_p2.clone() }))
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(SuperReach { g_p0: g_p0.clone(), frontier_p1: crate::prelude::append(&crate::prelude::drop(frontier_p1, &crate::prelude::Nat::from(1u32)), &crate::prelude::or(&crate::prelude::get(&g_p0.traits_p, &cls_p3), &dummy_trait_p()).supers_p), seen_p2: crate::prelude::push(seen_p2, &cls_p3) }))
            },
        }
    }
}

/// `Start SuperReach, x`: what the function value is when passed to `@Run`.
pub fn start_super_reach_f(g_p0: crate::check::env::G, frontier_p1: crate::prelude::Array<crate::prelude::Text>, seen_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(SuperReach { g_p0, frontier_p1, seen_p2 })
}

/// ```prism
/// TraitCycles: unbounded fn G, St -> St
/// ```
pub fn trait_cycles_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> crate::check::types::St {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g_p0.traits_p), st_p1.clone(), {
        let g_p0x = g_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p2 = p0;
                let name_p3 = p1;
                {
                    let ti_p4 = crate::prelude::or(&crate::prelude::get(&g_p0xy.traits_p, &name_p3), &dummy_trait_p());
                    crate::prelude::call_then(start_ring_from_o(g_p0xy.clone(), name_p3.clone(), ti_p4.supers_p.clone(), crate::prelude::Array::from(vec![name_p3.clone()])), move |ring_from_o_11001: ::std::option::Option<crate::prelude::Array<crate::prelude::Text>>| match ring_from_o_11001 {
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p2.clone()),
                        ::std::option::Option::Some(ring_p5) => ::prism_rtl::Turn::Finished(with_file_f(&crate::check::types::recording::err_fix_f(&with_file_f(&s_p2, &ti_p4.file_p), &crate::prelude::Text::lit("trait-cycle"), &ti_p4.span_p, &crate::prelude::Text::from(format!("the trait `^{}` asks for itself: its `where` names a ring of traits, {}", &crate::check::types::bare_name_f(&name_p3), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&ring_p5, &(|r_p6: &crate::prelude::Text| crate::prelude::Text::from(format!("`^{}`", &crate::check::types::bare_name_f(r_p6))))), &crate::prelude::Text::lit(", ")))), &crate::prelude::Text::lit("drop the `where` of one trait of the ring")), &s_p2.file_p)),
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `TraitCycles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitCycles: unbounded fn G, St -> St
/// ```
pub struct TraitCycles {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::types::St> for TraitCycles {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        crate::prelude::fold_job(crate::prelude::keys(&g_p0.traits_p), st_p1.clone(), {
            let g_p0x = g_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
                let g_p0xy = g_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p2 = p0;
                    let name_p3 = p1;
                    {
                        let ti_p4 = crate::prelude::or(&crate::prelude::get(&g_p0xy.traits_p, &name_p3), &dummy_trait_p());
                        crate::prelude::call_then(start_ring_from_o(g_p0xy.clone(), name_p3.clone(), ti_p4.supers_p.clone(), crate::prelude::Array::from(vec![name_p3.clone()])), move |ring_from_o_11001: ::std::option::Option<crate::prelude::Array<crate::prelude::Text>>| match ring_from_o_11001 {
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p2.clone()),
                            ::std::option::Option::Some(ring_p5) => ::prism_rtl::Turn::Finished(with_file_f(&crate::check::types::recording::err_fix_f(&with_file_f(&s_p2, &ti_p4.file_p), &crate::prelude::Text::lit("trait-cycle"), &ti_p4.span_p, &crate::prelude::Text::from(format!("the trait `^{}` asks for itself: its `where` names a ring of traits, {}", &crate::check::types::bare_name_f(&name_p3), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&ring_p5, &(|r_p6: &crate::prelude::Text| crate::prelude::Text::from(format!("`^{}`", &crate::check::types::bare_name_f(r_p6))))), &crate::prelude::Text::lit(", ")))), &crate::prelude::Text::lit("drop the `where` of one trait of the ring")), &s_p2.file_p)),
                        })
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start TraitCycles, x`: what the function value is when passed to `@Run`.
pub fn start_trait_cycles_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(TraitCycles { g_p0, st_p1 })
}

/// ```prism
/// TagVariablesPrint: unbounded fn G, St -> St
/// ```
pub fn tag_variables_print_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> crate::check::types::St {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g_p0.tags_p), st_p1.clone(), {
        let g_p0x = g_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p2 = p0;
                let name_p3 = p1;
                match crate::prelude::get(&g_p0xy.tags_p, &name_p3) {
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p2.clone()),
                    ::std::option::Option::Some(tg_p4) => crate::prelude::fold_job(tg_p4.qs_p.clone(), s_p2.clone(), {
                        let tg_p4x = tg_p4.clone();
                        let g_p0xyx = g_p0xy.clone();
                        let name_p3x = name_p3.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
                            let tg_p4xy = tg_p4x.clone();
                            let g_p0xyxy = g_p0xyx.clone();
                            let name_p3xy = name_p3x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let s1_p5 = p0;
                                let variable_p6 = p1;
                                crate::prelude::call_value(crate::prelude::fold_job(tg_p4xy.bounds_p.clone(), false, {
                                    let variable_p6x = variable_p6.clone();
                                    let g_p0xyxyx = g_p0xyxy.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Text))| {
                                        let variable_p6xy = variable_p6x.clone();
                                        let g_p0xyxyxy = g_p0xyxyx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let seen_p9 = p0;
                                            let (bounded_pa, cls_pb) = p1;
                                            if seen_p9 {
                                                ::prism_rtl::Turn::Finished(true)
                                            } else {
                                                if &bounded_pa == &variable_p6xy {
                                                    crate::prelude::call_then(start_super_closure_f(g_p0xyxyxy.clone(), cls_pb.clone()), move |super_closure_f_12008: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::has_text_f(&super_closure_f_12008, &crate::prelude::Text::lit("Prelude.Show"))))
                                                } else {
                                                    ::prism_rtl::Turn::Finished(false)
                                                }
                                            }
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Text))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                }), move |fold_11917: bool| {
                                    let prints_p7 = fold_11917;
                                    crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(crate::check::types::schemes::Inst { tys_p: crate::prelude::insert(&crate::prelude::Map::new(), &variable_p6, &crate::check::types::Ty::TyErr), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() }, tg_p4xy.out_p.clone()), move |subst_q_f_12156: crate::check::types::Ty| {
                                        let in_output_p8 = &subst_q_f_12156 != &tg_p4xy.out_p;
                                        if prints_p7 || !in_output_p8 {
                                            ::prism_rtl::Turn::Finished(s1_p5.clone())
                                        } else {
                                            ::prism_rtl::Turn::Finished(with_file_f(&crate::check::types::recording::err_fix_f(&with_file_f(&s1_p5, &tg_p4xy.file_p), &crate::prelude::Text::lit("tag-variable"), &tg_p4xy.span_p, &crate::prelude::Text::from(format!("the type variable `{}` of the tag `{}` has no `^Show` bound: every field and every output prints", &variable_p6, &name_p3xy)), &crate::prelude::Text::from(format!("write `where {}: ^Show` on the tag\'s line", &variable_p6))), &s1_p5.file_p))
                                        }
                                    })
                                })
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                    }).cycle(),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `TagVariablesPrint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagVariablesPrint: unbounded fn G, St -> St
/// ```
pub struct TagVariablesPrint {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::types::St> for TagVariablesPrint {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        crate::prelude::fold_job(crate::prelude::keys(&g_p0.tags_p), st_p1.clone(), {
            let g_p0x = g_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
                let g_p0xy = g_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p2 = p0;
                    let name_p3 = p1;
                    match crate::prelude::get(&g_p0xy.tags_p, &name_p3) {
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p2.clone()),
                        ::std::option::Option::Some(tg_p4) => crate::prelude::fold_job(tg_p4.qs_p.clone(), s_p2.clone(), {
                            let tg_p4x = tg_p4.clone();
                            let g_p0xyx = g_p0xy.clone();
                            let name_p3x = name_p3.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
                                let tg_p4xy = tg_p4x.clone();
                                let g_p0xyxy = g_p0xyx.clone();
                                let name_p3xy = name_p3x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s1_p5 = p0;
                                    let variable_p6 = p1;
                                    crate::prelude::call_value(crate::prelude::fold_job(tg_p4xy.bounds_p.clone(), false, {
                                        let variable_p6x = variable_p6.clone();
                                        let g_p0xyxyx = g_p0xyxy.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Text))| {
                                            let variable_p6xy = variable_p6x.clone();
                                            let g_p0xyxyxy = g_p0xyxyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let seen_p9 = p0;
                                                let (bounded_pa, cls_pb) = p1;
                                                if seen_p9 {
                                                    ::prism_rtl::Turn::Finished(true)
                                                } else {
                                                    if &bounded_pa == &variable_p6xy {
                                                        crate::prelude::call_then(start_super_closure_f(g_p0xyxyxy.clone(), cls_pb.clone()), move |super_closure_f_12008: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::has_text_f(&super_closure_f_12008, &crate::prelude::Text::lit("Prelude.Show"))))
                                                    } else {
                                                        ::prism_rtl::Turn::Finished(false)
                                                    }
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Text))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                    }), move |fold_11917: bool| {
                                        let prints_p7 = fold_11917;
                                        crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(crate::check::types::schemes::Inst { tys_p: crate::prelude::insert(&crate::prelude::Map::new(), &variable_p6, &crate::check::types::Ty::TyErr), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() }, tg_p4xy.out_p.clone()), move |subst_q_f_12156: crate::check::types::Ty| {
                                            let in_output_p8 = &subst_q_f_12156 != &tg_p4xy.out_p;
                                            if prints_p7 || !in_output_p8 {
                                                ::prism_rtl::Turn::Finished(s1_p5.clone())
                                            } else {
                                                ::prism_rtl::Turn::Finished(with_file_f(&crate::check::types::recording::err_fix_f(&with_file_f(&s1_p5, &tg_p4xy.file_p), &crate::prelude::Text::lit("tag-variable"), &tg_p4xy.span_p, &crate::prelude::Text::from(format!("the type variable `{}` of the tag `{}` has no `^Show` bound: every field and every output prints", &variable_p6, &name_p3xy)), &crate::prelude::Text::from(format!("write `where {}: ^Show` on the tag\'s line", &variable_p6))), &s1_p5.file_p))
                                            }
                                        })
                                    })
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                        }).cycle(),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start TagVariablesPrint, x`: what the function value is when passed to `@Run`.
pub fn start_tag_variables_print_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(TagVariablesPrint { g_p0, st_p1 })
}

/// ```prism
/// TagFieldsPrint: unbounded fn G, St -> St
/// ```
pub fn tag_fields_print_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> crate::check::types::St {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g_p0.tags_p), st_p1.clone(), {
        let g_p0x = g_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p2 = p0;
                let name_p3 = p1;
                match crate::prelude::get(&g_p0xy.tags_p, &name_p3) {
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p2.clone()),
                    ::std::option::Option::Some(tg_p4) => crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&tg_p4.fields_p)), s_p2.clone(), {
                        let tg_p4x = tg_p4.clone();
                        let g_p0xyx = g_p0xy.clone();
                        let name_p3x = name_p3.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Nat)| {
                            let tg_p4xy = tg_p4x.clone();
                            let g_p0xyxy = g_p0xyx.clone();
                            let name_p3xy = name_p3x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let s1_p5 = p0;
                                let i_p6 = p1;
                                {
                                    let (_, field_type_p7) = crate::prelude::or(&crate::prelude::index(&tg_p4xy.fields_p, &i_p6), &(crate::prelude::Text::lit(""), crate::check::types::Ty::TyErr));
                                    let (label_p8, at_p9) = crate::prelude::or(&crate::prelude::index(&tg_p4xy.field_at_p, &i_p6), &(crate::prelude::Text::lit(""), tg_p4xy.span_p.clone()));
                                    crate::prelude::call_then(start_unprintable_o(g_p0xyxy.clone(), s1_p5.clone(), field_type_p7.clone()), move |unprintable_o_13496: ::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)>| match unprintable_o_13496 {
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(s1_p5.clone()),
                                        ::std::option::Option::Some((bad_pa, why_pb, fix_pc)) => crate::prelude::call_then(crate::check::types::start_show_ty_f(s1_p5.clone(), bad_pa.clone()), move |show_ty_f_13692: crate::prelude::Text| {
                                            let message_pd = crate::prelude::Text::from(format!("the field `{}` of the tag `{}` does not print: no impl of `^Show` for `{}`{}", &label_p8, &name_p3xy, &show_ty_f_13692, &why_pb));
                                            let there_pe = with_file_f(&s1_p5, &tg_p4xy.file_p);
                                            ::prism_rtl::Turn::Finished(with_file_f(&(if &fix_pc == &crate::prelude::Text::lit("") {
                                                crate::check::types::recording::err_f(&there_pe, &crate::prelude::Text::lit("no-impl"), &at_p9, &message_pd)
                                            } else {
                                                crate::check::types::recording::err_fix_f(&there_pe, &crate::prelude::Text::lit("no-impl"), &at_p9, &message_pd, &fix_pc)
                                            }), &s1_p5.file_p))
                                        }),
                                    })
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                    }).cycle(),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `TagFieldsPrint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagFieldsPrint: unbounded fn G, St -> St
/// ```
pub struct TagFieldsPrint {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::types::St> for TagFieldsPrint {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        crate::prelude::fold_job(crate::prelude::keys(&g_p0.tags_p), st_p1.clone(), {
            let g_p0x = g_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
                let g_p0xy = g_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p2 = p0;
                    let name_p3 = p1;
                    match crate::prelude::get(&g_p0xy.tags_p, &name_p3) {
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p2.clone()),
                        ::std::option::Option::Some(tg_p4) => crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&tg_p4.fields_p)), s_p2.clone(), {
                            let tg_p4x = tg_p4.clone();
                            let g_p0xyx = g_p0xy.clone();
                            let name_p3x = name_p3.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Nat)| {
                                let tg_p4xy = tg_p4x.clone();
                                let g_p0xyxy = g_p0xyx.clone();
                                let name_p3xy = name_p3x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s1_p5 = p0;
                                    let i_p6 = p1;
                                    {
                                        let (_, field_type_p7) = crate::prelude::or(&crate::prelude::index(&tg_p4xy.fields_p, &i_p6), &(crate::prelude::Text::lit(""), crate::check::types::Ty::TyErr));
                                        let (label_p8, at_p9) = crate::prelude::or(&crate::prelude::index(&tg_p4xy.field_at_p, &i_p6), &(crate::prelude::Text::lit(""), tg_p4xy.span_p.clone()));
                                        crate::prelude::call_then(start_unprintable_o(g_p0xyxy.clone(), s1_p5.clone(), field_type_p7.clone()), move |unprintable_o_13496: ::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)>| match unprintable_o_13496 {
                                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(s1_p5.clone()),
                                            ::std::option::Option::Some((bad_pa, why_pb, fix_pc)) => crate::prelude::call_then(crate::check::types::start_show_ty_f(s1_p5.clone(), bad_pa.clone()), move |show_ty_f_13692: crate::prelude::Text| {
                                                let message_pd = crate::prelude::Text::from(format!("the field `{}` of the tag `{}` does not print: no impl of `^Show` for `{}`{}", &label_p8, &name_p3xy, &show_ty_f_13692, &why_pb));
                                                let there_pe = with_file_f(&s1_p5, &tg_p4xy.file_p);
                                                ::prism_rtl::Turn::Finished(with_file_f(&(if &fix_pc == &crate::prelude::Text::lit("") {
                                                    crate::check::types::recording::err_f(&there_pe, &crate::prelude::Text::lit("no-impl"), &at_p9, &message_pd)
                                                } else {
                                                    crate::check::types::recording::err_fix_f(&there_pe, &crate::prelude::Text::lit("no-impl"), &at_p9, &message_pd, &fix_pc)
                                                }), &s1_p5.file_p))
                                            }),
                                        })
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                        }).cycle(),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start TagFieldsPrint, x`: what the function value is when passed to `@Run`.
pub fn start_tag_fields_print_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(TagFieldsPrint { g_p0, st_p1 })
}

/// ```prism
/// FaultFieldsPlain: unbounded fn G, St -> St
/// ```
pub fn fault_fields_plain_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> crate::check::types::St {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g_p0.tags_p), st_p1.clone(), {
        let g_p0x = g_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p2 = p0;
                let name_p3 = p1;
                match crate::prelude::get(&g_p0xy.tags_p, &name_p3) {
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p2.clone()),
                    ::std::option::Option::Some(tg_p4) => if !((&tg_p4.kind_p == &crate::prelude::Text::lit("Fault")) || (&tg_p4.kind_p == &crate::prelude::Text::lit("Prelude.Fault"))) {
                        ::prism_rtl::Turn::Finished(s_p2.clone())
                    } else {
                        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&tg_p4.fields_p)), s_p2.clone(), {
                            let tg_p4x = tg_p4.clone();
                            let name_p3x = name_p3.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Nat)| {
                                let tg_p4xy = tg_p4x.clone();
                                let name_p3xy = name_p3x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s1_p5 = p0;
                                    let i_p6 = p1;
                                    {
                                        let (_, field_type_p7) = crate::prelude::or(&crate::prelude::index(&tg_p4xy.fields_p, &i_p6), &(crate::prelude::Text::lit(""), crate::check::types::Ty::TyErr));
                                        let (label_p8, at_p9) = crate::prelude::or(&crate::prelude::index(&tg_p4xy.field_at_p, &i_p6), &(crate::prelude::Text::lit(""), tg_p4xy.span_p.clone()));
                                        crate::prelude::call_then(start_not_plain_data_o(field_type_p7.clone()), move |not_plain_data_o_14801: ::std::option::Option<crate::prelude::Text>| match not_plain_data_o_14801 {
                                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(s1_p5.clone()),
                                            ::std::option::Option::Some(what_pa) => ::prism_rtl::Turn::Finished(with_file_f(&crate::check::types::recording::err_fix_f(&with_file_f(&s1_p5, &tg_p4xy.file_p), &crate::prelude::Text::lit("fault-field"), &at_p9, &crate::prelude::Text::from(format!("the field `{}` of the fault kind `{}` is no plain data: it holds {}", &label_p8, &name_p3xy, &what_pa)), &crate::prelude::Text::lit("give the field the value as the fault is made, a type with no `$`, `!`, `@` or `any` in it")), &s1_p5.file_p)),
                                        })
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                        }).cycle()
                    },
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `FaultFieldsPlain`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FaultFieldsPlain: unbounded fn G, St -> St
/// ```
pub struct FaultFieldsPlain {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::types::St> for FaultFieldsPlain {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        crate::prelude::fold_job(crate::prelude::keys(&g_p0.tags_p), st_p1.clone(), {
            let g_p0x = g_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
                let g_p0xy = g_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p2 = p0;
                    let name_p3 = p1;
                    match crate::prelude::get(&g_p0xy.tags_p, &name_p3) {
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p2.clone()),
                        ::std::option::Option::Some(tg_p4) => if !((&tg_p4.kind_p == &crate::prelude::Text::lit("Fault")) || (&tg_p4.kind_p == &crate::prelude::Text::lit("Prelude.Fault"))) {
                            ::prism_rtl::Turn::Finished(s_p2.clone())
                        } else {
                            crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&tg_p4.fields_p)), s_p2.clone(), {
                                let tg_p4x = tg_p4.clone();
                                let name_p3x = name_p3.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Nat)| {
                                    let tg_p4xy = tg_p4x.clone();
                                    let name_p3xy = name_p3x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let s1_p5 = p0;
                                        let i_p6 = p1;
                                        {
                                            let (_, field_type_p7) = crate::prelude::or(&crate::prelude::index(&tg_p4xy.fields_p, &i_p6), &(crate::prelude::Text::lit(""), crate::check::types::Ty::TyErr));
                                            let (label_p8, at_p9) = crate::prelude::or(&crate::prelude::index(&tg_p4xy.field_at_p, &i_p6), &(crate::prelude::Text::lit(""), tg_p4xy.span_p.clone()));
                                            crate::prelude::call_then(start_not_plain_data_o(field_type_p7.clone()), move |not_plain_data_o_14801: ::std::option::Option<crate::prelude::Text>| match not_plain_data_o_14801 {
                                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(s1_p5.clone()),
                                                ::std::option::Option::Some(what_pa) => ::prism_rtl::Turn::Finished(with_file_f(&crate::check::types::recording::err_fix_f(&with_file_f(&s1_p5, &tg_p4xy.file_p), &crate::prelude::Text::lit("fault-field"), &at_p9, &crate::prelude::Text::from(format!("the field `{}` of the fault kind `{}` is no plain data: it holds {}", &label_p8, &name_p3xy, &what_pa)), &crate::prelude::Text::lit("give the field the value as the fault is made, a type with no `$`, `!`, `@` or `any` in it")), &s1_p5.file_p)),
                                            })
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                            }).cycle()
                        },
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start FaultFieldsPlain, x`: what the function value is when passed to `@Run`.
pub fn start_fault_fields_plain_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(FaultFieldsPlain { g_p0, st_p1 })
}

/// ```prism
/// ?NotPlainData: unbounded fn Ty -> ?Text
/// ```
pub fn not_plain_data_o(t_p0: &crate::check::types::Ty) -> ::std::option::Option<crate::prelude::Text> {
    match t_p0 {
        crate::check::types::Ty::TySig(m15264_0_0, _) if (m15264_0_0 == &crate::prelude::Text::lit("$")) => ::std::option::Option::Some(crate::prelude::Text::lit("a dynamic")),
        crate::check::types::Ty::TySig(m15264_1_0, _) if (m15264_1_0 == &crate::prelude::Text::lit("!")) => ::std::option::Option::Some(crate::prelude::Text::lit("an event")),
        crate::check::types::Ty::TySig(m15264_2_0, _) if (m15264_2_0 == &crate::prelude::Text::lit("&")) => ::std::option::Option::Some(crate::prelude::Text::lit("a reference")),
        crate::check::types::Ty::TySig(_, inner_p1) => not_plain_data_o(&**inner_p1),
        crate::check::types::Ty::TyAt(_, _) => ::std::option::Option::Some(crate::prelude::Text::lit("a blueprint")),
        crate::check::types::Ty::TyElem(_, _) => ::std::option::Option::Some(crate::prelude::Text::lit("an element")),
        crate::check::types::Ty::TyElemAny(_) => ::std::option::Option::Some(crate::prelude::Text::lit("an element")),
        crate::check::types::Ty::TyAny(_) => ::std::option::Option::Some(crate::prelude::Text::lit("a packed value (`any`)")),
        crate::check::types::Ty::TyTuple(parts_p2) => first_not_plain_data_o(parts_p2),
        crate::check::types::Ty::TyArray(element_p3) => not_plain_data_o(&**element_p3),
        crate::check::types::Ty::TyMap(k_p4, v_p5) => first_not_plain_data_o(&crate::prelude::Array::from(vec![(**k_p4).clone(), (**v_p5).clone()])),
        crate::check::types::Ty::TyCon(_, args_p6) => first_not_plain_data_o(args_p6),
        _ => ::std::option::Option::None,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `NotPlainData`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?NotPlainData: unbounded fn Ty -> ?Text
/// ```
pub struct NotPlainData {
    pub t_p0: crate::check::types::Ty,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>> for NotPlainData {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Text>> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TySig(m15264_0_0, _) if (m15264_0_0 == &crate::prelude::Text::lit("$")) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::Text::lit("a dynamic"))),
            crate::check::types::Ty::TySig(m15264_1_0, _) if (m15264_1_0 == &crate::prelude::Text::lit("!")) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::Text::lit("an event"))),
            crate::check::types::Ty::TySig(m15264_2_0, _) if (m15264_2_0 == &crate::prelude::Text::lit("&")) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::Text::lit("a reference"))),
            crate::check::types::Ty::TySig(_, inner_p1) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NotPlainData { t_p0: (**inner_p1).clone() })),
            crate::check::types::Ty::TyAt(_, _) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::Text::lit("a blueprint"))),
            crate::check::types::Ty::TyElem(_, _) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::Text::lit("an element"))),
            crate::check::types::Ty::TyElemAny(_) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::Text::lit("an element"))),
            crate::check::types::Ty::TyAny(_) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::Text::lit("a packed value (`any`)"))),
            crate::check::types::Ty::TyTuple(parts_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstNotPlainData { parts_p0: parts_p2.clone() })),
            crate::check::types::Ty::TyArray(element_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NotPlainData { t_p0: (**element_p3).clone() })),
            crate::check::types::Ty::TyMap(k_p4, v_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstNotPlainData { parts_p0: crate::prelude::Array::from(vec![(**k_p4).clone(), (**v_p5).clone()]) })),
            crate::check::types::Ty::TyCon(_, args_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstNotPlainData { parts_p0: args_p6.clone() })),
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start NotPlainData, x`: what the function value is when passed to `@Run`.
pub fn start_not_plain_data_o(t_p0: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>>> {
    ::std::rc::Rc::new(NotPlainData { t_p0 })
}

/// ```prism
/// ?FirstNotPlainData: unbounded fn [Ty] -> ?Text
/// ```
pub fn first_not_plain_data_o(parts_p0: &crate::prelude::Array<crate::check::types::Ty>) -> ::std::option::Option<crate::prelude::Text> {
    crate::prelude::run_to_end(crate::prelude::fold_job(parts_p0.clone(), ::std::option::Option::None, ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
        let found_o1 = p0;
        let part_p2 = p1;
        match &found_o1 {
            ::std::option::Option::Some(what_p3) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(what_p3.clone())),
            ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(NotPlainData { t_p0: part_p2.clone() })),
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>>>>))
}

/// The step machine of `FirstNotPlainData`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FirstNotPlainData: unbounded fn [Ty] -> ?Text
/// ```
pub struct FirstNotPlainData {
    pub parts_p0: crate::prelude::Array<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>> for FirstNotPlainData {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Text>> {
        let parts_p0 = &self.parts_p0;
        crate::prelude::fold_job(parts_p0.clone(), ::std::option::Option::None, ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let found_o1 = p0;
            let part_p2 = p1;
            match &found_o1 {
                ::std::option::Option::Some(what_p3) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(what_p3.clone())),
                ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(NotPlainData { t_p0: part_p2.clone() })),
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>>>>).cycle()
    }
}

/// `Start FirstNotPlainData, x`: what the function value is when passed to `@Run`.
pub fn start_first_not_plain_data_o(parts_p0: crate::prelude::Array<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>>> {
    ::std::rc::Rc::new(FirstNotPlainData { parts_p0 })
}

/// ```prism
/// ?Unprintable: unbounded fn G, St, Ty -> ?((Ty, Text, Text))
/// ```
pub fn unprintable_o(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty) -> ::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)> {
    'm16182: {
        if let crate::check::types::Ty::TySig(_, inner_p3) = t_p2 {
            break 'm16182 unprintable_o(g_p0, st_p1, &**inner_p3);
        }
        if let crate::check::types::Ty::TyAt(inner_p4, _) = t_p2 {
            break 'm16182 unprintable_o(g_p0, st_p1, &**inner_p4);
        }
        if let crate::check::types::Ty::TyFn(_, _, _) = t_p2 {
            break 'm16182 ::std::option::Option::Some((t_p2.clone(), crate::prelude::Text::lit(": functions do not compare or print"), crate::prelude::Text::lit("")));
        }
        if let crate::check::types::Ty::TyTuple(parts_p5) = t_p2 {
            break 'm16182 first_unprintable_o(g_p0, st_p1, parts_p5);
        }
        if let crate::check::types::Ty::TyArray(element_p6) = t_p2 {
            break 'm16182 unprintable_o(g_p0, st_p1, &**element_p6);
        }
        if let crate::check::types::Ty::TyMap(k_p7, v_p8) = t_p2 {
            break 'm16182 first_unprintable_o(g_p0, st_p1, &crate::prelude::Array::from(vec![(**k_p7).clone(), (**v_p8).clone()]));
        }
        if let crate::check::types::Ty::TyCon(m16182_6_0, m16182_6_1) = t_p2 && (m16182_6_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m16182_6_1.len() == 1) && let ::std::option::Option::Some(c_p9) = crate::prelude::index(m16182_6_1, &crate::prelude::Nat::from(0u32)) {
            break 'm16182 unprintable_o(g_p0, st_p1, &c_p9);
        }
        if let crate::check::types::Ty::TyAny(traits_pa) = t_p2 {
            break 'm16182 if crate::prelude::run_to_end(crate::prelude::fold_job(traits_pa.clone(), false, {
                let g_p0x = g_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Text)| {
                    let g_p0xy = g_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let seen_pb = p0;
                        let tr_pc = p1;
                        if seen_pb {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            crate::prelude::call_then(start_super_closure_f(g_p0xy.clone(), tr_pc.clone()), move |super_closure_f_16655: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::has_text_f(&super_closure_f_16655, &crate::prelude::Text::lit("Prelude.Show"))))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            })) {
                ::std::option::Option::None
            } else {
                ::std::option::Option::Some((t_p2.clone(), crate::prelude::Text::lit(""), crate::prelude::Text::lit("")))
            };
        }
        if let crate::check::types::Ty::TyCon(con_pd, args_pe) = t_p2 {
            break 'm16182 if builtin_has_f(&crate::prelude::Text::lit("Prelude.Show"), con_pd) || is_row_kind_f(g_p0, con_pd) {
                ::std::option::Option::None
            } else {
                match find_impl_o(g_p0, st_p1, &crate::prelude::Text::lit("Prelude.Show"), t_p2) {
                    ::std::option::Option::Some((wants_pf, _, _, _)) => first_unprintable_o(g_p0, st_p1, &crate::prelude::fold(&wants_pf, &crate::prelude::Array::new(), &(|acc_pg: &crate::prelude::Array<crate::check::types::Ty>, (wanted_ph, cls_pi): &(crate::check::types::Ty, crate::prelude::Text)| if cls_pi == &crate::prelude::Text::lit("Prelude.Show") {
                        crate::prelude::push(acc_pg, wanted_ph)
                    } else {
                        acc_pg.clone()
                    }))),
                    ::std::option::Option::None => ::std::option::Option::Some((t_p2.clone(), crate::prelude::Text::lit(""), crate::prelude::Text::from(format!("derive `^Show` on `{}`, or write `impl ^Show {}`", &crate::check::types::bare_name_f(con_pd), &crate::check::types::bare_name_f(con_pd))))),
                }
            };
        }
        ::std::option::Option::None
    }
}

/// The step machine of `Unprintable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?Unprintable: unbounded fn G, St, Ty -> ?((Ty, Text, Text))
/// ```
pub struct Unprintable {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
}

impl ::prism_rtl::Job<::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)>> for Unprintable {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)>> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        'm16182: {
            if let crate::check::types::Ty::TySig(_, inner_p3) = t_p2 {
                break 'm16182 ::prism_rtl::Turn::More(::std::rc::Rc::new(Unprintable { g_p0: g_p0.clone(), st_p1: st_p1.clone(), t_p2: (**inner_p3).clone() }));
            }
            if let crate::check::types::Ty::TyAt(inner_p4, _) = t_p2 {
                break 'm16182 ::prism_rtl::Turn::More(::std::rc::Rc::new(Unprintable { g_p0: g_p0.clone(), st_p1: st_p1.clone(), t_p2: (**inner_p4).clone() }));
            }
            if let crate::check::types::Ty::TyFn(_, _, _) = t_p2 {
                break 'm16182 ::prism_rtl::Turn::Finished(::std::option::Option::Some((t_p2.clone(), crate::prelude::Text::lit(": functions do not compare or print"), crate::prelude::Text::lit(""))));
            }
            if let crate::check::types::Ty::TyTuple(parts_p5) = t_p2 {
                break 'm16182 ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstUnprintable { g_p0: g_p0.clone(), st_p1: st_p1.clone(), parts_p2: parts_p5.clone() }));
            }
            if let crate::check::types::Ty::TyArray(element_p6) = t_p2 {
                break 'm16182 ::prism_rtl::Turn::More(::std::rc::Rc::new(Unprintable { g_p0: g_p0.clone(), st_p1: st_p1.clone(), t_p2: (**element_p6).clone() }));
            }
            if let crate::check::types::Ty::TyMap(k_p7, v_p8) = t_p2 {
                break 'm16182 ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstUnprintable { g_p0: g_p0.clone(), st_p1: st_p1.clone(), parts_p2: crate::prelude::Array::from(vec![(**k_p7).clone(), (**v_p8).clone()]) }));
            }
            if let crate::check::types::Ty::TyCon(m16182_6_0, m16182_6_1) = t_p2 && (m16182_6_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m16182_6_1.len() == 1) && let ::std::option::Option::Some(c_p9) = crate::prelude::index(m16182_6_1, &crate::prelude::Nat::from(0u32)) {
                break 'm16182 ::prism_rtl::Turn::More(::std::rc::Rc::new(Unprintable { g_p0: g_p0.clone(), st_p1: st_p1.clone(), t_p2: c_p9.clone() }));
            }
            if let crate::check::types::Ty::TyAny(traits_pa) = t_p2 {
                break 'm16182 {
                    let g_p0x = g_p0.clone();
                    let t_p2x = t_p2.clone();
                    let traits_pax = traits_pa.clone();
                    crate::prelude::call_value(crate::prelude::fold_job(traits_pax.clone(), false, {
                        let g_p0xx = g_p0x.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Text)| {
                            let g_p0xxy = g_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let seen_pb = p0;
                                let tr_pc = p1;
                                if seen_pb {
                                    ::prism_rtl::Turn::Finished(true)
                                } else {
                                    crate::prelude::call_then(start_super_closure_f(g_p0xxy.clone(), tr_pc.clone()), move |super_closure_f_16655: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::has_text_f(&super_closure_f_16655, &crate::prelude::Text::lit("Prelude.Show"))))
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    }), move |fold_16605: bool| if fold_16605 {
                        ::prism_rtl::Turn::Finished(::std::option::Option::None)
                    } else {
                        ::prism_rtl::Turn::Finished(::std::option::Option::Some((t_p2x.clone(), crate::prelude::Text::lit(""), crate::prelude::Text::lit(""))))
                    })
                };
            }
            if let crate::check::types::Ty::TyCon(con_pd, args_pe) = t_p2 {
                break 'm16182 if builtin_has_f(&crate::prelude::Text::lit("Prelude.Show"), con_pd) || is_row_kind_f(g_p0, con_pd) {
                    ::prism_rtl::Turn::Finished(::std::option::Option::None)
                } else {
                    {
                        let con_pdx = con_pd.clone();
                        let g_p0x = g_p0.clone();
                        let st_p1x = st_p1.clone();
                        let t_p2x = t_p2.clone();
                        crate::prelude::call_then(start_find_impl_o(g_p0x.clone(), st_p1x.clone(), crate::prelude::Text::lit("Prelude.Show"), t_p2x.clone()), move |find_impl_o_16829: ::std::option::Option<(crate::prelude::Array<(crate::check::types::Ty, crate::prelude::Text)>, crate::check::types::St, crate::prelude::Text, crate::prelude::Text)>| match find_impl_o_16829 {
                            ::std::option::Option::Some((wants_pf, _, _, _)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstUnprintable { g_p0: g_p0x.clone(), st_p1: st_p1x.clone(), parts_p2: crate::prelude::fold(&wants_pf, &crate::prelude::Array::new(), &(|acc_pg: &crate::prelude::Array<crate::check::types::Ty>, (wanted_ph, cls_pi): &(crate::check::types::Ty, crate::prelude::Text)| if cls_pi == &crate::prelude::Text::lit("Prelude.Show") {
                                crate::prelude::push(acc_pg, wanted_ph)
                            } else {
                                acc_pg.clone()
                            })) })),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::Some((t_p2x.clone(), crate::prelude::Text::lit(""), crate::prelude::Text::from(format!("derive `^Show` on `{}`, or write `impl ^Show {}`", &crate::check::types::bare_name_f(&con_pdx), &crate::check::types::bare_name_f(&con_pdx)))))),
                        })
                    }
                };
            }
            ::prism_rtl::Turn::Finished(::std::option::Option::None)
        }
    }
}

/// `Start Unprintable, x`: what the function value is when passed to `@Run`.
pub fn start_unprintable_o(g_p0: crate::check::env::G, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)>>> {
    ::std::rc::Rc::new(Unprintable { g_p0, st_p1, t_p2 })
}

/// ```prism
/// IsRowKind: fn G, Text -> Bool
/// ```
pub fn is_row_kind_f(g_p0: &crate::check::env::G, con_p1: &crate::prelude::Text) -> bool {
    match crate::prelude::get(&g_p0.types_p, con_p1) {
        ::std::option::Option::Some(info_p2) => &info_p2.body_p == &crate::check::env::TyBody::BRowKind,
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// ?FirstUnprintable: unbounded fn G, St, [Ty] -> ?((Ty, Text, Text))
/// ```
pub fn first_unprintable_o(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, parts_p2: &crate::prelude::Array<crate::check::types::Ty>) -> ::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)> {
    crate::prelude::run_to_end(crate::prelude::fold_job(parts_p2.clone(), ::std::option::Option::None, {
        let g_p0x = g_p0.clone();
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)>, crate::check::types::Ty)| {
            let g_p0xy = g_p0x.clone();
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let found_o3 = p0;
                let part_p4 = p1;
                match &found_o3 {
                    ::std::option::Option::Some(f_p5) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(f_p5.clone())),
                    ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(Unprintable { g_p0: g_p0xy.clone(), st_p1: st_p1xy.clone(), t_p2: part_p4.clone() })),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)>>>>
    }))
}

/// The step machine of `FirstUnprintable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FirstUnprintable: unbounded fn G, St, [Ty] -> ?((Ty, Text, Text))
/// ```
pub struct FirstUnprintable {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub parts_p2: crate::prelude::Array<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)>> for FirstUnprintable {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)>> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let parts_p2 = &self.parts_p2;
        crate::prelude::fold_job(parts_p2.clone(), ::std::option::Option::None, {
            let g_p0x = g_p0.clone();
            let st_p1x = st_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)>, crate::check::types::Ty)| {
                let g_p0xy = g_p0x.clone();
                let st_p1xy = st_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_o3 = p0;
                    let part_p4 = p1;
                    match &found_o3 {
                        ::std::option::Option::Some(f_p5) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(f_p5.clone())),
                        ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(Unprintable { g_p0: g_p0xy.clone(), st_p1: st_p1xy.clone(), t_p2: part_p4.clone() })),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)>>>>
        }).cycle()
    }
}

/// `Start FirstUnprintable, x`: what the function value is when passed to `@Run`.
pub fn start_first_unprintable_o(g_p0: crate::check::env::G, st_p1: crate::check::types::St, parts_p2: crate::prelude::Array<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::check::types::Ty, crate::prelude::Text, crate::prelude::Text)>>> {
    ::std::rc::Rc::new(FirstUnprintable { g_p0, st_p1, parts_p2 })
}

/// ```prism
/// ?RingFrom: unbounded fn G, Text, [Text], [Text] -> ?[Text]
/// ```
pub fn ring_from_o(g_p0: &crate::check::env::G, name_p1: &crate::prelude::Text, nexts_p2: &crate::prelude::Array<crate::prelude::Text>, path_p3: &crate::prelude::Array<crate::prelude::Text>) -> ::std::option::Option<crate::prelude::Array<crate::prelude::Text>> {
    crate::prelude::run_to_end(crate::prelude::fold_job(nexts_p2.clone(), ::std::option::Option::None, {
        let name_p1x = name_p1.clone();
        let path_p3x = path_p3.clone();
        let g_p0x = g_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Array<crate::prelude::Text>>, crate::prelude::Text)| {
            let name_p1xy = name_p1x.clone();
            let path_p3xy = path_p3x.clone();
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let found_o4 = p0;
                let next_p5 = p1;
                match &found_o4 {
                    ::std::option::Option::Some(ring_p6) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(ring_p6.clone())),
                    ::std::option::Option::None => if &next_p5 == &name_p1xy {
                        ::prism_rtl::Turn::Finished(::std::option::Option::Some(path_p3xy.clone()))
                    } else {
                        if crate::check::types::has_text_f(&path_p3xy, &next_p5) {
                            ::prism_rtl::Turn::Finished(::std::option::Option::None)
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(RingFrom { g_p0: g_p0xy.clone(), name_p1: name_p1xy.clone(), nexts_p2: crate::prelude::or(&crate::prelude::get(&g_p0xy.traits_p, &next_p5), &dummy_trait_p()).supers_p.clone(), path_p3: crate::prelude::push(&path_p3xy, &next_p5) }))
                        }
                    },
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Array<crate::prelude::Text>>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<crate::prelude::Text>>>>>
    }))
}

/// The step machine of `RingFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RingFrom: unbounded fn G, Text, [Text], [Text] -> ?[Text]
/// ```
pub struct RingFrom {
    pub g_p0: crate::check::env::G,
    pub name_p1: crate::prelude::Text,
    pub nexts_p2: crate::prelude::Array<crate::prelude::Text>,
    pub path_p3: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<crate::prelude::Text>>> for RingFrom {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Array<crate::prelude::Text>>> {
        let g_p0 = &self.g_p0;
        let name_p1 = &self.name_p1;
        let nexts_p2 = &self.nexts_p2;
        let path_p3 = &self.path_p3;
        crate::prelude::fold_job(nexts_p2.clone(), ::std::option::Option::None, {
            let name_p1x = name_p1.clone();
            let path_p3x = path_p3.clone();
            let g_p0x = g_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Array<crate::prelude::Text>>, crate::prelude::Text)| {
                let name_p1xy = name_p1x.clone();
                let path_p3xy = path_p3x.clone();
                let g_p0xy = g_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_o4 = p0;
                    let next_p5 = p1;
                    match &found_o4 {
                        ::std::option::Option::Some(ring_p6) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(ring_p6.clone())),
                        ::std::option::Option::None => if &next_p5 == &name_p1xy {
                            ::prism_rtl::Turn::Finished(::std::option::Option::Some(path_p3xy.clone()))
                        } else {
                            if crate::check::types::has_text_f(&path_p3xy, &next_p5) {
                                ::prism_rtl::Turn::Finished(::std::option::Option::None)
                            } else {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(RingFrom { g_p0: g_p0xy.clone(), name_p1: name_p1xy.clone(), nexts_p2: crate::prelude::or(&crate::prelude::get(&g_p0xy.traits_p, &next_p5), &dummy_trait_p()).supers_p.clone(), path_p3: crate::prelude::push(&path_p3xy, &next_p5) }))
                            }
                        },
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Array<crate::prelude::Text>>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<crate::prelude::Text>>>>>
        }).cycle()
    }
}

/// `Start RingFrom, x`: what the function value is when passed to `@Run`.
pub fn start_ring_from_o(g_p0: crate::check::env::G, name_p1: crate::prelude::Text, nexts_p2: crate::prelude::Array<crate::prelude::Text>, path_p3: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<crate::prelude::Text>>>> {
    ::std::rc::Rc::new(RingFrom { g_p0, name_p1, nexts_p2, path_p3 })
}

/// ```prism
/// WithFile: fn St, Nat -> St
/// ```
pub fn with_file_f(s_p0: &crate::check::types::St, f_p1: &crate::prelude::Nat) -> crate::check::types::St {
    let mut this: crate::check::types::St = s_p0.clone();
    this.file_p = f_p1.clone();
    this
}

/// ```prism
/// BuiltinHas: fn Text, Text -> Bool
/// ```
pub fn builtin_has_f(cls_p0: &crate::prelude::Text, con_p1: &crate::prelude::Text) -> bool {
    let bare_p2 = crate::check::types::bare_name_f(cls_p0);
    if &bare_p2 == &crate::prelude::Text::lit("Num") {
        (((con_p1 == &crate::prelude::Text::lit("Nat")) || (con_p1 == &crate::prelude::Text::lit("Int"))) || (con_p1 == &crate::prelude::Text::lit("U8"))) || (con_p1 == &crate::prelude::Text::lit("Float"))
    } else {
        if (&bare_p2 == &crate::prelude::Text::lit("Eq")) || (&bare_p2 == &crate::prelude::Text::lit("Show")) {
            (crate::check::env::is_prim_type_f(con_p1) || (con_p1 == &crate::prelude::Text::lit("Fault"))) || (con_p1 == &crate::prelude::Text::lit("Prelude.Fault"))
        } else {
            if &bare_p2 == &crate::prelude::Text::lit("Ord") {
                ((crate::check::env::is_prim_type_f(con_p1) && !crate::check::env::is_regex_type_f(con_p1)) || (con_p1 == &crate::prelude::Text::lit("Fault"))) || (con_p1 == &crate::prelude::Text::lit("Prelude.Fault"))
            } else {
                false
            }
        }
    }
}

/// ```prism
/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
/// ```
pub fn solve_wants_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, givens_p2: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, final_p3: &bool) -> crate::check::types::St {
    let s4_p4 = solve_rounds_f(g_p0, &resolve_packs_f(st_p1, final_p3), givens_p2, &crate::prelude::Nat::from(0u32));
    if *final_p3 { default_wants_f(g_p0, &s4_p4, givens_p2) } else { s4_p4.clone() }
}

/// The step machine of `SolveWants`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
/// ```
pub struct SolveWants {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub givens_p2: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    pub final_p3: bool,
}

impl ::prism_rtl::Job<crate::check::types::St> for SolveWants {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let givens_p2 = &self.givens_p2;
        let final_p3 = &self.final_p3;
        let final_p3x = *final_p3;
        let g_p0x = g_p0.clone();
        let givens_p2x = givens_p2.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_resolve_packs_f(st_p1x.clone(), final_p3x), move |resolve_packs_f_19235: crate::check::types::St| crate::prelude::call_then(start_solve_rounds_f(g_p0x.clone(), resolve_packs_f_19235, givens_p2x.clone(), crate::prelude::Nat::from(0u32)), move |solve_rounds_f_19219: crate::check::types::St| {
            let s4_p4 = solve_rounds_f_19219;
            if final_p3x {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(DefaultWants { g_p0: g_p0x.clone(), st_p1: s4_p4.clone(), givens_p2: givens_p2x.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(s4_p4.clone())
            }
        }))
    }
}

/// `Start SolveWants, x`: what the function value is when passed to `@Run`.
pub fn start_solve_wants_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, givens_p2: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, final_p3: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(SolveWants { g_p0, st_p1, givens_p2, final_p3 })
}

/// ```prism
/// ResolvePacks: unbounded fn St, Bool -> St
/// ```
pub fn resolve_packs_f(st_p0: &crate::check::types::St, final_p1: &bool) -> crate::check::types::St {
    let cleared_p2 = {
        let mut this: crate::check::types::St = st_p0.clone();
        this.packs_p = crate::prelude::Array::new();
        this
    };
    let done_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(st_p0.packs_p.clone(), cleared_p2.clone(), {
        let final_p1x = *final_p1;
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Pack)| {
            let final_p1xy = final_p1x;
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p4 = p0;
                let p_p5 = p1;
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p4.clone(), p_p5.result_p.clone()), move |walk_f_19799: crate::check::types::Ty| match walk_f_19799 {
                    crate::check::types::Ty::TyAny(trs_p6) => ::prism_rtl::Turn::Finished({
                        let mut this: crate::check::types::St = s_p4.clone();
                        this.wants_p = crate::prelude::append(&this.wants_p, &crate::prelude::each(&trs_p6, &(|tr_p7: &crate::prelude::Text| crate::check::types::Want { cls_p: tr_p7.clone(), ty_p: p_p5.inner_p.clone(), file_p: p_p5.file_p.clone(), span_p: p_p5.span_p.clone(), level_p: this.level_p.clone() })));
                        this
                    }),
                    crate::check::types::Ty::TyFlex(_) => if final_p1xy {
                        ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&with_file_f(&s_p4, &p_p5.file_p), &crate::prelude::Text::lit("ambiguous"), &p_p5.span_p, &crate::prelude::Text::lit("nothing decides which existential this `any` packs for"), &crate::prelude::Text::lit("say it where the value goes, as `let x: any ^Show = any ...`")))
                    } else {
                        ::prism_rtl::Turn::Finished({
                            let mut this: crate::check::types::St = s_p4.clone();
                            this.packs_p = crate::prelude::push(&this.packs_p, &p_p5);
                            this
                        })
                    },
                    crate::check::types::Ty::TyErr => ::prism_rtl::Turn::Finished(s_p4.clone()),
                    other_p8 => crate::prelude::call_then(crate::check::types::start_show_ty_f(s_p4.clone(), other_p8.clone()), move |show_ty_f_20351: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&with_file_f(&s_p4, &p_p5.file_p), &crate::prelude::Text::lit("mismatch"), &p_p5.span_p, &crate::prelude::Text::from(format!("expected `{}`, found a packed value, `any ...`", &show_ty_f_20351))))),
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::Pack)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }));
    with_file_f(&done_p3, &st_p0.file_p)
}

/// The step machine of `ResolvePacks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolvePacks: unbounded fn St, Bool -> St
/// ```
pub struct ResolvePacks {
    pub st_p0: crate::check::types::St,
    pub final_p1: bool,
}

impl ::prism_rtl::Job<crate::check::types::St> for ResolvePacks {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let final_p1 = &self.final_p1;
        let cleared_p2 = {
            let mut this: crate::check::types::St = st_p0.clone();
            this.packs_p = crate::prelude::Array::new();
            this
        };
        let final_p1x = *final_p1;
        let st_p0x = st_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(st_p0x.packs_p.clone(), cleared_p2.clone(), {
            let final_p1xx = final_p1x;
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Pack)| {
                let final_p1xxy = final_p1xx;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p4 = p0;
                    let p_p5 = p1;
                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p4.clone(), p_p5.result_p.clone()), move |walk_f_19799: crate::check::types::Ty| match walk_f_19799 {
                        crate::check::types::Ty::TyAny(trs_p6) => ::prism_rtl::Turn::Finished({
                            let mut this: crate::check::types::St = s_p4.clone();
                            this.wants_p = crate::prelude::append(&this.wants_p, &crate::prelude::each(&trs_p6, &(|tr_p7: &crate::prelude::Text| crate::check::types::Want { cls_p: tr_p7.clone(), ty_p: p_p5.inner_p.clone(), file_p: p_p5.file_p.clone(), span_p: p_p5.span_p.clone(), level_p: this.level_p.clone() })));
                            this
                        }),
                        crate::check::types::Ty::TyFlex(_) => if final_p1xxy {
                            ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&with_file_f(&s_p4, &p_p5.file_p), &crate::prelude::Text::lit("ambiguous"), &p_p5.span_p, &crate::prelude::Text::lit("nothing decides which existential this `any` packs for"), &crate::prelude::Text::lit("say it where the value goes, as `let x: any ^Show = any ...`")))
                        } else {
                            ::prism_rtl::Turn::Finished({
                                let mut this: crate::check::types::St = s_p4.clone();
                                this.packs_p = crate::prelude::push(&this.packs_p, &p_p5);
                                this
                            })
                        },
                        crate::check::types::Ty::TyErr => ::prism_rtl::Turn::Finished(s_p4.clone()),
                        other_p8 => crate::prelude::call_then(crate::check::types::start_show_ty_f(s_p4.clone(), other_p8.clone()), move |show_ty_f_20351: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&with_file_f(&s_p4, &p_p5.file_p), &crate::prelude::Text::lit("mismatch"), &p_p5.span_p, &crate::prelude::Text::from(format!("expected `{}`, found a packed value, `any ...`", &show_ty_f_20351))))),
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::Pack)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }), move |fold_19761: crate::check::types::St| {
            let done_p3 = fold_19761;
            ::prism_rtl::Turn::Finished(with_file_f(&done_p3, &st_p0x.file_p))
        })
    }
}

/// `Start ResolvePacks, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_packs_f(st_p0: crate::check::types::St, final_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(ResolvePacks { st_p0, final_p1 })
}

/// ```prism
/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
/// ```
pub fn solve_rounds_f(g_p0: &crate::check::env::G, st0_p1: &crate::check::types::St, givens_p2: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, round_p3: &crate::prelude::Nat) -> crate::check::types::St {
    let st_p4 = resolve_fields_f(g_p0, &crate::check::types::unify::retry_deferred_f(st0_p1), &false);
    let cleared_p5 = {
        let mut this: crate::check::types::St = st_p4.clone();
        this.wants_p = crate::prelude::Array::new();
        this
    };
    let (keep_pc, s2_pd) = crate::prelude::run_to_end(crate::prelude::fold_job(st_p4.wants_p.clone(), (crate::prelude::Array::new(), cleared_p5.clone()), {
        let g_p0x = g_p0.clone();
        let givens_p2x = givens_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)| {
            let g_p0xy = g_p0x.clone();
            let givens_p2xy = givens_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p7, s_p8) = p0;
                let w_p9 = p1;
                crate::prelude::call_then(start_solve_one_f(g_p0xy.clone(), s_p8.clone(), givens_p2xy.clone(), w_p9.clone()), move |solve_one_f_20868: (crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)| {
                    let (left_pa, s3_pb) = solve_one_f_20868;
                    ::prism_rtl::Turn::Finished((crate::prelude::append(&acc_p7, &left_pa), s3_pb.clone()))
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)>>>
    }));
    let s4_p6 = {
        let mut this: crate::check::types::St = s2_pd.clone();
        this.wants_p = crate::prelude::append(&keep_pc, &this.wants_p);
        this
    };
    if (&s4_p6.wants_p == &st_p4.wants_p) || (round_p3 > &crate::prelude::Nat::from(6u32)) {
        s4_p6.clone()
    } else {
        solve_rounds_f(g_p0, &s4_p6, givens_p2, &(round_p3 + &crate::prelude::Nat::from(1u32)))
    }
}

/// The step machine of `SolveRounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
/// ```
pub struct SolveRounds {
    pub g_p0: crate::check::env::G,
    pub st0_p1: crate::check::types::St,
    pub givens_p2: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    pub round_p3: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::check::types::St> for SolveRounds {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st0_p1 = &self.st0_p1;
        let givens_p2 = &self.givens_p2;
        let round_p3 = &self.round_p3;
        let g_p0x = g_p0.clone();
        let givens_p2x = givens_p2.clone();
        let round_p3x = round_p3.clone();
        let st0_p1x = st0_p1.clone();
        crate::prelude::call_then(crate::check::types::unify::start_retry_deferred_f(st0_p1x.clone()), move |retry_deferred_f_20687: crate::check::types::St| crate::prelude::call_then(start_resolve_fields_f(g_p0x.clone(), retry_deferred_f_20687, false), move |resolve_fields_f_20669: crate::check::types::St| {
            let st_p4 = resolve_fields_f_20669;
            let cleared_p5 = {
                let mut this: crate::check::types::St = st_p4.clone();
                this.wants_p = crate::prelude::Array::new();
                this
            };
            crate::prelude::call_value(crate::prelude::fold_job(st_p4.wants_p.clone(), (crate::prelude::Array::new(), cleared_p5.clone()), {
                let g_p0xx = g_p0x.clone();
                let givens_p2xx = givens_p2x.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)| {
                    let g_p0xxy = g_p0xx.clone();
                    let givens_p2xxy = givens_p2xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (acc_p7, s_p8) = p0;
                        let w_p9 = p1;
                        crate::prelude::call_then(start_solve_one_f(g_p0xxy.clone(), s_p8.clone(), givens_p2xxy.clone(), w_p9.clone()), move |solve_one_f_20868: (crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)| {
                            let (left_pa, s3_pb) = solve_one_f_20868;
                            ::prism_rtl::Turn::Finished((crate::prelude::append(&acc_p7, &left_pa), s3_pb.clone()))
                        })
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)>>>
            }), move |fold_20790: (crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)| {
                let (keep_pc, s2_pd) = fold_20790;
                let s4_p6 = {
                    let mut this: crate::check::types::St = s2_pd.clone();
                    this.wants_p = crate::prelude::append(&keep_pc, &this.wants_p);
                    this
                };
                if (&s4_p6.wants_p == &st_p4.wants_p) || (&round_p3x > &crate::prelude::Nat::from(6u32)) {
                    ::prism_rtl::Turn::Finished(s4_p6.clone())
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SolveRounds { g_p0: g_p0x.clone(), st0_p1: s4_p6.clone(), givens_p2: givens_p2x.clone(), round_p3: &round_p3x + &crate::prelude::Nat::from(1u32) }))
                }
            })
        }))
    }
}

/// `Start SolveRounds, x`: what the function value is when passed to `@Run`.
pub fn start_solve_rounds_f(g_p0: crate::check::env::G, st0_p1: crate::check::types::St, givens_p2: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, round_p3: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(SolveRounds { g_p0, st0_p1, givens_p2, round_p3 })
}

/// ```prism
/// ResolveFields: unbounded fn G, St, Bool -> St
/// ```
pub fn resolve_fields_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, final_p2: &bool) -> crate::check::types::St {
    let qs_p3 = st_p1.field_qs_p.clone();
    let cleared_p4 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.field_qs_p = crate::prelude::Array::new();
        this
    };
    let done_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(qs_p3.clone(), cleared_p4.clone(), {
        let g_p0x = g_p0.clone();
        let final_p2x = *final_p2;
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::unify::FieldQ)| {
            let g_p0xy = g_p0x.clone();
            let final_p2xy = final_p2x;
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p6 = p0;
                let q_p7 = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ResolveField { g_p0: g_p0xy.clone(), st_p1: s_p6.clone(), q_p2: q_p7.clone(), final_p3: final_p2xy }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::unify::FieldQ)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }));
    with_file_f(&done_p5, &st_p1.file_p)
}

/// The step machine of `ResolveFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveFields: unbounded fn G, St, Bool -> St
/// ```
pub struct ResolveFields {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub final_p2: bool,
}

impl ::prism_rtl::Job<crate::check::types::St> for ResolveFields {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let final_p2 = &self.final_p2;
        let qs_p3 = st_p1.field_qs_p.clone();
        let cleared_p4 = {
            let mut this: crate::check::types::St = st_p1.clone();
            this.field_qs_p = crate::prelude::Array::new();
            this
        };
        let final_p2x = *final_p2;
        let g_p0x = g_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(qs_p3.clone(), cleared_p4.clone(), {
            let g_p0xx = g_p0x.clone();
            let final_p2xx = final_p2x;
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::unify::FieldQ)| {
                let g_p0xxy = g_p0xx.clone();
                let final_p2xxy = final_p2xx;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p6 = p0;
                    let q_p7 = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ResolveField { g_p0: g_p0xxy.clone(), st_p1: s_p6.clone(), q_p2: q_p7.clone(), final_p3: final_p2xxy }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::unify::FieldQ)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }), move |fold_21392: crate::check::types::St| {
            let done_p5 = fold_21392;
            ::prism_rtl::Turn::Finished(with_file_f(&done_p5, &st_p1x.file_p))
        })
    }
}

/// `Start ResolveFields, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_fields_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, final_p2: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(ResolveFields { g_p0, st_p1, final_p2 })
}

/// ```prism
/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
/// ```
pub fn resolve_field_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, q_p2: &crate::check::types::unify::FieldQ, final_p3: &bool) -> crate::check::types::St {
    let s_p4 = with_file_f(st_p1, &q_p2.file_p);
    match crate::check::types::recording::walk_f(&s_p4, &q_p2.recv_p) {
        crate::check::types::Ty::TyCon(n_p5, args_p6) => match crate::prelude::get(&g_p0.ctors_p, &n_p5) {
            ::std::option::Option::Some(c_p7) => {
                let i_o8 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p7.fields_p)), &::std::option::Option::None, &(|at_o9: &::std::option::Option<crate::prelude::Nat>, k_pa: &crate::prelude::Nat| if &crate::prelude::index(&c_p7.fields_p, k_pa) == &::std::option::Option::Some(q_p2.field_p.clone()) {
                    ::std::option::Option::Some(k_pa.clone())
                } else {
                    at_o9.clone()
                }));
                match &i_o8 {
                    ::std::option::Option::Some(i_pb) => {
                        let ft_pc = crate::check::types::schemes::subst_q_f(&crate::check::env::reading::param_inst_f(&c_p7.params_p, &args_p6), &crate::prelude::or(&crate::prelude::index(&c_p7.args_p, i_pb), &crate::check::types::Ty::TyErr));
                        field_marks_f(&crate::check::types::unify::unify_f(&s_p4, &q_p2.result_p, &ft_pc, &q_p2.span_p), q_p2, &ft_pc)
                    },
                    ::std::option::Option::None => crate::check::types::recording::err_f(&s_p4, &crate::prelude::Text::lit("mismatch"), &q_p2.span_p, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name_f(&n_p5), &q_p2.field_p))),
                }
            },
            ::std::option::Option::None => crate::check::types::recording::err_f(&s_p4, &crate::prelude::Text::lit("mismatch"), &q_p2.span_p, &crate::prelude::Text::from(format!("`{}` has no fields", &crate::check::types::bare_name_f(&n_p5)))),
        },
        crate::check::types::Ty::TyFlex(_) => if *final_p3 {
            crate::check::types::recording::err_fix_f(&s_p4, &crate::prelude::Text::lit("ambiguous"), &q_p2.span_p, &crate::prelude::Text::from(format!("nothing decides which record `.{}` reads: {} have it", &q_p2.field_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&q_p2.owners_p, &(|o_pd: &crate::prelude::Text| crate::prelude::Text::from(format!("`{}`", o_pd)))), &crate::prelude::Text::lit(", ")))), &crate::prelude::Text::lit("annotate the value\'s type, or name it from a signature"))
        } else {
            {
                let mut this: crate::check::types::St = s_p4.clone();
                this.field_qs_p = crate::prelude::push(&this.field_qs_p, q_p2);
                this
            }
        },
        crate::check::types::Ty::TyErr => s_p4.clone(),
        other_pe => crate::check::types::recording::err_f(&s_p4, &crate::prelude::Text::lit("mismatch"), &q_p2.span_p, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &crate::check::types::show_ty_f(&s_p4, &other_pe), &q_p2.field_p))),
    }
}

/// The step machine of `ResolveField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
/// ```
pub struct ResolveField {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub q_p2: crate::check::types::unify::FieldQ,
    pub final_p3: bool,
}

impl ::prism_rtl::Job<crate::check::types::St> for ResolveField {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let q_p2 = &self.q_p2;
        let final_p3 = &self.final_p3;
        let s_p4 = with_file_f(st_p1, &q_p2.file_p);
        let final_p3x = *final_p3;
        let g_p0x = g_p0.clone();
        let q_p2x = q_p2.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p4.clone(), q_p2x.recv_p.clone()), move |walk_f_21602: crate::check::types::Ty| match walk_f_21602 {
            crate::check::types::Ty::TyCon(n_p5, args_p6) => match crate::prelude::get(&g_p0x.ctors_p, &n_p5) {
                ::std::option::Option::Some(c_p7) => {
                    let i_o8 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p7.fields_p)), &::std::option::Option::None, &(|at_o9: &::std::option::Option<crate::prelude::Nat>, k_pa: &crate::prelude::Nat| if &crate::prelude::index(&c_p7.fields_p, k_pa) == &::std::option::Option::Some(q_p2x.field_p.clone()) {
                        ::std::option::Option::Some(k_pa.clone())
                    } else {
                        at_o9.clone()
                    }));
                    match &i_o8 {
                        ::std::option::Option::Some(i_pb) => {
                            let i_pbx = i_pb.clone();
                            crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(crate::check::env::reading::param_inst_f(&c_p7.params_p, &args_p6), crate::prelude::or(&crate::prelude::index(&c_p7.args_p, &i_pbx), &crate::check::types::Ty::TyErr)), move |subst_q_f_21873: crate::check::types::Ty| {
                                let ft_pc = subst_q_f_21873;
                                crate::prelude::call_then(crate::check::types::unify::start_unify_f(s_p4.clone(), q_p2x.result_p.clone(), ft_pc.clone(), q_p2x.span_p.clone()), move |unify_f_21966: crate::check::types::St| ::prism_rtl::Turn::More(::std::rc::Rc::new(FieldMarks { st_p0: unify_f_21966, q_p1: q_p2x.clone(), ft_p2: ft_pc.clone() })))
                            })
                        },
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_p4, &crate::prelude::Text::lit("mismatch"), &q_p2x.span_p, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name_f(&n_p5), &q_p2x.field_p)))),
                    }
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_p4, &crate::prelude::Text::lit("mismatch"), &q_p2x.span_p, &crate::prelude::Text::from(format!("`{}` has no fields", &crate::check::types::bare_name_f(&n_p5))))),
            },
            crate::check::types::Ty::TyFlex(_) => if final_p3x {
                ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s_p4, &crate::prelude::Text::lit("ambiguous"), &q_p2x.span_p, &crate::prelude::Text::from(format!("nothing decides which record `.{}` reads: {} have it", &q_p2x.field_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&q_p2x.owners_p, &(|o_pd: &crate::prelude::Text| crate::prelude::Text::from(format!("`{}`", o_pd)))), &crate::prelude::Text::lit(", ")))), &crate::prelude::Text::lit("annotate the value\'s type, or name it from a signature")))
            } else {
                ::prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = s_p4.clone();
                    this.field_qs_p = crate::prelude::push(&this.field_qs_p, &q_p2x);
                    this
                })
            },
            crate::check::types::Ty::TyErr => ::prism_rtl::Turn::Finished(s_p4.clone()),
            other_pe => crate::prelude::call_then(crate::check::types::start_show_ty_f(s_p4.clone(), other_pe.clone()), move |show_ty_f_22548: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_p4, &crate::prelude::Text::lit("mismatch"), &q_p2x.span_p, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &show_ty_f_22548, &q_p2x.field_p))))),
        })
    }
}

/// `Start ResolveField, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_field_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, q_p2: crate::check::types::unify::FieldQ, final_p3: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(ResolveField { g_p0, st_p1, q_p2, final_p3 })
}

/// ```prism
/// FieldMarks: unbounded fn St, FieldQ, Ty -> St
/// ```
pub fn field_marks_f(st_p0: &crate::check::types::St, q_p1: &crate::check::types::unify::FieldQ, ft_p2: &crate::check::types::Ty) -> crate::check::types::St {
    match &q_p1.marks_o {
        ::std::option::Option::Some((sigils_p3, at_p4)) => {
            let stack_p5 = crate::check::types::stack_of_f(st_p0, ft_p2);
            if (&stack_p5 == sigils_p3) || (ft_p2 == &crate::check::types::Ty::TyErr) {
                st_p0.clone()
            } else {
                crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("mark-stack"), at_p4, &crate::prelude::Text::from(format!("`.{}{}` has type `{}`, whose stack is `{}`; the access shows `{}`", sigils_p3, &q_p1.field_p, &crate::check::types::show_ty_f(st_p0, ft_p2), &stack_p5, sigils_p3)), &crate::prelude::Text::from(format!("write `.{}{}`", &stack_p5, &q_p1.field_p)))
            }
        },
        ::std::option::Option::None => st_p0.clone(),
    }
}

/// The step machine of `FieldMarks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldMarks: unbounded fn St, FieldQ, Ty -> St
/// ```
pub struct FieldMarks {
    pub st_p0: crate::check::types::St,
    pub q_p1: crate::check::types::unify::FieldQ,
    pub ft_p2: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::St> for FieldMarks {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let q_p1 = &self.q_p1;
        let ft_p2 = &self.ft_p2;
        match &q_p1.marks_o {
            ::std::option::Option::Some((sigils_p3, at_p4)) => {
                let at_p4x = at_p4.clone();
                let ft_p2x = ft_p2.clone();
                let q_p1x = q_p1.clone();
                let sigils_p3x = sigils_p3.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(crate::check::types::start_stack_of_f(st_p0x.clone(), ft_p2x.clone()), move |stack_of_f_22876: crate::prelude::Text| {
                    let stack_p5 = stack_of_f_22876;
                    if (&stack_p5 == &sigils_p3x) || (&ft_p2x == &crate::check::types::Ty::TyErr) {
                        ::prism_rtl::Turn::Finished(st_p0x.clone())
                    } else {
                        crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p0x.clone(), ft_p2x.clone()), move |show_ty_f_23013: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p0x, &crate::prelude::Text::lit("mark-stack"), &at_p4x, &crate::prelude::Text::from(format!("`.{}{}` has type `{}`, whose stack is `{}`; the access shows `{}`", &sigils_p3x, &q_p1x.field_p, &show_ty_f_23013, &stack_p5, &sigils_p3x)), &crate::prelude::Text::from(format!("write `.{}{}`", &stack_p5, &q_p1x.field_p)))))
                    }
                })
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(st_p0.clone()),
        }
    }
}

/// `Start FieldMarks, x`: what the function value is when passed to `@Run`.
pub fn start_field_marks_f(st_p0: crate::check::types::St, q_p1: crate::check::types::unify::FieldQ, ft_p2: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(FieldMarks { st_p0, q_p1, ft_p2 })
}

/// ```prism
/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
/// ```
pub fn solve_one_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, givens_p2: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, w_p3: &crate::check::types::Want) -> (crate::prelude::Array<crate::check::types::Want>, crate::check::types::St) {
    let t_p4 = crate::check::types::recording::walk_f(st_p1, &w_p3.ty_p);
    let s0_p5 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.file_p = w_p3.file_p.clone();
        this
    };
    let restore_f6 = {
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |s_p7: &crate::check::types::St| with_file_f(s_p7, &st_p1x.file_p)) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::check::types::St) -> crate::check::types::St>
    };
    'm23350: {
        if let crate::check::types::Ty::TyFlex(_) = &t_p4 {
            break 'm23350 (crate::prelude::Array::from(vec![w_p3.clone()]), st_p1.clone());
        }
        if let crate::check::types::Ty::TyErr = &t_p4 {
            break 'm23350 (crate::prelude::Array::new(), st_p1.clone());
        }
        if let crate::check::types::Ty::TyRigid(v_p8) = &t_p4 {
            break 'm23350 if (crate::syntax::lexer::chars::has_prefix_f(&w_p3.cls_p, &crate::prelude::Text::lit("Range ")) || (&w_p3.cls_p == &crate::prelude::Text::lit("Prelude.Sub"))) || (&w_p3.cls_p == &crate::prelude::Text::lit("Prelude.Signed")) {
                (crate::prelude::Array::new(), st_p1.clone())
            } else {
                if crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::append(givens_p2, &st_p1.any_givens_p), false, {
                    let v_p8x = v_p8.clone();
                    let g_p0x = g_p0.clone();
                    let w_p3x = w_p3.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Text))| {
                        let v_p8xy = v_p8x.clone();
                        let g_p0xy = g_p0x.clone();
                        let w_p3xy = w_p3x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let seen_p9 = p0;
                            let (gv_pa, gc_pb) = p1;
                            if seen_p9 {
                                ::prism_rtl::Turn::Finished(true)
                            } else {
                                if &gv_pa == &v_p8xy {
                                    crate::prelude::call_then(start_super_closure_f(g_p0xy.clone(), gc_pb.clone()), move |super_closure_f_23669: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::has_text_f(&super_closure_f_23669, &w_p3xy.cls_p)))
                                } else {
                                    ::prism_rtl::Turn::Finished(false)
                                }
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Text))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                })) {
                    if crate::syntax::lexer::chars::has_prefix_f(v_p8, &crate::prelude::Text::lit("e\'")) {
                        {
                            let bounds_pc = crate::prelude::fold(&st_p1.any_givens_p, &crate::prelude::Array::new(), &(|acc_pd: &crate::prelude::Array<crate::prelude::Text>, (gv_pe, gc_pf): &(crate::prelude::Text, crate::prelude::Text)| if gv_pe == v_p8 {
                                crate::prelude::push(acc_pd, &crate::prelude::Text::from(format!("^{}", &crate::check::types::bare_name_f(gc_pf))))
                            } else {
                                acc_pd.clone()
                            }));
                            (crate::prelude::Array::new(), (&restore_f6)(&ask_of_packed_f(g_p0, &solved_f(&s0_p5, w_p3, &t_p4, &crate::prelude::Text::lit("given")), w_p3, &crate::prelude::Text::from(format!("any {}", &crate::syntax::lexer::chars::join_f(&bounds_pc, &crate::prelude::Text::lit(" ")))))))
                        }
                    } else {
                        (crate::prelude::Array::new(), solved_f(st_p1, w_p3, &t_p4, &crate::prelude::Text::lit("given")))
                    }
                } else {
                    (crate::prelude::Array::new(), (&restore_f6)(&crate::check::types::recording::err_fix_f(&s0_p5, &crate::prelude::Text::lit("no-impl"), &w_p3.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&w_p3.cls_p), v_p8)), &crate::prelude::Text::from(format!("add `where {}: ^{}` to the signature", v_p8, &crate::check::types::bare_name_f(&w_p3.cls_p))))))
                }
            };
        }
        if let crate::check::types::Ty::TySig(s_pg, inner_ph) = &t_p4 {
            break 'm23350 if ((s_pg == &crate::prelude::Text::lit("?")) || (s_pg == &crate::prelude::Text::lit("~"))) && crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("Eq"), crate::prelude::Text::lit("Ord"), crate::prelude::Text::lit("Show")]), &crate::check::types::bare_name_f(&w_p3.cls_p)) {
                (crate::prelude::Array::from(vec![crate::check::types::Want { cls_p: w_p3.cls_p.clone(), ty_p: (**inner_ph).clone(), file_p: w_p3.file_p.clone(), span_p: w_p3.span_p.clone(), level_p: w_p3.level_p.clone() }]), solved_f(st_p1, w_p3, &t_p4, &crate::prelude::Text::lit("parts")))
            } else {
                (crate::prelude::Array::new(), (&restore_f6)(&crate::check::types::recording::err_fix_f(&s0_p5, &crate::prelude::Text::lit("no-impl"), &w_p3.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&w_p3.cls_p), &crate::check::types::show_ty_f(st_p1, &t_p4))), &crate::prelude::Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first"))))
            };
        }
        if let crate::check::types::Ty::TyCon(m23350_4_0, m23350_4_1) = &t_p4 && (m23350_4_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m23350_4_1.len() == 1) && let ::std::option::Option::Some(c_pi) = crate::prelude::index(m23350_4_1, &crate::prelude::Nat::from(0u32)) {
            break 'm23350 if crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("Eq"), crate::prelude::Text::lit("Ord"), crate::prelude::Text::lit("Show")]), &crate::check::types::bare_name_f(&w_p3.cls_p)) {
                (crate::prelude::Array::from(vec![crate::check::types::Want { cls_p: w_p3.cls_p.clone(), ty_p: c_pi.clone(), file_p: w_p3.file_p.clone(), span_p: w_p3.span_p.clone(), level_p: w_p3.level_p.clone() }]), st_p1.clone())
            } else {
                solve_at_head_f(g_p0, st_p1, &s0_p5, &{
                    let f = restore_f6.clone();
                    ::std::rc::Rc::new(move |a0: crate::check::types::St| {
                        let fy = f.clone();
                        crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                }, givens_p2, w_p3, &t_p4)
            };
        }
        if let crate::check::types::Ty::TyAt(_, _) = &t_p4 {
            break 'm23350 (crate::prelude::Array::new(), (&restore_f6)(&crate::check::types::recording::err_f(&s0_p5, &crate::prelude::Text::lit("no-impl"), &w_p3.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&w_p3.cls_p), &crate::check::types::show_ty_f(st_p1, &t_p4))))));
        }
        if let crate::check::types::Ty::TyFn(_, _, _) = &t_p4 {
            break 'm23350 (crate::prelude::Array::new(), (&restore_f6)(&crate::check::types::recording::err_f(&s0_p5, &crate::prelude::Text::lit("no-impl"), &w_p3.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`: functions do not compare or print", &crate::check::types::bare_name_f(&w_p3.cls_p), &crate::check::types::show_ty_f(st_p1, &t_p4))))));
        }
        solve_at_head_f(g_p0, st_p1, &s0_p5, &{
            let f = restore_f6.clone();
            ::std::rc::Rc::new(move |a0: crate::check::types::St| {
                let fy = f.clone();
                crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }, givens_p2, w_p3, &t_p4)
    }
}

/// The step machine of `SolveOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
/// ```
pub struct SolveOne {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub givens_p2: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    pub w_p3: crate::check::types::Want,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)> for SolveOne {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let givens_p2 = &self.givens_p2;
        let w_p3 = &self.w_p3;
        let g_p0x = g_p0.clone();
        let givens_p2x = givens_p2.clone();
        let st_p1x = st_p1.clone();
        let w_p3x = w_p3.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), w_p3x.ty_p.clone()), move |walk_f_23239: crate::check::types::Ty| {
            let t_p4 = walk_f_23239;
            let s0_p5 = {
                let mut this: crate::check::types::St = st_p1x.clone();
                this.file_p = w_p3x.file_p.clone();
                this
            };
            let restore_f6 = {
                let st_p1xx = st_p1x.clone();
                ::std::rc::Rc::new(move |s_p7: &crate::check::types::St| with_file_f(s_p7, &st_p1xx.file_p)) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::check::types::St) -> crate::check::types::St>
            };
            'm23350: {
                if let crate::check::types::Ty::TyFlex(_) = &t_p4 {
                    break 'm23350 ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![w_p3x.clone()]), st_p1x.clone()));
                }
                if let crate::check::types::Ty::TyErr = &t_p4 {
                    break 'm23350 ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), st_p1x.clone()));
                }
                if let crate::check::types::Ty::TyRigid(v_p8) = &t_p4 {
                    break 'm23350 if (crate::syntax::lexer::chars::has_prefix_f(&w_p3x.cls_p, &crate::prelude::Text::lit("Range ")) || (&w_p3x.cls_p == &crate::prelude::Text::lit("Prelude.Sub"))) || (&w_p3x.cls_p == &crate::prelude::Text::lit("Prelude.Signed")) {
                        ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), st_p1x.clone()))
                    } else {
                        {
                            let v_p8x = v_p8.clone();
                            crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::append(&givens_p2x, &st_p1x.any_givens_p), false, {
                                let v_p8xx = v_p8x.clone();
                                let g_p0xx = g_p0x.clone();
                                let w_p3xx = w_p3x.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Text))| {
                                    let v_p8xxy = v_p8xx.clone();
                                    let g_p0xxy = g_p0xx.clone();
                                    let w_p3xxy = w_p3xx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let seen_p9 = p0;
                                        let (gv_pa, gc_pb) = p1;
                                        if seen_p9 {
                                            ::prism_rtl::Turn::Finished(true)
                                        } else {
                                            if &gv_pa == &v_p8xxy {
                                                crate::prelude::call_then(start_super_closure_f(g_p0xxy.clone(), gc_pb.clone()), move |super_closure_f_23669: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::has_text_f(&super_closure_f_23669, &w_p3xxy.cls_p)))
                                            } else {
                                                ::prism_rtl::Turn::Finished(false)
                                            }
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Text))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            }), move |fold_23576: bool| if fold_23576 {
                                if crate::syntax::lexer::chars::has_prefix_f(&v_p8x, &crate::prelude::Text::lit("e\'")) {
                                    {
                                        let bounds_pc = crate::prelude::fold(&st_p1x.any_givens_p, &crate::prelude::Array::new(), &(|acc_pd: &crate::prelude::Array<crate::prelude::Text>, (gv_pe, gc_pf): &(crate::prelude::Text, crate::prelude::Text)| if gv_pe == &v_p8x {
                                            crate::prelude::push(acc_pd, &crate::prelude::Text::from(format!("^{}", &crate::check::types::bare_name_f(gc_pf))))
                                        } else {
                                            acc_pd.clone()
                                        }));
                                        crate::prelude::call_then(start_ask_of_packed_f(g_p0x.clone(), solved_f(&s0_p5, &w_p3x, &t_p4, &crate::prelude::Text::lit("given")), w_p3x.clone(), crate::prelude::Text::from(format!("any {}", &crate::syntax::lexer::chars::join_f(&bounds_pc, &crate::prelude::Text::lit(" "))))), move |ask_of_packed_f_23983: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), (&restore_f6)(&ask_of_packed_f_23983))))
                                    }
                                } else {
                                    ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), solved_f(&st_p1x, &w_p3x, &t_p4, &crate::prelude::Text::lit("given"))))
                                }
                            } else {
                                ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), (&restore_f6)(&crate::check::types::recording::err_fix_f(&s0_p5, &crate::prelude::Text::lit("no-impl"), &w_p3x.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&w_p3x.cls_p), &v_p8x)), &crate::prelude::Text::from(format!("add `where {}: ^{}` to the signature", &v_p8x, &crate::check::types::bare_name_f(&w_p3x.cls_p)))))))
                            })
                        }
                    };
                }
                if let crate::check::types::Ty::TySig(s_pg, inner_ph) = &t_p4 {
                    break 'm23350 if ((s_pg == &crate::prelude::Text::lit("?")) || (s_pg == &crate::prelude::Text::lit("~"))) && crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("Eq"), crate::prelude::Text::lit("Ord"), crate::prelude::Text::lit("Show")]), &crate::check::types::bare_name_f(&w_p3x.cls_p)) {
                        ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![crate::check::types::Want { cls_p: w_p3x.cls_p.clone(), ty_p: (**inner_ph).clone(), file_p: w_p3x.file_p.clone(), span_p: w_p3x.span_p.clone(), level_p: w_p3x.level_p.clone() }]), solved_f(&st_p1x, &w_p3x, &t_p4, &crate::prelude::Text::lit("parts"))))
                    } else {
                        crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p4.clone()), move |show_ty_f_24607: crate::prelude::Text| ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), (&restore_f6)(&crate::check::types::recording::err_fix_f(&s0_p5, &crate::prelude::Text::lit("no-impl"), &w_p3x.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&w_p3x.cls_p), &show_ty_f_24607)), &crate::prelude::Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first"))))))
                    };
                }
                if let crate::check::types::Ty::TyCon(m23350_4_0, m23350_4_1) = &t_p4 && (m23350_4_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m23350_4_1.len() == 1) && let ::std::option::Option::Some(c_pi) = crate::prelude::index(m23350_4_1, &crate::prelude::Nat::from(0u32)) {
                    break 'm23350 if crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("Eq"), crate::prelude::Text::lit("Ord"), crate::prelude::Text::lit("Show")]), &crate::check::types::bare_name_f(&w_p3x.cls_p)) {
                        ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![crate::check::types::Want { cls_p: w_p3x.cls_p.clone(), ty_p: c_pi.clone(), file_p: w_p3x.file_p.clone(), span_p: w_p3x.span_p.clone(), level_p: w_p3x.level_p.clone() }]), st_p1x.clone()))
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(SolveAtHead { g_p0: g_p0x.clone(), st_p1: st_p1x.clone(), s0_p2: s0_p5.clone(), restore_f3: {
                            let f = restore_f6.clone();
                            ::std::rc::Rc::new(move |a0: crate::check::types::St| {
                                let fy = f.clone();
                                crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                        }, givens_p4: givens_p2x.clone(), w_p5: w_p3x.clone(), t_p6: t_p4.clone() }))
                    };
                }
                if let crate::check::types::Ty::TyAt(_, _) = &t_p4 {
                    break 'm23350 crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p4.clone()), move |show_ty_f_25467: crate::prelude::Text| ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), (&restore_f6)(&crate::check::types::recording::err_f(&s0_p5, &crate::prelude::Text::lit("no-impl"), &w_p3x.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&w_p3x.cls_p), &show_ty_f_25467)))))));
                }
                if let crate::check::types::Ty::TyFn(_, _, _) = &t_p4 {
                    break 'm23350 crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p4.clone()), move |show_ty_f_25605: crate::prelude::Text| ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), (&restore_f6)(&crate::check::types::recording::err_f(&s0_p5, &crate::prelude::Text::lit("no-impl"), &w_p3x.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`: functions do not compare or print", &crate::check::types::bare_name_f(&w_p3x.cls_p), &show_ty_f_25605)))))));
                }
                ::prism_rtl::Turn::More(::std::rc::Rc::new(SolveAtHead { g_p0: g_p0x.clone(), st_p1: st_p1x.clone(), s0_p2: s0_p5.clone(), restore_f3: {
                    let f = restore_f6.clone();
                    ::std::rc::Rc::new(move |a0: crate::check::types::St| {
                        let fy = f.clone();
                        crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                }, givens_p4: givens_p2x.clone(), w_p5: w_p3x.clone(), t_p6: t_p4.clone() }))
            }
        })
    }
}

/// `Start SolveOne, x`: what the function value is when passed to `@Run`.
pub fn start_solve_one_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, givens_p2: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, w_p3: crate::check::types::Want) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)>> {
    ::std::rc::Rc::new(SolveOne { g_p0, st_p1, givens_p2, w_p3 })
}

/// ```prism
/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub fn solve_at_head_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, s0_p2: &crate::check::types::St, restore_f3: &::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>, givens_p4: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, w_p5: &crate::check::types::Want, t_p6: &crate::check::types::Ty) -> (crate::prelude::Array<crate::check::types::Want>, crate::check::types::St) {
    if crate::syntax::lexer::chars::has_prefix_f(&w_p5.cls_p, &crate::prelude::Text::lit("Range ")) {
        (crate::prelude::Array::new(), crate::prelude::run_to_end(restore_f3(literal_range_f(s0_p2, w_p5, t_p6))))
    } else {
        if (&w_p5.cls_p == &crate::prelude::Text::lit("Prelude.Sub")) || (&w_p5.cls_p == &crate::prelude::Text::lit("Prelude.Signed")) {
            (crate::prelude::Array::new(), crate::prelude::run_to_end(restore_f3(signed_at_f(s0_p2, w_p5, t_p6))))
        } else {
            solve_class_f(g_p0, st_p1, s0_p2, &restore_f3.clone(), givens_p4, w_p5, t_p6)
        }
    }
}

/// The step machine of `SolveAtHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub struct SolveAtHead {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub s0_p2: crate::check::types::St,
    pub restore_f3: ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>,
    pub givens_p4: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    pub w_p5: crate::check::types::Want,
    pub t_p6: crate::check::types::Ty,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)> for SolveAtHead {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let s0_p2 = &self.s0_p2;
        let restore_f3 = &self.restore_f3;
        let givens_p4 = &self.givens_p4;
        let w_p5 = &self.w_p5;
        let t_p6 = &self.t_p6;
        if crate::syntax::lexer::chars::has_prefix_f(&w_p5.cls_p, &crate::prelude::Text::lit("Range ")) {
            {
                let restore_f3x = restore_f3.clone();
                let s0_p2x = s0_p2.clone();
                let t_p6x = t_p6.clone();
                let w_p5x = w_p5.clone();
                crate::prelude::call_then(start_literal_range_f(s0_p2x.clone(), w_p5x.clone(), t_p6x.clone()), move |literal_range_f_25923: crate::check::types::St| crate::prelude::call_value((&restore_f3x)(literal_range_f_25923), move |restore_25914: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), restore_25914))))
            }
        } else {
            if (&w_p5.cls_p == &crate::prelude::Text::lit("Prelude.Sub")) || (&w_p5.cls_p == &crate::prelude::Text::lit("Prelude.Signed")) {
                {
                    let restore_f3x = restore_f3.clone();
                    let s0_p2x = s0_p2.clone();
                    let t_p6x = t_p6.clone();
                    let w_p5x = w_p5.clone();
                    crate::prelude::call_then(start_signed_at_f(s0_p2x.clone(), w_p5x.clone(), t_p6x.clone()), move |signed_at_f_26031: crate::check::types::St| crate::prelude::call_value((&restore_f3x)(signed_at_f_26031), move |restore_26022: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), restore_26022))))
                }
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(SolveClass { g_p0: g_p0.clone(), st_p1: st_p1.clone(), s0_p2: s0_p2.clone(), restore_f3: restore_f3.clone(), givens_p4: givens_p4.clone(), w_p5: w_p5.clone(), t_p6: t_p6.clone() }))
            }
        }
    }
}

/// `Start SolveAtHead, x`: what the function value is when passed to `@Run`.
pub fn start_solve_at_head_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, s0_p2: crate::check::types::St, restore_f3: ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>, givens_p4: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, w_p5: crate::check::types::Want, t_p6: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)>> {
    ::std::rc::Rc::new(SolveAtHead { g_p0, st_p1, s0_p2, restore_f3, givens_p4, w_p5, t_p6 })
}

/// ```prism
/// LiteralRange: unbounded fn St, Want, Ty -> St
/// ```
pub fn literal_range_f(st_p0: &crate::check::types::St, w_p1: &crate::check::types::Want, t_p2: &crate::check::types::Ty) -> crate::check::types::St {
    let lit_p3 = crate::syntax::lexer::chars::drop_prefix_f(&w_p1.cls_p, &crate::prelude::Text::lit("Range "));
    let negative_p4 = crate::syntax::lexer::chars::has_prefix_f(&lit_p3, &crate::prelude::Text::lit("-"));
    let digits_p5 = if negative_p4 {
        crate::syntax::lexer::chars::after_first_f(&lit_p3)
    } else {
        lit_p3.clone()
    };
    let n_o6 = crate::prelude::parse_nat_opt(&digits_p5);
    match t_p2 {
        crate::check::types::Ty::TyCon(m26429_0_0, m26429_0_1) if (m26429_0_0 == &crate::prelude::Text::lit("Nat")) && (m26429_0_1.len() == 0) => if negative_p4 && (&digits_p5 != &crate::prelude::Text::lit("0")) {
            crate::check::types::recording::err_f(st_p0, &crate::prelude::Text::lit("literal-range"), &w_p1.span_p, &crate::prelude::Text::from(format!("`{}` does not fit `Nat`", &lit_p3)))
        } else {
            st_p0.clone()
        },
        crate::check::types::Ty::TyCon(m26429_1_0, m26429_1_1) if (m26429_1_0 == &crate::prelude::Text::lit("U8")) && (m26429_1_1.len() == 0) => match &n_o6 {
            ::std::option::Option::Some(v_p7) => if negative_p4 || (v_p7 > &crate::prelude::Nat::from(255u32)) {
                crate::check::types::recording::err_f(st_p0, &crate::prelude::Text::lit("literal-range"), &w_p1.span_p, &crate::prelude::Text::from(format!("`{}` does not fit `U8`", &lit_p3)))
            } else {
                st_p0.clone()
            },
            ::std::option::Option::None => st_p0.clone(),
        },
        _ => st_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LiteralRange`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralRange: unbounded fn St, Want, Ty -> St
/// ```
pub struct LiteralRange {
    pub st_p0: crate::check::types::St,
    pub w_p1: crate::check::types::Want,
    pub t_p2: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::St> for LiteralRange {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let w_p1 = &self.w_p1;
        let t_p2 = &self.t_p2;
        let lit_p3 = crate::syntax::lexer::chars::drop_prefix_f(&w_p1.cls_p, &crate::prelude::Text::lit("Range "));
        let negative_p4 = crate::syntax::lexer::chars::has_prefix_f(&lit_p3, &crate::prelude::Text::lit("-"));
        let digits_p5 = if negative_p4 {
            crate::syntax::lexer::chars::after_first_f(&lit_p3)
        } else {
            lit_p3.clone()
        };
        let n_o6 = crate::prelude::parse_nat_opt(&digits_p5);
        match t_p2 {
            crate::check::types::Ty::TyCon(m26429_0_0, m26429_0_1) if (m26429_0_0 == &crate::prelude::Text::lit("Nat")) && (m26429_0_1.len() == 0) => if negative_p4 && (&digits_p5 != &crate::prelude::Text::lit("0")) {
                ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(st_p0, &crate::prelude::Text::lit("literal-range"), &w_p1.span_p, &crate::prelude::Text::from(format!("`{}` does not fit `Nat`", &lit_p3))))
            } else {
                ::prism_rtl::Turn::Finished(st_p0.clone())
            },
            crate::check::types::Ty::TyCon(m26429_1_0, m26429_1_1) if (m26429_1_0 == &crate::prelude::Text::lit("U8")) && (m26429_1_1.len() == 0) => match &n_o6 {
                ::std::option::Option::Some(v_p7) => if negative_p4 || (v_p7 > &crate::prelude::Nat::from(255u32)) {
                    ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(st_p0, &crate::prelude::Text::lit("literal-range"), &w_p1.span_p, &crate::prelude::Text::from(format!("`{}` does not fit `U8`", &lit_p3))))
                } else {
                    ::prism_rtl::Turn::Finished(st_p0.clone())
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(st_p0.clone()),
            },
            _ => ::prism_rtl::Turn::Finished(st_p0.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LiteralRange, x`: what the function value is when passed to `@Run`.
pub fn start_literal_range_f(st_p0: crate::check::types::St, w_p1: crate::check::types::Want, t_p2: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(LiteralRange { st_p0, w_p1, t_p2 })
}

/// ```prism
/// SignedAt: unbounded fn St, Want, Ty -> St
/// ```
pub fn signed_at_f(st_p0: &crate::check::types::St, w_p1: &crate::check::types::Want, t_p2: &crate::check::types::Ty) -> crate::check::types::St {
    match t_p2 {
        crate::check::types::Ty::TyCon(m26900_0_0, m26900_0_1) if (m26900_0_0 == &crate::prelude::Text::lit("Nat")) && (m26900_0_1.len() == 0) => if &w_p1.cls_p == &crate::prelude::Text::lit("Prelude.Sub") {
            crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("nat-minus"), &w_p1.span_p, &crate::prelude::Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), &crate::prelude::Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`"))
        } else {
            st_p0.clone()
        },
        crate::check::types::Ty::TyCon(m26900_1_0, m26900_1_1) if (m26900_1_0 == &crate::prelude::Text::lit("U8")) && (m26900_1_1.len() == 0) => if &w_p1.cls_p == &crate::prelude::Text::lit("Prelude.Sub") {
            st_p0.clone()
        } else {
            st_p0.clone()
        },
        _ => st_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SignedAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SignedAt: unbounded fn St, Want, Ty -> St
/// ```
pub struct SignedAt {
    pub st_p0: crate::check::types::St,
    pub w_p1: crate::check::types::Want,
    pub t_p2: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::St> for SignedAt {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let w_p1 = &self.w_p1;
        let t_p2 = &self.t_p2;
        match t_p2 {
            crate::check::types::Ty::TyCon(m26900_0_0, m26900_0_1) if (m26900_0_0 == &crate::prelude::Text::lit("Nat")) && (m26900_0_1.len() == 0) => if &w_p1.cls_p == &crate::prelude::Text::lit("Prelude.Sub") {
                ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("nat-minus"), &w_p1.span_p, &crate::prelude::Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), &crate::prelude::Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`")))
            } else {
                ::prism_rtl::Turn::Finished(st_p0.clone())
            },
            crate::check::types::Ty::TyCon(m26900_1_0, m26900_1_1) if (m26900_1_0 == &crate::prelude::Text::lit("U8")) && (m26900_1_1.len() == 0) => if &w_p1.cls_p == &crate::prelude::Text::lit("Prelude.Sub") {
                ::prism_rtl::Turn::Finished(st_p0.clone())
            } else {
                ::prism_rtl::Turn::Finished(st_p0.clone())
            },
            _ => ::prism_rtl::Turn::Finished(st_p0.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SignedAt, x`: what the function value is when passed to `@Run`.
pub fn start_signed_at_f(st_p0: crate::check::types::St, w_p1: crate::check::types::Want, t_p2: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(SignedAt { st_p0, w_p1, t_p2 })
}

/// ```prism
/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub fn solve_class_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, s0_p2: &crate::check::types::St, restore_f3: &::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>, givens_p4: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, w_p5: &crate::check::types::Want, t_p6: &crate::check::types::Ty) -> (crate::prelude::Array<crate::check::types::Want>, crate::check::types::St) {
    let bare_p7 = crate::check::types::bare_name_f(&w_p5.cls_p);
    let parts_o8 = match t_p6 {
        crate::check::types::Ty::TyTuple(ts_pa) => ::std::option::Option::Some(ts_pa.clone()),
        crate::check::types::Ty::TyArray(e_pb) => ::std::option::Option::Some(crate::prelude::Array::from(vec![(**e_pb).clone()])),
        crate::check::types::Ty::TyMap(k_pc, v_pd) => ::std::option::Option::Some(crate::prelude::Array::from(vec![(**k_pc).clone(), (**v_pd).clone()])),
        _ => ::std::option::Option::None,
    };
    let structural_p9 = ((&bare_p7 == &crate::prelude::Text::lit("Eq")) || (&bare_p7 == &crate::prelude::Text::lit("Ord"))) || (&bare_p7 == &crate::prelude::Text::lit("Show"));
    match &parts_o8 {
        ::std::option::Option::Some(ps_pe) => if structural_p9 {
            (crate::prelude::each(ps_pe, &(|p_pf: &crate::check::types::Ty| crate::check::types::Want { cls_p: w_p5.cls_p.clone(), ty_p: p_pf.clone(), file_p: w_p5.file_p.clone(), span_p: w_p5.span_p.clone(), level_p: w_p5.level_p.clone() })), solved_f(st_p1, w_p5, t_p6, &crate::prelude::Text::lit("parts")))
        } else {
            match find_impl_o(g_p0, st_p1, &w_p5.cls_p, t_p6) {
                ::std::option::Option::Some((im_pg, s2_ph, how_pi, ch_pj)) => {
                    let wants_pk = crate::prelude::each(&im_pg, &(|(ty_pl, cls_pm): &(crate::check::types::Ty, crate::prelude::Text)| crate::check::types::Want { cls_p: cls_pm.clone(), ty_p: ty_pl.clone(), file_p: w_p5.file_p.clone(), span_p: w_p5.span_p.clone(), level_p: w_p5.level_p.clone() }));
                    (wants_pk.clone(), note_impl_use_f(g_p0, &crate::check::types::recording::note_choice_f(&solved_f(&s2_ph, w_p5, t_p6, &how_pi), &w_p5.file_p, &w_p5.span_p, &w_p5.cls_p, &ch_pj), w_p5, t_p6))
                },
                ::std::option::Option::None => (crate::prelude::Array::new(), crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_f(s0_p2, &crate::prelude::Text::lit("no-impl"), &w_p5.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &crate::check::types::show_ty_f(st_p1, t_p6))))))),
            }
        },
        ::std::option::Option::None => match t_p6 {
            crate::check::types::Ty::TySig(_, _) => (crate::prelude::Array::new(), st_p1.clone()),
            crate::check::types::Ty::TyElem(rw_pn, _) => elem_trait_f(g_p0, st_p1, s0_p2, &restore_f3.clone(), w_p5, t_p6, &bare_p7, rw_pn),
            crate::check::types::Ty::TyElemAny(rw_po) => elem_trait_f(g_p0, st_p1, s0_p2, &restore_f3.clone(), w_p5, t_p6, &bare_p7, rw_po),
            crate::check::types::Ty::TyAny(trs_pp) if crate::check::types::has_text_f(&super_closure_f(g_p0, &w_p5.cls_p), &crate::prelude::Text::lit("Prelude.Eq")) => (crate::prelude::Array::new(), crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_f(s0_p2, &crate::prelude::Text::lit("no-impl"), &w_p5.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`: each existential hides a type of its own, so two do not compare", &bare_p7, &crate::check::types::show_ty_f(st_p1, t_p6))))))),
            crate::check::types::Ty::TyAny(trs_pq) => if crate::check::types::has_text_f(trs_pq, &w_p5.cls_p) || crate::prelude::run_to_end(crate::prelude::fold_job(trs_pq.clone(), false, {
                let g_p0x = g_p0.clone();
                let w_p5x = w_p5.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Text)| {
                    let g_p0xy = g_p0x.clone();
                    let w_p5xy = w_p5x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let seen_pr = p0;
                        let tr_ps = p1;
                        if seen_pr {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            crate::prelude::call_then(start_super_closure_f(g_p0xy.clone(), tr_ps.clone()), move |super_closure_f_29062: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::has_text_f(&super_closure_f_29062, &w_p5xy.cls_p)))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            })) {
                (crate::prelude::Array::new(), crate::prelude::run_to_end(restore_f3(ask_of_packed_f(g_p0, &solved_f(s0_p2, w_p5, t_p6, &crate::prelude::Text::lit("packed")), w_p5, &crate::check::types::show_ty_f(st_p1, t_p6)))))
            } else {
                (crate::prelude::Array::new(), crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_f(s0_p2, &crate::prelude::Text::lit("no-impl"), &w_p5.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &crate::check::types::show_ty_f(st_p1, t_p6)))))))
            },
            crate::check::types::Ty::TyCon(con_pt, args_pu) => if builtin_has_f(&w_p5.cls_p, con_pt) {
                (crate::prelude::Array::new(), solved_f(st_p1, w_p5, t_p6, &crate::prelude::Text::lit("builtin")))
            } else {
                match find_impl_o(g_p0, st_p1, &w_p5.cls_p, t_p6) {
                    ::std::option::Option::Some((im_pv, s2_p10, how_p11, ch_p12)) => {
                        let wants_p13 = crate::prelude::each(&im_pv, &(|(ty_p14, cls_p15): &(crate::check::types::Ty, crate::prelude::Text)| crate::check::types::Want { cls_p: cls_p15.clone(), ty_p: ty_p14.clone(), file_p: w_p5.file_p.clone(), span_p: w_p5.span_p.clone(), level_p: w_p5.level_p.clone() }));
                        (wants_p13.clone(), note_impl_use_f(g_p0, &crate::check::types::recording::note_choice_f(&solved_f(&s2_p10, w_p5, t_p6, &how_p11), &w_p5.file_p, &w_p5.span_p, &w_p5.cls_p, &ch_p12), w_p5, t_p6))
                    },
                    ::std::option::Option::None => {
                        let fix_p16 = if ((&bare_p7 == &crate::prelude::Text::lit("Num")) && (con_pt == &crate::prelude::Text::lit("Text"))) || crate::check::env::is_regex_type_f(con_pt) {
                            crate::prelude::Text::lit("")
                        } else {
                            if con_pt == &crate::prelude::Text::lit("Prelude.NonEmpty") {
                                crate::prelude::Text::from(format!("write `impl ^{} {}`, or pass the collection it is, with `as {}`", &bare_p7, &crate::check::types::show_ty_f(st_p1, t_p6), &crate::check::types::show_ty_f(st_p1, &crate::prelude::or(&crate::prelude::index(args_pu, &crate::prelude::Nat::from(0u32)), &crate::check::types::Ty::TyErr))))
                            } else {
                                crate::prelude::Text::from(format!("derive `^{}` on `{}`, or write `impl ^{} {}`", &bare_p7, &crate::check::types::bare_name_f(con_pt), &bare_p7, &crate::check::types::bare_name_f(con_pt)))
                            }
                        };
                        (crate::prelude::Array::new(), crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_fix_f(s0_p2, &crate::prelude::Text::lit("no-impl"), &w_p5.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &crate::check::types::show_ty_f(st_p1, t_p6))), &fix_p16))))
                    },
                }
            },
            _ => (crate::prelude::Array::new(), st_p1.clone()),
            _ => unreachable!("no arm matched"),
        },
    }
}

/// The step machine of `SolveClass`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub struct SolveClass {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub s0_p2: crate::check::types::St,
    pub restore_f3: ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>,
    pub givens_p4: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    pub w_p5: crate::check::types::Want,
    pub t_p6: crate::check::types::Ty,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)> for SolveClass {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let s0_p2 = &self.s0_p2;
        let restore_f3 = &self.restore_f3;
        let givens_p4 = &self.givens_p4;
        let w_p5 = &self.w_p5;
        let t_p6 = &self.t_p6;
        let bare_p7 = crate::check::types::bare_name_f(&w_p5.cls_p);
        let parts_o8 = match t_p6 {
            crate::check::types::Ty::TyTuple(ts_pa) => ::std::option::Option::Some(ts_pa.clone()),
            crate::check::types::Ty::TyArray(e_pb) => ::std::option::Option::Some(crate::prelude::Array::from(vec![(**e_pb).clone()])),
            crate::check::types::Ty::TyMap(k_pc, v_pd) => ::std::option::Option::Some(crate::prelude::Array::from(vec![(**k_pc).clone(), (**v_pd).clone()])),
            _ => ::std::option::Option::None,
        };
        let structural_p9 = ((&bare_p7 == &crate::prelude::Text::lit("Eq")) || (&bare_p7 == &crate::prelude::Text::lit("Ord"))) || (&bare_p7 == &crate::prelude::Text::lit("Show"));
        match &parts_o8 {
            ::std::option::Option::Some(ps_pe) => if structural_p9 {
                ::prism_rtl::Turn::Finished((crate::prelude::each(ps_pe, &(|p_pf: &crate::check::types::Ty| crate::check::types::Want { cls_p: w_p5.cls_p.clone(), ty_p: p_pf.clone(), file_p: w_p5.file_p.clone(), span_p: w_p5.span_p.clone(), level_p: w_p5.level_p.clone() })), solved_f(st_p1, w_p5, t_p6, &crate::prelude::Text::lit("parts"))))
            } else {
                {
                    let restore_f3x = restore_f3.clone();
                    let g_p0x = g_p0.clone();
                    let s0_p2x = s0_p2.clone();
                    let st_p1x = st_p1.clone();
                    let t_p6x = t_p6.clone();
                    let w_p5x = w_p5.clone();
                    crate::prelude::call_then(start_find_impl_o(g_p0x.clone(), st_p1x.clone(), w_p5x.cls_p.clone(), t_p6x.clone()), move |find_impl_o_27930: ::std::option::Option<(crate::prelude::Array<(crate::check::types::Ty, crate::prelude::Text)>, crate::check::types::St, crate::prelude::Text, crate::prelude::Text)>| match find_impl_o_27930 {
                        ::std::option::Option::Some((im_pg, s2_ph, how_pi, ch_pj)) => {
                            let wants_pk = crate::prelude::each(&im_pg, &(|(ty_pl, cls_pm): &(crate::check::types::Ty, crate::prelude::Text)| crate::check::types::Want { cls_p: cls_pm.clone(), ty_p: ty_pl.clone(), file_p: w_p5x.file_p.clone(), span_p: w_p5x.span_p.clone(), level_p: w_p5x.level_p.clone() }));
                            crate::prelude::call_then(start_note_impl_use_f(g_p0x.clone(), crate::check::types::recording::note_choice_f(&solved_f(&s2_ph, &w_p5x, &t_p6x, &how_pi), &w_p5x.file_p, &w_p5x.span_p, &w_p5x.cls_p, &ch_pj), w_p5x.clone(), t_p6x.clone()), move |note_impl_use_f_28144: crate::check::types::St| ::prism_rtl::Turn::Finished((wants_pk.clone(), note_impl_use_f_28144)))
                        },
                        ::std::option::Option::None => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p6x.clone()), move |show_ty_f_28324: crate::prelude::Text| crate::prelude::call_value((&restore_f3x)(crate::check::types::recording::err_f(&s0_p2x, &crate::prelude::Text::lit("no-impl"), &w_p5x.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &show_ty_f_28324)))), move |restore_28260: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), restore_28260)))),
                    })
                }
            },
            ::std::option::Option::None => match t_p6 {
                crate::check::types::Ty::TySig(_, _) => ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), st_p1.clone())),
                crate::check::types::Ty::TyElem(rw_pn, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ElemTrait { g_p0: g_p0.clone(), st_p1: st_p1.clone(), s0_p2: s0_p2.clone(), restore_f3: restore_f3.clone(), w_p4: w_p5.clone(), t_p5: t_p6.clone(), bare_p6: bare_p7.clone(), rw_p7: rw_pn.clone() })),
                crate::check::types::Ty::TyElemAny(rw_po) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ElemTrait { g_p0: g_p0.clone(), st_p1: st_p1.clone(), s0_p2: s0_p2.clone(), restore_f3: restore_f3.clone(), w_p4: w_p5.clone(), t_p5: t_p6.clone(), bare_p6: bare_p7.clone(), rw_p7: rw_po.clone() })),
                crate::check::types::Ty::TyAny(trs_pp) if crate::check::types::has_text_f(&super_closure_f(g_p0, &w_p5.cls_p), &crate::prelude::Text::lit("Prelude.Eq")) => {
                    let restore_f3x = restore_f3.clone();
                    let s0_p2x = s0_p2.clone();
                    let st_p1x = st_p1.clone();
                    let t_p6x = t_p6.clone();
                    let w_p5x = w_p5.clone();
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p6x.clone()), move |show_ty_f_28880: crate::prelude::Text| crate::prelude::call_value((&restore_f3x)(crate::check::types::recording::err_f(&s0_p2x, &crate::prelude::Text::lit("no-impl"), &w_p5x.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`: each existential hides a type of its own, so two do not compare", &bare_p7, &show_ty_f_28880)))), move |restore_28816: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), restore_28816))))
                },
                crate::check::types::Ty::TyAny(trs_pq) => if crate::check::types::has_text_f(trs_pq, &w_p5.cls_p) || crate::prelude::run_to_end(crate::prelude::fold_job(trs_pq.clone(), false, {
                    let g_p0x = g_p0.clone();
                    let w_p5x = w_p5.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Text)| {
                        let g_p0xy = g_p0x.clone();
                        let w_p5xy = w_p5x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let seen_pr = p0;
                            let tr_ps = p1;
                            if seen_pr {
                                ::prism_rtl::Turn::Finished(true)
                            } else {
                                crate::prelude::call_then(start_super_closure_f(g_p0xy.clone(), tr_ps.clone()), move |super_closure_f_29062: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::has_text_f(&super_closure_f_29062, &w_p5xy.cls_p)))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                })) {
                    {
                        let restore_f3x = restore_f3.clone();
                        let g_p0x = g_p0.clone();
                        let s0_p2x = s0_p2.clone();
                        let st_p1x = st_p1.clone();
                        let t_p6x = t_p6.clone();
                        let w_p5x = w_p5.clone();
                        crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p6x.clone()), move |show_ty_f_29157: crate::prelude::Text| crate::prelude::call_then(start_ask_of_packed_f(g_p0x.clone(), solved_f(&s0_p2x, &w_p5x, &t_p6x, &crate::prelude::Text::lit("packed")), w_p5x.clone(), show_ty_f_29157), move |ask_of_packed_f_29109: crate::check::types::St| crate::prelude::call_value((&restore_f3x)(ask_of_packed_f_29109), move |restore_29100: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), restore_29100)))))
                    }
                } else {
                    {
                        let restore_f3x = restore_f3.clone();
                        let s0_p2x = s0_p2.clone();
                        let st_p1x = st_p1.clone();
                        let t_p6x = t_p6.clone();
                        let w_p5x = w_p5.clone();
                        crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p6x.clone()), move |show_ty_f_29252: crate::prelude::Text| crate::prelude::call_value((&restore_f3x)(crate::check::types::recording::err_f(&s0_p2x, &crate::prelude::Text::lit("no-impl"), &w_p5x.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &show_ty_f_29252)))), move |restore_29188: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), restore_29188))))
                    }
                },
                crate::check::types::Ty::TyCon(con_pt, args_pu) => if builtin_has_f(&w_p5.cls_p, con_pt) {
                    ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), solved_f(st_p1, w_p5, t_p6, &crate::prelude::Text::lit("builtin"))))
                } else {
                    {
                        let restore_f3x = restore_f3.clone();
                        let args_pux = args_pu.clone();
                        let con_ptx = con_pt.clone();
                        let g_p0x = g_p0.clone();
                        let s0_p2x = s0_p2.clone();
                        let st_p1x = st_p1.clone();
                        let t_p6x = t_p6.clone();
                        let w_p5x = w_p5.clone();
                        crate::prelude::call_then(start_find_impl_o(g_p0x.clone(), st_p1x.clone(), w_p5x.cls_p.clone(), t_p6x.clone()), move |find_impl_o_29409: ::std::option::Option<(crate::prelude::Array<(crate::check::types::Ty, crate::prelude::Text)>, crate::check::types::St, crate::prelude::Text, crate::prelude::Text)>| match find_impl_o_29409 {
                            ::std::option::Option::Some((im_pv, s2_p10, how_p11, ch_p12)) => {
                                let wants_p13 = crate::prelude::each(&im_pv, &(|(ty_p14, cls_p15): &(crate::check::types::Ty, crate::prelude::Text)| crate::check::types::Want { cls_p: cls_p15.clone(), ty_p: ty_p14.clone(), file_p: w_p5x.file_p.clone(), span_p: w_p5x.span_p.clone(), level_p: w_p5x.level_p.clone() }));
                                crate::prelude::call_then(start_note_impl_use_f(g_p0x.clone(), crate::check::types::recording::note_choice_f(&solved_f(&s2_p10, &w_p5x, &t_p6x, &how_p11), &w_p5x.file_p, &w_p5x.span_p, &w_p5x.cls_p, &ch_p12), w_p5x.clone(), t_p6x.clone()), move |note_impl_use_f_29635: crate::check::types::St| ::prism_rtl::Turn::Finished((wants_p13.clone(), note_impl_use_f_29635)))
                            },
                            ::std::option::Option::None => {
                                let restore_f3xz = restore_f3x.clone();
                                let bare_p7z = bare_p7.clone();
                                let s0_p2xz = s0_p2x.clone();
                                let st_p1xz = st_p1x.clone();
                                let t_p6xz = t_p6x.clone();
                                let w_p5xz = w_p5x.clone();
                                let k_let29771 = move |v29771: crate::prelude::Text| {
                                    let fix_p16 = v29771;
                                    crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1xz.clone(), t_p6xz.clone()), move |show_ty_f_30223: crate::prelude::Text| crate::prelude::call_value((&restore_f3xz)(crate::check::types::recording::err_fix_f(&s0_p2xz, &crate::prelude::Text::lit("no-impl"), &w_p5xz.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`", &bare_p7z, &show_ty_f_30223)), &fix_p16)), move |restore_30156: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), restore_30156))))
                                };
                                if ((&bare_p7 == &crate::prelude::Text::lit("Num")) && (&con_ptx == &crate::prelude::Text::lit("Text"))) || crate::check::env::is_regex_type_f(&con_ptx) {
                                    k_let29771(crate::prelude::Text::lit(""))
                                } else {
                                    if &con_ptx == &crate::prelude::Text::lit("Prelude.NonEmpty") {
                                        crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p6x.clone()), move |show_ty_f_29925: crate::prelude::Text| crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), crate::prelude::or(&crate::prelude::index(&args_pux, &crate::prelude::Nat::from(0u32)), &crate::check::types::Ty::TyErr)), move |show_ty_f_29981: crate::prelude::Text| k_let29771(crate::prelude::Text::from(format!("write `impl ^{} {}`, or pass the collection it is, with `as {}`", &bare_p7, &show_ty_f_29925, &show_ty_f_29981)))))
                                    } else {
                                        k_let29771(crate::prelude::Text::from(format!("derive `^{}` on `{}`, or write `impl ^{} {}`", &bare_p7, &crate::check::types::bare_name_f(&con_ptx), &bare_p7, &crate::check::types::bare_name_f(&con_ptx))))
                                    }
                                }
                            },
                        })
                    }
                },
                _ => ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), st_p1.clone())),
                _ => unreachable!("no arm matched"),
            },
        }
    }
}

/// `Start SolveClass, x`: what the function value is when passed to `@Run`.
pub fn start_solve_class_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, s0_p2: crate::check::types::St, restore_f3: ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>, givens_p4: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, w_p5: crate::check::types::Want, t_p6: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)>> {
    ::std::rc::Rc::new(SolveClass { g_p0, st_p1, s0_p2, restore_f3, givens_p4, w_p5, t_p6 })
}

/// ```prism
/// AskOfPacked: unbounded fn G, St, Want, Text -> St
/// ```
pub fn ask_of_packed_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, w_p2: &crate::check::types::Want, shown_p3: &crate::prelude::Text) -> crate::check::types::St {
    let fix_p4 = crate::prelude::Text::lit("ask it of a value whose type is known, before `any` packs it");
    let own_o5 = match crate::prelude::get(&st_p1.method_uses_p, &crate::check::types::use_key_f(&w_p2.file_p, &w_p2.span_p)) {
        ::std::option::Option::Some(method_p6) => if &method_trait_f(g_p0, &method_p6) == &w_p2.cls_p {
            ::std::option::Option::Some(method_p6.clone())
        } else {
            ::std::option::Option::None
        },
        ::std::option::Option::None => ::std::option::Option::None,
    };
    match &own_o5 {
        ::std::option::Option::Some(method_p7) => match packed_refusal_o(g_p0, st_p1, method_p7) {
            ::std::option::Option::Some(why_p8) => crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("existential-method"), &w_p2.span_p, &crate::prelude::Text::from(format!("`{}` cannot be asked of the value packed in `{}`: {}", &crate::check::types::bare_name_f(method_p7), shown_p3, &why_p8)), &fix_p4),
            ::std::option::Option::None => st_p1.clone(),
        },
        ::std::option::Option::None => match trait_refusal_o(g_p0, st_p1, &w_p2.cls_p) {
            ::std::option::Option::Some((method_p9, why_pa)) => crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("existential-method"), &w_p2.span_p, &crate::prelude::Text::from(format!("`^{}` is asked of the value packed in `{}` here, and its method `{}` cannot be asked of one: {}", &crate::check::types::bare_name_f(&w_p2.cls_p), shown_p3, &crate::check::types::bare_name_f(&method_p9), &why_pa)), &fix_p4),
            ::std::option::Option::None => st_p1.clone(),
        },
    }
}

/// The step machine of `AskOfPacked`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AskOfPacked: unbounded fn G, St, Want, Text -> St
/// ```
pub struct AskOfPacked {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub w_p2: crate::check::types::Want,
    pub shown_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::check::types::St> for AskOfPacked {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let w_p2 = &self.w_p2;
        let shown_p3 = &self.shown_p3;
        let fix_p4 = crate::prelude::Text::lit("ask it of a value whose type is known, before `any` packs it");
        let own_o5 = match crate::prelude::get(&st_p1.method_uses_p, &crate::check::types::use_key_f(&w_p2.file_p, &w_p2.span_p)) {
            ::std::option::Option::Some(method_p6) => if &method_trait_f(g_p0, &method_p6) == &w_p2.cls_p {
                ::std::option::Option::Some(method_p6.clone())
            } else {
                ::std::option::Option::None
            },
            ::std::option::Option::None => ::std::option::Option::None,
        };
        match &own_o5 {
            ::std::option::Option::Some(method_p7) => {
                let g_p0x = g_p0.clone();
                let method_p7x = method_p7.clone();
                let shown_p3x = shown_p3.clone();
                let st_p1x = st_p1.clone();
                let w_p2x = w_p2.clone();
                crate::prelude::call_then(start_packed_refusal_o(g_p0x.clone(), st_p1x.clone(), method_p7x.clone()), move |packed_refusal_o_31168: ::std::option::Option<crate::prelude::Text>| match packed_refusal_o_31168 {
                    ::std::option::Option::Some(why_p8) => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("existential-method"), &w_p2x.span_p, &crate::prelude::Text::from(format!("`{}` cannot be asked of the value packed in `{}`: {}", &crate::check::types::bare_name_f(&method_p7x), &shown_p3x, &why_p8)), &fix_p4)),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(st_p1x.clone()),
                })
            },
            ::std::option::Option::None => {
                let g_p0x = g_p0.clone();
                let shown_p3x = shown_p3.clone();
                let st_p1x = st_p1.clone();
                let w_p2x = w_p2.clone();
                crate::prelude::call_then(start_trait_refusal_o(g_p0x.clone(), st_p1x.clone(), w_p2x.cls_p.clone()), move |trait_refusal_o_31380: ::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>| match trait_refusal_o_31380 {
                    ::std::option::Option::Some((method_p9, why_pa)) => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("existential-method"), &w_p2x.span_p, &crate::prelude::Text::from(format!("`^{}` is asked of the value packed in `{}` here, and its method `{}` cannot be asked of one: {}", &crate::check::types::bare_name_f(&w_p2x.cls_p), &shown_p3x, &crate::check::types::bare_name_f(&method_p9), &why_pa)), &fix_p4)),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(st_p1x.clone()),
                })
            },
        }
    }
}

/// `Start AskOfPacked, x`: what the function value is when passed to `@Run`.
pub fn start_ask_of_packed_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, w_p2: crate::check::types::Want, shown_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(AskOfPacked { g_p0, st_p1, w_p2, shown_p3 })
}

/// ```prism
/// MethodTrait: fn G, Text -> Text
/// ```
pub fn method_trait_f(g_p0: &crate::check::env::G, method_p1: &crate::prelude::Text) -> crate::prelude::Text {
    match crate::prelude::get(&g_p0.vals_p, method_p1) {
        ::std::option::Option::Some(v_p2) => {
            let (_, cls_p3) = crate::prelude::or(&crate::prelude::index(&v_p2.scheme_p.bounds_p, &crate::prelude::Nat::from(0u32)), &(crate::prelude::Text::lit(""), crate::prelude::Text::lit("")));
            if &v_p2.sort_p == &crate::prelude::Text::lit("method") {
                cls_p3.clone()
            } else {
                crate::prelude::Text::lit("")
            }
        },
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// ?TraitRefusal: unbounded fn G, St, Text -> ?((Text, Text))
/// ```
pub fn trait_refusal_o(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, cls_p2: &crate::prelude::Text) -> ::std::option::Option<(crate::prelude::Text, crate::prelude::Text)> {
    crate::prelude::run_to_end(crate::prelude::fold_job(super_closure_f(g_p0, cls_p2), ::std::option::Option::None, {
        let g_p0x = g_p0.clone();
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Text)| {
            let g_p0xy = g_p0x.clone();
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let found_o3 = p0;
                let tr_p4 = p1;
                match &found_o3 {
                    ::std::option::Option::Some(f_p5) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(f_p5.clone())),
                    ::std::option::Option::None => match crate::prelude::get(&g_p0xy.traits_p, &tr_p4) {
                        ::std::option::Option::Some(ti_p6) => crate::prelude::fold_job(ti_p6.methods_p.clone(), ::std::option::Option::None, {
                            let g_p0xyx = g_p0xy.clone();
                            let st_p1xyx = st_p1xy.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Text)| {
                                let g_p0xyxy = g_p0xyx.clone();
                                let st_p1xyxy = st_p1xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let first_o7 = p0;
                                    let method_p8 = p1;
                                    match &first_o7 {
                                        ::std::option::Option::Some(f_p9) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(f_p9.clone())),
                                        ::std::option::Option::None => crate::prelude::call_then(start_packed_refusal_o(g_p0xyxy.clone(), st_p1xyxy.clone(), method_p8.clone()), move |packed_refusal_o_32305: ::std::option::Option<crate::prelude::Text>| match packed_refusal_o_32305 {
                                            ::std::option::Option::Some(why_pa) => ::prism_rtl::Turn::Finished(::std::option::Option::Some((method_p8.clone(), why_pa.clone()))),
                                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                                        }),
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>>>>
                        }).cycle(),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                    },
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>>>>
    }))
}

/// The step machine of `TraitRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?TraitRefusal: unbounded fn G, St, Text -> ?((Text, Text))
/// ```
pub struct TraitRefusal {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub cls_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>> for TraitRefusal {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let cls_p2 = &self.cls_p2;
        let cls_p2x = cls_p2.clone();
        let g_p0x = g_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_super_closure_f(g_p0x.clone(), cls_p2x.clone()), move |super_closure_f_32096: crate::prelude::Array<crate::prelude::Text>| crate::prelude::fold_job(super_closure_f_32096, ::std::option::Option::None, {
            let g_p0xx = g_p0x.clone();
            let st_p1xx = st_p1x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Text)| {
                let g_p0xxy = g_p0xx.clone();
                let st_p1xxy = st_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_o3 = p0;
                    let tr_p4 = p1;
                    match &found_o3 {
                        ::std::option::Option::Some(f_p5) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(f_p5.clone())),
                        ::std::option::Option::None => match crate::prelude::get(&g_p0xxy.traits_p, &tr_p4) {
                            ::std::option::Option::Some(ti_p6) => crate::prelude::fold_job(ti_p6.methods_p.clone(), ::std::option::Option::None, {
                                let g_p0xxyx = g_p0xxy.clone();
                                let st_p1xxyx = st_p1xxy.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Text)| {
                                    let g_p0xxyxy = g_p0xxyx.clone();
                                    let st_p1xxyxy = st_p1xxyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let first_o7 = p0;
                                        let method_p8 = p1;
                                        match &first_o7 {
                                            ::std::option::Option::Some(f_p9) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(f_p9.clone())),
                                            ::std::option::Option::None => crate::prelude::call_then(start_packed_refusal_o(g_p0xxyxy.clone(), st_p1xxyxy.clone(), method_p8.clone()), move |packed_refusal_o_32305: ::std::option::Option<crate::prelude::Text>| match packed_refusal_o_32305 {
                                                ::std::option::Option::Some(why_pa) => ::prism_rtl::Turn::Finished(::std::option::Option::Some((method_p8.clone(), why_pa.clone()))),
                                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                                            }),
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>>>>
                            }).cycle(),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                        },
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>>>>
        }).cycle())
    }
}

/// `Start TraitRefusal, x`: what the function value is when passed to `@Run`.
pub fn start_trait_refusal_o(g_p0: crate::check::env::G, st_p1: crate::check::types::St, cls_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>>> {
    ::std::rc::Rc::new(TraitRefusal { g_p0, st_p1, cls_p2 })
}

/// ```prism
/// ?PackedRefusal: unbounded fn G, St, Text -> ?Text
/// ```
pub fn packed_refusal_o(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, method_p2: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Text> {
    match crate::prelude::get(&g_p0.vals_p, method_p2) {
        ::std::option::Option::None => ::std::option::Option::None,
        ::std::option::Option::Some(v_p3) => {
            let (param_p7, _) = crate::prelude::or(&crate::prelude::index(&v_p3.scheme_p.bounds_p, &crate::prelude::Nat::from(0u32)), &(crate::prelude::Text::lit(""), crate::prelude::Text::lit("")));
            let own_p4 = crate::prelude::filter(&v_p3.scheme_p.qs_p, &(|q_p8: &crate::prelude::Text| q_p8 != &param_p7));
            let erased_p5 = crate::check::types::schemes::Inst { tys_p: crate::prelude::insert(&crate::prelude::Map::new(), &param_p7, &crate::check::types::Ty::TyErr), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() };
            let no_value_p6 = crate::prelude::Text::from(format!("it has no parameter of the trait\'s type `{}`, so there is no packed value to read a dictionary from", &param_p7));
            match &v_p3.scheme_p.ty_p {
                crate::check::types::Ty::TyFn(_, params_p9, _) => {
                    let inside_oa = crate::prelude::run_to_end(crate::prelude::fold_job(params_p9.clone(), ::std::option::Option::None, {
                        let param_p7x = param_p7.clone();
                        let erased_p5x = erased_p5.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::check::types::Ty>, crate::check::types::Ty)| {
                            let param_p7xy = param_p7x.clone();
                            let erased_p5xy = erased_p5x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let found_ob = p0;
                                let p_pc = p1;
                                match &found_ob {
                                    ::std::option::Option::Some(f_pd) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(f_pd.clone())),
                                    ::std::option::Option::None => if (&p_pc != &crate::check::types::Ty::TyQ(param_p7xy.clone())) && (&crate::check::types::schemes::subst_q_f(&erased_p5xy, &p_pc) != &p_pc) {
                                        ::prism_rtl::Turn::Finished(::std::option::Option::Some(p_pc.clone()))
                                    } else {
                                        ::prism_rtl::Turn::Finished(::std::option::Option::None)
                                    },
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::check::types::Ty>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::check::types::Ty>>>>
                    }));
                    match &inside_oa {
                        ::std::option::Option::Some(p_pe) => ::std::option::Option::Some(crate::prelude::Text::from(format!("it takes the trait\'s type inside `{}`, and a collection of packed values has no one dictionary", &crate::check::types::show_ty_f(st_p1, p_pe)))),
                        ::std::option::Option::None => match crate::prelude::index(&own_p4, &crate::prelude::Nat::from(0u32)) {
                            ::std::option::Option::Some(q_pf) => ::std::option::Option::Some(crate::prelude::Text::from(format!("it has a type parameter of its own, `{}`, and a packed value\'s dictionary holds one function for a method", &q_pf))),
                            ::std::option::Option::None => if crate::prelude::fold(params_p9, &false, &(|seen_pg: &bool, p_ph: &crate::check::types::Ty| *seen_pg || (p_ph == &crate::check::types::Ty::TyQ(param_p7.clone())))) {
                                ::std::option::Option::None
                            } else {
                                ::std::option::Option::Some(no_value_p6.clone())
                            },
                        },
                    }
                },
                _ => ::std::option::Option::Some(no_value_p6.clone()),
            }
        },
    }
}

/// The step machine of `PackedRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?PackedRefusal: unbounded fn G, St, Text -> ?Text
/// ```
pub struct PackedRefusal {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub method_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>> for PackedRefusal {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Text>> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let method_p2 = &self.method_p2;
        match crate::prelude::get(&g_p0.vals_p, method_p2) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
            ::std::option::Option::Some(v_p3) => {
                let (param_p7, _) = crate::prelude::or(&crate::prelude::index(&v_p3.scheme_p.bounds_p, &crate::prelude::Nat::from(0u32)), &(crate::prelude::Text::lit(""), crate::prelude::Text::lit("")));
                let own_p4 = crate::prelude::filter(&v_p3.scheme_p.qs_p, &(|q_p8: &crate::prelude::Text| q_p8 != &param_p7));
                let erased_p5 = crate::check::types::schemes::Inst { tys_p: crate::prelude::insert(&crate::prelude::Map::new(), &param_p7, &crate::check::types::Ty::TyErr), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() };
                let no_value_p6 = crate::prelude::Text::from(format!("it has no parameter of the trait\'s type `{}`, so there is no packed value to read a dictionary from", &param_p7));
                match &v_p3.scheme_p.ty_p {
                    crate::check::types::Ty::TyFn(_, params_p9, _) => {
                        let params_p9x = params_p9.clone();
                        let st_p1x = st_p1.clone();
                        crate::prelude::call_value(crate::prelude::fold_job(params_p9x.clone(), ::std::option::Option::None, {
                            let param_p7x = param_p7.clone();
                            let erased_p5x = erased_p5.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::check::types::Ty>, crate::check::types::Ty)| {
                                let param_p7xy = param_p7x.clone();
                                let erased_p5xy = erased_p5x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let found_ob = p0;
                                    let p_pc = p1;
                                    match &found_ob {
                                        ::std::option::Option::Some(f_pd) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(f_pd.clone())),
                                        ::std::option::Option::None => if (&p_pc != &crate::check::types::Ty::TyQ(param_p7xy.clone())) && (&crate::check::types::schemes::subst_q_f(&erased_p5xy, &p_pc) != &p_pc) {
                                            ::prism_rtl::Turn::Finished(::std::option::Option::Some(p_pc.clone()))
                                        } else {
                                            ::prism_rtl::Turn::Finished(::std::option::Option::None)
                                        },
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::check::types::Ty>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::check::types::Ty>>>>
                        }), move |fold_33168: ::std::option::Option<crate::check::types::Ty>| {
                            let inside_oa = fold_33168;
                            match &inside_oa {
                                ::std::option::Option::Some(p_pe) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::Text::from(format!("it takes the trait\'s type inside `{}`, and a collection of packed values has no one dictionary", &crate::check::types::show_ty_f(&st_p1x, p_pe))))),
                                ::std::option::Option::None => match crate::prelude::index(&own_p4, &crate::prelude::Nat::from(0u32)) {
                                    ::std::option::Option::Some(q_pf) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::Text::from(format!("it has a type parameter of its own, `{}`, and a packed value\'s dictionary holds one function for a method", &q_pf)))),
                                    ::std::option::Option::None => if crate::prelude::fold(&params_p9x, &false, &(|seen_pg: &bool, p_ph: &crate::check::types::Ty| *seen_pg || (p_ph == &crate::check::types::Ty::TyQ(param_p7.clone())))) {
                                        ::prism_rtl::Turn::Finished(::std::option::Option::None)
                                    } else {
                                        ::prism_rtl::Turn::Finished(::std::option::Option::Some(no_value_p6.clone()))
                                    },
                                },
                            }
                        })
                    },
                    _ => ::prism_rtl::Turn::Finished(::std::option::Option::Some(no_value_p6.clone())),
                }
            },
        }
    }
}

/// `Start PackedRefusal, x`: what the function value is when passed to `@Run`.
pub fn start_packed_refusal_o(g_p0: crate::check::env::G, st_p1: crate::check::types::St, method_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>>> {
    ::std::rc::Rc::new(PackedRefusal { g_p0, st_p1, method_p2 })
}

/// ```prism
/// ElemTrait: unbounded fn G, St, St, (fn St -> St), Want, Ty, Text, Rw -> (([Want], St))
/// ```
pub fn elem_trait_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, s0_p2: &crate::check::types::St, restore_f3: &::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>, w_p4: &crate::check::types::Want, t_p5: &crate::check::types::Ty, bare_p6: &crate::prelude::Text, rw_p7: &crate::check::types::Rw) -> (crate::prelude::Array<crate::check::types::Want>, crate::check::types::St) {
    if !((bare_p6 == &crate::prelude::Text::lit("Eq")) || (bare_p6 == &crate::prelude::Text::lit("Show"))) {
        (crate::prelude::Array::new(), crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_f(s0_p2, &crate::prelude::Text::lit("no-impl"), &w_p4.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`", bare_p6, &crate::check::types::show_ty_f(st_p1, t_p5)))))))
    } else {
        if row_holds_dynamics_f(g_p0, &crate::check::types::recording::walk_row_f(st_p1, rw_p7)) {
            (crate::prelude::Array::new(), crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_fix_f(s0_p2, &crate::prelude::Text::lit("no-impl"), &w_p4.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`: a tag of its row holds dynamics (a container\'s children, `$(Path ==> $Elem)`), which do not compare or print", bare_p6, &crate::check::types::show_ty_f(st_p1, t_p5))), &crate::prelude::Text::lit("compare or show what the element holds, a field at a time")))))
        } else {
            (crate::prelude::Array::new(), solved_f(st_p1, w_p4, t_p5, &crate::prelude::Text::lit("builtin")))
        }
    }
}

/// The step machine of `ElemTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElemTrait: unbounded fn G, St, St, (fn St -> St), Want, Ty, Text, Rw -> (([Want], St))
/// ```
pub struct ElemTrait {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub s0_p2: crate::check::types::St,
    pub restore_f3: ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>,
    pub w_p4: crate::check::types::Want,
    pub t_p5: crate::check::types::Ty,
    pub bare_p6: crate::prelude::Text,
    pub rw_p7: crate::check::types::Rw,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)> for ElemTrait {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let s0_p2 = &self.s0_p2;
        let restore_f3 = &self.restore_f3;
        let w_p4 = &self.w_p4;
        let t_p5 = &self.t_p5;
        let bare_p6 = &self.bare_p6;
        let rw_p7 = &self.rw_p7;
        if !((bare_p6 == &crate::prelude::Text::lit("Eq")) || (bare_p6 == &crate::prelude::Text::lit("Show"))) {
            {
                let restore_f3x = restore_f3.clone();
                let bare_p6x = bare_p6.clone();
                let s0_p2x = s0_p2.clone();
                let st_p1x = st_p1.clone();
                let t_p5x = t_p5.clone();
                let w_p4x = w_p4.clone();
                crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p5x.clone()), move |show_ty_f_34167: crate::prelude::Text| crate::prelude::call_value((&restore_f3x)(crate::check::types::recording::err_f(&s0_p2x, &crate::prelude::Text::lit("no-impl"), &w_p4x.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`", &bare_p6x, &show_ty_f_34167)))), move |restore_34103: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), restore_34103))))
            }
        } else {
            {
                let restore_f3x = restore_f3.clone();
                let bare_p6x = bare_p6.clone();
                let g_p0x = g_p0.clone();
                let rw_p7x = rw_p7.clone();
                let s0_p2x = s0_p2.clone();
                let st_p1x = st_p1.clone();
                let t_p5x = t_p5.clone();
                let w_p4x = w_p4.clone();
                crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_p7x.clone()), move |walk_row_f_34220: crate::check::types::Rw| if row_holds_dynamics_f(&g_p0x, &walk_row_f_34220) {
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p5x.clone()), move |show_ty_f_34312: crate::prelude::Text| crate::prelude::call_value((&restore_f3x)(crate::check::types::recording::err_fix_f(&s0_p2x, &crate::prelude::Text::lit("no-impl"), &w_p4x.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`: a tag of its row holds dynamics (a container\'s children, `$(Path ==> $Elem)`), which do not compare or print", &bare_p6x, &show_ty_f_34312)), &crate::prelude::Text::lit("compare or show what the element holds, a field at a time"))), move |restore_34245: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), restore_34245))))
                } else {
                    ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), solved_f(&st_p1x, &w_p4x, &t_p5x, &crate::prelude::Text::lit("builtin"))))
                })
            }
        }
    }
}

/// `Start ElemTrait, x`: what the function value is when passed to `@Run`.
pub fn start_elem_trait_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, s0_p2: crate::check::types::St, restore_f3: ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>, w_p4: crate::check::types::Want, t_p5: crate::check::types::Ty, bare_p6: crate::prelude::Text, rw_p7: crate::check::types::Rw) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Want>, crate::check::types::St)>> {
    ::std::rc::Rc::new(ElemTrait { g_p0, st_p1, s0_p2, restore_f3, w_p4, t_p5, bare_p6, rw_p7 })
}

/// ```prism
/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
/// ```
pub fn find_impl_o(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, cls_p2: &crate::prelude::Text, t_p3: &crate::check::types::Ty) -> ::std::option::Option<(crate::prelude::Array<(crate::check::types::Ty, crate::prelude::Text)>, crate::check::types::St, crate::prelude::Text, crate::prelude::Text)> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&g_p0.impls_p, cls_p2), &crate::prelude::Array::new()), ::std::option::Option::None, {
        let st_p1x = st_p1.clone();
        let t_p3x = t_p3.clone();
        let g_p0x = g_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<(crate::prelude::Array<(crate::check::types::Ty, crate::prelude::Text)>, crate::check::types::St, crate::prelude::Text, crate::prelude::Text)>, crate::check::env::ImplInfo)| {
            let st_p1xy = st_p1x.clone();
            let t_p3xy = t_p3x.clone();
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let found_o4 = p0;
                let im_p5 = p1;
                match &found_o4 {
                    ::std::option::Option::Some(f_p6) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(f_p6.clone())),
                    ::std::option::Option::None => crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p1xy.clone(), t_p3xy.clone()), move |zonk_f_34956: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::unify::start_match_head_o(im_p5.head_p.clone(), zonk_f_34956, crate::prelude::Map::new()), move |match_head_o_34935: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| match match_head_o_34935 {
                        ::std::option::Option::Some(m_p7) => ::prism_rtl::Turn::Finished(::std::option::Option::Some((crate::prelude::each(&im_p5.bounds_p, &(|(v_p8, c_p9): &(crate::prelude::Text, crate::prelude::Text)| (crate::prelude::or(&crate::prelude::get(&m_p7, v_p8), &crate::check::types::Ty::TyErr), c_p9.clone()))), st_p1xy.clone(), impl_how_f(&g_p0xy, &im_p5), impl_choice_f(&im_p5)))),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                    })),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<(crate::prelude::Array<(crate::check::types::Ty, crate::prelude::Text)>, crate::check::types::St, crate::prelude::Text, crate::prelude::Text)>, crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Array<(crate::check::types::Ty, crate::prelude::Text)>, crate::check::types::St, crate::prelude::Text, crate::prelude::Text)>>>>
    }))
}

/// The step machine of `FindImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
/// ```
pub struct FindImpl {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub cls_p2: crate::prelude::Text,
    pub t_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<::std::option::Option<(crate::prelude::Array<(crate::check::types::Ty, crate::prelude::Text)>, crate::check::types::St, crate::prelude::Text, crate::prelude::Text)>> for FindImpl {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<(crate::prelude::Array<(crate::check::types::Ty, crate::prelude::Text)>, crate::check::types::St, crate::prelude::Text, crate::prelude::Text)>> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let cls_p2 = &self.cls_p2;
        let t_p3 = &self.t_p3;
        crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&g_p0.impls_p, cls_p2), &crate::prelude::Array::new()), ::std::option::Option::None, {
            let st_p1x = st_p1.clone();
            let t_p3x = t_p3.clone();
            let g_p0x = g_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<(crate::prelude::Array<(crate::check::types::Ty, crate::prelude::Text)>, crate::check::types::St, crate::prelude::Text, crate::prelude::Text)>, crate::check::env::ImplInfo)| {
                let st_p1xy = st_p1x.clone();
                let t_p3xy = t_p3x.clone();
                let g_p0xy = g_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_o4 = p0;
                    let im_p5 = p1;
                    match &found_o4 {
                        ::std::option::Option::Some(f_p6) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(f_p6.clone())),
                        ::std::option::Option::None => crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p1xy.clone(), t_p3xy.clone()), move |zonk_f_34956: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::unify::start_match_head_o(im_p5.head_p.clone(), zonk_f_34956, crate::prelude::Map::new()), move |match_head_o_34935: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| match match_head_o_34935 {
                            ::std::option::Option::Some(m_p7) => ::prism_rtl::Turn::Finished(::std::option::Option::Some((crate::prelude::each(&im_p5.bounds_p, &(|(v_p8, c_p9): &(crate::prelude::Text, crate::prelude::Text)| (crate::prelude::or(&crate::prelude::get(&m_p7, v_p8), &crate::check::types::Ty::TyErr), c_p9.clone()))), st_p1xy.clone(), impl_how_f(&g_p0xy, &im_p5), impl_choice_f(&im_p5)))),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                        })),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<(crate::prelude::Array<(crate::check::types::Ty, crate::prelude::Text)>, crate::check::types::St, crate::prelude::Text, crate::prelude::Text)>, crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Array<(crate::check::types::Ty, crate::prelude::Text)>, crate::check::types::St, crate::prelude::Text, crate::prelude::Text)>>>>
        }).cycle()
    }
}

/// `Start FindImpl, x`: what the function value is when passed to `@Run`.
pub fn start_find_impl_o(g_p0: crate::check::env::G, st_p1: crate::check::types::St, cls_p2: crate::prelude::Text, t_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Array<(crate::check::types::Ty, crate::prelude::Text)>, crate::check::types::St, crate::prelude::Text, crate::prelude::Text)>>> {
    ::std::rc::Rc::new(FindImpl { g_p0, st_p1, cls_p2, t_p3 })
}

/// ```prism
/// NoteImplUse: unbounded fn G, St, Want, Ty -> St
/// ```
pub fn note_impl_use_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, w_p2: &crate::check::types::Want, t_p3: &crate::check::types::Ty) -> crate::check::types::St {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&g_p0.impls_p, &w_p2.cls_p), &crate::prelude::Array::new()), st_p1.clone(), {
        let st_p1x = st_p1.clone();
        let t_p3x = t_p3.clone();
        let w_p2x = w_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::ImplInfo)| {
            let st_p1xy = st_p1x.clone();
            let t_p3xy = t_p3x.clone();
            let w_p2xy = w_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p4 = p0;
                let im_p5 = p1;
                if im_p5.derived_p || (&crate::prelude::len(&im_p5.qs_p) == &crate::prelude::Nat::from(0u32)) {
                    ::prism_rtl::Turn::Finished(s_p4.clone())
                } else {
                    crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p1xy.clone(), t_p3xy.clone()), move |zonk_f_35686: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::unify::start_match_head_o(im_p5.head_p.clone(), zonk_f_35686, crate::prelude::Map::new()), move |match_head_o_35665: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| match match_head_o_35665 {
                        ::std::option::Option::Some(m_p6) => ::prism_rtl::Turn::Finished({
                            let mut this: crate::check::types::St = s_p4.clone();
                            this.generic_uses_p = crate::prelude::push(&this.generic_uses_p, &crate::check::types::GenericUse { user_p: st_p1xy.definition_p.clone(), target_p: impl_choice_f(&im_p5), file_p: w_p2xy.file_p.clone(), span_p: w_p2xy.span_p.clone(), types_p: crate::prelude::each(&im_p5.qs_p, &(|q_p7: &crate::prelude::Text| (q_p7.clone(), crate::prelude::or(&crate::prelude::get(&m_p6, q_p7), &crate::check::types::Ty::TyErr)))) });
                            this
                        }),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p4.clone()),
                    }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `NoteImplUse`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NoteImplUse: unbounded fn G, St, Want, Ty -> St
/// ```
pub struct NoteImplUse {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub w_p2: crate::check::types::Want,
    pub t_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::St> for NoteImplUse {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let w_p2 = &self.w_p2;
        let t_p3 = &self.t_p3;
        crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&g_p0.impls_p, &w_p2.cls_p), &crate::prelude::Array::new()), st_p1.clone(), {
            let st_p1x = st_p1.clone();
            let t_p3x = t_p3.clone();
            let w_p2x = w_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::ImplInfo)| {
                let st_p1xy = st_p1x.clone();
                let t_p3xy = t_p3x.clone();
                let w_p2xy = w_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p4 = p0;
                    let im_p5 = p1;
                    if im_p5.derived_p || (&crate::prelude::len(&im_p5.qs_p) == &crate::prelude::Nat::from(0u32)) {
                        ::prism_rtl::Turn::Finished(s_p4.clone())
                    } else {
                        crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p1xy.clone(), t_p3xy.clone()), move |zonk_f_35686: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::unify::start_match_head_o(im_p5.head_p.clone(), zonk_f_35686, crate::prelude::Map::new()), move |match_head_o_35665: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| match match_head_o_35665 {
                            ::std::option::Option::Some(m_p6) => ::prism_rtl::Turn::Finished({
                                let mut this: crate::check::types::St = s_p4.clone();
                                this.generic_uses_p = crate::prelude::push(&this.generic_uses_p, &crate::check::types::GenericUse { user_p: st_p1xy.definition_p.clone(), target_p: impl_choice_f(&im_p5), file_p: w_p2xy.file_p.clone(), span_p: w_p2xy.span_p.clone(), types_p: crate::prelude::each(&im_p5.qs_p, &(|q_p7: &crate::prelude::Text| (q_p7.clone(), crate::prelude::or(&crate::prelude::get(&m_p6, q_p7), &crate::check::types::Ty::TyErr)))) });
                                this
                            }),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p4.clone()),
                        }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start NoteImplUse, x`: what the function value is when passed to `@Run`.
pub fn start_note_impl_use_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, w_p2: crate::check::types::Want, t_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(NoteImplUse { g_p0, st_p1, w_p2, t_p3 })
}

/// ```prism
/// ImplChoice: fn ImplInfo -> Text
/// ```
pub fn impl_choice_f(im_p0: &crate::check::env::ImplInfo) -> crate::prelude::Text {
    match &im_p0.head_p {
        crate::check::types::Ty::TyCon(n_p1, _) => if im_p0.derived_p {
            crate::prelude::Text::from(format!("derived:{}", n_p1))
        } else {
            crate::prelude::Text::from(format!("impl:{}.{}", &im_p0.file_p, &im_p0.span_p.start_p))
        },
        _ => if im_p0.derived_p {
            crate::prelude::Text::lit("any")
        } else {
            crate::prelude::Text::from(format!("impl:{}.{}", &im_p0.file_p, &im_p0.span_p.start_p))
        },
    }
}

/// ```prism
/// ImplHow: fn G, ImplInfo -> Text
/// ```
pub fn impl_how_f(g_p0: &crate::check::env::G, im_p1: &crate::check::env::ImplInfo) -> crate::prelude::Text {
    let src_p2 = crate::prelude::or(&crate::prelude::index(&g_p0.srcs_p, &im_p1.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit("?"), &crate::prelude::Text::lit("")));
    crate::prelude::Text::from(format!("{} {}:{}", &(if im_p1.derived_p {
        crate::prelude::Text::lit("derived")
    } else {
        crate::prelude::Text::lit("impl")
    }), &src_p2.path_p, &(&crate::check::errors::cline_of_f(&src_p2.starts_p, &im_p1.span_p.start_p) + &crate::prelude::Nat::from(1u32))))
}

/// ```prism
/// Solved: fn St, Want, Ty, Text -> St
/// ```
pub fn solved_f(st_p0: &crate::check::types::St, w_p1: &crate::check::types::Want, t_p2: &crate::check::types::Ty, how_p3: &crate::prelude::Text) -> crate::check::types::St {
    let s2_p4 = crate::check::types::recording::note_impl_f(st_p0, &w_p1.file_p, &w_p1.span_p, &w_p1.cls_p, t_p2, how_p3);
    if how_p3 == &crate::prelude::Text::lit("given") {
        crate::check::types::recording::note_choice_f(&s2_p4, &w_p1.file_p, &w_p1.span_p, &w_p1.cls_p, &given_choice_f(t_p2))
    } else {
        if (how_p3 == &crate::prelude::Text::lit("packed")) || (how_p3 == &crate::prelude::Text::lit("quantified")) {
            crate::check::types::recording::note_choice_f(&s2_p4, &w_p1.file_p, &w_p1.span_p, &w_p1.cls_p, &crate::prelude::Text::lit("any"))
        } else {
            if (how_p3 == &crate::prelude::Text::lit("builtin")) || (how_p3 == &crate::prelude::Text::lit("parts")) {
                crate::check::types::recording::note_choice_f(&s2_p4, &w_p1.file_p, &w_p1.span_p, &w_p1.cls_p, &crate::prelude::Text::lit("none"))
            } else {
                s2_p4.clone()
            }
        }
    }
}

/// ```prism
/// GivenChoice: fn Ty -> Text
/// ```
pub fn given_choice_f(ty0: &crate::check::types::Ty) -> crate::prelude::Text {
    match ty0 {
        crate::check::types::Ty::TyRigid(v_p0) => crate::prelude::Text::from(format!("given:{}", v_p0)),
        _ => crate::prelude::Text::lit("any"),
    }
}

/// ```prism
/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
/// ```
pub fn default_wants_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, givens_p2: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>) -> crate::check::types::St {
    let flex_vars_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(st_p1.wants_p.clone(), crate::prelude::Array::new(), {
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Want)| {
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p8 = p0;
                let w_p9 = p1;
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xy.clone(), w_p9.ty_p.clone()), move |walk_f_37807: crate::check::types::Ty| match walk_f_37807 {
                    crate::check::types::Ty::TyFlex(n_pa) => ::prism_rtl::Turn::Finished(crate::check::types::add_nat_f(&acc_p8, &n_pa)),
                    _ => ::prism_rtl::Turn::Finished(acc_p8.clone()),
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Want)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    let s2_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(flex_vars_p3.clone(), st_p1.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Nat)| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_pb = p0;
        let v_pc = p1;
        crate::prelude::call_value(crate::prelude::filter_job(s_pb.wants_p.clone(), {
            let s_pbx = s_pb.clone();
            let v_pcx = v_pc.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Want| {
                let s_pbxy = s_pbx.clone();
                let v_pcxy = v_pcx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let w_pf = p0;
                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_pbxy.clone(), w_pf.ty_p.clone()), move |walk_f_37967: crate::check::types::Ty| ::prism_rtl::Turn::Finished(&walk_f_37967 == &crate::check::types::Ty::TyFlex(v_pcxy.clone())))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Want) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }), move |filter_37945: crate::prelude::Array<crate::check::types::Want>| {
            let classes_pd = crate::prelude::each(&filter_37945, &(|w_pg: &crate::check::types::Want| crate::check::types::bare_name_f(&w_pg.cls_p)));
            let defaultable_pe = crate::check::types::has_text_f(&classes_pd, &crate::prelude::Text::lit("Num")) && crate::prelude::fold(&classes_pd, &true, &(|ok_ph: &bool, c_pi: &crate::prelude::Text| *ok_ph && (crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("Num"), crate::prelude::Text::lit("Eq"), crate::prelude::Text::lit("Ord"), crate::prelude::Text::lit("Show"), crate::prelude::Text::lit("Sub"), crate::prelude::Text::lit("Signed")]), c_pi) || crate::syntax::lexer::chars::has_prefix_f(c_pi, &crate::prelude::Text::lit("Range ")))));
            if defaultable_pe {
                ::prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = s_pb.clone();
                    this.tys_p = crate::prelude::insert(&this.tys_p, &v_pc, &crate::check::types::t_int_p());
                    this
                })
            } else {
                ::prism_rtl::Turn::Finished(s_pb.clone())
            }
        })
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>));
    let s3_p5 = solve_wants_f(g_p0, &s2_p4, givens_p2, &false);
    let leftover_p6 = crate::prelude::run_to_end(crate::prelude::filter_job(s3_p5.wants_p.clone(), {
        let s3_p5x = s3_p5.clone();
        ::std::rc::Rc::new(move |p0: crate::check::types::Want| {
            let s3_p5xy = s3_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_pj = p0;
                crate::prelude::call_then(crate::check::types::start_is_flex_var_f(s3_p5xy.clone(), w_pj.ty_p.clone()), move |is_flex_var_f_38380: bool| ::prism_rtl::Turn::Finished(((is_flex_var_f_38380 && !crate::syntax::lexer::chars::has_prefix_f(&w_pj.cls_p, &crate::prelude::Text::lit("Range "))) && (&w_pj.cls_p != &crate::prelude::Text::lit("Prelude.Sub"))) && (&w_pj.cls_p != &crate::prelude::Text::lit("Prelude.Signed"))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Want) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    let s4_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(leftover_p6.clone(), s3_p5.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Want)| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_pk = p0;
        let w_pl = p1;
        {
            let s5_pm = {
                let mut this: crate::check::types::St = s_pk.clone();
                this.file_p = w_pl.file_p.clone();
                this
            };
            crate::prelude::call_then(crate::check::types::start_show_ty_f(s_pk.clone(), w_pl.ty_p.clone()), move |show_ty_f_38651: crate::prelude::Text| crate::prelude::call_then(crate::check::types::start_show_ty_f(s_pk.clone(), w_pl.ty_p.clone()), move |show_ty_f_38691: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s5_pm, &crate::prelude::Text::lit("ambiguous"), &w_pl.span_p, &crate::prelude::Text::from(format!("nothing decides `{}` in `^{} {}`; annotate, or write a suffixed operator", &show_ty_f_38651, &crate::check::types::bare_name_f(&w_pl.cls_p), &show_ty_f_38691)), &crate::prelude::Text::lit("annotate the value\'s type")))))
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::Want)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>));
    let mut this: crate::check::types::St = s4_p7.clone();
    this.wants_p = crate::prelude::Array::new();
    this.file_p = st_p1.file_p.clone();
    this
}

/// The step machine of `DefaultWants`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
/// ```
pub struct DefaultWants {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub givens_p2: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
}

impl ::prism_rtl::Job<crate::check::types::St> for DefaultWants {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let givens_p2 = &self.givens_p2;
        let g_p0x = g_p0.clone();
        let givens_p2x = givens_p2.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(st_p1x.wants_p.clone(), crate::prelude::Array::new(), {
            let st_p1xx = st_p1x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Want)| {
                let st_p1xxy = st_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p8 = p0;
                    let w_p9 = p1;
                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xxy.clone(), w_p9.ty_p.clone()), move |walk_f_37807: crate::check::types::Ty| match walk_f_37807 {
                        crate::check::types::Ty::TyFlex(n_pa) => ::prism_rtl::Turn::Finished(crate::check::types::add_nat_f(&acc_p8, &n_pa)),
                        _ => ::prism_rtl::Turn::Finished(acc_p8.clone()),
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Want)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
        }), move |fold_37770: crate::prelude::Array<crate::prelude::Nat>| {
            let flex_vars_p3 = fold_37770;
            crate::prelude::call_value(crate::prelude::fold_job(flex_vars_p3.clone(), st_p1x.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Nat)| crate::prelude::entered(crate::prelude::once_job(move || {
                let s_pb = p0;
                let v_pc = p1;
                crate::prelude::call_value(crate::prelude::filter_job(s_pb.wants_p.clone(), {
                    let s_pbx = s_pb.clone();
                    let v_pcx = v_pc.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Want| {
                        let s_pbxy = s_pbx.clone();
                        let v_pcxy = v_pcx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let w_pf = p0;
                            crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_pbxy.clone(), w_pf.ty_p.clone()), move |walk_f_37967: crate::check::types::Ty| ::prism_rtl::Turn::Finished(&walk_f_37967 == &crate::check::types::Ty::TyFlex(v_pcxy.clone())))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Want) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }), move |filter_37945: crate::prelude::Array<crate::check::types::Want>| {
                    let classes_pd = crate::prelude::each(&filter_37945, &(|w_pg: &crate::check::types::Want| crate::check::types::bare_name_f(&w_pg.cls_p)));
                    let defaultable_pe = crate::check::types::has_text_f(&classes_pd, &crate::prelude::Text::lit("Num")) && crate::prelude::fold(&classes_pd, &true, &(|ok_ph: &bool, c_pi: &crate::prelude::Text| *ok_ph && (crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("Num"), crate::prelude::Text::lit("Eq"), crate::prelude::Text::lit("Ord"), crate::prelude::Text::lit("Show"), crate::prelude::Text::lit("Sub"), crate::prelude::Text::lit("Signed")]), c_pi) || crate::syntax::lexer::chars::has_prefix_f(c_pi, &crate::prelude::Text::lit("Range ")))));
                    if defaultable_pe {
                        ::prism_rtl::Turn::Finished({
                            let mut this: crate::check::types::St = s_pb.clone();
                            this.tys_p = crate::prelude::insert(&this.tys_p, &v_pc, &crate::check::types::t_int_p());
                            this
                        })
                    } else {
                        ::prism_rtl::Turn::Finished(s_pb.clone())
                    }
                })
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>), move |fold_37890: crate::check::types::St| {
                let s2_p4 = fold_37890;
                crate::prelude::call_then(start_solve_wants_f(g_p0x.clone(), s2_p4.clone(), givens_p2x.clone(), false), move |solve_wants_f_38306: crate::check::types::St| {
                    let s3_p5 = solve_wants_f_38306;
                    crate::prelude::call_value(crate::prelude::filter_job(s3_p5.wants_p.clone(), {
                        let s3_p5x = s3_p5.clone();
                        ::std::rc::Rc::new(move |p0: crate::check::types::Want| {
                            let s3_p5xy = s3_p5x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let w_pj = p0;
                                crate::prelude::call_then(crate::check::types::start_is_flex_var_f(s3_p5xy.clone(), w_pj.ty_p.clone()), move |is_flex_var_f_38380: bool| ::prism_rtl::Turn::Finished(((is_flex_var_f_38380 && !crate::syntax::lexer::chars::has_prefix_f(&w_pj.cls_p, &crate::prelude::Text::lit("Range "))) && (&w_pj.cls_p != &crate::prelude::Text::lit("Prelude.Sub"))) && (&w_pj.cls_p != &crate::prelude::Text::lit("Prelude.Signed"))))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Want) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    }), move |filter_38357: crate::prelude::Array<crate::check::types::Want>| {
                        let leftover_p6 = filter_38357;
                        crate::prelude::call_value(crate::prelude::fold_job(leftover_p6.clone(), s3_p5.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Want)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let s_pk = p0;
                            let w_pl = p1;
                            {
                                let s5_pm = {
                                    let mut this: crate::check::types::St = s_pk.clone();
                                    this.file_p = w_pl.file_p.clone();
                                    this
                                };
                                crate::prelude::call_then(crate::check::types::start_show_ty_f(s_pk.clone(), w_pl.ty_p.clone()), move |show_ty_f_38651: crate::prelude::Text| crate::prelude::call_then(crate::check::types::start_show_ty_f(s_pk.clone(), w_pl.ty_p.clone()), move |show_ty_f_38691: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s5_pm, &crate::prelude::Text::lit("ambiguous"), &w_pl.span_p, &crate::prelude::Text::from(format!("nothing decides `{}` in `^{} {}`; annotate, or write a suffixed operator", &show_ty_f_38651, &crate::check::types::bare_name_f(&w_pl.cls_p), &show_ty_f_38691)), &crate::prelude::Text::lit("annotate the value\'s type")))))
                            }
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::Want)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>), move |fold_38508: crate::check::types::St| {
                            let s4_p7 = fold_38508;
                            ::prism_rtl::Turn::Finished({
                                let mut this: crate::check::types::St = s4_p7.clone();
                                this.wants_p = crate::prelude::Array::new();
                                this.file_p = st_p1x.file_p.clone();
                                this
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start DefaultWants, x`: what the function value is when passed to `@Run`.
pub fn start_default_wants_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, givens_p2: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(DefaultWants { g_p0, st_p1, givens_p2 })
}
