//! The module `Check.Env.Traits`, from `target/bootstrap/src/prismc/check/env/traits.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// DerivedImpls: fn G -> G
/// ```
pub fn derived_impls(g: &crate::check::env::G) -> crate::check::env::G {
    fold(&keys(&g.types), g, &(|gg: &crate::check::env::G, k: &Text| match get(&gg.types, k) {
        Some(ti) => fold(&ti.derives, gg, &(|g2: &crate::check::env::G, tr: &Text| match crate::check::env::names::resolve_trait(g2, &ti.home, &split(tr, &Text::lit("."))) {
            Some(cls) => {
                let im = crate::check::env::ImplInfo { cls: cls.clone(), head: crate::check::types::Ty::TyCon(ti.name.clone(), each(&ti.params, &(|p_: &Text| crate::check::types::Ty::TyQ(p_.clone())))), qs: ti.params.clone(), bounds: each(&ti.params, &(|p_: &Text| (p_.clone(), cls.clone()))), home: ti.home.clone(), file: ti.file.clone(), span: ti.span.clone(), derived: true, assocs: Array::new(), methods: Array::new() };
                {
                    let mut this: crate::check::env::G = g2.clone();
                    this.impls = insert(&this.impls, &cls, &push(&or(&get(&this.impls, &cls), &Array::new()), &im));
                    this
                }
            },
            None => g2.clone(),
        })),
        None => gg.clone(),
    }))
}

/// ```prism
/// Coherence: unbounded fn G, St -> St
/// ```
pub fn coherence(g: &crate::check::env::G, st: &crate::check::types::St) -> crate::check::types::St {
    run_to_end(fold_job(keys(&g.impls), st.clone(), {
        let g = g.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
            let g = g.clone();
            entered(once_job(move || {
                let s = p0;
                let cls = p1;
                {
                    let impls = or(&get(&g.impls, &cls), &Array::new());
                    call_value(fold_job(impls.clone(), s.clone(), {
                        let g = g.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::ImplInfo)| {
                            let g = g.clone();
                            entered(once_job(move || {
                                let s1 = p0;
                                let i = p1;
                                prism_rtl::Turn::More(Rc::new(CheckOrphan { g: g.clone(), st: s1.clone(), i: i.clone() }))
                            }))
                        }) as Rc<dyn Fn((crate::check::types::St, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_1636: crate::check::types::St| {
                        let s2 = fold_1636;
                        fold_job(crate::check::errors::range0(&len(&impls)), s2.clone(), {
                            let impls = impls.clone();
                            let g = g.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                let impls = impls.clone();
                                let g = g.clone();
                                entered(once_job(move || {
                                    let s3 = p0;
                                    let a = p1;
                                    fold_job(crate::check::errors::range0(&len(&impls)), s3.clone(), {
                                        let a = a.clone();
                                        let g = g.clone();
                                        let impls = impls.clone();
                                        Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                            let a = a.clone();
                                            let g = g.clone();
                                            let impls = impls.clone();
                                            entered(once_job(move || {
                                                let s4 = p0;
                                                let b = p1;
                                                if &a < &b {
                                                    prism_rtl::Turn::More(Rc::new(CheckPair { g: g.clone(), st: s4.clone(), a: or(&index(&impls, &a), &dummy_impl()), b: or(&index(&impls, &b), &dummy_impl()) }))
                                                } else {
                                                    prism_rtl::Turn::Finished(s4.clone())
                                                }
                                            }))
                                        }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                                    }).cycle()
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle()
                    })
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `Coherence`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Coherence: unbounded fn G, St -> St
/// ```
pub struct Coherence {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for Coherence {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        fold_job(keys(&g.impls), st.clone(), {
            let g = g.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
                let g = g.clone();
                entered(once_job(move || {
                    let s = p0;
                    let cls = p1;
                    {
                        let impls = or(&get(&g.impls, &cls), &Array::new());
                        call_value(fold_job(impls.clone(), s.clone(), {
                            let g = g.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::ImplInfo)| {
                                let g = g.clone();
                                entered(once_job(move || {
                                    let s1 = p0;
                                    let i = p1;
                                    prism_rtl::Turn::More(Rc::new(CheckOrphan { g: g.clone(), st: s1.clone(), i: i.clone() }))
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }), move |fold_1636: crate::check::types::St| {
                            let s2 = fold_1636;
                            fold_job(crate::check::errors::range0(&len(&impls)), s2.clone(), {
                                let impls = impls.clone();
                                let g = g.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                    let impls = impls.clone();
                                    let g = g.clone();
                                    entered(once_job(move || {
                                        let s3 = p0;
                                        let a = p1;
                                        fold_job(crate::check::errors::range0(&len(&impls)), s3.clone(), {
                                            let a = a.clone();
                                            let g = g.clone();
                                            let impls = impls.clone();
                                            Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                                let a = a.clone();
                                                let g = g.clone();
                                                let impls = impls.clone();
                                                entered(once_job(move || {
                                                    let s4 = p0;
                                                    let b = p1;
                                                    if &a < &b {
                                                        prism_rtl::Turn::More(Rc::new(CheckPair { g: g.clone(), st: s4.clone(), a: or(&index(&impls, &a), &dummy_impl()), b: or(&index(&impls, &b), &dummy_impl()) }))
                                                    } else {
                                                        prism_rtl::Turn::Finished(s4.clone())
                                                    }
                                                }))
                                            }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                                        }).cycle()
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }).cycle()
                        })
                    }
                }))
            }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start Coherence, x`: what the function value is when passed to `@Run`.
pub fn start_coherence(g: crate::check::env::G, st: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Coherence { g, st })
}

/// ```prism
/// let dummyImpl
/// ```
pub fn dummy_impl() -> crate::check::env::ImplInfo {
    crate::check::env::ImplInfo { cls: Text::lit(""), head: crate::check::types::Ty::TyErr, qs: Array::new(), bounds: Array::new(), home: Text::lit(""), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }, derived: false, assocs: Array::new(), methods: Array::new() }
}

/// ```prism
/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub fn check_pair(g: &crate::check::env::G, st: &crate::check::types::St, a: &crate::check::env::ImplInfo, b: &crate::check::env::ImplInfo) -> crate::check::types::St {
    if !heads_may_meet(&a.head, &b.head) {
        st.clone()
    } else {
        if (&a.file < &b.file) || ((&a.file == &b.file) && (&a.span.start <= &b.span.start)) {
            check_pair_in(g, st, a, b)
        } else {
            check_pair_in(g, st, b, a)
        }
    }
}

/// The step machine of `CheckPair`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub struct CheckPair {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub a: crate::check::env::ImplInfo,
    pub b: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckPair {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let a = &self.a;
        let b = &self.b;
        if !heads_may_meet(&a.head, &b.head) {
            prism_rtl::Turn::Finished(st.clone())
        } else {
            if (&a.file < &b.file) || ((&a.file == &b.file) && (&a.span.start <= &b.span.start)) {
                prism_rtl::Turn::More(Rc::new(CheckPairIn { g: g.clone(), st: st.clone(), a: a.clone(), b: b.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(CheckPairIn { g: g.clone(), st: st.clone(), a: b.clone(), b: a.clone() }))
            }
        }
    }
}

/// `Start CheckPair, x`: what the function value is when passed to `@Run`.
pub fn start_check_pair(g: crate::check::env::G, st: crate::check::types::St, a: crate::check::env::ImplInfo, b: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckPair { g, st, a, b })
}

/// ```prism
/// HeadsMayMeet: fn Ty, Ty -> Bool
/// ```
pub fn heads_may_meet(ty0: &crate::check::types::Ty, ty1: &crate::check::types::Ty) -> bool {
    match (ty0, ty1) {
        (crate::check::types::Ty::TyCon(x, _), crate::check::types::Ty::TyCon(y, _)) => x == y,
        (_, _) => true,
    }
}

/// ```prism
/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub fn check_pair_in(g: &crate::check::env::G, st: &crate::check::types::St, a: &crate::check::env::ImplInfo, b: &crate::check::env::ImplInfo) -> crate::check::types::St {
    let s0 = {
        let mut this: crate::check::types::St = st.clone();
        this.file = b.file.clone();
        this
    };
    let (ta, s1) = crate::check::types::schemes::instantiate(&s0, &crate::check::types::Scheme { qs: a.qs.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: a.head.clone() }, &b.span);
    let (tb, s2) = crate::check::types::schemes::instantiate(&s1, &crate::check::types::Scheme { qs: b.qs.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: b.head.clone() }, &b.span);
    let (ok, s3) = crate::check::types::unify::try_unify(&s2, &ta, &tb, &b.span);
    if !ok {
        st.clone()
    } else {
        {
            let same = ((&len(&a.qs) == &Nat::from(0u32)) && (&len(&b.qs) == &Nat::from(0u32))) || (&shape_of(&a.head) == &shape_of(&b.head));
            let code = if same { Text::lit("impl-duplicate") } else { Text::lit("impl-overlap") };
            let first_at = crate::check::errors::src_place(&or(&index(&g.srcs, &a.file), &crate::check::errors::mk_src(&Text::lit("?"), &Text::lit(""))), &a.span.start);
            crate::check::types::recording::err_fix(&s0, &code, &b.span, &Text::from(format!("a second impl of `^{}` for `{}`", &crate::check::types::bare_name(&a.cls), &crate::check::types::show_ty(&s0, &b.head))), &Text::from(format!("the first is at {}; keep one", &first_at)))
        }
    }
}

/// The step machine of `CheckPairIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub struct CheckPairIn {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub a: crate::check::env::ImplInfo,
    pub b: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckPairIn {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let a = &self.a;
        let b = &self.b;
        let s0 = {
            let mut this: crate::check::types::St = st.clone();
            this.file = b.file.clone();
            this
        };
        let a = a.clone();
        let b = b.clone();
        let g = g.clone();
        let st = st.clone();
        call_then(crate::check::types::schemes::start_instantiate(s0.clone(), crate::check::types::Scheme { qs: a.qs.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: a.head.clone() }, b.span.clone()), move |instantiate_2653: (crate::check::types::Ty, crate::check::types::St)| {
            let (ta, s1) = instantiate_2653;
            call_then(crate::check::types::schemes::start_instantiate(s1.clone(), crate::check::types::Scheme { qs: b.qs.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: b.head.clone() }, b.span.clone()), move |instantiate_2787: (crate::check::types::Ty, crate::check::types::St)| {
                let (tb, s2) = instantiate_2787;
                call_then(crate::check::types::unify::start_try_unify(s2.clone(), ta.clone(), tb.clone(), b.span.clone()), move |try_unify_2921: (bool, crate::check::types::St)| {
                    let (ok, s3) = try_unify_2921;
                    if !ok {
                        prism_rtl::Turn::Finished(st.clone())
                    } else {
                        {
                            let same = ((&len(&a.qs) == &Nat::from(0u32)) && (&len(&b.qs) == &Nat::from(0u32))) || (&shape_of(&a.head) == &shape_of(&b.head));
                            let code = if same { Text::lit("impl-duplicate") } else { Text::lit("impl-overlap") };
                            let first_at = crate::check::errors::src_place(&or(&index(&g.srcs, &a.file), &crate::check::errors::mk_src(&Text::lit("?"), &Text::lit(""))), &a.span.start);
                            call_then(crate::check::types::start_show_ty(s0.clone(), b.head.clone()), move |show_ty_3297: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s0, &code, &b.span, &Text::from(format!("a second impl of `^{}` for `{}`", &crate::check::types::bare_name(&a.cls), &show_ty_3297)), &Text::from(format!("the first is at {}; keep one", &first_at)))))
                        }
                    }
                })
            })
        })
    }
}

/// `Start CheckPairIn, x`: what the function value is when passed to `@Run`.
pub fn start_check_pair_in(g: crate::check::env::G, st: crate::check::types::St, a: crate::check::env::ImplInfo, b: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckPairIn { g, st, a, b })
}

/// ```prism
/// ShapeOf: unbounded fn Ty -> Text
/// ```
pub fn shape_of(t: &crate::check::types::Ty) -> Text {
    match t {
        crate::check::types::Ty::TyQ(_) => Text::lit("_"),
        crate::check::types::Ty::TyCon(n, args) => Text::from(format!("{}({})", n, &crate::syntax::lexer::chars::join(&run_to_end(each_job(args.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_shape_of(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(",")))),
        crate::check::types::Ty::TyTuple(ts) => Text::from(format!("(({}))", &crate::syntax::lexer::chars::join(&run_to_end(each_job(ts.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_shape_of(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(",")))),
        crate::check::types::Ty::TyArray(e) => Text::from(format!("[{}]", &shape_of(&**e))),
        crate::check::types::Ty::TyMap(k, v_) => Text::from(format!("{}==>{}", &shape_of(&**k), &shape_of(&**v_))),
        crate::check::types::Ty::TySig(s, i) => Text::from(format!("{}{}", s, &shape_of(&**i))),
        _ => Text::lit("?"),
    }
}

/// The step machine of `ShapeOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShapeOf: unbounded fn Ty -> Text
/// ```
pub struct ShapeOf {
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for ShapeOf {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyQ(_) => prism_rtl::Turn::Finished(Text::lit("_")),
            crate::check::types::Ty::TyCon(n, args) => {
                let args = args.clone();
                let n = n.clone();
                call_value(each_job(args.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_shape_of(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_3539: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &n, &crate::syntax::lexer::chars::join(&each_3539, &Text::lit(","))))))
            },
            crate::check::types::Ty::TyTuple(ts) => {
                let ts = ts.clone();
                call_value(each_job(ts.clone(), Rc::new(|a0: crate::check::types::Ty| entered(start_shape_of(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_3593: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("(({}))", &crate::syntax::lexer::chars::join(&each_3593, &Text::lit(","))))))
            },
            crate::check::types::Ty::TyArray(e) => {
                let e = (**e).clone();
                call_then(start_shape_of(e.clone()), move |shape_of_3638: Text| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &shape_of_3638))))
            },
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_shape_of(k.clone()), move |shape_of_3669: Text| call_then(start_shape_of(v_.clone()), move |shape_of_3683: Text| prism_rtl::Turn::Finished(Text::from(format!("{}==>{}", &shape_of_3669, &shape_of_3683)))))
            },
            crate::check::types::Ty::TySig(s, i) => {
                let i = (**i).clone();
                let s = s.clone();
                call_then(start_shape_of(i.clone()), move |shape_of_3716: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &s, &shape_of_3716))))
            },
            _ => prism_rtl::Turn::Finished(Text::lit("?")),
        }
    }
}

/// `Start ShapeOf, x`: what the function value is when passed to `@Run`.
pub fn start_shape_of(t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShapeOf { t })
}

/// ```prism
/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
/// ```
pub fn check_orphan(g: &crate::check::env::G, st: &crate::check::types::St, i: &crate::check::env::ImplInfo) -> crate::check::types::St {
    let trait_mod = or(&get(&g.traits, &i.cls), &dummy_trait()).home.clone();
    let owners = each(&type_names_in(&i.head), &(|n: &Text| or(&get(&g.types, n), &crate::check::env::names::dummy_ty_info()).home.clone()));
    if (i.derived || (&i.home == &trait_mod)) || crate::check::types::has_text(&owners, &i.home) {
        st.clone()
    } else {
        {
            let s = {
                let mut this: crate::check::types::St = st.clone();
                this.file = i.file.clone();
                this
            };
            crate::check::types::recording::err_fix(&s, &Text::lit("orphan"), &i.span, &Text::from(format!("{} declares neither `^{}` nor `{}`", &(if &i.home == &Text::lit("") {
                Text::lit("this file")
            } else {
                Text::from(format!("`{}`", &i.home))
            }), &crate::check::types::bare_name(&i.cls), &crate::check::types::show_ty(&s, &i.head))), &Text::lit("wrap the type in a newtype of this module, or move the impl"))
        }
    }
}

/// The step machine of `CheckOrphan`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
/// ```
pub struct CheckOrphan {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub i: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckOrphan {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let i = &self.i;
        let trait_mod = or(&get(&g.traits, &i.cls), &dummy_trait()).home.clone();
        let g = g.clone();
        let i = i.clone();
        let st = st.clone();
        call_then(start_type_names_in(i.head.clone()), move |type_names_in_4029: Array<Text>| {
            let owners = each(&type_names_in_4029, &(|n: &Text| or(&get(&g.types, n), &crate::check::env::names::dummy_ty_info()).home.clone()));
            if (i.derived || (&i.home == &trait_mod)) || crate::check::types::has_text(&owners, &i.home) {
                prism_rtl::Turn::Finished(st.clone())
            } else {
                {
                    let s = {
                        let mut this: crate::check::types::St = st.clone();
                        this.file = i.file.clone();
                        this
                    };
                    call_then(crate::check::types::start_show_ty(s.clone(), i.head.clone()), move |show_ty_4355: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s, &Text::lit("orphan"), &i.span, &Text::from(format!("{} declares neither `^{}` nor `{}`", &(if &i.home == &Text::lit("") {
                        Text::lit("this file")
                    } else {
                        Text::from(format!("`{}`", &i.home))
                    }), &crate::check::types::bare_name(&i.cls), &show_ty_4355)), &Text::lit("wrap the type in a newtype of this module, or move the impl"))))
                }
            }
        })
    }
}

/// `Start CheckOrphan, x`: what the function value is when passed to `@Run`.
pub fn start_check_orphan(g: crate::check::env::G, st: crate::check::types::St, i: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckOrphan { g, st, i })
}

/// ```prism
/// let dummyTrait
/// ```
pub fn dummy_trait() -> crate::check::env::TraitInfo {
    crate::check::env::TraitInfo { name: Text::lit(""), home: Text::lit(""), param: Text::lit("a"), supers: Array::new(), methods: Array::new(), defaults: Array::new(), assocs: Array::new(), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// TypeNamesIn: unbounded fn Ty -> [Text]
/// ```
pub fn type_names_in(t: &crate::check::types::Ty) -> Array<Text> {
    match t {
        crate::check::types::Ty::TyCon(n, args) => run_to_end(fold_job(args.clone(), Array::from(vec![n.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_type_names_in(a.clone()), move |type_names_in_4718: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_names_in_4718)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_type_names_in(a.clone()), move |type_names_in_4791: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_names_in_4791)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyArray(e) => type_names_in(&**e),
        crate::check::types::Ty::TyMap(k, v_) => crate::check::types::union_texts(&type_names_in(&**k), &type_names_in(&**v_)),
        crate::check::types::Ty::TySig(_, i) => type_names_in(&**i),
        crate::check::types::Ty::TyFn(_, ps, r) => run_to_end(fold_job(ps.clone(), type_names_in(&**r), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_type_names_in(a.clone()), move |type_names_in_5007: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_names_in_5007)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        _ => Array::new(),
    }
}

/// The step machine of `TypeNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeNamesIn: unbounded fn Ty -> [Text]
/// ```
pub struct TypeNamesIn {
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Text>> for TypeNamesIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyCon(n, args) => fold_job(args.clone(), Array::from(vec![n.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_type_names_in(a.clone()), move |type_names_in_4718: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_names_in_4718)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_type_names_in(a.clone()), move |type_names_in_4791: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_names_in_4791)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(TypeNamesIn { t: (**e).clone() })),
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_type_names_in(k.clone()), move |type_names_in_4863: Array<Text>| call_then(start_type_names_in(v_.clone()), move |type_names_in_4880: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&type_names_in_4863, &type_names_in_4880))))
            },
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(TypeNamesIn { t: (**i).clone() })),
            crate::check::types::Ty::TyFn(_, ps, r) => {
                let ps = ps.clone();
                let r = (**r).clone();
                call_then(start_type_names_in(r.clone()), move |type_names_in_4964: Array<Text>| fold_job(ps.clone(), type_names_in_4964, Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_type_names_in(a.clone()), move |type_names_in_5007: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_names_in_5007)))
                }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start TypeNamesIn, x`: what the function value is when passed to `@Run`.
pub fn start_type_names_in(t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TypeNamesIn { t })
}

/// ```prism
/// SuperClosure: unbounded fn G, Text -> [Text]
/// ```
pub fn super_closure(g: &crate::check::env::G, cls: &Text) -> Array<Text> {
    run_to_end(fold_job(or(&get(&g.traits, cls), &dummy_trait()).supers.clone(), Array::from(vec![cls.clone()]), {
        let g = g.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
            let g = g.clone();
            entered(once_job(move || {
                let acc = p0;
                let s = p1;
                call_then(start_super_closure(g.clone(), s.clone()), move |super_closure_5465: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &super_closure_5465)))
            }))
        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `SuperClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SuperClosure: unbounded fn G, Text -> [Text]
/// ```
pub struct SuperClosure {
    pub g: crate::check::env::G,
    pub cls: Text,
}

impl prism_rtl::Job<Array<Text>> for SuperClosure {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let g = &self.g;
        let cls = &self.cls;
        fold_job(or(&get(&g.traits, cls), &dummy_trait()).supers.clone(), Array::from(vec![cls.clone()]), {
            let g = g.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                let g = g.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let s = p1;
                    call_then(start_super_closure(g.clone(), s.clone()), move |super_closure_5465: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &super_closure_5465)))
                }))
            }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start SuperClosure, x`: what the function value is when passed to `@Run`.
pub fn start_super_closure(g: crate::check::env::G, cls: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SuperClosure { g, cls })
}

/// ```prism
/// WithFile: fn St, Nat -> St
/// ```
pub fn with_file(s: &crate::check::types::St, f: &Nat) -> crate::check::types::St {
    let mut this: crate::check::types::St = s.clone();
    this.file = f.clone();
    this
}

/// ```prism
/// BuiltinHas: fn Text, Text -> Bool
/// ```
pub fn builtin_has(cls: &Text, con: &Text) -> bool {
    let bare = crate::check::types::bare_name(cls);
    if &bare == &Text::lit("Num") {
        (((con == &Text::lit("Nat")) || (con == &Text::lit("Int"))) || (con == &Text::lit("U8"))) || (con == &Text::lit("Float"))
    } else {
        if ((&bare == &Text::lit("Eq")) || (&bare == &Text::lit("Ord"))) || (&bare == &Text::lit("Show")) {
            (crate::check::env::is_prim_type(con) || (con == &Text::lit("Fault"))) || (con == &Text::lit("Prelude.Fault"))
        } else {
            false
        }
    }
}

/// ```prism
/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
/// ```
pub fn solve_wants(g: &crate::check::env::G, st: &crate::check::types::St, givens: &Array<(Text, Text)>, final_: &bool) -> crate::check::types::St {
    let s4 = solve_rounds(g, st, givens, &Nat::from(0u32));
    if *final_ { default_wants(g, &s4, givens) } else { s4.clone() }
}

/// The step machine of `SolveWants`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
/// ```
pub struct SolveWants {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub givens: Array<(Text, Text)>,
    pub final_: bool,
}

impl prism_rtl::Job<crate::check::types::St> for SolveWants {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let givens = &self.givens;
        let final_ = &self.final_;
        let final_ = *final_;
        let g = g.clone();
        let givens = givens.clone();
        let st = st.clone();
        call_then(start_solve_rounds(g.clone(), st.clone(), givens.clone(), Nat::from(0u32)), move |solve_rounds_6404: crate::check::types::St| {
            let s4 = solve_rounds_6404;
            if final_ {
                prism_rtl::Turn::More(Rc::new(DefaultWants { g: g.clone(), st: s4.clone(), givens: givens.clone() }))
            } else {
                prism_rtl::Turn::Finished(s4.clone())
            }
        })
    }
}

/// `Start SolveWants, x`: what the function value is when passed to `@Run`.
pub fn start_solve_wants(g: crate::check::env::G, st: crate::check::types::St, givens: Array<(Text, Text)>, final_: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SolveWants { g, st, givens, final_ })
}

/// ```prism
/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
/// ```
pub fn solve_rounds(g: &crate::check::env::G, st0: &crate::check::types::St, givens: &Array<(Text, Text)>, round: &Nat) -> crate::check::types::St {
    let st = resolve_fields(g, &crate::check::types::unify::retry_deferred(st0), &false);
    let cleared = {
        let mut this: crate::check::types::St = st.clone();
        this.wants = Array::new();
        this
    };
    let (keep, s2) = run_to_end(fold_job(st.wants.clone(), (Array::new(), cleared.clone()), {
        let g = g.clone();
        let givens = givens.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)| {
            let g = g.clone();
            let givens = givens.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let w = p1;
                call_then(start_solve_one(g.clone(), s.clone(), givens.clone(), w.clone()), move |solve_one_6921: (Array<crate::check::types::Want>, crate::check::types::St)| {
                    let (left, s3) = solve_one_6921;
                    prism_rtl::Turn::Finished((append(&acc, &left), s3.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>>>
    }));
    let s4 = {
        let mut this: crate::check::types::St = s2.clone();
        this.wants = append(&keep, &this.wants);
        this
    };
    if (&s4.wants == &st.wants) || (round > &Nat::from(6u32)) {
        s4.clone()
    } else {
        solve_rounds(g, &s4, givens, &(round + &Nat::from(1u32)))
    }
}

/// The step machine of `SolveRounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
/// ```
pub struct SolveRounds {
    pub g: crate::check::env::G,
    pub st0: crate::check::types::St,
    pub givens: Array<(Text, Text)>,
    pub round: Nat,
}

impl prism_rtl::Job<crate::check::types::St> for SolveRounds {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st0 = &self.st0;
        let givens = &self.givens;
        let round = &self.round;
        let g = g.clone();
        let givens = givens.clone();
        let round = round.clone();
        let st0 = st0.clone();
        call_then(crate::check::types::unify::start_retry_deferred(st0.clone()), move |retry_deferred_6740: crate::check::types::St| call_then(start_resolve_fields(g.clone(), retry_deferred_6740, false), move |resolve_fields_6722: crate::check::types::St| {
            let st = resolve_fields_6722;
            let cleared = {
                let mut this: crate::check::types::St = st.clone();
                this.wants = Array::new();
                this
            };
            call_value(fold_job(st.wants.clone(), (Array::new(), cleared.clone()), {
                let g = g.clone();
                let givens = givens.clone();
                Rc::new(move |(p0, p1): ((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)| {
                    let g = g.clone();
                    let givens = givens.clone();
                    entered(once_job(move || {
                        let (acc, s) = p0;
                        let w = p1;
                        call_then(start_solve_one(g.clone(), s.clone(), givens.clone(), w.clone()), move |solve_one_6921: (Array<crate::check::types::Want>, crate::check::types::St)| {
                            let (left, s3) = solve_one_6921;
                            prism_rtl::Turn::Finished((append(&acc, &left), s3.clone()))
                        })
                    }))
                }) as Rc<dyn Fn(((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>>>
            }), move |fold_6843: (Array<crate::check::types::Want>, crate::check::types::St)| {
                let (keep, s2) = fold_6843;
                let s4 = {
                    let mut this: crate::check::types::St = s2.clone();
                    this.wants = append(&keep, &this.wants);
                    this
                };
                if (&s4.wants == &st.wants) || (&round > &Nat::from(6u32)) {
                    prism_rtl::Turn::Finished(s4.clone())
                } else {
                    prism_rtl::Turn::More(Rc::new(SolveRounds { g: g.clone(), st0: s4.clone(), givens: givens.clone(), round: &round + &Nat::from(1u32) }))
                }
            })
        }))
    }
}

/// `Start SolveRounds, x`: what the function value is when passed to `@Run`.
pub fn start_solve_rounds(g: crate::check::env::G, st0: crate::check::types::St, givens: Array<(Text, Text)>, round: Nat) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SolveRounds { g, st0, givens, round })
}

/// ```prism
/// ResolveFields: unbounded fn G, St, Bool -> St
/// ```
pub fn resolve_fields(g: &crate::check::env::G, st: &crate::check::types::St, final_: &bool) -> crate::check::types::St {
    let qs = st.field_qs.clone();
    let cleared = {
        let mut this: crate::check::types::St = st.clone();
        this.field_qs = Array::new();
        this
    };
    let done = run_to_end(fold_job(qs.clone(), cleared.clone(), {
        let g = g.clone();
        let final_ = *final_;
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::unify::FieldQ)| {
            let g = g.clone();
            let final_ = final_;
            entered(once_job(move || {
                let s = p0;
                let q = p1;
                prism_rtl::Turn::More(Rc::new(ResolveField { g: g.clone(), st: s.clone(), q: q.clone(), final_ }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::unify::FieldQ)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    with_file(&done, &st.file)
}

/// The step machine of `ResolveFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveFields: unbounded fn G, St, Bool -> St
/// ```
pub struct ResolveFields {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub final_: bool,
}

impl prism_rtl::Job<crate::check::types::St> for ResolveFields {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let final_ = &self.final_;
        let qs = st.field_qs.clone();
        let cleared = {
            let mut this: crate::check::types::St = st.clone();
            this.field_qs = Array::new();
            this
        };
        let final_ = *final_;
        let g = g.clone();
        let st = st.clone();
        call_value(fold_job(qs.clone(), cleared.clone(), {
            let g = g.clone();
            let final_ = final_;
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::unify::FieldQ)| {
                let g = g.clone();
                let final_ = final_;
                entered(once_job(move || {
                    let s = p0;
                    let q = p1;
                    prism_rtl::Turn::More(Rc::new(ResolveField { g: g.clone(), st: s.clone(), q: q.clone(), final_ }))
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::unify::FieldQ)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }), move |fold_7445: crate::check::types::St| {
            let done = fold_7445;
            prism_rtl::Turn::Finished(with_file(&done, &st.file))
        })
    }
}

/// `Start ResolveFields, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_fields(g: crate::check::env::G, st: crate::check::types::St, final_: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ResolveFields { g, st, final_ })
}

/// ```prism
/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
/// ```
pub fn resolve_field(g: &crate::check::env::G, st: &crate::check::types::St, q: &crate::check::types::unify::FieldQ, final_: &bool) -> crate::check::types::St {
    let s = with_file(st, &q.file);
    match crate::check::types::recording::walk(&s, &q.recv) {
        crate::check::types::Ty::TyCon(n, args) => match get(&g.ctors, &n) {
            Some(c) => {
                let i_opt = fold(&crate::check::errors::range0(&len(&c.fields)), &None, &(|at_opt: &Option<Nat>, k: &Nat| if &index(&c.fields, k) == &Some(q.field.clone()) {
                    Some(k.clone())
                } else {
                    at_opt.clone()
                }));
                match &i_opt {
                    Some(i) => crate::check::types::unify::unify(&s, &q.result, &crate::check::types::schemes::subst_q(&crate::check::env::reading::param_inst(&c.params, &args), &or(&index(&c.args, i), &crate::check::types::Ty::TyErr)), &q.span),
                    None => crate::check::types::recording::err(&s, &Text::lit("mismatch"), &q.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&n), &q.field))),
                }
            },
            None => crate::check::types::recording::err(&s, &Text::lit("mismatch"), &q.span, &Text::from(format!("`{}` has no fields", &crate::check::types::bare_name(&n)))),
        },
        crate::check::types::Ty::TyFlex(_) => if *final_ {
            crate::check::types::recording::err_fix(&s, &Text::lit("ambiguous"), &q.span, &Text::from(format!("nothing decides which record `.{}` reads: {} have it", &q.field, &crate::syntax::lexer::chars::join(&each(&q.owners, &(|o: &Text| Text::from(format!("`{}`", o)))), &Text::lit(", ")))), &Text::lit("annotate the value\'s type, or name it from a signature"))
        } else {
            {
                let mut this: crate::check::types::St = s.clone();
                this.field_qs = push(&this.field_qs, q);
                this
            }
        },
        crate::check::types::Ty::TyErr => s.clone(),
        other => crate::check::types::recording::err(&s, &Text::lit("mismatch"), &q.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::show_ty(&s, &other), &q.field))),
    }
}

/// The step machine of `ResolveField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
/// ```
pub struct ResolveField {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub q: crate::check::types::unify::FieldQ,
    pub final_: bool,
}

impl prism_rtl::Job<crate::check::types::St> for ResolveField {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let q = &self.q;
        let final_ = &self.final_;
        let s = with_file(st, &q.file);
        let final_ = *final_;
        let g = g.clone();
        let q = q.clone();
        call_then(crate::check::types::recording::start_walk(s.clone(), q.recv.clone()), move |walk_7655: crate::check::types::Ty| match walk_7655 {
            crate::check::types::Ty::TyCon(n, args) => match get(&g.ctors, &n) {
                Some(c) => {
                    let i_opt = fold(&crate::check::errors::range0(&len(&c.fields)), &None, &(|at_opt: &Option<Nat>, k: &Nat| if &index(&c.fields, k) == &Some(q.field.clone()) {
                        Some(k.clone())
                    } else {
                        at_opt.clone()
                    }));
                    match &i_opt {
                        Some(i) => {
                            let i = i.clone();
                            call_then(crate::check::types::schemes::start_subst_q(crate::check::env::reading::param_inst(&c.params, &args), or(&index(&c.args, &i), &crate::check::types::Ty::TyErr)), move |subst_q_7913: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: s.clone(), expected: q.result.clone(), found: subst_q_7913, span: q.span.clone() })))
                        },
                        None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s, &Text::lit("mismatch"), &q.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&n), &q.field)))),
                    }
                },
                None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s, &Text::lit("mismatch"), &q.span, &Text::from(format!("`{}` has no fields", &crate::check::types::bare_name(&n))))),
            },
            crate::check::types::Ty::TyFlex(_) => if final_ {
                prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s, &Text::lit("ambiguous"), &q.span, &Text::from(format!("nothing decides which record `.{}` reads: {} have it", &q.field, &crate::syntax::lexer::chars::join(&each(&q.owners, &(|o: &Text| Text::from(format!("`{}`", o)))), &Text::lit(", ")))), &Text::lit("annotate the value\'s type, or name it from a signature")))
            } else {
                prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = s.clone();
                    this.field_qs = push(&this.field_qs, &q);
                    this
                })
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished(s.clone()),
            other => call_then(crate::check::types::start_show_ty(s.clone(), other.clone()), move |show_ty_8523: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err(&s, &Text::lit("mismatch"), &q.span, &Text::from(format!("`{}` has no field `{}`", &show_ty_8523, &q.field))))),
        })
    }
}

/// `Start ResolveField, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_field(g: crate::check::env::G, st: crate::check::types::St, q: crate::check::types::unify::FieldQ, final_: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ResolveField { g, st, q, final_ })
}

/// ```prism
/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
/// ```
pub fn solve_one(g: &crate::check::env::G, st: &crate::check::types::St, givens: &Array<(Text, Text)>, w: &crate::check::types::Want) -> (Array<crate::check::types::Want>, crate::check::types::St) {
    let t = crate::check::types::recording::walk(st, &w.ty);
    let s0 = {
        let mut this: crate::check::types::St = st.clone();
        this.file = w.file.clone();
        this
    };
    let restore_fn = {
        let st = st.clone();
        Rc::new(move |s: &crate::check::types::St| with_file(s, &st.file))
    };
    match &t {
        crate::check::types::Ty::TyFlex(_) => (Array::from(vec![w.clone()]), st.clone()),
        crate::check::types::Ty::TyErr => (Array::new(), st.clone()),
        crate::check::types::Ty::TyRigid(v_) => if (crate::syntax::lexer::chars::has_prefix(&w.cls, &Text::lit("Range ")) || (&w.cls == &Text::lit("Prelude.Sub"))) || (&w.cls == &Text::lit("Prelude.Signed")) {
            (Array::new(), st.clone())
        } else {
            if run_to_end(fold_job(givens.clone(), false, {
                let v_ = v_.clone();
                let g = g.clone();
                let w = w.clone();
                Rc::new(move |(p0, p1): (bool, (Text, Text))| {
                    let v_ = v_.clone();
                    let g = g.clone();
                    let w = w.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let (gv, gc) = p1;
                        prism_rtl::Turn::Finished(seen || ((&gv == &v_) && crate::check::types::has_text(&super_closure(&g, &gc), &w.cls)))
                    }))
                }) as Rc<dyn Fn((bool, (Text, Text))) -> Rc<dyn prism_rtl::Job<bool>>>
            })) {
                (Array::new(), solved(st, w, &t, &Text::lit("given")))
            } else {
                (Array::new(), (&restore_fn)(&crate::check::types::recording::err_fix(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w.cls), v_)), &Text::from(format!("add `where {}: ^{}` to the signature", v_, &crate::check::types::bare_name(&w.cls))))))
            }
        },
        crate::check::types::Ty::TySig(s, inner) => if ((s == &Text::lit("?")) || (s == &Text::lit("~"))) && crate::check::types::has_text(&Array::from(vec![Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")]), &crate::check::types::bare_name(&w.cls)) {
            (Array::from(vec![crate::check::types::Want { cls: w.cls.clone(), ty: (**inner).clone(), file: w.file.clone(), span: w.span.clone(), level: w.level.clone() }]), solved(st, w, &t, &Text::lit("parts")))
        } else {
            (Array::new(), (&restore_fn)(&crate::check::types::recording::err_fix(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w.cls), &crate::check::types::show_ty(st, &t))), &Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first"))))
        },
        crate::check::types::Ty::TyAt(_, _) => (Array::new(), (&restore_fn)(&crate::check::types::recording::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w.cls), &crate::check::types::show_ty(st, &t)))))),
        crate::check::types::Ty::TyFn(_, _, _) => (Array::new(), (&restore_fn)(&crate::check::types::recording::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`: functions do not compare or print", &crate::check::types::bare_name(&w.cls), &crate::check::types::show_ty(st, &t)))))),
        _ => solve_at_head(g, st, &s0, &{
            let f = restore_fn.clone();
            Rc::new(move |a0: crate::check::types::St| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }, givens, w, &t),
    }
}

/// The step machine of `SolveOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
/// ```
pub struct SolveOne {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub givens: Array<(Text, Text)>,
    pub w: crate::check::types::Want,
}

impl prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)> for SolveOne {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Want>, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let givens = &self.givens;
        let w = &self.w;
        let g = g.clone();
        let givens = givens.clone();
        let st = st.clone();
        let w = w.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), w.ty.clone()), move |walk_8771: crate::check::types::Ty| {
            let t = walk_8771;
            let s0 = {
                let mut this: crate::check::types::St = st.clone();
                this.file = w.file.clone();
                this
            };
            let restore_fn = {
                let st = st.clone();
                Rc::new(move |s: &crate::check::types::St| with_file(s, &st.file))
            };
            match &t {
                crate::check::types::Ty::TyFlex(_) => prism_rtl::Turn::Finished((Array::from(vec![w.clone()]), st.clone())),
                crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished((Array::new(), st.clone())),
                crate::check::types::Ty::TyRigid(v_) => if (crate::syntax::lexer::chars::has_prefix(&w.cls, &Text::lit("Range ")) || (&w.cls == &Text::lit("Prelude.Sub"))) || (&w.cls == &Text::lit("Prelude.Signed")) {
                    prism_rtl::Turn::Finished((Array::new(), st.clone()))
                } else {
                    {
                        let v_ = v_.clone();
                        call_value(fold_job(givens.clone(), false, {
                            let v_ = v_.clone();
                            let g = g.clone();
                            let w = w.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, Text))| {
                                let v_ = v_.clone();
                                let g = g.clone();
                                let w = w.clone();
                                entered(once_job(move || {
                                    let seen = p0;
                                    let (gv, gc) = p1;
                                    prism_rtl::Turn::Finished(seen || ((&gv == &v_) && crate::check::types::has_text(&super_closure(&g, &gc), &w.cls)))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, Text))) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |fold_9108: bool| if fold_9108 {
                            prism_rtl::Turn::Finished((Array::new(), solved(&st, &w, &t, &Text::lit("given"))))
                        } else {
                            prism_rtl::Turn::Finished((Array::new(), (&restore_fn)(&crate::check::types::recording::err_fix(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w.cls), &v_)), &Text::from(format!("add `where {}: ^{}` to the signature", &v_, &crate::check::types::bare_name(&w.cls)))))))
                        })
                    }
                },
                crate::check::types::Ty::TySig(s, inner) => if ((s == &Text::lit("?")) || (s == &Text::lit("~"))) && crate::check::types::has_text(&Array::from(vec![Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")]), &crate::check::types::bare_name(&w.cls)) {
                    prism_rtl::Turn::Finished((Array::from(vec![crate::check::types::Want { cls: w.cls.clone(), ty: (**inner).clone(), file: w.file.clone(), span: w.span.clone(), level: w.level.clone() }]), solved(&st, &w, &t, &Text::lit("parts"))))
                } else {
                    call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_9735: Text| prism_rtl::Turn::Finished((Array::new(), (&restore_fn)(&crate::check::types::recording::err_fix(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w.cls), &show_ty_9735)), &Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first"))))))
                },
                crate::check::types::Ty::TyAt(_, _) => call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_9957: Text| prism_rtl::Turn::Finished((Array::new(), (&restore_fn)(&crate::check::types::recording::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name(&w.cls), &show_ty_9957))))))),
                crate::check::types::Ty::TyFn(_, _, _) => call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_10095: Text| prism_rtl::Turn::Finished((Array::new(), (&restore_fn)(&crate::check::types::recording::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`: functions do not compare or print", &crate::check::types::bare_name(&w.cls), &show_ty_10095))))))),
                _ => prism_rtl::Turn::More(Rc::new(SolveAtHead { g: g.clone(), st: st.clone(), s0: s0.clone(), restore_fn: {
                    let f = restore_fn.clone();
                    Rc::new(move |a0: crate::check::types::St| {
                        let f = f.clone();
                        once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                    }) as Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                }, givens: givens.clone(), w: w.clone(), t: t.clone() })),
            }
        })
    }
}

/// `Start SolveOne, x`: what the function value is when passed to `@Run`.
pub fn start_solve_one(g: crate::check::env::G, st: crate::check::types::St, givens: Array<(Text, Text)>, w: crate::check::types::Want) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>> {
    Rc::new(SolveOne { g, st, givens, w })
}

/// ```prism
/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub fn solve_at_head(g: &crate::check::env::G, st: &crate::check::types::St, s0: &crate::check::types::St, restore_fn: &Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens: &Array<(Text, Text)>, w: &crate::check::types::Want, t: &crate::check::types::Ty) -> (Array<crate::check::types::Want>, crate::check::types::St) {
    if crate::syntax::lexer::chars::has_prefix(&w.cls, &Text::lit("Range ")) {
        (Array::new(), run_to_end(restore_fn(literal_range(s0, w, t))))
    } else {
        if (&w.cls == &Text::lit("Prelude.Sub")) || (&w.cls == &Text::lit("Prelude.Signed")) {
            (Array::new(), run_to_end(restore_fn(signed_at(s0, w, t))))
        } else {
            solve_class(g, st, s0, &restore_fn.clone(), givens, w, t)
        }
    }
}

/// The step machine of `SolveAtHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub struct SolveAtHead {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub s0: crate::check::types::St,
    pub restore_fn: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>,
    pub givens: Array<(Text, Text)>,
    pub w: crate::check::types::Want,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)> for SolveAtHead {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Want>, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let s0 = &self.s0;
        let restore_fn = &self.restore_fn;
        let givens = &self.givens;
        let w = &self.w;
        let t = &self.t;
        if crate::syntax::lexer::chars::has_prefix(&w.cls, &Text::lit("Range ")) {
            {
                let restore_fn = restore_fn.clone();
                let s0 = s0.clone();
                let t = t.clone();
                let w = w.clone();
                call_then(start_literal_range(s0.clone(), w.clone(), t.clone()), move |literal_range_10413: crate::check::types::St| call_value((&restore_fn)(literal_range_10413), move |restore_10404: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_10404))))
            }
        } else {
            if (&w.cls == &Text::lit("Prelude.Sub")) || (&w.cls == &Text::lit("Prelude.Signed")) {
                {
                    let restore_fn = restore_fn.clone();
                    let s0 = s0.clone();
                    let t = t.clone();
                    let w = w.clone();
                    call_then(start_signed_at(s0.clone(), w.clone(), t.clone()), move |signed_at_10521: crate::check::types::St| call_value((&restore_fn)(signed_at_10521), move |restore_10512: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_10512))))
                }
            } else {
                prism_rtl::Turn::More(Rc::new(SolveClass { g: g.clone(), st: st.clone(), s0: s0.clone(), restore_fn: restore_fn.clone(), givens: givens.clone(), w: w.clone(), t: t.clone() }))
            }
        }
    }
}

/// `Start SolveAtHead, x`: what the function value is when passed to `@Run`.
pub fn start_solve_at_head(g: crate::check::env::G, st: crate::check::types::St, s0: crate::check::types::St, restore_fn: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens: Array<(Text, Text)>, w: crate::check::types::Want, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>> {
    Rc::new(SolveAtHead { g, st, s0, restore_fn, givens, w, t })
}

/// ```prism
/// LiteralRange: unbounded fn St, Want, Ty -> St
/// ```
pub fn literal_range(st: &crate::check::types::St, w: &crate::check::types::Want, t: &crate::check::types::Ty) -> crate::check::types::St {
    let lit = crate::syntax::lexer::chars::drop_prefix(&w.cls, &Text::lit("Range "));
    let negative = crate::syntax::lexer::chars::has_prefix(&lit, &Text::lit("-"));
    let digits = if negative { crate::syntax::lexer::chars::after_first(&lit) } else { lit.clone() };
    let n_opt = parse_nat_opt(&digits);
    match t {
        crate::check::types::Ty::TyCon(m10919_0_0, m10919_0_1) if (m10919_0_0 == &Text::lit("Nat")) && (m10919_0_1.len() == 0) => if negative && (&digits != &Text::lit("0")) {
            crate::check::types::recording::err(st, &Text::lit("literal-range"), &w.span, &Text::from(format!("`{}` does not fit `Nat`", &lit)))
        } else {
            st.clone()
        },
        crate::check::types::Ty::TyCon(m10919_1_0, m10919_1_1) if (m10919_1_0 == &Text::lit("U8")) && (m10919_1_1.len() == 0) => match &n_opt {
            Some(v_) => if negative || (v_ > &Nat::from(255u32)) {
                crate::check::types::recording::err(st, &Text::lit("literal-range"), &w.span, &Text::from(format!("`{}` does not fit `U8`", &lit)))
            } else {
                st.clone()
            },
            None => st.clone(),
        },
        _ => st.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LiteralRange`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralRange: unbounded fn St, Want, Ty -> St
/// ```
pub struct LiteralRange {
    pub st: crate::check::types::St,
    pub w: crate::check::types::Want,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for LiteralRange {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let w = &self.w;
        let t = &self.t;
        let lit = crate::syntax::lexer::chars::drop_prefix(&w.cls, &Text::lit("Range "));
        let negative = crate::syntax::lexer::chars::has_prefix(&lit, &Text::lit("-"));
        let digits = if negative { crate::syntax::lexer::chars::after_first(&lit) } else { lit.clone() };
        let n_opt = parse_nat_opt(&digits);
        match t {
            crate::check::types::Ty::TyCon(m10919_0_0, m10919_0_1) if (m10919_0_0 == &Text::lit("Nat")) && (m10919_0_1.len() == 0) => if negative && (&digits != &Text::lit("0")) {
                prism_rtl::Turn::Finished(crate::check::types::recording::err(st, &Text::lit("literal-range"), &w.span, &Text::from(format!("`{}` does not fit `Nat`", &lit))))
            } else {
                prism_rtl::Turn::Finished(st.clone())
            },
            crate::check::types::Ty::TyCon(m10919_1_0, m10919_1_1) if (m10919_1_0 == &Text::lit("U8")) && (m10919_1_1.len() == 0) => match &n_opt {
                Some(v_) => if negative || (v_ > &Nat::from(255u32)) {
                    prism_rtl::Turn::Finished(crate::check::types::recording::err(st, &Text::lit("literal-range"), &w.span, &Text::from(format!("`{}` does not fit `U8`", &lit))))
                } else {
                    prism_rtl::Turn::Finished(st.clone())
                },
                None => prism_rtl::Turn::Finished(st.clone()),
            },
            _ => prism_rtl::Turn::Finished(st.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LiteralRange, x`: what the function value is when passed to `@Run`.
pub fn start_literal_range(st: crate::check::types::St, w: crate::check::types::Want, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(LiteralRange { st, w, t })
}

/// ```prism
/// SignedAt: unbounded fn St, Want, Ty -> St
/// ```
pub fn signed_at(st: &crate::check::types::St, w: &crate::check::types::Want, t: &crate::check::types::Ty) -> crate::check::types::St {
    match t {
        crate::check::types::Ty::TyCon(m11390_0_0, m11390_0_1) if (m11390_0_0 == &Text::lit("Nat")) && (m11390_0_1.len() == 0) => if &w.cls == &Text::lit("Prelude.Sub") {
            crate::check::types::recording::err_fix(st, &Text::lit("nat-minus"), &w.span, &Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), &Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`"))
        } else {
            st.clone()
        },
        crate::check::types::Ty::TyCon(m11390_1_0, m11390_1_1) if (m11390_1_0 == &Text::lit("U8")) && (m11390_1_1.len() == 0) => if &w.cls == &Text::lit("Prelude.Sub") { st.clone() } else { st.clone() },
        _ => st.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SignedAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SignedAt: unbounded fn St, Want, Ty -> St
/// ```
pub struct SignedAt {
    pub st: crate::check::types::St,
    pub w: crate::check::types::Want,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for SignedAt {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let w = &self.w;
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyCon(m11390_0_0, m11390_0_1) if (m11390_0_0 == &Text::lit("Nat")) && (m11390_0_1.len() == 0) => if &w.cls == &Text::lit("Prelude.Sub") {
                prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(st, &Text::lit("nat-minus"), &w.span, &Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), &Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`")))
            } else {
                prism_rtl::Turn::Finished(st.clone())
            },
            crate::check::types::Ty::TyCon(m11390_1_0, m11390_1_1) if (m11390_1_0 == &Text::lit("U8")) && (m11390_1_1.len() == 0) => if &w.cls == &Text::lit("Prelude.Sub") {
                prism_rtl::Turn::Finished(st.clone())
            } else {
                prism_rtl::Turn::Finished(st.clone())
            },
            _ => prism_rtl::Turn::Finished(st.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SignedAt, x`: what the function value is when passed to `@Run`.
pub fn start_signed_at(st: crate::check::types::St, w: crate::check::types::Want, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SignedAt { st, w, t })
}

/// ```prism
/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub fn solve_class(g: &crate::check::env::G, st: &crate::check::types::St, s0: &crate::check::types::St, restore_fn: &Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens: &Array<(Text, Text)>, w: &crate::check::types::Want, t: &crate::check::types::Ty) -> (Array<crate::check::types::Want>, crate::check::types::St) {
    let bare = crate::check::types::bare_name(&w.cls);
    let parts_opt = match t {
        crate::check::types::Ty::TyTuple(ts) => Some(ts.clone()),
        crate::check::types::Ty::TyArray(e) => Some(Array::from(vec![(**e).clone()])),
        crate::check::types::Ty::TyMap(k, v_) => Some(Array::from(vec![(**k).clone(), (**v_).clone()])),
        _ => None,
    };
    let structural = ((&bare == &Text::lit("Eq")) || (&bare == &Text::lit("Ord"))) || (&bare == &Text::lit("Show"));
    match &parts_opt {
        Some(ps) => if structural {
            (each(ps, &(|p_: &crate::check::types::Ty| crate::check::types::Want { cls: w.cls.clone(), ty: p_.clone(), file: w.file.clone(), span: w.span.clone(), level: w.level.clone() })), solved(st, w, t, &Text::lit("parts")))
        } else {
            (Array::new(), run_to_end(restore_fn(crate::check::types::recording::err(s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &crate::check::types::show_ty(st, t)))))))
        },
        None => match t {
            crate::check::types::Ty::TySig(_, _) => (Array::new(), st.clone()),
            crate::check::types::Ty::TyElem(_, _) => if (&bare == &Text::lit("Eq")) || (&bare == &Text::lit("Show")) {
                (Array::new(), solved(st, w, t, &Text::lit("builtin")))
            } else {
                (Array::new(), run_to_end(restore_fn(crate::check::types::recording::err(s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &crate::check::types::show_ty(st, t)))))))
            },
            crate::check::types::Ty::TyElemAny(_) => if (&bare == &Text::lit("Eq")) || (&bare == &Text::lit("Show")) {
                (Array::new(), solved(st, w, t, &Text::lit("builtin")))
            } else {
                (Array::new(), run_to_end(restore_fn(crate::check::types::recording::err(s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &crate::check::types::show_ty(st, t)))))))
            },
            crate::check::types::Ty::TyAny(trs) => if crate::check::types::has_text(trs, &w.cls) || run_to_end(fold_job(trs.clone(), false, {
                let g = g.clone();
                let w = w.clone();
                Rc::new(move |(p0, p1): (bool, Text)| {
                    let g = g.clone();
                    let w = w.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let tr = p1;
                        prism_rtl::Turn::Finished(seen || crate::check::types::has_text(&super_closure(&g, &tr), &w.cls))
                    }))
                }) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>
            })) {
                (Array::new(), solved(st, w, t, &Text::lit("packed")))
            } else {
                (Array::new(), run_to_end(restore_fn(crate::check::types::recording::err(s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &crate::check::types::show_ty(st, t)))))))
            },
            crate::check::types::Ty::TyCon(con, args) => if builtin_has(&w.cls, con) {
                (Array::new(), solved(st, w, t, &Text::lit("builtin")))
            } else {
                match find_impl(g, st, &w.cls, t) {
                    Some((im, s2, how, ch)) => {
                        let wants = each(&im, &(|(ty, cls): &(crate::check::types::Ty, Text)| crate::check::types::Want { cls: cls.clone(), ty: ty.clone(), file: w.file.clone(), span: w.span.clone(), level: w.level.clone() }));
                        (wants.clone(), crate::check::types::recording::note_choice(&solved(&s2, w, t, &how), &w.file, &w.span, &w.cls, &ch))
                    },
                    None => {
                        let fix = if (&bare == &Text::lit("Num")) && (con == &Text::lit("Text")) {
                            Text::lit("")
                        } else {
                            Text::from(format!("derive `^{}` on `{}`, or write `impl ^{} {}`", &bare, &crate::check::types::bare_name(con), &bare, &crate::check::types::bare_name(con)))
                        };
                        (Array::new(), run_to_end(restore_fn(crate::check::types::recording::err_fix(s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &crate::check::types::show_ty(st, t))), &fix))))
                    },
                }
            },
            _ => (Array::new(), st.clone()),
        },
    }
}

/// The step machine of `SolveClass`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub struct SolveClass {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub s0: crate::check::types::St,
    pub restore_fn: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>,
    pub givens: Array<(Text, Text)>,
    pub w: crate::check::types::Want,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)> for SolveClass {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Want>, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let s0 = &self.s0;
        let restore_fn = &self.restore_fn;
        let givens = &self.givens;
        let w = &self.w;
        let t = &self.t;
        let bare = crate::check::types::bare_name(&w.cls);
        let parts_opt = match t {
            crate::check::types::Ty::TyTuple(ts) => Some(ts.clone()),
            crate::check::types::Ty::TyArray(e) => Some(Array::from(vec![(**e).clone()])),
            crate::check::types::Ty::TyMap(k, v_) => Some(Array::from(vec![(**k).clone(), (**v_).clone()])),
            _ => None,
        };
        let structural = ((&bare == &Text::lit("Eq")) || (&bare == &Text::lit("Ord"))) || (&bare == &Text::lit("Show"));
        match &parts_opt {
            Some(ps) => if structural {
                prism_rtl::Turn::Finished((each(ps, &(|p_: &crate::check::types::Ty| crate::check::types::Want { cls: w.cls.clone(), ty: p_.clone(), file: w.file.clone(), span: w.span.clone(), level: w.level.clone() })), solved(st, w, t, &Text::lit("parts"))))
            } else {
                {
                    let restore_fn = restore_fn.clone();
                    let s0 = s0.clone();
                    let st = st.clone();
                    let t = t.clone();
                    let w = w.clone();
                    call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_12318: Text| call_value((&restore_fn)(crate::check::types::recording::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &show_ty_12318)))), move |restore_12254: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_12254))))
                }
            },
            None => match t {
                crate::check::types::Ty::TySig(_, _) => prism_rtl::Turn::Finished((Array::new(), st.clone())),
                crate::check::types::Ty::TyElem(_, _) => if (&bare == &Text::lit("Eq")) || (&bare == &Text::lit("Show")) {
                    prism_rtl::Turn::Finished((Array::new(), solved(st, w, t, &Text::lit("builtin"))))
                } else {
                    {
                        let restore_fn = restore_fn.clone();
                        let s0 = s0.clone();
                        let st = st.clone();
                        let t = t.clone();
                        let w = w.clone();
                        call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_12593: Text| call_value((&restore_fn)(crate::check::types::recording::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &show_ty_12593)))), move |restore_12529: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_12529))))
                    }
                },
                crate::check::types::Ty::TyElemAny(_) => if (&bare == &Text::lit("Eq")) || (&bare == &Text::lit("Show")) {
                    prism_rtl::Turn::Finished((Array::new(), solved(st, w, t, &Text::lit("builtin"))))
                } else {
                    {
                        let restore_fn = restore_fn.clone();
                        let s0 = s0.clone();
                        let st = st.clone();
                        let t = t.clone();
                        let w = w.clone();
                        call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_12794: Text| call_value((&restore_fn)(crate::check::types::recording::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &show_ty_12794)))), move |restore_12730: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_12730))))
                    }
                },
                crate::check::types::Ty::TyAny(trs) => if crate::check::types::has_text(trs, &w.cls) || run_to_end(fold_job(trs.clone(), false, {
                    let g = g.clone();
                    let w = w.clone();
                    Rc::new(move |(p0, p1): (bool, Text)| {
                        let g = g.clone();
                        let w = w.clone();
                        entered(once_job(move || {
                            let seen = p0;
                            let tr = p1;
                            prism_rtl::Turn::Finished(seen || crate::check::types::has_text(&super_closure(&g, &tr), &w.cls))
                        }))
                    }) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>
                })) {
                    prism_rtl::Turn::Finished((Array::new(), solved(st, w, t, &Text::lit("packed"))))
                } else {
                    {
                        let restore_fn = restore_fn.clone();
                        let s0 = s0.clone();
                        let st = st.clone();
                        let t = t.clone();
                        let w = w.clone();
                        call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_13057: Text| call_value((&restore_fn)(crate::check::types::recording::err(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &show_ty_13057)))), move |restore_12993: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_12993))))
                    }
                },
                crate::check::types::Ty::TyCon(con, args) => if builtin_has(&w.cls, con) {
                    prism_rtl::Turn::Finished((Array::new(), solved(st, w, t, &Text::lit("builtin"))))
                } else {
                    {
                        let restore_fn = restore_fn.clone();
                        let con = con.clone();
                        let g = g.clone();
                        let s0 = s0.clone();
                        let st = st.clone();
                        let t = t.clone();
                        let w = w.clone();
                        call_then(start_find_impl(g.clone(), st.clone(), w.cls.clone(), t.clone()), move |find_impl_13214: Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>| match find_impl_13214 {
                            Some((im, s2, how, ch)) => {
                                let wants = each(&im, &(|(ty, cls): &(crate::check::types::Ty, Text)| crate::check::types::Want { cls: cls.clone(), ty: ty.clone(), file: w.file.clone(), span: w.span.clone(), level: w.level.clone() }));
                                prism_rtl::Turn::Finished((wants.clone(), crate::check::types::recording::note_choice(&solved(&s2, &w, &t, &how), &w.file, &w.span, &w.cls, &ch)))
                            },
                            None => {
                                let fix = if (&bare == &Text::lit("Num")) && (&con == &Text::lit("Text")) {
                                    Text::lit("")
                                } else {
                                    Text::from(format!("derive `^{}` on `{}`, or write `impl ^{} {}`", &bare, &crate::check::types::bare_name(&con), &bare, &crate::check::types::bare_name(&con)))
                                };
                                call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_13786: Text| call_value((&restore_fn)(crate::check::types::recording::err_fix(&s0, &Text::lit("no-impl"), &w.span, &Text::from(format!("no impl of `^{}` for `{}`", &bare, &show_ty_13786)), &fix)), move |restore_13719: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_13719))))
                            },
                        })
                    }
                },
                _ => prism_rtl::Turn::Finished((Array::new(), st.clone())),
            },
        }
    }
}

/// `Start SolveClass, x`: what the function value is when passed to `@Run`.
pub fn start_solve_class(g: crate::check::env::G, st: crate::check::types::St, s0: crate::check::types::St, restore_fn: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens: Array<(Text, Text)>, w: crate::check::types::Want, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>> {
    Rc::new(SolveClass { g, st, s0, restore_fn, givens, w, t })
}

/// ```prism
/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
/// ```
pub fn find_impl(g: &crate::check::env::G, st: &crate::check::types::St, cls: &Text, t: &crate::check::types::Ty) -> Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)> {
    run_to_end(fold_job(or(&get(&g.impls, cls), &Array::new()), None, {
        let st = st.clone();
        let t = t.clone();
        let g = g.clone();
        Rc::new(move |(p0, p1): (Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, crate::check::env::ImplInfo)| {
            let st = st.clone();
            let t = t.clone();
            let g = g.clone();
            entered(once_job(move || {
                let found_opt = p0;
                let im = p1;
                match &found_opt {
                    Some(f) => prism_rtl::Turn::Finished(Some(f.clone())),
                    None => call_then(crate::check::types::recording::start_zonk(st.clone(), t.clone()), move |zonk_14251: crate::check::types::Ty| match match_head(&im.head, &zonk_14251, &Map::new()) {
                        Some(m) => prism_rtl::Turn::Finished(Some((each(&im.bounds, &(|(v_, c): &(Text, Text)| (or(&get(&m, v_), &crate::check::types::Ty::TyErr), c.clone()))), st.clone(), impl_how(&g, &im), impl_choice(&im)))),
                        None => prism_rtl::Turn::Finished(None),
                    }),
                }
            }))
        }) as Rc<dyn Fn((Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>>>>
    }))
}

/// The step machine of `FindImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
/// ```
pub struct FindImpl {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub cls: Text,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>> for FindImpl {
    fn cycle(&self) -> prism_rtl::Turn<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>> {
        let g = &self.g;
        let st = &self.st;
        let cls = &self.cls;
        let t = &self.t;
        fold_job(or(&get(&g.impls, cls), &Array::new()), None, {
            let st = st.clone();
            let t = t.clone();
            let g = g.clone();
            Rc::new(move |(p0, p1): (Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, crate::check::env::ImplInfo)| {
                let st = st.clone();
                let t = t.clone();
                let g = g.clone();
                entered(once_job(move || {
                    let found_opt = p0;
                    let im = p1;
                    match &found_opt {
                        Some(f) => prism_rtl::Turn::Finished(Some(f.clone())),
                        None => call_then(crate::check::types::recording::start_zonk(st.clone(), t.clone()), move |zonk_14251: crate::check::types::Ty| match match_head(&im.head, &zonk_14251, &Map::new()) {
                            Some(m) => prism_rtl::Turn::Finished(Some((each(&im.bounds, &(|(v_, c): &(Text, Text)| (or(&get(&m, v_), &crate::check::types::Ty::TyErr), c.clone()))), st.clone(), impl_how(&g, &im), impl_choice(&im)))),
                            None => prism_rtl::Turn::Finished(None),
                        }),
                    }
                }))
            }) as Rc<dyn Fn((Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>>>>
        }).cycle()
    }
}

/// `Start FindImpl, x`: what the function value is when passed to `@Run`.
pub fn start_find_impl(g: crate::check::env::G, st: crate::check::types::St, cls: Text, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>>> {
    Rc::new(FindImpl { g, st, cls, t })
}

/// ```prism
/// ImplChoice: fn ImplInfo -> Text
/// ```
pub fn impl_choice(im: &crate::check::env::ImplInfo) -> Text {
    match &im.head {
        crate::check::types::Ty::TyCon(n, _) => if im.derived {
            Text::from(format!("derived:{}", n))
        } else {
            Text::from(format!("impl:{}.{}", &im.file, &im.span.start))
        },
        _ => if im.derived {
            Text::lit("any")
        } else {
            Text::from(format!("impl:{}.{}", &im.file, &im.span.start))
        },
    }
}

/// ```prism
/// ImplHow: fn G, ImplInfo -> Text
/// ```
pub fn impl_how(g: &crate::check::env::G, im: &crate::check::env::ImplInfo) -> Text {
    let src = or(&index(&g.srcs, &im.file), &crate::check::errors::mk_src(&Text::lit("?"), &Text::lit("")));
    Text::from(format!("{} {}:{}", &(if im.derived { Text::lit("derived") } else { Text::lit("impl") }), &src.path_, &(&crate::check::errors::cline_of(&src.starts, &im.span.start) + &Nat::from(1u32))))
}

/// ```prism
/// Solved: fn St, Want, Ty, Text -> St
/// ```
pub fn solved(st: &crate::check::types::St, w: &crate::check::types::Want, t: &crate::check::types::Ty, how: &Text) -> crate::check::types::St {
    let s2 = crate::check::types::recording::note_impl(st, &w.file, &w.span, &w.cls, t, how);
    if ((how == &Text::lit("given")) || (how == &Text::lit("packed"))) || (how == &Text::lit("quantified")) {
        crate::check::types::recording::note_choice(&s2, &w.file, &w.span, &w.cls, &Text::lit("any"))
    } else {
        if (how == &Text::lit("builtin")) || (how == &Text::lit("parts")) {
            crate::check::types::recording::note_choice(&s2, &w.file, &w.span, &w.cls, &Text::lit("none"))
        } else {
            s2.clone()
        }
    }
}

/// ```prism
/// ?MatchHead: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub fn match_head(pat: &crate::check::types::Ty, t: &crate::check::types::Ty, m: &Map<Text, crate::check::types::Ty>) -> Option<Map<Text, crate::check::types::Ty>> {
    match (pat.clone(), t.clone()) {
        (crate::check::types::Ty::TyQ(v_), x) => match get(m, &v_) {
            Some(y) => if &y == &x { Some(m.clone()) } else { None },
            None => Some(insert(m, &v_, &x)),
        },
        (crate::check::types::Ty::TyCon(a, xs), crate::check::types::Ty::TyCon(b, ys)) => if (&a == &b) && (&len(&xs) == &len(&ys)) { match_all(&xs, &ys, m) } else { None },
        (crate::check::types::Ty::TyTuple(xs), crate::check::types::Ty::TyTuple(ys)) => if &len(&xs) == &len(&ys) { match_all(&xs, &ys, m) } else { None },
        (crate::check::types::Ty::TyArray(x), crate::check::types::Ty::TyArray(y)) => match_head(&*x, &*y, m),
        (crate::check::types::Ty::TyMap(k1, v1), crate::check::types::Ty::TyMap(k2, v2)) => match_all(&Array::from(vec![(*k1).clone(), (*v1).clone()]), &Array::from(vec![(*k2).clone(), (*v2).clone()]), m),
        (crate::check::types::Ty::TySig(s1, i1), crate::check::types::Ty::TySig(s2, i2)) => if &s1 == &s2 { match_head(&*i1, &*i2, m) } else { None },
        _ => None,
    }
}

/// ```prism
/// ?MatchAll: unbounded fn [Ty], [Ty], (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub fn match_all(xs: &Array<crate::check::types::Ty>, ys: &Array<crate::check::types::Ty>, m: &Map<Text, crate::check::types::Ty>) -> Option<Map<Text, crate::check::types::Ty>> {
    run_to_end(fold_job(crate::check::errors::range0(&len(xs)), Some(m.clone()), {
        let xs = xs.clone();
        let ys = ys.clone();
        Rc::new(move |(p0, p1): (Option<Map<Text, crate::check::types::Ty>>, Nat)| {
            let xs = xs.clone();
            let ys = ys.clone();
            entered(once_job(move || {
                let acc_opt = p0;
                let i = p1;
                match &acc_opt {
                    Some(mm) => prism_rtl::Turn::Finished(match_head(&or(&index(&xs, &i), &crate::check::types::Ty::TyErr), &or(&index(&ys, &i), &crate::check::types::Ty::TyErr), mm)),
                    None => prism_rtl::Turn::Finished(None),
                }
            }))
        }) as Rc<dyn Fn((Option<Map<Text, crate::check::types::Ty>>, Nat)) -> Rc<dyn prism_rtl::Job<Option<Map<Text, crate::check::types::Ty>>>>>
    }))
}

/// ```prism
/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
/// ```
pub fn default_wants(g: &crate::check::env::G, st: &crate::check::types::St, givens: &Array<(Text, Text)>) -> crate::check::types::St {
    let flex_vars = run_to_end(fold_job(st.wants.clone(), Array::new(), {
        let st = st.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Want)| {
            let st = st.clone();
            entered(once_job(move || {
                let acc = p0;
                let w = p1;
                call_then(crate::check::types::recording::start_walk(st.clone(), w.ty.clone()), move |walk_16835: crate::check::types::Ty| match walk_16835 {
                    crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(crate::check::types::add_nat(&acc, &n)),
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                })
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    let s2 = run_to_end(fold_job(flex_vars.clone(), st.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| entered(once_job(move || {
        let s = p0;
        let v_ = p1;
        call_value(filter_job(s.wants.clone(), {
            let s = s.clone();
            let v_ = v_.clone();
            Rc::new(move |p0: crate::check::types::Want| {
                let s = s.clone();
                let v_ = v_.clone();
                entered(once_job(move || {
                    let w = p0;
                    call_then(crate::check::types::recording::start_walk(s.clone(), w.ty.clone()), move |walk_16995: crate::check::types::Ty| prism_rtl::Turn::Finished(&walk_16995 == &crate::check::types::Ty::TyFlex(v_.clone())))
                }))
            }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |filter_16973: Array<crate::check::types::Want>| {
            let classes = each(&filter_16973, &(|w: &crate::check::types::Want| crate::check::types::bare_name(&w.cls)));
            let defaultable = crate::check::types::has_text(&classes, &Text::lit("Num")) && fold(&classes, &true, &(|ok: &bool, c: &Text| *ok && (crate::check::types::has_text(&Array::from(vec![Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")]), c) || crate::syntax::lexer::chars::has_prefix(c, &Text::lit("Range ")))));
            if defaultable {
                prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = s.clone();
                    this.tys = insert(&this.tys, &v_, &crate::check::types::t_int());
                    this
                })
            } else {
                prism_rtl::Turn::Finished(s.clone())
            }
        })
    }))) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>));
    let s3 = solve_wants(g, &s2, givens, &false);
    let leftover = run_to_end(filter_job(s3.wants.clone(), {
        let s3 = s3.clone();
        Rc::new(move |p0: crate::check::types::Want| {
            let s3 = s3.clone();
            entered(once_job(move || {
                let w = p0;
                call_then(crate::check::types::start_is_flex_var(s3.clone(), w.ty.clone()), move |is_flex_var_17408: bool| prism_rtl::Turn::Finished(((is_flex_var_17408 && !crate::syntax::lexer::chars::has_prefix(&w.cls, &Text::lit("Range "))) && (&w.cls != &Text::lit("Prelude.Sub"))) && (&w.cls != &Text::lit("Prelude.Signed"))))
            }))
        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let s4 = run_to_end(fold_job(leftover.clone(), s3.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Want)| entered(once_job(move || {
        let s = p0;
        let w = p1;
        {
            let s5 = {
                let mut this: crate::check::types::St = s.clone();
                this.file = w.file.clone();
                this
            };
            call_then(crate::check::types::start_show_ty(s.clone(), w.ty.clone()), move |show_ty_17679: Text| call_then(crate::check::types::start_show_ty(s.clone(), w.ty.clone()), move |show_ty_17719: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s5, &Text::lit("ambiguous"), &w.span, &Text::from(format!("nothing decides `{}` in `^{} {}`; annotate, or write a suffixed operator", &show_ty_17679, &crate::check::types::bare_name(&w.cls), &show_ty_17719)), &Text::lit("annotate the value\'s type")))))
        }
    }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>));
    let mut this: crate::check::types::St = s4.clone();
    this.wants = Array::new();
    this.file = st.file.clone();
    this
}

/// The step machine of `DefaultWants`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
/// ```
pub struct DefaultWants {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub givens: Array<(Text, Text)>,
}

impl prism_rtl::Job<crate::check::types::St> for DefaultWants {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let givens = &self.givens;
        let g = g.clone();
        let givens = givens.clone();
        let st = st.clone();
        call_value(fold_job(st.wants.clone(), Array::new(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Want)| {
                let st = st.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let w = p1;
                    call_then(crate::check::types::recording::start_walk(st.clone(), w.ty.clone()), move |walk_16835: crate::check::types::Ty| match walk_16835 {
                        crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(crate::check::types::add_nat(&acc, &n)),
                        _ => prism_rtl::Turn::Finished(acc.clone()),
                    })
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        }), move |fold_16798: Array<Nat>| {
            let flex_vars = fold_16798;
            call_value(fold_job(flex_vars.clone(), st.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| entered(once_job(move || {
                let s = p0;
                let v_ = p1;
                call_value(filter_job(s.wants.clone(), {
                    let s = s.clone();
                    let v_ = v_.clone();
                    Rc::new(move |p0: crate::check::types::Want| {
                        let s = s.clone();
                        let v_ = v_.clone();
                        entered(once_job(move || {
                            let w = p0;
                            call_then(crate::check::types::recording::start_walk(s.clone(), w.ty.clone()), move |walk_16995: crate::check::types::Ty| prism_rtl::Turn::Finished(&walk_16995 == &crate::check::types::Ty::TyFlex(v_.clone())))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |filter_16973: Array<crate::check::types::Want>| {
                    let classes = each(&filter_16973, &(|w: &crate::check::types::Want| crate::check::types::bare_name(&w.cls)));
                    let defaultable = crate::check::types::has_text(&classes, &Text::lit("Num")) && fold(&classes, &true, &(|ok: &bool, c: &Text| *ok && (crate::check::types::has_text(&Array::from(vec![Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")]), c) || crate::syntax::lexer::chars::has_prefix(c, &Text::lit("Range ")))));
                    if defaultable {
                        prism_rtl::Turn::Finished({
                            let mut this: crate::check::types::St = s.clone();
                            this.tys = insert(&this.tys, &v_, &crate::check::types::t_int());
                            this
                        })
                    } else {
                        prism_rtl::Turn::Finished(s.clone())
                    }
                })
            }))) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>), move |fold_16918: crate::check::types::St| {
                let s2 = fold_16918;
                call_then(start_solve_wants(g.clone(), s2.clone(), givens.clone(), false), move |solve_wants_17334: crate::check::types::St| {
                    let s3 = solve_wants_17334;
                    call_value(filter_job(s3.wants.clone(), {
                        let s3 = s3.clone();
                        Rc::new(move |p0: crate::check::types::Want| {
                            let s3 = s3.clone();
                            entered(once_job(move || {
                                let w = p0;
                                call_then(crate::check::types::start_is_flex_var(s3.clone(), w.ty.clone()), move |is_flex_var_17408: bool| prism_rtl::Turn::Finished(((is_flex_var_17408 && !crate::syntax::lexer::chars::has_prefix(&w.cls, &Text::lit("Range "))) && (&w.cls != &Text::lit("Prelude.Sub"))) && (&w.cls != &Text::lit("Prelude.Signed"))))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |filter_17385: Array<crate::check::types::Want>| {
                        let leftover = filter_17385;
                        call_value(fold_job(leftover.clone(), s3.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Want)| entered(once_job(move || {
                            let s = p0;
                            let w = p1;
                            {
                                let s5 = {
                                    let mut this: crate::check::types::St = s.clone();
                                    this.file = w.file.clone();
                                    this
                                };
                                call_then(crate::check::types::start_show_ty(s.clone(), w.ty.clone()), move |show_ty_17679: Text| call_then(crate::check::types::start_show_ty(s.clone(), w.ty.clone()), move |show_ty_17719: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s5, &Text::lit("ambiguous"), &w.span, &Text::from(format!("nothing decides `{}` in `^{} {}`; annotate, or write a suffixed operator", &show_ty_17679, &crate::check::types::bare_name(&w.cls), &show_ty_17719)), &Text::lit("annotate the value\'s type")))))
                            }
                        }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>), move |fold_17536: crate::check::types::St| {
                            let s4 = fold_17536;
                            prism_rtl::Turn::Finished({
                                let mut this: crate::check::types::St = s4.clone();
                                this.wants = Array::new();
                                this.file = st.file.clone();
                                this
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start DefaultWants, x`: what the function value is when passed to `@Run`.
pub fn start_default_wants(g: crate::check::env::G, st: crate::check::types::St, givens: Array<(Text, Text)>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DefaultWants { g, st, givens })
}
