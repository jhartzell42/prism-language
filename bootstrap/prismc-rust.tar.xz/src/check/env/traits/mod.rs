//! The module `Check.Env.Traits`, from `target/bootstrap/src/prismc/check/env/traits.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// DerivedImpls: fn G -> G
/// ```
pub fn derived_impls_f(g_p0: &crate::check::env::G) -> crate::check::env::G {
    crate::prelude::fold(&crate::prelude::keys(&g_p0.types_p), g_p0, &(|gg_p1: &crate::check::env::G, k_p2: &Text| match crate::prelude::get(&gg_p1.types_p, k_p2) {
        Some(ti_p3) => crate::prelude::fold(&ti_p3.derives_p, gg_p1, &(|g2_p4: &crate::check::env::G, tr_p5: &Text| match crate::check::env::names::resolve_trait_o(g2_p4, &ti_p3.home_p, &crate::prelude::split_on(tr_p5, &Text::lit("."))) {
            Some(cls_p6) => {
                let im_p7 = crate::check::env::ImplInfo { cls_p: cls_p6.clone(), head_p: crate::check::types::Ty::TyCon(ti_p3.name_p.clone(), crate::prelude::each(&ti_p3.params_p, &(|p_p8: &Text| crate::check::types::Ty::TyQ(p_p8.clone())))), qs_p: ti_p3.params_p.clone(), bounds_p: crate::prelude::each(&ti_p3.params_p, &(|p_p9: &Text| (p_p9.clone(), cls_p6.clone()))), home_p: ti_p3.home_p.clone(), file_p: ti_p3.file_p.clone(), span_p: ti_p3.span_p.clone(), derived_p: true, assocs_p: Array::new(), methods_p: Array::new() };
                {
                    let mut this: crate::check::env::G = g2_p4.clone();
                    this.impls_p = crate::prelude::insert(&this.impls_p, &cls_p6, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(&this.impls_p, &cls_p6), &Array::new()), &im_p7));
                    this
                }
            },
            None => g2_p4.clone(),
        })),
        None => gg_p1.clone(),
    }))
}

/// ```prism
/// DerivedDynamics: fn G, St -> St
/// ```
pub fn derived_dynamics_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> crate::check::types::St {
    crate::prelude::fold(&crate::prelude::keys(&g_p0.types_p), st_p1, &(|s_p2: &crate::check::types::St, k_p3: &Text| match crate::prelude::get(&g_p0.types_p, k_p3) {
        Some(ti_p4) => {
            let held_p5 = crate::prelude::filter(&ti_p4.derives_p, &(|d_p6: &Text| crate::check::types::has_text_f(&Array::from(vec![Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")]), &crate::check::types::bare_name_f(d_p6))));
            match field_holding_o(&ti_p4.body_p) {
                Some(f_p7) if (&crate::prelude::len(&held_p5) > &Nat::from(0u32)) => with_file_f(&crate::check::types::recording::err_fix_f(&with_file_f(s_p2, &ti_p4.file_p), &Text::lit("derive-dynamic"), &ti_p4.span_p, &Text::from(format!("`derive ^{}` on `{}`, whose `{}` holds a dynamic or an event, which does not compare or print", &crate::check::types::bare_name_f(&crate::prelude::or(&crate::prelude::index(&held_p5, &Nat::from(0u32)), &Text::lit(""))), &crate::check::types::bare_name_f(&ti_p4.name_p), &f_p7)), &Text::lit("drop the derive")), &s_p2.file_p),
                _ => s_p2.clone(),
                _ => unreachable!("no arm matched"),
            }
        },
        None => s_p2.clone(),
    }))
}

/// ```prism
/// ?FieldHolding: fn TyBody -> ?Text
/// ```
pub fn field_holding_o(b_p0: &crate::check::env::TyBody) -> Option<Text> {
    match b_p0 {
        crate::check::env::TyBody::BRecord(fs_p1) => crate::prelude::fold(fs_p1, &None, &(|found_o2: &Option<Text>, (f_p3, t_p4): &(Text, crate::check::types::Ty)| if (found_o2 == &None) && holds_layer_f(t_p4) {
            Some(f_p3.clone())
        } else {
            found_o2.clone()
        })),
        crate::check::env::TyBody::BChoice(cs_p5) => crate::prelude::fold(cs_p5, &None, &(|found_o6: &Option<Text>, (c_p7, ts_p8): &(Text, Array<crate::check::types::Ty>)| if (found_o6 == &None) && crate::prelude::fold(ts_p8, &false, &(|h_p9: &bool, t_pa: &crate::check::types::Ty| *h_p9 || holds_layer_f(t_pa))) {
            Some(c_p7.clone())
        } else {
            found_o6.clone()
        })),
        _ => None,
    }
}

/// ```prism
/// HoldsLayer: fn Ty -> Bool
/// ```
pub fn holds_layer_f(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TySig(m2957_0_0, _) if (m2957_0_0 == &Text::lit("$")) => true,
        crate::check::types::Ty::TySig(m2957_1_0, _) if (m2957_1_0 == &Text::lit("!")) => true,
        crate::check::types::Ty::TySig(_, i_p1) => holds_layer_f(&**i_p1),
        crate::check::types::Ty::TyTuple(ts_p2) => crate::prelude::fold(ts_p2, &false, &(|h_p3: &bool, x_p4: &crate::check::types::Ty| *h_p3 || holds_layer_f(x_p4))),
        crate::check::types::Ty::TyArray(e_p5) => holds_layer_f(&**e_p5),
        crate::check::types::Ty::TyMap(k_p6, v_p7) => holds_layer_f(&**k_p6) || holds_layer_f(&**v_p7),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RowHoldsDynamics: fn G, Rw -> Bool
/// ```
pub fn row_holds_dynamics_f(g_p0: &crate::check::env::G, w_p1: &crate::check::types::Rw) -> bool {
    crate::prelude::fold(&crate::prelude::values(&g_p0.tags_p), &false, &(|h_p2: &bool, tg_p3: &crate::check::env::TagInfo| *h_p2 || ((((&tg_p3.kind_p == &Text::lit("Element")) && crate::check::types::has_text_f(&w_p1.fams_p, &tg_p3.family_p)) && !crate::check::types::has_text_f(&w_p1.minus_p, &tg_p3.name_p)) && crate::prelude::fold(&tg_p3.fields_p, &false, &(|f_p4: &bool, (_, ft_p5): &(Text, crate::check::types::Ty)| *f_p4 || holds_layer_f(&unlive_f(ft_p5)))))))
}

/// ```prism
/// Unlive: fn Ty -> Ty
/// ```
pub fn unlive_f(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TySig(m3847_0_0, i_p1) if (m3847_0_0 == &Text::lit("$")) => (**i_p1).clone(),
        other_p2 => other_p2.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Coherence: unbounded fn G, St -> St
/// ```
pub fn coherence_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> crate::check::types::St {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g_p0.impls_p), st_p1.clone(), {
        let g_p0x = g_p0.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p2 = p0;
                let cls_p3 = p1;
                {
                    let impls_p4 = crate::prelude::or(&crate::prelude::get(&g_p0xy.impls_p, &cls_p3), &Array::new());
                    crate::prelude::call_value(crate::prelude::fold_job(impls_p4.clone(), s_p2.clone(), {
                        let g_p0xyx = g_p0xy.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::ImplInfo)| {
                            let g_p0xyxy = g_p0xyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let s1_p6 = p0;
                                let i_p7 = p1;
                                prism_rtl::Turn::More(Rc::new(CheckOrphan { g_p0: g_p0xyxy.clone(), st_p1: s1_p6.clone(), i_p2: i_p7.clone() }))
                            }))
                        }) as Rc<dyn Fn((crate::check::types::St, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_4037: crate::check::types::St| {
                        let s2_p5 = fold_4037;
                        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&impls_p4)), s2_p5.clone(), {
                            let impls_p4x = impls_p4.clone();
                            let g_p0xyx = g_p0xy.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                let impls_p4xy = impls_p4x.clone();
                                let g_p0xyxy = g_p0xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s3_p8 = p0;
                                    let a_p9 = p1;
                                    crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&impls_p4xy)), s3_p8.clone(), {
                                        let a_p9x = a_p9.clone();
                                        let g_p0xyxyx = g_p0xyxy.clone();
                                        let impls_p4xyx = impls_p4xy.clone();
                                        Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                            let a_p9xy = a_p9x.clone();
                                            let g_p0xyxyxy = g_p0xyxyx.clone();
                                            let impls_p4xyxy = impls_p4xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let s4_pa = p0;
                                                let b_pb = p1;
                                                if &a_p9xy < &b_pb {
                                                    prism_rtl::Turn::More(Rc::new(CheckPair { g_p0: g_p0xyxyxy.clone(), st_p1: s4_pa.clone(), a_p2: crate::prelude::or(&crate::prelude::index(&impls_p4xyxy, &a_p9xy), &dummy_impl_p()), b_p3: crate::prelude::or(&crate::prelude::index(&impls_p4xyxy, &b_pb), &dummy_impl_p()) }))
                                                } else {
                                                    prism_rtl::Turn::Finished(s4_pa.clone())
                                                }
                                            }))
                                        }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                                    }).cycle()
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle()
                    })
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `Coherence`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Coherence: unbounded fn G, St -> St
/// ```
pub struct Coherence {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for Coherence {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        crate::prelude::fold_job(crate::prelude::keys(&g_p0.impls_p), st_p1.clone(), {
            let g_p0x = g_p0.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
                let g_p0xy = g_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p2 = p0;
                    let cls_p3 = p1;
                    {
                        let impls_p4 = crate::prelude::or(&crate::prelude::get(&g_p0xy.impls_p, &cls_p3), &Array::new());
                        crate::prelude::call_value(crate::prelude::fold_job(impls_p4.clone(), s_p2.clone(), {
                            let g_p0xyx = g_p0xy.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::ImplInfo)| {
                                let g_p0xyxy = g_p0xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s1_p6 = p0;
                                    let i_p7 = p1;
                                    prism_rtl::Turn::More(Rc::new(CheckOrphan { g_p0: g_p0xyxy.clone(), st_p1: s1_p6.clone(), i_p2: i_p7.clone() }))
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }), move |fold_4037: crate::check::types::St| {
                            let s2_p5 = fold_4037;
                            crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&impls_p4)), s2_p5.clone(), {
                                let impls_p4x = impls_p4.clone();
                                let g_p0xyx = g_p0xy.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                    let impls_p4xy = impls_p4x.clone();
                                    let g_p0xyxy = g_p0xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let s3_p8 = p0;
                                        let a_p9 = p1;
                                        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&impls_p4xy)), s3_p8.clone(), {
                                            let a_p9x = a_p9.clone();
                                            let g_p0xyxyx = g_p0xyxy.clone();
                                            let impls_p4xyx = impls_p4xy.clone();
                                            Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                                let a_p9xy = a_p9x.clone();
                                                let g_p0xyxyxy = g_p0xyxyx.clone();
                                                let impls_p4xyxy = impls_p4xyx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let s4_pa = p0;
                                                    let b_pb = p1;
                                                    if &a_p9xy < &b_pb {
                                                        prism_rtl::Turn::More(Rc::new(CheckPair { g_p0: g_p0xyxyxy.clone(), st_p1: s4_pa.clone(), a_p2: crate::prelude::or(&crate::prelude::index(&impls_p4xyxy, &a_p9xy), &dummy_impl_p()), b_p3: crate::prelude::or(&crate::prelude::index(&impls_p4xyxy, &b_pb), &dummy_impl_p()) }))
                                                    } else {
                                                        prism_rtl::Turn::Finished(s4_pa.clone())
                                                    }
                                                }))
                                            }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                                        }).cycle()
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }).cycle()
                        })
                    }
                }))
            }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start Coherence, x`: what the function value is when passed to `@Run`.
pub fn start_coherence_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Coherence { g_p0, st_p1 })
}

/// ```prism
/// let dummyImpl
/// ```
pub fn dummy_impl_p() -> crate::check::env::ImplInfo {
    crate::check::env::ImplInfo { cls_p: Text::lit(""), head_p: crate::check::types::Ty::TyErr, qs_p: Array::new(), bounds_p: Array::new(), home_p: Text::lit(""), file_p: Nat::from(0u32), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) }, derived_p: false, assocs_p: Array::new(), methods_p: Array::new() }
}

/// ```prism
/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub fn check_pair_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, a_p2: &crate::check::env::ImplInfo, b_p3: &crate::check::env::ImplInfo) -> crate::check::types::St {
    if !heads_may_meet_f(&a_p2.head_p, &b_p3.head_p) {
        st_p1.clone()
    } else {
        if (&a_p2.file_p < &b_p3.file_p) || ((&a_p2.file_p == &b_p3.file_p) && (&a_p2.span_p.start_p <= &b_p3.span_p.start_p)) {
            check_pair_in_f(g_p0, st_p1, a_p2, b_p3)
        } else {
            check_pair_in_f(g_p0, st_p1, b_p3, a_p2)
        }
    }
}

/// The step machine of `CheckPair`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub struct CheckPair {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub a_p2: crate::check::env::ImplInfo,
    pub b_p3: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckPair {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let a_p2 = &self.a_p2;
        let b_p3 = &self.b_p3;
        if !heads_may_meet_f(&a_p2.head_p, &b_p3.head_p) {
            prism_rtl::Turn::Finished(st_p1.clone())
        } else {
            if (&a_p2.file_p < &b_p3.file_p) || ((&a_p2.file_p == &b_p3.file_p) && (&a_p2.span_p.start_p <= &b_p3.span_p.start_p)) {
                prism_rtl::Turn::More(Rc::new(CheckPairIn { g_p0: g_p0.clone(), st_p1: st_p1.clone(), a_p2: a_p2.clone(), b_p3: b_p3.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(CheckPairIn { g_p0: g_p0.clone(), st_p1: st_p1.clone(), a_p2: b_p3.clone(), b_p3: a_p2.clone() }))
            }
        }
    }
}

/// `Start CheckPair, x`: what the function value is when passed to `@Run`.
pub fn start_check_pair_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, a_p2: crate::check::env::ImplInfo, b_p3: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckPair { g_p0, st_p1, a_p2, b_p3 })
}

/// ```prism
/// HeadsMayMeet: fn Ty, Ty -> Bool
/// ```
pub fn heads_may_meet_f(ty0: &crate::check::types::Ty, ty1: &crate::check::types::Ty) -> bool {
    match (ty0, ty1) {
        (crate::check::types::Ty::TyCon(x_p0, _), crate::check::types::Ty::TyCon(y_p1, _)) => x_p0 == y_p1,
        (_, _) => true,
    }
}

/// ```prism
/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub fn check_pair_in_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, a_p2: &crate::check::env::ImplInfo, b_p3: &crate::check::env::ImplInfo) -> crate::check::types::St {
    let s0_p4 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.file_p = b_p3.file_p.clone();
        this
    };
    let (ta_p5, s1_p6) = crate::check::types::schemes::instantiate_f(&s0_p4, &crate::check::types::Scheme { qs_p: a_p2.qs_p.clone(), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: a_p2.head_p.clone() }, &b_p3.span_p);
    let (tb_p7, s2_p8) = crate::check::types::schemes::instantiate_f(&s1_p6, &crate::check::types::Scheme { qs_p: b_p3.qs_p.clone(), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: b_p3.head_p.clone() }, &b_p3.span_p);
    let (ok_p9, s3_pa) = crate::check::types::unify::try_unify_f(&s2_p8, &ta_p5, &tb_p7, &b_p3.span_p);
    if !ok_p9 {
        st_p1.clone()
    } else {
        {
            let same_pb = ((&crate::prelude::len(&a_p2.qs_p) == &Nat::from(0u32)) && (&crate::prelude::len(&b_p3.qs_p) == &Nat::from(0u32))) || (&shape_of_f(&a_p2.head_p) == &shape_of_f(&b_p3.head_p));
            let code_pc = if same_pb { Text::lit("impl-duplicate") } else { Text::lit("impl-overlap") };
            let first_at_pd = crate::check::errors::src_place_f(&crate::prelude::or(&crate::prelude::index(&g_p0.srcs_p, &a_p2.file_p), &crate::check::errors::mk_src_f(&Text::lit("?"), &Text::lit(""))), &a_p2.span_p.start_p);
            crate::check::types::recording::err_fix_f(&s0_p4, &code_pc, &b_p3.span_p, &Text::from(format!("a second impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&a_p2.cls_p), &crate::check::types::show_ty_f(&s0_p4, &b_p3.head_p))), &Text::from(format!("the first is at {}; keep one", &first_at_pd)))
        }
    }
}

/// The step machine of `CheckPairIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
/// ```
pub struct CheckPairIn {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub a_p2: crate::check::env::ImplInfo,
    pub b_p3: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckPairIn {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let a_p2 = &self.a_p2;
        let b_p3 = &self.b_p3;
        let s0_p4 = {
            let mut this: crate::check::types::St = st_p1.clone();
            this.file_p = b_p3.file_p.clone();
            this
        };
        let a_p2x = a_p2.clone();
        let b_p3x = b_p3.clone();
        let g_p0x = g_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::schemes::start_instantiate_f(s0_p4.clone(), crate::check::types::Scheme { qs_p: a_p2x.qs_p.clone(), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: a_p2x.head_p.clone() }, b_p3x.span_p.clone()), move |instantiate_f_5054: (crate::check::types::Ty, crate::check::types::St)| {
            let (ta_p5, s1_p6) = instantiate_f_5054;
            crate::prelude::call_then(crate::check::types::schemes::start_instantiate_f(s1_p6.clone(), crate::check::types::Scheme { qs_p: b_p3x.qs_p.clone(), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: b_p3x.head_p.clone() }, b_p3x.span_p.clone()), move |instantiate_f_5188: (crate::check::types::Ty, crate::check::types::St)| {
                let (tb_p7, s2_p8) = instantiate_f_5188;
                crate::prelude::call_then(crate::check::types::unify::start_try_unify_f(s2_p8.clone(), ta_p5.clone(), tb_p7.clone(), b_p3x.span_p.clone()), move |try_unify_f_5322: (bool, crate::check::types::St)| {
                    let (ok_p9, s3_pa) = try_unify_f_5322;
                    if !ok_p9 {
                        prism_rtl::Turn::Finished(st_p1x.clone())
                    } else {
                        {
                            let same_pb = ((&crate::prelude::len(&a_p2x.qs_p) == &Nat::from(0u32)) && (&crate::prelude::len(&b_p3x.qs_p) == &Nat::from(0u32))) || (&shape_of_f(&a_p2x.head_p) == &shape_of_f(&b_p3x.head_p));
                            let code_pc = if same_pb { Text::lit("impl-duplicate") } else { Text::lit("impl-overlap") };
                            let first_at_pd = crate::check::errors::src_place_f(&crate::prelude::or(&crate::prelude::index(&g_p0x.srcs_p, &a_p2x.file_p), &crate::check::errors::mk_src_f(&Text::lit("?"), &Text::lit(""))), &a_p2x.span_p.start_p);
                            crate::prelude::call_then(crate::check::types::start_show_ty_f(s0_p4.clone(), b_p3x.head_p.clone()), move |show_ty_f_5698: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s0_p4, &code_pc, &b_p3x.span_p, &Text::from(format!("a second impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&a_p2x.cls_p), &show_ty_f_5698)), &Text::from(format!("the first is at {}; keep one", &first_at_pd)))))
                        }
                    }
                })
            })
        })
    }
}

/// `Start CheckPairIn, x`: what the function value is when passed to `@Run`.
pub fn start_check_pair_in_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, a_p2: crate::check::env::ImplInfo, b_p3: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckPairIn { g_p0, st_p1, a_p2, b_p3 })
}

/// ```prism
/// ShapeOf: unbounded fn Ty -> Text
/// ```
pub fn shape_of_f(t_p0: &crate::check::types::Ty) -> Text {
    match t_p0 {
        crate::check::types::Ty::TyQ(_) => Text::lit("_"),
        crate::check::types::Ty::TyCon(n_p1, args_p2) => Text::from(format!("{}({})", n_p1, &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(args_p2.clone(), Rc::new(|a0: crate::check::types::Ty| crate::prelude::entered(start_shape_of_f(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(",")))),
        crate::check::types::Ty::TyTuple(ts_p3) => Text::from(format!("(({}))", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ts_p3.clone(), Rc::new(|a0: crate::check::types::Ty| crate::prelude::entered(start_shape_of_f(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(",")))),
        crate::check::types::Ty::TyArray(e_p4) => Text::from(format!("[{}]", &shape_of_f(&**e_p4))),
        crate::check::types::Ty::TyMap(k_p5, v_p6) => Text::from(format!("{}==>{}", &shape_of_f(&**k_p5), &shape_of_f(&**v_p6))),
        crate::check::types::Ty::TySig(s_p7, i_p8) => Text::from(format!("{}{}", s_p7, &shape_of_f(&**i_p8))),
        _ => Text::lit("?"),
    }
}

/// The step machine of `ShapeOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShapeOf: unbounded fn Ty -> Text
/// ```
pub struct ShapeOf {
    pub t_p0: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for ShapeOf {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyQ(_) => prism_rtl::Turn::Finished(Text::lit("_")),
            crate::check::types::Ty::TyCon(n_p1, args_p2) => {
                let args_p2x = args_p2.clone();
                let n_p1x = n_p1.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p2x.clone(), Rc::new(|a0: crate::check::types::Ty| crate::prelude::entered(start_shape_of_f(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5940: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &n_p1x, &crate::syntax::lexer::chars::join_f(&each_5940, &Text::lit(","))))))
            },
            crate::check::types::Ty::TyTuple(ts_p3) => {
                let ts_p3x = ts_p3.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_p3x.clone(), Rc::new(|a0: crate::check::types::Ty| crate::prelude::entered(start_shape_of_f(a0))) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5994: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("(({}))", &crate::syntax::lexer::chars::join_f(&each_5994, &Text::lit(","))))))
            },
            crate::check::types::Ty::TyArray(e_p4) => {
                let e_p4x = (**e_p4).clone();
                crate::prelude::call_then(start_shape_of_f(e_p4x.clone()), move |shape_of_f_6039: Text| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &shape_of_f_6039))))
            },
            crate::check::types::Ty::TyMap(k_p5, v_p6) => {
                let k_p5x = (**k_p5).clone();
                let v_p6x = (**v_p6).clone();
                crate::prelude::call_then(start_shape_of_f(k_p5x.clone()), move |shape_of_f_6070: Text| crate::prelude::call_then(start_shape_of_f(v_p6x.clone()), move |shape_of_f_6084: Text| prism_rtl::Turn::Finished(Text::from(format!("{}==>{}", &shape_of_f_6070, &shape_of_f_6084)))))
            },
            crate::check::types::Ty::TySig(s_p7, i_p8) => {
                let i_p8x = (**i_p8).clone();
                let s_p7x = s_p7.clone();
                crate::prelude::call_then(start_shape_of_f(i_p8x.clone()), move |shape_of_f_6117: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &s_p7x, &shape_of_f_6117))))
            },
            _ => prism_rtl::Turn::Finished(Text::lit("?")),
        }
    }
}

/// `Start ShapeOf, x`: what the function value is when passed to `@Run`.
pub fn start_shape_of_f(t_p0: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShapeOf { t_p0 })
}

/// ```prism
/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
/// ```
pub fn check_orphan_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, i_p2: &crate::check::env::ImplInfo) -> crate::check::types::St {
    let trait_mod_p3 = crate::prelude::or(&crate::prelude::get(&g_p0.traits_p, &i_p2.cls_p), &dummy_trait_p()).home_p.clone();
    let owners_p4 = crate::prelude::each(&type_names_in_f(&i_p2.head_p), &(|n_p5: &Text| crate::prelude::or(&crate::prelude::get(&g_p0.types_p, n_p5), &crate::check::env::names::dummy_ty_info_p()).home_p.clone()));
    if (i_p2.derived_p || (&i_p2.home_p == &trait_mod_p3)) || crate::check::types::has_text_f(&owners_p4, &i_p2.home_p) {
        st_p1.clone()
    } else {
        {
            let s_p6 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file_p = i_p2.file_p.clone();
                this
            };
            crate::check::types::recording::err_fix_f(&s_p6, &Text::lit("orphan"), &i_p2.span_p, &Text::from(format!("{} declares neither `^{}` nor `{}`", &(if &i_p2.home_p == &Text::lit("") {
                Text::lit("this file")
            } else {
                Text::from(format!("`{}`", &i_p2.home_p))
            }), &crate::check::types::bare_name_f(&i_p2.cls_p), &crate::check::types::show_ty_f(&s_p6, &i_p2.head_p))), &Text::lit("wrap the type in a newtype of this module, or move the impl"))
        }
    }
}

/// The step machine of `CheckOrphan`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
/// ```
pub struct CheckOrphan {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub i_p2: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckOrphan {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let i_p2 = &self.i_p2;
        let trait_mod_p3 = crate::prelude::or(&crate::prelude::get(&g_p0.traits_p, &i_p2.cls_p), &dummy_trait_p()).home_p.clone();
        let g_p0x = g_p0.clone();
        let i_p2x = i_p2.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_type_names_in_f(i_p2x.head_p.clone()), move |type_names_in_f_6430: Array<Text>| {
            let owners_p4 = crate::prelude::each(&type_names_in_f_6430, &(|n_p5: &Text| crate::prelude::or(&crate::prelude::get(&g_p0x.types_p, n_p5), &crate::check::env::names::dummy_ty_info_p()).home_p.clone()));
            if (i_p2x.derived_p || (&i_p2x.home_p == &trait_mod_p3)) || crate::check::types::has_text_f(&owners_p4, &i_p2x.home_p) {
                prism_rtl::Turn::Finished(st_p1x.clone())
            } else {
                {
                    let s_p6 = {
                        let mut this: crate::check::types::St = st_p1x.clone();
                        this.file_p = i_p2x.file_p.clone();
                        this
                    };
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(s_p6.clone(), i_p2x.head_p.clone()), move |show_ty_f_6756: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s_p6, &Text::lit("orphan"), &i_p2x.span_p, &Text::from(format!("{} declares neither `^{}` nor `{}`", &(if &i_p2x.home_p == &Text::lit("") {
                        Text::lit("this file")
                    } else {
                        Text::from(format!("`{}`", &i_p2x.home_p))
                    }), &crate::check::types::bare_name_f(&i_p2x.cls_p), &show_ty_f_6756)), &Text::lit("wrap the type in a newtype of this module, or move the impl"))))
                }
            }
        })
    }
}

/// `Start CheckOrphan, x`: what the function value is when passed to `@Run`.
pub fn start_check_orphan_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, i_p2: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckOrphan { g_p0, st_p1, i_p2 })
}

/// ```prism
/// let dummyTrait
/// ```
pub fn dummy_trait_p() -> crate::check::env::TraitInfo {
    crate::check::env::TraitInfo { name_p: Text::lit(""), home_p: Text::lit(""), param_p: Text::lit("a"), supers_p: Array::new(), methods_p: Array::new(), defaults_p: Array::new(), assocs_p: Array::new(), file_p: Nat::from(0u32), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }
}

/// ```prism
/// TypeNamesIn: unbounded fn Ty -> [Text]
/// ```
pub fn type_names_in_f(t_p0: &crate::check::types::Ty) -> Array<Text> {
    match t_p0 {
        crate::check::types::Ty::TyCon(n_p1, args_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p2.clone(), Array::from(vec![n_p1.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let a_p4 = p1;
            crate::prelude::call_then(start_type_names_in_f(a_p4.clone()), move |type_names_in_f_7119: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &type_names_in_f_7119)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyTuple(ts_p5) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p6 = p0;
            let a_p7 = p1;
            crate::prelude::call_then(start_type_names_in_f(a_p7.clone()), move |type_names_in_f_7192: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p6, &type_names_in_f_7192)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyArray(e_p8) => type_names_in_f(&**e_p8),
        crate::check::types::Ty::TyMap(k_p9, v_pa) => crate::check::types::union_texts_f(&type_names_in_f(&**k_p9), &type_names_in_f(&**v_pa)),
        crate::check::types::Ty::TySig(_, i_pb) => type_names_in_f(&**i_pb),
        crate::check::types::Ty::TyFn(_, ps_pc, r_pd) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pc.clone(), type_names_in_f(&**r_pd), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pe = p0;
            let a_pf = p1;
            crate::prelude::call_then(start_type_names_in_f(a_pf.clone()), move |type_names_in_f_7408: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pe, &type_names_in_f_7408)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        _ => Array::new(),
    }
}

/// The step machine of `TypeNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeNamesIn: unbounded fn Ty -> [Text]
/// ```
pub struct TypeNamesIn {
    pub t_p0: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Text>> for TypeNamesIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyCon(n_p1, args_p2) => crate::prelude::fold_job(args_p2.clone(), Array::from(vec![n_p1.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let a_p4 = p1;
                crate::prelude::call_then(start_type_names_in_f(a_p4.clone()), move |type_names_in_f_7119: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &type_names_in_f_7119)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyTuple(ts_p5) => crate::prelude::fold_job(ts_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let a_p7 = p1;
                crate::prelude::call_then(start_type_names_in_f(a_p7.clone()), move |type_names_in_f_7192: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p6, &type_names_in_f_7192)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyArray(e_p8) => prism_rtl::Turn::More(Rc::new(TypeNamesIn { t_p0: (**e_p8).clone() })),
            crate::check::types::Ty::TyMap(k_p9, v_pa) => {
                let k_p9x = (**k_p9).clone();
                let v_pax = (**v_pa).clone();
                crate::prelude::call_then(start_type_names_in_f(k_p9x.clone()), move |type_names_in_f_7264: Array<Text>| crate::prelude::call_then(start_type_names_in_f(v_pax.clone()), move |type_names_in_f_7281: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&type_names_in_f_7264, &type_names_in_f_7281))))
            },
            crate::check::types::Ty::TySig(_, i_pb) => prism_rtl::Turn::More(Rc::new(TypeNamesIn { t_p0: (**i_pb).clone() })),
            crate::check::types::Ty::TyFn(_, ps_pc, r_pd) => {
                let ps_pcx = ps_pc.clone();
                let r_pdx = (**r_pd).clone();
                crate::prelude::call_then(start_type_names_in_f(r_pdx.clone()), move |type_names_in_f_7365: Array<Text>| crate::prelude::fold_job(ps_pcx.clone(), type_names_in_f_7365, Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pe = p0;
                    let a_pf = p1;
                    crate::prelude::call_then(start_type_names_in_f(a_pf.clone()), move |type_names_in_f_7408: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pe, &type_names_in_f_7408)))
                }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start TypeNamesIn, x`: what the function value is when passed to `@Run`.
pub fn start_type_names_in_f(t_p0: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TypeNamesIn { t_p0 })
}

/// ```prism
/// SuperClosure: unbounded fn G, Text -> [Text]
/// ```
pub fn super_closure_f(g_p0: &crate::check::env::G, cls_p1: &Text) -> Array<Text> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&g_p0.traits_p, cls_p1), &dummy_trait_p()).supers_p.clone(), Array::from(vec![cls_p1.clone()]), {
        let g_p0x = g_p0.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p2 = p0;
                let s_p3 = p1;
                crate::prelude::call_then(start_super_closure_f(g_p0xy.clone(), s_p3.clone()), move |super_closure_f_7866: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p2, &super_closure_f_7866)))
            }))
        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `SuperClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SuperClosure: unbounded fn G, Text -> [Text]
/// ```
pub struct SuperClosure {
    pub g_p0: crate::check::env::G,
    pub cls_p1: Text,
}

impl prism_rtl::Job<Array<Text>> for SuperClosure {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let g_p0 = &self.g_p0;
        let cls_p1 = &self.cls_p1;
        crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&g_p0.traits_p, cls_p1), &dummy_trait_p()).supers_p.clone(), Array::from(vec![cls_p1.clone()]), {
            let g_p0x = g_p0.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                let g_p0xy = g_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p2 = p0;
                    let s_p3 = p1;
                    crate::prelude::call_then(start_super_closure_f(g_p0xy.clone(), s_p3.clone()), move |super_closure_f_7866: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p2, &super_closure_f_7866)))
                }))
            }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start SuperClosure, x`: what the function value is when passed to `@Run`.
pub fn start_super_closure_f(g_p0: crate::check::env::G, cls_p1: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SuperClosure { g_p0, cls_p1 })
}

/// ```prism
/// WithFile: fn St, Nat -> St
/// ```
pub fn with_file_f(s_p0: &crate::check::types::St, f_p1: &Nat) -> crate::check::types::St {
    let mut this: crate::check::types::St = s_p0.clone();
    this.file_p = f_p1.clone();
    this
}

/// ```prism
/// BuiltinHas: fn Text, Text -> Bool
/// ```
pub fn builtin_has_f(cls_p0: &Text, con_p1: &Text) -> bool {
    let bare_p2 = crate::check::types::bare_name_f(cls_p0);
    if &bare_p2 == &Text::lit("Num") {
        (((con_p1 == &Text::lit("Nat")) || (con_p1 == &Text::lit("Int"))) || (con_p1 == &Text::lit("U8"))) || (con_p1 == &Text::lit("Float"))
    } else {
        if (&bare_p2 == &Text::lit("Eq")) || (&bare_p2 == &Text::lit("Show")) {
            (crate::check::env::is_prim_type_f(con_p1) || (con_p1 == &Text::lit("Fault"))) || (con_p1 == &Text::lit("Prelude.Fault"))
        } else {
            if &bare_p2 == &Text::lit("Ord") {
                ((crate::check::env::is_prim_type_f(con_p1) && !crate::check::env::is_regex_type_f(con_p1)) || (con_p1 == &Text::lit("Fault"))) || (con_p1 == &Text::lit("Prelude.Fault"))
            } else {
                false
            }
        }
    }
}

/// ```prism
/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
/// ```
pub fn solve_wants_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, givens_p2: &Array<(Text, Text)>, final_p3: &bool) -> crate::check::types::St {
    let s4_p4 = solve_rounds_f(g_p0, st_p1, givens_p2, &Nat::from(0u32));
    if *final_p3 { default_wants_f(g_p0, &s4_p4, givens_p2) } else { s4_p4.clone() }
}

/// The step machine of `SolveWants`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
/// ```
pub struct SolveWants {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub givens_p2: Array<(Text, Text)>,
    pub final_p3: bool,
}

impl prism_rtl::Job<crate::check::types::St> for SolveWants {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let givens_p2 = &self.givens_p2;
        let final_p3 = &self.final_p3;
        let final_p3x = *final_p3;
        let g_p0x = g_p0.clone();
        let givens_p2x = givens_p2.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_solve_rounds_f(g_p0x.clone(), st_p1x.clone(), givens_p2x.clone(), Nat::from(0u32)), move |solve_rounds_f_9008: crate::check::types::St| {
            let s4_p4 = solve_rounds_f_9008;
            if final_p3x {
                prism_rtl::Turn::More(Rc::new(DefaultWants { g_p0: g_p0x.clone(), st_p1: s4_p4.clone(), givens_p2: givens_p2x.clone() }))
            } else {
                prism_rtl::Turn::Finished(s4_p4.clone())
            }
        })
    }
}

/// `Start SolveWants, x`: what the function value is when passed to `@Run`.
pub fn start_solve_wants_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, givens_p2: Array<(Text, Text)>, final_p3: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SolveWants { g_p0, st_p1, givens_p2, final_p3 })
}

/// ```prism
/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
/// ```
pub fn solve_rounds_f(g_p0: &crate::check::env::G, st0_p1: &crate::check::types::St, givens_p2: &Array<(Text, Text)>, round_p3: &Nat) -> crate::check::types::St {
    let st_p4 = resolve_fields_f(g_p0, &crate::check::types::unify::retry_deferred_f(st0_p1), &false);
    let cleared_p5 = {
        let mut this: crate::check::types::St = st_p4.clone();
        this.wants_p = Array::new();
        this
    };
    let (keep_pc, s2_pd) = crate::prelude::run_to_end(crate::prelude::fold_job(st_p4.wants_p.clone(), (Array::new(), cleared_p5.clone()), {
        let g_p0x = g_p0.clone();
        let givens_p2x = givens_p2.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)| {
            let g_p0xy = g_p0x.clone();
            let givens_p2xy = givens_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p7, s_p8) = p0;
                let w_p9 = p1;
                crate::prelude::call_then(start_solve_one_f(g_p0xy.clone(), s_p8.clone(), givens_p2xy.clone(), w_p9.clone()), move |solve_one_f_9525: (Array<crate::check::types::Want>, crate::check::types::St)| {
                    let (left_pa, s3_pb) = solve_one_f_9525;
                    prism_rtl::Turn::Finished((crate::prelude::append(&acc_p7, &left_pa), s3_pb.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>>>
    }));
    let s4_p6 = {
        let mut this: crate::check::types::St = s2_pd.clone();
        this.wants_p = crate::prelude::append(&keep_pc, &this.wants_p);
        this
    };
    if (&s4_p6.wants_p == &st_p4.wants_p) || (round_p3 > &Nat::from(6u32)) {
        s4_p6.clone()
    } else {
        solve_rounds_f(g_p0, &s4_p6, givens_p2, &(round_p3 + &Nat::from(1u32)))
    }
}

/// The step machine of `SolveRounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
/// ```
pub struct SolveRounds {
    pub g_p0: crate::check::env::G,
    pub st0_p1: crate::check::types::St,
    pub givens_p2: Array<(Text, Text)>,
    pub round_p3: Nat,
}

impl prism_rtl::Job<crate::check::types::St> for SolveRounds {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st0_p1 = &self.st0_p1;
        let givens_p2 = &self.givens_p2;
        let round_p3 = &self.round_p3;
        let g_p0x = g_p0.clone();
        let givens_p2x = givens_p2.clone();
        let round_p3x = round_p3.clone();
        let st0_p1x = st0_p1.clone();
        crate::prelude::call_then(crate::check::types::unify::start_retry_deferred_f(st0_p1x.clone()), move |retry_deferred_f_9344: crate::check::types::St| crate::prelude::call_then(start_resolve_fields_f(g_p0x.clone(), retry_deferred_f_9344, false), move |resolve_fields_f_9326: crate::check::types::St| {
            let st_p4 = resolve_fields_f_9326;
            let cleared_p5 = {
                let mut this: crate::check::types::St = st_p4.clone();
                this.wants_p = Array::new();
                this
            };
            crate::prelude::call_value(crate::prelude::fold_job(st_p4.wants_p.clone(), (Array::new(), cleared_p5.clone()), {
                let g_p0xx = g_p0x.clone();
                let givens_p2xx = givens_p2x.clone();
                Rc::new(move |(p0, p1): ((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)| {
                    let g_p0xxy = g_p0xx.clone();
                    let givens_p2xxy = givens_p2xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (acc_p7, s_p8) = p0;
                        let w_p9 = p1;
                        crate::prelude::call_then(start_solve_one_f(g_p0xxy.clone(), s_p8.clone(), givens_p2xxy.clone(), w_p9.clone()), move |solve_one_f_9525: (Array<crate::check::types::Want>, crate::check::types::St)| {
                            let (left_pa, s3_pb) = solve_one_f_9525;
                            prism_rtl::Turn::Finished((crate::prelude::append(&acc_p7, &left_pa), s3_pb.clone()))
                        })
                    }))
                }) as Rc<dyn Fn(((Array<crate::check::types::Want>, crate::check::types::St), crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>>>
            }), move |fold_9447: (Array<crate::check::types::Want>, crate::check::types::St)| {
                let (keep_pc, s2_pd) = fold_9447;
                let s4_p6 = {
                    let mut this: crate::check::types::St = s2_pd.clone();
                    this.wants_p = crate::prelude::append(&keep_pc, &this.wants_p);
                    this
                };
                if (&s4_p6.wants_p == &st_p4.wants_p) || (&round_p3x > &Nat::from(6u32)) {
                    prism_rtl::Turn::Finished(s4_p6.clone())
                } else {
                    prism_rtl::Turn::More(Rc::new(SolveRounds { g_p0: g_p0x.clone(), st0_p1: s4_p6.clone(), givens_p2: givens_p2x.clone(), round_p3: &round_p3x + &Nat::from(1u32) }))
                }
            })
        }))
    }
}

/// `Start SolveRounds, x`: what the function value is when passed to `@Run`.
pub fn start_solve_rounds_f(g_p0: crate::check::env::G, st0_p1: crate::check::types::St, givens_p2: Array<(Text, Text)>, round_p3: Nat) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SolveRounds { g_p0, st0_p1, givens_p2, round_p3 })
}

/// ```prism
/// ResolveFields: unbounded fn G, St, Bool -> St
/// ```
pub fn resolve_fields_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, final_p2: &bool) -> crate::check::types::St {
    let qs_p3 = st_p1.field_qs_p.clone();
    let cleared_p4 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.field_qs_p = Array::new();
        this
    };
    let done_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(qs_p3.clone(), cleared_p4.clone(), {
        let g_p0x = g_p0.clone();
        let final_p2x = *final_p2;
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::unify::FieldQ)| {
            let g_p0xy = g_p0x.clone();
            let final_p2xy = final_p2x;
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p6 = p0;
                let q_p7 = p1;
                prism_rtl::Turn::More(Rc::new(ResolveField { g_p0: g_p0xy.clone(), st_p1: s_p6.clone(), q_p2: q_p7.clone(), final_p3: final_p2xy }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::unify::FieldQ)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    with_file_f(&done_p5, &st_p1.file_p)
}

/// The step machine of `ResolveFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveFields: unbounded fn G, St, Bool -> St
/// ```
pub struct ResolveFields {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub final_p2: bool,
}

impl prism_rtl::Job<crate::check::types::St> for ResolveFields {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let final_p2 = &self.final_p2;
        let qs_p3 = st_p1.field_qs_p.clone();
        let cleared_p4 = {
            let mut this: crate::check::types::St = st_p1.clone();
            this.field_qs_p = Array::new();
            this
        };
        let final_p2x = *final_p2;
        let g_p0x = g_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(qs_p3.clone(), cleared_p4.clone(), {
            let g_p0xx = g_p0x.clone();
            let final_p2xx = final_p2x;
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::unify::FieldQ)| {
                let g_p0xxy = g_p0xx.clone();
                let final_p2xxy = final_p2xx;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p6 = p0;
                    let q_p7 = p1;
                    prism_rtl::Turn::More(Rc::new(ResolveField { g_p0: g_p0xxy.clone(), st_p1: s_p6.clone(), q_p2: q_p7.clone(), final_p3: final_p2xxy }))
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::check::types::unify::FieldQ)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }), move |fold_10049: crate::check::types::St| {
            let done_p5 = fold_10049;
            prism_rtl::Turn::Finished(with_file_f(&done_p5, &st_p1x.file_p))
        })
    }
}

/// `Start ResolveFields, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_fields_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, final_p2: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ResolveFields { g_p0, st_p1, final_p2 })
}

/// ```prism
/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
/// ```
pub fn resolve_field_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, q_p2: &crate::check::types::unify::FieldQ, final_p3: &bool) -> crate::check::types::St {
    let s_p4 = with_file_f(st_p1, &q_p2.file_p);
    match crate::check::types::recording::walk_f(&s_p4, &q_p2.recv_p) {
        crate::check::types::Ty::TyCon(n_p5, args_p6) => match crate::prelude::get(&g_p0.ctors_p, &n_p5) {
            Some(c_p7) => {
                let i_o8 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p7.fields_p)), &None, &(|at_o9: &Option<Nat>, k_pa: &Nat| if &crate::prelude::index(&c_p7.fields_p, k_pa) == &Some(q_p2.field_p.clone()) {
                    Some(k_pa.clone())
                } else {
                    at_o9.clone()
                }));
                match &i_o8 {
                    Some(i_pb) => {
                        let ft_pc = crate::check::types::schemes::subst_q_f(&crate::check::env::reading::param_inst_f(&c_p7.params_p, &args_p6), &crate::prelude::or(&crate::prelude::index(&c_p7.args_p, i_pb), &crate::check::types::Ty::TyErr));
                        field_marks_f(&crate::check::types::unify::unify_f(&s_p4, &q_p2.result_p, &ft_pc, &q_p2.span_p), q_p2, &ft_pc)
                    },
                    None => crate::check::types::recording::err_f(&s_p4, &Text::lit("mismatch"), &q_p2.span_p, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name_f(&n_p5), &q_p2.field_p))),
                }
            },
            None => crate::check::types::recording::err_f(&s_p4, &Text::lit("mismatch"), &q_p2.span_p, &Text::from(format!("`{}` has no fields", &crate::check::types::bare_name_f(&n_p5)))),
        },
        crate::check::types::Ty::TyFlex(_) => if *final_p3 {
            crate::check::types::recording::err_fix_f(&s_p4, &Text::lit("ambiguous"), &q_p2.span_p, &Text::from(format!("nothing decides which record `.{}` reads: {} have it", &q_p2.field_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&q_p2.owners_p, &(|o_pd: &Text| Text::from(format!("`{}`", o_pd)))), &Text::lit(", ")))), &Text::lit("annotate the value\'s type, or name it from a signature"))
        } else {
            {
                let mut this: crate::check::types::St = s_p4.clone();
                this.field_qs_p = crate::prelude::push(&this.field_qs_p, q_p2);
                this
            }
        },
        crate::check::types::Ty::TyErr => s_p4.clone(),
        other_pe => crate::check::types::recording::err_f(&s_p4, &Text::lit("mismatch"), &q_p2.span_p, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::show_ty_f(&s_p4, &other_pe), &q_p2.field_p))),
    }
}

/// The step machine of `ResolveField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
/// ```
pub struct ResolveField {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub q_p2: crate::check::types::unify::FieldQ,
    pub final_p3: bool,
}

impl prism_rtl::Job<crate::check::types::St> for ResolveField {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let q_p2 = &self.q_p2;
        let final_p3 = &self.final_p3;
        let s_p4 = with_file_f(st_p1, &q_p2.file_p);
        let final_p3x = *final_p3;
        let g_p0x = g_p0.clone();
        let q_p2x = q_p2.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p4.clone(), q_p2x.recv_p.clone()), move |walk_f_10259: crate::check::types::Ty| match walk_f_10259 {
            crate::check::types::Ty::TyCon(n_p5, args_p6) => match crate::prelude::get(&g_p0x.ctors_p, &n_p5) {
                Some(c_p7) => {
                    let i_o8 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p7.fields_p)), &None, &(|at_o9: &Option<Nat>, k_pa: &Nat| if &crate::prelude::index(&c_p7.fields_p, k_pa) == &Some(q_p2x.field_p.clone()) {
                        Some(k_pa.clone())
                    } else {
                        at_o9.clone()
                    }));
                    match &i_o8 {
                        Some(i_pb) => {
                            let i_pbx = i_pb.clone();
                            crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(crate::check::env::reading::param_inst_f(&c_p7.params_p, &args_p6), crate::prelude::or(&crate::prelude::index(&c_p7.args_p, &i_pbx), &crate::check::types::Ty::TyErr)), move |subst_q_f_10530: crate::check::types::Ty| {
                                let ft_pc = subst_q_f_10530;
                                crate::prelude::call_then(crate::check::types::unify::start_unify_f(s_p4.clone(), q_p2x.result_p.clone(), ft_pc.clone(), q_p2x.span_p.clone()), move |unify_f_10623: crate::check::types::St| prism_rtl::Turn::More(Rc::new(FieldMarks { st_p0: unify_f_10623, q_p1: q_p2x.clone(), ft_p2: ft_pc.clone() })))
                            })
                        },
                        None => prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_p4, &Text::lit("mismatch"), &q_p2x.span_p, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name_f(&n_p5), &q_p2x.field_p)))),
                    }
                },
                None => prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_p4, &Text::lit("mismatch"), &q_p2x.span_p, &Text::from(format!("`{}` has no fields", &crate::check::types::bare_name_f(&n_p5))))),
            },
            crate::check::types::Ty::TyFlex(_) => if final_p3x {
                prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s_p4, &Text::lit("ambiguous"), &q_p2x.span_p, &Text::from(format!("nothing decides which record `.{}` reads: {} have it", &q_p2x.field_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&q_p2x.owners_p, &(|o_pd: &Text| Text::from(format!("`{}`", o_pd)))), &Text::lit(", ")))), &Text::lit("annotate the value\'s type, or name it from a signature")))
            } else {
                prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = s_p4.clone();
                    this.field_qs_p = crate::prelude::push(&this.field_qs_p, &q_p2x);
                    this
                })
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished(s_p4.clone()),
            other_pe => crate::prelude::call_then(crate::check::types::start_show_ty_f(s_p4.clone(), other_pe.clone()), move |show_ty_f_11205: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_p4, &Text::lit("mismatch"), &q_p2x.span_p, &Text::from(format!("`{}` has no field `{}`", &show_ty_f_11205, &q_p2x.field_p))))),
        })
    }
}

/// `Start ResolveField, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_field_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, q_p2: crate::check::types::unify::FieldQ, final_p3: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ResolveField { g_p0, st_p1, q_p2, final_p3 })
}

/// ```prism
/// FieldMarks: unbounded fn St, FieldQ, Ty -> St
/// ```
pub fn field_marks_f(st_p0: &crate::check::types::St, q_p1: &crate::check::types::unify::FieldQ, ft_p2: &crate::check::types::Ty) -> crate::check::types::St {
    match &q_p1.marks_o {
        Some((sigils_p3, at_p4)) => {
            let stack_p5 = crate::check::types::stack_of_f(st_p0, ft_p2);
            if (&stack_p5 == sigils_p3) || (ft_p2 == &crate::check::types::Ty::TyErr) {
                st_p0.clone()
            } else {
                crate::check::types::recording::err_fix_f(st_p0, &Text::lit("mark-stack"), at_p4, &Text::from(format!("`.{}{}` has type `{}`, whose stack is `{}`; the access shows `{}`", sigils_p3, &q_p1.field_p, &crate::check::types::show_ty_f(st_p0, ft_p2), &stack_p5, sigils_p3)), &Text::from(format!("write `.{}{}`", &stack_p5, &q_p1.field_p)))
            }
        },
        None => st_p0.clone(),
    }
}

/// The step machine of `FieldMarks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldMarks: unbounded fn St, FieldQ, Ty -> St
/// ```
pub struct FieldMarks {
    pub st_p0: crate::check::types::St,
    pub q_p1: crate::check::types::unify::FieldQ,
    pub ft_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for FieldMarks {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let q_p1 = &self.q_p1;
        let ft_p2 = &self.ft_p2;
        match &q_p1.marks_o {
            Some((sigils_p3, at_p4)) => {
                let at_p4x = at_p4.clone();
                let ft_p2x = ft_p2.clone();
                let q_p1x = q_p1.clone();
                let sigils_p3x = sigils_p3.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(crate::check::types::start_stack_of_f(st_p0x.clone(), ft_p2x.clone()), move |stack_of_f_11533: Text| {
                    let stack_p5 = stack_of_f_11533;
                    if (&stack_p5 == &sigils_p3x) || (&ft_p2x == &crate::check::types::Ty::TyErr) {
                        prism_rtl::Turn::Finished(st_p0x.clone())
                    } else {
                        crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p0x.clone(), ft_p2x.clone()), move |show_ty_f_11670: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p0x, &Text::lit("mark-stack"), &at_p4x, &Text::from(format!("`.{}{}` has type `{}`, whose stack is `{}`; the access shows `{}`", &sigils_p3x, &q_p1x.field_p, &show_ty_f_11670, &stack_p5, &sigils_p3x)), &Text::from(format!("write `.{}{}`", &stack_p5, &q_p1x.field_p)))))
                    }
                })
            },
            None => prism_rtl::Turn::Finished(st_p0.clone()),
        }
    }
}

/// `Start FieldMarks, x`: what the function value is when passed to `@Run`.
pub fn start_field_marks_f(st_p0: crate::check::types::St, q_p1: crate::check::types::unify::FieldQ, ft_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(FieldMarks { st_p0, q_p1, ft_p2 })
}

/// ```prism
/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
/// ```
pub fn solve_one_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, givens_p2: &Array<(Text, Text)>, w_p3: &crate::check::types::Want) -> (Array<crate::check::types::Want>, crate::check::types::St) {
    let t_p4 = crate::check::types::recording::walk_f(st_p1, &w_p3.ty_p);
    let s0_p5 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.file_p = w_p3.file_p.clone();
        this
    };
    let restore_f6 = {
        let st_p1x = st_p1.clone();
        Rc::new(move |s_p7: &crate::check::types::St| with_file_f(s_p7, &st_p1x.file_p)) as Rc<dyn Fn(&crate::check::types::St) -> crate::check::types::St>
    };
    match &t_p4 {
        crate::check::types::Ty::TyFlex(_) => (Array::from(vec![w_p3.clone()]), st_p1.clone()),
        crate::check::types::Ty::TyErr => (Array::new(), st_p1.clone()),
        crate::check::types::Ty::TyRigid(v_p8) => if (crate::syntax::lexer::chars::has_prefix_f(&w_p3.cls_p, &Text::lit("Range ")) || (&w_p3.cls_p == &Text::lit("Prelude.Sub"))) || (&w_p3.cls_p == &Text::lit("Prelude.Signed")) {
            (Array::new(), st_p1.clone())
        } else {
            if crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::append(givens_p2, &st_p1.any_givens_p), false, {
                let v_p8x = v_p8.clone();
                let g_p0x = g_p0.clone();
                let w_p3x = w_p3.clone();
                Rc::new(move |(p0, p1): (bool, (Text, Text))| {
                    let v_p8xy = v_p8x.clone();
                    let g_p0xy = g_p0x.clone();
                    let w_p3xy = w_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let seen_p9 = p0;
                        let (gv_pa, gc_pb) = p1;
                        prism_rtl::Turn::Finished(seen_p9 || ((&gv_pa == &v_p8xy) && crate::check::types::has_text_f(&super_closure_f(&g_p0xy, &gc_pb), &w_p3xy.cls_p)))
                    }))
                }) as Rc<dyn Fn((bool, (Text, Text))) -> Rc<dyn prism_rtl::Job<bool>>>
            })) {
                (Array::new(), solved_f(st_p1, w_p3, &t_p4, &Text::lit("given")))
            } else {
                (Array::new(), (&restore_f6)(&crate::check::types::recording::err_fix_f(&s0_p5, &Text::lit("no-impl"), &w_p3.span_p, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&w_p3.cls_p), v_p8)), &Text::from(format!("add `where {}: ^{}` to the signature", v_p8, &crate::check::types::bare_name_f(&w_p3.cls_p))))))
            }
        },
        crate::check::types::Ty::TySig(s_pc, inner_pd) => if ((s_pc == &Text::lit("?")) || (s_pc == &Text::lit("~"))) && crate::check::types::has_text_f(&Array::from(vec![Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")]), &crate::check::types::bare_name_f(&w_p3.cls_p)) {
            (Array::from(vec![crate::check::types::Want { cls_p: w_p3.cls_p.clone(), ty_p: (**inner_pd).clone(), file_p: w_p3.file_p.clone(), span_p: w_p3.span_p.clone(), level_p: w_p3.level_p.clone() }]), solved_f(st_p1, w_p3, &t_p4, &Text::lit("parts")))
        } else {
            (Array::new(), (&restore_f6)(&crate::check::types::recording::err_fix_f(&s0_p5, &Text::lit("no-impl"), &w_p3.span_p, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&w_p3.cls_p), &crate::check::types::show_ty_f(st_p1, &t_p4))), &Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first"))))
        },
        crate::check::types::Ty::TyAt(_, _) => (Array::new(), (&restore_f6)(&crate::check::types::recording::err_f(&s0_p5, &Text::lit("no-impl"), &w_p3.span_p, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&w_p3.cls_p), &crate::check::types::show_ty_f(st_p1, &t_p4)))))),
        crate::check::types::Ty::TyFn(_, _, _) => (Array::new(), (&restore_f6)(&crate::check::types::recording::err_f(&s0_p5, &Text::lit("no-impl"), &w_p3.span_p, &Text::from(format!("no impl of `^{}` for `{}`: functions do not compare or print", &crate::check::types::bare_name_f(&w_p3.cls_p), &crate::check::types::show_ty_f(st_p1, &t_p4)))))),
        _ => solve_at_head_f(g_p0, st_p1, &s0_p5, &{
            let f = restore_f6.clone();
            Rc::new(move |a0: crate::check::types::St| {
                let fy = f.clone();
                crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
            }) as Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }, givens_p2, w_p3, &t_p4),
    }
}

/// The step machine of `SolveOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
/// ```
pub struct SolveOne {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub givens_p2: Array<(Text, Text)>,
    pub w_p3: crate::check::types::Want,
}

impl prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)> for SolveOne {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Want>, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let givens_p2 = &self.givens_p2;
        let w_p3 = &self.w_p3;
        let g_p0x = g_p0.clone();
        let givens_p2x = givens_p2.clone();
        let st_p1x = st_p1.clone();
        let w_p3x = w_p3.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), w_p3x.ty_p.clone()), move |walk_f_11896: crate::check::types::Ty| {
            let t_p4 = walk_f_11896;
            let s0_p5 = {
                let mut this: crate::check::types::St = st_p1x.clone();
                this.file_p = w_p3x.file_p.clone();
                this
            };
            let restore_f6 = {
                let st_p1xx = st_p1x.clone();
                Rc::new(move |s_p7: &crate::check::types::St| with_file_f(s_p7, &st_p1xx.file_p)) as Rc<dyn Fn(&crate::check::types::St) -> crate::check::types::St>
            };
            match &t_p4 {
                crate::check::types::Ty::TyFlex(_) => prism_rtl::Turn::Finished((Array::from(vec![w_p3x.clone()]), st_p1x.clone())),
                crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished((Array::new(), st_p1x.clone())),
                crate::check::types::Ty::TyRigid(v_p8) => if (crate::syntax::lexer::chars::has_prefix_f(&w_p3x.cls_p, &Text::lit("Range ")) || (&w_p3x.cls_p == &Text::lit("Prelude.Sub"))) || (&w_p3x.cls_p == &Text::lit("Prelude.Signed")) {
                    prism_rtl::Turn::Finished((Array::new(), st_p1x.clone()))
                } else {
                    {
                        let v_p8x = v_p8.clone();
                        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::append(&givens_p2x, &st_p1x.any_givens_p), false, {
                            let v_p8xx = v_p8x.clone();
                            let g_p0xx = g_p0x.clone();
                            let w_p3xx = w_p3x.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, Text))| {
                                let v_p8xxy = v_p8xx.clone();
                                let g_p0xxy = g_p0xx.clone();
                                let w_p3xxy = w_p3xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let seen_p9 = p0;
                                    let (gv_pa, gc_pb) = p1;
                                    prism_rtl::Turn::Finished(seen_p9 || ((&gv_pa == &v_p8xxy) && crate::check::types::has_text_f(&super_closure_f(&g_p0xxy, &gc_pb), &w_p3xxy.cls_p)))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, Text))) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |fold_12233: bool| if fold_12233 {
                            prism_rtl::Turn::Finished((Array::new(), solved_f(&st_p1x, &w_p3x, &t_p4, &Text::lit("given"))))
                        } else {
                            prism_rtl::Turn::Finished((Array::new(), (&restore_f6)(&crate::check::types::recording::err_fix_f(&s0_p5, &Text::lit("no-impl"), &w_p3x.span_p, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&w_p3x.cls_p), &v_p8x)), &Text::from(format!("add `where {}: ^{}` to the signature", &v_p8x, &crate::check::types::bare_name_f(&w_p3x.cls_p)))))))
                        })
                    }
                },
                crate::check::types::Ty::TySig(s_pc, inner_pd) => if ((s_pc == &Text::lit("?")) || (s_pc == &Text::lit("~"))) && crate::check::types::has_text_f(&Array::from(vec![Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")]), &crate::check::types::bare_name_f(&w_p3x.cls_p)) {
                    prism_rtl::Turn::Finished((Array::from(vec![crate::check::types::Want { cls_p: w_p3x.cls_p.clone(), ty_p: (**inner_pd).clone(), file_p: w_p3x.file_p.clone(), span_p: w_p3x.span_p.clone(), level_p: w_p3x.level_p.clone() }]), solved_f(&st_p1x, &w_p3x, &t_p4, &Text::lit("parts"))))
                } else {
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p4.clone()), move |show_ty_f_12883: Text| prism_rtl::Turn::Finished((Array::new(), (&restore_f6)(&crate::check::types::recording::err_fix_f(&s0_p5, &Text::lit("no-impl"), &w_p3x.span_p, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&w_p3x.cls_p), &show_ty_f_12883)), &Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first"))))))
                },
                crate::check::types::Ty::TyAt(_, _) => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p4.clone()), move |show_ty_f_13105: Text| prism_rtl::Turn::Finished((Array::new(), (&restore_f6)(&crate::check::types::recording::err_f(&s0_p5, &Text::lit("no-impl"), &w_p3x.span_p, &Text::from(format!("no impl of `^{}` for `{}`", &crate::check::types::bare_name_f(&w_p3x.cls_p), &show_ty_f_13105))))))),
                crate::check::types::Ty::TyFn(_, _, _) => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p4.clone()), move |show_ty_f_13243: Text| prism_rtl::Turn::Finished((Array::new(), (&restore_f6)(&crate::check::types::recording::err_f(&s0_p5, &Text::lit("no-impl"), &w_p3x.span_p, &Text::from(format!("no impl of `^{}` for `{}`: functions do not compare or print", &crate::check::types::bare_name_f(&w_p3x.cls_p), &show_ty_f_13243))))))),
                _ => prism_rtl::Turn::More(Rc::new(SolveAtHead { g_p0: g_p0x.clone(), st_p1: st_p1x.clone(), s0_p2: s0_p5.clone(), restore_f3: {
                    let f = restore_f6.clone();
                    Rc::new(move |a0: crate::check::types::St| {
                        let fy = f.clone();
                        crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
                    }) as Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                }, givens_p4: givens_p2x.clone(), w_p5: w_p3x.clone(), t_p6: t_p4.clone() })),
            }
        })
    }
}

/// `Start SolveOne, x`: what the function value is when passed to `@Run`.
pub fn start_solve_one_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, givens_p2: Array<(Text, Text)>, w_p3: crate::check::types::Want) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>> {
    Rc::new(SolveOne { g_p0, st_p1, givens_p2, w_p3 })
}

/// ```prism
/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub fn solve_at_head_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, s0_p2: &crate::check::types::St, restore_f3: &Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens_p4: &Array<(Text, Text)>, w_p5: &crate::check::types::Want, t_p6: &crate::check::types::Ty) -> (Array<crate::check::types::Want>, crate::check::types::St) {
    if crate::syntax::lexer::chars::has_prefix_f(&w_p5.cls_p, &Text::lit("Range ")) {
        (Array::new(), crate::prelude::run_to_end(restore_f3(literal_range_f(s0_p2, w_p5, t_p6))))
    } else {
        if (&w_p5.cls_p == &Text::lit("Prelude.Sub")) || (&w_p5.cls_p == &Text::lit("Prelude.Signed")) {
            (Array::new(), crate::prelude::run_to_end(restore_f3(signed_at_f(s0_p2, w_p5, t_p6))))
        } else {
            solve_class_f(g_p0, st_p1, s0_p2, &restore_f3.clone(), givens_p4, w_p5, t_p6)
        }
    }
}

/// The step machine of `SolveAtHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub struct SolveAtHead {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub s0_p2: crate::check::types::St,
    pub restore_f3: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>,
    pub givens_p4: Array<(Text, Text)>,
    pub w_p5: crate::check::types::Want,
    pub t_p6: crate::check::types::Ty,
}

impl prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)> for SolveAtHead {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Want>, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let s0_p2 = &self.s0_p2;
        let restore_f3 = &self.restore_f3;
        let givens_p4 = &self.givens_p4;
        let w_p5 = &self.w_p5;
        let t_p6 = &self.t_p6;
        if crate::syntax::lexer::chars::has_prefix_f(&w_p5.cls_p, &Text::lit("Range ")) {
            {
                let restore_f3x = restore_f3.clone();
                let s0_p2x = s0_p2.clone();
                let t_p6x = t_p6.clone();
                let w_p5x = w_p5.clone();
                crate::prelude::call_then(start_literal_range_f(s0_p2x.clone(), w_p5x.clone(), t_p6x.clone()), move |literal_range_f_13561: crate::check::types::St| crate::prelude::call_value((&restore_f3x)(literal_range_f_13561), move |restore_13552: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_13552))))
            }
        } else {
            if (&w_p5.cls_p == &Text::lit("Prelude.Sub")) || (&w_p5.cls_p == &Text::lit("Prelude.Signed")) {
                {
                    let restore_f3x = restore_f3.clone();
                    let s0_p2x = s0_p2.clone();
                    let t_p6x = t_p6.clone();
                    let w_p5x = w_p5.clone();
                    crate::prelude::call_then(start_signed_at_f(s0_p2x.clone(), w_p5x.clone(), t_p6x.clone()), move |signed_at_f_13669: crate::check::types::St| crate::prelude::call_value((&restore_f3x)(signed_at_f_13669), move |restore_13660: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_13660))))
                }
            } else {
                prism_rtl::Turn::More(Rc::new(SolveClass { g_p0: g_p0.clone(), st_p1: st_p1.clone(), s0_p2: s0_p2.clone(), restore_f3: restore_f3.clone(), givens_p4: givens_p4.clone(), w_p5: w_p5.clone(), t_p6: t_p6.clone() }))
            }
        }
    }
}

/// `Start SolveAtHead, x`: what the function value is when passed to `@Run`.
pub fn start_solve_at_head_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, s0_p2: crate::check::types::St, restore_f3: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens_p4: Array<(Text, Text)>, w_p5: crate::check::types::Want, t_p6: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>> {
    Rc::new(SolveAtHead { g_p0, st_p1, s0_p2, restore_f3, givens_p4, w_p5, t_p6 })
}

/// ```prism
/// LiteralRange: unbounded fn St, Want, Ty -> St
/// ```
pub fn literal_range_f(st_p0: &crate::check::types::St, w_p1: &crate::check::types::Want, t_p2: &crate::check::types::Ty) -> crate::check::types::St {
    let lit_p3 = crate::syntax::lexer::chars::drop_prefix_f(&w_p1.cls_p, &Text::lit("Range "));
    let negative_p4 = crate::syntax::lexer::chars::has_prefix_f(&lit_p3, &Text::lit("-"));
    let digits_p5 = if negative_p4 {
        crate::syntax::lexer::chars::after_first_f(&lit_p3)
    } else {
        lit_p3.clone()
    };
    let n_o6 = crate::prelude::parse_nat_opt(&digits_p5);
    match t_p2 {
        crate::check::types::Ty::TyCon(m14067_0_0, m14067_0_1) if (m14067_0_0 == &Text::lit("Nat")) && (m14067_0_1.len() == 0) => if negative_p4 && (&digits_p5 != &Text::lit("0")) {
            crate::check::types::recording::err_f(st_p0, &Text::lit("literal-range"), &w_p1.span_p, &Text::from(format!("`{}` does not fit `Nat`", &lit_p3)))
        } else {
            st_p0.clone()
        },
        crate::check::types::Ty::TyCon(m14067_1_0, m14067_1_1) if (m14067_1_0 == &Text::lit("U8")) && (m14067_1_1.len() == 0) => match &n_o6 {
            Some(v_p7) => if negative_p4 || (v_p7 > &Nat::from(255u32)) {
                crate::check::types::recording::err_f(st_p0, &Text::lit("literal-range"), &w_p1.span_p, &Text::from(format!("`{}` does not fit `U8`", &lit_p3)))
            } else {
                st_p0.clone()
            },
            None => st_p0.clone(),
        },
        _ => st_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LiteralRange`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralRange: unbounded fn St, Want, Ty -> St
/// ```
pub struct LiteralRange {
    pub st_p0: crate::check::types::St,
    pub w_p1: crate::check::types::Want,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for LiteralRange {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let w_p1 = &self.w_p1;
        let t_p2 = &self.t_p2;
        let lit_p3 = crate::syntax::lexer::chars::drop_prefix_f(&w_p1.cls_p, &Text::lit("Range "));
        let negative_p4 = crate::syntax::lexer::chars::has_prefix_f(&lit_p3, &Text::lit("-"));
        let digits_p5 = if negative_p4 {
            crate::syntax::lexer::chars::after_first_f(&lit_p3)
        } else {
            lit_p3.clone()
        };
        let n_o6 = crate::prelude::parse_nat_opt(&digits_p5);
        match t_p2 {
            crate::check::types::Ty::TyCon(m14067_0_0, m14067_0_1) if (m14067_0_0 == &Text::lit("Nat")) && (m14067_0_1.len() == 0) => if negative_p4 && (&digits_p5 != &Text::lit("0")) {
                prism_rtl::Turn::Finished(crate::check::types::recording::err_f(st_p0, &Text::lit("literal-range"), &w_p1.span_p, &Text::from(format!("`{}` does not fit `Nat`", &lit_p3))))
            } else {
                prism_rtl::Turn::Finished(st_p0.clone())
            },
            crate::check::types::Ty::TyCon(m14067_1_0, m14067_1_1) if (m14067_1_0 == &Text::lit("U8")) && (m14067_1_1.len() == 0) => match &n_o6 {
                Some(v_p7) => if negative_p4 || (v_p7 > &Nat::from(255u32)) {
                    prism_rtl::Turn::Finished(crate::check::types::recording::err_f(st_p0, &Text::lit("literal-range"), &w_p1.span_p, &Text::from(format!("`{}` does not fit `U8`", &lit_p3))))
                } else {
                    prism_rtl::Turn::Finished(st_p0.clone())
                },
                None => prism_rtl::Turn::Finished(st_p0.clone()),
            },
            _ => prism_rtl::Turn::Finished(st_p0.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LiteralRange, x`: what the function value is when passed to `@Run`.
pub fn start_literal_range_f(st_p0: crate::check::types::St, w_p1: crate::check::types::Want, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(LiteralRange { st_p0, w_p1, t_p2 })
}

/// ```prism
/// SignedAt: unbounded fn St, Want, Ty -> St
/// ```
pub fn signed_at_f(st_p0: &crate::check::types::St, w_p1: &crate::check::types::Want, t_p2: &crate::check::types::Ty) -> crate::check::types::St {
    match t_p2 {
        crate::check::types::Ty::TyCon(m14538_0_0, m14538_0_1) if (m14538_0_0 == &Text::lit("Nat")) && (m14538_0_1.len() == 0) => if &w_p1.cls_p == &Text::lit("Prelude.Sub") {
            crate::check::types::recording::err_fix_f(st_p0, &Text::lit("nat-minus"), &w_p1.span_p, &Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), &Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`"))
        } else {
            st_p0.clone()
        },
        crate::check::types::Ty::TyCon(m14538_1_0, m14538_1_1) if (m14538_1_0 == &Text::lit("U8")) && (m14538_1_1.len() == 0) => if &w_p1.cls_p == &Text::lit("Prelude.Sub") { st_p0.clone() } else { st_p0.clone() },
        _ => st_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SignedAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SignedAt: unbounded fn St, Want, Ty -> St
/// ```
pub struct SignedAt {
    pub st_p0: crate::check::types::St,
    pub w_p1: crate::check::types::Want,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for SignedAt {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let w_p1 = &self.w_p1;
        let t_p2 = &self.t_p2;
        match t_p2 {
            crate::check::types::Ty::TyCon(m14538_0_0, m14538_0_1) if (m14538_0_0 == &Text::lit("Nat")) && (m14538_0_1.len() == 0) => if &w_p1.cls_p == &Text::lit("Prelude.Sub") {
                prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(st_p0, &Text::lit("nat-minus"), &w_p1.span_p, &Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), &Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`")))
            } else {
                prism_rtl::Turn::Finished(st_p0.clone())
            },
            crate::check::types::Ty::TyCon(m14538_1_0, m14538_1_1) if (m14538_1_0 == &Text::lit("U8")) && (m14538_1_1.len() == 0) => if &w_p1.cls_p == &Text::lit("Prelude.Sub") {
                prism_rtl::Turn::Finished(st_p0.clone())
            } else {
                prism_rtl::Turn::Finished(st_p0.clone())
            },
            _ => prism_rtl::Turn::Finished(st_p0.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SignedAt, x`: what the function value is when passed to `@Run`.
pub fn start_signed_at_f(st_p0: crate::check::types::St, w_p1: crate::check::types::Want, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SignedAt { st_p0, w_p1, t_p2 })
}

/// ```prism
/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub fn solve_class_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, s0_p2: &crate::check::types::St, restore_f3: &Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens_p4: &Array<(Text, Text)>, w_p5: &crate::check::types::Want, t_p6: &crate::check::types::Ty) -> (Array<crate::check::types::Want>, crate::check::types::St) {
    let bare_p7 = crate::check::types::bare_name_f(&w_p5.cls_p);
    let parts_o8 = match t_p6 {
        crate::check::types::Ty::TyTuple(ts_pa) => Some(ts_pa.clone()),
        crate::check::types::Ty::TyArray(e_pb) => Some(Array::from(vec![(**e_pb).clone()])),
        crate::check::types::Ty::TyMap(k_pc, v_pd) => Some(Array::from(vec![(**k_pc).clone(), (**v_pd).clone()])),
        _ => None,
    };
    let structural_p9 = ((&bare_p7 == &Text::lit("Eq")) || (&bare_p7 == &Text::lit("Ord"))) || (&bare_p7 == &Text::lit("Show"));
    match &parts_o8 {
        Some(ps_pe) => if structural_p9 {
            (crate::prelude::each(ps_pe, &(|p_pf: &crate::check::types::Ty| crate::check::types::Want { cls_p: w_p5.cls_p.clone(), ty_p: p_pf.clone(), file_p: w_p5.file_p.clone(), span_p: w_p5.span_p.clone(), level_p: w_p5.level_p.clone() })), solved_f(st_p1, w_p5, t_p6, &Text::lit("parts")))
        } else {
            (Array::new(), crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_f(s0_p2, &Text::lit("no-impl"), &w_p5.span_p, &Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &crate::check::types::show_ty_f(st_p1, t_p6)))))))
        },
        None => match t_p6 {
            crate::check::types::Ty::TySig(_, _) => (Array::new(), st_p1.clone()),
            crate::check::types::Ty::TyElem(rw_pg, _) => elem_trait_f(g_p0, st_p1, s0_p2, &restore_f3.clone(), w_p5, t_p6, &bare_p7, rw_pg),
            crate::check::types::Ty::TyElemAny(rw_ph) => elem_trait_f(g_p0, st_p1, s0_p2, &restore_f3.clone(), w_p5, t_p6, &bare_p7, rw_ph),
            crate::check::types::Ty::TyAny(trs_pi) if crate::check::types::has_text_f(&super_closure_f(g_p0, &w_p5.cls_p), &Text::lit("Prelude.Eq")) => (Array::new(), crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_f(s0_p2, &Text::lit("no-impl"), &w_p5.span_p, &Text::from(format!("no impl of `^{}` for `{}`: each existential hides a type of its own, so two do not compare", &bare_p7, &crate::check::types::show_ty_f(st_p1, t_p6))))))),
            crate::check::types::Ty::TyAny(trs_pj) => if crate::check::types::has_text_f(trs_pj, &w_p5.cls_p) || crate::prelude::run_to_end(crate::prelude::fold_job(trs_pj.clone(), false, {
                let g_p0x = g_p0.clone();
                let w_p5x = w_p5.clone();
                Rc::new(move |(p0, p1): (bool, Text)| {
                    let g_p0xy = g_p0x.clone();
                    let w_p5xy = w_p5x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let seen_pk = p0;
                        let tr_pl = p1;
                        prism_rtl::Turn::Finished(seen_pk || crate::check::types::has_text_f(&super_closure_f(&g_p0xy, &tr_pl), &w_p5xy.cls_p))
                    }))
                }) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>
            })) {
                (Array::new(), solved_f(st_p1, w_p5, t_p6, &Text::lit("packed")))
            } else {
                (Array::new(), crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_f(s0_p2, &Text::lit("no-impl"), &w_p5.span_p, &Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &crate::check::types::show_ty_f(st_p1, t_p6)))))))
            },
            crate::check::types::Ty::TyCon(con_pm, args_pn) => if builtin_has_f(&w_p5.cls_p, con_pm) {
                (Array::new(), solved_f(st_p1, w_p5, t_p6, &Text::lit("builtin")))
            } else {
                match find_impl_o(g_p0, st_p1, &w_p5.cls_p, t_p6) {
                    Some((im_po, s2_pp, how_pq, ch_pr)) => {
                        let wants_ps = crate::prelude::each(&im_po, &(|(ty_pt, cls_pu): &(crate::check::types::Ty, Text)| crate::check::types::Want { cls_p: cls_pu.clone(), ty_p: ty_pt.clone(), file_p: w_p5.file_p.clone(), span_p: w_p5.span_p.clone(), level_p: w_p5.level_p.clone() }));
                        (wants_ps.clone(), crate::check::types::recording::note_choice_f(&solved_f(&s2_pp, w_p5, t_p6, &how_pq), &w_p5.file_p, &w_p5.span_p, &w_p5.cls_p, &ch_pr))
                    },
                    None => {
                        let fix_pv = if ((&bare_p7 == &Text::lit("Num")) && (con_pm == &Text::lit("Text"))) || crate::check::env::is_regex_type_f(con_pm) {
                            Text::lit("")
                        } else {
                            Text::from(format!("derive `^{}` on `{}`, or write `impl ^{} {}`", &bare_p7, &crate::check::types::bare_name_f(con_pm), &bare_p7, &crate::check::types::bare_name_f(con_pm)))
                        };
                        (Array::new(), crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_fix_f(s0_p2, &Text::lit("no-impl"), &w_p5.span_p, &Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &crate::check::types::show_ty_f(st_p1, t_p6))), &fix_pv))))
                    },
                }
            },
            _ => (Array::new(), st_p1.clone()),
            _ => unreachable!("no arm matched"),
        },
    }
}

/// The step machine of `SolveClass`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
/// ```
pub struct SolveClass {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub s0_p2: crate::check::types::St,
    pub restore_f3: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>,
    pub givens_p4: Array<(Text, Text)>,
    pub w_p5: crate::check::types::Want,
    pub t_p6: crate::check::types::Ty,
}

impl prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)> for SolveClass {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Want>, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let s0_p2 = &self.s0_p2;
        let restore_f3 = &self.restore_f3;
        let givens_p4 = &self.givens_p4;
        let w_p5 = &self.w_p5;
        let t_p6 = &self.t_p6;
        let bare_p7 = crate::check::types::bare_name_f(&w_p5.cls_p);
        let parts_o8 = match t_p6 {
            crate::check::types::Ty::TyTuple(ts_pa) => Some(ts_pa.clone()),
            crate::check::types::Ty::TyArray(e_pb) => Some(Array::from(vec![(**e_pb).clone()])),
            crate::check::types::Ty::TyMap(k_pc, v_pd) => Some(Array::from(vec![(**k_pc).clone(), (**v_pd).clone()])),
            _ => None,
        };
        let structural_p9 = ((&bare_p7 == &Text::lit("Eq")) || (&bare_p7 == &Text::lit("Ord"))) || (&bare_p7 == &Text::lit("Show"));
        match &parts_o8 {
            Some(ps_pe) => if structural_p9 {
                prism_rtl::Turn::Finished((crate::prelude::each(ps_pe, &(|p_pf: &crate::check::types::Ty| crate::check::types::Want { cls_p: w_p5.cls_p.clone(), ty_p: p_pf.clone(), file_p: w_p5.file_p.clone(), span_p: w_p5.span_p.clone(), level_p: w_p5.level_p.clone() })), solved_f(st_p1, w_p5, t_p6, &Text::lit("parts"))))
            } else {
                {
                    let restore_f3x = restore_f3.clone();
                    let s0_p2x = s0_p2.clone();
                    let st_p1x = st_p1.clone();
                    let t_p6x = t_p6.clone();
                    let w_p5x = w_p5.clone();
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p6x.clone()), move |show_ty_f_15466: Text| crate::prelude::call_value((&restore_f3x)(crate::check::types::recording::err_f(&s0_p2x, &Text::lit("no-impl"), &w_p5x.span_p, &Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &show_ty_f_15466)))), move |restore_15402: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_15402))))
                }
            },
            None => match t_p6 {
                crate::check::types::Ty::TySig(_, _) => prism_rtl::Turn::Finished((Array::new(), st_p1.clone())),
                crate::check::types::Ty::TyElem(rw_pg, _) => prism_rtl::Turn::More(Rc::new(ElemTrait { g_p0: g_p0.clone(), st_p1: st_p1.clone(), s0_p2: s0_p2.clone(), restore_f3: restore_f3.clone(), w_p4: w_p5.clone(), t_p5: t_p6.clone(), bare_p6: bare_p7.clone(), rw_p7: rw_pg.clone() })),
                crate::check::types::Ty::TyElemAny(rw_ph) => prism_rtl::Turn::More(Rc::new(ElemTrait { g_p0: g_p0.clone(), st_p1: st_p1.clone(), s0_p2: s0_p2.clone(), restore_f3: restore_f3.clone(), w_p4: w_p5.clone(), t_p5: t_p6.clone(), bare_p6: bare_p7.clone(), rw_p7: rw_ph.clone() })),
                crate::check::types::Ty::TyAny(trs_pi) if crate::check::types::has_text_f(&super_closure_f(g_p0, &w_p5.cls_p), &Text::lit("Prelude.Eq")) => {
                    let restore_f3x = restore_f3.clone();
                    let s0_p2x = s0_p2.clone();
                    let st_p1x = st_p1.clone();
                    let t_p6x = t_p6.clone();
                    let w_p5x = w_p5.clone();
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p6x.clone()), move |show_ty_f_16022: Text| crate::prelude::call_value((&restore_f3x)(crate::check::types::recording::err_f(&s0_p2x, &Text::lit("no-impl"), &w_p5x.span_p, &Text::from(format!("no impl of `^{}` for `{}`: each existential hides a type of its own, so two do not compare", &bare_p7, &show_ty_f_16022)))), move |restore_15958: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_15958))))
                },
                crate::check::types::Ty::TyAny(trs_pj) => if crate::check::types::has_text_f(trs_pj, &w_p5.cls_p) || crate::prelude::run_to_end(crate::prelude::fold_job(trs_pj.clone(), false, {
                    let g_p0x = g_p0.clone();
                    let w_p5x = w_p5.clone();
                    Rc::new(move |(p0, p1): (bool, Text)| {
                        let g_p0xy = g_p0x.clone();
                        let w_p5xy = w_p5x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let seen_pk = p0;
                            let tr_pl = p1;
                            prism_rtl::Turn::Finished(seen_pk || crate::check::types::has_text_f(&super_closure_f(&g_p0xy, &tr_pl), &w_p5xy.cls_p))
                        }))
                    }) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>
                })) {
                    prism_rtl::Turn::Finished((Array::new(), solved_f(st_p1, w_p5, t_p6, &Text::lit("packed"))))
                } else {
                    {
                        let restore_f3x = restore_f3.clone();
                        let s0_p2x = s0_p2.clone();
                        let st_p1x = st_p1.clone();
                        let t_p6x = t_p6.clone();
                        let w_p5x = w_p5.clone();
                        crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p6x.clone()), move |show_ty_f_16350: Text| crate::prelude::call_value((&restore_f3x)(crate::check::types::recording::err_f(&s0_p2x, &Text::lit("no-impl"), &w_p5x.span_p, &Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &show_ty_f_16350)))), move |restore_16286: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_16286))))
                    }
                },
                crate::check::types::Ty::TyCon(con_pm, args_pn) => if builtin_has_f(&w_p5.cls_p, con_pm) {
                    prism_rtl::Turn::Finished((Array::new(), solved_f(st_p1, w_p5, t_p6, &Text::lit("builtin"))))
                } else {
                    {
                        let restore_f3x = restore_f3.clone();
                        let con_pmx = con_pm.clone();
                        let g_p0x = g_p0.clone();
                        let s0_p2x = s0_p2.clone();
                        let st_p1x = st_p1.clone();
                        let t_p6x = t_p6.clone();
                        let w_p5x = w_p5.clone();
                        crate::prelude::call_then(start_find_impl_o(g_p0x.clone(), st_p1x.clone(), w_p5x.cls_p.clone(), t_p6x.clone()), move |find_impl_o_16507: Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>| match find_impl_o_16507 {
                            Some((im_po, s2_pp, how_pq, ch_pr)) => {
                                let wants_ps = crate::prelude::each(&im_po, &(|(ty_pt, cls_pu): &(crate::check::types::Ty, Text)| crate::check::types::Want { cls_p: cls_pu.clone(), ty_p: ty_pt.clone(), file_p: w_p5x.file_p.clone(), span_p: w_p5x.span_p.clone(), level_p: w_p5x.level_p.clone() }));
                                prism_rtl::Turn::Finished((wants_ps.clone(), crate::check::types::recording::note_choice_f(&solved_f(&s2_pp, &w_p5x, &t_p6x, &how_pq), &w_p5x.file_p, &w_p5x.span_p, &w_p5x.cls_p, &ch_pr)))
                            },
                            None => {
                                let fix_pv = if ((&bare_p7 == &Text::lit("Num")) && (&con_pmx == &Text::lit("Text"))) || crate::check::env::is_regex_type_f(&con_pmx) {
                                    Text::lit("")
                                } else {
                                    Text::from(format!("derive `^{}` on `{}`, or write `impl ^{} {}`", &bare_p7, &crate::check::types::bare_name_f(&con_pmx), &bare_p7, &crate::check::types::bare_name_f(&con_pmx)))
                                };
                                crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p6x.clone()), move |show_ty_f_17102: Text| crate::prelude::call_value((&restore_f3x)(crate::check::types::recording::err_fix_f(&s0_p2x, &Text::lit("no-impl"), &w_p5x.span_p, &Text::from(format!("no impl of `^{}` for `{}`", &bare_p7, &show_ty_f_17102)), &fix_pv)), move |restore_17035: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_17035))))
                            },
                        })
                    }
                },
                _ => prism_rtl::Turn::Finished((Array::new(), st_p1.clone())),
                _ => unreachable!("no arm matched"),
            },
        }
    }
}

/// `Start SolveClass, x`: what the function value is when passed to `@Run`.
pub fn start_solve_class_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, s0_p2: crate::check::types::St, restore_f3: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, givens_p4: Array<(Text, Text)>, w_p5: crate::check::types::Want, t_p6: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>> {
    Rc::new(SolveClass { g_p0, st_p1, s0_p2, restore_f3, givens_p4, w_p5, t_p6 })
}

/// ```prism
/// ElemTrait: unbounded fn G, St, St, (fn St -> St), Want, Ty, Text, Rw -> (([Want], St))
/// ```
pub fn elem_trait_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, s0_p2: &crate::check::types::St, restore_f3: &Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, w_p4: &crate::check::types::Want, t_p5: &crate::check::types::Ty, bare_p6: &Text, rw_p7: &crate::check::types::Rw) -> (Array<crate::check::types::Want>, crate::check::types::St) {
    if !((bare_p6 == &Text::lit("Eq")) || (bare_p6 == &Text::lit("Show"))) {
        (Array::new(), crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_f(s0_p2, &Text::lit("no-impl"), &w_p4.span_p, &Text::from(format!("no impl of `^{}` for `{}`", bare_p6, &crate::check::types::show_ty_f(st_p1, t_p5)))))))
    } else {
        if row_holds_dynamics_f(g_p0, &crate::check::types::recording::walk_row_f(st_p1, rw_p7)) {
            (Array::new(), crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_fix_f(s0_p2, &Text::lit("no-impl"), &w_p4.span_p, &Text::from(format!("no impl of `^{}` for `{}`: a tag of its row holds dynamics (a container\'s children, `$(Path ==> $Elem)`), which do not compare or print", bare_p6, &crate::check::types::show_ty_f(st_p1, t_p5))), &Text::lit("compare or show what the element holds, a field at a time")))))
        } else {
            (Array::new(), solved_f(st_p1, w_p4, t_p5, &Text::lit("builtin")))
        }
    }
}

/// The step machine of `ElemTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElemTrait: unbounded fn G, St, St, (fn St -> St), Want, Ty, Text, Rw -> (([Want], St))
/// ```
pub struct ElemTrait {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub s0_p2: crate::check::types::St,
    pub restore_f3: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>,
    pub w_p4: crate::check::types::Want,
    pub t_p5: crate::check::types::Ty,
    pub bare_p6: Text,
    pub rw_p7: crate::check::types::Rw,
}

impl prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)> for ElemTrait {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Want>, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let s0_p2 = &self.s0_p2;
        let restore_f3 = &self.restore_f3;
        let w_p4 = &self.w_p4;
        let t_p5 = &self.t_p5;
        let bare_p6 = &self.bare_p6;
        let rw_p7 = &self.rw_p7;
        if !((bare_p6 == &Text::lit("Eq")) || (bare_p6 == &Text::lit("Show"))) {
            {
                let restore_f3x = restore_f3.clone();
                let bare_p6x = bare_p6.clone();
                let s0_p2x = s0_p2.clone();
                let st_p1x = st_p1.clone();
                let t_p5x = t_p5.clone();
                let w_p4x = w_p4.clone();
                crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p5x.clone()), move |show_ty_f_17511: Text| crate::prelude::call_value((&restore_f3x)(crate::check::types::recording::err_f(&s0_p2x, &Text::lit("no-impl"), &w_p4x.span_p, &Text::from(format!("no impl of `^{}` for `{}`", &bare_p6x, &show_ty_f_17511)))), move |restore_17447: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_17447))))
            }
        } else {
            {
                let restore_f3x = restore_f3.clone();
                let bare_p6x = bare_p6.clone();
                let g_p0x = g_p0.clone();
                let rw_p7x = rw_p7.clone();
                let s0_p2x = s0_p2.clone();
                let st_p1x = st_p1.clone();
                let t_p5x = t_p5.clone();
                let w_p4x = w_p4.clone();
                crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_p7x.clone()), move |walk_row_f_17564: crate::check::types::Rw| if row_holds_dynamics_f(&g_p0x, &walk_row_f_17564) {
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p5x.clone()), move |show_ty_f_17656: Text| crate::prelude::call_value((&restore_f3x)(crate::check::types::recording::err_fix_f(&s0_p2x, &Text::lit("no-impl"), &w_p4x.span_p, &Text::from(format!("no impl of `^{}` for `{}`: a tag of its row holds dynamics (a container\'s children, `$(Path ==> $Elem)`), which do not compare or print", &bare_p6x, &show_ty_f_17656)), &Text::lit("compare or show what the element holds, a field at a time"))), move |restore_17589: crate::check::types::St| prism_rtl::Turn::Finished((Array::new(), restore_17589))))
                } else {
                    prism_rtl::Turn::Finished((Array::new(), solved_f(&st_p1x, &w_p4x, &t_p5x, &Text::lit("builtin"))))
                })
            }
        }
    }
}

/// `Start ElemTrait, x`: what the function value is when passed to `@Run`.
pub fn start_elem_trait_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, s0_p2: crate::check::types::St, restore_f3: Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>, w_p4: crate::check::types::Want, t_p5: crate::check::types::Ty, bare_p6: Text, rw_p7: crate::check::types::Rw) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Want>, crate::check::types::St)>> {
    Rc::new(ElemTrait { g_p0, st_p1, s0_p2, restore_f3, w_p4, t_p5, bare_p6, rw_p7 })
}

/// ```prism
/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
/// ```
pub fn find_impl_o(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, cls_p2: &Text, t_p3: &crate::check::types::Ty) -> Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&g_p0.impls_p, cls_p2), &Array::new()), None, {
        let st_p1x = st_p1.clone();
        let t_p3x = t_p3.clone();
        let g_p0x = g_p0.clone();
        Rc::new(move |(p0, p1): (Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, crate::check::env::ImplInfo)| {
            let st_p1xy = st_p1x.clone();
            let t_p3xy = t_p3x.clone();
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let found_o4 = p0;
                let im_p5 = p1;
                match &found_o4 {
                    Some(f_p6) => prism_rtl::Turn::Finished(Some(f_p6.clone())),
                    None => crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p1xy.clone(), t_p3xy.clone()), move |zonk_f_18300: crate::check::types::Ty| match match_head_o(&im_p5.head_p, &zonk_f_18300, &Map::new()) {
                        Some(m_p7) => prism_rtl::Turn::Finished(Some((crate::prelude::each(&im_p5.bounds_p, &(|(v_p8, c_p9): &(Text, Text)| (crate::prelude::or(&crate::prelude::get(&m_p7, v_p8), &crate::check::types::Ty::TyErr), c_p9.clone()))), st_p1xy.clone(), impl_how_f(&g_p0xy, &im_p5), impl_choice_f(&im_p5)))),
                        None => prism_rtl::Turn::Finished(None),
                    }),
                }
            }))
        }) as Rc<dyn Fn((Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>>>>
    }))
}

/// The step machine of `FindImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
/// ```
pub struct FindImpl {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub cls_p2: Text,
    pub t_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>> for FindImpl {
    fn cycle(&self) -> prism_rtl::Turn<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let cls_p2 = &self.cls_p2;
        let t_p3 = &self.t_p3;
        crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&g_p0.impls_p, cls_p2), &Array::new()), None, {
            let st_p1x = st_p1.clone();
            let t_p3x = t_p3.clone();
            let g_p0x = g_p0.clone();
            Rc::new(move |(p0, p1): (Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, crate::check::env::ImplInfo)| {
                let st_p1xy = st_p1x.clone();
                let t_p3xy = t_p3x.clone();
                let g_p0xy = g_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_o4 = p0;
                    let im_p5 = p1;
                    match &found_o4 {
                        Some(f_p6) => prism_rtl::Turn::Finished(Some(f_p6.clone())),
                        None => crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p1xy.clone(), t_p3xy.clone()), move |zonk_f_18300: crate::check::types::Ty| match match_head_o(&im_p5.head_p, &zonk_f_18300, &Map::new()) {
                            Some(m_p7) => prism_rtl::Turn::Finished(Some((crate::prelude::each(&im_p5.bounds_p, &(|(v_p8, c_p9): &(Text, Text)| (crate::prelude::or(&crate::prelude::get(&m_p7, v_p8), &crate::check::types::Ty::TyErr), c_p9.clone()))), st_p1xy.clone(), impl_how_f(&g_p0xy, &im_p5), impl_choice_f(&im_p5)))),
                            None => prism_rtl::Turn::Finished(None),
                        }),
                    }
                }))
            }) as Rc<dyn Fn((Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>>>>
        }).cycle()
    }
}

/// `Start FindImpl, x`: what the function value is when passed to `@Run`.
pub fn start_find_impl_o(g_p0: crate::check::env::G, st_p1: crate::check::types::St, cls_p2: Text, t_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Option<(Array<(crate::check::types::Ty, Text)>, crate::check::types::St, Text, Text)>>> {
    Rc::new(FindImpl { g_p0, st_p1, cls_p2, t_p3 })
}

/// ```prism
/// ImplChoice: fn ImplInfo -> Text
/// ```
pub fn impl_choice_f(im_p0: &crate::check::env::ImplInfo) -> Text {
    match &im_p0.head_p {
        crate::check::types::Ty::TyCon(n_p1, _) => if im_p0.derived_p {
            Text::from(format!("derived:{}", n_p1))
        } else {
            Text::from(format!("impl:{}.{}", &im_p0.file_p, &im_p0.span_p.start_p))
        },
        _ => if im_p0.derived_p {
            Text::lit("any")
        } else {
            Text::from(format!("impl:{}.{}", &im_p0.file_p, &im_p0.span_p.start_p))
        },
    }
}

/// ```prism
/// ImplHow: fn G, ImplInfo -> Text
/// ```
pub fn impl_how_f(g_p0: &crate::check::env::G, im_p1: &crate::check::env::ImplInfo) -> Text {
    let src_p2 = crate::prelude::or(&crate::prelude::index(&g_p0.srcs_p, &im_p1.file_p), &crate::check::errors::mk_src_f(&Text::lit("?"), &Text::lit("")));
    Text::from(format!("{} {}:{}", &(if im_p1.derived_p { Text::lit("derived") } else { Text::lit("impl") }), &src_p2.path_p, &(&crate::check::errors::cline_of_f(&src_p2.starts_p, &im_p1.span_p.start_p) + &Nat::from(1u32))))
}

/// ```prism
/// Solved: fn St, Want, Ty, Text -> St
/// ```
pub fn solved_f(st_p0: &crate::check::types::St, w_p1: &crate::check::types::Want, t_p2: &crate::check::types::Ty, how_p3: &Text) -> crate::check::types::St {
    let s2_p4 = crate::check::types::recording::note_impl_f(st_p0, &w_p1.file_p, &w_p1.span_p, &w_p1.cls_p, t_p2, how_p3);
    if ((how_p3 == &Text::lit("given")) || (how_p3 == &Text::lit("packed"))) || (how_p3 == &Text::lit("quantified")) {
        crate::check::types::recording::note_choice_f(&s2_p4, &w_p1.file_p, &w_p1.span_p, &w_p1.cls_p, &Text::lit("any"))
    } else {
        if (how_p3 == &Text::lit("builtin")) || (how_p3 == &Text::lit("parts")) {
            crate::check::types::recording::note_choice_f(&s2_p4, &w_p1.file_p, &w_p1.span_p, &w_p1.cls_p, &Text::lit("none"))
        } else {
            s2_p4.clone()
        }
    }
}

/// ```prism
/// ?MatchHead: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub fn match_head_o(pat_p0: &crate::check::types::Ty, t_p1: &crate::check::types::Ty, m_p2: &Map<Text, crate::check::types::Ty>) -> Option<Map<Text, crate::check::types::Ty>> {
    match (pat_p0.clone(), t_p1.clone()) {
        (crate::check::types::Ty::TyQ(v_p3), x_p4) => match crate::prelude::get(m_p2, &v_p3) {
            Some(y_p5) => if &y_p5 == &x_p4 { Some(m_p2.clone()) } else { None },
            None => Some(crate::prelude::insert(m_p2, &v_p3, &x_p4)),
        },
        (crate::check::types::Ty::TyCon(a_p6, xs_p7), crate::check::types::Ty::TyCon(b_p8, ys_p9)) => if (&a_p6 == &b_p8) && (&crate::prelude::len(&xs_p7) == &crate::prelude::len(&ys_p9)) {
            match_all_o(&xs_p7, &ys_p9, m_p2)
        } else {
            None
        },
        (crate::check::types::Ty::TyTuple(xs_pa), crate::check::types::Ty::TyTuple(ys_pb)) => if &crate::prelude::len(&xs_pa) == &crate::prelude::len(&ys_pb) {
            match_all_o(&xs_pa, &ys_pb, m_p2)
        } else {
            None
        },
        (crate::check::types::Ty::TyArray(x_pc), crate::check::types::Ty::TyArray(y_pd)) => match_head_o(&*x_pc, &*y_pd, m_p2),
        (crate::check::types::Ty::TyMap(k1_pe, v1_pf), crate::check::types::Ty::TyMap(k2_pg, v2_ph)) => match_all_o(&Array::from(vec![(*k1_pe).clone(), (*v1_pf).clone()]), &Array::from(vec![(*k2_pg).clone(), (*v2_ph).clone()]), m_p2),
        (crate::check::types::Ty::TySig(s1_pi, i1_pj), crate::check::types::Ty::TySig(s2_pk, i2_pl)) => if &s1_pi == &s2_pk { match_head_o(&*i1_pj, &*i2_pl, m_p2) } else { None },
        _ => None,
    }
}

/// ```prism
/// ?MatchAll: unbounded fn [Ty], [Ty], (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub fn match_all_o(xs_p0: &Array<crate::check::types::Ty>, ys_p1: &Array<crate::check::types::Ty>, m_p2: &Map<Text, crate::check::types::Ty>) -> Option<Map<Text, crate::check::types::Ty>> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(xs_p0)), Some(m_p2.clone()), {
        let xs_p0x = xs_p0.clone();
        let ys_p1x = ys_p1.clone();
        Rc::new(move |(p0, p1): (Option<Map<Text, crate::check::types::Ty>>, Nat)| {
            let xs_p0xy = xs_p0x.clone();
            let ys_p1xy = ys_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_o3 = p0;
                let i_p4 = p1;
                match &acc_o3 {
                    Some(mm_p5) => prism_rtl::Turn::Finished(match_head_o(&crate::prelude::or(&crate::prelude::index(&xs_p0xy, &i_p4), &crate::check::types::Ty::TyErr), &crate::prelude::or(&crate::prelude::index(&ys_p1xy, &i_p4), &crate::check::types::Ty::TyErr), mm_p5)),
                    None => prism_rtl::Turn::Finished(None),
                }
            }))
        }) as Rc<dyn Fn((Option<Map<Text, crate::check::types::Ty>>, Nat)) -> Rc<dyn prism_rtl::Job<Option<Map<Text, crate::check::types::Ty>>>>>
    }))
}

/// ```prism
/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
/// ```
pub fn default_wants_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, givens_p2: &Array<(Text, Text)>) -> crate::check::types::St {
    let flex_vars_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(st_p1.wants_p.clone(), Array::new(), {
        let st_p1x = st_p1.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Want)| {
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p8 = p0;
                let w_p9 = p1;
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xy.clone(), w_p9.ty_p.clone()), move |walk_f_20884: crate::check::types::Ty| match walk_f_20884 {
                    crate::check::types::Ty::TyFlex(n_pa) => prism_rtl::Turn::Finished(crate::check::types::add_nat_f(&acc_p8, &n_pa)),
                    _ => prism_rtl::Turn::Finished(acc_p8.clone()),
                })
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    let s2_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(flex_vars_p3.clone(), st_p1.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_pb = p0;
        let v_pc = p1;
        crate::prelude::call_value(crate::prelude::filter_job(s_pb.wants_p.clone(), {
            let s_pbx = s_pb.clone();
            let v_pcx = v_pc.clone();
            Rc::new(move |p0: crate::check::types::Want| {
                let s_pbxy = s_pbx.clone();
                let v_pcxy = v_pcx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let w_pf = p0;
                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_pbxy.clone(), w_pf.ty_p.clone()), move |walk_f_21044: crate::check::types::Ty| prism_rtl::Turn::Finished(&walk_f_21044 == &crate::check::types::Ty::TyFlex(v_pcxy.clone())))
                }))
            }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |filter_21022: Array<crate::check::types::Want>| {
            let classes_pd = crate::prelude::each(&filter_21022, &(|w_pg: &crate::check::types::Want| crate::check::types::bare_name_f(&w_pg.cls_p)));
            let defaultable_pe = crate::check::types::has_text_f(&classes_pd, &Text::lit("Num")) && crate::prelude::fold(&classes_pd, &true, &(|ok_ph: &bool, c_pi: &Text| *ok_ph && (crate::check::types::has_text_f(&Array::from(vec![Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")]), c_pi) || crate::syntax::lexer::chars::has_prefix_f(c_pi, &Text::lit("Range ")))));
            if defaultable_pe {
                prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = s_pb.clone();
                    this.tys_p = crate::prelude::insert(&this.tys_p, &v_pc, &crate::check::types::t_int_p());
                    this
                })
            } else {
                prism_rtl::Turn::Finished(s_pb.clone())
            }
        })
    }))) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>));
    let s3_p5 = solve_wants_f(g_p0, &s2_p4, givens_p2, &false);
    let leftover_p6 = crate::prelude::run_to_end(crate::prelude::filter_job(s3_p5.wants_p.clone(), {
        let s3_p5x = s3_p5.clone();
        Rc::new(move |p0: crate::check::types::Want| {
            let s3_p5xy = s3_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_pj = p0;
                crate::prelude::call_then(crate::check::types::start_is_flex_var_f(s3_p5xy.clone(), w_pj.ty_p.clone()), move |is_flex_var_f_21457: bool| prism_rtl::Turn::Finished(((is_flex_var_f_21457 && !crate::syntax::lexer::chars::has_prefix_f(&w_pj.cls_p, &Text::lit("Range "))) && (&w_pj.cls_p != &Text::lit("Prelude.Sub"))) && (&w_pj.cls_p != &Text::lit("Prelude.Signed"))))
            }))
        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let s4_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(leftover_p6.clone(), s3_p5.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Want)| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_pk = p0;
        let w_pl = p1;
        {
            let s5_pm = {
                let mut this: crate::check::types::St = s_pk.clone();
                this.file_p = w_pl.file_p.clone();
                this
            };
            crate::prelude::call_then(crate::check::types::start_show_ty_f(s_pk.clone(), w_pl.ty_p.clone()), move |show_ty_f_21728: Text| crate::prelude::call_then(crate::check::types::start_show_ty_f(s_pk.clone(), w_pl.ty_p.clone()), move |show_ty_f_21768: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s5_pm, &Text::lit("ambiguous"), &w_pl.span_p, &Text::from(format!("nothing decides `{}` in `^{} {}`; annotate, or write a suffixed operator", &show_ty_f_21728, &crate::check::types::bare_name_f(&w_pl.cls_p), &show_ty_f_21768)), &Text::lit("annotate the value\'s type")))))
        }
    }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>));
    let mut this: crate::check::types::St = s4_p7.clone();
    this.wants_p = Array::new();
    this.file_p = st_p1.file_p.clone();
    this
}

/// The step machine of `DefaultWants`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
/// ```
pub struct DefaultWants {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub givens_p2: Array<(Text, Text)>,
}

impl prism_rtl::Job<crate::check::types::St> for DefaultWants {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let givens_p2 = &self.givens_p2;
        let g_p0x = g_p0.clone();
        let givens_p2x = givens_p2.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(st_p1x.wants_p.clone(), Array::new(), {
            let st_p1xx = st_p1x.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Want)| {
                let st_p1xxy = st_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p8 = p0;
                    let w_p9 = p1;
                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xxy.clone(), w_p9.ty_p.clone()), move |walk_f_20884: crate::check::types::Ty| match walk_f_20884 {
                        crate::check::types::Ty::TyFlex(n_pa) => prism_rtl::Turn::Finished(crate::check::types::add_nat_f(&acc_p8, &n_pa)),
                        _ => prism_rtl::Turn::Finished(acc_p8.clone()),
                    })
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        }), move |fold_20847: Array<Nat>| {
            let flex_vars_p3 = fold_20847;
            crate::prelude::call_value(crate::prelude::fold_job(flex_vars_p3.clone(), st_p1x.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| crate::prelude::entered(crate::prelude::once_job(move || {
                let s_pb = p0;
                let v_pc = p1;
                crate::prelude::call_value(crate::prelude::filter_job(s_pb.wants_p.clone(), {
                    let s_pbx = s_pb.clone();
                    let v_pcx = v_pc.clone();
                    Rc::new(move |p0: crate::check::types::Want| {
                        let s_pbxy = s_pbx.clone();
                        let v_pcxy = v_pcx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let w_pf = p0;
                            crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_pbxy.clone(), w_pf.ty_p.clone()), move |walk_f_21044: crate::check::types::Ty| prism_rtl::Turn::Finished(&walk_f_21044 == &crate::check::types::Ty::TyFlex(v_pcxy.clone())))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |filter_21022: Array<crate::check::types::Want>| {
                    let classes_pd = crate::prelude::each(&filter_21022, &(|w_pg: &crate::check::types::Want| crate::check::types::bare_name_f(&w_pg.cls_p)));
                    let defaultable_pe = crate::check::types::has_text_f(&classes_pd, &Text::lit("Num")) && crate::prelude::fold(&classes_pd, &true, &(|ok_ph: &bool, c_pi: &Text| *ok_ph && (crate::check::types::has_text_f(&Array::from(vec![Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")]), c_pi) || crate::syntax::lexer::chars::has_prefix_f(c_pi, &Text::lit("Range ")))));
                    if defaultable_pe {
                        prism_rtl::Turn::Finished({
                            let mut this: crate::check::types::St = s_pb.clone();
                            this.tys_p = crate::prelude::insert(&this.tys_p, &v_pc, &crate::check::types::t_int_p());
                            this
                        })
                    } else {
                        prism_rtl::Turn::Finished(s_pb.clone())
                    }
                })
            }))) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>), move |fold_20967: crate::check::types::St| {
                let s2_p4 = fold_20967;
                crate::prelude::call_then(start_solve_wants_f(g_p0x.clone(), s2_p4.clone(), givens_p2x.clone(), false), move |solve_wants_f_21383: crate::check::types::St| {
                    let s3_p5 = solve_wants_f_21383;
                    crate::prelude::call_value(crate::prelude::filter_job(s3_p5.wants_p.clone(), {
                        let s3_p5x = s3_p5.clone();
                        Rc::new(move |p0: crate::check::types::Want| {
                            let s3_p5xy = s3_p5x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let w_pj = p0;
                                crate::prelude::call_then(crate::check::types::start_is_flex_var_f(s3_p5xy.clone(), w_pj.ty_p.clone()), move |is_flex_var_f_21457: bool| prism_rtl::Turn::Finished(((is_flex_var_f_21457 && !crate::syntax::lexer::chars::has_prefix_f(&w_pj.cls_p, &Text::lit("Range "))) && (&w_pj.cls_p != &Text::lit("Prelude.Sub"))) && (&w_pj.cls_p != &Text::lit("Prelude.Signed"))))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |filter_21434: Array<crate::check::types::Want>| {
                        let leftover_p6 = filter_21434;
                        crate::prelude::call_value(crate::prelude::fold_job(leftover_p6.clone(), s3_p5.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Want)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let s_pk = p0;
                            let w_pl = p1;
                            {
                                let s5_pm = {
                                    let mut this: crate::check::types::St = s_pk.clone();
                                    this.file_p = w_pl.file_p.clone();
                                    this
                                };
                                crate::prelude::call_then(crate::check::types::start_show_ty_f(s_pk.clone(), w_pl.ty_p.clone()), move |show_ty_f_21728: Text| crate::prelude::call_then(crate::check::types::start_show_ty_f(s_pk.clone(), w_pl.ty_p.clone()), move |show_ty_f_21768: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s5_pm, &Text::lit("ambiguous"), &w_pl.span_p, &Text::from(format!("nothing decides `{}` in `^{} {}`; annotate, or write a suffixed operator", &show_ty_f_21728, &crate::check::types::bare_name_f(&w_pl.cls_p), &show_ty_f_21768)), &Text::lit("annotate the value\'s type")))))
                            }
                        }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>), move |fold_21585: crate::check::types::St| {
                            let s4_p7 = fold_21585;
                            prism_rtl::Turn::Finished({
                                let mut this: crate::check::types::St = s4_p7.clone();
                                this.wants_p = Array::new();
                                this.file_p = st_p1x.file_p.clone();
                                this
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start DefaultWants, x`: what the function value is when passed to `@Run`.
pub fn start_default_wants_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, givens_p2: Array<(Text, Text)>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DefaultWants { g_p0, st_p1, givens_p2 })
}
