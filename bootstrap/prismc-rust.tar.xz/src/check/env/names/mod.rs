//! The module `Check.Env.Names`, from `target/bootstrap/src/prismc/check/env/names.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// CollectNames: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn collect_names_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, m_p2: &Text) -> (crate::check::env::G, crate::check::types::St) {
    match crate::prelude::get(&g_p0.mods_p, m_p2) {
        None => (g_p0.clone(), st_p1.clone()),
        Some(info_p3) => {
            let s0_p4 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file_p = info_p3.file_p.clone();
                this
            };
            let (g2_p9, s2_pa, _) = crate::prelude::run_to_end(crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), (g_p0.clone(), s0_p4.clone(), None), {
                let info_p3x = info_p3.clone();
                Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St, Option<Text>), crate::syntax::decls::Decl)| {
                    let info_p3xy = info_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (gg_p5, s_p6, last_type_o7) = p0;
                        let d_p8 = p1;
                        prism_rtl::Turn::More(Rc::new(CollectDecl { g_p0: gg_p5.clone(), st_p1: s_p6.clone(), info_p2: info_p3xy.clone(), d_p3: d_p8.clone(), last_type_o4: last_type_o7.clone() }))
                    }))
                }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St, Option<Text>), crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Option<Text>)>>>
            }));
            (g2_p9.clone(), s2_pa.clone())
        },
    }
}

/// The step machine of `CollectNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollectNames: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct CollectNames {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub m_p2: Text,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for CollectNames {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let m_p2 = &self.m_p2;
        match crate::prelude::get(&g_p0.mods_p, m_p2) {
            None => prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
            Some(info_p3) => {
                let s0_p4 = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.file_p = info_p3.file_p.clone();
                    this
                };
                let g_p0x = g_p0.clone();
                crate::prelude::call_value(crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), (g_p0x.clone(), s0_p4.clone(), None), {
                    let info_p3x = info_p3.clone();
                    Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St, Option<Text>), crate::syntax::decls::Decl)| {
                        let info_p3xy = info_p3x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (gg_p5, s_p6, last_type_o7) = p0;
                            let d_p8 = p1;
                            prism_rtl::Turn::More(Rc::new(CollectDecl { g_p0: gg_p5.clone(), st_p1: s_p6.clone(), info_p2: info_p3xy.clone(), d_p3: d_p8.clone(), last_type_o4: last_type_o7.clone() }))
                        }))
                    }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St, Option<Text>), crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Option<Text>)>>>
                }), move |fold_1030: (crate::check::env::G, crate::check::types::St, Option<Text>)| {
                    let (g2_p9, s2_pa, _) = fold_1030;
                    prism_rtl::Turn::Finished((g2_p9.clone(), s2_pa.clone()))
                })
            },
        }
    }
}

/// `Start CollectNames, x`: what the function value is when passed to `@Run`.
pub fn start_collect_names_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, m_p2: Text) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(CollectNames { g_p0, st_p1, m_p2 })
}

/// ```prism
/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
/// ```
pub fn collect_decl_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, d_p3: &crate::syntax::decls::Decl, last_type_o4: &Option<Text>) -> (crate::check::env::G, crate::check::types::St, Option<Text>) {
    match &d_p3.kind_p {
        crate::syntax::decls::DeclKind::DType(t_p5) => {
            let name_p6 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_p5.name_p.path_p));
            let ti_p7 = crate::check::env::TyInfo { name_p: name_p6.clone(), home_p: info_p2.name_p.clone(), params_p: crate::prelude::each(&t_p5.params_p, &(|p_p8: &crate::syntax::Ident| p_p8.name_p.clone())), body_p: crate::check::env::TyBody::BOpaque, derives_p: Array::new(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone() };
            if crate::check::env::has_key_f(&g_p0.types_p, &name_p6) {
                (g_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("collision"), &d_p3.span_p, &Text::from(format!("a second type `{}`", &crate::check::env::dotted_f(&t_p5.name_p.path_p)))), last_type_o4.clone())
            } else {
                {
                    let upd_p9 = {
                        let mut this: crate::check::env::G = g_p0.clone();
                        this.types_p = crate::prelude::insert(&this.types_p, &name_p6, &ti_p7);
                        this
                    };
                    (upd_p9.clone(), st_p1.clone(), Some(name_p6.clone()))
                }
            }
        },
        crate::syntax::decls::DeclKind::DDerive(trs_pa) => match last_type_o4 {
            Some(tn_pb) => {
                let upd_pc = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.types_p = crate::prelude::insert(&this.types_p, tn_pb, &add_derives_f(&crate::prelude::or(&crate::prelude::get(&g_p0.types_p, tn_pb), &dummy_ty_info_p()), &crate::prelude::each(trs_pa, &(|tr_pd: &crate::syntax::TraitRef| crate::check::env::dotted_f(&tr_pd.path_p)))));
                    this
                };
                (upd_pc.clone(), st_p1.clone(), last_type_o4.clone())
            },
            None => (g_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), &d_p3.span_p, &Text::lit("a `derive` line follows a type declaration")), None),
        },
        crate::syntax::decls::DeclKind::DTag(t_pe) => {
            let name_pf = crate::check::env::dotted_f(&t_pe.name_p.path_p);
            let family_pg = crate::check::env::dotted_f(&crate::prelude::take(&t_pe.name_p.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&t_pe.name_p.path_p))));
            let tags_ph = crate::prelude::or(&crate::prelude::get(&g_p0.families_p, &family_pg), &Array::new());
            let owner_pi = crate::prelude::or(&crate::prelude::get(&g_p0.fam_owner_p, &family_pg), &info_p2.name_p);
            let st2_pj = if &owner_pi != &info_p2.name_p {
                crate::check::types::recording::err_f(st_p1, &Text::lit("collision"), &d_p3.span_p, &Text::from(format!("the family `{}` is declared in {}; every tag of a family is declared in its family\'s module", &family_pg, &(if &owner_pi == &Text::lit("") {
                    Text::lit("the root")
                } else {
                    Text::from(format!("`{}`", &owner_pi))
                }))))
            } else {
                st_p1.clone()
            };
            let is_elem_pk = match &*t_pe.of_type_p.kind_p {
                crate::syntax::TypeKind::TName(n_pm, _) => &crate::check::env::dotted_f(&n_pm.path_p) == &Text::lit("Element"),
                _ => false,
            };
            let g2_pl = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.families_p = crate::prelude::insert(&this.families_p, &family_pg, &crate::prelude::push(&tags_ph, &name_pf));
                this.fam_owner_p = crate::prelude::insert(&this.fam_owner_p, &family_pg, &owner_pi);
                if is_elem_pk {
                    this.elem_fams_p = crate::check::types::add_text_f(&this.elem_fams_p, &family_pg);
                }
                this
            };
            (g2_pl.clone(), st2_pj.clone(), None)
        },
        crate::syntax::decls::DeclKind::DTrait(t_pn) => {
            let name_po = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_pn.name_p.path_p));
            let ti_pp = crate::check::env::TraitInfo { name_p: name_po.clone(), home_p: info_p2.name_p.clone(), param_p: crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&t_pn.params_p, &(|p_pr: &crate::syntax::Ident| p_pr.name_p.clone())), &Nat::from(0u32)), &Text::lit("a")), supers_p: Array::new(), methods_p: Array::new(), defaults_p: Array::new(), assocs_p: Array::new(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone() };
            let upd_pq = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.traits_p = crate::prelude::insert(&this.traits_p, &name_po, &ti_pp);
                this
            };
            (upd_pq.clone(), st_p1.clone(), None)
        },
        _ => (g_p0.clone(), st_p1.clone(), None),
    }
}

/// The step machine of `CollectDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
/// ```
pub struct CollectDecl {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
    pub d_p3: crate::syntax::decls::Decl,
    pub last_type_o4: Option<Text>,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Option<Text>)> for CollectDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St, Option<Text>)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        let d_p3 = &self.d_p3;
        let last_type_o4 = &self.last_type_o4;
        match &d_p3.kind_p {
            crate::syntax::decls::DeclKind::DType(t_p5) => {
                let name_p6 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_p5.name_p.path_p));
                let ti_p7 = crate::check::env::TyInfo { name_p: name_p6.clone(), home_p: info_p2.name_p.clone(), params_p: crate::prelude::each(&t_p5.params_p, &(|p_p8: &crate::syntax::Ident| p_p8.name_p.clone())), body_p: crate::check::env::TyBody::BOpaque, derives_p: Array::new(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone() };
                if crate::check::env::has_key_f(&g_p0.types_p, &name_p6) {
                    prism_rtl::Turn::Finished((g_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("collision"), &d_p3.span_p, &Text::from(format!("a second type `{}`", &crate::check::env::dotted_f(&t_p5.name_p.path_p)))), last_type_o4.clone()))
                } else {
                    {
                        let upd_p9 = {
                            let mut this: crate::check::env::G = g_p0.clone();
                            this.types_p = crate::prelude::insert(&this.types_p, &name_p6, &ti_p7);
                            this
                        };
                        prism_rtl::Turn::Finished((upd_p9.clone(), st_p1.clone(), Some(name_p6.clone())))
                    }
                }
            },
            crate::syntax::decls::DeclKind::DDerive(trs_pa) => match last_type_o4 {
                Some(tn_pb) => {
                    let upd_pc = {
                        let mut this: crate::check::env::G = g_p0.clone();
                        this.types_p = crate::prelude::insert(&this.types_p, tn_pb, &add_derives_f(&crate::prelude::or(&crate::prelude::get(&g_p0.types_p, tn_pb), &dummy_ty_info_p()), &crate::prelude::each(trs_pa, &(|tr_pd: &crate::syntax::TraitRef| crate::check::env::dotted_f(&tr_pd.path_p)))));
                        this
                    };
                    prism_rtl::Turn::Finished((upd_pc.clone(), st_p1.clone(), last_type_o4.clone()))
                },
                None => prism_rtl::Turn::Finished((g_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), &d_p3.span_p, &Text::lit("a `derive` line follows a type declaration")), None)),
            },
            crate::syntax::decls::DeclKind::DTag(t_pe) => {
                let name_pf = crate::check::env::dotted_f(&t_pe.name_p.path_p);
                let family_pg = crate::check::env::dotted_f(&crate::prelude::take(&t_pe.name_p.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&t_pe.name_p.path_p))));
                let tags_ph = crate::prelude::or(&crate::prelude::get(&g_p0.families_p, &family_pg), &Array::new());
                let owner_pi = crate::prelude::or(&crate::prelude::get(&g_p0.fam_owner_p, &family_pg), &info_p2.name_p);
                let st2_pj = if &owner_pi != &info_p2.name_p {
                    crate::check::types::recording::err_f(st_p1, &Text::lit("collision"), &d_p3.span_p, &Text::from(format!("the family `{}` is declared in {}; every tag of a family is declared in its family\'s module", &family_pg, &(if &owner_pi == &Text::lit("") {
                        Text::lit("the root")
                    } else {
                        Text::from(format!("`{}`", &owner_pi))
                    }))))
                } else {
                    st_p1.clone()
                };
                let is_elem_pk = match &*t_pe.of_type_p.kind_p {
                    crate::syntax::TypeKind::TName(n_pm, _) => &crate::check::env::dotted_f(&n_pm.path_p) == &Text::lit("Element"),
                    _ => false,
                };
                let g2_pl = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.families_p = crate::prelude::insert(&this.families_p, &family_pg, &crate::prelude::push(&tags_ph, &name_pf));
                    this.fam_owner_p = crate::prelude::insert(&this.fam_owner_p, &family_pg, &owner_pi);
                    if is_elem_pk {
                        this.elem_fams_p = crate::check::types::add_text_f(&this.elem_fams_p, &family_pg);
                    }
                    this
                };
                prism_rtl::Turn::Finished((g2_pl.clone(), st2_pj.clone(), None))
            },
            crate::syntax::decls::DeclKind::DTrait(t_pn) => {
                let name_po = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_pn.name_p.path_p));
                let ti_pp = crate::check::env::TraitInfo { name_p: name_po.clone(), home_p: info_p2.name_p.clone(), param_p: crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&t_pn.params_p, &(|p_pr: &crate::syntax::Ident| p_pr.name_p.clone())), &Nat::from(0u32)), &Text::lit("a")), supers_p: Array::new(), methods_p: Array::new(), defaults_p: Array::new(), assocs_p: Array::new(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone() };
                let upd_pq = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.traits_p = crate::prelude::insert(&this.traits_p, &name_po, &ti_pp);
                    this
                };
                prism_rtl::Turn::Finished((upd_pq.clone(), st_p1.clone(), None))
            },
            _ => prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone(), None)),
        }
    }
}

/// `Start CollectDecl, x`: what the function value is when passed to `@Run`.
pub fn start_collect_decl_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo, d_p3: crate::syntax::decls::Decl, last_type_o4: Option<Text>) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Option<Text>)>> {
    Rc::new(CollectDecl { g_p0, st_p1, info_p2, d_p3, last_type_o4 })
}

/// ```prism
/// let dummyTyInfo
/// ```
pub fn dummy_ty_info_p() -> crate::check::env::TyInfo {
    crate::check::env::TyInfo { name_p: Text::lit(""), home_p: Text::lit(""), params_p: Array::new(), body_p: crate::check::env::TyBody::BOpaque, derives_p: Array::new(), file_p: Nat::from(0u32), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }
}

/// ```prism
/// AddDerives: fn TyInfo, [Text] -> TyInfo
/// ```
pub fn add_derives_f(ti_p0: &crate::check::env::TyInfo, trs_p1: &Array<Text>) -> crate::check::env::TyInfo {
    let mut this: crate::check::env::TyInfo = ti_p0.clone();
    this.derives_p = crate::prelude::append(&this.derives_p, trs_p1);
    this
}

/// ```prism
/// ProgramRow: fn G -> Rw
/// ```
pub fn program_row_f(g_p0: &crate::check::env::G) -> crate::check::types::Rw {
    crate::check::types::closed_f(&g_p0.elem_fams_p)
}

/// ```prism
/// BuildTables: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn build_tables_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, m_p2: &Text) -> (crate::check::env::G, crate::check::types::St) {
    match crate::prelude::get(&g_p0.mods_p, m_p2) {
        None => (g_p0.clone(), st_p1.clone()),
        Some(info_p3) => {
            let s0_p4 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file_p = info_p3.file_p.clone();
                this
            };
            let s1_p5 = crate::prelude::fold(&info_p3.uses_p, &s0_p4, &(|s_pd: &crate::check::types::St, (u_pe, _): &(Text, bool)| if crate::check::env::has_key_f(&g_p0.mods_p, u_pe) || (u_pe == &Text::lit("Prelude")) {
                s_pd.clone()
            } else {
                crate::check::types::recording::err_f(s_pd, &Text::lit("unknown-name"), &info_p3.tree_p.span_p, &Text::from(format!("no module `{}` among the program\'s files", u_pe)))
            }));
            let starred_p6 = crate::prelude::fold(&info_p3.uses_p, &Array::new(), &(|acc_pf: &Array<Text>, (u_pg, star_ph): &(Text, bool)| if *star_ph && (u_pg != m_p2) {
                crate::prelude::push(acc_pf, u_pg)
            } else {
                acc_pf.clone()
            }));
            let sources_p7 = crate::check::types::add_text_f(&crate::prelude::append(&Array::from(vec![m_p2.clone()]), &starred_p6), &Text::lit("Prelude"));
            let vals_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(sources_p7.clone(), Map::new(), {
                let g_p0x = g_p0.clone();
                Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                    let g_p0xy = g_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pi = p0;
                        let src_pj = p1;
                        prism_rtl::Turn::More(Rc::new(BareValuesOf { g_p0: g_p0xy.clone(), src_p1: src_pj.clone(), acc_p2: acc_pi.clone() }))
                    }))
                }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
            }));
            let tys_p9 = crate::prelude::fold(&sources_p7, &Map::new(), &(|acc_pk: &Map<Text, Array<Text>>, src_pl: &Text| bare_types_of_f(g_p0, src_pl, acc_pk)));
            let trs_pa = crate::prelude::fold(&sources_p7, &Map::new(), &(|acc_pm: &Map<Text, Array<Text>>, src_pn: &Text| bare_traits_of_f(g_p0, src_pn, acc_pm)));
            let (rw_po, rv_pp, s2_pq) = module_row_f(g_p0, &s1_p5, &info_p3);
            let info2_pb = {
                let mut this: crate::check::env::ModInfo = info_p3.clone();
                this.emit_rw_p = rw_po.clone();
                this.row_var_p = rv_pp.clone();
                this
            };
            let upd_pc = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.bare_p = crate::prelude::insert(&this.bare_p, m_p2, &vals_p8);
                this.bare_types_p = crate::prelude::insert(&this.bare_types_p, m_p2, &tys_p9);
                this.bare_traits_p = crate::prelude::insert(&this.bare_traits_p, m_p2, &trs_pa);
                this.mods_p = crate::prelude::insert(&this.mods_p, m_p2, &info2_pb);
                this
            };
            (upd_pc.clone(), s2_pq.clone())
        },
    }
}

/// The step machine of `BuildTables`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildTables: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct BuildTables {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub m_p2: Text,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for BuildTables {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let m_p2 = &self.m_p2;
        match crate::prelude::get(&g_p0.mods_p, m_p2) {
            None => prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
            Some(info_p3) => {
                let s0_p4 = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.file_p = info_p3.file_p.clone();
                    this
                };
                let s1_p5 = crate::prelude::fold(&info_p3.uses_p, &s0_p4, &(|s_pd: &crate::check::types::St, (u_pe, _): &(Text, bool)| if crate::check::env::has_key_f(&g_p0.mods_p, u_pe) || (u_pe == &Text::lit("Prelude")) {
                    s_pd.clone()
                } else {
                    crate::check::types::recording::err_f(s_pd, &Text::lit("unknown-name"), &info_p3.tree_p.span_p, &Text::from(format!("no module `{}` among the program\'s files", u_pe)))
                }));
                let starred_p6 = crate::prelude::fold(&info_p3.uses_p, &Array::new(), &(|acc_pf: &Array<Text>, (u_pg, star_ph): &(Text, bool)| if *star_ph && (u_pg != m_p2) {
                    crate::prelude::push(acc_pf, u_pg)
                } else {
                    acc_pf.clone()
                }));
                let sources_p7 = crate::check::types::add_text_f(&crate::prelude::append(&Array::from(vec![m_p2.clone()]), &starred_p6), &Text::lit("Prelude"));
                let g_p0x = g_p0.clone();
                let m_p2x = m_p2.clone();
                crate::prelude::call_value(crate::prelude::fold_job(sources_p7.clone(), Map::new(), {
                    let g_p0xx = g_p0x.clone();
                    Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                        let g_p0xxy = g_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pi = p0;
                            let src_pj = p1;
                            prism_rtl::Turn::More(Rc::new(BareValuesOf { g_p0: g_p0xxy.clone(), src_p1: src_pj.clone(), acc_p2: acc_pi.clone() }))
                        }))
                    }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
                }), move |fold_4611: Map<Text, Array<Text>>| {
                    let vals_p8 = fold_4611;
                    let tys_p9 = crate::prelude::fold(&sources_p7, &Map::new(), &(|acc_pk: &Map<Text, Array<Text>>, src_pl: &Text| bare_types_of_f(&g_p0x, src_pl, acc_pk)));
                    let trs_pa = crate::prelude::fold(&sources_p7, &Map::new(), &(|acc_pm: &Map<Text, Array<Text>>, src_pn: &Text| bare_traits_of_f(&g_p0x, src_pn, acc_pm)));
                    crate::prelude::call_then(start_module_row_f(g_p0x.clone(), s1_p5.clone(), info_p3.clone()), move |module_row_f_4840: (crate::check::types::Rw, Text, crate::check::types::St)| {
                        let (rw_po, rv_pp, s2_pq) = module_row_f_4840;
                        let info2_pb = {
                            let mut this: crate::check::env::ModInfo = info_p3.clone();
                            this.emit_rw_p = rw_po.clone();
                            this.row_var_p = rv_pp.clone();
                            this
                        };
                        let upd_pc = {
                            let mut this: crate::check::env::G = g_p0x.clone();
                            this.bare_p = crate::prelude::insert(&this.bare_p, &m_p2x, &vals_p8);
                            this.bare_types_p = crate::prelude::insert(&this.bare_types_p, &m_p2x, &tys_p9);
                            this.bare_traits_p = crate::prelude::insert(&this.bare_traits_p, &m_p2x, &trs_pa);
                            this.mods_p = crate::prelude::insert(&this.mods_p, &m_p2x, &info2_pb);
                            this
                        };
                        prism_rtl::Turn::Finished((upd_pc.clone(), s2_pq.clone()))
                    })
                })
            },
        }
    }
}

/// `Start BuildTables, x`: what the function value is when passed to `@Run`.
pub fn start_build_tables_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, m_p2: Text) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(BuildTables { g_p0, st_p1, m_p2 })
}

/// ```prism
/// AddBare: fn (Text ==> [Text]), Text, Text -> (Text ==> [Text])
/// ```
pub fn add_bare_f(acc_p0: &Map<Text, Array<Text>>, name_p1: &Text, qk_p2: &Text) -> Map<Text, Array<Text>> {
    let have_p3 = crate::prelude::or(&crate::prelude::get(acc_p0, name_p1), &Array::new());
    if crate::check::types::has_text_f(&have_p3, qk_p2) {
        acc_p0.clone()
    } else {
        crate::prelude::insert(acc_p0, name_p1, &crate::prelude::push(&have_p3, qk_p2))
    }
}

/// ```prism
/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_values_of_f(g_p0: &crate::check::env::G, src_p1: &Text, acc_p2: &Map<Text, Array<Text>>) -> Map<Text, Array<Text>> {
    match crate::prelude::get(&g_p0.mods_p, src_p1) {
        None => acc_p2.clone(),
        Some(info_p3) => crate::prelude::run_to_end(crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), acc_p2.clone(), {
            let src_p1x = src_p1.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::syntax::decls::Decl)| {
                let src_p1xy = src_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p4 = p0;
                    let d_p5 = p1;
                    prism_rtl::Turn::More(Rc::new(BareOfDecl { m_p0: src_p1xy.clone(), acc_p1: a_p4.clone(), d_p2: d_p5.clone() }))
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        })),
    }
}

/// The step machine of `BareValuesOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub struct BareValuesOf {
    pub g_p0: crate::check::env::G,
    pub src_p1: Text,
    pub acc_p2: Map<Text, Array<Text>>,
}

impl prism_rtl::Job<Map<Text, Array<Text>>> for BareValuesOf {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<Text>>> {
        let g_p0 = &self.g_p0;
        let src_p1 = &self.src_p1;
        let acc_p2 = &self.acc_p2;
        match crate::prelude::get(&g_p0.mods_p, src_p1) {
            None => prism_rtl::Turn::Finished(acc_p2.clone()),
            Some(info_p3) => crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), acc_p2.clone(), {
                let src_p1x = src_p1.clone();
                Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::syntax::decls::Decl)| {
                    let src_p1xy = src_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p4 = p0;
                        let d_p5 = p1;
                        prism_rtl::Turn::More(Rc::new(BareOfDecl { m_p0: src_p1xy.clone(), acc_p1: a_p4.clone(), d_p2: d_p5.clone() }))
                    }))
                }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
            }).cycle(),
        }
    }
}

/// `Start BareValuesOf, x`: what the function value is when passed to `@Run`.
pub fn start_bare_values_of_f(g_p0: crate::check::env::G, src_p1: Text, acc_p2: Map<Text, Array<Text>>) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>> {
    Rc::new(BareValuesOf { g_p0, src_p1, acc_p2 })
}

/// ```prism
/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
/// ```
pub fn bare_of_decl_f(m_p0: &Text, acc_p1: &Map<Text, Array<Text>>, d_p2: &crate::syntax::decls::Decl) -> Map<Text, Array<Text>> {
    match &d_p2.kind_p {
        crate::syntax::decls::DeclKind::DSignature(s_p3) => add_bare_f(acc_p1, &crate::check::env::def_name_text_f(&s_p3.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::def_name_text_f(&s_p3.name_p))),
        crate::syntax::decls::DeclKind::DFn(f_p4) => add_bare_f(acc_p1, &crate::check::env::def_name_text_f(&f_p4.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::def_name_text_f(&f_p4.name_p))),
        crate::syntax::decls::DeclKind::DLet(l_p5) => crate::prelude::fold(&pattern_names_f(&l_p5.pattern_p), acc_p1, &(|a_p6: &Map<Text, Array<Text>>, n_p7: &Text| add_bare_f(a_p6, n_p7, &crate::check::env::qual_key_f(m_p0, n_p7)))),
        crate::syntax::decls::DeclKind::DWidget(w_p8) => add_bare_f(acc_p1, &crate::check::env::sname_key_f(&w_p8.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::sname_key_f(&w_p8.name_p))),
        crate::syntax::decls::DeclKind::DType(t_p9) => crate::prelude::fold(&ctor_names_of_f(t_p9), acc_p1, &(|a_pa: &Map<Text, Array<Text>>, c_pb: &Text| add_bare_f(a_pa, c_pb, &crate::check::env::qual_key_f(m_p0, c_pb)))),
        crate::syntax::decls::DeclKind::DTrait(t_pc) => crate::prelude::fold(&t_pc.items_p, acc_p1, &(|a_pd: &Map<Text, Array<Text>>, it_pe: &crate::syntax::decls::TraitItem| match it_pe {
            crate::syntax::decls::TraitItem::TiSignature(s_pf) => add_bare_f(a_pd, &crate::check::env::def_name_text_f(&s_pf.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::def_name_text_f(&s_pf.name_p))),
            _ => a_pd.clone(),
        })),
        _ => acc_p1.clone(),
    }
}

/// The step machine of `BareOfDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
/// ```
pub struct BareOfDecl {
    pub m_p0: Text,
    pub acc_p1: Map<Text, Array<Text>>,
    pub d_p2: crate::syntax::decls::Decl,
}

impl prism_rtl::Job<Map<Text, Array<Text>>> for BareOfDecl {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<Text>>> {
        let m_p0 = &self.m_p0;
        let acc_p1 = &self.acc_p1;
        let d_p2 = &self.d_p2;
        match &d_p2.kind_p {
            crate::syntax::decls::DeclKind::DSignature(s_p3) => prism_rtl::Turn::Finished(add_bare_f(acc_p1, &crate::check::env::def_name_text_f(&s_p3.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::def_name_text_f(&s_p3.name_p)))),
            crate::syntax::decls::DeclKind::DFn(f_p4) => prism_rtl::Turn::Finished(add_bare_f(acc_p1, &crate::check::env::def_name_text_f(&f_p4.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::def_name_text_f(&f_p4.name_p)))),
            crate::syntax::decls::DeclKind::DLet(l_p5) => {
                let acc_p1x = acc_p1.clone();
                let l_p5x = l_p5.clone();
                let m_p0x = m_p0.clone();
                crate::prelude::call_then(start_pattern_names_f(l_p5x.pattern_p.clone()), move |pattern_names_f_5985: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::fold(&pattern_names_f_5985, &acc_p1x, &(|a_p6: &Map<Text, Array<Text>>, n_p7: &Text| add_bare_f(a_p6, n_p7, &crate::check::env::qual_key_f(&m_p0x, n_p7))))))
            },
            crate::syntax::decls::DeclKind::DWidget(w_p8) => prism_rtl::Turn::Finished(add_bare_f(acc_p1, &crate::check::env::sname_key_f(&w_p8.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::sname_key_f(&w_p8.name_p)))),
            crate::syntax::decls::DeclKind::DType(t_p9) => prism_rtl::Turn::Finished(crate::prelude::fold(&ctor_names_of_f(t_p9), acc_p1, &(|a_pa: &Map<Text, Array<Text>>, c_pb: &Text| add_bare_f(a_pa, c_pb, &crate::check::env::qual_key_f(m_p0, c_pb))))),
            crate::syntax::decls::DeclKind::DTrait(t_pc) => prism_rtl::Turn::Finished(crate::prelude::fold(&t_pc.items_p, acc_p1, &(|a_pd: &Map<Text, Array<Text>>, it_pe: &crate::syntax::decls::TraitItem| match it_pe {
                crate::syntax::decls::TraitItem::TiSignature(s_pf) => add_bare_f(a_pd, &crate::check::env::def_name_text_f(&s_pf.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::def_name_text_f(&s_pf.name_p))),
                _ => a_pd.clone(),
            }))),
            _ => prism_rtl::Turn::Finished(acc_p1.clone()),
        }
    }
}

/// `Start BareOfDecl, x`: what the function value is when passed to `@Run`.
pub fn start_bare_of_decl_f(m_p0: Text, acc_p1: Map<Text, Array<Text>>, d_p2: crate::syntax::decls::Decl) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>> {
    Rc::new(BareOfDecl { m_p0, acc_p1, d_p2 })
}

/// ```prism
/// CtorNamesOf: fn TypeDecl -> [Text]
/// ```
pub fn ctor_names_of_f(t_p0: &crate::syntax::decls::TypeDecl) -> Array<Text> {
    match &t_p0.body_o {
        Some(crate::syntax::decls::TypeBody::TbRecord(_)) => Array::from(vec![crate::check::env::dotted_f(&t_p0.name_p.path_p)]),
        Some(crate::syntax::decls::TypeBody::TbChoice(cs_p1)) => crate::prelude::each(cs_p1, &(|c_p2: &crate::syntax::decls::Case_| crate::check::env::sname_key_f(&c_p2.name_p))),
        Some(crate::syntax::decls::TypeBody::TbNewtype(c_p3)) => Array::from(vec![crate::check::env::sname_key_f(&c_p3.name_p)]),
        Some(crate::syntax::decls::TypeBody::TbUnit(i_p4)) => Array::from(vec![i_p4.name_p.clone()]),
        _ => Array::new(),
    }
}

/// ```prism
/// PatternNames: unbounded fn Pattern -> [Text]
/// ```
pub fn pattern_names_f(p_p0: &crate::syntax::Pattern_) -> Array<Text> {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p1) => Array::from(vec![crate::check::env::sname_key_f(n_p1)]),
        crate::syntax::PatternKind::PCtor(_, ps_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let q_p4 = p1;
            crate::prelude::call_then(start_pattern_names_f(q_p4.clone()), move |pattern_names_f_6861: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &pattern_names_f_6861)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PRecord(_, fs_p5, _) => crate::prelude::run_to_end(crate::prelude::fold_job(fs_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::FieldPat)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p6 = p0;
            let f_p7 = p1;
            crate::prelude::call_then(start_pattern_names_f(f_p7.pattern_p.clone()), move |pattern_names_f_6947: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &pattern_names_f_6947)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PSigil(_, q_p8) => pattern_names_f(&**q_p8),
        crate::syntax::PatternKind::PTuple(ps_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p9.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pa = p0;
            let q_pb = p1;
            crate::prelude::call_then(start_pattern_names_f(q_pb.clone()), move |pattern_names_f_7061: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pa, &pattern_names_f_7061)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PArray(ps_pc) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pc.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pd = p0;
            let q_pe = p1;
            crate::prelude::call_then(start_pattern_names_f(q_pe.clone()), move |pattern_names_f_7130: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pd, &pattern_names_f_7130)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PGroup(q_pf) => pattern_names_f(&**q_pf),
        _ => Array::new(),
    }
}

/// The step machine of `PatternNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatternNames: unbounded fn Pattern -> [Text]
/// ```
pub struct PatternNames {
    pub p_p0: crate::syntax::Pattern_,
}

impl prism_rtl::Job<Array<Text>> for PatternNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let p_p0 = &self.p_p0;
        match &*p_p0.kind_p {
            crate::syntax::PatternKind::PName(n_p1) => prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::sname_key_f(n_p1)])),
            crate::syntax::PatternKind::PCtor(_, ps_p2) => crate::prelude::fold_job(ps_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let q_p4 = p1;
                crate::prelude::call_then(start_pattern_names_f(q_p4.clone()), move |pattern_names_f_6861: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &pattern_names_f_6861)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PRecord(_, fs_p5, _) => crate::prelude::fold_job(fs_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::FieldPat)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let f_p7 = p1;
                crate::prelude::call_then(start_pattern_names_f(f_p7.pattern_p.clone()), move |pattern_names_f_6947: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &pattern_names_f_6947)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PSigil(_, q_p8) => prism_rtl::Turn::More(Rc::new(PatternNames { p_p0: (**q_p8).clone() })),
            crate::syntax::PatternKind::PTuple(ps_p9) => crate::prelude::fold_job(ps_p9.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pa = p0;
                let q_pb = p1;
                crate::prelude::call_then(start_pattern_names_f(q_pb.clone()), move |pattern_names_f_7061: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pa, &pattern_names_f_7061)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PArray(ps_pc) => crate::prelude::fold_job(ps_pc.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pd = p0;
                let q_pe = p1;
                crate::prelude::call_then(start_pattern_names_f(q_pe.clone()), move |pattern_names_f_7130: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pd, &pattern_names_f_7130)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PGroup(q_pf) => prism_rtl::Turn::More(Rc::new(PatternNames { p_p0: (**q_pf).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatternNames, x`: what the function value is when passed to `@Run`.
pub fn start_pattern_names_f(p_p0: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatternNames { p_p0 })
}

/// ```prism
/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
/// ```
pub fn pattern_binders_f(p_p0: &crate::syntax::Pattern_) -> Array<(Text, crate::syntax::Range)> {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p1) => Array::from(vec![(crate::check::env::sname_key_f(n_p1), n_p1.span_p.clone())]),
        crate::syntax::PatternKind::PCtor(_, ps_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let q_p4 = p1;
            crate::prelude::call_then(start_pattern_binders_f(q_p4.clone()), move |pattern_binders_f_7450: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &pattern_binders_f_7450)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PRecord(_, fs_p5, _) => crate::prelude::run_to_end(crate::prelude::fold_job(fs_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p6 = p0;
            let f_p7 = p1;
            crate::prelude::call_then(start_pattern_binders_f(f_p7.pattern_p.clone()), move |pattern_binders_f_7538: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &pattern_binders_f_7538)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PSigil(_, q_p8) => pattern_binders_f(&**q_p8),
        crate::syntax::PatternKind::PTuple(ps_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p9.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pa = p0;
            let q_pb = p1;
            crate::prelude::call_then(start_pattern_binders_f(q_pb.clone()), move |pattern_binders_f_7656: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pa, &pattern_binders_f_7656)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PArray(ps_pc) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pc.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pd = p0;
            let q_pe = p1;
            crate::prelude::call_then(start_pattern_binders_f(q_pe.clone()), move |pattern_binders_f_7727: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pd, &pattern_binders_f_7727)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PGroup(q_pf) => pattern_binders_f(&**q_pf),
        _ => Array::new(),
    }
}

/// The step machine of `PatternBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
/// ```
pub struct PatternBinders {
    pub p_p0: crate::syntax::Pattern_,
}

impl prism_rtl::Job<Array<(Text, crate::syntax::Range)>> for PatternBinders {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, crate::syntax::Range)>> {
        let p_p0 = &self.p_p0;
        match &*p_p0.kind_p {
            crate::syntax::PatternKind::PName(n_p1) => prism_rtl::Turn::Finished(Array::from(vec![(crate::check::env::sname_key_f(n_p1), n_p1.span_p.clone())])),
            crate::syntax::PatternKind::PCtor(_, ps_p2) => crate::prelude::fold_job(ps_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let q_p4 = p1;
                crate::prelude::call_then(start_pattern_binders_f(q_p4.clone()), move |pattern_binders_f_7450: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &pattern_binders_f_7450)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PRecord(_, fs_p5, _) => crate::prelude::fold_job(fs_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let f_p7 = p1;
                crate::prelude::call_then(start_pattern_binders_f(f_p7.pattern_p.clone()), move |pattern_binders_f_7538: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &pattern_binders_f_7538)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PSigil(_, q_p8) => prism_rtl::Turn::More(Rc::new(PatternBinders { p_p0: (**q_p8).clone() })),
            crate::syntax::PatternKind::PTuple(ps_p9) => crate::prelude::fold_job(ps_p9.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pa = p0;
                let q_pb = p1;
                crate::prelude::call_then(start_pattern_binders_f(q_pb.clone()), move |pattern_binders_f_7656: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pa, &pattern_binders_f_7656)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PArray(ps_pc) => crate::prelude::fold_job(ps_pc.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pd = p0;
                let q_pe = p1;
                crate::prelude::call_then(start_pattern_binders_f(q_pe.clone()), move |pattern_binders_f_7727: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pd, &pattern_binders_f_7727)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PGroup(q_pf) => prism_rtl::Turn::More(Rc::new(PatternBinders { p_p0: (**q_pf).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatternBinders, x`: what the function value is when passed to `@Run`.
pub fn start_pattern_binders_f(p_p0: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>> {
    Rc::new(PatternBinders { p_p0 })
}

/// ```prism
/// BareTypesOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_types_of_f(g_p0: &crate::check::env::G, src_p1: &Text, acc_p2: &Map<Text, Array<Text>>) -> Map<Text, Array<Text>> {
    crate::prelude::fold(&crate::prelude::keys(&g_p0.types_p), acc_p2, &(|a_p3: &Map<Text, Array<Text>>, k_p4: &Text| match crate::prelude::get(&g_p0.types_p, k_p4) {
        Some(ti_p5) => if &ti_p5.home_p == src_p1 {
            add_bare_f(a_p3, &crate::check::types::bare_name_f(&ti_p5.name_p), k_p4)
        } else {
            a_p3.clone()
        },
        None => a_p3.clone(),
    }))
}

/// ```prism
/// BareTraitsOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_traits_of_f(g_p0: &crate::check::env::G, src_p1: &Text, acc_p2: &Map<Text, Array<Text>>) -> Map<Text, Array<Text>> {
    crate::prelude::fold(&crate::prelude::keys(&g_p0.traits_p), acc_p2, &(|a_p3: &Map<Text, Array<Text>>, k_p4: &Text| match crate::prelude::get(&g_p0.traits_p, k_p4) {
        Some(ti_p5) => if &ti_p5.home_p == src_p1 {
            add_bare_f(a_p3, &crate::check::types::bare_name_f(&ti_p5.name_p), k_p4)
        } else {
            a_p3.clone()
        },
        None => a_p3.clone(),
    }))
}

/// ```prism
/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
/// ```
pub fn module_row_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo) -> (crate::check::types::Rw, Text, crate::check::types::St) {
    match &info_p2.tree_p.emit_row_o {
        None => if info_p2.root_p {
            (g_p0.program_row_p.clone(), Text::lit(""), st_p1.clone())
        } else {
            (crate::check::types::empty_row_p(), Text::lit(""), crate::check::types::recording::err_f(st_p1, &Text::lit("emit-element"), &info_p2.tree_p.span_p, &Text::lit("a library writes its own row; this one writes no `emit` line")))
        },
        Some(row_decl_p3) => {
            let (fams_pa, vars_pb, s2_pc) = crate::prelude::fold(&row_decl_p3.terms_p, &(Array::new(), Array::new(), st_p1.clone()), &(|(fs_p6, vs_p7, s_p8): &(Array<Text>, Array<Text>, crate::check::types::St), term_p9: &crate::syntax::RowTerm| row_term_of_f(g_p0, s_p8, info_p2, term_p9, fs_p6, vs_p7)));
            let s3_p4 = if &crate::prelude::len(&vars_pb) > &Nat::from(1u32) {
                crate::check::types::recording::err_fix_f(&s2_pc, &Text::lit("row-two-tails"), &row_decl_p3.span_p, &Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::chars::join_f(&vars_pb, &Text::lit(" | ")))), &Text::lit("keep one variable"))
            } else {
                s2_pc.clone()
            };
            let tail_p5 = match crate::prelude::index(&vars_pb, &Nat::from(0u32)) {
                Some(v_pd) => crate::check::types::Tail::TlQ(v_pd),
                None => crate::check::types::Tail::TlClosed,
            };
            (crate::check::types::Rw { fams_p: crate::check::types::sort_texts_f(&fams_pa), minus_p: Array::new(), tail_p: tail_p5.clone() }, crate::prelude::or(&crate::prelude::index(&vars_pb, &Nat::from(0u32)), &Text::lit("")), s3_p4.clone())
        },
    }
}

/// The step machine of `ModuleRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
/// ```
pub struct ModuleRow {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
}

impl prism_rtl::Job<(crate::check::types::Rw, Text, crate::check::types::St)> for ModuleRow {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Rw, Text, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        match &info_p2.tree_p.emit_row_o {
            None => if info_p2.root_p {
                prism_rtl::Turn::Finished((g_p0.program_row_p.clone(), Text::lit(""), st_p1.clone()))
            } else {
                prism_rtl::Turn::Finished((crate::check::types::empty_row_p(), Text::lit(""), crate::check::types::recording::err_f(st_p1, &Text::lit("emit-element"), &info_p2.tree_p.span_p, &Text::lit("a library writes its own row; this one writes no `emit` line"))))
            },
            Some(row_decl_p3) => {
                let (fams_pa, vars_pb, s2_pc) = crate::prelude::fold(&row_decl_p3.terms_p, &(Array::new(), Array::new(), st_p1.clone()), &(|(fs_p6, vs_p7, s_p8): &(Array<Text>, Array<Text>, crate::check::types::St), term_p9: &crate::syntax::RowTerm| row_term_of_f(g_p0, s_p8, info_p2, term_p9, fs_p6, vs_p7)));
                let s3_p4 = if &crate::prelude::len(&vars_pb) > &Nat::from(1u32) {
                    crate::check::types::recording::err_fix_f(&s2_pc, &Text::lit("row-two-tails"), &row_decl_p3.span_p, &Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::chars::join_f(&vars_pb, &Text::lit(" | ")))), &Text::lit("keep one variable"))
                } else {
                    s2_pc.clone()
                };
                let tail_p5 = match crate::prelude::index(&vars_pb, &Nat::from(0u32)) {
                    Some(v_pd) => crate::check::types::Tail::TlQ(v_pd),
                    None => crate::check::types::Tail::TlClosed,
                };
                prism_rtl::Turn::Finished((crate::check::types::Rw { fams_p: crate::check::types::sort_texts_f(&fams_pa), minus_p: Array::new(), tail_p: tail_p5.clone() }, crate::prelude::or(&crate::prelude::index(&vars_pb, &Nat::from(0u32)), &Text::lit("")), s3_p4.clone()))
            },
        }
    }
}

/// `Start ModuleRow, x`: what the function value is when passed to `@Run`.
pub fn start_module_row_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo) -> Rc<dyn prism_rtl::Job<(crate::check::types::Rw, Text, crate::check::types::St)>> {
    Rc::new(ModuleRow { g_p0, st_p1, info_p2 })
}

/// ```prism
/// RowTermOf: fn G, St, ModInfo, RowTerm, [Text], [Text] -> (([Text], [Text], St))
/// ```
pub fn row_term_of_f(g_p0: &crate::check::env::G, s_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, term_p3: &crate::syntax::RowTerm, fs_p4: &Array<Text>, vs_p5: &Array<Text>) -> (Array<Text>, Array<Text>, crate::check::types::St) {
    match term_p3 {
        crate::syntax::RowTerm::RFamily(q_p6) => (crate::prelude::push(fs_p4, &crate::check::env::dotted_f(&q_p6.path_p)), vs_p5.clone(), check_family_f(g_p0, s_p1, &crate::check::env::dotted_f(&q_p6.path_p), &q_p6.span_p)),
        crate::syntax::RowTerm::RVar(v_p7) => (fs_p4.clone(), crate::prelude::push(vs_p5, &v_p7.name_p), s_p1.clone()),
        crate::syntax::RowTerm::RType(t_p8) => match &*t_p8.kind_p {
            crate::syntax::TypeKind::TName(n_p9, m9527_0_1) if (m9527_0_1.len() == 0) => {
                let name_pa = crate::check::env::dotted_f(&n_p9.path_p);
                if (&name_pa == &Text::lit("Element")) && info_p2.root_p {
                    (crate::prelude::append(fs_p4, &g_p0.program_row_p.fams_p), vs_p5.clone(), s_p1.clone())
                } else {
                    if &name_pa == &Text::lit("Element") {
                        (fs_p4.clone(), vs_p5.clone(), crate::check::types::recording::err_f(s_p1, &Text::lit("emit-element"), &t_p8.span_p, &Text::lit("a library writes its own row; `emit Element` names the program\'s")))
                    } else {
                        if crate::check::env::has_key_f(&g_p0.tags_p, &name_pa) || (&crate::prelude::len(&n_p9.path_p) > &Nat::from(1u32)) {
                            (fs_p4.clone(), vs_p5.clone(), crate::check::types::recording::err_fix_f(s_p1, &Text::lit("row-single-tag"), &t_p8.span_p, &Text::from(format!("a row names families, not tags: `{}`", &name_pa)), &Text::from(format!("write `{}.*`", &crate::check::env::dotted_f(&crate::prelude::take(&n_p9.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&n_p9.path_p))))))))
                        } else {
                            (fs_p4.clone(), vs_p5.clone(), crate::check::types::recording::err_f(s_p1, &Text::lit("kind"), &t_p8.span_p, &Text::from(format!("`{}` is not a row", &name_pa))))
                        }
                    }
                }
            },
            _ => (fs_p4.clone(), vs_p5.clone(), crate::check::types::recording::err_f(s_p1, &Text::lit("kind"), &t_p8.span_p, &Text::lit("this is not a row"))),
            _ => unreachable!("no arm matched"),
        },
    }
}

/// ```prism
/// CheckFamily: fn G, St, Text, Range -> St
/// ```
pub fn check_family_f(g_p0: &crate::check::env::G, s_p1: &crate::check::types::St, fam_p2: &Text, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    if crate::check::env::has_key_f(&g_p0.families_p, fam_p2) {
        s_p1.clone()
    } else {
        crate::check::types::recording::err_f(s_p1, &Text::lit("unknown-name"), span_p3, &Text::from(format!("no family `{}`: no module declares a `{}.` tag", fam_p2, fam_p2)))
    }
}

/// ```prism
/// ResolveValue: fn G, Text, SName -> ((?Text, Text))
/// ```
pub fn resolve_value_f(g_p0: &crate::check::env::G, m_p1: &Text, n_p2: &crate::syntax::SName) -> (Option<Text>, Text) {
    let marks_p3 = n_p2.sigils_p.clone();
    if &crate::prelude::len(&n_p2.path_p) == &Nat::from(1u32) {
        {
            let name_p4 = Text::from(format!("{}{}", &marks_p3, &crate::prelude::or(&crate::prelude::index(&n_p2.path_p, &Nat::from(0u32)), &Text::lit(""))));
            let table_p5 = crate::prelude::or(&crate::prelude::get(&g_p0.bare_p, m_p1), &Map::new());
            let keys_p6 = crate::prelude::or(&crate::prelude::get(&table_p5, &name_p4), &Array::new());
            if &crate::prelude::len(&keys_p6) == &Nat::from(1u32) {
                (crate::prelude::index(&keys_p6, &Nat::from(0u32)), Text::lit(""))
            } else {
                if &crate::prelude::len(&keys_p6) > &Nat::from(1u32) {
                    (Some(own_first_f(m_p1, &keys_p6)), Text::lit("collision"))
                } else {
                    if &name_p4 == &Text::lit("never") {
                        (Some(Text::lit("Prelude.never")), Text::lit(""))
                    } else {
                        if crate::check::env::has_key_f(&g_p0.ctors_p, &name_p4) {
                            (Some(name_p4.clone()), Text::lit(""))
                        } else {
                            (None, Text::lit("unknown"))
                        }
                    }
                }
            }
        }
    } else {
        {
            let qual_p7 = crate::check::env::qual_module_f(g_p0, &crate::prelude::take(&n_p2.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&n_p2.path_p))));
            let last_p8 = crate::prelude::or(&crate::syntax::lexer::chars::last_o(&n_p2.path_p), &Text::lit(""));
            let qk_p9 = crate::check::env::qual_key_f(&qual_p7, &Text::from(format!("{}{}", &marks_p3, &last_p8)));
            if (&crate::prelude::len_text(&marks_p3) == &Nat::from(0u32)) && crate::check::env::has_key_f(&g_p0.tags_p, &crate::check::env::dotted_f(&n_p2.path_p)) {
                (Some(crate::check::env::dotted_f(&n_p2.path_p)), Text::lit("tag"))
            } else {
                if crate::check::env::has_key_f(&g_p0.vals_p, &qk_p9) || crate::check::env::has_key_f(&g_p0.ctors_p, &qk_p9) {
                    (Some(qk_p9.clone()), Text::lit(""))
                } else {
                    (None, Text::lit("unknown"))
                }
            }
        }
    }
}

/// ```prism
/// ResolveType: fn G, Text, [Text] -> ((?Text, Text))
/// ```
pub fn resolve_type_f(g_p0: &crate::check::env::G, m_p1: &Text, path_p2: &Array<Text>) -> (Option<Text>, Text) {
    if &crate::prelude::len(path_p2) == &Nat::from(1u32) {
        {
            let keys_p3 = crate::prelude::or(&crate::prelude::get(&crate::prelude::or(&crate::prelude::get(&g_p0.bare_types_p, m_p1), &Map::new()), &crate::prelude::or(&crate::prelude::index(path_p2, &Nat::from(0u32)), &Text::lit(""))), &Array::new());
            if &crate::prelude::len(&keys_p3) == &Nat::from(1u32) {
                (crate::prelude::index(&keys_p3, &Nat::from(0u32)), Text::lit(""))
            } else {
                if &crate::prelude::len(&keys_p3) > &Nat::from(1u32) {
                    (Some(own_first_f(m_p1, &keys_p3)), Text::lit("collision"))
                } else {
                    (None, Text::lit("unknown"))
                }
            }
        }
    } else {
        {
            let qk_p4 = crate::check::env::qual_key_f(&crate::check::env::qual_module_f(g_p0, &crate::prelude::take(path_p2, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(path_p2)))), &crate::prelude::or(&crate::syntax::lexer::chars::last_o(path_p2), &Text::lit("")));
            if crate::check::env::has_key_f(&g_p0.types_p, &qk_p4) {
                (Some(qk_p4.clone()), Text::lit(""))
            } else {
                (None, Text::lit("unknown"))
            }
        }
    }
}

/// ```prism
/// OwnFirst: fn Text, [Text] -> Text
/// ```
pub fn own_first_f(m_p0: &Text, keys_p1: &Array<Text>) -> Text {
    let own_p2 = crate::prelude::filter(keys_p1, &(|k_p3: &Text| (&crate::check::env::qual_key_f(m_p0, &crate::check::types::bare_name_f(k_p3)) == k_p3) || ((m_p0 == &Text::lit("")) && !crate::syntax::lexer::chars::contains_f(k_p3, &Text::lit(".")))));
    crate::prelude::or(&crate::prelude::index(&own_p2, &Nat::from(0u32)), &crate::prelude::or(&crate::prelude::index(keys_p1, &Nat::from(0u32)), &Text::lit("")))
}

/// ```prism
/// ?ResolveTrait: fn G, Text, [Text] -> ?Text
/// ```
pub fn resolve_trait_o(g_p0: &crate::check::env::G, m_p1: &Text, path_p2: &Array<Text>) -> Option<Text> {
    if &crate::prelude::len(path_p2) == &Nat::from(1u32) {
        {
            let keys_p3 = crate::prelude::or(&crate::prelude::get(&crate::prelude::or(&crate::prelude::get(&g_p0.bare_traits_p, m_p1), &Map::new()), &crate::prelude::or(&crate::prelude::index(path_p2, &Nat::from(0u32)), &Text::lit(""))), &Array::new());
            crate::prelude::index(&keys_p3, &Nat::from(0u32))
        }
    } else {
        {
            let qk_p4 = crate::check::env::qual_key_f(&crate::check::env::qual_module_f(g_p0, &crate::prelude::take(path_p2, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(path_p2)))), &crate::prelude::or(&crate::syntax::lexer::chars::last_o(path_p2), &Text::lit("")));
            if crate::check::env::has_key_f(&g_p0.traits_p, &qk_p4) {
                Some(qk_p4.clone())
            } else {
                None
            }
        }
    }
}
