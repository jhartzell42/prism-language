//! The module `Check.Env.Names`, from `target/bootstrap/src/prismc/check/env/names.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// CollectNames: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn collect_names(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, m_p2: &Text) -> (crate::check::env::G, crate::check::types::St) {
    match get(&g_p0.mods, m_p2) {
        None => (g_p0.clone(), st_p1.clone()),
        Some(info_p3) => {
            let s0_p4 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file = info_p3.file.clone();
                this
            };
            let (g2_p9, s2_pa, _) = run_to_end(fold_job(info_p3.tree.decls.clone(), (g_p0.clone(), s0_p4.clone(), None), {
                let info_p3 = info_p3.clone();
                Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St, Option<Text>), crate::syntax::decls::Decl)| {
                    let info_p3 = info_p3.clone();
                    entered(once_job(move || {
                        let (gg_p5, s_p6, last_type_o7) = p0;
                        let d_p8 = p1;
                        prism_rtl::Turn::More(Rc::new(CollectDecl { g_p0: gg_p5.clone(), st_p1: s_p6.clone(), info_p2: info_p3.clone(), d_p3: d_p8.clone(), last_type_o4: last_type_o7.clone() }))
                    }))
                }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St, Option<Text>), crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Option<Text>)>>>
            }));
            (g2_p9.clone(), s2_pa.clone())
        },
    }
}

/// The step machine of `CollectNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollectNames: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct CollectNames {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub m_p2: Text,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for CollectNames {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let m_p2 = &self.m_p2;
        match get(&g_p0.mods, m_p2) {
            None => prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
            Some(info_p3) => {
                let s0_p4 = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.file = info_p3.file.clone();
                    this
                };
                let g_p0 = g_p0.clone();
                call_value(fold_job(info_p3.tree.decls.clone(), (g_p0.clone(), s0_p4.clone(), None), {
                    let info_p3 = info_p3.clone();
                    Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St, Option<Text>), crate::syntax::decls::Decl)| {
                        let info_p3 = info_p3.clone();
                        entered(once_job(move || {
                            let (gg_p5, s_p6, last_type_o7) = p0;
                            let d_p8 = p1;
                            prism_rtl::Turn::More(Rc::new(CollectDecl { g_p0: gg_p5.clone(), st_p1: s_p6.clone(), info_p2: info_p3.clone(), d_p3: d_p8.clone(), last_type_o4: last_type_o7.clone() }))
                        }))
                    }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St, Option<Text>), crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Option<Text>)>>>
                }), move |fold_1030: (crate::check::env::G, crate::check::types::St, Option<Text>)| {
                    let (g2_p9, s2_pa, _) = fold_1030;
                    prism_rtl::Turn::Finished((g2_p9.clone(), s2_pa.clone()))
                })
            },
        }
    }
}

/// `Start CollectNames, x`: what the function value is when passed to `@Run`.
pub fn start_collect_names(g_p0: crate::check::env::G, st_p1: crate::check::types::St, m_p2: Text) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(CollectNames { g_p0, st_p1, m_p2 })
}

/// ```prism
/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
/// ```
pub fn collect_decl(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, d_p3: &crate::syntax::decls::Decl, last_type_o4: &Option<Text>) -> (crate::check::env::G, crate::check::types::St, Option<Text>) {
    match &d_p3.kind {
        crate::syntax::decls::DeclKind::DType(t_p5) => {
            let name_p6 = crate::check::env::qual_key(&info_p2.name, &crate::check::env::dotted(&t_p5.name.path_));
            let ti_p7 = crate::check::env::TyInfo { name: name_p6.clone(), home: info_p2.name.clone(), params: each(&t_p5.params, &(|p_p8: &crate::syntax::Ident| p_p8.name.clone())), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: info_p2.file.clone(), span: d_p3.span.clone() };
            if crate::check::env::has_key(&g_p0.types, &name_p6) {
                (g_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("collision"), &d_p3.span, &Text::from(format!("a second type `{}`", &crate::check::env::dotted(&t_p5.name.path_)))), last_type_o4.clone())
            } else {
                {
                    let upd_p9 = {
                        let mut this: crate::check::env::G = g_p0.clone();
                        this.types = insert(&this.types, &name_p6, &ti_p7);
                        this
                    };
                    (upd_p9.clone(), st_p1.clone(), Some(name_p6.clone()))
                }
            }
        },
        crate::syntax::decls::DeclKind::DDerive(trs_pa) => match last_type_o4 {
            Some(tn_pb) => {
                let upd_pc = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.types = insert(&this.types, tn_pb, &add_derives(&or(&get(&g_p0.types, tn_pb), &dummy_ty_info()), &each(trs_pa, &(|tr_pd: &crate::syntax::TraitRef| crate::check::env::dotted(&tr_pd.path_)))));
                    this
                };
                (upd_pc.clone(), st_p1.clone(), last_type_o4.clone())
            },
            None => (g_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &d_p3.span, &Text::lit("a `derive` line follows a type declaration")), None),
        },
        crate::syntax::decls::DeclKind::DTag(t_pe) => {
            let name_pf = crate::check::env::dotted(&t_pe.name.path_);
            let family_pg = crate::check::env::dotted(&take(&t_pe.name.path_, &crate::syntax::lexer::chars::dec(&len(&t_pe.name.path_))));
            let tags_ph = or(&get(&g_p0.families, &family_pg), &Array::new());
            let owner_pi = or(&get(&g_p0.fam_owner, &family_pg), &info_p2.name);
            let st2_pj = if &owner_pi != &info_p2.name {
                crate::check::types::recording::err(st_p1, &Text::lit("collision"), &d_p3.span, &Text::from(format!("the family `{}` is declared in {}; every tag of a family is declared in its family\'s module", &family_pg, &(if &owner_pi == &Text::lit("") {
                    Text::lit("the root")
                } else {
                    Text::from(format!("`{}`", &owner_pi))
                }))))
            } else {
                st_p1.clone()
            };
            let is_elem_pk = match &*t_pe.of_type.kind {
                crate::syntax::TypeKind::TName(n_pm, _) => &crate::check::env::dotted(&n_pm.path_) == &Text::lit("Element"),
                _ => false,
            };
            let g2_pl = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.families = insert(&this.families, &family_pg, &push(&tags_ph, &name_pf));
                this.fam_owner = insert(&this.fam_owner, &family_pg, &owner_pi);
                if is_elem_pk {
                    this.elem_fams = crate::check::types::add_text(&this.elem_fams, &family_pg);
                }
                this
            };
            (g2_pl.clone(), st2_pj.clone(), None)
        },
        crate::syntax::decls::DeclKind::DTrait(t_pn) => {
            let name_po = crate::check::env::qual_key(&info_p2.name, &crate::check::env::dotted(&t_pn.name.path_));
            let ti_pp = crate::check::env::TraitInfo { name: name_po.clone(), home: info_p2.name.clone(), param: or(&index(&each(&t_pn.params, &(|p_pr: &crate::syntax::Ident| p_pr.name.clone())), &Nat::from(0u32)), &Text::lit("a")), supers: Array::new(), methods: Array::new(), defaults: Array::new(), assocs: Array::new(), file: info_p2.file.clone(), span: d_p3.span.clone() };
            let upd_pq = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.traits = insert(&this.traits, &name_po, &ti_pp);
                this
            };
            (upd_pq.clone(), st_p1.clone(), None)
        },
        _ => (g_p0.clone(), st_p1.clone(), None),
    }
}

/// The step machine of `CollectDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
/// ```
pub struct CollectDecl {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
    pub d_p3: crate::syntax::decls::Decl,
    pub last_type_o4: Option<Text>,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Option<Text>)> for CollectDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St, Option<Text>)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        let d_p3 = &self.d_p3;
        let last_type_o4 = &self.last_type_o4;
        match &d_p3.kind {
            crate::syntax::decls::DeclKind::DType(t_p5) => {
                let name_p6 = crate::check::env::qual_key(&info_p2.name, &crate::check::env::dotted(&t_p5.name.path_));
                let ti_p7 = crate::check::env::TyInfo { name: name_p6.clone(), home: info_p2.name.clone(), params: each(&t_p5.params, &(|p_p8: &crate::syntax::Ident| p_p8.name.clone())), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: info_p2.file.clone(), span: d_p3.span.clone() };
                if crate::check::env::has_key(&g_p0.types, &name_p6) {
                    prism_rtl::Turn::Finished((g_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("collision"), &d_p3.span, &Text::from(format!("a second type `{}`", &crate::check::env::dotted(&t_p5.name.path_)))), last_type_o4.clone()))
                } else {
                    {
                        let upd_p9 = {
                            let mut this: crate::check::env::G = g_p0.clone();
                            this.types = insert(&this.types, &name_p6, &ti_p7);
                            this
                        };
                        prism_rtl::Turn::Finished((upd_p9.clone(), st_p1.clone(), Some(name_p6.clone())))
                    }
                }
            },
            crate::syntax::decls::DeclKind::DDerive(trs_pa) => match last_type_o4 {
                Some(tn_pb) => {
                    let upd_pc = {
                        let mut this: crate::check::env::G = g_p0.clone();
                        this.types = insert(&this.types, tn_pb, &add_derives(&or(&get(&g_p0.types, tn_pb), &dummy_ty_info()), &each(trs_pa, &(|tr_pd: &crate::syntax::TraitRef| crate::check::env::dotted(&tr_pd.path_)))));
                        this
                    };
                    prism_rtl::Turn::Finished((upd_pc.clone(), st_p1.clone(), last_type_o4.clone()))
                },
                None => prism_rtl::Turn::Finished((g_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &d_p3.span, &Text::lit("a `derive` line follows a type declaration")), None)),
            },
            crate::syntax::decls::DeclKind::DTag(t_pe) => {
                let name_pf = crate::check::env::dotted(&t_pe.name.path_);
                let family_pg = crate::check::env::dotted(&take(&t_pe.name.path_, &crate::syntax::lexer::chars::dec(&len(&t_pe.name.path_))));
                let tags_ph = or(&get(&g_p0.families, &family_pg), &Array::new());
                let owner_pi = or(&get(&g_p0.fam_owner, &family_pg), &info_p2.name);
                let st2_pj = if &owner_pi != &info_p2.name {
                    crate::check::types::recording::err(st_p1, &Text::lit("collision"), &d_p3.span, &Text::from(format!("the family `{}` is declared in {}; every tag of a family is declared in its family\'s module", &family_pg, &(if &owner_pi == &Text::lit("") {
                        Text::lit("the root")
                    } else {
                        Text::from(format!("`{}`", &owner_pi))
                    }))))
                } else {
                    st_p1.clone()
                };
                let is_elem_pk = match &*t_pe.of_type.kind {
                    crate::syntax::TypeKind::TName(n_pm, _) => &crate::check::env::dotted(&n_pm.path_) == &Text::lit("Element"),
                    _ => false,
                };
                let g2_pl = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.families = insert(&this.families, &family_pg, &push(&tags_ph, &name_pf));
                    this.fam_owner = insert(&this.fam_owner, &family_pg, &owner_pi);
                    if is_elem_pk {
                        this.elem_fams = crate::check::types::add_text(&this.elem_fams, &family_pg);
                    }
                    this
                };
                prism_rtl::Turn::Finished((g2_pl.clone(), st2_pj.clone(), None))
            },
            crate::syntax::decls::DeclKind::DTrait(t_pn) => {
                let name_po = crate::check::env::qual_key(&info_p2.name, &crate::check::env::dotted(&t_pn.name.path_));
                let ti_pp = crate::check::env::TraitInfo { name: name_po.clone(), home: info_p2.name.clone(), param: or(&index(&each(&t_pn.params, &(|p_pr: &crate::syntax::Ident| p_pr.name.clone())), &Nat::from(0u32)), &Text::lit("a")), supers: Array::new(), methods: Array::new(), defaults: Array::new(), assocs: Array::new(), file: info_p2.file.clone(), span: d_p3.span.clone() };
                let upd_pq = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.traits = insert(&this.traits, &name_po, &ti_pp);
                    this
                };
                prism_rtl::Turn::Finished((upd_pq.clone(), st_p1.clone(), None))
            },
            _ => prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone(), None)),
        }
    }
}

/// `Start CollectDecl, x`: what the function value is when passed to `@Run`.
pub fn start_collect_decl(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo, d_p3: crate::syntax::decls::Decl, last_type_o4: Option<Text>) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Option<Text>)>> {
    Rc::new(CollectDecl { g_p0, st_p1, info_p2, d_p3, last_type_o4 })
}

/// ```prism
/// let dummyTyInfo
/// ```
pub fn dummy_ty_info() -> crate::check::env::TyInfo {
    crate::check::env::TyInfo { name: Text::lit(""), home: Text::lit(""), params: Array::new(), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// AddDerives: fn TyInfo, [Text] -> TyInfo
/// ```
pub fn add_derives(ti_p0: &crate::check::env::TyInfo, trs_p1: &Array<Text>) -> crate::check::env::TyInfo {
    let mut this: crate::check::env::TyInfo = ti_p0.clone();
    this.derives = append(&this.derives, trs_p1);
    this
}

/// ```prism
/// ProgramRow: fn G -> Rw
/// ```
pub fn program_row(g_p0: &crate::check::env::G) -> crate::check::types::Rw {
    crate::check::types::closed(&g_p0.elem_fams)
}

/// ```prism
/// BuildTables: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn build_tables(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, m_p2: &Text) -> (crate::check::env::G, crate::check::types::St) {
    match get(&g_p0.mods, m_p2) {
        None => (g_p0.clone(), st_p1.clone()),
        Some(info_p3) => {
            let s0_p4 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file = info_p3.file.clone();
                this
            };
            let s1_p5 = fold(&info_p3.uses, &s0_p4, &(|s_pd: &crate::check::types::St, (u_pe, _): &(Text, bool)| if crate::check::env::has_key(&g_p0.mods, u_pe) || (u_pe == &Text::lit("Prelude")) {
                s_pd.clone()
            } else {
                crate::check::types::recording::err(s_pd, &Text::lit("unknown-name"), &info_p3.tree.span, &Text::from(format!("no module `{}` among the program\'s files", u_pe)))
            }));
            let starred_p6 = fold(&info_p3.uses, &Array::new(), &(|acc_pf: &Array<Text>, (u_pg, star_ph): &(Text, bool)| if *star_ph && (u_pg != m_p2) { push(acc_pf, u_pg) } else { acc_pf.clone() }));
            let sources_p7 = crate::check::types::add_text(&append(&Array::from(vec![m_p2.clone()]), &starred_p6), &Text::lit("Prelude"));
            let vals_p8 = run_to_end(fold_job(sources_p7.clone(), Map::new(), {
                let g_p0 = g_p0.clone();
                Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                    let g_p0 = g_p0.clone();
                    entered(once_job(move || {
                        let acc_pi = p0;
                        let src_pj = p1;
                        prism_rtl::Turn::More(Rc::new(BareValuesOf { g_p0: g_p0.clone(), src_p1: src_pj.clone(), acc_p2: acc_pi.clone() }))
                    }))
                }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
            }));
            let tys_p9 = fold(&sources_p7, &Map::new(), &(|acc_pk: &Map<Text, Array<Text>>, src_pl: &Text| bare_types_of(g_p0, src_pl, acc_pk)));
            let trs_pa = fold(&sources_p7, &Map::new(), &(|acc_pm: &Map<Text, Array<Text>>, src_pn: &Text| bare_traits_of(g_p0, src_pn, acc_pm)));
            let (rw_po, rv_pp, s2_pq) = module_row(g_p0, &s1_p5, &info_p3);
            let info2_pb = {
                let mut this: crate::check::env::ModInfo = info_p3.clone();
                this.emit_rw = rw_po.clone();
                this.row_var = rv_pp.clone();
                this
            };
            let upd_pc = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.bare = insert(&this.bare, m_p2, &vals_p8);
                this.bare_types = insert(&this.bare_types, m_p2, &tys_p9);
                this.bare_traits = insert(&this.bare_traits, m_p2, &trs_pa);
                this.mods = insert(&this.mods, m_p2, &info2_pb);
                this
            };
            (upd_pc.clone(), s2_pq.clone())
        },
    }
}

/// The step machine of `BuildTables`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildTables: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct BuildTables {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub m_p2: Text,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for BuildTables {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let m_p2 = &self.m_p2;
        match get(&g_p0.mods, m_p2) {
            None => prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
            Some(info_p3) => {
                let s0_p4 = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.file = info_p3.file.clone();
                    this
                };
                let s1_p5 = fold(&info_p3.uses, &s0_p4, &(|s_pd: &crate::check::types::St, (u_pe, _): &(Text, bool)| if crate::check::env::has_key(&g_p0.mods, u_pe) || (u_pe == &Text::lit("Prelude")) {
                    s_pd.clone()
                } else {
                    crate::check::types::recording::err(s_pd, &Text::lit("unknown-name"), &info_p3.tree.span, &Text::from(format!("no module `{}` among the program\'s files", u_pe)))
                }));
                let starred_p6 = fold(&info_p3.uses, &Array::new(), &(|acc_pf: &Array<Text>, (u_pg, star_ph): &(Text, bool)| if *star_ph && (u_pg != m_p2) { push(acc_pf, u_pg) } else { acc_pf.clone() }));
                let sources_p7 = crate::check::types::add_text(&append(&Array::from(vec![m_p2.clone()]), &starred_p6), &Text::lit("Prelude"));
                let g_p0 = g_p0.clone();
                let m_p2 = m_p2.clone();
                call_value(fold_job(sources_p7.clone(), Map::new(), {
                    let g_p0 = g_p0.clone();
                    Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                        let g_p0 = g_p0.clone();
                        entered(once_job(move || {
                            let acc_pi = p0;
                            let src_pj = p1;
                            prism_rtl::Turn::More(Rc::new(BareValuesOf { g_p0: g_p0.clone(), src_p1: src_pj.clone(), acc_p2: acc_pi.clone() }))
                        }))
                    }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
                }), move |fold_4611: Map<Text, Array<Text>>| {
                    let vals_p8 = fold_4611;
                    let tys_p9 = fold(&sources_p7, &Map::new(), &(|acc_pk: &Map<Text, Array<Text>>, src_pl: &Text| bare_types_of(&g_p0, src_pl, acc_pk)));
                    let trs_pa = fold(&sources_p7, &Map::new(), &(|acc_pm: &Map<Text, Array<Text>>, src_pn: &Text| bare_traits_of(&g_p0, src_pn, acc_pm)));
                    call_then(start_module_row(g_p0.clone(), s1_p5.clone(), info_p3.clone()), move |module_row_4840: (crate::check::types::Rw, Text, crate::check::types::St)| {
                        let (rw_po, rv_pp, s2_pq) = module_row_4840;
                        let info2_pb = {
                            let mut this: crate::check::env::ModInfo = info_p3.clone();
                            this.emit_rw = rw_po.clone();
                            this.row_var = rv_pp.clone();
                            this
                        };
                        let upd_pc = {
                            let mut this: crate::check::env::G = g_p0.clone();
                            this.bare = insert(&this.bare, &m_p2, &vals_p8);
                            this.bare_types = insert(&this.bare_types, &m_p2, &tys_p9);
                            this.bare_traits = insert(&this.bare_traits, &m_p2, &trs_pa);
                            this.mods = insert(&this.mods, &m_p2, &info2_pb);
                            this
                        };
                        prism_rtl::Turn::Finished((upd_pc.clone(), s2_pq.clone()))
                    })
                })
            },
        }
    }
}

/// `Start BuildTables, x`: what the function value is when passed to `@Run`.
pub fn start_build_tables(g_p0: crate::check::env::G, st_p1: crate::check::types::St, m_p2: Text) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(BuildTables { g_p0, st_p1, m_p2 })
}

/// ```prism
/// AddBare: fn (Text ==> [Text]), Text, Text -> (Text ==> [Text])
/// ```
pub fn add_bare(acc_p0: &Map<Text, Array<Text>>, name_p1: &Text, qk_p2: &Text) -> Map<Text, Array<Text>> {
    let have_p3 = or(&get(acc_p0, name_p1), &Array::new());
    if crate::check::types::has_text(&have_p3, qk_p2) {
        acc_p0.clone()
    } else {
        insert(acc_p0, name_p1, &push(&have_p3, qk_p2))
    }
}

/// ```prism
/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_values_of(g_p0: &crate::check::env::G, src_p1: &Text, acc_p2: &Map<Text, Array<Text>>) -> Map<Text, Array<Text>> {
    match get(&g_p0.mods, src_p1) {
        None => acc_p2.clone(),
        Some(info_p3) => run_to_end(fold_job(info_p3.tree.decls.clone(), acc_p2.clone(), {
            let src_p1 = src_p1.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::syntax::decls::Decl)| {
                let src_p1 = src_p1.clone();
                entered(once_job(move || {
                    let a_p4 = p0;
                    let d_p5 = p1;
                    prism_rtl::Turn::More(Rc::new(BareOfDecl { m_p0: src_p1.clone(), acc_p1: a_p4.clone(), d_p2: d_p5.clone() }))
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        })),
    }
}

/// The step machine of `BareValuesOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub struct BareValuesOf {
    pub g_p0: crate::check::env::G,
    pub src_p1: Text,
    pub acc_p2: Map<Text, Array<Text>>,
}

impl prism_rtl::Job<Map<Text, Array<Text>>> for BareValuesOf {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<Text>>> {
        let g_p0 = &self.g_p0;
        let src_p1 = &self.src_p1;
        let acc_p2 = &self.acc_p2;
        match get(&g_p0.mods, src_p1) {
            None => prism_rtl::Turn::Finished(acc_p2.clone()),
            Some(info_p3) => fold_job(info_p3.tree.decls.clone(), acc_p2.clone(), {
                let src_p1 = src_p1.clone();
                Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::syntax::decls::Decl)| {
                    let src_p1 = src_p1.clone();
                    entered(once_job(move || {
                        let a_p4 = p0;
                        let d_p5 = p1;
                        prism_rtl::Turn::More(Rc::new(BareOfDecl { m_p0: src_p1.clone(), acc_p1: a_p4.clone(), d_p2: d_p5.clone() }))
                    }))
                }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
            }).cycle(),
        }
    }
}

/// `Start BareValuesOf, x`: what the function value is when passed to `@Run`.
pub fn start_bare_values_of(g_p0: crate::check::env::G, src_p1: Text, acc_p2: Map<Text, Array<Text>>) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>> {
    Rc::new(BareValuesOf { g_p0, src_p1, acc_p2 })
}

/// ```prism
/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
/// ```
pub fn bare_of_decl(m_p0: &Text, acc_p1: &Map<Text, Array<Text>>, d_p2: &crate::syntax::decls::Decl) -> Map<Text, Array<Text>> {
    match &d_p2.kind {
        crate::syntax::decls::DeclKind::DSignature(s_p3) => add_bare(acc_p1, &crate::check::env::def_name_text(&s_p3.name), &crate::check::env::qual_key(m_p0, &crate::check::env::def_name_text(&s_p3.name))),
        crate::syntax::decls::DeclKind::DFn(f_p4) => add_bare(acc_p1, &crate::check::env::def_name_text(&f_p4.name), &crate::check::env::qual_key(m_p0, &crate::check::env::def_name_text(&f_p4.name))),
        crate::syntax::decls::DeclKind::DLet(l_p5) => fold(&pattern_names(&l_p5.pattern), acc_p1, &(|a_p6: &Map<Text, Array<Text>>, n_p7: &Text| add_bare(a_p6, n_p7, &crate::check::env::qual_key(m_p0, n_p7)))),
        crate::syntax::decls::DeclKind::DWidget(w_p8) => add_bare(acc_p1, &crate::check::env::sname_key(&w_p8.name), &crate::check::env::qual_key(m_p0, &crate::check::env::sname_key(&w_p8.name))),
        crate::syntax::decls::DeclKind::DType(t_p9) => fold(&ctor_names_of(t_p9), acc_p1, &(|a_pa: &Map<Text, Array<Text>>, c_pb: &Text| add_bare(a_pa, c_pb, &crate::check::env::qual_key(m_p0, c_pb)))),
        crate::syntax::decls::DeclKind::DTrait(t_pc) => fold(&t_pc.items, acc_p1, &(|a_pd: &Map<Text, Array<Text>>, it_pe: &crate::syntax::decls::TraitItem| match it_pe {
            crate::syntax::decls::TraitItem::TiSignature(s_pf) => add_bare(a_pd, &crate::check::env::def_name_text(&s_pf.name), &crate::check::env::qual_key(m_p0, &crate::check::env::def_name_text(&s_pf.name))),
            _ => a_pd.clone(),
        })),
        _ => acc_p1.clone(),
    }
}

/// The step machine of `BareOfDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
/// ```
pub struct BareOfDecl {
    pub m_p0: Text,
    pub acc_p1: Map<Text, Array<Text>>,
    pub d_p2: crate::syntax::decls::Decl,
}

impl prism_rtl::Job<Map<Text, Array<Text>>> for BareOfDecl {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<Text>>> {
        let m_p0 = &self.m_p0;
        let acc_p1 = &self.acc_p1;
        let d_p2 = &self.d_p2;
        match &d_p2.kind {
            crate::syntax::decls::DeclKind::DSignature(s_p3) => prism_rtl::Turn::Finished(add_bare(acc_p1, &crate::check::env::def_name_text(&s_p3.name), &crate::check::env::qual_key(m_p0, &crate::check::env::def_name_text(&s_p3.name)))),
            crate::syntax::decls::DeclKind::DFn(f_p4) => prism_rtl::Turn::Finished(add_bare(acc_p1, &crate::check::env::def_name_text(&f_p4.name), &crate::check::env::qual_key(m_p0, &crate::check::env::def_name_text(&f_p4.name)))),
            crate::syntax::decls::DeclKind::DLet(l_p5) => {
                let acc_p1 = acc_p1.clone();
                let l_p5 = l_p5.clone();
                let m_p0 = m_p0.clone();
                call_then(start_pattern_names(l_p5.pattern.clone()), move |pattern_names_5985: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_5985, &acc_p1, &(|a_p6: &Map<Text, Array<Text>>, n_p7: &Text| add_bare(a_p6, n_p7, &crate::check::env::qual_key(&m_p0, n_p7))))))
            },
            crate::syntax::decls::DeclKind::DWidget(w_p8) => prism_rtl::Turn::Finished(add_bare(acc_p1, &crate::check::env::sname_key(&w_p8.name), &crate::check::env::qual_key(m_p0, &crate::check::env::sname_key(&w_p8.name)))),
            crate::syntax::decls::DeclKind::DType(t_p9) => prism_rtl::Turn::Finished(fold(&ctor_names_of(t_p9), acc_p1, &(|a_pa: &Map<Text, Array<Text>>, c_pb: &Text| add_bare(a_pa, c_pb, &crate::check::env::qual_key(m_p0, c_pb))))),
            crate::syntax::decls::DeclKind::DTrait(t_pc) => prism_rtl::Turn::Finished(fold(&t_pc.items, acc_p1, &(|a_pd: &Map<Text, Array<Text>>, it_pe: &crate::syntax::decls::TraitItem| match it_pe {
                crate::syntax::decls::TraitItem::TiSignature(s_pf) => add_bare(a_pd, &crate::check::env::def_name_text(&s_pf.name), &crate::check::env::qual_key(m_p0, &crate::check::env::def_name_text(&s_pf.name))),
                _ => a_pd.clone(),
            }))),
            _ => prism_rtl::Turn::Finished(acc_p1.clone()),
        }
    }
}

/// `Start BareOfDecl, x`: what the function value is when passed to `@Run`.
pub fn start_bare_of_decl(m_p0: Text, acc_p1: Map<Text, Array<Text>>, d_p2: crate::syntax::decls::Decl) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>> {
    Rc::new(BareOfDecl { m_p0, acc_p1, d_p2 })
}

/// ```prism
/// CtorNamesOf: fn TypeDecl -> [Text]
/// ```
pub fn ctor_names_of(t_p0: &crate::syntax::decls::TypeDecl) -> Array<Text> {
    match &t_p0.body {
        Some(crate::syntax::decls::TypeBody::TbRecord(_)) => Array::from(vec![crate::check::env::dotted(&t_p0.name.path_)]),
        Some(crate::syntax::decls::TypeBody::TbChoice(cs_p1)) => each(cs_p1, &(|c_p2: &crate::syntax::decls::Case_| crate::check::env::sname_key(&c_p2.name))),
        Some(crate::syntax::decls::TypeBody::TbNewtype(c_p3)) => Array::from(vec![crate::check::env::sname_key(&c_p3.name)]),
        Some(crate::syntax::decls::TypeBody::TbUnit(i_p4)) => Array::from(vec![i_p4.name.clone()]),
        _ => Array::new(),
    }
}

/// ```prism
/// PatternNames: unbounded fn Pattern -> [Text]
/// ```
pub fn pattern_names(p_p0: &crate::syntax::Pattern_) -> Array<Text> {
    match &*p_p0.kind {
        crate::syntax::PatternKind::PName(n_p1) => Array::from(vec![crate::check::env::sname_key(n_p1)]),
        crate::syntax::PatternKind::PCtor(_, ps_p2) => run_to_end(fold_job(ps_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc_p3 = p0;
            let q_p4 = p1;
            call_then(start_pattern_names(q_p4.clone()), move |pattern_names_6861: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p3, &pattern_names_6861)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PRecord(_, fs_p5, _) => run_to_end(fold_job(fs_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::FieldPat)| entered(once_job(move || {
            let acc_p6 = p0;
            let f_p7 = p1;
            call_then(start_pattern_names(f_p7.pattern.clone()), move |pattern_names_6947: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p6, &pattern_names_6947)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PSigil(_, q_p8) => pattern_names(&**q_p8),
        crate::syntax::PatternKind::PTuple(ps_p9) => run_to_end(fold_job(ps_p9.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc_pa = p0;
            let q_pb = p1;
            call_then(start_pattern_names(q_pb.clone()), move |pattern_names_7061: Array<Text>| prism_rtl::Turn::Finished(append(&acc_pa, &pattern_names_7061)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PArray(ps_pc) => run_to_end(fold_job(ps_pc.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc_pd = p0;
            let q_pe = p1;
            call_then(start_pattern_names(q_pe.clone()), move |pattern_names_7130: Array<Text>| prism_rtl::Turn::Finished(append(&acc_pd, &pattern_names_7130)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PGroup(q_pf) => pattern_names(&**q_pf),
        _ => Array::new(),
    }
}

/// The step machine of `PatternNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatternNames: unbounded fn Pattern -> [Text]
/// ```
pub struct PatternNames {
    pub p_p0: crate::syntax::Pattern_,
}

impl prism_rtl::Job<Array<Text>> for PatternNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let p_p0 = &self.p_p0;
        match &*p_p0.kind {
            crate::syntax::PatternKind::PName(n_p1) => prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::sname_key(n_p1)])),
            crate::syntax::PatternKind::PCtor(_, ps_p2) => fold_job(ps_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc_p3 = p0;
                let q_p4 = p1;
                call_then(start_pattern_names(q_p4.clone()), move |pattern_names_6861: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p3, &pattern_names_6861)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PRecord(_, fs_p5, _) => fold_job(fs_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::FieldPat)| entered(once_job(move || {
                let acc_p6 = p0;
                let f_p7 = p1;
                call_then(start_pattern_names(f_p7.pattern.clone()), move |pattern_names_6947: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p6, &pattern_names_6947)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PSigil(_, q_p8) => prism_rtl::Turn::More(Rc::new(PatternNames { p_p0: (**q_p8).clone() })),
            crate::syntax::PatternKind::PTuple(ps_p9) => fold_job(ps_p9.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc_pa = p0;
                let q_pb = p1;
                call_then(start_pattern_names(q_pb.clone()), move |pattern_names_7061: Array<Text>| prism_rtl::Turn::Finished(append(&acc_pa, &pattern_names_7061)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PArray(ps_pc) => fold_job(ps_pc.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc_pd = p0;
                let q_pe = p1;
                call_then(start_pattern_names(q_pe.clone()), move |pattern_names_7130: Array<Text>| prism_rtl::Turn::Finished(append(&acc_pd, &pattern_names_7130)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PGroup(q_pf) => prism_rtl::Turn::More(Rc::new(PatternNames { p_p0: (**q_pf).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatternNames, x`: what the function value is when passed to `@Run`.
pub fn start_pattern_names(p_p0: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatternNames { p_p0 })
}

/// ```prism
/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
/// ```
pub fn pattern_binders(p_p0: &crate::syntax::Pattern_) -> Array<(Text, crate::syntax::Range)> {
    match &*p_p0.kind {
        crate::syntax::PatternKind::PName(n_p1) => Array::from(vec![(crate::check::env::sname_key(n_p1), n_p1.span.clone())]),
        crate::syntax::PatternKind::PCtor(_, ps_p2) => run_to_end(fold_job(ps_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc_p3 = p0;
            let q_p4 = p1;
            call_then(start_pattern_binders(q_p4.clone()), move |pattern_binders_7450: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc_p3, &pattern_binders_7450)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PRecord(_, fs_p5, _) => run_to_end(fold_job(fs_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)| entered(once_job(move || {
            let acc_p6 = p0;
            let f_p7 = p1;
            call_then(start_pattern_binders(f_p7.pattern.clone()), move |pattern_binders_7538: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc_p6, &pattern_binders_7538)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PSigil(_, q_p8) => pattern_binders(&**q_p8),
        crate::syntax::PatternKind::PTuple(ps_p9) => run_to_end(fold_job(ps_p9.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc_pa = p0;
            let q_pb = p1;
            call_then(start_pattern_binders(q_pb.clone()), move |pattern_binders_7656: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc_pa, &pattern_binders_7656)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PArray(ps_pc) => run_to_end(fold_job(ps_pc.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc_pd = p0;
            let q_pe = p1;
            call_then(start_pattern_binders(q_pe.clone()), move |pattern_binders_7727: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc_pd, &pattern_binders_7727)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PGroup(q_pf) => pattern_binders(&**q_pf),
        _ => Array::new(),
    }
}

/// The step machine of `PatternBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
/// ```
pub struct PatternBinders {
    pub p_p0: crate::syntax::Pattern_,
}

impl prism_rtl::Job<Array<(Text, crate::syntax::Range)>> for PatternBinders {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, crate::syntax::Range)>> {
        let p_p0 = &self.p_p0;
        match &*p_p0.kind {
            crate::syntax::PatternKind::PName(n_p1) => prism_rtl::Turn::Finished(Array::from(vec![(crate::check::env::sname_key(n_p1), n_p1.span.clone())])),
            crate::syntax::PatternKind::PCtor(_, ps_p2) => fold_job(ps_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc_p3 = p0;
                let q_p4 = p1;
                call_then(start_pattern_binders(q_p4.clone()), move |pattern_binders_7450: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc_p3, &pattern_binders_7450)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PRecord(_, fs_p5, _) => fold_job(fs_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)| entered(once_job(move || {
                let acc_p6 = p0;
                let f_p7 = p1;
                call_then(start_pattern_binders(f_p7.pattern.clone()), move |pattern_binders_7538: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc_p6, &pattern_binders_7538)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PSigil(_, q_p8) => prism_rtl::Turn::More(Rc::new(PatternBinders { p_p0: (**q_p8).clone() })),
            crate::syntax::PatternKind::PTuple(ps_p9) => fold_job(ps_p9.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc_pa = p0;
                let q_pb = p1;
                call_then(start_pattern_binders(q_pb.clone()), move |pattern_binders_7656: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc_pa, &pattern_binders_7656)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PArray(ps_pc) => fold_job(ps_pc.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc_pd = p0;
                let q_pe = p1;
                call_then(start_pattern_binders(q_pe.clone()), move |pattern_binders_7727: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc_pd, &pattern_binders_7727)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PGroup(q_pf) => prism_rtl::Turn::More(Rc::new(PatternBinders { p_p0: (**q_pf).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatternBinders, x`: what the function value is when passed to `@Run`.
pub fn start_pattern_binders(p_p0: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>> {
    Rc::new(PatternBinders { p_p0 })
}

/// ```prism
/// BareTypesOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_types_of(g_p0: &crate::check::env::G, src_p1: &Text, acc_p2: &Map<Text, Array<Text>>) -> Map<Text, Array<Text>> {
    fold(&keys(&g_p0.types), acc_p2, &(|a_p3: &Map<Text, Array<Text>>, k_p4: &Text| match get(&g_p0.types, k_p4) {
        Some(ti_p5) => if &ti_p5.home == src_p1 {
            add_bare(a_p3, &crate::check::types::bare_name(&ti_p5.name), k_p4)
        } else {
            a_p3.clone()
        },
        None => a_p3.clone(),
    }))
}

/// ```prism
/// BareTraitsOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_traits_of(g_p0: &crate::check::env::G, src_p1: &Text, acc_p2: &Map<Text, Array<Text>>) -> Map<Text, Array<Text>> {
    fold(&keys(&g_p0.traits), acc_p2, &(|a_p3: &Map<Text, Array<Text>>, k_p4: &Text| match get(&g_p0.traits, k_p4) {
        Some(ti_p5) => if &ti_p5.home == src_p1 {
            add_bare(a_p3, &crate::check::types::bare_name(&ti_p5.name), k_p4)
        } else {
            a_p3.clone()
        },
        None => a_p3.clone(),
    }))
}

/// ```prism
/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
/// ```
pub fn module_row(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo) -> (crate::check::types::Rw, Text, crate::check::types::St) {
    match &info_p2.tree.emit_row {
        None => if info_p2.root {
            (g_p0.program_row.clone(), Text::lit(""), st_p1.clone())
        } else {
            (crate::check::types::empty_row(), Text::lit(""), crate::check::types::recording::err(st_p1, &Text::lit("emit-element"), &info_p2.tree.span, &Text::lit("a library writes its own row; this one writes no `emit` line")))
        },
        Some(row_decl_p3) => {
            let (fams_pa, vars_pb, s2_pc) = fold(&row_decl_p3.terms, &(Array::new(), Array::new(), st_p1.clone()), &(|(fs_p6, vs_p7, s_p8): &(Array<Text>, Array<Text>, crate::check::types::St), term_p9: &crate::syntax::RowTerm| row_term_of(g_p0, s_p8, info_p2, term_p9, fs_p6, vs_p7)));
            let s3_p4 = if &len(&vars_pb) > &Nat::from(1u32) {
                crate::check::types::recording::err_fix(&s2_pc, &Text::lit("row-two-tails"), &row_decl_p3.span, &Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::chars::join(&vars_pb, &Text::lit(" | ")))), &Text::lit("keep one variable"))
            } else {
                s2_pc.clone()
            };
            let tail_p5 = match index(&vars_pb, &Nat::from(0u32)) {
                Some(v_pd) => crate::check::types::Tail::TlQ(v_pd),
                None => crate::check::types::Tail::TlClosed,
            };
            (crate::check::types::Rw { fams: crate::check::types::sort_texts(&fams_pa), minus: Array::new(), tail: tail_p5.clone() }, or(&index(&vars_pb, &Nat::from(0u32)), &Text::lit("")), s3_p4.clone())
        },
    }
}

/// The step machine of `ModuleRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
/// ```
pub struct ModuleRow {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
}

impl prism_rtl::Job<(crate::check::types::Rw, Text, crate::check::types::St)> for ModuleRow {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Rw, Text, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        match &info_p2.tree.emit_row {
            None => if info_p2.root {
                prism_rtl::Turn::Finished((g_p0.program_row.clone(), Text::lit(""), st_p1.clone()))
            } else {
                prism_rtl::Turn::Finished((crate::check::types::empty_row(), Text::lit(""), crate::check::types::recording::err(st_p1, &Text::lit("emit-element"), &info_p2.tree.span, &Text::lit("a library writes its own row; this one writes no `emit` line"))))
            },
            Some(row_decl_p3) => {
                let (fams_pa, vars_pb, s2_pc) = fold(&row_decl_p3.terms, &(Array::new(), Array::new(), st_p1.clone()), &(|(fs_p6, vs_p7, s_p8): &(Array<Text>, Array<Text>, crate::check::types::St), term_p9: &crate::syntax::RowTerm| row_term_of(g_p0, s_p8, info_p2, term_p9, fs_p6, vs_p7)));
                let s3_p4 = if &len(&vars_pb) > &Nat::from(1u32) {
                    crate::check::types::recording::err_fix(&s2_pc, &Text::lit("row-two-tails"), &row_decl_p3.span, &Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::chars::join(&vars_pb, &Text::lit(" | ")))), &Text::lit("keep one variable"))
                } else {
                    s2_pc.clone()
                };
                let tail_p5 = match index(&vars_pb, &Nat::from(0u32)) {
                    Some(v_pd) => crate::check::types::Tail::TlQ(v_pd),
                    None => crate::check::types::Tail::TlClosed,
                };
                prism_rtl::Turn::Finished((crate::check::types::Rw { fams: crate::check::types::sort_texts(&fams_pa), minus: Array::new(), tail: tail_p5.clone() }, or(&index(&vars_pb, &Nat::from(0u32)), &Text::lit("")), s3_p4.clone()))
            },
        }
    }
}

/// `Start ModuleRow, x`: what the function value is when passed to `@Run`.
pub fn start_module_row(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo) -> Rc<dyn prism_rtl::Job<(crate::check::types::Rw, Text, crate::check::types::St)>> {
    Rc::new(ModuleRow { g_p0, st_p1, info_p2 })
}

/// ```prism
/// RowTermOf: fn G, St, ModInfo, RowTerm, [Text], [Text] -> (([Text], [Text], St))
/// ```
pub fn row_term_of(g_p0: &crate::check::env::G, s_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, term_p3: &crate::syntax::RowTerm, fs_p4: &Array<Text>, vs_p5: &Array<Text>) -> (Array<Text>, Array<Text>, crate::check::types::St) {
    match term_p3 {
        crate::syntax::RowTerm::RFamily(q_p6) => (push(fs_p4, &crate::check::env::dotted(&q_p6.path_)), vs_p5.clone(), check_family(g_p0, s_p1, &crate::check::env::dotted(&q_p6.path_), &q_p6.span)),
        crate::syntax::RowTerm::RVar(v_p7) => (fs_p4.clone(), push(vs_p5, &v_p7.name), s_p1.clone()),
        crate::syntax::RowTerm::RType(t_p8) => match &*t_p8.kind {
            crate::syntax::TypeKind::TName(n_p9, m9527_0_1) if (m9527_0_1.len() == 0) => {
                let name_pa = crate::check::env::dotted(&n_p9.path_);
                if (&name_pa == &Text::lit("Element")) && info_p2.root {
                    (append(fs_p4, &g_p0.program_row.fams), vs_p5.clone(), s_p1.clone())
                } else {
                    if &name_pa == &Text::lit("Element") {
                        (fs_p4.clone(), vs_p5.clone(), crate::check::types::recording::err(s_p1, &Text::lit("emit-element"), &t_p8.span, &Text::lit("a library writes its own row; `emit Element` names the program\'s")))
                    } else {
                        if crate::check::env::has_key(&g_p0.tags, &name_pa) || (&len(&n_p9.path_) > &Nat::from(1u32)) {
                            (fs_p4.clone(), vs_p5.clone(), crate::check::types::recording::err_fix(s_p1, &Text::lit("row-single-tag"), &t_p8.span, &Text::from(format!("a row names families, not tags: `{}`", &name_pa)), &Text::from(format!("write `{}.*`", &crate::check::env::dotted(&take(&n_p9.path_, &crate::syntax::lexer::chars::dec(&len(&n_p9.path_))))))))
                        } else {
                            (fs_p4.clone(), vs_p5.clone(), crate::check::types::recording::err(s_p1, &Text::lit("kind"), &t_p8.span, &Text::from(format!("`{}` is not a row", &name_pa))))
                        }
                    }
                }
            },
            _ => (fs_p4.clone(), vs_p5.clone(), crate::check::types::recording::err(s_p1, &Text::lit("kind"), &t_p8.span, &Text::lit("this is not a row"))),
            _ => unreachable!("no arm matched"),
        },
    }
}

/// ```prism
/// CheckFamily: fn G, St, Text, Range -> St
/// ```
pub fn check_family(g_p0: &crate::check::env::G, s_p1: &crate::check::types::St, fam_p2: &Text, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    if crate::check::env::has_key(&g_p0.families, fam_p2) {
        s_p1.clone()
    } else {
        crate::check::types::recording::err(s_p1, &Text::lit("unknown-name"), span_p3, &Text::from(format!("no family `{}`: no module declares a `{}.` tag", fam_p2, fam_p2)))
    }
}

/// ```prism
/// ResolveValue: fn G, Text, SName -> ((?Text, Text))
/// ```
pub fn resolve_value(g_p0: &crate::check::env::G, m_p1: &Text, n_p2: &crate::syntax::SName) -> (Option<Text>, Text) {
    let marks_p3 = n_p2.sigils.clone();
    if &len(&n_p2.path_) == &Nat::from(1u32) {
        {
            let name_p4 = Text::from(format!("{}{}", &marks_p3, &or(&index(&n_p2.path_, &Nat::from(0u32)), &Text::lit(""))));
            let table_p5 = or(&get(&g_p0.bare, m_p1), &Map::new());
            let keys_p6 = or(&get(&table_p5, &name_p4), &Array::new());
            if &len(&keys_p6) == &Nat::from(1u32) {
                (index(&keys_p6, &Nat::from(0u32)), Text::lit(""))
            } else {
                if &len(&keys_p6) > &Nat::from(1u32) {
                    (Some(own_first(m_p1, &keys_p6)), Text::lit("collision"))
                } else {
                    if &name_p4 == &Text::lit("never") {
                        (Some(Text::lit("Prelude.never")), Text::lit(""))
                    } else {
                        if crate::check::env::has_key(&g_p0.ctors, &name_p4) {
                            (Some(name_p4.clone()), Text::lit(""))
                        } else {
                            (None, Text::lit("unknown"))
                        }
                    }
                }
            }
        }
    } else {
        {
            let qual_p7 = crate::check::env::qual_module(g_p0, &take(&n_p2.path_, &crate::syntax::lexer::chars::dec(&len(&n_p2.path_))));
            let last_p8 = or(&crate::syntax::lexer::chars::last(&n_p2.path_), &Text::lit(""));
            let qk_p9 = crate::check::env::qual_key(&qual_p7, &Text::from(format!("{}{}", &marks_p3, &last_p8)));
            if (&len_text(&marks_p3) == &Nat::from(0u32)) && crate::check::env::has_key(&g_p0.tags, &crate::check::env::dotted(&n_p2.path_)) {
                (Some(crate::check::env::dotted(&n_p2.path_)), Text::lit("tag"))
            } else {
                if crate::check::env::has_key(&g_p0.vals, &qk_p9) || crate::check::env::has_key(&g_p0.ctors, &qk_p9) {
                    (Some(qk_p9.clone()), Text::lit(""))
                } else {
                    (None, Text::lit("unknown"))
                }
            }
        }
    }
}

/// ```prism
/// ResolveType: fn G, Text, [Text] -> ((?Text, Text))
/// ```
pub fn resolve_type(g_p0: &crate::check::env::G, m_p1: &Text, path_p2: &Array<Text>) -> (Option<Text>, Text) {
    if &len(path_p2) == &Nat::from(1u32) {
        {
            let keys_p3 = or(&get(&or(&get(&g_p0.bare_types, m_p1), &Map::new()), &or(&index(path_p2, &Nat::from(0u32)), &Text::lit(""))), &Array::new());
            if &len(&keys_p3) == &Nat::from(1u32) {
                (index(&keys_p3, &Nat::from(0u32)), Text::lit(""))
            } else {
                if &len(&keys_p3) > &Nat::from(1u32) {
                    (Some(own_first(m_p1, &keys_p3)), Text::lit("collision"))
                } else {
                    (None, Text::lit("unknown"))
                }
            }
        }
    } else {
        {
            let qk_p4 = crate::check::env::qual_key(&crate::check::env::qual_module(g_p0, &take(path_p2, &crate::syntax::lexer::chars::dec(&len(path_p2)))), &or(&crate::syntax::lexer::chars::last(path_p2), &Text::lit("")));
            if crate::check::env::has_key(&g_p0.types, &qk_p4) {
                (Some(qk_p4.clone()), Text::lit(""))
            } else {
                (None, Text::lit("unknown"))
            }
        }
    }
}

/// ```prism
/// OwnFirst: fn Text, [Text] -> Text
/// ```
pub fn own_first(m_p0: &Text, keys_p1: &Array<Text>) -> Text {
    let own_p2 = filter(keys_p1, &(|k_p3: &Text| (&crate::check::env::qual_key(m_p0, &crate::check::types::bare_name(k_p3)) == k_p3) || ((m_p0 == &Text::lit("")) && !crate::syntax::lexer::chars::contains(k_p3, &Text::lit(".")))));
    or(&index(&own_p2, &Nat::from(0u32)), &or(&index(keys_p1, &Nat::from(0u32)), &Text::lit("")))
}

/// ```prism
/// ?ResolveTrait: fn G, Text, [Text] -> ?Text
/// ```
pub fn resolve_trait(g_p0: &crate::check::env::G, m_p1: &Text, path_p2: &Array<Text>) -> Option<Text> {
    if &len(path_p2) == &Nat::from(1u32) {
        {
            let keys_p3 = or(&get(&or(&get(&g_p0.bare_traits, m_p1), &Map::new()), &or(&index(path_p2, &Nat::from(0u32)), &Text::lit(""))), &Array::new());
            index(&keys_p3, &Nat::from(0u32))
        }
    } else {
        {
            let qk_p4 = crate::check::env::qual_key(&crate::check::env::qual_module(g_p0, &take(path_p2, &crate::syntax::lexer::chars::dec(&len(path_p2)))), &or(&crate::syntax::lexer::chars::last(path_p2), &Text::lit("")));
            if crate::check::env::has_key(&g_p0.traits, &qk_p4) {
                Some(qk_p4.clone())
            } else {
                None
            }
        }
    }
}
