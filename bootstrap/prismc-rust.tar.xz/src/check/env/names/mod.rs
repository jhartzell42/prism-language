//! The module `Check.Env.Names`, from `target/bootstrap/src/prismc/check/env/names.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// CollectNames: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn collect_names_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, m_p2: &crate::prelude::Text) -> (crate::check::env::G, crate::check::types::St) {
    match crate::prelude::get(&g_p0.mods_p, m_p2) {
        ::std::option::Option::None => (g_p0.clone(), st_p1.clone()),
        ::std::option::Option::Some(info_p3) => {
            let s0_p4 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file_p = info_p3.file_p.clone();
                this
            };
            let (g2_p9, s2_pa, _) = crate::prelude::run_to_end(crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), (g_p0.clone(), s0_p4.clone(), ::std::option::Option::None), {
                let info_p3x = info_p3.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St, ::std::option::Option<crate::prelude::Text>), crate::syntax::decls::Decl)| {
                    let info_p3xy = info_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (gg_p5, s_p6, last_type_o7) = p0;
                        let d_p8 = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(CollectDecl { g_p0: gg_p5.clone(), st_p1: s_p6.clone(), info_p2: info_p3xy.clone(), d_p3: d_p8.clone(), last_type_o4: last_type_o7.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St, ::std::option::Option<crate::prelude::Text>), crate::syntax::decls::Decl)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St, ::std::option::Option<crate::prelude::Text>)>>>
            }));
            (g2_p9.clone(), s2_pa.clone())
        },
    }
}

/// The step machine of `CollectNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollectNames: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct CollectNames {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub m_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for CollectNames {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let m_p2 = &self.m_p2;
        match crate::prelude::get(&g_p0.mods_p, m_p2) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
            ::std::option::Option::Some(info_p3) => {
                let s0_p4 = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.file_p = info_p3.file_p.clone();
                    this
                };
                let g_p0x = g_p0.clone();
                crate::prelude::call_value(crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), (g_p0x.clone(), s0_p4.clone(), ::std::option::Option::None), {
                    let info_p3x = info_p3.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St, ::std::option::Option<crate::prelude::Text>), crate::syntax::decls::Decl)| {
                        let info_p3xy = info_p3x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (gg_p5, s_p6, last_type_o7) = p0;
                            let d_p8 = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(CollectDecl { g_p0: gg_p5.clone(), st_p1: s_p6.clone(), info_p2: info_p3xy.clone(), d_p3: d_p8.clone(), last_type_o4: last_type_o7.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St, ::std::option::Option<crate::prelude::Text>), crate::syntax::decls::Decl)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St, ::std::option::Option<crate::prelude::Text>)>>>
                }), move |fold_1030: (crate::check::env::G, crate::check::types::St, ::std::option::Option<crate::prelude::Text>)| {
                    let (g2_p9, s2_pa, _) = fold_1030;
                    ::prism_rtl::Turn::Finished((g2_p9.clone(), s2_pa.clone()))
                })
            },
        }
    }
}

/// `Start CollectNames, x`: what the function value is when passed to `@Run`.
pub fn start_collect_names_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, m_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    ::std::rc::Rc::new(CollectNames { g_p0, st_p1, m_p2 })
}

/// ```prism
/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
/// ```
pub fn collect_decl_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, d_p3: &crate::syntax::decls::Decl, last_type_o4: &::std::option::Option<crate::prelude::Text>) -> (crate::check::env::G, crate::check::types::St, ::std::option::Option<crate::prelude::Text>) {
    match &d_p3.kind_p {
        crate::syntax::decls::DeclKind::DType(t_p5) => {
            let name_p6 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_p5.name_p.path_p));
            let ti_p7 = crate::check::env::TyInfo { name_p: name_p6.clone(), home_p: info_p2.name_p.clone(), params_p: crate::prelude::each(&t_p5.params_p, &(|p_p8: &crate::syntax::Ident| p_p8.name_p.clone())), body_p: crate::check::env::TyBody::BOpaque, derives_p: crate::prelude::Array::new(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone() };
            if crate::check::env::has_key_f(&g_p0.types_p, &name_p6) {
                (g_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("collision"), &d_p3.span_p, &crate::prelude::Text::from(format!("a second type `{}`", &crate::check::env::dotted_f(&t_p5.name_p.path_p)))), last_type_o4.clone())
            } else {
                if crate::check::env::has_key_f(&g_p0.assoc_names_p, &name_p6) {
                    (g_p0.clone(), crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("duplicate-name"), &d_p3.span_p, &crate::prelude::Text::from(format!("`{}` is already an associated type of `^{}` in this module", &crate::check::env::dotted_f(&t_p5.name_p.path_p), &crate::check::types::bare_name_f(&crate::prelude::or(&crate::prelude::get(&g_p0.assoc_names_p, &name_p6), &crate::prelude::Text::lit(""))))), &crate::prelude::Text::lit("rename one of them, or declare the trait in a module of its own")), last_type_o4.clone())
                } else {
                    {
                        let upd_p9 = {
                            let mut this: crate::check::env::G = g_p0.clone();
                            this.types_p = crate::prelude::insert(&this.types_p, &name_p6, &ti_p7);
                            this
                        };
                        (upd_p9.clone(), st_p1.clone(), ::std::option::Option::Some(name_p6.clone()))
                    }
                }
            }
        },
        crate::syntax::decls::DeclKind::DDerive(trs_pa) => match last_type_o4 {
            ::std::option::Option::Some(tn_pb) => {
                let upd_pc = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.types_p = crate::prelude::insert(&this.types_p, tn_pb, &add_derives_f(&crate::prelude::or(&crate::prelude::get(&g_p0.types_p, tn_pb), &dummy_ty_info_p()), &crate::prelude::each(trs_pa, &(|tr_pd: &crate::syntax::TraitRef| crate::check::env::dotted_f(&tr_pd.path_p)))));
                    this
                };
                (upd_pc.clone(), st_p1.clone(), last_type_o4.clone())
            },
            ::std::option::Option::None => (g_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &d_p3.span_p, &crate::prelude::Text::lit("a `derive` line follows a type declaration")), ::std::option::Option::None),
        },
        crate::syntax::decls::DeclKind::DTag(t_pe) => {
            let name_pf = crate::check::env::dotted_f(&t_pe.name_p.path_p);
            let family_pg = crate::check::env::dotted_f(&crate::prelude::take(&t_pe.name_p.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&t_pe.name_p.path_p))));
            let tags_ph = crate::prelude::or(&crate::prelude::get(&g_p0.families_p, &family_pg), &crate::prelude::Array::new());
            let owner_pi = crate::prelude::or(&crate::prelude::get(&g_p0.fam_owner_p, &family_pg), &info_p2.name_p);
            let st2_pj = if &owner_pi != &info_p2.name_p {
                crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("collision"), &d_p3.span_p, &crate::prelude::Text::from(format!("the family `{}` is declared in {}; every tag of a family is declared in its family\'s module", &family_pg, &(if &owner_pi == &crate::prelude::Text::lit("") {
                    crate::prelude::Text::lit("the root")
                } else {
                    crate::prelude::Text::from(format!("`{}`", &owner_pi))
                }))))
            } else {
                st_p1.clone()
            };
            let is_elem_pk = match &*t_pe.of_type_p.kind_p {
                crate::syntax::TypeKind::TName(n_pm, _) => &crate::check::env::dotted_f(&n_pm.path_p) == &crate::prelude::Text::lit("Element"),
                _ => false,
            };
            let g2_pl = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.families_p = crate::prelude::insert(&this.families_p, &family_pg, &crate::prelude::push(&tags_ph, &name_pf));
                this.fam_owner_p = crate::prelude::insert(&this.fam_owner_p, &family_pg, &owner_pi);
                if is_elem_pk {
                    this.elem_fams_p = crate::check::types::add_text_f(&this.elem_fams_p, &family_pg);
                }
                this
            };
            (g2_pl.clone(), st2_pj.clone(), ::std::option::Option::None)
        },
        crate::syntax::decls::DeclKind::DTrait(t_pn) => {
            let name_po = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_pn.name_p.path_p));
            let assocs_pp = crate::prelude::fold(&t_pn.items_p, &crate::prelude::Array::new(), &(|acc_ps: &crate::prelude::Array<crate::prelude::Text>, it_pt: &crate::syntax::decls::TraitItem| match it_pt {
                crate::syntax::decls::TraitItem::TiAssocType(n_pu, _, _, _) => crate::prelude::push(acc_ps, &n_pu.name_p),
                _ => acc_ps.clone(),
            }));
            let ti_pq = crate::check::env::TraitInfo { name_p: name_po.clone(), home_p: info_p2.name_p.clone(), param_p: crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&t_pn.params_p, &(|p_pv: &crate::syntax::Ident| p_pv.name_p.clone())), &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("a")), supers_p: crate::prelude::Array::new(), methods_p: crate::prelude::Array::new(), defaults_p: crate::prelude::Array::new(), assocs_p: assocs_pp.clone(), assoc_defaults_p: crate::prelude::Array::new(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone() };
            let (names_p17, st2_p18) = crate::prelude::fold(&t_pn.items_p, &(g_p0.assoc_names_p.clone(), st_p1.clone()), &(|(m_p10, s_p11): &(crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, crate::check::types::St), it_p12: &crate::syntax::decls::TraitItem| match it_p12 {
                crate::syntax::decls::TraitItem::TiAssocType(n_p13, _, _, aspan_p14) => {
                    let qkey_p15 = crate::check::env::qual_key_f(&info_p2.name_p, &n_p13.name_p);
                    match crate::prelude::get(m_p10, &qkey_p15) {
                        ::std::option::Option::Some(other_p16) => (m_p10.clone(), crate::check::types::recording::err_fix_f(s_p11, &crate::prelude::Text::lit("duplicate-name"), aspan_p14, &crate::prelude::Text::from(format!("`{}` is already an associated type of `^{}` in this module", &n_p13.name_p, &crate::check::types::bare_name_f(&other_p16))), &crate::prelude::Text::lit("rename one of them, or declare the trait in a module of its own"))),
                        ::std::option::Option::None => if crate::check::env::has_key_f(&g_p0.types_p, &qkey_p15) {
                            (m_p10.clone(), crate::check::types::recording::err_fix_f(s_p11, &crate::prelude::Text::lit("duplicate-name"), aspan_p14, &crate::prelude::Text::from(format!("`{}` is already a type of this module", &n_p13.name_p)), &crate::prelude::Text::lit("rename one of them, or declare the trait in a module of its own")))
                        } else {
                            (crate::prelude::insert(m_p10, &qkey_p15, &name_po), s_p11.clone())
                        },
                    }
                },
                _ => (m_p10.clone(), s_p11.clone()),
            }));
            let upd_pr = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.traits_p = crate::prelude::insert(&this.traits_p, &name_po, &ti_pq);
                this.assoc_names_p = names_p17.clone();
                this
            };
            (upd_pr.clone(), st2_p18.clone(), ::std::option::Option::None)
        },
        _ => (g_p0.clone(), st_p1.clone(), ::std::option::Option::None),
    }
}

/// The step machine of `CollectDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
/// ```
pub struct CollectDecl {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
    pub d_p3: crate::syntax::decls::Decl,
    pub last_type_o4: ::std::option::Option<crate::prelude::Text>,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St, ::std::option::Option<crate::prelude::Text>)> for CollectDecl {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St, ::std::option::Option<crate::prelude::Text>)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        let d_p3 = &self.d_p3;
        let last_type_o4 = &self.last_type_o4;
        match &d_p3.kind_p {
            crate::syntax::decls::DeclKind::DType(t_p5) => {
                let name_p6 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_p5.name_p.path_p));
                let ti_p7 = crate::check::env::TyInfo { name_p: name_p6.clone(), home_p: info_p2.name_p.clone(), params_p: crate::prelude::each(&t_p5.params_p, &(|p_p8: &crate::syntax::Ident| p_p8.name_p.clone())), body_p: crate::check::env::TyBody::BOpaque, derives_p: crate::prelude::Array::new(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone() };
                if crate::check::env::has_key_f(&g_p0.types_p, &name_p6) {
                    ::prism_rtl::Turn::Finished((g_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("collision"), &d_p3.span_p, &crate::prelude::Text::from(format!("a second type `{}`", &crate::check::env::dotted_f(&t_p5.name_p.path_p)))), last_type_o4.clone()))
                } else {
                    if crate::check::env::has_key_f(&g_p0.assoc_names_p, &name_p6) {
                        ::prism_rtl::Turn::Finished((g_p0.clone(), crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("duplicate-name"), &d_p3.span_p, &crate::prelude::Text::from(format!("`{}` is already an associated type of `^{}` in this module", &crate::check::env::dotted_f(&t_p5.name_p.path_p), &crate::check::types::bare_name_f(&crate::prelude::or(&crate::prelude::get(&g_p0.assoc_names_p, &name_p6), &crate::prelude::Text::lit(""))))), &crate::prelude::Text::lit("rename one of them, or declare the trait in a module of its own")), last_type_o4.clone()))
                    } else {
                        {
                            let upd_p9 = {
                                let mut this: crate::check::env::G = g_p0.clone();
                                this.types_p = crate::prelude::insert(&this.types_p, &name_p6, &ti_p7);
                                this
                            };
                            ::prism_rtl::Turn::Finished((upd_p9.clone(), st_p1.clone(), ::std::option::Option::Some(name_p6.clone())))
                        }
                    }
                }
            },
            crate::syntax::decls::DeclKind::DDerive(trs_pa) => match last_type_o4 {
                ::std::option::Option::Some(tn_pb) => {
                    let upd_pc = {
                        let mut this: crate::check::env::G = g_p0.clone();
                        this.types_p = crate::prelude::insert(&this.types_p, tn_pb, &add_derives_f(&crate::prelude::or(&crate::prelude::get(&g_p0.types_p, tn_pb), &dummy_ty_info_p()), &crate::prelude::each(trs_pa, &(|tr_pd: &crate::syntax::TraitRef| crate::check::env::dotted_f(&tr_pd.path_p)))));
                        this
                    };
                    ::prism_rtl::Turn::Finished((upd_pc.clone(), st_p1.clone(), last_type_o4.clone()))
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished((g_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &d_p3.span_p, &crate::prelude::Text::lit("a `derive` line follows a type declaration")), ::std::option::Option::None)),
            },
            crate::syntax::decls::DeclKind::DTag(t_pe) => {
                let name_pf = crate::check::env::dotted_f(&t_pe.name_p.path_p);
                let family_pg = crate::check::env::dotted_f(&crate::prelude::take(&t_pe.name_p.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&t_pe.name_p.path_p))));
                let tags_ph = crate::prelude::or(&crate::prelude::get(&g_p0.families_p, &family_pg), &crate::prelude::Array::new());
                let owner_pi = crate::prelude::or(&crate::prelude::get(&g_p0.fam_owner_p, &family_pg), &info_p2.name_p);
                let st2_pj = if &owner_pi != &info_p2.name_p {
                    crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("collision"), &d_p3.span_p, &crate::prelude::Text::from(format!("the family `{}` is declared in {}; every tag of a family is declared in its family\'s module", &family_pg, &(if &owner_pi == &crate::prelude::Text::lit("") {
                        crate::prelude::Text::lit("the root")
                    } else {
                        crate::prelude::Text::from(format!("`{}`", &owner_pi))
                    }))))
                } else {
                    st_p1.clone()
                };
                let is_elem_pk = match &*t_pe.of_type_p.kind_p {
                    crate::syntax::TypeKind::TName(n_pm, _) => &crate::check::env::dotted_f(&n_pm.path_p) == &crate::prelude::Text::lit("Element"),
                    _ => false,
                };
                let g2_pl = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.families_p = crate::prelude::insert(&this.families_p, &family_pg, &crate::prelude::push(&tags_ph, &name_pf));
                    this.fam_owner_p = crate::prelude::insert(&this.fam_owner_p, &family_pg, &owner_pi);
                    if is_elem_pk {
                        this.elem_fams_p = crate::check::types::add_text_f(&this.elem_fams_p, &family_pg);
                    }
                    this
                };
                ::prism_rtl::Turn::Finished((g2_pl.clone(), st2_pj.clone(), ::std::option::Option::None))
            },
            crate::syntax::decls::DeclKind::DTrait(t_pn) => {
                let name_po = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_pn.name_p.path_p));
                let assocs_pp = crate::prelude::fold(&t_pn.items_p, &crate::prelude::Array::new(), &(|acc_ps: &crate::prelude::Array<crate::prelude::Text>, it_pt: &crate::syntax::decls::TraitItem| match it_pt {
                    crate::syntax::decls::TraitItem::TiAssocType(n_pu, _, _, _) => crate::prelude::push(acc_ps, &n_pu.name_p),
                    _ => acc_ps.clone(),
                }));
                let ti_pq = crate::check::env::TraitInfo { name_p: name_po.clone(), home_p: info_p2.name_p.clone(), param_p: crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&t_pn.params_p, &(|p_pv: &crate::syntax::Ident| p_pv.name_p.clone())), &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("a")), supers_p: crate::prelude::Array::new(), methods_p: crate::prelude::Array::new(), defaults_p: crate::prelude::Array::new(), assocs_p: assocs_pp.clone(), assoc_defaults_p: crate::prelude::Array::new(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone() };
                let (names_p17, st2_p18) = crate::prelude::fold(&t_pn.items_p, &(g_p0.assoc_names_p.clone(), st_p1.clone()), &(|(m_p10, s_p11): &(crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, crate::check::types::St), it_p12: &crate::syntax::decls::TraitItem| match it_p12 {
                    crate::syntax::decls::TraitItem::TiAssocType(n_p13, _, _, aspan_p14) => {
                        let qkey_p15 = crate::check::env::qual_key_f(&info_p2.name_p, &n_p13.name_p);
                        match crate::prelude::get(m_p10, &qkey_p15) {
                            ::std::option::Option::Some(other_p16) => (m_p10.clone(), crate::check::types::recording::err_fix_f(s_p11, &crate::prelude::Text::lit("duplicate-name"), aspan_p14, &crate::prelude::Text::from(format!("`{}` is already an associated type of `^{}` in this module", &n_p13.name_p, &crate::check::types::bare_name_f(&other_p16))), &crate::prelude::Text::lit("rename one of them, or declare the trait in a module of its own"))),
                            ::std::option::Option::None => if crate::check::env::has_key_f(&g_p0.types_p, &qkey_p15) {
                                (m_p10.clone(), crate::check::types::recording::err_fix_f(s_p11, &crate::prelude::Text::lit("duplicate-name"), aspan_p14, &crate::prelude::Text::from(format!("`{}` is already a type of this module", &n_p13.name_p)), &crate::prelude::Text::lit("rename one of them, or declare the trait in a module of its own")))
                            } else {
                                (crate::prelude::insert(m_p10, &qkey_p15, &name_po), s_p11.clone())
                            },
                        }
                    },
                    _ => (m_p10.clone(), s_p11.clone()),
                }));
                let upd_pr = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.traits_p = crate::prelude::insert(&this.traits_p, &name_po, &ti_pq);
                    this.assoc_names_p = names_p17.clone();
                    this
                };
                ::prism_rtl::Turn::Finished((upd_pr.clone(), st2_p18.clone(), ::std::option::Option::None))
            },
            _ => ::prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone(), ::std::option::Option::None)),
        }
    }
}

/// `Start CollectDecl, x`: what the function value is when passed to `@Run`.
pub fn start_collect_decl_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo, d_p3: crate::syntax::decls::Decl, last_type_o4: ::std::option::Option<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St, ::std::option::Option<crate::prelude::Text>)>> {
    ::std::rc::Rc::new(CollectDecl { g_p0, st_p1, info_p2, d_p3, last_type_o4 })
}

/// ```prism
/// let dummyTyInfo
/// ```
pub fn dummy_ty_info_p() -> crate::check::env::TyInfo {
    crate::check::env::TyInfo { name_p: crate::prelude::Text::lit(""), home_p: crate::prelude::Text::lit(""), params_p: crate::prelude::Array::new(), body_p: crate::check::env::TyBody::BOpaque, derives_p: crate::prelude::Array::new(), file_p: crate::prelude::Nat::from(0u32), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// AddDerives: fn TyInfo, [Text] -> TyInfo
/// ```
pub fn add_derives_f(ti_p0: &crate::check::env::TyInfo, trs_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::check::env::TyInfo {
    let mut this: crate::check::env::TyInfo = ti_p0.clone();
    this.derives_p = crate::prelude::append(&this.derives_p, trs_p1);
    this
}

/// ```prism
/// ProgramRow: fn G -> Rw
/// ```
pub fn program_row_f(g_p0: &crate::check::env::G) -> crate::check::types::Rw {
    crate::check::types::closed_f(&g_p0.elem_fams_p)
}

/// ```prism
/// BuildTables: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn build_tables_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, m_p2: &crate::prelude::Text) -> (crate::check::env::G, crate::check::types::St) {
    match crate::prelude::get(&g_p0.mods_p, m_p2) {
        ::std::option::Option::None => (g_p0.clone(), st_p1.clone()),
        ::std::option::Option::Some(info_p3) => {
            let s0_p4 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file_p = info_p3.file_p.clone();
                this
            };
            let s1_p5 = crate::prelude::fold(&info_p3.tree_p.uses_p, &s0_p4, &(|s_pd: &crate::check::types::St, line_pe: &crate::syntax::Use| {
                let u_pf = crate::check::env::use_name_f(g_p0, &crate::check::env::dotted_f(&line_pe.target_p.path_p));
                if crate::check::env::has_key_f(&g_p0.mods_p, &u_pf) || (&u_pf == &crate::prelude::Text::lit("Prelude")) {
                    s_pd.clone()
                } else {
                    crate::check::types::recording::err_f(s_pd, &crate::prelude::Text::lit("unknown-name"), &line_pe.span_p, &crate::prelude::Text::from(format!("no module `{}` among the program\'s files", &u_pf)))
                }
            }));
            let starred_p6 = crate::prelude::fold(&info_p3.uses_p, &crate::prelude::Array::new(), &(|acc_pg: &crate::prelude::Array<crate::prelude::Text>, (u_ph, star_pi): &(crate::prelude::Text, bool)| if *star_pi && (u_ph != m_p2) {
                crate::prelude::push(acc_pg, u_ph)
            } else {
                acc_pg.clone()
            }));
            let sources_p7 = crate::check::types::add_text_f(&crate::prelude::append(&crate::prelude::Array::from(vec![m_p2.clone()]), &starred_p6), &crate::prelude::Text::lit("Prelude"));
            let vals_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(sources_p7.clone(), crate::prelude::Map::new(), {
                let g_p0x = g_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::prelude::Text)| {
                    let g_p0xy = g_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pj = p0;
                        let src_pk = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(BareValuesOf { g_p0: g_p0xy.clone(), src_p1: src_pk.clone(), acc_p2: acc_pj.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>>>
            }));
            let tys_p9 = crate::prelude::fold(&sources_p7, &crate::prelude::Map::new(), &(|acc_pl: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, src_pm: &crate::prelude::Text| bare_types_of_f(g_p0, src_pm, acc_pl)));
            let trs_pa = crate::prelude::fold(&sources_p7, &crate::prelude::Map::new(), &(|acc_pn: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, src_po: &crate::prelude::Text| bare_traits_of_f(g_p0, src_po, acc_pn)));
            let (rw_pp, rv_pq, s2_pr) = module_row_f(g_p0, &s1_p5, &info_p3);
            let info2_pb = {
                let mut this: crate::check::env::ModInfo = info_p3.clone();
                this.emit_rw_p = rw_pp.clone();
                this.row_var_p = rv_pq.clone();
                this
            };
            let upd_pc = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.bare_p = crate::prelude::insert(&this.bare_p, m_p2, &vals_p8);
                this.bare_types_p = crate::prelude::insert(&this.bare_types_p, m_p2, &tys_p9);
                this.bare_traits_p = crate::prelude::insert(&this.bare_traits_p, m_p2, &trs_pa);
                this.mods_p = crate::prelude::insert(&this.mods_p, m_p2, &info2_pb);
                this
            };
            (upd_pc.clone(), s2_pr.clone())
        },
    }
}

/// The step machine of `BuildTables`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildTables: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct BuildTables {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub m_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for BuildTables {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let m_p2 = &self.m_p2;
        match crate::prelude::get(&g_p0.mods_p, m_p2) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
            ::std::option::Option::Some(info_p3) => {
                let s0_p4 = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.file_p = info_p3.file_p.clone();
                    this
                };
                let s1_p5 = crate::prelude::fold(&info_p3.tree_p.uses_p, &s0_p4, &(|s_pd: &crate::check::types::St, line_pe: &crate::syntax::Use| {
                    let u_pf = crate::check::env::use_name_f(g_p0, &crate::check::env::dotted_f(&line_pe.target_p.path_p));
                    if crate::check::env::has_key_f(&g_p0.mods_p, &u_pf) || (&u_pf == &crate::prelude::Text::lit("Prelude")) {
                        s_pd.clone()
                    } else {
                        crate::check::types::recording::err_f(s_pd, &crate::prelude::Text::lit("unknown-name"), &line_pe.span_p, &crate::prelude::Text::from(format!("no module `{}` among the program\'s files", &u_pf)))
                    }
                }));
                let starred_p6 = crate::prelude::fold(&info_p3.uses_p, &crate::prelude::Array::new(), &(|acc_pg: &crate::prelude::Array<crate::prelude::Text>, (u_ph, star_pi): &(crate::prelude::Text, bool)| if *star_pi && (u_ph != m_p2) {
                    crate::prelude::push(acc_pg, u_ph)
                } else {
                    acc_pg.clone()
                }));
                let sources_p7 = crate::check::types::add_text_f(&crate::prelude::append(&crate::prelude::Array::from(vec![m_p2.clone()]), &starred_p6), &crate::prelude::Text::lit("Prelude"));
                let g_p0x = g_p0.clone();
                let m_p2x = m_p2.clone();
                crate::prelude::call_value(crate::prelude::fold_job(sources_p7.clone(), crate::prelude::Map::new(), {
                    let g_p0xx = g_p0x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::prelude::Text)| {
                        let g_p0xxy = g_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pj = p0;
                            let src_pk = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(BareValuesOf { g_p0: g_p0xxy.clone(), src_p1: src_pk.clone(), acc_p2: acc_pj.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>>>
                }), move |fold_6453: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>| {
                    let vals_p8 = fold_6453;
                    let tys_p9 = crate::prelude::fold(&sources_p7, &crate::prelude::Map::new(), &(|acc_pl: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, src_pm: &crate::prelude::Text| bare_types_of_f(&g_p0x, src_pm, acc_pl)));
                    let trs_pa = crate::prelude::fold(&sources_p7, &crate::prelude::Map::new(), &(|acc_pn: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, src_po: &crate::prelude::Text| bare_traits_of_f(&g_p0x, src_po, acc_pn)));
                    crate::prelude::call_then(start_module_row_f(g_p0x.clone(), s1_p5.clone(), info_p3.clone()), move |module_row_f_6682: (crate::check::types::Rw, crate::prelude::Text, crate::check::types::St)| {
                        let (rw_pp, rv_pq, s2_pr) = module_row_f_6682;
                        let info2_pb = {
                            let mut this: crate::check::env::ModInfo = info_p3.clone();
                            this.emit_rw_p = rw_pp.clone();
                            this.row_var_p = rv_pq.clone();
                            this
                        };
                        let upd_pc = {
                            let mut this: crate::check::env::G = g_p0x.clone();
                            this.bare_p = crate::prelude::insert(&this.bare_p, &m_p2x, &vals_p8);
                            this.bare_types_p = crate::prelude::insert(&this.bare_types_p, &m_p2x, &tys_p9);
                            this.bare_traits_p = crate::prelude::insert(&this.bare_traits_p, &m_p2x, &trs_pa);
                            this.mods_p = crate::prelude::insert(&this.mods_p, &m_p2x, &info2_pb);
                            this
                        };
                        ::prism_rtl::Turn::Finished((upd_pc.clone(), s2_pr.clone()))
                    })
                })
            },
        }
    }
}

/// `Start BuildTables, x`: what the function value is when passed to `@Run`.
pub fn start_build_tables_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, m_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    ::std::rc::Rc::new(BuildTables { g_p0, st_p1, m_p2 })
}

/// ```prism
/// AddBare: fn (Text ==> [Text]), Text, Text -> (Text ==> [Text])
/// ```
pub fn add_bare_f(acc_p0: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, name_p1: &crate::prelude::Text, qk_p2: &crate::prelude::Text) -> crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>> {
    let have_p3 = crate::prelude::or(&crate::prelude::get(acc_p0, name_p1), &crate::prelude::Array::new());
    if crate::check::types::has_text_f(&have_p3, qk_p2) {
        acc_p0.clone()
    } else {
        crate::prelude::insert(acc_p0, name_p1, &crate::prelude::push(&have_p3, qk_p2))
    }
}

/// ```prism
/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_values_of_f(g_p0: &crate::check::env::G, src_p1: &crate::prelude::Text, acc_p2: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>) -> crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>> {
    match crate::prelude::get(&g_p0.mods_p, src_p1) {
        ::std::option::Option::None => acc_p2.clone(),
        ::std::option::Option::Some(info_p3) => crate::prelude::run_to_end(crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), acc_p2.clone(), {
            let src_p1x = src_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::syntax::decls::Decl)| {
                let src_p1xy = src_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p4 = p0;
                    let d_p5 = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(BareOfDecl { m_p0: src_p1xy.clone(), acc_p1: a_p4.clone(), d_p2: d_p5.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::syntax::decls::Decl)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>>>
        })),
    }
}

/// The step machine of `BareValuesOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub struct BareValuesOf {
    pub g_p0: crate::check::env::G,
    pub src_p1: crate::prelude::Text,
    pub acc_p2: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>> for BareValuesOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>> {
        let g_p0 = &self.g_p0;
        let src_p1 = &self.src_p1;
        let acc_p2 = &self.acc_p2;
        match crate::prelude::get(&g_p0.mods_p, src_p1) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_p2.clone()),
            ::std::option::Option::Some(info_p3) => crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), acc_p2.clone(), {
                let src_p1x = src_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::syntax::decls::Decl)| {
                    let src_p1xy = src_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p4 = p0;
                        let d_p5 = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(BareOfDecl { m_p0: src_p1xy.clone(), acc_p1: a_p4.clone(), d_p2: d_p5.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::syntax::decls::Decl)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>>>
            }).cycle(),
        }
    }
}

/// `Start BareValuesOf, x`: what the function value is when passed to `@Run`.
pub fn start_bare_values_of_f(g_p0: crate::check::env::G, src_p1: crate::prelude::Text, acc_p2: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>> {
    ::std::rc::Rc::new(BareValuesOf { g_p0, src_p1, acc_p2 })
}

/// ```prism
/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
/// ```
pub fn bare_of_decl_f(m_p0: &crate::prelude::Text, acc_p1: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, d_p2: &crate::syntax::decls::Decl) -> crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>> {
    match &d_p2.kind_p {
        crate::syntax::decls::DeclKind::DSignature(s_p3) => add_bare_f(acc_p1, &crate::check::env::def_name_text_f(&s_p3.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::def_name_text_f(&s_p3.name_p))),
        crate::syntax::decls::DeclKind::DFn(f_p4) => add_bare_f(acc_p1, &crate::check::env::def_name_text_f(&f_p4.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::def_name_text_f(&f_p4.name_p))),
        crate::syntax::decls::DeclKind::DLet(l_p5) => crate::prelude::fold(&pattern_names_f(&l_p5.pattern_p), acc_p1, &(|a_p6: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, n_p7: &crate::prelude::Text| add_bare_f(a_p6, n_p7, &crate::check::env::qual_key_f(m_p0, n_p7)))),
        crate::syntax::decls::DeclKind::DWidget(w_p8) => add_bare_f(acc_p1, &crate::check::env::sname_key_f(&w_p8.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::sname_key_f(&w_p8.name_p))),
        crate::syntax::decls::DeclKind::DType(t_p9) => crate::prelude::fold(&ctor_names_of_f(t_p9), acc_p1, &(|a_pa: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, c_pb: &crate::prelude::Text| add_bare_f(a_pa, c_pb, &crate::check::env::qual_key_f(m_p0, c_pb)))),
        crate::syntax::decls::DeclKind::DTrait(t_pc) => crate::prelude::fold(&t_pc.items_p, acc_p1, &(|a_pd: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, it_pe: &crate::syntax::decls::TraitItem| match it_pe {
            crate::syntax::decls::TraitItem::TiSignature(s_pf) => add_bare_f(a_pd, &crate::check::env::def_name_text_f(&s_pf.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::def_name_text_f(&s_pf.name_p))),
            _ => a_pd.clone(),
        })),
        _ => acc_p1.clone(),
    }
}

/// The step machine of `BareOfDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
/// ```
pub struct BareOfDecl {
    pub m_p0: crate::prelude::Text,
    pub acc_p1: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>,
    pub d_p2: crate::syntax::decls::Decl,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>> for BareOfDecl {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>> {
        let m_p0 = &self.m_p0;
        let acc_p1 = &self.acc_p1;
        let d_p2 = &self.d_p2;
        match &d_p2.kind_p {
            crate::syntax::decls::DeclKind::DSignature(s_p3) => ::prism_rtl::Turn::Finished(add_bare_f(acc_p1, &crate::check::env::def_name_text_f(&s_p3.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::def_name_text_f(&s_p3.name_p)))),
            crate::syntax::decls::DeclKind::DFn(f_p4) => ::prism_rtl::Turn::Finished(add_bare_f(acc_p1, &crate::check::env::def_name_text_f(&f_p4.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::def_name_text_f(&f_p4.name_p)))),
            crate::syntax::decls::DeclKind::DLet(l_p5) => {
                let acc_p1x = acc_p1.clone();
                let l_p5x = l_p5.clone();
                let m_p0x = m_p0.clone();
                crate::prelude::call_then(start_pattern_names_f(l_p5x.pattern_p.clone()), move |pattern_names_f_7827: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&pattern_names_f_7827, &acc_p1x, &(|a_p6: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, n_p7: &crate::prelude::Text| add_bare_f(a_p6, n_p7, &crate::check::env::qual_key_f(&m_p0x, n_p7))))))
            },
            crate::syntax::decls::DeclKind::DWidget(w_p8) => ::prism_rtl::Turn::Finished(add_bare_f(acc_p1, &crate::check::env::sname_key_f(&w_p8.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::sname_key_f(&w_p8.name_p)))),
            crate::syntax::decls::DeclKind::DType(t_p9) => ::prism_rtl::Turn::Finished(crate::prelude::fold(&ctor_names_of_f(t_p9), acc_p1, &(|a_pa: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, c_pb: &crate::prelude::Text| add_bare_f(a_pa, c_pb, &crate::check::env::qual_key_f(m_p0, c_pb))))),
            crate::syntax::decls::DeclKind::DTrait(t_pc) => ::prism_rtl::Turn::Finished(crate::prelude::fold(&t_pc.items_p, acc_p1, &(|a_pd: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, it_pe: &crate::syntax::decls::TraitItem| match it_pe {
                crate::syntax::decls::TraitItem::TiSignature(s_pf) => add_bare_f(a_pd, &crate::check::env::def_name_text_f(&s_pf.name_p), &crate::check::env::qual_key_f(m_p0, &crate::check::env::def_name_text_f(&s_pf.name_p))),
                _ => a_pd.clone(),
            }))),
            _ => ::prism_rtl::Turn::Finished(acc_p1.clone()),
        }
    }
}

/// `Start BareOfDecl, x`: what the function value is when passed to `@Run`.
pub fn start_bare_of_decl_f(m_p0: crate::prelude::Text, acc_p1: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, d_p2: crate::syntax::decls::Decl) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>> {
    ::std::rc::Rc::new(BareOfDecl { m_p0, acc_p1, d_p2 })
}

/// ```prism
/// CtorNamesOf: fn TypeDecl -> [Text]
/// ```
pub fn ctor_names_of_f(t_p0: &crate::syntax::decls::TypeDecl) -> crate::prelude::Array<crate::prelude::Text> {
    match &t_p0.body_o {
        ::std::option::Option::Some(crate::syntax::decls::TypeBody::TbRecord(_)) => crate::prelude::Array::from(vec![crate::check::env::dotted_f(&t_p0.name_p.path_p)]),
        ::std::option::Option::Some(crate::syntax::decls::TypeBody::TbChoice(cs_p1)) => crate::prelude::each(cs_p1, &(|c_p2: &crate::syntax::decls::Case| crate::check::env::sname_key_f(&c_p2.name_p))),
        ::std::option::Option::Some(crate::syntax::decls::TypeBody::TbNewtype(c_p3)) => crate::prelude::Array::from(vec![crate::check::env::sname_key_f(&c_p3.name_p)]),
        ::std::option::Option::Some(crate::syntax::decls::TypeBody::TbUnit(i_p4)) => crate::prelude::Array::from(vec![i_p4.name_p.clone()]),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// PatternNames: unbounded fn Pattern -> [Text]
/// ```
pub fn pattern_names_f(p_p0: &crate::syntax::Pattern) -> crate::prelude::Array<crate::prelude::Text> {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p1) => crate::prelude::Array::from(vec![crate::check::env::sname_key_f(n_p1)]),
        crate::syntax::PatternKind::PCtor(_, ps_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p2.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let q_p4 = p1;
            crate::prelude::call_then(start_pattern_names_f(q_p4.clone()), move |pattern_names_f_8703: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &pattern_names_f_8703)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::syntax::PatternKind::PRecord(_, fs_p5, _) => crate::prelude::run_to_end(crate::prelude::fold_job(fs_p5.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::FieldPat)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p6 = p0;
            let f_p7 = p1;
            crate::prelude::call_then(start_pattern_names_f(f_p7.pattern_p.clone()), move |pattern_names_f_8789: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &pattern_names_f_8789)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::FieldPat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::syntax::PatternKind::PSigil(_, q_p8) => pattern_names_f(&**q_p8),
        crate::syntax::PatternKind::PTuple(ps_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p9.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pa = p0;
            let q_pb = p1;
            crate::prelude::call_then(start_pattern_names_f(q_pb.clone()), move |pattern_names_f_8903: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pa, &pattern_names_f_8903)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::syntax::PatternKind::PArray(ps_pc) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pc.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pd = p0;
            let q_pe = p1;
            crate::prelude::call_then(start_pattern_names_f(q_pe.clone()), move |pattern_names_f_8972: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pd, &pattern_names_f_8972)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::syntax::PatternKind::PGroup(q_pf) => pattern_names_f(&**q_pf),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `PatternNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatternNames: unbounded fn Pattern -> [Text]
/// ```
pub struct PatternNames {
    pub p_p0: crate::syntax::Pattern,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for PatternNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let p_p0 = &self.p_p0;
        match &*p_p0.kind_p {
            crate::syntax::PatternKind::PName(n_p1) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::check::env::sname_key_f(n_p1)])),
            crate::syntax::PatternKind::PCtor(_, ps_p2) => crate::prelude::fold_job(ps_p2.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let q_p4 = p1;
                crate::prelude::call_then(start_pattern_names_f(q_p4.clone()), move |pattern_names_f_8703: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &pattern_names_f_8703)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::syntax::PatternKind::PRecord(_, fs_p5, _) => crate::prelude::fold_job(fs_p5.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::FieldPat)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let f_p7 = p1;
                crate::prelude::call_then(start_pattern_names_f(f_p7.pattern_p.clone()), move |pattern_names_f_8789: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &pattern_names_f_8789)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::FieldPat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::syntax::PatternKind::PSigil(_, q_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PatternNames { p_p0: (**q_p8).clone() })),
            crate::syntax::PatternKind::PTuple(ps_p9) => crate::prelude::fold_job(ps_p9.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pa = p0;
                let q_pb = p1;
                crate::prelude::call_then(start_pattern_names_f(q_pb.clone()), move |pattern_names_f_8903: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pa, &pattern_names_f_8903)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::syntax::PatternKind::PArray(ps_pc) => crate::prelude::fold_job(ps_pc.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pd = p0;
                let q_pe = p1;
                crate::prelude::call_then(start_pattern_names_f(q_pe.clone()), move |pattern_names_f_8972: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pd, &pattern_names_f_8972)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::syntax::PatternKind::PGroup(q_pf) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PatternNames { p_p0: (**q_pf).clone() })),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start PatternNames, x`: what the function value is when passed to `@Run`.
pub fn start_pattern_names_f(p_p0: crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(PatternNames { p_p0 })
}

/// ```prism
/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
/// ```
pub fn pattern_binders_f(p_p0: &crate::syntax::Pattern) -> crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)> {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p1) => crate::prelude::Array::from(vec![(crate::check::env::sname_key_f(n_p1), n_p1.span_p.clone())]),
        crate::syntax::PatternKind::PCtor(_, ps_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p2.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let q_p4 = p1;
            crate::prelude::call_then(start_pattern_binders_f(q_p4.clone()), move |pattern_binders_f_9292: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &pattern_binders_f_9292)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PRecord(_, fs_p5, _) => crate::prelude::run_to_end(crate::prelude::fold_job(fs_p5.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::FieldPat)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p6 = p0;
            let f_p7 = p1;
            crate::prelude::call_then(start_pattern_binders_f(f_p7.pattern_p.clone()), move |pattern_binders_f_9380: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &pattern_binders_f_9380)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::FieldPat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PSigil(_, q_p8) => pattern_binders_f(&**q_p8),
        crate::syntax::PatternKind::PTuple(ps_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p9.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pa = p0;
            let q_pb = p1;
            crate::prelude::call_then(start_pattern_binders_f(q_pb.clone()), move |pattern_binders_f_9498: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pa, &pattern_binders_f_9498)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PArray(ps_pc) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pc.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pd = p0;
            let q_pe = p1;
            crate::prelude::call_then(start_pattern_binders_f(q_pe.clone()), move |pattern_binders_f_9569: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pd, &pattern_binders_f_9569)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PGroup(q_pf) => pattern_binders_f(&**q_pf),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `PatternBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
/// ```
pub struct PatternBinders {
    pub p_p0: crate::syntax::Pattern,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>> for PatternBinders {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>> {
        let p_p0 = &self.p_p0;
        match &*p_p0.kind_p {
            crate::syntax::PatternKind::PName(n_p1) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![(crate::check::env::sname_key_f(n_p1), n_p1.span_p.clone())])),
            crate::syntax::PatternKind::PCtor(_, ps_p2) => crate::prelude::fold_job(ps_p2.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let q_p4 = p1;
                crate::prelude::call_then(start_pattern_binders_f(q_p4.clone()), move |pattern_binders_f_9292: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &pattern_binders_f_9292)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PRecord(_, fs_p5, _) => crate::prelude::fold_job(fs_p5.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::FieldPat)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let f_p7 = p1;
                crate::prelude::call_then(start_pattern_binders_f(f_p7.pattern_p.clone()), move |pattern_binders_f_9380: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &pattern_binders_f_9380)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::FieldPat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PSigil(_, q_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PatternBinders { p_p0: (**q_p8).clone() })),
            crate::syntax::PatternKind::PTuple(ps_p9) => crate::prelude::fold_job(ps_p9.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pa = p0;
                let q_pb = p1;
                crate::prelude::call_then(start_pattern_binders_f(q_pb.clone()), move |pattern_binders_f_9498: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pa, &pattern_binders_f_9498)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PArray(ps_pc) => crate::prelude::fold_job(ps_pc.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pd = p0;
                let q_pe = p1;
                crate::prelude::call_then(start_pattern_binders_f(q_pe.clone()), move |pattern_binders_f_9569: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pd, &pattern_binders_f_9569)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PGroup(q_pf) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PatternBinders { p_p0: (**q_pf).clone() })),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start PatternBinders, x`: what the function value is when passed to `@Run`.
pub fn start_pattern_binders_f(p_p0: crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>> {
    ::std::rc::Rc::new(PatternBinders { p_p0 })
}

/// ```prism
/// BareTypesOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_types_of_f(g_p0: &crate::check::env::G, src_p1: &crate::prelude::Text, acc_p2: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>) -> crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>> {
    let types_p3 = crate::prelude::fold(&crate::prelude::keys(&g_p0.types_p), acc_p2, &(|a_p4: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, k_p5: &crate::prelude::Text| match crate::prelude::get(&g_p0.types_p, k_p5) {
        ::std::option::Option::Some(ti_p6) => if &ti_p6.home_p == src_p1 {
            add_bare_f(a_p4, &crate::check::types::bare_name_f(&ti_p6.name_p), k_p5)
        } else {
            a_p4.clone()
        },
        ::std::option::Option::None => a_p4.clone(),
    }));
    crate::prelude::fold(&crate::prelude::keys(&g_p0.assoc_names_p), &types_p3, &(|a_p7: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, k_p8: &crate::prelude::Text| match crate::prelude::get(&g_p0.traits_p, &crate::prelude::or(&crate::prelude::get(&g_p0.assoc_names_p, k_p8), &crate::prelude::Text::lit(""))) {
        ::std::option::Option::Some(tr_p9) => if &tr_p9.home_p == src_p1 {
            add_bare_f(a_p7, &crate::check::types::bare_name_f(k_p8), k_p8)
        } else {
            a_p7.clone()
        },
        ::std::option::Option::None => a_p7.clone(),
    }))
}

/// ```prism
/// BareTraitsOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_traits_of_f(g_p0: &crate::check::env::G, src_p1: &crate::prelude::Text, acc_p2: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>) -> crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>> {
    crate::prelude::fold(&crate::prelude::keys(&g_p0.traits_p), acc_p2, &(|a_p3: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, k_p4: &crate::prelude::Text| match crate::prelude::get(&g_p0.traits_p, k_p4) {
        ::std::option::Option::Some(ti_p5) => if &ti_p5.home_p == src_p1 {
            add_bare_f(a_p3, &crate::check::types::bare_name_f(&ti_p5.name_p), k_p4)
        } else {
            a_p3.clone()
        },
        ::std::option::Option::None => a_p3.clone(),
    }))
}

/// ```prism
/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
/// ```
pub fn module_row_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo) -> (crate::check::types::Rw, crate::prelude::Text, crate::check::types::St) {
    match &info_p2.tree_p.emit_row_o {
        ::std::option::Option::None => if info_p2.root_p {
            (g_p0.program_row_p.clone(), crate::prelude::Text::lit(""), st_p1.clone())
        } else {
            (crate::check::types::empty_row_p(), crate::prelude::Text::lit(""), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("emit-element"), &info_p2.tree_p.span_p, &crate::prelude::Text::lit("a library writes its own row; this one writes no `emit` line")))
        },
        ::std::option::Option::Some(row_decl_p3) => {
            let (fams_pa, vars_pb, s2_pc) = crate::prelude::fold(&row_decl_p3.terms_p, &(crate::prelude::Array::new(), crate::prelude::Array::new(), st_p1.clone()), &(|(fs_p6, vs_p7, s_p8): &(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), term_p9: &crate::syntax::RowTerm| row_term_of_f(g_p0, s_p8, info_p2, term_p9, fs_p6, vs_p7)));
            let s3_p4 = if &crate::prelude::len(&vars_pb) > &crate::prelude::Nat::from(1u32) {
                crate::check::types::recording::err_fix_f(&s2_pc, &crate::prelude::Text::lit("row-two-tails"), &row_decl_p3.span_p, &crate::prelude::Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::chars::join_f(&vars_pb, &crate::prelude::Text::lit(" | ")))), &crate::prelude::Text::lit("keep one variable"))
            } else {
                s2_pc.clone()
            };
            let tail_p5 = match crate::prelude::index(&vars_pb, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(v_pd) => crate::check::types::Tail::TlQ(v_pd),
                ::std::option::Option::None => crate::check::types::Tail::TlClosed,
            };
            (crate::check::types::Rw { fams_p: crate::check::types::sort_texts_f(&fams_pa), minus_p: crate::prelude::Array::new(), tail_p: tail_p5.clone() }, crate::prelude::or(&crate::prelude::index(&vars_pb, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), s3_p4.clone())
        },
    }
}

/// The step machine of `ModuleRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
/// ```
pub struct ModuleRow {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
}

impl ::prism_rtl::Job<(crate::check::types::Rw, crate::prelude::Text, crate::check::types::St)> for ModuleRow {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Rw, crate::prelude::Text, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        match &info_p2.tree_p.emit_row_o {
            ::std::option::Option::None => if info_p2.root_p {
                ::prism_rtl::Turn::Finished((g_p0.program_row_p.clone(), crate::prelude::Text::lit(""), st_p1.clone()))
            } else {
                ::prism_rtl::Turn::Finished((crate::check::types::empty_row_p(), crate::prelude::Text::lit(""), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("emit-element"), &info_p2.tree_p.span_p, &crate::prelude::Text::lit("a library writes its own row; this one writes no `emit` line"))))
            },
            ::std::option::Option::Some(row_decl_p3) => {
                let (fams_pa, vars_pb, s2_pc) = crate::prelude::fold(&row_decl_p3.terms_p, &(crate::prelude::Array::new(), crate::prelude::Array::new(), st_p1.clone()), &(|(fs_p6, vs_p7, s_p8): &(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), term_p9: &crate::syntax::RowTerm| row_term_of_f(g_p0, s_p8, info_p2, term_p9, fs_p6, vs_p7)));
                let s3_p4 = if &crate::prelude::len(&vars_pb) > &crate::prelude::Nat::from(1u32) {
                    crate::check::types::recording::err_fix_f(&s2_pc, &crate::prelude::Text::lit("row-two-tails"), &row_decl_p3.span_p, &crate::prelude::Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::chars::join_f(&vars_pb, &crate::prelude::Text::lit(" | ")))), &crate::prelude::Text::lit("keep one variable"))
                } else {
                    s2_pc.clone()
                };
                let tail_p5 = match crate::prelude::index(&vars_pb, &crate::prelude::Nat::from(0u32)) {
                    ::std::option::Option::Some(v_pd) => crate::check::types::Tail::TlQ(v_pd),
                    ::std::option::Option::None => crate::check::types::Tail::TlClosed,
                };
                ::prism_rtl::Turn::Finished((crate::check::types::Rw { fams_p: crate::check::types::sort_texts_f(&fams_pa), minus_p: crate::prelude::Array::new(), tail_p: tail_p5.clone() }, crate::prelude::or(&crate::prelude::index(&vars_pb, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), s3_p4.clone()))
            },
        }
    }
}

/// `Start ModuleRow, x`: what the function value is when passed to `@Run`.
pub fn start_module_row_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Rw, crate::prelude::Text, crate::check::types::St)>> {
    ::std::rc::Rc::new(ModuleRow { g_p0, st_p1, info_p2 })
}

/// ```prism
/// RowTermOf: fn G, St, ModInfo, RowTerm, [Text], [Text] -> (([Text], [Text], St))
/// ```
pub fn row_term_of_f(g_p0: &crate::check::env::G, s_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, term_p3: &crate::syntax::RowTerm, fs_p4: &crate::prelude::Array<crate::prelude::Text>, vs_p5: &crate::prelude::Array<crate::prelude::Text>) -> (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St) {
    match term_p3 {
        crate::syntax::RowTerm::RFamily(q_p6) => (crate::prelude::push(fs_p4, &crate::check::env::dotted_f(&q_p6.path_p)), vs_p5.clone(), check_family_f(g_p0, s_p1, &crate::check::env::dotted_f(&q_p6.path_p), &q_p6.span_p)),
        crate::syntax::RowTerm::RVar(v_p7) => (fs_p4.clone(), crate::prelude::push(vs_p5, &v_p7.name_p), s_p1.clone()),
        crate::syntax::RowTerm::RType(t_p8) => match &*t_p8.kind_p {
            crate::syntax::TypeKind::TName(n_p9, m11652_0_1) if (m11652_0_1.len() == 0) => {
                let name_pa = crate::check::env::dotted_f(&n_p9.path_p);
                if (&name_pa == &crate::prelude::Text::lit("Element")) && info_p2.root_p {
                    (crate::prelude::append(fs_p4, &g_p0.program_row_p.fams_p), vs_p5.clone(), s_p1.clone())
                } else {
                    if &name_pa == &crate::prelude::Text::lit("Element") {
                        (fs_p4.clone(), vs_p5.clone(), crate::check::types::recording::err_f(s_p1, &crate::prelude::Text::lit("emit-element"), &t_p8.span_p, &crate::prelude::Text::lit("a library writes its own row; `emit Element` names the program\'s")))
                    } else {
                        if crate::check::env::has_key_f(&g_p0.tags_p, &name_pa) || (&crate::prelude::len(&n_p9.path_p) > &crate::prelude::Nat::from(1u32)) {
                            (fs_p4.clone(), vs_p5.clone(), crate::check::types::recording::err_fix_f(s_p1, &crate::prelude::Text::lit("row-single-tag"), &t_p8.span_p, &crate::prelude::Text::from(format!("a row names families, not tags: `{}`", &name_pa)), &crate::prelude::Text::from(format!("write `{}.*`", &crate::check::env::dotted_f(&crate::prelude::take(&n_p9.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&n_p9.path_p))))))))
                        } else {
                            (fs_p4.clone(), vs_p5.clone(), crate::check::types::recording::err_f(s_p1, &crate::prelude::Text::lit("kind"), &t_p8.span_p, &crate::prelude::Text::from(format!("`{}` is not a row", &name_pa))))
                        }
                    }
                }
            },
            _ => (fs_p4.clone(), vs_p5.clone(), crate::check::types::recording::err_f(s_p1, &crate::prelude::Text::lit("kind"), &t_p8.span_p, &crate::prelude::Text::lit("this is not a row"))),
            _ => unreachable!("no arm matched"),
        },
    }
}

/// ```prism
/// CheckFamily: fn G, St, Text, Range -> St
/// ```
pub fn check_family_f(g_p0: &crate::check::env::G, s_p1: &crate::check::types::St, fam_p2: &crate::prelude::Text, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    if crate::check::env::has_key_f(&g_p0.families_p, fam_p2) {
        s_p1.clone()
    } else {
        crate::check::types::recording::err_f(s_p1, &crate::prelude::Text::lit("unknown-name"), span_p3, &crate::prelude::Text::from(format!("no family `{}`: no module declares a `{}.` tag", fam_p2, fam_p2)))
    }
}

/// ```prism
/// ResolveValue: fn G, Text, SName -> ((?Text, Text))
/// ```
pub fn resolve_value_f(g_p0: &crate::check::env::G, m_p1: &crate::prelude::Text, n_p2: &crate::syntax::SName) -> (::std::option::Option<crate::prelude::Text>, crate::prelude::Text) {
    let marks_p3 = n_p2.sigils_p.clone();
    if &crate::prelude::len(&n_p2.path_p) == &crate::prelude::Nat::from(1u32) {
        {
            let name_p4 = crate::prelude::Text::from(format!("{}{}", &marks_p3, &crate::prelude::or(&crate::prelude::index(&n_p2.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""))));
            let table_p5 = crate::prelude::or(&crate::prelude::get(&g_p0.bare_p, m_p1), &crate::prelude::Map::new());
            let keys_p6 = crate::prelude::or(&crate::prelude::get(&table_p5, &name_p4), &crate::prelude::Array::new());
            if &crate::prelude::len(&keys_p6) == &crate::prelude::Nat::from(1u32) {
                (crate::prelude::index(&keys_p6, &crate::prelude::Nat::from(0u32)), crate::prelude::Text::lit(""))
            } else {
                if &crate::prelude::len(&keys_p6) > &crate::prelude::Nat::from(1u32) {
                    (::std::option::Option::Some(own_first_f(m_p1, &keys_p6)), crate::prelude::Text::lit("collision"))
                } else {
                    if &name_p4 == &crate::prelude::Text::lit("never") {
                        (::std::option::Option::Some(crate::prelude::Text::lit("Prelude.never")), crate::prelude::Text::lit(""))
                    } else {
                        if crate::check::env::has_key_f(&g_p0.ctors_p, &name_p4) {
                            (::std::option::Option::Some(name_p4.clone()), crate::prelude::Text::lit(""))
                        } else {
                            (::std::option::Option::None, crate::prelude::Text::lit("unknown"))
                        }
                    }
                }
            }
        }
    } else {
        {
            let qual_p7 = crate::check::env::qual_module_f(g_p0, &crate::prelude::take(&n_p2.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&n_p2.path_p))));
            let last_p8 = crate::prelude::or(&crate::syntax::lexer::chars::last_o(&n_p2.path_p), &crate::prelude::Text::lit(""));
            let qk_p9 = crate::check::env::qual_key_f(&qual_p7, &crate::prelude::Text::from(format!("{}{}", &marks_p3, &last_p8)));
            if (&crate::prelude::len_text(&marks_p3) == &crate::prelude::Nat::from(0u32)) && crate::check::env::has_key_f(&g_p0.tags_p, &crate::check::env::dotted_f(&n_p2.path_p)) {
                (::std::option::Option::Some(crate::check::env::dotted_f(&n_p2.path_p)), crate::prelude::Text::lit("tag"))
            } else {
                if ((&crate::prelude::len_text(&marks_p3) == &crate::prelude::Nat::from(0u32)) && (&last_p8 == &answer_constructor_p())) && declares_element_tag_f(g_p0, &crate::check::env::dotted_f(&crate::prelude::take(&n_p2.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&n_p2.path_p))))) {
                    (::std::option::Option::Some(crate::check::env::dotted_f(&n_p2.path_p)), crate::prelude::Text::lit("answer"))
                } else {
                    if crate::check::env::has_key_f(&g_p0.vals_p, &qk_p9) || crate::check::env::has_key_f(&g_p0.ctors_p, &qk_p9) {
                        (::std::option::Option::Some(qk_p9.clone()), crate::prelude::Text::lit(""))
                    } else {
                        if crate::prelude::fold(&g_p0.defs_p, &false, &(|found_pa: &bool, d_pb: &crate::check::env::Def| *found_pa || (&d_pb.qk_p == &qk_p9))) {
                            (::std::option::Option::Some(qk_p9.clone()), crate::prelude::Text::lit(""))
                        } else {
                            (::std::option::Option::None, crate::prelude::Text::lit("unknown"))
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// ?QualifiedField: fn G, Text, Expr, Text, Ident -> ?SName
/// ```
pub fn qualified_field_o(g_p0: &crate::check::env::G, m_p1: &crate::prelude::Text, recv_p2: &crate::syntax::Expr, sigils_p3: &crate::prelude::Text, name_p4: &crate::syntax::Ident) -> ::std::option::Option<crate::syntax::SName> {
    match &*recv_p2.kind_p {
        crate::syntax::ExprKind::EName(r_p5) => if (&r_p5.sigils_p != &crate::prelude::Text::lit("")) && (sigils_p3 != &crate::prelude::Text::lit("")) {
            ::std::option::Option::None
        } else {
            {
                let (value_o7, _) = resolve_value_f(g_p0, m_p1, r_p5);
                let n_p6 = crate::syntax::SName { sigils_p: if &r_p5.sigils_p != &crate::prelude::Text::lit("") {
                    r_p5.sigils_p.clone()
                } else {
                    sigils_p3.clone()
                }, path_p: crate::prelude::push(&r_p5.path_p, &name_p4.name_p), span_p: r_p5.span_p.clone() };
                let (qk_o8, why_p9) = resolve_value_f(g_p0, m_p1, &n_p6);
                match (value_o7.clone(), qk_o8.clone()) {
                    (::std::option::Option::None, ::std::option::Option::Some(_)) => if &why_p9 == &crate::prelude::Text::lit("") {
                        ::std::option::Option::Some(n_p6.clone())
                    } else {
                        ::std::option::Option::None
                    },
                    _ => ::std::option::Option::None,
                }
            }
        },
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// TraitCollisionAt: fn G, St, Text, [Text], Range -> St
/// ```
pub fn trait_collision_at_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, m_p2: &crate::prelude::Text, path_p3: &crate::prelude::Array<crate::prelude::Text>, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    let keys_p5 = if &crate::prelude::len(path_p3) == &crate::prelude::Nat::from(1u32) {
        crate::prelude::or(&crate::prelude::get(&crate::prelude::or(&crate::prelude::get(&g_p0.bare_traits_p, m_p2), &crate::prelude::Map::new()), &crate::prelude::or(&crate::prelude::index(path_p3, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""))), &crate::prelude::Array::new())
    } else {
        crate::prelude::Array::new()
    };
    if &crate::prelude::len(&keys_p5) < &crate::prelude::Nat::from(2u32) {
        st_p1.clone()
    } else {
        {
            let qualified_p6 = crate::prelude::filter(&keys_p5, &(|k_p7: &crate::prelude::Text| crate::syntax::lexer::chars::contains_f(k_p7, &crate::prelude::Text::lit("."))));
            crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("collision"), span_p4, &crate::prelude::Text::from(format!("`^{}` is declared by more than one module this file reaches by a bare name: {}", &crate::check::env::dotted_f(path_p3), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&keys_p5, &(|k_p8: &crate::prelude::Text| crate::prelude::Text::from(format!("`^{}`", k_p8)))), &crate::prelude::Text::lit(", ")))), &crate::prelude::Text::from(format!("write the one meant qualified, as `^{}`", &crate::prelude::or(&crate::prelude::index(&qualified_p6, &crate::prelude::Nat::from(0u32)), &crate::check::env::dotted_f(path_p3)))))
        }
    }
}

/// ```prism
/// let answerConstructor
/// ```
pub fn answer_constructor_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("Answer")
}

/// ```prism
/// AnswerTag: fn Text -> Text
/// ```
pub fn answer_tag_f(constructor_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::or(&crate::syntax::lexer::chars::before_suffix_o(constructor_p0, &crate::prelude::Text::from(format!(".{}", &answer_constructor_p()))), constructor_p0)
}

/// ```prism
/// DeclaresElementTag: fn G, Text -> Bool
/// ```
pub fn declares_element_tag_f(g_p0: &crate::check::env::G, name_p1: &crate::prelude::Text) -> bool {
    match crate::prelude::get(&g_p0.tags_p, name_p1) {
        ::std::option::Option::Some(tg_p2) => &tg_p2.kind_p == &crate::prelude::Text::lit("Element"),
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// ResolveType: fn G, Text, [Text] -> ((?Text, Text))
/// ```
pub fn resolve_type_f(g_p0: &crate::check::env::G, m_p1: &crate::prelude::Text, path_p2: &crate::prelude::Array<crate::prelude::Text>) -> (::std::option::Option<crate::prelude::Text>, crate::prelude::Text) {
    if &crate::prelude::len(path_p2) == &crate::prelude::Nat::from(1u32) {
        {
            let keys_p3 = crate::prelude::or(&crate::prelude::get(&crate::prelude::or(&crate::prelude::get(&g_p0.bare_types_p, m_p1), &crate::prelude::Map::new()), &crate::prelude::or(&crate::prelude::index(path_p2, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""))), &crate::prelude::Array::new());
            if &crate::prelude::len(&keys_p3) == &crate::prelude::Nat::from(1u32) {
                (crate::prelude::index(&keys_p3, &crate::prelude::Nat::from(0u32)), crate::prelude::Text::lit(""))
            } else {
                if &crate::prelude::len(&keys_p3) > &crate::prelude::Nat::from(1u32) {
                    (::std::option::Option::Some(own_first_f(m_p1, &keys_p3)), crate::prelude::Text::lit("collision"))
                } else {
                    (::std::option::Option::None, crate::prelude::Text::lit("unknown"))
                }
            }
        }
    } else {
        {
            let qk_p4 = crate::check::env::qual_key_f(&crate::check::env::qual_module_f(g_p0, &crate::prelude::take(path_p2, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(path_p2)))), &crate::prelude::or(&crate::syntax::lexer::chars::last_o(path_p2), &crate::prelude::Text::lit("")));
            if crate::check::env::has_key_f(&g_p0.types_p, &qk_p4) || crate::check::env::has_key_f(&g_p0.assoc_names_p, &qk_p4) {
                (::std::option::Option::Some(qk_p4.clone()), crate::prelude::Text::lit(""))
            } else {
                (::std::option::Option::None, crate::prelude::Text::lit("unknown"))
            }
        }
    }
}

/// ```prism
/// OwnFirst: fn Text, [Text] -> Text
/// ```
pub fn own_first_f(m_p0: &crate::prelude::Text, keys_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    let own_p2 = crate::prelude::filter(keys_p1, &(|k_p3: &crate::prelude::Text| (&crate::check::env::qual_key_f(m_p0, &crate::check::types::bare_name_f(k_p3)) == k_p3) || ((m_p0 == &crate::prelude::Text::lit("")) && !crate::syntax::lexer::chars::contains_f(k_p3, &crate::prelude::Text::lit(".")))));
    crate::prelude::or(&crate::prelude::index(&own_p2, &crate::prelude::Nat::from(0u32)), &crate::prelude::or(&crate::prelude::index(keys_p1, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")))
}

/// ```prism
/// ?ResolveTrait: fn G, Text, [Text] -> ?Text
/// ```
pub fn resolve_trait_o(g_p0: &crate::check::env::G, m_p1: &crate::prelude::Text, path_p2: &crate::prelude::Array<crate::prelude::Text>) -> ::std::option::Option<crate::prelude::Text> {
    if &crate::prelude::len(path_p2) == &crate::prelude::Nat::from(1u32) {
        {
            let keys_p3 = crate::prelude::or(&crate::prelude::get(&crate::prelude::or(&crate::prelude::get(&g_p0.bare_traits_p, m_p1), &crate::prelude::Map::new()), &crate::prelude::or(&crate::prelude::index(path_p2, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""))), &crate::prelude::Array::new());
            crate::prelude::index(&keys_p3, &crate::prelude::Nat::from(0u32))
        }
    } else {
        {
            let qk_p4 = crate::check::env::qual_key_f(&crate::check::env::qual_module_f(g_p0, &crate::prelude::take(path_p2, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(path_p2)))), &crate::prelude::or(&crate::syntax::lexer::chars::last_o(path_p2), &crate::prelude::Text::lit("")));
            if crate::check::env::has_key_f(&g_p0.traits_p, &qk_p4) {
                ::std::option::Option::Some(qk_p4.clone())
            } else {
                ::std::option::Option::None
            }
        }
    }
}
