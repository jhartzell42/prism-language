//! The module `Check.Env.Names`, from `target/bootstrap/src/prismc/check/env/names.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// CollectNames: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn collect_names(g: &crate::check::env::G, st: &crate::check::types::St, m: &Text) -> (crate::check::env::G, crate::check::types::St) {
    match get(&g.mods, m) {
        None => (g.clone(), st.clone()),
        Some(info) => {
            let s0 = {
                let mut this: crate::check::types::St = st.clone();
                this.file = info.file.clone();
                this
            };
            let (g2, s2, _) = run_to_end(fold_job(info.tree.decls.clone(), (g.clone(), s0.clone(), None), {
                let info = info.clone();
                Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St, Option<Text>), crate::syntax::decls::Decl)| {
                    let info = info.clone();
                    entered(once_job(move || {
                        let (gg, s, last_type_opt) = p0;
                        let d = p1;
                        prism_rtl::Turn::More(Rc::new(CollectDecl { g: gg.clone(), st: s.clone(), info: info.clone(), d: d.clone(), last_type_opt: last_type_opt.clone() }))
                    }))
                }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St, Option<Text>), crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Option<Text>)>>>
            }));
            (g2.clone(), s2.clone())
        },
    }
}

/// The step machine of `CollectNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollectNames: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct CollectNames {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub m: Text,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for CollectNames {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let m = &self.m;
        match get(&g.mods, m) {
            None => prism_rtl::Turn::Finished((g.clone(), st.clone())),
            Some(info) => {
                let s0 = {
                    let mut this: crate::check::types::St = st.clone();
                    this.file = info.file.clone();
                    this
                };
                let g = g.clone();
                call_value(fold_job(info.tree.decls.clone(), (g.clone(), s0.clone(), None), {
                    let info = info.clone();
                    Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St, Option<Text>), crate::syntax::decls::Decl)| {
                        let info = info.clone();
                        entered(once_job(move || {
                            let (gg, s, last_type_opt) = p0;
                            let d = p1;
                            prism_rtl::Turn::More(Rc::new(CollectDecl { g: gg.clone(), st: s.clone(), info: info.clone(), d: d.clone(), last_type_opt: last_type_opt.clone() }))
                        }))
                    }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St, Option<Text>), crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Option<Text>)>>>
                }), move |fold_1030: (crate::check::env::G, crate::check::types::St, Option<Text>)| {
                    let (g2, s2, _) = fold_1030;
                    prism_rtl::Turn::Finished((g2.clone(), s2.clone()))
                })
            },
        }
    }
}

/// `Start CollectNames, x`: what the function value is when passed to `@Run`.
pub fn start_collect_names(g: crate::check::env::G, st: crate::check::types::St, m: Text) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(CollectNames { g, st, m })
}

/// ```prism
/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
/// ```
pub fn collect_decl(g: &crate::check::env::G, st: &crate::check::types::St, info: &crate::check::env::ModInfo, d: &crate::syntax::decls::Decl, last_type_opt: &Option<Text>) -> (crate::check::env::G, crate::check::types::St, Option<Text>) {
    match &d.kind {
        crate::syntax::decls::DeclKind::DType(t) => {
            let name = crate::check::env::qual_key(&info.name, &crate::check::env::dotted(&t.name.path_));
            let ti = crate::check::env::TyInfo { name: name.clone(), home: info.name.clone(), params: each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone())), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: info.file.clone(), span: d.span.clone() };
            if crate::check::env::has_key(&g.types, &name) {
                (g.clone(), crate::check::types::recording::err(st, &Text::lit("collision"), &d.span, &Text::from(format!("a second type `{}`", &crate::check::env::dotted(&t.name.path_)))), last_type_opt.clone())
            } else {
                {
                    let upd = {
                        let mut this: crate::check::env::G = g.clone();
                        this.types = insert(&this.types, &name, &ti);
                        this
                    };
                    (upd.clone(), st.clone(), Some(name.clone()))
                }
            }
        },
        crate::syntax::decls::DeclKind::DDerive(trs) => match last_type_opt {
            Some(tn) => {
                let upd = {
                    let mut this: crate::check::env::G = g.clone();
                    this.types = insert(&this.types, tn, &add_derives(&or(&get(&g.types, tn), &dummy_ty_info()), &each(trs, &(|tr: &crate::syntax::TraitRef| crate::check::env::dotted(&tr.path_)))));
                    this
                };
                (upd.clone(), st.clone(), last_type_opt.clone())
            },
            None => (g.clone(), crate::check::types::recording::err(st, &Text::lit("mismatch"), &d.span, &Text::lit("a `derive` line follows a type declaration")), None),
        },
        crate::syntax::decls::DeclKind::DTag(t) => {
            let name = crate::check::env::dotted(&t.name.path_);
            let family = crate::check::env::dotted(&take(&t.name.path_, &crate::syntax::lexer::chars::dec(&len(&t.name.path_))));
            let tags = or(&get(&g.families, &family), &Array::new());
            let owner = or(&get(&g.fam_owner, &family), &info.name);
            let st2 = if &owner != &info.name {
                crate::check::types::recording::err(st, &Text::lit("collision"), &d.span, &Text::from(format!("the family `{}` is declared in {}; every tag of a family is declared in its family\'s module", &family, &(if &owner == &Text::lit("") {
                    Text::lit("the root")
                } else {
                    Text::from(format!("`{}`", &owner))
                }))))
            } else {
                st.clone()
            };
            let is_elem = match &*t.of_type.kind {
                crate::syntax::TypeKind::TName(n, _) => &crate::check::env::dotted(&n.path_) == &Text::lit("Element"),
                _ => false,
            };
            let g2 = {
                let mut this: crate::check::env::G = g.clone();
                this.families = insert(&this.families, &family, &push(&tags, &name));
                this.fam_owner = insert(&this.fam_owner, &family, &owner);
                if is_elem {
                    this.elem_fams = crate::check::types::add_text(&this.elem_fams, &family);
                }
                this
            };
            (g2.clone(), st2.clone(), None)
        },
        crate::syntax::decls::DeclKind::DTrait(t) => {
            let name = crate::check::env::qual_key(&info.name, &crate::check::env::dotted(&t.name.path_));
            let ti = crate::check::env::TraitInfo { name: name.clone(), home: info.name.clone(), param: or(&index(&each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone())), &Nat::from(0u32)), &Text::lit("a")), supers: Array::new(), methods: Array::new(), defaults: Array::new(), assocs: Array::new(), file: info.file.clone(), span: d.span.clone() };
            let upd = {
                let mut this: crate::check::env::G = g.clone();
                this.traits = insert(&this.traits, &name, &ti);
                this
            };
            (upd.clone(), st.clone(), None)
        },
        _ => (g.clone(), st.clone(), None),
    }
}

/// The step machine of `CollectDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
/// ```
pub struct CollectDecl {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub info: crate::check::env::ModInfo,
    pub d: crate::syntax::decls::Decl,
    pub last_type_opt: Option<Text>,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Option<Text>)> for CollectDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St, Option<Text>)> {
        let g = &self.g;
        let st = &self.st;
        let info = &self.info;
        let d = &self.d;
        let last_type_opt = &self.last_type_opt;
        match &d.kind {
            crate::syntax::decls::DeclKind::DType(t) => {
                let name = crate::check::env::qual_key(&info.name, &crate::check::env::dotted(&t.name.path_));
                let ti = crate::check::env::TyInfo { name: name.clone(), home: info.name.clone(), params: each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone())), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: info.file.clone(), span: d.span.clone() };
                if crate::check::env::has_key(&g.types, &name) {
                    prism_rtl::Turn::Finished((g.clone(), crate::check::types::recording::err(st, &Text::lit("collision"), &d.span, &Text::from(format!("a second type `{}`", &crate::check::env::dotted(&t.name.path_)))), last_type_opt.clone()))
                } else {
                    {
                        let upd = {
                            let mut this: crate::check::env::G = g.clone();
                            this.types = insert(&this.types, &name, &ti);
                            this
                        };
                        prism_rtl::Turn::Finished((upd.clone(), st.clone(), Some(name.clone())))
                    }
                }
            },
            crate::syntax::decls::DeclKind::DDerive(trs) => match last_type_opt {
                Some(tn) => {
                    let upd = {
                        let mut this: crate::check::env::G = g.clone();
                        this.types = insert(&this.types, tn, &add_derives(&or(&get(&g.types, tn), &dummy_ty_info()), &each(trs, &(|tr: &crate::syntax::TraitRef| crate::check::env::dotted(&tr.path_)))));
                        this
                    };
                    prism_rtl::Turn::Finished((upd.clone(), st.clone(), last_type_opt.clone()))
                },
                None => prism_rtl::Turn::Finished((g.clone(), crate::check::types::recording::err(st, &Text::lit("mismatch"), &d.span, &Text::lit("a `derive` line follows a type declaration")), None)),
            },
            crate::syntax::decls::DeclKind::DTag(t) => {
                let name = crate::check::env::dotted(&t.name.path_);
                let family = crate::check::env::dotted(&take(&t.name.path_, &crate::syntax::lexer::chars::dec(&len(&t.name.path_))));
                let tags = or(&get(&g.families, &family), &Array::new());
                let owner = or(&get(&g.fam_owner, &family), &info.name);
                let st2 = if &owner != &info.name {
                    crate::check::types::recording::err(st, &Text::lit("collision"), &d.span, &Text::from(format!("the family `{}` is declared in {}; every tag of a family is declared in its family\'s module", &family, &(if &owner == &Text::lit("") {
                        Text::lit("the root")
                    } else {
                        Text::from(format!("`{}`", &owner))
                    }))))
                } else {
                    st.clone()
                };
                let is_elem = match &*t.of_type.kind {
                    crate::syntax::TypeKind::TName(n, _) => &crate::check::env::dotted(&n.path_) == &Text::lit("Element"),
                    _ => false,
                };
                let g2 = {
                    let mut this: crate::check::env::G = g.clone();
                    this.families = insert(&this.families, &family, &push(&tags, &name));
                    this.fam_owner = insert(&this.fam_owner, &family, &owner);
                    if is_elem {
                        this.elem_fams = crate::check::types::add_text(&this.elem_fams, &family);
                    }
                    this
                };
                prism_rtl::Turn::Finished((g2.clone(), st2.clone(), None))
            },
            crate::syntax::decls::DeclKind::DTrait(t) => {
                let name = crate::check::env::qual_key(&info.name, &crate::check::env::dotted(&t.name.path_));
                let ti = crate::check::env::TraitInfo { name: name.clone(), home: info.name.clone(), param: or(&index(&each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone())), &Nat::from(0u32)), &Text::lit("a")), supers: Array::new(), methods: Array::new(), defaults: Array::new(), assocs: Array::new(), file: info.file.clone(), span: d.span.clone() };
                let upd = {
                    let mut this: crate::check::env::G = g.clone();
                    this.traits = insert(&this.traits, &name, &ti);
                    this
                };
                prism_rtl::Turn::Finished((upd.clone(), st.clone(), None))
            },
            _ => prism_rtl::Turn::Finished((g.clone(), st.clone(), None)),
        }
    }
}

/// `Start CollectDecl, x`: what the function value is when passed to `@Run`.
pub fn start_collect_decl(g: crate::check::env::G, st: crate::check::types::St, info: crate::check::env::ModInfo, d: crate::syntax::decls::Decl, last_type_opt: Option<Text>) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Option<Text>)>> {
    Rc::new(CollectDecl { g, st, info, d, last_type_opt })
}

/// ```prism
/// let dummyTyInfo
/// ```
pub fn dummy_ty_info() -> crate::check::env::TyInfo {
    crate::check::env::TyInfo { name: Text::lit(""), home: Text::lit(""), params: Array::new(), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// AddDerives: fn TyInfo, [Text] -> TyInfo
/// ```
pub fn add_derives(ti: &crate::check::env::TyInfo, trs: &Array<Text>) -> crate::check::env::TyInfo {
    let mut this: crate::check::env::TyInfo = ti.clone();
    this.derives = append(&this.derives, trs);
    this
}

/// ```prism
/// ProgramRow: fn G -> Rw
/// ```
pub fn program_row(g: &crate::check::env::G) -> crate::check::types::Rw {
    crate::check::types::closed(&g.elem_fams)
}

/// ```prism
/// BuildTables: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn build_tables(g: &crate::check::env::G, st: &crate::check::types::St, m: &Text) -> (crate::check::env::G, crate::check::types::St) {
    match get(&g.mods, m) {
        None => (g.clone(), st.clone()),
        Some(info) => {
            let s0 = {
                let mut this: crate::check::types::St = st.clone();
                this.file = info.file.clone();
                this
            };
            let s1 = fold(&info.uses, &s0, &(|s: &crate::check::types::St, (u, _): &(Text, bool)| if crate::check::env::has_key(&g.mods, u) || (u == &Text::lit("Prelude")) {
                s.clone()
            } else {
                crate::check::types::recording::err(s, &Text::lit("unknown-name"), &info.tree.span, &Text::from(format!("no module `{}` among the program\'s files", u)))
            }));
            let starred = fold(&info.uses, &Array::new(), &(|acc: &Array<Text>, (u, star): &(Text, bool)| if *star && (u != m) { push(acc, u) } else { acc.clone() }));
            let sources = crate::check::types::add_text(&append(&Array::from(vec![m.clone()]), &starred), &Text::lit("Prelude"));
            let vals = run_to_end(fold_job(sources.clone(), Map::new(), {
                let g = g.clone();
                Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                    let g = g.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let src = p1;
                        prism_rtl::Turn::More(Rc::new(BareValuesOf { g: g.clone(), src: src.clone(), acc: acc.clone() }))
                    }))
                }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
            }));
            let tys = fold(&sources, &Map::new(), &(|acc: &Map<Text, Array<Text>>, src: &Text| bare_types_of(g, src, acc)));
            let trs = fold(&sources, &Map::new(), &(|acc: &Map<Text, Array<Text>>, src: &Text| bare_traits_of(g, src, acc)));
            let (rw, rv, s2) = module_row(g, &s1, &info);
            let info2 = {
                let mut this: crate::check::env::ModInfo = info.clone();
                this.emit_rw = rw.clone();
                this.row_var = rv.clone();
                this
            };
            let upd = {
                let mut this: crate::check::env::G = g.clone();
                this.bare = insert(&this.bare, m, &vals);
                this.bare_types = insert(&this.bare_types, m, &tys);
                this.bare_traits = insert(&this.bare_traits, m, &trs);
                this.mods = insert(&this.mods, m, &info2);
                this
            };
            (upd.clone(), s2.clone())
        },
    }
}

/// The step machine of `BuildTables`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildTables: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct BuildTables {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub m: Text,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for BuildTables {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let m = &self.m;
        match get(&g.mods, m) {
            None => prism_rtl::Turn::Finished((g.clone(), st.clone())),
            Some(info) => {
                let s0 = {
                    let mut this: crate::check::types::St = st.clone();
                    this.file = info.file.clone();
                    this
                };
                let s1 = fold(&info.uses, &s0, &(|s: &crate::check::types::St, (u, _): &(Text, bool)| if crate::check::env::has_key(&g.mods, u) || (u == &Text::lit("Prelude")) {
                    s.clone()
                } else {
                    crate::check::types::recording::err(s, &Text::lit("unknown-name"), &info.tree.span, &Text::from(format!("no module `{}` among the program\'s files", u)))
                }));
                let starred = fold(&info.uses, &Array::new(), &(|acc: &Array<Text>, (u, star): &(Text, bool)| if *star && (u != m) { push(acc, u) } else { acc.clone() }));
                let sources = crate::check::types::add_text(&append(&Array::from(vec![m.clone()]), &starred), &Text::lit("Prelude"));
                let g = g.clone();
                let m = m.clone();
                call_value(fold_job(sources.clone(), Map::new(), {
                    let g = g.clone();
                    Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                        let g = g.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let src = p1;
                            prism_rtl::Turn::More(Rc::new(BareValuesOf { g: g.clone(), src: src.clone(), acc: acc.clone() }))
                        }))
                    }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
                }), move |fold_4611: Map<Text, Array<Text>>| {
                    let vals = fold_4611;
                    let tys = fold(&sources, &Map::new(), &(|acc: &Map<Text, Array<Text>>, src: &Text| bare_types_of(&g, src, acc)));
                    let trs = fold(&sources, &Map::new(), &(|acc: &Map<Text, Array<Text>>, src: &Text| bare_traits_of(&g, src, acc)));
                    call_then(start_module_row(g.clone(), s1.clone(), info.clone()), move |module_row_4840: (crate::check::types::Rw, Text, crate::check::types::St)| {
                        let (rw, rv, s2) = module_row_4840;
                        let info2 = {
                            let mut this: crate::check::env::ModInfo = info.clone();
                            this.emit_rw = rw.clone();
                            this.row_var = rv.clone();
                            this
                        };
                        let upd = {
                            let mut this: crate::check::env::G = g.clone();
                            this.bare = insert(&this.bare, &m, &vals);
                            this.bare_types = insert(&this.bare_types, &m, &tys);
                            this.bare_traits = insert(&this.bare_traits, &m, &trs);
                            this.mods = insert(&this.mods, &m, &info2);
                            this
                        };
                        prism_rtl::Turn::Finished((upd.clone(), s2.clone()))
                    })
                })
            },
        }
    }
}

/// `Start BuildTables, x`: what the function value is when passed to `@Run`.
pub fn start_build_tables(g: crate::check::env::G, st: crate::check::types::St, m: Text) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(BuildTables { g, st, m })
}

/// ```prism
/// AddBare: fn (Text ==> [Text]), Text, Text -> (Text ==> [Text])
/// ```
pub fn add_bare(acc: &Map<Text, Array<Text>>, name: &Text, qk: &Text) -> Map<Text, Array<Text>> {
    let have = or(&get(acc, name), &Array::new());
    if crate::check::types::has_text(&have, qk) {
        acc.clone()
    } else {
        insert(acc, name, &push(&have, qk))
    }
}

/// ```prism
/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_values_of(g: &crate::check::env::G, src: &Text, acc: &Map<Text, Array<Text>>) -> Map<Text, Array<Text>> {
    match get(&g.mods, src) {
        None => acc.clone(),
        Some(info) => run_to_end(fold_job(info.tree.decls.clone(), acc.clone(), {
            let src = src.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::syntax::decls::Decl)| {
                let src = src.clone();
                entered(once_job(move || {
                    let a = p0;
                    let d = p1;
                    prism_rtl::Turn::More(Rc::new(BareOfDecl { m: src.clone(), acc: a.clone(), d: d.clone() }))
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        })),
    }
}

/// The step machine of `BareValuesOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub struct BareValuesOf {
    pub g: crate::check::env::G,
    pub src: Text,
    pub acc: Map<Text, Array<Text>>,
}

impl prism_rtl::Job<Map<Text, Array<Text>>> for BareValuesOf {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<Text>>> {
        let g = &self.g;
        let src = &self.src;
        let acc = &self.acc;
        match get(&g.mods, src) {
            None => prism_rtl::Turn::Finished(acc.clone()),
            Some(info) => fold_job(info.tree.decls.clone(), acc.clone(), {
                let src = src.clone();
                Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::syntax::decls::Decl)| {
                    let src = src.clone();
                    entered(once_job(move || {
                        let a = p0;
                        let d = p1;
                        prism_rtl::Turn::More(Rc::new(BareOfDecl { m: src.clone(), acc: a.clone(), d: d.clone() }))
                    }))
                }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
            }).cycle(),
        }
    }
}

/// `Start BareValuesOf, x`: what the function value is when passed to `@Run`.
pub fn start_bare_values_of(g: crate::check::env::G, src: Text, acc: Map<Text, Array<Text>>) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>> {
    Rc::new(BareValuesOf { g, src, acc })
}

/// ```prism
/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
/// ```
pub fn bare_of_decl(m: &Text, acc: &Map<Text, Array<Text>>, d: &crate::syntax::decls::Decl) -> Map<Text, Array<Text>> {
    match &d.kind {
        crate::syntax::decls::DeclKind::DSignature(s) => add_bare(acc, &crate::check::env::def_name_text(&s.name), &crate::check::env::qual_key(m, &crate::check::env::def_name_text(&s.name))),
        crate::syntax::decls::DeclKind::DFn(f) => add_bare(acc, &crate::check::env::def_name_text(&f.name), &crate::check::env::qual_key(m, &crate::check::env::def_name_text(&f.name))),
        crate::syntax::decls::DeclKind::DLet(l) => fold(&pattern_names(&l.pattern), acc, &(|a: &Map<Text, Array<Text>>, n: &Text| add_bare(a, n, &crate::check::env::qual_key(m, n)))),
        crate::syntax::decls::DeclKind::DWidget(w) => add_bare(acc, &crate::check::env::sname_key(&w.name), &crate::check::env::qual_key(m, &crate::check::env::sname_key(&w.name))),
        crate::syntax::decls::DeclKind::DType(t) => fold(&ctor_names_of(t), acc, &(|a: &Map<Text, Array<Text>>, c: &Text| add_bare(a, c, &crate::check::env::qual_key(m, c)))),
        crate::syntax::decls::DeclKind::DTrait(t) => fold(&t.items, acc, &(|a: &Map<Text, Array<Text>>, it: &crate::syntax::decls::TraitItem| match it {
            crate::syntax::decls::TraitItem::TiSignature(s) => add_bare(a, &crate::check::env::def_name_text(&s.name), &crate::check::env::qual_key(m, &crate::check::env::def_name_text(&s.name))),
            _ => a.clone(),
        })),
        _ => acc.clone(),
    }
}

/// The step machine of `BareOfDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
/// ```
pub struct BareOfDecl {
    pub m: Text,
    pub acc: Map<Text, Array<Text>>,
    pub d: crate::syntax::decls::Decl,
}

impl prism_rtl::Job<Map<Text, Array<Text>>> for BareOfDecl {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<Text>>> {
        let m = &self.m;
        let acc = &self.acc;
        let d = &self.d;
        match &d.kind {
            crate::syntax::decls::DeclKind::DSignature(s) => prism_rtl::Turn::Finished(add_bare(acc, &crate::check::env::def_name_text(&s.name), &crate::check::env::qual_key(m, &crate::check::env::def_name_text(&s.name)))),
            crate::syntax::decls::DeclKind::DFn(f) => prism_rtl::Turn::Finished(add_bare(acc, &crate::check::env::def_name_text(&f.name), &crate::check::env::qual_key(m, &crate::check::env::def_name_text(&f.name)))),
            crate::syntax::decls::DeclKind::DLet(l) => {
                let acc = acc.clone();
                let l = l.clone();
                let m = m.clone();
                call_then(start_pattern_names(l.pattern.clone()), move |pattern_names_5985: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_5985, &acc, &(|a: &Map<Text, Array<Text>>, n: &Text| add_bare(a, n, &crate::check::env::qual_key(&m, n))))))
            },
            crate::syntax::decls::DeclKind::DWidget(w) => prism_rtl::Turn::Finished(add_bare(acc, &crate::check::env::sname_key(&w.name), &crate::check::env::qual_key(m, &crate::check::env::sname_key(&w.name)))),
            crate::syntax::decls::DeclKind::DType(t) => prism_rtl::Turn::Finished(fold(&ctor_names_of(t), acc, &(|a: &Map<Text, Array<Text>>, c: &Text| add_bare(a, c, &crate::check::env::qual_key(m, c))))),
            crate::syntax::decls::DeclKind::DTrait(t) => prism_rtl::Turn::Finished(fold(&t.items, acc, &(|a: &Map<Text, Array<Text>>, it: &crate::syntax::decls::TraitItem| match it {
                crate::syntax::decls::TraitItem::TiSignature(s) => add_bare(a, &crate::check::env::def_name_text(&s.name), &crate::check::env::qual_key(m, &crate::check::env::def_name_text(&s.name))),
                _ => a.clone(),
            }))),
            _ => prism_rtl::Turn::Finished(acc.clone()),
        }
    }
}

/// `Start BareOfDecl, x`: what the function value is when passed to `@Run`.
pub fn start_bare_of_decl(m: Text, acc: Map<Text, Array<Text>>, d: crate::syntax::decls::Decl) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>> {
    Rc::new(BareOfDecl { m, acc, d })
}

/// ```prism
/// CtorNamesOf: fn TypeDecl -> [Text]
/// ```
pub fn ctor_names_of(t: &crate::syntax::decls::TypeDecl) -> Array<Text> {
    match &t.body {
        Some(crate::syntax::decls::TypeBody::TbRecord(_)) => Array::from(vec![crate::check::env::dotted(&t.name.path_)]),
        Some(crate::syntax::decls::TypeBody::TbChoice(cs)) => each(cs, &(|c: &crate::syntax::decls::Case_| crate::check::env::sname_key(&c.name))),
        Some(crate::syntax::decls::TypeBody::TbNewtype(c)) => Array::from(vec![crate::check::env::sname_key(&c.name)]),
        Some(crate::syntax::decls::TypeBody::TbUnit(i)) => Array::from(vec![i.name.clone()]),
        _ => Array::new(),
    }
}

/// ```prism
/// PatternNames: unbounded fn Pattern -> [Text]
/// ```
pub fn pattern_names(p_: &crate::syntax::Pattern_) -> Array<Text> {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => Array::from(vec![crate::check::env::sname_key(n)]),
        crate::syntax::PatternKind::PCtor(_, ps) => run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc = p0;
            let q = p1;
            call_then(start_pattern_names(q.clone()), move |pattern_names_6861: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_6861)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PRecord(_, fs, _) => run_to_end(fold_job(fs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::FieldPat)| entered(once_job(move || {
            let acc = p0;
            let f = p1;
            call_then(start_pattern_names(f.pattern.clone()), move |pattern_names_6947: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_6947)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PSigil(_, q) => pattern_names(&**q),
        crate::syntax::PatternKind::PTuple(ps) => run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc = p0;
            let q = p1;
            call_then(start_pattern_names(q.clone()), move |pattern_names_7061: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_7061)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PArray(ps) => run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc = p0;
            let q = p1;
            call_then(start_pattern_names(q.clone()), move |pattern_names_7130: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_7130)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::PatternKind::PGroup(q) => pattern_names(&**q),
        _ => Array::new(),
    }
}

/// The step machine of `PatternNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatternNames: unbounded fn Pattern -> [Text]
/// ```
pub struct PatternNames {
    pub p_: crate::syntax::Pattern_,
}

impl prism_rtl::Job<Array<Text>> for PatternNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let p_ = &self.p_;
        match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::sname_key(n)])),
            crate::syntax::PatternKind::PCtor(_, ps) => fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc = p0;
                let q = p1;
                call_then(start_pattern_names(q.clone()), move |pattern_names_6861: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_6861)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PRecord(_, fs, _) => fold_job(fs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::FieldPat)| entered(once_job(move || {
                let acc = p0;
                let f = p1;
                call_then(start_pattern_names(f.pattern.clone()), move |pattern_names_6947: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_6947)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PSigil(_, q) => prism_rtl::Turn::More(Rc::new(PatternNames { p_: (**q).clone() })),
            crate::syntax::PatternKind::PTuple(ps) => fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc = p0;
                let q = p1;
                call_then(start_pattern_names(q.clone()), move |pattern_names_7061: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_7061)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PArray(ps) => fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc = p0;
                let q = p1;
                call_then(start_pattern_names(q.clone()), move |pattern_names_7130: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &pattern_names_7130)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(PatternNames { p_: (**q).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatternNames, x`: what the function value is when passed to `@Run`.
pub fn start_pattern_names(p_: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatternNames { p_ })
}

/// ```prism
/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
/// ```
pub fn pattern_binders(p_: &crate::syntax::Pattern_) -> Array<(Text, crate::syntax::Range)> {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => Array::from(vec![(crate::check::env::sname_key(n), n.span.clone())]),
        crate::syntax::PatternKind::PCtor(_, ps) => run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc = p0;
            let q = p1;
            call_then(start_pattern_binders(q.clone()), move |pattern_binders_7450: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_7450)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PRecord(_, fs, _) => run_to_end(fold_job(fs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)| entered(once_job(move || {
            let acc = p0;
            let f = p1;
            call_then(start_pattern_binders(f.pattern.clone()), move |pattern_binders_7538: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_7538)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PSigil(_, q) => pattern_binders(&**q),
        crate::syntax::PatternKind::PTuple(ps) => run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc = p0;
            let q = p1;
            call_then(start_pattern_binders(q.clone()), move |pattern_binders_7656: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_7656)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PArray(ps) => run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc = p0;
            let q = p1;
            call_then(start_pattern_binders(q.clone()), move |pattern_binders_7727: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_7727)))
        }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)),
        crate::syntax::PatternKind::PGroup(q) => pattern_binders(&**q),
        _ => Array::new(),
    }
}

/// The step machine of `PatternBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
/// ```
pub struct PatternBinders {
    pub p_: crate::syntax::Pattern_,
}

impl prism_rtl::Job<Array<(Text, crate::syntax::Range)>> for PatternBinders {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, crate::syntax::Range)>> {
        let p_ = &self.p_;
        match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::Finished(Array::from(vec![(crate::check::env::sname_key(n), n.span.clone())])),
            crate::syntax::PatternKind::PCtor(_, ps) => fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc = p0;
                let q = p1;
                call_then(start_pattern_binders(q.clone()), move |pattern_binders_7450: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_7450)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PRecord(_, fs, _) => fold_job(fs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)| entered(once_job(move || {
                let acc = p0;
                let f = p1;
                call_then(start_pattern_binders(f.pattern.clone()), move |pattern_binders_7538: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_7538)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::FieldPat)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PSigil(_, q) => prism_rtl::Turn::More(Rc::new(PatternBinders { p_: (**q).clone() })),
            crate::syntax::PatternKind::PTuple(ps) => fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc = p0;
                let q = p1;
                call_then(start_pattern_binders(q.clone()), move |pattern_binders_7656: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_7656)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PArray(ps) => fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc = p0;
                let q = p1;
                call_then(start_pattern_binders(q.clone()), move |pattern_binders_7727: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_7727)))
            }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(PatternBinders { p_: (**q).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatternBinders, x`: what the function value is when passed to `@Run`.
pub fn start_pattern_binders(p_: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>> {
    Rc::new(PatternBinders { p_ })
}

/// ```prism
/// BareTypesOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_types_of(g: &crate::check::env::G, src: &Text, acc: &Map<Text, Array<Text>>) -> Map<Text, Array<Text>> {
    fold(&keys(&g.types), acc, &(|a: &Map<Text, Array<Text>>, k: &Text| match get(&g.types, k) {
        Some(ti) => if &ti.home == src {
            add_bare(a, &crate::check::types::bare_name(&ti.name), k)
        } else {
            a.clone()
        },
        None => a.clone(),
    }))
}

/// ```prism
/// BareTraitsOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn bare_traits_of(g: &crate::check::env::G, src: &Text, acc: &Map<Text, Array<Text>>) -> Map<Text, Array<Text>> {
    fold(&keys(&g.traits), acc, &(|a: &Map<Text, Array<Text>>, k: &Text| match get(&g.traits, k) {
        Some(ti) => if &ti.home == src {
            add_bare(a, &crate::check::types::bare_name(&ti.name), k)
        } else {
            a.clone()
        },
        None => a.clone(),
    }))
}

/// ```prism
/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
/// ```
pub fn module_row(g: &crate::check::env::G, st: &crate::check::types::St, info: &crate::check::env::ModInfo) -> (crate::check::types::Rw, Text, crate::check::types::St) {
    match &info.tree.emit_row {
        None => if info.root {
            (g.program_row.clone(), Text::lit(""), st.clone())
        } else {
            (crate::check::types::empty_row(), Text::lit(""), crate::check::types::recording::err(st, &Text::lit("emit-element"), &info.tree.span, &Text::lit("a library writes its own row; this one writes no `emit` line")))
        },
        Some(row_decl) => {
            let (fams, vars, s2) = fold(&row_decl.terms, &(Array::new(), Array::new(), st.clone()), &(|(fs, vs, s): &(Array<Text>, Array<Text>, crate::check::types::St), term: &crate::syntax::RowTerm| row_term_of(g, s, info, term, fs, vs)));
            let s3 = if &len(&vars) > &Nat::from(1u32) {
                crate::check::types::recording::err_fix(&s2, &Text::lit("row-two-tails"), &row_decl.span, &Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::chars::join(&vars, &Text::lit(" | ")))), &Text::lit("keep one variable"))
            } else {
                s2.clone()
            };
            let tail = match index(&vars, &Nat::from(0u32)) {
                Some(v_) => crate::check::types::Tail::TlQ(v_.clone()),
                None => crate::check::types::Tail::TlClosed,
            };
            (crate::check::types::Rw { fams: crate::check::types::sort_texts(&fams), minus: Array::new(), tail: tail.clone() }, or(&index(&vars, &Nat::from(0u32)), &Text::lit("")), s3.clone())
        },
    }
}

/// The step machine of `ModuleRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
/// ```
pub struct ModuleRow {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub info: crate::check::env::ModInfo,
}

impl prism_rtl::Job<(crate::check::types::Rw, Text, crate::check::types::St)> for ModuleRow {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Rw, Text, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let info = &self.info;
        match &info.tree.emit_row {
            None => if info.root {
                prism_rtl::Turn::Finished((g.program_row.clone(), Text::lit(""), st.clone()))
            } else {
                prism_rtl::Turn::Finished((crate::check::types::empty_row(), Text::lit(""), crate::check::types::recording::err(st, &Text::lit("emit-element"), &info.tree.span, &Text::lit("a library writes its own row; this one writes no `emit` line"))))
            },
            Some(row_decl) => {
                let (fams, vars, s2) = fold(&row_decl.terms, &(Array::new(), Array::new(), st.clone()), &(|(fs, vs, s): &(Array<Text>, Array<Text>, crate::check::types::St), term: &crate::syntax::RowTerm| row_term_of(g, s, info, term, fs, vs)));
                let s3 = if &len(&vars) > &Nat::from(1u32) {
                    crate::check::types::recording::err_fix(&s2, &Text::lit("row-two-tails"), &row_decl.span, &Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::chars::join(&vars, &Text::lit(" | ")))), &Text::lit("keep one variable"))
                } else {
                    s2.clone()
                };
                let tail = match index(&vars, &Nat::from(0u32)) {
                    Some(v_) => crate::check::types::Tail::TlQ(v_.clone()),
                    None => crate::check::types::Tail::TlClosed,
                };
                prism_rtl::Turn::Finished((crate::check::types::Rw { fams: crate::check::types::sort_texts(&fams), minus: Array::new(), tail: tail.clone() }, or(&index(&vars, &Nat::from(0u32)), &Text::lit("")), s3.clone()))
            },
        }
    }
}

/// `Start ModuleRow, x`: what the function value is when passed to `@Run`.
pub fn start_module_row(g: crate::check::env::G, st: crate::check::types::St, info: crate::check::env::ModInfo) -> Rc<dyn prism_rtl::Job<(crate::check::types::Rw, Text, crate::check::types::St)>> {
    Rc::new(ModuleRow { g, st, info })
}

/// ```prism
/// RowTermOf: fn G, St, ModInfo, RowTerm, [Text], [Text] -> (([Text], [Text], St))
/// ```
pub fn row_term_of(g: &crate::check::env::G, s: &crate::check::types::St, info: &crate::check::env::ModInfo, term: &crate::syntax::RowTerm, fs: &Array<Text>, vs: &Array<Text>) -> (Array<Text>, Array<Text>, crate::check::types::St) {
    match term {
        crate::syntax::RowTerm::RFamily(q) => (push(fs, &crate::check::env::dotted(&q.path_)), vs.clone(), check_family(g, s, &crate::check::env::dotted(&q.path_), &q.span)),
        crate::syntax::RowTerm::RVar(v_) => (fs.clone(), push(vs, &v_.name), s.clone()),
        crate::syntax::RowTerm::RType(t) => match &*t.kind {
            crate::syntax::TypeKind::TName(n, m9527_0_1) if (m9527_0_1.len() == 0) => {
                let name = crate::check::env::dotted(&n.path_);
                if (&name == &Text::lit("Element")) && info.root {
                    (append(fs, &g.program_row.fams), vs.clone(), s.clone())
                } else {
                    if &name == &Text::lit("Element") {
                        (fs.clone(), vs.clone(), crate::check::types::recording::err(s, &Text::lit("emit-element"), &t.span, &Text::lit("a library writes its own row; `emit Element` names the program\'s")))
                    } else {
                        if crate::check::env::has_key(&g.tags, &name) || (&len(&n.path_) > &Nat::from(1u32)) {
                            (fs.clone(), vs.clone(), crate::check::types::recording::err_fix(s, &Text::lit("row-single-tag"), &t.span, &Text::from(format!("a row names families, not tags: `{}`", &name)), &Text::from(format!("write `{}.*`", &crate::check::env::dotted(&take(&n.path_, &crate::syntax::lexer::chars::dec(&len(&n.path_))))))))
                        } else {
                            (fs.clone(), vs.clone(), crate::check::types::recording::err(s, &Text::lit("kind"), &t.span, &Text::from(format!("`{}` is not a row", &name))))
                        }
                    }
                }
            },
            _ => (fs.clone(), vs.clone(), crate::check::types::recording::err(s, &Text::lit("kind"), &t.span, &Text::lit("this is not a row"))),
            _ => unreachable!("no arm matched"),
        },
    }
}

/// ```prism
/// CheckFamily: fn G, St, Text, Range -> St
/// ```
pub fn check_family(g: &crate::check::env::G, s: &crate::check::types::St, fam: &Text, span: &crate::syntax::Range) -> crate::check::types::St {
    if crate::check::env::has_key(&g.families, fam) {
        s.clone()
    } else {
        crate::check::types::recording::err(s, &Text::lit("unknown-name"), span, &Text::from(format!("no family `{}`: no module declares a `{}.` tag", fam, fam)))
    }
}

/// ```prism
/// ResolveValue: fn G, Text, SName -> ((?Text, Text))
/// ```
pub fn resolve_value(g: &crate::check::env::G, m: &Text, n: &crate::syntax::SName) -> (Option<Text>, Text) {
    let marks = n.sigils.clone();
    if &len(&n.path_) == &Nat::from(1u32) {
        {
            let name = Text::from(format!("{}{}", &marks, &or(&index(&n.path_, &Nat::from(0u32)), &Text::lit(""))));
            let table = or(&get(&g.bare, m), &Map::new());
            let keys_ = or(&get(&table, &name), &Array::new());
            if &len(&keys_) == &Nat::from(1u32) {
                (index(&keys_, &Nat::from(0u32)), Text::lit(""))
            } else {
                if &len(&keys_) > &Nat::from(1u32) {
                    (Some(own_first(m, &keys_)), Text::lit("collision"))
                } else {
                    if &name == &Text::lit("never") {
                        (Some(Text::lit("Prelude.never")), Text::lit(""))
                    } else {
                        if crate::check::env::has_key(&g.ctors, &name) {
                            (Some(name.clone()), Text::lit(""))
                        } else {
                            (None, Text::lit("unknown"))
                        }
                    }
                }
            }
        }
    } else {
        {
            let qual = crate::check::env::qual_module(g, &take(&n.path_, &crate::syntax::lexer::chars::dec(&len(&n.path_))));
            let last = or(&crate::syntax::lexer::chars::last(&n.path_), &Text::lit(""));
            let qk = crate::check::env::qual_key(&qual, &Text::from(format!("{}{}", &marks, &last)));
            if (&len_text(&marks) == &Nat::from(0u32)) && crate::check::env::has_key(&g.tags, &crate::check::env::dotted(&n.path_)) {
                (Some(crate::check::env::dotted(&n.path_)), Text::lit("tag"))
            } else {
                if crate::check::env::has_key(&g.vals, &qk) || crate::check::env::has_key(&g.ctors, &qk) {
                    (Some(qk.clone()), Text::lit(""))
                } else {
                    (None, Text::lit("unknown"))
                }
            }
        }
    }
}

/// ```prism
/// ResolveType: fn G, Text, [Text] -> ((?Text, Text))
/// ```
pub fn resolve_type(g: &crate::check::env::G, m: &Text, path_: &Array<Text>) -> (Option<Text>, Text) {
    if &len(path_) == &Nat::from(1u32) {
        {
            let keys_ = or(&get(&or(&get(&g.bare_types, m), &Map::new()), &or(&index(path_, &Nat::from(0u32)), &Text::lit(""))), &Array::new());
            if &len(&keys_) == &Nat::from(1u32) {
                (index(&keys_, &Nat::from(0u32)), Text::lit(""))
            } else {
                if &len(&keys_) > &Nat::from(1u32) {
                    (Some(own_first(m, &keys_)), Text::lit("collision"))
                } else {
                    (None, Text::lit("unknown"))
                }
            }
        }
    } else {
        {
            let qk = crate::check::env::qual_key(&crate::check::env::qual_module(g, &take(path_, &crate::syntax::lexer::chars::dec(&len(path_)))), &or(&crate::syntax::lexer::chars::last(path_), &Text::lit("")));
            if crate::check::env::has_key(&g.types, &qk) {
                (Some(qk.clone()), Text::lit(""))
            } else {
                (None, Text::lit("unknown"))
            }
        }
    }
}

/// ```prism
/// OwnFirst: fn Text, [Text] -> Text
/// ```
pub fn own_first(m: &Text, keys_: &Array<Text>) -> Text {
    let own = filter(keys_, &(|k: &Text| (&crate::check::env::qual_key(m, &crate::check::types::bare_name(k)) == k) || ((m == &Text::lit("")) && !crate::syntax::lexer::chars::contains(k, &Text::lit(".")))));
    or(&index(&own, &Nat::from(0u32)), &or(&index(keys_, &Nat::from(0u32)), &Text::lit("")))
}

/// ```prism
/// ?ResolveTrait: fn G, Text, [Text] -> ?Text
/// ```
pub fn resolve_trait(g: &crate::check::env::G, m: &Text, path_: &Array<Text>) -> Option<Text> {
    if &len(path_) == &Nat::from(1u32) {
        {
            let keys_ = or(&get(&or(&get(&g.bare_traits, m), &Map::new()), &or(&index(path_, &Nat::from(0u32)), &Text::lit(""))), &Array::new());
            index(&keys_, &Nat::from(0u32))
        }
    } else {
        {
            let qk = crate::check::env::qual_key(&crate::check::env::qual_module(g, &take(path_, &crate::syntax::lexer::chars::dec(&len(path_)))), &or(&crate::syntax::lexer::chars::last(path_), &Text::lit("")));
            if crate::check::env::has_key(&g.traits, &qk) { Some(qk.clone()) } else { None }
        }
    }
}
