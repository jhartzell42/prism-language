//! The module `Check.Env.Decls`, from `target/bootstrap/src/prismc/check/env/decls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn convert_types_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, m_p2: &crate::prelude::Text) -> (crate::check::env::G, crate::check::types::St) {
    match crate::prelude::get(&g_p0.mods_p, m_p2) {
        ::std::option::Option::None => (g_p0.clone(), st_p1.clone()),
        ::std::option::Option::Some(info_p3) => {
            let s0_p4 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file_p = info_p3.file_p.clone();
                this
            };
            crate::prelude::run_to_end(crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), (g_p0.clone(), s0_p4.clone()), {
                let info_p3x = info_p3.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)| {
                    let info_p3xy = info_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (gg_p5, s_p6) = p0;
                        let d_p7 = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ConvertTypeDecl { g_p0: gg_p5.clone(), st0_p1: s_p6.clone(), info_p2: info_p3xy.clone(), d_p3: d_p7.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
            }))
        },
    }
}

/// The step machine of `ConvertTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct ConvertTypes {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub m_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvertTypes {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let m_p2 = &self.m_p2;
        match crate::prelude::get(&g_p0.mods_p, m_p2) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
            ::std::option::Option::Some(info_p3) => {
                let s0_p4 = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.file_p = info_p3.file_p.clone();
                    this
                };
                crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), (g_p0.clone(), s0_p4.clone()), {
                    let info_p3x = info_p3.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)| {
                        let info_p3xy = info_p3x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (gg_p5, s_p6) = p0;
                            let d_p7 = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ConvertTypeDecl { g_p0: gg_p5.clone(), st0_p1: s_p6.clone(), info_p2: info_p3xy.clone(), d_p3: d_p7.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
                }).cycle()
            },
        }
    }
}

/// `Start ConvertTypes, x`: what the function value is when passed to `@Run`.
pub fn start_convert_types_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, m_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvertTypes { g_p0, st_p1, m_p2 })
}

/// ```prism
/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn convert_decls_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, m_p2: &crate::prelude::Text) -> (crate::check::env::G, crate::check::types::St) {
    match crate::prelude::get(&g_p0.mods_p, m_p2) {
        ::std::option::Option::None => (g_p0.clone(), st_p1.clone()),
        ::std::option::Option::Some(info_p3) => {
            let s1_p4 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file_p = info_p3.file_p.clone();
                this
            };
            let (g2_p9, s2_pa) = crate::prelude::run_to_end(crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), (g_p0.clone(), s1_p4.clone()), {
                let info_p3x = info_p3.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)| {
                    let info_p3xy = info_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (gg_p6, s_p7) = p0;
                        let d_p8 = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ConvertDecl { g_p0: gg_p6.clone(), st_p1: s_p7.clone(), info_p2: info_p3xy.clone(), d_p3: d_p8.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
            }));
            let s3_p5 = missing_signatures_f(&g2_p9, &s2_pa, &info_p3);
            (g2_p9.clone(), s3_p5.clone())
        },
    }
}

/// The step machine of `ConvertDecls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct ConvertDecls {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub m_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvertDecls {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let m_p2 = &self.m_p2;
        match crate::prelude::get(&g_p0.mods_p, m_p2) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
            ::std::option::Option::Some(info_p3) => {
                let s1_p4 = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.file_p = info_p3.file_p.clone();
                    this
                };
                let g_p0x = g_p0.clone();
                crate::prelude::call_value(crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), (g_p0x.clone(), s1_p4.clone()), {
                    let info_p3x = info_p3.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)| {
                        let info_p3xy = info_p3x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (gg_p6, s_p7) = p0;
                            let d_p8 = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ConvertDecl { g_p0: gg_p6.clone(), st_p1: s_p7.clone(), info_p2: info_p3xy.clone(), d_p3: d_p8.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
                }), move |fold_1281: (crate::check::env::G, crate::check::types::St)| {
                    let (g2_p9, s2_pa) = fold_1281;
                    let s3_p5 = missing_signatures_f(&g2_p9, &s2_pa, &info_p3);
                    ::prism_rtl::Turn::Finished((g2_p9.clone(), s3_p5.clone()))
                })
            },
        }
    }
}

/// `Start ConvertDecls, x`: what the function value is when passed to `@Run`.
pub fn start_convert_decls_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, m_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvertDecls { g_p0, st_p1, m_p2 })
}

/// ```prism
/// ConvertAliases: unbounded fn G, St -> ((G, St))
/// ```
pub fn convert_aliases_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> (crate::check::env::G, crate::check::types::St) {
    let aliases_p2 = crate::prelude::fold(&crate::prelude::values(&g_p0.mods_p), &crate::prelude::Array::new(), &(|acc_p4: &crate::prelude::Array<(crate::check::env::ModInfo, crate::syntax::decls::Decl)>, info_p5: &crate::check::env::ModInfo| crate::prelude::fold(&info_p5.tree_p.decls_p, acc_p4, &(|a_p6: &crate::prelude::Array<(crate::check::env::ModInfo, crate::syntax::decls::Decl)>, d_p7: &crate::syntax::decls::Decl| if is_alias_decl_f(d_p7) {
        crate::prelude::push(a_p6, &(info_p5.clone(), d_p7.clone()))
    } else {
        a_p6.clone()
    }))));
    let quiet_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(aliases_p2.clone(), g_p0.clone(), {
        let aliases_p2x = aliases_p2.clone();
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::env::G, (crate::check::env::ModInfo, crate::syntax::decls::Decl))| {
            let aliases_p2xy = aliases_p2x.clone();
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let gg_p8 = p0;
                let _ = p1;
                crate::prelude::fold_job(aliases_p2xy.clone(), gg_p8.clone(), {
                    let st_p1xyx = st_p1xy.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::check::env::G, (crate::check::env::ModInfo, crate::syntax::decls::Decl))| {
                        let st_p1xyxy = st_p1xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let g1_p9 = p0;
                            let (info_pa, d_pb) = p1;
                            crate::prelude::call_then(start_convert_alias_f(g1_p9.clone(), st_p1xyxy.clone(), info_pa.clone(), d_pb.clone()), move |convert_alias_f_2258: (crate::check::env::G, crate::check::types::St)| {
                                let (g2_pc, _) = convert_alias_f_2258;
                                ::prism_rtl::Turn::Finished(g2_pc.clone())
                            })
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::env::G, (crate::check::env::ModInfo, crate::syntax::decls::Decl))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::env::G>>>
                }).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::env::G, (crate::check::env::ModInfo, crate::syntax::decls::Decl))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::env::G>>>
    }));
    let (read_pj, st2_pk) = crate::prelude::run_to_end(crate::prelude::fold_job(aliases_p2.clone(), (quiet_p3.clone(), st_p1.clone()), {
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), (crate::check::env::ModInfo, crate::syntax::decls::Decl))| {
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (g1_pd, s_pe) = p0;
                let (info_pf, d_pg) = p1;
                crate::prelude::call_then(start_convert_alias_f(g1_pd.clone(), crate::check::env::traits::with_file_f(&s_pe, &info_pf.file_p), info_pf.clone(), d_pg.clone()), move |convert_alias_f_2402: (crate::check::env::G, crate::check::types::St)| {
                    let (g2_ph, s2_pi) = convert_alias_f_2402;
                    ::prism_rtl::Turn::Finished((g2_ph.clone(), crate::check::env::traits::with_file_f(&s2_pi, &st_p1xy.file_p)))
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St), (crate::check::env::ModInfo, crate::syntax::decls::Decl))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
    }));
    crate::prelude::run_to_end(crate::prelude::fold_job(aliases_p2.clone(), (read_pj.clone(), st2_pk.clone()), {
        let read_pjx = read_pj.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), (crate::check::env::ModInfo, crate::syntax::decls::Decl))| {
            let read_pjxy = read_pjx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (g1_pl, s_pm) = p0;
                let (info_pn, d_po) = p1;
                match &d_po.kind_p {
                    crate::syntax::decls::DeclKind::DType(t_pp) => {
                        let name_pq = crate::check::env::qual_key_f(&info_pn.name_p, &crate::check::env::dotted_f(&t_pp.name_p.path_p));
                        let ti_pr = crate::prelude::or(&crate::prelude::get(&read_pjxy.types_p, &name_pq), &crate::check::env::names::dummy_ty_info_p());
                        if (&ti_pr.span_p != &d_po.span_p) || !names_alias_f(&read_pjxy, &alias_body_f(&ti_pr)) {
                            ::prism_rtl::Turn::Finished((g1_pl.clone(), s_pm.clone()))
                        } else {
                            {
                                let upd_ps = {
                                    let mut this: crate::check::env::G = g1_pl.clone();
                                    this.types_p = crate::prelude::insert(&this.types_p, &name_pq, &with_body_f(&ti_pr, &crate::check::env::TyBody::BAlias(crate::check::types::Ty::TyErr)));
                                    this
                                };
                                ::prism_rtl::Turn::Finished((upd_ps.clone(), crate::check::env::traits::with_file_f(&crate::check::types::recording::err_fix_f(&crate::check::env::traits::with_file_f(&s_pm, &info_pn.file_p), &crate::prelude::Text::lit("alias-cycle"), &d_po.span_p, &crate::prelude::Text::from(format!("the alias `{}` names a ring of aliases, and no type", &crate::check::env::dotted_f(&t_pp.name_p.path_p))), &crate::prelude::Text::lit("make one type of the ring a record, a choice or a newtype")), &s_pm.file_p)))
                            }
                        }
                    },
                    _ => ::prism_rtl::Turn::Finished((g1_pl.clone(), s_pm.clone())),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St), (crate::check::env::ModInfo, crate::syntax::decls::Decl))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
    }))
}

/// The step machine of `ConvertAliases`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertAliases: unbounded fn G, St -> ((G, St))
/// ```
pub struct ConvertAliases {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvertAliases {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let aliases_p2 = crate::prelude::fold(&crate::prelude::values(&g_p0.mods_p), &crate::prelude::Array::new(), &(|acc_p4: &crate::prelude::Array<(crate::check::env::ModInfo, crate::syntax::decls::Decl)>, info_p5: &crate::check::env::ModInfo| crate::prelude::fold(&info_p5.tree_p.decls_p, acc_p4, &(|a_p6: &crate::prelude::Array<(crate::check::env::ModInfo, crate::syntax::decls::Decl)>, d_p7: &crate::syntax::decls::Decl| if is_alias_decl_f(d_p7) {
            crate::prelude::push(a_p6, &(info_p5.clone(), d_p7.clone()))
        } else {
            a_p6.clone()
        }))));
        let g_p0x = g_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(aliases_p2.clone(), g_p0x.clone(), {
            let aliases_p2x = aliases_p2.clone();
            let st_p1xx = st_p1x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::env::G, (crate::check::env::ModInfo, crate::syntax::decls::Decl))| {
                let aliases_p2xy = aliases_p2x.clone();
                let st_p1xxy = st_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let gg_p8 = p0;
                    let _ = p1;
                    crate::prelude::fold_job(aliases_p2xy.clone(), gg_p8.clone(), {
                        let st_p1xxyx = st_p1xxy.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::check::env::G, (crate::check::env::ModInfo, crate::syntax::decls::Decl))| {
                            let st_p1xxyxy = st_p1xxyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let g1_p9 = p0;
                                let (info_pa, d_pb) = p1;
                                crate::prelude::call_then(start_convert_alias_f(g1_p9.clone(), st_p1xxyxy.clone(), info_pa.clone(), d_pb.clone()), move |convert_alias_f_2258: (crate::check::env::G, crate::check::types::St)| {
                                    let (g2_pc, _) = convert_alias_f_2258;
                                    ::prism_rtl::Turn::Finished(g2_pc.clone())
                                })
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::env::G, (crate::check::env::ModInfo, crate::syntax::decls::Decl))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::env::G>>>
                    }).cycle()
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::env::G, (crate::check::env::ModInfo, crate::syntax::decls::Decl))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::env::G>>>
        }), move |fold_2161: crate::check::env::G| {
            let quiet_p3 = fold_2161;
            crate::prelude::call_value(crate::prelude::fold_job(aliases_p2.clone(), (quiet_p3.clone(), st_p1x.clone()), {
                let st_p1xx = st_p1x.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), (crate::check::env::ModInfo, crate::syntax::decls::Decl))| {
                    let st_p1xxy = st_p1xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (g1_pd, s_pe) = p0;
                        let (info_pf, d_pg) = p1;
                        crate::prelude::call_then(start_convert_alias_f(g1_pd.clone(), crate::check::env::traits::with_file_f(&s_pe, &info_pf.file_p), info_pf.clone(), d_pg.clone()), move |convert_alias_f_2402: (crate::check::env::G, crate::check::types::St)| {
                            let (g2_ph, s2_pi) = convert_alias_f_2402;
                            ::prism_rtl::Turn::Finished((g2_ph.clone(), crate::check::env::traits::with_file_f(&s2_pi, &st_p1xxy.file_p)))
                        })
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St), (crate::check::env::ModInfo, crate::syntax::decls::Decl))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
            }), move |fold_2322: (crate::check::env::G, crate::check::types::St)| {
                let (read_pj, st2_pk) = fold_2322;
                crate::prelude::fold_job(aliases_p2.clone(), (read_pj.clone(), st2_pk.clone()), {
                    let read_pjx = read_pj.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), (crate::check::env::ModInfo, crate::syntax::decls::Decl))| {
                        let read_pjxy = read_pjx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (g1_pl, s_pm) = p0;
                            let (info_pn, d_po) = p1;
                            match &d_po.kind_p {
                                crate::syntax::decls::DeclKind::DType(t_pp) => {
                                    let name_pq = crate::check::env::qual_key_f(&info_pn.name_p, &crate::check::env::dotted_f(&t_pp.name_p.path_p));
                                    let ti_pr = crate::prelude::or(&crate::prelude::get(&read_pjxy.types_p, &name_pq), &crate::check::env::names::dummy_ty_info_p());
                                    if (&ti_pr.span_p != &d_po.span_p) || !names_alias_f(&read_pjxy, &alias_body_f(&ti_pr)) {
                                        ::prism_rtl::Turn::Finished((g1_pl.clone(), s_pm.clone()))
                                    } else {
                                        {
                                            let upd_ps = {
                                                let mut this: crate::check::env::G = g1_pl.clone();
                                                this.types_p = crate::prelude::insert(&this.types_p, &name_pq, &with_body_f(&ti_pr, &crate::check::env::TyBody::BAlias(crate::check::types::Ty::TyErr)));
                                                this
                                            };
                                            ::prism_rtl::Turn::Finished((upd_ps.clone(), crate::check::env::traits::with_file_f(&crate::check::types::recording::err_fix_f(&crate::check::env::traits::with_file_f(&s_pm, &info_pn.file_p), &crate::prelude::Text::lit("alias-cycle"), &d_po.span_p, &crate::prelude::Text::from(format!("the alias `{}` names a ring of aliases, and no type", &crate::check::env::dotted_f(&t_pp.name_p.path_p))), &crate::prelude::Text::lit("make one type of the ring a record, a choice or a newtype")), &s_pm.file_p)))
                                        }
                                    }
                                },
                                _ => ::prism_rtl::Turn::Finished((g1_pl.clone(), s_pm.clone())),
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St), (crate::check::env::ModInfo, crate::syntax::decls::Decl))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
                }).cycle()
            })
        })
    }
}

/// `Start ConvertAliases, x`: what the function value is when passed to `@Run`.
pub fn start_convert_aliases_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvertAliases { g_p0, st_p1 })
}

/// ```prism
/// IsAliasDecl: fn Decl -> Bool
/// ```
pub fn is_alias_decl_f(d_p0: &crate::syntax::decls::Decl) -> bool {
    match &d_p0.kind_p {
        crate::syntax::decls::DeclKind::DType(t_p1) => match &t_p1.body_o {
            ::std::option::Option::Some(body_p2) => match body_p2 {
                crate::syntax::decls::TypeBody::TbAlias(_) => true,
                _ => false,
            },
            ::std::option::Option::None => false,
        },
        _ => false,
    }
}

/// ```prism
/// AliasBody: fn TyInfo -> Ty
/// ```
pub fn alias_body_f(ti_p0: &crate::check::env::TyInfo) -> crate::check::types::Ty {
    match &ti_p0.body_p {
        crate::check::env::TyBody::BAlias(t_p1) => t_p1.clone(),
        _ => crate::check::types::Ty::TyErr,
    }
}

/// ```prism
/// ConvertAlias: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub fn convert_alias_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, d_p3: &crate::syntax::decls::Decl) -> (crate::check::env::G, crate::check::types::St) {
    match &d_p3.kind_p {
        crate::syntax::decls::DeclKind::DType(t_p4) => {
            let name_p5 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_p4.name_p.path_p));
            let ti_p6 = crate::prelude::or(&crate::prelude::get(&g_p0.types_p, &name_p5), &crate::check::env::names::dummy_ty_info_p());
            if &ti_p6.span_p != &d_p3.span_p {
                (g_p0.clone(), st_p1.clone())
            } else {
                match &t_p4.body_o {
                    ::std::option::Option::Some(body_p7) => match body_p7 {
                        crate::syntax::decls::TypeBody::TbAlias(a_p8) => {
                            let (at_pa, st2_pb) = crate::check::env::reading::conv_type_f(&crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p), st_p1, a_p8);
                            let upd_p9 = {
                                let mut this: crate::check::env::G = g_p0.clone();
                                this.types_p = crate::prelude::insert(&this.types_p, &name_p5, &with_body_f(&ti_p6, &crate::check::env::TyBody::BAlias(at_pa.clone())));
                                this
                            };
                            (upd_p9.clone(), st2_pb.clone())
                        },
                        _ => (g_p0.clone(), st_p1.clone()),
                    },
                    ::std::option::Option::None => (g_p0.clone(), st_p1.clone()),
                }
            }
        },
        _ => (g_p0.clone(), st_p1.clone()),
    }
}

/// The step machine of `ConvertAlias`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertAlias: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub struct ConvertAlias {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
    pub d_p3: crate::syntax::decls::Decl,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvertAlias {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        let d_p3 = &self.d_p3;
        match &d_p3.kind_p {
            crate::syntax::decls::DeclKind::DType(t_p4) => {
                let name_p5 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_p4.name_p.path_p));
                let ti_p6 = crate::prelude::or(&crate::prelude::get(&g_p0.types_p, &name_p5), &crate::check::env::names::dummy_ty_info_p());
                if &ti_p6.span_p != &d_p3.span_p {
                    ::prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone()))
                } else {
                    match &t_p4.body_o {
                        ::std::option::Option::Some(body_p7) => match body_p7 {
                            crate::syntax::decls::TypeBody::TbAlias(a_p8) => {
                                let a_p8x = a_p8.clone();
                                let g_p0x = g_p0.clone();
                                let info_p2x = info_p2.clone();
                                let st_p1x = st_p1.clone();
                                crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(crate::check::env::reading::cx_of_f(&g_p0x, &info_p2x.name_p), st_p1x.clone(), a_p8x.clone()), move |conv_type_f_4066: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (at_pa, st2_pb) = conv_type_f_4066;
                                    let upd_p9 = {
                                        let mut this: crate::check::env::G = g_p0x.clone();
                                        this.types_p = crate::prelude::insert(&this.types_p, &name_p5, &with_body_f(&ti_p6, &crate::check::env::TyBody::BAlias(at_pa.clone())));
                                        this
                                    };
                                    ::prism_rtl::Turn::Finished((upd_p9.clone(), st2_pb.clone()))
                                })
                            },
                            _ => ::prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
                        },
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
                    }
                }
            },
            _ => ::prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
        }
    }
}

/// `Start ConvertAlias, x`: what the function value is when passed to `@Run`.
pub fn start_convert_alias_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo, d_p3: crate::syntax::decls::Decl) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvertAlias { g_p0, st_p1, info_p2, d_p3 })
}

/// ```prism
/// NamesAlias: unbounded fn G, Ty -> Bool
/// ```
pub fn names_alias_f(g_p0: &crate::check::env::G, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyCon(n_p2, args_p3) => is_alias_body_f(&crate::prelude::or(&crate::prelude::get(&g_p0.types_p, n_p2), &crate::check::env::names::dummy_ty_info_p()).body_p) || any_names_alias_f(g_p0, args_p3),
        crate::check::types::Ty::TyFn(_, ps_p4, r_p5) => any_names_alias_f(g_p0, ps_p4) || names_alias_f(g_p0, &**r_p5),
        crate::check::types::Ty::TyTuple(ts_p6) => any_names_alias_f(g_p0, ts_p6),
        crate::check::types::Ty::TyArray(e_p7) => names_alias_f(g_p0, &**e_p7),
        crate::check::types::Ty::TyMap(k_p8, v_p9) => names_alias_f(g_p0, &**k_p8) || names_alias_f(g_p0, &**v_p9),
        crate::check::types::Ty::TySig(_, i_pa) => names_alias_f(g_p0, &**i_pa),
        crate::check::types::Ty::TyAt(i_pb, _) => names_alias_f(g_p0, &**i_pb),
        crate::check::types::Ty::TyElem(_, o_pc) => names_alias_f(g_p0, &**o_pc),
        crate::check::types::Ty::TyAssoc(_, _, a_pd) => names_alias_f(g_p0, &**a_pd),
        _ => false,
    }
}

/// The step machine of `NamesAlias`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamesAlias: unbounded fn G, Ty -> Bool
/// ```
pub struct NamesAlias {
    pub g_p0: crate::check::env::G,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<bool> for NamesAlias {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let g_p0 = &self.g_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyCon(n_p2, args_p3) => if is_alias_body_f(&crate::prelude::or(&crate::prelude::get(&g_p0.types_p, n_p2), &crate::check::env::names::dummy_ty_info_p()).body_p) {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyNamesAlias { g_p0: g_p0.clone(), ts_p1: args_p3.clone() }))
            },
            crate::check::types::Ty::TyFn(_, ps_p4, r_p5) => {
                let g_p0x = g_p0.clone();
                let ps_p4x = ps_p4.clone();
                let r_p5x = (**r_p5).clone();
                crate::prelude::call_then(start_any_names_alias_f(g_p0x.clone(), ps_p4x.clone()), move |any_names_alias_f_4626: bool| if any_names_alias_f_4626 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesAlias { g_p0: g_p0x.clone(), t_p1: r_p5x.clone() }))
                })
            },
            crate::check::types::Ty::TyTuple(ts_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyNamesAlias { g_p0: g_p0.clone(), ts_p1: ts_p6.clone() })),
            crate::check::types::Ty::TyArray(e_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesAlias { g_p0: g_p0.clone(), t_p1: (**e_p7).clone() })),
            crate::check::types::Ty::TyMap(k_p8, v_p9) => {
                let g_p0x = g_p0.clone();
                let k_p8x = (**k_p8).clone();
                let v_p9x = (**v_p9).clone();
                crate::prelude::call_then(start_names_alias_f(g_p0x.clone(), k_p8x.clone()), move |names_alias_f_4752: bool| if names_alias_f_4752 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesAlias { g_p0: g_p0x.clone(), t_p1: v_p9x.clone() }))
                })
            },
            crate::check::types::Ty::TySig(_, i_pa) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesAlias { g_p0: g_p0.clone(), t_p1: (**i_pa).clone() })),
            crate::check::types::Ty::TyAt(i_pb, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesAlias { g_p0: g_p0.clone(), t_p1: (**i_pb).clone() })),
            crate::check::types::Ty::TyElem(_, o_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesAlias { g_p0: g_p0.clone(), t_p1: (**o_pc).clone() })),
            crate::check::types::Ty::TyAssoc(_, _, a_pd) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesAlias { g_p0: g_p0.clone(), t_p1: (**a_pd).clone() })),
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start NamesAlias, x`: what the function value is when passed to `@Run`.
pub fn start_names_alias_f(g_p0: crate::check::env::G, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(NamesAlias { g_p0, t_p1 })
}

/// ```prism
/// AnyNamesAlias: unbounded fn G, [Ty] -> Bool
/// ```
pub fn any_names_alias_f(g_p0: &crate::check::env::G, ts_p1: &crate::prelude::Array<crate::check::types::Ty>) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(ts_p1.clone(), false, {
        let g_p0x = g_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_p2 = p0;
                let t_p3 = p1;
                if seen_p2 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesAlias { g_p0: g_p0xy.clone(), t_p1: t_p3.clone() }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `AnyNamesAlias`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnyNamesAlias: unbounded fn G, [Ty] -> Bool
/// ```
pub struct AnyNamesAlias {
    pub g_p0: crate::check::env::G,
    pub ts_p1: crate::prelude::Array<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<bool> for AnyNamesAlias {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let g_p0 = &self.g_p0;
        let ts_p1 = &self.ts_p1;
        crate::prelude::fold_job(ts_p1.clone(), false, {
            let g_p0x = g_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let g_p0xy = g_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_p2 = p0;
                    let t_p3 = p1;
                    if seen_p2 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesAlias { g_p0: g_p0xy.clone(), t_p1: t_p3.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start AnyNamesAlias, x`: what the function value is when passed to `@Run`.
pub fn start_any_names_alias_f(g_p0: crate::check::env::G, ts_p1: crate::prelude::Array<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(AnyNamesAlias { g_p0, ts_p1 })
}

/// ```prism
/// IsAliasBody: fn TyBody -> Bool
/// ```
pub fn is_alias_body_f(b_p0: &crate::check::env::TyBody) -> bool {
    match b_p0 {
        crate::check::env::TyBody::BAlias(_) => true,
        _ => false,
    }
}

/// ```prism
/// TypeHeadVariables: unbounded fn St, TypeDecl -> St
/// ```
pub fn type_head_variables_f(st_p0: &crate::check::types::St, t_p1: &crate::syntax::decls::TypeDecl) -> crate::check::types::St {
    let params_p2 = crate::prelude::each(&t_p1.params_p, &(|p_p5: &crate::syntax::Ident| p_p5.name_p.clone()));
    let st1_p3 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&t_p1.params_p)), st_p0, &(|s_p6: &crate::check::types::St, i_p7: &crate::prelude::Nat| match crate::prelude::index(&t_p1.params_p, i_p7) {
        ::std::option::Option::Some(p_p8) => if crate::check::types::has_text_f(&crate::prelude::take(&params_p2, i_p7), &p_p8.name_p) {
            crate::check::types::recording::err_f(s_p6, &crate::prelude::Text::lit("collision"), &p_p8.span_p, &crate::prelude::Text::from(format!("a second parameter `{}`", &p_p8.name_p)))
        } else {
            s_p6.clone()
        },
        ::std::option::Option::None => s_p6.clone(),
    }));
    let written_p4 = match &t_p1.body_o {
        ::std::option::Option::Some(body_p9) => match body_p9 {
            crate::syntax::decls::TypeBody::TbRecord(fs_pa) => crate::prelude::each(fs_pa, &(|f_pb: &crate::syntax::decls::Field| f_pb.ty_p.clone())),
            crate::syntax::decls::TypeBody::TbChoice(cs_pc) => crate::prelude::fold(cs_pc, &crate::prelude::Array::new(), &(|acc_pd: &crate::prelude::Array<crate::syntax::Type>, c_pe: &crate::syntax::decls::Case| crate::prelude::append(acc_pd, &c_pe.args_p))),
            crate::syntax::decls::TypeBody::TbNewtype(c_pf) => c_pf.args_p.clone(),
            crate::syntax::decls::TypeBody::TbAlias(a_pg) => crate::prelude::Array::from(vec![a_pg.clone()]),
            _ => crate::prelude::Array::new(),
        },
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    let (st2_pn, _) = crate::prelude::run_to_end(crate::prelude::fold_job(written_p4.clone(), (st1_p3.clone(), params_p2.clone()), {
        let t_p1x = t_p1.clone();
        let params_p2x = params_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::types::St, crate::prelude::Array<crate::prelude::Text>), crate::syntax::Type)| {
            let t_p1xy = t_p1x.clone();
            let params_p2xy = params_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (s_ph, known_pi) = p0;
                let ty_pj = p1;
                crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(ty_pj.clone()), move |type_vars_of_type_f_6150: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&type_vars_of_type_f_6150, &(s_ph.clone(), known_pi.clone()), &(|(s1_pk, seen_pl): &(crate::check::types::St, crate::prelude::Array<crate::prelude::Text>), v_pm: &crate::prelude::Text| if crate::check::types::has_text_f(seen_pl, v_pm) {
                    (s1_pk.clone(), seen_pl.clone())
                } else {
                    (crate::check::types::recording::err_fix_f(s1_pk, &crate::prelude::Text::lit("unknown-name"), &ty_pj.span_p, &crate::prelude::Text::from(format!("`{}` is no parameter of `{}`", v_pm, &crate::check::env::dotted_f(&t_p1xy.name_p.path_p))), &crate::prelude::Text::from(format!("declare it in the head, `type {} = ...`", &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::check::env::dotted_f(&t_p1xy.name_p.path_p)]), &crate::prelude::push(&params_p2xy, v_pm)), &crate::prelude::Text::lit(" "))))), crate::prelude::push(seen_pl, v_pm))
                }))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::types::St, crate::prelude::Array<crate::prelude::Text>), crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::St, crate::prelude::Array<crate::prelude::Text>)>>>
    }));
    st2_pn.clone()
}

/// The step machine of `TypeHeadVariables`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeHeadVariables: unbounded fn St, TypeDecl -> St
/// ```
pub struct TypeHeadVariables {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::syntax::decls::TypeDecl,
}

impl ::prism_rtl::Job<crate::check::types::St> for TypeHeadVariables {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let params_p2 = crate::prelude::each(&t_p1.params_p, &(|p_p5: &crate::syntax::Ident| p_p5.name_p.clone()));
        let st1_p3 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&t_p1.params_p)), st_p0, &(|s_p6: &crate::check::types::St, i_p7: &crate::prelude::Nat| match crate::prelude::index(&t_p1.params_p, i_p7) {
            ::std::option::Option::Some(p_p8) => if crate::check::types::has_text_f(&crate::prelude::take(&params_p2, i_p7), &p_p8.name_p) {
                crate::check::types::recording::err_f(s_p6, &crate::prelude::Text::lit("collision"), &p_p8.span_p, &crate::prelude::Text::from(format!("a second parameter `{}`", &p_p8.name_p)))
            } else {
                s_p6.clone()
            },
            ::std::option::Option::None => s_p6.clone(),
        }));
        let written_p4 = match &t_p1.body_o {
            ::std::option::Option::Some(body_p9) => match body_p9 {
                crate::syntax::decls::TypeBody::TbRecord(fs_pa) => crate::prelude::each(fs_pa, &(|f_pb: &crate::syntax::decls::Field| f_pb.ty_p.clone())),
                crate::syntax::decls::TypeBody::TbChoice(cs_pc) => crate::prelude::fold(cs_pc, &crate::prelude::Array::new(), &(|acc_pd: &crate::prelude::Array<crate::syntax::Type>, c_pe: &crate::syntax::decls::Case| crate::prelude::append(acc_pd, &c_pe.args_p))),
                crate::syntax::decls::TypeBody::TbNewtype(c_pf) => c_pf.args_p.clone(),
                crate::syntax::decls::TypeBody::TbAlias(a_pg) => crate::prelude::Array::from(vec![a_pg.clone()]),
                _ => crate::prelude::Array::new(),
            },
            ::std::option::Option::None => crate::prelude::Array::new(),
        };
        let t_p1x = t_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(written_p4.clone(), (st1_p3.clone(), params_p2.clone()), {
            let t_p1xx = t_p1x.clone();
            let params_p2x = params_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::check::types::St, crate::prelude::Array<crate::prelude::Text>), crate::syntax::Type)| {
                let t_p1xxy = t_p1xx.clone();
                let params_p2xy = params_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (s_ph, known_pi) = p0;
                    let ty_pj = p1;
                    crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(ty_pj.clone()), move |type_vars_of_type_f_6150: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&type_vars_of_type_f_6150, &(s_ph.clone(), known_pi.clone()), &(|(s1_pk, seen_pl): &(crate::check::types::St, crate::prelude::Array<crate::prelude::Text>), v_pm: &crate::prelude::Text| if crate::check::types::has_text_f(seen_pl, v_pm) {
                        (s1_pk.clone(), seen_pl.clone())
                    } else {
                        (crate::check::types::recording::err_fix_f(s1_pk, &crate::prelude::Text::lit("unknown-name"), &ty_pj.span_p, &crate::prelude::Text::from(format!("`{}` is no parameter of `{}`", v_pm, &crate::check::env::dotted_f(&t_p1xxy.name_p.path_p))), &crate::prelude::Text::from(format!("declare it in the head, `type {} = ...`", &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::check::env::dotted_f(&t_p1xxy.name_p.path_p)]), &crate::prelude::push(&params_p2xy, v_pm)), &crate::prelude::Text::lit(" "))))), crate::prelude::push(seen_pl, v_pm))
                    }))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::types::St, crate::prelude::Array<crate::prelude::Text>), crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::St, crate::prelude::Array<crate::prelude::Text>)>>>
        }), move |fold_6093: (crate::check::types::St, crate::prelude::Array<crate::prelude::Text>)| {
            let (st2_pn, _) = fold_6093;
            ::prism_rtl::Turn::Finished(st2_pn.clone())
        })
    }
}

/// `Start TypeHeadVariables, x`: what the function value is when passed to `@Run`.
pub fn start_type_head_variables_f(st_p0: crate::check::types::St, t_p1: crate::syntax::decls::TypeDecl) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(TypeHeadVariables { st_p0, t_p1 })
}

/// ```prism
/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub fn convert_type_decl_f(g_p0: &crate::check::env::G, st0_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, d_p3: &crate::syntax::decls::Decl) -> (crate::check::env::G, crate::check::types::St) {
    match &d_p3.kind_p {
        crate::syntax::decls::DeclKind::DType(t_p4) => {
            let name_p5 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_p4.name_p.path_p));
            let ti_p6 = crate::prelude::or(&crate::prelude::get(&g_p0.types_p, &name_p5), &crate::check::env::names::dummy_ty_info_p());
            let st_p7 = if &ti_p6.span_p == &d_p3.span_p {
                type_head_variables_f(st0_p1, t_p4)
            } else {
                st0_p1.clone()
            };
            let cx_p8 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
            let params_p9 = crate::prelude::each(&t_p4.params_p, &(|p_pb: &crate::syntax::Ident| p_pb.name_p.clone()));
            let self_pa = crate::check::types::Ty::TyCon(name_p5.clone(), crate::prelude::each(&params_p9, &(|p_pc: &crate::prelude::Text| crate::check::types::Ty::TyQ(p_pc.clone()))));
            if &ti_p6.span_p != &d_p3.span_p {
                (g_p0.clone(), st_p7.clone())
            } else {
                match &t_p4.body_o {
                    ::std::option::Option::None => (g_p0.clone(), st_p7.clone()),
                    ::std::option::Option::Some(body_pd) => match body_pd {
                        crate::syntax::decls::TypeBody::TbRecord(fs_pe) => {
                            let (fields_pp, st2a_pq) = crate::prelude::run_to_end(crate::prelude::fold_job(fs_pe.clone(), (crate::prelude::Array::new(), st_p7.clone()), {
                                let cx_p8x = cx_p8.clone();
                                let g_p0x = g_p0.clone();
                                let info_p2x = info_p2.clone();
                                let t_p4x = t_p4.clone();
                                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)| {
                                    let cx_p8xy = cx_p8x.clone();
                                    let g_p0xy = g_p0x.clone();
                                    let info_p2xy = info_p2x.clone();
                                    let t_p4xy = t_p4x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (acc_pi, s_pj) = p0;
                                        let f_pk = p1;
                                        crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p8xy.clone(), sigils_on_name_f(&second_field_f(&s_pj, &acc_pi, &f_pk), &crate::prelude::or(&crate::prelude::index(&g_p0xy.srcs_p, &info_p2xy.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit("?"), &crate::prelude::Text::lit(""))), &f_pk), f_pk.ty_p.clone()), move |conv_type_f_7320: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (ft_pl, s2_pm) = conv_type_f_7320;
                                            let acc_piz = acc_pi.clone();
                                            let f_pkz = f_pk.clone();
                                            let ft_plz = ft_pl.clone();
                                            let info_p2xyz = info_p2xy.clone();
                                            let t_p4xyz = t_p4xy.clone();
                                            let k_let7450 = move |v7450: (crate::check::types::Rw, crate::check::types::St)| {
                                                let (field_row_pn, s3_po) = v7450;
                                                crate::prelude::call_then(start_field_row_bound_f(s3_po.clone(), info_p2xyz.clone(), crate::check::env::dotted_f(&t_p4xyz.name_p.path_p), f_pkz.clone()), move |field_row_bound_f_7643: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_piz, &(f_pkz.name_p.name_p.clone(), field_sigils_f(&f_pkz.sigils_p, &ft_plz, &field_row_pn))), field_row_bound_f_7643)))
                                            };
                                            if crate::syntax::lexer::chars::contains_f(&f_pk.sigils_p, &crate::prelude::Text::lit("@")) {
                                                crate::prelude::call_then(start_field_row_f(cx_p8xy.clone(), s2_pm.clone(), f_pk.ty_p.clone()), move |field_row_f_7500: (crate::check::types::Rw, crate::check::types::St)| k_let7450(field_row_f_7500))
                                            } else {
                                                k_let7450((cx_p8xy.scope_p.clone(), s2_pm.clone()))
                                            }
                                        })
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St)>>>
                            }));
                            let st2_pf = second_constructor_f(g_p0, &st2a_pq, &name_p5, &name_p5, &d_p3.span_p);
                            let ctor_pg = crate::check::env::CtorInfo { name_p: name_p5.clone(), owner_p: name_p5.clone(), params_p: params_p9.clone(), args_p: crate::prelude::each(&fields_pp, &(|(_, ft_pr): &(crate::prelude::Text, crate::check::types::Ty)| ft_pr.clone())), fields_p: crate::prelude::each(&fields_pp, &(|(fname_ps, _): &(crate::prelude::Text, crate::check::types::Ty)| fname_ps.clone())), ty_p: self_pa.clone(), index_p: crate::prelude::Nat::from(0u32) };
                            let upd_ph = {
                                let mut this: crate::check::env::G = g_p0.clone();
                                this.types_p = crate::prelude::insert(&this.types_p, &name_p5, &with_body_f(&ti_p6, &crate::check::env::TyBody::BRecord(fields_pp.clone())));
                                this.ctors_p = crate::prelude::insert(&this.ctors_p, &name_p5, &ctor_pg);
                                this
                            };
                            (upd_ph.clone(), st2_pf.clone())
                        },
                        crate::syntax::decls::TypeBody::TbChoice(cs_pt) => conv_cases_f(g_p0, &case_rows_bound_f(&st_p7, info_p2, &crate::check::env::dotted_f(&t_p4.name_p.path_p), cs_pt), &cx_p8, &ti_p6, &name_p5, &params_p9, &self_pa, cs_pt),
                        crate::syntax::decls::TypeBody::TbNewtype(c_pu) => conv_cases_f(g_p0, &case_rows_bound_f(&st_p7, info_p2, &crate::check::env::dotted_f(&t_p4.name_p.path_p), &crate::prelude::Array::from(vec![c_pu.clone()])), &cx_p8, &ti_p6, &name_p5, &params_p9, &self_pa, &crate::prelude::Array::from(vec![c_pu.clone()])),
                        crate::syntax::decls::TypeBody::TbUnit(i_pv) => {
                            let st_unit_p10 = second_constructor_f(g_p0, &st_p7, &crate::check::env::qual_key_f(&info_p2.name_p, &i_pv.name_p), &name_p5, &i_pv.span_p);
                            let ctor_p11 = crate::check::env::CtorInfo { name_p: crate::check::env::qual_key_f(&info_p2.name_p, &i_pv.name_p), owner_p: name_p5.clone(), params_p: params_p9.clone(), args_p: crate::prelude::Array::new(), fields_p: crate::prelude::Array::new(), ty_p: self_pa.clone(), index_p: crate::prelude::Nat::from(0u32) };
                            let upd_p12 = {
                                let mut this: crate::check::env::G = g_p0.clone();
                                this.types_p = crate::prelude::insert(&this.types_p, &name_p5, &with_body_f(&ti_p6, &crate::check::env::TyBody::BChoice(crate::prelude::Array::from(vec![(i_pv.name_p.clone(), crate::prelude::Array::new())]))));
                                this.ctors_p = crate::prelude::insert(&this.ctors_p, &crate::check::env::qual_key_f(&info_p2.name_p, &i_pv.name_p), &ctor_p11);
                                this
                            };
                            (upd_p12.clone(), st_unit_p10.clone())
                        },
                        crate::syntax::decls::TypeBody::TbRow => {
                            let upd_p13 = {
                                let mut this: crate::check::env::G = g_p0.clone();
                                this.types_p = crate::prelude::insert(&this.types_p, &name_p5, &with_body_f(&ti_p6, &crate::check::env::TyBody::BRowKind));
                                this
                            };
                            (upd_p13.clone(), st_p7.clone())
                        },
                        crate::syntax::decls::TypeBody::TbAlias(_) => (g_p0.clone(), st_p7.clone()),
                    },
                }
            }
        },
        _ => (g_p0.clone(), st0_p1.clone()),
    }
}

/// The step machine of `ConvertTypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub struct ConvertTypeDecl {
    pub g_p0: crate::check::env::G,
    pub st0_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
    pub d_p3: crate::syntax::decls::Decl,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvertTypeDecl {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st0_p1 = &self.st0_p1;
        let info_p2 = &self.info_p2;
        let d_p3 = &self.d_p3;
        match &d_p3.kind_p {
            crate::syntax::decls::DeclKind::DType(t_p4) => {
                let name_p5 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_p4.name_p.path_p));
                let ti_p6 = crate::prelude::or(&crate::prelude::get(&g_p0.types_p, &name_p5), &crate::check::env::names::dummy_ty_info_p());
                let d_p3z = d_p3.clone();
                let g_p0z = g_p0.clone();
                let info_p2z = info_p2.clone();
                let name_p5z = name_p5.clone();
                let t_p4z = t_p4.clone();
                let ti_p6z = ti_p6.clone();
                let k_let6719 = move |v6719: crate::check::types::St| {
                    let st_p7 = v6719;
                    let cx_p8 = crate::check::env::reading::cx_of_f(&g_p0z, &info_p2z.name_p);
                    let params_p9 = crate::prelude::each(&t_p4z.params_p, &(|p_pb: &crate::syntax::Ident| p_pb.name_p.clone()));
                    let self_pa = crate::check::types::Ty::TyCon(name_p5z.clone(), crate::prelude::each(&params_p9, &(|p_pc: &crate::prelude::Text| crate::check::types::Ty::TyQ(p_pc.clone()))));
                    if &ti_p6z.span_p != &d_p3z.span_p {
                        ::prism_rtl::Turn::Finished((g_p0z.clone(), st_p7.clone()))
                    } else {
                        match &t_p4z.body_o {
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished((g_p0z.clone(), st_p7.clone())),
                            ::std::option::Option::Some(body_pd) => match body_pd {
                                crate::syntax::decls::TypeBody::TbRecord(fs_pe) => {
                                    let fs_pex = fs_pe.clone();
                                    crate::prelude::call_value(crate::prelude::fold_job(fs_pex.clone(), (crate::prelude::Array::new(), st_p7.clone()), {
                                        let cx_p8x = cx_p8.clone();
                                        let g_p0zx = g_p0z.clone();
                                        let info_p2zx = info_p2z.clone();
                                        let t_p4zx = t_p4z.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)| {
                                            let cx_p8xy = cx_p8x.clone();
                                            let g_p0zxy = g_p0zx.clone();
                                            let info_p2zxy = info_p2zx.clone();
                                            let t_p4zxy = t_p4zx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let (acc_pi, s_pj) = p0;
                                                let f_pk = p1;
                                                crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p8xy.clone(), sigils_on_name_f(&second_field_f(&s_pj, &acc_pi, &f_pk), &crate::prelude::or(&crate::prelude::index(&g_p0zxy.srcs_p, &info_p2zxy.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit("?"), &crate::prelude::Text::lit(""))), &f_pk), f_pk.ty_p.clone()), move |conv_type_f_7320: (crate::check::types::Ty, crate::check::types::St)| {
                                                    let (ft_pl, s2_pm) = conv_type_f_7320;
                                                    let acc_piz = acc_pi.clone();
                                                    let f_pkz = f_pk.clone();
                                                    let ft_plz = ft_pl.clone();
                                                    let info_p2zxyz = info_p2zxy.clone();
                                                    let t_p4zxyz = t_p4zxy.clone();
                                                    let k_let7450 = move |v7450: (crate::check::types::Rw, crate::check::types::St)| {
                                                        let (field_row_pn, s3_po) = v7450;
                                                        crate::prelude::call_then(start_field_row_bound_f(s3_po.clone(), info_p2zxyz.clone(), crate::check::env::dotted_f(&t_p4zxyz.name_p.path_p), f_pkz.clone()), move |field_row_bound_f_7643: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_piz, &(f_pkz.name_p.name_p.clone(), field_sigils_f(&f_pkz.sigils_p, &ft_plz, &field_row_pn))), field_row_bound_f_7643)))
                                                    };
                                                    if crate::syntax::lexer::chars::contains_f(&f_pk.sigils_p, &crate::prelude::Text::lit("@")) {
                                                        crate::prelude::call_then(start_field_row_f(cx_p8xy.clone(), s2_pm.clone(), f_pk.ty_p.clone()), move |field_row_f_7500: (crate::check::types::Rw, crate::check::types::St)| k_let7450(field_row_f_7500))
                                                    } else {
                                                        k_let7450((cx_p8xy.scope_p.clone(), s2_pm.clone()))
                                                    }
                                                })
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St)>>>
                                    }), move |fold_7235: (crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St)| {
                                        let (fields_pp, st2a_pq) = fold_7235;
                                        let st2_pf = second_constructor_f(&g_p0z, &st2a_pq, &name_p5z, &name_p5z, &d_p3z.span_p);
                                        let ctor_pg = crate::check::env::CtorInfo { name_p: name_p5z.clone(), owner_p: name_p5z.clone(), params_p: params_p9.clone(), args_p: crate::prelude::each(&fields_pp, &(|(_, ft_pr): &(crate::prelude::Text, crate::check::types::Ty)| ft_pr.clone())), fields_p: crate::prelude::each(&fields_pp, &(|(fname_ps, _): &(crate::prelude::Text, crate::check::types::Ty)| fname_ps.clone())), ty_p: self_pa.clone(), index_p: crate::prelude::Nat::from(0u32) };
                                        let upd_ph = {
                                            let mut this: crate::check::env::G = g_p0z.clone();
                                            this.types_p = crate::prelude::insert(&this.types_p, &name_p5z, &with_body_f(&ti_p6z, &crate::check::env::TyBody::BRecord(fields_pp.clone())));
                                            this.ctors_p = crate::prelude::insert(&this.ctors_p, &name_p5z, &ctor_pg);
                                            this
                                        };
                                        ::prism_rtl::Turn::Finished((upd_ph.clone(), st2_pf.clone()))
                                    })
                                },
                                crate::syntax::decls::TypeBody::TbChoice(cs_pt) => {
                                    let cs_ptx = cs_pt.clone();
                                    crate::prelude::call_then(start_case_rows_bound_f(st_p7.clone(), info_p2z.clone(), crate::check::env::dotted_f(&t_p4z.name_p.path_p), cs_ptx.clone()), move |case_rows_bound_f_8257: crate::check::types::St| ::prism_rtl::Turn::More(::std::rc::Rc::new(ConvCases { g_p0: g_p0z.clone(), st_p1: case_rows_bound_f_8257, cx_p2: cx_p8.clone(), ti_p3: ti_p6z.clone(), name_p4: name_p5z.clone(), params_p5: params_p9.clone(), self_p6: self_pa.clone(), cs_p7: cs_ptx.clone() })))
                                },
                                crate::syntax::decls::TypeBody::TbNewtype(c_pu) => {
                                    let c_pux = c_pu.clone();
                                    crate::prelude::call_then(start_case_rows_bound_f(st_p7.clone(), info_p2z.clone(), crate::check::env::dotted_f(&t_p4z.name_p.path_p), crate::prelude::Array::from(vec![c_pux.clone()])), move |case_rows_bound_f_8386: crate::check::types::St| ::prism_rtl::Turn::More(::std::rc::Rc::new(ConvCases { g_p0: g_p0z.clone(), st_p1: case_rows_bound_f_8386, cx_p2: cx_p8.clone(), ti_p3: ti_p6z.clone(), name_p4: name_p5z.clone(), params_p5: params_p9.clone(), self_p6: self_pa.clone(), cs_p7: crate::prelude::Array::from(vec![c_pux.clone()]) })))
                                },
                                crate::syntax::decls::TypeBody::TbUnit(i_pv) => {
                                    let st_unit_p10 = second_constructor_f(&g_p0z, &st_p7, &crate::check::env::qual_key_f(&info_p2z.name_p, &i_pv.name_p), &name_p5z, &i_pv.span_p);
                                    let ctor_p11 = crate::check::env::CtorInfo { name_p: crate::check::env::qual_key_f(&info_p2z.name_p, &i_pv.name_p), owner_p: name_p5z.clone(), params_p: params_p9.clone(), args_p: crate::prelude::Array::new(), fields_p: crate::prelude::Array::new(), ty_p: self_pa.clone(), index_p: crate::prelude::Nat::from(0u32) };
                                    let upd_p12 = {
                                        let mut this: crate::check::env::G = g_p0z.clone();
                                        this.types_p = crate::prelude::insert(&this.types_p, &name_p5z, &with_body_f(&ti_p6z, &crate::check::env::TyBody::BChoice(crate::prelude::Array::from(vec![(i_pv.name_p.clone(), crate::prelude::Array::new())]))));
                                        this.ctors_p = crate::prelude::insert(&this.ctors_p, &crate::check::env::qual_key_f(&info_p2z.name_p, &i_pv.name_p), &ctor_p11);
                                        this
                                    };
                                    ::prism_rtl::Turn::Finished((upd_p12.clone(), st_unit_p10.clone()))
                                },
                                crate::syntax::decls::TypeBody::TbRow => {
                                    let upd_p13 = {
                                        let mut this: crate::check::env::G = g_p0z.clone();
                                        this.types_p = crate::prelude::insert(&this.types_p, &name_p5z, &with_body_f(&ti_p6z, &crate::check::env::TyBody::BRowKind));
                                        this
                                    };
                                    ::prism_rtl::Turn::Finished((upd_p13.clone(), st_p7.clone()))
                                },
                                crate::syntax::decls::TypeBody::TbAlias(_) => ::prism_rtl::Turn::Finished((g_p0z.clone(), st_p7.clone())),
                            },
                        }
                    }
                };
                if &ti_p6.span_p == &d_p3.span_p {
                    {
                        let st0_p1x = st0_p1.clone();
                        let t_p4x = t_p4.clone();
                        crate::prelude::call_then(start_type_head_variables_f(st0_p1x.clone(), t_p4x.clone()), move |type_head_variables_f_6750: crate::check::types::St| k_let6719(type_head_variables_f_6750))
                    }
                } else {
                    k_let6719(st0_p1.clone())
                }
            },
            _ => ::prism_rtl::Turn::Finished((g_p0.clone(), st0_p1.clone())),
        }
    }
}

/// `Start ConvertTypeDecl, x`: what the function value is when passed to `@Run`.
pub fn start_convert_type_decl_f(g_p0: crate::check::env::G, st0_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo, d_p3: crate::syntax::decls::Decl) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvertTypeDecl { g_p0, st0_p1, info_p2, d_p3 })
}

/// ```prism
/// IsLetOf: fn Def, Text -> Bool
/// ```
pub fn is_let_of_f(d_p0: &crate::check::env::Def, qk_p1: &crate::prelude::Text) -> bool {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbLet(_) => &d_p0.qk_p == qk_p1,
        _ => false,
    }
}

/// ```prism
/// IsWidgetOf: fn Def, Text -> Bool
/// ```
pub fn is_widget_of_f(d_p0: &crate::check::env::Def, qk_p1: &crate::prelude::Text) -> bool {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbWidget(_) => &d_p0.qk_p == qk_p1,
        _ => false,
    }
}

/// ```prism
/// SecondField: fn St, [((Text, Ty))], Field -> St
/// ```
pub fn second_field_f(st_p0: &crate::check::types::St, fields_p1: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, f_p2: &crate::syntax::decls::Field) -> crate::check::types::St {
    if crate::prelude::fold(fields_p1, &false, &(|seen_p3: &bool, (fname_p4, _): &(crate::prelude::Text, crate::check::types::Ty)| *seen_p3 || (fname_p4 == &f_p2.name_p.name_p))) {
        crate::check::types::recording::err_f(st_p0, &crate::prelude::Text::lit("collision"), &f_p2.span_p, &crate::prelude::Text::from(format!("a second field `{}`", &f_p2.name_p.name_p)))
    } else {
        st_p0.clone()
    }
}

/// ```prism
/// SecondConstructor: fn G, St, Text, Text, Range -> St
/// ```
pub fn second_constructor_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, qk_p2: &crate::prelude::Text, owner_p3: &crate::prelude::Text, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    match crate::prelude::get(&g_p0.ctors_p, qk_p2) {
        ::std::option::Option::Some(other_p5) => crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("collision"), span_p4, &crate::prelude::Text::from(format!("a second constructor `{}`{}", &crate::check::types::bare_name_f(qk_p2), &(if &other_p5.owner_p == owner_p3 {
            crate::prelude::Text::lit("")
        } else {
            crate::prelude::Text::from(format!(": `{}` has one", &crate::check::types::bare_name_f(&other_p5.owner_p)))
        })))),
        ::std::option::Option::None => st_p1.clone(),
    }
}

/// ```prism
/// WithBody: fn TyInfo, TyBody -> TyInfo
/// ```
pub fn with_body_f(ti_p0: &crate::check::env::TyInfo, b_p1: &crate::check::env::TyBody) -> crate::check::env::TyInfo {
    let mut this: crate::check::env::TyInfo = ti_p0.clone();
    this.body_p = b_p1.clone();
    this
}

/// ```prism
/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
/// ```
pub fn conv_cases_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, cx_p2: &crate::check::env::reading::Cx, ti_p3: &crate::check::env::TyInfo, name_p4: &crate::prelude::Text, params_p5: &crate::prelude::Array<crate::prelude::Text>, self_p6: &crate::check::types::Ty, cs_p7: &crate::prelude::Array<crate::syntax::decls::Case>) -> (crate::check::env::G, crate::check::types::St) {
    let (cases_pf, st2_pg) = crate::prelude::run_to_end(crate::prelude::fold_job(cs_p7.clone(), (crate::prelude::Array::new(), st_p1.clone()), {
        let cx_p2x = cx_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::decls::Case)| {
            let cx_p2xy = cx_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p9, s_pa) = p0;
                let c_pb = p1;
                {
                    let s1_pc = match &c_pb.indexed_o {
                        ::std::option::Option::Some(_) => crate::check::types::recording::err_f(&s_pa, &crate::prelude::Text::lit("unsupported"), &c_pb.span_p, &crate::prelude::Text::lit("this checker does not implement indexed choices for user types")),
                        ::std::option::Option::None => s_pa.clone(),
                    };
                    crate::prelude::call_then(crate::check::env::reading::start_conv_types_f(cx_p2xy.clone(), s1_pc.clone(), c_pb.args_p.clone()), move |conv_types_f_10940: (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)| {
                        let (args_pd, s2_pe) = conv_types_f_10940;
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &(crate::check::env::sname_key_f(&c_pb.name_p), args_pd.clone())), s2_pe.clone()))
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::decls::Case)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)>, crate::check::types::St)>>>
    }));
    let (g2_pp, st3_pq) = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&cases_pf)), &(g_p0.clone(), st2_pg.clone()), &(|(gg_ph, s_pi): &(crate::check::env::G, crate::check::types::St), i_pj: &crate::prelude::Nat| {
        let (cn_pn, args_po) = crate::prelude::or(&crate::prelude::index(&cases_pf, i_pj), &(crate::prelude::Text::lit(""), crate::prelude::Array::new()));
        let qk_pk = crate::check::env::qual_key_f(&ti_p3.home_p, &cn_pn);
        let s2_pl = second_constructor_f(gg_ph, s_pi, &qk_pk, name_p4, &crate::prelude::or(&crate::prelude::index(cs_p7, i_pj), &dummy_case_p()).span_p);
        let upd_pm = {
            let mut this: crate::check::env::G = gg_ph.clone();
            this.ctors_p = crate::prelude::insert(&this.ctors_p, &qk_pk, &crate::check::env::CtorInfo { name_p: qk_pk.clone(), owner_p: name_p4.clone(), params_p: params_p5.clone(), args_p: args_po.clone(), fields_p: crate::prelude::Array::new(), ty_p: self_p6.clone(), index_p: i_pj.clone() });
            this
        };
        (upd_pm.clone(), s2_pl.clone())
    }));
    let upd_p8 = {
        let mut this: crate::check::env::G = g2_pp.clone();
        this.types_p = crate::prelude::insert(&this.types_p, name_p4, &with_body_f(ti_p3, &crate::check::env::TyBody::BChoice(cases_pf.clone())));
        this
    };
    (upd_p8.clone(), st3_pq.clone())
}

/// The step machine of `ConvCases`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
/// ```
pub struct ConvCases {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub cx_p2: crate::check::env::reading::Cx,
    pub ti_p3: crate::check::env::TyInfo,
    pub name_p4: crate::prelude::Text,
    pub params_p5: crate::prelude::Array<crate::prelude::Text>,
    pub self_p6: crate::check::types::Ty,
    pub cs_p7: crate::prelude::Array<crate::syntax::decls::Case>,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvCases {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let cx_p2 = &self.cx_p2;
        let ti_p3 = &self.ti_p3;
        let name_p4 = &self.name_p4;
        let params_p5 = &self.params_p5;
        let self_p6 = &self.self_p6;
        let cs_p7 = &self.cs_p7;
        let cs_p7x = cs_p7.clone();
        let cx_p2x = cx_p2.clone();
        let g_p0x = g_p0.clone();
        let name_p4x = name_p4.clone();
        let params_p5x = params_p5.clone();
        let self_p6x = self_p6.clone();
        let st_p1x = st_p1.clone();
        let ti_p3x = ti_p3.clone();
        crate::prelude::call_value(crate::prelude::fold_job(cs_p7x.clone(), (crate::prelude::Array::new(), st_p1x.clone()), {
            let cx_p2xx = cx_p2x.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::decls::Case)| {
                let cx_p2xxy = cx_p2xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p9, s_pa) = p0;
                    let c_pb = p1;
                    {
                        let s1_pc = match &c_pb.indexed_o {
                            ::std::option::Option::Some(_) => crate::check::types::recording::err_f(&s_pa, &crate::prelude::Text::lit("unsupported"), &c_pb.span_p, &crate::prelude::Text::lit("this checker does not implement indexed choices for user types")),
                            ::std::option::Option::None => s_pa.clone(),
                        };
                        crate::prelude::call_then(crate::check::env::reading::start_conv_types_f(cx_p2xxy.clone(), s1_pc.clone(), c_pb.args_p.clone()), move |conv_types_f_10940: (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)| {
                            let (args_pd, s2_pe) = conv_types_f_10940;
                            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &(crate::check::env::sname_key_f(&c_pb.name_p), args_pd.clone())), s2_pe.clone()))
                        })
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::decls::Case)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)>, crate::check::types::St)>>>
        }), move |fold_10702: (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)>, crate::check::types::St)| {
            let (cases_pf, st2_pg) = fold_10702;
            let (g2_pp, st3_pq) = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&cases_pf)), &(g_p0x.clone(), st2_pg.clone()), &(|(gg_ph, s_pi): &(crate::check::env::G, crate::check::types::St), i_pj: &crate::prelude::Nat| {
                let (cn_pn, args_po) = crate::prelude::or(&crate::prelude::index(&cases_pf, i_pj), &(crate::prelude::Text::lit(""), crate::prelude::Array::new()));
                let qk_pk = crate::check::env::qual_key_f(&ti_p3x.home_p, &cn_pn);
                let s2_pl = second_constructor_f(gg_ph, s_pi, &qk_pk, &name_p4x, &crate::prelude::or(&crate::prelude::index(&cs_p7x, i_pj), &dummy_case_p()).span_p);
                let upd_pm = {
                    let mut this: crate::check::env::G = gg_ph.clone();
                    this.ctors_p = crate::prelude::insert(&this.ctors_p, &qk_pk, &crate::check::env::CtorInfo { name_p: qk_pk.clone(), owner_p: name_p4x.clone(), params_p: params_p5x.clone(), args_p: args_po.clone(), fields_p: crate::prelude::Array::new(), ty_p: self_p6x.clone(), index_p: i_pj.clone() });
                    this
                };
                (upd_pm.clone(), s2_pl.clone())
            }));
            let upd_p8 = {
                let mut this: crate::check::env::G = g2_pp.clone();
                this.types_p = crate::prelude::insert(&this.types_p, &name_p4x, &with_body_f(&ti_p3x, &crate::check::env::TyBody::BChoice(cases_pf.clone())));
                this
            };
            ::prism_rtl::Turn::Finished((upd_p8.clone(), st3_pq.clone()))
        })
    }
}

/// `Start ConvCases, x`: what the function value is when passed to `@Run`.
pub fn start_conv_cases_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, cx_p2: crate::check::env::reading::Cx, ti_p3: crate::check::env::TyInfo, name_p4: crate::prelude::Text, params_p5: crate::prelude::Array<crate::prelude::Text>, self_p6: crate::check::types::Ty, cs_p7: crate::prelude::Array<crate::syntax::decls::Case>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvCases { g_p0, st_p1, cx_p2, ti_p3, name_p4, params_p5, self_p6, cs_p7 })
}

/// ```prism
/// let dummyCase
/// ```
pub fn dummy_case_p() -> crate::syntax::decls::Case {
    crate::syntax::decls::Case { name_p: crate::syntax::SName { sigils_p: crate::prelude::Text::lit(""), path_p: crate::prelude::Array::new(), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }, args_p: crate::prelude::Array::new(), indexed_o: ::std::option::Option::None, span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub fn convert_decl_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, d_p3: &crate::syntax::decls::Decl) -> (crate::check::env::G, crate::check::types::St) {
    match &d_p3.kind_p {
        crate::syntax::decls::DeclKind::DSignature(s_p4) => {
            let qk_p5 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::def_name_text_f(&s_p4.name_p));
            let cx_p6 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
            let lens_p7 = is_lens_text_f(&crate::check::env::def_name_text_f(&s_p4.name_p));
            let (sc0_pc, st1a_pd) = crate::check::env::reading::sig_scheme_f(&cx_p6, st_p1, &(if lens_p7 { lens_plain_f(&s_p4.ty_p) } else { s_p4.ty_p.clone() }), &s_p4.bounds_p);
            let st1_p8 = bounds_named_f(&st1a_pd, &s_p4.bounds_p, &crate::check::env::reading::type_vars_of_type_f(&s_p4.ty_p), &crate::prelude::Text::lit("the signature"), &crate::prelude::Text::lit("the signature"));
            let st2_p9 = if lens_p7 {
                lens_check_f(&st1_p8, &crate::prelude::or(&crate::prelude::index(&g_p0.srcs_p, &info_p2.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit("?"), &crate::prelude::Text::lit(""))), &crate::check::env::def_name_text_f(&s_p4.name_p), &s_p4.ty_p, &crate::check::env::def_name_span_f(&s_p4.name_p))
            } else {
                st1_p8.clone()
            };
            let sc_pa = if &crate::prelude::len(&st2_p9.diags_p) == &crate::prelude::len(&st1_p8.diags_p) {
                sc0_pc.clone()
            } else {
                {
                    let mut this: crate::check::types::Scheme = sc0_pc.clone();
                    this.ty_p = crate::check::types::Ty::TyErr;
                    this
                }
            };
            let st3_pb = check_mark_function_f(&st2_p9, &(if lens_p7 {
                crate::syntax::lexer::chars::drop_prefix_f(&crate::check::env::def_name_text_f(&s_p4.name_p), &crate::prelude::Text::lit("&"))
            } else {
                crate::check::env::def_name_text_f(&s_p4.name_p)
            }), &sc_pa.ty_p, &crate::check::env::def_name_span_f(&s_p4.name_p));
            if crate::check::env::has_key_f(&g_p0.vals_p, &qk_p5) {
                (g_p0.clone(), crate::check::types::recording::err_f(&st3_pb, &crate::prelude::Text::lit("collision"), &d_p3.span_p, &crate::prelude::Text::from(format!("a second signature for `{}`", &crate::check::env::def_name_text_f(&s_p4.name_p)))))
            } else {
                match crate::prelude::get(&g_p0.ctors_p, &qk_p5) {
                    ::std::option::Option::Some(constructor_pe) => (g_p0.clone(), crate::check::types::recording::err_f(&st3_pb, &crate::prelude::Text::lit("collision"), &d_p3.span_p, &crate::prelude::Text::from(format!("`{}` is a constructor of `{}` in this module", &crate::check::env::def_name_text_f(&s_p4.name_p), &crate::check::types::bare_name_f(&constructor_pe.owner_p))))),
                    ::std::option::Option::None => {
                        let upd_pf = {
                            let mut this: crate::check::env::G = g_p0.clone();
                            this.vals_p = crate::prelude::insert(&this.vals_p, &qk_p5, &crate::check::env::ValInfo { qk_p: qk_p5.clone(), scheme_p: sc_pa.clone(), sort_p: crate::prelude::Text::lit("fn"), has_sig_p: true, home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone() });
                            this
                        };
                        (upd_pf.clone(), st3_pb.clone())
                    },
                }
            }
        },
        crate::syntax::decls::DeclKind::DFn(f_pg) => {
            let qk_ph = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::def_name_text_f(&f_pg.name_p));
            (add_clause_f(g_p0, info_p2, &qk_ph, &crate::check::env::def_name_text_f(&f_pg.name_p), f_pg, &d_p3.span_p, st_p1), st_p1.clone())
        },
        crate::syntax::decls::DeclKind::DLet(l_pi) => {
            let names_pj = crate::check::env::names::pattern_names_f(&l_pi.pattern_p);
            let qk_pk = crate::check::env::qual_key_f(&info_p2.name_p, &crate::prelude::or(&crate::prelude::index(&names_pj, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")));
            let def_pl = crate::check::env::Def { qk_p: qk_pk.clone(), name_p: crate::prelude::or(&crate::prelude::index(&names_pj, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone(), body_p: crate::check::env::DefBody::DbLet(l_pi.clone()) };
            if crate::prelude::fold(&g_p0.defs_p, &false, &(|seen_pm: &bool, other_pn: &crate::check::env::Def| *seen_pm || is_let_of_f(other_pn, &qk_pk))) {
                (g_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("collision"), &d_p3.span_p, &crate::prelude::Text::from(format!("a second `let` for `{}`", &crate::prelude::or(&crate::prelude::index(&names_pj, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""))))))
            } else {
                {
                    let upd_po = {
                        let mut this: crate::check::env::G = g_p0.clone();
                        this.defs_p = crate::prelude::push(&this.defs_p, &def_pl);
                        this
                    };
                    (upd_po.clone(), st_p1.clone())
                }
            }
        },
        crate::syntax::decls::DeclKind::DWidget(w_pp) => {
            let qk_pq = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::sname_key_f(&w_pp.name_p));
            let def_pr = crate::check::env::Def { qk_p: qk_pq.clone(), name_p: crate::check::env::sname_key_f(&w_pp.name_p), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone(), body_p: crate::check::env::DefBody::DbWidget(w_pp.clone()) };
            let upd_ps = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.defs_p = crate::prelude::push(&this.defs_p, &def_pr);
                this
            };
            if crate::prelude::fold(&g_p0.defs_p, &false, &(|seen_pt: &bool, other_pu: &crate::check::env::Def| *seen_pt || is_widget_of_f(other_pu, &qk_pq))) {
                (upd_ps.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("collision"), &d_p3.span_p, &crate::prelude::Text::from(format!("`{}` is defined twice", &crate::check::env::sname_key_f(&w_pp.name_p)))))
            } else {
                (upd_ps.clone(), st_p1.clone())
            }
        },
        crate::syntax::decls::DeclKind::DTag(t_pv) => conv_tag_f(g_p0, st_p1, info_p2, t_pv, &d_p3.span_p),
        crate::syntax::decls::DeclKind::DTrait(t_p10) => conv_trait_f(g_p0, st_p1, info_p2, t_p10, &d_p3.span_p),
        crate::syntax::decls::DeclKind::DImpl(i_p11) => conv_impl_f(g_p0, st_p1, info_p2, i_p11, &d_p3.span_p),
        crate::syntax::decls::DeclKind::DCheck(c_p12) => {
            let upd_p13 = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.defs_p = crate::prelude::push(&this.defs_p, &crate::check::env::Def { qk_p: crate::check::env::qual_key_f(&info_p2.name_p, &crate::prelude::Text::from(format!("check {}", &c_p12.name_p.name_p))), name_p: c_p12.name_p.name_p.clone(), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone(), body_p: crate::check::env::DefBody::DbCheck(c_p12.clone()) });
                this
            };
            (upd_p13.clone(), st_p1.clone())
        },
        crate::syntax::decls::DeclKind::DTest(t_p14) => {
            let upd_p15 = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.defs_p = crate::prelude::push(&this.defs_p, &crate::check::env::Def { qk_p: crate::check::env::qual_key_f(&info_p2.name_p, &crate::prelude::Text::from(format!("test {}", &t_p14.name_p.name_p))), name_p: t_p14.name_p.name_p.clone(), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone(), body_p: crate::check::env::DefBody::DbTest(t_p14.clone()) });
                this
            };
            (upd_p15.clone(), st_p1.clone())
        },
        crate::syntax::decls::DeclKind::DStmt(s_p16) => match &s_p16.kind_p {
            crate::syntax::StmtKind::SEmit(_) => (g_p0.clone(), st_p1.clone()),
            _ => (g_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), &d_p3.span_p, &crate::prelude::Text::lit("a statement at the top of a file: nothing at top level is built"))),
        },
        _ => (g_p0.clone(), st_p1.clone()),
    }
}

/// The step machine of `ConvertDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub struct ConvertDecl {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
    pub d_p3: crate::syntax::decls::Decl,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvertDecl {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        let d_p3 = &self.d_p3;
        match &d_p3.kind_p {
            crate::syntax::decls::DeclKind::DSignature(s_p4) => {
                let qk_p5 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::def_name_text_f(&s_p4.name_p));
                let cx_p6 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
                let lens_p7 = is_lens_text_f(&crate::check::env::def_name_text_f(&s_p4.name_p));
                let d_p3x = d_p3.clone();
                let g_p0x = g_p0.clone();
                let info_p2x = info_p2.clone();
                let s_p4x = s_p4.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::env::reading::start_sig_scheme_f(cx_p6.clone(), st_p1x.clone(), if lens_p7 { lens_plain_f(&s_p4x.ty_p) } else { s_p4x.ty_p.clone() }, s_p4x.bounds_p.clone()), move |sig_scheme_f_12235: (crate::check::types::Scheme, crate::check::types::St)| {
                    let (sc0_pc, st1a_pd) = sig_scheme_f_12235;
                    crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(s_p4x.ty_p.clone()), move |type_vars_of_type_f_12347: crate::prelude::Array<crate::prelude::Text>| {
                        let st1_p8 = bounds_named_f(&st1a_pd, &s_p4x.bounds_p, &type_vars_of_type_f_12347, &crate::prelude::Text::lit("the signature"), &crate::prelude::Text::lit("the signature"));
                        let st2_p9 = if lens_p7 {
                            lens_check_f(&st1_p8, &crate::prelude::or(&crate::prelude::index(&g_p0x.srcs_p, &info_p2x.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit("?"), &crate::prelude::Text::lit(""))), &crate::check::env::def_name_text_f(&s_p4x.name_p), &s_p4x.ty_p, &crate::check::env::def_name_span_f(&s_p4x.name_p))
                        } else {
                            st1_p8.clone()
                        };
                        let sc_pa = if &crate::prelude::len(&st2_p9.diags_p) == &crate::prelude::len(&st1_p8.diags_p) {
                            sc0_pc.clone()
                        } else {
                            {
                                let mut this: crate::check::types::Scheme = sc0_pc.clone();
                                this.ty_p = crate::check::types::Ty::TyErr;
                                this
                            }
                        };
                        crate::prelude::call_then(start_check_mark_function_f(st2_p9.clone(), if lens_p7 {
                            crate::syntax::lexer::chars::drop_prefix_f(&crate::check::env::def_name_text_f(&s_p4x.name_p), &crate::prelude::Text::lit("&"))
                        } else {
                            crate::check::env::def_name_text_f(&s_p4x.name_p)
                        }, sc_pa.ty_p.clone(), crate::check::env::def_name_span_f(&s_p4x.name_p)), move |check_mark_function_f_12683: crate::check::types::St| {
                            let st3_pb = check_mark_function_f_12683;
                            if crate::check::env::has_key_f(&g_p0x.vals_p, &qk_p5) {
                                ::prism_rtl::Turn::Finished((g_p0x.clone(), crate::check::types::recording::err_f(&st3_pb, &crate::prelude::Text::lit("collision"), &d_p3x.span_p, &crate::prelude::Text::from(format!("a second signature for `{}`", &crate::check::env::def_name_text_f(&s_p4x.name_p))))))
                            } else {
                                match crate::prelude::get(&g_p0x.ctors_p, &qk_p5) {
                                    ::std::option::Option::Some(constructor_pe) => ::prism_rtl::Turn::Finished((g_p0x.clone(), crate::check::types::recording::err_f(&st3_pb, &crate::prelude::Text::lit("collision"), &d_p3x.span_p, &crate::prelude::Text::from(format!("`{}` is a constructor of `{}` in this module", &crate::check::env::def_name_text_f(&s_p4x.name_p), &crate::check::types::bare_name_f(&constructor_pe.owner_p)))))),
                                    ::std::option::Option::None => {
                                        let upd_pf = {
                                            let mut this: crate::check::env::G = g_p0x.clone();
                                            this.vals_p = crate::prelude::insert(&this.vals_p, &qk_p5, &crate::check::env::ValInfo { qk_p: qk_p5.clone(), scheme_p: sc_pa.clone(), sort_p: crate::prelude::Text::lit("fn"), has_sig_p: true, home_p: info_p2x.name_p.clone(), file_p: info_p2x.file_p.clone(), span_p: d_p3x.span_p.clone() });
                                            this
                                        };
                                        ::prism_rtl::Turn::Finished((upd_pf.clone(), st3_pb.clone()))
                                    },
                                }
                            }
                        })
                    })
                })
            },
            crate::syntax::decls::DeclKind::DFn(f_pg) => {
                let qk_ph = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::def_name_text_f(&f_pg.name_p));
                ::prism_rtl::Turn::Finished((add_clause_f(g_p0, info_p2, &qk_ph, &crate::check::env::def_name_text_f(&f_pg.name_p), f_pg, &d_p3.span_p, st_p1), st_p1.clone()))
            },
            crate::syntax::decls::DeclKind::DLet(l_pi) => {
                let d_p3x = d_p3.clone();
                let g_p0x = g_p0.clone();
                let info_p2x = info_p2.clone();
                let l_pix = l_pi.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(l_pix.pattern_p.clone()), move |pattern_names_f_13587: crate::prelude::Array<crate::prelude::Text>| {
                    let names_pj = pattern_names_f_13587;
                    let qk_pk = crate::check::env::qual_key_f(&info_p2x.name_p, &crate::prelude::or(&crate::prelude::index(&names_pj, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")));
                    let def_pl = crate::check::env::Def { qk_p: qk_pk.clone(), name_p: crate::prelude::or(&crate::prelude::index(&names_pj, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), home_p: info_p2x.name_p.clone(), file_p: info_p2x.file_p.clone(), span_p: d_p3x.span_p.clone(), body_p: crate::check::env::DefBody::DbLet(l_pix.clone()) };
                    if crate::prelude::fold(&g_p0x.defs_p, &false, &(|seen_pm: &bool, other_pn: &crate::check::env::Def| *seen_pm || is_let_of_f(other_pn, &qk_pk))) {
                        ::prism_rtl::Turn::Finished((g_p0x.clone(), crate::check::types::recording::err_f(&st_p1x, &crate::prelude::Text::lit("collision"), &d_p3x.span_p, &crate::prelude::Text::from(format!("a second `let` for `{}`", &crate::prelude::or(&crate::prelude::index(&names_pj, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")))))))
                    } else {
                        {
                            let upd_po = {
                                let mut this: crate::check::env::G = g_p0x.clone();
                                this.defs_p = crate::prelude::push(&this.defs_p, &def_pl);
                                this
                            };
                            ::prism_rtl::Turn::Finished((upd_po.clone(), st_p1x.clone()))
                        }
                    }
                })
            },
            crate::syntax::decls::DeclKind::DWidget(w_pp) => {
                let qk_pq = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::sname_key_f(&w_pp.name_p));
                let def_pr = crate::check::env::Def { qk_p: qk_pq.clone(), name_p: crate::check::env::sname_key_f(&w_pp.name_p), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone(), body_p: crate::check::env::DefBody::DbWidget(w_pp.clone()) };
                let upd_ps = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.defs_p = crate::prelude::push(&this.defs_p, &def_pr);
                    this
                };
                if crate::prelude::fold(&g_p0.defs_p, &false, &(|seen_pt: &bool, other_pu: &crate::check::env::Def| *seen_pt || is_widget_of_f(other_pu, &qk_pq))) {
                    ::prism_rtl::Turn::Finished((upd_ps.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("collision"), &d_p3.span_p, &crate::prelude::Text::from(format!("`{}` is defined twice", &crate::check::env::sname_key_f(&w_pp.name_p))))))
                } else {
                    ::prism_rtl::Turn::Finished((upd_ps.clone(), st_p1.clone()))
                }
            },
            crate::syntax::decls::DeclKind::DTag(t_pv) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ConvTag { g_p0: g_p0.clone(), st_p1: st_p1.clone(), info_p2: info_p2.clone(), t_p3: t_pv.clone(), span_p4: d_p3.span_p.clone() })),
            crate::syntax::decls::DeclKind::DTrait(t_p10) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ConvTrait { g_p0: g_p0.clone(), st_p1: st_p1.clone(), info_p2: info_p2.clone(), t_p3: t_p10.clone(), span_p4: d_p3.span_p.clone() })),
            crate::syntax::decls::DeclKind::DImpl(i_p11) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ConvImpl { g_p0: g_p0.clone(), st_p1: st_p1.clone(), info_p2: info_p2.clone(), i_p3: i_p11.clone(), span_p4: d_p3.span_p.clone() })),
            crate::syntax::decls::DeclKind::DCheck(c_p12) => {
                let upd_p13 = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.defs_p = crate::prelude::push(&this.defs_p, &crate::check::env::Def { qk_p: crate::check::env::qual_key_f(&info_p2.name_p, &crate::prelude::Text::from(format!("check {}", &c_p12.name_p.name_p))), name_p: c_p12.name_p.name_p.clone(), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone(), body_p: crate::check::env::DefBody::DbCheck(c_p12.clone()) });
                    this
                };
                ::prism_rtl::Turn::Finished((upd_p13.clone(), st_p1.clone()))
            },
            crate::syntax::decls::DeclKind::DTest(t_p14) => {
                let upd_p15 = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.defs_p = crate::prelude::push(&this.defs_p, &crate::check::env::Def { qk_p: crate::check::env::qual_key_f(&info_p2.name_p, &crate::prelude::Text::from(format!("test {}", &t_p14.name_p.name_p))), name_p: t_p14.name_p.name_p.clone(), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone(), body_p: crate::check::env::DefBody::DbTest(t_p14.clone()) });
                    this
                };
                ::prism_rtl::Turn::Finished((upd_p15.clone(), st_p1.clone()))
            },
            crate::syntax::decls::DeclKind::DStmt(s_p16) => match &s_p16.kind_p {
                crate::syntax::StmtKind::SEmit(_) => ::prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
                _ => ::prism_rtl::Turn::Finished((g_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), &d_p3.span_p, &crate::prelude::Text::lit("a statement at the top of a file: nothing at top level is built")))),
            },
            _ => ::prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
        }
    }
}

/// `Start ConvertDecl, x`: what the function value is when passed to `@Run`.
pub fn start_convert_decl_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo, d_p3: crate::syntax::decls::Decl) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvertDecl { g_p0, st_p1, info_p2, d_p3 })
}

/// ```prism
/// AddClause: fn G, ModInfo, Text, Text, FnClause, Range, St -> G
/// ```
pub fn add_clause_f(g_p0: &crate::check::env::G, info_p1: &crate::check::env::ModInfo, qk_p2: &crate::prelude::Text, name_p3: &crate::prelude::Text, f_p4: &crate::syntax::decls::FnClause, span_p5: &crate::syntax::Range, st_p6: &crate::check::types::St) -> crate::check::env::G {
    match crate::prelude::get(&g_p0.fn_at_p, qk_p2) {
        ::std::option::Option::Some(i_p7) => {
            let mut this: crate::check::env::G = g_p0.clone();
            this.defs_p = insert2_f(&this.defs_p, &i_p7, &add_to_fn_f(&crate::prelude::or(&crate::prelude::index(&this.defs_p, &i_p7), &dummy_def_p()), f_p4));
            this
        },
        ::std::option::Option::None => {
            let mut this: crate::check::env::G = g_p0.clone();
            this.fn_at_p = crate::prelude::insert(&this.fn_at_p, qk_p2, &crate::prelude::len(&this.defs_p));
            this.defs_p = crate::prelude::push(&this.defs_p, &crate::check::env::Def { qk_p: qk_p2.clone(), name_p: name_p3.clone(), home_p: info_p1.name_p.clone(), file_p: info_p1.file_p.clone(), span_p: span_p5.clone(), body_p: crate::check::env::DefBody::DbFn(crate::prelude::Array::from(vec![f_p4.clone()])) });
            this
        },
    }
}

/// ```prism
/// let dummyDef
/// ```
pub fn dummy_def_p() -> crate::check::env::Def {
    crate::check::env::Def { qk_p: crate::prelude::Text::lit(""), name_p: crate::prelude::Text::lit(""), home_p: crate::prelude::Text::lit(""), file_p: crate::prelude::Nat::from(0u32), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) }, body_p: crate::check::env::DefBody::DbFn(crate::prelude::Array::new()) }
}

/// ```prism
/// IsFnDef: fn Def -> Bool
/// ```
pub fn is_fn_def_f(d_p0: &crate::check::env::Def) -> bool {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbFn(_) => true,
        _ => false,
    }
}

/// ```prism
/// AddToFn: fn Def, FnClause -> Def
/// ```
pub fn add_to_fn_f(d_p0: &crate::check::env::Def, f_p1: &crate::syntax::decls::FnClause) -> crate::check::env::Def {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbFn(fs_p2) => {
            let mut this: crate::check::env::Def = d_p0.clone();
            this.body_p = crate::check::env::DefBody::DbFn(crate::prelude::push(fs_p2, f_p1));
            this
        },
        _ => d_p0.clone(),
    }
}

/// ```prism
/// Insert2: fn [a], Nat, a -> [a]
/// ```
pub fn insert2_f<A: ::std::clone::Clone + 'static>(xs_p0: &crate::prelude::Array<A>, i_p1: &crate::prelude::Nat, x_p2: &A) -> crate::prelude::Array<A> {
    crate::prelude::append(&crate::prelude::push(&crate::prelude::take(xs_p0, i_p1), x_p2), &crate::prelude::drop(xs_p0, &(i_p1 + &crate::prelude::Nat::from(1u32))))
}

/// ```prism
/// LensCheck: fn St, Src, Text, Type, Range -> St
/// ```
pub fn lens_check_f(st_p0: &crate::check::types::St, src_p1: &crate::check::errors::Src, name_p2: &crate::prelude::Text, t_p3: &crate::syntax::Type, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    match &*t_p3.kind_p {
        crate::syntax::TypeKind::TFn(_, ps_p5, res_p6) => {
            let refs_p7 = crate::prelude::filter(ps_p5, &(|p_p8: &crate::syntax::Type| is_ref_type_f(p_p8)));
            if &crate::prelude::len(&refs_p7) > &crate::prelude::Nat::from(1u32) {
                crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("lens-arity"), span_p4, &crate::prelude::Text::lit("a lens takes one reference"), &crate::prelude::Text::lit("take the second part as a plain value"))
            } else {
                if &crate::prelude::len(&refs_p7) == &crate::prelude::Nat::from(0u32) {
                    {
                        let fix_p9 = match crate::prelude::index(ps_p5, &crate::prelude::Nat::from(0u32)) {
                            ::std::option::Option::Some(p_pa) => crate::prelude::Text::from(format!("write its parameter as a reference, `&{}`", &crate::check::errors::span_text_f(src_p1, &p_pa.span_p))),
                            ::std::option::Option::None => crate::prelude::Text::lit("give it one parameter, a reference"),
                        };
                        crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("lens-arity"), span_p4, &crate::prelude::Text::from(format!("a lens takes one reference, and `{}` takes none", name_p2)), &fix_p9)
                    }
                } else {
                    if &crate::prelude::len(ps_p5) > &crate::prelude::Nat::from(1u32) {
                        crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("lens-arity"), span_p4, &crate::prelude::Text::from(format!("a lens takes one reference and nothing else, and `{}` takes {} parameters", name_p2, &crate::prelude::len(ps_p5))), &crate::prelude::Text::lit("write a lens for each part, or the path in the `update` block"))
                    } else {
                        if !is_ref_type_f(&**res_p6) {
                            crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("lens-result"), span_p4, &crate::prelude::Text::from(format!("a lens gives back a reference, and `{}` gives back `{}`", name_p2, &crate::check::errors::span_text_f(src_p1, &res_p6.span_p))), &crate::prelude::Text::from(format!("write the result as `&{}`", &crate::check::errors::span_text_f(src_p1, &res_p6.span_p))))
                        } else {
                            st_p0.clone()
                        }
                    }
                }
            }
        },
        _ => crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("lens-result"), span_p4, &crate::prelude::Text::lit("a name with `&` is a lens, a function from one reference to a reference"), &crate::prelude::Text::from(format!("write `{}: fn &Whole -> &Part`, or name it without `&`", name_p2))),
    }
}

/// ```prism
/// IsRefType: fn Type -> Bool
/// ```
pub fn is_ref_type_f(t_p0: &crate::syntax::Type) -> bool {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TName(n_p1, _) => crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &crate::prelude::Text::lit("&")),
        crate::syntax::TypeKind::TSigiled(s_p2, _) => crate::syntax::lexer::chars::has_prefix_f(s_p2, &crate::prelude::Text::lit("&")),
        _ => false,
    }
}

/// ```prism
/// IsLensText: fn Text -> Bool
/// ```
pub fn is_lens_text_f(name_p0: &crate::prelude::Text) -> bool {
    let bare_p1 = crate::check::types::bare_name_f(name_p0);
    crate::syntax::lexer::chars::has_prefix_f(&bare_p1, &crate::prelude::Text::lit("&")) && crate::check::env::is_upper_text_f(&crate::syntax::lexer::chars::drop_prefix_f(&bare_p1, &crate::check::types::unify::marks_of_f(&bare_p1)))
}

/// ```prism
/// LensPlain: fn Type -> Type
/// ```
pub fn lens_plain_f(t_p0: &crate::syntax::Type) -> crate::syntax::Type {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TFn(color_p1, ps_p2, res_p3) => crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TFn(color_p1.clone(), crate::prelude::each(ps_p2, &without_ref_f), ::std::rc::Rc::new(without_ref_f(&**res_p3)))), span_p: t_p0.span_p.clone() },
        _ => t_p0.clone(),
    }
}

/// ```prism
/// WithoutRef: fn Type -> Type
/// ```
pub fn without_ref_f(t_p0: &crate::syntax::Type) -> crate::syntax::Type {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TName(n_p1, args_p2) => if crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &crate::prelude::Text::lit("&")) {
            crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TName(crate::syntax::SName { sigils_p: crate::syntax::lexer::chars::drop_prefix_f(&n_p1.sigils_p, &crate::prelude::Text::lit("&")), path_p: n_p1.path_p.clone(), span_p: n_p1.span_p.clone() }, args_p2.clone())), span_p: t_p0.span_p.clone() }
        } else {
            t_p0.clone()
        },
        crate::syntax::TypeKind::TSigiled(s_p3, inner_p4) => if s_p3 == &crate::prelude::Text::lit("&") {
            (**inner_p4).clone()
        } else {
            if crate::syntax::lexer::chars::has_prefix_f(s_p3, &crate::prelude::Text::lit("&")) {
                crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TSigiled(crate::syntax::lexer::chars::drop_prefix_f(s_p3, &crate::prelude::Text::lit("&")), ::std::rc::Rc::new((**inner_p4).clone()))), span_p: t_p0.span_p.clone() }
            } else {
                t_p0.clone()
            }
        },
        _ => t_p0.clone(),
    }
}

/// ```prism
/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
/// ```
pub fn check_mark_function_f(st_p0: &crate::check::types::St, name_p1: &crate::prelude::Text, t_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    match t_p2 {
        crate::check::types::Ty::TyFn(_, _, res_p4) => {
            let want_p5 = crate::check::types::head_sigil_f(st_p0, &**res_p4);
            let marks_p6 = crate::check::types::unify::marks_of_f(name_p1);
            let shown_p7 = crate::syntax::lexer::chars::head_f(&marks_p6);
            let bare_p8 = crate::syntax::lexer::chars::drop_prefix_f(name_p1, &marks_p6);
            if (((&shown_p7 == &want_p5) || (&crate::prelude::len_text(&marks_p6) > &crate::prelude::Nat::from(1u32))) || (&bare_p8 == &crate::prelude::Text::lit(""))) || !crate::check::env::is_upper_text_f(&bare_p8) {
                st_p0.clone()
            } else {
                crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("mark-function"), span_p3, &crate::prelude::Text::from(format!("`{}` returns `{}`; name it `{}{}`", name_p1, &crate::check::types::show_ty_f(st_p0, &**res_p4), &want_p5, &bare_p8)), &crate::prelude::Text::from(format!("rename to `{}{}`", &want_p5, &bare_p8)))
            }
        },
        _ => st_p0.clone(),
    }
}

/// The step machine of `CheckMarkFunction`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
/// ```
pub struct CheckMarkFunction {
    pub st_p0: crate::check::types::St,
    pub name_p1: crate::prelude::Text,
    pub t_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for CheckMarkFunction {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let name_p1 = &self.name_p1;
        let t_p2 = &self.t_p2;
        let span_p3 = &self.span_p3;
        match t_p2 {
            crate::check::types::Ty::TyFn(_, _, res_p4) => {
                let name_p1x = name_p1.clone();
                let res_p4x = (**res_p4).clone();
                let span_p3x = span_p3.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p0x.clone(), res_p4x.clone()), move |head_sigil_f_19675: crate::prelude::Text| {
                    let want_p5 = head_sigil_f_19675;
                    let marks_p6 = crate::check::types::unify::marks_of_f(&name_p1x);
                    let shown_p7 = crate::syntax::lexer::chars::head_f(&marks_p6);
                    let bare_p8 = crate::syntax::lexer::chars::drop_prefix_f(&name_p1x, &marks_p6);
                    if (((&shown_p7 == &want_p5) || (&crate::prelude::len_text(&marks_p6) > &crate::prelude::Nat::from(1u32))) || (&bare_p8 == &crate::prelude::Text::lit(""))) || !crate::check::env::is_upper_text_f(&bare_p8) {
                        ::prism_rtl::Turn::Finished(st_p0x.clone())
                    } else {
                        crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p0x.clone(), res_p4x.clone()), move |show_ty_f_19955: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p0x, &crate::prelude::Text::lit("mark-function"), &span_p3x, &crate::prelude::Text::from(format!("`{}` returns `{}`; name it `{}{}`", &name_p1x, &show_ty_f_19955, &want_p5, &bare_p8)), &crate::prelude::Text::from(format!("rename to `{}{}`", &want_p5, &bare_p8)))))
                    }
                })
            },
            _ => ::prism_rtl::Turn::Finished(st_p0.clone()),
        }
    }
}

/// `Start CheckMarkFunction, x`: what the function value is when passed to `@Run`.
pub fn start_check_mark_function_f(st_p0: crate::check::types::St, name_p1: crate::prelude::Text, t_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CheckMarkFunction { st_p0, name_p1, t_p2, span_p3 })
}

/// ```prism
/// SigilsOnName: fn St, Src, Field -> St
/// ```
pub fn sigils_on_name_f(st_p0: &crate::check::types::St, src_p1: &crate::check::errors::Src, f_p2: &crate::syntax::decls::Field) -> crate::check::types::St {
    let sigils_p3 = type_sigils_f(&f_p2.ty_p);
    if crate::syntax::lexer::chars::has_prefix_f(&f_p2.sigils_p, &crate::prelude::Text::lit("&")) || crate::syntax::lexer::chars::has_prefix_f(&sigils_p3, &crate::prelude::Text::lit("&")) {
        crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("reference-stored"), &f_p2.span_p, &crate::prelude::Text::from(format!("the field `{}{}` would store a reference, and no reference outlives its `update` block", &f_p2.sigils_p, &f_p2.name_p.name_p)), &crate::prelude::Text::from(format!("store the value, `{}{}: {}`", &crate::syntax::lexer::chars::drop_prefix_f(&f_p2.sigils_p, &crate::prelude::Text::lit("&")), &f_p2.name_p.name_p, &crate::syntax::lexer::chars::drop_prefix_f(&crate::check::errors::span_text_f(src_p1, &f_p2.ty_p.span_p), &crate::prelude::Text::lit("&")))))
    } else {
        if &sigils_p3 == &crate::prelude::Text::lit("") {
            st_p0.clone()
        } else {
            crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("field-sigils"), &f_p2.span_p, &crate::prelude::Text::from(format!("the field `{}{}` writes `{}` on its type; a field\'s sigils stand on its name", &f_p2.sigils_p, &f_p2.name_p.name_p, &sigils_p3)), &crate::prelude::Text::from(format!("write `{}{}{}: ` and the type without them", &f_p2.sigils_p, &sigils_p3, &f_p2.name_p.name_p)))
        }
    }
}

/// ```prism
/// TypeSigils: fn Type -> Text
/// ```
pub fn type_sigils_f(t_p0: &crate::syntax::Type) -> crate::prelude::Text {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TName(n_p1, _) => n_p1.sigils_p.clone(),
        crate::syntax::TypeKind::TSigiled(s_p2, _) => s_p2.clone(),
        crate::syntax::TypeKind::TUnit(m_p3) => m_p3.clone(),
        crate::syntax::TypeKind::TGroup(inner_p4) => type_sigils_f(&**inner_p4),
        _ => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// FieldSigils: fn Text, Ty, Rw -> Ty
/// ```
pub fn field_sigils_f(sigils_p0: &crate::prelude::Text, t_p1: &crate::check::types::Ty, emitted_p2: &crate::check::types::Rw) -> crate::check::types::Ty {
    crate::check::types::with_marks_f(sigils_p0, t_p1, emitted_p2)
}

/// ```prism
/// FieldRowBound: unbounded fn St, ModInfo, Text, Field -> St
/// ```
pub fn field_row_bound_f(st_p0: &crate::check::types::St, info_p1: &crate::check::env::ModInfo, owner_p2: &crate::prelude::Text, f_p3: &crate::syntax::decls::Field) -> crate::check::types::St {
    let takes_scope_p4 = (crate::syntax::lexer::chars::contains_f(&f_p3.sigils_p, &crate::prelude::Text::lit("@")) && !writes_emit_f(&f_p3.ty_p)) || crate::check::env::reading::uses_scope_f(&f_p3.ty_p);
    if (&info_p1.row_var_p == &crate::prelude::Text::lit("")) || !takes_scope_p4 {
        st_p0.clone()
    } else {
        crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("unknown-name"), &f_p3.span_p, &crate::prelude::Text::from(format!("the field `{}{}` of `{}` emits the module\'s row `{}`, and a record has no row of its own", &f_p3.sigils_p, &f_p3.name_p.name_p, owner_p2, &info_p1.row_var_p)), &crate::prelude::Text::lit("write the row on the field\'s type, as `emit Ui.*`"))
    }
}

/// The step machine of `FieldRowBound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldRowBound: unbounded fn St, ModInfo, Text, Field -> St
/// ```
pub struct FieldRowBound {
    pub st_p0: crate::check::types::St,
    pub info_p1: crate::check::env::ModInfo,
    pub owner_p2: crate::prelude::Text,
    pub f_p3: crate::syntax::decls::Field,
}

impl ::prism_rtl::Job<crate::check::types::St> for FieldRowBound {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let info_p1 = &self.info_p1;
        let owner_p2 = &self.owner_p2;
        let f_p3 = &self.f_p3;
        let f_p3z = f_p3.clone();
        let info_p1z = info_p1.clone();
        let owner_p2z = owner_p2.clone();
        let st_p0z = st_p0.clone();
        let k_let22102 = move |v22102: bool| {
            let takes_scope_p4 = v22102;
            if (&info_p1z.row_var_p == &crate::prelude::Text::lit("")) || !takes_scope_p4 {
                ::prism_rtl::Turn::Finished(st_p0z.clone())
            } else {
                ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p0z, &crate::prelude::Text::lit("unknown-name"), &f_p3z.span_p, &crate::prelude::Text::from(format!("the field `{}{}` of `{}` emits the module\'s row `{}`, and a record has no row of its own", &f_p3z.sigils_p, &f_p3z.name_p.name_p, &owner_p2z, &info_p1z.row_var_p)), &crate::prelude::Text::lit("write the row on the field\'s type, as `emit Ui.*`")))
            }
        };
        if crate::syntax::lexer::chars::contains_f(&f_p3.sigils_p, &crate::prelude::Text::lit("@")) && !writes_emit_f(&f_p3.ty_p) {
            k_let22102(true)
        } else {
            {
                let f_p3x = f_p3.clone();
                crate::prelude::call_then(crate::check::env::reading::start_uses_scope_f(f_p3x.ty_p.clone()), move |uses_scope_f_22175: bool| k_let22102(uses_scope_f_22175))
            }
        }
    }
}

/// `Start FieldRowBound, x`: what the function value is when passed to `@Run`.
pub fn start_field_row_bound_f(st_p0: crate::check::types::St, info_p1: crate::check::env::ModInfo, owner_p2: crate::prelude::Text, f_p3: crate::syntax::decls::Field) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(FieldRowBound { st_p0, info_p1, owner_p2, f_p3 })
}

/// ```prism
/// CaseRowsBound: unbounded fn St, ModInfo, Text, [Case] -> St
/// ```
pub fn case_rows_bound_f(st_p0: &crate::check::types::St, info_p1: &crate::check::env::ModInfo, owner_p2: &crate::prelude::Text, cs_p3: &crate::prelude::Array<crate::syntax::decls::Case>) -> crate::check::types::St {
    if &info_p1.row_var_p == &crate::prelude::Text::lit("") {
        st_p0.clone()
    } else {
        crate::prelude::run_to_end(crate::prelude::fold_job(cs_p3.clone(), st_p0.clone(), {
            let owner_p2x = owner_p2.clone();
            let info_p1x = info_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::Case)| {
                let owner_p2xy = owner_p2x.clone();
                let info_p1xy = info_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p4 = p0;
                    let c_p5 = p1;
                    crate::prelude::call_value(crate::prelude::fold_job(c_p5.args_p.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let seen_p6 = p0;
                        let a_p7 = p1;
                        if seen_p6 {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::reading::UsesScope { t_p0: a_p7.clone() }))
                        }
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>), move |fold_22837: bool| if fold_22837 {
                        ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s_p4, &crate::prelude::Text::lit("unknown-name"), &c_p5.span_p, &crate::prelude::Text::from(format!("the case `{}` of `{}` emits the module\'s row `{}`, and a choice has no row of its own", &crate::check::env::sname_key_f(&c_p5.name_p), &owner_p2xy, &info_p1xy.row_var_p)), &crate::prelude::Text::lit("write the row on the case\'s type, as `emit Ui.*`")))
                    } else {
                        ::prism_rtl::Turn::Finished(s_p4.clone())
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::decls::Case)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }))
    }
}

/// The step machine of `CaseRowsBound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseRowsBound: unbounded fn St, ModInfo, Text, [Case] -> St
/// ```
pub struct CaseRowsBound {
    pub st_p0: crate::check::types::St,
    pub info_p1: crate::check::env::ModInfo,
    pub owner_p2: crate::prelude::Text,
    pub cs_p3: crate::prelude::Array<crate::syntax::decls::Case>,
}

impl ::prism_rtl::Job<crate::check::types::St> for CaseRowsBound {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let info_p1 = &self.info_p1;
        let owner_p2 = &self.owner_p2;
        let cs_p3 = &self.cs_p3;
        if &info_p1.row_var_p == &crate::prelude::Text::lit("") {
            ::prism_rtl::Turn::Finished(st_p0.clone())
        } else {
            crate::prelude::fold_job(cs_p3.clone(), st_p0.clone(), {
                let owner_p2x = owner_p2.clone();
                let info_p1x = info_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::Case)| {
                    let owner_p2xy = owner_p2x.clone();
                    let info_p1xy = info_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_p4 = p0;
                        let c_p5 = p1;
                        crate::prelude::call_value(crate::prelude::fold_job(c_p5.args_p.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let seen_p6 = p0;
                            let a_p7 = p1;
                            if seen_p6 {
                                ::prism_rtl::Turn::Finished(true)
                            } else {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::reading::UsesScope { t_p0: a_p7.clone() }))
                            }
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>), move |fold_22837: bool| if fold_22837 {
                            ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s_p4, &crate::prelude::Text::lit("unknown-name"), &c_p5.span_p, &crate::prelude::Text::from(format!("the case `{}` of `{}` emits the module\'s row `{}`, and a choice has no row of its own", &crate::check::env::sname_key_f(&c_p5.name_p), &owner_p2xy, &info_p1xy.row_var_p)), &crate::prelude::Text::lit("write the row on the case\'s type, as `emit Ui.*`")))
                        } else {
                            ::prism_rtl::Turn::Finished(s_p4.clone())
                        })
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::decls::Case)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
            }).cycle()
        }
    }
}

/// `Start CaseRowsBound, x`: what the function value is when passed to `@Run`.
pub fn start_case_rows_bound_f(st_p0: crate::check::types::St, info_p1: crate::check::env::ModInfo, owner_p2: crate::prelude::Text, cs_p3: crate::prelude::Array<crate::syntax::decls::Case>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CaseRowsBound { st_p0, info_p1, owner_p2, cs_p3 })
}

/// ```prism
/// WritesEmit: unbounded fn Type -> Bool
/// ```
pub fn writes_emit_f(t_p0: &crate::syntax::Type) -> bool {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TEmit(_, _) => true,
        crate::syntax::TypeKind::TGroup(inner_p1) => writes_emit_f(&**inner_p1),
        _ => false,
    }
}

/// The step machine of `WritesEmit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WritesEmit: unbounded fn Type -> Bool
/// ```
pub struct WritesEmit {
    pub t_p0: crate::syntax::Type,
}

impl ::prism_rtl::Job<bool> for WritesEmit {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TEmit(_, _) => ::prism_rtl::Turn::Finished(true),
            crate::syntax::TypeKind::TGroup(inner_p1) => ::prism_rtl::Turn::More(::std::rc::Rc::new(WritesEmit { t_p0: (**inner_p1).clone() })),
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start WritesEmit, x`: what the function value is when passed to `@Run`.
pub fn start_writes_emit_f(t_p0: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(WritesEmit { t_p0 })
}

/// ```prism
/// FieldRow: unbounded fn Cx, St, Type -> ((Rw, St))
/// ```
pub fn field_row_f(cx_p0: &crate::check::env::reading::Cx, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Type) -> (crate::check::types::Rw, crate::check::types::St) {
    match &*t_p2.kind_p {
        crate::syntax::TypeKind::TEmit(_, row_type_p3) => crate::check::env::reading::conv_row_f(cx_p0, st_p1, &**row_type_p3),
        crate::syntax::TypeKind::TGroup(inner_p4) => field_row_f(cx_p0, st_p1, &**inner_p4),
        _ => (cx_p0.scope_p.clone(), st_p1.clone()),
    }
}

/// The step machine of `FieldRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldRow: unbounded fn Cx, St, Type -> ((Rw, St))
/// ```
pub struct FieldRow {
    pub cx_p0: crate::check::env::reading::Cx,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Type,
}

impl ::prism_rtl::Job<(crate::check::types::Rw, crate::check::types::St)> for FieldRow {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Rw, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        match &*t_p2.kind_p {
            crate::syntax::TypeKind::TEmit(_, row_type_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::reading::ConvRow { cx_p0: cx_p0.clone(), st_p1: st_p1.clone(), t_p2: (**row_type_p3).clone() })),
            crate::syntax::TypeKind::TGroup(inner_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FieldRow { cx_p0: cx_p0.clone(), st_p1: st_p1.clone(), t_p2: (**inner_p4).clone() })),
            _ => ::prism_rtl::Turn::Finished((cx_p0.scope_p.clone(), st_p1.clone())),
        }
    }
}

/// `Start FieldRow, x`: what the function value is when passed to `@Run`.
pub fn start_field_row_f(cx_p0: crate::check::env::reading::Cx, st_p1: crate::check::types::St, t_p2: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Rw, crate::check::types::St)>> {
    ::std::rc::Rc::new(FieldRow { cx_p0, st_p1, t_p2 })
}

/// ```prism
/// MissingSignatures: fn G, St, ModInfo -> St
/// ```
pub fn missing_signatures_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo) -> crate::check::types::St {
    crate::prelude::fold(&g_p0.defs_p, st_p1, &(|s_p3: &crate::check::types::St, d_p4: &crate::check::env::Def| if ((&d_p4.home_p == &info_p2.name_p) && is_fn_def_f(d_p4)) && !crate::check::env::has_key_f(&g_p0.vals_p, &d_p4.qk_p) {
        crate::check::types::recording::err_fix_f(s_p3, &crate::prelude::Text::lit("no-signature"), &d_p4.span_p, &crate::prelude::Text::from(format!("`{}` has no signature line", &d_p4.name_p)), &crate::prelude::Text::from(format!("write `{}: fn ... -> ...` above it", &d_p4.name_p)))
    } else {
        s_p3.clone()
    }))
}

/// ```prism
/// MissingDefinitions: unbounded fn G, St -> St
/// ```
pub fn missing_definitions_f(g_p0: &crate::check::env::G, st0_p1: &crate::check::types::St) -> crate::check::types::St {
    let defined_p2 = crate::prelude::fold(&g_p0.defs_p, &crate::prelude::Map::new(), &(|m_p4: &crate::prelude::Map<crate::prelude::Text, bool>, x_p5: &crate::check::env::Def| crate::prelude::insert(m_p4, &x_p5.qk_p, &true)));
    let st_p3 = crate::prelude::fold(&crate::prelude::values(&g_p0.mods_p), st0_p1, &(|s0_p6: &crate::check::types::St, info_p7: &crate::check::env::ModInfo| if (&info_p7.file_p >= &g_p0.prelude_from_p) || (&info_p7.name_p == &crate::prelude::Text::lit("Prelude")) {
        s0_p6.clone()
    } else {
        {
            let s1_p8 = {
                let mut this: crate::check::types::St = s0_p6.clone();
                this.file_p = info_p7.file_p.clone();
                this
            };
            crate::prelude::fold(&info_p7.tree_p.decls_p, &s1_p8, &(|s_p9: &crate::check::types::St, d_pa: &crate::syntax::decls::Decl| match &d_pa.kind_p {
                crate::syntax::decls::DeclKind::DSignature(sg_pb) => if crate::check::env::has_key_f(&defined_p2, &crate::check::env::qual_key_f(&info_p7.name_p, &crate::check::env::def_name_text_f(&sg_pb.name_p))) {
                    s_p9.clone()
                } else {
                    crate::check::types::recording::err_fix_f(s_p9, &crate::prelude::Text::lit("no-definition"), &d_pa.span_p, &crate::prelude::Text::from(format!("`{}` has a signature line and no definition", &crate::check::env::def_name_text_f(&sg_pb.name_p))), &crate::prelude::Text::from(format!("define it under its signature, `fn {} ... = ...`, or delete the line", &crate::check::env::def_name_text_f(&sg_pb.name_p))))
                },
                _ => s_p9.clone(),
            }))
        }
    }));
    let mut this: crate::check::types::St = st_p3.clone();
    this.file_p = st0_p1.file_p.clone();
    this
}

/// The step machine of `MissingDefinitions`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MissingDefinitions: unbounded fn G, St -> St
/// ```
pub struct MissingDefinitions {
    pub g_p0: crate::check::env::G,
    pub st0_p1: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::types::St> for MissingDefinitions {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st0_p1 = &self.st0_p1;
        let defined_p2 = crate::prelude::fold(&g_p0.defs_p, &crate::prelude::Map::new(), &(|m_p4: &crate::prelude::Map<crate::prelude::Text, bool>, x_p5: &crate::check::env::Def| crate::prelude::insert(m_p4, &x_p5.qk_p, &true)));
        let st_p3 = crate::prelude::fold(&crate::prelude::values(&g_p0.mods_p), st0_p1, &(|s0_p6: &crate::check::types::St, info_p7: &crate::check::env::ModInfo| if (&info_p7.file_p >= &g_p0.prelude_from_p) || (&info_p7.name_p == &crate::prelude::Text::lit("Prelude")) {
            s0_p6.clone()
        } else {
            {
                let s1_p8 = {
                    let mut this: crate::check::types::St = s0_p6.clone();
                    this.file_p = info_p7.file_p.clone();
                    this
                };
                crate::prelude::fold(&info_p7.tree_p.decls_p, &s1_p8, &(|s_p9: &crate::check::types::St, d_pa: &crate::syntax::decls::Decl| match &d_pa.kind_p {
                    crate::syntax::decls::DeclKind::DSignature(sg_pb) => if crate::check::env::has_key_f(&defined_p2, &crate::check::env::qual_key_f(&info_p7.name_p, &crate::check::env::def_name_text_f(&sg_pb.name_p))) {
                        s_p9.clone()
                    } else {
                        crate::check::types::recording::err_fix_f(s_p9, &crate::prelude::Text::lit("no-definition"), &d_pa.span_p, &crate::prelude::Text::from(format!("`{}` has a signature line and no definition", &crate::check::env::def_name_text_f(&sg_pb.name_p))), &crate::prelude::Text::from(format!("define it under its signature, `fn {} ... = ...`, or delete the line", &crate::check::env::def_name_text_f(&sg_pb.name_p))))
                    },
                    _ => s_p9.clone(),
                }))
            }
        }));
        ::prism_rtl::Turn::Finished({
            let mut this: crate::check::types::St = st_p3.clone();
            this.file_p = st0_p1.file_p.clone();
            this
        })
    }
}

/// `Start MissingDefinitions, x`: what the function value is when passed to `@Run`.
pub fn start_missing_definitions_f(g_p0: crate::check::env::G, st0_p1: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(MissingDefinitions { g_p0, st0_p1 })
}

/// ```prism
/// ImplDefaults: unbounded fn G, St -> ((G, St))
/// ```
pub fn impl_defaults_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> (crate::check::env::G, crate::check::types::St) {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(&g_p0.traits_p), (g_p0.clone(), st_p1.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::check::env::TraitInfo)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (g1_p2, st1_p3) = p0;
        let tr_p4 = p1;
        if &crate::prelude::len(&tr_p4.assoc_defaults_p) == &crate::prelude::Nat::from(0u32) {
            ::prism_rtl::Turn::Finished((g1_p2.clone(), st1_p3.clone()))
        } else {
            crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&g1_p2.impls_p, &tr_p4.name_p), &crate::prelude::Array::new()), (crate::prelude::Array::new(), crate::prelude::Array::new()), {
                let tr_p4x = tr_p4.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::env::ImplInfo>, crate::prelude::Array<crate::check::types::AssocImpl>), crate::check::env::ImplInfo)| {
                    let tr_p4xy = tr_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (done_p7, new_p8) = p0;
                        let im_p9 = p1;
                        crate::prelude::call_value(crate::prelude::fold_job(tr_p4xy.assoc_defaults_p.clone(), crate::prelude::Array::new(), {
                            let im_p9x = im_p9.clone();
                            let tr_p4xyx = tr_p4xy.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, (crate::prelude::Text, crate::check::types::Ty))| {
                                let im_p9xy = im_p9x.clone();
                                let tr_p4xyxy = tr_p4xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_pc = p0;
                                    let (assoc_pd, value_pe) = p1;
                                    if im_p9xy.derived_p || crate::prelude::fold(&im_p9xy.assocs_p, &false, &(|seen_pf: &bool, (chosen_pg, _): &(crate::prelude::Text, crate::check::types::Ty)| *seen_pf || (chosen_pg == &assoc_pd))) {
                                        ::prism_rtl::Turn::Finished(acc_pc.clone())
                                    } else {
                                        crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(crate::check::types::schemes::Inst { tys_p: crate::prelude::map_of(vec![(tr_p4xyxy.param_p.clone(), im_p9xy.head_p.clone())]), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() }, value_pe.clone()), move |subst_q_f_25816: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pc, &(assoc_pd.clone(), subst_q_f_25816))))
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>>>
                        }), move |fold_25605: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>| {
                            let taken_pa = fold_25605;
                            let filled_pb = {
                                let mut this: crate::check::env::ImplInfo = im_p9.clone();
                                this.assocs_p = crate::prelude::append(&this.assocs_p, &taken_pa);
                                this
                            };
                            ::prism_rtl::Turn::Finished((crate::prelude::push(&done_p7, &filled_pb), crate::prelude::append(&new_p8, &crate::prelude::each(&taken_pa, &(|(an_ph, at_pi): &(crate::prelude::Text, crate::check::types::Ty)| crate::check::types::AssocImpl { cls_p: im_p9.cls_p.clone(), name_p: an_ph.clone(), head_p: im_p9.head_p.clone(), qs_p: im_p9.qs_p.clone(), value_p: at_pi.clone() })))))
                        })
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::env::ImplInfo>, crate::prelude::Array<crate::check::types::AssocImpl>), crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::env::ImplInfo>, crate::prelude::Array<crate::check::types::AssocImpl>)>>>
            }), move |fold_25509: (crate::prelude::Array<crate::check::env::ImplInfo>, crate::prelude::Array<crate::check::types::AssocImpl>)| {
                let (impls_pj, added_pk) = fold_25509;
                let g2_p5 = {
                    let mut this: crate::check::env::G = g1_p2.clone();
                    this.impls_p = crate::prelude::insert(&this.impls_p, &tr_p4.name_p, &impls_pj);
                    this
                };
                let st2_p6 = {
                    let mut this: crate::check::types::St = st1_p3.clone();
                    this.assoc_impls_p = crate::prelude::append(&this.assoc_impls_p, &added_pk);
                    this
                };
                ::prism_rtl::Turn::Finished((g2_p5.clone(), st2_p6.clone()))
            })
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St), crate::check::env::TraitInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>))
}

/// The step machine of `ImplDefaults`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplDefaults: unbounded fn G, St -> ((G, St))
/// ```
pub struct ImplDefaults {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ImplDefaults {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        crate::prelude::fold_job(crate::prelude::values(&g_p0.traits_p), (g_p0.clone(), st_p1.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::check::env::TraitInfo)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (g1_p2, st1_p3) = p0;
            let tr_p4 = p1;
            if &crate::prelude::len(&tr_p4.assoc_defaults_p) == &crate::prelude::Nat::from(0u32) {
                ::prism_rtl::Turn::Finished((g1_p2.clone(), st1_p3.clone()))
            } else {
                crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&g1_p2.impls_p, &tr_p4.name_p), &crate::prelude::Array::new()), (crate::prelude::Array::new(), crate::prelude::Array::new()), {
                    let tr_p4x = tr_p4.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::env::ImplInfo>, crate::prelude::Array<crate::check::types::AssocImpl>), crate::check::env::ImplInfo)| {
                        let tr_p4xy = tr_p4x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (done_p7, new_p8) = p0;
                            let im_p9 = p1;
                            crate::prelude::call_value(crate::prelude::fold_job(tr_p4xy.assoc_defaults_p.clone(), crate::prelude::Array::new(), {
                                let im_p9x = im_p9.clone();
                                let tr_p4xyx = tr_p4xy.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, (crate::prelude::Text, crate::check::types::Ty))| {
                                    let im_p9xy = im_p9x.clone();
                                    let tr_p4xyxy = tr_p4xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let acc_pc = p0;
                                        let (assoc_pd, value_pe) = p1;
                                        if im_p9xy.derived_p || crate::prelude::fold(&im_p9xy.assocs_p, &false, &(|seen_pf: &bool, (chosen_pg, _): &(crate::prelude::Text, crate::check::types::Ty)| *seen_pf || (chosen_pg == &assoc_pd))) {
                                            ::prism_rtl::Turn::Finished(acc_pc.clone())
                                        } else {
                                            crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(crate::check::types::schemes::Inst { tys_p: crate::prelude::map_of(vec![(tr_p4xyxy.param_p.clone(), im_p9xy.head_p.clone())]), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() }, value_pe.clone()), move |subst_q_f_25816: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pc, &(assoc_pd.clone(), subst_q_f_25816))))
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>>>
                            }), move |fold_25605: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>| {
                                let taken_pa = fold_25605;
                                let filled_pb = {
                                    let mut this: crate::check::env::ImplInfo = im_p9.clone();
                                    this.assocs_p = crate::prelude::append(&this.assocs_p, &taken_pa);
                                    this
                                };
                                ::prism_rtl::Turn::Finished((crate::prelude::push(&done_p7, &filled_pb), crate::prelude::append(&new_p8, &crate::prelude::each(&taken_pa, &(|(an_ph, at_pi): &(crate::prelude::Text, crate::check::types::Ty)| crate::check::types::AssocImpl { cls_p: im_p9.cls_p.clone(), name_p: an_ph.clone(), head_p: im_p9.head_p.clone(), qs_p: im_p9.qs_p.clone(), value_p: at_pi.clone() })))))
                            })
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::env::ImplInfo>, crate::prelude::Array<crate::check::types::AssocImpl>), crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::env::ImplInfo>, crate::prelude::Array<crate::check::types::AssocImpl>)>>>
                }), move |fold_25509: (crate::prelude::Array<crate::check::env::ImplInfo>, crate::prelude::Array<crate::check::types::AssocImpl>)| {
                    let (impls_pj, added_pk) = fold_25509;
                    let g2_p5 = {
                        let mut this: crate::check::env::G = g1_p2.clone();
                        this.impls_p = crate::prelude::insert(&this.impls_p, &tr_p4.name_p, &impls_pj);
                        this
                    };
                    let st2_p6 = {
                        let mut this: crate::check::types::St = st1_p3.clone();
                        this.assoc_impls_p = crate::prelude::append(&this.assoc_impls_p, &added_pk);
                        this
                    };
                    ::prism_rtl::Turn::Finished((g2_p5.clone(), st2_p6.clone()))
                })
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St), crate::check::env::TraitInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>).cycle()
    }
}

/// `Start ImplDefaults, x`: what the function value is when passed to `@Run`.
pub fn start_impl_defaults_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    ::std::rc::Rc::new(ImplDefaults { g_p0, st_p1 })
}

/// ```prism
/// ImplsComplete: unbounded fn G, St -> St
/// ```
pub fn impls_complete_f(g_p0: &crate::check::env::G, st0_p1: &crate::check::types::St) -> crate::check::types::St {
    let st_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(&g_p0.traits_p), st0_p1.clone(), {
        let g_p0x = g_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::TraitInfo)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s0_p3 = p0;
                let tr_p4 = p1;
                crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&g_p0xy.impls_p, &tr_p4.name_p), &crate::prelude::Array::new()), s0_p3.clone(), {
                    let g_p0xyx = g_p0xy.clone();
                    let tr_p4x = tr_p4.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::ImplInfo)| {
                        let g_p0xyxy = g_p0xyx.clone();
                        let tr_p4xy = tr_p4x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let s1_p5 = p0;
                            let im_p6 = p1;
                            if (im_p6.derived_p || (&im_p6.file_p >= &g_p0xyxy.prelude_from_p)) || (&im_p6.home_p == &crate::prelude::Text::lit("Prelude")) {
                                ::prism_rtl::Turn::Finished(s1_p5.clone())
                            } else {
                                {
                                    let shown_p7 = crate::check::types::bare_name_f(&tr_p4xy.name_p);
                                    let s2_p8 = {
                                        let mut this: crate::check::types::St = s1_p5.clone();
                                        this.file_p = im_p6.file_p.clone();
                                        this
                                    };
                                    let s3_p9 = crate::prelude::fold(&tr_p4xy.methods_p, &s2_p8, &(|s_pc: &crate::check::types::St, method_pd: &crate::prelude::Text| {
                                        let defined_pe = crate::prelude::fold(&im_p6.methods_p, &false, &(|seen_pf: &bool, m_pg: &crate::prelude::Text| (*seen_pf || (&crate::check::types::bare_name_f(method_pd) == m_pg)) || (&crate::syntax::lexer::chars::drop_prefix_f(method_pd, &crate::prelude::Text::from(format!("{}.", &tr_p4xy.home_p))) == m_pg)));
                                        if defined_pe || crate::check::types::has_text_f(&tr_p4xy.defaults_p, method_pd) {
                                            s_pc.clone()
                                        } else {
                                            crate::check::types::recording::err_fix_f(s_pc, &crate::prelude::Text::lit("impl-lacks"), &im_p6.span_p, &crate::prelude::Text::from(format!("this impl of `^{}` lacks `{}`, which has no default body", &shown_p7, &crate::check::types::bare_name_f(method_pd))), &crate::prelude::Text::from(format!("define it under the impl, `fn {} ...`", &crate::check::types::bare_name_f(method_pd))))
                                        }
                                    }));
                                    let s4_pa = crate::prelude::fold(&tr_p4xy.assocs_p, &s3_p9, &(|s_ph: &crate::check::types::St, assoc_pi: &crate::prelude::Text| if crate::prelude::fold(&im_p6.assocs_p, &false, &(|seen_pj: &bool, (chosen_pk, _): &(crate::prelude::Text, crate::check::types::Ty)| *seen_pj || (chosen_pk == assoc_pi))) {
                                        s_ph.clone()
                                    } else {
                                        crate::check::types::recording::err_fix_f(s_ph, &crate::prelude::Text::lit("impl-lacks"), &im_p6.span_p, &crate::prelude::Text::from(format!("this impl of `^{}` lacks `type {}`", &shown_p7, assoc_pi)), &crate::prelude::Text::from(format!("choose it under the impl, `type {} = ...`", assoc_pi)))
                                    }));
                                    let s5_pb = crate::prelude::fold(&im_p6.assocs_p, &s4_pa, &(|s_pl: &crate::check::types::St, (chosen_pm, _): &(crate::prelude::Text, crate::check::types::Ty)| if crate::check::types::has_text_f(&tr_p4xy.assocs_p, chosen_pm) {
                                        s_pl.clone()
                                    } else {
                                        crate::check::types::recording::err_f(s_pl, &crate::prelude::Text::lit("mismatch"), &im_p6.span_p, &crate::prelude::Text::from(format!("`^{}` has no associated type `{}`", &shown_p7, chosen_pm)))
                                    }));
                                    crate::prelude::fold_job(tr_p4xy.supers_p.clone(), s5_pb.clone(), {
                                        let g_p0xyxyx = g_p0xyxy.clone();
                                        let im_p6x = im_p6.clone();
                                        let shown_p7x = shown_p7.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
                                            let g_p0xyxyxy = g_p0xyxyx.clone();
                                            let im_p6xy = im_p6x.clone();
                                            let shown_p7xy = shown_p7x.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let s_pn = p0;
                                                let above_po = p1;
                                                ::prism_rtl::Turn::More(::std::rc::Rc::new(ImplHasAbove { g_p0: g_p0xyxyxy.clone(), st_p1: s_pn.clone(), im_p2: im_p6xy.clone(), shown_p3: shown_p7xy.clone(), above_p4: above_po.clone() }))
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                                    }).cycle()
                                }
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                }).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::env::TraitInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }));
    let mut this: crate::check::types::St = st_p2.clone();
    this.file_p = st0_p1.file_p.clone();
    this
}

/// The step machine of `ImplsComplete`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplsComplete: unbounded fn G, St -> St
/// ```
pub struct ImplsComplete {
    pub g_p0: crate::check::env::G,
    pub st0_p1: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::types::St> for ImplsComplete {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st0_p1 = &self.st0_p1;
        let g_p0x = g_p0.clone();
        let st0_p1x = st0_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(&g_p0x.traits_p), st0_p1x.clone(), {
            let g_p0xx = g_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::TraitInfo)| {
                let g_p0xxy = g_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s0_p3 = p0;
                    let tr_p4 = p1;
                    crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&g_p0xxy.impls_p, &tr_p4.name_p), &crate::prelude::Array::new()), s0_p3.clone(), {
                        let g_p0xxyx = g_p0xxy.clone();
                        let tr_p4x = tr_p4.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::ImplInfo)| {
                            let g_p0xxyxy = g_p0xxyx.clone();
                            let tr_p4xy = tr_p4x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let s1_p5 = p0;
                                let im_p6 = p1;
                                if (im_p6.derived_p || (&im_p6.file_p >= &g_p0xxyxy.prelude_from_p)) || (&im_p6.home_p == &crate::prelude::Text::lit("Prelude")) {
                                    ::prism_rtl::Turn::Finished(s1_p5.clone())
                                } else {
                                    {
                                        let shown_p7 = crate::check::types::bare_name_f(&tr_p4xy.name_p);
                                        let s2_p8 = {
                                            let mut this: crate::check::types::St = s1_p5.clone();
                                            this.file_p = im_p6.file_p.clone();
                                            this
                                        };
                                        let s3_p9 = crate::prelude::fold(&tr_p4xy.methods_p, &s2_p8, &(|s_pc: &crate::check::types::St, method_pd: &crate::prelude::Text| {
                                            let defined_pe = crate::prelude::fold(&im_p6.methods_p, &false, &(|seen_pf: &bool, m_pg: &crate::prelude::Text| (*seen_pf || (&crate::check::types::bare_name_f(method_pd) == m_pg)) || (&crate::syntax::lexer::chars::drop_prefix_f(method_pd, &crate::prelude::Text::from(format!("{}.", &tr_p4xy.home_p))) == m_pg)));
                                            if defined_pe || crate::check::types::has_text_f(&tr_p4xy.defaults_p, method_pd) {
                                                s_pc.clone()
                                            } else {
                                                crate::check::types::recording::err_fix_f(s_pc, &crate::prelude::Text::lit("impl-lacks"), &im_p6.span_p, &crate::prelude::Text::from(format!("this impl of `^{}` lacks `{}`, which has no default body", &shown_p7, &crate::check::types::bare_name_f(method_pd))), &crate::prelude::Text::from(format!("define it under the impl, `fn {} ...`", &crate::check::types::bare_name_f(method_pd))))
                                            }
                                        }));
                                        let s4_pa = crate::prelude::fold(&tr_p4xy.assocs_p, &s3_p9, &(|s_ph: &crate::check::types::St, assoc_pi: &crate::prelude::Text| if crate::prelude::fold(&im_p6.assocs_p, &false, &(|seen_pj: &bool, (chosen_pk, _): &(crate::prelude::Text, crate::check::types::Ty)| *seen_pj || (chosen_pk == assoc_pi))) {
                                            s_ph.clone()
                                        } else {
                                            crate::check::types::recording::err_fix_f(s_ph, &crate::prelude::Text::lit("impl-lacks"), &im_p6.span_p, &crate::prelude::Text::from(format!("this impl of `^{}` lacks `type {}`", &shown_p7, assoc_pi)), &crate::prelude::Text::from(format!("choose it under the impl, `type {} = ...`", assoc_pi)))
                                        }));
                                        let s5_pb = crate::prelude::fold(&im_p6.assocs_p, &s4_pa, &(|s_pl: &crate::check::types::St, (chosen_pm, _): &(crate::prelude::Text, crate::check::types::Ty)| if crate::check::types::has_text_f(&tr_p4xy.assocs_p, chosen_pm) {
                                            s_pl.clone()
                                        } else {
                                            crate::check::types::recording::err_f(s_pl, &crate::prelude::Text::lit("mismatch"), &im_p6.span_p, &crate::prelude::Text::from(format!("`^{}` has no associated type `{}`", &shown_p7, chosen_pm)))
                                        }));
                                        crate::prelude::fold_job(tr_p4xy.supers_p.clone(), s5_pb.clone(), {
                                            let g_p0xxyxyx = g_p0xxyxy.clone();
                                            let im_p6x = im_p6.clone();
                                            let shown_p7x = shown_p7.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
                                                let g_p0xxyxyxy = g_p0xxyxyx.clone();
                                                let im_p6xy = im_p6x.clone();
                                                let shown_p7xy = shown_p7x.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let s_pn = p0;
                                                    let above_po = p1;
                                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ImplHasAbove { g_p0: g_p0xxyxyxy.clone(), st_p1: s_pn.clone(), im_p2: im_p6xy.clone(), shown_p3: shown_p7xy.clone(), above_p4: above_po.clone() }))
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                                        }).cycle()
                                    }
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                    }).cycle()
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::env::TraitInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }), move |fold_26883: crate::check::types::St| {
            let st_p2 = fold_26883;
            ::prism_rtl::Turn::Finished({
                let mut this: crate::check::types::St = st_p2.clone();
                this.file_p = st0_p1x.file_p.clone();
                this
            })
        })
    }
}

/// `Start ImplsComplete, x`: what the function value is when passed to `@Run`.
pub fn start_impls_complete_f(g_p0: crate::check::env::G, st0_p1: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(ImplsComplete { g_p0, st0_p1 })
}

/// ```prism
/// ImplHasAbove: unbounded fn G, St, ImplInfo, Text, Text -> St
/// ```
pub fn impl_has_above_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, im_p2: &crate::check::env::ImplInfo, shown_p3: &crate::prelude::Text, above_p4: &crate::prelude::Text) -> crate::check::types::St {
    if &im_p2.head_p == &crate::check::types::Ty::TyErr {
        st_p1.clone()
    } else {
        {
            let head_p5 = crate::check::types::schemes::subst_q_f(&crate::check::env::reading::param_inst_f(&im_p2.qs_p, &crate::prelude::each(&im_p2.qs_p, &(|q_p8: &crate::prelude::Text| crate::check::types::Ty::TyRigid(q_p8.clone())))), &im_p2.head_p);
            let trial_p6 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.diags_p = crate::prelude::Array::new();
                this.wants_p = crate::prelude::Array::from(vec![crate::check::types::Want { cls_p: above_p4.clone(), ty_p: head_p5.clone(), file_p: im_p2.file_p.clone(), span_p: im_p2.span_p.clone(), level_p: crate::prelude::Nat::from(0u32) }]);
                this
            };
            let out_p7 = crate::check::env::traits::solve_wants_f(g_p0, &trial_p6, &im_p2.bounds_p, &false);
            if (&crate::prelude::len(&out_p7.diags_p) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&out_p7.wants_p) == &crate::prelude::Nat::from(0u32)) {
                st_p1.clone()
            } else {
                crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("no-impl"), &im_p2.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`, which `^{}` asks of its types", &crate::check::types::bare_name_f(above_p4), &crate::check::types::show_ty_f(st_p1, &im_p2.head_p), shown_p3)), &crate::prelude::Text::from(format!("add `impl ^{} {}`", &crate::check::types::bare_name_f(above_p4), &crate::check::types::show_ty_in_f(st_p1, &im_p2.head_p, &true))))
            }
        }
    }
}

/// The step machine of `ImplHasAbove`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplHasAbove: unbounded fn G, St, ImplInfo, Text, Text -> St
/// ```
pub struct ImplHasAbove {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub im_p2: crate::check::env::ImplInfo,
    pub shown_p3: crate::prelude::Text,
    pub above_p4: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::check::types::St> for ImplHasAbove {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let im_p2 = &self.im_p2;
        let shown_p3 = &self.shown_p3;
        let above_p4 = &self.above_p4;
        if &im_p2.head_p == &crate::check::types::Ty::TyErr {
            ::prism_rtl::Turn::Finished(st_p1.clone())
        } else {
            {
                let above_p4x = above_p4.clone();
                let g_p0x = g_p0.clone();
                let im_p2x = im_p2.clone();
                let shown_p3x = shown_p3.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(crate::check::env::reading::param_inst_f(&im_p2x.qs_p, &crate::prelude::each(&im_p2x.qs_p, &(|q_p8: &crate::prelude::Text| crate::check::types::Ty::TyRigid(q_p8.clone())))), im_p2x.head_p.clone()), move |subst_q_f_28594: crate::check::types::Ty| {
                    let head_p5 = subst_q_f_28594;
                    let trial_p6 = {
                        let mut this: crate::check::types::St = st_p1x.clone();
                        this.diags_p = crate::prelude::Array::new();
                        this.wants_p = crate::prelude::Array::from(vec![crate::check::types::Want { cls_p: above_p4x.clone(), ty_p: head_p5.clone(), file_p: im_p2x.file_p.clone(), span_p: im_p2x.span_p.clone(), level_p: crate::prelude::Nat::from(0u32) }]);
                        this
                    };
                    crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(g_p0x.clone(), trial_p6.clone(), im_p2x.bounds_p.clone(), false), move |solve_wants_f_28810: crate::check::types::St| {
                        let out_p7 = solve_wants_f_28810;
                        if (&crate::prelude::len(&out_p7.diags_p) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&out_p7.wants_p) == &crate::prelude::Nat::from(0u32)) {
                            ::prism_rtl::Turn::Finished(st_p1x.clone())
                        } else {
                            crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), im_p2x.head_p.clone()), move |show_ty_f_28984: crate::prelude::Text| crate::prelude::call_then(crate::check::types::start_show_ty_in_f(st_p1x.clone(), im_p2x.head_p.clone(), true), move |show_ty_in_f_29073: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("no-impl"), &im_p2x.span_p, &crate::prelude::Text::from(format!("no impl of `^{}` for `{}`, which `^{}` asks of its types", &crate::check::types::bare_name_f(&above_p4x), &show_ty_f_28984, &shown_p3x)), &crate::prelude::Text::from(format!("add `impl ^{} {}`", &crate::check::types::bare_name_f(&above_p4x), &show_ty_in_f_29073))))))
                        }
                    })
                })
            }
        }
    }
}

/// `Start ImplHasAbove, x`: what the function value is when passed to `@Run`.
pub fn start_impl_has_above_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, im_p2: crate::check::env::ImplInfo, shown_p3: crate::prelude::Text, above_p4: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(ImplHasAbove { g_p0, st_p1, im_p2, shown_p3, above_p4 })
}

/// ```prism
/// BoundsNamed: fn St, [Bound], [Text], Text, Text -> St
/// ```
pub fn bounds_named_f(st_p0: &crate::check::types::St, bounds_p1: &crate::prelude::Array<crate::syntax::decls::Bound>, known_p2: &crate::prelude::Array<crate::prelude::Text>, place_p3: &crate::prelude::Text, short_p4: &crate::prelude::Text) -> crate::check::types::St {
    crate::prelude::fold(bounds_p1, st_p0, &(|s_p5: &crate::check::types::St, b_p6: &crate::syntax::decls::Bound| if crate::check::types::has_text_f(known_p2, &b_p6.var_p.name_p) {
        s_p5.clone()
    } else {
        crate::check::types::recording::err_fix_f(s_p5, &crate::prelude::Text::lit("ambiguous"), &b_p6.span_p, &crate::prelude::Text::from(format!("nothing decides `{}` in `^{} {}`: {} names no `{}`", &b_p6.var_p.name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&b_p6.traits_p, &(|tr_p7: &crate::syntax::TraitRef| crate::check::env::dotted_f(&tr_p7.path_p))), &crate::prelude::Text::lit(", ^")), &b_p6.var_p.name_p, place_p3, &b_p6.var_p.name_p)), &crate::prelude::Text::from(format!("bound a variable of {}, or drop the bound", short_p4)))
    }))
}

/// ```prism
/// AddDefaultClause: fn Def, Text, Text, FnClause -> Def
/// ```
pub fn add_default_clause_f(d_p0: &crate::check::env::Def, qk_p1: &crate::prelude::Text, cls_p2: &crate::prelude::Text, f_p3: &crate::syntax::decls::FnClause) -> crate::check::env::Def {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbDefault(cs_p4, c_p5) if ((&d_p0.qk_p == qk_p1) && (c_p5 == cls_p2)) => {
            let mut this: crate::check::env::Def = d_p0.clone();
            this.body_p = crate::check::env::DefBody::DbDefault(crate::prelude::push(cs_p4, f_p3), c_p5.clone());
            this
        },
        _ => d_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
/// ```
pub fn conv_tag_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, t_p3: &crate::syntax::decls::TagDecl, span_p4: &crate::syntax::Range) -> (crate::check::env::G, crate::check::types::St) {
    let name_p5 = crate::check::env::dotted_f(&t_p3.name_p.path_p);
    let family_p6 = crate::check::env::dotted_f(&crate::prelude::take(&t_p3.name_p.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&t_p3.name_p.path_p))));
    let cx_p7 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
    let (kind_pg, out_ph, st2_pi) = tag_kind_f(g_p0, &cx_p7, st_p1, &t_p3.of_type_p);
    let (fields_pq, st3_pr) = crate::prelude::run_to_end(crate::prelude::fold_job(t_p3.fields_p.clone(), (crate::prelude::Array::new(), st2_pi.clone()), {
        let cx_p7x = cx_p7.clone();
        let g_p0x = g_p0.clone();
        let info_p2x = info_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)| {
            let cx_p7xy = cx_p7x.clone();
            let g_p0xy = g_p0x.clone();
            let info_p2xy = info_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pj, s_pk) = p0;
                let f_pl = p1;
                crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p7xy.clone(), sigils_on_name_f(&second_field_f(&s_pk, &acc_pj, &f_pl), &crate::prelude::or(&crate::prelude::index(&g_p0xy.srcs_p, &info_p2xy.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit("?"), &crate::prelude::Text::lit(""))), &f_pl), f_pl.ty_p.clone()), move |conv_type_f_30506: (crate::check::types::Ty, crate::check::types::St)| {
                    let (ft_pm, s2_pn) = conv_type_f_30506;
                    let acc_pjz = acc_pj.clone();
                    let f_plz = f_pl.clone();
                    let ft_pmz = ft_pm.clone();
                    let k_let30616 = move |v30616: (crate::check::types::Rw, crate::check::types::St)| {
                        let (field_row_po, s3_pp) = v30616;
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pjz, &(f_plz.name_p.name_p.clone(), field_sigils_f(&f_plz.sigils_p, &ft_pmz, &field_row_po))), s3_pp.clone()))
                    };
                    if crate::syntax::lexer::chars::contains_f(&f_pl.sigils_p, &crate::prelude::Text::lit("@")) {
                        crate::prelude::call_then(start_field_row_f(cx_p7xy.clone(), s2_pn.clone(), f_pl.ty_p.clone()), move |field_row_f_30666: (crate::check::types::Rw, crate::check::types::St)| k_let30616(field_row_f_30666))
                    } else {
                        k_let30616((cx_p7xy.scope_p.clone(), s2_pn.clone()))
                    }
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St)>>>
    }));
    let qs_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(t_p3.fields_p.clone(), crate::check::env::reading::type_vars_of_type_f(&t_p3.of_type_p), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::Field)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_ps = p0;
        let f_pt = p1;
        crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(f_pt.ty_p.clone()), move |type_vars_of_type_f_30875: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_ps, &type_vars_of_type_f_30875)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::Field)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
    let (bs_pu, st4a_pv) = crate::check::env::reading::conv_bounds_f(&cx_p7, &st3_pr, &t_p3.bounds_p);
    let st4b_p9 = if crate::check::env::has_key_f(&g_p0.tags_p, &name_p5) {
        crate::check::types::recording::err_f(&st4a_pv, &crate::prelude::Text::lit("collision"), span_p4, &crate::prelude::Text::from(format!("a second tag `{}`", &name_p5)))
    } else {
        st4a_pv.clone()
    };
    let st4_pa = st4b_p9.clone();
    let indexed_pb = crate::check::env::reading::type_vars_of_type_f(&t_p3.of_type_p);
    let out_text_pc = 'm31495: {
        let scrutinee = &*t_p3.of_type_p.kind_p;
        if let crate::syntax::TypeKind::TName(_, m31495_0_1) = scrutinee && (m31495_0_1.len() == 1) && let ::std::option::Option::Some(o_p10) = crate::prelude::index(m31495_0_1, &crate::prelude::Nat::from(0u32)) {
            break 'm31495 crate::check::errors::span_text_f(&crate::prelude::or(&crate::prelude::index(&g_p0.srcs_p, &info_p2.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit("?"), &crate::prelude::Text::lit(""))), &o_p10.span_p);
        }
        crate::prelude::Text::lit("unit")
    };
    let st5_pd = crate::prelude::run_to_end(crate::prelude::fold_job(t_p3.fields_p.clone(), st4_pa.clone(), {
        let indexed_pbx = indexed_pb.clone();
        let name_p5x = name_p5.clone();
        let out_text_pcx = out_text_pc.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::Field)| {
            let indexed_pbxy = indexed_pbx.clone();
            let name_p5xy = name_p5x.clone();
            let out_text_pcxy = out_text_pcx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p11 = p0;
                let f_p12 = p1;
                crate::prelude::call_then(crate::check::env::reading::start_type_var_places_f(crate::prelude::Array::new(), f_p12.ty_p.clone()), move |type_var_places_f_31676: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&type_var_places_f_31676, &s_p11, &(|s2_p13: &crate::check::types::St, (v_p14, at_p15): &(crate::prelude::Text, crate::syntax::Range)| if crate::check::types::has_text_f(&indexed_pbxy, v_p14) {
                    s2_p13.clone()
                } else {
                    crate::check::types::recording::err_fix_f(s2_p13, &crate::prelude::Text::lit("field-variable"), at_p15, &crate::prelude::Text::from(format!("the type variable `{}` in the field `{}` of `{}` does not appear in the tag\'s output, `{}`", v_p14, &f_p12.name_p.name_p, &name_p5xy, &out_text_pcxy)), &crate::prelude::Text::from(format!("put `{}` in the output, or give the field a type without it", v_p14)))
                }))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::decls::Field)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }));
    let tg_pe = crate::check::env::TagInfo { name_p: name_p5.clone(), family_p: family_p6.clone(), kind_p: kind_pg.clone(), out_p: out_ph.clone(), qs_p: qs_p8.clone(), rqs_p: if &info_p2.row_var_p == &crate::prelude::Text::lit("") {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![info_p2.row_var_p.clone()])
    }, bounds_p: bs_pu.clone(), fields_p: fields_pq.clone(), field_at_p: crate::prelude::each(&t_p3.fields_p, &(|f_p16: &crate::syntax::decls::Field| (crate::prelude::Text::from(format!("{}{}", &f_p16.sigils_p, &f_p16.name_p.name_p)), f_p16.span_p.clone()))), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: span_p4.clone() };
    let upd_pf = {
        let mut this: crate::check::env::G = g_p0.clone();
        if !crate::check::env::has_key_f(&this.tags_p, &name_p5) {
            this.tags_p = crate::prelude::insert(&this.tags_p, &name_p5, &tg_pe);
        }
        this
    };
    (upd_pf.clone(), st5_pd.clone())
}

/// The step machine of `ConvTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
/// ```
pub struct ConvTag {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
    pub t_p3: crate::syntax::decls::TagDecl,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvTag {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        let t_p3 = &self.t_p3;
        let span_p4 = &self.span_p4;
        let name_p5 = crate::check::env::dotted_f(&t_p3.name_p.path_p);
        let family_p6 = crate::check::env::dotted_f(&crate::prelude::take(&t_p3.name_p.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&t_p3.name_p.path_p))));
        let cx_p7 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
        let g_p0x = g_p0.clone();
        let info_p2x = info_p2.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        let t_p3x = t_p3.clone();
        crate::prelude::call_then(start_tag_kind_f(g_p0x.clone(), cx_p7.clone(), st_p1x.clone(), t_p3x.of_type_p.clone()), move |tag_kind_f_30380: (crate::prelude::Text, crate::check::types::Ty, crate::check::types::St)| {
            let (kind_pg, out_ph, st2_pi) = tag_kind_f_30380;
            crate::prelude::call_value(crate::prelude::fold_job(t_p3x.fields_p.clone(), (crate::prelude::Array::new(), st2_pi.clone()), {
                let cx_p7x = cx_p7.clone();
                let g_p0xx = g_p0x.clone();
                let info_p2xx = info_p2x.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)| {
                    let cx_p7xy = cx_p7x.clone();
                    let g_p0xxy = g_p0xx.clone();
                    let info_p2xxy = info_p2xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (acc_pj, s_pk) = p0;
                        let f_pl = p1;
                        crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p7xy.clone(), sigils_on_name_f(&second_field_f(&s_pk, &acc_pj, &f_pl), &crate::prelude::or(&crate::prelude::index(&g_p0xxy.srcs_p, &info_p2xxy.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit("?"), &crate::prelude::Text::lit(""))), &f_pl), f_pl.ty_p.clone()), move |conv_type_f_30506: (crate::check::types::Ty, crate::check::types::St)| {
                            let (ft_pm, s2_pn) = conv_type_f_30506;
                            let acc_pjz = acc_pj.clone();
                            let f_plz = f_pl.clone();
                            let ft_pmz = ft_pm.clone();
                            let k_let30616 = move |v30616: (crate::check::types::Rw, crate::check::types::St)| {
                                let (field_row_po, s3_pp) = v30616;
                                ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pjz, &(f_plz.name_p.name_p.clone(), field_sigils_f(&f_plz.sigils_p, &ft_pmz, &field_row_po))), s3_pp.clone()))
                            };
                            if crate::syntax::lexer::chars::contains_f(&f_pl.sigils_p, &crate::prelude::Text::lit("@")) {
                                crate::prelude::call_then(start_field_row_f(cx_p7xy.clone(), s2_pn.clone(), f_pl.ty_p.clone()), move |field_row_f_30666: (crate::check::types::Rw, crate::check::types::St)| k_let30616(field_row_f_30666))
                            } else {
                                k_let30616((cx_p7xy.scope_p.clone(), s2_pn.clone()))
                            }
                        })
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St)>>>
            }), move |fold_30434: (crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St)| {
                let (fields_pq, st3_pr) = fold_30434;
                crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(t_p3x.of_type_p.clone()), move |type_vars_of_type_f_30822: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_value(crate::prelude::fold_job(t_p3x.fields_p.clone(), type_vars_of_type_f_30822, ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::Field)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_ps = p0;
                    let f_pt = p1;
                    crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(f_pt.ty_p.clone()), move |type_vars_of_type_f_30875: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_ps, &type_vars_of_type_f_30875)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::Field)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_30806: crate::prelude::Array<crate::prelude::Text>| {
                    let qs_p8 = fold_30806;
                    let (bs_pu, st4a_pv) = crate::check::env::reading::conv_bounds_f(&cx_p7, &st3_pr, &t_p3x.bounds_p);
                    let st4b_p9 = if crate::check::env::has_key_f(&g_p0x.tags_p, &name_p5) {
                        crate::check::types::recording::err_f(&st4a_pv, &crate::prelude::Text::lit("collision"), &span_p4x, &crate::prelude::Text::from(format!("a second tag `{}`", &name_p5)))
                    } else {
                        st4a_pv.clone()
                    };
                    let st4_pa = st4b_p9.clone();
                    crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(t_p3x.of_type_p.clone()), move |type_vars_of_type_f_31453: crate::prelude::Array<crate::prelude::Text>| {
                        let indexed_pb = type_vars_of_type_f_31453;
                        let out_text_pc = 'm31495: {
                            let scrutinee = &*t_p3x.of_type_p.kind_p;
                            if let crate::syntax::TypeKind::TName(_, m31495_0_1) = scrutinee && (m31495_0_1.len() == 1) && let ::std::option::Option::Some(o_p10) = crate::prelude::index(m31495_0_1, &crate::prelude::Nat::from(0u32)) {
                                break 'm31495 crate::check::errors::span_text_f(&crate::prelude::or(&crate::prelude::index(&g_p0x.srcs_p, &info_p2x.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit("?"), &crate::prelude::Text::lit(""))), &o_p10.span_p);
                            }
                            crate::prelude::Text::lit("unit")
                        };
                        crate::prelude::call_value(crate::prelude::fold_job(t_p3x.fields_p.clone(), st4_pa.clone(), {
                            let indexed_pbx = indexed_pb.clone();
                            let name_p5x = name_p5.clone();
                            let out_text_pcx = out_text_pc.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::Field)| {
                                let indexed_pbxy = indexed_pbx.clone();
                                let name_p5xy = name_p5x.clone();
                                let out_text_pcxy = out_text_pcx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s_p11 = p0;
                                    let f_p12 = p1;
                                    crate::prelude::call_then(crate::check::env::reading::start_type_var_places_f(crate::prelude::Array::new(), f_p12.ty_p.clone()), move |type_var_places_f_31676: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&type_var_places_f_31676, &s_p11, &(|s2_p13: &crate::check::types::St, (v_p14, at_p15): &(crate::prelude::Text, crate::syntax::Range)| if crate::check::types::has_text_f(&indexed_pbxy, v_p14) {
                                        s2_p13.clone()
                                    } else {
                                        crate::check::types::recording::err_fix_f(s2_p13, &crate::prelude::Text::lit("field-variable"), at_p15, &crate::prelude::Text::from(format!("the type variable `{}` in the field `{}` of `{}` does not appear in the tag\'s output, `{}`", v_p14, &f_p12.name_p.name_p, &name_p5xy, &out_text_pcxy)), &crate::prelude::Text::from(format!("put `{}` in the output, or give the field a type without it", v_p14)))
                                    }))))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::decls::Field)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                        }), move |fold_31642: crate::check::types::St| {
                            let st5_pd = fold_31642;
                            let tg_pe = crate::check::env::TagInfo { name_p: name_p5.clone(), family_p: family_p6.clone(), kind_p: kind_pg.clone(), out_p: out_ph.clone(), qs_p: qs_p8.clone(), rqs_p: if &info_p2x.row_var_p == &crate::prelude::Text::lit("") {
                                crate::prelude::Array::new()
                            } else {
                                crate::prelude::Array::from(vec![info_p2x.row_var_p.clone()])
                            }, bounds_p: bs_pu.clone(), fields_p: fields_pq.clone(), field_at_p: crate::prelude::each(&t_p3x.fields_p, &(|f_p16: &crate::syntax::decls::Field| (crate::prelude::Text::from(format!("{}{}", &f_p16.sigils_p, &f_p16.name_p.name_p)), f_p16.span_p.clone()))), home_p: info_p2x.name_p.clone(), file_p: info_p2x.file_p.clone(), span_p: span_p4x.clone() };
                            let upd_pf = {
                                let mut this: crate::check::env::G = g_p0x.clone();
                                if !crate::check::env::has_key_f(&this.tags_p, &name_p5) {
                                    this.tags_p = crate::prelude::insert(&this.tags_p, &name_p5, &tg_pe);
                                }
                                this
                            };
                            ::prism_rtl::Turn::Finished((upd_pf.clone(), st5_pd.clone()))
                        })
                    })
                }))
            })
        })
    }
}

/// `Start ConvTag, x`: what the function value is when passed to `@Run`.
pub fn start_conv_tag_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo, t_p3: crate::syntax::decls::TagDecl, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvTag { g_p0, st_p1, info_p2, t_p3, span_p4 })
}

/// ```prism
/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
/// ```
pub fn tag_kind_f(g_p0: &crate::check::env::G, cx_p1: &crate::check::env::reading::Cx, st_p2: &crate::check::types::St, t_p3: &crate::syntax::Type) -> (crate::prelude::Text, crate::check::types::Ty, crate::check::types::St) {
    match &*t_p3.kind_p {
        crate::syntax::TypeKind::TName(n_p4, args_p5) => {
            let name_p6 = crate::check::env::dotted_f(&n_p4.path_p);
            if &name_p6 == &crate::prelude::Text::lit("Element") {
                match crate::prelude::index(args_p5, &crate::prelude::Nat::from(0u32)) {
                    ::std::option::Option::Some(o_p7) => {
                        let (ot_p8, s2_p9) = crate::check::env::reading::conv_type_f(cx_p1, st_p2, &o_p7);
                        (crate::prelude::Text::lit("Element"), ot_p8.clone(), s2_p9.clone())
                    },
                    ::std::option::Option::None => (crate::prelude::Text::lit("Element"), crate::check::types::t_unit_p(), st_p2.clone()),
                }
            } else {
                {
                    let (key_oa, _) = crate::check::env::names::resolve_type_f(g_p0, &cx_p1.home_p, &n_p4.path_p);
                    match &key_oa {
                        ::std::option::Option::Some(k_pb) => match &crate::prelude::or(&crate::prelude::get(&g_p0.types_p, k_pb), &crate::check::env::names::dummy_ty_info_p()).body_p {
                            crate::check::env::TyBody::BRowKind => (k_pb.clone(), crate::check::types::t_unit_p(), st_p2.clone()),
                            _ => (k_pb.clone(), crate::check::types::t_unit_p(), crate::check::types::recording::err_f(st_p2, &crate::prelude::Text::lit("kind"), &t_p3.span_p, &crate::prelude::Text::from(format!("`{}` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`", &name_p6)))),
                        },
                        ::std::option::Option::None => (crate::prelude::Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p2, &crate::prelude::Text::lit("unknown-name"), &t_p3.span_p, &crate::prelude::Text::from(format!("no row kind `{}`", &name_p6)))),
                    }
                }
            }
        },
        crate::syntax::TypeKind::TGroup(x_pc) => tag_kind_f(g_p0, cx_p1, st_p2, &**x_pc),
        _ => (crate::prelude::Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p2, &crate::prelude::Text::lit("kind"), &t_p3.span_p, &crate::prelude::Text::lit("a tag joins a row kind"))),
    }
}

/// The step machine of `TagKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
/// ```
pub struct TagKind {
    pub g_p0: crate::check::env::G,
    pub cx_p1: crate::check::env::reading::Cx,
    pub st_p2: crate::check::types::St,
    pub t_p3: crate::syntax::Type,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::Ty, crate::check::types::St)> for TagKind {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::check::types::Ty, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let cx_p1 = &self.cx_p1;
        let st_p2 = &self.st_p2;
        let t_p3 = &self.t_p3;
        match &*t_p3.kind_p {
            crate::syntax::TypeKind::TName(n_p4, args_p5) => {
                let name_p6 = crate::check::env::dotted_f(&n_p4.path_p);
                if &name_p6 == &crate::prelude::Text::lit("Element") {
                    match crate::prelude::index(args_p5, &crate::prelude::Nat::from(0u32)) {
                        ::std::option::Option::Some(o_p7) => {
                            let cx_p1x = cx_p1.clone();
                            let st_p2x = st_p2.clone();
                            crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p1x.clone(), st_p2x.clone(), o_p7.clone()), move |conv_type_f_32734: (crate::check::types::Ty, crate::check::types::St)| {
                                let (ot_p8, s2_p9) = conv_type_f_32734;
                                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("Element"), ot_p8.clone(), s2_p9.clone()))
                            })
                        },
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("Element"), crate::check::types::t_unit_p(), st_p2.clone())),
                    }
                } else {
                    {
                        let (key_oa, _) = crate::check::env::names::resolve_type_f(g_p0, &cx_p1.home_p, &n_p4.path_p);
                        match &key_oa {
                            ::std::option::Option::Some(k_pb) => match &crate::prelude::or(&crate::prelude::get(&g_p0.types_p, k_pb), &crate::check::env::names::dummy_ty_info_p()).body_p {
                                crate::check::env::TyBody::BRowKind => ::prism_rtl::Turn::Finished((k_pb.clone(), crate::check::types::t_unit_p(), st_p2.clone())),
                                _ => ::prism_rtl::Turn::Finished((k_pb.clone(), crate::check::types::t_unit_p(), crate::check::types::recording::err_f(st_p2, &crate::prelude::Text::lit("kind"), &t_p3.span_p, &crate::prelude::Text::from(format!("`{}` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`", &name_p6))))),
                            },
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p2, &crate::prelude::Text::lit("unknown-name"), &t_p3.span_p, &crate::prelude::Text::from(format!("no row kind `{}`", &name_p6))))),
                        }
                    }
                }
            },
            crate::syntax::TypeKind::TGroup(x_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TagKind { g_p0: g_p0.clone(), cx_p1: cx_p1.clone(), st_p2: st_p2.clone(), t_p3: (**x_pc).clone() })),
            _ => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p2, &crate::prelude::Text::lit("kind"), &t_p3.span_p, &crate::prelude::Text::lit("a tag joins a row kind")))),
        }
    }
}

/// `Start TagKind, x`: what the function value is when passed to `@Run`.
pub fn start_tag_kind_f(g_p0: crate::check::env::G, cx_p1: crate::check::env::reading::Cx, st_p2: crate::check::types::St, t_p3: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(TagKind { g_p0, cx_p1, st_p2, t_p3 })
}

/// ```prism
/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
/// ```
pub fn conv_trait_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, t_p3: &crate::syntax::decls::TraitDecl, span_p4: &crate::syntax::Range) -> (crate::check::env::G, crate::check::types::St) {
    let name_p5 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_p3.name_p.path_p));
    let param_p6 = crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&t_p3.params_p, &(|p_pc: &crate::syntax::Ident| p_pc.name_p.clone())), &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("a"));
    let st1_p7 = if &crate::prelude::len(&t_p3.params_p) > &crate::prelude::Nat::from(1u32) {
        crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), span_p4, &crate::prelude::Text::lit("this checker does not implement traits of several types"))
    } else {
        st_p1.clone()
    };
    let cx_p8 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
    let (supers_pd, st2_pe) = crate::check::env::reading::conv_bounds_f(&cx_p8, &st1_p7, &t_p3.bounds_p);
    let (assoc_defaults_pm, st2d_pn) = crate::prelude::run_to_end(crate::prelude::fold_job(t_p3.items_p.clone(), (crate::prelude::Array::new(), st2_pe.clone()), {
        let cx_p8x = cx_p8.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)| {
            let cx_p8xy = cx_p8x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pf, s_pg) = p0;
                let it_ph = p1;
                match &it_ph {
                    crate::syntax::decls::TraitItem::TiAssocType(n_pi, _, ::std::option::Option::Some(v_pj), _) => {
                        let n_pix = n_pi.clone();
                        let v_pjx = v_pj.clone();
                        crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p8xy.clone(), s_pg.clone(), v_pjx.clone()), move |conv_type_f_34274: (crate::check::types::Ty, crate::check::types::St)| {
                            let (vt_pk, s2_pl) = conv_type_f_34274;
                            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pf, &(n_pix.name_p.clone(), vt_pk.clone())), s2_pl.clone()))
                        })
                    },
                    _ => ::prism_rtl::Turn::Finished((acc_pf.clone(), s_pg.clone())),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St)>>>
    }));
    let (g3_p1e, st3_p1f, methods_p1g, defaults_p1h, assocs_p1i) = crate::prelude::run_to_end(crate::prelude::fold_job(t_p3.items_p.clone(), (g_p0.clone(), st2d_pn.clone(), crate::prelude::Array::new(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
        let info_p2x = info_p2.clone();
        let cx_p8x = cx_p8.clone();
        let param_p6x = param_p6.clone();
        let name_p5x = name_p5.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>), crate::syntax::decls::TraitItem)| {
            let info_p2xy = info_p2x.clone();
            let cx_p8xy = cx_p8x.clone();
            let param_p6xy = param_p6x.clone();
            let name_p5xy = name_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (gg_po, s_pp, ms_pq, ds_pr, assoc_acc_ps) = p0;
                let it_pt = p1;
                match &it_pt {
                    crate::syntax::decls::TraitItem::TiSignature(sg_pu) => {
                        let mname_pv = crate::check::env::def_name_text_f(&sg_pu.name_p);
                        let qk_p10 = crate::check::env::qual_key_f(&info_p2xy.name_p, &mname_pv);
                        let sg_pux = sg_pu.clone();
                        crate::prelude::call_then(crate::check::env::reading::start_sig_scheme_f(cx_p8xy.clone(), s_pp.clone(), sg_pux.ty_p.clone(), sg_pux.bounds_p.clone()), move |sig_scheme_f_34652: (crate::check::types::Scheme, crate::check::types::St)| {
                            let (sc_p14, s2a_p15) = sig_scheme_f_34652;
                            let s2_p11 = if crate::check::types::has_text_f(&ms_pq, &qk_p10) {
                                crate::check::types::recording::err_f(&s2a_p15, &crate::prelude::Text::lit("collision"), &sg_pux.span_p, &crate::prelude::Text::from(format!("a second signature for `{}`", &mname_pv)))
                            } else {
                                s2a_p15.clone()
                            };
                            let sc2_p12 = {
                                let mut this: crate::check::types::Scheme = sc_p14.clone();
                                this.qs_p = if crate::check::types::has_text_f(&this.qs_p, &param_p6xy) {
                                    this.qs_p.clone()
                                } else {
                                    crate::prelude::append(&crate::prelude::Array::from(vec![param_p6xy.clone()]), &this.qs_p)
                                };
                                this.bounds_p = crate::prelude::append(&crate::prelude::Array::from(vec![(param_p6xy.clone(), name_p5xy.clone())]), &this.bounds_p);
                                this
                            };
                            let upd_p13 = {
                                let mut this: crate::check::env::G = gg_po.clone();
                                this.vals_p = crate::prelude::insert(&this.vals_p, &qk_p10, &crate::check::env::ValInfo { qk_p: qk_p10.clone(), scheme_p: sc2_p12.clone(), sort_p: crate::prelude::Text::lit("method"), has_sig_p: true, home_p: info_p2xy.name_p.clone(), file_p: info_p2xy.file_p.clone(), span_p: sg_pux.span_p.clone() });
                                this
                            };
                            ::prism_rtl::Turn::Finished((upd_p13.clone(), s2_p11.clone(), crate::prelude::push(&ms_pq, &qk_p10), ds_pr.clone(), assoc_acc_ps.clone()))
                        })
                    },
                    crate::syntax::decls::TraitItem::TiFn(f_p16) => {
                        let qk_p17 = crate::check::env::qual_key_f(&info_p2xy.name_p, &crate::check::env::def_name_text_f(&f_p16.name_p));
                        if crate::check::types::has_text_f(&ds_pr, &qk_p17) {
                            {
                                let upd_p18 = {
                                    let mut this: crate::check::env::G = gg_po.clone();
                                    this.defs_p = crate::prelude::each(&this.defs_p, &(|d_p19: &crate::check::env::Def| add_default_clause_f(d_p19, &qk_p17, &name_p5xy, f_p16)));
                                    this
                                };
                                ::prism_rtl::Turn::Finished((upd_p18.clone(), s_pp.clone(), ms_pq.clone(), ds_pr.clone(), assoc_acc_ps.clone()))
                            }
                        } else {
                            {
                                let def_p1a = crate::check::env::Def { qk_p: qk_p17.clone(), name_p: crate::check::env::def_name_text_f(&f_p16.name_p), home_p: info_p2xy.name_p.clone(), file_p: info_p2xy.file_p.clone(), span_p: f_p16.span_p.clone(), body_p: crate::check::env::DefBody::DbDefault(crate::prelude::Array::from(vec![f_p16.clone()]), name_p5xy.clone()) };
                                let upd_p1b = {
                                    let mut this: crate::check::env::G = gg_po.clone();
                                    this.defs_p = crate::prelude::push(&this.defs_p, &def_p1a);
                                    this
                                };
                                ::prism_rtl::Turn::Finished((upd_p1b.clone(), s_pp.clone(), ms_pq.clone(), crate::prelude::push(&ds_pr, &qk_p17), assoc_acc_ps.clone()))
                            }
                        }
                    },
                    crate::syntax::decls::TraitItem::TiAssocType(n_p1c, _, _, _) => ::prism_rtl::Turn::Finished((gg_po.clone(), s_pp.clone(), ms_pq.clone(), ds_pr.clone(), crate::prelude::push(&assoc_acc_ps, &n_p1c.name_p))),
                    crate::syntax::decls::TraitItem::TiAssocRow(_, r_p1d) => ::prism_rtl::Turn::Finished((gg_po.clone(), crate::check::types::recording::err_f(&s_pp, &crate::prelude::Text::lit("unsupported"), r_p1d, &crate::prelude::Text::lit("this checker does not implement associated rows")), ms_pq.clone(), ds_pr.clone(), assoc_acc_ps.clone())),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>), crate::syntax::decls::TraitItem)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>)>>>
    }));
    let st4_p9 = crate::prelude::fold(&t_p3.items_p, &st3_p1f, &(|s_p1j: &crate::check::types::St, it_p1k: &crate::syntax::decls::TraitItem| match it_p1k {
        crate::syntax::decls::TraitItem::TiFn(f_p1l) => if crate::check::types::has_text_f(&methods_p1g, &crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::def_name_text_f(&f_p1l.name_p))) {
            s_p1j.clone()
        } else {
            crate::check::types::recording::err_f(s_p1j, &crate::prelude::Text::lit("mismatch"), &f_p1l.span_p, &crate::prelude::Text::from(format!("`^{}` has no method `{}`", &crate::check::env::dotted_f(&t_p3.name_p.path_p), &crate::check::env::def_name_text_f(&f_p1l.name_p))))
        },
        _ => s_p1j.clone(),
    }));
    let ti_pa = crate::check::env::TraitInfo { name_p: name_p5.clone(), home_p: info_p2.name_p.clone(), param_p: param_p6.clone(), supers_p: crate::prelude::each(&supers_pd, &(|(_, k_p1m): &(crate::prelude::Text, crate::prelude::Text)| k_p1m.clone())), methods_p: methods_p1g.clone(), defaults_p: defaults_p1h.clone(), assocs_p: assocs_p1i.clone(), assoc_defaults_p: assoc_defaults_pm.clone(), file_p: info_p2.file_p.clone(), span_p: span_p4.clone() };
    let upd3_pb = {
        let mut this: crate::check::env::G = g3_p1e.clone();
        this.traits_p = crate::prelude::insert(&this.traits_p, &name_p5, &ti_pa);
        this
    };
    (upd3_pb.clone(), st4_p9.clone())
}

/// The step machine of `ConvTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
/// ```
pub struct ConvTrait {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
    pub t_p3: crate::syntax::decls::TraitDecl,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvTrait {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        let t_p3 = &self.t_p3;
        let span_p4 = &self.span_p4;
        let name_p5 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_p3.name_p.path_p));
        let param_p6 = crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&t_p3.params_p, &(|p_pc: &crate::syntax::Ident| p_pc.name_p.clone())), &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("a"));
        let st1_p7 = if &crate::prelude::len(&t_p3.params_p) > &crate::prelude::Nat::from(1u32) {
            crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), span_p4, &crate::prelude::Text::lit("this checker does not implement traits of several types"))
        } else {
            st_p1.clone()
        };
        let cx_p8 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
        let (supers_pd, st2_pe) = crate::check::env::reading::conv_bounds_f(&cx_p8, &st1_p7, &t_p3.bounds_p);
        let g_p0x = g_p0.clone();
        let info_p2x = info_p2.clone();
        let span_p4x = span_p4.clone();
        let t_p3x = t_p3.clone();
        crate::prelude::call_value(crate::prelude::fold_job(t_p3x.items_p.clone(), (crate::prelude::Array::new(), st2_pe.clone()), {
            let cx_p8x = cx_p8.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)| {
                let cx_p8xy = cx_p8x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_pf, s_pg) = p0;
                    let it_ph = p1;
                    match &it_ph {
                        crate::syntax::decls::TraitItem::TiAssocType(n_pi, _, ::std::option::Option::Some(v_pj), _) => {
                            let n_pix = n_pi.clone();
                            let v_pjx = v_pj.clone();
                            crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p8xy.clone(), s_pg.clone(), v_pjx.clone()), move |conv_type_f_34274: (crate::check::types::Ty, crate::check::types::St)| {
                                let (vt_pk, s2_pl) = conv_type_f_34274;
                                ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pf, &(n_pix.name_p.clone(), vt_pk.clone())), s2_pl.clone()))
                            })
                        },
                        _ => ::prism_rtl::Turn::Finished((acc_pf.clone(), s_pg.clone())),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St)>>>
        }), move |fold_34142: (crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St)| {
            let (assoc_defaults_pm, st2d_pn) = fold_34142;
            crate::prelude::call_value(crate::prelude::fold_job(t_p3x.items_p.clone(), (g_p0x.clone(), st2d_pn.clone(), crate::prelude::Array::new(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
                let info_p2xx = info_p2x.clone();
                let cx_p8x = cx_p8.clone();
                let param_p6x = param_p6.clone();
                let name_p5x = name_p5.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>), crate::syntax::decls::TraitItem)| {
                    let info_p2xxy = info_p2xx.clone();
                    let cx_p8xy = cx_p8x.clone();
                    let param_p6xy = param_p6x.clone();
                    let name_p5xy = name_p5x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (gg_po, s_pp, ms_pq, ds_pr, assoc_acc_ps) = p0;
                        let it_pt = p1;
                        match &it_pt {
                            crate::syntax::decls::TraitItem::TiSignature(sg_pu) => {
                                let mname_pv = crate::check::env::def_name_text_f(&sg_pu.name_p);
                                let qk_p10 = crate::check::env::qual_key_f(&info_p2xxy.name_p, &mname_pv);
                                let sg_pux = sg_pu.clone();
                                crate::prelude::call_then(crate::check::env::reading::start_sig_scheme_f(cx_p8xy.clone(), s_pp.clone(), sg_pux.ty_p.clone(), sg_pux.bounds_p.clone()), move |sig_scheme_f_34652: (crate::check::types::Scheme, crate::check::types::St)| {
                                    let (sc_p14, s2a_p15) = sig_scheme_f_34652;
                                    let s2_p11 = if crate::check::types::has_text_f(&ms_pq, &qk_p10) {
                                        crate::check::types::recording::err_f(&s2a_p15, &crate::prelude::Text::lit("collision"), &sg_pux.span_p, &crate::prelude::Text::from(format!("a second signature for `{}`", &mname_pv)))
                                    } else {
                                        s2a_p15.clone()
                                    };
                                    let sc2_p12 = {
                                        let mut this: crate::check::types::Scheme = sc_p14.clone();
                                        this.qs_p = if crate::check::types::has_text_f(&this.qs_p, &param_p6xy) {
                                            this.qs_p.clone()
                                        } else {
                                            crate::prelude::append(&crate::prelude::Array::from(vec![param_p6xy.clone()]), &this.qs_p)
                                        };
                                        this.bounds_p = crate::prelude::append(&crate::prelude::Array::from(vec![(param_p6xy.clone(), name_p5xy.clone())]), &this.bounds_p);
                                        this
                                    };
                                    let upd_p13 = {
                                        let mut this: crate::check::env::G = gg_po.clone();
                                        this.vals_p = crate::prelude::insert(&this.vals_p, &qk_p10, &crate::check::env::ValInfo { qk_p: qk_p10.clone(), scheme_p: sc2_p12.clone(), sort_p: crate::prelude::Text::lit("method"), has_sig_p: true, home_p: info_p2xxy.name_p.clone(), file_p: info_p2xxy.file_p.clone(), span_p: sg_pux.span_p.clone() });
                                        this
                                    };
                                    ::prism_rtl::Turn::Finished((upd_p13.clone(), s2_p11.clone(), crate::prelude::push(&ms_pq, &qk_p10), ds_pr.clone(), assoc_acc_ps.clone()))
                                })
                            },
                            crate::syntax::decls::TraitItem::TiFn(f_p16) => {
                                let qk_p17 = crate::check::env::qual_key_f(&info_p2xxy.name_p, &crate::check::env::def_name_text_f(&f_p16.name_p));
                                if crate::check::types::has_text_f(&ds_pr, &qk_p17) {
                                    {
                                        let upd_p18 = {
                                            let mut this: crate::check::env::G = gg_po.clone();
                                            this.defs_p = crate::prelude::each(&this.defs_p, &(|d_p19: &crate::check::env::Def| add_default_clause_f(d_p19, &qk_p17, &name_p5xy, f_p16)));
                                            this
                                        };
                                        ::prism_rtl::Turn::Finished((upd_p18.clone(), s_pp.clone(), ms_pq.clone(), ds_pr.clone(), assoc_acc_ps.clone()))
                                    }
                                } else {
                                    {
                                        let def_p1a = crate::check::env::Def { qk_p: qk_p17.clone(), name_p: crate::check::env::def_name_text_f(&f_p16.name_p), home_p: info_p2xxy.name_p.clone(), file_p: info_p2xxy.file_p.clone(), span_p: f_p16.span_p.clone(), body_p: crate::check::env::DefBody::DbDefault(crate::prelude::Array::from(vec![f_p16.clone()]), name_p5xy.clone()) };
                                        let upd_p1b = {
                                            let mut this: crate::check::env::G = gg_po.clone();
                                            this.defs_p = crate::prelude::push(&this.defs_p, &def_p1a);
                                            this
                                        };
                                        ::prism_rtl::Turn::Finished((upd_p1b.clone(), s_pp.clone(), ms_pq.clone(), crate::prelude::push(&ds_pr, &qk_p17), assoc_acc_ps.clone()))
                                    }
                                }
                            },
                            crate::syntax::decls::TraitItem::TiAssocType(n_p1c, _, _, _) => ::prism_rtl::Turn::Finished((gg_po.clone(), s_pp.clone(), ms_pq.clone(), ds_pr.clone(), crate::prelude::push(&assoc_acc_ps, &n_p1c.name_p))),
                            crate::syntax::decls::TraitItem::TiAssocRow(_, r_p1d) => ::prism_rtl::Turn::Finished((gg_po.clone(), crate::check::types::recording::err_f(&s_pp, &crate::prelude::Text::lit("unsupported"), r_p1d, &crate::prelude::Text::lit("this checker does not implement associated rows")), ms_pq.clone(), ds_pr.clone(), assoc_acc_ps.clone())),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>), crate::syntax::decls::TraitItem)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>)>>>
            }), move |fold_34418: (crate::check::env::G, crate::check::types::St, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>)| {
                let (g3_p1e, st3_p1f, methods_p1g, defaults_p1h, assocs_p1i) = fold_34418;
                let st4_p9 = crate::prelude::fold(&t_p3x.items_p, &st3_p1f, &(|s_p1j: &crate::check::types::St, it_p1k: &crate::syntax::decls::TraitItem| match it_p1k {
                    crate::syntax::decls::TraitItem::TiFn(f_p1l) => if crate::check::types::has_text_f(&methods_p1g, &crate::check::env::qual_key_f(&info_p2x.name_p, &crate::check::env::def_name_text_f(&f_p1l.name_p))) {
                        s_p1j.clone()
                    } else {
                        crate::check::types::recording::err_f(s_p1j, &crate::prelude::Text::lit("mismatch"), &f_p1l.span_p, &crate::prelude::Text::from(format!("`^{}` has no method `{}`", &crate::check::env::dotted_f(&t_p3x.name_p.path_p), &crate::check::env::def_name_text_f(&f_p1l.name_p))))
                    },
                    _ => s_p1j.clone(),
                }));
                let ti_pa = crate::check::env::TraitInfo { name_p: name_p5.clone(), home_p: info_p2x.name_p.clone(), param_p: param_p6.clone(), supers_p: crate::prelude::each(&supers_pd, &(|(_, k_p1m): &(crate::prelude::Text, crate::prelude::Text)| k_p1m.clone())), methods_p: methods_p1g.clone(), defaults_p: defaults_p1h.clone(), assocs_p: assocs_p1i.clone(), assoc_defaults_p: assoc_defaults_pm.clone(), file_p: info_p2x.file_p.clone(), span_p: span_p4x.clone() };
                let upd3_pb = {
                    let mut this: crate::check::env::G = g3_p1e.clone();
                    this.traits_p = crate::prelude::insert(&this.traits_p, &name_p5, &ti_pa);
                    this
                };
                ::prism_rtl::Turn::Finished((upd3_pb.clone(), st4_p9.clone()))
            })
        })
    }
}

/// `Start ConvTrait, x`: what the function value is when passed to `@Run`.
pub fn start_conv_trait_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo, t_p3: crate::syntax::decls::TraitDecl, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvTrait { g_p0, st_p1, info_p2, t_p3, span_p4 })
}

/// ```prism
/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
/// ```
pub fn conv_impl_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, i_p3: &crate::syntax::decls::ImplDecl, span_p4: &crate::syntax::Range) -> (crate::check::env::G, crate::check::types::St) {
    match crate::check::env::names::resolve_trait_o(g_p0, &info_p2.name_p, &i_p3.trait_ref_p.path_p) {
        ::std::option::Option::None => (g_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), &i_p3.trait_ref_p.span_p, &crate::prelude::Text::from(format!("no trait `^{}`", &crate::check::env::dotted_f(&i_p3.trait_ref_p.path_p))))),
        ::std::option::Option::Some(cls_p5) => {
            let cx_p6 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
            let (bs_pd, st2a_pe) = crate::check::env::reading::conv_bounds_f(&cx_p6, &crate::check::env::names::trait_collision_at_f(g_p0, st_p1, &info_p2.name_p, &i_p3.trait_ref_p.path_p, &i_p3.trait_ref_p.span_p), &i_p3.bounds_p);
            let st2_p7 = bounds_named_f(&st2a_pe, &i_p3.bounds_p, &crate::check::env::reading::type_vars_of_type_f(&i_p3.ty_p), &crate::prelude::Text::lit("the impl\'s head"), &crate::prelude::Text::lit("the head"));
            let (head_pf, st3_pg) = crate::check::env::reading::conv_type_f(&cx_p6, &st2_p7, &i_p3.ty_p);
            let (assocs_pr, st4_ps) = crate::prelude::run_to_end(crate::prelude::fold_job(i_p3.items_p.clone(), (crate::prelude::Array::new(), st3_pg.clone()), {
                let cx_p6x = cx_p6.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)| {
                    let cx_p6xy = cx_p6x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (acc_ph, s_pi) = p0;
                        let it_pj = p1;
                        match &it_pj {
                            crate::syntax::decls::TraitItem::TiAssocType(n_pk, _, ::std::option::Option::Some(v_pl), chosen_at_pm) => {
                                let chosen_at_pmx = chosen_at_pm.clone();
                                let n_pkx = n_pk.clone();
                                let v_plx = v_pl.clone();
                                crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p6xy.clone(), s_pi.clone(), v_plx.clone()), move |conv_type_f_37730: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (vt_pn, s2_po) = conv_type_f_37730;
                                    if crate::prelude::fold(&acc_ph, &false, &(|seen_pp: &bool, (chosen_pq, _): &(crate::prelude::Text, crate::check::types::Ty)| *seen_pp || (chosen_pq == &n_pkx.name_p))) {
                                        ::prism_rtl::Turn::Finished((acc_ph.clone(), crate::check::types::recording::err_f(&s2_po, &crate::prelude::Text::lit("collision"), &chosen_at_pmx, &crate::prelude::Text::from(format!("a second choice of `type {}`", &n_pkx.name_p)))))
                                    } else {
                                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_ph, &(n_pkx.name_p.clone(), vt_pn.clone())), s2_po.clone()))
                                    }
                                })
                            },
                            _ => ::prism_rtl::Turn::Finished((acc_ph.clone(), s_pi.clone())),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St)>>>
            }));
            let names_p8 = crate::prelude::fold(&i_p3.items_p, &crate::prelude::Array::new(), &(|acc_pt: &crate::prelude::Array<crate::prelude::Text>, it_pu: &crate::syntax::decls::TraitItem| match it_pu {
                crate::syntax::decls::TraitItem::TiFn(f_pv) => crate::check::types::add_text_f(acc_pt, &crate::check::env::def_name_text_f(&f_pv.name_p)),
                _ => acc_pt.clone(),
            }));
            let im_p9 = crate::check::env::ImplInfo { cls_p: cls_p5.clone(), head_p: head_pf.clone(), qs_p: crate::check::env::reading::type_vars_of_type_f(&i_p3.ty_p), bounds_p: bs_pd.clone(), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: span_p4.clone(), derived_p: false, assocs_p: assocs_pr.clone(), methods_p: names_p8.clone() };
            let st5_pa = {
                let mut this: crate::check::types::St = st4_ps.clone();
                this.assoc_impls_p = crate::prelude::append(&this.assoc_impls_p, &crate::prelude::each(&assocs_pr, &(|(an_p10, at_p11): &(crate::prelude::Text, crate::check::types::Ty)| crate::check::types::AssocImpl { cls_p: cls_p5.clone(), name_p: an_p10.clone(), head_p: head_pf.clone(), qs_p: im_p9.qs_p.clone(), value_p: at_p11.clone() })));
                this
            };
            let g2_pb = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.impls_p = crate::prelude::insert(&this.impls_p, &cls_p5, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(&this.impls_p, &cls_p5), &crate::prelude::Array::new()), &im_p9));
                this
            };
            let g3_pc = crate::prelude::fold(&names_p8, &g2_pb, &(|gg_p12: &crate::check::env::G, mname_p13: &crate::prelude::Text| {
                let clauses_p14 = crate::prelude::fold(&i_p3.items_p, &crate::prelude::Array::new(), &(|acc_p15: &crate::prelude::Array<crate::syntax::decls::FnClause>, it_p16: &crate::syntax::decls::TraitItem| match it_p16 {
                    crate::syntax::decls::TraitItem::TiFn(f_p17) => if &crate::check::env::def_name_text_f(&f_p17.name_p) == mname_p13 {
                        crate::prelude::push(acc_p15, f_p17)
                    } else {
                        acc_p15.clone()
                    },
                    _ => acc_p15.clone(),
                }));
                {
                    let mut this: crate::check::env::G = gg_p12.clone();
                    this.defs_p = crate::prelude::push(&this.defs_p, &crate::check::env::Def { qk_p: crate::prelude::Text::from(format!("{} impl {}", &cls_p5, mname_p13)), name_p: mname_p13.clone(), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: span_p4.clone(), body_p: crate::check::env::DefBody::DbMethod(clauses_p14.clone(), cls_p5.clone(), im_p9.clone()) });
                    this
                }
            }));
            (g3_pc.clone(), st5_pa.clone())
        },
    }
}

/// The step machine of `ConvImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
/// ```
pub struct ConvImpl {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
    pub i_p3: crate::syntax::decls::ImplDecl,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvImpl {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        let i_p3 = &self.i_p3;
        let span_p4 = &self.span_p4;
        match crate::check::env::names::resolve_trait_o(g_p0, &info_p2.name_p, &i_p3.trait_ref_p.path_p) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((g_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), &i_p3.trait_ref_p.span_p, &crate::prelude::Text::from(format!("no trait `^{}`", &crate::check::env::dotted_f(&i_p3.trait_ref_p.path_p)))))),
            ::std::option::Option::Some(cls_p5) => {
                let cx_p6 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
                let (bs_pd, st2a_pe) = crate::check::env::reading::conv_bounds_f(&cx_p6, &crate::check::env::names::trait_collision_at_f(g_p0, st_p1, &info_p2.name_p, &i_p3.trait_ref_p.path_p, &i_p3.trait_ref_p.span_p), &i_p3.bounds_p);
                let g_p0x = g_p0.clone();
                let i_p3x = i_p3.clone();
                let info_p2x = info_p2.clone();
                let span_p4x = span_p4.clone();
                crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(i_p3x.ty_p.clone()), move |type_vars_of_type_f_37455: crate::prelude::Array<crate::prelude::Text>| {
                    let st2_p7 = bounds_named_f(&st2a_pe, &i_p3x.bounds_p, &type_vars_of_type_f_37455, &crate::prelude::Text::lit("the impl\'s head"), &crate::prelude::Text::lit("the head"));
                    crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p6.clone(), st2_p7.clone(), i_p3x.ty_p.clone()), move |conv_type_f_37535: (crate::check::types::Ty, crate::check::types::St)| {
                        let (head_pf, st3_pg) = conv_type_f_37535;
                        crate::prelude::call_value(crate::prelude::fold_job(i_p3x.items_p.clone(), (crate::prelude::Array::new(), st3_pg.clone()), {
                            let cx_p6x = cx_p6.clone();
                            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)| {
                                let cx_p6xy = cx_p6x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (acc_ph, s_pi) = p0;
                                    let it_pj = p1;
                                    match &it_pj {
                                        crate::syntax::decls::TraitItem::TiAssocType(n_pk, _, ::std::option::Option::Some(v_pl), chosen_at_pm) => {
                                            let chosen_at_pmx = chosen_at_pm.clone();
                                            let n_pkx = n_pk.clone();
                                            let v_plx = v_pl.clone();
                                            crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p6xy.clone(), s_pi.clone(), v_plx.clone()), move |conv_type_f_37730: (crate::check::types::Ty, crate::check::types::St)| {
                                                let (vt_pn, s2_po) = conv_type_f_37730;
                                                if crate::prelude::fold(&acc_ph, &false, &(|seen_pp: &bool, (chosen_pq, _): &(crate::prelude::Text, crate::check::types::Ty)| *seen_pp || (chosen_pq == &n_pkx.name_p))) {
                                                    ::prism_rtl::Turn::Finished((acc_ph.clone(), crate::check::types::recording::err_f(&s2_po, &crate::prelude::Text::lit("collision"), &chosen_at_pmx, &crate::prelude::Text::from(format!("a second choice of `type {}`", &n_pkx.name_p)))))
                                                } else {
                                                    ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_ph, &(n_pkx.name_p.clone(), vt_pn.clone())), s2_po.clone()))
                                                }
                                            })
                                        },
                                        _ => ::prism_rtl::Turn::Finished((acc_ph.clone(), s_pi.clone())),
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St)>>>
                        }), move |fold_37588: (crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::check::types::St)| {
                            let (assocs_pr, st4_ps) = fold_37588;
                            let names_p8 = crate::prelude::fold(&i_p3x.items_p, &crate::prelude::Array::new(), &(|acc_pt: &crate::prelude::Array<crate::prelude::Text>, it_pu: &crate::syntax::decls::TraitItem| match it_pu {
                                crate::syntax::decls::TraitItem::TiFn(f_pv) => crate::check::types::add_text_f(acc_pt, &crate::check::env::def_name_text_f(&f_pv.name_p)),
                                _ => acc_pt.clone(),
                            }));
                            crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(i_p3x.ty_p.clone()), move |type_vars_of_type_f_38288: crate::prelude::Array<crate::prelude::Text>| {
                                let im_p9 = crate::check::env::ImplInfo { cls_p: cls_p5.clone(), head_p: head_pf.clone(), qs_p: type_vars_of_type_f_38288, bounds_p: bs_pd.clone(), home_p: info_p2x.name_p.clone(), file_p: info_p2x.file_p.clone(), span_p: span_p4x.clone(), derived_p: false, assocs_p: assocs_pr.clone(), methods_p: names_p8.clone() };
                                let st5_pa = {
                                    let mut this: crate::check::types::St = st4_ps.clone();
                                    this.assoc_impls_p = crate::prelude::append(&this.assoc_impls_p, &crate::prelude::each(&assocs_pr, &(|(an_p10, at_p11): &(crate::prelude::Text, crate::check::types::Ty)| crate::check::types::AssocImpl { cls_p: cls_p5.clone(), name_p: an_p10.clone(), head_p: head_pf.clone(), qs_p: im_p9.qs_p.clone(), value_p: at_p11.clone() })));
                                    this
                                };
                                let g2_pb = {
                                    let mut this: crate::check::env::G = g_p0x.clone();
                                    this.impls_p = crate::prelude::insert(&this.impls_p, &cls_p5, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(&this.impls_p, &cls_p5), &crate::prelude::Array::new()), &im_p9));
                                    this
                                };
                                let g3_pc = crate::prelude::fold(&names_p8, &g2_pb, &(|gg_p12: &crate::check::env::G, mname_p13: &crate::prelude::Text| {
                                    let clauses_p14 = crate::prelude::fold(&i_p3x.items_p, &crate::prelude::Array::new(), &(|acc_p15: &crate::prelude::Array<crate::syntax::decls::FnClause>, it_p16: &crate::syntax::decls::TraitItem| match it_p16 {
                                        crate::syntax::decls::TraitItem::TiFn(f_p17) => if &crate::check::env::def_name_text_f(&f_p17.name_p) == mname_p13 {
                                            crate::prelude::push(acc_p15, f_p17)
                                        } else {
                                            acc_p15.clone()
                                        },
                                        _ => acc_p15.clone(),
                                    }));
                                    {
                                        let mut this: crate::check::env::G = gg_p12.clone();
                                        this.defs_p = crate::prelude::push(&this.defs_p, &crate::check::env::Def { qk_p: crate::prelude::Text::from(format!("{} impl {}", &cls_p5, mname_p13)), name_p: mname_p13.clone(), home_p: info_p2x.name_p.clone(), file_p: info_p2x.file_p.clone(), span_p: span_p4x.clone(), body_p: crate::check::env::DefBody::DbMethod(clauses_p14.clone(), cls_p5.clone(), im_p9.clone()) });
                                        this
                                    }
                                }));
                                ::prism_rtl::Turn::Finished((g3_pc.clone(), st5_pa.clone()))
                            })
                        })
                    })
                })
            },
        }
    }
}

/// `Start ConvImpl, x`: what the function value is when passed to `@Run`.
pub fn start_conv_impl_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo, i_p3: crate::syntax::decls::ImplDecl, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvImpl { g_p0, st_p1, info_p2, i_p3, span_p4 })
}
