//! The module `Check.Env.Decls`, from `target/bootstrap/src/prismc/check/env/decls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn convert_types_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, m_p2: &Text) -> (crate::check::env::G, crate::check::types::St) {
    match crate::prelude::get(&g_p0.mods_p, m_p2) {
        None => (g_p0.clone(), st_p1.clone()),
        Some(info_p3) => {
            let s0_p4 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file_p = info_p3.file_p.clone();
                this
            };
            crate::prelude::run_to_end(crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), (g_p0.clone(), s0_p4.clone()), {
                let info_p3x = info_p3.clone();
                Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)| {
                    let info_p3xy = info_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (gg_p5, s_p6) = p0;
                        let d_p7 = p1;
                        prism_rtl::Turn::More(Rc::new(ConvertTypeDecl { g_p0: gg_p5.clone(), st_p1: s_p6.clone(), info_p2: info_p3xy.clone(), d_p3: d_p7.clone() }))
                    }))
                }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
            }))
        },
    }
}

/// The step machine of `ConvertTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct ConvertTypes {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub m_p2: Text,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvertTypes {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let m_p2 = &self.m_p2;
        match crate::prelude::get(&g_p0.mods_p, m_p2) {
            None => prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
            Some(info_p3) => {
                let s0_p4 = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.file_p = info_p3.file_p.clone();
                    this
                };
                crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), (g_p0.clone(), s0_p4.clone()), {
                    let info_p3x = info_p3.clone();
                    Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)| {
                        let info_p3xy = info_p3x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (gg_p5, s_p6) = p0;
                            let d_p7 = p1;
                            prism_rtl::Turn::More(Rc::new(ConvertTypeDecl { g_p0: gg_p5.clone(), st_p1: s_p6.clone(), info_p2: info_p3xy.clone(), d_p3: d_p7.clone() }))
                        }))
                    }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
                }).cycle()
            },
        }
    }
}

/// `Start ConvertTypes, x`: what the function value is when passed to `@Run`.
pub fn start_convert_types_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, m_p2: Text) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvertTypes { g_p0, st_p1, m_p2 })
}

/// ```prism
/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn convert_decls_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, m_p2: &Text) -> (crate::check::env::G, crate::check::types::St) {
    match crate::prelude::get(&g_p0.mods_p, m_p2) {
        None => (g_p0.clone(), st_p1.clone()),
        Some(info_p3) => {
            let s1_p4 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file_p = info_p3.file_p.clone();
                this
            };
            let (g2_p9, s2_pa) = crate::prelude::run_to_end(crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), (g_p0.clone(), s1_p4.clone()), {
                let info_p3x = info_p3.clone();
                Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)| {
                    let info_p3xy = info_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (gg_p6, s_p7) = p0;
                        let d_p8 = p1;
                        prism_rtl::Turn::More(Rc::new(ConvertDecl { g_p0: gg_p6.clone(), st_p1: s_p7.clone(), info_p2: info_p3xy.clone(), d_p3: d_p8.clone() }))
                    }))
                }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
            }));
            let s3_p5 = missing_signatures_f(&g2_p9, &s2_pa, &info_p3);
            (g2_p9.clone(), s3_p5.clone())
        },
    }
}

/// The step machine of `ConvertDecls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct ConvertDecls {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub m_p2: Text,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvertDecls {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let m_p2 = &self.m_p2;
        match crate::prelude::get(&g_p0.mods_p, m_p2) {
            None => prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
            Some(info_p3) => {
                let s1_p4 = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.file_p = info_p3.file_p.clone();
                    this
                };
                let g_p0x = g_p0.clone();
                crate::prelude::call_value(crate::prelude::fold_job(info_p3.tree_p.decls_p.clone(), (g_p0x.clone(), s1_p4.clone()), {
                    let info_p3x = info_p3.clone();
                    Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)| {
                        let info_p3xy = info_p3x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (gg_p6, s_p7) = p0;
                            let d_p8 = p1;
                            prism_rtl::Turn::More(Rc::new(ConvertDecl { g_p0: gg_p6.clone(), st_p1: s_p7.clone(), info_p2: info_p3xy.clone(), d_p3: d_p8.clone() }))
                        }))
                    }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
                }), move |fold_1281: (crate::check::env::G, crate::check::types::St)| {
                    let (g2_p9, s2_pa) = fold_1281;
                    let s3_p5 = missing_signatures_f(&g2_p9, &s2_pa, &info_p3);
                    prism_rtl::Turn::Finished((g2_p9.clone(), s3_p5.clone()))
                })
            },
        }
    }
}

/// `Start ConvertDecls, x`: what the function value is when passed to `@Run`.
pub fn start_convert_decls_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, m_p2: Text) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvertDecls { g_p0, st_p1, m_p2 })
}

/// ```prism
/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub fn convert_type_decl_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, d_p3: &crate::syntax::decls::Decl) -> (crate::check::env::G, crate::check::types::St) {
    match &d_p3.kind_p {
        crate::syntax::decls::DeclKind::DType(t_p4) => {
            let name_p5 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_p4.name_p.path_p));
            let ti_p6 = crate::prelude::or(&crate::prelude::get(&g_p0.types_p, &name_p5), &crate::check::env::names::dummy_ty_info_p());
            let cx_p7 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
            let params_p8 = crate::prelude::each(&t_p4.params_p, &(|p_pa: &crate::syntax::Ident| p_pa.name_p.clone()));
            let self_p9 = crate::check::types::Ty::TyCon(name_p5.clone(), crate::prelude::each(&params_p8, &(|p_pb: &Text| crate::check::types::Ty::TyQ(p_pb.clone()))));
            match &t_p4.body_o {
                None => (g_p0.clone(), st_p1.clone()),
                Some(body_pc) => match body_pc {
                    crate::syntax::decls::TypeBody::TbRecord(fs_pd) => {
                        let (fields_pl, st2_pm) = crate::prelude::run_to_end(crate::prelude::fold_job(fs_pd.clone(), (Array::new(), st_p1.clone()), {
                            let cx_p7x = cx_p7.clone();
                            Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)| {
                                let cx_p7xy = cx_p7x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (acc_pg, s_ph) = p0;
                                    let f_pi = p1;
                                    crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p7xy.clone(), s_ph.clone(), f_pi.ty_p.clone()), move |conv_type_f_2032: (crate::check::types::Ty, crate::check::types::St)| {
                                        let (ft_pj, s2_pk) = conv_type_f_2032;
                                        prism_rtl::Turn::Finished((crate::prelude::push(&acc_pg, &(f_pi.name_p.name_p.clone(), ft_pj.clone())), s2_pk.clone()))
                                    })
                                }))
                            }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
                        }));
                        let ctor_pe = crate::check::env::CtorInfo { name_p: name_p5.clone(), owner_p: name_p5.clone(), params_p: params_p8.clone(), args_p: crate::prelude::each(&fields_pl, &(|(_, ft_pn): &(Text, crate::check::types::Ty)| ft_pn.clone())), fields_p: crate::prelude::each(&fields_pl, &(|(fname_po, _): &(Text, crate::check::types::Ty)| fname_po.clone())), ty_p: self_p9.clone(), index_p: Nat::from(0u32) };
                        let upd_pf = {
                            let mut this: crate::check::env::G = g_p0.clone();
                            this.types_p = crate::prelude::insert(&this.types_p, &name_p5, &with_body_f(&ti_p6, &crate::check::env::TyBody::BRecord(fields_pl.clone())));
                            this.ctors_p = crate::prelude::insert(&this.ctors_p, &name_p5, &ctor_pe);
                            this
                        };
                        (upd_pf.clone(), st2_pm.clone())
                    },
                    crate::syntax::decls::TypeBody::TbChoice(cs_pp) => conv_cases_f(g_p0, st_p1, &cx_p7, &ti_p6, &name_p5, &params_p8, &self_p9, cs_pp),
                    crate::syntax::decls::TypeBody::TbNewtype(c_pq) => conv_cases_f(g_p0, st_p1, &cx_p7, &ti_p6, &name_p5, &params_p8, &self_p9, &Array::from(vec![c_pq.clone()])),
                    crate::syntax::decls::TypeBody::TbUnit(i_pr) => {
                        let ctor_ps = crate::check::env::CtorInfo { name_p: crate::check::env::qual_key_f(&info_p2.name_p, &i_pr.name_p), owner_p: name_p5.clone(), params_p: params_p8.clone(), args_p: Array::new(), fields_p: Array::new(), ty_p: self_p9.clone(), index_p: Nat::from(0u32) };
                        let upd_pt = {
                            let mut this: crate::check::env::G = g_p0.clone();
                            this.types_p = crate::prelude::insert(&this.types_p, &name_p5, &with_body_f(&ti_p6, &crate::check::env::TyBody::BChoice(Array::from(vec![(i_pr.name_p.clone(), Array::new())]))));
                            this.ctors_p = crate::prelude::insert(&this.ctors_p, &crate::check::env::qual_key_f(&info_p2.name_p, &i_pr.name_p), &ctor_ps);
                            this
                        };
                        (upd_pt.clone(), st_p1.clone())
                    },
                    crate::syntax::decls::TypeBody::TbRow => {
                        let upd_pu = {
                            let mut this: crate::check::env::G = g_p0.clone();
                            this.types_p = crate::prelude::insert(&this.types_p, &name_p5, &with_body_f(&ti_p6, &crate::check::env::TyBody::BRowKind));
                            this
                        };
                        (upd_pu.clone(), st_p1.clone())
                    },
                    crate::syntax::decls::TypeBody::TbAlias(a_pv) => {
                        let (at_p11, st2_p12) = crate::check::env::reading::conv_type_f(&cx_p7, st_p1, a_pv);
                        let upd_p10 = {
                            let mut this: crate::check::env::G = g_p0.clone();
                            this.types_p = crate::prelude::insert(&this.types_p, &name_p5, &with_body_f(&ti_p6, &crate::check::env::TyBody::BAlias(at_p11.clone())));
                            this
                        };
                        (upd_p10.clone(), st2_p12.clone())
                    },
                },
            }
        },
        _ => (g_p0.clone(), st_p1.clone()),
    }
}

/// The step machine of `ConvertTypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub struct ConvertTypeDecl {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
    pub d_p3: crate::syntax::decls::Decl,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvertTypeDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        let d_p3 = &self.d_p3;
        match &d_p3.kind_p {
            crate::syntax::decls::DeclKind::DType(t_p4) => {
                let name_p5 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_p4.name_p.path_p));
                let ti_p6 = crate::prelude::or(&crate::prelude::get(&g_p0.types_p, &name_p5), &crate::check::env::names::dummy_ty_info_p());
                let cx_p7 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
                let params_p8 = crate::prelude::each(&t_p4.params_p, &(|p_pa: &crate::syntax::Ident| p_pa.name_p.clone()));
                let self_p9 = crate::check::types::Ty::TyCon(name_p5.clone(), crate::prelude::each(&params_p8, &(|p_pb: &Text| crate::check::types::Ty::TyQ(p_pb.clone()))));
                match &t_p4.body_o {
                    None => prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
                    Some(body_pc) => match body_pc {
                        crate::syntax::decls::TypeBody::TbRecord(fs_pd) => {
                            let fs_pdx = fs_pd.clone();
                            let g_p0x = g_p0.clone();
                            let st_p1x = st_p1.clone();
                            crate::prelude::call_value(crate::prelude::fold_job(fs_pdx.clone(), (Array::new(), st_p1x.clone()), {
                                let cx_p7x = cx_p7.clone();
                                Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)| {
                                    let cx_p7xy = cx_p7x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (acc_pg, s_ph) = p0;
                                        let f_pi = p1;
                                        crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p7xy.clone(), s_ph.clone(), f_pi.ty_p.clone()), move |conv_type_f_2032: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (ft_pj, s2_pk) = conv_type_f_2032;
                                            prism_rtl::Turn::Finished((crate::prelude::push(&acc_pg, &(f_pi.name_p.name_p.clone(), ft_pj.clone())), s2_pk.clone()))
                                        })
                                    }))
                                }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
                            }), move |fold_1951: (Array<(Text, crate::check::types::Ty)>, crate::check::types::St)| {
                                let (fields_pl, st2_pm) = fold_1951;
                                let ctor_pe = crate::check::env::CtorInfo { name_p: name_p5.clone(), owner_p: name_p5.clone(), params_p: params_p8.clone(), args_p: crate::prelude::each(&fields_pl, &(|(_, ft_pn): &(Text, crate::check::types::Ty)| ft_pn.clone())), fields_p: crate::prelude::each(&fields_pl, &(|(fname_po, _): &(Text, crate::check::types::Ty)| fname_po.clone())), ty_p: self_p9.clone(), index_p: Nat::from(0u32) };
                                let upd_pf = {
                                    let mut this: crate::check::env::G = g_p0x.clone();
                                    this.types_p = crate::prelude::insert(&this.types_p, &name_p5, &with_body_f(&ti_p6, &crate::check::env::TyBody::BRecord(fields_pl.clone())));
                                    this.ctors_p = crate::prelude::insert(&this.ctors_p, &name_p5, &ctor_pe);
                                    this
                                };
                                prism_rtl::Turn::Finished((upd_pf.clone(), st2_pm.clone()))
                            })
                        },
                        crate::syntax::decls::TypeBody::TbChoice(cs_pp) => prism_rtl::Turn::More(Rc::new(ConvCases { g_p0: g_p0.clone(), st_p1: st_p1.clone(), cx_p2: cx_p7.clone(), ti_p3: ti_p6.clone(), name_p4: name_p5.clone(), params_p5: params_p8.clone(), self_p6: self_p9.clone(), cs_p7: cs_pp.clone() })),
                        crate::syntax::decls::TypeBody::TbNewtype(c_pq) => prism_rtl::Turn::More(Rc::new(ConvCases { g_p0: g_p0.clone(), st_p1: st_p1.clone(), cx_p2: cx_p7.clone(), ti_p3: ti_p6.clone(), name_p4: name_p5.clone(), params_p5: params_p8.clone(), self_p6: self_p9.clone(), cs_p7: Array::from(vec![c_pq.clone()]) })),
                        crate::syntax::decls::TypeBody::TbUnit(i_pr) => {
                            let ctor_ps = crate::check::env::CtorInfo { name_p: crate::check::env::qual_key_f(&info_p2.name_p, &i_pr.name_p), owner_p: name_p5.clone(), params_p: params_p8.clone(), args_p: Array::new(), fields_p: Array::new(), ty_p: self_p9.clone(), index_p: Nat::from(0u32) };
                            let upd_pt = {
                                let mut this: crate::check::env::G = g_p0.clone();
                                this.types_p = crate::prelude::insert(&this.types_p, &name_p5, &with_body_f(&ti_p6, &crate::check::env::TyBody::BChoice(Array::from(vec![(i_pr.name_p.clone(), Array::new())]))));
                                this.ctors_p = crate::prelude::insert(&this.ctors_p, &crate::check::env::qual_key_f(&info_p2.name_p, &i_pr.name_p), &ctor_ps);
                                this
                            };
                            prism_rtl::Turn::Finished((upd_pt.clone(), st_p1.clone()))
                        },
                        crate::syntax::decls::TypeBody::TbRow => {
                            let upd_pu = {
                                let mut this: crate::check::env::G = g_p0.clone();
                                this.types_p = crate::prelude::insert(&this.types_p, &name_p5, &with_body_f(&ti_p6, &crate::check::env::TyBody::BRowKind));
                                this
                            };
                            prism_rtl::Turn::Finished((upd_pu.clone(), st_p1.clone()))
                        },
                        crate::syntax::decls::TypeBody::TbAlias(a_pv) => {
                            let a_pvx = a_pv.clone();
                            let g_p0x = g_p0.clone();
                            let st_p1x = st_p1.clone();
                            crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p7.clone(), st_p1x.clone(), a_pvx.clone()), move |conv_type_f_3366: (crate::check::types::Ty, crate::check::types::St)| {
                                let (at_p11, st2_p12) = conv_type_f_3366;
                                let upd_p10 = {
                                    let mut this: crate::check::env::G = g_p0x.clone();
                                    this.types_p = crate::prelude::insert(&this.types_p, &name_p5, &with_body_f(&ti_p6, &crate::check::env::TyBody::BAlias(at_p11.clone())));
                                    this
                                };
                                prism_rtl::Turn::Finished((upd_p10.clone(), st2_p12.clone()))
                            })
                        },
                    },
                }
            },
            _ => prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
        }
    }
}

/// `Start ConvertTypeDecl, x`: what the function value is when passed to `@Run`.
pub fn start_convert_type_decl_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo, d_p3: crate::syntax::decls::Decl) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvertTypeDecl { g_p0, st_p1, info_p2, d_p3 })
}

/// ```prism
/// WithBody: fn TyInfo, TyBody -> TyInfo
/// ```
pub fn with_body_f(ti_p0: &crate::check::env::TyInfo, b_p1: &crate::check::env::TyBody) -> crate::check::env::TyInfo {
    let mut this: crate::check::env::TyInfo = ti_p0.clone();
    this.body_p = b_p1.clone();
    this
}

/// ```prism
/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
/// ```
pub fn conv_cases_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, cx_p2: &crate::check::env::reading::Cx_, ti_p3: &crate::check::env::TyInfo, name_p4: &Text, params_p5: &Array<Text>, self_p6: &crate::check::types::Ty, cs_p7: &Array<crate::syntax::decls::Case_>) -> (crate::check::env::G, crate::check::types::St) {
    let (cases_pg, st2_ph) = crate::prelude::run_to_end(crate::prelude::fold_job(cs_p7.clone(), (Array::new(), st_p1.clone()), {
        let cx_p2x = cx_p2.clone();
        Rc::new(move |(p0, p1): ((Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::decls::Case_)| {
            let cx_p2xy = cx_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pa, s_pb) = p0;
                let c_pc = p1;
                {
                    let s1_pd = match &c_pc.indexed_o {
                        Some(_) => crate::check::types::recording::err_f(&s_pb, &Text::lit("unsupported"), &c_pc.span_p, &Text::lit("this checker does not implement indexed choices for user types")),
                        None => s_pb.clone(),
                    };
                    crate::prelude::call_then(crate::check::env::reading::start_conv_types_f(cx_p2xy.clone(), s1_pd.clone(), c_pc.args_p.clone()), move |conv_types_f_4053: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                        let (args_pe, s2_pf) = conv_types_f_4053;
                        prism_rtl::Turn::Finished((crate::prelude::push(&acc_pa, &(crate::check::env::sname_key_f(&c_pc.name_p), args_pe.clone())), s2_pf.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::decls::Case_)) -> Rc<dyn prism_rtl::Job<(Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St)>>>
    }));
    let g2_p8 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&cases_pg)), g_p0, &(|gg_pi: &crate::check::env::G, i_pj: &Nat| {
        let (cn_pl, args_pm) = crate::prelude::or(&crate::prelude::index(&cases_pg, i_pj), &(Text::lit(""), Array::new()));
        let qk_pk = crate::check::env::qual_key_f(&ti_p3.home_p, &cn_pl);
        {
            let mut this: crate::check::env::G = gg_pi.clone();
            this.ctors_p = crate::prelude::insert(&this.ctors_p, &qk_pk, &crate::check::env::CtorInfo { name_p: qk_pk.clone(), owner_p: name_p4.clone(), params_p: params_p5.clone(), args_p: args_pm.clone(), fields_p: Array::new(), ty_p: self_p6.clone(), index_p: i_pj.clone() });
            this
        }
    }));
    let upd_p9 = {
        let mut this: crate::check::env::G = g2_p8.clone();
        this.types_p = crate::prelude::insert(&this.types_p, name_p4, &with_body_f(ti_p3, &crate::check::env::TyBody::BChoice(cases_pg.clone())));
        this
    };
    (upd_p9.clone(), st2_ph.clone())
}

/// The step machine of `ConvCases`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
/// ```
pub struct ConvCases {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub cx_p2: crate::check::env::reading::Cx_,
    pub ti_p3: crate::check::env::TyInfo,
    pub name_p4: Text,
    pub params_p5: Array<Text>,
    pub self_p6: crate::check::types::Ty,
    pub cs_p7: Array<crate::syntax::decls::Case_>,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvCases {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let cx_p2 = &self.cx_p2;
        let ti_p3 = &self.ti_p3;
        let name_p4 = &self.name_p4;
        let params_p5 = &self.params_p5;
        let self_p6 = &self.self_p6;
        let cs_p7 = &self.cs_p7;
        let cs_p7x = cs_p7.clone();
        let cx_p2x = cx_p2.clone();
        let g_p0x = g_p0.clone();
        let name_p4x = name_p4.clone();
        let params_p5x = params_p5.clone();
        let self_p6x = self_p6.clone();
        let st_p1x = st_p1.clone();
        let ti_p3x = ti_p3.clone();
        crate::prelude::call_value(crate::prelude::fold_job(cs_p7x.clone(), (Array::new(), st_p1x.clone()), {
            let cx_p2xx = cx_p2x.clone();
            Rc::new(move |(p0, p1): ((Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::decls::Case_)| {
                let cx_p2xxy = cx_p2xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_pa, s_pb) = p0;
                    let c_pc = p1;
                    {
                        let s1_pd = match &c_pc.indexed_o {
                            Some(_) => crate::check::types::recording::err_f(&s_pb, &Text::lit("unsupported"), &c_pc.span_p, &Text::lit("this checker does not implement indexed choices for user types")),
                            None => s_pb.clone(),
                        };
                        crate::prelude::call_then(crate::check::env::reading::start_conv_types_f(cx_p2xxy.clone(), s1_pd.clone(), c_pc.args_p.clone()), move |conv_types_f_4053: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                            let (args_pe, s2_pf) = conv_types_f_4053;
                            prism_rtl::Turn::Finished((crate::prelude::push(&acc_pa, &(crate::check::env::sname_key_f(&c_pc.name_p), args_pe.clone())), s2_pf.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::decls::Case_)) -> Rc<dyn prism_rtl::Job<(Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St)>>>
        }), move |fold_3815: (Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St)| {
            let (cases_pg, st2_ph) = fold_3815;
            let g2_p8 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&cases_pg)), &g_p0x, &(|gg_pi: &crate::check::env::G, i_pj: &Nat| {
                let (cn_pl, args_pm) = crate::prelude::or(&crate::prelude::index(&cases_pg, i_pj), &(Text::lit(""), Array::new()));
                let qk_pk = crate::check::env::qual_key_f(&ti_p3x.home_p, &cn_pl);
                {
                    let mut this: crate::check::env::G = gg_pi.clone();
                    this.ctors_p = crate::prelude::insert(&this.ctors_p, &qk_pk, &crate::check::env::CtorInfo { name_p: qk_pk.clone(), owner_p: name_p4x.clone(), params_p: params_p5x.clone(), args_p: args_pm.clone(), fields_p: Array::new(), ty_p: self_p6x.clone(), index_p: i_pj.clone() });
                    this
                }
            }));
            let upd_p9 = {
                let mut this: crate::check::env::G = g2_p8.clone();
                this.types_p = crate::prelude::insert(&this.types_p, &name_p4x, &with_body_f(&ti_p3x, &crate::check::env::TyBody::BChoice(cases_pg.clone())));
                this
            };
            prism_rtl::Turn::Finished((upd_p9.clone(), st2_ph.clone()))
        })
    }
}

/// `Start ConvCases, x`: what the function value is when passed to `@Run`.
pub fn start_conv_cases_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, cx_p2: crate::check::env::reading::Cx_, ti_p3: crate::check::env::TyInfo, name_p4: Text, params_p5: Array<Text>, self_p6: crate::check::types::Ty, cs_p7: Array<crate::syntax::decls::Case_>) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvCases { g_p0, st_p1, cx_p2, ti_p3, name_p4, params_p5, self_p6, cs_p7 })
}

/// ```prism
/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub fn convert_decl_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, d_p3: &crate::syntax::decls::Decl) -> (crate::check::env::G, crate::check::types::St) {
    match &d_p3.kind_p {
        crate::syntax::decls::DeclKind::DSignature(s_p4) => {
            let qk_p5 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::def_name_text_f(&s_p4.name_p));
            let cx_p6 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
            let (sc_p9, st1_pa) = crate::check::env::reading::sig_scheme_f(&cx_p6, st_p1, &s_p4.ty_p, &s_p4.bounds_p);
            let st2_p7 = lens_check_f(&st1_pa, &crate::check::env::def_name_text_f(&s_p4.name_p), &s_p4.ty_p, &crate::check::env::def_name_span_f(&s_p4.name_p));
            let st3_p8 = check_mark_function_f(&st2_p7, &crate::check::env::def_name_text_f(&s_p4.name_p), &sc_p9.ty_p, &crate::check::env::def_name_span_f(&s_p4.name_p));
            if crate::check::env::has_key_f(&g_p0.vals_p, &qk_p5) {
                (g_p0.clone(), crate::check::types::recording::err_f(&st3_p8, &Text::lit("collision"), &d_p3.span_p, &Text::from(format!("a second signature for `{}`", &crate::check::env::def_name_text_f(&s_p4.name_p)))))
            } else {
                {
                    let upd_pb = {
                        let mut this: crate::check::env::G = g_p0.clone();
                        this.vals_p = crate::prelude::insert(&this.vals_p, &qk_p5, &crate::check::env::ValInfo { qk_p: qk_p5.clone(), scheme_p: sc_p9.clone(), sort_p: Text::lit("fn"), has_sig_p: true, home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone() });
                        this
                    };
                    (upd_pb.clone(), st3_p8.clone())
                }
            }
        },
        crate::syntax::decls::DeclKind::DFn(f_pc) => {
            let qk_pd = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::def_name_text_f(&f_pc.name_p));
            (add_clause_f(g_p0, info_p2, &qk_pd, &crate::check::env::def_name_text_f(&f_pc.name_p), f_pc, &d_p3.span_p, st_p1), st_p1.clone())
        },
        crate::syntax::decls::DeclKind::DLet(l_pe) => {
            let names_pf = crate::check::env::names::pattern_names_f(&l_pe.pattern_p);
            let qk_pg = crate::check::env::qual_key_f(&info_p2.name_p, &crate::prelude::or(&crate::prelude::index(&names_pf, &Nat::from(0u32)), &Text::lit("")));
            let def_ph = crate::check::env::Def { qk_p: qk_pg.clone(), name_p: crate::prelude::or(&crate::prelude::index(&names_pf, &Nat::from(0u32)), &Text::lit("")), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone(), body_p: crate::check::env::DefBody::DbLet(l_pe.clone()) };
            let upd_pi = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.defs_p = crate::prelude::push(&this.defs_p, &def_ph);
                this
            };
            (upd_pi.clone(), st_p1.clone())
        },
        crate::syntax::decls::DeclKind::DWidget(w_pj) => {
            let qk_pk = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::sname_key_f(&w_pj.name_p));
            let def_pl = crate::check::env::Def { qk_p: qk_pk.clone(), name_p: crate::check::env::sname_key_f(&w_pj.name_p), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone(), body_p: crate::check::env::DefBody::DbWidget(w_pj.clone()) };
            let upd_pm = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.defs_p = crate::prelude::push(&this.defs_p, &def_pl);
                this
            };
            (upd_pm.clone(), st_p1.clone())
        },
        crate::syntax::decls::DeclKind::DTag(t_pn) => conv_tag_f(g_p0, st_p1, info_p2, t_pn, &d_p3.span_p),
        crate::syntax::decls::DeclKind::DTrait(t_po) => conv_trait_f(g_p0, st_p1, info_p2, t_po, &d_p3.span_p),
        crate::syntax::decls::DeclKind::DImpl(i_pp) => conv_impl_f(g_p0, st_p1, info_p2, i_pp, &d_p3.span_p),
        crate::syntax::decls::DeclKind::DCheck(c_pq) => {
            let upd_pr = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.defs_p = crate::prelude::push(&this.defs_p, &crate::check::env::Def { qk_p: crate::check::env::qual_key_f(&info_p2.name_p, &Text::from(format!("check {}", &c_pq.name_p.name_p))), name_p: c_pq.name_p.name_p.clone(), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone(), body_p: crate::check::env::DefBody::DbCheck(c_pq.clone()) });
                this
            };
            (upd_pr.clone(), st_p1.clone())
        },
        crate::syntax::decls::DeclKind::DTest(t_ps) => {
            let upd_pt = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.defs_p = crate::prelude::push(&this.defs_p, &crate::check::env::Def { qk_p: crate::check::env::qual_key_f(&info_p2.name_p, &Text::from(format!("test {}", &t_ps.name_p.name_p))), name_p: t_ps.name_p.name_p.clone(), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone(), body_p: crate::check::env::DefBody::DbTest(t_ps.clone()) });
                this
            };
            (upd_pt.clone(), st_p1.clone())
        },
        crate::syntax::decls::DeclKind::DStmt(s_pu) => match &s_pu.kind_p {
            crate::syntax::StmtKind::SEmit(_) => (g_p0.clone(), st_p1.clone()),
            _ => (g_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &d_p3.span_p, &Text::lit("a statement at the top of a file: nothing at top level is built"))),
        },
        _ => (g_p0.clone(), st_p1.clone()),
    }
}

/// The step machine of `ConvertDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub struct ConvertDecl {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
    pub d_p3: crate::syntax::decls::Decl,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvertDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        let d_p3 = &self.d_p3;
        match &d_p3.kind_p {
            crate::syntax::decls::DeclKind::DSignature(s_p4) => {
                let qk_p5 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::def_name_text_f(&s_p4.name_p));
                let cx_p6 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
                let d_p3x = d_p3.clone();
                let g_p0x = g_p0.clone();
                let info_p2x = info_p2.clone();
                let s_p4x = s_p4.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::env::reading::start_sig_scheme_f(cx_p6.clone(), st_p1x.clone(), s_p4x.ty_p.clone(), s_p4x.bounds_p.clone()), move |sig_scheme_f_4784: (crate::check::types::Scheme, crate::check::types::St)| {
                    let (sc_p9, st1_pa) = sig_scheme_f_4784;
                    let st2_p7 = lens_check_f(&st1_pa, &crate::check::env::def_name_text_f(&s_p4x.name_p), &s_p4x.ty_p, &crate::check::env::def_name_span_f(&s_p4x.name_p));
                    crate::prelude::call_then(start_check_mark_function_f(st2_p7.clone(), crate::check::env::def_name_text_f(&s_p4x.name_p), sc_p9.ty_p.clone(), crate::check::env::def_name_span_f(&s_p4x.name_p)), move |check_mark_function_f_4917: crate::check::types::St| {
                        let st3_p8 = check_mark_function_f_4917;
                        if crate::check::env::has_key_f(&g_p0x.vals_p, &qk_p5) {
                            prism_rtl::Turn::Finished((g_p0x.clone(), crate::check::types::recording::err_f(&st3_p8, &Text::lit("collision"), &d_p3x.span_p, &Text::from(format!("a second signature for `{}`", &crate::check::env::def_name_text_f(&s_p4x.name_p))))))
                        } else {
                            {
                                let upd_pb = {
                                    let mut this: crate::check::env::G = g_p0x.clone();
                                    this.vals_p = crate::prelude::insert(&this.vals_p, &qk_p5, &crate::check::env::ValInfo { qk_p: qk_p5.clone(), scheme_p: sc_p9.clone(), sort_p: Text::lit("fn"), has_sig_p: true, home_p: info_p2x.name_p.clone(), file_p: info_p2x.file_p.clone(), span_p: d_p3x.span_p.clone() });
                                    this
                                };
                                prism_rtl::Turn::Finished((upd_pb.clone(), st3_p8.clone()))
                            }
                        }
                    })
                })
            },
            crate::syntax::decls::DeclKind::DFn(f_pc) => {
                let qk_pd = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::def_name_text_f(&f_pc.name_p));
                prism_rtl::Turn::Finished((add_clause_f(g_p0, info_p2, &qk_pd, &crate::check::env::def_name_text_f(&f_pc.name_p), f_pc, &d_p3.span_p, st_p1), st_p1.clone()))
            },
            crate::syntax::decls::DeclKind::DLet(l_pe) => {
                let d_p3x = d_p3.clone();
                let g_p0x = g_p0.clone();
                let info_p2x = info_p2.clone();
                let l_pex = l_pe.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(l_pex.pattern_p.clone()), move |pattern_names_f_5497: Array<Text>| {
                    let names_pf = pattern_names_f_5497;
                    let qk_pg = crate::check::env::qual_key_f(&info_p2x.name_p, &crate::prelude::or(&crate::prelude::index(&names_pf, &Nat::from(0u32)), &Text::lit("")));
                    let def_ph = crate::check::env::Def { qk_p: qk_pg.clone(), name_p: crate::prelude::or(&crate::prelude::index(&names_pf, &Nat::from(0u32)), &Text::lit("")), home_p: info_p2x.name_p.clone(), file_p: info_p2x.file_p.clone(), span_p: d_p3x.span_p.clone(), body_p: crate::check::env::DefBody::DbLet(l_pex.clone()) };
                    let upd_pi = {
                        let mut this: crate::check::env::G = g_p0x.clone();
                        this.defs_p = crate::prelude::push(&this.defs_p, &def_ph);
                        this
                    };
                    prism_rtl::Turn::Finished((upd_pi.clone(), st_p1x.clone()))
                })
            },
            crate::syntax::decls::DeclKind::DWidget(w_pj) => {
                let qk_pk = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::sname_key_f(&w_pj.name_p));
                let def_pl = crate::check::env::Def { qk_p: qk_pk.clone(), name_p: crate::check::env::sname_key_f(&w_pj.name_p), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone(), body_p: crate::check::env::DefBody::DbWidget(w_pj.clone()) };
                let upd_pm = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.defs_p = crate::prelude::push(&this.defs_p, &def_pl);
                    this
                };
                prism_rtl::Turn::Finished((upd_pm.clone(), st_p1.clone()))
            },
            crate::syntax::decls::DeclKind::DTag(t_pn) => prism_rtl::Turn::More(Rc::new(ConvTag { g_p0: g_p0.clone(), st_p1: st_p1.clone(), info_p2: info_p2.clone(), t_p3: t_pn.clone(), span_p4: d_p3.span_p.clone() })),
            crate::syntax::decls::DeclKind::DTrait(t_po) => prism_rtl::Turn::More(Rc::new(ConvTrait { g_p0: g_p0.clone(), st_p1: st_p1.clone(), info_p2: info_p2.clone(), t_p3: t_po.clone(), span_p4: d_p3.span_p.clone() })),
            crate::syntax::decls::DeclKind::DImpl(i_pp) => prism_rtl::Turn::More(Rc::new(ConvImpl { g_p0: g_p0.clone(), st_p1: st_p1.clone(), info_p2: info_p2.clone(), i_p3: i_pp.clone(), span_p4: d_p3.span_p.clone() })),
            crate::syntax::decls::DeclKind::DCheck(c_pq) => {
                let upd_pr = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.defs_p = crate::prelude::push(&this.defs_p, &crate::check::env::Def { qk_p: crate::check::env::qual_key_f(&info_p2.name_p, &Text::from(format!("check {}", &c_pq.name_p.name_p))), name_p: c_pq.name_p.name_p.clone(), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone(), body_p: crate::check::env::DefBody::DbCheck(c_pq.clone()) });
                    this
                };
                prism_rtl::Turn::Finished((upd_pr.clone(), st_p1.clone()))
            },
            crate::syntax::decls::DeclKind::DTest(t_ps) => {
                let upd_pt = {
                    let mut this: crate::check::env::G = g_p0.clone();
                    this.defs_p = crate::prelude::push(&this.defs_p, &crate::check::env::Def { qk_p: crate::check::env::qual_key_f(&info_p2.name_p, &Text::from(format!("test {}", &t_ps.name_p.name_p))), name_p: t_ps.name_p.name_p.clone(), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: d_p3.span_p.clone(), body_p: crate::check::env::DefBody::DbTest(t_ps.clone()) });
                    this
                };
                prism_rtl::Turn::Finished((upd_pt.clone(), st_p1.clone()))
            },
            crate::syntax::decls::DeclKind::DStmt(s_pu) => match &s_pu.kind_p {
                crate::syntax::StmtKind::SEmit(_) => prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
                _ => prism_rtl::Turn::Finished((g_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &d_p3.span_p, &Text::lit("a statement at the top of a file: nothing at top level is built")))),
            },
            _ => prism_rtl::Turn::Finished((g_p0.clone(), st_p1.clone())),
        }
    }
}

/// `Start ConvertDecl, x`: what the function value is when passed to `@Run`.
pub fn start_convert_decl_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo, d_p3: crate::syntax::decls::Decl) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvertDecl { g_p0, st_p1, info_p2, d_p3 })
}

/// ```prism
/// AddClause: fn G, ModInfo, Text, Text, FnClause, Range, St -> G
/// ```
pub fn add_clause_f(g_p0: &crate::check::env::G, info_p1: &crate::check::env::ModInfo, qk_p2: &Text, name_p3: &Text, f_p4: &crate::syntax::decls::FnClause, span_p5: &crate::syntax::Range, st_p6: &crate::check::types::St) -> crate::check::env::G {
    match crate::prelude::get(&g_p0.fn_at_p, qk_p2) {
        Some(i_p7) => {
            let mut this: crate::check::env::G = g_p0.clone();
            this.defs_p = insert2_f(&this.defs_p, &i_p7, &add_to_fn_f(&crate::prelude::or(&crate::prelude::index(&this.defs_p, &i_p7), &dummy_def_p()), f_p4));
            this
        },
        None => {
            let mut this: crate::check::env::G = g_p0.clone();
            this.fn_at_p = crate::prelude::insert(&this.fn_at_p, qk_p2, &crate::prelude::len(&this.defs_p));
            this.defs_p = crate::prelude::push(&this.defs_p, &crate::check::env::Def { qk_p: qk_p2.clone(), name_p: name_p3.clone(), home_p: info_p1.name_p.clone(), file_p: info_p1.file_p.clone(), span_p: span_p5.clone(), body_p: crate::check::env::DefBody::DbFn(Array::from(vec![f_p4.clone()])) });
            this
        },
    }
}

/// ```prism
/// let dummyDef
/// ```
pub fn dummy_def_p() -> crate::check::env::Def {
    crate::check::env::Def { qk_p: Text::lit(""), name_p: Text::lit(""), home_p: Text::lit(""), file_p: Nat::from(0u32), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) }, body_p: crate::check::env::DefBody::DbFn(Array::new()) }
}

/// ```prism
/// IsFnDef: fn Def -> Bool
/// ```
pub fn is_fn_def_f(d_p0: &crate::check::env::Def) -> bool {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbFn(_) => true,
        _ => false,
    }
}

/// ```prism
/// AddToFn: fn Def, FnClause -> Def
/// ```
pub fn add_to_fn_f(d_p0: &crate::check::env::Def, f_p1: &crate::syntax::decls::FnClause) -> crate::check::env::Def {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbFn(fs_p2) => {
            let mut this: crate::check::env::Def = d_p0.clone();
            this.body_p = crate::check::env::DefBody::DbFn(crate::prelude::push(fs_p2, f_p1));
            this
        },
        _ => d_p0.clone(),
    }
}

/// ```prism
/// Insert2: fn [a], Nat, a -> [a]
/// ```
pub fn insert2_f<A: Clone + 'static>(xs_p0: &Array<A>, i_p1: &Nat, x_p2: &A) -> Array<A> {
    crate::prelude::append(&crate::prelude::push(&crate::prelude::take(xs_p0, i_p1), x_p2), &crate::prelude::drop(xs_p0, &(i_p1 + &Nat::from(1u32))))
}

/// ```prism
/// LensCheck: fn St, Text, Type, Range -> St
/// ```
pub fn lens_check_f(st_p0: &crate::check::types::St, name_p1: &Text, t_p2: &crate::syntax::Type, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    if !crate::syntax::lexer::chars::has_prefix_f(name_p1, &Text::lit("&")) {
        st_p0.clone()
    } else {
        match &*t_p2.kind_p {
            crate::syntax::TypeKind::TFn(_, ps_p4, _) => {
                let refs_p5 = crate::prelude::filter(ps_p4, &(|p_p6: &crate::syntax::Type| is_ref_type_f(p_p6)));
                if &crate::prelude::len(&refs_p5) > &Nat::from(1u32) {
                    crate::check::types::recording::err_fix_f(st_p0, &Text::lit("lens-arity"), span_p3, &Text::lit("a lens takes one reference"), &Text::lit("take the second part as a plain value"))
                } else {
                    crate::check::types::recording::err_f(st_p0, &Text::lit("unsupported"), span_p3, &Text::lit("this checker does not implement named lenses and `Over`"))
                }
            },
            _ => st_p0.clone(),
        }
    }
}

/// ```prism
/// IsRefType: fn Type -> Bool
/// ```
pub fn is_ref_type_f(t_p0: &crate::syntax::Type) -> bool {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TName(n_p1, _) => crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &Text::lit("&")),
        crate::syntax::TypeKind::TSigiled(s_p2, _) => crate::syntax::lexer::chars::has_prefix_f(s_p2, &Text::lit("&")),
        _ => false,
    }
}

/// ```prism
/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
/// ```
pub fn check_mark_function_f(st_p0: &crate::check::types::St, name_p1: &Text, t_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    match t_p2 {
        crate::check::types::Ty::TyFn(_, _, res_p4) => {
            let want_p5 = crate::check::types::head_sigil_f(st_p0, &**res_p4);
            let marks_p6 = crate::check::types::unify::marks_of_f(name_p1);
            let shown_p7 = crate::syntax::lexer::chars::head_f(&marks_p6);
            let bare_p8 = crate::syntax::lexer::chars::drop_prefix_f(name_p1, &marks_p6);
            if (((&shown_p7 == &want_p5) || (&crate::prelude::len_text(&marks_p6) > &Nat::from(1u32))) || (&bare_p8 == &Text::lit(""))) || !crate::check::env::is_upper_text_f(&bare_p8) {
                st_p0.clone()
            } else {
                crate::check::types::recording::err_fix_f(st_p0, &Text::lit("mark-function"), span_p3, &Text::from(format!("`{}` returns `{}`; name it `{}{}`", name_p1, &crate::check::types::show_ty_f(st_p0, &**res_p4), &want_p5, &bare_p8)), &Text::from(format!("rename to `{}{}`", &want_p5, &bare_p8)))
            }
        },
        _ => st_p0.clone(),
    }
}

/// The step machine of `CheckMarkFunction`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
/// ```
pub struct CheckMarkFunction {
    pub st_p0: crate::check::types::St,
    pub name_p1: Text,
    pub t_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for CheckMarkFunction {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let name_p1 = &self.name_p1;
        let t_p2 = &self.t_p2;
        let span_p3 = &self.span_p3;
        match t_p2 {
            crate::check::types::Ty::TyFn(_, _, res_p4) => {
                let name_p1x = name_p1.clone();
                let res_p4x = (**res_p4).clone();
                let span_p3x = span_p3.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p0x.clone(), res_p4x.clone()), move |head_sigil_f_8937: Text| {
                    let want_p5 = head_sigil_f_8937;
                    let marks_p6 = crate::check::types::unify::marks_of_f(&name_p1x);
                    let shown_p7 = crate::syntax::lexer::chars::head_f(&marks_p6);
                    let bare_p8 = crate::syntax::lexer::chars::drop_prefix_f(&name_p1x, &marks_p6);
                    if (((&shown_p7 == &want_p5) || (&crate::prelude::len_text(&marks_p6) > &Nat::from(1u32))) || (&bare_p8 == &Text::lit(""))) || !crate::check::env::is_upper_text_f(&bare_p8) {
                        prism_rtl::Turn::Finished(st_p0x.clone())
                    } else {
                        crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p0x.clone(), res_p4x.clone()), move |show_ty_f_9217: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p0x, &Text::lit("mark-function"), &span_p3x, &Text::from(format!("`{}` returns `{}`; name it `{}{}`", &name_p1x, &show_ty_f_9217, &want_p5, &bare_p8)), &Text::from(format!("rename to `{}{}`", &want_p5, &bare_p8)))))
                    }
                })
            },
            _ => prism_rtl::Turn::Finished(st_p0.clone()),
        }
    }
}

/// `Start CheckMarkFunction, x`: what the function value is when passed to `@Run`.
pub fn start_check_mark_function_f(st_p0: crate::check::types::St, name_p1: Text, t_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckMarkFunction { st_p0, name_p1, t_p2, span_p3 })
}

/// ```prism
/// MissingSignatures: fn G, St, ModInfo -> St
/// ```
pub fn missing_signatures_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo) -> crate::check::types::St {
    crate::prelude::fold(&g_p0.defs_p, st_p1, &(|s_p3: &crate::check::types::St, d_p4: &crate::check::env::Def| if ((&d_p4.home_p == &info_p2.name_p) && is_fn_def_f(d_p4)) && !crate::check::env::has_key_f(&g_p0.vals_p, &d_p4.qk_p) {
        crate::check::types::recording::err_fix_f(s_p3, &Text::lit("no-signature"), &d_p4.span_p, &Text::from(format!("`{}` has no signature line", &d_p4.name_p)), &Text::from(format!("write `{}: fn ... -> ...` above it", &d_p4.name_p)))
    } else {
        s_p3.clone()
    }))
}

/// ```prism
/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
/// ```
pub fn conv_tag_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, t_p3: &crate::syntax::decls::TagDecl, span_p4: &crate::syntax::Range) -> (crate::check::env::G, crate::check::types::St) {
    let name_p5 = crate::check::env::dotted_f(&t_p3.name_p.path_p);
    let family_p6 = crate::check::env::dotted_f(&crate::prelude::take(&t_p3.name_p.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&t_p3.name_p.path_p))));
    let cx_p7 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
    let (kind_pb, out_pc, st2_pd) = tag_kind_f(g_p0, &cx_p7, st_p1, &t_p3.of_type_p);
    let (fields_pj, st3_pk) = crate::prelude::run_to_end(crate::prelude::fold_job(t_p3.fields_p.clone(), (Array::new(), st2_pd.clone()), {
        let cx_p7x = cx_p7.clone();
        Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)| {
            let cx_p7xy = cx_p7x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pe, s_pf) = p0;
                let f_pg = p1;
                crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p7xy.clone(), s_pf.clone(), f_pg.ty_p.clone()), move |conv_type_f_10129: (crate::check::types::Ty, crate::check::types::St)| {
                    let (ft_ph, s2_pi) = conv_type_f_10129;
                    prism_rtl::Turn::Finished((crate::prelude::push(&acc_pe, &(f_pg.name_p.name_p.clone(), ft_ph.clone())), s2_pi.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
    }));
    let qs_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(t_p3.fields_p.clone(), crate::check::env::reading::type_vars_of_type_f(&t_p3.of_type_p), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::decls::Field)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_pl = p0;
        let f_pm = p1;
        crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(f_pm.ty_p.clone()), move |type_vars_of_type_f_10280: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pl, &type_vars_of_type_f_10280)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::decls::Field)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let (bs_pn, st4_po) = crate::check::env::reading::conv_bounds_f(&cx_p7, &st3_pk, &t_p3.bounds_p);
    let tg_p9 = crate::check::env::TagInfo { name_p: name_p5.clone(), family_p: family_p6.clone(), kind_p: kind_pb.clone(), out_p: out_pc.clone(), qs_p: qs_p8.clone(), rqs_p: if &info_p2.row_var_p == &Text::lit("") {
        Array::new()
    } else {
        Array::from(vec![info_p2.row_var_p.clone()])
    }, bounds_p: bs_pn.clone(), fields_p: fields_pj.clone(), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: span_p4.clone() };
    let upd_pa = {
        let mut this: crate::check::env::G = g_p0.clone();
        this.tags_p = crate::prelude::insert(&this.tags_p, &name_p5, &tg_p9);
        this
    };
    (upd_pa.clone(), st4_po.clone())
}

/// The step machine of `ConvTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
/// ```
pub struct ConvTag {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
    pub t_p3: crate::syntax::decls::TagDecl,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvTag {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        let t_p3 = &self.t_p3;
        let span_p4 = &self.span_p4;
        let name_p5 = crate::check::env::dotted_f(&t_p3.name_p.path_p);
        let family_p6 = crate::check::env::dotted_f(&crate::prelude::take(&t_p3.name_p.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&t_p3.name_p.path_p))));
        let cx_p7 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
        let g_p0x = g_p0.clone();
        let info_p2x = info_p2.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        let t_p3x = t_p3.clone();
        crate::prelude::call_then(start_tag_kind_f(g_p0x.clone(), cx_p7.clone(), st_p1x.clone(), t_p3x.of_type_p.clone()), move |tag_kind_f_10003: (Text, crate::check::types::Ty, crate::check::types::St)| {
            let (kind_pb, out_pc, st2_pd) = tag_kind_f_10003;
            crate::prelude::call_value(crate::prelude::fold_job(t_p3x.fields_p.clone(), (Array::new(), st2_pd.clone()), {
                let cx_p7x = cx_p7.clone();
                Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)| {
                    let cx_p7xy = cx_p7x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (acc_pe, s_pf) = p0;
                        let f_pg = p1;
                        crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p7xy.clone(), s_pf.clone(), f_pg.ty_p.clone()), move |conv_type_f_10129: (crate::check::types::Ty, crate::check::types::St)| {
                            let (ft_ph, s2_pi) = conv_type_f_10129;
                            prism_rtl::Turn::Finished((crate::prelude::push(&acc_pe, &(f_pg.name_p.name_p.clone(), ft_ph.clone())), s2_pi.clone()))
                        })
                    }))
                }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
            }), move |fold_10057: (Array<(Text, crate::check::types::Ty)>, crate::check::types::St)| {
                let (fields_pj, st3_pk) = fold_10057;
                crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(t_p3x.of_type_p.clone()), move |type_vars_of_type_f_10227: Array<Text>| crate::prelude::call_value(crate::prelude::fold_job(t_p3x.fields_p.clone(), type_vars_of_type_f_10227, Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::decls::Field)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pl = p0;
                    let f_pm = p1;
                    crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(f_pm.ty_p.clone()), move |type_vars_of_type_f_10280: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pl, &type_vars_of_type_f_10280)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::decls::Field)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_10211: Array<Text>| {
                    let qs_p8 = fold_10211;
                    let (bs_pn, st4_po) = crate::check::env::reading::conv_bounds_f(&cx_p7, &st3_pk, &t_p3x.bounds_p);
                    let tg_p9 = crate::check::env::TagInfo { name_p: name_p5.clone(), family_p: family_p6.clone(), kind_p: kind_pb.clone(), out_p: out_pc.clone(), qs_p: qs_p8.clone(), rqs_p: if &info_p2x.row_var_p == &Text::lit("") {
                        Array::new()
                    } else {
                        Array::from(vec![info_p2x.row_var_p.clone()])
                    }, bounds_p: bs_pn.clone(), fields_p: fields_pj.clone(), home_p: info_p2x.name_p.clone(), file_p: info_p2x.file_p.clone(), span_p: span_p4x.clone() };
                    let upd_pa = {
                        let mut this: crate::check::env::G = g_p0x.clone();
                        this.tags_p = crate::prelude::insert(&this.tags_p, &name_p5, &tg_p9);
                        this
                    };
                    prism_rtl::Turn::Finished((upd_pa.clone(), st4_po.clone()))
                }))
            })
        })
    }
}

/// `Start ConvTag, x`: what the function value is when passed to `@Run`.
pub fn start_conv_tag_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo, t_p3: crate::syntax::decls::TagDecl, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvTag { g_p0, st_p1, info_p2, t_p3, span_p4 })
}

/// ```prism
/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
/// ```
pub fn tag_kind_f(g_p0: &crate::check::env::G, cx_p1: &crate::check::env::reading::Cx_, st_p2: &crate::check::types::St, t_p3: &crate::syntax::Type) -> (Text, crate::check::types::Ty, crate::check::types::St) {
    match &*t_p3.kind_p {
        crate::syntax::TypeKind::TName(n_p4, args_p5) => {
            let name_p6 = crate::check::env::dotted_f(&n_p4.path_p);
            if &name_p6 == &Text::lit("Element") {
                match crate::prelude::index(args_p5, &Nat::from(0u32)) {
                    Some(o_p7) => {
                        let (ot_p8, s2_p9) = crate::check::env::reading::conv_type_f(cx_p1, st_p2, &o_p7);
                        (Text::lit("Element"), ot_p8.clone(), s2_p9.clone())
                    },
                    None => (Text::lit("Element"), crate::check::types::t_unit_p(), st_p2.clone()),
                }
            } else {
                {
                    let (key_oa, _) = crate::check::env::names::resolve_type_f(g_p0, &cx_p1.home_p, &n_p4.path_p);
                    match &key_oa {
                        Some(k_pb) => match &crate::prelude::or(&crate::prelude::get(&g_p0.types_p, k_pb), &crate::check::env::names::dummy_ty_info_p()).body_p {
                            crate::check::env::TyBody::BRowKind => (k_pb.clone(), crate::check::types::t_unit_p(), st_p2.clone()),
                            _ => (k_pb.clone(), crate::check::types::t_unit_p(), crate::check::types::recording::err_f(st_p2, &Text::lit("kind"), &t_p3.span_p, &Text::from(format!("`{}` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`", &name_p6)))),
                        },
                        None => (Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p2, &Text::lit("unknown-name"), &t_p3.span_p, &Text::from(format!("no row kind `{}`", &name_p6)))),
                    }
                }
            }
        },
        crate::syntax::TypeKind::TGroup(x_pc) => tag_kind_f(g_p0, cx_p1, st_p2, &**x_pc),
        _ => (Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p2, &Text::lit("kind"), &t_p3.span_p, &Text::lit("a tag joins a row kind"))),
    }
}

/// The step machine of `TagKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
/// ```
pub struct TagKind {
    pub g_p0: crate::check::env::G,
    pub cx_p1: crate::check::env::reading::Cx_,
    pub st_p2: crate::check::types::St,
    pub t_p3: crate::syntax::Type,
}

impl prism_rtl::Job<(Text, crate::check::types::Ty, crate::check::types::St)> for TagKind {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::Ty, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let cx_p1 = &self.cx_p1;
        let st_p2 = &self.st_p2;
        let t_p3 = &self.t_p3;
        match &*t_p3.kind_p {
            crate::syntax::TypeKind::TName(n_p4, args_p5) => {
                let name_p6 = crate::check::env::dotted_f(&n_p4.path_p);
                if &name_p6 == &Text::lit("Element") {
                    match crate::prelude::index(args_p5, &Nat::from(0u32)) {
                        Some(o_p7) => {
                            let cx_p1x = cx_p1.clone();
                            let st_p2x = st_p2.clone();
                            crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p1x.clone(), st_p2x.clone(), o_p7.clone()), move |conv_type_f_10990: (crate::check::types::Ty, crate::check::types::St)| {
                                let (ot_p8, s2_p9) = conv_type_f_10990;
                                prism_rtl::Turn::Finished((Text::lit("Element"), ot_p8.clone(), s2_p9.clone()))
                            })
                        },
                        None => prism_rtl::Turn::Finished((Text::lit("Element"), crate::check::types::t_unit_p(), st_p2.clone())),
                    }
                } else {
                    {
                        let (key_oa, _) = crate::check::env::names::resolve_type_f(g_p0, &cx_p1.home_p, &n_p4.path_p);
                        match &key_oa {
                            Some(k_pb) => match &crate::prelude::or(&crate::prelude::get(&g_p0.types_p, k_pb), &crate::check::env::names::dummy_ty_info_p()).body_p {
                                crate::check::env::TyBody::BRowKind => prism_rtl::Turn::Finished((k_pb.clone(), crate::check::types::t_unit_p(), st_p2.clone())),
                                _ => prism_rtl::Turn::Finished((k_pb.clone(), crate::check::types::t_unit_p(), crate::check::types::recording::err_f(st_p2, &Text::lit("kind"), &t_p3.span_p, &Text::from(format!("`{}` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`", &name_p6))))),
                            },
                            None => prism_rtl::Turn::Finished((Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p2, &Text::lit("unknown-name"), &t_p3.span_p, &Text::from(format!("no row kind `{}`", &name_p6))))),
                        }
                    }
                }
            },
            crate::syntax::TypeKind::TGroup(x_pc) => prism_rtl::Turn::More(Rc::new(TagKind { g_p0: g_p0.clone(), cx_p1: cx_p1.clone(), st_p2: st_p2.clone(), t_p3: (**x_pc).clone() })),
            _ => prism_rtl::Turn::Finished((Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p2, &Text::lit("kind"), &t_p3.span_p, &Text::lit("a tag joins a row kind")))),
        }
    }
}

/// `Start TagKind, x`: what the function value is when passed to `@Run`.
pub fn start_tag_kind_f(g_p0: crate::check::env::G, cx_p1: crate::check::env::reading::Cx_, st_p2: crate::check::types::St, t_p3: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(TagKind { g_p0, cx_p1, st_p2, t_p3 })
}

/// ```prism
/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
/// ```
pub fn conv_trait_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, t_p3: &crate::syntax::decls::TraitDecl, span_p4: &crate::syntax::Range) -> (crate::check::env::G, crate::check::types::St) {
    let name_p5 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_p3.name_p.path_p));
    let param_p6 = crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&t_p3.params_p, &(|p_pb: &crate::syntax::Ident| p_pb.name_p.clone())), &Nat::from(0u32)), &Text::lit("a"));
    let st1_p7 = if &crate::prelude::len(&t_p3.params_p) > &Nat::from(1u32) {
        crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), span_p4, &Text::lit("this checker does not implement traits of several types"))
    } else {
        st_p1.clone()
    };
    let cx_p8 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
    let (supers_pc, st2_pd) = crate::check::env::reading::conv_bounds_f(&cx_p8, &st1_p7, &t_p3.bounds_p);
    let (g3_p11, st3_p12, methods_p13, defaults_p14, assocs_p15) = crate::prelude::run_to_end(crate::prelude::fold_job(t_p3.items_p.clone(), (g_p0.clone(), st2_pd.clone(), Array::new(), Array::new(), Array::new()), {
        let info_p2x = info_p2.clone();
        let cx_p8x = cx_p8.clone();
        let param_p6x = param_p6.clone();
        let name_p5x = name_p5.clone();
        Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>), crate::syntax::decls::TraitItem)| {
            let info_p2xy = info_p2x.clone();
            let cx_p8xy = cx_p8x.clone();
            let param_p6xy = param_p6x.clone();
            let name_p5xy = name_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (gg_pe, s_pf, ms_pg, ds_ph, assoc_acc_pi) = p0;
                let it_pj = p1;
                match &it_pj {
                    crate::syntax::decls::TraitItem::TiSignature(sg_pk) => {
                        let mname_pl = crate::check::env::def_name_text_f(&sg_pk.name_p);
                        let qk_pm = crate::check::env::qual_key_f(&info_p2xy.name_p, &mname_pl);
                        let sg_pkx = sg_pk.clone();
                        crate::prelude::call_then(crate::check::env::reading::start_sig_scheme_f(cx_p8xy.clone(), s_pf.clone(), sg_pkx.ty_p.clone(), sg_pkx.bounds_p.clone()), move |sig_scheme_f_12556: (crate::check::types::Scheme, crate::check::types::St)| {
                            let (sc_pp, s2_pq) = sig_scheme_f_12556;
                            let sc2_pn = {
                                let mut this: crate::check::types::Scheme = sc_pp.clone();
                                this.qs_p = if crate::check::types::has_text_f(&this.qs_p, &param_p6xy) {
                                    this.qs_p.clone()
                                } else {
                                    crate::prelude::append(&Array::from(vec![param_p6xy.clone()]), &this.qs_p)
                                };
                                this.bounds_p = crate::prelude::append(&Array::from(vec![(param_p6xy.clone(), name_p5xy.clone())]), &this.bounds_p);
                                this
                            };
                            let upd_po = {
                                let mut this: crate::check::env::G = gg_pe.clone();
                                this.vals_p = crate::prelude::insert(&this.vals_p, &qk_pm, &crate::check::env::ValInfo { qk_p: qk_pm.clone(), scheme_p: sc2_pn.clone(), sort_p: Text::lit("method"), has_sig_p: true, home_p: info_p2xy.name_p.clone(), file_p: info_p2xy.file_p.clone(), span_p: sg_pkx.span_p.clone() });
                                this
                            };
                            prism_rtl::Turn::Finished((upd_po.clone(), s2_pq.clone(), crate::prelude::push(&ms_pg, &qk_pm), ds_ph.clone(), assoc_acc_pi.clone()))
                        })
                    },
                    crate::syntax::decls::TraitItem::TiFn(f_pr) => {
                        let qk_ps = crate::check::env::qual_key_f(&info_p2xy.name_p, &crate::check::env::def_name_text_f(&f_pr.name_p));
                        let def_pt = crate::check::env::Def { qk_p: qk_ps.clone(), name_p: crate::check::env::def_name_text_f(&f_pr.name_p), home_p: info_p2xy.name_p.clone(), file_p: info_p2xy.file_p.clone(), span_p: f_pr.span_p.clone(), body_p: crate::check::env::DefBody::DbDefault(Array::from(vec![f_pr.clone()]), name_p5xy.clone()) };
                        let upd_pu = {
                            let mut this: crate::check::env::G = gg_pe.clone();
                            this.defs_p = crate::prelude::push(&this.defs_p, &def_pt);
                            this
                        };
                        prism_rtl::Turn::Finished((upd_pu.clone(), s_pf.clone(), ms_pg.clone(), crate::prelude::push(&ds_ph, &qk_ps), assoc_acc_pi.clone()))
                    },
                    crate::syntax::decls::TraitItem::TiAssocType(n_pv, _, _, _) => prism_rtl::Turn::Finished((gg_pe.clone(), s_pf.clone(), ms_pg.clone(), ds_ph.clone(), crate::prelude::push(&assoc_acc_pi, &n_pv.name_p))),
                    crate::syntax::decls::TraitItem::TiAssocRow(_, r_p10) => prism_rtl::Turn::Finished((gg_pe.clone(), crate::check::types::recording::err_f(&s_pf, &Text::lit("unsupported"), r_p10, &Text::lit("this checker does not implement associated rows")), ms_pg.clone(), ds_ph.clone(), assoc_acc_pi.clone())),
                }
            }))
        }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>), crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>)>>>
    }));
    let ti_p9 = crate::check::env::TraitInfo { name_p: name_p5.clone(), home_p: info_p2.name_p.clone(), param_p: param_p6.clone(), supers_p: crate::prelude::each(&supers_pc, &(|(_, k_p16): &(Text, Text)| k_p16.clone())), methods_p: methods_p13.clone(), defaults_p: defaults_p14.clone(), assocs_p: assocs_p15.clone(), file_p: info_p2.file_p.clone(), span_p: span_p4.clone() };
    let upd3_pa = {
        let mut this: crate::check::env::G = g3_p11.clone();
        this.traits_p = crate::prelude::insert(&this.traits_p, &name_p5, &ti_p9);
        this
    };
    (upd3_pa.clone(), st3_p12.clone())
}

/// The step machine of `ConvTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
/// ```
pub struct ConvTrait {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
    pub t_p3: crate::syntax::decls::TraitDecl,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvTrait {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        let t_p3 = &self.t_p3;
        let span_p4 = &self.span_p4;
        let name_p5 = crate::check::env::qual_key_f(&info_p2.name_p, &crate::check::env::dotted_f(&t_p3.name_p.path_p));
        let param_p6 = crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&t_p3.params_p, &(|p_pb: &crate::syntax::Ident| p_pb.name_p.clone())), &Nat::from(0u32)), &Text::lit("a"));
        let st1_p7 = if &crate::prelude::len(&t_p3.params_p) > &Nat::from(1u32) {
            crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), span_p4, &Text::lit("this checker does not implement traits of several types"))
        } else {
            st_p1.clone()
        };
        let cx_p8 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
        let (supers_pc, st2_pd) = crate::check::env::reading::conv_bounds_f(&cx_p8, &st1_p7, &t_p3.bounds_p);
        let g_p0x = g_p0.clone();
        let info_p2x = info_p2.clone();
        let span_p4x = span_p4.clone();
        let t_p3x = t_p3.clone();
        crate::prelude::call_value(crate::prelude::fold_job(t_p3x.items_p.clone(), (g_p0x.clone(), st2_pd.clone(), Array::new(), Array::new(), Array::new()), {
            let info_p2xx = info_p2x.clone();
            let cx_p8x = cx_p8.clone();
            let param_p6x = param_p6.clone();
            let name_p5x = name_p5.clone();
            Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>), crate::syntax::decls::TraitItem)| {
                let info_p2xxy = info_p2xx.clone();
                let cx_p8xy = cx_p8x.clone();
                let param_p6xy = param_p6x.clone();
                let name_p5xy = name_p5x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (gg_pe, s_pf, ms_pg, ds_ph, assoc_acc_pi) = p0;
                    let it_pj = p1;
                    match &it_pj {
                        crate::syntax::decls::TraitItem::TiSignature(sg_pk) => {
                            let mname_pl = crate::check::env::def_name_text_f(&sg_pk.name_p);
                            let qk_pm = crate::check::env::qual_key_f(&info_p2xxy.name_p, &mname_pl);
                            let sg_pkx = sg_pk.clone();
                            crate::prelude::call_then(crate::check::env::reading::start_sig_scheme_f(cx_p8xy.clone(), s_pf.clone(), sg_pkx.ty_p.clone(), sg_pkx.bounds_p.clone()), move |sig_scheme_f_12556: (crate::check::types::Scheme, crate::check::types::St)| {
                                let (sc_pp, s2_pq) = sig_scheme_f_12556;
                                let sc2_pn = {
                                    let mut this: crate::check::types::Scheme = sc_pp.clone();
                                    this.qs_p = if crate::check::types::has_text_f(&this.qs_p, &param_p6xy) {
                                        this.qs_p.clone()
                                    } else {
                                        crate::prelude::append(&Array::from(vec![param_p6xy.clone()]), &this.qs_p)
                                    };
                                    this.bounds_p = crate::prelude::append(&Array::from(vec![(param_p6xy.clone(), name_p5xy.clone())]), &this.bounds_p);
                                    this
                                };
                                let upd_po = {
                                    let mut this: crate::check::env::G = gg_pe.clone();
                                    this.vals_p = crate::prelude::insert(&this.vals_p, &qk_pm, &crate::check::env::ValInfo { qk_p: qk_pm.clone(), scheme_p: sc2_pn.clone(), sort_p: Text::lit("method"), has_sig_p: true, home_p: info_p2xxy.name_p.clone(), file_p: info_p2xxy.file_p.clone(), span_p: sg_pkx.span_p.clone() });
                                    this
                                };
                                prism_rtl::Turn::Finished((upd_po.clone(), s2_pq.clone(), crate::prelude::push(&ms_pg, &qk_pm), ds_ph.clone(), assoc_acc_pi.clone()))
                            })
                        },
                        crate::syntax::decls::TraitItem::TiFn(f_pr) => {
                            let qk_ps = crate::check::env::qual_key_f(&info_p2xxy.name_p, &crate::check::env::def_name_text_f(&f_pr.name_p));
                            let def_pt = crate::check::env::Def { qk_p: qk_ps.clone(), name_p: crate::check::env::def_name_text_f(&f_pr.name_p), home_p: info_p2xxy.name_p.clone(), file_p: info_p2xxy.file_p.clone(), span_p: f_pr.span_p.clone(), body_p: crate::check::env::DefBody::DbDefault(Array::from(vec![f_pr.clone()]), name_p5xy.clone()) };
                            let upd_pu = {
                                let mut this: crate::check::env::G = gg_pe.clone();
                                this.defs_p = crate::prelude::push(&this.defs_p, &def_pt);
                                this
                            };
                            prism_rtl::Turn::Finished((upd_pu.clone(), s_pf.clone(), ms_pg.clone(), crate::prelude::push(&ds_ph, &qk_ps), assoc_acc_pi.clone()))
                        },
                        crate::syntax::decls::TraitItem::TiAssocType(n_pv, _, _, _) => prism_rtl::Turn::Finished((gg_pe.clone(), s_pf.clone(), ms_pg.clone(), ds_ph.clone(), crate::prelude::push(&assoc_acc_pi, &n_pv.name_p))),
                        crate::syntax::decls::TraitItem::TiAssocRow(_, r_p10) => prism_rtl::Turn::Finished((gg_pe.clone(), crate::check::types::recording::err_f(&s_pf, &Text::lit("unsupported"), r_p10, &Text::lit("this checker does not implement associated rows")), ms_pg.clone(), ds_ph.clone(), assoc_acc_pi.clone())),
                    }
                }))
            }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>), crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>)>>>
        }), move |fold_12324: (crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>)| {
            let (g3_p11, st3_p12, methods_p13, defaults_p14, assocs_p15) = fold_12324;
            let ti_p9 = crate::check::env::TraitInfo { name_p: name_p5.clone(), home_p: info_p2x.name_p.clone(), param_p: param_p6.clone(), supers_p: crate::prelude::each(&supers_pc, &(|(_, k_p16): &(Text, Text)| k_p16.clone())), methods_p: methods_p13.clone(), defaults_p: defaults_p14.clone(), assocs_p: assocs_p15.clone(), file_p: info_p2x.file_p.clone(), span_p: span_p4x.clone() };
            let upd3_pa = {
                let mut this: crate::check::env::G = g3_p11.clone();
                this.traits_p = crate::prelude::insert(&this.traits_p, &name_p5, &ti_p9);
                this
            };
            prism_rtl::Turn::Finished((upd3_pa.clone(), st3_p12.clone()))
        })
    }
}

/// `Start ConvTrait, x`: what the function value is when passed to `@Run`.
pub fn start_conv_trait_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo, t_p3: crate::syntax::decls::TraitDecl, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvTrait { g_p0, st_p1, info_p2, t_p3, span_p4 })
}

/// ```prism
/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
/// ```
pub fn conv_impl_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, info_p2: &crate::check::env::ModInfo, i_p3: &crate::syntax::decls::ImplDecl, span_p4: &crate::syntax::Range) -> (crate::check::env::G, crate::check::types::St) {
    match crate::check::env::names::resolve_trait_o(g_p0, &info_p2.name_p, &i_p3.trait_ref_p.path_p) {
        None => (g_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), &i_p3.trait_ref_p.span_p, &Text::from(format!("no trait `^{}`", &crate::check::env::dotted_f(&i_p3.trait_ref_p.path_p))))),
        Some(cls_p5) => {
            let cx_p6 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
            let (head_pb, st2_pc) = crate::check::env::reading::conv_type_f(&cx_p6, st_p1, &i_p3.ty_p);
            let (bs_pd, st3_pe) = crate::check::env::reading::conv_bounds_f(&cx_p6, &st2_pc, &i_p3.bounds_p);
            let (assocs_pm, st4_pn) = crate::prelude::run_to_end(crate::prelude::fold_job(i_p3.items_p.clone(), (Array::new(), st3_pe.clone()), {
                let cx_p6x = cx_p6.clone();
                Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)| {
                    let cx_p6xy = cx_p6x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (acc_pf, s_pg) = p0;
                        let it_ph = p1;
                        match &it_ph {
                            crate::syntax::decls::TraitItem::TiAssocType(n_pi, _, Some(v_pj), _) => {
                                let n_pix = n_pi.clone();
                                let v_pjx = v_pj.clone();
                                crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p6xy.clone(), s_pg.clone(), v_pjx.clone()), move |conv_type_f_14573: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (vt_pk, s2_pl) = conv_type_f_14573;
                                    prism_rtl::Turn::Finished((crate::prelude::push(&acc_pf, &(n_pix.name_p.clone(), vt_pk.clone())), s2_pl.clone()))
                                })
                            },
                            _ => prism_rtl::Turn::Finished((acc_pf.clone(), s_pg.clone())),
                        }
                    }))
                }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
            }));
            let names_p7 = crate::prelude::fold(&i_p3.items_p, &Array::new(), &(|acc_po: &Array<Text>, it_pp: &crate::syntax::decls::TraitItem| match it_pp {
                crate::syntax::decls::TraitItem::TiFn(f_pq) => crate::check::types::add_text_f(acc_po, &crate::check::env::def_name_text_f(&f_pq.name_p)),
                _ => acc_po.clone(),
            }));
            let im_p8 = crate::check::env::ImplInfo { cls_p: cls_p5.clone(), head_p: head_pb.clone(), qs_p: crate::check::env::reading::type_vars_of_type_f(&i_p3.ty_p), bounds_p: bs_pd.clone(), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: span_p4.clone(), derived_p: false, assocs_p: assocs_pm.clone(), methods_p: names_p7.clone() };
            let g2_p9 = {
                let mut this: crate::check::env::G = g_p0.clone();
                this.impls_p = crate::prelude::insert(&this.impls_p, &cls_p5, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(&this.impls_p, &cls_p5), &Array::new()), &im_p8));
                this
            };
            let g3_pa = crate::prelude::fold(&names_p7, &g2_p9, &(|gg_pr: &crate::check::env::G, mname_ps: &Text| {
                let clauses_pt = crate::prelude::fold(&i_p3.items_p, &Array::new(), &(|acc_pu: &Array<crate::syntax::decls::FnClause>, it_pv: &crate::syntax::decls::TraitItem| match it_pv {
                    crate::syntax::decls::TraitItem::TiFn(f_p10) => if &crate::check::env::def_name_text_f(&f_p10.name_p) == mname_ps {
                        crate::prelude::push(acc_pu, f_p10)
                    } else {
                        acc_pu.clone()
                    },
                    _ => acc_pu.clone(),
                }));
                {
                    let mut this: crate::check::env::G = gg_pr.clone();
                    this.defs_p = crate::prelude::push(&this.defs_p, &crate::check::env::Def { qk_p: Text::from(format!("{} impl {}", &cls_p5, mname_ps)), name_p: mname_ps.clone(), home_p: info_p2.name_p.clone(), file_p: info_p2.file_p.clone(), span_p: span_p4.clone(), body_p: crate::check::env::DefBody::DbMethod(clauses_pt.clone(), cls_p5.clone(), im_p8.clone()) });
                    this
                }
            }));
            (g3_pa.clone(), st4_pn.clone())
        },
    }
}

/// The step machine of `ConvImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
/// ```
pub struct ConvImpl {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub info_p2: crate::check::env::ModInfo,
    pub i_p3: crate::syntax::decls::ImplDecl,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvImpl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let info_p2 = &self.info_p2;
        let i_p3 = &self.i_p3;
        let span_p4 = &self.span_p4;
        match crate::check::env::names::resolve_trait_o(g_p0, &info_p2.name_p, &i_p3.trait_ref_p.path_p) {
            None => prism_rtl::Turn::Finished((g_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), &i_p3.trait_ref_p.span_p, &Text::from(format!("no trait `^{}`", &crate::check::env::dotted_f(&i_p3.trait_ref_p.path_p)))))),
            Some(cls_p5) => {
                let cx_p6 = crate::check::env::reading::cx_of_f(g_p0, &info_p2.name_p);
                let g_p0x = g_p0.clone();
                let i_p3x = i_p3.clone();
                let info_p2x = info_p2.clone();
                let span_p4x = span_p4.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p6.clone(), st_p1x.clone(), i_p3x.ty_p.clone()), move |conv_type_f_14326: (crate::check::types::Ty, crate::check::types::St)| {
                    let (head_pb, st2_pc) = conv_type_f_14326;
                    let (bs_pd, st3_pe) = crate::check::env::reading::conv_bounds_f(&cx_p6, &st2_pc, &i_p3x.bounds_p);
                    crate::prelude::call_value(crate::prelude::fold_job(i_p3x.items_p.clone(), (Array::new(), st3_pe.clone()), {
                        let cx_p6x = cx_p6.clone();
                        Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)| {
                            let cx_p6xy = cx_p6x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (acc_pf, s_pg) = p0;
                                let it_ph = p1;
                                match &it_ph {
                                    crate::syntax::decls::TraitItem::TiAssocType(n_pi, _, Some(v_pj), _) => {
                                        let n_pix = n_pi.clone();
                                        let v_pjx = v_pj.clone();
                                        crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p6xy.clone(), s_pg.clone(), v_pjx.clone()), move |conv_type_f_14573: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (vt_pk, s2_pl) = conv_type_f_14573;
                                            prism_rtl::Turn::Finished((crate::prelude::push(&acc_pf, &(n_pix.name_p.clone(), vt_pk.clone())), s2_pl.clone()))
                                        })
                                    },
                                    _ => prism_rtl::Turn::Finished((acc_pf.clone(), s_pg.clone())),
                                }
                            }))
                        }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
                    }), move |fold_14433: (Array<(Text, crate::check::types::Ty)>, crate::check::types::St)| {
                        let (assocs_pm, st4_pn) = fold_14433;
                        let names_p7 = crate::prelude::fold(&i_p3x.items_p, &Array::new(), &(|acc_po: &Array<Text>, it_pp: &crate::syntax::decls::TraitItem| match it_pp {
                            crate::syntax::decls::TraitItem::TiFn(f_pq) => crate::check::types::add_text_f(acc_po, &crate::check::env::def_name_text_f(&f_pq.name_p)),
                            _ => acc_po.clone(),
                        }));
                        crate::prelude::call_then(crate::check::env::reading::start_type_vars_of_type_f(i_p3x.ty_p.clone()), move |type_vars_of_type_f_14868: Array<Text>| {
                            let im_p8 = crate::check::env::ImplInfo { cls_p: cls_p5.clone(), head_p: head_pb.clone(), qs_p: type_vars_of_type_f_14868, bounds_p: bs_pd.clone(), home_p: info_p2x.name_p.clone(), file_p: info_p2x.file_p.clone(), span_p: span_p4x.clone(), derived_p: false, assocs_p: assocs_pm.clone(), methods_p: names_p7.clone() };
                            let g2_p9 = {
                                let mut this: crate::check::env::G = g_p0x.clone();
                                this.impls_p = crate::prelude::insert(&this.impls_p, &cls_p5, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(&this.impls_p, &cls_p5), &Array::new()), &im_p8));
                                this
                            };
                            let g3_pa = crate::prelude::fold(&names_p7, &g2_p9, &(|gg_pr: &crate::check::env::G, mname_ps: &Text| {
                                let clauses_pt = crate::prelude::fold(&i_p3x.items_p, &Array::new(), &(|acc_pu: &Array<crate::syntax::decls::FnClause>, it_pv: &crate::syntax::decls::TraitItem| match it_pv {
                                    crate::syntax::decls::TraitItem::TiFn(f_p10) => if &crate::check::env::def_name_text_f(&f_p10.name_p) == mname_ps {
                                        crate::prelude::push(acc_pu, f_p10)
                                    } else {
                                        acc_pu.clone()
                                    },
                                    _ => acc_pu.clone(),
                                }));
                                {
                                    let mut this: crate::check::env::G = gg_pr.clone();
                                    this.defs_p = crate::prelude::push(&this.defs_p, &crate::check::env::Def { qk_p: Text::from(format!("{} impl {}", &cls_p5, mname_ps)), name_p: mname_ps.clone(), home_p: info_p2x.name_p.clone(), file_p: info_p2x.file_p.clone(), span_p: span_p4x.clone(), body_p: crate::check::env::DefBody::DbMethod(clauses_pt.clone(), cls_p5.clone(), im_p8.clone()) });
                                    this
                                }
                            }));
                            prism_rtl::Turn::Finished((g3_pa.clone(), st4_pn.clone()))
                        })
                    })
                })
            },
        }
    }
}

/// `Start ConvImpl, x`: what the function value is when passed to `@Run`.
pub fn start_conv_impl_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, info_p2: crate::check::env::ModInfo, i_p3: crate::syntax::decls::ImplDecl, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvImpl { g_p0, st_p1, info_p2, i_p3, span_p4 })
}
