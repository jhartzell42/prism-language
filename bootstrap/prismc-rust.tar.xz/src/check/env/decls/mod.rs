//! The module `Check.Env.Decls`, from `target/bootstrap/src/prismc/check/env/decls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn convert_types(g: &crate::check::env::G, st: &crate::check::types::St, m: &Text) -> (crate::check::env::G, crate::check::types::St) {
    match get(&g.mods, m) {
        None => (g.clone(), st.clone()),
        Some(info) => {
            let s0 = {
                let mut this: crate::check::types::St = st.clone();
                this.file = info.file.clone();
                this
            };
            run_to_end(fold_job(info.tree.decls.clone(), (g.clone(), s0.clone()), {
                let info = info.clone();
                Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)| {
                    let info = info.clone();
                    entered(once_job(move || {
                        let (gg, s) = p0;
                        let d = p1;
                        prism_rtl::Turn::More(Rc::new(ConvertTypeDecl { g: gg.clone(), st: s.clone(), info: info.clone(), d: d.clone() }))
                    }))
                }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
            }))
        },
    }
}

/// The step machine of `ConvertTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct ConvertTypes {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub m: Text,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvertTypes {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let m = &self.m;
        match get(&g.mods, m) {
            None => prism_rtl::Turn::Finished((g.clone(), st.clone())),
            Some(info) => {
                let s0 = {
                    let mut this: crate::check::types::St = st.clone();
                    this.file = info.file.clone();
                    this
                };
                fold_job(info.tree.decls.clone(), (g.clone(), s0.clone()), {
                    let info = info.clone();
                    Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)| {
                        let info = info.clone();
                        entered(once_job(move || {
                            let (gg, s) = p0;
                            let d = p1;
                            prism_rtl::Turn::More(Rc::new(ConvertTypeDecl { g: gg.clone(), st: s.clone(), info: info.clone(), d: d.clone() }))
                        }))
                    }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
                }).cycle()
            },
        }
    }
}

/// `Start ConvertTypes, x`: what the function value is when passed to `@Run`.
pub fn start_convert_types(g: crate::check::env::G, st: crate::check::types::St, m: Text) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvertTypes { g, st, m })
}

/// ```prism
/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
/// ```
pub fn convert_decls(g: &crate::check::env::G, st: &crate::check::types::St, m: &Text) -> (crate::check::env::G, crate::check::types::St) {
    match get(&g.mods, m) {
        None => (g.clone(), st.clone()),
        Some(info) => {
            let s1 = {
                let mut this: crate::check::types::St = st.clone();
                this.file = info.file.clone();
                this
            };
            let (g2, s2) = run_to_end(fold_job(info.tree.decls.clone(), (g.clone(), s1.clone()), {
                let info = info.clone();
                Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)| {
                    let info = info.clone();
                    entered(once_job(move || {
                        let (gg, s) = p0;
                        let d = p1;
                        prism_rtl::Turn::More(Rc::new(ConvertDecl { g: gg.clone(), st: s.clone(), info: info.clone(), d: d.clone() }))
                    }))
                }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
            }));
            let s3 = missing_signatures(&g2, &s2, &info);
            (g2.clone(), s3.clone())
        },
    }
}

/// The step machine of `ConvertDecls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
/// ```
pub struct ConvertDecls {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub m: Text,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvertDecls {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let m = &self.m;
        match get(&g.mods, m) {
            None => prism_rtl::Turn::Finished((g.clone(), st.clone())),
            Some(info) => {
                let s1 = {
                    let mut this: crate::check::types::St = st.clone();
                    this.file = info.file.clone();
                    this
                };
                let g = g.clone();
                call_value(fold_job(info.tree.decls.clone(), (g.clone(), s1.clone()), {
                    let info = info.clone();
                    Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)| {
                        let info = info.clone();
                        entered(once_job(move || {
                            let (gg, s) = p0;
                            let d = p1;
                            prism_rtl::Turn::More(Rc::new(ConvertDecl { g: gg.clone(), st: s.clone(), info: info.clone(), d: d.clone() }))
                        }))
                    }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St), crate::syntax::decls::Decl)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>
                }), move |fold_1281: (crate::check::env::G, crate::check::types::St)| {
                    let (g2, s2) = fold_1281;
                    let s3 = missing_signatures(&g2, &s2, &info);
                    prism_rtl::Turn::Finished((g2.clone(), s3.clone()))
                })
            },
        }
    }
}

/// `Start ConvertDecls, x`: what the function value is when passed to `@Run`.
pub fn start_convert_decls(g: crate::check::env::G, st: crate::check::types::St, m: Text) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvertDecls { g, st, m })
}

/// ```prism
/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub fn convert_type_decl(g: &crate::check::env::G, st: &crate::check::types::St, info: &crate::check::env::ModInfo, d: &crate::syntax::decls::Decl) -> (crate::check::env::G, crate::check::types::St) {
    match &d.kind {
        crate::syntax::decls::DeclKind::DType(t) => {
            let name = crate::check::env::qual_key(&info.name, &crate::check::env::dotted(&t.name.path_));
            let ti = or(&get(&g.types, &name), &crate::check::env::names::dummy_ty_info());
            let cx_ = crate::check::env::reading::cx_of(g, &info.name);
            let params = each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone()));
            let self_ = crate::check::types::Ty::TyCon(name.clone(), each(&params, &(|p_: &Text| crate::check::types::Ty::TyQ(p_.clone()))));
            match &t.body {
                None => (g.clone(), st.clone()),
                Some(body) => match body {
                    crate::syntax::decls::TypeBody::TbRecord(fs) => {
                        let (fields, st2) = run_to_end(fold_job(fs.clone(), (Array::new(), st.clone()), {
                            let cx_ = cx_.clone();
                            Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)| {
                                let cx_ = cx_.clone();
                                entered(once_job(move || {
                                    let (acc, s) = p0;
                                    let f = p1;
                                    call_then(crate::check::env::reading::start_conv_type(cx_.clone(), s.clone(), f.ty.clone()), move |conv_type_2032: (crate::check::types::Ty, crate::check::types::St)| {
                                        let (ft, s2) = conv_type_2032;
                                        prism_rtl::Turn::Finished((push(&acc, &(f.name.name.clone(), ft.clone())), s2.clone()))
                                    })
                                }))
                            }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
                        }));
                        let ctor = crate::check::env::CtorInfo { name: name.clone(), owner: name.clone(), params: params.clone(), args: each(&fields, &(|(_, ft): &(Text, crate::check::types::Ty)| ft.clone())), fields: each(&fields, &(|(fname, _): &(Text, crate::check::types::Ty)| fname.clone())), ty: self_.clone(), index: Nat::from(0u32) };
                        let upd = {
                            let mut this: crate::check::env::G = g.clone();
                            this.types = insert(&this.types, &name, &with_body(&ti, &crate::check::env::TyBody::BRecord(fields.clone())));
                            this.ctors = insert(&this.ctors, &name, &ctor);
                            this
                        };
                        (upd.clone(), st2.clone())
                    },
                    crate::syntax::decls::TypeBody::TbChoice(cs) => conv_cases(g, st, &cx_, &ti, &name, &params, &self_, cs),
                    crate::syntax::decls::TypeBody::TbNewtype(c) => conv_cases(g, st, &cx_, &ti, &name, &params, &self_, &Array::from(vec![c.clone()])),
                    crate::syntax::decls::TypeBody::TbUnit(i) => {
                        let ctor = crate::check::env::CtorInfo { name: crate::check::env::qual_key(&info.name, &i.name), owner: name.clone(), params: params.clone(), args: Array::new(), fields: Array::new(), ty: self_.clone(), index: Nat::from(0u32) };
                        let upd = {
                            let mut this: crate::check::env::G = g.clone();
                            this.types = insert(&this.types, &name, &with_body(&ti, &crate::check::env::TyBody::BChoice(Array::from(vec![(i.name.clone(), Array::new())]))));
                            this.ctors = insert(&this.ctors, &crate::check::env::qual_key(&info.name, &i.name), &ctor);
                            this
                        };
                        (upd.clone(), st.clone())
                    },
                    crate::syntax::decls::TypeBody::TbRow => {
                        let upd = {
                            let mut this: crate::check::env::G = g.clone();
                            this.types = insert(&this.types, &name, &with_body(&ti, &crate::check::env::TyBody::BRowKind));
                            this
                        };
                        (upd.clone(), st.clone())
                    },
                    crate::syntax::decls::TypeBody::TbAlias(a) => {
                        let (at_, st2) = crate::check::env::reading::conv_type(&cx_, st, a);
                        let upd = {
                            let mut this: crate::check::env::G = g.clone();
                            this.types = insert(&this.types, &name, &with_body(&ti, &crate::check::env::TyBody::BAlias(at_.clone())));
                            this
                        };
                        (upd.clone(), st2.clone())
                    },
                },
            }
        },
        _ => (g.clone(), st.clone()),
    }
}

/// The step machine of `ConvertTypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub struct ConvertTypeDecl {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub info: crate::check::env::ModInfo,
    pub d: crate::syntax::decls::Decl,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvertTypeDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let info = &self.info;
        let d = &self.d;
        match &d.kind {
            crate::syntax::decls::DeclKind::DType(t) => {
                let name = crate::check::env::qual_key(&info.name, &crate::check::env::dotted(&t.name.path_));
                let ti = or(&get(&g.types, &name), &crate::check::env::names::dummy_ty_info());
                let cx_ = crate::check::env::reading::cx_of(g, &info.name);
                let params = each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone()));
                let self_ = crate::check::types::Ty::TyCon(name.clone(), each(&params, &(|p_: &Text| crate::check::types::Ty::TyQ(p_.clone()))));
                match &t.body {
                    None => prism_rtl::Turn::Finished((g.clone(), st.clone())),
                    Some(body) => match body {
                        crate::syntax::decls::TypeBody::TbRecord(fs) => {
                            let fs = fs.clone();
                            let g = g.clone();
                            let st = st.clone();
                            call_value(fold_job(fs.clone(), (Array::new(), st.clone()), {
                                let cx_ = cx_.clone();
                                Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)| {
                                    let cx_ = cx_.clone();
                                    entered(once_job(move || {
                                        let (acc, s) = p0;
                                        let f = p1;
                                        call_then(crate::check::env::reading::start_conv_type(cx_.clone(), s.clone(), f.ty.clone()), move |conv_type_2032: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (ft, s2) = conv_type_2032;
                                            prism_rtl::Turn::Finished((push(&acc, &(f.name.name.clone(), ft.clone())), s2.clone()))
                                        })
                                    }))
                                }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
                            }), move |fold_1951: (Array<(Text, crate::check::types::Ty)>, crate::check::types::St)| {
                                let (fields, st2) = fold_1951;
                                let ctor = crate::check::env::CtorInfo { name: name.clone(), owner: name.clone(), params: params.clone(), args: each(&fields, &(|(_, ft): &(Text, crate::check::types::Ty)| ft.clone())), fields: each(&fields, &(|(fname, _): &(Text, crate::check::types::Ty)| fname.clone())), ty: self_.clone(), index: Nat::from(0u32) };
                                let upd = {
                                    let mut this: crate::check::env::G = g.clone();
                                    this.types = insert(&this.types, &name, &with_body(&ti, &crate::check::env::TyBody::BRecord(fields.clone())));
                                    this.ctors = insert(&this.ctors, &name, &ctor);
                                    this
                                };
                                prism_rtl::Turn::Finished((upd.clone(), st2.clone()))
                            })
                        },
                        crate::syntax::decls::TypeBody::TbChoice(cs) => prism_rtl::Turn::More(Rc::new(ConvCases { g: g.clone(), st: st.clone(), cx_: cx_.clone(), ti: ti.clone(), name: name.clone(), params: params.clone(), self_: self_.clone(), cs: cs.clone() })),
                        crate::syntax::decls::TypeBody::TbNewtype(c) => prism_rtl::Turn::More(Rc::new(ConvCases { g: g.clone(), st: st.clone(), cx_: cx_.clone(), ti: ti.clone(), name: name.clone(), params: params.clone(), self_: self_.clone(), cs: Array::from(vec![c.clone()]) })),
                        crate::syntax::decls::TypeBody::TbUnit(i) => {
                            let ctor = crate::check::env::CtorInfo { name: crate::check::env::qual_key(&info.name, &i.name), owner: name.clone(), params: params.clone(), args: Array::new(), fields: Array::new(), ty: self_.clone(), index: Nat::from(0u32) };
                            let upd = {
                                let mut this: crate::check::env::G = g.clone();
                                this.types = insert(&this.types, &name, &with_body(&ti, &crate::check::env::TyBody::BChoice(Array::from(vec![(i.name.clone(), Array::new())]))));
                                this.ctors = insert(&this.ctors, &crate::check::env::qual_key(&info.name, &i.name), &ctor);
                                this
                            };
                            prism_rtl::Turn::Finished((upd.clone(), st.clone()))
                        },
                        crate::syntax::decls::TypeBody::TbRow => {
                            let upd = {
                                let mut this: crate::check::env::G = g.clone();
                                this.types = insert(&this.types, &name, &with_body(&ti, &crate::check::env::TyBody::BRowKind));
                                this
                            };
                            prism_rtl::Turn::Finished((upd.clone(), st.clone()))
                        },
                        crate::syntax::decls::TypeBody::TbAlias(a) => {
                            let a = a.clone();
                            let g = g.clone();
                            let st = st.clone();
                            call_then(crate::check::env::reading::start_conv_type(cx_.clone(), st.clone(), a.clone()), move |conv_type_3366: (crate::check::types::Ty, crate::check::types::St)| {
                                let (at_, st2) = conv_type_3366;
                                let upd = {
                                    let mut this: crate::check::env::G = g.clone();
                                    this.types = insert(&this.types, &name, &with_body(&ti, &crate::check::env::TyBody::BAlias(at_.clone())));
                                    this
                                };
                                prism_rtl::Turn::Finished((upd.clone(), st2.clone()))
                            })
                        },
                    },
                }
            },
            _ => prism_rtl::Turn::Finished((g.clone(), st.clone())),
        }
    }
}

/// `Start ConvertTypeDecl, x`: what the function value is when passed to `@Run`.
pub fn start_convert_type_decl(g: crate::check::env::G, st: crate::check::types::St, info: crate::check::env::ModInfo, d: crate::syntax::decls::Decl) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvertTypeDecl { g, st, info, d })
}

/// ```prism
/// WithBody: fn TyInfo, TyBody -> TyInfo
/// ```
pub fn with_body(ti: &crate::check::env::TyInfo, b: &crate::check::env::TyBody) -> crate::check::env::TyInfo {
    let mut this: crate::check::env::TyInfo = ti.clone();
    this.body = b.clone();
    this
}

/// ```prism
/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
/// ```
pub fn conv_cases(g: &crate::check::env::G, st: &crate::check::types::St, cx_: &crate::check::env::reading::Cx_, ti: &crate::check::env::TyInfo, name: &Text, params: &Array<Text>, self_: &crate::check::types::Ty, cs: &Array<crate::syntax::decls::Case_>) -> (crate::check::env::G, crate::check::types::St) {
    let (cases, st2) = run_to_end(fold_job(cs.clone(), (Array::new(), st.clone()), {
        let cx_ = cx_.clone();
        Rc::new(move |(p0, p1): ((Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::decls::Case_)| {
            let cx_ = cx_.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let c = p1;
                {
                    let s1 = match &c.indexed {
                        Some(_) => crate::check::types::recording::err(&s, &Text::lit("unsupported"), &c.span, &Text::lit("this checker does not implement indexed choices for user types")),
                        None => s.clone(),
                    };
                    call_then(crate::check::env::reading::start_conv_types(cx_.clone(), s1.clone(), c.args.clone()), move |conv_types_4053: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                        let (args, s2) = conv_types_4053;
                        prism_rtl::Turn::Finished((push(&acc, &(crate::check::env::sname_key(&c.name), args.clone())), s2.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::decls::Case_)) -> Rc<dyn prism_rtl::Job<(Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St)>>>
    }));
    let g2 = fold(&crate::check::errors::range0(&len(&cases)), g, &(|gg: &crate::check::env::G, i: &Nat| {
        let (cn, args) = or(&index(&cases, i), &(Text::lit(""), Array::new()));
        let qk = crate::check::env::qual_key(&ti.home, &cn);
        {
            let mut this: crate::check::env::G = gg.clone();
            this.ctors = insert(&this.ctors, &qk, &crate::check::env::CtorInfo { name: qk.clone(), owner: name.clone(), params: params.clone(), args: args.clone(), fields: Array::new(), ty: self_.clone(), index: i.clone() });
            this
        }
    }));
    let upd = {
        let mut this: crate::check::env::G = g2.clone();
        this.types = insert(&this.types, name, &with_body(ti, &crate::check::env::TyBody::BChoice(cases.clone())));
        this
    };
    (upd.clone(), st2.clone())
}

/// The step machine of `ConvCases`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
/// ```
pub struct ConvCases {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub cx_: crate::check::env::reading::Cx_,
    pub ti: crate::check::env::TyInfo,
    pub name: Text,
    pub params: Array<Text>,
    pub self_: crate::check::types::Ty,
    pub cs: Array<crate::syntax::decls::Case_>,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvCases {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let cx_ = &self.cx_;
        let ti = &self.ti;
        let name = &self.name;
        let params = &self.params;
        let self_ = &self.self_;
        let cs = &self.cs;
        let cs = cs.clone();
        let cx_ = cx_.clone();
        let g = g.clone();
        let name = name.clone();
        let params = params.clone();
        let self_ = self_.clone();
        let st = st.clone();
        let ti = ti.clone();
        call_value(fold_job(cs.clone(), (Array::new(), st.clone()), {
            let cx_ = cx_.clone();
            Rc::new(move |(p0, p1): ((Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::decls::Case_)| {
                let cx_ = cx_.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let c = p1;
                    {
                        let s1 = match &c.indexed {
                            Some(_) => crate::check::types::recording::err(&s, &Text::lit("unsupported"), &c.span, &Text::lit("this checker does not implement indexed choices for user types")),
                            None => s.clone(),
                        };
                        call_then(crate::check::env::reading::start_conv_types(cx_.clone(), s1.clone(), c.args.clone()), move |conv_types_4053: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                            let (args, s2) = conv_types_4053;
                            prism_rtl::Turn::Finished((push(&acc, &(crate::check::env::sname_key(&c.name), args.clone())), s2.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St), crate::syntax::decls::Case_)) -> Rc<dyn prism_rtl::Job<(Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St)>>>
        }), move |fold_3815: (Array<(Text, Array<crate::check::types::Ty>)>, crate::check::types::St)| {
            let (cases, st2) = fold_3815;
            let g2 = fold(&crate::check::errors::range0(&len(&cases)), &g, &(|gg: &crate::check::env::G, i: &Nat| {
                let (cn, args) = or(&index(&cases, i), &(Text::lit(""), Array::new()));
                let qk = crate::check::env::qual_key(&ti.home, &cn);
                {
                    let mut this: crate::check::env::G = gg.clone();
                    this.ctors = insert(&this.ctors, &qk, &crate::check::env::CtorInfo { name: qk.clone(), owner: name.clone(), params: params.clone(), args: args.clone(), fields: Array::new(), ty: self_.clone(), index: i.clone() });
                    this
                }
            }));
            let upd = {
                let mut this: crate::check::env::G = g2.clone();
                this.types = insert(&this.types, &name, &with_body(&ti, &crate::check::env::TyBody::BChoice(cases.clone())));
                this
            };
            prism_rtl::Turn::Finished((upd.clone(), st2.clone()))
        })
    }
}

/// `Start ConvCases, x`: what the function value is when passed to `@Run`.
pub fn start_conv_cases(g: crate::check::env::G, st: crate::check::types::St, cx_: crate::check::env::reading::Cx_, ti: crate::check::env::TyInfo, name: Text, params: Array<Text>, self_: crate::check::types::Ty, cs: Array<crate::syntax::decls::Case_>) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvCases { g, st, cx_, ti, name, params, self_, cs })
}

/// ```prism
/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub fn convert_decl(g: &crate::check::env::G, st: &crate::check::types::St, info: &crate::check::env::ModInfo, d: &crate::syntax::decls::Decl) -> (crate::check::env::G, crate::check::types::St) {
    match &d.kind {
        crate::syntax::decls::DeclKind::DSignature(s) => {
            let qk = crate::check::env::qual_key(&info.name, &crate::check::env::def_name_text(&s.name));
            let cx_ = crate::check::env::reading::cx_of(g, &info.name);
            let (sc, st1) = crate::check::env::reading::sig_scheme(&cx_, st, &s.ty, &s.bounds);
            let st2 = lens_check(&st1, &crate::check::env::def_name_text(&s.name), &s.ty, &crate::check::env::def_name_span(&s.name));
            let st3 = check_mark_function(&st2, &crate::check::env::def_name_text(&s.name), &sc.ty, &crate::check::env::def_name_span(&s.name));
            if crate::check::env::has_key(&g.vals, &qk) {
                (g.clone(), crate::check::types::recording::err(&st3, &Text::lit("collision"), &d.span, &Text::from(format!("a second signature for `{}`", &crate::check::env::def_name_text(&s.name)))))
            } else {
                {
                    let upd = {
                        let mut this: crate::check::env::G = g.clone();
                        this.vals = insert(&this.vals, &qk, &crate::check::env::ValInfo { qk: qk.clone(), scheme: sc.clone(), sort: Text::lit("fn"), has_sig: true, home: info.name.clone(), file: info.file.clone(), span: d.span.clone() });
                        this
                    };
                    (upd.clone(), st3.clone())
                }
            }
        },
        crate::syntax::decls::DeclKind::DFn(f) => {
            let qk = crate::check::env::qual_key(&info.name, &crate::check::env::def_name_text(&f.name));
            (add_clause(g, info, &qk, &crate::check::env::def_name_text(&f.name), f, &d.span, st), st.clone())
        },
        crate::syntax::decls::DeclKind::DLet(l) => {
            let names = crate::check::env::names::pattern_names(&l.pattern);
            let qk = crate::check::env::qual_key(&info.name, &or(&index(&names, &Nat::from(0u32)), &Text::lit("")));
            let def = crate::check::env::Def { qk: qk.clone(), name: or(&index(&names, &Nat::from(0u32)), &Text::lit("")), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: crate::check::env::DefBody::DbLet(l.clone()) };
            let upd = {
                let mut this: crate::check::env::G = g.clone();
                this.defs = push(&this.defs, &def);
                this
            };
            (upd.clone(), st.clone())
        },
        crate::syntax::decls::DeclKind::DWidget(w) => {
            let qk = crate::check::env::qual_key(&info.name, &crate::check::env::sname_key(&w.name));
            let def = crate::check::env::Def { qk: qk.clone(), name: crate::check::env::sname_key(&w.name), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: crate::check::env::DefBody::DbWidget(w.clone()) };
            let upd = {
                let mut this: crate::check::env::G = g.clone();
                this.defs = push(&this.defs, &def);
                this
            };
            (upd.clone(), st.clone())
        },
        crate::syntax::decls::DeclKind::DTag(t) => conv_tag(g, st, info, t, &d.span),
        crate::syntax::decls::DeclKind::DTrait(t) => conv_trait(g, st, info, t, &d.span),
        crate::syntax::decls::DeclKind::DImpl(i) => conv_impl(g, st, info, i, &d.span),
        crate::syntax::decls::DeclKind::DCheck(c) => {
            let upd = {
                let mut this: crate::check::env::G = g.clone();
                this.defs = push(&this.defs, &crate::check::env::Def { qk: crate::check::env::qual_key(&info.name, &Text::from(format!("check {}", &c.name.name))), name: c.name.name.clone(), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: crate::check::env::DefBody::DbCheck(c.clone()) });
                this
            };
            (upd.clone(), st.clone())
        },
        crate::syntax::decls::DeclKind::DTest(t) => {
            let upd = {
                let mut this: crate::check::env::G = g.clone();
                this.defs = push(&this.defs, &crate::check::env::Def { qk: crate::check::env::qual_key(&info.name, &Text::from(format!("test {}", &t.name.name))), name: t.name.name.clone(), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: crate::check::env::DefBody::DbTest(t.clone()) });
                this
            };
            (upd.clone(), st.clone())
        },
        crate::syntax::decls::DeclKind::DStmt(s) => match &s.kind {
            crate::syntax::StmtKind::SEmit(_) => (g.clone(), st.clone()),
            _ => (g.clone(), crate::check::types::recording::err(st, &Text::lit("unsupported"), &d.span, &Text::lit("a statement at the top of a file: nothing at top level is built"))),
        },
        _ => (g.clone(), st.clone()),
    }
}

/// The step machine of `ConvertDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
/// ```
pub struct ConvertDecl {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub info: crate::check::env::ModInfo,
    pub d: crate::syntax::decls::Decl,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvertDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let info = &self.info;
        let d = &self.d;
        match &d.kind {
            crate::syntax::decls::DeclKind::DSignature(s) => {
                let qk = crate::check::env::qual_key(&info.name, &crate::check::env::def_name_text(&s.name));
                let cx_ = crate::check::env::reading::cx_of(g, &info.name);
                let d = d.clone();
                let g = g.clone();
                let info = info.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(crate::check::env::reading::start_sig_scheme(cx_.clone(), st.clone(), s.ty.clone(), s.bounds.clone()), move |sig_scheme_4784: (crate::check::types::Scheme, crate::check::types::St)| {
                    let (sc, st1) = sig_scheme_4784;
                    let st2 = lens_check(&st1, &crate::check::env::def_name_text(&s.name), &s.ty, &crate::check::env::def_name_span(&s.name));
                    call_then(start_check_mark_function(st2.clone(), crate::check::env::def_name_text(&s.name), sc.ty.clone(), crate::check::env::def_name_span(&s.name)), move |check_mark_function_4917: crate::check::types::St| {
                        let st3 = check_mark_function_4917;
                        if crate::check::env::has_key(&g.vals, &qk) {
                            prism_rtl::Turn::Finished((g.clone(), crate::check::types::recording::err(&st3, &Text::lit("collision"), &d.span, &Text::from(format!("a second signature for `{}`", &crate::check::env::def_name_text(&s.name))))))
                        } else {
                            {
                                let upd = {
                                    let mut this: crate::check::env::G = g.clone();
                                    this.vals = insert(&this.vals, &qk, &crate::check::env::ValInfo { qk: qk.clone(), scheme: sc.clone(), sort: Text::lit("fn"), has_sig: true, home: info.name.clone(), file: info.file.clone(), span: d.span.clone() });
                                    this
                                };
                                prism_rtl::Turn::Finished((upd.clone(), st3.clone()))
                            }
                        }
                    })
                })
            },
            crate::syntax::decls::DeclKind::DFn(f) => {
                let qk = crate::check::env::qual_key(&info.name, &crate::check::env::def_name_text(&f.name));
                prism_rtl::Turn::Finished((add_clause(g, info, &qk, &crate::check::env::def_name_text(&f.name), f, &d.span, st), st.clone()))
            },
            crate::syntax::decls::DeclKind::DLet(l) => {
                let d = d.clone();
                let g = g.clone();
                let info = info.clone();
                let l = l.clone();
                let st = st.clone();
                call_then(crate::check::env::names::start_pattern_names(l.pattern.clone()), move |pattern_names_5497: Array<Text>| {
                    let names = pattern_names_5497;
                    let qk = crate::check::env::qual_key(&info.name, &or(&index(&names, &Nat::from(0u32)), &Text::lit("")));
                    let def = crate::check::env::Def { qk: qk.clone(), name: or(&index(&names, &Nat::from(0u32)), &Text::lit("")), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: crate::check::env::DefBody::DbLet(l.clone()) };
                    let upd = {
                        let mut this: crate::check::env::G = g.clone();
                        this.defs = push(&this.defs, &def);
                        this
                    };
                    prism_rtl::Turn::Finished((upd.clone(), st.clone()))
                })
            },
            crate::syntax::decls::DeclKind::DWidget(w) => {
                let qk = crate::check::env::qual_key(&info.name, &crate::check::env::sname_key(&w.name));
                let def = crate::check::env::Def { qk: qk.clone(), name: crate::check::env::sname_key(&w.name), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: crate::check::env::DefBody::DbWidget(w.clone()) };
                let upd = {
                    let mut this: crate::check::env::G = g.clone();
                    this.defs = push(&this.defs, &def);
                    this
                };
                prism_rtl::Turn::Finished((upd.clone(), st.clone()))
            },
            crate::syntax::decls::DeclKind::DTag(t) => prism_rtl::Turn::More(Rc::new(ConvTag { g: g.clone(), st: st.clone(), info: info.clone(), t: t.clone(), span: d.span.clone() })),
            crate::syntax::decls::DeclKind::DTrait(t) => prism_rtl::Turn::More(Rc::new(ConvTrait { g: g.clone(), st: st.clone(), info: info.clone(), t: t.clone(), span: d.span.clone() })),
            crate::syntax::decls::DeclKind::DImpl(i) => prism_rtl::Turn::More(Rc::new(ConvImpl { g: g.clone(), st: st.clone(), info: info.clone(), i: i.clone(), span: d.span.clone() })),
            crate::syntax::decls::DeclKind::DCheck(c) => {
                let upd = {
                    let mut this: crate::check::env::G = g.clone();
                    this.defs = push(&this.defs, &crate::check::env::Def { qk: crate::check::env::qual_key(&info.name, &Text::from(format!("check {}", &c.name.name))), name: c.name.name.clone(), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: crate::check::env::DefBody::DbCheck(c.clone()) });
                    this
                };
                prism_rtl::Turn::Finished((upd.clone(), st.clone()))
            },
            crate::syntax::decls::DeclKind::DTest(t) => {
                let upd = {
                    let mut this: crate::check::env::G = g.clone();
                    this.defs = push(&this.defs, &crate::check::env::Def { qk: crate::check::env::qual_key(&info.name, &Text::from(format!("test {}", &t.name.name))), name: t.name.name.clone(), home: info.name.clone(), file: info.file.clone(), span: d.span.clone(), body: crate::check::env::DefBody::DbTest(t.clone()) });
                    this
                };
                prism_rtl::Turn::Finished((upd.clone(), st.clone()))
            },
            crate::syntax::decls::DeclKind::DStmt(s) => match &s.kind {
                crate::syntax::StmtKind::SEmit(_) => prism_rtl::Turn::Finished((g.clone(), st.clone())),
                _ => prism_rtl::Turn::Finished((g.clone(), crate::check::types::recording::err(st, &Text::lit("unsupported"), &d.span, &Text::lit("a statement at the top of a file: nothing at top level is built")))),
            },
            _ => prism_rtl::Turn::Finished((g.clone(), st.clone())),
        }
    }
}

/// `Start ConvertDecl, x`: what the function value is when passed to `@Run`.
pub fn start_convert_decl(g: crate::check::env::G, st: crate::check::types::St, info: crate::check::env::ModInfo, d: crate::syntax::decls::Decl) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvertDecl { g, st, info, d })
}

/// ```prism
/// AddClause: fn G, ModInfo, Text, Text, FnClause, Range, St -> G
/// ```
pub fn add_clause(g: &crate::check::env::G, info: &crate::check::env::ModInfo, qk: &Text, name: &Text, f: &crate::syntax::decls::FnClause, span: &crate::syntax::Range, st: &crate::check::types::St) -> crate::check::env::G {
    match get(&g.fn_at, qk) {
        Some(i) => {
            let mut this: crate::check::env::G = g.clone();
            this.defs = insert2(&this.defs, &i, &add_to_fn(&or(&index(&this.defs, &i), &dummy_def()), f));
            this
        },
        None => {
            let mut this: crate::check::env::G = g.clone();
            this.fn_at = insert(&this.fn_at, qk, &len(&this.defs));
            this.defs = push(&this.defs, &crate::check::env::Def { qk: qk.clone(), name: name.clone(), home: info.name.clone(), file: info.file.clone(), span: span.clone(), body: crate::check::env::DefBody::DbFn(Array::from(vec![f.clone()])) });
            this
        },
    }
}

/// ```prism
/// let dummyDef
/// ```
pub fn dummy_def() -> crate::check::env::Def {
    crate::check::env::Def { qk: Text::lit(""), name: Text::lit(""), home: Text::lit(""), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }, body: crate::check::env::DefBody::DbFn(Array::new()) }
}

/// ```prism
/// IsFnDef: fn Def -> Bool
/// ```
pub fn is_fn_def(d: &crate::check::env::Def) -> bool {
    match &d.body {
        crate::check::env::DefBody::DbFn(_) => true,
        _ => false,
    }
}

/// ```prism
/// AddToFn: fn Def, FnClause -> Def
/// ```
pub fn add_to_fn(d: &crate::check::env::Def, f: &crate::syntax::decls::FnClause) -> crate::check::env::Def {
    match &d.body {
        crate::check::env::DefBody::DbFn(fs) => {
            let mut this: crate::check::env::Def = d.clone();
            this.body = crate::check::env::DefBody::DbFn(push(fs, f));
            this
        },
        _ => d.clone(),
    }
}

/// ```prism
/// Insert2: fn [a], Nat, a -> [a]
/// ```
pub fn insert2<A: Clone + 'static>(xs: &Array<A>, i: &Nat, x: &A) -> Array<A> {
    append(&push(&take(xs, i), x), &drop(xs, &(i + &Nat::from(1u32))))
}

/// ```prism
/// LensCheck: fn St, Text, Type, Range -> St
/// ```
pub fn lens_check(st: &crate::check::types::St, name: &Text, t: &crate::syntax::Type, span: &crate::syntax::Range) -> crate::check::types::St {
    if !crate::syntax::lexer::chars::has_prefix(name, &Text::lit("&")) {
        st.clone()
    } else {
        match &*t.kind {
            crate::syntax::TypeKind::TFn(_, ps, _) => {
                let refs = filter(ps, &(|p_: &crate::syntax::Type| is_ref_type(p_)));
                if &len(&refs) > &Nat::from(1u32) {
                    crate::check::types::recording::err_fix(st, &Text::lit("lens-arity"), span, &Text::lit("a lens takes one reference"), &Text::lit("take the second part as a plain value"))
                } else {
                    crate::check::types::recording::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement named lenses and `Over`"))
                }
            },
            _ => st.clone(),
        }
    }
}

/// ```prism
/// IsRefType: fn Type -> Bool
/// ```
pub fn is_ref_type(t: &crate::syntax::Type) -> bool {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, _) => crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")),
        crate::syntax::TypeKind::TSigiled(s, _) => crate::syntax::lexer::chars::has_prefix(s, &Text::lit("&")),
        _ => false,
    }
}

/// ```prism
/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
/// ```
pub fn check_mark_function(st: &crate::check::types::St, name: &Text, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> crate::check::types::St {
    match t {
        crate::check::types::Ty::TyFn(_, _, res) => {
            let want = crate::check::types::head_sigil(st, &**res);
            let marks = crate::check::types::unify::marks_of(name);
            let shown = crate::syntax::lexer::chars::head(&marks);
            let bare = crate::syntax::lexer::chars::drop_prefix(name, &marks);
            if (((&shown == &want) || (&len_text(&marks) > &Nat::from(1u32))) || (&bare == &Text::lit(""))) || !crate::check::env::is_upper_text(&bare) {
                st.clone()
            } else {
                crate::check::types::recording::err_fix(st, &Text::lit("mark-function"), span, &Text::from(format!("`{}` returns `{}`; name it `{}{}`", name, &crate::check::types::show_ty(st, &**res), &want, &bare)), &Text::from(format!("rename to `{}{}`", &want, &bare)))
            }
        },
        _ => st.clone(),
    }
}

/// The step machine of `CheckMarkFunction`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
/// ```
pub struct CheckMarkFunction {
    pub st: crate::check::types::St,
    pub name: Text,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for CheckMarkFunction {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let name = &self.name;
        let t = &self.t;
        let span = &self.span;
        match t {
            crate::check::types::Ty::TyFn(_, _, res) => {
                let name = name.clone();
                let res = (**res).clone();
                let span = span.clone();
                let st = st.clone();
                call_then(crate::check::types::start_head_sigil(st.clone(), res.clone()), move |head_sigil_8937: Text| {
                    let want = head_sigil_8937;
                    let marks = crate::check::types::unify::marks_of(&name);
                    let shown = crate::syntax::lexer::chars::head(&marks);
                    let bare = crate::syntax::lexer::chars::drop_prefix(&name, &marks);
                    if (((&shown == &want) || (&len_text(&marks) > &Nat::from(1u32))) || (&bare == &Text::lit(""))) || !crate::check::env::is_upper_text(&bare) {
                        prism_rtl::Turn::Finished(st.clone())
                    } else {
                        call_then(crate::check::types::start_show_ty(st.clone(), res.clone()), move |show_ty_9217: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st, &Text::lit("mark-function"), &span, &Text::from(format!("`{}` returns `{}`; name it `{}{}`", &name, &show_ty_9217, &want, &bare)), &Text::from(format!("rename to `{}{}`", &want, &bare)))))
                    }
                })
            },
            _ => prism_rtl::Turn::Finished(st.clone()),
        }
    }
}

/// `Start CheckMarkFunction, x`: what the function value is when passed to `@Run`.
pub fn start_check_mark_function(st: crate::check::types::St, name: Text, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckMarkFunction { st, name, t, span })
}

/// ```prism
/// MissingSignatures: fn G, St, ModInfo -> St
/// ```
pub fn missing_signatures(g: &crate::check::env::G, st: &crate::check::types::St, info: &crate::check::env::ModInfo) -> crate::check::types::St {
    fold(&g.defs, st, &(|s: &crate::check::types::St, d: &crate::check::env::Def| if ((&d.home == &info.name) && is_fn_def(d)) && !crate::check::env::has_key(&g.vals, &d.qk) {
        crate::check::types::recording::err_fix(s, &Text::lit("no-signature"), &d.span, &Text::from(format!("`{}` has no signature line", &d.name)), &Text::from(format!("write `{}: fn ... -> ...` above it", &d.name)))
    } else {
        s.clone()
    }))
}

/// ```prism
/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
/// ```
pub fn conv_tag(g: &crate::check::env::G, st: &crate::check::types::St, info: &crate::check::env::ModInfo, t: &crate::syntax::decls::TagDecl, span: &crate::syntax::Range) -> (crate::check::env::G, crate::check::types::St) {
    let name = crate::check::env::dotted(&t.name.path_);
    let family = crate::check::env::dotted(&take(&t.name.path_, &crate::syntax::lexer::chars::dec(&len(&t.name.path_))));
    let cx_ = crate::check::env::reading::cx_of(g, &info.name);
    let (kind, out, st2) = tag_kind(g, &cx_, st, &t.of_type);
    let (fields, st3) = run_to_end(fold_job(t.fields.clone(), (Array::new(), st2.clone()), {
        let cx_ = cx_.clone();
        Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)| {
            let cx_ = cx_.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let f = p1;
                call_then(crate::check::env::reading::start_conv_type(cx_.clone(), s.clone(), f.ty.clone()), move |conv_type_10129: (crate::check::types::Ty, crate::check::types::St)| {
                    let (ft, s2) = conv_type_10129;
                    prism_rtl::Turn::Finished((push(&acc, &(f.name.name.clone(), ft.clone())), s2.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
    }));
    let qs = run_to_end(fold_job(t.fields.clone(), crate::check::env::reading::type_vars_of_type(&t.of_type), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::decls::Field)| entered(once_job(move || {
        let acc = p0;
        let f = p1;
        call_then(crate::check::env::reading::start_type_vars_of_type(f.ty.clone()), move |type_vars_of_type_10280: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_vars_of_type_10280)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::decls::Field)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let (bs, st4) = crate::check::env::reading::conv_bounds(&cx_, &st3, &t.bounds);
    let tg = crate::check::env::TagInfo { name: name.clone(), family: family.clone(), kind: kind.clone(), out: out.clone(), qs: qs.clone(), rqs: if &info.row_var == &Text::lit("") {
        Array::new()
    } else {
        Array::from(vec![info.row_var.clone()])
    }, bounds: bs.clone(), fields: fields.clone(), home: info.name.clone(), file: info.file.clone(), span: span.clone() };
    let upd = {
        let mut this: crate::check::env::G = g.clone();
        this.tags = insert(&this.tags, &name, &tg);
        this
    };
    (upd.clone(), st4.clone())
}

/// The step machine of `ConvTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
/// ```
pub struct ConvTag {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub info: crate::check::env::ModInfo,
    pub t: crate::syntax::decls::TagDecl,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvTag {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let info = &self.info;
        let t = &self.t;
        let span = &self.span;
        let name = crate::check::env::dotted(&t.name.path_);
        let family = crate::check::env::dotted(&take(&t.name.path_, &crate::syntax::lexer::chars::dec(&len(&t.name.path_))));
        let cx_ = crate::check::env::reading::cx_of(g, &info.name);
        let g = g.clone();
        let info = info.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_tag_kind(g.clone(), cx_.clone(), st.clone(), t.of_type.clone()), move |tag_kind_10003: (Text, crate::check::types::Ty, crate::check::types::St)| {
            let (kind, out, st2) = tag_kind_10003;
            call_value(fold_job(t.fields.clone(), (Array::new(), st2.clone()), {
                let cx_ = cx_.clone();
                Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)| {
                    let cx_ = cx_.clone();
                    entered(once_job(move || {
                        let (acc, s) = p0;
                        let f = p1;
                        call_then(crate::check::env::reading::start_conv_type(cx_.clone(), s.clone(), f.ty.clone()), move |conv_type_10129: (crate::check::types::Ty, crate::check::types::St)| {
                            let (ft, s2) = conv_type_10129;
                            prism_rtl::Turn::Finished((push(&acc, &(f.name.name.clone(), ft.clone())), s2.clone()))
                        })
                    }))
                }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::Field)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
            }), move |fold_10057: (Array<(Text, crate::check::types::Ty)>, crate::check::types::St)| {
                let (fields, st3) = fold_10057;
                call_then(crate::check::env::reading::start_type_vars_of_type(t.of_type.clone()), move |type_vars_of_type_10227: Array<Text>| call_value(fold_job(t.fields.clone(), type_vars_of_type_10227, Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::decls::Field)| entered(once_job(move || {
                    let acc = p0;
                    let f = p1;
                    call_then(crate::check::env::reading::start_type_vars_of_type(f.ty.clone()), move |type_vars_of_type_10280: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &type_vars_of_type_10280)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::decls::Field)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_10211: Array<Text>| {
                    let qs = fold_10211;
                    let (bs, st4) = crate::check::env::reading::conv_bounds(&cx_, &st3, &t.bounds);
                    let tg = crate::check::env::TagInfo { name: name.clone(), family: family.clone(), kind: kind.clone(), out: out.clone(), qs: qs.clone(), rqs: if &info.row_var == &Text::lit("") {
                        Array::new()
                    } else {
                        Array::from(vec![info.row_var.clone()])
                    }, bounds: bs.clone(), fields: fields.clone(), home: info.name.clone(), file: info.file.clone(), span: span.clone() };
                    let upd = {
                        let mut this: crate::check::env::G = g.clone();
                        this.tags = insert(&this.tags, &name, &tg);
                        this
                    };
                    prism_rtl::Turn::Finished((upd.clone(), st4.clone()))
                }))
            })
        })
    }
}

/// `Start ConvTag, x`: what the function value is when passed to `@Run`.
pub fn start_conv_tag(g: crate::check::env::G, st: crate::check::types::St, info: crate::check::env::ModInfo, t: crate::syntax::decls::TagDecl, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvTag { g, st, info, t, span })
}

/// ```prism
/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
/// ```
pub fn tag_kind(g: &crate::check::env::G, cx_: &crate::check::env::reading::Cx_, st: &crate::check::types::St, t: &crate::syntax::Type) -> (Text, crate::check::types::Ty, crate::check::types::St) {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, args) => {
            let name = crate::check::env::dotted(&n.path_);
            if &name == &Text::lit("Element") {
                match index(args, &Nat::from(0u32)) {
                    Some(o) => {
                        let (ot, s2) = crate::check::env::reading::conv_type(cx_, st, &o);
                        (Text::lit("Element"), ot.clone(), s2.clone())
                    },
                    None => (Text::lit("Element"), crate::check::types::t_unit(), st.clone()),
                }
            } else {
                {
                    let (key_opt, _) = crate::check::env::names::resolve_type(g, &cx_.home, &n.path_);
                    match &key_opt {
                        Some(k) => match &or(&get(&g.types, k), &crate::check::env::names::dummy_ty_info()).body {
                            crate::check::env::TyBody::BRowKind => (k.clone(), crate::check::types::t_unit(), st.clone()),
                            _ => (k.clone(), crate::check::types::t_unit(), crate::check::types::recording::err(st, &Text::lit("kind"), &t.span, &Text::from(format!("`{}` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`", &name)))),
                        },
                        None => (Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unknown-name"), &t.span, &Text::from(format!("no row kind `{}`", &name)))),
                    }
                }
            }
        },
        crate::syntax::TypeKind::TGroup(x) => tag_kind(g, cx_, st, &**x),
        _ => (Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("kind"), &t.span, &Text::lit("a tag joins a row kind"))),
    }
}

/// The step machine of `TagKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
/// ```
pub struct TagKind {
    pub g: crate::check::env::G,
    pub cx_: crate::check::env::reading::Cx_,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<(Text, crate::check::types::Ty, crate::check::types::St)> for TagKind {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::Ty, crate::check::types::St)> {
        let g = &self.g;
        let cx_ = &self.cx_;
        let st = &self.st;
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TName(n, args) => {
                let name = crate::check::env::dotted(&n.path_);
                if &name == &Text::lit("Element") {
                    match index(args, &Nat::from(0u32)) {
                        Some(o) => {
                            let cx_ = cx_.clone();
                            let st = st.clone();
                            call_then(crate::check::env::reading::start_conv_type(cx_.clone(), st.clone(), o.clone()), move |conv_type_10990: (crate::check::types::Ty, crate::check::types::St)| {
                                let (ot, s2) = conv_type_10990;
                                prism_rtl::Turn::Finished((Text::lit("Element"), ot.clone(), s2.clone()))
                            })
                        },
                        None => prism_rtl::Turn::Finished((Text::lit("Element"), crate::check::types::t_unit(), st.clone())),
                    }
                } else {
                    {
                        let (key_opt, _) = crate::check::env::names::resolve_type(g, &cx_.home, &n.path_);
                        match &key_opt {
                            Some(k) => match &or(&get(&g.types, k), &crate::check::env::names::dummy_ty_info()).body {
                                crate::check::env::TyBody::BRowKind => prism_rtl::Turn::Finished((k.clone(), crate::check::types::t_unit(), st.clone())),
                                _ => prism_rtl::Turn::Finished((k.clone(), crate::check::types::t_unit(), crate::check::types::recording::err(st, &Text::lit("kind"), &t.span, &Text::from(format!("`{}` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`", &name))))),
                            },
                            None => prism_rtl::Turn::Finished((Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unknown-name"), &t.span, &Text::from(format!("no row kind `{}`", &name))))),
                        }
                    }
                }
            },
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(TagKind { g: g.clone(), cx_: cx_.clone(), st: st.clone(), t: (**x).clone() })),
            _ => prism_rtl::Turn::Finished((Text::lit(""), crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("kind"), &t.span, &Text::lit("a tag joins a row kind")))),
        }
    }
}

/// `Start TagKind, x`: what the function value is when passed to `@Run`.
pub fn start_tag_kind(g: crate::check::env::G, cx_: crate::check::env::reading::Cx_, st: crate::check::types::St, t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(TagKind { g, cx_, st, t })
}

/// ```prism
/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
/// ```
pub fn conv_trait(g: &crate::check::env::G, st: &crate::check::types::St, info: &crate::check::env::ModInfo, t: &crate::syntax::decls::TraitDecl, span: &crate::syntax::Range) -> (crate::check::env::G, crate::check::types::St) {
    let name = crate::check::env::qual_key(&info.name, &crate::check::env::dotted(&t.name.path_));
    let param = or(&index(&each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone())), &Nat::from(0u32)), &Text::lit("a"));
    let st1 = if &len(&t.params) > &Nat::from(1u32) {
        crate::check::types::recording::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement traits of several types"))
    } else {
        st.clone()
    };
    let cx_ = crate::check::env::reading::cx_of(g, &info.name);
    let (supers, st2) = crate::check::env::reading::conv_bounds(&cx_, &st1, &t.bounds);
    let (g3, st3, methods, defaults, assocs) = run_to_end(fold_job(t.items.clone(), (g.clone(), st2.clone(), Array::new(), Array::new(), Array::new()), {
        let info = info.clone();
        let cx_ = cx_.clone();
        let param = param.clone();
        let name = name.clone();
        Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>), crate::syntax::decls::TraitItem)| {
            let info = info.clone();
            let cx_ = cx_.clone();
            let param = param.clone();
            let name = name.clone();
            entered(once_job(move || {
                let (gg, s, ms, ds, assoc_acc) = p0;
                let it = p1;
                match &it {
                    crate::syntax::decls::TraitItem::TiSignature(sg) => {
                        let mname = crate::check::env::def_name_text(&sg.name);
                        let qk = crate::check::env::qual_key(&info.name, &mname);
                        let sg = sg.clone();
                        call_then(crate::check::env::reading::start_sig_scheme(cx_.clone(), s.clone(), sg.ty.clone(), sg.bounds.clone()), move |sig_scheme_12556: (crate::check::types::Scheme, crate::check::types::St)| {
                            let (sc, s2) = sig_scheme_12556;
                            let sc2 = {
                                let mut this: crate::check::types::Scheme = sc.clone();
                                this.qs = if crate::check::types::has_text(&this.qs, &param) {
                                    this.qs.clone()
                                } else {
                                    append(&Array::from(vec![param.clone()]), &this.qs)
                                };
                                this.bounds = append(&Array::from(vec![(param.clone(), name.clone())]), &this.bounds);
                                this
                            };
                            let upd = {
                                let mut this: crate::check::env::G = gg.clone();
                                this.vals = insert(&this.vals, &qk, &crate::check::env::ValInfo { qk: qk.clone(), scheme: sc2.clone(), sort: Text::lit("method"), has_sig: true, home: info.name.clone(), file: info.file.clone(), span: sg.span.clone() });
                                this
                            };
                            prism_rtl::Turn::Finished((upd.clone(), s2.clone(), push(&ms, &qk), ds.clone(), assoc_acc.clone()))
                        })
                    },
                    crate::syntax::decls::TraitItem::TiFn(f) => {
                        let qk = crate::check::env::qual_key(&info.name, &crate::check::env::def_name_text(&f.name));
                        let def = crate::check::env::Def { qk: qk.clone(), name: crate::check::env::def_name_text(&f.name), home: info.name.clone(), file: info.file.clone(), span: f.span.clone(), body: crate::check::env::DefBody::DbDefault(Array::from(vec![f.clone()]), name.clone()) };
                        let upd = {
                            let mut this: crate::check::env::G = gg.clone();
                            this.defs = push(&this.defs, &def);
                            this
                        };
                        prism_rtl::Turn::Finished((upd.clone(), s.clone(), ms.clone(), push(&ds, &qk), assoc_acc.clone()))
                    },
                    crate::syntax::decls::TraitItem::TiAssocType(n, _, _, _) => prism_rtl::Turn::Finished((gg.clone(), s.clone(), ms.clone(), ds.clone(), push(&assoc_acc, &n.name))),
                    crate::syntax::decls::TraitItem::TiAssocRow(_, r) => prism_rtl::Turn::Finished((gg.clone(), crate::check::types::recording::err(&s, &Text::lit("unsupported"), r, &Text::lit("this checker does not implement associated rows")), ms.clone(), ds.clone(), assoc_acc.clone())),
                }
            }))
        }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>), crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>)>>>
    }));
    let ti = crate::check::env::TraitInfo { name: name.clone(), home: info.name.clone(), param: param.clone(), supers: each(&supers, &(|(_, k): &(Text, Text)| k.clone())), methods: methods.clone(), defaults: defaults.clone(), assocs: assocs.clone(), file: info.file.clone(), span: span.clone() };
    let upd3 = {
        let mut this: crate::check::env::G = g3.clone();
        this.traits = insert(&this.traits, &name, &ti);
        this
    };
    (upd3.clone(), st3.clone())
}

/// The step machine of `ConvTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
/// ```
pub struct ConvTrait {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub info: crate::check::env::ModInfo,
    pub t: crate::syntax::decls::TraitDecl,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvTrait {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let info = &self.info;
        let t = &self.t;
        let span = &self.span;
        let name = crate::check::env::qual_key(&info.name, &crate::check::env::dotted(&t.name.path_));
        let param = or(&index(&each(&t.params, &(|p_: &crate::syntax::Ident| p_.name.clone())), &Nat::from(0u32)), &Text::lit("a"));
        let st1 = if &len(&t.params) > &Nat::from(1u32) {
            crate::check::types::recording::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement traits of several types"))
        } else {
            st.clone()
        };
        let cx_ = crate::check::env::reading::cx_of(g, &info.name);
        let (supers, st2) = crate::check::env::reading::conv_bounds(&cx_, &st1, &t.bounds);
        let g = g.clone();
        let info = info.clone();
        let span = span.clone();
        let t = t.clone();
        call_value(fold_job(t.items.clone(), (g.clone(), st2.clone(), Array::new(), Array::new(), Array::new()), {
            let info = info.clone();
            let cx_ = cx_.clone();
            let param = param.clone();
            let name = name.clone();
            Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>), crate::syntax::decls::TraitItem)| {
                let info = info.clone();
                let cx_ = cx_.clone();
                let param = param.clone();
                let name = name.clone();
                entered(once_job(move || {
                    let (gg, s, ms, ds, assoc_acc) = p0;
                    let it = p1;
                    match &it {
                        crate::syntax::decls::TraitItem::TiSignature(sg) => {
                            let mname = crate::check::env::def_name_text(&sg.name);
                            let qk = crate::check::env::qual_key(&info.name, &mname);
                            let sg = sg.clone();
                            call_then(crate::check::env::reading::start_sig_scheme(cx_.clone(), s.clone(), sg.ty.clone(), sg.bounds.clone()), move |sig_scheme_12556: (crate::check::types::Scheme, crate::check::types::St)| {
                                let (sc, s2) = sig_scheme_12556;
                                let sc2 = {
                                    let mut this: crate::check::types::Scheme = sc.clone();
                                    this.qs = if crate::check::types::has_text(&this.qs, &param) {
                                        this.qs.clone()
                                    } else {
                                        append(&Array::from(vec![param.clone()]), &this.qs)
                                    };
                                    this.bounds = append(&Array::from(vec![(param.clone(), name.clone())]), &this.bounds);
                                    this
                                };
                                let upd = {
                                    let mut this: crate::check::env::G = gg.clone();
                                    this.vals = insert(&this.vals, &qk, &crate::check::env::ValInfo { qk: qk.clone(), scheme: sc2.clone(), sort: Text::lit("method"), has_sig: true, home: info.name.clone(), file: info.file.clone(), span: sg.span.clone() });
                                    this
                                };
                                prism_rtl::Turn::Finished((upd.clone(), s2.clone(), push(&ms, &qk), ds.clone(), assoc_acc.clone()))
                            })
                        },
                        crate::syntax::decls::TraitItem::TiFn(f) => {
                            let qk = crate::check::env::qual_key(&info.name, &crate::check::env::def_name_text(&f.name));
                            let def = crate::check::env::Def { qk: qk.clone(), name: crate::check::env::def_name_text(&f.name), home: info.name.clone(), file: info.file.clone(), span: f.span.clone(), body: crate::check::env::DefBody::DbDefault(Array::from(vec![f.clone()]), name.clone()) };
                            let upd = {
                                let mut this: crate::check::env::G = gg.clone();
                                this.defs = push(&this.defs, &def);
                                this
                            };
                            prism_rtl::Turn::Finished((upd.clone(), s.clone(), ms.clone(), push(&ds, &qk), assoc_acc.clone()))
                        },
                        crate::syntax::decls::TraitItem::TiAssocType(n, _, _, _) => prism_rtl::Turn::Finished((gg.clone(), s.clone(), ms.clone(), ds.clone(), push(&assoc_acc, &n.name))),
                        crate::syntax::decls::TraitItem::TiAssocRow(_, r) => prism_rtl::Turn::Finished((gg.clone(), crate::check::types::recording::err(&s, &Text::lit("unsupported"), r, &Text::lit("this checker does not implement associated rows")), ms.clone(), ds.clone(), assoc_acc.clone())),
                    }
                }))
            }) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>), crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>)>>>
        }), move |fold_12324: (crate::check::env::G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>)| {
            let (g3, st3, methods, defaults, assocs) = fold_12324;
            let ti = crate::check::env::TraitInfo { name: name.clone(), home: info.name.clone(), param: param.clone(), supers: each(&supers, &(|(_, k): &(Text, Text)| k.clone())), methods: methods.clone(), defaults: defaults.clone(), assocs: assocs.clone(), file: info.file.clone(), span: span.clone() };
            let upd3 = {
                let mut this: crate::check::env::G = g3.clone();
                this.traits = insert(&this.traits, &name, &ti);
                this
            };
            prism_rtl::Turn::Finished((upd3.clone(), st3.clone()))
        })
    }
}

/// `Start ConvTrait, x`: what the function value is when passed to `@Run`.
pub fn start_conv_trait(g: crate::check::env::G, st: crate::check::types::St, info: crate::check::env::ModInfo, t: crate::syntax::decls::TraitDecl, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvTrait { g, st, info, t, span })
}

/// ```prism
/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
/// ```
pub fn conv_impl(g: &crate::check::env::G, st: &crate::check::types::St, info: &crate::check::env::ModInfo, i: &crate::syntax::decls::ImplDecl, span: &crate::syntax::Range) -> (crate::check::env::G, crate::check::types::St) {
    match crate::check::env::names::resolve_trait(g, &info.name, &i.trait_ref.path_) {
        None => (g.clone(), crate::check::types::recording::err(st, &Text::lit("unknown-name"), &i.trait_ref.span, &Text::from(format!("no trait `^{}`", &crate::check::env::dotted(&i.trait_ref.path_))))),
        Some(cls) => {
            let cx_ = crate::check::env::reading::cx_of(g, &info.name);
            let (head, st2) = crate::check::env::reading::conv_type(&cx_, st, &i.ty);
            let (bs, st3) = crate::check::env::reading::conv_bounds(&cx_, &st2, &i.bounds);
            let (assocs, st4) = run_to_end(fold_job(i.items.clone(), (Array::new(), st3.clone()), {
                let cx_ = cx_.clone();
                Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)| {
                    let cx_ = cx_.clone();
                    entered(once_job(move || {
                        let (acc, s) = p0;
                        let it = p1;
                        match &it {
                            crate::syntax::decls::TraitItem::TiAssocType(n, _, Some(v_), _) => {
                                let n = n.clone();
                                let v_ = v_.clone();
                                call_then(crate::check::env::reading::start_conv_type(cx_.clone(), s.clone(), v_.clone()), move |conv_type_14573: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (vt, s2) = conv_type_14573;
                                    prism_rtl::Turn::Finished((push(&acc, &(n.name.clone(), vt.clone())), s2.clone()))
                                })
                            },
                            _ => prism_rtl::Turn::Finished((acc.clone(), s.clone())),
                        }
                    }))
                }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
            }));
            let names = fold(&i.items, &Array::new(), &(|acc: &Array<Text>, it: &crate::syntax::decls::TraitItem| match it {
                crate::syntax::decls::TraitItem::TiFn(f) => crate::check::types::add_text(acc, &crate::check::env::def_name_text(&f.name)),
                _ => acc.clone(),
            }));
            let im = crate::check::env::ImplInfo { cls: cls.clone(), head: head.clone(), qs: crate::check::env::reading::type_vars_of_type(&i.ty), bounds: bs.clone(), home: info.name.clone(), file: info.file.clone(), span: span.clone(), derived: false, assocs: assocs.clone(), methods: names.clone() };
            let g2 = {
                let mut this: crate::check::env::G = g.clone();
                this.impls = insert(&this.impls, &cls, &push(&or(&get(&this.impls, &cls), &Array::new()), &im));
                this
            };
            let g3 = fold(&names, &g2, &(|gg: &crate::check::env::G, mname: &Text| {
                let clauses = fold(&i.items, &Array::new(), &(|acc: &Array<crate::syntax::decls::FnClause>, it: &crate::syntax::decls::TraitItem| match it {
                    crate::syntax::decls::TraitItem::TiFn(f) => if &crate::check::env::def_name_text(&f.name) == mname {
                        push(acc, f)
                    } else {
                        acc.clone()
                    },
                    _ => acc.clone(),
                }));
                {
                    let mut this: crate::check::env::G = gg.clone();
                    this.defs = push(&this.defs, &crate::check::env::Def { qk: Text::from(format!("{} impl {}", &cls, mname)), name: mname.clone(), home: info.name.clone(), file: info.file.clone(), span: span.clone(), body: crate::check::env::DefBody::DbMethod(clauses.clone(), cls.clone(), im.clone()) });
                    this
                }
            }));
            (g3.clone(), st4.clone())
        },
    }
}

/// The step machine of `ConvImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
/// ```
pub struct ConvImpl {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub info: crate::check::env::ModInfo,
    pub i: crate::syntax::decls::ImplDecl,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for ConvImpl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let info = &self.info;
        let i = &self.i;
        let span = &self.span;
        match crate::check::env::names::resolve_trait(g, &info.name, &i.trait_ref.path_) {
            None => prism_rtl::Turn::Finished((g.clone(), crate::check::types::recording::err(st, &Text::lit("unknown-name"), &i.trait_ref.span, &Text::from(format!("no trait `^{}`", &crate::check::env::dotted(&i.trait_ref.path_)))))),
            Some(cls) => {
                let cx_ = crate::check::env::reading::cx_of(g, &info.name);
                let g = g.clone();
                let i = i.clone();
                let info = info.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(crate::check::env::reading::start_conv_type(cx_.clone(), st.clone(), i.ty.clone()), move |conv_type_14326: (crate::check::types::Ty, crate::check::types::St)| {
                    let (head, st2) = conv_type_14326;
                    let (bs, st3) = crate::check::env::reading::conv_bounds(&cx_, &st2, &i.bounds);
                    call_value(fold_job(i.items.clone(), (Array::new(), st3.clone()), {
                        let cx_ = cx_.clone();
                        Rc::new(move |(p0, p1): ((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)| {
                            let cx_ = cx_.clone();
                            entered(once_job(move || {
                                let (acc, s) = p0;
                                let it = p1;
                                match &it {
                                    crate::syntax::decls::TraitItem::TiAssocType(n, _, Some(v_), _) => {
                                        let n = n.clone();
                                        let v_ = v_.clone();
                                        call_then(crate::check::env::reading::start_conv_type(cx_.clone(), s.clone(), v_.clone()), move |conv_type_14573: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (vt, s2) = conv_type_14573;
                                            prism_rtl::Turn::Finished((push(&acc, &(n.name.clone(), vt.clone())), s2.clone()))
                                        })
                                    },
                                    _ => prism_rtl::Turn::Finished((acc.clone(), s.clone())),
                                }
                            }))
                        }) as Rc<dyn Fn(((Array<(Text, crate::check::types::Ty)>, crate::check::types::St), crate::syntax::decls::TraitItem)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::check::types::Ty)>, crate::check::types::St)>>>
                    }), move |fold_14433: (Array<(Text, crate::check::types::Ty)>, crate::check::types::St)| {
                        let (assocs, st4) = fold_14433;
                        let names = fold(&i.items, &Array::new(), &(|acc: &Array<Text>, it: &crate::syntax::decls::TraitItem| match it {
                            crate::syntax::decls::TraitItem::TiFn(f) => crate::check::types::add_text(acc, &crate::check::env::def_name_text(&f.name)),
                            _ => acc.clone(),
                        }));
                        call_then(crate::check::env::reading::start_type_vars_of_type(i.ty.clone()), move |type_vars_of_type_14868: Array<Text>| {
                            let im = crate::check::env::ImplInfo { cls: cls.clone(), head: head.clone(), qs: type_vars_of_type_14868, bounds: bs.clone(), home: info.name.clone(), file: info.file.clone(), span: span.clone(), derived: false, assocs: assocs.clone(), methods: names.clone() };
                            let g2 = {
                                let mut this: crate::check::env::G = g.clone();
                                this.impls = insert(&this.impls, &cls, &push(&or(&get(&this.impls, &cls), &Array::new()), &im));
                                this
                            };
                            let g3 = fold(&names, &g2, &(|gg: &crate::check::env::G, mname: &Text| {
                                let clauses = fold(&i.items, &Array::new(), &(|acc: &Array<crate::syntax::decls::FnClause>, it: &crate::syntax::decls::TraitItem| match it {
                                    crate::syntax::decls::TraitItem::TiFn(f) => if &crate::check::env::def_name_text(&f.name) == mname {
                                        push(acc, f)
                                    } else {
                                        acc.clone()
                                    },
                                    _ => acc.clone(),
                                }));
                                {
                                    let mut this: crate::check::env::G = gg.clone();
                                    this.defs = push(&this.defs, &crate::check::env::Def { qk: Text::from(format!("{} impl {}", &cls, mname)), name: mname.clone(), home: info.name.clone(), file: info.file.clone(), span: span.clone(), body: crate::check::env::DefBody::DbMethod(clauses.clone(), cls.clone(), im.clone()) });
                                    this
                                }
                            }));
                            prism_rtl::Turn::Finished((g3.clone(), st4.clone()))
                        })
                    })
                })
            },
        }
    }
}

/// `Start ConvImpl, x`: what the function value is when passed to `@Run`.
pub fn start_conv_impl(g: crate::check::env::G, st: crate::check::types::St, info: crate::check::env::ModInfo, i: crate::syntax::decls::ImplDecl, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(ConvImpl { g, st, info, i, span })
}
