//! The module `Check.Env.Reading`, from `target/bootstrap/src/prismc/check/env/reading.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `Cx`:
///
/// ```prism
/// type Cx = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Cx {
    pub g_p: crate::check::env::G,
    pub home_p: crate::prelude::Text,
    pub scope_p: crate::check::types::Rw,
    pub row_vars_p: crate::prelude::Array<crate::prelude::Text>,
    pub unwritten_p: crate::check::types::Col,
}

impl crate::prelude::Show for Cx {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Cx", &[("g", &self.g_p), ("home", &self.home_p), ("scope", &self.scope_p), ("rowVars", &self.row_vars_p), ("unwritten", &self.unwritten_p)]);
    }
}

impl crate::prelude::ToPod for Cx {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Cx", vec![("g", self.g_p.to_pod()), ("home", self.home_p.to_pod()), ("scope", self.scope_p.to_pod()), ("rowVars", self.row_vars_p.to_pod()), ("unwritten", self.unwritten_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Cx {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Cx { g_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "g")?)?, home_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "home")?)?, scope_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "scope")?)?, row_vars_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rowVars")?)?, unwritten_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "unwritten")?)? })
    }
}

/// ```prism
/// CxOf: fn G, Text -> Cx
/// ```
pub fn cx_of_f(g_p0: &crate::check::env::G, m_p1: &crate::prelude::Text) -> Cx {
    let info_p2 = crate::prelude::or(&crate::prelude::get(&g_p0.mods_p, m_p1), &crate::prelude::or(&crate::prelude::get(&g_p0.mods_p, &crate::prelude::Text::lit("")), &dummy_mod_p()));
    Cx { g_p: g_p0.clone(), home_p: m_p1.clone(), scope_p: info_p2.emit_rw_p.clone(), row_vars_p: if &info_p2.row_var_p == &crate::prelude::Text::lit("") {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![info_p2.row_var_p.clone()])
    }, unwritten_p: crate::check::types::Col::CBound }
}

/// ```prism
/// let dummyMod
/// ```
pub fn dummy_mod_p() -> crate::check::env::ModInfo {
    crate::check::env::ModInfo { name_p: crate::prelude::Text::lit(""), file_p: crate::prelude::Nat::from(0u32), emit_rw_p: crate::check::types::empty_row_p(), row_var_p: crate::prelude::Text::lit(""), uses_p: crate::prelude::Array::new(), root_p: false, tree_p: crate::check::env::empty_module_p() }
}

/// ```prism
/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
/// ```
pub fn conv_type_f(cx_p0: &Cx, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Type) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*t_p2.kind_p {
        crate::syntax::TypeKind::TName(n_p3, args_p4) => {
            let (base_p5, st2_p6) = conv_named_f(cx_p0, st_p1, n_p3, args_p4, &t_p2.span_p);
            (crate::check::types::with_marks_f(&n_p3.sigils_p, &base_p5, &cx_p0.scope_p), st2_p6.clone())
        },
        crate::syntax::TypeKind::TSigiled(sigils_p7, inner_p8) => {
            let (i_p9, st2_pa) = conv_type_f(cx_p0, st_p1, &**inner_p8);
            (crate::check::types::with_marks_f(sigils_p7, &i_p9, &cx_p0.scope_p), st2_pa.clone())
        },
        crate::syntax::TypeKind::TArray(e_pb, _) => {
            let (i_pc, st2_pd) = conv_type_f(cx_p0, st_p1, &**e_pb);
            (crate::check::types::Ty::TyArray(::std::rc::Rc::new(i_pc.clone())), st2_pd.clone())
        },
        crate::syntax::TypeKind::TTuple(ts_pe) => {
            let (xs_pf, st2_pg) = conv_types_f(cx_p0, st_p1, ts_pe);
            (crate::check::types::Ty::TyTuple(xs_pf.clone()), st2_pg.clone())
        },
        crate::syntax::TypeKind::TGroup(x_ph) => conv_type_f(cx_p0, st_p1, &**x_ph),
        crate::syntax::TypeKind::TMap(k_pi, v_pj) => {
            let (kk_pk, st2_pl) = conv_type_f(cx_p0, st_p1, &**k_pi);
            let (vv_pm, st3_pn) = conv_type_f(cx_p0, &st2_pl, &**v_pj);
            (crate::check::types::Ty::TyMap(::std::rc::Rc::new(kk_pk.clone()), ::std::rc::Rc::new(vv_pm.clone())), st3_pn.clone())
        },
        crate::syntax::TypeKind::TFn(color_po, ps_pp, res_pq) => {
            let (xs_ps, st2_pt) = conv_types_f(cx_p0, st_p1, ps_pp);
            let (r_pu, st3_pv) = conv_type_f(cx_p0, &st2_pt, &**res_pq);
            let c_pr = match color_po {
                crate::syntax::Color::Bounded => cx_p0.unwritten_p.clone(),
                crate::syntax::Color::Unbounded => crate::check::types::Col::CUnbound,
                crate::syntax::Color::ColorVar(v_p10) => if &v_p10.name_p == &crate::prelude::Text::lit("bounded") {
                    crate::check::types::Col::CBound
                } else {
                    crate::check::types::Col::CQ(v_p10.name_p.clone())
                },
            };
            (crate::check::types::Ty::TyFn(c_pr.clone(), xs_ps.clone(), ::std::rc::Rc::new(r_pu.clone())), st3_pv.clone())
        },
        crate::syntax::TypeKind::TEmit(ty_p11, row_t_p12) => {
            let (rw_p14, st2_p15) = conv_row_f(cx_p0, st_p1, &**row_t_p12);
            let inner_p13 = {
                let mut this: Cx = cx_p0.clone();
                this.scope_p = rw_p14.clone();
                this
            };
            conv_type_f(&inner_p13, &st2_p15, &**ty_p11)
        },
        crate::syntax::TypeKind::TUnit(sigils_p16) => (crate::check::types::with_marks_f(sigils_p16, &crate::check::types::t_unit_p(), &cx_p0.scope_p), st_p1.clone()),
        crate::syntax::TypeKind::TAny(tr_p17) => match crate::check::env::names::resolve_trait_o(&cx_p0.g_p, &cx_p0.home_p, &tr_p17.path_p) {
            ::std::option::Option::Some(k_p18) => (crate::check::types::Ty::TyAny(crate::prelude::Array::from(vec![k_p18])), crate::check::env::names::trait_collision_at_f(&cx_p0.g_p, st_p1, &cx_p0.home_p, &tr_p17.path_p, &tr_p17.span_p)),
            ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), &tr_p17.span_p, &crate::prelude::Text::from(format!("no trait `^{}`", &crate::check::env::dotted_f(&tr_p17.path_p))))),
        },
        crate::syntax::TypeKind::TAbsent => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), &t_p2.span_p, &crate::prelude::Text::lit("this checker does not implement sparse tuples"))),
        crate::syntax::TypeKind::TNonEmpty(inner_p19) => {
            let (c_p1a, st2_p1b) = conv_type_f(cx_p0, st_p1, &**inner_p19);
            match &c_p1a {
                crate::check::types::Ty::TyArray(_) => (crate::check::types::non_empty_of_f(&c_p1a), st2_p1b.clone()),
                crate::check::types::Ty::TyMap(_, _) => (crate::check::types::non_empty_of_f(&c_p1a), st2_p1b.clone()),
                _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st2_p1b, &crate::prelude::Text::lit("kind"), &t_p2.span_p, &crate::prelude::Text::from(format!("only an array or a map is non-empty; this is `{}`", &crate::check::types::show_ty_f(&st2_p1b, &c_p1a))))),
            }
        },
        crate::syntax::TypeKind::THole(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), &t_p2.span_p, &crate::prelude::Text::lit("this checker does not implement higher-kinded traits"))),
        crate::syntax::TypeKind::TFamily(q_p1c) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("kind"), &t_p2.span_p, &crate::prelude::Text::from(format!("`{}.*` is a row, not a type", &crate::check::env::dotted_f(&q_p1c.path_p))))),
        crate::syntax::TypeKind::TRowUnion(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("kind"), &t_p2.span_p, &crate::prelude::Text::lit("a row is not a type"))),
    }
}

/// The step machine of `ConvType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
/// ```
pub struct ConvType {
    pub cx_p0: Cx,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Type,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ConvType {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        match &*t_p2.kind_p {
            crate::syntax::TypeKind::TName(n_p3, args_p4) => {
                let args_p4x = args_p4.clone();
                let cx_p0x = cx_p0.clone();
                let n_p3x = n_p3.clone();
                let st_p1x = st_p1.clone();
                let t_p2x = t_p2.clone();
                crate::prelude::call_then(start_conv_named_f(cx_p0x.clone(), st_p1x.clone(), n_p3x.clone(), args_p4x.clone(), t_p2x.span_p.clone()), move |conv_named_f_1482: (crate::check::types::Ty, crate::check::types::St)| {
                    let (base_p5, st2_p6) = conv_named_f_1482;
                    ::prism_rtl::Turn::Finished((crate::check::types::with_marks_f(&n_p3x.sigils_p, &base_p5, &cx_p0x.scope_p), st2_p6.clone()))
                })
            },
            crate::syntax::TypeKind::TSigiled(sigils_p7, inner_p8) => {
                let cx_p0x = cx_p0.clone();
                let inner_p8x = (**inner_p8).clone();
                let sigils_p7x = sigils_p7.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st_p1x.clone(), inner_p8x.clone()), move |conv_type_f_1623: (crate::check::types::Ty, crate::check::types::St)| {
                    let (i_p9, st2_pa) = conv_type_f_1623;
                    ::prism_rtl::Turn::Finished((crate::check::types::with_marks_f(&sigils_p7x, &i_p9, &cx_p0x.scope_p), st2_pa.clone()))
                })
            },
            crate::syntax::TypeKind::TArray(e_pb, _) => {
                let cx_p0x = cx_p0.clone();
                let e_pbx = (**e_pb).clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st_p1x.clone(), e_pbx.clone()), move |conv_type_f_1742: (crate::check::types::Ty, crate::check::types::St)| {
                    let (i_pc, st2_pd) = conv_type_f_1742;
                    ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyArray(::std::rc::Rc::new(i_pc.clone())), st2_pd.clone()))
                })
            },
            crate::syntax::TypeKind::TTuple(ts_pe) => {
                let cx_p0x = cx_p0.clone();
                let st_p1x = st_p1.clone();
                let ts_pex = ts_pe.clone();
                crate::prelude::call_then(start_conv_types_f(cx_p0x.clone(), st_p1x.clone(), ts_pex.clone()), move |conv_types_f_1829: (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (xs_pf, st2_pg) = conv_types_f_1829;
                    ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyTuple(xs_pf.clone()), st2_pg.clone()))
                })
            },
            crate::syntax::TypeKind::TGroup(x_ph) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ConvType { cx_p0: cx_p0.clone(), st_p1: st_p1.clone(), t_p2: (**x_ph).clone() })),
            crate::syntax::TypeKind::TMap(k_pi, v_pj) => {
                let cx_p0x = cx_p0.clone();
                let k_pix = (**k_pi).clone();
                let st_p1x = st_p1.clone();
                let v_pjx = (**v_pj).clone();
                crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st_p1x.clone(), k_pix.clone()), move |conv_type_f_1952: (crate::check::types::Ty, crate::check::types::St)| {
                    let (kk_pk, st2_pl) = conv_type_f_1952;
                    crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st2_pl.clone(), v_pjx.clone()), move |conv_type_f_1997: (crate::check::types::Ty, crate::check::types::St)| {
                        let (vv_pm, st3_pn) = conv_type_f_1997;
                        ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyMap(::std::rc::Rc::new(kk_pk.clone()), ::std::rc::Rc::new(vv_pm.clone())), st3_pn.clone()))
                    })
                })
            },
            crate::syntax::TypeKind::TFn(color_po, ps_pp, res_pq) => {
                let color_pox = color_po.clone();
                let cx_p0x = cx_p0.clone();
                let ps_ppx = ps_pp.clone();
                let res_pqx = (**res_pq).clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_conv_types_f(cx_p0x.clone(), st_p1x.clone(), ps_ppx.clone()), move |conv_types_f_2099: (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (xs_ps, st2_pt) = conv_types_f_2099;
                    crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st2_pt.clone(), res_pqx.clone()), move |conv_type_f_2145: (crate::check::types::Ty, crate::check::types::St)| {
                        let (r_pu, st3_pv) = conv_type_f_2145;
                        let c_pr = match &color_pox {
                            crate::syntax::Color::Bounded => cx_p0x.unwritten_p.clone(),
                            crate::syntax::Color::Unbounded => crate::check::types::Col::CUnbound,
                            crate::syntax::Color::ColorVar(v_p10) => if &v_p10.name_p == &crate::prelude::Text::lit("bounded") {
                                crate::check::types::Col::CBound
                            } else {
                                crate::check::types::Col::CQ(v_p10.name_p.clone())
                            },
                        };
                        ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyFn(c_pr.clone(), xs_ps.clone(), ::std::rc::Rc::new(r_pu.clone())), st3_pv.clone()))
                    })
                })
            },
            crate::syntax::TypeKind::TEmit(ty_p11, row_t_p12) => {
                let cx_p0x = cx_p0.clone();
                let row_t_p12x = (**row_t_p12).clone();
                let st_p1x = st_p1.clone();
                let ty_p11x = (**ty_p11).clone();
                crate::prelude::call_then(start_conv_row_f(cx_p0x.clone(), st_p1x.clone(), row_t_p12x.clone()), move |conv_row_f_2412: (crate::check::types::Rw, crate::check::types::St)| {
                    let (rw_p14, st2_p15) = conv_row_f_2412;
                    let inner_p13 = {
                        let mut this: Cx = cx_p0x.clone();
                        this.scope_p = rw_p14.clone();
                        this
                    };
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ConvType { cx_p0: inner_p13.clone(), st_p1: st2_p15.clone(), t_p2: ty_p11x.clone() }))
                })
            },
            crate::syntax::TypeKind::TUnit(sigils_p16) => ::prism_rtl::Turn::Finished((crate::check::types::with_marks_f(sigils_p16, &crate::check::types::t_unit_p(), &cx_p0.scope_p), st_p1.clone())),
            crate::syntax::TypeKind::TAny(tr_p17) => match crate::check::env::names::resolve_trait_o(&cx_p0.g_p, &cx_p0.home_p, &tr_p17.path_p) {
                ::std::option::Option::Some(k_p18) => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyAny(crate::prelude::Array::from(vec![k_p18.clone()])), crate::check::env::names::trait_collision_at_f(&cx_p0.g_p, st_p1, &cx_p0.home_p, &tr_p17.path_p, &tr_p17.span_p))),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), &tr_p17.span_p, &crate::prelude::Text::from(format!("no trait `^{}`", &crate::check::env::dotted_f(&tr_p17.path_p)))))),
            },
            crate::syntax::TypeKind::TAbsent => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), &t_p2.span_p, &crate::prelude::Text::lit("this checker does not implement sparse tuples")))),
            crate::syntax::TypeKind::TNonEmpty(inner_p19) => {
                let cx_p0x = cx_p0.clone();
                let inner_p19x = (**inner_p19).clone();
                let st_p1x = st_p1.clone();
                let t_p2x = t_p2.clone();
                crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st_p1x.clone(), inner_p19x.clone()), move |conv_type_f_2968: (crate::check::types::Ty, crate::check::types::St)| {
                    let (c_p1a, st2_p1b) = conv_type_f_2968;
                    match &c_p1a {
                        crate::check::types::Ty::TyArray(_) => ::prism_rtl::Turn::Finished((crate::check::types::non_empty_of_f(&c_p1a), st2_p1b.clone())),
                        crate::check::types::Ty::TyMap(_, _) => ::prism_rtl::Turn::Finished((crate::check::types::non_empty_of_f(&c_p1a), st2_p1b.clone())),
                        _ => crate::prelude::call_then(crate::check::types::start_show_ty_f(st2_p1b.clone(), c_p1a.clone()), move |show_ty_f_3224: crate::prelude::Text| ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st2_p1b, &crate::prelude::Text::lit("kind"), &t_p2x.span_p, &crate::prelude::Text::from(format!("only an array or a map is non-empty; this is `{}`", &show_ty_f_3224)))))),
                    }
                })
            },
            crate::syntax::TypeKind::THole(_) => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), &t_p2.span_p, &crate::prelude::Text::lit("this checker does not implement higher-kinded traits")))),
            crate::syntax::TypeKind::TFamily(q_p1c) => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("kind"), &t_p2.span_p, &crate::prelude::Text::from(format!("`{}.*` is a row, not a type", &crate::check::env::dotted_f(&q_p1c.path_p)))))),
            crate::syntax::TypeKind::TRowUnion(_) => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("kind"), &t_p2.span_p, &crate::prelude::Text::lit("a row is not a type")))),
        }
    }
}

/// `Start ConvType, x`: what the function value is when passed to `@Run`.
pub fn start_conv_type_f(cx_p0: Cx, st_p1: crate::check::types::St, t_p2: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvType { cx_p0, st_p1, t_p2 })
}

/// ```prism
/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
/// ```
pub fn conv_types_f(cx_p0: &Cx, st_p1: &crate::check::types::St, ts_p2: &crate::prelude::Array<crate::syntax::Type>) -> (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St) {
    crate::prelude::run_to_end(crate::prelude::fold_job(ts_p2.clone(), (crate::prelude::Array::new(), st_p1.clone()), {
        let cx_p0x = cx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)| {
            let cx_p0xy = cx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p3, s_p4) = p0;
                let x_p5 = p1;
                crate::prelude::call_then(start_conv_type_f(cx_p0xy.clone(), s_p4.clone(), x_p5.clone()), move |conv_type_f_3679: (crate::check::types::Ty, crate::check::types::St)| {
                    let (y_p6, s2_p7) = conv_type_f_3679;
                    ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p3, &y_p6), s2_p7.clone()))
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }))
}

/// The step machine of `ConvTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
/// ```
pub struct ConvTypes {
    pub cx_p0: Cx,
    pub st_p1: crate::check::types::St,
    pub ts_p2: crate::prelude::Array<crate::syntax::Type>,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)> for ConvTypes {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let ts_p2 = &self.ts_p2;
        crate::prelude::fold_job(ts_p2.clone(), (crate::prelude::Array::new(), st_p1.clone()), {
            let cx_p0x = cx_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)| {
                let cx_p0xy = cx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p3, s_p4) = p0;
                    let x_p5 = p1;
                    crate::prelude::call_then(start_conv_type_f(cx_p0xy.clone(), s_p4.clone(), x_p5.clone()), move |conv_type_f_3679: (crate::check::types::Ty, crate::check::types::St)| {
                        let (y_p6, s2_p7) = conv_type_f_3679;
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p3, &y_p6), s2_p7.clone()))
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start ConvTypes, x`: what the function value is when passed to `@Run`.
pub fn start_conv_types_f(cx_p0: Cx, st_p1: crate::check::types::St, ts_p2: crate::prelude::Array<crate::syntax::Type>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvTypes { cx_p0, st_p1, ts_p2 })
}

/// ```prism
/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
/// ```
pub fn conv_named_f(cx_p0: &Cx, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, args_p3: &crate::prelude::Array<crate::syntax::Type>, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let name_p5 = crate::check::env::dotted_f(&n_p2.path_p);
    if (&crate::prelude::len(&n_p2.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::is_lower_text_f(&name_p5) {
        if &crate::prelude::len(args_p3) > &crate::prelude::Nat::from(0u32) {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), span_p4, &crate::prelude::Text::lit("this checker does not implement higher-kinded traits")))
        } else {
            (crate::check::types::Ty::TyQ(name_p5.clone()), st_p1.clone())
        }
    } else {
        if (&name_p5 == &crate::prelude::Text::lit("Element")) || (&name_p5 == &crate::prelude::Text::lit("Prelude.Element")) {
            match crate::prelude::len(args_p3) {
                m4276_0 if (&m4276_0 == &crate::prelude::Nat::from(0u32)) => (crate::check::types::Ty::TyElem(cx_p0.scope_p.clone(), ::std::rc::Rc::new(crate::check::types::t_unit_p())), st_p1.clone()),
                m4276_1 if (&m4276_1 == &crate::prelude::Nat::from(1u32)) => {
                    let (o_p6, st2_p7) = conv_type_f(cx_p0, st_p1, &crate::prelude::or(&crate::prelude::index(args_p3, &crate::prelude::Nat::from(0u32)), &dummy_type_p()));
                    (crate::check::types::Ty::TyElem(cx_p0.scope_p.clone(), ::std::rc::Rc::new(o_p6.clone())), st2_p7.clone())
                },
                m4276_2 if (&m4276_2 == &crate::prelude::Nat::from(2u32)) => {
                    let (rw_p8, st2_p9) = conv_row_f(cx_p0, st_p1, &crate::prelude::or(&crate::prelude::index(args_p3, &crate::prelude::Nat::from(0u32)), &dummy_type_p()));
                    let (o_pa, st3_pb) = conv_type_f(cx_p0, &st2_p9, &crate::prelude::or(&crate::prelude::index(args_p3, &crate::prelude::Nat::from(1u32)), &dummy_type_p()));
                    (crate::check::types::Ty::TyElem(rw_p8.clone(), ::std::rc::Rc::new(o_pa.clone())), st3_pb.clone())
                },
                _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("kind"), span_p4, &crate::prelude::Text::from(format!("`Element` takes a row and a type; here it has {}", &crate::check::errors::count_word_f(&crate::prelude::len(args_p3)))))),
                _ => unreachable!("no arm matched"),
            }
        } else {
            if &name_p5 == &crate::prelude::Text::lit("Elem") {
                match crate::prelude::len(args_p3) {
                    m4845_0 if (&m4845_0 == &crate::prelude::Nat::from(0u32)) => (crate::check::types::Ty::TyElemAny(cx_p0.scope_p.clone()), st_p1.clone()),
                    m4845_1 if (&m4845_1 == &crate::prelude::Nat::from(1u32)) => {
                        let (rw_pc, st2_pd) = conv_row_f(cx_p0, st_p1, &crate::prelude::or(&crate::prelude::index(args_p3, &crate::prelude::Nat::from(0u32)), &dummy_type_p()));
                        (crate::check::types::Ty::TyElemAny(rw_pc.clone()), st2_pd.clone())
                    },
                    _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("kind"), span_p4, &crate::prelude::Text::from(format!("`Elem` takes a row; here it has {}", &crate::check::errors::count_word_f(&crate::prelude::len(args_p3)))))),
                    _ => unreachable!("no arm matched"),
                }
            } else {
                if &name_p5 == &crate::prelude::Text::lit("Answer") {
                    match crate::prelude::len(args_p3) {
                        m5361_0 if (&m5361_0 == &crate::prelude::Nat::from(0u32)) => (crate::check::types::answer_type_f(&cx_p0.scope_p), st_p1.clone()),
                        m5361_1 if (&m5361_1 == &crate::prelude::Nat::from(1u32)) => {
                            let (rw_pe, st2_pf) = conv_row_f(cx_p0, st_p1, &crate::prelude::or(&crate::prelude::index(args_p3, &crate::prelude::Nat::from(0u32)), &dummy_type_p()));
                            (crate::check::types::answer_type_f(&rw_pe), st2_pf.clone())
                        },
                        _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("kind"), span_p4, &crate::prelude::Text::from(format!("`Answer` takes a row; here it has {}", &crate::check::errors::count_word_f(&crate::prelude::len(args_p3)))))),
                        _ => unreachable!("no arm matched"),
                    }
                } else {
                    if &name_p5 == &crate::prelude::Text::lit("Wired") {
                        (crate::check::types::Ty::TyCon(name_p5.clone(), crate::prelude::Array::new()), st_p1.clone())
                    } else {
                        if &name_p5 == &crate::prelude::Text::lit("Instant") {
                            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), span_p4, &crate::prelude::Text::lit("this checker does not implement `Instant`")))
                        } else {
                            if crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("U16"), crate::prelude::Text::lit("U32"), crate::prelude::Text::lit("U64"), crate::prelude::Text::lit("U128"), crate::prelude::Text::lit("I8"), crate::prelude::Text::lit("I16"), crate::prelude::Text::lit("I32"), crate::prelude::Text::lit("I64"), crate::prelude::Text::lit("I128")]), &name_p5) {
                                (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), span_p4, &crate::prelude::Text::lit("this checker does not implement sized integers other than `U8`")))
                            } else {
                                if crate::check::env::is_prim_type_f(&name_p5) {
                                    if &crate::prelude::len(args_p3) == &crate::prelude::Nat::from(0u32) {
                                        (crate::check::types::Ty::TyCon(name_p5.clone(), crate::prelude::Array::new()), st_p1.clone())
                                    } else {
                                        (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("kind"), span_p4, &crate::prelude::Text::from(format!("`{}` takes no type; here it has {}", &name_p5, &crate::check::errors::count_word_f(&crate::prelude::len(args_p3))))))
                                    }
                                } else {
                                    if (&name_p5 == &crate::prelude::Text::lit("Buffer")) || (&name_p5 == &crate::prelude::Text::lit("Table")) {
                                        {
                                            let want_pg = if &name_p5 == &crate::prelude::Text::lit("Buffer") {
                                                crate::prelude::Nat::from(1u32)
                                            } else {
                                                crate::prelude::Nat::from(2u32)
                                            };
                                            let (xs_ph, st2_pi) = conv_types_f(cx_p0, st_p1, args_p3);
                                            if &crate::prelude::len(args_p3) == &want_pg {
                                                (crate::check::types::Ty::TyCon(name_p5.clone(), xs_ph.clone()), st2_pi.clone())
                                            } else {
                                                (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st2_pi, &crate::prelude::Text::lit("kind"), span_p4, &crate::prelude::Text::from(format!("`{}` takes {} types; here it has {}", &name_p5, &crate::check::errors::count_word_f(&want_pg), &crate::check::errors::count_word_f(&crate::prelude::len(args_p3))))))
                                            }
                                        }
                                    } else {
                                        {
                                            let (key_oj, why_pk) = crate::check::env::names::resolve_type_f(&cx_p0.g_p, &cx_p0.home_p, &n_p2.path_p);
                                            match &key_oj {
                                                ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), span_p4, &crate::prelude::Text::from(format!("no type `{}`", &name_p5)))),
                                                ::std::option::Option::Some(qk_pl) => {
                                                    let ti_pm = crate::prelude::or(&crate::prelude::get(&cx_p0.g_p.types_p, qk_pl), &crate::check::env::names::dummy_ty_info_p());
                                                    let st1_pn = if &why_pk == &crate::prelude::Text::lit("collision") {
                                                        crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("collision"), span_p4, &crate::prelude::Text::from(format!("`{}` is declared by two modules this file reaches by a bare name", &name_p5)), &crate::prelude::Text::from(format!("write it qualified, `{}`, or rename this file\'s own", qk_pl)))
                                                    } else {
                                                        st_p1.clone()
                                                    };
                                                    match crate::prelude::get(&cx_p0.g_p.assoc_names_p, qk_pl) {
                                                        ::std::option::Option::Some(tr_po) => if &crate::prelude::len(args_p3) == &crate::prelude::Nat::from(1u32) {
                                                            {
                                                                let (a_pp, st2_pq) = conv_type_f(cx_p0, &st1_pn, &crate::prelude::or(&crate::prelude::index(args_p3, &crate::prelude::Nat::from(0u32)), &dummy_type_p()));
                                                                (crate::check::types::Ty::TyAssoc(tr_po, crate::check::types::bare_name_f(qk_pl), ::std::rc::Rc::new(a_pp.clone())), st2_pq.clone())
                                                            }
                                                        } else {
                                                            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st1_pn, &crate::prelude::Text::lit("kind"), span_p4, &crate::prelude::Text::from(format!("the associated type `{}` takes one type; here it has {}", &name_p5, &crate::check::errors::count_word_f(&crate::prelude::len(args_p3))))))
                                                        },
                                                        ::std::option::Option::None => conv_named_type_f(cx_p0, &st1_pn, qk_pl, &ti_pm, &name_p5, args_p3, span_p4),
                                                    }
                                                },
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `ConvNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
/// ```
pub struct ConvNamed {
    pub cx_p0: Cx,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub args_p3: crate::prelude::Array<crate::syntax::Type>,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ConvNamed {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let name_p5 = crate::check::env::dotted_f(&n_p2.path_p);
        if (&crate::prelude::len(&n_p2.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::is_lower_text_f(&name_p5) {
            if &crate::prelude::len(args_p3) > &crate::prelude::Nat::from(0u32) {
                ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), span_p4, &crate::prelude::Text::lit("this checker does not implement higher-kinded traits"))))
            } else {
                ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyQ(name_p5.clone()), st_p1.clone()))
            }
        } else {
            if (&name_p5 == &crate::prelude::Text::lit("Element")) || (&name_p5 == &crate::prelude::Text::lit("Prelude.Element")) {
                match crate::prelude::len(args_p3) {
                    m4276_0 if (&m4276_0 == &crate::prelude::Nat::from(0u32)) => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(cx_p0.scope_p.clone(), ::std::rc::Rc::new(crate::check::types::t_unit_p())), st_p1.clone())),
                    m4276_1 if (&m4276_1 == &crate::prelude::Nat::from(1u32)) => {
                        let args_p3x = args_p3.clone();
                        let cx_p0x = cx_p0.clone();
                        let st_p1x = st_p1.clone();
                        crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st_p1x.clone(), crate::prelude::or(&crate::prelude::index(&args_p3x, &crate::prelude::Nat::from(0u32)), &dummy_type_p())), move |conv_type_f_4388: (crate::check::types::Ty, crate::check::types::St)| {
                            let (o_p6, st2_p7) = conv_type_f_4388;
                            ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(cx_p0x.scope_p.clone(), ::std::rc::Rc::new(o_p6.clone())), st2_p7.clone()))
                        })
                    },
                    m4276_2 if (&m4276_2 == &crate::prelude::Nat::from(2u32)) => {
                        let args_p3x = args_p3.clone();
                        let cx_p0x = cx_p0.clone();
                        let st_p1x = st_p1.clone();
                        crate::prelude::call_then(start_conv_row_f(cx_p0x.clone(), st_p1x.clone(), crate::prelude::or(&crate::prelude::index(&args_p3x, &crate::prelude::Nat::from(0u32)), &dummy_type_p())), move |conv_row_f_4524: (crate::check::types::Rw, crate::check::types::St)| {
                            let (rw_p8, st2_p9) = conv_row_f_4524;
                            crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st2_p9.clone(), crate::prelude::or(&crate::prelude::index(&args_p3x, &crate::prelude::Nat::from(1u32)), &dummy_type_p())), move |conv_type_f_4597: (crate::check::types::Ty, crate::check::types::St)| {
                                let (o_pa, st3_pb) = conv_type_f_4597;
                                ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(rw_p8.clone(), ::std::rc::Rc::new(o_pa.clone())), st3_pb.clone()))
                            })
                        })
                    },
                    _ => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("kind"), span_p4, &crate::prelude::Text::from(format!("`Element` takes a row and a type; here it has {}", &crate::check::errors::count_word_f(&crate::prelude::len(args_p3))))))),
                    _ => unreachable!("no arm matched"),
                }
            } else {
                if &name_p5 == &crate::prelude::Text::lit("Elem") {
                    match crate::prelude::len(args_p3) {
                        m4845_0 if (&m4845_0 == &crate::prelude::Nat::from(0u32)) => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyElemAny(cx_p0.scope_p.clone()), st_p1.clone())),
                        m4845_1 if (&m4845_1 == &crate::prelude::Nat::from(1u32)) => {
                            let args_p3x = args_p3.clone();
                            let cx_p0x = cx_p0.clone();
                            let st_p1x = st_p1.clone();
                            crate::prelude::call_then(start_conv_row_f(cx_p0x.clone(), st_p1x.clone(), crate::prelude::or(&crate::prelude::index(&args_p3x, &crate::prelude::Nat::from(0u32)), &dummy_type_p())), move |conv_row_f_4952: (crate::check::types::Rw, crate::check::types::St)| {
                                let (rw_pc, st2_pd) = conv_row_f_4952;
                                ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyElemAny(rw_pc.clone()), st2_pd.clone()))
                            })
                        },
                        _ => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("kind"), span_p4, &crate::prelude::Text::from(format!("`Elem` takes a row; here it has {}", &crate::check::errors::count_word_f(&crate::prelude::len(args_p3))))))),
                        _ => unreachable!("no arm matched"),
                    }
                } else {
                    if &name_p5 == &crate::prelude::Text::lit("Answer") {
                        match crate::prelude::len(args_p3) {
                            m5361_0 if (&m5361_0 == &crate::prelude::Nat::from(0u32)) => ::prism_rtl::Turn::Finished((crate::check::types::answer_type_f(&cx_p0.scope_p), st_p1.clone())),
                            m5361_1 if (&m5361_1 == &crate::prelude::Nat::from(1u32)) => {
                                let args_p3x = args_p3.clone();
                                let cx_p0x = cx_p0.clone();
                                let st_p1x = st_p1.clone();
                                crate::prelude::call_then(start_conv_row_f(cx_p0x.clone(), st_p1x.clone(), crate::prelude::or(&crate::prelude::index(&args_p3x, &crate::prelude::Nat::from(0u32)), &dummy_type_p())), move |conv_row_f_5471: (crate::check::types::Rw, crate::check::types::St)| {
                                    let (rw_pe, st2_pf) = conv_row_f_5471;
                                    ::prism_rtl::Turn::Finished((crate::check::types::answer_type_f(&rw_pe), st2_pf.clone()))
                                })
                            },
                            _ => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("kind"), span_p4, &crate::prelude::Text::from(format!("`Answer` takes a row; here it has {}", &crate::check::errors::count_word_f(&crate::prelude::len(args_p3))))))),
                            _ => unreachable!("no arm matched"),
                        }
                    } else {
                        if &name_p5 == &crate::prelude::Text::lit("Wired") {
                            ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(name_p5.clone(), crate::prelude::Array::new()), st_p1.clone()))
                        } else {
                            if &name_p5 == &crate::prelude::Text::lit("Instant") {
                                ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), span_p4, &crate::prelude::Text::lit("this checker does not implement `Instant`"))))
                            } else {
                                if crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("U16"), crate::prelude::Text::lit("U32"), crate::prelude::Text::lit("U64"), crate::prelude::Text::lit("U128"), crate::prelude::Text::lit("I8"), crate::prelude::Text::lit("I16"), crate::prelude::Text::lit("I32"), crate::prelude::Text::lit("I64"), crate::prelude::Text::lit("I128")]), &name_p5) {
                                    ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), span_p4, &crate::prelude::Text::lit("this checker does not implement sized integers other than `U8`"))))
                                } else {
                                    if crate::check::env::is_prim_type_f(&name_p5) {
                                        if &crate::prelude::len(args_p3) == &crate::prelude::Nat::from(0u32) {
                                            ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(name_p5.clone(), crate::prelude::Array::new()), st_p1.clone()))
                                        } else {
                                            ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("kind"), span_p4, &crate::prelude::Text::from(format!("`{}` takes no type; here it has {}", &name_p5, &crate::check::errors::count_word_f(&crate::prelude::len(args_p3)))))))
                                        }
                                    } else {
                                        if (&name_p5 == &crate::prelude::Text::lit("Buffer")) || (&name_p5 == &crate::prelude::Text::lit("Table")) {
                                            {
                                                let want_pg = if &name_p5 == &crate::prelude::Text::lit("Buffer") {
                                                    crate::prelude::Nat::from(1u32)
                                                } else {
                                                    crate::prelude::Nat::from(2u32)
                                                };
                                                let args_p3x = args_p3.clone();
                                                let cx_p0x = cx_p0.clone();
                                                let span_p4x = span_p4.clone();
                                                let st_p1x = st_p1.clone();
                                                crate::prelude::call_then(start_conv_types_f(cx_p0x.clone(), st_p1x.clone(), args_p3x.clone()), move |conv_types_f_6391: (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)| {
                                                    let (xs_ph, st2_pi) = conv_types_f_6391;
                                                    if &crate::prelude::len(&args_p3x) == &want_pg {
                                                        ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(name_p5.clone(), xs_ph.clone()), st2_pi.clone()))
                                                    } else {
                                                        ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st2_pi, &crate::prelude::Text::lit("kind"), &span_p4x, &crate::prelude::Text::from(format!("`{}` takes {} types; here it has {}", &name_p5, &crate::check::errors::count_word_f(&want_pg), &crate::check::errors::count_word_f(&crate::prelude::len(&args_p3x)))))))
                                                    }
                                                })
                                            }
                                        } else {
                                            {
                                                let (key_oj, why_pk) = crate::check::env::names::resolve_type_f(&cx_p0.g_p, &cx_p0.home_p, &n_p2.path_p);
                                                match &key_oj {
                                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), span_p4, &crate::prelude::Text::from(format!("no type `{}`", &name_p5))))),
                                                    ::std::option::Option::Some(qk_pl) => {
                                                        let ti_pm = crate::prelude::or(&crate::prelude::get(&cx_p0.g_p.types_p, qk_pl), &crate::check::env::names::dummy_ty_info_p());
                                                        let st1_pn = if &why_pk == &crate::prelude::Text::lit("collision") {
                                                            crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("collision"), span_p4, &crate::prelude::Text::from(format!("`{}` is declared by two modules this file reaches by a bare name", &name_p5)), &crate::prelude::Text::from(format!("write it qualified, `{}`, or rename this file\'s own", qk_pl)))
                                                        } else {
                                                            st_p1.clone()
                                                        };
                                                        match crate::prelude::get(&cx_p0.g_p.assoc_names_p, qk_pl) {
                                                            ::std::option::Option::Some(tr_po) => if &crate::prelude::len(args_p3) == &crate::prelude::Nat::from(1u32) {
                                                                {
                                                                    let args_p3x = args_p3.clone();
                                                                    let cx_p0x = cx_p0.clone();
                                                                    let qk_plx = qk_pl.clone();
                                                                    crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st1_pn.clone(), crate::prelude::or(&crate::prelude::index(&args_p3x, &crate::prelude::Nat::from(0u32)), &dummy_type_p())), move |conv_type_f_7369: (crate::check::types::Ty, crate::check::types::St)| {
                                                                        let (a_pp, st2_pq) = conv_type_f_7369;
                                                                        ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyAssoc(tr_po.clone(), crate::check::types::bare_name_f(&qk_plx), ::std::rc::Rc::new(a_pp.clone())), st2_pq.clone()))
                                                                    })
                                                                }
                                                            } else {
                                                                ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st1_pn, &crate::prelude::Text::lit("kind"), span_p4, &crate::prelude::Text::from(format!("the associated type `{}` takes one type; here it has {}", &name_p5, &crate::check::errors::count_word_f(&crate::prelude::len(args_p3)))))))
                                                            },
                                                            ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(ConvNamedType { cx_p0: cx_p0.clone(), st1_p1: st1_pn.clone(), qk_p2: qk_pl.clone(), ti_p3: ti_pm.clone(), name_p4: name_p5.clone(), args_p5: args_p3.clone(), span_p6: span_p4.clone() })),
                                                        }
                                                    },
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// `Start ConvNamed, x`: what the function value is when passed to `@Run`.
pub fn start_conv_named_f(cx_p0: Cx, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, args_p3: crate::prelude::Array<crate::syntax::Type>, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvNamed { cx_p0, st_p1, n_p2, args_p3, span_p4 })
}

/// ```prism
/// ConvNamedType: unbounded fn Cx, St, Text, TyInfo, Text, [Type], Range -> ((Ty, St))
/// ```
pub fn conv_named_type_f(cx_p0: &Cx, st1_p1: &crate::check::types::St, qk_p2: &crate::prelude::Text, ti_p3: &crate::check::env::TyInfo, name_p4: &crate::prelude::Text, args_p5: &crate::prelude::Array<crate::syntax::Type>, span_p6: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (xs_p7, st2_p8) = conv_types_f(cx_p0, st1_p1, args_p5);
    if &crate::prelude::len(&xs_p7) != &crate::prelude::len(&ti_p3.params_p) {
        (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st2_p8, &crate::prelude::Text::lit("kind"), span_p6, &crate::prelude::Text::from(format!("`{}` takes {} type{}; here it has {}", name_p4, &crate::check::errors::count_word_f(&crate::prelude::len(&ti_p3.params_p)), &(if &crate::prelude::len(&ti_p3.params_p) == &crate::prelude::Nat::from(1u32) {
            crate::prelude::Text::lit("")
        } else {
            crate::prelude::Text::lit("s")
        }), &crate::check::errors::count_word_f(&crate::prelude::len(&xs_p7))))))
    } else {
        match &ti_p3.body_p {
            crate::check::env::TyBody::BAlias(body_p9) => (crate::check::types::schemes::subst_q_f(&param_inst_f(&ti_p3.params_p, &xs_p7), body_p9), st2_p8.clone()),
            crate::check::env::TyBody::BRowKind => (crate::check::types::Ty::TyCon(qk_p2.clone(), xs_p7.clone()), st2_p8.clone()),
            _ => (crate::check::types::Ty::TyCon(qk_p2.clone(), xs_p7.clone()), st2_p8.clone()),
        }
    }
}

/// The step machine of `ConvNamedType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvNamedType: unbounded fn Cx, St, Text, TyInfo, Text, [Type], Range -> ((Ty, St))
/// ```
pub struct ConvNamedType {
    pub cx_p0: Cx,
    pub st1_p1: crate::check::types::St,
    pub qk_p2: crate::prelude::Text,
    pub ti_p3: crate::check::env::TyInfo,
    pub name_p4: crate::prelude::Text,
    pub args_p5: crate::prelude::Array<crate::syntax::Type>,
    pub span_p6: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ConvNamedType {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st1_p1 = &self.st1_p1;
        let qk_p2 = &self.qk_p2;
        let ti_p3 = &self.ti_p3;
        let name_p4 = &self.name_p4;
        let args_p5 = &self.args_p5;
        let span_p6 = &self.span_p6;
        let args_p5x = args_p5.clone();
        let cx_p0x = cx_p0.clone();
        let name_p4x = name_p4.clone();
        let qk_p2x = qk_p2.clone();
        let span_p6x = span_p6.clone();
        let st1_p1x = st1_p1.clone();
        let ti_p3x = ti_p3.clone();
        crate::prelude::call_then(start_conv_types_f(cx_p0x.clone(), st1_p1x.clone(), args_p5x.clone()), move |conv_types_f_7851: (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)| {
            let (xs_p7, st2_p8) = conv_types_f_7851;
            if &crate::prelude::len(&xs_p7) != &crate::prelude::len(&ti_p3x.params_p) {
                ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st2_p8, &crate::prelude::Text::lit("kind"), &span_p6x, &crate::prelude::Text::from(format!("`{}` takes {} type{}; here it has {}", &name_p4x, &crate::check::errors::count_word_f(&crate::prelude::len(&ti_p3x.params_p)), &(if &crate::prelude::len(&ti_p3x.params_p) == &crate::prelude::Nat::from(1u32) {
                    crate::prelude::Text::lit("")
                } else {
                    crate::prelude::Text::lit("s")
                }), &crate::check::errors::count_word_f(&crate::prelude::len(&xs_p7)))))))
            } else {
                match &ti_p3x.body_p {
                    crate::check::env::TyBody::BAlias(body_p9) => {
                        let body_p9x = body_p9.clone();
                        crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(param_inst_f(&ti_p3x.params_p, &xs_p7), body_p9x.clone()), move |subst_q_f_8127: crate::check::types::Ty| ::prism_rtl::Turn::Finished((subst_q_f_8127, st2_p8.clone())))
                    },
                    crate::check::env::TyBody::BRowKind => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(qk_p2x.clone(), xs_p7.clone()), st2_p8.clone())),
                    _ => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(qk_p2x.clone(), xs_p7.clone()), st2_p8.clone())),
                }
            }
        })
    }
}

/// `Start ConvNamedType, x`: what the function value is when passed to `@Run`.
pub fn start_conv_named_type_f(cx_p0: Cx, st1_p1: crate::check::types::St, qk_p2: crate::prelude::Text, ti_p3: crate::check::env::TyInfo, name_p4: crate::prelude::Text, args_p5: crate::prelude::Array<crate::syntax::Type>, span_p6: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvNamedType { cx_p0, st1_p1, qk_p2, ti_p3, name_p4, args_p5, span_p6 })
}

/// ```prism
/// let dummyType
/// ```
pub fn dummy_type_p() -> crate::syntax::Type {
    crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TAbsent), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// ParamInst: fn [Text], [Ty] -> Inst
/// ```
pub fn param_inst_f(ps_p0: &crate::prelude::Array<crate::prelude::Text>, xs_p1: &crate::prelude::Array<crate::check::types::Ty>) -> crate::check::types::schemes::Inst {
    crate::check::types::schemes::Inst { tys_p: crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(ps_p0)), &crate::prelude::Map::new(), &(|m_p2: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, i_p3: &crate::prelude::Nat| crate::prelude::insert(m_p2, &crate::prelude::or(&crate::prelude::index(ps_p0, i_p3), &crate::prelude::Text::lit("")), &crate::prelude::or(&crate::prelude::index(xs_p1, i_p3), &crate::check::types::Ty::TyErr)))), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() }
}

/// ```prism
/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
/// ```
pub fn conv_row_f(cx_p0: &Cx, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Type) -> (crate::check::types::Rw, crate::check::types::St) {
    let (fams_p5, vars_p6, st2_p7) = row_parts_f(cx_p0, st_p1, t_p2);
    let st3_p3 = if &crate::prelude::len(&vars_p6) > &crate::prelude::Nat::from(1u32) {
        crate::check::types::recording::err_fix_f(&st2_p7, &crate::prelude::Text::lit("row-two-tails"), &t_p2.span_p, &crate::prelude::Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::chars::join_f(&vars_p6, &crate::prelude::Text::lit(" | ")))), &crate::prelude::Text::lit("keep one variable"))
    } else {
        st2_p7.clone()
    };
    let tail_p4 = match crate::prelude::index(&vars_p6, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(v_p8) => crate::check::types::Tail::TlQ(v_p8),
        ::std::option::Option::None => crate::check::types::Tail::TlClosed,
    };
    (crate::check::types::Rw { fams_p: crate::check::types::sort_texts_f(&fams_p5), minus_p: crate::prelude::Array::new(), tail_p: tail_p4.clone() }, st3_p3.clone())
}

/// The step machine of `ConvRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
/// ```
pub struct ConvRow {
    pub cx_p0: Cx,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Type,
}

impl ::prism_rtl::Job<(crate::check::types::Rw, crate::check::types::St)> for ConvRow {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Rw, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let cx_p0x = cx_p0.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(start_row_parts_f(cx_p0x.clone(), st_p1x.clone(), t_p2x.clone()), move |row_parts_f_8662: (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)| {
            let (fams_p5, vars_p6, st2_p7) = row_parts_f_8662;
            let st3_p3 = if &crate::prelude::len(&vars_p6) > &crate::prelude::Nat::from(1u32) {
                crate::check::types::recording::err_fix_f(&st2_p7, &crate::prelude::Text::lit("row-two-tails"), &t_p2x.span_p, &crate::prelude::Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::chars::join_f(&vars_p6, &crate::prelude::Text::lit(" | ")))), &crate::prelude::Text::lit("keep one variable"))
            } else {
                st2_p7.clone()
            };
            let tail_p4 = match crate::prelude::index(&vars_p6, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(v_p8) => crate::check::types::Tail::TlQ(v_p8),
                ::std::option::Option::None => crate::check::types::Tail::TlClosed,
            };
            ::prism_rtl::Turn::Finished((crate::check::types::Rw { fams_p: crate::check::types::sort_texts_f(&fams_p5), minus_p: crate::prelude::Array::new(), tail_p: tail_p4.clone() }, st3_p3.clone()))
        })
    }
}

/// `Start ConvRow, x`: what the function value is when passed to `@Run`.
pub fn start_conv_row_f(cx_p0: Cx, st_p1: crate::check::types::St, t_p2: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Rw, crate::check::types::St)>> {
    ::std::rc::Rc::new(ConvRow { cx_p0, st_p1, t_p2 })
}

/// ```prism
/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
/// ```
pub fn row_parts_f(cx_p0: &Cx, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Type) -> (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St) {
    match &*t_p2.kind_p {
        crate::syntax::TypeKind::TRowUnion(ts_p3) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p3.clone(), (crate::prelude::Array::new(), crate::prelude::Array::new(), st_p1.clone()), {
            let cx_p0x = cx_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), crate::syntax::Type)| {
                let cx_p0xy = cx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (fs_p4, vs_p5, s_p6) = p0;
                    let x_p7 = p1;
                    crate::prelude::call_then(start_row_parts_f(cx_p0xy.clone(), s_p6.clone(), x_p7.clone()), move |row_parts_f_9169: (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)| {
                        let (f2_p8, v2_p9, s2_pa) = row_parts_f_9169;
                        ::prism_rtl::Turn::Finished((crate::prelude::append(&fs_p4, &f2_p8), crate::prelude::append(&vs_p5, &v2_p9), s2_pa.clone()))
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)>>>
        })),
        crate::syntax::TypeKind::TGroup(x_pb) => row_parts_f(cx_p0, st_p1, &**x_pb),
        crate::syntax::TypeKind::TFamily(q_pc) => (crate::prelude::Array::from(vec![crate::check::env::dotted_f(&q_pc.path_p)]), crate::prelude::Array::new(), crate::check::env::names::check_family_f(&cx_p0.g_p, st_p1, &crate::check::env::dotted_f(&q_pc.path_p), &q_pc.span_p)),
        crate::syntax::TypeKind::TName(n_pd, m9059_3_1) if (m9059_3_1.len() == 0) => {
            let name_pe = crate::check::env::dotted_f(&n_pd.path_p);
            if (&crate::prelude::len(&n_pd.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::is_lower_text_f(&name_pe) {
                (crate::prelude::Array::new(), crate::prelude::Array::from(vec![name_pe.clone()]), st_p1.clone())
            } else {
                if &name_pe == &crate::prelude::Text::lit("Element") {
                    (cx_p0.scope_p.fams_p.clone(), tail_names_f(&cx_p0.scope_p.tail_p), st_p1.clone())
                } else {
                    (crate::prelude::Array::new(), crate::prelude::Array::new(), crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("row-single-tag"), &t_p2.span_p, &crate::prelude::Text::from(format!("a row names families, not tags: `{}`", &name_pe)), &crate::prelude::Text::from(format!("write `{}.*`", &crate::check::env::dotted_f(&crate::prelude::take(&n_pd.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&n_pd.path_p))))))))
                }
            }
        },
        _ => (crate::prelude::Array::new(), crate::prelude::Array::new(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("kind"), &t_p2.span_p, &crate::prelude::Text::lit("this is not a row"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
/// ```
pub struct RowParts {
    pub cx_p0: Cx,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Type,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)> for RowParts {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        match &*t_p2.kind_p {
            crate::syntax::TypeKind::TRowUnion(ts_p3) => crate::prelude::fold_job(ts_p3.clone(), (crate::prelude::Array::new(), crate::prelude::Array::new(), st_p1.clone()), {
                let cx_p0x = cx_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), crate::syntax::Type)| {
                    let cx_p0xy = cx_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (fs_p4, vs_p5, s_p6) = p0;
                        let x_p7 = p1;
                        crate::prelude::call_then(start_row_parts_f(cx_p0xy.clone(), s_p6.clone(), x_p7.clone()), move |row_parts_f_9169: (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)| {
                            let (f2_p8, v2_p9, s2_pa) = row_parts_f_9169;
                            ::prism_rtl::Turn::Finished((crate::prelude::append(&fs_p4, &f2_p8), crate::prelude::append(&vs_p5, &v2_p9), s2_pa.clone()))
                        })
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)>>>
            }).cycle(),
            crate::syntax::TypeKind::TGroup(x_pb) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RowParts { cx_p0: cx_p0.clone(), st_p1: st_p1.clone(), t_p2: (**x_pb).clone() })),
            crate::syntax::TypeKind::TFamily(q_pc) => ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![crate::check::env::dotted_f(&q_pc.path_p)]), crate::prelude::Array::new(), crate::check::env::names::check_family_f(&cx_p0.g_p, st_p1, &crate::check::env::dotted_f(&q_pc.path_p), &q_pc.span_p))),
            crate::syntax::TypeKind::TName(n_pd, m9059_3_1) if (m9059_3_1.len() == 0) => {
                let name_pe = crate::check::env::dotted_f(&n_pd.path_p);
                if (&crate::prelude::len(&n_pd.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::is_lower_text_f(&name_pe) {
                    ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::from(vec![name_pe.clone()]), st_p1.clone()))
                } else {
                    if &name_pe == &crate::prelude::Text::lit("Element") {
                        ::prism_rtl::Turn::Finished((cx_p0.scope_p.fams_p.clone(), tail_names_f(&cx_p0.scope_p.tail_p), st_p1.clone()))
                    } else {
                        ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::new(), crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("row-single-tag"), &t_p2.span_p, &crate::prelude::Text::from(format!("a row names families, not tags: `{}`", &name_pe)), &crate::prelude::Text::from(format!("write `{}.*`", &crate::check::env::dotted_f(&crate::prelude::take(&n_pd.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&n_pd.path_p)))))))))
                    }
                }
            },
            _ => ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::new(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("kind"), &t_p2.span_p, &crate::prelude::Text::lit("this is not a row")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start RowParts, x`: what the function value is when passed to `@Run`.
pub fn start_row_parts_f(cx_p0: Cx, st_p1: crate::check::types::St, t_p2: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)>> {
    ::std::rc::Rc::new(RowParts { cx_p0, st_p1, t_p2 })
}

/// ```prism
/// TailNames: fn Tail -> [Text]
/// ```
pub fn tail_names_f(tail0: &crate::check::types::Tail) -> crate::prelude::Array<crate::prelude::Text> {
    match tail0 {
        crate::check::types::Tail::TlQ(v_p0) => crate::prelude::Array::from(vec![v_p0.clone()]),
        crate::check::types::Tail::TlRigid(v_p1) => crate::prelude::Array::from(vec![v_p1.clone()]),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
/// ```
pub fn sig_scheme_f(cx_p0: &Cx, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Type, bounds_p3: &crate::prelude::Array<crate::syntax::decls::Bound>) -> (crate::check::types::Scheme, crate::check::types::St) {
    let row_vars_p4 = crate::check::types::union_texts_f(&cx_p0.row_vars_p, &row_vars_of_type_f(t_p2));
    let cx2_p5 = {
        let mut this: Cx = cx_p0.clone();
        this.row_vars_p = row_vars_p4.clone();
        this.unwritten_p = crate::check::types::Col::CBound;
        this
    };
    let written_p6 = color_vars_of_type_f(t_p2);
    let (bs_pa, st1_pb) = conv_bounds_f(cx_p0, st_p1, bounds_p3);
    let (ty_pc, defaults_pd, joins_pe, st3_pf) = sig_type_f(&cx2_p5, &st1_pb, t_p2, &written_p6);
    let tvs_p7 = crate::prelude::filter(&type_vars_of_type_f(t_p2), &(|v_pg: &crate::prelude::Text| !crate::check::types::has_text_f(&row_vars_p4, v_pg)));
    let cqs_p8 = crate::prelude::fold(&defaults_pd, &written_p6, &(|acc_ph: &crate::prelude::Array<crate::prelude::Text>, v_pi: &crate::prelude::Text| crate::check::types::add_text_f(acc_ph, v_pi)));
    let rows_used_p9 = crate::prelude::run_to_end(crate::prelude::filter_job(row_vars_p4.clone(), {
        let t_p2x = t_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
            let t_p2xy = t_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let v_pj = p0;
                crate::prelude::call_then(start_row_vars_of_type_f(t_p2xy.clone()), move |row_vars_of_type_f_10690: crate::prelude::Array<crate::prelude::Text>| if crate::check::types::has_text_f(&row_vars_of_type_f_10690, &v_pj) {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(UsesScope { t_p0: t_p2xy.clone() }))
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    (crate::check::types::Scheme { qs_p: tvs_p7.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: rows_used_p9.clone(), cqs_p: cqs_p8.clone(), cjoins_p: joins_pe.clone(), bounds_p: bs_pa.clone(), eqs_p: crate::prelude::Array::new(), ty_p: ty_pc.clone() }, st3_pf.clone())
}

/// The step machine of `SigScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
/// ```
pub struct SigScheme {
    pub cx_p0: Cx,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Type,
    pub bounds_p3: crate::prelude::Array<crate::syntax::decls::Bound>,
}

impl ::prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)> for SigScheme {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Scheme, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let bounds_p3 = &self.bounds_p3;
        let bounds_p3x = bounds_p3.clone();
        let cx_p0x = cx_p0.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(start_row_vars_of_type_f(t_p2x.clone()), move |row_vars_of_type_f_10251: crate::prelude::Array<crate::prelude::Text>| {
            let row_vars_p4 = crate::check::types::union_texts_f(&cx_p0x.row_vars_p, &row_vars_of_type_f_10251);
            let cx2_p5 = {
                let mut this: Cx = cx_p0x.clone();
                this.row_vars_p = row_vars_p4.clone();
                this.unwritten_p = crate::check::types::Col::CBound;
                this
            };
            crate::prelude::call_then(start_color_vars_of_type_f(t_p2x.clone()), move |color_vars_of_type_f_10372: crate::prelude::Array<crate::prelude::Text>| {
                let written_p6 = color_vars_of_type_f_10372;
                let (bs_pa, st1_pb) = conv_bounds_f(&cx_p0x, &st_p1x, &bounds_p3x);
                crate::prelude::call_then(start_sig_type_f(cx2_p5.clone(), st1_pb.clone(), t_p2x.clone(), written_p6.clone()), move |sig_type_f_10477: (crate::check::types::Ty, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St)| {
                    let (ty_pc, defaults_pd, joins_pe, st3_pf) = sig_type_f_10477;
                    crate::prelude::call_then(start_type_vars_of_type_f(t_p2x.clone()), move |type_vars_of_type_f_10528: crate::prelude::Array<crate::prelude::Text>| {
                        let tvs_p7 = crate::prelude::filter(&type_vars_of_type_f_10528, &(|v_pg: &crate::prelude::Text| !crate::check::types::has_text_f(&row_vars_p4, v_pg)));
                        let cqs_p8 = crate::prelude::fold(&defaults_pd, &written_p6, &(|acc_ph: &crate::prelude::Array<crate::prelude::Text>, v_pi: &crate::prelude::Text| crate::check::types::add_text_f(acc_ph, v_pi)));
                        crate::prelude::call_value(crate::prelude::filter_job(row_vars_p4.clone(), {
                            let t_p2xx = t_p2x.clone();
                            ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                                let t_p2xxy = t_p2xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let v_pj = p0;
                                    crate::prelude::call_then(start_row_vars_of_type_f(t_p2xxy.clone()), move |row_vars_of_type_f_10690: crate::prelude::Array<crate::prelude::Text>| if crate::check::types::has_text_f(&row_vars_of_type_f_10690, &v_pj) {
                                        ::prism_rtl::Turn::Finished(true)
                                    } else {
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(UsesScope { t_p0: t_p2xxy.clone() }))
                                    })
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                        }), move |filter_10659: crate::prelude::Array<crate::prelude::Text>| {
                            let rows_used_p9 = filter_10659;
                            ::prism_rtl::Turn::Finished((crate::check::types::Scheme { qs_p: tvs_p7.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: rows_used_p9.clone(), cqs_p: cqs_p8.clone(), cjoins_p: joins_pe.clone(), bounds_p: bs_pa.clone(), eqs_p: crate::prelude::Array::new(), ty_p: ty_pc.clone() }, st3_pf.clone()))
                        })
                    })
                })
            })
        })
    }
}

/// `Start SigScheme, x`: what the function value is when passed to `@Run`.
pub fn start_sig_scheme_f(cx_p0: Cx, st_p1: crate::check::types::St, t_p2: crate::syntax::Type, bounds_p3: crate::prelude::Array<crate::syntax::decls::Bound>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)>> {
    ::std::rc::Rc::new(SigScheme { cx_p0, st_p1, t_p2, bounds_p3 })
}

/// ```prism
/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub fn sig_type_f(cx_p0: &Cx, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Type, written_p3: &crate::prelude::Array<crate::prelude::Text>) -> (crate::check::types::Ty, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St) {
    match &*t_p2.kind_p {
        crate::syntax::TypeKind::TGroup(x_p4) => sig_type_f(cx_p0, st_p1, &**x_p4, written_p3),
        crate::syntax::TypeKind::TFn(color_p5, ps_p6, res_p7) => if mentions_time_f(t_p2) || !takes_closure_f(t_p2) {
            bounded_sig_f(cx_p0, st_p1, t_p2)
        } else {
            closure_sig_f(cx_p0, st_p1, color_p5, ps_p6, &**res_p7, written_p3)
        },
        _ => bounded_sig_f(cx_p0, st_p1, t_p2),
    }
}

/// The step machine of `SigType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub struct SigType {
    pub cx_p0: Cx,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Type,
    pub written_p3: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St)> for SigType {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let written_p3 = &self.written_p3;
        match &*t_p2.kind_p {
            crate::syntax::TypeKind::TGroup(x_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(SigType { cx_p0: cx_p0.clone(), st_p1: st_p1.clone(), t_p2: (**x_p4).clone(), written_p3: written_p3.clone() })),
            crate::syntax::TypeKind::TFn(color_p5, ps_p6, res_p7) => {
                let color_p5x = color_p5.clone();
                let cx_p0x = cx_p0.clone();
                let ps_p6x = ps_p6.clone();
                let res_p7x = (**res_p7).clone();
                let st_p1x = st_p1.clone();
                let t_p2x = t_p2.clone();
                let written_p3x = written_p3.clone();
                crate::prelude::call_then(start_mentions_time_f(t_p2x.clone()), move |mentions_time_f_11842: bool| if mentions_time_f_11842 || !takes_closure_f(&t_p2x) {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(BoundedSig { cx_p0: cx_p0x.clone(), st_p1: st_p1x.clone(), t_p2: t_p2x.clone() }))
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ClosureSig { cx_p0: cx_p0x.clone(), st_p1: st_p1x.clone(), color_p2: color_p5x.clone(), ps_p3: ps_p6x.clone(), res_p4: res_p7x.clone(), written_p5: written_p3x.clone() }))
                })
            },
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(BoundedSig { cx_p0: cx_p0.clone(), st_p1: st_p1.clone(), t_p2: t_p2.clone() })),
        }
    }
}

/// `Start SigType, x`: what the function value is when passed to `@Run`.
pub fn start_sig_type_f(cx_p0: Cx, st_p1: crate::check::types::St, t_p2: crate::syntax::Type, written_p3: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St)>> {
    ::std::rc::Rc::new(SigType { cx_p0, st_p1, t_p2, written_p3 })
}

/// ```prism
/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub fn bounded_sig_f(cx_p0: &Cx, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Type) -> (crate::check::types::Ty, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St) {
    let (ty_p3, st2_p4) = conv_type_f(cx_p0, st_p1, t_p2);
    (ty_p3.clone(), crate::prelude::Array::new(), crate::prelude::Array::new(), st2_p4.clone())
}

/// The step machine of `BoundedSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub struct BoundedSig {
    pub cx_p0: Cx,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Type,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St)> for BoundedSig {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let cx_p0x = cx_p0.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st_p1x.clone(), t_p2x.clone()), move |conv_type_f_12123: (crate::check::types::Ty, crate::check::types::St)| {
            let (ty_p3, st2_p4) = conv_type_f_12123;
            ::prism_rtl::Turn::Finished((ty_p3.clone(), crate::prelude::Array::new(), crate::prelude::Array::new(), st2_p4.clone()))
        })
    }
}

/// `Start BoundedSig, x`: what the function value is when passed to `@Run`.
pub fn start_bounded_sig_f(cx_p0: Cx, st_p1: crate::check::types::St, t_p2: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St)>> {
    ::std::rc::Rc::new(BoundedSig { cx_p0, st_p1, t_p2 })
}

/// ```prism
/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub fn closure_sig_f(cx_p0: &Cx, st_p1: &crate::check::types::St, color_p2: &crate::syntax::Color, ps_p3: &crate::prelude::Array<crate::syntax::Type>, res_p4: &crate::syntax::Type, written_p5: &crate::prelude::Array<crate::prelude::Text>) -> (crate::check::types::Ty, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St) {
    let (outer_set_ph, outer_w_pi) = written_col_f(color_p2);
    let bounded_outer_p6 = outer_set_ph && (&outer_w_pi == &crate::check::types::Col::CBound);
    let n_default_p7 = crate::prelude::len(&crate::prelude::run_to_end(crate::prelude::filter_job(ps_p3.clone(), ::std::rc::Rc::new(move |p0: crate::syntax::Type| crate::prelude::entered(crate::prelude::once_job(move || {
        let p_pj = p0;
        crate::prelude::call_then(start_is_fn_type_f(p_pj.clone()), move |is_fn_type_f_12461: bool| if is_fn_type_f_12461 {
            crate::prelude::call_then(start_top_color_f(p_pj.clone()), move |top_color_f_12493: crate::syntax::Color| ::prism_rtl::Turn::Finished(!writes_col_f(&top_color_f_12493)))
        } else {
            ::prism_rtl::Turn::Finished(false)
        })
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)));
    let names_p8 = fresh_col_names_f(written_p5, &(if bounded_outer_p6 { crate::prelude::Nat::from(0u32) } else { n_default_p7.clone() }));
    let (pcols_pp, _) = crate::prelude::run_to_end(crate::prelude::fold_job(ps_p3.clone(), (crate::prelude::Array::new(), crate::prelude::Nat::from(0u32)), {
        let bounded_outer_p6x = bounded_outer_p6;
        let names_p8x = names_p8.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(bool, crate::check::types::Col)>, crate::prelude::Nat), crate::syntax::Type)| {
            let bounded_outer_p6xy = bounded_outer_p6x;
            let names_p8xy = names_p8x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pk, k_pl) = p0;
                let p_pm = p1;
                crate::prelude::call_then(start_is_fn_type_f(p_pm.clone()), move |is_fn_type_f_12738: bool| if !is_fn_type_f_12738 {
                    ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(false, crate::check::types::Col::CBound)), k_pl.clone()))
                } else {
                    crate::prelude::call_then(start_top_color_f(p_pm.clone()), move |top_color_f_12843: crate::syntax::Color| {
                        let (set_pn, c_po) = written_col_f(&top_color_f_12843);
                        if set_pn {
                            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(true, c_po.clone())), k_pl.clone()))
                        } else {
                            if bounded_outer_p6xy {
                                ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(true, crate::check::types::Col::CBound)), k_pl.clone()))
                            } else {
                                ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(true, crate::check::types::Col::CQ(crate::prelude::or(&crate::prelude::index(&names_p8xy, &k_pl), &crate::prelude::Text::lit("u"))))), &k_pl + &crate::prelude::Nat::from(1u32)))
                            }
                        }
                    })
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(bool, crate::check::types::Col)>, crate::prelude::Nat), crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(bool, crate::check::types::Col)>, crate::prelude::Nat)>>>
    }));
    let vars_p9 = crate::prelude::fold(&pcols_pp, &crate::prelude::Array::new(), &(|acc_pq: &crate::prelude::Array<crate::prelude::Text>, (_, c_pr): &(bool, crate::check::types::Col)| match c_pr {
        crate::check::types::Col::CQ(v_ps) => crate::check::types::add_text_f(acc_pq, v_ps),
        _ => acc_pq.clone(),
    }));
    let any_unbounded_pa = crate::prelude::fold(&pcols_pp, &false, &(|seen_pt: &bool, (_, c_pu): &(bool, crate::check::types::Col)| *seen_pt || (c_pu == &crate::check::types::Col::CUnbound)));
    let spare_pb = fresh_col_names_f(&crate::prelude::append(written_p5, &names_p8), &crate::prelude::Nat::from(1u32));
    let outer_name_pc = if (outer_set_ph || any_unbounded_pa) || (&crate::prelude::len(&vars_p9) < &crate::prelude::Nat::from(2u32)) {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::or(&crate::prelude::index(&spare_pb, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("u"))
    };
    let outer_pd = if outer_set_ph {
        outer_w_pi.clone()
    } else {
        if any_unbounded_pa {
            crate::check::types::Col::CUnbound
        } else {
            if &crate::prelude::len(&vars_p9) == &crate::prelude::Nat::from(0u32) {
                crate::check::types::Col::CBound
            } else {
                if &crate::prelude::len(&vars_p9) == &crate::prelude::Nat::from(1u32) {
                    crate::check::types::Col::CQ(crate::prelude::or(&crate::prelude::index(&vars_p9, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("u")))
                } else {
                    crate::check::types::Col::CQ(outer_name_pc.clone())
                }
            }
        }
    };
    let joins_pe = match &outer_pd {
        crate::check::types::Col::CQ(hi_pv) => crate::prelude::each(&crate::prelude::filter(&vars_p9, &(|v_p10: &crate::prelude::Text| v_p10 != hi_pv)), &(|v_p11: &crate::prelude::Text| (v_p11.clone(), hi_pv.clone()))),
        _ => crate::prelude::Array::new(),
    };
    let cx_outer_pf = with_unwritten_f(cx_p0, &outer_pd);
    let (xs_p1b, st2_p1c) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p3)), (crate::prelude::Array::new(), st_p1.clone()), {
        let ps_p3x = ps_p3.clone();
        let res_p4x = res_p4.clone();
        let pcols_ppx = pcols_pp.clone();
        let cx_p0x = cx_p0.clone();
        let cx_outer_pfx = cx_outer_pf.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)| {
            let ps_p3xy = ps_p3x.clone();
            let res_p4xy = res_p4x.clone();
            let pcols_ppxy = pcols_ppx.clone();
            let cx_p0xy = cx_p0x.clone();
            let cx_outer_pfxy = cx_outer_pfx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p12, s_p13) = p0;
                let i_p14 = p1;
                {
                    let p_p15 = crate::prelude::or(&crate::prelude::index(&ps_p3xy, &i_p14), &res_p4xy);
                    let (is_fn_p17, c_p18) = crate::prelude::or(&crate::prelude::index(&pcols_ppxy, &i_p14), &(false, crate::check::types::Col::CBound));
                    let pcx_p16 = if is_fn_p17 { with_unwritten_f(&cx_p0xy, &c_p18) } else { cx_outer_pfxy.clone() };
                    crate::prelude::call_then(start_conv_type_f(pcx_p16.clone(), s_p13.clone(), p_p15.clone()), move |conv_type_f_14012: (crate::check::types::Ty, crate::check::types::St)| {
                        let (y_p19, s2_p1a) = conv_type_f_14012;
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p12, &y_p19), s2_p1a.clone()))
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }));
    let (r_p1d, st3_p1e) = conv_type_f(&cx_outer_pf, &st2_p1c, res_p4);
    let added_pg = if &outer_name_pc == &crate::prelude::Text::lit("") {
        names_p8.clone()
    } else {
        crate::prelude::push(&names_p8, &outer_name_pc)
    };
    (crate::check::types::Ty::TyFn(outer_pd.clone(), xs_p1b.clone(), ::std::rc::Rc::new(r_p1d.clone())), added_pg.clone(), joins_pe.clone(), st3_p1e.clone())
}

/// The step machine of `ClosureSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub struct ClosureSig {
    pub cx_p0: Cx,
    pub st_p1: crate::check::types::St,
    pub color_p2: crate::syntax::Color,
    pub ps_p3: crate::prelude::Array<crate::syntax::Type>,
    pub res_p4: crate::syntax::Type,
    pub written_p5: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St)> for ClosureSig {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let color_p2 = &self.color_p2;
        let ps_p3 = &self.ps_p3;
        let res_p4 = &self.res_p4;
        let written_p5 = &self.written_p5;
        let (outer_set_ph, outer_w_pi) = written_col_f(color_p2);
        let bounded_outer_p6 = outer_set_ph && (&outer_w_pi == &crate::check::types::Col::CBound);
        let cx_p0x = cx_p0.clone();
        let ps_p3x = ps_p3.clone();
        let res_p4x = res_p4.clone();
        let st_p1x = st_p1.clone();
        let written_p5x = written_p5.clone();
        crate::prelude::call_value(crate::prelude::filter_job(ps_p3x.clone(), ::std::rc::Rc::new(move |p0: crate::syntax::Type| crate::prelude::entered(crate::prelude::once_job(move || {
            let p_pj = p0;
            crate::prelude::call_then(start_is_fn_type_f(p_pj.clone()), move |is_fn_type_f_12461: bool| if is_fn_type_f_12461 {
                crate::prelude::call_then(start_top_color_f(p_pj.clone()), move |top_color_f_12493: crate::syntax::Color| ::prism_rtl::Turn::Finished(!writes_col_f(&top_color_f_12493)))
            } else {
                ::prism_rtl::Turn::Finished(false)
            })
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>), move |filter_12444: crate::prelude::Array<crate::syntax::Type>| {
            let n_default_p7 = crate::prelude::len(&filter_12444);
            crate::prelude::call_then(start_fresh_col_names_f(written_p5x.clone(), if bounded_outer_p6 { crate::prelude::Nat::from(0u32) } else { n_default_p7.clone() }), move |fresh_col_names_f_12523: crate::prelude::Array<crate::prelude::Text>| {
                let names_p8 = fresh_col_names_f_12523;
                crate::prelude::call_value(crate::prelude::fold_job(ps_p3x.clone(), (crate::prelude::Array::new(), crate::prelude::Nat::from(0u32)), {
                    let bounded_outer_p6x = bounded_outer_p6;
                    let names_p8x = names_p8.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(bool, crate::check::types::Col)>, crate::prelude::Nat), crate::syntax::Type)| {
                        let bounded_outer_p6xy = bounded_outer_p6x;
                        let names_p8xy = names_p8x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (acc_pk, k_pl) = p0;
                            let p_pm = p1;
                            crate::prelude::call_then(start_is_fn_type_f(p_pm.clone()), move |is_fn_type_f_12738: bool| if !is_fn_type_f_12738 {
                                ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(false, crate::check::types::Col::CBound)), k_pl.clone()))
                            } else {
                                crate::prelude::call_then(start_top_color_f(p_pm.clone()), move |top_color_f_12843: crate::syntax::Color| {
                                    let (set_pn, c_po) = written_col_f(&top_color_f_12843);
                                    if set_pn {
                                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(true, c_po.clone())), k_pl.clone()))
                                    } else {
                                        if bounded_outer_p6xy {
                                            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(true, crate::check::types::Col::CBound)), k_pl.clone()))
                                        } else {
                                            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(true, crate::check::types::Col::CQ(crate::prelude::or(&crate::prelude::index(&names_p8xy, &k_pl), &crate::prelude::Text::lit("u"))))), &k_pl + &crate::prelude::Nat::from(1u32)))
                                        }
                                    }
                                })
                            })
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(bool, crate::check::types::Col)>, crate::prelude::Nat), crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(bool, crate::check::types::Col)>, crate::prelude::Nat)>>>
                }), move |fold_12683: (crate::prelude::Array<(bool, crate::check::types::Col)>, crate::prelude::Nat)| {
                    let (pcols_pp, _) = fold_12683;
                    let vars_p9 = crate::prelude::fold(&pcols_pp, &crate::prelude::Array::new(), &(|acc_pq: &crate::prelude::Array<crate::prelude::Text>, (_, c_pr): &(bool, crate::check::types::Col)| match c_pr {
                        crate::check::types::Col::CQ(v_ps) => crate::check::types::add_text_f(acc_pq, v_ps),
                        _ => acc_pq.clone(),
                    }));
                    let any_unbounded_pa = crate::prelude::fold(&pcols_pp, &false, &(|seen_pt: &bool, (_, c_pu): &(bool, crate::check::types::Col)| *seen_pt || (c_pu == &crate::check::types::Col::CUnbound)));
                    crate::prelude::call_then(start_fresh_col_names_f(crate::prelude::append(&written_p5x, &names_p8), crate::prelude::Nat::from(1u32)), move |fresh_col_names_f_13271: crate::prelude::Array<crate::prelude::Text>| {
                        let spare_pb = fresh_col_names_f_13271;
                        let outer_name_pc = if (outer_set_ph || any_unbounded_pa) || (&crate::prelude::len(&vars_p9) < &crate::prelude::Nat::from(2u32)) {
                            crate::prelude::Text::lit("")
                        } else {
                            crate::prelude::or(&crate::prelude::index(&spare_pb, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("u"))
                        };
                        let outer_pd = if outer_set_ph {
                            outer_w_pi.clone()
                        } else {
                            if any_unbounded_pa {
                                crate::check::types::Col::CUnbound
                            } else {
                                if &crate::prelude::len(&vars_p9) == &crate::prelude::Nat::from(0u32) {
                                    crate::check::types::Col::CBound
                                } else {
                                    if &crate::prelude::len(&vars_p9) == &crate::prelude::Nat::from(1u32) {
                                        crate::check::types::Col::CQ(crate::prelude::or(&crate::prelude::index(&vars_p9, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("u")))
                                    } else {
                                        crate::check::types::Col::CQ(outer_name_pc.clone())
                                    }
                                }
                            }
                        };
                        let joins_pe = match &outer_pd {
                            crate::check::types::Col::CQ(hi_pv) => crate::prelude::each(&crate::prelude::filter(&vars_p9, &(|v_p10: &crate::prelude::Text| v_p10 != hi_pv)), &(|v_p11: &crate::prelude::Text| (v_p11.clone(), hi_pv.clone()))),
                            _ => crate::prelude::Array::new(),
                        };
                        let cx_outer_pf = with_unwritten_f(&cx_p0x, &outer_pd);
                        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_p3x)), (crate::prelude::Array::new(), st_p1x.clone()), {
                            let ps_p3xx = ps_p3x.clone();
                            let res_p4xx = res_p4x.clone();
                            let pcols_ppx = pcols_pp.clone();
                            let cx_p0xx = cx_p0x.clone();
                            let cx_outer_pfx = cx_outer_pf.clone();
                            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)| {
                                let ps_p3xxy = ps_p3xx.clone();
                                let res_p4xxy = res_p4xx.clone();
                                let pcols_ppxy = pcols_ppx.clone();
                                let cx_p0xxy = cx_p0xx.clone();
                                let cx_outer_pfxy = cx_outer_pfx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (acc_p12, s_p13) = p0;
                                    let i_p14 = p1;
                                    {
                                        let p_p15 = crate::prelude::or(&crate::prelude::index(&ps_p3xxy, &i_p14), &res_p4xxy);
                                        let (is_fn_p17, c_p18) = crate::prelude::or(&crate::prelude::index(&pcols_ppxy, &i_p14), &(false, crate::check::types::Col::CBound));
                                        let pcx_p16 = if is_fn_p17 { with_unwritten_f(&cx_p0xxy, &c_p18) } else { cx_outer_pfxy.clone() };
                                        crate::prelude::call_then(start_conv_type_f(pcx_p16.clone(), s_p13.clone(), p_p15.clone()), move |conv_type_f_14012: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (y_p19, s2_p1a) = conv_type_f_14012;
                                            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p12, &y_p19), s2_p1a.clone()))
                                        })
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>>>
                        }), move |fold_13785: (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)| {
                            let (xs_p1b, st2_p1c) = fold_13785;
                            crate::prelude::call_then(start_conv_type_f(cx_outer_pf.clone(), st2_p1c.clone(), res_p4x.clone()), move |conv_type_f_14082: (crate::check::types::Ty, crate::check::types::St)| {
                                let (r_p1d, st3_p1e) = conv_type_f_14082;
                                let added_pg = if &outer_name_pc == &crate::prelude::Text::lit("") {
                                    names_p8.clone()
                                } else {
                                    crate::prelude::push(&names_p8, &outer_name_pc)
                                };
                                ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyFn(outer_pd.clone(), xs_p1b.clone(), ::std::rc::Rc::new(r_p1d.clone())), added_pg.clone(), joins_pe.clone(), st3_p1e.clone()))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start ClosureSig, x`: what the function value is when passed to `@Run`.
pub fn start_closure_sig_f(cx_p0: Cx, st_p1: crate::check::types::St, color_p2: crate::syntax::Color, ps_p3: crate::prelude::Array<crate::syntax::Type>, res_p4: crate::syntax::Type, written_p5: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St)>> {
    ::std::rc::Rc::new(ClosureSig { cx_p0, st_p1, color_p2, ps_p3, res_p4, written_p5 })
}

/// ```prism
/// WrittenCol: fn Color -> ((Bool, Col))
/// ```
pub fn written_col_f(color0: &crate::syntax::Color) -> (bool, crate::check::types::Col) {
    match color0 {
        crate::syntax::Color::Bounded => (false, crate::check::types::Col::CBound),
        crate::syntax::Color::Unbounded => (true, crate::check::types::Col::CUnbound),
        crate::syntax::Color::ColorVar(v_p0) => if &v_p0.name_p == &crate::prelude::Text::lit("bounded") {
            (true, crate::check::types::Col::CBound)
        } else {
            (true, crate::check::types::Col::CQ(v_p0.name_p.clone()))
        },
    }
}

/// ```prism
/// WithUnwritten: fn Cx, Col -> Cx
/// ```
pub fn with_unwritten_f(cx_p0: &Cx, c_p1: &crate::check::types::Col) -> Cx {
    let mut this: Cx = cx_p0.clone();
    this.unwritten_p = c_p1.clone();
    this
}

/// ```prism
/// WritesCol: fn Color -> Bool
/// ```
pub fn writes_col_f(color0: &crate::syntax::Color) -> bool {
    match color0 {
        crate::syntax::Color::Bounded => false,
        _ => true,
    }
}

/// ```prism
/// TopColor: unbounded fn Type -> Color
/// ```
pub fn top_color_f(t_p0: &crate::syntax::Type) -> crate::syntax::Color {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TFn(c_p1, _, _) => c_p1.clone(),
        crate::syntax::TypeKind::TGroup(x_p2) => top_color_f(&**x_p2),
        _ => crate::syntax::Color::Bounded,
    }
}

/// The step machine of `TopColor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TopColor: unbounded fn Type -> Color
/// ```
pub struct TopColor {
    pub t_p0: crate::syntax::Type,
}

impl ::prism_rtl::Job<crate::syntax::Color> for TopColor {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::Color> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TFn(c_p1, _, _) => ::prism_rtl::Turn::Finished(c_p1.clone()),
            crate::syntax::TypeKind::TGroup(x_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TopColor { t_p0: (**x_p2).clone() })),
            _ => ::prism_rtl::Turn::Finished(crate::syntax::Color::Bounded),
        }
    }
}

/// `Start TopColor, x`: what the function value is when passed to `@Run`.
pub fn start_top_color_f(t_p0: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::Color>> {
    ::std::rc::Rc::new(TopColor { t_p0 })
}

/// ```prism
/// FreshColNames: unbounded fn [Text], Nat -> [Text]
/// ```
pub fn fresh_col_names_f(taken_p0: &crate::prelude::Array<crate::prelude::Text>, n_p1: &crate::prelude::Nat) -> crate::prelude::Array<crate::prelude::Text> {
    let (names_p5, _) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(n_p1), (crate::prelude::Array::new(), crate::prelude::Nat::from(1u32)), {
        let taken_p0x = taken_p0.clone();
        let n_p1x = n_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat), crate::prelude::Nat)| {
            let taken_p0xy = taken_p0x.clone();
            let n_p1xy = n_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p2, k_p3) = p0;
                let _ = p1;
                {
                    let k2_p4 = next_free_col_f(&crate::prelude::append(&taken_p0xy, &acc_p2), &(if &n_p1xy == &crate::prelude::Nat::from(1u32) {
                        crate::prelude::Nat::from(0u32)
                    } else {
                        k_p3.clone()
                    }));
                    ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p2, &sig_col_name_f(&k2_p4)), &k2_p4 + &crate::prelude::Nat::from(1u32)))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)>>>
    }));
    names_p5.clone()
}

/// The step machine of `FreshColNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreshColNames: unbounded fn [Text], Nat -> [Text]
/// ```
pub struct FreshColNames {
    pub taken_p0: crate::prelude::Array<crate::prelude::Text>,
    pub n_p1: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for FreshColNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let taken_p0 = &self.taken_p0;
        let n_p1 = &self.n_p1;
        let n_p1x = n_p1.clone();
        let taken_p0x = taken_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p1x), (crate::prelude::Array::new(), crate::prelude::Nat::from(1u32)), {
            let taken_p0xx = taken_p0x.clone();
            let n_p1xx = n_p1x.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat), crate::prelude::Nat)| {
                let taken_p0xxy = taken_p0xx.clone();
                let n_p1xxy = n_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p2, k_p3) = p0;
                    let _ = p1;
                    {
                        let k2_p4 = next_free_col_f(&crate::prelude::append(&taken_p0xxy, &acc_p2), &(if &n_p1xxy == &crate::prelude::Nat::from(1u32) {
                            crate::prelude::Nat::from(0u32)
                        } else {
                            k_p3.clone()
                        }));
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p2, &sig_col_name_f(&k2_p4)), &k2_p4 + &crate::prelude::Nat::from(1u32)))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)>>>
        }), move |fold_15150: (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)| {
            let (names_p5, _) = fold_15150;
            ::prism_rtl::Turn::Finished(names_p5.clone())
        })
    }
}

/// `Start FreshColNames, x`: what the function value is when passed to `@Run`.
pub fn start_fresh_col_names_f(taken_p0: crate::prelude::Array<crate::prelude::Text>, n_p1: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(FreshColNames { taken_p0, n_p1 })
}

/// ```prism
/// NextFreeCol: unbounded fn [Text], Nat -> Nat
/// ```
pub fn next_free_col_f(taken_p0: &crate::prelude::Array<crate::prelude::Text>, k_p1: &crate::prelude::Nat) -> crate::prelude::Nat {
    if crate::check::types::has_text_f(taken_p0, &sig_col_name_f(k_p1)) {
        next_free_col_f(taken_p0, &(k_p1 + &crate::prelude::Nat::from(1u32)))
    } else {
        k_p1.clone()
    }
}

/// ```prism
/// SigColName: fn Nat -> Text
/// ```
pub fn sig_col_name_f(n0: &crate::prelude::Nat) -> crate::prelude::Text {
    match n0 {
        c0_0 if (c0_0 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("u"),
        k_p0 => crate::prelude::Text::from(format!("u{}", k_p0)),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ConvBounds: fn Cx, St, [Bound] -> (([((Text, Text))], St))
/// ```
pub fn conv_bounds_f(cx_p0: &Cx, st_p1: &crate::check::types::St, bounds_p2: &crate::prelude::Array<crate::syntax::decls::Bound>) -> (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St) {
    crate::prelude::fold(bounds_p2, &(crate::prelude::Array::new(), st_p1.clone()), &(|(acc_p3, s_p4): &(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St), b_p5: &crate::syntax::decls::Bound| crate::prelude::fold(&b_p5.traits_p, &(acc_p3.clone(), s_p4.clone()), &(|(a2_p6, s2_p7): &(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::check::types::St), tr_p8: &crate::syntax::TraitRef| match crate::check::env::names::resolve_trait_o(&cx_p0.g_p, &cx_p0.home_p, &tr_p8.path_p) {
        ::std::option::Option::Some(k_p9) => (crate::prelude::push(a2_p6, &(b_p5.var_p.name_p.clone(), k_p9)), crate::check::env::names::trait_collision_at_f(&cx_p0.g_p, s2_p7, &cx_p0.home_p, &tr_p8.path_p, &tr_p8.span_p)),
        ::std::option::Option::None => (a2_p6.clone(), crate::check::types::recording::err_f(s2_p7, &crate::prelude::Text::lit("unknown-name"), &tr_p8.span_p, &crate::prelude::Text::from(format!("no trait `^{}`", &crate::check::env::dotted_f(&tr_p8.path_p))))),
    }))))
}

/// ```prism
/// MentionsTime: unbounded fn Type -> Bool
/// ```
pub fn mentions_time_f(t_p0: &crate::syntax::Type) -> bool {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TName(n_p1, args_p2) => ((crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &crate::prelude::Text::lit("$")) || crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &crate::prelude::Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &crate::prelude::Text::lit("@"))) || crate::prelude::run_to_end(crate::prelude::fold_job(args_p2.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_p3 = p0;
            let a_p4 = p1;
            if seen_p3 {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(MentionsTime { t_p0: a_p4.clone() }))
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TSigiled(s_p5, i_p6) => ((crate::syntax::lexer::chars::contains_f(s_p5, &crate::prelude::Text::lit("$")) || crate::syntax::lexer::chars::contains_f(s_p5, &crate::prelude::Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(s_p5, &crate::prelude::Text::lit("@"))) || mentions_time_f(&**i_p6),
        crate::syntax::TypeKind::TUnit(s_p7) => (crate::syntax::lexer::chars::contains_f(s_p7, &crate::prelude::Text::lit("$")) || crate::syntax::lexer::chars::contains_f(s_p7, &crate::prelude::Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(s_p7, &crate::prelude::Text::lit("@")),
        crate::syntax::TypeKind::TArray(e_p8, _) => mentions_time_f(&**e_p8),
        crate::syntax::TypeKind::TTuple(ts_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_pa = p0;
            let a_pb = p1;
            if seen_pa {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(MentionsTime { t_p0: a_pb.clone() }))
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TGroup(x_pc) => mentions_time_f(&**x_pc),
        crate::syntax::TypeKind::TMap(k_pd, v_pe) => mentions_time_f(&**k_pd) || mentions_time_f(&**v_pe),
        crate::syntax::TypeKind::TFn(_, ps_pf, res_pg) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pf.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_ph = p0;
            let a_pi = p1;
            if seen_ph {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(MentionsTime { t_p0: a_pi.clone() }))
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)) || mentions_time_f(&**res_pg),
        crate::syntax::TypeKind::TEmit(ty_pj, _) => true,
        _ => false,
    }
}

/// The step machine of `MentionsTime`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MentionsTime: unbounded fn Type -> Bool
/// ```
pub struct MentionsTime {
    pub t_p0: crate::syntax::Type,
}

impl ::prism_rtl::Job<bool> for MentionsTime {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TName(n_p1, args_p2) => if (crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &crate::prelude::Text::lit("$")) || crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &crate::prelude::Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &crate::prelude::Text::lit("@")) {
                ::prism_rtl::Turn::Finished(true)
            } else {
                crate::prelude::fold_job(args_p2.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_p3 = p0;
                    let a_p4 = p1;
                    if seen_p3 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(MentionsTime { t_p0: a_p4.clone() }))
                    }
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle()
            },
            crate::syntax::TypeKind::TSigiled(s_p5, i_p6) => if (crate::syntax::lexer::chars::contains_f(s_p5, &crate::prelude::Text::lit("$")) || crate::syntax::lexer::chars::contains_f(s_p5, &crate::prelude::Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(s_p5, &crate::prelude::Text::lit("@")) {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(MentionsTime { t_p0: (**i_p6).clone() }))
            },
            crate::syntax::TypeKind::TUnit(s_p7) => ::prism_rtl::Turn::Finished((crate::syntax::lexer::chars::contains_f(s_p7, &crate::prelude::Text::lit("$")) || crate::syntax::lexer::chars::contains_f(s_p7, &crate::prelude::Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(s_p7, &crate::prelude::Text::lit("@"))),
            crate::syntax::TypeKind::TArray(e_p8, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(MentionsTime { t_p0: (**e_p8).clone() })),
            crate::syntax::TypeKind::TTuple(ts_p9) => crate::prelude::fold_job(ts_p9.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_pa = p0;
                let a_pb = p1;
                if seen_pa {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(MentionsTime { t_p0: a_pb.clone() }))
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(MentionsTime { t_p0: (**x_pc).clone() })),
            crate::syntax::TypeKind::TMap(k_pd, v_pe) => {
                let k_pdx = (**k_pd).clone();
                let v_pex = (**v_pe).clone();
                crate::prelude::call_then(start_mentions_time_f(k_pdx.clone()), move |mentions_time_f_16582: bool| if mentions_time_f_16582 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(MentionsTime { t_p0: v_pex.clone() }))
                })
            },
            crate::syntax::TypeKind::TFn(_, ps_pf, res_pg) => {
                let ps_pfx = ps_pf.clone();
                let res_pgx = (**res_pg).clone();
                crate::prelude::call_value(crate::prelude::fold_job(ps_pfx.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_ph = p0;
                    let a_pi = p1;
                    if seen_ph {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(MentionsTime { t_p0: a_pi.clone() }))
                    }
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>), move |fold_16642: bool| if fold_16642 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(MentionsTime { t_p0: res_pgx.clone() }))
                })
            },
            crate::syntax::TypeKind::TEmit(ty_pj, _) => ::prism_rtl::Turn::Finished(true),
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start MentionsTime, x`: what the function value is when passed to `@Run`.
pub fn start_mentions_time_f(t_p0: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(MentionsTime { t_p0 })
}

/// ```prism
/// TakesClosure: unbounded fn Type -> Bool
/// ```
pub fn takes_closure_f(t_p0: &crate::syntax::Type) -> bool {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TFn(_, ps_p1, _) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p1.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_p2 = p0;
            let p_p3 = p1;
            if seen_p2 {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(IsFnType { t_p0: p_p3.clone() }))
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
        _ => false,
    }
}

/// The step machine of `TakesClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TakesClosure: unbounded fn Type -> Bool
/// ```
pub struct TakesClosure {
    pub t_p0: crate::syntax::Type,
}

impl ::prism_rtl::Job<bool> for TakesClosure {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TFn(_, ps_p1, _) => crate::prelude::fold_job(ps_p1.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_p2 = p0;
                let p_p3 = p1;
                if seen_p2 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(IsFnType { t_p0: p_p3.clone() }))
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle(),
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start TakesClosure, x`: what the function value is when passed to `@Run`.
pub fn start_takes_closure_f(t_p0: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(TakesClosure { t_p0 })
}

/// ```prism
/// IsFnType: unbounded fn Type -> Bool
/// ```
pub fn is_fn_type_f(t_p0: &crate::syntax::Type) -> bool {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TFn(_, _, _) => true,
        crate::syntax::TypeKind::TGroup(x_p1) => is_fn_type_f(&**x_p1),
        _ => false,
    }
}

/// The step machine of `IsFnType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsFnType: unbounded fn Type -> Bool
/// ```
pub struct IsFnType {
    pub t_p0: crate::syntax::Type,
}

impl ::prism_rtl::Job<bool> for IsFnType {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TFn(_, _, _) => ::prism_rtl::Turn::Finished(true),
            crate::syntax::TypeKind::TGroup(x_p1) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IsFnType { t_p0: (**x_p1).clone() })),
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsFnType, x`: what the function value is when passed to `@Run`.
pub fn start_is_fn_type_f(t_p0: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsFnType { t_p0 })
}

/// ```prism
/// UsesScope: unbounded fn Type -> Bool
/// ```
pub fn uses_scope_f(t_p0: &crate::syntax::Type) -> bool {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TName(n_p1, args_p2) => ((crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &crate::prelude::Text::lit("@")) || ((&crate::check::env::dotted_f(&n_p1.path_p) == &crate::prelude::Text::lit("Element")) && (&crate::prelude::len(args_p2) < &crate::prelude::Nat::from(2u32)))) || ((&crate::check::env::dotted_f(&n_p1.path_p) == &crate::prelude::Text::lit("Elem")) && (&crate::prelude::len(args_p2) == &crate::prelude::Nat::from(0u32)))) || crate::prelude::run_to_end(crate::prelude::fold_job(args_p2.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_p3 = p0;
            let a_p4 = p1;
            if seen_p3 {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(UsesScope { t_p0: a_p4.clone() }))
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TSigiled(s_p5, i_p6) => crate::syntax::lexer::chars::contains_f(s_p5, &crate::prelude::Text::lit("@")) || uses_scope_f(&**i_p6),
        crate::syntax::TypeKind::TUnit(s_p7) => crate::syntax::lexer::chars::contains_f(s_p7, &crate::prelude::Text::lit("@")),
        crate::syntax::TypeKind::TArray(e_p8, _) => uses_scope_f(&**e_p8),
        crate::syntax::TypeKind::TTuple(ts_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_pa = p0;
            let a_pb = p1;
            if seen_pa {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(UsesScope { t_p0: a_pb.clone() }))
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TGroup(x_pc) => uses_scope_f(&**x_pc),
        crate::syntax::TypeKind::TMap(k_pd, v_pe) => uses_scope_f(&**k_pd) || uses_scope_f(&**v_pe),
        crate::syntax::TypeKind::TFn(_, ps_pf, res_pg) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pf.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_ph = p0;
            let a_pi = p1;
            if seen_ph {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(UsesScope { t_p0: a_pi.clone() }))
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)) || uses_scope_f(&**res_pg),
        crate::syntax::TypeKind::TEmit(ty_pj, row_t_pk) => uses_scope_f(&**row_t_pk),
        _ => false,
    }
}

/// The step machine of `UsesScope`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UsesScope: unbounded fn Type -> Bool
/// ```
pub struct UsesScope {
    pub t_p0: crate::syntax::Type,
}

impl ::prism_rtl::Job<bool> for UsesScope {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TName(n_p1, args_p2) => if (crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &crate::prelude::Text::lit("@")) || ((&crate::check::env::dotted_f(&n_p1.path_p) == &crate::prelude::Text::lit("Element")) && (&crate::prelude::len(args_p2) < &crate::prelude::Nat::from(2u32)))) || ((&crate::check::env::dotted_f(&n_p1.path_p) == &crate::prelude::Text::lit("Elem")) && (&crate::prelude::len(args_p2) == &crate::prelude::Nat::from(0u32))) {
                ::prism_rtl::Turn::Finished(true)
            } else {
                crate::prelude::fold_job(args_p2.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_p3 = p0;
                    let a_p4 = p1;
                    if seen_p3 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(UsesScope { t_p0: a_p4.clone() }))
                    }
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle()
            },
            crate::syntax::TypeKind::TSigiled(s_p5, i_p6) => if crate::syntax::lexer::chars::contains_f(s_p5, &crate::prelude::Text::lit("@")) {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(UsesScope { t_p0: (**i_p6).clone() }))
            },
            crate::syntax::TypeKind::TUnit(s_p7) => ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::contains_f(s_p7, &crate::prelude::Text::lit("@"))),
            crate::syntax::TypeKind::TArray(e_p8, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(UsesScope { t_p0: (**e_p8).clone() })),
            crate::syntax::TypeKind::TTuple(ts_p9) => crate::prelude::fold_job(ts_p9.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_pa = p0;
                let a_pb = p1;
                if seen_pa {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(UsesScope { t_p0: a_pb.clone() }))
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(UsesScope { t_p0: (**x_pc).clone() })),
            crate::syntax::TypeKind::TMap(k_pd, v_pe) => {
                let k_pdx = (**k_pd).clone();
                let v_pex = (**v_pe).clone();
                crate::prelude::call_then(start_uses_scope_f(k_pdx.clone()), move |uses_scope_f_17649: bool| if uses_scope_f_17649 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(UsesScope { t_p0: v_pex.clone() }))
                })
            },
            crate::syntax::TypeKind::TFn(_, ps_pf, res_pg) => {
                let ps_pfx = ps_pf.clone();
                let res_pgx = (**res_pg).clone();
                crate::prelude::call_value(crate::prelude::fold_job(ps_pfx.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_ph = p0;
                    let a_pi = p1;
                    if seen_ph {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(UsesScope { t_p0: a_pi.clone() }))
                    }
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>), move |fold_17703: bool| if fold_17703 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(UsesScope { t_p0: res_pgx.clone() }))
                })
            },
            crate::syntax::TypeKind::TEmit(ty_pj, row_t_pk) => ::prism_rtl::Turn::More(::std::rc::Rc::new(UsesScope { t_p0: (**row_t_pk).clone() })),
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start UsesScope, x`: what the function value is when passed to `@Run`.
pub fn start_uses_scope_f(t_p0: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(UsesScope { t_p0 })
}

/// ```prism
/// RowVarsOfType: unbounded fn Type -> [Text]
/// ```
pub fn row_vars_of_type_f(t_p0: &crate::syntax::Type) -> crate::prelude::Array<crate::prelude::Text> {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TName(n_p1, args_p2) => {
            let name_p3 = crate::check::env::dotted_f(&n_p1.path_p);
            let own_p4 = if ((&name_p3 == &crate::prelude::Text::lit("Element")) && (&crate::prelude::len(args_p2) == &crate::prelude::Nat::from(2u32))) || ((&name_p3 == &crate::prelude::Text::lit("Elem")) && (&crate::prelude::len(args_p2) == &crate::prelude::Nat::from(1u32))) {
                row_names_in_f(&crate::prelude::or(&crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)), &dummy_type_p()))
            } else {
                crate::prelude::Array::new()
            };
            let rest_p5 = if (&name_p3 == &crate::prelude::Text::lit("Element")) && (&crate::prelude::len(args_p2) == &crate::prelude::Nat::from(2u32)) {
                crate::prelude::drop(args_p2, &crate::prelude::Nat::from(1u32))
            } else {
                if &name_p3 == &crate::prelude::Text::lit("Elem") {
                    crate::prelude::Array::new()
                } else {
                    args_p2.clone()
                }
            };
            crate::prelude::run_to_end(crate::prelude::fold_job(rest_p5.clone(), own_p4.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let a_p7 = p1;
                crate::prelude::call_then(start_row_vars_of_type_f(a_p7.clone()), move |row_vars_of_type_f_18323: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p6, &row_vars_of_type_f_18323)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>))
        },
        crate::syntax::TypeKind::TSigiled(_, i_p8) => row_vars_of_type_f(&**i_p8),
        crate::syntax::TypeKind::TArray(e_p9, _) => row_vars_of_type_f(&**e_p9),
        crate::syntax::TypeKind::TTuple(ts_pa) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_pa.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pb = p0;
            let a_pc = p1;
            crate::prelude::call_then(start_row_vars_of_type_f(a_pc.clone()), move |row_vars_of_type_f_18475: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pb, &row_vars_of_type_f_18475)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::syntax::TypeKind::TGroup(x_pd) => row_vars_of_type_f(&**x_pd),
        crate::syntax::TypeKind::TMap(k_pe, v_pf) => crate::check::types::union_texts_f(&row_vars_of_type_f(&**k_pe), &row_vars_of_type_f(&**v_pf)),
        crate::syntax::TypeKind::TFn(_, ps_pg, res_ph) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pg.clone(), row_vars_of_type_f(&**res_ph), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pi = p0;
            let a_pj = p1;
            crate::prelude::call_then(start_row_vars_of_type_f(a_pj.clone()), move |row_vars_of_type_f_18667: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pi, &row_vars_of_type_f_18667)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::syntax::TypeKind::TEmit(ty_pk, row_t_pl) => crate::check::types::union_texts_f(&row_vars_of_type_f(&**ty_pk), &row_names_in_f(&**row_t_pl)),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `RowVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowVarsOfType: unbounded fn Type -> [Text]
/// ```
pub struct RowVarsOfType {
    pub t_p0: crate::syntax::Type,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for RowVarsOfType {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TName(n_p1, args_p2) => {
                let name_p3 = crate::check::env::dotted_f(&n_p1.path_p);
                let args_p2z = args_p2.clone();
                let name_p3z = name_p3.clone();
                let k_let18017 = move |v18017: crate::prelude::Array<crate::prelude::Text>| {
                    let own_p4 = v18017;
                    let rest_p5 = if (&name_p3z == &crate::prelude::Text::lit("Element")) && (&crate::prelude::len(&args_p2z) == &crate::prelude::Nat::from(2u32)) {
                        crate::prelude::drop(&args_p2z, &crate::prelude::Nat::from(1u32))
                    } else {
                        if &name_p3z == &crate::prelude::Text::lit("Elem") {
                            crate::prelude::Array::new()
                        } else {
                            args_p2z.clone()
                        }
                    };
                    crate::prelude::fold_job(rest_p5.clone(), own_p4.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p6 = p0;
                        let a_p7 = p1;
                        crate::prelude::call_then(start_row_vars_of_type_f(a_p7.clone()), move |row_vars_of_type_f_18323: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p6, &row_vars_of_type_f_18323)))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle()
                };
                if ((&name_p3 == &crate::prelude::Text::lit("Element")) && (&crate::prelude::len(args_p2) == &crate::prelude::Nat::from(2u32))) || ((&name_p3 == &crate::prelude::Text::lit("Elem")) && (&crate::prelude::len(args_p2) == &crate::prelude::Nat::from(1u32))) {
                    {
                        let args_p2x = args_p2.clone();
                        crate::prelude::call_then(start_row_names_in_f(crate::prelude::or(&crate::prelude::index(&args_p2x, &crate::prelude::Nat::from(0u32)), &dummy_type_p())), move |row_names_in_f_18111: crate::prelude::Array<crate::prelude::Text>| k_let18017(row_names_in_f_18111))
                    }
                } else {
                    k_let18017(crate::prelude::Array::new())
                }
            },
            crate::syntax::TypeKind::TSigiled(_, i_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RowVarsOfType { t_p0: (**i_p8).clone() })),
            crate::syntax::TypeKind::TArray(e_p9, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RowVarsOfType { t_p0: (**e_p9).clone() })),
            crate::syntax::TypeKind::TTuple(ts_pa) => crate::prelude::fold_job(ts_pa.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pb = p0;
                let a_pc = p1;
                crate::prelude::call_then(start_row_vars_of_type_f(a_pc.clone()), move |row_vars_of_type_f_18475: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pb, &row_vars_of_type_f_18475)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x_pd) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RowVarsOfType { t_p0: (**x_pd).clone() })),
            crate::syntax::TypeKind::TMap(k_pe, v_pf) => {
                let k_pex = (**k_pe).clone();
                let v_pfx = (**v_pf).clone();
                crate::prelude::call_then(start_row_vars_of_type_f(k_pex.clone()), move |row_vars_of_type_f_18549: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_row_vars_of_type_f(v_pfx.clone()), move |row_vars_of_type_f_18568: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&row_vars_of_type_f_18549, &row_vars_of_type_f_18568))))
            },
            crate::syntax::TypeKind::TFn(_, ps_pg, res_ph) => {
                let ps_pgx = ps_pg.clone();
                let res_phx = (**res_ph).clone();
                crate::prelude::call_then(start_row_vars_of_type_f(res_phx.clone()), move |row_vars_of_type_f_18620: crate::prelude::Array<crate::prelude::Text>| crate::prelude::fold_job(ps_pgx.clone(), row_vars_of_type_f_18620, ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pi = p0;
                    let a_pj = p1;
                    crate::prelude::call_then(start_row_vars_of_type_f(a_pj.clone()), move |row_vars_of_type_f_18667: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pi, &row_vars_of_type_f_18667)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle())
            },
            crate::syntax::TypeKind::TEmit(ty_pk, row_t_pl) => {
                let row_t_plx = (**row_t_pl).clone();
                let ty_pkx = (**ty_pk).clone();
                crate::prelude::call_then(start_row_vars_of_type_f(ty_pkx.clone()), move |row_vars_of_type_f_18716: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_row_names_in_f(row_t_plx.clone()), move |row_names_in_f_18736: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&row_vars_of_type_f_18716, &row_names_in_f_18736))))
            },
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start RowVarsOfType, x`: what the function value is when passed to `@Run`.
pub fn start_row_vars_of_type_f(t_p0: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(RowVarsOfType { t_p0 })
}

/// ```prism
/// RowNamesIn: unbounded fn Type -> [Text]
/// ```
pub fn row_names_in_f(t_p0: &crate::syntax::Type) -> crate::prelude::Array<crate::prelude::Text> {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TName(n_p1, m18832_0_1) if (m18832_0_1.len() == 0) => if (&crate::prelude::len(&n_p1.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::is_lower_text_f(&crate::check::env::dotted_f(&n_p1.path_p)) {
            crate::prelude::Array::from(vec![crate::check::env::dotted_f(&n_p1.path_p)])
        } else {
            crate::prelude::Array::new()
        },
        crate::syntax::TypeKind::TRowUnion(ts_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p2.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let a_p4 = p1;
            crate::prelude::call_then(start_row_names_in_f(a_p4.clone()), move |row_names_in_f_19010: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &row_names_in_f_19010)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::syntax::TypeKind::TGroup(x_p5) => row_names_in_f(&**x_p5),
        _ => crate::prelude::Array::new(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RowNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowNamesIn: unbounded fn Type -> [Text]
/// ```
pub struct RowNamesIn {
    pub t_p0: crate::syntax::Type,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for RowNamesIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TName(n_p1, m18832_0_1) if (m18832_0_1.len() == 0) => if (&crate::prelude::len(&n_p1.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::is_lower_text_f(&crate::check::env::dotted_f(&n_p1.path_p)) {
                ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::check::env::dotted_f(&n_p1.path_p)]))
            } else {
                ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
            },
            crate::syntax::TypeKind::TRowUnion(ts_p2) => crate::prelude::fold_job(ts_p2.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let a_p4 = p1;
                crate::prelude::call_then(start_row_names_in_f(a_p4.clone()), move |row_names_in_f_19010: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &row_names_in_f_19010)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RowNamesIn { t_p0: (**x_p5).clone() })),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start RowNamesIn, x`: what the function value is when passed to `@Run`.
pub fn start_row_names_in_f(t_p0: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(RowNamesIn { t_p0 })
}

/// ```prism
/// TypeVarsOfType: unbounded fn Type -> [Text]
/// ```
pub fn type_vars_of_type_f(t_p0: &crate::syntax::Type) -> crate::prelude::Array<crate::prelude::Text> {
    type_vars_into_f(&crate::prelude::Array::new(), t_p0)
}

/// The step machine of `TypeVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeVarsOfType: unbounded fn Type -> [Text]
/// ```
pub struct TypeVarsOfType {
    pub t_p0: crate::syntax::Type,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for TypeVarsOfType {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let t_p0 = &self.t_p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarsInto { acc_p0: crate::prelude::Array::new(), t_p1: t_p0.clone() }))
    }
}

/// `Start TypeVarsOfType, x`: what the function value is when passed to `@Run`.
pub fn start_type_vars_of_type_f(t_p0: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(TypeVarsOfType { t_p0 })
}

/// ```prism
/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
/// ```
pub fn type_vars_into_f(acc_p0: &crate::prelude::Array<crate::prelude::Text>, t_p1: &crate::syntax::Type) -> crate::prelude::Array<crate::prelude::Text> {
    match &*t_p1.kind_p {
        crate::syntax::TypeKind::TName(n_p2, args_p3) => {
            let name_p4 = crate::check::env::dotted_f(&n_p2.path_p);
            let here_p5 = if ((&crate::prelude::len(&n_p2.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::is_lower_text_f(&name_p4)) && (&crate::prelude::len(args_p3) == &crate::prelude::Nat::from(0u32)) {
                crate::check::types::add_text_f(acc_p0, &name_p4)
            } else {
                acc_p0.clone()
            };
            let rest_p6 = if (&name_p4 == &crate::prelude::Text::lit("Element")) && (&crate::prelude::len(args_p3) == &crate::prelude::Nat::from(2u32)) {
                crate::prelude::drop(args_p3, &crate::prelude::Nat::from(1u32))
            } else {
                if &name_p4 == &crate::prelude::Text::lit("Elem") {
                    crate::prelude::Array::new()
                } else {
                    args_p3.clone()
                }
            };
            crate::prelude::run_to_end(crate::prelude::fold_job(rest_p6.clone(), here_p5.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let a_p7 = p0;
                let x_p8 = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarsInto { acc_p0: a_p7.clone(), t_p1: x_p8.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>))
        },
        crate::syntax::TypeKind::TSigiled(_, i_p9) => type_vars_into_f(acc_p0, &**i_p9),
        crate::syntax::TypeKind::TArray(e_pa, _) => type_vars_into_f(acc_p0, &**e_pa),
        crate::syntax::TypeKind::TTuple(ts_pb) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_pb.clone(), acc_p0.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_pc = p0;
            let x_pd = p1;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarsInto { acc_p0: a_pc.clone(), t_p1: x_pd.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::syntax::TypeKind::TGroup(x_pe) => type_vars_into_f(acc_p0, &**x_pe),
        crate::syntax::TypeKind::TMap(k_pf, v_pg) => type_vars_into_f(&type_vars_into_f(acc_p0, &**k_pf), &**v_pg),
        crate::syntax::TypeKind::TFn(_, ps_ph, res_pi) => type_vars_into_f(&crate::prelude::run_to_end(crate::prelude::fold_job(ps_ph.clone(), acc_p0.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_pj = p0;
            let x_pk = p1;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarsInto { acc_p0: a_pj.clone(), t_p1: x_pk.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)), &**res_pi),
        crate::syntax::TypeKind::TEmit(ty_pl, _) => type_vars_into_f(acc_p0, &**ty_pl),
        crate::syntax::TypeKind::TNonEmpty(x_pm) => type_vars_into_f(acc_p0, &**x_pm),
        _ => acc_p0.clone(),
    }
}

/// The step machine of `TypeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
/// ```
pub struct TypeVarsInto {
    pub acc_p0: crate::prelude::Array<crate::prelude::Text>,
    pub t_p1: crate::syntax::Type,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for TypeVarsInto {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let acc_p0 = &self.acc_p0;
        let t_p1 = &self.t_p1;
        match &*t_p1.kind_p {
            crate::syntax::TypeKind::TName(n_p2, args_p3) => {
                let name_p4 = crate::check::env::dotted_f(&n_p2.path_p);
                let here_p5 = if ((&crate::prelude::len(&n_p2.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::is_lower_text_f(&name_p4)) && (&crate::prelude::len(args_p3) == &crate::prelude::Nat::from(0u32)) {
                    crate::check::types::add_text_f(acc_p0, &name_p4)
                } else {
                    acc_p0.clone()
                };
                let rest_p6 = if (&name_p4 == &crate::prelude::Text::lit("Element")) && (&crate::prelude::len(args_p3) == &crate::prelude::Nat::from(2u32)) {
                    crate::prelude::drop(args_p3, &crate::prelude::Nat::from(1u32))
                } else {
                    if &name_p4 == &crate::prelude::Text::lit("Elem") {
                        crate::prelude::Array::new()
                    } else {
                        args_p3.clone()
                    }
                };
                crate::prelude::fold_job(rest_p6.clone(), here_p5.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p7 = p0;
                    let x_p8 = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarsInto { acc_p0: a_p7.clone(), t_p1: x_p8.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle()
            },
            crate::syntax::TypeKind::TSigiled(_, i_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarsInto { acc_p0: acc_p0.clone(), t_p1: (**i_p9).clone() })),
            crate::syntax::TypeKind::TArray(e_pa, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarsInto { acc_p0: acc_p0.clone(), t_p1: (**e_pa).clone() })),
            crate::syntax::TypeKind::TTuple(ts_pb) => crate::prelude::fold_job(ts_pb.clone(), acc_p0.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let a_pc = p0;
                let x_pd = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarsInto { acc_p0: a_pc.clone(), t_p1: x_pd.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x_pe) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarsInto { acc_p0: acc_p0.clone(), t_p1: (**x_pe).clone() })),
            crate::syntax::TypeKind::TMap(k_pf, v_pg) => {
                let acc_p0x = acc_p0.clone();
                let k_pfx = (**k_pf).clone();
                let v_pgx = (**v_pg).clone();
                crate::prelude::call_then(start_type_vars_into_f(acc_p0x.clone(), k_pfx.clone()), move |type_vars_into_f_19867: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarsInto { acc_p0: type_vars_into_f_19867, t_p1: v_pgx.clone() })))
            },
            crate::syntax::TypeKind::TFn(_, ps_ph, res_pi) => {
                let acc_p0x = acc_p0.clone();
                let ps_phx = ps_ph.clone();
                let res_pix = (**res_pi).clone();
                crate::prelude::call_value(crate::prelude::fold_job(ps_phx.clone(), acc_p0x.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pj = p0;
                    let x_pk = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarsInto { acc_p0: a_pj.clone(), t_p1: x_pk.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_19930: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarsInto { acc_p0: fold_19930, t_p1: res_pix.clone() })))
            },
            crate::syntax::TypeKind::TEmit(ty_pl, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarsInto { acc_p0: acc_p0.clone(), t_p1: (**ty_pl).clone() })),
            crate::syntax::TypeKind::TNonEmpty(x_pm) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarsInto { acc_p0: acc_p0.clone(), t_p1: (**x_pm).clone() })),
            _ => ::prism_rtl::Turn::Finished(acc_p0.clone()),
        }
    }
}

/// `Start TypeVarsInto, x`: what the function value is when passed to `@Run`.
pub fn start_type_vars_into_f(acc_p0: crate::prelude::Array<crate::prelude::Text>, t_p1: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(TypeVarsInto { acc_p0, t_p1 })
}

/// ```prism
/// TypeVarPlaces: unbounded fn [((Text, Range))], Type -> [((Text, Range))]
/// ```
pub fn type_var_places_f(acc_p0: &crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, t_p1: &crate::syntax::Type) -> crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)> {
    match &*t_p1.kind_p {
        crate::syntax::TypeKind::TName(n_p2, args_p3) => {
            let name_p4 = crate::check::env::dotted_f(&n_p2.path_p);
            let known_p5 = crate::prelude::fold(acc_p0, &false, &(|seen_p8: &bool, (v_p9, _): &(crate::prelude::Text, crate::syntax::Range)| *seen_p8 || (v_p9 == &name_p4)));
            let here_p6 = if (((&crate::prelude::len(&n_p2.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::is_lower_text_f(&name_p4)) && (&crate::prelude::len(args_p3) == &crate::prelude::Nat::from(0u32))) && !known_p5 {
                crate::prelude::push(acc_p0, &(name_p4.clone(), t_p1.span_p.clone()))
            } else {
                acc_p0.clone()
            };
            let rest_p7 = if (&name_p4 == &crate::prelude::Text::lit("Element")) && (&crate::prelude::len(args_p3) == &crate::prelude::Nat::from(2u32)) {
                crate::prelude::drop(args_p3, &crate::prelude::Nat::from(1u32))
            } else {
                if &name_p4 == &crate::prelude::Text::lit("Elem") {
                    crate::prelude::Array::new()
                } else {
                    args_p3.clone()
                }
            };
            crate::prelude::run_to_end(crate::prelude::fold_job(rest_p7.clone(), here_p6.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let a_pa = p0;
                let x_pb = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarPlaces { acc_p0: a_pa.clone(), t_p1: x_pb.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>))
        },
        crate::syntax::TypeKind::TSigiled(_, i_pc) => type_var_places_f(acc_p0, &**i_pc),
        crate::syntax::TypeKind::TArray(e_pd, _) => type_var_places_f(acc_p0, &**e_pd),
        crate::syntax::TypeKind::TTuple(ts_pe) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_pe.clone(), acc_p0.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_pf = p0;
            let x_pg = p1;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarPlaces { acc_p0: a_pf.clone(), t_p1: x_pg.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>)),
        crate::syntax::TypeKind::TGroup(x_ph) => type_var_places_f(acc_p0, &**x_ph),
        crate::syntax::TypeKind::TMap(k_pi, v_pj) => type_var_places_f(&type_var_places_f(acc_p0, &**k_pi), &**v_pj),
        crate::syntax::TypeKind::TFn(_, ps_pk, res_pl) => type_var_places_f(&crate::prelude::run_to_end(crate::prelude::fold_job(ps_pk.clone(), acc_p0.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_pm = p0;
            let x_pn = p1;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarPlaces { acc_p0: a_pm.clone(), t_p1: x_pn.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>)), &**res_pl),
        crate::syntax::TypeKind::TEmit(ty_po, _) => type_var_places_f(acc_p0, &**ty_po),
        crate::syntax::TypeKind::TNonEmpty(x_pp) => type_var_places_f(acc_p0, &**x_pp),
        _ => acc_p0.clone(),
    }
}

/// The step machine of `TypeVarPlaces`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeVarPlaces: unbounded fn [((Text, Range))], Type -> [((Text, Range))]
/// ```
pub struct TypeVarPlaces {
    pub acc_p0: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>,
    pub t_p1: crate::syntax::Type,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>> for TypeVarPlaces {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>> {
        let acc_p0 = &self.acc_p0;
        let t_p1 = &self.t_p1;
        match &*t_p1.kind_p {
            crate::syntax::TypeKind::TName(n_p2, args_p3) => {
                let name_p4 = crate::check::env::dotted_f(&n_p2.path_p);
                let known_p5 = crate::prelude::fold(acc_p0, &false, &(|seen_p8: &bool, (v_p9, _): &(crate::prelude::Text, crate::syntax::Range)| *seen_p8 || (v_p9 == &name_p4)));
                let here_p6 = if (((&crate::prelude::len(&n_p2.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::is_lower_text_f(&name_p4)) && (&crate::prelude::len(args_p3) == &crate::prelude::Nat::from(0u32))) && !known_p5 {
                    crate::prelude::push(acc_p0, &(name_p4.clone(), t_p1.span_p.clone()))
                } else {
                    acc_p0.clone()
                };
                let rest_p7 = if (&name_p4 == &crate::prelude::Text::lit("Element")) && (&crate::prelude::len(args_p3) == &crate::prelude::Nat::from(2u32)) {
                    crate::prelude::drop(args_p3, &crate::prelude::Nat::from(1u32))
                } else {
                    if &name_p4 == &crate::prelude::Text::lit("Elem") {
                        crate::prelude::Array::new()
                    } else {
                        args_p3.clone()
                    }
                };
                crate::prelude::fold_job(rest_p7.clone(), here_p6.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pa = p0;
                    let x_pb = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarPlaces { acc_p0: a_pa.clone(), t_p1: x_pb.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>).cycle()
            },
            crate::syntax::TypeKind::TSigiled(_, i_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarPlaces { acc_p0: acc_p0.clone(), t_p1: (**i_pc).clone() })),
            crate::syntax::TypeKind::TArray(e_pd, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarPlaces { acc_p0: acc_p0.clone(), t_p1: (**e_pd).clone() })),
            crate::syntax::TypeKind::TTuple(ts_pe) => crate::prelude::fold_job(ts_pe.clone(), acc_p0.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let a_pf = p0;
                let x_pg = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarPlaces { acc_p0: a_pf.clone(), t_p1: x_pg.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x_ph) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarPlaces { acc_p0: acc_p0.clone(), t_p1: (**x_ph).clone() })),
            crate::syntax::TypeKind::TMap(k_pi, v_pj) => {
                let acc_p0x = acc_p0.clone();
                let k_pix = (**k_pi).clone();
                let v_pjx = (**v_pj).clone();
                crate::prelude::call_then(start_type_var_places_f(acc_p0x.clone(), k_pix.clone()), move |type_var_places_f_20895: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarPlaces { acc_p0: type_var_places_f_20895, t_p1: v_pjx.clone() })))
            },
            crate::syntax::TypeKind::TFn(_, ps_pk, res_pl) => {
                let acc_p0x = acc_p0.clone();
                let ps_pkx = ps_pk.clone();
                let res_plx = (**res_pl).clone();
                crate::prelude::call_value(crate::prelude::fold_job(ps_pkx.clone(), acc_p0x.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pm = p0;
                    let x_pn = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarPlaces { acc_p0: a_pm.clone(), t_p1: x_pn.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>), move |fold_20960: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarPlaces { acc_p0: fold_20960, t_p1: res_plx.clone() })))
            },
            crate::syntax::TypeKind::TEmit(ty_po, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarPlaces { acc_p0: acc_p0.clone(), t_p1: (**ty_po).clone() })),
            crate::syntax::TypeKind::TNonEmpty(x_pp) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeVarPlaces { acc_p0: acc_p0.clone(), t_p1: (**x_pp).clone() })),
            _ => ::prism_rtl::Turn::Finished(acc_p0.clone()),
        }
    }
}

/// `Start TypeVarPlaces, x`: what the function value is when passed to `@Run`.
pub fn start_type_var_places_f(acc_p0: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, t_p1: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>> {
    ::std::rc::Rc::new(TypeVarPlaces { acc_p0, t_p1 })
}

/// ```prism
/// ColorVarsOfType: unbounded fn Type -> [Text]
/// ```
pub fn color_vars_of_type_f(t_p0: &crate::syntax::Type) -> crate::prelude::Array<crate::prelude::Text> {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TFn(crate::syntax::Color::ColorVar(v_p1), ps_p2, res_p3) => {
            let inner_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(ps_p2.clone(), color_vars_of_type_f(&**res_p3), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let a_p6 = p1;
                crate::prelude::call_then(start_color_vars_of_type_f(a_p6.clone()), move |color_vars_of_type_f_21301: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p5, &color_vars_of_type_f_21301)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
            if &v_p1.name_p == &crate::prelude::Text::lit("bounded") {
                inner_p4.clone()
            } else {
                crate::check::types::add_text_f(&inner_p4, &v_p1.name_p)
            }
        },
        crate::syntax::TypeKind::TFn(_, ps_p7, res_p8) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p7.clone(), color_vars_of_type_f(&**res_p8), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p9 = p0;
            let a_pa = p1;
            crate::prelude::call_then(start_color_vars_of_type_f(a_pa.clone()), move |color_vars_of_type_f_21470: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p9, &color_vars_of_type_f_21470)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::syntax::TypeKind::TName(_, args_pb) => crate::prelude::run_to_end(crate::prelude::fold_job(args_pb.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pc = p0;
            let a_pd = p1;
            crate::prelude::call_then(start_color_vars_of_type_f(a_pd.clone()), move |color_vars_of_type_f_21557: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pc, &color_vars_of_type_f_21557)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::syntax::TypeKind::TSigiled(_, i_pe) => color_vars_of_type_f(&**i_pe),
        crate::syntax::TypeKind::TArray(e_pf, _) => color_vars_of_type_f(&**e_pf),
        crate::syntax::TypeKind::TTuple(ts_pg) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_pg.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_ph = p0;
            let a_pi = p1;
            crate::prelude::call_then(start_color_vars_of_type_f(a_pi.clone()), move |color_vars_of_type_f_21715: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_ph, &color_vars_of_type_f_21715)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::syntax::TypeKind::TGroup(x_pj) => color_vars_of_type_f(&**x_pj),
        crate::syntax::TypeKind::TMap(k_pk, v_pl) => crate::check::types::union_texts_f(&color_vars_of_type_f(&**k_pk), &color_vars_of_type_f(&**v_pl)),
        crate::syntax::TypeKind::TEmit(ty_pm, _) => color_vars_of_type_f(&**ty_pm),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `ColorVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ColorVarsOfType: unbounded fn Type -> [Text]
/// ```
pub struct ColorVarsOfType {
    pub t_p0: crate::syntax::Type,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for ColorVarsOfType {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TFn(crate::syntax::Color::ColorVar(v_p1), ps_p2, res_p3) => {
                let ps_p2x = ps_p2.clone();
                let res_p3x = (**res_p3).clone();
                let v_p1x = v_p1.clone();
                crate::prelude::call_then(start_color_vars_of_type_f(res_p3x.clone()), move |color_vars_of_type_f_21252: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_value(crate::prelude::fold_job(ps_p2x.clone(), color_vars_of_type_f_21252, ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p5 = p0;
                    let a_p6 = p1;
                    crate::prelude::call_then(start_color_vars_of_type_f(a_p6.clone()), move |color_vars_of_type_f_21301: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p5, &color_vars_of_type_f_21301)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_21242: crate::prelude::Array<crate::prelude::Text>| {
                    let inner_p4 = fold_21242;
                    if &v_p1x.name_p == &crate::prelude::Text::lit("bounded") {
                        ::prism_rtl::Turn::Finished(inner_p4.clone())
                    } else {
                        ::prism_rtl::Turn::Finished(crate::check::types::add_text_f(&inner_p4, &v_p1x.name_p))
                    }
                }))
            },
            crate::syntax::TypeKind::TFn(_, ps_p7, res_p8) => {
                let ps_p7x = ps_p7.clone();
                let res_p8x = (**res_p8).clone();
                crate::prelude::call_then(start_color_vars_of_type_f(res_p8x.clone()), move |color_vars_of_type_f_21421: crate::prelude::Array<crate::prelude::Text>| crate::prelude::fold_job(ps_p7x.clone(), color_vars_of_type_f_21421, ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p9 = p0;
                    let a_pa = p1;
                    crate::prelude::call_then(start_color_vars_of_type_f(a_pa.clone()), move |color_vars_of_type_f_21470: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p9, &color_vars_of_type_f_21470)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle())
            },
            crate::syntax::TypeKind::TName(_, args_pb) => crate::prelude::fold_job(args_pb.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pc = p0;
                let a_pd = p1;
                crate::prelude::call_then(start_color_vars_of_type_f(a_pd.clone()), move |color_vars_of_type_f_21557: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pc, &color_vars_of_type_f_21557)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::syntax::TypeKind::TSigiled(_, i_pe) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ColorVarsOfType { t_p0: (**i_pe).clone() })),
            crate::syntax::TypeKind::TArray(e_pf, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ColorVarsOfType { t_p0: (**e_pf).clone() })),
            crate::syntax::TypeKind::TTuple(ts_pg) => crate::prelude::fold_job(ts_pg.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_ph = p0;
                let a_pi = p1;
                crate::prelude::call_then(start_color_vars_of_type_f(a_pi.clone()), move |color_vars_of_type_f_21715: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_ph, &color_vars_of_type_f_21715)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Type)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x_pj) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ColorVarsOfType { t_p0: (**x_pj).clone() })),
            crate::syntax::TypeKind::TMap(k_pk, v_pl) => {
                let k_pkx = (**k_pk).clone();
                let v_plx = (**v_pl).clone();
                crate::prelude::call_then(start_color_vars_of_type_f(k_pkx.clone()), move |color_vars_of_type_f_21793: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_color_vars_of_type_f(v_plx.clone()), move |color_vars_of_type_f_21814: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&color_vars_of_type_f_21793, &color_vars_of_type_f_21814))))
            },
            crate::syntax::TypeKind::TEmit(ty_pm, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ColorVarsOfType { t_p0: (**ty_pm).clone() })),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start ColorVarsOfType, x`: what the function value is when passed to `@Run`.
pub fn start_color_vars_of_type_f(t_p0: crate::syntax::Type) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(ColorVarsOfType { t_p0 })
}
