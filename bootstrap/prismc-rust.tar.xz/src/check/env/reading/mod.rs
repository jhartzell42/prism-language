//! The module `Check.Env.Reading`, from `target/bootstrap/src/prismc/check/env/reading.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Cx`:
///
/// ```prism
/// type Cx = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Cx_ {
    pub g: crate::check::env::G,
    pub home: Text,
    pub scope: crate::check::types::Rw,
    pub row_vars: Array<Text>,
    pub unwritten: crate::check::types::Col,
}

impl Show for Cx_ {
    fn show(&self, p: &mut Printer) {
        p.record("Cx", &[("g", &self.g), ("home", &self.home), ("scope", &self.scope), ("row_vars", &self.row_vars), ("unwritten", &self.unwritten)]);
    }
}

impl ToPod for Cx_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Cx", vec![("g", self.g.to_pod()), ("home", self.home.to_pod()), ("scope", self.scope.to_pod()), ("row_vars", self.row_vars.to_pod()), ("unwritten", self.unwritten.to_pod())])
    }
}

impl FromPod for Cx_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Cx_ { g: FromPod::from_pod(field(p, "g")?)?, home: FromPod::from_pod(field(p, "home")?)?, scope: FromPod::from_pod(field(p, "scope")?)?, row_vars: FromPod::from_pod(field(p, "row_vars")?)?, unwritten: FromPod::from_pod(field(p, "unwritten")?)? })
    }
}

/// ```prism
/// CxOf: fn G, Text -> Cx
/// ```
pub fn cx_of(g: &crate::check::env::G, m: &Text) -> Cx_ {
    let info = or(&get(&g.mods, m), &or(&get(&g.mods, &Text::lit("")), &dummy_mod()));
    Cx_ { g: g.clone(), home: m.clone(), scope: info.emit_rw.clone(), row_vars: if &info.row_var == &Text::lit("") {
        Array::new()
    } else {
        Array::from(vec![info.row_var.clone()])
    }, unwritten: crate::check::types::Col::CBound }
}

/// ```prism
/// let dummyMod
/// ```
pub fn dummy_mod() -> crate::check::env::ModInfo {
    crate::check::env::ModInfo { name: Text::lit(""), file: Nat::from(0u32), emit_rw: crate::check::types::empty_row(), row_var: Text::lit(""), uses: Array::new(), root: false, tree: crate::check::env::empty_module() }
}

/// ```prism
/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
/// ```
pub fn conv_type(cx_: &Cx_, st: &crate::check::types::St, t: &crate::syntax::Type) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, args) => {
            let (base, st2) = conv_named(cx_, st, n, args, &t.span);
            (crate::check::types::with_marks(&n.sigils, &base, &cx_.scope), st2.clone())
        },
        crate::syntax::TypeKind::TSigiled(sigils, inner) => {
            let (i, st2) = conv_type(cx_, st, &**inner);
            (crate::check::types::with_marks(sigils, &i, &cx_.scope), st2.clone())
        },
        crate::syntax::TypeKind::TArray(e, _) => {
            let (i, st2) = conv_type(cx_, st, &**e);
            (crate::check::types::Ty::TyArray(Rc::new(i.clone())), st2.clone())
        },
        crate::syntax::TypeKind::TTuple(ts) => {
            let (xs, st2) = conv_types(cx_, st, ts);
            (crate::check::types::Ty::TyTuple(xs.clone()), st2.clone())
        },
        crate::syntax::TypeKind::TGroup(x) => conv_type(cx_, st, &**x),
        crate::syntax::TypeKind::TMap(k, v_) => {
            let (kk, st2) = conv_type(cx_, st, &**k);
            let (vv, st3) = conv_type(cx_, &st2, &**v_);
            (crate::check::types::Ty::TyMap(Rc::new(kk.clone()), Rc::new(vv.clone())), st3.clone())
        },
        crate::syntax::TypeKind::TFn(color, ps, res) => {
            let (xs, st2) = conv_types(cx_, st, ps);
            let (r, st3) = conv_type(cx_, &st2, &**res);
            let c = match color {
                crate::syntax::Color::Bounded => cx_.unwritten.clone(),
                crate::syntax::Color::Unbounded => crate::check::types::Col::CUnbound,
                crate::syntax::Color::ColorVar(v_) => if &v_.name == &Text::lit("bounded") {
                    crate::check::types::Col::CBound
                } else {
                    crate::check::types::Col::CQ(v_.name.clone())
                },
            };
            (crate::check::types::Ty::TyFn(c.clone(), xs.clone(), Rc::new(r.clone())), st3.clone())
        },
        crate::syntax::TypeKind::TEmit(ty, row_t) => {
            let (rw, st2) = conv_row(cx_, st, &**row_t);
            let inner = {
                let mut this: Cx_ = cx_.clone();
                this.scope = rw.clone();
                this
            };
            conv_type(&inner, &st2, &**ty)
        },
        crate::syntax::TypeKind::TUnit(sigils) => (crate::check::types::with_marks(sigils, &crate::check::types::t_unit(), &cx_.scope), st.clone()),
        crate::syntax::TypeKind::TAny(tr) => match crate::check::env::names::resolve_trait(&cx_.g, &cx_.home, &tr.path_) {
            Some(k) => (crate::check::types::Ty::TyAny(Array::from(vec![k.clone()])), st.clone()),
            None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unknown-name"), &tr.span, &Text::from(format!("no trait `^{}`", &crate::check::env::dotted(&tr.path_))))),
        },
        crate::syntax::TypeKind::TAbsent => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &t.span, &Text::lit("this checker does not implement sparse tuples"))),
        crate::syntax::TypeKind::TNonEmpty(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &t.span, &Text::lit("this checker does not implement non-empty arrays"))),
        crate::syntax::TypeKind::THole(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &t.span, &Text::lit("this checker does not implement higher-kinded traits"))),
        crate::syntax::TypeKind::TFamily(q) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("kind"), &t.span, &Text::from(format!("`{}.*` is a row, not a type", &crate::check::env::dotted(&q.path_))))),
        crate::syntax::TypeKind::TRowUnion(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("kind"), &t.span, &Text::lit("a row is not a type"))),
    }
}

/// The step machine of `ConvType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
/// ```
pub struct ConvType {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ConvType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TName(n, args) => {
                let args = args.clone();
                let cx_ = cx_.clone();
                let n = n.clone();
                let st = st.clone();
                let t = t.clone();
                call_then(start_conv_named(cx_.clone(), st.clone(), n.clone(), args.clone(), t.span.clone()), move |conv_named_1482: (crate::check::types::Ty, crate::check::types::St)| {
                    let (base, st2) = conv_named_1482;
                    prism_rtl::Turn::Finished((crate::check::types::with_marks(&n.sigils, &base, &cx_.scope), st2.clone()))
                })
            },
            crate::syntax::TypeKind::TSigiled(sigils, inner) => {
                let cx_ = cx_.clone();
                let inner = (**inner).clone();
                let sigils = sigils.clone();
                let st = st.clone();
                call_then(start_conv_type(cx_.clone(), st.clone(), inner.clone()), move |conv_type_1623: (crate::check::types::Ty, crate::check::types::St)| {
                    let (i, st2) = conv_type_1623;
                    prism_rtl::Turn::Finished((crate::check::types::with_marks(&sigils, &i, &cx_.scope), st2.clone()))
                })
            },
            crate::syntax::TypeKind::TArray(e, _) => {
                let cx_ = cx_.clone();
                let e = (**e).clone();
                let st = st.clone();
                call_then(start_conv_type(cx_.clone(), st.clone(), e.clone()), move |conv_type_1742: (crate::check::types::Ty, crate::check::types::St)| {
                    let (i, st2) = conv_type_1742;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyArray(Rc::new(i.clone())), st2.clone()))
                })
            },
            crate::syntax::TypeKind::TTuple(ts) => {
                let cx_ = cx_.clone();
                let st = st.clone();
                let ts = ts.clone();
                call_then(start_conv_types(cx_.clone(), st.clone(), ts.clone()), move |conv_types_1829: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (xs, st2) = conv_types_1829;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyTuple(xs.clone()), st2.clone()))
                })
            },
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(ConvType { cx_: cx_.clone(), st: st.clone(), t: (**x).clone() })),
            crate::syntax::TypeKind::TMap(k, v_) => {
                let cx_ = cx_.clone();
                let k = (**k).clone();
                let st = st.clone();
                let v_ = (**v_).clone();
                call_then(start_conv_type(cx_.clone(), st.clone(), k.clone()), move |conv_type_1952: (crate::check::types::Ty, crate::check::types::St)| {
                    let (kk, st2) = conv_type_1952;
                    call_then(start_conv_type(cx_.clone(), st2.clone(), v_.clone()), move |conv_type_1997: (crate::check::types::Ty, crate::check::types::St)| {
                        let (vv, st3) = conv_type_1997;
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyMap(Rc::new(kk.clone()), Rc::new(vv.clone())), st3.clone()))
                    })
                })
            },
            crate::syntax::TypeKind::TFn(color, ps, res) => {
                let color = color.clone();
                let cx_ = cx_.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                let st = st.clone();
                call_then(start_conv_types(cx_.clone(), st.clone(), ps.clone()), move |conv_types_2099: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (xs, st2) = conv_types_2099;
                    call_then(start_conv_type(cx_.clone(), st2.clone(), res.clone()), move |conv_type_2145: (crate::check::types::Ty, crate::check::types::St)| {
                        let (r, st3) = conv_type_2145;
                        let c = match &color {
                            crate::syntax::Color::Bounded => cx_.unwritten.clone(),
                            crate::syntax::Color::Unbounded => crate::check::types::Col::CUnbound,
                            crate::syntax::Color::ColorVar(v_) => if &v_.name == &Text::lit("bounded") {
                                crate::check::types::Col::CBound
                            } else {
                                crate::check::types::Col::CQ(v_.name.clone())
                            },
                        };
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyFn(c.clone(), xs.clone(), Rc::new(r.clone())), st3.clone()))
                    })
                })
            },
            crate::syntax::TypeKind::TEmit(ty, row_t) => {
                let cx_ = cx_.clone();
                let row_t = (**row_t).clone();
                let st = st.clone();
                let ty = (**ty).clone();
                call_then(start_conv_row(cx_.clone(), st.clone(), row_t.clone()), move |conv_row_2412: (crate::check::types::Rw, crate::check::types::St)| {
                    let (rw, st2) = conv_row_2412;
                    let inner = {
                        let mut this: Cx_ = cx_.clone();
                        this.scope = rw.clone();
                        this
                    };
                    prism_rtl::Turn::More(Rc::new(ConvType { cx_: inner.clone(), st: st2.clone(), t: ty.clone() }))
                })
            },
            crate::syntax::TypeKind::TUnit(sigils) => prism_rtl::Turn::Finished((crate::check::types::with_marks(sigils, &crate::check::types::t_unit(), &cx_.scope), st.clone())),
            crate::syntax::TypeKind::TAny(tr) => match crate::check::env::names::resolve_trait(&cx_.g, &cx_.home, &tr.path_) {
                Some(k) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyAny(Array::from(vec![k.clone()])), st.clone())),
                None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unknown-name"), &tr.span, &Text::from(format!("no trait `^{}`", &crate::check::env::dotted(&tr.path_)))))),
            },
            crate::syntax::TypeKind::TAbsent => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &t.span, &Text::lit("this checker does not implement sparse tuples")))),
            crate::syntax::TypeKind::TNonEmpty(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &t.span, &Text::lit("this checker does not implement non-empty arrays")))),
            crate::syntax::TypeKind::THole(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &t.span, &Text::lit("this checker does not implement higher-kinded traits")))),
            crate::syntax::TypeKind::TFamily(q) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("kind"), &t.span, &Text::from(format!("`{}.*` is a row, not a type", &crate::check::env::dotted(&q.path_)))))),
            crate::syntax::TypeKind::TRowUnion(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("kind"), &t.span, &Text::lit("a row is not a type")))),
        }
    }
}

/// `Start ConvType, x`: what the function value is when passed to `@Run`.
pub fn start_conv_type(cx_: Cx_, st: crate::check::types::St, t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(ConvType { cx_, st, t })
}

/// ```prism
/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
/// ```
pub fn conv_types(cx_: &Cx_, st: &crate::check::types::St, ts: &Array<crate::syntax::Type>) -> (Array<crate::check::types::Ty>, crate::check::types::St) {
    run_to_end(fold_job(ts.clone(), (Array::new(), st.clone()), {
        let cx_ = cx_.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)| {
            let cx_ = cx_.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let x = p1;
                call_then(start_conv_type(cx_.clone(), s.clone(), x.clone()), move |conv_type_3422: (crate::check::types::Ty, crate::check::types::St)| {
                    let (y, s2) = conv_type_3422;
                    prism_rtl::Turn::Finished((push(&acc, &y), s2.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }))
}

/// The step machine of `ConvTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
/// ```
pub struct ConvTypes {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub ts: Array<crate::syntax::Type>,
}

impl prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)> for ConvTypes {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Ty>, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let ts = &self.ts;
        fold_job(ts.clone(), (Array::new(), st.clone()), {
            let cx_ = cx_.clone();
            Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)| {
                let cx_ = cx_.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let x = p1;
                    call_then(start_conv_type(cx_.clone(), s.clone(), x.clone()), move |conv_type_3422: (crate::check::types::Ty, crate::check::types::St)| {
                        let (y, s2) = conv_type_3422;
                        prism_rtl::Turn::Finished((push(&acc, &y), s2.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start ConvTypes, x`: what the function value is when passed to `@Run`.
pub fn start_conv_types(cx_: Cx_, st: crate::check::types::St, ts: Array<crate::syntax::Type>) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>> {
    Rc::new(ConvTypes { cx_, st, ts })
}

/// ```prism
/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
/// ```
pub fn conv_named(cx_: &Cx_, st: &crate::check::types::St, n: &crate::syntax::SName, args: &Array<crate::syntax::Type>, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let name = crate::check::env::dotted(&n.path_);
    if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::is_lower_text(&name) {
        if &len(args) > &Nat::from(0u32) {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement higher-kinded traits")))
        } else {
            (crate::check::types::Ty::TyQ(name.clone()), st.clone())
        }
    } else {
        if (&name == &Text::lit("Element")) || (&name == &Text::lit("Prelude.Element")) {
            match len(args) {
                m4019_0 if (&m4019_0 == &Nat::from(0u32)) => (crate::check::types::Ty::TyElem(cx_.scope.clone(), Rc::new(crate::check::types::t_unit())), st.clone()),
                m4019_1 if (&m4019_1 == &Nat::from(1u32)) => {
                    let (o, st2) = conv_type(cx_, st, &or(&index(args, &Nat::from(0u32)), &dummy_type()));
                    (crate::check::types::Ty::TyElem(cx_.scope.clone(), Rc::new(o.clone())), st2.clone())
                },
                m4019_2 if (&m4019_2 == &Nat::from(2u32)) => {
                    let (rw, st2) = conv_row(cx_, st, &or(&index(args, &Nat::from(0u32)), &dummy_type()));
                    let (o, st3) = conv_type(cx_, &st2, &or(&index(args, &Nat::from(1u32)), &dummy_type()));
                    (crate::check::types::Ty::TyElem(rw.clone(), Rc::new(o.clone())), st3.clone())
                },
                _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("kind"), span, &Text::from(format!("`Element` takes a row and a type; here it has {}", &crate::check::errors::count_word(&len(args)))))),
                _ => unreachable!("no arm matched"),
            }
        } else {
            if &name == &Text::lit("Elem") {
                match len(args) {
                    m4588_0 if (&m4588_0 == &Nat::from(0u32)) => (crate::check::types::Ty::TyElemAny(cx_.scope.clone()), st.clone()),
                    m4588_1 if (&m4588_1 == &Nat::from(1u32)) => {
                        let (rw, st2) = conv_row(cx_, st, &or(&index(args, &Nat::from(0u32)), &dummy_type()));
                        (crate::check::types::Ty::TyElemAny(rw.clone()), st2.clone())
                    },
                    _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("kind"), span, &Text::from(format!("`Elem` takes a row; here it has {}", &crate::check::errors::count_word(&len(args)))))),
                    _ => unreachable!("no arm matched"),
                }
            } else {
                if (&name == &Text::lit("Answer")) || (&name == &Text::lit("Wired")) {
                    (crate::check::types::Ty::TyCon(name.clone(), Array::new()), st.clone())
                } else {
                    if &name == &Text::lit("Instant") {
                        (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement `Instant`")))
                    } else {
                        if crate::check::types::has_text(&Array::from(vec![Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")]), &name) {
                            (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement sized integers other than `U8`")))
                        } else {
                            if crate::check::env::is_prim_type(&name) {
                                if &len(args) == &Nat::from(0u32) {
                                    (crate::check::types::Ty::TyCon(name.clone(), Array::new()), st.clone())
                                } else {
                                    (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("kind"), span, &Text::from(format!("`{}` takes no type; here it has {}", &name, &crate::check::errors::count_word(&len(args))))))
                                }
                            } else {
                                if (&name == &Text::lit("Buffer")) || (&name == &Text::lit("Table")) {
                                    {
                                        let want = if &name == &Text::lit("Buffer") { Nat::from(1u32) } else { Nat::from(2u32) };
                                        let (xs, st2) = conv_types(cx_, st, args);
                                        if &len(args) == &want {
                                            (crate::check::types::Ty::TyCon(name.clone(), xs.clone()), st2.clone())
                                        } else {
                                            (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st2, &Text::lit("kind"), span, &Text::from(format!("`{}` takes {} types; here it has {}", &name, &crate::check::errors::count_word(&want), &crate::check::errors::count_word(&len(args))))))
                                        }
                                    }
                                } else {
                                    {
                                        let (key_opt, why) = crate::check::env::names::resolve_type(&cx_.g, &cx_.home, &n.path_);
                                        match &key_opt {
                                            None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unknown-name"), span, &Text::from(format!("no type `{}`", &name)))),
                                            Some(qk) => {
                                                let ti = or(&get(&cx_.g.types, qk), &crate::check::env::names::dummy_ty_info());
                                                let st1 = if &why == &Text::lit("collision") {
                                                    crate::check::types::recording::err_fix(st, &Text::lit("collision"), span, &Text::from(format!("`{}` is declared by two modules this file reaches by a bare name", &name)), &Text::from(format!("write it qualified, `{}`, or rename this file's own", qk)))
                                                } else {
                                                    st.clone()
                                                };
                                                let (xs, st2) = conv_types(cx_, &st1, args);
                                                if &len(&xs) != &len(&ti.params) {
                                                    (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st2, &Text::lit("kind"), span, &Text::from(format!("`{}` takes {} type{}; here it has {}", &name, &crate::check::errors::count_word(&len(&ti.params)), &(if &len(&ti.params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(&xs))))))
                                                } else {
                                                    match &ti.body {
                                                        crate::check::env::TyBody::BAlias(body) => (crate::check::types::schemes::subst_q(&param_inst(&ti.params, &xs), body), st2.clone()),
                                                        crate::check::env::TyBody::BRowKind => (crate::check::types::Ty::TyCon(qk.clone(), xs.clone()), st2.clone()),
                                                        _ => (crate::check::types::Ty::TyCon(qk.clone(), xs.clone()), st2.clone()),
                                                    }
                                                }
                                            },
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `ConvNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
/// ```
pub struct ConvNamed {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub n: crate::syntax::SName,
    pub args: Array<crate::syntax::Type>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ConvNamed {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let n = &self.n;
        let args = &self.args;
        let span = &self.span;
        let name = crate::check::env::dotted(&n.path_);
        if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::is_lower_text(&name) {
            if &len(args) > &Nat::from(0u32) {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement higher-kinded traits"))))
            } else {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyQ(name.clone()), st.clone()))
            }
        } else {
            if (&name == &Text::lit("Element")) || (&name == &Text::lit("Prelude.Element")) {
                match len(args) {
                    m4019_0 if (&m4019_0 == &Nat::from(0u32)) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(cx_.scope.clone(), Rc::new(crate::check::types::t_unit())), st.clone())),
                    m4019_1 if (&m4019_1 == &Nat::from(1u32)) => {
                        let args = args.clone();
                        let cx_ = cx_.clone();
                        let st = st.clone();
                        call_then(start_conv_type(cx_.clone(), st.clone(), or(&index(&args, &Nat::from(0u32)), &dummy_type())), move |conv_type_4131: (crate::check::types::Ty, crate::check::types::St)| {
                            let (o, st2) = conv_type_4131;
                            prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(cx_.scope.clone(), Rc::new(o.clone())), st2.clone()))
                        })
                    },
                    m4019_2 if (&m4019_2 == &Nat::from(2u32)) => {
                        let args = args.clone();
                        let cx_ = cx_.clone();
                        let st = st.clone();
                        call_then(start_conv_row(cx_.clone(), st.clone(), or(&index(&args, &Nat::from(0u32)), &dummy_type())), move |conv_row_4267: (crate::check::types::Rw, crate::check::types::St)| {
                            let (rw, st2) = conv_row_4267;
                            call_then(start_conv_type(cx_.clone(), st2.clone(), or(&index(&args, &Nat::from(1u32)), &dummy_type())), move |conv_type_4340: (crate::check::types::Ty, crate::check::types::St)| {
                                let (o, st3) = conv_type_4340;
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(rw.clone(), Rc::new(o.clone())), st3.clone()))
                            })
                        })
                    },
                    _ => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("kind"), span, &Text::from(format!("`Element` takes a row and a type; here it has {}", &crate::check::errors::count_word(&len(args))))))),
                    _ => unreachable!("no arm matched"),
                }
            } else {
                if &name == &Text::lit("Elem") {
                    match len(args) {
                        m4588_0 if (&m4588_0 == &Nat::from(0u32)) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyElemAny(cx_.scope.clone()), st.clone())),
                        m4588_1 if (&m4588_1 == &Nat::from(1u32)) => {
                            let args = args.clone();
                            let cx_ = cx_.clone();
                            let st = st.clone();
                            call_then(start_conv_row(cx_.clone(), st.clone(), or(&index(&args, &Nat::from(0u32)), &dummy_type())), move |conv_row_4695: (crate::check::types::Rw, crate::check::types::St)| {
                                let (rw, st2) = conv_row_4695;
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyElemAny(rw.clone()), st2.clone()))
                            })
                        },
                        _ => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("kind"), span, &Text::from(format!("`Elem` takes a row; here it has {}", &crate::check::errors::count_word(&len(args))))))),
                        _ => unreachable!("no arm matched"),
                    }
                } else {
                    if (&name == &Text::lit("Answer")) || (&name == &Text::lit("Wired")) {
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(name.clone(), Array::new()), st.clone()))
                    } else {
                        if &name == &Text::lit("Instant") {
                            prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement `Instant`"))))
                        } else {
                            if crate::check::types::has_text(&Array::from(vec![Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")]), &name) {
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), span, &Text::lit("this checker does not implement sized integers other than `U8`"))))
                            } else {
                                if crate::check::env::is_prim_type(&name) {
                                    if &len(args) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(name.clone(), Array::new()), st.clone()))
                                    } else {
                                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("kind"), span, &Text::from(format!("`{}` takes no type; here it has {}", &name, &crate::check::errors::count_word(&len(args)))))))
                                    }
                                } else {
                                    if (&name == &Text::lit("Buffer")) || (&name == &Text::lit("Table")) {
                                        {
                                            let want = if &name == &Text::lit("Buffer") { Nat::from(1u32) } else { Nat::from(2u32) };
                                            let args = args.clone();
                                            let cx_ = cx_.clone();
                                            let span = span.clone();
                                            let st = st.clone();
                                            call_then(start_conv_types(cx_.clone(), st.clone(), args.clone()), move |conv_types_5630: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                                                let (xs, st2) = conv_types_5630;
                                                if &len(&args) == &want {
                                                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(name.clone(), xs.clone()), st2.clone()))
                                                } else {
                                                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st2, &Text::lit("kind"), &span, &Text::from(format!("`{}` takes {} types; here it has {}", &name, &crate::check::errors::count_word(&want), &crate::check::errors::count_word(&len(&args)))))))
                                                }
                                            })
                                        }
                                    } else {
                                        {
                                            let (key_opt, why) = crate::check::env::names::resolve_type(&cx_.g, &cx_.home, &n.path_);
                                            match &key_opt {
                                                None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unknown-name"), span, &Text::from(format!("no type `{}`", &name))))),
                                                Some(qk) => {
                                                    let ti = or(&get(&cx_.g.types, qk), &crate::check::env::names::dummy_ty_info());
                                                    let st1 = if &why == &Text::lit("collision") {
                                                        crate::check::types::recording::err_fix(st, &Text::lit("collision"), span, &Text::from(format!("`{}` is declared by two modules this file reaches by a bare name", &name)), &Text::from(format!("write it qualified, `{}`, or rename this file's own", qk)))
                                                    } else {
                                                        st.clone()
                                                    };
                                                    let args = args.clone();
                                                    let cx_ = cx_.clone();
                                                    let qk = qk.clone();
                                                    let span = span.clone();
                                                    call_then(start_conv_types(cx_.clone(), st1.clone(), args.clone()), move |conv_types_6331: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                                                        let (xs, st2) = conv_types_6331;
                                                        if &len(&xs) != &len(&ti.params) {
                                                            prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st2, &Text::lit("kind"), &span, &Text::from(format!("`{}` takes {} type{}; here it has {}", &name, &crate::check::errors::count_word(&len(&ti.params)), &(if &len(&ti.params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(&xs)))))))
                                                        } else {
                                                            match &ti.body {
                                                                crate::check::env::TyBody::BAlias(body) => {
                                                                    let body = body.clone();
                                                                    call_then(crate::check::types::schemes::start_subst_q(param_inst(&ti.params, &xs), body.clone()), move |subst_q_6655: crate::check::types::Ty| prism_rtl::Turn::Finished((subst_q_6655, st2.clone())))
                                                                },
                                                                crate::check::env::TyBody::BRowKind => prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(qk.clone(), xs.clone()), st2.clone())),
                                                                _ => prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(qk.clone(), xs.clone()), st2.clone())),
                                                            }
                                                        }
                                                    })
                                                },
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// `Start ConvNamed, x`: what the function value is when passed to `@Run`.
pub fn start_conv_named(cx_: Cx_, st: crate::check::types::St, n: crate::syntax::SName, args: Array<crate::syntax::Type>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(ConvNamed { cx_, st, n, args, span })
}

/// ```prism
/// let dummyType
/// ```
pub fn dummy_type() -> crate::syntax::Type {
    crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TAbsent), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// ParamInst: fn [Text], [Ty] -> Inst
/// ```
pub fn param_inst(ps: &Array<Text>, xs: &Array<crate::check::types::Ty>) -> crate::check::types::schemes::Inst {
    crate::check::types::schemes::Inst { tys: fold(&crate::check::errors::range0(&len(ps)), &Map::new(), &(|m: &Map<Text, crate::check::types::Ty>, i: &Nat| insert(m, &or(&index(ps, i), &Text::lit("")), &or(&index(xs, i), &crate::check::types::Ty::TyErr)))), rows: Map::new(), cols: Map::new() }
}

/// ```prism
/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
/// ```
pub fn conv_row(cx_: &Cx_, st: &crate::check::types::St, t: &crate::syntax::Type) -> (crate::check::types::Rw, crate::check::types::St) {
    let (fams, vars, st2) = row_parts(cx_, st, t);
    let st3 = if &len(&vars) > &Nat::from(1u32) {
        crate::check::types::recording::err_fix(&st2, &Text::lit("row-two-tails"), &t.span, &Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::chars::join(&vars, &Text::lit(" | ")))), &Text::lit("keep one variable"))
    } else {
        st2.clone()
    };
    let tail = match index(&vars, &Nat::from(0u32)) {
        Some(v_) => crate::check::types::Tail::TlQ(v_.clone()),
        None => crate::check::types::Tail::TlClosed,
    };
    (crate::check::types::Rw { fams: crate::check::types::sort_texts(&fams), minus: Array::new(), tail: tail.clone() }, st3.clone())
}

/// The step machine of `ConvRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
/// ```
pub struct ConvRow {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<(crate::check::types::Rw, crate::check::types::St)> for ConvRow {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Rw, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let t = &self.t;
        let cx_ = cx_.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_row_parts(cx_.clone(), st.clone(), t.clone()), move |row_parts_7214: (Array<Text>, Array<Text>, crate::check::types::St)| {
            let (fams, vars, st2) = row_parts_7214;
            let st3 = if &len(&vars) > &Nat::from(1u32) {
                crate::check::types::recording::err_fix(&st2, &Text::lit("row-two-tails"), &t.span, &Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::chars::join(&vars, &Text::lit(" | ")))), &Text::lit("keep one variable"))
            } else {
                st2.clone()
            };
            let tail = match index(&vars, &Nat::from(0u32)) {
                Some(v_) => crate::check::types::Tail::TlQ(v_.clone()),
                None => crate::check::types::Tail::TlClosed,
            };
            prism_rtl::Turn::Finished((crate::check::types::Rw { fams: crate::check::types::sort_texts(&fams), minus: Array::new(), tail: tail.clone() }, st3.clone()))
        })
    }
}

/// `Start ConvRow, x`: what the function value is when passed to `@Run`.
pub fn start_conv_row(cx_: Cx_, st: crate::check::types::St, t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(crate::check::types::Rw, crate::check::types::St)>> {
    Rc::new(ConvRow { cx_, st, t })
}

/// ```prism
/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
/// ```
pub fn row_parts(cx_: &Cx_, st: &crate::check::types::St, t: &crate::syntax::Type) -> (Array<Text>, Array<Text>, crate::check::types::St) {
    match &*t.kind {
        crate::syntax::TypeKind::TRowUnion(ts) => run_to_end(fold_job(ts.clone(), (Array::new(), Array::new(), st.clone()), {
            let cx_ = cx_.clone();
            Rc::new(move |(p0, p1): ((Array<Text>, Array<Text>, crate::check::types::St), crate::syntax::Type)| {
                let cx_ = cx_.clone();
                entered(once_job(move || {
                    let (fs, vs, s) = p0;
                    let x = p1;
                    call_then(start_row_parts(cx_.clone(), s.clone(), x.clone()), move |row_parts_7721: (Array<Text>, Array<Text>, crate::check::types::St)| {
                        let (f2, v2, s2) = row_parts_7721;
                        prism_rtl::Turn::Finished((append(&fs, &f2), append(&vs, &v2), s2.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<Text>, Array<Text>, crate::check::types::St), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<Text>, crate::check::types::St)>>>
        })),
        crate::syntax::TypeKind::TGroup(x) => row_parts(cx_, st, &**x),
        crate::syntax::TypeKind::TFamily(q) => (Array::from(vec![crate::check::env::dotted(&q.path_)]), Array::new(), crate::check::env::names::check_family(&cx_.g, st, &crate::check::env::dotted(&q.path_), &q.span)),
        crate::syntax::TypeKind::TName(n, m7611_3_1) if (m7611_3_1.len() == 0) => {
            let name = crate::check::env::dotted(&n.path_);
            if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::is_lower_text(&name) {
                (Array::new(), Array::from(vec![name.clone()]), st.clone())
            } else {
                if &name == &Text::lit("Element") {
                    (cx_.scope.fams.clone(), tail_names(&cx_.scope.tail), st.clone())
                } else {
                    (Array::new(), Array::new(), crate::check::types::recording::err_fix(st, &Text::lit("row-single-tag"), &t.span, &Text::from(format!("a row names families, not tags: `{}`", &name)), &Text::from(format!("write `{}.*`", &crate::check::env::dotted(&take(&n.path_, &crate::syntax::lexer::chars::dec(&len(&n.path_))))))))
                }
            }
        },
        _ => (Array::new(), Array::new(), crate::check::types::recording::err(st, &Text::lit("kind"), &t.span, &Text::lit("this is not a row"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
/// ```
pub struct RowParts {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<(Array<Text>, Array<Text>, crate::check::types::St)> for RowParts {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, Array<Text>, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TRowUnion(ts) => fold_job(ts.clone(), (Array::new(), Array::new(), st.clone()), {
                let cx_ = cx_.clone();
                Rc::new(move |(p0, p1): ((Array<Text>, Array<Text>, crate::check::types::St), crate::syntax::Type)| {
                    let cx_ = cx_.clone();
                    entered(once_job(move || {
                        let (fs, vs, s) = p0;
                        let x = p1;
                        call_then(start_row_parts(cx_.clone(), s.clone(), x.clone()), move |row_parts_7721: (Array<Text>, Array<Text>, crate::check::types::St)| {
                            let (f2, v2, s2) = row_parts_7721;
                            prism_rtl::Turn::Finished((append(&fs, &f2), append(&vs, &v2), s2.clone()))
                        })
                    }))
                }) as Rc<dyn Fn(((Array<Text>, Array<Text>, crate::check::types::St), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<Text>, crate::check::types::St)>>>
            }).cycle(),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(RowParts { cx_: cx_.clone(), st: st.clone(), t: (**x).clone() })),
            crate::syntax::TypeKind::TFamily(q) => prism_rtl::Turn::Finished((Array::from(vec![crate::check::env::dotted(&q.path_)]), Array::new(), crate::check::env::names::check_family(&cx_.g, st, &crate::check::env::dotted(&q.path_), &q.span))),
            crate::syntax::TypeKind::TName(n, m7611_3_1) if (m7611_3_1.len() == 0) => {
                let name = crate::check::env::dotted(&n.path_);
                if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::is_lower_text(&name) {
                    prism_rtl::Turn::Finished((Array::new(), Array::from(vec![name.clone()]), st.clone()))
                } else {
                    if &name == &Text::lit("Element") {
                        prism_rtl::Turn::Finished((cx_.scope.fams.clone(), tail_names(&cx_.scope.tail), st.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Array::new(), Array::new(), crate::check::types::recording::err_fix(st, &Text::lit("row-single-tag"), &t.span, &Text::from(format!("a row names families, not tags: `{}`", &name)), &Text::from(format!("write `{}.*`", &crate::check::env::dotted(&take(&n.path_, &crate::syntax::lexer::chars::dec(&len(&n.path_)))))))))
                    }
                }
            },
            _ => prism_rtl::Turn::Finished((Array::new(), Array::new(), crate::check::types::recording::err(st, &Text::lit("kind"), &t.span, &Text::lit("this is not a row")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start RowParts, x`: what the function value is when passed to `@Run`.
pub fn start_row_parts(cx_: Cx_, st: crate::check::types::St, t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<Text>, crate::check::types::St)>> {
    Rc::new(RowParts { cx_, st, t })
}

/// ```prism
/// TailNames: fn Tail -> [Text]
/// ```
pub fn tail_names(tail0: &crate::check::types::Tail) -> Array<Text> {
    match tail0 {
        crate::check::types::Tail::TlQ(v_) => Array::from(vec![v_.clone()]),
        crate::check::types::Tail::TlRigid(v_) => Array::from(vec![v_.clone()]),
        _ => Array::new(),
    }
}

/// ```prism
/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
/// ```
pub fn sig_scheme(cx_: &Cx_, st: &crate::check::types::St, t: &crate::syntax::Type, bounds: &Array<crate::syntax::decls::Bound>) -> (crate::check::types::Scheme, crate::check::types::St) {
    let row_vars = crate::check::types::union_texts(&cx_.row_vars, &row_vars_of_type(t));
    let cx2 = {
        let mut this: Cx_ = cx_.clone();
        this.row_vars = row_vars.clone();
        this.unwritten = crate::check::types::Col::CBound;
        this
    };
    let written = color_vars_of_type(t);
    let (ty, defaults, joins, st2) = sig_type(&cx2, st, t, &written);
    let tvs = filter(&type_vars_of_type(t), &(|v_: &Text| !crate::check::types::has_text(&row_vars, v_)));
    let cqs = fold(&defaults, &written, &(|acc: &Array<Text>, v_: &Text| crate::check::types::add_text(acc, v_)));
    let (bs, st3) = conv_bounds(cx_, &st2, bounds);
    let rows_used = run_to_end(filter_job(row_vars.clone(), {
        let t = t.clone();
        Rc::new(move |p0: Text| {
            let t = t.clone();
            entered(once_job(move || {
                let v_ = p0;
                call_then(start_row_vars_of_type(t.clone()), move |row_vars_of_type_9242: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::has_text(&row_vars_of_type_9242, &v_) || uses_scope(&t)))
            }))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    (crate::check::types::Scheme { qs: tvs.clone(), plain_qs: Array::new(), rqs: rows_used.clone(), cqs: cqs.clone(), cjoins: joins.clone(), bounds: bs.clone(), ty: ty.clone() }, st3.clone())
}

/// The step machine of `SigScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
/// ```
pub struct SigScheme {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Type,
    pub bounds: Array<crate::syntax::decls::Bound>,
}

impl prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)> for SigScheme {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Scheme, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let t = &self.t;
        let bounds = &self.bounds;
        let bounds = bounds.clone();
        let cx_ = cx_.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_row_vars_of_type(t.clone()), move |row_vars_of_type_8803: Array<Text>| {
            let row_vars = crate::check::types::union_texts(&cx_.row_vars, &row_vars_of_type_8803);
            let cx2 = {
                let mut this: Cx_ = cx_.clone();
                this.row_vars = row_vars.clone();
                this.unwritten = crate::check::types::Col::CBound;
                this
            };
            call_then(start_color_vars_of_type(t.clone()), move |color_vars_of_type_8924: Array<Text>| {
                let written = color_vars_of_type_8924;
                call_then(start_sig_type(cx2.clone(), st.clone(), t.clone(), written.clone()), move |sig_type_8981: (crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)| {
                    let (ty, defaults, joins, st2) = sig_type_8981;
                    call_then(start_type_vars_of_type(t.clone()), move |type_vars_of_type_9031: Array<Text>| {
                        let tvs = filter(&type_vars_of_type_9031, &(|v_: &Text| !crate::check::types::has_text(&row_vars, v_)));
                        let cqs = fold(&defaults, &written, &(|acc: &Array<Text>, v_: &Text| crate::check::types::add_text(acc, v_)));
                        let (bs, st3) = conv_bounds(&cx_, &st2, &bounds);
                        call_value(filter_job(row_vars.clone(), {
                            let t = t.clone();
                            Rc::new(move |p0: Text| {
                                let t = t.clone();
                                entered(once_job(move || {
                                    let v_ = p0;
                                    call_then(start_row_vars_of_type(t.clone()), move |row_vars_of_type_9242: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::has_text(&row_vars_of_type_9242, &v_) || uses_scope(&t)))
                                }))
                            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |filter_9211: Array<Text>| {
                            let rows_used = filter_9211;
                            prism_rtl::Turn::Finished((crate::check::types::Scheme { qs: tvs.clone(), plain_qs: Array::new(), rqs: rows_used.clone(), cqs: cqs.clone(), cjoins: joins.clone(), bounds: bs.clone(), ty: ty.clone() }, st3.clone()))
                        })
                    })
                })
            })
        })
    }
}

/// `Start SigScheme, x`: what the function value is when passed to `@Run`.
pub fn start_sig_scheme(cx_: Cx_, st: crate::check::types::St, t: crate::syntax::Type, bounds: Array<crate::syntax::decls::Bound>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)>> {
    Rc::new(SigScheme { cx_, st, t, bounds })
}

/// ```prism
/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub fn sig_type(cx_: &Cx_, st: &crate::check::types::St, t: &crate::syntax::Type, written: &Array<Text>) -> (crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St) {
    match &*t.kind {
        crate::syntax::TypeKind::TGroup(x) => sig_type(cx_, st, &**x, written),
        crate::syntax::TypeKind::TFn(color, ps, res) => if mentions_time(t) || !takes_closure(t) {
            bounded_sig(cx_, st, t)
        } else {
            closure_sig(cx_, st, color, ps, &**res, written)
        },
        _ => bounded_sig(cx_, st, t),
    }
}

/// The step machine of `SigType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub struct SigType {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Type,
    pub written: Array<Text>,
}

impl prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> for SigType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let t = &self.t;
        let written = &self.written;
        match &*t.kind {
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(SigType { cx_: cx_.clone(), st: st.clone(), t: (**x).clone(), written: written.clone() })),
            crate::syntax::TypeKind::TFn(color, ps, res) => {
                let color = color.clone();
                let cx_ = cx_.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                let st = st.clone();
                let t = t.clone();
                let written = written.clone();
                call_then(start_mentions_time(t.clone()), move |mentions_time_10384: bool| if mentions_time_10384 || !takes_closure(&t) {
                    prism_rtl::Turn::More(Rc::new(BoundedSig { cx_: cx_.clone(), st: st.clone(), t: t.clone() }))
                } else {
                    prism_rtl::Turn::More(Rc::new(ClosureSig { cx_: cx_.clone(), st: st.clone(), color: color.clone(), ps: ps.clone(), res: res.clone(), written: written.clone() }))
                })
            },
            _ => prism_rtl::Turn::More(Rc::new(BoundedSig { cx_: cx_.clone(), st: st.clone(), t: t.clone() })),
        }
    }
}

/// `Start SigType, x`: what the function value is when passed to `@Run`.
pub fn start_sig_type(cx_: Cx_, st: crate::check::types::St, t: crate::syntax::Type, written: Array<Text>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)>> {
    Rc::new(SigType { cx_, st, t, written })
}

/// ```prism
/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub fn bounded_sig(cx_: &Cx_, st: &crate::check::types::St, t: &crate::syntax::Type) -> (crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St) {
    let (ty, st2) = conv_type(cx_, st, t);
    (ty.clone(), Array::new(), Array::new(), st2.clone())
}

/// The step machine of `BoundedSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub struct BoundedSig {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> for BoundedSig {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let t = &self.t;
        let cx_ = cx_.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_conv_type(cx_.clone(), st.clone(), t.clone()), move |conv_type_10665: (crate::check::types::Ty, crate::check::types::St)| {
            let (ty, st2) = conv_type_10665;
            prism_rtl::Turn::Finished((ty.clone(), Array::new(), Array::new(), st2.clone()))
        })
    }
}

/// `Start BoundedSig, x`: what the function value is when passed to `@Run`.
pub fn start_bounded_sig(cx_: Cx_, st: crate::check::types::St, t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)>> {
    Rc::new(BoundedSig { cx_, st, t })
}

/// ```prism
/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub fn closure_sig(cx_: &Cx_, st: &crate::check::types::St, color: &crate::syntax::Color, ps: &Array<crate::syntax::Type>, res: &crate::syntax::Type, written: &Array<Text>) -> (crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St) {
    let (outer_set, outer_w) = written_col(color);
    let bounded_outer = outer_set && (&outer_w == &crate::check::types::Col::CBound);
    let n_default = len(&run_to_end(filter_job(ps.clone(), Rc::new(move |p0: crate::syntax::Type| entered(once_job(move || {
        let p_ = p0;
        call_then(start_is_fn_type(p_.clone()), move |is_fn_type_11003: bool| prism_rtl::Turn::Finished(is_fn_type_11003 && !writes_col(&top_color(&p_))))
    }))) as Rc<dyn Fn(crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>>>)));
    let names = fresh_col_names(written, &(if bounded_outer { Nat::from(0u32) } else { n_default.clone() }));
    let (pcols, _) = run_to_end(fold_job(ps.clone(), (Array::new(), Nat::from(0u32)), {
        let bounded_outer = bounded_outer;
        let names = names.clone();
        Rc::new(move |(p0, p1): ((Array<(bool, crate::check::types::Col)>, Nat), crate::syntax::Type)| {
            let bounded_outer = bounded_outer;
            let names = names.clone();
            entered(once_job(move || {
                let (acc, k) = p0;
                let p_ = p1;
                call_then(start_is_fn_type(p_.clone()), move |is_fn_type_11280: bool| if !is_fn_type_11280 {
                    prism_rtl::Turn::Finished((push(&acc, &(false, crate::check::types::Col::CBound)), k.clone()))
                } else {
                    call_then(start_top_color(p_.clone()), move |top_color_11385: crate::syntax::Color| {
                        let (set, c) = written_col(&top_color_11385);
                        if set {
                            prism_rtl::Turn::Finished((push(&acc, &(true, c.clone())), k.clone()))
                        } else {
                            if bounded_outer {
                                prism_rtl::Turn::Finished((push(&acc, &(true, crate::check::types::Col::CBound)), k.clone()))
                            } else {
                                prism_rtl::Turn::Finished((push(&acc, &(true, crate::check::types::Col::CQ(or(&index(&names, &k), &Text::lit("u"))))), &k + &Nat::from(1u32)))
                            }
                        }
                    })
                })
            }))
        }) as Rc<dyn Fn(((Array<(bool, crate::check::types::Col)>, Nat), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<(bool, crate::check::types::Col)>, Nat)>>>
    }));
    let vars = fold(&pcols, &Array::new(), &(|acc: &Array<Text>, (_, c): &(bool, crate::check::types::Col)| match c {
        crate::check::types::Col::CQ(v_) => crate::check::types::add_text(acc, v_),
        _ => acc.clone(),
    }));
    let any_unbounded = fold(&pcols, &false, &(|seen: &bool, (_, c): &(bool, crate::check::types::Col)| *seen || (c == &crate::check::types::Col::CUnbound)));
    let spare = fresh_col_names(&append(written, &names), &Nat::from(1u32));
    let outer_name = if (outer_set || any_unbounded) || (&len(&vars) < &Nat::from(2u32)) {
        Text::lit("")
    } else {
        or(&index(&spare, &Nat::from(0u32)), &Text::lit("u"))
    };
    let outer = if outer_set {
        outer_w.clone()
    } else {
        if any_unbounded {
            crate::check::types::Col::CUnbound
        } else {
            if &len(&vars) == &Nat::from(0u32) {
                crate::check::types::Col::CBound
            } else {
                if &len(&vars) == &Nat::from(1u32) {
                    crate::check::types::Col::CQ(or(&index(&vars, &Nat::from(0u32)), &Text::lit("u")))
                } else {
                    crate::check::types::Col::CQ(outer_name.clone())
                }
            }
        }
    };
    let joins = match &outer {
        crate::check::types::Col::CQ(hi) => each(&filter(&vars, &(|v_: &Text| v_ != hi)), &(|v_: &Text| (v_.clone(), hi.clone()))),
        _ => Array::new(),
    };
    let cx_outer = with_unwritten(cx_, &outer);
    let (xs, st2) = run_to_end(fold_job(crate::check::errors::range0(&len(ps)), (Array::new(), st.clone()), {
        let ps = ps.clone();
        let res = res.clone();
        let pcols = pcols.clone();
        let cx_ = cx_.clone();
        let cx_outer = cx_outer.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
            let ps = ps.clone();
            let res = res.clone();
            let pcols = pcols.clone();
            let cx_ = cx_.clone();
            let cx_outer = cx_outer.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let i = p1;
                {
                    let p_ = or(&index(&ps, &i), &res);
                    let (is_fn, c) = or(&index(&pcols, &i), &(false, crate::check::types::Col::CBound));
                    let pcx = if is_fn { with_unwritten(&cx_, &c) } else { cx_outer.clone() };
                    call_then(start_conv_type(pcx.clone(), s.clone(), p_.clone()), move |conv_type_12554: (crate::check::types::Ty, crate::check::types::St)| {
                        let (y, s2) = conv_type_12554;
                        prism_rtl::Turn::Finished((push(&acc, &y), s2.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }));
    let (r, st3) = conv_type(&cx_outer, &st2, res);
    let added = if &outer_name == &Text::lit("") { names.clone() } else { push(&names, &outer_name) };
    (crate::check::types::Ty::TyFn(outer.clone(), xs.clone(), Rc::new(r.clone())), added.clone(), joins.clone(), st3.clone())
}

/// The step machine of `ClosureSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub struct ClosureSig {
    pub cx_: Cx_,
    pub st: crate::check::types::St,
    pub color: crate::syntax::Color,
    pub ps: Array<crate::syntax::Type>,
    pub res: crate::syntax::Type,
    pub written: Array<Text>,
}

impl prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> for ClosureSig {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> {
        let cx_ = &self.cx_;
        let st = &self.st;
        let color = &self.color;
        let ps = &self.ps;
        let res = &self.res;
        let written = &self.written;
        let (outer_set, outer_w) = written_col(color);
        let bounded_outer = outer_set && (&outer_w == &crate::check::types::Col::CBound);
        let color = color.clone();
        let cx_ = cx_.clone();
        let ps = ps.clone();
        let res = res.clone();
        let st = st.clone();
        let written = written.clone();
        call_value(filter_job(ps.clone(), Rc::new(move |p0: crate::syntax::Type| entered(once_job(move || {
            let p_ = p0;
            call_then(start_is_fn_type(p_.clone()), move |is_fn_type_11003: bool| prism_rtl::Turn::Finished(is_fn_type_11003 && !writes_col(&top_color(&p_))))
        }))) as Rc<dyn Fn(crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>>>), move |filter_10986: Array<crate::syntax::Type>| {
            let n_default = len(&filter_10986);
            call_then(start_fresh_col_names(written.clone(), if bounded_outer { Nat::from(0u32) } else { n_default.clone() }), move |fresh_col_names_11065: Array<Text>| {
                let names = fresh_col_names_11065;
                call_value(fold_job(ps.clone(), (Array::new(), Nat::from(0u32)), {
                    let bounded_outer = bounded_outer;
                    let names = names.clone();
                    Rc::new(move |(p0, p1): ((Array<(bool, crate::check::types::Col)>, Nat), crate::syntax::Type)| {
                        let bounded_outer = bounded_outer;
                        let names = names.clone();
                        entered(once_job(move || {
                            let (acc, k) = p0;
                            let p_ = p1;
                            call_then(start_is_fn_type(p_.clone()), move |is_fn_type_11280: bool| if !is_fn_type_11280 {
                                prism_rtl::Turn::Finished((push(&acc, &(false, crate::check::types::Col::CBound)), k.clone()))
                            } else {
                                call_then(start_top_color(p_.clone()), move |top_color_11385: crate::syntax::Color| {
                                    let (set, c) = written_col(&top_color_11385);
                                    if set {
                                        prism_rtl::Turn::Finished((push(&acc, &(true, c.clone())), k.clone()))
                                    } else {
                                        if bounded_outer {
                                            prism_rtl::Turn::Finished((push(&acc, &(true, crate::check::types::Col::CBound)), k.clone()))
                                        } else {
                                            prism_rtl::Turn::Finished((push(&acc, &(true, crate::check::types::Col::CQ(or(&index(&names, &k), &Text::lit("u"))))), &k + &Nat::from(1u32)))
                                        }
                                    }
                                })
                            })
                        }))
                    }) as Rc<dyn Fn(((Array<(bool, crate::check::types::Col)>, Nat), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<(bool, crate::check::types::Col)>, Nat)>>>
                }), move |fold_11225: (Array<(bool, crate::check::types::Col)>, Nat)| {
                    let (pcols, _) = fold_11225;
                    let vars = fold(&pcols, &Array::new(), &(|acc: &Array<Text>, (_, c): &(bool, crate::check::types::Col)| match c {
                        crate::check::types::Col::CQ(v_) => crate::check::types::add_text(acc, v_),
                        _ => acc.clone(),
                    }));
                    let any_unbounded = fold(&pcols, &false, &(|seen: &bool, (_, c): &(bool, crate::check::types::Col)| *seen || (c == &crate::check::types::Col::CUnbound)));
                    call_then(start_fresh_col_names(append(&written, &names), Nat::from(1u32)), move |fresh_col_names_11813: Array<Text>| {
                        let spare = fresh_col_names_11813;
                        let outer_name = if (outer_set || any_unbounded) || (&len(&vars) < &Nat::from(2u32)) {
                            Text::lit("")
                        } else {
                            or(&index(&spare, &Nat::from(0u32)), &Text::lit("u"))
                        };
                        let outer = if outer_set {
                            outer_w.clone()
                        } else {
                            if any_unbounded {
                                crate::check::types::Col::CUnbound
                            } else {
                                if &len(&vars) == &Nat::from(0u32) {
                                    crate::check::types::Col::CBound
                                } else {
                                    if &len(&vars) == &Nat::from(1u32) {
                                        crate::check::types::Col::CQ(or(&index(&vars, &Nat::from(0u32)), &Text::lit("u")))
                                    } else {
                                        crate::check::types::Col::CQ(outer_name.clone())
                                    }
                                }
                            }
                        };
                        let joins = match &outer {
                            crate::check::types::Col::CQ(hi) => each(&filter(&vars, &(|v_: &Text| v_ != hi)), &(|v_: &Text| (v_.clone(), hi.clone()))),
                            _ => Array::new(),
                        };
                        let cx_outer = with_unwritten(&cx_, &outer);
                        call_value(fold_job(crate::check::errors::range0(&len(&ps)), (Array::new(), st.clone()), {
                            let ps = ps.clone();
                            let res = res.clone();
                            let pcols = pcols.clone();
                            let cx_ = cx_.clone();
                            let cx_outer = cx_outer.clone();
                            Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
                                let ps = ps.clone();
                                let res = res.clone();
                                let pcols = pcols.clone();
                                let cx_ = cx_.clone();
                                let cx_outer = cx_outer.clone();
                                entered(once_job(move || {
                                    let (acc, s) = p0;
                                    let i = p1;
                                    {
                                        let p_ = or(&index(&ps, &i), &res);
                                        let (is_fn, c) = or(&index(&pcols, &i), &(false, crate::check::types::Col::CBound));
                                        let pcx = if is_fn { with_unwritten(&cx_, &c) } else { cx_outer.clone() };
                                        call_then(start_conv_type(pcx.clone(), s.clone(), p_.clone()), move |conv_type_12554: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (y, s2) = conv_type_12554;
                                            prism_rtl::Turn::Finished((push(&acc, &y), s2.clone()))
                                        })
                                    }
                                }))
                            }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
                        }), move |fold_12327: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                            let (xs, st2) = fold_12327;
                            call_then(start_conv_type(cx_outer.clone(), st2.clone(), res.clone()), move |conv_type_12624: (crate::check::types::Ty, crate::check::types::St)| {
                                let (r, st3) = conv_type_12624;
                                let added = if &outer_name == &Text::lit("") { names.clone() } else { push(&names, &outer_name) };
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyFn(outer.clone(), xs.clone(), Rc::new(r.clone())), added.clone(), joins.clone(), st3.clone()))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start ClosureSig, x`: what the function value is when passed to `@Run`.
pub fn start_closure_sig(cx_: Cx_, st: crate::check::types::St, color: crate::syntax::Color, ps: Array<crate::syntax::Type>, res: crate::syntax::Type, written: Array<Text>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)>> {
    Rc::new(ClosureSig { cx_, st, color, ps, res, written })
}

/// ```prism
/// WrittenCol: fn Color -> ((Bool, Col))
/// ```
pub fn written_col(color0: &crate::syntax::Color) -> (bool, crate::check::types::Col) {
    match color0 {
        crate::syntax::Color::Bounded => (false, crate::check::types::Col::CBound),
        crate::syntax::Color::Unbounded => (true, crate::check::types::Col::CUnbound),
        crate::syntax::Color::ColorVar(v_) => if &v_.name == &Text::lit("bounded") {
            (true, crate::check::types::Col::CBound)
        } else {
            (true, crate::check::types::Col::CQ(v_.name.clone()))
        },
    }
}

/// ```prism
/// WithUnwritten: fn Cx, Col -> Cx
/// ```
pub fn with_unwritten(cx_: &Cx_, c: &crate::check::types::Col) -> Cx_ {
    let mut this: Cx_ = cx_.clone();
    this.unwritten = c.clone();
    this
}

/// ```prism
/// WritesCol: fn Color -> Bool
/// ```
pub fn writes_col(color0: &crate::syntax::Color) -> bool {
    match color0 {
        crate::syntax::Color::Bounded => false,
        _ => true,
    }
}

/// ```prism
/// TopColor: unbounded fn Type -> Color
/// ```
pub fn top_color(t: &crate::syntax::Type) -> crate::syntax::Color {
    match &*t.kind {
        crate::syntax::TypeKind::TFn(c, _, _) => c.clone(),
        crate::syntax::TypeKind::TGroup(x) => top_color(&**x),
        _ => crate::syntax::Color::Bounded,
    }
}

/// The step machine of `TopColor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TopColor: unbounded fn Type -> Color
/// ```
pub struct TopColor {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<crate::syntax::Color> for TopColor {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::Color> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TFn(c, _, _) => prism_rtl::Turn::Finished(c.clone()),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(TopColor { t: (**x).clone() })),
            _ => prism_rtl::Turn::Finished(crate::syntax::Color::Bounded),
        }
    }
}

/// `Start TopColor, x`: what the function value is when passed to `@Run`.
pub fn start_top_color(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<crate::syntax::Color>> {
    Rc::new(TopColor { t })
}

/// ```prism
/// FreshColNames: unbounded fn [Text], Nat -> [Text]
/// ```
pub fn fresh_col_names(taken: &Array<Text>, n: &Nat) -> Array<Text> {
    let (names, _) = run_to_end(fold_job(crate::check::errors::range0(n), (Array::new(), Nat::from(1u32)), {
        let taken = taken.clone();
        let n = n.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, Nat), Nat)| {
            let taken = taken.clone();
            let n = n.clone();
            entered(once_job(move || {
                let (acc, k) = p0;
                let _ = p1;
                {
                    let k2 = next_free_col(&append(&taken, &acc), &(if &n == &Nat::from(1u32) { Nat::from(0u32) } else { k.clone() }));
                    prism_rtl::Turn::Finished((push(&acc, &sig_col_name(&k2)), &k2 + &Nat::from(1u32)))
                }
            }))
        }) as Rc<dyn Fn(((Array<Text>, Nat), Nat)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Nat)>>>
    }));
    names.clone()
}

/// The step machine of `FreshColNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreshColNames: unbounded fn [Text], Nat -> [Text]
/// ```
pub struct FreshColNames {
    pub taken: Array<Text>,
    pub n: Nat,
}

impl prism_rtl::Job<Array<Text>> for FreshColNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let taken = &self.taken;
        let n = &self.n;
        let n = n.clone();
        let taken = taken.clone();
        call_value(fold_job(crate::check::errors::range0(&n), (Array::new(), Nat::from(1u32)), {
            let taken = taken.clone();
            let n = n.clone();
            Rc::new(move |(p0, p1): ((Array<Text>, Nat), Nat)| {
                let taken = taken.clone();
                let n = n.clone();
                entered(once_job(move || {
                    let (acc, k) = p0;
                    let _ = p1;
                    {
                        let k2 = next_free_col(&append(&taken, &acc), &(if &n == &Nat::from(1u32) { Nat::from(0u32) } else { k.clone() }));
                        prism_rtl::Turn::Finished((push(&acc, &sig_col_name(&k2)), &k2 + &Nat::from(1u32)))
                    }
                }))
            }) as Rc<dyn Fn(((Array<Text>, Nat), Nat)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Nat)>>>
        }), move |fold_13692: (Array<Text>, Nat)| {
            let (names, _) = fold_13692;
            prism_rtl::Turn::Finished(names.clone())
        })
    }
}

/// `Start FreshColNames, x`: what the function value is when passed to `@Run`.
pub fn start_fresh_col_names(taken: Array<Text>, n: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(FreshColNames { taken, n })
}

/// ```prism
/// NextFreeCol: unbounded fn [Text], Nat -> Nat
/// ```
pub fn next_free_col(taken: &Array<Text>, k: &Nat) -> Nat {
    if crate::check::types::has_text(taken, &sig_col_name(k)) {
        next_free_col(taken, &(k + &Nat::from(1u32)))
    } else {
        k.clone()
    }
}

/// ```prism
/// SigColName: fn Nat -> Text
/// ```
pub fn sig_col_name(n0: &Nat) -> Text {
    match n0 {
        c0_0 if (c0_0 == &Nat::from(0u32)) => Text::lit("u"),
        k => Text::from(format!("u{}", k)),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ConvBounds: fn Cx, St, [Bound] -> (([((Text, Text))], St))
/// ```
pub fn conv_bounds(cx_: &Cx_, st: &crate::check::types::St, bounds: &Array<crate::syntax::decls::Bound>) -> (Array<(Text, Text)>, crate::check::types::St) {
    fold(bounds, &(Array::new(), st.clone()), &(|(acc, s): &(Array<(Text, Text)>, crate::check::types::St), b: &crate::syntax::decls::Bound| fold(&b.traits, &(acc.clone(), s.clone()), &(|(a2, s2): &(Array<(Text, Text)>, crate::check::types::St), tr: &crate::syntax::TraitRef| match crate::check::env::names::resolve_trait(&cx_.g, &cx_.home, &tr.path_) {
        Some(k) => (push(a2, &(b.var.name.clone(), k.clone())), s2.clone()),
        None => (a2.clone(), crate::check::types::recording::err(s2, &Text::lit("unknown-name"), &tr.span, &Text::from(format!("no trait `^{}`", &crate::check::env::dotted(&tr.path_))))),
    }))))
}

/// ```prism
/// MentionsTime: unbounded fn Type -> Bool
/// ```
pub fn mentions_time(t: &crate::syntax::Type) -> bool {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, args) => ((crate::syntax::lexer::chars::contains(&n.sigils, &Text::lit("$")) || crate::syntax::lexer::chars::contains(&n.sigils, &Text::lit("!"))) || crate::syntax::lexer::chars::contains(&n.sigils, &Text::lit("@"))) || run_to_end(fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || mentions_time(&a))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TSigiled(s, i) => ((crate::syntax::lexer::chars::contains(s, &Text::lit("$")) || crate::syntax::lexer::chars::contains(s, &Text::lit("!"))) || crate::syntax::lexer::chars::contains(s, &Text::lit("@"))) || mentions_time(&**i),
        crate::syntax::TypeKind::TUnit(s) => (crate::syntax::lexer::chars::contains(s, &Text::lit("$")) || crate::syntax::lexer::chars::contains(s, &Text::lit("!"))) || crate::syntax::lexer::chars::contains(s, &Text::lit("@")),
        crate::syntax::TypeKind::TArray(e, _) => mentions_time(&**e),
        crate::syntax::TypeKind::TTuple(ts) => run_to_end(fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || mentions_time(&a))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TGroup(x) => mentions_time(&**x),
        crate::syntax::TypeKind::TMap(k, v_) => mentions_time(&**k) || mentions_time(&**v_),
        crate::syntax::TypeKind::TFn(_, ps, res) => run_to_end(fold_job(ps.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || mentions_time(&a))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)) || mentions_time(&**res),
        crate::syntax::TypeKind::TEmit(ty, _) => true,
        _ => false,
    }
}

/// The step machine of `MentionsTime`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MentionsTime: unbounded fn Type -> Bool
/// ```
pub struct MentionsTime {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<bool> for MentionsTime {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TName(n, args) => prism_rtl::Turn::Finished(((crate::syntax::lexer::chars::contains(&n.sigils, &Text::lit("$")) || crate::syntax::lexer::chars::contains(&n.sigils, &Text::lit("!"))) || crate::syntax::lexer::chars::contains(&n.sigils, &Text::lit("@"))) || run_to_end(fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
                let seen = p0;
                let a = p1;
                prism_rtl::Turn::Finished(seen || mentions_time(&a))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>))),
            crate::syntax::TypeKind::TSigiled(s, i) => prism_rtl::Turn::Finished(((crate::syntax::lexer::chars::contains(s, &Text::lit("$")) || crate::syntax::lexer::chars::contains(s, &Text::lit("!"))) || crate::syntax::lexer::chars::contains(s, &Text::lit("@"))) || mentions_time(&**i)),
            crate::syntax::TypeKind::TUnit(s) => prism_rtl::Turn::Finished((crate::syntax::lexer::chars::contains(s, &Text::lit("$")) || crate::syntax::lexer::chars::contains(s, &Text::lit("!"))) || crate::syntax::lexer::chars::contains(s, &Text::lit("@"))),
            crate::syntax::TypeKind::TArray(e, _) => prism_rtl::Turn::More(Rc::new(MentionsTime { t: (**e).clone() })),
            crate::syntax::TypeKind::TTuple(ts) => fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
                let seen = p0;
                let a = p1;
                prism_rtl::Turn::Finished(seen || mentions_time(&a))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(MentionsTime { t: (**x).clone() })),
            crate::syntax::TypeKind::TMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_mentions_time(k.clone()), move |mentions_time_15072: bool| prism_rtl::Turn::Finished(mentions_time_15072 || mentions_time(&v_)))
            },
            crate::syntax::TypeKind::TFn(_, ps, res) => {
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(fold_job(ps.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
                    let seen = p0;
                    let a = p1;
                    prism_rtl::Turn::Finished(seen || mentions_time(&a))
                }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_15132: bool| prism_rtl::Turn::Finished(fold_15132 || mentions_time(&res)))
            },
            crate::syntax::TypeKind::TEmit(ty, _) => prism_rtl::Turn::Finished(true),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start MentionsTime, x`: what the function value is when passed to `@Run`.
pub fn start_mentions_time(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(MentionsTime { t })
}

/// ```prism
/// TakesClosure: unbounded fn Type -> Bool
/// ```
pub fn takes_closure(t: &crate::syntax::Type) -> bool {
    match &*t.kind {
        crate::syntax::TypeKind::TFn(_, ps, _) => run_to_end(fold_job(ps.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
            let seen = p0;
            let p_ = p1;
            prism_rtl::Turn::Finished(seen || is_fn_type(&p_))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        _ => false,
    }
}

/// The step machine of `TakesClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TakesClosure: unbounded fn Type -> Bool
/// ```
pub struct TakesClosure {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<bool> for TakesClosure {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TFn(_, ps, _) => fold_job(ps.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
                let seen = p0;
                let p_ = p1;
                prism_rtl::Turn::Finished(seen || is_fn_type(&p_))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start TakesClosure, x`: what the function value is when passed to `@Run`.
pub fn start_takes_closure(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(TakesClosure { t })
}

/// ```prism
/// IsFnType: unbounded fn Type -> Bool
/// ```
pub fn is_fn_type(t: &crate::syntax::Type) -> bool {
    match &*t.kind {
        crate::syntax::TypeKind::TFn(_, _, _) => true,
        crate::syntax::TypeKind::TGroup(x) => is_fn_type(&**x),
        _ => false,
    }
}

/// The step machine of `IsFnType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsFnType: unbounded fn Type -> Bool
/// ```
pub struct IsFnType {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<bool> for IsFnType {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TFn(_, _, _) => prism_rtl::Turn::Finished(true),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(IsFnType { t: (**x).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsFnType, x`: what the function value is when passed to `@Run`.
pub fn start_is_fn_type(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsFnType { t })
}

/// ```prism
/// UsesScope: unbounded fn Type -> Bool
/// ```
pub fn uses_scope(t: &crate::syntax::Type) -> bool {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, args) => ((crate::syntax::lexer::chars::contains(&n.sigils, &Text::lit("@")) || ((&crate::check::env::dotted(&n.path_) == &Text::lit("Element")) && (&len(args) < &Nat::from(2u32)))) || ((&crate::check::env::dotted(&n.path_) == &Text::lit("Elem")) && (&len(args) == &Nat::from(0u32)))) || run_to_end(fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || uses_scope(&a))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TSigiled(s, i) => crate::syntax::lexer::chars::contains(s, &Text::lit("@")) || uses_scope(&**i),
        crate::syntax::TypeKind::TUnit(s) => crate::syntax::lexer::chars::contains(s, &Text::lit("@")),
        crate::syntax::TypeKind::TArray(e, _) => uses_scope(&**e),
        crate::syntax::TypeKind::TTuple(ts) => run_to_end(fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || uses_scope(&a))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TGroup(x) => uses_scope(&**x),
        crate::syntax::TypeKind::TMap(k, v_) => uses_scope(&**k) || uses_scope(&**v_),
        crate::syntax::TypeKind::TFn(_, ps, res) => run_to_end(fold_job(ps.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || uses_scope(&a))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)) || uses_scope(&**res),
        crate::syntax::TypeKind::TEmit(ty, row_t) => uses_scope(&**row_t),
        _ => false,
    }
}

/// The step machine of `UsesScope`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UsesScope: unbounded fn Type -> Bool
/// ```
pub struct UsesScope {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<bool> for UsesScope {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TName(n, args) => prism_rtl::Turn::Finished(((crate::syntax::lexer::chars::contains(&n.sigils, &Text::lit("@")) || ((&crate::check::env::dotted(&n.path_) == &Text::lit("Element")) && (&len(args) < &Nat::from(2u32)))) || ((&crate::check::env::dotted(&n.path_) == &Text::lit("Elem")) && (&len(args) == &Nat::from(0u32)))) || run_to_end(fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
                let seen = p0;
                let a = p1;
                prism_rtl::Turn::Finished(seen || uses_scope(&a))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>))),
            crate::syntax::TypeKind::TSigiled(s, i) => prism_rtl::Turn::Finished(crate::syntax::lexer::chars::contains(s, &Text::lit("@")) || uses_scope(&**i)),
            crate::syntax::TypeKind::TUnit(s) => prism_rtl::Turn::Finished(crate::syntax::lexer::chars::contains(s, &Text::lit("@"))),
            crate::syntax::TypeKind::TArray(e, _) => prism_rtl::Turn::More(Rc::new(UsesScope { t: (**e).clone() })),
            crate::syntax::TypeKind::TTuple(ts) => fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
                let seen = p0;
                let a = p1;
                prism_rtl::Turn::Finished(seen || uses_scope(&a))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(UsesScope { t: (**x).clone() })),
            crate::syntax::TypeKind::TMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_uses_scope(k.clone()), move |uses_scope_16139: bool| prism_rtl::Turn::Finished(uses_scope_16139 || uses_scope(&v_)))
            },
            crate::syntax::TypeKind::TFn(_, ps, res) => {
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(fold_job(ps.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| entered(once_job(move || {
                    let seen = p0;
                    let a = p1;
                    prism_rtl::Turn::Finished(seen || uses_scope(&a))
                }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_16193: bool| prism_rtl::Turn::Finished(fold_16193 || uses_scope(&res)))
            },
            crate::syntax::TypeKind::TEmit(ty, row_t) => prism_rtl::Turn::More(Rc::new(UsesScope { t: (**row_t).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start UsesScope, x`: what the function value is when passed to `@Run`.
pub fn start_uses_scope(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(UsesScope { t })
}

/// ```prism
/// RowVarsOfType: unbounded fn Type -> [Text]
/// ```
pub fn row_vars_of_type(t: &crate::syntax::Type) -> Array<Text> {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, args) => {
            let name = crate::check::env::dotted(&n.path_);
            let own = if ((&name == &Text::lit("Element")) && (&len(args) == &Nat::from(2u32))) || ((&name == &Text::lit("Elem")) && (&len(args) == &Nat::from(1u32))) {
                row_names_in(&or(&index(args, &Nat::from(0u32)), &dummy_type()))
            } else {
                Array::new()
            };
            let rest = if (&name == &Text::lit("Element")) && (&len(args) == &Nat::from(2u32)) {
                drop(args, &Nat::from(1u32))
            } else {
                if &name == &Text::lit("Elem") { Array::new() } else { args.clone() }
            };
            run_to_end(fold_job(rest.clone(), own.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_row_vars_of_type(a.clone()), move |row_vars_of_type_16813: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_vars_of_type_16813)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
        },
        crate::syntax::TypeKind::TSigiled(_, i) => row_vars_of_type(&**i),
        crate::syntax::TypeKind::TArray(e, _) => row_vars_of_type(&**e),
        crate::syntax::TypeKind::TTuple(ts) => run_to_end(fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_row_vars_of_type(a.clone()), move |row_vars_of_type_16965: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_vars_of_type_16965)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TGroup(x) => row_vars_of_type(&**x),
        crate::syntax::TypeKind::TMap(k, v_) => crate::check::types::union_texts(&row_vars_of_type(&**k), &row_vars_of_type(&**v_)),
        crate::syntax::TypeKind::TFn(_, ps, res) => run_to_end(fold_job(ps.clone(), row_vars_of_type(&**res), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_row_vars_of_type(a.clone()), move |row_vars_of_type_17157: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_vars_of_type_17157)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TEmit(ty, row_t) => crate::check::types::union_texts(&row_vars_of_type(&**ty), &row_names_in(&**row_t)),
        _ => Array::new(),
    }
}

/// The step machine of `RowVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowVarsOfType: unbounded fn Type -> [Text]
/// ```
pub struct RowVarsOfType {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for RowVarsOfType {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TName(n, args) => {
                let name = crate::check::env::dotted(&n.path_);
                let own = if ((&name == &Text::lit("Element")) && (&len(args) == &Nat::from(2u32))) || ((&name == &Text::lit("Elem")) && (&len(args) == &Nat::from(1u32))) {
                    row_names_in(&or(&index(args, &Nat::from(0u32)), &dummy_type()))
                } else {
                    Array::new()
                };
                let rest = if (&name == &Text::lit("Element")) && (&len(args) == &Nat::from(2u32)) {
                    drop(args, &Nat::from(1u32))
                } else {
                    if &name == &Text::lit("Elem") { Array::new() } else { args.clone() }
                };
                fold_job(rest.clone(), own.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_row_vars_of_type(a.clone()), move |row_vars_of_type_16813: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_vars_of_type_16813)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
            },
            crate::syntax::TypeKind::TSigiled(_, i) => prism_rtl::Turn::More(Rc::new(RowVarsOfType { t: (**i).clone() })),
            crate::syntax::TypeKind::TArray(e, _) => prism_rtl::Turn::More(Rc::new(RowVarsOfType { t: (**e).clone() })),
            crate::syntax::TypeKind::TTuple(ts) => fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_row_vars_of_type(a.clone()), move |row_vars_of_type_16965: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_vars_of_type_16965)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(RowVarsOfType { t: (**x).clone() })),
            crate::syntax::TypeKind::TMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_row_vars_of_type(k.clone()), move |row_vars_of_type_17039: Array<Text>| call_then(start_row_vars_of_type(v_.clone()), move |row_vars_of_type_17058: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&row_vars_of_type_17039, &row_vars_of_type_17058))))
            },
            crate::syntax::TypeKind::TFn(_, ps, res) => {
                let ps = ps.clone();
                let res = (**res).clone();
                call_then(start_row_vars_of_type(res.clone()), move |row_vars_of_type_17110: Array<Text>| fold_job(ps.clone(), row_vars_of_type_17110, Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_row_vars_of_type(a.clone()), move |row_vars_of_type_17157: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_vars_of_type_17157)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            crate::syntax::TypeKind::TEmit(ty, row_t) => {
                let row_t = (**row_t).clone();
                let ty = (**ty).clone();
                call_then(start_row_vars_of_type(ty.clone()), move |row_vars_of_type_17206: Array<Text>| call_then(start_row_names_in(row_t.clone()), move |row_names_in_17226: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&row_vars_of_type_17206, &row_names_in_17226))))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start RowVarsOfType, x`: what the function value is when passed to `@Run`.
pub fn start_row_vars_of_type(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RowVarsOfType { t })
}

/// ```prism
/// RowNamesIn: unbounded fn Type -> [Text]
/// ```
pub fn row_names_in(t: &crate::syntax::Type) -> Array<Text> {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, m17322_0_1) if (m17322_0_1.len() == 0) => if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::is_lower_text(&crate::check::env::dotted(&n.path_)) {
            Array::from(vec![crate::check::env::dotted(&n.path_)])
        } else {
            Array::new()
        },
        crate::syntax::TypeKind::TRowUnion(ts) => run_to_end(fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_row_names_in(a.clone()), move |row_names_in_17500: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_names_in_17500)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TGroup(x) => row_names_in(&**x),
        _ => Array::new(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RowNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowNamesIn: unbounded fn Type -> [Text]
/// ```
pub struct RowNamesIn {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for RowNamesIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TName(n, m17322_0_1) if (m17322_0_1.len() == 0) => if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::is_lower_text(&crate::check::env::dotted(&n.path_)) {
                prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::dotted(&n.path_)]))
            } else {
                prism_rtl::Turn::Finished(Array::new())
            },
            crate::syntax::TypeKind::TRowUnion(ts) => fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_row_names_in(a.clone()), move |row_names_in_17500: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &row_names_in_17500)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(RowNamesIn { t: (**x).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start RowNamesIn, x`: what the function value is when passed to `@Run`.
pub fn start_row_names_in(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RowNamesIn { t })
}

/// ```prism
/// TypeVarsOfType: unbounded fn Type -> [Text]
/// ```
pub fn type_vars_of_type(t: &crate::syntax::Type) -> Array<Text> {
    type_vars_into(&Array::new(), t)
}

/// The step machine of `TypeVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeVarsOfType: unbounded fn Type -> [Text]
/// ```
pub struct TypeVarsOfType {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for TypeVarsOfType {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: Array::new(), t: t.clone() }))
    }
}

/// `Start TypeVarsOfType, x`: what the function value is when passed to `@Run`.
pub fn start_type_vars_of_type(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TypeVarsOfType { t })
}

/// ```prism
/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
/// ```
pub fn type_vars_into(acc: &Array<Text>, t: &crate::syntax::Type) -> Array<Text> {
    match &*t.kind {
        crate::syntax::TypeKind::TName(n, args) => {
            let name = crate::check::env::dotted(&n.path_);
            let here = if ((&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::is_lower_text(&name)) && (&len(args) == &Nat::from(0u32)) {
                crate::check::types::add_text(acc, &name)
            } else {
                acc.clone()
            };
            let rest = if (&name == &Text::lit("Element")) && (&len(args) == &Nat::from(2u32)) {
                drop(args, &Nat::from(1u32))
            } else {
                if &name == &Text::lit("Elem") { Array::new() } else { args.clone() }
            };
            run_to_end(fold_job(rest.clone(), here.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let a = p0;
                let x = p1;
                prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: a.clone(), t: x.clone() }))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
        },
        crate::syntax::TypeKind::TSigiled(_, i) => type_vars_into(acc, &**i),
        crate::syntax::TypeKind::TArray(e, _) => type_vars_into(acc, &**e),
        crate::syntax::TypeKind::TTuple(ts) => run_to_end(fold_job(ts.clone(), acc.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let a = p0;
            let x = p1;
            prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: a.clone(), t: x.clone() }))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TGroup(x) => type_vars_into(acc, &**x),
        crate::syntax::TypeKind::TMap(k, v_) => type_vars_into(&type_vars_into(acc, &**k), &**v_),
        crate::syntax::TypeKind::TFn(_, ps, res) => type_vars_into(&run_to_end(fold_job(ps.clone(), acc.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let a = p0;
            let x = p1;
            prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: a.clone(), t: x.clone() }))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)), &**res),
        crate::syntax::TypeKind::TEmit(ty, _) => type_vars_into(acc, &**ty),
        _ => acc.clone(),
    }
}

/// The step machine of `TypeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
/// ```
pub struct TypeVarsInto {
    pub acc: Array<Text>,
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for TypeVarsInto {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let acc = &self.acc;
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TName(n, args) => {
                let name = crate::check::env::dotted(&n.path_);
                let here = if ((&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::is_lower_text(&name)) && (&len(args) == &Nat::from(0u32)) {
                    crate::check::types::add_text(acc, &name)
                } else {
                    acc.clone()
                };
                let rest = if (&name == &Text::lit("Element")) && (&len(args) == &Nat::from(2u32)) {
                    drop(args, &Nat::from(1u32))
                } else {
                    if &name == &Text::lit("Elem") { Array::new() } else { args.clone() }
                };
                fold_job(rest.clone(), here.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: a.clone(), t: x.clone() }))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
            },
            crate::syntax::TypeKind::TSigiled(_, i) => prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: acc.clone(), t: (**i).clone() })),
            crate::syntax::TypeKind::TArray(e, _) => prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: acc.clone(), t: (**e).clone() })),
            crate::syntax::TypeKind::TTuple(ts) => fold_job(ts.clone(), acc.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let a = p0;
                let x = p1;
                prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: a.clone(), t: x.clone() }))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: acc.clone(), t: (**x).clone() })),
            crate::syntax::TypeKind::TMap(k, v_) => {
                let acc = acc.clone();
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_type_vars_into(acc.clone(), k.clone()), move |type_vars_into_18357: Array<Text>| prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: type_vars_into_18357, t: v_.clone() })))
            },
            crate::syntax::TypeKind::TFn(_, ps, res) => {
                let acc = acc.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(fold_job(ps.clone(), acc.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: a.clone(), t: x.clone() }))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_18420: Array<Text>| prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: fold_18420, t: res.clone() })))
            },
            crate::syntax::TypeKind::TEmit(ty, _) => prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc: acc.clone(), t: (**ty).clone() })),
            _ => prism_rtl::Turn::Finished(acc.clone()),
        }
    }
}

/// `Start TypeVarsInto, x`: what the function value is when passed to `@Run`.
pub fn start_type_vars_into(acc: Array<Text>, t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TypeVarsInto { acc, t })
}

/// ```prism
/// ColorVarsOfType: unbounded fn Type -> [Text]
/// ```
pub fn color_vars_of_type(t: &crate::syntax::Type) -> Array<Text> {
    match &*t.kind {
        crate::syntax::TypeKind::TFn(crate::syntax::Color::ColorVar(v_), ps, res) => {
            let inner = run_to_end(fold_job(ps.clone(), color_vars_of_type(&**res), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_18721: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_18721)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
            if &v_.name == &Text::lit("bounded") {
                inner.clone()
            } else {
                crate::check::types::add_text(&inner, &v_.name)
            }
        },
        crate::syntax::TypeKind::TFn(_, ps, res) => run_to_end(fold_job(ps.clone(), color_vars_of_type(&**res), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_18890: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_18890)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TName(_, args) => run_to_end(fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_18977: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_18977)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TSigiled(_, i) => color_vars_of_type(&**i),
        crate::syntax::TypeKind::TArray(e, _) => color_vars_of_type(&**e),
        crate::syntax::TypeKind::TTuple(ts) => run_to_end(fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_19135: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_19135)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TGroup(x) => color_vars_of_type(&**x),
        crate::syntax::TypeKind::TMap(k, v_) => crate::check::types::union_texts(&color_vars_of_type(&**k), &color_vars_of_type(&**v_)),
        crate::syntax::TypeKind::TEmit(ty, _) => color_vars_of_type(&**ty),
        _ => Array::new(),
    }
}

/// The step machine of `ColorVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ColorVarsOfType: unbounded fn Type -> [Text]
/// ```
pub struct ColorVarsOfType {
    pub t: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for ColorVarsOfType {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        match &*t.kind {
            crate::syntax::TypeKind::TFn(crate::syntax::Color::ColorVar(v_), ps, res) => {
                let ps = ps.clone();
                let res = (**res).clone();
                let v_ = v_.clone();
                call_then(start_color_vars_of_type(res.clone()), move |color_vars_of_type_18672: Array<Text>| call_value(fold_job(ps.clone(), color_vars_of_type_18672, Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_18721: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_18721)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_18662: Array<Text>| {
                    let inner = fold_18662;
                    if &v_.name == &Text::lit("bounded") {
                        prism_rtl::Turn::Finished(inner.clone())
                    } else {
                        prism_rtl::Turn::Finished(crate::check::types::add_text(&inner, &v_.name))
                    }
                }))
            },
            crate::syntax::TypeKind::TFn(_, ps, res) => {
                let ps = ps.clone();
                let res = (**res).clone();
                call_then(start_color_vars_of_type(res.clone()), move |color_vars_of_type_18841: Array<Text>| fold_job(ps.clone(), color_vars_of_type_18841, Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_18890: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_18890)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            crate::syntax::TypeKind::TName(_, args) => fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_18977: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_18977)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TSigiled(_, i) => prism_rtl::Turn::More(Rc::new(ColorVarsOfType { t: (**i).clone() })),
            crate::syntax::TypeKind::TArray(e, _) => prism_rtl::Turn::More(Rc::new(ColorVarsOfType { t: (**e).clone() })),
            crate::syntax::TypeKind::TTuple(ts) => fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_color_vars_of_type(a.clone()), move |color_vars_of_type_19135: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &color_vars_of_type_19135)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x) => prism_rtl::Turn::More(Rc::new(ColorVarsOfType { t: (**x).clone() })),
            crate::syntax::TypeKind::TMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_color_vars_of_type(k.clone()), move |color_vars_of_type_19213: Array<Text>| call_then(start_color_vars_of_type(v_.clone()), move |color_vars_of_type_19234: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&color_vars_of_type_19213, &color_vars_of_type_19234))))
            },
            crate::syntax::TypeKind::TEmit(ty, _) => prism_rtl::Turn::More(Rc::new(ColorVarsOfType { t: (**ty).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ColorVarsOfType, x`: what the function value is when passed to `@Run`.
pub fn start_color_vars_of_type(t: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ColorVarsOfType { t })
}
