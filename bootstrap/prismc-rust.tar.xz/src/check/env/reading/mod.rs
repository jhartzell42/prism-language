//! The module `Check.Env.Reading`, from `target/bootstrap/src/prismc/check/env/reading.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Cx`:
///
/// ```prism
/// type Cx = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Cx_ {
    pub g_p: crate::check::env::G,
    pub home_p: Text,
    pub scope_p: crate::check::types::Rw,
    pub row_vars_p: Array<Text>,
    pub unwritten_p: crate::check::types::Col,
}

impl Show for Cx_ {
    fn show(&self, p: &mut Printer) {
        p.record("Cx", &[("g", &self.g_p), ("home", &self.home_p), ("scope", &self.scope_p), ("rowVars", &self.row_vars_p), ("unwritten", &self.unwritten_p)]);
    }
}

impl ToPod for Cx_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Cx", vec![("g", self.g_p.to_pod()), ("home", self.home_p.to_pod()), ("scope", self.scope_p.to_pod()), ("rowVars", self.row_vars_p.to_pod()), ("unwritten", self.unwritten_p.to_pod())])
    }
}

impl FromPod for Cx_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Cx_ { g_p: FromPod::from_pod(field(p, "g")?)?, home_p: FromPod::from_pod(field(p, "home")?)?, scope_p: FromPod::from_pod(field(p, "scope")?)?, row_vars_p: FromPod::from_pod(field(p, "rowVars")?)?, unwritten_p: FromPod::from_pod(field(p, "unwritten")?)? })
    }
}

/// ```prism
/// CxOf: fn G, Text -> Cx
/// ```
pub fn cx_of_f(g_p0: &crate::check::env::G, m_p1: &Text) -> Cx_ {
    let info_p2 = crate::prelude::or(&crate::prelude::get(&g_p0.mods_p, m_p1), &crate::prelude::or(&crate::prelude::get(&g_p0.mods_p, &Text::lit("")), &dummy_mod_p()));
    Cx_ { g_p: g_p0.clone(), home_p: m_p1.clone(), scope_p: info_p2.emit_rw_p.clone(), row_vars_p: if &info_p2.row_var_p == &Text::lit("") {
        Array::new()
    } else {
        Array::from(vec![info_p2.row_var_p.clone()])
    }, unwritten_p: crate::check::types::Col::CBound }
}

/// ```prism
/// let dummyMod
/// ```
pub fn dummy_mod_p() -> crate::check::env::ModInfo {
    crate::check::env::ModInfo { name_p: Text::lit(""), file_p: Nat::from(0u32), emit_rw_p: crate::check::types::empty_row_p(), row_var_p: Text::lit(""), uses_p: Array::new(), root_p: false, tree_p: crate::check::env::empty_module_p() }
}

/// ```prism
/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
/// ```
pub fn conv_type_f(cx_p0: &Cx_, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Type) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*t_p2.kind_p {
        crate::syntax::TypeKind::TName(n_p3, args_p4) => {
            let (base_p5, st2_p6) = conv_named_f(cx_p0, st_p1, n_p3, args_p4, &t_p2.span_p);
            (crate::check::types::with_marks_f(&n_p3.sigils_p, &base_p5, &cx_p0.scope_p), st2_p6.clone())
        },
        crate::syntax::TypeKind::TSigiled(sigils_p7, inner_p8) => {
            let (i_p9, st2_pa) = conv_type_f(cx_p0, st_p1, &**inner_p8);
            (crate::check::types::with_marks_f(sigils_p7, &i_p9, &cx_p0.scope_p), st2_pa.clone())
        },
        crate::syntax::TypeKind::TArray(e_pb, _) => {
            let (i_pc, st2_pd) = conv_type_f(cx_p0, st_p1, &**e_pb);
            (crate::check::types::Ty::TyArray(Rc::new(i_pc.clone())), st2_pd.clone())
        },
        crate::syntax::TypeKind::TTuple(ts_pe) => {
            let (xs_pf, st2_pg) = conv_types_f(cx_p0, st_p1, ts_pe);
            (crate::check::types::Ty::TyTuple(xs_pf.clone()), st2_pg.clone())
        },
        crate::syntax::TypeKind::TGroup(x_ph) => conv_type_f(cx_p0, st_p1, &**x_ph),
        crate::syntax::TypeKind::TMap(k_pi, v_pj) => {
            let (kk_pk, st2_pl) = conv_type_f(cx_p0, st_p1, &**k_pi);
            let (vv_pm, st3_pn) = conv_type_f(cx_p0, &st2_pl, &**v_pj);
            (crate::check::types::Ty::TyMap(Rc::new(kk_pk.clone()), Rc::new(vv_pm.clone())), st3_pn.clone())
        },
        crate::syntax::TypeKind::TFn(color_po, ps_pp, res_pq) => {
            let (xs_ps, st2_pt) = conv_types_f(cx_p0, st_p1, ps_pp);
            let (r_pu, st3_pv) = conv_type_f(cx_p0, &st2_pt, &**res_pq);
            let c_pr = match color_po {
                crate::syntax::Color::Bounded => cx_p0.unwritten_p.clone(),
                crate::syntax::Color::Unbounded => crate::check::types::Col::CUnbound,
                crate::syntax::Color::ColorVar(v_p10) => if &v_p10.name_p == &Text::lit("bounded") {
                    crate::check::types::Col::CBound
                } else {
                    crate::check::types::Col::CQ(v_p10.name_p.clone())
                },
            };
            (crate::check::types::Ty::TyFn(c_pr.clone(), xs_ps.clone(), Rc::new(r_pu.clone())), st3_pv.clone())
        },
        crate::syntax::TypeKind::TEmit(ty_p11, row_t_p12) => {
            let (rw_p14, st2_p15) = conv_row_f(cx_p0, st_p1, &**row_t_p12);
            let inner_p13 = {
                let mut this: Cx_ = cx_p0.clone();
                this.scope_p = rw_p14.clone();
                this
            };
            conv_type_f(&inner_p13, &st2_p15, &**ty_p11)
        },
        crate::syntax::TypeKind::TUnit(sigils_p16) => (crate::check::types::with_marks_f(sigils_p16, &crate::check::types::t_unit_p(), &cx_p0.scope_p), st_p1.clone()),
        crate::syntax::TypeKind::TAny(tr_p17) => match crate::check::env::names::resolve_trait_o(&cx_p0.g_p, &cx_p0.home_p, &tr_p17.path_p) {
            Some(k_p18) => (crate::check::types::Ty::TyAny(Array::from(vec![k_p18])), st_p1.clone()),
            None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), &tr_p17.span_p, &Text::from(format!("no trait `^{}`", &crate::check::env::dotted_f(&tr_p17.path_p))))),
        },
        crate::syntax::TypeKind::TAbsent => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &t_p2.span_p, &Text::lit("this checker does not implement sparse tuples"))),
        crate::syntax::TypeKind::TNonEmpty(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &t_p2.span_p, &Text::lit("this checker does not implement non-empty arrays"))),
        crate::syntax::TypeKind::THole(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &t_p2.span_p, &Text::lit("this checker does not implement higher-kinded traits"))),
        crate::syntax::TypeKind::TFamily(q_p19) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("kind"), &t_p2.span_p, &Text::from(format!("`{}.*` is a row, not a type", &crate::check::env::dotted_f(&q_p19.path_p))))),
        crate::syntax::TypeKind::TRowUnion(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("kind"), &t_p2.span_p, &Text::lit("a row is not a type"))),
    }
}

/// The step machine of `ConvType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
/// ```
pub struct ConvType {
    pub cx_p0: Cx_,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Type,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ConvType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        match &*t_p2.kind_p {
            crate::syntax::TypeKind::TName(n_p3, args_p4) => {
                let args_p4x = args_p4.clone();
                let cx_p0x = cx_p0.clone();
                let n_p3x = n_p3.clone();
                let st_p1x = st_p1.clone();
                let t_p2x = t_p2.clone();
                crate::prelude::call_then(start_conv_named_f(cx_p0x.clone(), st_p1x.clone(), n_p3x.clone(), args_p4x.clone(), t_p2x.span_p.clone()), move |conv_named_f_1482: (crate::check::types::Ty, crate::check::types::St)| {
                    let (base_p5, st2_p6) = conv_named_f_1482;
                    prism_rtl::Turn::Finished((crate::check::types::with_marks_f(&n_p3x.sigils_p, &base_p5, &cx_p0x.scope_p), st2_p6.clone()))
                })
            },
            crate::syntax::TypeKind::TSigiled(sigils_p7, inner_p8) => {
                let cx_p0x = cx_p0.clone();
                let inner_p8x = (**inner_p8).clone();
                let sigils_p7x = sigils_p7.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st_p1x.clone(), inner_p8x.clone()), move |conv_type_f_1623: (crate::check::types::Ty, crate::check::types::St)| {
                    let (i_p9, st2_pa) = conv_type_f_1623;
                    prism_rtl::Turn::Finished((crate::check::types::with_marks_f(&sigils_p7x, &i_p9, &cx_p0x.scope_p), st2_pa.clone()))
                })
            },
            crate::syntax::TypeKind::TArray(e_pb, _) => {
                let cx_p0x = cx_p0.clone();
                let e_pbx = (**e_pb).clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st_p1x.clone(), e_pbx.clone()), move |conv_type_f_1742: (crate::check::types::Ty, crate::check::types::St)| {
                    let (i_pc, st2_pd) = conv_type_f_1742;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyArray(Rc::new(i_pc.clone())), st2_pd.clone()))
                })
            },
            crate::syntax::TypeKind::TTuple(ts_pe) => {
                let cx_p0x = cx_p0.clone();
                let st_p1x = st_p1.clone();
                let ts_pex = ts_pe.clone();
                crate::prelude::call_then(start_conv_types_f(cx_p0x.clone(), st_p1x.clone(), ts_pex.clone()), move |conv_types_f_1829: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (xs_pf, st2_pg) = conv_types_f_1829;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyTuple(xs_pf.clone()), st2_pg.clone()))
                })
            },
            crate::syntax::TypeKind::TGroup(x_ph) => prism_rtl::Turn::More(Rc::new(ConvType { cx_p0: cx_p0.clone(), st_p1: st_p1.clone(), t_p2: (**x_ph).clone() })),
            crate::syntax::TypeKind::TMap(k_pi, v_pj) => {
                let cx_p0x = cx_p0.clone();
                let k_pix = (**k_pi).clone();
                let st_p1x = st_p1.clone();
                let v_pjx = (**v_pj).clone();
                crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st_p1x.clone(), k_pix.clone()), move |conv_type_f_1952: (crate::check::types::Ty, crate::check::types::St)| {
                    let (kk_pk, st2_pl) = conv_type_f_1952;
                    crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st2_pl.clone(), v_pjx.clone()), move |conv_type_f_1997: (crate::check::types::Ty, crate::check::types::St)| {
                        let (vv_pm, st3_pn) = conv_type_f_1997;
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyMap(Rc::new(kk_pk.clone()), Rc::new(vv_pm.clone())), st3_pn.clone()))
                    })
                })
            },
            crate::syntax::TypeKind::TFn(color_po, ps_pp, res_pq) => {
                let color_pox = color_po.clone();
                let cx_p0x = cx_p0.clone();
                let ps_ppx = ps_pp.clone();
                let res_pqx = (**res_pq).clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_conv_types_f(cx_p0x.clone(), st_p1x.clone(), ps_ppx.clone()), move |conv_types_f_2099: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (xs_ps, st2_pt) = conv_types_f_2099;
                    crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st2_pt.clone(), res_pqx.clone()), move |conv_type_f_2145: (crate::check::types::Ty, crate::check::types::St)| {
                        let (r_pu, st3_pv) = conv_type_f_2145;
                        let c_pr = match &color_pox {
                            crate::syntax::Color::Bounded => cx_p0x.unwritten_p.clone(),
                            crate::syntax::Color::Unbounded => crate::check::types::Col::CUnbound,
                            crate::syntax::Color::ColorVar(v_p10) => if &v_p10.name_p == &Text::lit("bounded") {
                                crate::check::types::Col::CBound
                            } else {
                                crate::check::types::Col::CQ(v_p10.name_p.clone())
                            },
                        };
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyFn(c_pr.clone(), xs_ps.clone(), Rc::new(r_pu.clone())), st3_pv.clone()))
                    })
                })
            },
            crate::syntax::TypeKind::TEmit(ty_p11, row_t_p12) => {
                let cx_p0x = cx_p0.clone();
                let row_t_p12x = (**row_t_p12).clone();
                let st_p1x = st_p1.clone();
                let ty_p11x = (**ty_p11).clone();
                crate::prelude::call_then(start_conv_row_f(cx_p0x.clone(), st_p1x.clone(), row_t_p12x.clone()), move |conv_row_f_2412: (crate::check::types::Rw, crate::check::types::St)| {
                    let (rw_p14, st2_p15) = conv_row_f_2412;
                    let inner_p13 = {
                        let mut this: Cx_ = cx_p0x.clone();
                        this.scope_p = rw_p14.clone();
                        this
                    };
                    prism_rtl::Turn::More(Rc::new(ConvType { cx_p0: inner_p13.clone(), st_p1: st2_p15.clone(), t_p2: ty_p11x.clone() }))
                })
            },
            crate::syntax::TypeKind::TUnit(sigils_p16) => prism_rtl::Turn::Finished((crate::check::types::with_marks_f(sigils_p16, &crate::check::types::t_unit_p(), &cx_p0.scope_p), st_p1.clone())),
            crate::syntax::TypeKind::TAny(tr_p17) => match crate::check::env::names::resolve_trait_o(&cx_p0.g_p, &cx_p0.home_p, &tr_p17.path_p) {
                Some(k_p18) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyAny(Array::from(vec![k_p18.clone()])), st_p1.clone())),
                None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), &tr_p17.span_p, &Text::from(format!("no trait `^{}`", &crate::check::env::dotted_f(&tr_p17.path_p)))))),
            },
            crate::syntax::TypeKind::TAbsent => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &t_p2.span_p, &Text::lit("this checker does not implement sparse tuples")))),
            crate::syntax::TypeKind::TNonEmpty(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &t_p2.span_p, &Text::lit("this checker does not implement non-empty arrays")))),
            crate::syntax::TypeKind::THole(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &t_p2.span_p, &Text::lit("this checker does not implement higher-kinded traits")))),
            crate::syntax::TypeKind::TFamily(q_p19) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("kind"), &t_p2.span_p, &Text::from(format!("`{}.*` is a row, not a type", &crate::check::env::dotted_f(&q_p19.path_p)))))),
            crate::syntax::TypeKind::TRowUnion(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("kind"), &t_p2.span_p, &Text::lit("a row is not a type")))),
        }
    }
}

/// `Start ConvType, x`: what the function value is when passed to `@Run`.
pub fn start_conv_type_f(cx_p0: Cx_, st_p1: crate::check::types::St, t_p2: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(ConvType { cx_p0, st_p1, t_p2 })
}

/// ```prism
/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
/// ```
pub fn conv_types_f(cx_p0: &Cx_, st_p1: &crate::check::types::St, ts_p2: &Array<crate::syntax::Type>) -> (Array<crate::check::types::Ty>, crate::check::types::St) {
    crate::prelude::run_to_end(crate::prelude::fold_job(ts_p2.clone(), (Array::new(), st_p1.clone()), {
        let cx_p0x = cx_p0.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)| {
            let cx_p0xy = cx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p3, s_p4) = p0;
                let x_p5 = p1;
                crate::prelude::call_then(start_conv_type_f(cx_p0xy.clone(), s_p4.clone(), x_p5.clone()), move |conv_type_f_3422: (crate::check::types::Ty, crate::check::types::St)| {
                    let (y_p6, s2_p7) = conv_type_f_3422;
                    prism_rtl::Turn::Finished((crate::prelude::push(&acc_p3, &y_p6), s2_p7.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }))
}

/// The step machine of `ConvTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
/// ```
pub struct ConvTypes {
    pub cx_p0: Cx_,
    pub st_p1: crate::check::types::St,
    pub ts_p2: Array<crate::syntax::Type>,
}

impl prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)> for ConvTypes {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Ty>, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let ts_p2 = &self.ts_p2;
        crate::prelude::fold_job(ts_p2.clone(), (Array::new(), st_p1.clone()), {
            let cx_p0x = cx_p0.clone();
            Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)| {
                let cx_p0xy = cx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p3, s_p4) = p0;
                    let x_p5 = p1;
                    crate::prelude::call_then(start_conv_type_f(cx_p0xy.clone(), s_p4.clone(), x_p5.clone()), move |conv_type_f_3422: (crate::check::types::Ty, crate::check::types::St)| {
                        let (y_p6, s2_p7) = conv_type_f_3422;
                        prism_rtl::Turn::Finished((crate::prelude::push(&acc_p3, &y_p6), s2_p7.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start ConvTypes, x`: what the function value is when passed to `@Run`.
pub fn start_conv_types_f(cx_p0: Cx_, st_p1: crate::check::types::St, ts_p2: Array<crate::syntax::Type>) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>> {
    Rc::new(ConvTypes { cx_p0, st_p1, ts_p2 })
}

/// ```prism
/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
/// ```
pub fn conv_named_f(cx_p0: &Cx_, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, args_p3: &Array<crate::syntax::Type>, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let name_p5 = crate::check::env::dotted_f(&n_p2.path_p);
    if (&crate::prelude::len(&n_p2.path_p) == &Nat::from(1u32)) && crate::check::env::is_lower_text_f(&name_p5) {
        if &crate::prelude::len(args_p3) > &Nat::from(0u32) {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), span_p4, &Text::lit("this checker does not implement higher-kinded traits")))
        } else {
            (crate::check::types::Ty::TyQ(name_p5.clone()), st_p1.clone())
        }
    } else {
        if (&name_p5 == &Text::lit("Element")) || (&name_p5 == &Text::lit("Prelude.Element")) {
            match crate::prelude::len(args_p3) {
                m4019_0 if (&m4019_0 == &Nat::from(0u32)) => (crate::check::types::Ty::TyElem(cx_p0.scope_p.clone(), Rc::new(crate::check::types::t_unit_p())), st_p1.clone()),
                m4019_1 if (&m4019_1 == &Nat::from(1u32)) => {
                    let (o_p6, st2_p7) = conv_type_f(cx_p0, st_p1, &crate::prelude::or(&crate::prelude::index(args_p3, &Nat::from(0u32)), &dummy_type_p()));
                    (crate::check::types::Ty::TyElem(cx_p0.scope_p.clone(), Rc::new(o_p6.clone())), st2_p7.clone())
                },
                m4019_2 if (&m4019_2 == &Nat::from(2u32)) => {
                    let (rw_p8, st2_p9) = conv_row_f(cx_p0, st_p1, &crate::prelude::or(&crate::prelude::index(args_p3, &Nat::from(0u32)), &dummy_type_p()));
                    let (o_pa, st3_pb) = conv_type_f(cx_p0, &st2_p9, &crate::prelude::or(&crate::prelude::index(args_p3, &Nat::from(1u32)), &dummy_type_p()));
                    (crate::check::types::Ty::TyElem(rw_p8.clone(), Rc::new(o_pa.clone())), st3_pb.clone())
                },
                _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("kind"), span_p4, &Text::from(format!("`Element` takes a row and a type; here it has {}", &crate::check::errors::count_word_f(&crate::prelude::len(args_p3)))))),
                _ => unreachable!("no arm matched"),
            }
        } else {
            if &name_p5 == &Text::lit("Elem") {
                match crate::prelude::len(args_p3) {
                    m4588_0 if (&m4588_0 == &Nat::from(0u32)) => (crate::check::types::Ty::TyElemAny(cx_p0.scope_p.clone()), st_p1.clone()),
                    m4588_1 if (&m4588_1 == &Nat::from(1u32)) => {
                        let (rw_pc, st2_pd) = conv_row_f(cx_p0, st_p1, &crate::prelude::or(&crate::prelude::index(args_p3, &Nat::from(0u32)), &dummy_type_p()));
                        (crate::check::types::Ty::TyElemAny(rw_pc.clone()), st2_pd.clone())
                    },
                    _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("kind"), span_p4, &Text::from(format!("`Elem` takes a row; here it has {}", &crate::check::errors::count_word_f(&crate::prelude::len(args_p3)))))),
                    _ => unreachable!("no arm matched"),
                }
            } else {
                if (&name_p5 == &Text::lit("Answer")) || (&name_p5 == &Text::lit("Wired")) {
                    (crate::check::types::Ty::TyCon(name_p5.clone(), Array::new()), st_p1.clone())
                } else {
                    if &name_p5 == &Text::lit("Instant") {
                        (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), span_p4, &Text::lit("this checker does not implement `Instant`")))
                    } else {
                        if crate::check::types::has_text_f(&Array::from(vec![Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")]), &name_p5) {
                            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), span_p4, &Text::lit("this checker does not implement sized integers other than `U8`")))
                        } else {
                            if crate::check::env::is_prim_type_f(&name_p5) {
                                if &crate::prelude::len(args_p3) == &Nat::from(0u32) {
                                    (crate::check::types::Ty::TyCon(name_p5.clone(), Array::new()), st_p1.clone())
                                } else {
                                    (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("kind"), span_p4, &Text::from(format!("`{}` takes no type; here it has {}", &name_p5, &crate::check::errors::count_word_f(&crate::prelude::len(args_p3))))))
                                }
                            } else {
                                if (&name_p5 == &Text::lit("Buffer")) || (&name_p5 == &Text::lit("Table")) {
                                    {
                                        let want_pe = if &name_p5 == &Text::lit("Buffer") { Nat::from(1u32) } else { Nat::from(2u32) };
                                        let (xs_pf, st2_pg) = conv_types_f(cx_p0, st_p1, args_p3);
                                        if &crate::prelude::len(args_p3) == &want_pe {
                                            (crate::check::types::Ty::TyCon(name_p5.clone(), xs_pf.clone()), st2_pg.clone())
                                        } else {
                                            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st2_pg, &Text::lit("kind"), span_p4, &Text::from(format!("`{}` takes {} types; here it has {}", &name_p5, &crate::check::errors::count_word_f(&want_pe), &crate::check::errors::count_word_f(&crate::prelude::len(args_p3))))))
                                        }
                                    }
                                } else {
                                    {
                                        let (key_oh, why_pi) = crate::check::env::names::resolve_type_f(&cx_p0.g_p, &cx_p0.home_p, &n_p2.path_p);
                                        match &key_oh {
                                            None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), span_p4, &Text::from(format!("no type `{}`", &name_p5)))),
                                            Some(qk_pj) => {
                                                let ti_pk = crate::prelude::or(&crate::prelude::get(&cx_p0.g_p.types_p, qk_pj), &crate::check::env::names::dummy_ty_info_p());
                                                let st1_pl = if &why_pi == &Text::lit("collision") {
                                                    crate::check::types::recording::err_fix_f(st_p1, &Text::lit("collision"), span_p4, &Text::from(format!("`{}` is declared by two modules this file reaches by a bare name", &name_p5)), &Text::from(format!("write it qualified, `{}`, or rename this file\'s own", qk_pj)))
                                                } else {
                                                    st_p1.clone()
                                                };
                                                let (xs_pm, st2_pn) = conv_types_f(cx_p0, &st1_pl, args_p3);
                                                if &crate::prelude::len(&xs_pm) != &crate::prelude::len(&ti_pk.params_p) {
                                                    (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st2_pn, &Text::lit("kind"), span_p4, &Text::from(format!("`{}` takes {} type{}; here it has {}", &name_p5, &crate::check::errors::count_word_f(&crate::prelude::len(&ti_pk.params_p)), &(if &crate::prelude::len(&ti_pk.params_p) == &Nat::from(1u32) {
                                                        Text::lit("")
                                                    } else {
                                                        Text::lit("s")
                                                    }), &crate::check::errors::count_word_f(&crate::prelude::len(&xs_pm))))))
                                                } else {
                                                    match &ti_pk.body_p {
                                                        crate::check::env::TyBody::BAlias(body_po) => (crate::check::types::schemes::subst_q_f(&param_inst_f(&ti_pk.params_p, &xs_pm), body_po), st2_pn.clone()),
                                                        crate::check::env::TyBody::BRowKind => (crate::check::types::Ty::TyCon(qk_pj.clone(), xs_pm.clone()), st2_pn.clone()),
                                                        _ => (crate::check::types::Ty::TyCon(qk_pj.clone(), xs_pm.clone()), st2_pn.clone()),
                                                    }
                                                }
                                            },
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `ConvNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
/// ```
pub struct ConvNamed {
    pub cx_p0: Cx_,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub args_p3: Array<crate::syntax::Type>,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ConvNamed {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let name_p5 = crate::check::env::dotted_f(&n_p2.path_p);
        if (&crate::prelude::len(&n_p2.path_p) == &Nat::from(1u32)) && crate::check::env::is_lower_text_f(&name_p5) {
            if &crate::prelude::len(args_p3) > &Nat::from(0u32) {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), span_p4, &Text::lit("this checker does not implement higher-kinded traits"))))
            } else {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyQ(name_p5.clone()), st_p1.clone()))
            }
        } else {
            if (&name_p5 == &Text::lit("Element")) || (&name_p5 == &Text::lit("Prelude.Element")) {
                match crate::prelude::len(args_p3) {
                    m4019_0 if (&m4019_0 == &Nat::from(0u32)) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(cx_p0.scope_p.clone(), Rc::new(crate::check::types::t_unit_p())), st_p1.clone())),
                    m4019_1 if (&m4019_1 == &Nat::from(1u32)) => {
                        let args_p3x = args_p3.clone();
                        let cx_p0x = cx_p0.clone();
                        let st_p1x = st_p1.clone();
                        crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st_p1x.clone(), crate::prelude::or(&crate::prelude::index(&args_p3x, &Nat::from(0u32)), &dummy_type_p())), move |conv_type_f_4131: (crate::check::types::Ty, crate::check::types::St)| {
                            let (o_p6, st2_p7) = conv_type_f_4131;
                            prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(cx_p0x.scope_p.clone(), Rc::new(o_p6.clone())), st2_p7.clone()))
                        })
                    },
                    m4019_2 if (&m4019_2 == &Nat::from(2u32)) => {
                        let args_p3x = args_p3.clone();
                        let cx_p0x = cx_p0.clone();
                        let st_p1x = st_p1.clone();
                        crate::prelude::call_then(start_conv_row_f(cx_p0x.clone(), st_p1x.clone(), crate::prelude::or(&crate::prelude::index(&args_p3x, &Nat::from(0u32)), &dummy_type_p())), move |conv_row_f_4267: (crate::check::types::Rw, crate::check::types::St)| {
                            let (rw_p8, st2_p9) = conv_row_f_4267;
                            crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st2_p9.clone(), crate::prelude::or(&crate::prelude::index(&args_p3x, &Nat::from(1u32)), &dummy_type_p())), move |conv_type_f_4340: (crate::check::types::Ty, crate::check::types::St)| {
                                let (o_pa, st3_pb) = conv_type_f_4340;
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(rw_p8.clone(), Rc::new(o_pa.clone())), st3_pb.clone()))
                            })
                        })
                    },
                    _ => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("kind"), span_p4, &Text::from(format!("`Element` takes a row and a type; here it has {}", &crate::check::errors::count_word_f(&crate::prelude::len(args_p3))))))),
                    _ => unreachable!("no arm matched"),
                }
            } else {
                if &name_p5 == &Text::lit("Elem") {
                    match crate::prelude::len(args_p3) {
                        m4588_0 if (&m4588_0 == &Nat::from(0u32)) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyElemAny(cx_p0.scope_p.clone()), st_p1.clone())),
                        m4588_1 if (&m4588_1 == &Nat::from(1u32)) => {
                            let args_p3x = args_p3.clone();
                            let cx_p0x = cx_p0.clone();
                            let st_p1x = st_p1.clone();
                            crate::prelude::call_then(start_conv_row_f(cx_p0x.clone(), st_p1x.clone(), crate::prelude::or(&crate::prelude::index(&args_p3x, &Nat::from(0u32)), &dummy_type_p())), move |conv_row_f_4695: (crate::check::types::Rw, crate::check::types::St)| {
                                let (rw_pc, st2_pd) = conv_row_f_4695;
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyElemAny(rw_pc.clone()), st2_pd.clone()))
                            })
                        },
                        _ => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("kind"), span_p4, &Text::from(format!("`Elem` takes a row; here it has {}", &crate::check::errors::count_word_f(&crate::prelude::len(args_p3))))))),
                        _ => unreachable!("no arm matched"),
                    }
                } else {
                    if (&name_p5 == &Text::lit("Answer")) || (&name_p5 == &Text::lit("Wired")) {
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(name_p5.clone(), Array::new()), st_p1.clone()))
                    } else {
                        if &name_p5 == &Text::lit("Instant") {
                            prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), span_p4, &Text::lit("this checker does not implement `Instant`"))))
                        } else {
                            if crate::check::types::has_text_f(&Array::from(vec![Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")]), &name_p5) {
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), span_p4, &Text::lit("this checker does not implement sized integers other than `U8`"))))
                            } else {
                                if crate::check::env::is_prim_type_f(&name_p5) {
                                    if &crate::prelude::len(args_p3) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(name_p5.clone(), Array::new()), st_p1.clone()))
                                    } else {
                                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("kind"), span_p4, &Text::from(format!("`{}` takes no type; here it has {}", &name_p5, &crate::check::errors::count_word_f(&crate::prelude::len(args_p3)))))))
                                    }
                                } else {
                                    if (&name_p5 == &Text::lit("Buffer")) || (&name_p5 == &Text::lit("Table")) {
                                        {
                                            let want_pe = if &name_p5 == &Text::lit("Buffer") { Nat::from(1u32) } else { Nat::from(2u32) };
                                            let args_p3x = args_p3.clone();
                                            let cx_p0x = cx_p0.clone();
                                            let span_p4x = span_p4.clone();
                                            let st_p1x = st_p1.clone();
                                            crate::prelude::call_then(start_conv_types_f(cx_p0x.clone(), st_p1x.clone(), args_p3x.clone()), move |conv_types_f_5630: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                                                let (xs_pf, st2_pg) = conv_types_f_5630;
                                                if &crate::prelude::len(&args_p3x) == &want_pe {
                                                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(name_p5.clone(), xs_pf.clone()), st2_pg.clone()))
                                                } else {
                                                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st2_pg, &Text::lit("kind"), &span_p4x, &Text::from(format!("`{}` takes {} types; here it has {}", &name_p5, &crate::check::errors::count_word_f(&want_pe), &crate::check::errors::count_word_f(&crate::prelude::len(&args_p3x)))))))
                                                }
                                            })
                                        }
                                    } else {
                                        {
                                            let (key_oh, why_pi) = crate::check::env::names::resolve_type_f(&cx_p0.g_p, &cx_p0.home_p, &n_p2.path_p);
                                            match &key_oh {
                                                None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), span_p4, &Text::from(format!("no type `{}`", &name_p5))))),
                                                Some(qk_pj) => {
                                                    let ti_pk = crate::prelude::or(&crate::prelude::get(&cx_p0.g_p.types_p, qk_pj), &crate::check::env::names::dummy_ty_info_p());
                                                    let st1_pl = if &why_pi == &Text::lit("collision") {
                                                        crate::check::types::recording::err_fix_f(st_p1, &Text::lit("collision"), span_p4, &Text::from(format!("`{}` is declared by two modules this file reaches by a bare name", &name_p5)), &Text::from(format!("write it qualified, `{}`, or rename this file\'s own", qk_pj)))
                                                    } else {
                                                        st_p1.clone()
                                                    };
                                                    let args_p3x = args_p3.clone();
                                                    let cx_p0x = cx_p0.clone();
                                                    let qk_pjx = qk_pj.clone();
                                                    let span_p4x = span_p4.clone();
                                                    crate::prelude::call_then(start_conv_types_f(cx_p0x.clone(), st1_pl.clone(), args_p3x.clone()), move |conv_types_f_6331: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                                                        let (xs_pm, st2_pn) = conv_types_f_6331;
                                                        if &crate::prelude::len(&xs_pm) != &crate::prelude::len(&ti_pk.params_p) {
                                                            prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st2_pn, &Text::lit("kind"), &span_p4x, &Text::from(format!("`{}` takes {} type{}; here it has {}", &name_p5, &crate::check::errors::count_word_f(&crate::prelude::len(&ti_pk.params_p)), &(if &crate::prelude::len(&ti_pk.params_p) == &Nat::from(1u32) {
                                                                Text::lit("")
                                                            } else {
                                                                Text::lit("s")
                                                            }), &crate::check::errors::count_word_f(&crate::prelude::len(&xs_pm)))))))
                                                        } else {
                                                            match &ti_pk.body_p {
                                                                crate::check::env::TyBody::BAlias(body_po) => {
                                                                    let body_pox = body_po.clone();
                                                                    crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(param_inst_f(&ti_pk.params_p, &xs_pm), body_pox.clone()), move |subst_q_f_6655: crate::check::types::Ty| prism_rtl::Turn::Finished((subst_q_f_6655, st2_pn.clone())))
                                                                },
                                                                crate::check::env::TyBody::BRowKind => prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(qk_pjx.clone(), xs_pm.clone()), st2_pn.clone())),
                                                                _ => prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(qk_pjx.clone(), xs_pm.clone()), st2_pn.clone())),
                                                            }
                                                        }
                                                    })
                                                },
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// `Start ConvNamed, x`: what the function value is when passed to `@Run`.
pub fn start_conv_named_f(cx_p0: Cx_, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, args_p3: Array<crate::syntax::Type>, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(ConvNamed { cx_p0, st_p1, n_p2, args_p3, span_p4 })
}

/// ```prism
/// let dummyType
/// ```
pub fn dummy_type_p() -> crate::syntax::Type {
    crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TAbsent), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }
}

/// ```prism
/// ParamInst: fn [Text], [Ty] -> Inst
/// ```
pub fn param_inst_f(ps_p0: &Array<Text>, xs_p1: &Array<crate::check::types::Ty>) -> crate::check::types::schemes::Inst {
    crate::check::types::schemes::Inst { tys_p: crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(ps_p0)), &Map::new(), &(|m_p2: &Map<Text, crate::check::types::Ty>, i_p3: &Nat| crate::prelude::insert(m_p2, &crate::prelude::or(&crate::prelude::index(ps_p0, i_p3), &Text::lit("")), &crate::prelude::or(&crate::prelude::index(xs_p1, i_p3), &crate::check::types::Ty::TyErr)))), rows_p: Map::new(), cols_p: Map::new() }
}

/// ```prism
/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
/// ```
pub fn conv_row_f(cx_p0: &Cx_, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Type) -> (crate::check::types::Rw, crate::check::types::St) {
    let (fams_p5, vars_p6, st2_p7) = row_parts_f(cx_p0, st_p1, t_p2);
    let st3_p3 = if &crate::prelude::len(&vars_p6) > &Nat::from(1u32) {
        crate::check::types::recording::err_fix_f(&st2_p7, &Text::lit("row-two-tails"), &t_p2.span_p, &Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::chars::join_f(&vars_p6, &Text::lit(" | ")))), &Text::lit("keep one variable"))
    } else {
        st2_p7.clone()
    };
    let tail_p4 = match crate::prelude::index(&vars_p6, &Nat::from(0u32)) {
        Some(v_p8) => crate::check::types::Tail::TlQ(v_p8),
        None => crate::check::types::Tail::TlClosed,
    };
    (crate::check::types::Rw { fams_p: crate::check::types::sort_texts_f(&fams_p5), minus_p: Array::new(), tail_p: tail_p4.clone() }, st3_p3.clone())
}

/// The step machine of `ConvRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
/// ```
pub struct ConvRow {
    pub cx_p0: Cx_,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Type,
}

impl prism_rtl::Job<(crate::check::types::Rw, crate::check::types::St)> for ConvRow {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Rw, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let cx_p0x = cx_p0.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(start_row_parts_f(cx_p0x.clone(), st_p1x.clone(), t_p2x.clone()), move |row_parts_f_7214: (Array<Text>, Array<Text>, crate::check::types::St)| {
            let (fams_p5, vars_p6, st2_p7) = row_parts_f_7214;
            let st3_p3 = if &crate::prelude::len(&vars_p6) > &Nat::from(1u32) {
                crate::check::types::recording::err_fix_f(&st2_p7, &Text::lit("row-two-tails"), &t_p2x.span_p, &Text::from(format!("a row has one variable; `{}` names two", &crate::syntax::lexer::chars::join_f(&vars_p6, &Text::lit(" | ")))), &Text::lit("keep one variable"))
            } else {
                st2_p7.clone()
            };
            let tail_p4 = match crate::prelude::index(&vars_p6, &Nat::from(0u32)) {
                Some(v_p8) => crate::check::types::Tail::TlQ(v_p8),
                None => crate::check::types::Tail::TlClosed,
            };
            prism_rtl::Turn::Finished((crate::check::types::Rw { fams_p: crate::check::types::sort_texts_f(&fams_p5), minus_p: Array::new(), tail_p: tail_p4.clone() }, st3_p3.clone()))
        })
    }
}

/// `Start ConvRow, x`: what the function value is when passed to `@Run`.
pub fn start_conv_row_f(cx_p0: Cx_, st_p1: crate::check::types::St, t_p2: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(crate::check::types::Rw, crate::check::types::St)>> {
    Rc::new(ConvRow { cx_p0, st_p1, t_p2 })
}

/// ```prism
/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
/// ```
pub fn row_parts_f(cx_p0: &Cx_, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Type) -> (Array<Text>, Array<Text>, crate::check::types::St) {
    match &*t_p2.kind_p {
        crate::syntax::TypeKind::TRowUnion(ts_p3) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p3.clone(), (Array::new(), Array::new(), st_p1.clone()), {
            let cx_p0x = cx_p0.clone();
            Rc::new(move |(p0, p1): ((Array<Text>, Array<Text>, crate::check::types::St), crate::syntax::Type)| {
                let cx_p0xy = cx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (fs_p4, vs_p5, s_p6) = p0;
                    let x_p7 = p1;
                    crate::prelude::call_then(start_row_parts_f(cx_p0xy.clone(), s_p6.clone(), x_p7.clone()), move |row_parts_f_7721: (Array<Text>, Array<Text>, crate::check::types::St)| {
                        let (f2_p8, v2_p9, s2_pa) = row_parts_f_7721;
                        prism_rtl::Turn::Finished((crate::prelude::append(&fs_p4, &f2_p8), crate::prelude::append(&vs_p5, &v2_p9), s2_pa.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<Text>, Array<Text>, crate::check::types::St), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<Text>, crate::check::types::St)>>>
        })),
        crate::syntax::TypeKind::TGroup(x_pb) => row_parts_f(cx_p0, st_p1, &**x_pb),
        crate::syntax::TypeKind::TFamily(q_pc) => (Array::from(vec![crate::check::env::dotted_f(&q_pc.path_p)]), Array::new(), crate::check::env::names::check_family_f(&cx_p0.g_p, st_p1, &crate::check::env::dotted_f(&q_pc.path_p), &q_pc.span_p)),
        crate::syntax::TypeKind::TName(n_pd, m7611_3_1) if (m7611_3_1.len() == 0) => {
            let name_pe = crate::check::env::dotted_f(&n_pd.path_p);
            if (&crate::prelude::len(&n_pd.path_p) == &Nat::from(1u32)) && crate::check::env::is_lower_text_f(&name_pe) {
                (Array::new(), Array::from(vec![name_pe.clone()]), st_p1.clone())
            } else {
                if &name_pe == &Text::lit("Element") {
                    (cx_p0.scope_p.fams_p.clone(), tail_names_f(&cx_p0.scope_p.tail_p), st_p1.clone())
                } else {
                    (Array::new(), Array::new(), crate::check::types::recording::err_fix_f(st_p1, &Text::lit("row-single-tag"), &t_p2.span_p, &Text::from(format!("a row names families, not tags: `{}`", &name_pe)), &Text::from(format!("write `{}.*`", &crate::check::env::dotted_f(&crate::prelude::take(&n_pd.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&n_pd.path_p))))))))
                }
            }
        },
        _ => (Array::new(), Array::new(), crate::check::types::recording::err_f(st_p1, &Text::lit("kind"), &t_p2.span_p, &Text::lit("this is not a row"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
/// ```
pub struct RowParts {
    pub cx_p0: Cx_,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Type,
}

impl prism_rtl::Job<(Array<Text>, Array<Text>, crate::check::types::St)> for RowParts {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, Array<Text>, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        match &*t_p2.kind_p {
            crate::syntax::TypeKind::TRowUnion(ts_p3) => crate::prelude::fold_job(ts_p3.clone(), (Array::new(), Array::new(), st_p1.clone()), {
                let cx_p0x = cx_p0.clone();
                Rc::new(move |(p0, p1): ((Array<Text>, Array<Text>, crate::check::types::St), crate::syntax::Type)| {
                    let cx_p0xy = cx_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (fs_p4, vs_p5, s_p6) = p0;
                        let x_p7 = p1;
                        crate::prelude::call_then(start_row_parts_f(cx_p0xy.clone(), s_p6.clone(), x_p7.clone()), move |row_parts_f_7721: (Array<Text>, Array<Text>, crate::check::types::St)| {
                            let (f2_p8, v2_p9, s2_pa) = row_parts_f_7721;
                            prism_rtl::Turn::Finished((crate::prelude::append(&fs_p4, &f2_p8), crate::prelude::append(&vs_p5, &v2_p9), s2_pa.clone()))
                        })
                    }))
                }) as Rc<dyn Fn(((Array<Text>, Array<Text>, crate::check::types::St), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<Text>, crate::check::types::St)>>>
            }).cycle(),
            crate::syntax::TypeKind::TGroup(x_pb) => prism_rtl::Turn::More(Rc::new(RowParts { cx_p0: cx_p0.clone(), st_p1: st_p1.clone(), t_p2: (**x_pb).clone() })),
            crate::syntax::TypeKind::TFamily(q_pc) => prism_rtl::Turn::Finished((Array::from(vec![crate::check::env::dotted_f(&q_pc.path_p)]), Array::new(), crate::check::env::names::check_family_f(&cx_p0.g_p, st_p1, &crate::check::env::dotted_f(&q_pc.path_p), &q_pc.span_p))),
            crate::syntax::TypeKind::TName(n_pd, m7611_3_1) if (m7611_3_1.len() == 0) => {
                let name_pe = crate::check::env::dotted_f(&n_pd.path_p);
                if (&crate::prelude::len(&n_pd.path_p) == &Nat::from(1u32)) && crate::check::env::is_lower_text_f(&name_pe) {
                    prism_rtl::Turn::Finished((Array::new(), Array::from(vec![name_pe.clone()]), st_p1.clone()))
                } else {
                    if &name_pe == &Text::lit("Element") {
                        prism_rtl::Turn::Finished((cx_p0.scope_p.fams_p.clone(), tail_names_f(&cx_p0.scope_p.tail_p), st_p1.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Array::new(), Array::new(), crate::check::types::recording::err_fix_f(st_p1, &Text::lit("row-single-tag"), &t_p2.span_p, &Text::from(format!("a row names families, not tags: `{}`", &name_pe)), &Text::from(format!("write `{}.*`", &crate::check::env::dotted_f(&crate::prelude::take(&n_pd.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&n_pd.path_p)))))))))
                    }
                }
            },
            _ => prism_rtl::Turn::Finished((Array::new(), Array::new(), crate::check::types::recording::err_f(st_p1, &Text::lit("kind"), &t_p2.span_p, &Text::lit("this is not a row")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start RowParts, x`: what the function value is when passed to `@Run`.
pub fn start_row_parts_f(cx_p0: Cx_, st_p1: crate::check::types::St, t_p2: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<Text>, crate::check::types::St)>> {
    Rc::new(RowParts { cx_p0, st_p1, t_p2 })
}

/// ```prism
/// TailNames: fn Tail -> [Text]
/// ```
pub fn tail_names_f(tail0: &crate::check::types::Tail) -> Array<Text> {
    match tail0 {
        crate::check::types::Tail::TlQ(v_p0) => Array::from(vec![v_p0.clone()]),
        crate::check::types::Tail::TlRigid(v_p1) => Array::from(vec![v_p1.clone()]),
        _ => Array::new(),
    }
}

/// ```prism
/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
/// ```
pub fn sig_scheme_f(cx_p0: &Cx_, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Type, bounds_p3: &Array<crate::syntax::decls::Bound>) -> (crate::check::types::Scheme, crate::check::types::St) {
    let row_vars_p4 = crate::check::types::union_texts_f(&cx_p0.row_vars_p, &row_vars_of_type_f(t_p2));
    let cx2_p5 = {
        let mut this: Cx_ = cx_p0.clone();
        this.row_vars_p = row_vars_p4.clone();
        this.unwritten_p = crate::check::types::Col::CBound;
        this
    };
    let written_p6 = color_vars_of_type_f(t_p2);
    let (ty_pa, defaults_pb, joins_pc, st2_pd) = sig_type_f(&cx2_p5, st_p1, t_p2, &written_p6);
    let tvs_p7 = crate::prelude::filter(&type_vars_of_type_f(t_p2), &(|v_pe: &Text| !crate::check::types::has_text_f(&row_vars_p4, v_pe)));
    let cqs_p8 = crate::prelude::fold(&defaults_pb, &written_p6, &(|acc_pf: &Array<Text>, v_pg: &Text| crate::check::types::add_text_f(acc_pf, v_pg)));
    let (bs_ph, st3_pi) = conv_bounds_f(cx_p0, &st2_pd, bounds_p3);
    let rows_used_p9 = crate::prelude::run_to_end(crate::prelude::filter_job(row_vars_p4.clone(), {
        let t_p2x = t_p2.clone();
        Rc::new(move |p0: Text| {
            let t_p2xy = t_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let v_pj = p0;
                crate::prelude::call_then(start_row_vars_of_type_f(t_p2xy.clone()), move |row_vars_of_type_f_9242: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::has_text_f(&row_vars_of_type_f_9242, &v_pj) || uses_scope_f(&t_p2xy)))
            }))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    (crate::check::types::Scheme { qs_p: tvs_p7.clone(), plain_qs_p: Array::new(), rqs_p: rows_used_p9.clone(), cqs_p: cqs_p8.clone(), cjoins_p: joins_pc.clone(), bounds_p: bs_ph.clone(), ty_p: ty_pa.clone() }, st3_pi.clone())
}

/// The step machine of `SigScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
/// ```
pub struct SigScheme {
    pub cx_p0: Cx_,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Type,
    pub bounds_p3: Array<crate::syntax::decls::Bound>,
}

impl prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)> for SigScheme {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Scheme, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let bounds_p3 = &self.bounds_p3;
        let bounds_p3x = bounds_p3.clone();
        let cx_p0x = cx_p0.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(start_row_vars_of_type_f(t_p2x.clone()), move |row_vars_of_type_f_8803: Array<Text>| {
            let row_vars_p4 = crate::check::types::union_texts_f(&cx_p0x.row_vars_p, &row_vars_of_type_f_8803);
            let cx2_p5 = {
                let mut this: Cx_ = cx_p0x.clone();
                this.row_vars_p = row_vars_p4.clone();
                this.unwritten_p = crate::check::types::Col::CBound;
                this
            };
            crate::prelude::call_then(start_color_vars_of_type_f(t_p2x.clone()), move |color_vars_of_type_f_8924: Array<Text>| {
                let written_p6 = color_vars_of_type_f_8924;
                crate::prelude::call_then(start_sig_type_f(cx2_p5.clone(), st_p1x.clone(), t_p2x.clone(), written_p6.clone()), move |sig_type_f_8981: (crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)| {
                    let (ty_pa, defaults_pb, joins_pc, st2_pd) = sig_type_f_8981;
                    crate::prelude::call_then(start_type_vars_of_type_f(t_p2x.clone()), move |type_vars_of_type_f_9031: Array<Text>| {
                        let tvs_p7 = crate::prelude::filter(&type_vars_of_type_f_9031, &(|v_pe: &Text| !crate::check::types::has_text_f(&row_vars_p4, v_pe)));
                        let cqs_p8 = crate::prelude::fold(&defaults_pb, &written_p6, &(|acc_pf: &Array<Text>, v_pg: &Text| crate::check::types::add_text_f(acc_pf, v_pg)));
                        let (bs_ph, st3_pi) = conv_bounds_f(&cx_p0x, &st2_pd, &bounds_p3x);
                        crate::prelude::call_value(crate::prelude::filter_job(row_vars_p4.clone(), {
                            let t_p2xx = t_p2x.clone();
                            Rc::new(move |p0: Text| {
                                let t_p2xxy = t_p2xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let v_pj = p0;
                                    crate::prelude::call_then(start_row_vars_of_type_f(t_p2xxy.clone()), move |row_vars_of_type_f_9242: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::has_text_f(&row_vars_of_type_f_9242, &v_pj) || uses_scope_f(&t_p2xxy)))
                                }))
                            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |filter_9211: Array<Text>| {
                            let rows_used_p9 = filter_9211;
                            prism_rtl::Turn::Finished((crate::check::types::Scheme { qs_p: tvs_p7.clone(), plain_qs_p: Array::new(), rqs_p: rows_used_p9.clone(), cqs_p: cqs_p8.clone(), cjoins_p: joins_pc.clone(), bounds_p: bs_ph.clone(), ty_p: ty_pa.clone() }, st3_pi.clone()))
                        })
                    })
                })
            })
        })
    }
}

/// `Start SigScheme, x`: what the function value is when passed to `@Run`.
pub fn start_sig_scheme_f(cx_p0: Cx_, st_p1: crate::check::types::St, t_p2: crate::syntax::Type, bounds_p3: Array<crate::syntax::decls::Bound>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)>> {
    Rc::new(SigScheme { cx_p0, st_p1, t_p2, bounds_p3 })
}

/// ```prism
/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub fn sig_type_f(cx_p0: &Cx_, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Type, written_p3: &Array<Text>) -> (crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St) {
    match &*t_p2.kind_p {
        crate::syntax::TypeKind::TGroup(x_p4) => sig_type_f(cx_p0, st_p1, &**x_p4, written_p3),
        crate::syntax::TypeKind::TFn(color_p5, ps_p6, res_p7) => if mentions_time_f(t_p2) || !takes_closure_f(t_p2) {
            bounded_sig_f(cx_p0, st_p1, t_p2)
        } else {
            closure_sig_f(cx_p0, st_p1, color_p5, ps_p6, &**res_p7, written_p3)
        },
        _ => bounded_sig_f(cx_p0, st_p1, t_p2),
    }
}

/// The step machine of `SigType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub struct SigType {
    pub cx_p0: Cx_,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Type,
    pub written_p3: Array<Text>,
}

impl prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> for SigType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let written_p3 = &self.written_p3;
        match &*t_p2.kind_p {
            crate::syntax::TypeKind::TGroup(x_p4) => prism_rtl::Turn::More(Rc::new(SigType { cx_p0: cx_p0.clone(), st_p1: st_p1.clone(), t_p2: (**x_p4).clone(), written_p3: written_p3.clone() })),
            crate::syntax::TypeKind::TFn(color_p5, ps_p6, res_p7) => {
                let color_p5x = color_p5.clone();
                let cx_p0x = cx_p0.clone();
                let ps_p6x = ps_p6.clone();
                let res_p7x = (**res_p7).clone();
                let st_p1x = st_p1.clone();
                let t_p2x = t_p2.clone();
                let written_p3x = written_p3.clone();
                crate::prelude::call_then(start_mentions_time_f(t_p2x.clone()), move |mentions_time_f_10384: bool| if mentions_time_f_10384 || !takes_closure_f(&t_p2x) {
                    prism_rtl::Turn::More(Rc::new(BoundedSig { cx_p0: cx_p0x.clone(), st_p1: st_p1x.clone(), t_p2: t_p2x.clone() }))
                } else {
                    prism_rtl::Turn::More(Rc::new(ClosureSig { cx_p0: cx_p0x.clone(), st_p1: st_p1x.clone(), color_p2: color_p5x.clone(), ps_p3: ps_p6x.clone(), res_p4: res_p7x.clone(), written_p5: written_p3x.clone() }))
                })
            },
            _ => prism_rtl::Turn::More(Rc::new(BoundedSig { cx_p0: cx_p0.clone(), st_p1: st_p1.clone(), t_p2: t_p2.clone() })),
        }
    }
}

/// `Start SigType, x`: what the function value is when passed to `@Run`.
pub fn start_sig_type_f(cx_p0: Cx_, st_p1: crate::check::types::St, t_p2: crate::syntax::Type, written_p3: Array<Text>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)>> {
    Rc::new(SigType { cx_p0, st_p1, t_p2, written_p3 })
}

/// ```prism
/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub fn bounded_sig_f(cx_p0: &Cx_, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Type) -> (crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St) {
    let (ty_p3, st2_p4) = conv_type_f(cx_p0, st_p1, t_p2);
    (ty_p3.clone(), Array::new(), Array::new(), st2_p4.clone())
}

/// The step machine of `BoundedSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub struct BoundedSig {
    pub cx_p0: Cx_,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Type,
}

impl prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> for BoundedSig {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let cx_p0x = cx_p0.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(start_conv_type_f(cx_p0x.clone(), st_p1x.clone(), t_p2x.clone()), move |conv_type_f_10665: (crate::check::types::Ty, crate::check::types::St)| {
            let (ty_p3, st2_p4) = conv_type_f_10665;
            prism_rtl::Turn::Finished((ty_p3.clone(), Array::new(), Array::new(), st2_p4.clone()))
        })
    }
}

/// `Start BoundedSig, x`: what the function value is when passed to `@Run`.
pub fn start_bounded_sig_f(cx_p0: Cx_, st_p1: crate::check::types::St, t_p2: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)>> {
    Rc::new(BoundedSig { cx_p0, st_p1, t_p2 })
}

/// ```prism
/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub fn closure_sig_f(cx_p0: &Cx_, st_p1: &crate::check::types::St, color_p2: &crate::syntax::Color, ps_p3: &Array<crate::syntax::Type>, res_p4: &crate::syntax::Type, written_p5: &Array<Text>) -> (crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St) {
    let (outer_set_ph, outer_w_pi) = written_col_f(color_p2);
    let bounded_outer_p6 = outer_set_ph && (&outer_w_pi == &crate::check::types::Col::CBound);
    let n_default_p7 = crate::prelude::len(&crate::prelude::run_to_end(crate::prelude::filter_job(ps_p3.clone(), Rc::new(move |p0: crate::syntax::Type| crate::prelude::entered(crate::prelude::once_job(move || {
        let p_pj = p0;
        crate::prelude::call_then(start_is_fn_type_f(p_pj.clone()), move |is_fn_type_f_11003: bool| prism_rtl::Turn::Finished(is_fn_type_f_11003 && !writes_col_f(&top_color_f(&p_pj))))
    }))) as Rc<dyn Fn(crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>>>)));
    let names_p8 = fresh_col_names_f(written_p5, &(if bounded_outer_p6 { Nat::from(0u32) } else { n_default_p7.clone() }));
    let (pcols_pp, _) = crate::prelude::run_to_end(crate::prelude::fold_job(ps_p3.clone(), (Array::new(), Nat::from(0u32)), {
        let bounded_outer_p6x = bounded_outer_p6;
        let names_p8x = names_p8.clone();
        Rc::new(move |(p0, p1): ((Array<(bool, crate::check::types::Col)>, Nat), crate::syntax::Type)| {
            let bounded_outer_p6xy = bounded_outer_p6x;
            let names_p8xy = names_p8x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pk, k_pl) = p0;
                let p_pm = p1;
                crate::prelude::call_then(start_is_fn_type_f(p_pm.clone()), move |is_fn_type_f_11280: bool| if !is_fn_type_f_11280 {
                    prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(false, crate::check::types::Col::CBound)), k_pl.clone()))
                } else {
                    crate::prelude::call_then(start_top_color_f(p_pm.clone()), move |top_color_f_11385: crate::syntax::Color| {
                        let (set_pn, c_po) = written_col_f(&top_color_f_11385);
                        if set_pn {
                            prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(true, c_po.clone())), k_pl.clone()))
                        } else {
                            if bounded_outer_p6xy {
                                prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(true, crate::check::types::Col::CBound)), k_pl.clone()))
                            } else {
                                prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(true, crate::check::types::Col::CQ(crate::prelude::or(&crate::prelude::index(&names_p8xy, &k_pl), &Text::lit("u"))))), &k_pl + &Nat::from(1u32)))
                            }
                        }
                    })
                })
            }))
        }) as Rc<dyn Fn(((Array<(bool, crate::check::types::Col)>, Nat), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<(bool, crate::check::types::Col)>, Nat)>>>
    }));
    let vars_p9 = crate::prelude::fold(&pcols_pp, &Array::new(), &(|acc_pq: &Array<Text>, (_, c_pr): &(bool, crate::check::types::Col)| match c_pr {
        crate::check::types::Col::CQ(v_ps) => crate::check::types::add_text_f(acc_pq, v_ps),
        _ => acc_pq.clone(),
    }));
    let any_unbounded_pa = crate::prelude::fold(&pcols_pp, &false, &(|seen_pt: &bool, (_, c_pu): &(bool, crate::check::types::Col)| *seen_pt || (c_pu == &crate::check::types::Col::CUnbound)));
    let spare_pb = fresh_col_names_f(&crate::prelude::append(written_p5, &names_p8), &Nat::from(1u32));
    let outer_name_pc = if (outer_set_ph || any_unbounded_pa) || (&crate::prelude::len(&vars_p9) < &Nat::from(2u32)) {
        Text::lit("")
    } else {
        crate::prelude::or(&crate::prelude::index(&spare_pb, &Nat::from(0u32)), &Text::lit("u"))
    };
    let outer_pd = if outer_set_ph {
        outer_w_pi.clone()
    } else {
        if any_unbounded_pa {
            crate::check::types::Col::CUnbound
        } else {
            if &crate::prelude::len(&vars_p9) == &Nat::from(0u32) {
                crate::check::types::Col::CBound
            } else {
                if &crate::prelude::len(&vars_p9) == &Nat::from(1u32) {
                    crate::check::types::Col::CQ(crate::prelude::or(&crate::prelude::index(&vars_p9, &Nat::from(0u32)), &Text::lit("u")))
                } else {
                    crate::check::types::Col::CQ(outer_name_pc.clone())
                }
            }
        }
    };
    let joins_pe = match &outer_pd {
        crate::check::types::Col::CQ(hi_pv) => crate::prelude::each(&crate::prelude::filter(&vars_p9, &(|v_p10: &Text| v_p10 != hi_pv)), &(|v_p11: &Text| (v_p11.clone(), hi_pv.clone()))),
        _ => Array::new(),
    };
    let cx_outer_pf = with_unwritten_f(cx_p0, &outer_pd);
    let (xs_p1b, st2_p1c) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p3)), (Array::new(), st_p1.clone()), {
        let ps_p3x = ps_p3.clone();
        let res_p4x = res_p4.clone();
        let pcols_ppx = pcols_pp.clone();
        let cx_p0x = cx_p0.clone();
        let cx_outer_pfx = cx_outer_pf.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
            let ps_p3xy = ps_p3x.clone();
            let res_p4xy = res_p4x.clone();
            let pcols_ppxy = pcols_ppx.clone();
            let cx_p0xy = cx_p0x.clone();
            let cx_outer_pfxy = cx_outer_pfx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p12, s_p13) = p0;
                let i_p14 = p1;
                {
                    let p_p15 = crate::prelude::or(&crate::prelude::index(&ps_p3xy, &i_p14), &res_p4xy);
                    let (is_fn_p17, c_p18) = crate::prelude::or(&crate::prelude::index(&pcols_ppxy, &i_p14), &(false, crate::check::types::Col::CBound));
                    let pcx_p16 = if is_fn_p17 { with_unwritten_f(&cx_p0xy, &c_p18) } else { cx_outer_pfxy.clone() };
                    crate::prelude::call_then(start_conv_type_f(pcx_p16.clone(), s_p13.clone(), p_p15.clone()), move |conv_type_f_12554: (crate::check::types::Ty, crate::check::types::St)| {
                        let (y_p19, s2_p1a) = conv_type_f_12554;
                        prism_rtl::Turn::Finished((crate::prelude::push(&acc_p12, &y_p19), s2_p1a.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }));
    let (r_p1d, st3_p1e) = conv_type_f(&cx_outer_pf, &st2_p1c, res_p4);
    let added_pg = if &outer_name_pc == &Text::lit("") {
        names_p8.clone()
    } else {
        crate::prelude::push(&names_p8, &outer_name_pc)
    };
    (crate::check::types::Ty::TyFn(outer_pd.clone(), xs_p1b.clone(), Rc::new(r_p1d.clone())), added_pg.clone(), joins_pe.clone(), st3_p1e.clone())
}

/// The step machine of `ClosureSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
/// ```
pub struct ClosureSig {
    pub cx_p0: Cx_,
    pub st_p1: crate::check::types::St,
    pub color_p2: crate::syntax::Color,
    pub ps_p3: Array<crate::syntax::Type>,
    pub res_p4: crate::syntax::Type,
    pub written_p5: Array<Text>,
}

impl prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> for ClosureSig {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)> {
        let cx_p0 = &self.cx_p0;
        let st_p1 = &self.st_p1;
        let color_p2 = &self.color_p2;
        let ps_p3 = &self.ps_p3;
        let res_p4 = &self.res_p4;
        let written_p5 = &self.written_p5;
        let (outer_set_ph, outer_w_pi) = written_col_f(color_p2);
        let bounded_outer_p6 = outer_set_ph && (&outer_w_pi == &crate::check::types::Col::CBound);
        let color_p2x = color_p2.clone();
        let cx_p0x = cx_p0.clone();
        let ps_p3x = ps_p3.clone();
        let res_p4x = res_p4.clone();
        let st_p1x = st_p1.clone();
        let written_p5x = written_p5.clone();
        crate::prelude::call_value(crate::prelude::filter_job(ps_p3x.clone(), Rc::new(move |p0: crate::syntax::Type| crate::prelude::entered(crate::prelude::once_job(move || {
            let p_pj = p0;
            crate::prelude::call_then(start_is_fn_type_f(p_pj.clone()), move |is_fn_type_f_11003: bool| prism_rtl::Turn::Finished(is_fn_type_f_11003 && !writes_col_f(&top_color_f(&p_pj))))
        }))) as Rc<dyn Fn(crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>>>), move |filter_10986: Array<crate::syntax::Type>| {
            let n_default_p7 = crate::prelude::len(&filter_10986);
            crate::prelude::call_then(start_fresh_col_names_f(written_p5x.clone(), if bounded_outer_p6 { Nat::from(0u32) } else { n_default_p7.clone() }), move |fresh_col_names_f_11065: Array<Text>| {
                let names_p8 = fresh_col_names_f_11065;
                crate::prelude::call_value(crate::prelude::fold_job(ps_p3x.clone(), (Array::new(), Nat::from(0u32)), {
                    let bounded_outer_p6x = bounded_outer_p6;
                    let names_p8x = names_p8.clone();
                    Rc::new(move |(p0, p1): ((Array<(bool, crate::check::types::Col)>, Nat), crate::syntax::Type)| {
                        let bounded_outer_p6xy = bounded_outer_p6x;
                        let names_p8xy = names_p8x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (acc_pk, k_pl) = p0;
                            let p_pm = p1;
                            crate::prelude::call_then(start_is_fn_type_f(p_pm.clone()), move |is_fn_type_f_11280: bool| if !is_fn_type_f_11280 {
                                prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(false, crate::check::types::Col::CBound)), k_pl.clone()))
                            } else {
                                crate::prelude::call_then(start_top_color_f(p_pm.clone()), move |top_color_f_11385: crate::syntax::Color| {
                                    let (set_pn, c_po) = written_col_f(&top_color_f_11385);
                                    if set_pn {
                                        prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(true, c_po.clone())), k_pl.clone()))
                                    } else {
                                        if bounded_outer_p6xy {
                                            prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(true, crate::check::types::Col::CBound)), k_pl.clone()))
                                        } else {
                                            prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &(true, crate::check::types::Col::CQ(crate::prelude::or(&crate::prelude::index(&names_p8xy, &k_pl), &Text::lit("u"))))), &k_pl + &Nat::from(1u32)))
                                        }
                                    }
                                })
                            })
                        }))
                    }) as Rc<dyn Fn(((Array<(bool, crate::check::types::Col)>, Nat), crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<(Array<(bool, crate::check::types::Col)>, Nat)>>>
                }), move |fold_11225: (Array<(bool, crate::check::types::Col)>, Nat)| {
                    let (pcols_pp, _) = fold_11225;
                    let vars_p9 = crate::prelude::fold(&pcols_pp, &Array::new(), &(|acc_pq: &Array<Text>, (_, c_pr): &(bool, crate::check::types::Col)| match c_pr {
                        crate::check::types::Col::CQ(v_ps) => crate::check::types::add_text_f(acc_pq, v_ps),
                        _ => acc_pq.clone(),
                    }));
                    let any_unbounded_pa = crate::prelude::fold(&pcols_pp, &false, &(|seen_pt: &bool, (_, c_pu): &(bool, crate::check::types::Col)| *seen_pt || (c_pu == &crate::check::types::Col::CUnbound)));
                    crate::prelude::call_then(start_fresh_col_names_f(crate::prelude::append(&written_p5x, &names_p8), Nat::from(1u32)), move |fresh_col_names_f_11813: Array<Text>| {
                        let spare_pb = fresh_col_names_f_11813;
                        let outer_name_pc = if (outer_set_ph || any_unbounded_pa) || (&crate::prelude::len(&vars_p9) < &Nat::from(2u32)) {
                            Text::lit("")
                        } else {
                            crate::prelude::or(&crate::prelude::index(&spare_pb, &Nat::from(0u32)), &Text::lit("u"))
                        };
                        let outer_pd = if outer_set_ph {
                            outer_w_pi.clone()
                        } else {
                            if any_unbounded_pa {
                                crate::check::types::Col::CUnbound
                            } else {
                                if &crate::prelude::len(&vars_p9) == &Nat::from(0u32) {
                                    crate::check::types::Col::CBound
                                } else {
                                    if &crate::prelude::len(&vars_p9) == &Nat::from(1u32) {
                                        crate::check::types::Col::CQ(crate::prelude::or(&crate::prelude::index(&vars_p9, &Nat::from(0u32)), &Text::lit("u")))
                                    } else {
                                        crate::check::types::Col::CQ(outer_name_pc.clone())
                                    }
                                }
                            }
                        };
                        let joins_pe = match &outer_pd {
                            crate::check::types::Col::CQ(hi_pv) => crate::prelude::each(&crate::prelude::filter(&vars_p9, &(|v_p10: &Text| v_p10 != hi_pv)), &(|v_p11: &Text| (v_p11.clone(), hi_pv.clone()))),
                            _ => Array::new(),
                        };
                        let cx_outer_pf = with_unwritten_f(&cx_p0x, &outer_pd);
                        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_p3x)), (Array::new(), st_p1x.clone()), {
                            let ps_p3xx = ps_p3x.clone();
                            let res_p4xx = res_p4x.clone();
                            let pcols_ppx = pcols_pp.clone();
                            let cx_p0xx = cx_p0x.clone();
                            let cx_outer_pfx = cx_outer_pf.clone();
                            Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
                                let ps_p3xxy = ps_p3xx.clone();
                                let res_p4xxy = res_p4xx.clone();
                                let pcols_ppxy = pcols_ppx.clone();
                                let cx_p0xxy = cx_p0xx.clone();
                                let cx_outer_pfxy = cx_outer_pfx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (acc_p12, s_p13) = p0;
                                    let i_p14 = p1;
                                    {
                                        let p_p15 = crate::prelude::or(&crate::prelude::index(&ps_p3xxy, &i_p14), &res_p4xxy);
                                        let (is_fn_p17, c_p18) = crate::prelude::or(&crate::prelude::index(&pcols_ppxy, &i_p14), &(false, crate::check::types::Col::CBound));
                                        let pcx_p16 = if is_fn_p17 { with_unwritten_f(&cx_p0xxy, &c_p18) } else { cx_outer_pfxy.clone() };
                                        crate::prelude::call_then(start_conv_type_f(pcx_p16.clone(), s_p13.clone(), p_p15.clone()), move |conv_type_f_12554: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (y_p19, s2_p1a) = conv_type_f_12554;
                                            prism_rtl::Turn::Finished((crate::prelude::push(&acc_p12, &y_p19), s2_p1a.clone()))
                                        })
                                    }
                                }))
                            }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
                        }), move |fold_12327: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                            let (xs_p1b, st2_p1c) = fold_12327;
                            crate::prelude::call_then(start_conv_type_f(cx_outer_pf.clone(), st2_p1c.clone(), res_p4x.clone()), move |conv_type_f_12624: (crate::check::types::Ty, crate::check::types::St)| {
                                let (r_p1d, st3_p1e) = conv_type_f_12624;
                                let added_pg = if &outer_name_pc == &Text::lit("") {
                                    names_p8.clone()
                                } else {
                                    crate::prelude::push(&names_p8, &outer_name_pc)
                                };
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyFn(outer_pd.clone(), xs_p1b.clone(), Rc::new(r_p1d.clone())), added_pg.clone(), joins_pe.clone(), st3_p1e.clone()))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start ClosureSig, x`: what the function value is when passed to `@Run`.
pub fn start_closure_sig_f(cx_p0: Cx_, st_p1: crate::check::types::St, color_p2: crate::syntax::Color, ps_p3: Array<crate::syntax::Type>, res_p4: crate::syntax::Type, written_p5: Array<Text>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, Array<Text>, Array<(Text, Text)>, crate::check::types::St)>> {
    Rc::new(ClosureSig { cx_p0, st_p1, color_p2, ps_p3, res_p4, written_p5 })
}

/// ```prism
/// WrittenCol: fn Color -> ((Bool, Col))
/// ```
pub fn written_col_f(color0: &crate::syntax::Color) -> (bool, crate::check::types::Col) {
    match color0 {
        crate::syntax::Color::Bounded => (false, crate::check::types::Col::CBound),
        crate::syntax::Color::Unbounded => (true, crate::check::types::Col::CUnbound),
        crate::syntax::Color::ColorVar(v_p0) => if &v_p0.name_p == &Text::lit("bounded") {
            (true, crate::check::types::Col::CBound)
        } else {
            (true, crate::check::types::Col::CQ(v_p0.name_p.clone()))
        },
    }
}

/// ```prism
/// WithUnwritten: fn Cx, Col -> Cx
/// ```
pub fn with_unwritten_f(cx_p0: &Cx_, c_p1: &crate::check::types::Col) -> Cx_ {
    let mut this: Cx_ = cx_p0.clone();
    this.unwritten_p = c_p1.clone();
    this
}

/// ```prism
/// WritesCol: fn Color -> Bool
/// ```
pub fn writes_col_f(color0: &crate::syntax::Color) -> bool {
    match color0 {
        crate::syntax::Color::Bounded => false,
        _ => true,
    }
}

/// ```prism
/// TopColor: unbounded fn Type -> Color
/// ```
pub fn top_color_f(t_p0: &crate::syntax::Type) -> crate::syntax::Color {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TFn(c_p1, _, _) => c_p1.clone(),
        crate::syntax::TypeKind::TGroup(x_p2) => top_color_f(&**x_p2),
        _ => crate::syntax::Color::Bounded,
    }
}

/// The step machine of `TopColor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TopColor: unbounded fn Type -> Color
/// ```
pub struct TopColor {
    pub t_p0: crate::syntax::Type,
}

impl prism_rtl::Job<crate::syntax::Color> for TopColor {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::Color> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TFn(c_p1, _, _) => prism_rtl::Turn::Finished(c_p1.clone()),
            crate::syntax::TypeKind::TGroup(x_p2) => prism_rtl::Turn::More(Rc::new(TopColor { t_p0: (**x_p2).clone() })),
            _ => prism_rtl::Turn::Finished(crate::syntax::Color::Bounded),
        }
    }
}

/// `Start TopColor, x`: what the function value is when passed to `@Run`.
pub fn start_top_color_f(t_p0: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<crate::syntax::Color>> {
    Rc::new(TopColor { t_p0 })
}

/// ```prism
/// FreshColNames: unbounded fn [Text], Nat -> [Text]
/// ```
pub fn fresh_col_names_f(taken_p0: &Array<Text>, n_p1: &Nat) -> Array<Text> {
    let (names_p5, _) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(n_p1), (Array::new(), Nat::from(1u32)), {
        let taken_p0x = taken_p0.clone();
        let n_p1x = n_p1.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, Nat), Nat)| {
            let taken_p0xy = taken_p0x.clone();
            let n_p1xy = n_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p2, k_p3) = p0;
                let _ = p1;
                {
                    let k2_p4 = next_free_col_f(&crate::prelude::append(&taken_p0xy, &acc_p2), &(if &n_p1xy == &Nat::from(1u32) { Nat::from(0u32) } else { k_p3.clone() }));
                    prism_rtl::Turn::Finished((crate::prelude::push(&acc_p2, &sig_col_name_f(&k2_p4)), &k2_p4 + &Nat::from(1u32)))
                }
            }))
        }) as Rc<dyn Fn(((Array<Text>, Nat), Nat)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Nat)>>>
    }));
    names_p5.clone()
}

/// The step machine of `FreshColNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreshColNames: unbounded fn [Text], Nat -> [Text]
/// ```
pub struct FreshColNames {
    pub taken_p0: Array<Text>,
    pub n_p1: Nat,
}

impl prism_rtl::Job<Array<Text>> for FreshColNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let taken_p0 = &self.taken_p0;
        let n_p1 = &self.n_p1;
        let n_p1x = n_p1.clone();
        let taken_p0x = taken_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p1x), (Array::new(), Nat::from(1u32)), {
            let taken_p0xx = taken_p0x.clone();
            let n_p1xx = n_p1x.clone();
            Rc::new(move |(p0, p1): ((Array<Text>, Nat), Nat)| {
                let taken_p0xxy = taken_p0xx.clone();
                let n_p1xxy = n_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p2, k_p3) = p0;
                    let _ = p1;
                    {
                        let k2_p4 = next_free_col_f(&crate::prelude::append(&taken_p0xxy, &acc_p2), &(if &n_p1xxy == &Nat::from(1u32) { Nat::from(0u32) } else { k_p3.clone() }));
                        prism_rtl::Turn::Finished((crate::prelude::push(&acc_p2, &sig_col_name_f(&k2_p4)), &k2_p4 + &Nat::from(1u32)))
                    }
                }))
            }) as Rc<dyn Fn(((Array<Text>, Nat), Nat)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Nat)>>>
        }), move |fold_13692: (Array<Text>, Nat)| {
            let (names_p5, _) = fold_13692;
            prism_rtl::Turn::Finished(names_p5.clone())
        })
    }
}

/// `Start FreshColNames, x`: what the function value is when passed to `@Run`.
pub fn start_fresh_col_names_f(taken_p0: Array<Text>, n_p1: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(FreshColNames { taken_p0, n_p1 })
}

/// ```prism
/// NextFreeCol: unbounded fn [Text], Nat -> Nat
/// ```
pub fn next_free_col_f(taken_p0: &Array<Text>, k_p1: &Nat) -> Nat {
    if crate::check::types::has_text_f(taken_p0, &sig_col_name_f(k_p1)) {
        next_free_col_f(taken_p0, &(k_p1 + &Nat::from(1u32)))
    } else {
        k_p1.clone()
    }
}

/// ```prism
/// SigColName: fn Nat -> Text
/// ```
pub fn sig_col_name_f(n0: &Nat) -> Text {
    match n0 {
        c0_0 if (c0_0 == &Nat::from(0u32)) => Text::lit("u"),
        k_p0 => Text::from(format!("u{}", k_p0)),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ConvBounds: fn Cx, St, [Bound] -> (([((Text, Text))], St))
/// ```
pub fn conv_bounds_f(cx_p0: &Cx_, st_p1: &crate::check::types::St, bounds_p2: &Array<crate::syntax::decls::Bound>) -> (Array<(Text, Text)>, crate::check::types::St) {
    crate::prelude::fold(bounds_p2, &(Array::new(), st_p1.clone()), &(|(acc_p3, s_p4): &(Array<(Text, Text)>, crate::check::types::St), b_p5: &crate::syntax::decls::Bound| crate::prelude::fold(&b_p5.traits_p, &(acc_p3.clone(), s_p4.clone()), &(|(a2_p6, s2_p7): &(Array<(Text, Text)>, crate::check::types::St), tr_p8: &crate::syntax::TraitRef| match crate::check::env::names::resolve_trait_o(&cx_p0.g_p, &cx_p0.home_p, &tr_p8.path_p) {
        Some(k_p9) => (crate::prelude::push(a2_p6, &(b_p5.var_p.name_p.clone(), k_p9)), s2_p7.clone()),
        None => (a2_p6.clone(), crate::check::types::recording::err_f(s2_p7, &Text::lit("unknown-name"), &tr_p8.span_p, &Text::from(format!("no trait `^{}`", &crate::check::env::dotted_f(&tr_p8.path_p))))),
    }))))
}

/// ```prism
/// MentionsTime: unbounded fn Type -> Bool
/// ```
pub fn mentions_time_f(t_p0: &crate::syntax::Type) -> bool {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TName(n_p1, args_p2) => ((crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &Text::lit("$")) || crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &Text::lit("@"))) || crate::prelude::run_to_end(crate::prelude::fold_job(args_p2.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_p3 = p0;
            let a_p4 = p1;
            prism_rtl::Turn::Finished(seen_p3 || mentions_time_f(&a_p4))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TSigiled(s_p5, i_p6) => ((crate::syntax::lexer::chars::contains_f(s_p5, &Text::lit("$")) || crate::syntax::lexer::chars::contains_f(s_p5, &Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(s_p5, &Text::lit("@"))) || mentions_time_f(&**i_p6),
        crate::syntax::TypeKind::TUnit(s_p7) => (crate::syntax::lexer::chars::contains_f(s_p7, &Text::lit("$")) || crate::syntax::lexer::chars::contains_f(s_p7, &Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(s_p7, &Text::lit("@")),
        crate::syntax::TypeKind::TArray(e_p8, _) => mentions_time_f(&**e_p8),
        crate::syntax::TypeKind::TTuple(ts_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_pa = p0;
            let a_pb = p1;
            prism_rtl::Turn::Finished(seen_pa || mentions_time_f(&a_pb))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TGroup(x_pc) => mentions_time_f(&**x_pc),
        crate::syntax::TypeKind::TMap(k_pd, v_pe) => mentions_time_f(&**k_pd) || mentions_time_f(&**v_pe),
        crate::syntax::TypeKind::TFn(_, ps_pf, res_pg) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pf.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_ph = p0;
            let a_pi = p1;
            prism_rtl::Turn::Finished(seen_ph || mentions_time_f(&a_pi))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)) || mentions_time_f(&**res_pg),
        crate::syntax::TypeKind::TEmit(ty_pj, _) => true,
        _ => false,
    }
}

/// The step machine of `MentionsTime`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MentionsTime: unbounded fn Type -> Bool
/// ```
pub struct MentionsTime {
    pub t_p0: crate::syntax::Type,
}

impl prism_rtl::Job<bool> for MentionsTime {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TName(n_p1, args_p2) => prism_rtl::Turn::Finished(((crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &Text::lit("$")) || crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &Text::lit("@"))) || crate::prelude::run_to_end(crate::prelude::fold_job(args_p2.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_p3 = p0;
                let a_p4 = p1;
                prism_rtl::Turn::Finished(seen_p3 || mentions_time_f(&a_p4))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>))),
            crate::syntax::TypeKind::TSigiled(s_p5, i_p6) => prism_rtl::Turn::Finished(((crate::syntax::lexer::chars::contains_f(s_p5, &Text::lit("$")) || crate::syntax::lexer::chars::contains_f(s_p5, &Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(s_p5, &Text::lit("@"))) || mentions_time_f(&**i_p6)),
            crate::syntax::TypeKind::TUnit(s_p7) => prism_rtl::Turn::Finished((crate::syntax::lexer::chars::contains_f(s_p7, &Text::lit("$")) || crate::syntax::lexer::chars::contains_f(s_p7, &Text::lit("!"))) || crate::syntax::lexer::chars::contains_f(s_p7, &Text::lit("@"))),
            crate::syntax::TypeKind::TArray(e_p8, _) => prism_rtl::Turn::More(Rc::new(MentionsTime { t_p0: (**e_p8).clone() })),
            crate::syntax::TypeKind::TTuple(ts_p9) => crate::prelude::fold_job(ts_p9.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_pa = p0;
                let a_pb = p1;
                prism_rtl::Turn::Finished(seen_pa || mentions_time_f(&a_pb))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x_pc) => prism_rtl::Turn::More(Rc::new(MentionsTime { t_p0: (**x_pc).clone() })),
            crate::syntax::TypeKind::TMap(k_pd, v_pe) => {
                let k_pdx = (**k_pd).clone();
                let v_pex = (**v_pe).clone();
                crate::prelude::call_then(start_mentions_time_f(k_pdx.clone()), move |mentions_time_f_15072: bool| prism_rtl::Turn::Finished(mentions_time_f_15072 || mentions_time_f(&v_pex)))
            },
            crate::syntax::TypeKind::TFn(_, ps_pf, res_pg) => {
                let ps_pfx = ps_pf.clone();
                let res_pgx = (**res_pg).clone();
                crate::prelude::call_value(crate::prelude::fold_job(ps_pfx.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_ph = p0;
                    let a_pi = p1;
                    prism_rtl::Turn::Finished(seen_ph || mentions_time_f(&a_pi))
                }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_15132: bool| prism_rtl::Turn::Finished(fold_15132 || mentions_time_f(&res_pgx)))
            },
            crate::syntax::TypeKind::TEmit(ty_pj, _) => prism_rtl::Turn::Finished(true),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start MentionsTime, x`: what the function value is when passed to `@Run`.
pub fn start_mentions_time_f(t_p0: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(MentionsTime { t_p0 })
}

/// ```prism
/// TakesClosure: unbounded fn Type -> Bool
/// ```
pub fn takes_closure_f(t_p0: &crate::syntax::Type) -> bool {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TFn(_, ps_p1, _) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p1.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_p2 = p0;
            let p_p3 = p1;
            prism_rtl::Turn::Finished(seen_p2 || is_fn_type_f(&p_p3))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        _ => false,
    }
}

/// The step machine of `TakesClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TakesClosure: unbounded fn Type -> Bool
/// ```
pub struct TakesClosure {
    pub t_p0: crate::syntax::Type,
}

impl prism_rtl::Job<bool> for TakesClosure {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TFn(_, ps_p1, _) => crate::prelude::fold_job(ps_p1.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_p2 = p0;
                let p_p3 = p1;
                prism_rtl::Turn::Finished(seen_p2 || is_fn_type_f(&p_p3))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start TakesClosure, x`: what the function value is when passed to `@Run`.
pub fn start_takes_closure_f(t_p0: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(TakesClosure { t_p0 })
}

/// ```prism
/// IsFnType: unbounded fn Type -> Bool
/// ```
pub fn is_fn_type_f(t_p0: &crate::syntax::Type) -> bool {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TFn(_, _, _) => true,
        crate::syntax::TypeKind::TGroup(x_p1) => is_fn_type_f(&**x_p1),
        _ => false,
    }
}

/// The step machine of `IsFnType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsFnType: unbounded fn Type -> Bool
/// ```
pub struct IsFnType {
    pub t_p0: crate::syntax::Type,
}

impl prism_rtl::Job<bool> for IsFnType {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TFn(_, _, _) => prism_rtl::Turn::Finished(true),
            crate::syntax::TypeKind::TGroup(x_p1) => prism_rtl::Turn::More(Rc::new(IsFnType { t_p0: (**x_p1).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsFnType, x`: what the function value is when passed to `@Run`.
pub fn start_is_fn_type_f(t_p0: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsFnType { t_p0 })
}

/// ```prism
/// UsesScope: unbounded fn Type -> Bool
/// ```
pub fn uses_scope_f(t_p0: &crate::syntax::Type) -> bool {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TName(n_p1, args_p2) => ((crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &Text::lit("@")) || ((&crate::check::env::dotted_f(&n_p1.path_p) == &Text::lit("Element")) && (&crate::prelude::len(args_p2) < &Nat::from(2u32)))) || ((&crate::check::env::dotted_f(&n_p1.path_p) == &Text::lit("Elem")) && (&crate::prelude::len(args_p2) == &Nat::from(0u32)))) || crate::prelude::run_to_end(crate::prelude::fold_job(args_p2.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_p3 = p0;
            let a_p4 = p1;
            prism_rtl::Turn::Finished(seen_p3 || uses_scope_f(&a_p4))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TSigiled(s_p5, i_p6) => crate::syntax::lexer::chars::contains_f(s_p5, &Text::lit("@")) || uses_scope_f(&**i_p6),
        crate::syntax::TypeKind::TUnit(s_p7) => crate::syntax::lexer::chars::contains_f(s_p7, &Text::lit("@")),
        crate::syntax::TypeKind::TArray(e_p8, _) => uses_scope_f(&**e_p8),
        crate::syntax::TypeKind::TTuple(ts_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_pa = p0;
            let a_pb = p1;
            prism_rtl::Turn::Finished(seen_pa || uses_scope_f(&a_pb))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::syntax::TypeKind::TGroup(x_pc) => uses_scope_f(&**x_pc),
        crate::syntax::TypeKind::TMap(k_pd, v_pe) => uses_scope_f(&**k_pd) || uses_scope_f(&**v_pe),
        crate::syntax::TypeKind::TFn(_, ps_pf, res_pg) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pf.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_ph = p0;
            let a_pi = p1;
            prism_rtl::Turn::Finished(seen_ph || uses_scope_f(&a_pi))
        }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>)) || uses_scope_f(&**res_pg),
        crate::syntax::TypeKind::TEmit(ty_pj, row_t_pk) => uses_scope_f(&**row_t_pk),
        _ => false,
    }
}

/// The step machine of `UsesScope`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UsesScope: unbounded fn Type -> Bool
/// ```
pub struct UsesScope {
    pub t_p0: crate::syntax::Type,
}

impl prism_rtl::Job<bool> for UsesScope {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TName(n_p1, args_p2) => prism_rtl::Turn::Finished(((crate::syntax::lexer::chars::contains_f(&n_p1.sigils_p, &Text::lit("@")) || ((&crate::check::env::dotted_f(&n_p1.path_p) == &Text::lit("Element")) && (&crate::prelude::len(args_p2) < &Nat::from(2u32)))) || ((&crate::check::env::dotted_f(&n_p1.path_p) == &Text::lit("Elem")) && (&crate::prelude::len(args_p2) == &Nat::from(0u32)))) || crate::prelude::run_to_end(crate::prelude::fold_job(args_p2.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_p3 = p0;
                let a_p4 = p1;
                prism_rtl::Turn::Finished(seen_p3 || uses_scope_f(&a_p4))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>))),
            crate::syntax::TypeKind::TSigiled(s_p5, i_p6) => prism_rtl::Turn::Finished(crate::syntax::lexer::chars::contains_f(s_p5, &Text::lit("@")) || uses_scope_f(&**i_p6)),
            crate::syntax::TypeKind::TUnit(s_p7) => prism_rtl::Turn::Finished(crate::syntax::lexer::chars::contains_f(s_p7, &Text::lit("@"))),
            crate::syntax::TypeKind::TArray(e_p8, _) => prism_rtl::Turn::More(Rc::new(UsesScope { t_p0: (**e_p8).clone() })),
            crate::syntax::TypeKind::TTuple(ts_p9) => crate::prelude::fold_job(ts_p9.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_pa = p0;
                let a_pb = p1;
                prism_rtl::Turn::Finished(seen_pa || uses_scope_f(&a_pb))
            }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x_pc) => prism_rtl::Turn::More(Rc::new(UsesScope { t_p0: (**x_pc).clone() })),
            crate::syntax::TypeKind::TMap(k_pd, v_pe) => {
                let k_pdx = (**k_pd).clone();
                let v_pex = (**v_pe).clone();
                crate::prelude::call_then(start_uses_scope_f(k_pdx.clone()), move |uses_scope_f_16139: bool| prism_rtl::Turn::Finished(uses_scope_f_16139 || uses_scope_f(&v_pex)))
            },
            crate::syntax::TypeKind::TFn(_, ps_pf, res_pg) => {
                let ps_pfx = ps_pf.clone();
                let res_pgx = (**res_pg).clone();
                crate::prelude::call_value(crate::prelude::fold_job(ps_pfx.clone(), false, Rc::new(move |(p0, p1): (bool, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_ph = p0;
                    let a_pi = p1;
                    prism_rtl::Turn::Finished(seen_ph || uses_scope_f(&a_pi))
                }))) as Rc<dyn Fn((bool, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_16193: bool| prism_rtl::Turn::Finished(fold_16193 || uses_scope_f(&res_pgx)))
            },
            crate::syntax::TypeKind::TEmit(ty_pj, row_t_pk) => prism_rtl::Turn::More(Rc::new(UsesScope { t_p0: (**row_t_pk).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start UsesScope, x`: what the function value is when passed to `@Run`.
pub fn start_uses_scope_f(t_p0: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(UsesScope { t_p0 })
}

/// ```prism
/// RowVarsOfType: unbounded fn Type -> [Text]
/// ```
pub fn row_vars_of_type_f(t_p0: &crate::syntax::Type) -> Array<Text> {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TName(n_p1, args_p2) => {
            let name_p3 = crate::check::env::dotted_f(&n_p1.path_p);
            let own_p4 = if ((&name_p3 == &Text::lit("Element")) && (&crate::prelude::len(args_p2) == &Nat::from(2u32))) || ((&name_p3 == &Text::lit("Elem")) && (&crate::prelude::len(args_p2) == &Nat::from(1u32))) {
                row_names_in_f(&crate::prelude::or(&crate::prelude::index(args_p2, &Nat::from(0u32)), &dummy_type_p()))
            } else {
                Array::new()
            };
            let rest_p5 = if (&name_p3 == &Text::lit("Element")) && (&crate::prelude::len(args_p2) == &Nat::from(2u32)) {
                crate::prelude::drop(args_p2, &Nat::from(1u32))
            } else {
                if &name_p3 == &Text::lit("Elem") { Array::new() } else { args_p2.clone() }
            };
            crate::prelude::run_to_end(crate::prelude::fold_job(rest_p5.clone(), own_p4.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let a_p7 = p1;
                crate::prelude::call_then(start_row_vars_of_type_f(a_p7.clone()), move |row_vars_of_type_f_16813: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p6, &row_vars_of_type_f_16813)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
        },
        crate::syntax::TypeKind::TSigiled(_, i_p8) => row_vars_of_type_f(&**i_p8),
        crate::syntax::TypeKind::TArray(e_p9, _) => row_vars_of_type_f(&**e_p9),
        crate::syntax::TypeKind::TTuple(ts_pa) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_pa.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pb = p0;
            let a_pc = p1;
            crate::prelude::call_then(start_row_vars_of_type_f(a_pc.clone()), move |row_vars_of_type_f_16965: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pb, &row_vars_of_type_f_16965)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TGroup(x_pd) => row_vars_of_type_f(&**x_pd),
        crate::syntax::TypeKind::TMap(k_pe, v_pf) => crate::check::types::union_texts_f(&row_vars_of_type_f(&**k_pe), &row_vars_of_type_f(&**v_pf)),
        crate::syntax::TypeKind::TFn(_, ps_pg, res_ph) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pg.clone(), row_vars_of_type_f(&**res_ph), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pi = p0;
            let a_pj = p1;
            crate::prelude::call_then(start_row_vars_of_type_f(a_pj.clone()), move |row_vars_of_type_f_17157: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pi, &row_vars_of_type_f_17157)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TEmit(ty_pk, row_t_pl) => crate::check::types::union_texts_f(&row_vars_of_type_f(&**ty_pk), &row_names_in_f(&**row_t_pl)),
        _ => Array::new(),
    }
}

/// The step machine of `RowVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowVarsOfType: unbounded fn Type -> [Text]
/// ```
pub struct RowVarsOfType {
    pub t_p0: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for RowVarsOfType {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TName(n_p1, args_p2) => {
                let name_p3 = crate::check::env::dotted_f(&n_p1.path_p);
                let own_p4 = if ((&name_p3 == &Text::lit("Element")) && (&crate::prelude::len(args_p2) == &Nat::from(2u32))) || ((&name_p3 == &Text::lit("Elem")) && (&crate::prelude::len(args_p2) == &Nat::from(1u32))) {
                    row_names_in_f(&crate::prelude::or(&crate::prelude::index(args_p2, &Nat::from(0u32)), &dummy_type_p()))
                } else {
                    Array::new()
                };
                let rest_p5 = if (&name_p3 == &Text::lit("Element")) && (&crate::prelude::len(args_p2) == &Nat::from(2u32)) {
                    crate::prelude::drop(args_p2, &Nat::from(1u32))
                } else {
                    if &name_p3 == &Text::lit("Elem") { Array::new() } else { args_p2.clone() }
                };
                crate::prelude::fold_job(rest_p5.clone(), own_p4.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p6 = p0;
                    let a_p7 = p1;
                    crate::prelude::call_then(start_row_vars_of_type_f(a_p7.clone()), move |row_vars_of_type_f_16813: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p6, &row_vars_of_type_f_16813)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
            },
            crate::syntax::TypeKind::TSigiled(_, i_p8) => prism_rtl::Turn::More(Rc::new(RowVarsOfType { t_p0: (**i_p8).clone() })),
            crate::syntax::TypeKind::TArray(e_p9, _) => prism_rtl::Turn::More(Rc::new(RowVarsOfType { t_p0: (**e_p9).clone() })),
            crate::syntax::TypeKind::TTuple(ts_pa) => crate::prelude::fold_job(ts_pa.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pb = p0;
                let a_pc = p1;
                crate::prelude::call_then(start_row_vars_of_type_f(a_pc.clone()), move |row_vars_of_type_f_16965: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pb, &row_vars_of_type_f_16965)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x_pd) => prism_rtl::Turn::More(Rc::new(RowVarsOfType { t_p0: (**x_pd).clone() })),
            crate::syntax::TypeKind::TMap(k_pe, v_pf) => {
                let k_pex = (**k_pe).clone();
                let v_pfx = (**v_pf).clone();
                crate::prelude::call_then(start_row_vars_of_type_f(k_pex.clone()), move |row_vars_of_type_f_17039: Array<Text>| crate::prelude::call_then(start_row_vars_of_type_f(v_pfx.clone()), move |row_vars_of_type_f_17058: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&row_vars_of_type_f_17039, &row_vars_of_type_f_17058))))
            },
            crate::syntax::TypeKind::TFn(_, ps_pg, res_ph) => {
                let ps_pgx = ps_pg.clone();
                let res_phx = (**res_ph).clone();
                crate::prelude::call_then(start_row_vars_of_type_f(res_phx.clone()), move |row_vars_of_type_f_17110: Array<Text>| crate::prelude::fold_job(ps_pgx.clone(), row_vars_of_type_f_17110, Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pi = p0;
                    let a_pj = p1;
                    crate::prelude::call_then(start_row_vars_of_type_f(a_pj.clone()), move |row_vars_of_type_f_17157: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pi, &row_vars_of_type_f_17157)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            crate::syntax::TypeKind::TEmit(ty_pk, row_t_pl) => {
                let row_t_plx = (**row_t_pl).clone();
                let ty_pkx = (**ty_pk).clone();
                crate::prelude::call_then(start_row_vars_of_type_f(ty_pkx.clone()), move |row_vars_of_type_f_17206: Array<Text>| crate::prelude::call_then(start_row_names_in_f(row_t_plx.clone()), move |row_names_in_f_17226: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&row_vars_of_type_f_17206, &row_names_in_f_17226))))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start RowVarsOfType, x`: what the function value is when passed to `@Run`.
pub fn start_row_vars_of_type_f(t_p0: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RowVarsOfType { t_p0 })
}

/// ```prism
/// RowNamesIn: unbounded fn Type -> [Text]
/// ```
pub fn row_names_in_f(t_p0: &crate::syntax::Type) -> Array<Text> {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TName(n_p1, m17322_0_1) if (m17322_0_1.len() == 0) => if (&crate::prelude::len(&n_p1.path_p) == &Nat::from(1u32)) && crate::check::env::is_lower_text_f(&crate::check::env::dotted_f(&n_p1.path_p)) {
            Array::from(vec![crate::check::env::dotted_f(&n_p1.path_p)])
        } else {
            Array::new()
        },
        crate::syntax::TypeKind::TRowUnion(ts_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let a_p4 = p1;
            crate::prelude::call_then(start_row_names_in_f(a_p4.clone()), move |row_names_in_f_17500: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &row_names_in_f_17500)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TGroup(x_p5) => row_names_in_f(&**x_p5),
        _ => Array::new(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RowNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowNamesIn: unbounded fn Type -> [Text]
/// ```
pub struct RowNamesIn {
    pub t_p0: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for RowNamesIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TName(n_p1, m17322_0_1) if (m17322_0_1.len() == 0) => if (&crate::prelude::len(&n_p1.path_p) == &Nat::from(1u32)) && crate::check::env::is_lower_text_f(&crate::check::env::dotted_f(&n_p1.path_p)) {
                prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::dotted_f(&n_p1.path_p)]))
            } else {
                prism_rtl::Turn::Finished(Array::new())
            },
            crate::syntax::TypeKind::TRowUnion(ts_p2) => crate::prelude::fold_job(ts_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let a_p4 = p1;
                crate::prelude::call_then(start_row_names_in_f(a_p4.clone()), move |row_names_in_f_17500: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &row_names_in_f_17500)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x_p5) => prism_rtl::Turn::More(Rc::new(RowNamesIn { t_p0: (**x_p5).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start RowNamesIn, x`: what the function value is when passed to `@Run`.
pub fn start_row_names_in_f(t_p0: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RowNamesIn { t_p0 })
}

/// ```prism
/// TypeVarsOfType: unbounded fn Type -> [Text]
/// ```
pub fn type_vars_of_type_f(t_p0: &crate::syntax::Type) -> Array<Text> {
    type_vars_into_f(&Array::new(), t_p0)
}

/// The step machine of `TypeVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeVarsOfType: unbounded fn Type -> [Text]
/// ```
pub struct TypeVarsOfType {
    pub t_p0: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for TypeVarsOfType {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t_p0 = &self.t_p0;
        prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc_p0: Array::new(), t_p1: t_p0.clone() }))
    }
}

/// `Start TypeVarsOfType, x`: what the function value is when passed to `@Run`.
pub fn start_type_vars_of_type_f(t_p0: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TypeVarsOfType { t_p0 })
}

/// ```prism
/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
/// ```
pub fn type_vars_into_f(acc_p0: &Array<Text>, t_p1: &crate::syntax::Type) -> Array<Text> {
    match &*t_p1.kind_p {
        crate::syntax::TypeKind::TName(n_p2, args_p3) => {
            let name_p4 = crate::check::env::dotted_f(&n_p2.path_p);
            let here_p5 = if ((&crate::prelude::len(&n_p2.path_p) == &Nat::from(1u32)) && crate::check::env::is_lower_text_f(&name_p4)) && (&crate::prelude::len(args_p3) == &Nat::from(0u32)) {
                crate::check::types::add_text_f(acc_p0, &name_p4)
            } else {
                acc_p0.clone()
            };
            let rest_p6 = if (&name_p4 == &Text::lit("Element")) && (&crate::prelude::len(args_p3) == &Nat::from(2u32)) {
                crate::prelude::drop(args_p3, &Nat::from(1u32))
            } else {
                if &name_p4 == &Text::lit("Elem") { Array::new() } else { args_p3.clone() }
            };
            crate::prelude::run_to_end(crate::prelude::fold_job(rest_p6.clone(), here_p5.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let a_p7 = p0;
                let x_p8 = p1;
                prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc_p0: a_p7.clone(), t_p1: x_p8.clone() }))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
        },
        crate::syntax::TypeKind::TSigiled(_, i_p9) => type_vars_into_f(acc_p0, &**i_p9),
        crate::syntax::TypeKind::TArray(e_pa, _) => type_vars_into_f(acc_p0, &**e_pa),
        crate::syntax::TypeKind::TTuple(ts_pb) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_pb.clone(), acc_p0.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_pc = p0;
            let x_pd = p1;
            prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc_p0: a_pc.clone(), t_p1: x_pd.clone() }))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TGroup(x_pe) => type_vars_into_f(acc_p0, &**x_pe),
        crate::syntax::TypeKind::TMap(k_pf, v_pg) => type_vars_into_f(&type_vars_into_f(acc_p0, &**k_pf), &**v_pg),
        crate::syntax::TypeKind::TFn(_, ps_ph, res_pi) => type_vars_into_f(&crate::prelude::run_to_end(crate::prelude::fold_job(ps_ph.clone(), acc_p0.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_pj = p0;
            let x_pk = p1;
            prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc_p0: a_pj.clone(), t_p1: x_pk.clone() }))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)), &**res_pi),
        crate::syntax::TypeKind::TEmit(ty_pl, _) => type_vars_into_f(acc_p0, &**ty_pl),
        _ => acc_p0.clone(),
    }
}

/// The step machine of `TypeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
/// ```
pub struct TypeVarsInto {
    pub acc_p0: Array<Text>,
    pub t_p1: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for TypeVarsInto {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let acc_p0 = &self.acc_p0;
        let t_p1 = &self.t_p1;
        match &*t_p1.kind_p {
            crate::syntax::TypeKind::TName(n_p2, args_p3) => {
                let name_p4 = crate::check::env::dotted_f(&n_p2.path_p);
                let here_p5 = if ((&crate::prelude::len(&n_p2.path_p) == &Nat::from(1u32)) && crate::check::env::is_lower_text_f(&name_p4)) && (&crate::prelude::len(args_p3) == &Nat::from(0u32)) {
                    crate::check::types::add_text_f(acc_p0, &name_p4)
                } else {
                    acc_p0.clone()
                };
                let rest_p6 = if (&name_p4 == &Text::lit("Element")) && (&crate::prelude::len(args_p3) == &Nat::from(2u32)) {
                    crate::prelude::drop(args_p3, &Nat::from(1u32))
                } else {
                    if &name_p4 == &Text::lit("Elem") { Array::new() } else { args_p3.clone() }
                };
                crate::prelude::fold_job(rest_p6.clone(), here_p5.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p7 = p0;
                    let x_p8 = p1;
                    prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc_p0: a_p7.clone(), t_p1: x_p8.clone() }))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
            },
            crate::syntax::TypeKind::TSigiled(_, i_p9) => prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc_p0: acc_p0.clone(), t_p1: (**i_p9).clone() })),
            crate::syntax::TypeKind::TArray(e_pa, _) => prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc_p0: acc_p0.clone(), t_p1: (**e_pa).clone() })),
            crate::syntax::TypeKind::TTuple(ts_pb) => crate::prelude::fold_job(ts_pb.clone(), acc_p0.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let a_pc = p0;
                let x_pd = p1;
                prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc_p0: a_pc.clone(), t_p1: x_pd.clone() }))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x_pe) => prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc_p0: acc_p0.clone(), t_p1: (**x_pe).clone() })),
            crate::syntax::TypeKind::TMap(k_pf, v_pg) => {
                let acc_p0x = acc_p0.clone();
                let k_pfx = (**k_pf).clone();
                let v_pgx = (**v_pg).clone();
                crate::prelude::call_then(start_type_vars_into_f(acc_p0x.clone(), k_pfx.clone()), move |type_vars_into_f_18357: Array<Text>| prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc_p0: type_vars_into_f_18357, t_p1: v_pgx.clone() })))
            },
            crate::syntax::TypeKind::TFn(_, ps_ph, res_pi) => {
                let acc_p0x = acc_p0.clone();
                let ps_phx = ps_ph.clone();
                let res_pix = (**res_pi).clone();
                crate::prelude::call_value(crate::prelude::fold_job(ps_phx.clone(), acc_p0x.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pj = p0;
                    let x_pk = p1;
                    prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc_p0: a_pj.clone(), t_p1: x_pk.clone() }))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_18420: Array<Text>| prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc_p0: fold_18420, t_p1: res_pix.clone() })))
            },
            crate::syntax::TypeKind::TEmit(ty_pl, _) => prism_rtl::Turn::More(Rc::new(TypeVarsInto { acc_p0: acc_p0.clone(), t_p1: (**ty_pl).clone() })),
            _ => prism_rtl::Turn::Finished(acc_p0.clone()),
        }
    }
}

/// `Start TypeVarsInto, x`: what the function value is when passed to `@Run`.
pub fn start_type_vars_into_f(acc_p0: Array<Text>, t_p1: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TypeVarsInto { acc_p0, t_p1 })
}

/// ```prism
/// ColorVarsOfType: unbounded fn Type -> [Text]
/// ```
pub fn color_vars_of_type_f(t_p0: &crate::syntax::Type) -> Array<Text> {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TFn(crate::syntax::Color::ColorVar(v_p1), ps_p2, res_p3) => {
            let inner_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(ps_p2.clone(), color_vars_of_type_f(&**res_p3), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let a_p6 = p1;
                crate::prelude::call_then(start_color_vars_of_type_f(a_p6.clone()), move |color_vars_of_type_f_18721: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p5, &color_vars_of_type_f_18721)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
            if &v_p1.name_p == &Text::lit("bounded") {
                inner_p4.clone()
            } else {
                crate::check::types::add_text_f(&inner_p4, &v_p1.name_p)
            }
        },
        crate::syntax::TypeKind::TFn(_, ps_p7, res_p8) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p7.clone(), color_vars_of_type_f(&**res_p8), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p9 = p0;
            let a_pa = p1;
            crate::prelude::call_then(start_color_vars_of_type_f(a_pa.clone()), move |color_vars_of_type_f_18890: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p9, &color_vars_of_type_f_18890)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TName(_, args_pb) => crate::prelude::run_to_end(crate::prelude::fold_job(args_pb.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pc = p0;
            let a_pd = p1;
            crate::prelude::call_then(start_color_vars_of_type_f(a_pd.clone()), move |color_vars_of_type_f_18977: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pc, &color_vars_of_type_f_18977)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TSigiled(_, i_pe) => color_vars_of_type_f(&**i_pe),
        crate::syntax::TypeKind::TArray(e_pf, _) => color_vars_of_type_f(&**e_pf),
        crate::syntax::TypeKind::TTuple(ts_pg) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_pg.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_ph = p0;
            let a_pi = p1;
            crate::prelude::call_then(start_color_vars_of_type_f(a_pi.clone()), move |color_vars_of_type_f_19135: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_ph, &color_vars_of_type_f_19135)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::syntax::TypeKind::TGroup(x_pj) => color_vars_of_type_f(&**x_pj),
        crate::syntax::TypeKind::TMap(k_pk, v_pl) => crate::check::types::union_texts_f(&color_vars_of_type_f(&**k_pk), &color_vars_of_type_f(&**v_pl)),
        crate::syntax::TypeKind::TEmit(ty_pm, _) => color_vars_of_type_f(&**ty_pm),
        _ => Array::new(),
    }
}

/// The step machine of `ColorVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ColorVarsOfType: unbounded fn Type -> [Text]
/// ```
pub struct ColorVarsOfType {
    pub t_p0: crate::syntax::Type,
}

impl prism_rtl::Job<Array<Text>> for ColorVarsOfType {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t_p0 = &self.t_p0;
        match &*t_p0.kind_p {
            crate::syntax::TypeKind::TFn(crate::syntax::Color::ColorVar(v_p1), ps_p2, res_p3) => {
                let ps_p2x = ps_p2.clone();
                let res_p3x = (**res_p3).clone();
                let v_p1x = v_p1.clone();
                crate::prelude::call_then(start_color_vars_of_type_f(res_p3x.clone()), move |color_vars_of_type_f_18672: Array<Text>| crate::prelude::call_value(crate::prelude::fold_job(ps_p2x.clone(), color_vars_of_type_f_18672, Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p5 = p0;
                    let a_p6 = p1;
                    crate::prelude::call_then(start_color_vars_of_type_f(a_p6.clone()), move |color_vars_of_type_f_18721: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p5, &color_vars_of_type_f_18721)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_18662: Array<Text>| {
                    let inner_p4 = fold_18662;
                    if &v_p1x.name_p == &Text::lit("bounded") {
                        prism_rtl::Turn::Finished(inner_p4.clone())
                    } else {
                        prism_rtl::Turn::Finished(crate::check::types::add_text_f(&inner_p4, &v_p1x.name_p))
                    }
                }))
            },
            crate::syntax::TypeKind::TFn(_, ps_p7, res_p8) => {
                let ps_p7x = ps_p7.clone();
                let res_p8x = (**res_p8).clone();
                crate::prelude::call_then(start_color_vars_of_type_f(res_p8x.clone()), move |color_vars_of_type_f_18841: Array<Text>| crate::prelude::fold_job(ps_p7x.clone(), color_vars_of_type_f_18841, Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p9 = p0;
                    let a_pa = p1;
                    crate::prelude::call_then(start_color_vars_of_type_f(a_pa.clone()), move |color_vars_of_type_f_18890: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p9, &color_vars_of_type_f_18890)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            crate::syntax::TypeKind::TName(_, args_pb) => crate::prelude::fold_job(args_pb.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pc = p0;
                let a_pd = p1;
                crate::prelude::call_then(start_color_vars_of_type_f(a_pd.clone()), move |color_vars_of_type_f_18977: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pc, &color_vars_of_type_f_18977)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TSigiled(_, i_pe) => prism_rtl::Turn::More(Rc::new(ColorVarsOfType { t_p0: (**i_pe).clone() })),
            crate::syntax::TypeKind::TArray(e_pf, _) => prism_rtl::Turn::More(Rc::new(ColorVarsOfType { t_p0: (**e_pf).clone() })),
            crate::syntax::TypeKind::TTuple(ts_pg) => crate::prelude::fold_job(ts_pg.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Type)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_ph = p0;
                let a_pi = p1;
                crate::prelude::call_then(start_color_vars_of_type_f(a_pi.clone()), move |color_vars_of_type_f_19135: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_ph, &color_vars_of_type_f_19135)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Type)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::syntax::TypeKind::TGroup(x_pj) => prism_rtl::Turn::More(Rc::new(ColorVarsOfType { t_p0: (**x_pj).clone() })),
            crate::syntax::TypeKind::TMap(k_pk, v_pl) => {
                let k_pkx = (**k_pk).clone();
                let v_plx = (**v_pl).clone();
                crate::prelude::call_then(start_color_vars_of_type_f(k_pkx.clone()), move |color_vars_of_type_f_19213: Array<Text>| crate::prelude::call_then(start_color_vars_of_type_f(v_plx.clone()), move |color_vars_of_type_f_19234: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&color_vars_of_type_f_19213, &color_vars_of_type_f_19234))))
            },
            crate::syntax::TypeKind::TEmit(ty_pm, _) => prism_rtl::Turn::More(Rc::new(ColorVarsOfType { t_p0: (**ty_pm).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ColorVarsOfType, x`: what the function value is when passed to `@Run`.
pub fn start_color_vars_of_type_f(t_p0: crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ColorVarsOfType { t_p0 })
}
