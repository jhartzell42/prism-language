//! The module `Check.Shrink.Walk`, from `target/bootstrap/src/prismc/check/shrink/walk.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Kid`:
///
/// ```prism
/// type Kid = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Kid {
    KidExpr(crate::syntax::Expr, Map<Text, crate::check::shrink::Rel>),
    KidStmts(Array<crate::syntax::Stmt>, Map<Text, crate::check::shrink::Rel>),
}

impl Show for Kid {
    fn show(&self, p: &mut Printer) {
        match self {
            Kid::KidExpr(a0, a1) => p.choice("KidExpr", &[a0, a1]),
            Kid::KidStmts(a0, a1) => p.choice("KidStmts", &[a0, a1]),
        }
    }
}

impl ToPod for Kid {
    fn to_pod(&self) -> Pod {
        match self {
            Kid::KidExpr(a0, a1) => Pod::Choice("KidExpr".into(), vec![a0.to_pod(), a1.to_pod()]),
            Kid::KidStmts(a0, a1) => Pod::Choice("KidStmts".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Kid {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "KidExpr" && a.len() == 2 => Ok(Kid::KidExpr(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KidStmts" && a.len() == 2 => Ok(Kid::KidStmts(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Kid", other),
        }
    }
}

/// `Site`:
///
/// ```prism
/// type Site = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Site {
    pub callee: Text,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
    pub rels: Map<Text, crate::check::shrink::Rel>,
}

impl Show for Site {
    fn show(&self, p: &mut Printer) {
        p.record("Site", &[("callee", &self.callee), ("args", &self.args), ("span", &self.span), ("rels", &self.rels)]);
    }
}

impl ToPod for Site {
    fn to_pod(&self) -> Pod {
        Pod::record("Site", vec![("callee", self.callee.to_pod()), ("args", self.args.to_pod()), ("span", self.span.to_pod()), ("rels", self.rels.to_pod())])
    }
}

impl FromPod for Site {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Site { callee: FromPod::from_pod(field(p, "callee")?)?, args: FromPod::from_pod(field(p, "args")?)?, span: FromPod::from_pod(field(p, "span")?)?, rels: FromPod::from_pod(field(p, "rels")?)? })
    }
}

/// `Spot`:
///
/// ```prism
/// type Spot = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Spot {
    SpotExpr(crate::syntax::Expr, Map<Text, crate::check::shrink::Rel>),
    SpotStmt(crate::syntax::Stmt, Map<Text, crate::check::shrink::Rel>),
}

impl Show for Spot {
    fn show(&self, p: &mut Printer) {
        match self {
            Spot::SpotExpr(a0, a1) => p.choice("SpotExpr", &[a0, a1]),
            Spot::SpotStmt(a0, a1) => p.choice("SpotStmt", &[a0, a1]),
        }
    }
}

impl ToPod for Spot {
    fn to_pod(&self) -> Pod {
        match self {
            Spot::SpotExpr(a0, a1) => Pod::Choice("SpotExpr".into(), vec![a0.to_pod(), a1.to_pod()]),
            Spot::SpotStmt(a0, a1) => Pod::Choice("SpotStmt".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Spot {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "SpotExpr" && a.len() == 2 => Ok(Spot::SpotExpr(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "SpotStmt" && a.len() == 2 => Ok(Spot::SpotStmt(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Spot", other),
        }
    }
}

/// ```prism
/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
/// ```
pub fn expr_spots(e: &crate::syntax::Expr, m: &Map<Text, crate::check::shrink::Rel>) -> Array<Spot> {
    run_to_end(fold_job(expr_kids(e, m), Array::from(vec![Spot::SpotExpr(e.clone(), m.clone())]), Rc::new(move |(p0, p1): (Array<Spot>, Kid)| entered(once_job(move || {
        let acc = p0;
        let k = p1;
        call_then(start_kid_spots(k.clone()), move |kid_spots_2175: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &kid_spots_2175)))
    }))) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>))
}

/// The step machine of `ExprSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
/// ```
pub struct ExprSpots {
    pub e: crate::syntax::Expr,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<Spot>> for ExprSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let e = &self.e;
        let m = &self.m;
        let e = e.clone();
        let m = m.clone();
        call_then(start_expr_kids(e.clone(), m.clone()), move |expr_kids_2115: Array<Kid>| fold_job(expr_kids_2115, Array::from(vec![Spot::SpotExpr(e.clone(), m.clone())]), Rc::new(move |(p0, p1): (Array<Spot>, Kid)| entered(once_job(move || {
            let acc = p0;
            let k = p1;
            call_then(start_kid_spots(k.clone()), move |kid_spots_2175: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &kid_spots_2175)))
        }))) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>).cycle())
    }
}

/// `Start ExprSpots, x`: what the function value is when passed to `@Run`.
pub fn start_expr_spots(e: crate::syntax::Expr, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(ExprSpots { e, m })
}

/// ```prism
/// KidSpots: unbounded fn Kid -> [Spot]
/// ```
pub fn kid_spots(kid0: &Kid) -> Array<Spot> {
    match kid0 {
        Kid::KidExpr(x, m) => expr_spots(x, m),
        Kid::KidStmts(ss, m) => stmts_spots(ss, m),
    }
}

/// The step machine of `KidSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KidSpots: unbounded fn Kid -> [Spot]
/// ```
pub struct KidSpots {
    pub kid0: Kid,
}

impl prism_rtl::Job<Array<Spot>> for KidSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let kid0 = &self.kid0;
        match kid0 {
            Kid::KidExpr(x, m) => prism_rtl::Turn::More(Rc::new(ExprSpots { e: x.clone(), m: m.clone() })),
            Kid::KidStmts(ss, m) => prism_rtl::Turn::More(Rc::new(StmtsSpots { stmts: ss.clone(), m: m.clone() })),
        }
    }
}

/// `Start KidSpots, x`: what the function value is when passed to `@Run`.
pub fn start_kid_spots(kid0: Kid) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(KidSpots { kid0 })
}

/// ```prism
/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
/// ```
pub fn stmts_spots(stmts: &Array<crate::syntax::Stmt>, m: &Map<Text, crate::check::shrink::Rel>) -> Array<Spot> {
    let bm = crate::check::shrink::relations::block_rels(stmts, m);
    run_to_end(fold_job(stmts.clone(), Array::new(), {
        let bm = bm.clone();
        Rc::new(move |(p0, p1): (Array<Spot>, crate::syntax::Stmt)| {
            let bm = bm.clone();
            entered(once_job(move || {
                let acc = p0;
                let s = p1;
                call_then(start_stmt_spots(s.clone(), bm.clone()), move |stmt_spots_2562: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &stmt_spots_2562)))
            }))
        }) as Rc<dyn Fn((Array<Spot>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>
    }))
}

/// The step machine of `StmtsSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
/// ```
pub struct StmtsSpots {
    pub stmts: Array<crate::syntax::Stmt>,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<Spot>> for StmtsSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let stmts = &self.stmts;
        let m = &self.m;
        let m = m.clone();
        let stmts = stmts.clone();
        call_then(crate::check::shrink::relations::start_block_rels(stmts.clone(), m.clone()), move |block_rels_2498: Map<Text, crate::check::shrink::Rel>| {
            let bm = block_rels_2498;
            fold_job(stmts.clone(), Array::new(), {
                let bm = bm.clone();
                Rc::new(move |(p0, p1): (Array<Spot>, crate::syntax::Stmt)| {
                    let bm = bm.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let s = p1;
                        call_then(start_stmt_spots(s.clone(), bm.clone()), move |stmt_spots_2562: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &stmt_spots_2562)))
                    }))
                }) as Rc<dyn Fn((Array<Spot>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>
            }).cycle()
        })
    }
}

/// `Start StmtsSpots, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_spots(stmts: Array<crate::syntax::Stmt>, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(StmtsSpots { stmts, m })
}

/// ```prism
/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
/// ```
pub fn stmt_spots(s: &crate::syntax::Stmt, m: &Map<Text, crate::check::shrink::Rel>) -> Array<Spot> {
    run_to_end(fold_job(stmt_kids(s, m), Array::from(vec![Spot::SpotStmt(s.clone(), m.clone())]), Rc::new(move |(p0, p1): (Array<Spot>, Kid)| entered(once_job(move || {
        let acc = p0;
        let k = p1;
        call_then(start_kid_spots(k.clone()), move |kid_spots_2721: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &kid_spots_2721)))
    }))) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>))
}

/// The step machine of `StmtSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
/// ```
pub struct StmtSpots {
    pub s: crate::syntax::Stmt,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<Spot>> for StmtSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let s = &self.s;
        let m = &self.m;
        let m = m.clone();
        let s = s.clone();
        call_then(start_stmt_kids(s.clone(), m.clone()), move |stmt_kids_2661: Array<Kid>| fold_job(stmt_kids_2661, Array::from(vec![Spot::SpotStmt(s.clone(), m.clone())]), Rc::new(move |(p0, p1): (Array<Spot>, Kid)| entered(once_job(move || {
            let acc = p0;
            let k = p1;
            call_then(start_kid_spots(k.clone()), move |kid_spots_2721: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &kid_spots_2721)))
        }))) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>).cycle())
    }
}

/// `Start StmtSpots, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_spots(s: crate::syntax::Stmt, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(StmtSpots { s, m })
}

/// ```prism
/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
/// ```
pub fn body_spots(fn_body0: &crate::syntax::decls::FnBody, m: &Map<Text, crate::check::shrink::Rel>) -> Array<Spot> {
    match fn_body0 {
        crate::syntax::decls::FnBody::BodyExpr(e) => expr_spots(e, m),
        crate::syntax::decls::FnBody::BodyBlock(b) => stmts_spots(&b.stmts, m),
    }
}

/// The step machine of `BodySpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
/// ```
pub struct BodySpots {
    pub fn_body0: crate::syntax::decls::FnBody,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<Spot>> for BodySpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let fn_body0 = &self.fn_body0;
        let m = &self.m;
        match fn_body0 {
            crate::syntax::decls::FnBody::BodyExpr(e) => prism_rtl::Turn::More(Rc::new(ExprSpots { e: e.clone(), m: m.clone() })),
            crate::syntax::decls::FnBody::BodyBlock(b) => prism_rtl::Turn::More(Rc::new(StmtsSpots { stmts: b.stmts.clone(), m: m.clone() })),
        }
    }
}

/// `Start BodySpots, x`: what the function value is when passed to `@Run`.
pub fn start_body_spots(fn_body0: crate::syntax::decls::FnBody, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(BodySpots { fn_body0, m })
}

/// ```prism
/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
/// ```
pub fn expr_kids(e: &crate::syntax::Expr, m: &Map<Text, crate::check::shrink::Rel>) -> Array<Kid> {
    match &*e.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => call_kids(&**c, args, m),
        crate::syntax::ExprKind::EMethod(r, n, args) => call_kids(&method_callee(n), &method_args(&**r, args), m),
        crate::syntax::ExprKind::EBinary(_, l, r) => exprs_kids(&Array::from(vec![(**l).clone(), (**r).clone()]), m),
        crate::syntax::ExprKind::ESuffixed(_, _, l, r) => exprs_kids(&Array::from(vec![(**l).clone(), (**r).clone()]), m),
        crate::syntax::ExprKind::EIndex(r, i) => exprs_kids(&Array::from(vec![(**r).clone(), (**i).clone()]), m),
        crate::syntax::ExprKind::EUnary(_, x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::EFreeSigil(_, x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::EField(r, _, _) => Array::from(vec![Kid::KidExpr((**r).clone(), m.clone())]),
        crate::syntax::ExprKind::ETopicIndex(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::EGroup(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::ETypeArgs(x, _) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::ECast(x, _, _) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::ENonEmpty(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::EAny(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::ETuple(es) => exprs_kids(es, m),
        crate::syntax::ExprKind::EArray(es) => exprs_kids(es, m),
        crate::syntax::ExprKind::EMap(kvs) => fold(kvs, &Array::new(), &(|acc: &Array<Kid>, (k, v_): &(crate::syntax::Expr, crate::syntax::Expr)| append(acc, &exprs_kids(&Array::from(vec![k.clone(), v_.clone()]), m)))),
        crate::syntax::ExprKind::ELit(l) => match &l.kind {
            crate::syntax::LitKind::LText(segs) => fold(segs, &Array::new(), &(|acc: &Array<Kid>, sg: &crate::syntax::TextSeg| match sg {
                crate::syntax::TextSeg::SegPlaceholder(x) => push(acc, &Kid::KidExpr(x.clone(), m.clone())),
                _ => acc.clone(),
            })),
            _ => Array::new(),
        },
        crate::syntax::ExprKind::ELambda(ps_opt, body) => Array::from(vec![lambda_kid(&**body, &later(&crate::check::shrink::relations::hide(m, &patterns_names(&or(ps_opt, &Array::new())))))]),
        crate::syntax::ExprKind::EIf(c, t, el_opt) => {
            let with_then = push(&cond_kids(&**c, m), &Kid::KidStmts(t.stmts.clone(), crate::check::shrink::relations::cond_rels(&**c, m)));
            match el_opt {
                Some(b) => push(&with_then, &Kid::KidStmts(b.stmts.clone(), m.clone())),
                None => with_then.clone(),
            }
        },
        crate::syntax::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), Array::from(vec![Kid::KidExpr((**s).clone(), m.clone())]), {
            let s = (**s).clone();
            let m = m.clone();
            Rc::new(move |(p0, p1): (Array<Kid>, crate::syntax::Arm)| {
                let s = s.clone();
                let m = m.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(crate::check::shrink::relations::start_arm_pat_rels(s.clone(), a.clone(), m.clone()), move |arm_pat_rels_4324: Map<Text, crate::check::shrink::Rel>| {
                        let am = arm_pat_rels_4324;
                        prism_rtl::Turn::Finished(push(&append(&acc, &opt_kids(&a.guard, &am)), &Kid::KidStmts(a.body.stmts.clone(), am.clone())))
                    })
                }))
            }) as Rc<dyn Fn((Array<Kid>, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<Array<Kid>>>>
        })),
        crate::syntax::ExprKind::ERebuild(s, b) => Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), later(m))]),
        crate::syntax::ExprKind::EUpdate(s, b) => Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), m.clone())]),
        crate::syntax::ExprKind::EMonad(s, b) => Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), m.clone())]),
        crate::syntax::ExprKind::EFor(fb_opt, s, b) => {
            let names = match fb_opt {
                Some(fb) => crate::check::types::union_texts(&crate::check::env::names::pattern_names(&fb.first), &crate::check::shrink::summaries::opt_names(&fb.second)),
                None => Array::new(),
            };
            Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), crate::check::shrink::relations::hide(m, &names))])
        },
        crate::syntax::ExprKind::EGiven(b) => Array::from(vec![Kid::KidStmts(b.stmts.clone(), m.clone())]),
        crate::syntax::ExprKind::EWidgetBlock(b) => Array::from(vec![Kid::KidStmts(b.stmts.clone(), later(m))]),
        crate::syntax::ExprKind::ETemplate(t) => template_kids(&t.parts, m),
        _ => Array::new(),
    }
}

/// The step machine of `ExprKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
/// ```
pub struct ExprKids {
    pub e: crate::syntax::Expr,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<Kid>> for ExprKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let e = &self.e;
        let m = &self.m;
        match &*e.kind {
            crate::syntax::ExprKind::ECall(c, args, _, _) => prism_rtl::Turn::More(Rc::new(CallKids { c: (**c).clone(), args: args.clone(), m: m.clone() })),
            crate::syntax::ExprKind::EMethod(r, n, args) => prism_rtl::Turn::More(Rc::new(CallKids { c: method_callee(n), args: method_args(&**r, args), m: m.clone() })),
            crate::syntax::ExprKind::EBinary(_, l, r) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![(**l).clone(), (**r).clone()]), m)),
            crate::syntax::ExprKind::ESuffixed(_, _, l, r) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![(**l).clone(), (**r).clone()]), m)),
            crate::syntax::ExprKind::EIndex(r, i) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![(**r).clone(), (**i).clone()]), m)),
            crate::syntax::ExprKind::EUnary(_, x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::EFreeSigil(_, x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::EField(r, _, _) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**r).clone(), m.clone())])),
            crate::syntax::ExprKind::ETopicIndex(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::ETypeArgs(x, _) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::ECast(x, _, _) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::ENonEmpty(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::EAny(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::ETuple(es) => prism_rtl::Turn::Finished(exprs_kids(es, m)),
            crate::syntax::ExprKind::EArray(es) => prism_rtl::Turn::Finished(exprs_kids(es, m)),
            crate::syntax::ExprKind::EMap(kvs) => prism_rtl::Turn::Finished(fold(kvs, &Array::new(), &(|acc: &Array<Kid>, (k, v_): &(crate::syntax::Expr, crate::syntax::Expr)| append(acc, &exprs_kids(&Array::from(vec![k.clone(), v_.clone()]), m))))),
            crate::syntax::ExprKind::ELit(l) => match &l.kind {
                crate::syntax::LitKind::LText(segs) => prism_rtl::Turn::Finished(fold(segs, &Array::new(), &(|acc: &Array<Kid>, sg: &crate::syntax::TextSeg| match sg {
                    crate::syntax::TextSeg::SegPlaceholder(x) => push(acc, &Kid::KidExpr(x.clone(), m.clone())),
                    _ => acc.clone(),
                }))),
                _ => prism_rtl::Turn::Finished(Array::new()),
            },
            crate::syntax::ExprKind::ELambda(ps_opt, body) => {
                let ps_opt = ps_opt.clone();
                let body = (**body).clone();
                let m = m.clone();
                call_then(start_patterns_names(or(&ps_opt, &Array::new())), move |patterns_names_4012: Array<Text>| prism_rtl::Turn::Finished(Array::from(vec![lambda_kid(&body, &later(&crate::check::shrink::relations::hide(&m, &patterns_names_4012)))])))
            },
            crate::syntax::ExprKind::EIf(c, t, el_opt) => {
                let el_opt = el_opt.clone();
                let c = (**c).clone();
                let m = m.clone();
                let t = t.clone();
                call_then(start_cond_kids(c.clone(), m.clone()), move |cond_kids_4095: Array<Kid>| call_then(crate::check::shrink::relations::start_cond_rels(c.clone(), m.clone()), move |cond_rels_4131: Map<Text, crate::check::shrink::Rel>| {
                    let with_then = push(&cond_kids_4095, &Kid::KidStmts(t.stmts.clone(), cond_rels_4131));
                    match &el_opt {
                        Some(b) => prism_rtl::Turn::Finished(push(&with_then, &Kid::KidStmts(b.stmts.clone(), m.clone()))),
                        None => prism_rtl::Turn::Finished(with_then.clone()),
                    }
                }))
            },
            crate::syntax::ExprKind::EMatch(s, arms) => fold_job(arms.clone(), Array::from(vec![Kid::KidExpr((**s).clone(), m.clone())]), {
                let s = (**s).clone();
                let m = m.clone();
                Rc::new(move |(p0, p1): (Array<Kid>, crate::syntax::Arm)| {
                    let s = s.clone();
                    let m = m.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let a = p1;
                        call_then(crate::check::shrink::relations::start_arm_pat_rels(s.clone(), a.clone(), m.clone()), move |arm_pat_rels_4324: Map<Text, crate::check::shrink::Rel>| {
                            let am = arm_pat_rels_4324;
                            prism_rtl::Turn::Finished(push(&append(&acc, &opt_kids(&a.guard, &am)), &Kid::KidStmts(a.body.stmts.clone(), am.clone())))
                        })
                    }))
                }) as Rc<dyn Fn((Array<Kid>, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<Array<Kid>>>>
            }).cycle(),
            crate::syntax::ExprKind::ERebuild(s, b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), later(m))])),
            crate::syntax::ExprKind::EUpdate(s, b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), m.clone())])),
            crate::syntax::ExprKind::EMonad(s, b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), m.clone())])),
            crate::syntax::ExprKind::EFor(fb_opt, s, b) => {
                let names = match fb_opt {
                    Some(fb) => crate::check::types::union_texts(&crate::check::env::names::pattern_names(&fb.first), &crate::check::shrink::summaries::opt_names(&fb.second)),
                    None => Array::new(),
                };
                prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), crate::check::shrink::relations::hide(m, &names))]))
            },
            crate::syntax::ExprKind::EGiven(b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidStmts(b.stmts.clone(), m.clone())])),
            crate::syntax::ExprKind::EWidgetBlock(b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidStmts(b.stmts.clone(), later(m))])),
            crate::syntax::ExprKind::ETemplate(t) => prism_rtl::Turn::More(Rc::new(TemplateKids { parts: t.parts.clone(), m: m.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ExprKids, x`: what the function value is when passed to `@Run`.
pub fn start_expr_kids(e: crate::syntax::Expr, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(ExprKids { e, m })
}

/// ```prism
/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
/// ```
pub fn stmt_kids(s: &crate::syntax::Stmt, m: &Map<Text, crate::check::shrink::Rel>) -> Array<Kid> {
    match &s.kind {
        crate::syntax::StmtKind::SBind(_, e, t_opt) => append(&Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]), &opt_kids(t_opt, m)),
        crate::syntax::StmtKind::SIgnore(e) => Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]),
        crate::syntax::StmtKind::SLet(_, _, e) => Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]),
        crate::syntax::StmtKind::SFn(f) => Array::from(vec![body_kid(&f.body, &later(&crate::check::shrink::relations::hide(m, &patterns_names(&f.params))))]),
        crate::syntax::StmtKind::SWidget(w) => Array::from(vec![Kid::KidStmts(w.body.stmts.clone(), later(m))]),
        crate::syntax::StmtKind::SSet(t, v_) => exprs_kids(&Array::from(vec![t.clone(), v_.clone()]), m),
        crate::syntax::StmtKind::SAccum(t, _, v_) => exprs_kids(&Array::from(vec![t.clone(), v_.clone()]), m),
        crate::syntax::StmtKind::SRequire(c) => Array::from(vec![Kid::KidExpr(c.clone(), m.clone())]),
        crate::syntax::StmtKind::SForbid(c) => Array::from(vec![Kid::KidExpr(c.clone(), m.clone())]),
        crate::syntax::StmtKind::SReturn(e) => Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]),
        crate::syntax::StmtKind::SWhile(c, b) => push(&cond_kids(c, m), &Kid::KidStmts(b.stmts.clone(), crate::check::shrink::relations::cond_rels(c, m))),
        crate::syntax::StmtKind::SExpr(e) => Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]),
        _ => Array::new(),
    }
}

/// The step machine of `StmtKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
/// ```
pub struct StmtKids {
    pub s: crate::syntax::Stmt,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<Kid>> for StmtKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let s = &self.s;
        let m = &self.m;
        match &s.kind {
            crate::syntax::StmtKind::SBind(_, e, t_opt) => prism_rtl::Turn::Finished(append(&Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]), &opt_kids(t_opt, m))),
            crate::syntax::StmtKind::SIgnore(e) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(e.clone(), m.clone())])),
            crate::syntax::StmtKind::SLet(_, _, e) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(e.clone(), m.clone())])),
            crate::syntax::StmtKind::SFn(f) => {
                let f = f.clone();
                let m = m.clone();
                call_then(start_patterns_names(f.params.clone()), move |patterns_names_5261: Array<Text>| prism_rtl::Turn::Finished(Array::from(vec![body_kid(&f.body, &later(&crate::check::shrink::relations::hide(&m, &patterns_names_5261)))])))
            },
            crate::syntax::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidStmts(w.body.stmts.clone(), later(m))])),
            crate::syntax::StmtKind::SSet(t, v_) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![t.clone(), v_.clone()]), m)),
            crate::syntax::StmtKind::SAccum(t, _, v_) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![t.clone(), v_.clone()]), m)),
            crate::syntax::StmtKind::SRequire(c) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(c.clone(), m.clone())])),
            crate::syntax::StmtKind::SForbid(c) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(c.clone(), m.clone())])),
            crate::syntax::StmtKind::SReturn(e) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(e.clone(), m.clone())])),
            crate::syntax::StmtKind::SWhile(c, b) => {
                let b = b.clone();
                let c = c.clone();
                let m = m.clone();
                call_then(start_cond_kids(c.clone(), m.clone()), move |cond_kids_5554: Array<Kid>| call_then(crate::check::shrink::relations::start_cond_rels(c.clone(), m.clone()), move |cond_rels_5590: Map<Text, crate::check::shrink::Rel>| prism_rtl::Turn::Finished(push(&cond_kids_5554, &Kid::KidStmts(b.stmts.clone(), cond_rels_5590)))))
            },
            crate::syntax::StmtKind::SExpr(e) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(e.clone(), m.clone())])),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start StmtKids, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_kids(s: crate::syntax::Stmt, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(StmtKids { s, m })
}

/// ```prism
/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
/// ```
pub fn cond_kids(c: &crate::syntax::Cond, m: &Map<Text, crate::check::shrink::Rel>) -> Array<Kid> {
    match c {
        crate::syntax::Cond::CondExpr(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::Cond::CondBind(_, x, g_opt) => append(&Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]), &opt_kids(&**g_opt, &crate::check::shrink::relations::cond_rels(c, m))),
    }
}

/// The step machine of `CondKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
/// ```
pub struct CondKids {
    pub c: crate::syntax::Cond,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<Kid>> for CondKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let c = &self.c;
        let m = &self.m;
        match c {
            crate::syntax::Cond::CondExpr(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::Cond::CondBind(_, x, g_opt) => {
                let g_opt = (**g_opt).clone();
                let c = c.clone();
                let m = m.clone();
                let x = (**x).clone();
                call_then(crate::check::shrink::relations::start_cond_rels(c.clone(), m.clone()), move |cond_rels_5930: Map<Text, crate::check::shrink::Rel>| prism_rtl::Turn::Finished(append(&Array::from(vec![Kid::KidExpr(x.clone(), m.clone())]), &opt_kids(&g_opt, &cond_rels_5930))))
            },
        }
    }
}

/// `Start CondKids, x`: what the function value is when passed to `@Run`.
pub fn start_cond_kids(c: crate::syntax::Cond, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(CondKids { c, m })
}

/// ```prism
/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
/// ```
pub fn call_kids(c: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>, m: &Map<Text, crate::check::shrink::Rel>) -> Array<Kid> {
    let callee = match callee_name(c) {
        Some(_) => Array::new(),
        None => Array::from(vec![Kid::KidExpr(c.clone(), m.clone())]),
    };
    match traversal_of(m, c, args) {
        None => match acc_callee(m, c, args) {
            Some(cn) => append(&callee, &run_to_end(fold_job(crate::check::errors::range0(&len(args)), Array::new(), {
                let m = m.clone();
                let cn = cn.clone();
                let args = args.clone();
                Rc::new(move |(p0, p1): (Array<Kid>, Nat)| {
                    let m = m.clone();
                    let cn = cn.clone();
                    let args = args.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let i = p1;
                        call_then(start_acc_kids(m.clone(), cn.clone(), args.clone(), i.clone()), move |acc_kids_6790: Array<Kid>| prism_rtl::Turn::Finished(append(&acc, &acc_kids_6790)))
                    }))
                }) as Rc<dyn Fn((Array<Kid>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Kid>>>>
            }))),
            None => append(&callee, &exprs_kids(&each(args, &(|a: &crate::syntax::Arg| a.value.clone())), m)),
        },
        Some((coll, step_, at_)) => {
            let others = fold(&crate::check::errors::range0(&len(args)), &callee, &(|acc: &Array<Kid>, i: &Nat| if i == &(&at_ + &Nat::from(1u32)) {
                acc.clone()
            } else {
                match index(args, i) {
                    Some(a) => push(acc, &Kid::KidExpr(a.value.clone(), m.clone())),
                    None => acc.clone(),
                }
            }));
            match &*step_.kind {
                crate::syntax::ExprKind::ELambda(Some(ps), body) => push(&others, &lambda_kid(&**body, &crate::check::shrink::relations::step_rels(m, &coll, ps, &at_))),
                crate::syntax::ExprKind::EName(_) => others.clone(),
                _ => push(&others, &Kid::KidExpr(step_.clone(), m.clone())),
            }
        },
    }
}

/// The step machine of `CallKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
/// ```
pub struct CallKids {
    pub c: crate::syntax::Expr,
    pub args: Array<crate::syntax::Arg>,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<Kid>> for CallKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let c = &self.c;
        let args = &self.args;
        let m = &self.m;
        let callee = match callee_name(c) {
            Some(_) => Array::new(),
            None => Array::from(vec![Kid::KidExpr(c.clone(), m.clone())]),
        };
        match traversal_of(m, c, args) {
            None => match acc_callee(m, c, args) {
                Some(cn) => {
                    let args = args.clone();
                    let m = m.clone();
                    call_value(fold_job(crate::check::errors::range0(&len(&args)), Array::new(), {
                        let m = m.clone();
                        let cn = cn.clone();
                        let args = args.clone();
                        Rc::new(move |(p0, p1): (Array<Kid>, Nat)| {
                            let m = m.clone();
                            let cn = cn.clone();
                            let args = args.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let i = p1;
                                call_then(start_acc_kids(m.clone(), cn.clone(), args.clone(), i.clone()), move |acc_kids_6790: Array<Kid>| prism_rtl::Turn::Finished(append(&acc, &acc_kids_6790)))
                            }))
                        }) as Rc<dyn Fn((Array<Kid>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Kid>>>>
                    }), move |fold_6735: Array<Kid>| prism_rtl::Turn::Finished(append(&callee, &fold_6735)))
                },
                None => prism_rtl::Turn::Finished(append(&callee, &exprs_kids(&each(args, &(|a: &crate::syntax::Arg| a.value.clone())), m))),
            },
            Some((coll, step_, at_)) => {
                let others = fold(&crate::check::errors::range0(&len(args)), &callee, &(|acc: &Array<Kid>, i: &Nat| if i == &(&at_ + &Nat::from(1u32)) {
                    acc.clone()
                } else {
                    match index(args, i) {
                        Some(a) => push(acc, &Kid::KidExpr(a.value.clone(), m.clone())),
                        None => acc.clone(),
                    }
                }));
                match &*step_.kind {
                    crate::syntax::ExprKind::ELambda(Some(ps), body) => {
                        let body = (**body).clone();
                        let m = m.clone();
                        let ps = ps.clone();
                        call_then(crate::check::shrink::relations::start_step_rels(m.clone(), coll.clone(), ps.clone(), at_.clone()), move |step_rels_7203: Map<Text, crate::check::shrink::Rel>| prism_rtl::Turn::Finished(push(&others, &lambda_kid(&body, &step_rels_7203))))
                    },
                    crate::syntax::ExprKind::EName(_) => prism_rtl::Turn::Finished(others.clone()),
                    _ => prism_rtl::Turn::Finished(push(&others, &Kid::KidExpr(step_.clone(), m.clone()))),
                }
            },
        }
    }
}

/// `Start CallKids, x`: what the function value is when passed to `@Run`.
pub fn start_call_kids(c: crate::syntax::Expr, args: Array<crate::syntax::Arg>, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(CallKids { c, args, m })
}

/// ```prism
/// Later: fn (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn later(m: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    insert(m, &Text::lit("lam:"), &crate::check::shrink::relations::no_rel())
}

/// ```prism
/// ?AccCallee: fn (Text ==> Rel), Expr, [Arg] -> ?Text
/// ```
pub fn acc_callee(m: &Map<Text, crate::check::shrink::Rel>, c: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>) -> Option<Text> {
    match callee_name(c) {
        Some(cn) => if crate::check::shrink::relations::is_local(m, &cn) {
            None
        } else {
            if !fold(args, &true, &(|ok: &bool, a: &crate::syntax::Arg| *ok && (&a.name == &None))) {
                None
            } else {
                if fold(&crate::check::errors::range0(&len(args)), &false, &(|seen: &bool, i: &Nat| *seen || crate::check::env::has_key(m, &Text::from(format!("acc:{}:{}", &cn, i))))) {
                    Some(cn.clone())
                } else {
                    None
                }
            }
        },
        None => None,
    }
}

/// ```prism
/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
/// ```
pub fn acc_kids(m: &Map<Text, crate::check::shrink::Rel>, cn: &Text, args: &Array<crate::syntax::Arg>, i: &Nat) -> Array<Kid> {
    let a = or(&index(args, i), &crate::check::shrink::summaries::dummy_arg());
    if !crate::check::env::has_key(m, &Text::from(format!("acc:{}:{}", cn, i))) {
        Array::from(vec![Kid::KidExpr(a.value.clone(), m.clone())])
    } else {
        match &*a.value.kind {
            crate::syntax::ExprKind::ELambda(ps_opt, body) => Array::from(vec![lambda_kid(&**body, &acc_lambda_rels(m, cn, i, &or(ps_opt, &Array::new()), args))]),
            crate::syntax::ExprKind::EName(_) => Array::new(),
            _ => Array::from(vec![Kid::KidExpr(a.value.clone(), m.clone())]),
        }
    }
}

/// The step machine of `AccKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
/// ```
pub struct AccKids {
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub cn: Text,
    pub args: Array<crate::syntax::Arg>,
    pub i: Nat,
}

impl prism_rtl::Job<Array<Kid>> for AccKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let m = &self.m;
        let cn = &self.cn;
        let args = &self.args;
        let i = &self.i;
        let a = or(&index(args, i), &crate::check::shrink::summaries::dummy_arg());
        if !crate::check::env::has_key(m, &Text::from(format!("acc:{}:{}", cn, i))) {
            prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(a.value.clone(), m.clone())]))
        } else {
            match &*a.value.kind {
                crate::syntax::ExprKind::ELambda(ps_opt, body) => prism_rtl::Turn::Finished(Array::from(vec![lambda_kid(&**body, &acc_lambda_rels(m, cn, i, &or(ps_opt, &Array::new()), args))])),
                crate::syntax::ExprKind::EName(_) => prism_rtl::Turn::Finished(Array::new()),
                _ => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(a.value.clone(), m.clone())])),
            }
        }
    }
}

/// `Start AccKids, x`: what the function value is when passed to `@Run`.
pub fn start_acc_kids(m: Map<Text, crate::check::shrink::Rel>, cn: Text, args: Array<crate::syntax::Arg>, i: Nat) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(AccKids { m, cn, args, i })
}

/// ```prism
/// AccLambdaRels: unbounded fn (Text ==> Rel), Text, Nat, [Pattern], [Arg] -> (Text ==> Rel)
/// ```
pub fn acc_lambda_rels(m: &Map<Text, crate::check::shrink::Rel>, cn: &Text, j: &Nat, ps: &Array<crate::syntax::Pattern_>, args: &Array<crate::syntax::Arg>) -> Map<Text, crate::check::shrink::Rel> {
    let h = crate::check::shrink::relations::hide(m, &patterns_names(ps));
    run_to_end(fold_job(crate::check::errors::range0(&len(ps)), h.clone(), {
        let m = m.clone();
        let cn = cn.clone();
        let j = j.clone();
        let ps = ps.clone();
        let args = args.clone();
        Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Nat)| {
            let m = m.clone();
            let cn = cn.clone();
            let j = j.clone();
            let ps = ps.clone();
            let args = args.clone();
            entered(once_job(move || {
                let m2 = p0;
                let q = p1;
                match (get(&m, &Text::from(format!("sum:{}:{}:{}", &cn, &j, &q))), index(&ps, &q)) {
                    (Some(s), Some(p_)) => if &s.param == &top_param() {
                        prism_rtl::Turn::Finished(m2.clone())
                    } else {
                        match index(&args, &s.param) {
                            Some(a) => call_then(start_rel_of(m.clone(), a.value.clone()), move |rel_of_9191: Option<crate::check::shrink::Rel>| match rel_of_9191 {
                                Some(r) => match &*p_.kind {
                                    crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::Finished(insert(&m2, &crate::check::env::sname_key(n), &crate::check::shrink::Rel { param: r.param.clone(), strict: r.strict || s.strict })),
                                    _ => call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_9386: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_9386, &m2, &(|m3: &Map<Text, crate::check::shrink::Rel>, n: &Text| insert(m3, n, &crate::check::shrink::Rel { param: r.param.clone(), strict: true }))))),
                                },
                                None => prism_rtl::Turn::Finished(m2.clone()),
                            }),
                            None => prism_rtl::Turn::Finished(m2.clone()),
                        }
                    },
                    _ => prism_rtl::Turn::Finished(m2.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
    }))
}

/// ```prism
/// let topParam
/// ```
pub fn top_param() -> Nat {
    Nat::from(9999u32)
}

/// ```prism
/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
/// ```
pub fn template_kids(parts: &Array<crate::syntax::TemplatePart>, m: &Map<Text, crate::check::shrink::Rel>) -> Array<Kid> {
    fold(parts, &Array::new(), &(|acc: &Array<Kid>, p_: &crate::syntax::TemplatePart| match p_ {
        crate::syntax::TemplatePart::TpPlaceholder(x, _) => push(acc, &Kid::KidExpr(x.clone(), m.clone())),
        crate::syntax::TemplatePart::TpBlock(b) => push(acc, &Kid::KidStmts(b.stmts.clone(), m.clone())),
        crate::syntax::TemplatePart::TpCall(n, args, ps_opt, span) => push(acc, &Kid::KidExpr(template_call_expr(n, args, ps_opt, span), m.clone())),
        _ => acc.clone(),
    }))
}

/// The step machine of `TemplateKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
/// ```
pub struct TemplateKids {
    pub parts: Array<crate::syntax::TemplatePart>,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<Kid>> for TemplateKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let parts = &self.parts;
        let m = &self.m;
        prism_rtl::Turn::Finished(fold(parts, &Array::new(), &(|acc: &Array<Kid>, p_: &crate::syntax::TemplatePart| match p_ {
            crate::syntax::TemplatePart::TpPlaceholder(x, _) => push(acc, &Kid::KidExpr(x.clone(), m.clone())),
            crate::syntax::TemplatePart::TpBlock(b) => push(acc, &Kid::KidStmts(b.stmts.clone(), m.clone())),
            crate::syntax::TemplatePart::TpCall(n, args, ps_opt, span) => push(acc, &Kid::KidExpr(template_call_expr(n, args, ps_opt, span), m.clone())),
            _ => acc.clone(),
        })))
    }
}

/// `Start TemplateKids, x`: what the function value is when passed to `@Run`.
pub fn start_template_kids(parts: Array<crate::syntax::TemplatePart>, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(TemplateKids { parts, m })
}

/// ```prism
/// TemplateCallExpr: fn SName, [Arg], ?[TemplatePart], Range -> Expr
/// ```
pub fn template_call_expr(n: &crate::syntax::SName, args: &Array<crate::syntax::Arg>, ps_opt: &Option<Array<crate::syntax::TemplatePart>>, span: &crate::syntax::Range) -> crate::syntax::Expr {
    let body = match ps_opt {
        Some(ps) => Array::from(vec![crate::syntax::Arg { name: Some(crate::syntax::Ident { name: Text::lit("#body"), span: span.clone() }), value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(crate::syntax::Template { keyword: Text::lit("InlineText"), lang: Text::lit(""), delims: Text::lit("double"), parts: ps.clone(), span: span.clone() })), span: span.clone() }, span: span.clone() }]),
        None => Array::new(),
    };
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(n.clone())), span: n.span.clone() }), append(args, &body), false, false)), span: span.clone() }
}

/// ```prism
/// ArgOf: fn Expr -> Arg
/// ```
pub fn arg_of(x: &crate::syntax::Expr) -> crate::syntax::Arg {
    crate::syntax::Arg { name: None, value: x.clone(), span: x.span.clone() }
}

/// ```prism
/// ExprsKids: fn [Expr], (Text ==> Rel) -> [Kid]
/// ```
pub fn exprs_kids(xs: &Array<crate::syntax::Expr>, m: &Map<Text, crate::check::shrink::Rel>) -> Array<Kid> {
    each(xs, &(|x: &crate::syntax::Expr| Kid::KidExpr(x.clone(), m.clone())))
}

/// ```prism
/// OptKids: fn ?Expr, (Text ==> Rel) -> [Kid]
/// ```
pub fn opt_kids(opt0: &Option<crate::syntax::Expr>, map1: &Map<Text, crate::check::shrink::Rel>) -> Array<Kid> {
    match (opt0, map1) {
        (Some(x), m) => Array::from(vec![Kid::KidExpr(x.clone(), m.clone())]),
        (None, _) => Array::new(),
    }
}

/// ```prism
/// LambdaKid: fn LambdaBody, (Text ==> Rel) -> Kid
/// ```
pub fn lambda_kid(lambda_body0: &crate::syntax::LambdaBody, m: &Map<Text, crate::check::shrink::Rel>) -> Kid {
    match lambda_body0 {
        crate::syntax::LambdaBody::LbExpr(x) => Kid::KidExpr((**x).clone(), m.clone()),
        crate::syntax::LambdaBody::LbBlock(b) => Kid::KidStmts(b.stmts.clone(), m.clone()),
    }
}

/// ```prism
/// BodyKid: fn FnBody, (Text ==> Rel) -> Kid
/// ```
pub fn body_kid(fn_body0: &crate::syntax::decls::FnBody, m: &Map<Text, crate::check::shrink::Rel>) -> Kid {
    match fn_body0 {
        crate::syntax::decls::FnBody::BodyExpr(x) => Kid::KidExpr(x.clone(), m.clone()),
        crate::syntax::decls::FnBody::BodyBlock(b) => Kid::KidStmts(b.stmts.clone(), m.clone()),
    }
}

/// ```prism
/// PatternsNames: unbounded fn [Pattern] -> [Text]
/// ```
pub fn patterns_names(ps: &Array<crate::syntax::Pattern_>) -> Array<Text> {
    run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
        let a = p0;
        let p_ = p1;
        call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_11345: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &pattern_names_11345)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `PatternsNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatternsNames: unbounded fn [Pattern] -> [Text]
/// ```
pub struct PatternsNames {
    pub ps: Array<crate::syntax::Pattern_>,
}

impl prism_rtl::Job<Array<Text>> for PatternsNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let ps = &self.ps;
        fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let a = p0;
            let p_ = p1;
            call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_11345: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &pattern_names_11345)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
    }
}

/// `Start PatternsNames, x`: what the function value is when passed to `@Run`.
pub fn start_patterns_names(ps: Array<crate::syntax::Pattern_>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatternsNames { ps })
}

/// ```prism
/// ?CalleeName: fn Expr -> ?Text
/// ```
pub fn callee_name(c: &crate::syntax::Expr) -> Option<Text> {
    match &*c.kind {
        crate::syntax::ExprKind::EName(n) => Some(crate::check::env::sname_key(n)),
        crate::syntax::ExprKind::ETypeArgs(t, _) => match &*t.kind {
            crate::syntax::ExprKind::EName(n) => Some(crate::check::env::sname_key(n)),
            _ => None,
        },
        _ => None,
    }
}

/// ```prism
/// MethodCallee: fn SName -> Expr
/// ```
pub fn method_callee(n: &crate::syntax::SName) -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(n.clone())), span: n.span.clone() }
}

/// ```prism
/// MethodArgs: fn Expr, [Arg] -> [Arg]
/// ```
pub fn method_args(r: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>) -> Array<crate::syntax::Arg> {
    append(&Array::from(vec![crate::syntax::Arg { name: None, value: r.clone(), span: r.span.clone() }]), args)
}

/// ```prism
/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
/// ```
pub fn body_sites(body: &crate::syntax::decls::FnBody, m: &Map<Text, crate::check::shrink::Rel>) -> Array<Site> {
    run_to_end(fold_job(body_spots(body, m), Array::new(), Rc::new(move |(p0, p1): (Array<Site>, Spot)| entered(once_job(move || {
        let acc = p0;
        let sp = p1;
        call_then(start_spot_sites(sp.clone()), move |spot_sites_12302: Array<Site>| prism_rtl::Turn::Finished(append(&acc, &spot_sites_12302)))
    }))) as Rc<dyn Fn((Array<Site>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>))
}

/// The step machine of `BodySites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
/// ```
pub struct BodySites {
    pub body: crate::syntax::decls::FnBody,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<Site>> for BodySites {
    fn cycle(&self) -> prism_rtl::Turn<Array<Site>> {
        let body = &self.body;
        let m = &self.m;
        let body = body.clone();
        let m = m.clone();
        call_then(start_body_spots(body.clone(), m.clone()), move |body_spots_12252: Array<Spot>| fold_job(body_spots_12252, Array::new(), Rc::new(move |(p0, p1): (Array<Site>, Spot)| entered(once_job(move || {
            let acc = p0;
            let sp = p1;
            call_then(start_spot_sites(sp.clone()), move |spot_sites_12302: Array<Site>| prism_rtl::Turn::Finished(append(&acc, &spot_sites_12302)))
        }))) as Rc<dyn Fn((Array<Site>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>).cycle())
    }
}

/// `Start BodySites, x`: what the function value is when passed to `@Run`.
pub fn start_body_sites(body: crate::syntax::decls::FnBody, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<Site>>> {
    Rc::new(BodySites { body, m })
}

/// ```prism
/// SpotSites: unbounded fn Spot -> [Site]
/// ```
pub fn spot_sites(spot0: &Spot) -> Array<Site> {
    match spot0 {
        Spot::SpotStmt(_, _) => Array::new(),
        Spot::SpotExpr(e, m) => match &*e.kind {
            crate::syntax::ExprKind::EName(n) => Array::from(vec![Site { callee: crate::check::env::sname_key(n), args: Array::new(), span: e.span.clone(), rels: m.clone() }]),
            crate::syntax::ExprKind::ECall(c, args, _, _) => call_sites(&**c, args, &e.span, m),
            crate::syntax::ExprKind::EMethod(r, n, args) => call_sites(&method_callee(n), &method_args(&**r, args), &e.span, m),
            crate::syntax::ExprKind::EBinary(op, l, r) => if is_called_op(op) {
                Array::from(vec![Site { callee: op.clone(), args: Array::from(vec![arg_of(&**l), arg_of(&**r)]), span: e.span.clone(), rels: m.clone() }])
            } else {
                Array::new()
            },
            _ => Array::new(),
        },
    }
}

/// The step machine of `SpotSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotSites: unbounded fn Spot -> [Site]
/// ```
pub struct SpotSites {
    pub spot0: Spot,
}

impl prism_rtl::Job<Array<Site>> for SpotSites {
    fn cycle(&self) -> prism_rtl::Turn<Array<Site>> {
        let spot0 = &self.spot0;
        match spot0 {
            Spot::SpotStmt(_, _) => prism_rtl::Turn::Finished(Array::new()),
            Spot::SpotExpr(e, m) => match &*e.kind {
                crate::syntax::ExprKind::EName(n) => prism_rtl::Turn::Finished(Array::from(vec![Site { callee: crate::check::env::sname_key(n), args: Array::new(), span: e.span.clone(), rels: m.clone() }])),
                crate::syntax::ExprKind::ECall(c, args, _, _) => prism_rtl::Turn::More(Rc::new(CallSites { c: (**c).clone(), args: args.clone(), span: e.span.clone(), m: m.clone() })),
                crate::syntax::ExprKind::EMethod(r, n, args) => prism_rtl::Turn::More(Rc::new(CallSites { c: method_callee(n), args: method_args(&**r, args), span: e.span.clone(), m: m.clone() })),
                crate::syntax::ExprKind::EBinary(op, l, r) => if is_called_op(op) {
                    prism_rtl::Turn::Finished(Array::from(vec![Site { callee: op.clone(), args: Array::from(vec![arg_of(&**l), arg_of(&**r)]), span: e.span.clone(), rels: m.clone() }]))
                } else {
                    prism_rtl::Turn::Finished(Array::new())
                },
                _ => prism_rtl::Turn::Finished(Array::new()),
            },
        }
    }
}

/// `Start SpotSites, x`: what the function value is when passed to `@Run`.
pub fn start_spot_sites(spot0: Spot) -> Rc<dyn prism_rtl::Job<Array<Site>>> {
    Rc::new(SpotSites { spot0 })
}

/// ```prism
/// IsCalledOp: fn Text -> Bool
/// ```
pub fn is_called_op(op: &Text) -> bool {
    !crate::check::types::has_text(&Array::from(vec![Text::lit("and"), Text::lit("or"), Text::lit("on"), Text::lit("<|"), Text::lit("mod")]), op)
}

/// ```prism
/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
/// ```
pub fn call_sites(c: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range, m: &Map<Text, crate::check::shrink::Rel>) -> Array<Site> {
    let direct = match callee_name(c) {
        Some(n) => Array::from(vec![Site { callee: n.clone(), args: args.clone(), span: span.clone(), rels: m.clone() }]),
        None => Array::new(),
    };
    match traversal_of(m, c, args) {
        Some((coll, step_, at_)) => match &*step_.kind {
            crate::syntax::ExprKind::EName(n) => {
                let call_args = if &at_ == &Nat::from(1u32) {
                    Array::from(vec![or(&index(args, &Nat::from(1u32)), &crate::check::shrink::summaries::dummy_arg()), arg_of(&part_of(&coll))])
                } else {
                    Array::from(vec![arg_of(&part_of(&coll))])
                };
                push(&direct, &Site { callee: crate::check::env::sname_key(n), args: call_args.clone(), span: step_.span.clone(), rels: m.clone() })
            },
            _ => direct.clone(),
        },
        None => match acc_callee(m, c, args) {
            Some(cn) => append(&direct, &acc_sites(m, &cn, args)),
            None => direct.clone(),
        },
    }
}

/// The step machine of `CallSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
/// ```
pub struct CallSites {
    pub c: crate::syntax::Expr,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Array<Site>> for CallSites {
    fn cycle(&self) -> prism_rtl::Turn<Array<Site>> {
        let c = &self.c;
        let args = &self.args;
        let span = &self.span;
        let m = &self.m;
        let direct = match callee_name(c) {
            Some(n) => Array::from(vec![Site { callee: n.clone(), args: args.clone(), span: span.clone(), rels: m.clone() }]),
            None => Array::new(),
        };
        match traversal_of(m, c, args) {
            Some((coll, step_, at_)) => match &*step_.kind {
                crate::syntax::ExprKind::EName(n) => {
                    let call_args = if &at_ == &Nat::from(1u32) {
                        Array::from(vec![or(&index(args, &Nat::from(1u32)), &crate::check::shrink::summaries::dummy_arg()), arg_of(&part_of(&coll))])
                    } else {
                        Array::from(vec![arg_of(&part_of(&coll))])
                    };
                    prism_rtl::Turn::Finished(push(&direct, &Site { callee: crate::check::env::sname_key(n), args: call_args.clone(), span: step_.span.clone(), rels: m.clone() }))
                },
                _ => prism_rtl::Turn::Finished(direct.clone()),
            },
            None => match acc_callee(m, c, args) {
                Some(cn) => prism_rtl::Turn::Finished(append(&direct, &acc_sites(m, &cn, args))),
                None => prism_rtl::Turn::Finished(direct.clone()),
            },
        }
    }
}

/// `Start CallSites, x`: what the function value is when passed to `@Run`.
pub fn start_call_sites(c: crate::syntax::Expr, args: Array<crate::syntax::Arg>, span: crate::syntax::Range, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Array<Site>>> {
    Rc::new(CallSites { c, args, span, m })
}

/// ```prism
/// PartOf: fn Expr -> Expr
/// ```
pub fn part_of(x: &crate::syntax::Expr) -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(x.clone()), Text::lit(""), crate::syntax::Ident { name: Text::lit("element"), span: x.span.clone() })), span: x.span.clone() }
}

/// ```prism
/// AccSites: fn (Text ==> Rel), Text, [Arg] -> [Site]
/// ```
pub fn acc_sites(m: &Map<Text, crate::check::shrink::Rel>, cn: &Text, args: &Array<crate::syntax::Arg>) -> Array<Site> {
    fold(&crate::check::errors::range0(&len(args)), &Array::new(), &(|acc: &Array<Site>, j: &Nat| match (get(m, &Text::from(format!("acc:{}:{}", cn, j))), index(args, j)) {
        (Some(ar), Some(a)) => match &*a.value.kind {
            crate::syntax::ExprKind::EName(f) => push(acc, &Site { callee: crate::check::env::sname_key(f), args: each(&crate::check::errors::range0(&ar.param), &(|q: &Nat| acc_arg(m, cn, j, q, args))), span: a.value.span.clone(), rels: m.clone() }),
            _ => acc.clone(),
        },
        _ => acc.clone(),
    }))
}

/// ```prism
/// AccArg: fn (Text ==> Rel), Text, Nat, Nat, [Arg] -> Arg
/// ```
pub fn acc_arg(m: &Map<Text, crate::check::shrink::Rel>, cn: &Text, j: &Nat, q: &Nat, args: &Array<crate::syntax::Arg>) -> crate::syntax::Arg {
    match get(m, &Text::from(format!("sum:{}:{}:{}", cn, j, q))) {
        Some(s) => if &s.param == &top_param() {
            arg_of(&top_expr())
        } else {
            match index(args, &s.param) {
                Some(a) => arg_of(&(if s.strict { part_of(&a.value) } else { a.value.clone() })),
                None => crate::check::shrink::summaries::dummy_arg(),
            }
        },
        None => crate::check::shrink::summaries::dummy_arg(),
    }
}

/// ```prism
/// let topExpr
/// ```
pub fn top_expr() -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(crate::syntax::SName { sigils: Text::lit(""), path_: Array::from(vec![Text::lit("⊤")]), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } })), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// SpotsNames: unbounded fn [Spot] -> [Text]
/// ```
pub fn spots_names(spots: &Array<Spot>) -> Array<Text> {
    run_to_end(fold_job(spots.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, Spot)| entered(once_job(move || {
        let acc = p0;
        let sp = p1;
        call_then(start_spot_names(sp.clone()), move |spot_names_15643: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &spot_names_15643)))
    }))) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `SpotsNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotsNames: unbounded fn [Spot] -> [Text]
/// ```
pub struct SpotsNames {
    pub spots: Array<Spot>,
}

impl prism_rtl::Job<Array<Text>> for SpotsNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let spots = &self.spots;
        fold_job(spots.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, Spot)| entered(once_job(move || {
            let acc = p0;
            let sp = p1;
            call_then(start_spot_names(sp.clone()), move |spot_names_15643: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &spot_names_15643)))
        }))) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
    }
}

/// `Start SpotsNames, x`: what the function value is when passed to `@Run`.
pub fn start_spots_names(spots: Array<Spot>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotsNames { spots })
}

/// ```prism
/// SpotNames: unbounded fn Spot -> [Text]
/// ```
pub fn spot_names(sp: &Spot) -> Array<Text> {
    let called = each(&spot_sites(sp), &(|s: &Site| s.callee.clone()));
    match sp {
        Spot::SpotExpr(_, _) => called.clone(),
        Spot::SpotStmt(s, _) => match &s.kind {
            crate::syntax::StmtKind::SWidget(w) => crate::check::types::add_text(&called, &crate::check::env::sname_key(&w.name)),
            _ => called.clone(),
        },
    }
}

/// The step machine of `SpotNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotNames: unbounded fn Spot -> [Text]
/// ```
pub struct SpotNames {
    pub sp: Spot,
}

impl prism_rtl::Job<Array<Text>> for SpotNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sp = &self.sp;
        let sp = sp.clone();
        call_then(start_spot_sites(sp.clone()), move |spot_sites_15737: Array<Site>| {
            let called = each(&spot_sites_15737, &(|s: &Site| s.callee.clone()));
            match &sp {
                Spot::SpotExpr(_, _) => prism_rtl::Turn::Finished(called.clone()),
                Spot::SpotStmt(s, _) => match &s.kind {
                    crate::syntax::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(crate::check::types::add_text(&called, &crate::check::env::sname_key(&w.name))),
                    _ => prism_rtl::Turn::Finished(called.clone()),
                },
            }
        })
    }
}

/// `Start SpotNames, x`: what the function value is when passed to `@Run`.
pub fn start_spot_names(sp: Spot) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotNames { sp })
}

/// ```prism
/// ?TraversalOf: fn (Text ==> Rel), Expr, [Arg] -> ?((Expr, Expr, Nat))
/// ```
pub fn traversal_of(m: &Map<Text, crate::check::shrink::Rel>, c: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>) -> Option<(crate::syntax::Expr, crate::syntax::Expr, Nat)> {
    match &*c.kind {
        crate::syntax::ExprKind::EName(n) => {
            let name = crate::check::env::sname_key(n);
            if crate::check::shrink::relations::pre_is(m, &name, &Text::lit("Fold")) && (&len(args) == &Nat::from(3u32)) {
                match (index(args, &Nat::from(0u32)), index(args, &Nat::from(2u32))) {
                    (Some(a), Some(s)) => Some((a.value.clone(), s.value.clone(), Nat::from(1u32))),
                    _ => None,
                }
            } else {
                if (crate::check::shrink::relations::pre_is(m, &name, &Text::lit("Each")) || crate::check::shrink::relations::pre_is(m, &name, &Text::lit("Filter"))) && (&len(args) == &Nat::from(2u32)) {
                    match (index(args, &Nat::from(0u32)), index(args, &Nat::from(1u32))) {
                        (Some(a), Some(s)) => Some((a.value.clone(), s.value.clone(), Nat::from(0u32))),
                        _ => None,
                    }
                } else {
                    None
                }
            }
        },
        _ => None,
    }
}

/// ```prism
/// ?LastExpr: fn Block -> ?Expr
/// ```
pub fn last_expr(b: &crate::syntax::Block) -> Option<crate::syntax::Expr> {
    match crate::syntax::lexer::chars::last(&b.stmts) {
        Some(s) => match &s.kind {
            crate::syntax::StmtKind::SExpr(x) => Some(x.clone()),
            _ => None,
        },
        None => None,
    }
}

/// ```prism
/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub fn rel_of(m: &Map<Text, crate::check::shrink::Rel>, e: &crate::syntax::Expr) -> Option<crate::check::shrink::Rel> {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => get(m, &crate::check::env::sname_key(n)),
        crate::syntax::ExprKind::EField(r, _, _) => match rel_of(m, &**r) {
            Some(x) => Some(crate::check::shrink::Rel { param: x.param.clone(), strict: true }),
            None => None,
        },
        crate::syntax::ExprKind::EIndex(r, _) => rel_of(m, &**r),
        crate::syntax::ExprKind::EGroup(x) => rel_of(m, &**x),
        _ => match call_of(e) {
            Some((c, args)) => if is_non_nat_min(m, e, &c) { None } else { rel_of_call(m, &c, &args) },
            None => None,
        },
    }
}

/// The step machine of `RelOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub struct RelOf {
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<Option<crate::check::shrink::Rel>> for RelOf {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::check::shrink::Rel>> {
        let m = &self.m;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EName(n) => prism_rtl::Turn::Finished(get(m, &crate::check::env::sname_key(n))),
            crate::syntax::ExprKind::EField(r, _, _) => {
                let m = m.clone();
                let r = (**r).clone();
                call_then(start_rel_of(m.clone(), r.clone()), move |rel_of_17853: Option<crate::check::shrink::Rel>| match rel_of_17853 {
                    Some(x) => prism_rtl::Turn::Finished(Some(crate::check::shrink::Rel { param: x.param.clone(), strict: true })),
                    None => prism_rtl::Turn::Finished(None),
                })
            },
            crate::syntax::ExprKind::EIndex(r, _) => prism_rtl::Turn::More(Rc::new(RelOf { m: m.clone(), e: (**r).clone() })),
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(RelOf { m: m.clone(), e: (**x).clone() })),
            _ => match call_of(e) {
                Some((c, args)) => if is_non_nat_min(m, e, &c) {
                    prism_rtl::Turn::Finished(None)
                } else {
                    prism_rtl::Turn::More(Rc::new(RelOfCall { m: m.clone(), c: c.clone(), args: args.clone() }))
                },
                None => prism_rtl::Turn::Finished(None),
            },
        }
    }
}

/// `Start RelOf, x`: what the function value is when passed to `@Run`.
pub fn start_rel_of(m: Map<Text, crate::check::shrink::Rel>, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Option<crate::check::shrink::Rel>>> {
    Rc::new(RelOf { m, e })
}

/// ```prism
/// IsNonNatMin: fn (Text ==> Rel), Expr, Expr -> Bool
/// ```
pub fn is_non_nat_min(m: &Map<Text, crate::check::shrink::Rel>, e: &crate::syntax::Expr, c: &crate::syntax::Expr) -> bool {
    match callee_name(c) {
        Some(n) => if crate::check::shrink::relations::pre_is(m, &n, &Text::lit("Min")) {
            !is_nat_at(m, e)
        } else {
            false
        },
        None => false,
    }
}

/// ```prism
/// IsNatAt: fn (Text ==> Rel), Expr -> Bool
/// ```
pub fn is_nat_at(m: &Map<Text, crate::check::shrink::Rel>, e: &crate::syntax::Expr) -> bool {
    match get(m, &Text::lit("file:")) {
        Some(f) => crate::check::env::has_key(m, &Text::from(format!("nat:{}:{}:{}", &f.param, &e.span.start, &e.span.end))),
        None => false,
    }
}

/// ```prism
/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
/// ```
pub fn rel_of_call(m: &Map<Text, crate::check::shrink::Rel>, c: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>) -> Option<crate::check::shrink::Rel> {
    match &*c.kind {
        crate::syntax::ExprKind::EName(n) => {
            let name = crate::check::env::sname_key(n);
            if (crate::check::shrink::relations::pre_is(m, &name, &Text::lit("Drop")) && (&len(args) == &Nat::from(2u32))) && crate::check::shrink::summaries::is_positive_lit(&or(&index(args, &Nat::from(1u32)), &crate::check::shrink::summaries::dummy_arg()).value) {
                match index(args, &Nat::from(0u32)) {
                    Some(a) => match rel_of(m, &a.value) {
                        Some(x) => Some(crate::check::shrink::Rel { param: x.param.clone(), strict: x.strict || known_non_empty(m, &a.value) }),
                        None => None,
                    },
                    None => None,
                }
            } else {
                if (crate::check::shrink::relations::pre_is(m, &name, &Text::lit("Values")) || crate::check::shrink::relations::pre_is(m, &name, &Text::lit("Keys"))) && (&len(args) == &Nat::from(1u32)) {
                    rel_of(m, &or(&index(args, &Nat::from(0u32)), &crate::check::shrink::summaries::dummy_arg()).value)
                } else {
                    match no_larger_arg(m, c, args) {
                        Some(a) => rel_of(m, &a),
                        None => None,
                    }
                }
            }
        },
        _ => None,
    }
}

/// The step machine of `RelOfCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
/// ```
pub struct RelOfCall {
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub c: crate::syntax::Expr,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Option<crate::check::shrink::Rel>> for RelOfCall {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::check::shrink::Rel>> {
        let m = &self.m;
        let c = &self.c;
        let args = &self.args;
        match &*c.kind {
            crate::syntax::ExprKind::EName(n) => {
                let name = crate::check::env::sname_key(n);
                if (crate::check::shrink::relations::pre_is(m, &name, &Text::lit("Drop")) && (&len(args) == &Nat::from(2u32))) && crate::check::shrink::summaries::is_positive_lit(&or(&index(args, &Nat::from(1u32)), &crate::check::shrink::summaries::dummy_arg()).value) {
                    match index(args, &Nat::from(0u32)) {
                        Some(a) => {
                            let m = m.clone();
                            call_then(start_rel_of(m.clone(), a.value.clone()), move |rel_of_19010: Option<crate::check::shrink::Rel>| match rel_of_19010 {
                                Some(x) => prism_rtl::Turn::Finished(Some(crate::check::shrink::Rel { param: x.param.clone(), strict: x.strict || known_non_empty(&m, &a.value) })),
                                None => prism_rtl::Turn::Finished(None),
                            })
                        },
                        None => prism_rtl::Turn::Finished(None),
                    }
                } else {
                    if (crate::check::shrink::relations::pre_is(m, &name, &Text::lit("Values")) || crate::check::shrink::relations::pre_is(m, &name, &Text::lit("Keys"))) && (&len(args) == &Nat::from(1u32)) {
                        prism_rtl::Turn::More(Rc::new(RelOf { m: m.clone(), e: or(&index(args, &Nat::from(0u32)), &crate::check::shrink::summaries::dummy_arg()).value.clone() }))
                    } else {
                        match no_larger_arg(m, c, args) {
                            Some(a) => prism_rtl::Turn::More(Rc::new(RelOf { m: m.clone(), e: a.clone() })),
                            None => prism_rtl::Turn::Finished(None),
                        }
                    }
                }
            },
            _ => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start RelOfCall, x`: what the function value is when passed to `@Run`.
pub fn start_rel_of_call(m: Map<Text, crate::check::shrink::Rel>, c: crate::syntax::Expr, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Option<crate::check::shrink::Rel>>> {
    Rc::new(RelOfCall { m, c, args })
}

/// ```prism
/// KnownNonEmpty: fn (Text ==> Rel), Expr -> Bool
/// ```
pub fn known_non_empty(m: &Map<Text, crate::check::shrink::Rel>, e: &crate::syntax::Expr) -> bool {
    match crate::check::shrink::relations::name_of(e) {
        Some(n) => crate::check::env::has_key(m, &Text::from(format!("ne:{}", &n))),
        None => false,
    }
}

/// ```prism
/// ?CallOf: fn Expr -> ?((Expr, [Arg]))
/// ```
pub fn call_of(e: &crate::syntax::Expr) -> Option<(crate::syntax::Expr, Array<crate::syntax::Arg>)> {
    match &*e.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => Some(((**c).clone(), args.clone())),
        crate::syntax::ExprKind::EMethod(r, n, args) => Some((method_callee(n), method_args(&**r, args))),
        _ => None,
    }
}

/// ```prism
/// ?NoLargerArg: fn (Text ==> Rel), Expr, [Arg] -> ?Expr
/// ```
pub fn no_larger_arg(m: &Map<Text, crate::check::shrink::Rel>, c: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>) -> Option<crate::syntax::Expr> {
    match callee_name(c) {
        Some(n) => if crate::check::shrink::relations::is_local(m, &n) {
            None
        } else {
            match get(m, &Text::from(format!("fn:{}", &n))) {
                Some(s) => match index(args, &s.param) {
                    Some(a) => Some(a.value.clone()),
                    None => None,
                },
                None => None,
            }
        },
        None => None,
    }
}

/// ```prism
/// IsNoLargerPrelude: fn G, Text -> Bool
/// ```
pub fn is_no_larger_prelude(g: &crate::check::env::G, k: &Text) -> bool {
    crate::check::types::has_text(&Array::from(vec![Text::lit("Prelude.Take"), Text::lit("Prelude.Drop"), Text::lit("Prelude.Filter"), Text::lit("Prelude.Remove"), Text::lit("Prelude.Min")]), k) && crate::check::shrink::relations::is_prelude_key(g, k)
}
