//! The module `Check.Shrink.Walk`, from `target/bootstrap/src/prismc/check/shrink/walk.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `Kid`:
///
/// ```prism
/// type Kid = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Kid {
    KidExpr(crate::syntax::Expr, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>),
    KidStmts(crate::prelude::Array<crate::syntax::Stmt>, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>),
}

impl crate::prelude::Show for Kid {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Kid::KidExpr(a0, a1) => p.choice("KidExpr", &[a0, a1]),
            Kid::KidStmts(a0, a1) => p.choice("KidStmts", &[a0, a1]),
        }
    }
}

impl crate::prelude::ToPod for Kid {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Kid::KidExpr(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KidExpr", 0), vec![a0.to_pod(), a1.to_pod()]),
            Kid::KidStmts(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KidStmts", 1), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Kid {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "KidExpr" && a.len() == 2 => ::std::result::Result::Ok(Kid::KidExpr(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KidStmts" && a.len() == 2 => ::std::result::Result::Ok(Kid::KidStmts(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            other => ::prism_rtl::pod::mismatch("a Kid", other),
        }
    }
}

/// `Site`:
///
/// ```prism
/// type Site = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Site {
    pub callee_p: crate::prelude::Text,
    pub args_p: crate::prelude::Array<crate::syntax::Arg>,
    pub span_p: crate::syntax::Range,
    pub rels_p: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl crate::prelude::Show for Site {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Site", &[("callee", &self.callee_p), ("args", &self.args_p), ("span", &self.span_p), ("rels", &self.rels_p)]);
    }
}

impl crate::prelude::ToPod for Site {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Site", vec![("callee", self.callee_p.to_pod()), ("args", self.args_p.to_pod()), ("span", self.span_p.to_pod()), ("rels", self.rels_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Site {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Site { callee_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "callee")?)?, args_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "args")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)?, rels_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rels")?)? })
    }
}

/// `Spot`:
///
/// ```prism
/// type Spot = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Spot {
    SpotExpr(crate::syntax::Expr, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>),
    SpotStmt(crate::syntax::Stmt, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>),
}

impl crate::prelude::Show for Spot {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Spot::SpotExpr(a0, a1) => p.choice("SpotExpr", &[a0, a1]),
            Spot::SpotStmt(a0, a1) => p.choice("SpotStmt", &[a0, a1]),
        }
    }
}

impl crate::prelude::ToPod for Spot {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Spot::SpotExpr(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SpotExpr", 0), vec![a0.to_pod(), a1.to_pod()]),
            Spot::SpotStmt(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SpotStmt", 1), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Spot {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "SpotExpr" && a.len() == 2 => ::std::result::Result::Ok(Spot::SpotExpr(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SpotStmt" && a.len() == 2 => ::std::result::Result::Ok(Spot::SpotStmt(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            other => ::prism_rtl::pod::mismatch("a Spot", other),
        }
    }
}

/// ```prism
/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
/// ```
pub fn expr_spots_f(e_p0: &crate::syntax::Expr, m_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<Spot> {
    crate::prelude::run_to_end(crate::prelude::fold_job(expr_kids_f(e_p0, m_p1), crate::prelude::Array::from(vec![Spot::SpotExpr(e_p0.clone(), m_p1.clone())]), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<Spot>, Kid)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p2 = p0;
        let k_p3 = p1;
        crate::prelude::call_then(start_kid_spots_f(k_p3.clone()), move |kid_spots_f_2175: crate::prelude::Array<Spot>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p2, &kid_spots_f_2175)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<Spot>, Kid)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Spot>>>>))
}

/// The step machine of `ExprSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
/// ```
pub struct ExprSpots {
    pub e_p0: crate::syntax::Expr,
    pub m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<crate::prelude::Array<Spot>> for ExprSpots {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Spot>> {
        let e_p0 = &self.e_p0;
        let m_p1 = &self.m_p1;
        let e_p0x = e_p0.clone();
        let m_p1x = m_p1.clone();
        crate::prelude::call_then(start_expr_kids_f(e_p0x.clone(), m_p1x.clone()), move |expr_kids_f_2115: crate::prelude::Array<Kid>| crate::prelude::fold_job(expr_kids_f_2115, crate::prelude::Array::from(vec![Spot::SpotExpr(e_p0x.clone(), m_p1x.clone())]), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<Spot>, Kid)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p2 = p0;
            let k_p3 = p1;
            crate::prelude::call_then(start_kid_spots_f(k_p3.clone()), move |kid_spots_f_2175: crate::prelude::Array<Spot>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p2, &kid_spots_f_2175)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<Spot>, Kid)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Spot>>>>).cycle())
    }
}

/// `Start ExprSpots, x`: what the function value is when passed to `@Run`.
pub fn start_expr_spots_f(e_p0: crate::syntax::Expr, m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Spot>>> {
    ::std::rc::Rc::new(ExprSpots { e_p0, m_p1 })
}

/// ```prism
/// KidSpots: unbounded fn Kid -> [Spot]
/// ```
pub fn kid_spots_f(kid0: &Kid) -> crate::prelude::Array<Spot> {
    match kid0 {
        Kid::KidExpr(x_p0, m_p1) => expr_spots_f(x_p0, m_p1),
        Kid::KidStmts(ss_p2, m_p3) => stmts_spots_f(ss_p2, m_p3),
    }
}

/// The step machine of `KidSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KidSpots: unbounded fn Kid -> [Spot]
/// ```
pub struct KidSpots {
    pub kid0: Kid,
}

impl ::prism_rtl::Job<crate::prelude::Array<Spot>> for KidSpots {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Spot>> {
        let kid0 = &self.kid0;
        match kid0 {
            Kid::KidExpr(x_p0, m_p1) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExprSpots { e_p0: x_p0.clone(), m_p1: m_p1.clone() })),
            Kid::KidStmts(ss_p2, m_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(StmtsSpots { stmts_p0: ss_p2.clone(), m_p1: m_p3.clone() })),
        }
    }
}

/// `Start KidSpots, x`: what the function value is when passed to `@Run`.
pub fn start_kid_spots_f(kid0: Kid) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Spot>>> {
    ::std::rc::Rc::new(KidSpots { kid0 })
}

/// ```prism
/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
/// ```
pub fn stmts_spots_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>, m_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<Spot> {
    let bm_p2 = crate::check::shrink::relations::block_rels_f(stmts_p0, m_p1);
    crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p0.clone(), crate::prelude::Array::new(), {
        let bm_p2x = bm_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<Spot>, crate::syntax::Stmt)| {
            let bm_p2xy = bm_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let s_p4 = p1;
                crate::prelude::call_then(start_stmt_spots_f(s_p4.clone(), bm_p2xy.clone()), move |stmt_spots_f_2562: crate::prelude::Array<Spot>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &stmt_spots_f_2562)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<Spot>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Spot>>>>
    }))
}

/// The step machine of `StmtsSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
/// ```
pub struct StmtsSpots {
    pub stmts_p0: crate::prelude::Array<crate::syntax::Stmt>,
    pub m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<crate::prelude::Array<Spot>> for StmtsSpots {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Spot>> {
        let stmts_p0 = &self.stmts_p0;
        let m_p1 = &self.m_p1;
        let m_p1x = m_p1.clone();
        let stmts_p0x = stmts_p0.clone();
        crate::prelude::call_then(crate::check::shrink::relations::start_block_rels_f(stmts_p0x.clone(), m_p1x.clone()), move |block_rels_f_2498: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
            let bm_p2 = block_rels_f_2498;
            crate::prelude::fold_job(stmts_p0x.clone(), crate::prelude::Array::new(), {
                let bm_p2x = bm_p2.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<Spot>, crate::syntax::Stmt)| {
                    let bm_p2xy = bm_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p3 = p0;
                        let s_p4 = p1;
                        crate::prelude::call_then(start_stmt_spots_f(s_p4.clone(), bm_p2xy.clone()), move |stmt_spots_f_2562: crate::prelude::Array<Spot>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &stmt_spots_f_2562)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<Spot>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Spot>>>>
            }).cycle()
        })
    }
}

/// `Start StmtsSpots, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_spots_f(stmts_p0: crate::prelude::Array<crate::syntax::Stmt>, m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Spot>>> {
    ::std::rc::Rc::new(StmtsSpots { stmts_p0, m_p1 })
}

/// ```prism
/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
/// ```
pub fn stmt_spots_f(s_p0: &crate::syntax::Stmt, m_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<Spot> {
    crate::prelude::run_to_end(crate::prelude::fold_job(stmt_kids_f(s_p0, m_p1), crate::prelude::Array::from(vec![Spot::SpotStmt(s_p0.clone(), m_p1.clone())]), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<Spot>, Kid)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p2 = p0;
        let k_p3 = p1;
        crate::prelude::call_then(start_kid_spots_f(k_p3.clone()), move |kid_spots_f_2721: crate::prelude::Array<Spot>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p2, &kid_spots_f_2721)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<Spot>, Kid)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Spot>>>>))
}

/// The step machine of `StmtSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
/// ```
pub struct StmtSpots {
    pub s_p0: crate::syntax::Stmt,
    pub m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<crate::prelude::Array<Spot>> for StmtSpots {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Spot>> {
        let s_p0 = &self.s_p0;
        let m_p1 = &self.m_p1;
        let m_p1x = m_p1.clone();
        let s_p0x = s_p0.clone();
        crate::prelude::call_then(start_stmt_kids_f(s_p0x.clone(), m_p1x.clone()), move |stmt_kids_f_2661: crate::prelude::Array<Kid>| crate::prelude::fold_job(stmt_kids_f_2661, crate::prelude::Array::from(vec![Spot::SpotStmt(s_p0x.clone(), m_p1x.clone())]), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<Spot>, Kid)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p2 = p0;
            let k_p3 = p1;
            crate::prelude::call_then(start_kid_spots_f(k_p3.clone()), move |kid_spots_f_2721: crate::prelude::Array<Spot>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p2, &kid_spots_f_2721)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<Spot>, Kid)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Spot>>>>).cycle())
    }
}

/// `Start StmtSpots, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_spots_f(s_p0: crate::syntax::Stmt, m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Spot>>> {
    ::std::rc::Rc::new(StmtSpots { s_p0, m_p1 })
}

/// ```prism
/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
/// ```
pub fn body_spots_f(fn_body0: &crate::syntax::decls::FnBody, m_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<Spot> {
    match fn_body0 {
        crate::syntax::decls::FnBody::BodyExpr(e_p0) => expr_spots_f(e_p0, m_p1),
        crate::syntax::decls::FnBody::BodyBlock(b_p2) => stmts_spots_f(&b_p2.stmts_p, m_p1),
    }
}

/// The step machine of `BodySpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
/// ```
pub struct BodySpots {
    pub fn_body0: crate::syntax::decls::FnBody,
    pub m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<crate::prelude::Array<Spot>> for BodySpots {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Spot>> {
        let fn_body0 = &self.fn_body0;
        let m_p1 = &self.m_p1;
        match fn_body0 {
            crate::syntax::decls::FnBody::BodyExpr(e_p0) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExprSpots { e_p0: e_p0.clone(), m_p1: m_p1.clone() })),
            crate::syntax::decls::FnBody::BodyBlock(b_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(StmtsSpots { stmts_p0: b_p2.stmts_p.clone(), m_p1: m_p1.clone() })),
        }
    }
}

/// `Start BodySpots, x`: what the function value is when passed to `@Run`.
pub fn start_body_spots_f(fn_body0: crate::syntax::decls::FnBody, m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Spot>>> {
    ::std::rc::Rc::new(BodySpots { fn_body0, m_p1 })
}

/// ```prism
/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
/// ```
pub fn expr_kids_f(e_p0: &crate::syntax::Expr, m_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<Kid> {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ECall(c_p2, args_p3, _, _) => call_kids_f(&**c_p2, args_p3, m_p1),
        crate::syntax::ExprKind::EMethod(r_p4, n_p5, args_p6) => call_kids_f(&method_callee_f(n_p5), &method_args_f(&**r_p4, args_p6), m_p1),
        crate::syntax::ExprKind::EBinary(_, l_p7, r_p8) => exprs_kids_f(&crate::prelude::Array::from(vec![(**l_p7).clone(), (**r_p8).clone()]), m_p1),
        crate::syntax::ExprKind::ESuffixed(_, _, l_p9, r_pa) => exprs_kids_f(&crate::prelude::Array::from(vec![(**l_p9).clone(), (**r_pa).clone()]), m_p1),
        crate::syntax::ExprKind::EIndex(r_pb, i_pc) => exprs_kids_f(&crate::prelude::Array::from(vec![(**r_pb).clone(), (**i_pc).clone()]), m_p1),
        crate::syntax::ExprKind::EUnary(_, x_pd) => crate::prelude::Array::from(vec![Kid::KidExpr((**x_pd).clone(), m_p1.clone())]),
        crate::syntax::ExprKind::EFreeSigil(_, x_pe) => crate::prelude::Array::from(vec![Kid::KidExpr((**x_pe).clone(), m_p1.clone())]),
        crate::syntax::ExprKind::EField(r_pf, _, _) => crate::prelude::Array::from(vec![Kid::KidExpr((**r_pf).clone(), m_p1.clone())]),
        crate::syntax::ExprKind::ETopicIndex(x_pg) => crate::prelude::Array::from(vec![Kid::KidExpr((**x_pg).clone(), m_p1.clone())]),
        crate::syntax::ExprKind::EGroup(x_ph) => crate::prelude::Array::from(vec![Kid::KidExpr((**x_ph).clone(), m_p1.clone())]),
        crate::syntax::ExprKind::ETypeArgs(x_pi, _) => crate::prelude::Array::from(vec![Kid::KidExpr((**x_pi).clone(), m_p1.clone())]),
        crate::syntax::ExprKind::ECast(x_pj, _, _) => crate::prelude::Array::from(vec![Kid::KidExpr((**x_pj).clone(), m_p1.clone())]),
        crate::syntax::ExprKind::ENonEmpty(x_pk) => crate::prelude::Array::from(vec![Kid::KidExpr((**x_pk).clone(), m_p1.clone())]),
        crate::syntax::ExprKind::EAny(x_pl) => crate::prelude::Array::from(vec![Kid::KidExpr((**x_pl).clone(), m_p1.clone())]),
        crate::syntax::ExprKind::ETuple(es_pm) => exprs_kids_f(es_pm, m_p1),
        crate::syntax::ExprKind::EArray(es_pn) => exprs_kids_f(es_pn, m_p1),
        crate::syntax::ExprKind::EMap(kvs_po) => crate::prelude::fold(kvs_po, &crate::prelude::Array::new(), &(|acc_pp: &crate::prelude::Array<Kid>, (k_pq, v_pr): &(crate::syntax::Expr, crate::syntax::Expr)| crate::prelude::append(acc_pp, &exprs_kids_f(&crate::prelude::Array::from(vec![k_pq.clone(), v_pr.clone()]), m_p1)))),
        crate::syntax::ExprKind::ELit(l_ps) => match &l_ps.kind_p {
            crate::syntax::LitKind::LText(segs_pt) => crate::prelude::fold(segs_pt, &crate::prelude::Array::new(), &(|acc_pu: &crate::prelude::Array<Kid>, sg_pv: &crate::syntax::TextSeg| match sg_pv {
                crate::syntax::TextSeg::SegPlaceholder(x_p10) => crate::prelude::push(acc_pu, &Kid::KidExpr(x_p10.clone(), m_p1.clone())),
                _ => acc_pu.clone(),
            })),
            _ => crate::prelude::Array::new(),
        },
        crate::syntax::ExprKind::ELambda(ps_o11, body_p12) => crate::prelude::Array::from(vec![lambda_kid_f(&**body_p12, &later_f(&crate::check::shrink::relations::hide_f(m_p1, &patterns_names_f(&crate::prelude::or(ps_o11, &crate::prelude::Array::new())))))]),
        crate::syntax::ExprKind::EIf(c_p13, t_p14, el_o15) => {
            let with_then_p16 = crate::prelude::push(&cond_kids_f(&**c_p13, m_p1), &Kid::KidStmts(t_p14.stmts_p.clone(), crate::check::shrink::relations::cond_rels_f(&**c_p13, m_p1)));
            match el_o15 {
                ::std::option::Option::Some(b_p17) => crate::prelude::push(&with_then_p16, &Kid::KidStmts(b_p17.stmts_p.clone(), m_p1.clone())),
                ::std::option::Option::None => with_then_p16.clone(),
            }
        },
        crate::syntax::ExprKind::EMatch(s_p18, arms_p19) => crate::prelude::run_to_end(crate::prelude::fold_job(arms_p19.clone(), crate::prelude::Array::from(vec![Kid::KidExpr((**s_p18).clone(), m_p1.clone())]), {
            let s_p18x = (**s_p18).clone();
            let m_p1x = m_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<Kid>, crate::syntax::Arm)| {
                let s_p18xy = s_p18x.clone();
                let m_p1xy = m_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p1a = p0;
                    let a_p1b = p1;
                    crate::prelude::call_then(crate::check::shrink::relations::start_arm_pat_rels_f(s_p18xy.clone(), a_p1b.clone(), m_p1xy.clone()), move |arm_pat_rels_f_4324: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                        let am_p1c = arm_pat_rels_f_4324;
                        ::prism_rtl::Turn::Finished(crate::prelude::push(&crate::prelude::append(&acc_p1a, &opt_kids_f(&a_p1b.guard_o, &am_p1c)), &Kid::KidStmts(a_p1b.body_p.stmts_p.clone(), am_p1c.clone())))
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<Kid>, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Kid>>>>
        })),
        crate::syntax::ExprKind::ERebuild(s_p1d, b_p1e) => crate::prelude::Array::from(vec![Kid::KidExpr((**s_p1d).clone(), m_p1.clone()), Kid::KidStmts(b_p1e.stmts_p.clone(), later_f(m_p1))]),
        crate::syntax::ExprKind::EUpdate(s_p1f, b_p1g) => crate::prelude::Array::from(vec![Kid::KidExpr((**s_p1f).clone(), m_p1.clone()), Kid::KidStmts(b_p1g.stmts_p.clone(), m_p1.clone())]),
        crate::syntax::ExprKind::EMonad(s_p1h, b_p1i) => crate::prelude::Array::from(vec![Kid::KidExpr((**s_p1h).clone(), m_p1.clone()), Kid::KidStmts(b_p1i.stmts_p.clone(), m_p1.clone())]),
        crate::syntax::ExprKind::EFor(fb_o1j, s_p1k, b_p1l) => {
            let names_p1m = match fb_o1j {
                ::std::option::Option::Some(fb_p1o) => crate::check::types::union_texts_f(&crate::check::env::names::pattern_names_f(&fb_p1o.first_p), &crate::check::shrink::summaries::opt_names_f(&fb_p1o.second_o)),
                ::std::option::Option::None => crate::prelude::Array::new(),
            };
            let in_body_p1n = match fb_o1j {
                ::std::option::Option::Some(fb_p1p) => {
                    let with_first_p1q = crate::check::shrink::relations::bind_rels_f(&fb_p1p.first_p, &part_of_f(&**s_p1k), &crate::check::shrink::relations::hide_f(m_p1, &names_p1m), &false);
                    match &fb_p1p.second_o {
                        ::std::option::Option::Some(p2_p1r) => crate::check::shrink::relations::bind_rels_f(p2_p1r, &part_of_f(&**s_p1k), &with_first_p1q, &false),
                        ::std::option::Option::None => with_first_p1q.clone(),
                    }
                },
                ::std::option::Option::None => crate::check::shrink::relations::hide_f(m_p1, &names_p1m),
            };
            crate::prelude::Array::from(vec![Kid::KidExpr((**s_p1k).clone(), m_p1.clone()), Kid::KidStmts(b_p1l.stmts_p.clone(), in_body_p1n.clone())])
        },
        crate::syntax::ExprKind::EGiven(b_p1s) => crate::prelude::Array::from(vec![Kid::KidStmts(b_p1s.stmts_p.clone(), m_p1.clone())]),
        crate::syntax::ExprKind::EWidgetBlock(b_p1t) => crate::prelude::Array::from(vec![Kid::KidStmts(b_p1t.stmts_p.clone(), later_f(m_p1))]),
        crate::syntax::ExprKind::ETemplate(t_p1u) => template_kids_f(&t_p1u.parts_p, m_p1),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `ExprKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
/// ```
pub struct ExprKids {
    pub e_p0: crate::syntax::Expr,
    pub m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<crate::prelude::Array<Kid>> for ExprKids {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Kid>> {
        let e_p0 = &self.e_p0;
        let m_p1 = &self.m_p1;
        match &*e_p0.kind_p {
            crate::syntax::ExprKind::ECall(c_p2, args_p3, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CallKids { c_p0: (**c_p2).clone(), args_p1: args_p3.clone(), m_p2: m_p1.clone() })),
            crate::syntax::ExprKind::EMethod(r_p4, n_p5, args_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CallKids { c_p0: method_callee_f(n_p5), args_p1: method_args_f(&**r_p4, args_p6), m_p2: m_p1.clone() })),
            crate::syntax::ExprKind::EBinary(_, l_p7, r_p8) => ::prism_rtl::Turn::Finished(exprs_kids_f(&crate::prelude::Array::from(vec![(**l_p7).clone(), (**r_p8).clone()]), m_p1)),
            crate::syntax::ExprKind::ESuffixed(_, _, l_p9, r_pa) => ::prism_rtl::Turn::Finished(exprs_kids_f(&crate::prelude::Array::from(vec![(**l_p9).clone(), (**r_pa).clone()]), m_p1)),
            crate::syntax::ExprKind::EIndex(r_pb, i_pc) => ::prism_rtl::Turn::Finished(exprs_kids_f(&crate::prelude::Array::from(vec![(**r_pb).clone(), (**i_pc).clone()]), m_p1)),
            crate::syntax::ExprKind::EUnary(_, x_pd) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr((**x_pd).clone(), m_p1.clone())])),
            crate::syntax::ExprKind::EFreeSigil(_, x_pe) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr((**x_pe).clone(), m_p1.clone())])),
            crate::syntax::ExprKind::EField(r_pf, _, _) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr((**r_pf).clone(), m_p1.clone())])),
            crate::syntax::ExprKind::ETopicIndex(x_pg) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr((**x_pg).clone(), m_p1.clone())])),
            crate::syntax::ExprKind::EGroup(x_ph) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr((**x_ph).clone(), m_p1.clone())])),
            crate::syntax::ExprKind::ETypeArgs(x_pi, _) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr((**x_pi).clone(), m_p1.clone())])),
            crate::syntax::ExprKind::ECast(x_pj, _, _) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr((**x_pj).clone(), m_p1.clone())])),
            crate::syntax::ExprKind::ENonEmpty(x_pk) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr((**x_pk).clone(), m_p1.clone())])),
            crate::syntax::ExprKind::EAny(x_pl) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr((**x_pl).clone(), m_p1.clone())])),
            crate::syntax::ExprKind::ETuple(es_pm) => ::prism_rtl::Turn::Finished(exprs_kids_f(es_pm, m_p1)),
            crate::syntax::ExprKind::EArray(es_pn) => ::prism_rtl::Turn::Finished(exprs_kids_f(es_pn, m_p1)),
            crate::syntax::ExprKind::EMap(kvs_po) => ::prism_rtl::Turn::Finished(crate::prelude::fold(kvs_po, &crate::prelude::Array::new(), &(|acc_pp: &crate::prelude::Array<Kid>, (k_pq, v_pr): &(crate::syntax::Expr, crate::syntax::Expr)| crate::prelude::append(acc_pp, &exprs_kids_f(&crate::prelude::Array::from(vec![k_pq.clone(), v_pr.clone()]), m_p1))))),
            crate::syntax::ExprKind::ELit(l_ps) => match &l_ps.kind_p {
                crate::syntax::LitKind::LText(segs_pt) => ::prism_rtl::Turn::Finished(crate::prelude::fold(segs_pt, &crate::prelude::Array::new(), &(|acc_pu: &crate::prelude::Array<Kid>, sg_pv: &crate::syntax::TextSeg| match sg_pv {
                    crate::syntax::TextSeg::SegPlaceholder(x_p10) => crate::prelude::push(acc_pu, &Kid::KidExpr(x_p10.clone(), m_p1.clone())),
                    _ => acc_pu.clone(),
                }))),
                _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
            },
            crate::syntax::ExprKind::ELambda(ps_o11, body_p12) => {
                let ps_o11x = ps_o11.clone();
                let body_p12x = (**body_p12).clone();
                let m_p1x = m_p1.clone();
                crate::prelude::call_then(start_patterns_names_f(crate::prelude::or(&ps_o11x, &crate::prelude::Array::new())), move |patterns_names_f_4012: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![lambda_kid_f(&body_p12x, &later_f(&crate::check::shrink::relations::hide_f(&m_p1x, &patterns_names_f_4012)))])))
            },
            crate::syntax::ExprKind::EIf(c_p13, t_p14, el_o15) => {
                let el_o15x = el_o15.clone();
                let c_p13x = (**c_p13).clone();
                let m_p1x = m_p1.clone();
                let t_p14x = t_p14.clone();
                crate::prelude::call_then(start_cond_kids_f(c_p13x.clone(), m_p1x.clone()), move |cond_kids_f_4095: crate::prelude::Array<Kid>| crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_p13x.clone(), m_p1x.clone()), move |cond_rels_f_4131: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                    let with_then_p16 = crate::prelude::push(&cond_kids_f_4095, &Kid::KidStmts(t_p14x.stmts_p.clone(), cond_rels_f_4131));
                    match &el_o15x {
                        ::std::option::Option::Some(b_p17) => ::prism_rtl::Turn::Finished(crate::prelude::push(&with_then_p16, &Kid::KidStmts(b_p17.stmts_p.clone(), m_p1x.clone()))),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(with_then_p16.clone()),
                    }
                }))
            },
            crate::syntax::ExprKind::EMatch(s_p18, arms_p19) => crate::prelude::fold_job(arms_p19.clone(), crate::prelude::Array::from(vec![Kid::KidExpr((**s_p18).clone(), m_p1.clone())]), {
                let s_p18x = (**s_p18).clone();
                let m_p1x = m_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<Kid>, crate::syntax::Arm)| {
                    let s_p18xy = s_p18x.clone();
                    let m_p1xy = m_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p1a = p0;
                        let a_p1b = p1;
                        crate::prelude::call_then(crate::check::shrink::relations::start_arm_pat_rels_f(s_p18xy.clone(), a_p1b.clone(), m_p1xy.clone()), move |arm_pat_rels_f_4324: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                            let am_p1c = arm_pat_rels_f_4324;
                            ::prism_rtl::Turn::Finished(crate::prelude::push(&crate::prelude::append(&acc_p1a, &opt_kids_f(&a_p1b.guard_o, &am_p1c)), &Kid::KidStmts(a_p1b.body_p.stmts_p.clone(), am_p1c.clone())))
                        })
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<Kid>, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Kid>>>>
            }).cycle(),
            crate::syntax::ExprKind::ERebuild(s_p1d, b_p1e) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr((**s_p1d).clone(), m_p1.clone()), Kid::KidStmts(b_p1e.stmts_p.clone(), later_f(m_p1))])),
            crate::syntax::ExprKind::EUpdate(s_p1f, b_p1g) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr((**s_p1f).clone(), m_p1.clone()), Kid::KidStmts(b_p1g.stmts_p.clone(), m_p1.clone())])),
            crate::syntax::ExprKind::EMonad(s_p1h, b_p1i) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr((**s_p1h).clone(), m_p1.clone()), Kid::KidStmts(b_p1i.stmts_p.clone(), m_p1.clone())])),
            crate::syntax::ExprKind::EFor(fb_o1j, s_p1k, b_p1l) => {
                let fb_o1jz = fb_o1j.clone();
                let b_p1lz = b_p1l.clone();
                let m_p1z = m_p1.clone();
                let s_p1kz = (**s_p1k).clone();
                let k_let4638 = move |v4638: crate::prelude::Array<crate::prelude::Text>| {
                    let names_p1m = v4638;
                    let b_p1lzz = b_p1lz.clone();
                    let m_p1zz = m_p1z.clone();
                    let s_p1kzz = s_p1kz.clone();
                    let k_let4970 = move |v4970: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                        let in_body_p1n = v4970;
                        ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr(s_p1kzz.clone(), m_p1zz.clone()), Kid::KidStmts(b_p1lzz.stmts_p.clone(), in_body_p1n.clone())]))
                    };
                    match fb_o1jz.clone() {
                        ::std::option::Option::Some(fb_p1p) => crate::prelude::call_then(crate::check::shrink::relations::start_bind_rels_f(fb_p1p.first_p.clone(), part_of_f(&s_p1kz), crate::check::shrink::relations::hide_f(&m_p1z, &names_p1m), false), move |bind_rels_f_5044: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                            let with_first_p1q = bind_rels_f_5044;
                            match fb_p1p.second_o.clone() {
                                ::std::option::Option::Some(p2_p1r) => crate::prelude::call_then(crate::check::shrink::relations::start_bind_rels_f(p2_p1r.clone(), part_of_f(&s_p1kz), with_first_p1q.clone(), false), move |bind_rels_f_5158: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| k_let4970(bind_rels_f_5158)),
                                ::std::option::Option::None => k_let4970(with_first_p1q.clone()),
                            }
                        }),
                        ::std::option::Option::None => k_let4970(crate::check::shrink::relations::hide_f(&m_p1z, &names_p1m)),
                    }
                };
                match fb_o1j.clone() {
                    ::std::option::Option::Some(fb_p1o) => {
                        let fb_o1jx = fb_o1j.clone();
                        crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(fb_p1o.first_p.clone()), move |pattern_names_f_4691: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(crate::check::shrink::summaries::start_opt_names_f(fb_p1o.second_o.clone()), move |opt_names_f_4716: crate::prelude::Array<crate::prelude::Text>| k_let4638(crate::check::types::union_texts_f(&pattern_names_f_4691, &opt_names_f_4716))))
                    },
                    ::std::option::Option::None => k_let4638(crate::prelude::Array::new()),
                }
            },
            crate::syntax::ExprKind::EGiven(b_p1s) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidStmts(b_p1s.stmts_p.clone(), m_p1.clone())])),
            crate::syntax::ExprKind::EWidgetBlock(b_p1t) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidStmts(b_p1t.stmts_p.clone(), later_f(m_p1))])),
            crate::syntax::ExprKind::ETemplate(t_p1u) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TemplateKids { parts_p0: t_p1u.parts_p.clone(), m_p1: m_p1.clone() })),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start ExprKids, x`: what the function value is when passed to `@Run`.
pub fn start_expr_kids_f(e_p0: crate::syntax::Expr, m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Kid>>> {
    ::std::rc::Rc::new(ExprKids { e_p0, m_p1 })
}

/// ```prism
/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
/// ```
pub fn stmt_kids_f(s_p0: &crate::syntax::Stmt, m_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<Kid> {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SBind(_, e_p2, t_o3) => crate::prelude::append(&crate::prelude::Array::from(vec![Kid::KidExpr(e_p2.clone(), m_p1.clone())]), &opt_kids_f(t_o3, m_p1)),
        crate::syntax::StmtKind::SIgnore(e_p4) => crate::prelude::Array::from(vec![Kid::KidExpr(e_p4.clone(), m_p1.clone())]),
        crate::syntax::StmtKind::SLet(_, _, e_p5) => crate::prelude::Array::from(vec![Kid::KidExpr(e_p5.clone(), m_p1.clone())]),
        crate::syntax::StmtKind::SFn(f_p6) => crate::prelude::Array::from(vec![body_kid_f(&f_p6.body_p, &later_f(&crate::check::shrink::relations::hide_f(m_p1, &patterns_names_f(&f_p6.params_p))))]),
        crate::syntax::StmtKind::SWidget(w_p7) => crate::prelude::Array::from(vec![Kid::KidStmts(w_p7.body_p.stmts_p.clone(), later_f(m_p1))]),
        crate::syntax::StmtKind::SSet(t_p8, v_p9) => exprs_kids_f(&crate::prelude::Array::from(vec![t_p8.clone(), v_p9.clone()]), m_p1),
        crate::syntax::StmtKind::SAccum(t_pa, _, v_pb) => exprs_kids_f(&crate::prelude::Array::from(vec![t_pa.clone(), v_pb.clone()]), m_p1),
        crate::syntax::StmtKind::SRequire(c_pc) => crate::prelude::Array::from(vec![Kid::KidExpr(c_pc.clone(), m_p1.clone())]),
        crate::syntax::StmtKind::SForbid(c_pd) => crate::prelude::Array::from(vec![Kid::KidExpr(c_pd.clone(), m_p1.clone())]),
        crate::syntax::StmtKind::SReturn(e_pe) => crate::prelude::Array::from(vec![Kid::KidExpr(e_pe.clone(), m_p1.clone())]),
        crate::syntax::StmtKind::SWhile(c_pf, b_pg) => crate::prelude::push(&cond_kids_f(c_pf, m_p1), &Kid::KidStmts(b_pg.stmts_p.clone(), crate::check::shrink::relations::cond_rels_f(c_pf, m_p1))),
        crate::syntax::StmtKind::SExpr(e_ph) => crate::prelude::Array::from(vec![Kid::KidExpr(e_ph.clone(), m_p1.clone())]),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `StmtKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
/// ```
pub struct StmtKids {
    pub s_p0: crate::syntax::Stmt,
    pub m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<crate::prelude::Array<Kid>> for StmtKids {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Kid>> {
        let s_p0 = &self.s_p0;
        let m_p1 = &self.m_p1;
        match &s_p0.kind_p {
            crate::syntax::StmtKind::SBind(_, e_p2, t_o3) => ::prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::Array::from(vec![Kid::KidExpr(e_p2.clone(), m_p1.clone())]), &opt_kids_f(t_o3, m_p1))),
            crate::syntax::StmtKind::SIgnore(e_p4) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr(e_p4.clone(), m_p1.clone())])),
            crate::syntax::StmtKind::SLet(_, _, e_p5) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr(e_p5.clone(), m_p1.clone())])),
            crate::syntax::StmtKind::SFn(f_p6) => {
                let f_p6x = f_p6.clone();
                let m_p1x = m_p1.clone();
                crate::prelude::call_then(start_patterns_names_f(f_p6x.params_p.clone()), move |patterns_names_f_5759: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![body_kid_f(&f_p6x.body_p, &later_f(&crate::check::shrink::relations::hide_f(&m_p1x, &patterns_names_f_5759)))])))
            },
            crate::syntax::StmtKind::SWidget(w_p7) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidStmts(w_p7.body_p.stmts_p.clone(), later_f(m_p1))])),
            crate::syntax::StmtKind::SSet(t_p8, v_p9) => ::prism_rtl::Turn::Finished(exprs_kids_f(&crate::prelude::Array::from(vec![t_p8.clone(), v_p9.clone()]), m_p1)),
            crate::syntax::StmtKind::SAccum(t_pa, _, v_pb) => ::prism_rtl::Turn::Finished(exprs_kids_f(&crate::prelude::Array::from(vec![t_pa.clone(), v_pb.clone()]), m_p1)),
            crate::syntax::StmtKind::SRequire(c_pc) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr(c_pc.clone(), m_p1.clone())])),
            crate::syntax::StmtKind::SForbid(c_pd) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr(c_pd.clone(), m_p1.clone())])),
            crate::syntax::StmtKind::SReturn(e_pe) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr(e_pe.clone(), m_p1.clone())])),
            crate::syntax::StmtKind::SWhile(c_pf, b_pg) => {
                let b_pgx = b_pg.clone();
                let c_pfx = c_pf.clone();
                let m_p1x = m_p1.clone();
                crate::prelude::call_then(start_cond_kids_f(c_pfx.clone(), m_p1x.clone()), move |cond_kids_f_6052: crate::prelude::Array<Kid>| crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_pfx.clone(), m_p1x.clone()), move |cond_rels_f_6088: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::Finished(crate::prelude::push(&cond_kids_f_6052, &Kid::KidStmts(b_pgx.stmts_p.clone(), cond_rels_f_6088)))))
            },
            crate::syntax::StmtKind::SExpr(e_ph) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr(e_ph.clone(), m_p1.clone())])),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start StmtKids, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_kids_f(s_p0: crate::syntax::Stmt, m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Kid>>> {
    ::std::rc::Rc::new(StmtKids { s_p0, m_p1 })
}

/// ```prism
/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
/// ```
pub fn cond_kids_f(c_p0: &crate::syntax::Cond, m_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<Kid> {
    match c_p0 {
        crate::syntax::Cond::CondExpr(x_p2) => crate::prelude::Array::from(vec![Kid::KidExpr((**x_p2).clone(), m_p1.clone())]),
        crate::syntax::Cond::CondBind(_, x_p3, g_o4) => crate::prelude::append(&crate::prelude::Array::from(vec![Kid::KidExpr((**x_p3).clone(), m_p1.clone())]), &opt_kids_f(&**g_o4, &crate::check::shrink::relations::cond_rels_f(c_p0, m_p1))),
    }
}

/// The step machine of `CondKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
/// ```
pub struct CondKids {
    pub c_p0: crate::syntax::Cond,
    pub m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<crate::prelude::Array<Kid>> for CondKids {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Kid>> {
        let c_p0 = &self.c_p0;
        let m_p1 = &self.m_p1;
        match c_p0 {
            crate::syntax::Cond::CondExpr(x_p2) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr((**x_p2).clone(), m_p1.clone())])),
            crate::syntax::Cond::CondBind(_, x_p3, g_o4) => {
                let g_o4x = (**g_o4).clone();
                let c_p0x = c_p0.clone();
                let m_p1x = m_p1.clone();
                let x_p3x = (**x_p3).clone();
                crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_p0x.clone(), m_p1x.clone()), move |cond_rels_f_6428: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::Array::from(vec![Kid::KidExpr(x_p3x.clone(), m_p1x.clone())]), &opt_kids_f(&g_o4x, &cond_rels_f_6428))))
            },
        }
    }
}

/// `Start CondKids, x`: what the function value is when passed to `@Run`.
pub fn start_cond_kids_f(c_p0: crate::syntax::Cond, m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Kid>>> {
    ::std::rc::Rc::new(CondKids { c_p0, m_p1 })
}

/// ```prism
/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
/// ```
pub fn call_kids_f(c_p0: &crate::syntax::Expr, args_p1: &crate::prelude::Array<crate::syntax::Arg>, m_p2: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<Kid> {
    let callee_p3 = match callee_name_o(c_p0) {
        ::std::option::Option::Some(_) => crate::prelude::Array::new(),
        ::std::option::Option::None => crate::prelude::Array::from(vec![Kid::KidExpr(c_p0.clone(), m_p2.clone())]),
    };
    match traversal_of_o(m_p2, c_p0, args_p1) {
        ::std::option::Option::None => match acc_callee_o(m_p2, c_p0, args_p1) {
            ::std::option::Option::Some(cn_p4) => crate::prelude::append(&callee_p3, &crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(args_p1)), crate::prelude::Array::new(), {
                let m_p2x = m_p2.clone();
                let cn_p4x = cn_p4.clone();
                let args_p1x = args_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<Kid>, crate::prelude::Nat)| {
                    let m_p2xy = m_p2x.clone();
                    let cn_p4xy = cn_p4x.clone();
                    let args_p1xy = args_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p5 = p0;
                        let i_p6 = p1;
                        crate::prelude::call_then(start_acc_kids_f(m_p2xy.clone(), cn_p4xy.clone(), args_p1xy.clone(), i_p6.clone()), move |acc_kids_f_7288: crate::prelude::Array<Kid>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &acc_kids_f_7288)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<Kid>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Kid>>>>
            }))),
            ::std::option::Option::None => crate::prelude::append(&callee_p3, &exprs_kids_f(&crate::prelude::each(args_p1, &(|a_p7: &crate::syntax::Arg| a_p7.value_p.clone())), m_p2)),
        },
        ::std::option::Option::Some((coll_p8, step_p9, at_pa)) => {
            let others_pb = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(args_p1)), &callee_p3, &(|acc_pc: &crate::prelude::Array<Kid>, i_pd: &crate::prelude::Nat| if i_pd == &(&at_pa + &crate::prelude::Nat::from(1u32)) {
                acc_pc.clone()
            } else {
                match crate::prelude::index(args_p1, i_pd) {
                    ::std::option::Option::Some(a_pe) => crate::prelude::push(acc_pc, &Kid::KidExpr(a_pe.value_p.clone(), m_p2.clone())),
                    ::std::option::Option::None => acc_pc.clone(),
                }
            }));
            match &*step_p9.kind_p {
                crate::syntax::ExprKind::ELambda(::std::option::Option::Some(ps_pf), body_pg) => crate::prelude::push(&others_pb, &lambda_kid_f(&**body_pg, &crate::check::shrink::relations::step_rels_f(m_p2, &coll_p8, ps_pf, &at_pa))),
                crate::syntax::ExprKind::EName(_) => others_pb.clone(),
                _ => crate::prelude::push(&others_pb, &Kid::KidExpr(step_p9.clone(), m_p2.clone())),
            }
        },
    }
}

/// The step machine of `CallKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
/// ```
pub struct CallKids {
    pub c_p0: crate::syntax::Expr,
    pub args_p1: crate::prelude::Array<crate::syntax::Arg>,
    pub m_p2: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<crate::prelude::Array<Kid>> for CallKids {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Kid>> {
        let c_p0 = &self.c_p0;
        let args_p1 = &self.args_p1;
        let m_p2 = &self.m_p2;
        let callee_p3 = match callee_name_o(c_p0) {
            ::std::option::Option::Some(_) => crate::prelude::Array::new(),
            ::std::option::Option::None => crate::prelude::Array::from(vec![Kid::KidExpr(c_p0.clone(), m_p2.clone())]),
        };
        match traversal_of_o(m_p2, c_p0, args_p1) {
            ::std::option::Option::None => match acc_callee_o(m_p2, c_p0, args_p1) {
                ::std::option::Option::Some(cn_p4) => {
                    let args_p1x = args_p1.clone();
                    let m_p2x = m_p2.clone();
                    crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&args_p1x)), crate::prelude::Array::new(), {
                        let m_p2xx = m_p2x.clone();
                        let cn_p4x = cn_p4.clone();
                        let args_p1xx = args_p1x.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<Kid>, crate::prelude::Nat)| {
                            let m_p2xxy = m_p2xx.clone();
                            let cn_p4xy = cn_p4x.clone();
                            let args_p1xxy = args_p1xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_p5 = p0;
                                let i_p6 = p1;
                                crate::prelude::call_then(start_acc_kids_f(m_p2xxy.clone(), cn_p4xy.clone(), args_p1xxy.clone(), i_p6.clone()), move |acc_kids_f_7288: crate::prelude::Array<Kid>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &acc_kids_f_7288)))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<Kid>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Kid>>>>
                    }), move |fold_7233: crate::prelude::Array<Kid>| ::prism_rtl::Turn::Finished(crate::prelude::append(&callee_p3, &fold_7233)))
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::append(&callee_p3, &exprs_kids_f(&crate::prelude::each(args_p1, &(|a_p7: &crate::syntax::Arg| a_p7.value_p.clone())), m_p2))),
            },
            ::std::option::Option::Some((coll_p8, step_p9, at_pa)) => {
                let others_pb = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(args_p1)), &callee_p3, &(|acc_pc: &crate::prelude::Array<Kid>, i_pd: &crate::prelude::Nat| if i_pd == &(&at_pa + &crate::prelude::Nat::from(1u32)) {
                    acc_pc.clone()
                } else {
                    match crate::prelude::index(args_p1, i_pd) {
                        ::std::option::Option::Some(a_pe) => crate::prelude::push(acc_pc, &Kid::KidExpr(a_pe.value_p.clone(), m_p2.clone())),
                        ::std::option::Option::None => acc_pc.clone(),
                    }
                }));
                match &*step_p9.kind_p {
                    crate::syntax::ExprKind::ELambda(::std::option::Option::Some(ps_pf), body_pg) => {
                        let body_pgx = (**body_pg).clone();
                        let m_p2x = m_p2.clone();
                        let ps_pfx = ps_pf.clone();
                        crate::prelude::call_then(crate::check::shrink::relations::start_step_rels_f(m_p2x.clone(), coll_p8.clone(), ps_pfx.clone(), at_pa.clone()), move |step_rels_f_7701: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::Finished(crate::prelude::push(&others_pb, &lambda_kid_f(&body_pgx, &step_rels_f_7701))))
                    },
                    crate::syntax::ExprKind::EName(_) => ::prism_rtl::Turn::Finished(others_pb.clone()),
                    _ => ::prism_rtl::Turn::Finished(crate::prelude::push(&others_pb, &Kid::KidExpr(step_p9.clone(), m_p2.clone()))),
                }
            },
        }
    }
}

/// `Start CallKids, x`: what the function value is when passed to `@Run`.
pub fn start_call_kids_f(c_p0: crate::syntax::Expr, args_p1: crate::prelude::Array<crate::syntax::Arg>, m_p2: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Kid>>> {
    ::std::rc::Rc::new(CallKids { c_p0, args_p1, m_p2 })
}

/// ```prism
/// Later: fn (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn later_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel> {
    crate::prelude::insert(m_p0, &crate::prelude::Text::lit("lam:"), &crate::check::shrink::relations::no_rel_p())
}

/// ```prism
/// ?AccCallee: fn (Text ==> Rel), Expr, [Arg] -> ?Text
/// ```
pub fn acc_callee_o(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, c_p1: &crate::syntax::Expr, args_p2: &crate::prelude::Array<crate::syntax::Arg>) -> ::std::option::Option<crate::prelude::Text> {
    match callee_name_o(c_p1) {
        ::std::option::Option::Some(cn_p3) => if crate::check::shrink::relations::is_local_f(m_p0, &cn_p3) {
            ::std::option::Option::None
        } else {
            if !crate::prelude::fold(args_p2, &true, &(|ok_p4: &bool, a_p5: &crate::syntax::Arg| *ok_p4 && (&a_p5.name_o == &::std::option::Option::None))) {
                ::std::option::Option::None
            } else {
                if crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(args_p2)), &false, &(|seen_p6: &bool, i_p7: &crate::prelude::Nat| *seen_p6 || crate::check::env::has_key_f(m_p0, &crate::prelude::Text::from(format!("acc:{}:{}", &cn_p3, i_p7))))) {
                    ::std::option::Option::Some(cn_p3.clone())
                } else {
                    ::std::option::Option::None
                }
            }
        },
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
/// ```
pub fn acc_kids_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, cn_p1: &crate::prelude::Text, args_p2: &crate::prelude::Array<crate::syntax::Arg>, i_p3: &crate::prelude::Nat) -> crate::prelude::Array<Kid> {
    let a_p4 = crate::prelude::or(&crate::prelude::index(args_p2, i_p3), &crate::check::shrink::summaries::dummy_arg_p());
    if !crate::check::env::has_key_f(m_p0, &crate::prelude::Text::from(format!("acc:{}:{}", cn_p1, i_p3))) {
        crate::prelude::Array::from(vec![Kid::KidExpr(a_p4.value_p.clone(), m_p0.clone())])
    } else {
        match &*a_p4.value_p.kind_p {
            crate::syntax::ExprKind::ELambda(ps_o5, body_p6) => crate::prelude::Array::from(vec![lambda_kid_f(&**body_p6, &acc_lambda_rels_f(m_p0, cn_p1, i_p3, &crate::prelude::or(ps_o5, &crate::prelude::Array::new()), args_p2))]),
            crate::syntax::ExprKind::EName(_) => crate::prelude::Array::new(),
            _ => crate::prelude::Array::from(vec![Kid::KidExpr(a_p4.value_p.clone(), m_p0.clone())]),
        }
    }
}

/// The step machine of `AccKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
/// ```
pub struct AccKids {
    pub m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub cn_p1: crate::prelude::Text,
    pub args_p2: crate::prelude::Array<crate::syntax::Arg>,
    pub i_p3: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Array<Kid>> for AccKids {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Kid>> {
        let m_p0 = &self.m_p0;
        let cn_p1 = &self.cn_p1;
        let args_p2 = &self.args_p2;
        let i_p3 = &self.i_p3;
        let a_p4 = crate::prelude::or(&crate::prelude::index(args_p2, i_p3), &crate::check::shrink::summaries::dummy_arg_p());
        if !crate::check::env::has_key_f(m_p0, &crate::prelude::Text::from(format!("acc:{}:{}", cn_p1, i_p3))) {
            ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr(a_p4.value_p.clone(), m_p0.clone())]))
        } else {
            match &*a_p4.value_p.kind_p {
                crate::syntax::ExprKind::ELambda(ps_o5, body_p6) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![lambda_kid_f(&**body_p6, &acc_lambda_rels_f(m_p0, cn_p1, i_p3, &crate::prelude::or(ps_o5, &crate::prelude::Array::new()), args_p2))])),
                crate::syntax::ExprKind::EName(_) => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
                _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Kid::KidExpr(a_p4.value_p.clone(), m_p0.clone())])),
            }
        }
    }
}

/// `Start AccKids, x`: what the function value is when passed to `@Run`.
pub fn start_acc_kids_f(m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, cn_p1: crate::prelude::Text, args_p2: crate::prelude::Array<crate::syntax::Arg>, i_p3: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Kid>>> {
    ::std::rc::Rc::new(AccKids { m_p0, cn_p1, args_p2, i_p3 })
}

/// ```prism
/// AccLambdaRels: unbounded fn (Text ==> Rel), Text, Nat, [Pattern], [Arg] -> (Text ==> Rel)
/// ```
pub fn acc_lambda_rels_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, cn_p1: &crate::prelude::Text, j_p2: &crate::prelude::Nat, ps_p3: &crate::prelude::Array<crate::syntax::Pattern>, args_p4: &crate::prelude::Array<crate::syntax::Arg>) -> crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel> {
    let h_p5 = crate::check::shrink::relations::hide_f(m_p0, &patterns_names_f(ps_p3));
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p3)), h_p5.clone(), {
        let m_p0x = m_p0.clone();
        let cn_p1x = cn_p1.clone();
        let j_p2x = j_p2.clone();
        let ps_p3x = ps_p3.clone();
        let args_p4x = args_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, crate::prelude::Nat)| {
            let m_p0xy = m_p0x.clone();
            let cn_p1xy = cn_p1x.clone();
            let j_p2xy = j_p2x.clone();
            let ps_p3xy = ps_p3x.clone();
            let args_p4xy = args_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m2_p6 = p0;
                let q_p7 = p1;
                match (crate::prelude::get(&m_p0xy, &crate::prelude::Text::from(format!("sum:{}:{}:{}", &cn_p1xy, &j_p2xy, &q_p7))), crate::prelude::index(&ps_p3xy, &q_p7)) {
                    (::std::option::Option::Some(s_p8), ::std::option::Option::Some(p_p9)) => if &s_p8.param_p == &top_param_p() {
                        ::prism_rtl::Turn::Finished(m2_p6.clone())
                    } else {
                        match crate::prelude::index(&args_p4xy, &s_p8.param_p) {
                            ::std::option::Option::Some(a_pa) => crate::prelude::call_then(start_rel_of_o(m_p0xy.clone(), a_pa.value_p.clone()), move |rel_of_o_9689: ::std::option::Option<crate::check::shrink::Rel>| match rel_of_o_9689 {
                                ::std::option::Option::Some(r_pb) => match &*p_p9.kind_p {
                                    crate::syntax::PatternKind::PName(n_pc) => ::prism_rtl::Turn::Finished(crate::prelude::insert(&m2_p6, &crate::check::env::sname_key_f(n_pc), &crate::check::shrink::Rel { param_p: r_pb.param_p.clone(), strict_p: r_pb.strict_p || s_p8.strict_p })),
                                    _ => crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p9.clone()), move |pattern_names_f_9884: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&pattern_names_f_9884, &m2_p6, &(|m3_pd: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, n_pe: &crate::prelude::Text| crate::prelude::insert(m3_pd, n_pe, &crate::check::shrink::Rel { param_p: r_pb.param_p.clone(), strict_p: true }))))),
                                },
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(m2_p6.clone()),
                            }),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(m2_p6.clone()),
                        }
                    },
                    _ => ::prism_rtl::Turn::Finished(m2_p6.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>>>
    }))
}

/// ```prism
/// let topParam
/// ```
pub fn top_param_p() -> crate::prelude::Nat {
    crate::prelude::Nat::from(9999u32)
}

/// ```prism
/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
/// ```
pub fn template_kids_f(parts_p0: &crate::prelude::Array<crate::syntax::TemplatePart>, m_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<Kid> {
    crate::prelude::fold(parts_p0, &crate::prelude::Array::new(), &(|acc_p2: &crate::prelude::Array<Kid>, p_p3: &crate::syntax::TemplatePart| match p_p3 {
        crate::syntax::TemplatePart::TpPlaceholder(x_p4, _) => crate::prelude::push(acc_p2, &Kid::KidExpr(x_p4.clone(), m_p1.clone())),
        crate::syntax::TemplatePart::TpBlock(b_p5) => crate::prelude::push(acc_p2, &Kid::KidStmts(b_p5.stmts_p.clone(), m_p1.clone())),
        crate::syntax::TemplatePart::TpCall(n_p6, args_p7, ps_o8, span_p9) => crate::prelude::push(acc_p2, &Kid::KidExpr(template_call_expr_f(n_p6, args_p7, ps_o8, span_p9), m_p1.clone())),
        _ => acc_p2.clone(),
    }))
}

/// The step machine of `TemplateKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
/// ```
pub struct TemplateKids {
    pub parts_p0: crate::prelude::Array<crate::syntax::TemplatePart>,
    pub m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<crate::prelude::Array<Kid>> for TemplateKids {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Kid>> {
        let parts_p0 = &self.parts_p0;
        let m_p1 = &self.m_p1;
        ::prism_rtl::Turn::Finished(crate::prelude::fold(parts_p0, &crate::prelude::Array::new(), &(|acc_p2: &crate::prelude::Array<Kid>, p_p3: &crate::syntax::TemplatePart| match p_p3 {
            crate::syntax::TemplatePart::TpPlaceholder(x_p4, _) => crate::prelude::push(acc_p2, &Kid::KidExpr(x_p4.clone(), m_p1.clone())),
            crate::syntax::TemplatePart::TpBlock(b_p5) => crate::prelude::push(acc_p2, &Kid::KidStmts(b_p5.stmts_p.clone(), m_p1.clone())),
            crate::syntax::TemplatePart::TpCall(n_p6, args_p7, ps_o8, span_p9) => crate::prelude::push(acc_p2, &Kid::KidExpr(template_call_expr_f(n_p6, args_p7, ps_o8, span_p9), m_p1.clone())),
            _ => acc_p2.clone(),
        })))
    }
}

/// `Start TemplateKids, x`: what the function value is when passed to `@Run`.
pub fn start_template_kids_f(parts_p0: crate::prelude::Array<crate::syntax::TemplatePart>, m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Kid>>> {
    ::std::rc::Rc::new(TemplateKids { parts_p0, m_p1 })
}

/// ```prism
/// TemplateCallExpr: fn SName, [Arg], ?[TemplatePart], Range -> Expr
/// ```
pub fn template_call_expr_f(n_p0: &crate::syntax::SName, args_p1: &crate::prelude::Array<crate::syntax::Arg>, ps_o2: &::std::option::Option<crate::prelude::Array<crate::syntax::TemplatePart>>, span_p3: &crate::syntax::Range) -> crate::syntax::Expr {
    let body_p4 = match ps_o2 {
        ::std::option::Option::Some(ps_p5) => crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::Some(crate::syntax::Ident { name_p: crate::prelude::Text::lit("#body"), span_p: span_p3.clone() }), value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETemplate(crate::syntax::Template { keyword_p: crate::prelude::Text::lit("InlineText"), lang_p: crate::prelude::Text::lit(""), delims_p: crate::prelude::Text::lit("double"), parts_p: ps_p5.clone(), span_p: span_p3.clone() })), span_p: span_p3.clone() }, span_p: span_p3.clone() }]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ECall(::std::rc::Rc::new(crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EName(n_p0.clone())), span_p: n_p0.span_p.clone() }), crate::prelude::append(args_p1, &body_p4), false, false)), span_p: span_p3.clone() }
}

/// ```prism
/// ArgOf: fn Expr -> Arg
/// ```
pub fn arg_of_f(x_p0: &crate::syntax::Expr) -> crate::syntax::Arg {
    crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: x_p0.clone(), span_p: x_p0.span_p.clone() }
}

/// ```prism
/// ExprsKids: fn [Expr], (Text ==> Rel) -> [Kid]
/// ```
pub fn exprs_kids_f(xs_p0: &crate::prelude::Array<crate::syntax::Expr>, m_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<Kid> {
    crate::prelude::each(xs_p0, &(|x_p2: &crate::syntax::Expr| Kid::KidExpr(x_p2.clone(), m_p1.clone())))
}

/// ```prism
/// OptKids: fn ?Expr, (Text ==> Rel) -> [Kid]
/// ```
pub fn opt_kids_f(opt0: &::std::option::Option<crate::syntax::Expr>, map1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<Kid> {
    match (opt0, map1) {
        (::std::option::Option::Some(x_p0), m_p1) => crate::prelude::Array::from(vec![Kid::KidExpr(x_p0.clone(), m_p1.clone())]),
        (::std::option::Option::None, _) => crate::prelude::Array::new(),
    }
}

/// ```prism
/// LambdaKid: fn LambdaBody, (Text ==> Rel) -> Kid
/// ```
pub fn lambda_kid_f(lambda_body0: &crate::syntax::LambdaBody, m_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> Kid {
    match lambda_body0 {
        crate::syntax::LambdaBody::LbExpr(x_p0) => Kid::KidExpr((**x_p0).clone(), m_p1.clone()),
        crate::syntax::LambdaBody::LbBlock(b_p2) => Kid::KidStmts(b_p2.stmts_p.clone(), m_p1.clone()),
    }
}

/// ```prism
/// BodyKid: fn FnBody, (Text ==> Rel) -> Kid
/// ```
pub fn body_kid_f(fn_body0: &crate::syntax::decls::FnBody, m_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> Kid {
    match fn_body0 {
        crate::syntax::decls::FnBody::BodyExpr(x_p0) => Kid::KidExpr(x_p0.clone(), m_p1.clone()),
        crate::syntax::decls::FnBody::BodyBlock(b_p2) => Kid::KidStmts(b_p2.stmts_p.clone(), m_p1.clone()),
    }
}

/// ```prism
/// PatternsNames: unbounded fn [Pattern] -> [Text]
/// ```
pub fn patterns_names_f(ps_p0: &crate::prelude::Array<crate::syntax::Pattern>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::run_to_end(crate::prelude::fold_job(ps_p0.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
        let a_p1 = p0;
        let p_p2 = p1;
        crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p2.clone()), move |pattern_names_f_11865: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&a_p1, &pattern_names_f_11865)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>))
}

/// The step machine of `PatternsNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatternsNames: unbounded fn [Pattern] -> [Text]
/// ```
pub struct PatternsNames {
    pub ps_p0: crate::prelude::Array<crate::syntax::Pattern>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for PatternsNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let ps_p0 = &self.ps_p0;
        crate::prelude::fold_job(ps_p0.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_p1 = p0;
            let p_p2 = p1;
            crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p2.clone()), move |pattern_names_f_11865: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&a_p1, &pattern_names_f_11865)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle()
    }
}

/// `Start PatternsNames, x`: what the function value is when passed to `@Run`.
pub fn start_patterns_names_f(ps_p0: crate::prelude::Array<crate::syntax::Pattern>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(PatternsNames { ps_p0 })
}

/// ```prism
/// ?CalleeName: fn Expr -> ?Text
/// ```
pub fn callee_name_o(c_p0: &crate::syntax::Expr) -> ::std::option::Option<crate::prelude::Text> {
    match &*c_p0.kind_p {
        crate::syntax::ExprKind::EName(n_p1) => ::std::option::Option::Some(crate::check::env::sname_key_f(n_p1)),
        crate::syntax::ExprKind::ETypeArgs(t_p2, _) => match &*t_p2.kind_p {
            crate::syntax::ExprKind::EName(n_p3) => ::std::option::Option::Some(crate::check::env::sname_key_f(n_p3)),
            _ => ::std::option::Option::None,
        },
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// MethodCallee: fn SName -> Expr
/// ```
pub fn method_callee_f(n_p0: &crate::syntax::SName) -> crate::syntax::Expr {
    crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EName(n_p0.clone())), span_p: n_p0.span_p.clone() }
}

/// ```prism
/// MethodArgs: fn Expr, [Arg] -> [Arg]
/// ```
pub fn method_args_f(r_p0: &crate::syntax::Expr, args_p1: &crate::prelude::Array<crate::syntax::Arg>) -> crate::prelude::Array<crate::syntax::Arg> {
    crate::prelude::append(&crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: r_p0.clone(), span_p: r_p0.span_p.clone() }]), args_p1)
}

/// ```prism
/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
/// ```
pub fn body_sites_f(body_p0: &crate::syntax::decls::FnBody, m_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<Site> {
    crate::prelude::run_to_end(crate::prelude::fold_job(body_spots_f(body_p0, m_p1), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<Site>, Spot)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p2 = p0;
        let sp_p3 = p1;
        crate::prelude::call_then(start_spot_sites_f(sp_p3.clone()), move |spot_sites_f_12833: crate::prelude::Array<Site>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p2, &spot_sites_f_12833)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<Site>, Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Site>>>>))
}

/// The step machine of `BodySites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
/// ```
pub struct BodySites {
    pub body_p0: crate::syntax::decls::FnBody,
    pub m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<crate::prelude::Array<Site>> for BodySites {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Site>> {
        let body_p0 = &self.body_p0;
        let m_p1 = &self.m_p1;
        let body_p0x = body_p0.clone();
        let m_p1x = m_p1.clone();
        crate::prelude::call_then(start_body_spots_f(body_p0x.clone(), m_p1x.clone()), move |body_spots_f_12783: crate::prelude::Array<Spot>| crate::prelude::fold_job(body_spots_f_12783, crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<Site>, Spot)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p2 = p0;
            let sp_p3 = p1;
            crate::prelude::call_then(start_spot_sites_f(sp_p3.clone()), move |spot_sites_f_12833: crate::prelude::Array<Site>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p2, &spot_sites_f_12833)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<Site>, Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Site>>>>).cycle())
    }
}

/// `Start BodySites, x`: what the function value is when passed to `@Run`.
pub fn start_body_sites_f(body_p0: crate::syntax::decls::FnBody, m_p1: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Site>>> {
    ::std::rc::Rc::new(BodySites { body_p0, m_p1 })
}

/// ```prism
/// SpotSites: unbounded fn Spot -> [Site]
/// ```
pub fn spot_sites_f(spot0: &Spot) -> crate::prelude::Array<Site> {
    match spot0 {
        Spot::SpotStmt(_, _) => crate::prelude::Array::new(),
        Spot::SpotExpr(e_p0, m_p1) => match &*e_p0.kind_p {
            crate::syntax::ExprKind::EName(n_p2) => crate::prelude::Array::from(vec![Site { callee_p: crate::check::env::sname_key_f(n_p2), args_p: crate::prelude::Array::new(), span_p: e_p0.span_p.clone(), rels_p: m_p1.clone() }]),
            crate::syntax::ExprKind::ECall(c_p3, args_p4, _, _) => call_sites_f(&**c_p3, args_p4, &e_p0.span_p, m_p1),
            crate::syntax::ExprKind::EMethod(r_p5, n_p6, args_p7) => call_sites_f(&method_callee_f(n_p6), &method_args_f(&**r_p5, args_p7), &e_p0.span_p, m_p1),
            crate::syntax::ExprKind::EBinary(op_p8, l_p9, r_pa) => if is_called_op_f(op_p8) {
                crate::prelude::Array::from(vec![Site { callee_p: op_p8.clone(), args_p: crate::prelude::Array::from(vec![arg_of_f(&**l_p9), arg_of_f(&**r_pa)]), span_p: e_p0.span_p.clone(), rels_p: m_p1.clone() }])
            } else {
                crate::prelude::Array::new()
            },
            _ => crate::prelude::Array::new(),
        },
    }
}

/// The step machine of `SpotSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotSites: unbounded fn Spot -> [Site]
/// ```
pub struct SpotSites {
    pub spot0: Spot,
}

impl ::prism_rtl::Job<crate::prelude::Array<Site>> for SpotSites {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Site>> {
        let spot0 = &self.spot0;
        match spot0 {
            Spot::SpotStmt(_, _) => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
            Spot::SpotExpr(e_p0, m_p1) => match &*e_p0.kind_p {
                crate::syntax::ExprKind::EName(n_p2) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Site { callee_p: crate::check::env::sname_key_f(n_p2), args_p: crate::prelude::Array::new(), span_p: e_p0.span_p.clone(), rels_p: m_p1.clone() }])),
                crate::syntax::ExprKind::ECall(c_p3, args_p4, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CallSites { c_p0: (**c_p3).clone(), args_p1: args_p4.clone(), span_p2: e_p0.span_p.clone(), m_p3: m_p1.clone() })),
                crate::syntax::ExprKind::EMethod(r_p5, n_p6, args_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CallSites { c_p0: method_callee_f(n_p6), args_p1: method_args_f(&**r_p5, args_p7), span_p2: e_p0.span_p.clone(), m_p3: m_p1.clone() })),
                crate::syntax::ExprKind::EBinary(op_p8, l_p9, r_pa) => if is_called_op_f(op_p8) {
                    ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![Site { callee_p: op_p8.clone(), args_p: crate::prelude::Array::from(vec![arg_of_f(&**l_p9), arg_of_f(&**r_pa)]), span_p: e_p0.span_p.clone(), rels_p: m_p1.clone() }]))
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
                },
                _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
            },
        }
    }
}

/// `Start SpotSites, x`: what the function value is when passed to `@Run`.
pub fn start_spot_sites_f(spot0: Spot) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Site>>> {
    ::std::rc::Rc::new(SpotSites { spot0 })
}

/// ```prism
/// IsCalledOp: fn Text -> Bool
/// ```
pub fn is_called_op_f(op_p0: &crate::prelude::Text) -> bool {
    !crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("and"), crate::prelude::Text::lit("or"), crate::prelude::Text::lit("on"), crate::prelude::Text::lit("<|"), crate::prelude::Text::lit("mod")]), op_p0)
}

/// ```prism
/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
/// ```
pub fn call_sites_f(c_p0: &crate::syntax::Expr, args_p1: &crate::prelude::Array<crate::syntax::Arg>, span_p2: &crate::syntax::Range, m_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Array<Site> {
    let direct_p4 = match callee_name_o(c_p0) {
        ::std::option::Option::Some(n_p5) => crate::prelude::Array::from(vec![Site { callee_p: n_p5, args_p: args_p1.clone(), span_p: span_p2.clone(), rels_p: m_p3.clone() }]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    match traversal_of_o(m_p3, c_p0, args_p1) {
        ::std::option::Option::Some((coll_p6, step_p7, at_p8)) => match &*step_p7.kind_p {
            crate::syntax::ExprKind::EName(n_p9) => {
                let call_args_pa = if &at_p8 == &crate::prelude::Nat::from(1u32) {
                    crate::prelude::Array::from(vec![crate::prelude::or(&crate::prelude::index(args_p1, &crate::prelude::Nat::from(1u32)), &crate::check::shrink::summaries::dummy_arg_p()), arg_of_f(&part_of_f(&coll_p6))])
                } else {
                    crate::prelude::Array::from(vec![arg_of_f(&part_of_f(&coll_p6))])
                };
                crate::prelude::push(&direct_p4, &Site { callee_p: crate::check::env::sname_key_f(n_p9), args_p: call_args_pa.clone(), span_p: step_p7.span_p.clone(), rels_p: m_p3.clone() })
            },
            _ => direct_p4.clone(),
        },
        ::std::option::Option::None => match acc_callee_o(m_p3, c_p0, args_p1) {
            ::std::option::Option::Some(cn_pb) => crate::prelude::append(&direct_p4, &acc_sites_f(m_p3, &cn_pb, args_p1)),
            ::std::option::Option::None => direct_p4.clone(),
        },
    }
}

/// The step machine of `CallSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
/// ```
pub struct CallSites {
    pub c_p0: crate::syntax::Expr,
    pub args_p1: crate::prelude::Array<crate::syntax::Arg>,
    pub span_p2: crate::syntax::Range,
    pub m_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<crate::prelude::Array<Site>> for CallSites {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Site>> {
        let c_p0 = &self.c_p0;
        let args_p1 = &self.args_p1;
        let span_p2 = &self.span_p2;
        let m_p3 = &self.m_p3;
        let direct_p4 = match callee_name_o(c_p0) {
            ::std::option::Option::Some(n_p5) => crate::prelude::Array::from(vec![Site { callee_p: n_p5, args_p: args_p1.clone(), span_p: span_p2.clone(), rels_p: m_p3.clone() }]),
            ::std::option::Option::None => crate::prelude::Array::new(),
        };
        match traversal_of_o(m_p3, c_p0, args_p1) {
            ::std::option::Option::Some((coll_p6, step_p7, at_p8)) => match &*step_p7.kind_p {
                crate::syntax::ExprKind::EName(n_p9) => {
                    let call_args_pa = if &at_p8 == &crate::prelude::Nat::from(1u32) {
                        crate::prelude::Array::from(vec![crate::prelude::or(&crate::prelude::index(args_p1, &crate::prelude::Nat::from(1u32)), &crate::check::shrink::summaries::dummy_arg_p()), arg_of_f(&part_of_f(&coll_p6))])
                    } else {
                        crate::prelude::Array::from(vec![arg_of_f(&part_of_f(&coll_p6))])
                    };
                    ::prism_rtl::Turn::Finished(crate::prelude::push(&direct_p4, &Site { callee_p: crate::check::env::sname_key_f(n_p9), args_p: call_args_pa.clone(), span_p: step_p7.span_p.clone(), rels_p: m_p3.clone() }))
                },
                _ => ::prism_rtl::Turn::Finished(direct_p4.clone()),
            },
            ::std::option::Option::None => match acc_callee_o(m_p3, c_p0, args_p1) {
                ::std::option::Option::Some(cn_pb) => ::prism_rtl::Turn::Finished(crate::prelude::append(&direct_p4, &acc_sites_f(m_p3, &cn_pb, args_p1))),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(direct_p4.clone()),
            },
        }
    }
}

/// `Start CallSites, x`: what the function value is when passed to `@Run`.
pub fn start_call_sites_f(c_p0: crate::syntax::Expr, args_p1: crate::prelude::Array<crate::syntax::Arg>, span_p2: crate::syntax::Range, m_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Site>>> {
    ::std::rc::Rc::new(CallSites { c_p0, args_p1, span_p2, m_p3 })
}

/// ```prism
/// PartOf: fn Expr -> Expr
/// ```
pub fn part_of_f(x_p0: &crate::syntax::Expr) -> crate::syntax::Expr {
    crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EField(::std::rc::Rc::new(x_p0.clone()), crate::prelude::Text::lit(""), crate::syntax::Ident { name_p: crate::prelude::Text::lit("element"), span_p: x_p0.span_p.clone() })), span_p: x_p0.span_p.clone() }
}

/// ```prism
/// AccSites: fn (Text ==> Rel), Text, [Arg] -> [Site]
/// ```
pub fn acc_sites_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, cn_p1: &crate::prelude::Text, args_p2: &crate::prelude::Array<crate::syntax::Arg>) -> crate::prelude::Array<Site> {
    crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(args_p2)), &crate::prelude::Array::new(), &(|acc_p3: &crate::prelude::Array<Site>, j_p4: &crate::prelude::Nat| match (crate::prelude::get(m_p0, &crate::prelude::Text::from(format!("acc:{}:{}", cn_p1, j_p4))), crate::prelude::index(args_p2, j_p4)) {
        (::std::option::Option::Some(ar_p5), ::std::option::Option::Some(a_p6)) => match &*a_p6.value_p.kind_p {
            crate::syntax::ExprKind::EName(f_p7) => crate::prelude::push(acc_p3, &Site { callee_p: crate::check::env::sname_key_f(f_p7), args_p: crate::prelude::each(&crate::check::errors::range0_f(&ar_p5.param_p), &(|q_p8: &crate::prelude::Nat| acc_arg_f(m_p0, cn_p1, j_p4, q_p8, args_p2))), span_p: a_p6.value_p.span_p.clone(), rels_p: m_p0.clone() }),
            _ => acc_p3.clone(),
        },
        _ => acc_p3.clone(),
    }))
}

/// ```prism
/// AccArg: fn (Text ==> Rel), Text, Nat, Nat, [Arg] -> Arg
/// ```
pub fn acc_arg_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, cn_p1: &crate::prelude::Text, j_p2: &crate::prelude::Nat, q_p3: &crate::prelude::Nat, args_p4: &crate::prelude::Array<crate::syntax::Arg>) -> crate::syntax::Arg {
    match crate::prelude::get(m_p0, &crate::prelude::Text::from(format!("sum:{}:{}:{}", cn_p1, j_p2, q_p3))) {
        ::std::option::Option::Some(s_p5) => if &s_p5.param_p == &top_param_p() {
            arg_of_f(&top_expr_p())
        } else {
            match crate::prelude::index(args_p4, &s_p5.param_p) {
                ::std::option::Option::Some(a_p6) => arg_of_f(&(if s_p5.strict_p { part_of_f(&a_p6.value_p) } else { a_p6.value_p.clone() })),
                ::std::option::Option::None => crate::check::shrink::summaries::dummy_arg_p(),
            }
        },
        ::std::option::Option::None => crate::check::shrink::summaries::dummy_arg_p(),
    }
}

/// ```prism
/// let topExpr
/// ```
pub fn top_expr_p() -> crate::syntax::Expr {
    crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EName(crate::syntax::SName { sigils_p: crate::prelude::Text::lit(""), path_p: crate::prelude::Array::from(vec![crate::prelude::Text::lit("⊤")]), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } })), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// SpotsNames: unbounded fn [Spot] -> [Text]
/// ```
pub fn spots_names_f(spots_p0: &crate::prelude::Array<Spot>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::run_to_end(crate::prelude::fold_job(spots_p0.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, Spot)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p1 = p0;
        let sp_p2 = p1;
        ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p1, &spot_names_f(&sp_p2)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>))
}

/// The step machine of `SpotsNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotsNames: unbounded fn [Spot] -> [Text]
/// ```
pub struct SpotsNames {
    pub spots_p0: crate::prelude::Array<Spot>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for SpotsNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let spots_p0 = &self.spots_p0;
        crate::prelude::fold_job(spots_p0.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, Spot)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p1 = p0;
            let sp_p2 = p1;
            ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p1, &spot_names_f(&sp_p2)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle()
    }
}

/// `Start SpotsNames, x`: what the function value is when passed to `@Run`.
pub fn start_spots_names_f(spots_p0: crate::prelude::Array<Spot>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(SpotsNames { spots_p0 })
}

/// ```prism
/// SpotNames: unbounded fn Spot -> [Text]
/// ```
pub fn spot_names_f(sp_p0: &Spot) -> crate::prelude::Array<crate::prelude::Text> {
    let called_p1 = crate::prelude::each(&spot_sites_f(sp_p0), &(|s_p2: &Site| s_p2.callee_p.clone()));
    match sp_p0 {
        Spot::SpotExpr(_, _) => called_p1.clone(),
        Spot::SpotStmt(s_p3, _) => match &s_p3.kind_p {
            crate::syntax::StmtKind::SWidget(w_p4) => crate::check::types::add_text_f(&called_p1, &crate::check::env::sname_key_f(&w_p4.name_p)),
            _ => called_p1.clone(),
        },
    }
}

/// ```prism
/// ?TraversalOf: fn (Text ==> Rel), Expr, [Arg] -> ?((Expr, Expr, Nat))
/// ```
pub fn traversal_of_o(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, c_p1: &crate::syntax::Expr, args_p2: &crate::prelude::Array<crate::syntax::Arg>) -> ::std::option::Option<(crate::syntax::Expr, crate::syntax::Expr, crate::prelude::Nat)> {
    match &*c_p1.kind_p {
        crate::syntax::ExprKind::EName(n_p3) => {
            let name_p4 = crate::check::env::sname_key_f(n_p3);
            if crate::check::shrink::relations::pre_is_f(m_p0, &name_p4, &crate::prelude::Text::lit("Fold")) && (&crate::prelude::len(args_p2) == &crate::prelude::Nat::from(3u32)) {
                match (crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)), crate::prelude::index(args_p2, &crate::prelude::Nat::from(2u32))) {
                    (::std::option::Option::Some(a_p5), ::std::option::Option::Some(s_p6)) => ::std::option::Option::Some((a_p5.value_p.clone(), s_p6.value_p.clone(), crate::prelude::Nat::from(1u32))),
                    _ => ::std::option::Option::None,
                }
            } else {
                if (crate::check::shrink::relations::pre_is_f(m_p0, &name_p4, &crate::prelude::Text::lit("Each")) || crate::check::shrink::relations::pre_is_f(m_p0, &name_p4, &crate::prelude::Text::lit("Filter"))) && (&crate::prelude::len(args_p2) == &crate::prelude::Nat::from(2u32)) {
                    match (crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)), crate::prelude::index(args_p2, &crate::prelude::Nat::from(1u32))) {
                        (::std::option::Option::Some(a_p7), ::std::option::Option::Some(s_p8)) => ::std::option::Option::Some((a_p7.value_p.clone(), s_p8.value_p.clone(), crate::prelude::Nat::from(0u32))),
                        _ => ::std::option::Option::None,
                    }
                } else {
                    ::std::option::Option::None
                }
            }
        },
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// ?LastExpr: fn Block -> ?Expr
/// ```
pub fn last_expr_o(b_p0: &crate::syntax::Block) -> ::std::option::Option<crate::syntax::Expr> {
    match crate::syntax::lexer::chars::last_o(&b_p0.stmts_p) {
        ::std::option::Option::Some(s_p1) => match &s_p1.kind_p {
            crate::syntax::StmtKind::SExpr(x_p2) => ::std::option::Option::Some(x_p2.clone()),
            _ => ::std::option::Option::None,
        },
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub fn rel_of_o(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, e_p1: &crate::syntax::Expr) -> ::std::option::Option<crate::check::shrink::Rel> {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::EName(n_p2) => crate::prelude::get(m_p0, &crate::check::env::sname_key_f(n_p2)),
        crate::syntax::ExprKind::EField(r_p3, _, _) => match rel_of_o(m_p0, &**r_p3) {
            ::std::option::Option::Some(x_p4) => ::std::option::Option::Some(crate::check::shrink::Rel { param_p: x_p4.param_p.clone(), strict_p: true }),
            ::std::option::Option::None => ::std::option::Option::None,
        },
        crate::syntax::ExprKind::EIndex(r_p5, _) => rel_of_o(m_p0, &**r_p5),
        crate::syntax::ExprKind::EGroup(x_p6) => rel_of_o(m_p0, &**x_p6),
        crate::syntax::ExprKind::ECast(x_p7, _, _) => rel_of_o(m_p0, &**x_p7),
        _ => match call_of_o(e_p1) {
            ::std::option::Option::Some((c_p8, args_p9)) => if is_non_nat_min_f(m_p0, e_p1, &c_p8) {
                ::std::option::Option::None
            } else {
                rel_of_call_o(m_p0, &c_p8, &args_p9)
            },
            ::std::option::Option::None => ::std::option::Option::None,
        },
    }
}

/// The step machine of `RelOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub struct RelOf {
    pub m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub e_p1: crate::syntax::Expr,
}

impl ::prism_rtl::Job<::std::option::Option<crate::check::shrink::Rel>> for RelOf {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::check::shrink::Rel>> {
        let m_p0 = &self.m_p0;
        let e_p1 = &self.e_p1;
        match &*e_p1.kind_p {
            crate::syntax::ExprKind::EName(n_p2) => ::prism_rtl::Turn::Finished(crate::prelude::get(m_p0, &crate::check::env::sname_key_f(n_p2))),
            crate::syntax::ExprKind::EField(r_p3, _, _) => {
                let m_p0x = m_p0.clone();
                let r_p3x = (**r_p3).clone();
                crate::prelude::call_then(start_rel_of_o(m_p0x.clone(), r_p3x.clone()), move |rel_of_o_18384: ::std::option::Option<crate::check::shrink::Rel>| match rel_of_o_18384 {
                    ::std::option::Option::Some(x_p4) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::check::shrink::Rel { param_p: x_p4.param_p.clone(), strict_p: true })),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                })
            },
            crate::syntax::ExprKind::EIndex(r_p5, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RelOf { m_p0: m_p0.clone(), e_p1: (**r_p5).clone() })),
            crate::syntax::ExprKind::EGroup(x_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RelOf { m_p0: m_p0.clone(), e_p1: (**x_p6).clone() })),
            crate::syntax::ExprKind::ECast(x_p7, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RelOf { m_p0: m_p0.clone(), e_p1: (**x_p7).clone() })),
            _ => match call_of_o(e_p1) {
                ::std::option::Option::Some((c_p8, args_p9)) => if is_non_nat_min_f(m_p0, e_p1, &c_p8) {
                    ::prism_rtl::Turn::Finished(::std::option::Option::None)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(RelOfCall { m_p0: m_p0.clone(), c_p1: c_p8.clone(), args_p2: args_p9.clone() }))
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
            },
        }
    }
}

/// `Start RelOf, x`: what the function value is when passed to `@Run`.
pub fn start_rel_of_o(m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, e_p1: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::check::shrink::Rel>>> {
    ::std::rc::Rc::new(RelOf { m_p0, e_p1 })
}

/// ```prism
/// IsNonNatMin: fn (Text ==> Rel), Expr, Expr -> Bool
/// ```
pub fn is_non_nat_min_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, e_p1: &crate::syntax::Expr, c_p2: &crate::syntax::Expr) -> bool {
    match callee_name_o(c_p2) {
        ::std::option::Option::Some(n_p3) => if crate::check::shrink::relations::pre_is_f(m_p0, &n_p3, &crate::prelude::Text::lit("Min")) {
            !is_nat_at_f(m_p0, e_p1)
        } else {
            false
        },
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// IsNatAt: fn (Text ==> Rel), Expr -> Bool
/// ```
pub fn is_nat_at_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, e_p1: &crate::syntax::Expr) -> bool {
    match crate::prelude::get(m_p0, &crate::prelude::Text::lit("file:")) {
        ::std::option::Option::Some(f_p2) => crate::check::env::has_key_f(m_p0, &crate::prelude::Text::from(format!("nat:{}:{}:{}", &f_p2.param_p, &e_p1.span_p.start_p, &e_p1.span_p.end_p))),
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
/// ```
pub fn rel_of_call_o(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, c_p1: &crate::syntax::Expr, args_p2: &crate::prelude::Array<crate::syntax::Arg>) -> ::std::option::Option<crate::check::shrink::Rel> {
    match &*c_p1.kind_p {
        crate::syntax::ExprKind::EName(n_p3) => {
            let name_p4 = crate::check::env::sname_key_f(n_p3);
            if (crate::check::shrink::relations::pre_is_f(m_p0, &name_p4, &crate::prelude::Text::lit("Drop")) && (&crate::prelude::len(args_p2) == &crate::prelude::Nat::from(2u32))) && crate::check::shrink::summaries::is_positive_lit_f(&crate::prelude::or(&crate::prelude::index(args_p2, &crate::prelude::Nat::from(1u32)), &crate::check::shrink::summaries::dummy_arg_p()).value_p) {
                match crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)) {
                    ::std::option::Option::Some(a_p5) => match rel_of_o(m_p0, &a_p5.value_p) {
                        ::std::option::Option::Some(x_p6) => ::std::option::Option::Some(crate::check::shrink::Rel { param_p: x_p6.param_p.clone(), strict_p: x_p6.strict_p || known_non_empty_f(m_p0, &a_p5.value_p) }),
                        ::std::option::Option::None => ::std::option::Option::None,
                    },
                    ::std::option::Option::None => ::std::option::Option::None,
                }
            } else {
                if (crate::check::shrink::relations::pre_is_f(m_p0, &name_p4, &crate::prelude::Text::lit("Values")) || crate::check::shrink::relations::pre_is_f(m_p0, &name_p4, &crate::prelude::Text::lit("Keys"))) && (&crate::prelude::len(args_p2) == &crate::prelude::Nat::from(1u32)) {
                    rel_of_o(m_p0, &crate::prelude::or(&crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)), &crate::check::shrink::summaries::dummy_arg_p()).value_p)
                } else {
                    match no_larger_arg_o(m_p0, c_p1, args_p2) {
                        ::std::option::Option::Some(a_p7) => rel_of_o(m_p0, &a_p7),
                        ::std::option::Option::None => ::std::option::Option::None,
                    }
                }
            }
        },
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `RelOfCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
/// ```
pub struct RelOfCall {
    pub m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub c_p1: crate::syntax::Expr,
    pub args_p2: crate::prelude::Array<crate::syntax::Arg>,
}

impl ::prism_rtl::Job<::std::option::Option<crate::check::shrink::Rel>> for RelOfCall {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::check::shrink::Rel>> {
        let m_p0 = &self.m_p0;
        let c_p1 = &self.c_p1;
        let args_p2 = &self.args_p2;
        match &*c_p1.kind_p {
            crate::syntax::ExprKind::EName(n_p3) => {
                let name_p4 = crate::check::env::sname_key_f(n_p3);
                if (crate::check::shrink::relations::pre_is_f(m_p0, &name_p4, &crate::prelude::Text::lit("Drop")) && (&crate::prelude::len(args_p2) == &crate::prelude::Nat::from(2u32))) && crate::check::shrink::summaries::is_positive_lit_f(&crate::prelude::or(&crate::prelude::index(args_p2, &crate::prelude::Nat::from(1u32)), &crate::check::shrink::summaries::dummy_arg_p()).value_p) {
                    match crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)) {
                        ::std::option::Option::Some(a_p5) => {
                            let m_p0x = m_p0.clone();
                            crate::prelude::call_then(start_rel_of_o(m_p0x.clone(), a_p5.value_p.clone()), move |rel_of_o_19633: ::std::option::Option<crate::check::shrink::Rel>| match rel_of_o_19633 {
                                ::std::option::Option::Some(x_p6) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::check::shrink::Rel { param_p: x_p6.param_p.clone(), strict_p: x_p6.strict_p || known_non_empty_f(&m_p0x, &a_p5.value_p) })),
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                            })
                        },
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                    }
                } else {
                    if (crate::check::shrink::relations::pre_is_f(m_p0, &name_p4, &crate::prelude::Text::lit("Values")) || crate::check::shrink::relations::pre_is_f(m_p0, &name_p4, &crate::prelude::Text::lit("Keys"))) && (&crate::prelude::len(args_p2) == &crate::prelude::Nat::from(1u32)) {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(RelOf { m_p0: m_p0.clone(), e_p1: crate::prelude::or(&crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)), &crate::check::shrink::summaries::dummy_arg_p()).value_p.clone() }))
                    } else {
                        match no_larger_arg_o(m_p0, c_p1, args_p2) {
                            ::std::option::Option::Some(a_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RelOf { m_p0: m_p0.clone(), e_p1: a_p7.clone() })),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                        }
                    }
                }
            },
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start RelOfCall, x`: what the function value is when passed to `@Run`.
pub fn start_rel_of_call_o(m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, c_p1: crate::syntax::Expr, args_p2: crate::prelude::Array<crate::syntax::Arg>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::check::shrink::Rel>>> {
    ::std::rc::Rc::new(RelOfCall { m_p0, c_p1, args_p2 })
}

/// ```prism
/// KnownNonEmpty: fn (Text ==> Rel), Expr -> Bool
/// ```
pub fn known_non_empty_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, e_p1: &crate::syntax::Expr) -> bool {
    match crate::check::shrink::relations::name_of_o(e_p1) {
        ::std::option::Option::Some(n_p2) => crate::check::env::has_key_f(m_p0, &crate::prelude::Text::from(format!("ne:{}", &n_p2))),
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// ?CallOf: fn Expr -> ?((Expr, [Arg]))
/// ```
pub fn call_of_o(e_p0: &crate::syntax::Expr) -> ::std::option::Option<(crate::syntax::Expr, crate::prelude::Array<crate::syntax::Arg>)> {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ECall(c_p1, args_p2, _, _) => ::std::option::Option::Some(((**c_p1).clone(), args_p2.clone())),
        crate::syntax::ExprKind::EMethod(r_p3, n_p4, args_p5) => ::std::option::Option::Some((method_callee_f(n_p4), method_args_f(&**r_p3, args_p5))),
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// ?NoLargerArg: fn (Text ==> Rel), Expr, [Arg] -> ?Expr
/// ```
pub fn no_larger_arg_o(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, c_p1: &crate::syntax::Expr, args_p2: &crate::prelude::Array<crate::syntax::Arg>) -> ::std::option::Option<crate::syntax::Expr> {
    match callee_name_o(c_p1) {
        ::std::option::Option::Some(n_p3) => if crate::check::shrink::relations::is_local_f(m_p0, &n_p3) {
            ::std::option::Option::None
        } else {
            match crate::prelude::get(m_p0, &crate::prelude::Text::from(format!("fn:{}", &n_p3))) {
                ::std::option::Option::Some(s_p4) => match crate::prelude::index(args_p2, &s_p4.param_p) {
                    ::std::option::Option::Some(a_p5) => ::std::option::Option::Some(a_p5.value_p.clone()),
                    ::std::option::Option::None => ::std::option::Option::None,
                },
                ::std::option::Option::None => ::std::option::Option::None,
            }
        },
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// IsNoLargerPrelude: fn G, Text -> Bool
/// ```
pub fn is_no_larger_prelude_f(g_p0: &crate::check::env::G, k_p1: &crate::prelude::Text) -> bool {
    crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("Prelude.Take"), crate::prelude::Text::lit("Prelude.Drop"), crate::prelude::Text::lit("Prelude.Filter"), crate::prelude::Text::lit("Prelude.Remove"), crate::prelude::Text::lit("Prelude.Min"), crate::prelude::Text::lit("Prelude.@Flatten")]), k_p1) && crate::check::shrink::relations::is_prelude_key_f(g_p0, k_p1)
}
