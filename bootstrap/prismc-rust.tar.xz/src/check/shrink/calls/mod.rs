//! The module `Check.Shrink.Calls`, from `target/bootstrap/src/prismc/check/shrink/calls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `Slot`:
///
/// ```prism
/// type Slot = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Slot {
    pub owner_p: crate::prelude::Text,
    pub at_p: crate::prelude::Nat,
    pub arity_p: crate::prelude::Nat,
}

impl crate::prelude::Show for Slot {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Slot", &[("owner", &self.owner_p), ("at", &self.at_p), ("arity", &self.arity_p)]);
    }
}

impl crate::prelude::ToPod for Slot {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Slot", vec![("owner", self.owner_p.to_pod()), ("at", self.at_p.to_pod()), ("arity", self.arity_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Slot {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Slot { owner_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "owner")?)?, at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, arity_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "arity")?)? })
    }
}

/// ```prism
/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
/// ```
pub fn hof_seeds_f(sk_p0: &crate::check::shrink::Shrink, homes_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>> {
    let cands_p2 = hof_candidates_f(sk_p0);
    let cleared_p3 = clear_slots_f(sk_p0, homes_p1, &cands_p2, &crate::prelude::Nat::from(0u32));
    let sums_p4 = slot_sums_f(sk_p0, homes_p1, &cleared_p3, &top_sums_f(&cleared_p3), &crate::prelude::Nat::from(0u32));
    crate::prelude::fold(homes_p1, &crate::prelude::Map::new(), &(|m_p5: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>, h_p6: &crate::prelude::Text| crate::prelude::insert(m_p5, h_p6, &slot_seeds_f(sk_p0, h_p6, &cleared_p3, &sums_p4, &false))))
}

/// The step machine of `HofSeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
/// ```
pub struct HofSeeds {
    pub sk_p0: crate::check::shrink::Shrink,
    pub homes_p1: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>> for HofSeeds {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>> {
        let sk_p0 = &self.sk_p0;
        let homes_p1 = &self.homes_p1;
        let cands_p2 = hof_candidates_f(sk_p0);
        let homes_p1x = homes_p1.clone();
        let sk_p0x = sk_p0.clone();
        crate::prelude::call_then(start_clear_slots_f(sk_p0x.clone(), homes_p1x.clone(), cands_p2.clone(), crate::prelude::Nat::from(0u32)), move |clear_slots_f_2618: crate::prelude::Array<Slot>| {
            let cleared_p3 = clear_slots_f_2618;
            crate::prelude::call_then(start_slot_sums_f(sk_p0x.clone(), homes_p1x.clone(), cleared_p3.clone(), top_sums_f(&cleared_p3), crate::prelude::Nat::from(0u32)), move |slot_sums_f_2664: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                let sums_p4 = slot_sums_f_2664;
                ::prism_rtl::Turn::Finished(crate::prelude::fold(&homes_p1x, &crate::prelude::Map::new(), &(|m_p5: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>, h_p6: &crate::prelude::Text| crate::prelude::insert(m_p5, h_p6, &slot_seeds_f(&sk_p0x, h_p6, &cleared_p3, &sums_p4, &false)))))
            })
        })
    }
}

/// `Start HofSeeds, x`: what the function value is when passed to `@Run`.
pub fn start_hof_seeds_f(sk_p0: crate::check::shrink::Shrink, homes_p1: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>>> {
    ::std::rc::Rc::new(HofSeeds { sk_p0, homes_p1 })
}

/// ```prism
/// HofCandidates: fn Shrink -> [Slot]
/// ```
pub fn hof_candidates_f(sk_p0: &crate::check::shrink::Shrink) -> crate::prelude::Array<Slot> {
    crate::prelude::fold(&sk_p0.fns_p, &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<Slot>, d_p2: &crate::check::env::Def| match &d_p2.body_p {
        crate::check::env::DefBody::DbFn(clauses_p3) => match crate::prelude::get(&sk_p0.g_p.vals_p, &d_p2.qk_p) {
            ::std::option::Option::Some(v_p4) => match &v_p4.scheme_p.ty_p {
                crate::check::types::Ty::TyFn(_, ps_p5, _) => crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(ps_p5)), acc_p1, &(|a2_p6: &crate::prelude::Array<Slot>, j_p7: &crate::prelude::Nat| match crate::prelude::index(ps_p5, j_p7) {
                    ::std::option::Option::Some(crate::check::types::Ty::TyFn(_, fps_p8, _)) => if crate::prelude::fold(clauses_p3, &true, &(|ok_p9: &bool, c_pa: &crate::syntax::decls::FnClause| *ok_p9 && slot_named_f(c_pa, j_p7))) {
                        crate::prelude::push(a2_p6, &Slot { owner_p: d_p2.qk_p.clone(), at_p: j_p7.clone(), arity_p: crate::prelude::len(&fps_p8) })
                    } else {
                        a2_p6.clone()
                    },
                    _ => a2_p6.clone(),
                })),
                _ => acc_p1.clone(),
            },
            ::std::option::Option::None => acc_p1.clone(),
        },
        _ => acc_p1.clone(),
    }))
}

/// ```prism
/// SlotNamed: fn FnClause, Nat -> Bool
/// ```
pub fn slot_named_f(c_p0: &crate::syntax::decls::FnClause, j_p1: &crate::prelude::Nat) -> bool {
    match crate::prelude::index(&c_p0.params_p, j_p1) {
        ::std::option::Option::Some(p_p2) => match &*p_p2.kind_p {
            crate::syntax::PatternKind::PName(_) => true,
            crate::syntax::PatternKind::PIgnore => true,
            _ => false,
        },
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// SlotName: fn FnClause, Nat -> Text
/// ```
pub fn slot_name_f(c_p0: &crate::syntax::decls::FnClause, j_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    match crate::prelude::index(&c_p0.params_p, j_p1) {
        ::std::option::Option::Some(p_p2) => match &*p_p2.kind_p {
            crate::syntax::PatternKind::PName(n_p3) => crate::check::env::sname_key_f(n_p3),
            _ => crate::prelude::Text::lit(""),
        },
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// SlotSeeds: fn Shrink, Text, [Slot], (Text ==> Rel), Bool -> (Text ==> Rel)
/// ```
pub fn slot_seeds_f(sk_p0: &crate::check::shrink::Shrink, h_p1: &crate::prelude::Text, slots_p2: &crate::prelude::Array<Slot>, sums_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, with_top_p4: &bool) -> crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel> {
    let pre_p5 = crate::prelude::or(&crate::prelude::get(&sk_p0.seeds_p, h_p1), &crate::prelude::Map::new());
    let start_p6 = if *with_top_p4 {
        crate::prelude::insert(&pre_p5, &crate::prelude::Text::lit("⊤"), &crate::check::shrink::Rel { param_p: crate::check::shrink::walk::top_param_p(), strict_p: false })
    } else {
        pre_p5.clone()
    };
    crate::prelude::fold(slots_p2, &start_p6, &(|m_p7: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, sl_p8: &Slot| crate::prelude::fold(&spellings_f(&sk_p0.g_p, h_p1, &sl_p8.owner_p), m_p7, &(|m2_p9: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, sp_pa: &crate::prelude::Text| {
        let m3_pb = crate::prelude::insert(m2_p9, &crate::prelude::Text::from(format!("acc:{}:{}", sp_pa, &sl_p8.at_p)), &crate::check::shrink::Rel { param_p: sl_p8.arity_p.clone(), strict_p: false });
        crate::prelude::fold(&crate::check::errors::range0_f(&sl_p8.arity_p), &m3_pb, &(|m4_pc: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, q_pd: &crate::prelude::Nat| match crate::prelude::get(sums_p3, &crate::prelude::Text::from(format!("{}:{}:{}", &sl_p8.owner_p, &sl_p8.at_p, q_pd))) {
            ::std::option::Option::Some(r_pe) => if (&r_pe.param_p == &crate::check::shrink::walk::top_param_p()) && !*with_top_p4 {
                m4_pc.clone()
            } else {
                crate::prelude::insert(m4_pc, &crate::prelude::Text::from(format!("sum:{}:{}:{}", sp_pa, &sl_p8.at_p, q_pd)), &r_pe)
            },
            ::std::option::Option::None => m4_pc.clone(),
        }))
    }))))
}

/// ```prism
/// Spellings: fn G, Text, Text -> [Text]
/// ```
pub fn spellings_f(g_p0: &crate::check::env::G, h_p1: &crate::prelude::Text, k_p2: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::filter(&crate::check::types::add_text_f(&crate::prelude::Array::from(vec![crate::check::types::bare_name_f(k_p2)]), k_p2), &(|sp_p3: &crate::prelude::Text| &crate::check::shrink::locals::resolve_name_o(g_p0, h_p1, sp_p3) == &::std::option::Option::Some(k_p2.clone())))
}

/// ```prism
/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
/// ```
pub fn clear_slots_f(sk_p0: &crate::check::shrink::Shrink, homes_p1: &crate::prelude::Array<crate::prelude::Text>, slots_p2: &crate::prelude::Array<Slot>, round_p3: &crate::prelude::Nat) -> crate::prelude::Array<Slot> {
    let sks_p4 = seeds_for_f(sk_p0, homes_p1, slots_p2, &crate::prelude::Map::new(), &false);
    let kept_p5 = crate::prelude::run_to_end(crate::prelude::filter_job(slots_p2.clone(), {
        let sks_p4x = sks_p4.clone();
        ::std::rc::Rc::new(move |p0: Slot| {
            let sks_p4xy = sks_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let sl_p6 = p0;
                crate::prelude::call_then(start_slot_escapes_f(sks_p4xy.clone(), sl_p6.clone()), move |slot_escapes_f_5090: bool| ::prism_rtl::Turn::Finished(!slot_escapes_f_5090))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(Slot) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    if &crate::prelude::len(&kept_p5) == &crate::prelude::len(slots_p2) {
        kept_p5.clone()
    } else {
        if round_p3 > &crate::prelude::Nat::from(20u32) {
            crate::prelude::Array::new()
        } else {
            clear_slots_f(sk_p0, homes_p1, &kept_p5, &(round_p3 + &crate::prelude::Nat::from(1u32)))
        }
    }
}

/// The step machine of `ClearSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
/// ```
pub struct ClearSlots {
    pub sk_p0: crate::check::shrink::Shrink,
    pub homes_p1: crate::prelude::Array<crate::prelude::Text>,
    pub slots_p2: crate::prelude::Array<Slot>,
    pub round_p3: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Array<Slot>> for ClearSlots {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<Slot>> {
        let sk_p0 = &self.sk_p0;
        let homes_p1 = &self.homes_p1;
        let slots_p2 = &self.slots_p2;
        let round_p3 = &self.round_p3;
        let sks_p4 = seeds_for_f(sk_p0, homes_p1, slots_p2, &crate::prelude::Map::new(), &false);
        let homes_p1x = homes_p1.clone();
        let round_p3x = round_p3.clone();
        let sk_p0x = sk_p0.clone();
        let slots_p2x = slots_p2.clone();
        crate::prelude::call_value(crate::prelude::filter_job(slots_p2x.clone(), {
            let sks_p4x = sks_p4.clone();
            ::std::rc::Rc::new(move |p0: Slot| {
                let sks_p4xy = sks_p4x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let sl_p6 = p0;
                    crate::prelude::call_then(start_slot_escapes_f(sks_p4xy.clone(), sl_p6.clone()), move |slot_escapes_f_5090: bool| ::prism_rtl::Turn::Finished(!slot_escapes_f_5090))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(Slot) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }), move |filter_5065: crate::prelude::Array<Slot>| {
            let kept_p5 = filter_5065;
            if &crate::prelude::len(&kept_p5) == &crate::prelude::len(&slots_p2x) {
                ::prism_rtl::Turn::Finished(kept_p5.clone())
            } else {
                if &round_p3x > &crate::prelude::Nat::from(20u32) {
                    ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ClearSlots { sk_p0: sk_p0x.clone(), homes_p1: homes_p1x.clone(), slots_p2: kept_p5.clone(), round_p3: &round_p3x + &crate::prelude::Nat::from(1u32) }))
                }
            }
        })
    }
}

/// `Start ClearSlots, x`: what the function value is when passed to `@Run`.
pub fn start_clear_slots_f(sk_p0: crate::check::shrink::Shrink, homes_p1: crate::prelude::Array<crate::prelude::Text>, slots_p2: crate::prelude::Array<Slot>, round_p3: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<Slot>>> {
    ::std::rc::Rc::new(ClearSlots { sk_p0, homes_p1, slots_p2, round_p3 })
}

/// ```prism
/// SeedsFor: fn Shrink, [Text], [Slot], (Text ==> Rel), Bool -> Shrink
/// ```
pub fn seeds_for_f(sk_p0: &crate::check::shrink::Shrink, homes_p1: &crate::prelude::Array<crate::prelude::Text>, slots_p2: &crate::prelude::Array<Slot>, sums_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, with_top_p4: &bool) -> crate::check::shrink::Shrink {
    let mut this: crate::check::shrink::Shrink = sk_p0.clone();
    this.seeds_p = crate::prelude::fold(homes_p1, &crate::prelude::Map::new(), &(|m_p5: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>, h_p6: &crate::prelude::Text| crate::prelude::insert(m_p5, h_p6, &slot_seeds_f(sk_p0, h_p6, slots_p2, sums_p3, with_top_p4))));
    this
}

/// ```prism
/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
/// ```
pub fn slot_escapes_f(sk_p0: &crate::check::shrink::Shrink, sl_p1: &Slot) -> bool {
    match crate::prelude::get(&sk_p0.by_key_p, &sl_p1.owner_p) {
        ::std::option::Option::Some(d_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(&d_p2), false, {
            let sl_p1x = sl_p1.clone();
            let sk_p0x = sk_p0.clone();
            let d_p2x = d_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                let sl_p1xy = sl_p1x.clone();
                let sk_p0xy = sk_p0x.clone();
                let d_p2xy = d_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_p3 = p0;
                    let c_p4 = p1;
                    {
                        let n_p5 = slot_name_f(&c_p4, &sl_p1xy.at_p);
                        if seen_p3 || (&n_p5 == &crate::prelude::Text::lit("")) {
                            ::prism_rtl::Turn::Finished(seen_p3)
                        } else {
                            crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0xy.clone(), d_p2xy.clone(), c_p4.clone()), move |clause_base_f_5891: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p4.body_p.clone(), clause_base_f_5891), move |body_spots_f_5872: crate::prelude::Array<crate::check::shrink::walk::Spot>| crate::prelude::fold_job(body_spots_f_5872, false, {
                                let n_p5x = n_p5.clone();
                                let sl_p1xyx = sl_p1xy.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                                    let n_p5xy = n_p5x.clone();
                                    let sl_p1xyxy = sl_p1xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let esc_p6 = p0;
                                        let sp_p7 = p1;
                                        if esc_p6 {
                                            ::prism_rtl::Turn::Finished(true)
                                        } else {
                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(SpotEscapes { sp_p0: sp_p7.clone(), n_p1: n_p5xy.clone(), j_p2: sl_p1xyxy.at_p.clone() }))
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            }).cycle()))
                        }
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        ::std::option::Option::None => true,
    }
}

/// The step machine of `SlotEscapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
/// ```
pub struct SlotEscapes {
    pub sk_p0: crate::check::shrink::Shrink,
    pub sl_p1: Slot,
}

impl ::prism_rtl::Job<bool> for SlotEscapes {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let sk_p0 = &self.sk_p0;
        let sl_p1 = &self.sl_p1;
        match crate::prelude::get(&sk_p0.by_key_p, &sl_p1.owner_p) {
            ::std::option::Option::Some(d_p2) => crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(&d_p2), false, {
                let sl_p1x = sl_p1.clone();
                let sk_p0x = sk_p0.clone();
                let d_p2x = d_p2.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                    let sl_p1xy = sl_p1x.clone();
                    let sk_p0xy = sk_p0x.clone();
                    let d_p2xy = d_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let seen_p3 = p0;
                        let c_p4 = p1;
                        {
                            let n_p5 = slot_name_f(&c_p4, &sl_p1xy.at_p);
                            if seen_p3 || (&n_p5 == &crate::prelude::Text::lit("")) {
                                ::prism_rtl::Turn::Finished(seen_p3)
                            } else {
                                crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0xy.clone(), d_p2xy.clone(), c_p4.clone()), move |clause_base_f_5891: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p4.body_p.clone(), clause_base_f_5891), move |body_spots_f_5872: crate::prelude::Array<crate::check::shrink::walk::Spot>| crate::prelude::fold_job(body_spots_f_5872, false, {
                                    let n_p5x = n_p5.clone();
                                    let sl_p1xyx = sl_p1xy.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                                        let n_p5xy = n_p5x.clone();
                                        let sl_p1xyxy = sl_p1xyx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let esc_p6 = p0;
                                            let sp_p7 = p1;
                                            if esc_p6 {
                                                ::prism_rtl::Turn::Finished(true)
                                            } else {
                                                ::prism_rtl::Turn::More(::std::rc::Rc::new(SpotEscapes { sp_p0: sp_p7.clone(), n_p1: n_p5xy.clone(), j_p2: sl_p1xyxy.at_p.clone() }))
                                            }
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                }).cycle()))
                            }
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle(),
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start SlotEscapes, x`: what the function value is when passed to `@Run`.
pub fn start_slot_escapes_f(sk_p0: crate::check::shrink::Shrink, sl_p1: Slot) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(SlotEscapes { sk_p0, sl_p1 })
}

/// ```prism
/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub fn spot_escapes_f(sp_p0: &crate::check::shrink::walk::Spot, n_p1: &crate::prelude::Text, j_p2: &crate::prelude::Nat) -> bool {
    match sp_p0 {
        crate::check::shrink::walk::Spot::SpotExpr(e_p3, m_p4) => match &*e_p3.kind_p {
            crate::syntax::ExprKind::EName(x_p5) => (&crate::check::env::sname_key_f(x_p5) == n_p1) && is_slot_param_f(m_p4, n_p1, j_p2),
            _ => crate::prelude::fold(&crate::check::shrink::walk::spot_sites_f(sp_p0), &false, &(|seen_p6: &bool, site_p7: &crate::check::shrink::walk::Site| *seen_p6 || (((&site_p7.callee_p == n_p1) && is_slot_param_f(&site_p7.rels_p, n_p1, j_p2)) && crate::check::env::has_key_f(&site_p7.rels_p, &crate::prelude::Text::lit("lam:"))))),
        },
        crate::check::shrink::walk::Spot::SpotStmt(_, _) => false,
    }
}

/// The step machine of `SpotEscapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub struct SpotEscapes {
    pub sp_p0: crate::check::shrink::walk::Spot,
    pub n_p1: crate::prelude::Text,
    pub j_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<bool> for SpotEscapes {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let sp_p0 = &self.sp_p0;
        let n_p1 = &self.n_p1;
        let j_p2 = &self.j_p2;
        match sp_p0 {
            crate::check::shrink::walk::Spot::SpotExpr(e_p3, m_p4) => match &*e_p3.kind_p {
                crate::syntax::ExprKind::EName(x_p5) => ::prism_rtl::Turn::Finished((&crate::check::env::sname_key_f(x_p5) == n_p1) && is_slot_param_f(m_p4, n_p1, j_p2)),
                _ => {
                    let j_p2x = j_p2.clone();
                    let n_p1x = n_p1.clone();
                    let sp_p0x = sp_p0.clone();
                    crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p0x.clone()), move |spot_sites_f_6182: crate::prelude::Array<crate::check::shrink::walk::Site>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&spot_sites_f_6182, &false, &(|seen_p6: &bool, site_p7: &crate::check::shrink::walk::Site| *seen_p6 || (((&site_p7.callee_p == &n_p1x) && is_slot_param_f(&site_p7.rels_p, &n_p1x, &j_p2x)) && crate::check::env::has_key_f(&site_p7.rels_p, &crate::prelude::Text::lit("lam:")))))))
                },
            },
            crate::check::shrink::walk::Spot::SpotStmt(_, _) => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start SpotEscapes, x`: what the function value is when passed to `@Run`.
pub fn start_spot_escapes_f(sp_p0: crate::check::shrink::walk::Spot, n_p1: crate::prelude::Text, j_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(SpotEscapes { sp_p0, n_p1, j_p2 })
}

/// ```prism
/// IsSlotParam: fn (Text ==> Rel), Text, Nat -> Bool
/// ```
pub fn is_slot_param_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, n_p1: &crate::prelude::Text, j_p2: &crate::prelude::Nat) -> bool {
    &crate::prelude::get(m_p0, n_p1) == &::std::option::Option::Some(crate::check::shrink::Rel { param_p: j_p2.clone(), strict_p: false })
}

/// ```prism
/// TopSums: fn [Slot] -> (Text ==> Rel)
/// ```
pub fn top_sums_f(slots_p0: &crate::prelude::Array<Slot>) -> crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel> {
    crate::prelude::fold(slots_p0, &crate::prelude::Map::new(), &(|m_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, sl_p2: &Slot| crate::prelude::fold(&crate::check::errors::range0_f(&sl_p2.arity_p), m_p1, &(|m2_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, q_p4: &crate::prelude::Nat| crate::prelude::insert(m2_p3, &crate::prelude::Text::from(format!("{}:{}:{}", &sl_p2.owner_p, &sl_p2.at_p, q_p4)), &crate::check::shrink::Rel { param_p: crate::check::shrink::walk::top_param_p(), strict_p: false })))))
}

/// ```prism
/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
/// ```
pub fn slot_sums_f(sk_p0: &crate::check::shrink::Shrink, homes_p1: &crate::prelude::Array<crate::prelude::Text>, slots_p2: &crate::prelude::Array<Slot>, sums_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, round_p4: &crate::prelude::Nat) -> crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel> {
    let sks_p5 = seeds_for_f(sk_p0, homes_p1, slots_p2, sums_p3, &true);
    let next_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(slots_p2.clone(), crate::prelude::Map::new(), {
        let sks_p5x = sks_p5.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, Slot)| {
            let sks_p5xy = sks_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p7 = p0;
                let sl_p8 = p1;
                crate::prelude::call_then(start_slot_calls_f(sks_p5xy.clone(), sl_p8.clone()), move |slot_calls_f_7327: crate::prelude::Array<crate::check::shrink::walk::Site>| {
                    let calls_p9 = slot_calls_f_7327;
                    crate::prelude::fold_job(crate::check::errors::range0_f(&sl_p8.arity_p), m_p7.clone(), {
                        let calls_p9x = calls_p9.clone();
                        let sl_p8x = sl_p8.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, crate::prelude::Nat)| {
                            let calls_p9xy = calls_p9x.clone();
                            let sl_p8xy = sl_p8x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let m2_pa = p0;
                                let q_pb = p1;
                                crate::prelude::call_then(start_meet_args_o(calls_p9xy.clone(), q_pb.clone()), move |meet_args_o_7395: ::std::option::Option<crate::check::shrink::Rel>| match meet_args_o_7395 {
                                    ::std::option::Option::Some(r_pc) => ::prism_rtl::Turn::Finished(crate::prelude::insert(&m2_pa, &crate::prelude::Text::from(format!("{}:{}:{}", &sl_p8xy.owner_p, &sl_p8xy.at_p, &q_pb)), &r_pc)),
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(m2_pa.clone()),
                                })
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>>>
                    }).cycle()
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, Slot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>>>
    }));
    if &next_p6 == sums_p3 {
        next_p6.clone()
    } else {
        if round_p4 > &crate::prelude::Nat::from(12u32) {
            crate::prelude::Map::new()
        } else {
            slot_sums_f(sk_p0, homes_p1, slots_p2, &next_p6, &(round_p4 + &crate::prelude::Nat::from(1u32)))
        }
    }
}

/// The step machine of `SlotSums`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
/// ```
pub struct SlotSums {
    pub sk_p0: crate::check::shrink::Shrink,
    pub homes_p1: crate::prelude::Array<crate::prelude::Text>,
    pub slots_p2: crate::prelude::Array<Slot>,
    pub sums_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub round_p4: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>> for SlotSums {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>> {
        let sk_p0 = &self.sk_p0;
        let homes_p1 = &self.homes_p1;
        let slots_p2 = &self.slots_p2;
        let sums_p3 = &self.sums_p3;
        let round_p4 = &self.round_p4;
        let sks_p5 = seeds_for_f(sk_p0, homes_p1, slots_p2, sums_p3, &true);
        let homes_p1x = homes_p1.clone();
        let round_p4x = round_p4.clone();
        let sk_p0x = sk_p0.clone();
        let slots_p2x = slots_p2.clone();
        let sums_p3x = sums_p3.clone();
        crate::prelude::call_value(crate::prelude::fold_job(slots_p2x.clone(), crate::prelude::Map::new(), {
            let sks_p5x = sks_p5.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, Slot)| {
                let sks_p5xy = sks_p5x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m_p7 = p0;
                    let sl_p8 = p1;
                    crate::prelude::call_then(start_slot_calls_f(sks_p5xy.clone(), sl_p8.clone()), move |slot_calls_f_7327: crate::prelude::Array<crate::check::shrink::walk::Site>| {
                        let calls_p9 = slot_calls_f_7327;
                        crate::prelude::fold_job(crate::check::errors::range0_f(&sl_p8.arity_p), m_p7.clone(), {
                            let calls_p9x = calls_p9.clone();
                            let sl_p8x = sl_p8.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, crate::prelude::Nat)| {
                                let calls_p9xy = calls_p9x.clone();
                                let sl_p8xy = sl_p8x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let m2_pa = p0;
                                    let q_pb = p1;
                                    crate::prelude::call_then(start_meet_args_o(calls_p9xy.clone(), q_pb.clone()), move |meet_args_o_7395: ::std::option::Option<crate::check::shrink::Rel>| match meet_args_o_7395 {
                                        ::std::option::Option::Some(r_pc) => ::prism_rtl::Turn::Finished(crate::prelude::insert(&m2_pa, &crate::prelude::Text::from(format!("{}:{}:{}", &sl_p8xy.owner_p, &sl_p8xy.at_p, &q_pb)), &r_pc)),
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(m2_pa.clone()),
                                    })
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>>>
                        }).cycle()
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, Slot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>>>
        }), move |fold_7282: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
            let next_p6 = fold_7282;
            if &next_p6 == &sums_p3x {
                ::prism_rtl::Turn::Finished(next_p6.clone())
            } else {
                if &round_p4x > &crate::prelude::Nat::from(12u32) {
                    ::prism_rtl::Turn::Finished(crate::prelude::Map::new())
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SlotSums { sk_p0: sk_p0x.clone(), homes_p1: homes_p1x.clone(), slots_p2: slots_p2x.clone(), sums_p3: next_p6.clone(), round_p4: &round_p4x + &crate::prelude::Nat::from(1u32) }))
                }
            }
        })
    }
}

/// `Start SlotSums, x`: what the function value is when passed to `@Run`.
pub fn start_slot_sums_f(sk_p0: crate::check::shrink::Shrink, homes_p1: crate::prelude::Array<crate::prelude::Text>, slots_p2: crate::prelude::Array<Slot>, sums_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, round_p4: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>> {
    ::std::rc::Rc::new(SlotSums { sk_p0, homes_p1, slots_p2, sums_p3, round_p4 })
}

/// ```prism
/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
/// ```
pub fn slot_calls_f(sk_p0: &crate::check::shrink::Shrink, sl_p1: &Slot) -> crate::prelude::Array<crate::check::shrink::walk::Site> {
    match crate::prelude::get(&sk_p0.by_key_p, &sl_p1.owner_p) {
        ::std::option::Option::Some(d_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(&d_p2), crate::prelude::Array::new(), {
            let sl_p1x = sl_p1.clone();
            let sk_p0x = sk_p0.clone();
            let d_p2x = d_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause)| {
                let sl_p1xy = sl_p1x.clone();
                let sk_p0xy = sk_p0x.clone();
                let d_p2xy = d_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p3 = p0;
                    let c_p4 = p1;
                    {
                        let n_p5 = slot_name_f(&c_p4, &sl_p1xy.at_p);
                        if &n_p5 == &crate::prelude::Text::lit("") {
                            ::prism_rtl::Turn::Finished(acc_p3.clone())
                        } else {
                            crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0xy.clone(), d_p2xy.clone(), c_p4.clone()), move |clause_base_f_7920: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                                let base_p6 = clause_base_f_7920;
                                crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p4.body_p.clone(), base_p6.clone()), move |body_spots_f_7984: crate::prelude::Array<crate::check::shrink::walk::Spot>| crate::prelude::call_then(crate::check::shrink::summaries::start_summary_seeds_f(sk_p0xy.clone(), d_p2xy.clone(), body_spots_f_7984, base_p6.clone()), move |summary_seeds_f_7963: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                                    let rels_p7 = summary_seeds_f_7963;
                                    crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p4.body_p.clone(), rels_p7.clone()), move |body_spots_f_8032: crate::prelude::Array<crate::check::shrink::walk::Spot>| crate::prelude::fold_job(body_spots_f_8032, acc_p3.clone(), {
                                        let n_p5x = n_p5.clone();
                                        let sl_p1xyx = sl_p1xy.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)| {
                                            let n_p5xy = n_p5x.clone();
                                            let sl_p1xyxy = sl_p1xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let a2_p8 = p0;
                                                let sp_p9 = p1;
                                                match &sp_p9 {
                                                    crate::check::shrink::walk::Spot::SpotExpr(e_pa, _) => match &*e_pa.kind_p {
                                                        crate::syntax::ExprKind::EName(_) => ::prism_rtl::Turn::Finished(a2_p8.clone()),
                                                        _ => crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p9.clone()), move |spot_sites_f_8220: crate::prelude::Array<crate::check::shrink::walk::Site>| ::prism_rtl::Turn::Finished(crate::prelude::append(&a2_p8, &crate::prelude::filter(&spot_sites_f_8220, &(|site_pb: &crate::check::shrink::walk::Site| (&site_pb.callee_p == &n_p5xy) && is_slot_param_f(&site_pb.rels_p, &n_p5xy, &sl_p1xyxy.at_p)))))),
                                                    },
                                                    _ => ::prism_rtl::Turn::Finished(a2_p8.clone()),
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Site>>>>
                                    }).cycle())
                                }))
                            })
                        }
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Site>>>>
        })),
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// The step machine of `SlotCalls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
/// ```
pub struct SlotCalls {
    pub sk_p0: crate::check::shrink::Shrink,
    pub sl_p1: Slot,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Site>> for SlotCalls {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::check::shrink::walk::Site>> {
        let sk_p0 = &self.sk_p0;
        let sl_p1 = &self.sl_p1;
        match crate::prelude::get(&sk_p0.by_key_p, &sl_p1.owner_p) {
            ::std::option::Option::Some(d_p2) => crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(&d_p2), crate::prelude::Array::new(), {
                let sl_p1x = sl_p1.clone();
                let sk_p0x = sk_p0.clone();
                let d_p2x = d_p2.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause)| {
                    let sl_p1xy = sl_p1x.clone();
                    let sk_p0xy = sk_p0x.clone();
                    let d_p2xy = d_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p3 = p0;
                        let c_p4 = p1;
                        {
                            let n_p5 = slot_name_f(&c_p4, &sl_p1xy.at_p);
                            if &n_p5 == &crate::prelude::Text::lit("") {
                                ::prism_rtl::Turn::Finished(acc_p3.clone())
                            } else {
                                crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0xy.clone(), d_p2xy.clone(), c_p4.clone()), move |clause_base_f_7920: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                                    let base_p6 = clause_base_f_7920;
                                    crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p4.body_p.clone(), base_p6.clone()), move |body_spots_f_7984: crate::prelude::Array<crate::check::shrink::walk::Spot>| crate::prelude::call_then(crate::check::shrink::summaries::start_summary_seeds_f(sk_p0xy.clone(), d_p2xy.clone(), body_spots_f_7984, base_p6.clone()), move |summary_seeds_f_7963: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                                        let rels_p7 = summary_seeds_f_7963;
                                        crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p4.body_p.clone(), rels_p7.clone()), move |body_spots_f_8032: crate::prelude::Array<crate::check::shrink::walk::Spot>| crate::prelude::fold_job(body_spots_f_8032, acc_p3.clone(), {
                                            let n_p5x = n_p5.clone();
                                            let sl_p1xyx = sl_p1xy.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)| {
                                                let n_p5xy = n_p5x.clone();
                                                let sl_p1xyxy = sl_p1xyx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let a2_p8 = p0;
                                                    let sp_p9 = p1;
                                                    match &sp_p9 {
                                                        crate::check::shrink::walk::Spot::SpotExpr(e_pa, _) => match &*e_pa.kind_p {
                                                            crate::syntax::ExprKind::EName(_) => ::prism_rtl::Turn::Finished(a2_p8.clone()),
                                                            _ => crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p9.clone()), move |spot_sites_f_8220: crate::prelude::Array<crate::check::shrink::walk::Site>| ::prism_rtl::Turn::Finished(crate::prelude::append(&a2_p8, &crate::prelude::filter(&spot_sites_f_8220, &(|site_pb: &crate::check::shrink::walk::Site| (&site_pb.callee_p == &n_p5xy) && is_slot_param_f(&site_pb.rels_p, &n_p5xy, &sl_p1xyxy.at_p)))))),
                                                        },
                                                        _ => ::prism_rtl::Turn::Finished(a2_p8.clone()),
                                                    }
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Site>>>>
                                        }).cycle())
                                    }))
                                })
                            }
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Site>>>>
            }).cycle(),
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start SlotCalls, x`: what the function value is when passed to `@Run`.
pub fn start_slot_calls_f(sk_p0: crate::check::shrink::Shrink, sl_p1: Slot) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Site>>> {
    ::std::rc::Rc::new(SlotCalls { sk_p0, sl_p1 })
}

/// ```prism
/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
/// ```
pub fn meet_args_o(calls_p0: &crate::prelude::Array<crate::check::shrink::walk::Site>, q_p1: &crate::prelude::Nat) -> ::std::option::Option<crate::check::shrink::Rel> {
    crate::prelude::run_to_end(crate::prelude::fold_job(calls_p0.clone(), ::std::option::Option::Some(crate::check::shrink::Rel { param_p: crate::check::shrink::walk::top_param_p(), strict_p: false }), {
        let q_p1x = q_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::check::shrink::Rel>, crate::check::shrink::walk::Site)| {
            let q_p1xy = q_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_o2 = p0;
                let site_p3 = p1;
                match &acc_o2 {
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                    ::std::option::Option::Some(acc_p4) => match crate::prelude::index(&site_p3.args_p, &q_p1xy) {
                        ::std::option::Option::Some(a_p5) => if &a_p5.name_o != &::std::option::Option::None {
                            ::prism_rtl::Turn::Finished(::std::option::Option::None)
                        } else {
                            {
                                let acc_p4x = acc_p4.clone();
                                crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(site_p3.rels_p.clone(), a_p5.value_p.clone()), move |rel_of_o_8797: ::std::option::Option<crate::check::shrink::Rel>| match rel_of_o_8797 {
                                    ::std::option::Option::Some(r_p6) => if &r_p6.param_p == &crate::check::shrink::walk::top_param_p() {
                                        ::prism_rtl::Turn::Finished(::std::option::Option::Some(acc_p4x.clone()))
                                    } else {
                                        if &acc_p4x.param_p == &crate::check::shrink::walk::top_param_p() {
                                            ::prism_rtl::Turn::Finished(::std::option::Option::Some(r_p6.clone()))
                                        } else {
                                            if &acc_p4x.param_p == &r_p6.param_p {
                                                ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::check::shrink::Rel { param_p: r_p6.param_p.clone(), strict_p: acc_p4x.strict_p && r_p6.strict_p }))
                                            } else {
                                                ::prism_rtl::Turn::Finished(::std::option::Option::None)
                                            }
                                        }
                                    },
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                                })
                            }
                        },
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                    },
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::check::shrink::Rel>, crate::check::shrink::walk::Site)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::check::shrink::Rel>>>>
    }))
}

/// The step machine of `MeetArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
/// ```
pub struct MeetArgs {
    pub calls_p0: crate::prelude::Array<crate::check::shrink::walk::Site>,
    pub q_p1: crate::prelude::Nat,
}

impl ::prism_rtl::Job<::std::option::Option<crate::check::shrink::Rel>> for MeetArgs {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::check::shrink::Rel>> {
        let calls_p0 = &self.calls_p0;
        let q_p1 = &self.q_p1;
        crate::prelude::fold_job(calls_p0.clone(), ::std::option::Option::Some(crate::check::shrink::Rel { param_p: crate::check::shrink::walk::top_param_p(), strict_p: false }), {
            let q_p1x = q_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::check::shrink::Rel>, crate::check::shrink::walk::Site)| {
                let q_p1xy = q_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_o2 = p0;
                    let site_p3 = p1;
                    match &acc_o2 {
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                        ::std::option::Option::Some(acc_p4) => match crate::prelude::index(&site_p3.args_p, &q_p1xy) {
                            ::std::option::Option::Some(a_p5) => if &a_p5.name_o != &::std::option::Option::None {
                                ::prism_rtl::Turn::Finished(::std::option::Option::None)
                            } else {
                                {
                                    let acc_p4x = acc_p4.clone();
                                    crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(site_p3.rels_p.clone(), a_p5.value_p.clone()), move |rel_of_o_8797: ::std::option::Option<crate::check::shrink::Rel>| match rel_of_o_8797 {
                                        ::std::option::Option::Some(r_p6) => if &r_p6.param_p == &crate::check::shrink::walk::top_param_p() {
                                            ::prism_rtl::Turn::Finished(::std::option::Option::Some(acc_p4x.clone()))
                                        } else {
                                            if &acc_p4x.param_p == &crate::check::shrink::walk::top_param_p() {
                                                ::prism_rtl::Turn::Finished(::std::option::Option::Some(r_p6.clone()))
                                            } else {
                                                if &acc_p4x.param_p == &r_p6.param_p {
                                                    ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::check::shrink::Rel { param_p: r_p6.param_p.clone(), strict_p: acc_p4x.strict_p && r_p6.strict_p }))
                                                } else {
                                                    ::prism_rtl::Turn::Finished(::std::option::Option::None)
                                                }
                                            }
                                        },
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                                    })
                                }
                            },
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                        },
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::check::shrink::Rel>, crate::check::shrink::walk::Site)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::check::shrink::Rel>>>>
        }).cycle()
    }
}

/// `Start MeetArgs, x`: what the function value is when passed to `@Run`.
pub fn start_meet_args_o(calls_p0: crate::prelude::Array<crate::check::shrink::walk::Site>, q_p1: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::check::shrink::Rel>>> {
    ::std::rc::Rc::new(MeetArgs { calls_p0, q_p1 })
}

/// ```prism
/// DefRefs: unbounded fn Shrink, Def -> [Text]
/// ```
pub fn def_refs_f(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p1), crate::prelude::Array::new(), {
        let sk_p0x = sk_p0.clone();
        let d_p1x = d_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::FnClause)| {
            let sk_p0xy = sk_p0x.clone();
            let d_p1xy = d_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p2 = p0;
                let c_p3 = p1;
                crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0xy.clone(), d_p1xy.clone(), c_p3.clone()), move |clause_base_f_9334: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p3.body_p.clone(), clause_base_f_9334), move |body_spots_f_9315: crate::prelude::Array<crate::check::shrink::walk::Spot>| ::prism_rtl::Turn::More(::std::rc::Rc::new(SpotsRefs { sk_p0: sk_p0xy.clone(), d_p1: d_p1xy.clone(), spots_p2: body_spots_f_9315, acc_p3: acc_p2.clone() }))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }))
}

/// The step machine of `DefRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefRefs: unbounded fn Shrink, Def -> [Text]
/// ```
pub struct DefRefs {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for DefRefs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p1), crate::prelude::Array::new(), {
            let sk_p0x = sk_p0.clone();
            let d_p1x = d_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::FnClause)| {
                let sk_p0xy = sk_p0x.clone();
                let d_p1xy = d_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p2 = p0;
                    let c_p3 = p1;
                    crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0xy.clone(), d_p1xy.clone(), c_p3.clone()), move |clause_base_f_9334: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p3.body_p.clone(), clause_base_f_9334), move |body_spots_f_9315: crate::prelude::Array<crate::check::shrink::walk::Spot>| ::prism_rtl::Turn::More(::std::rc::Rc::new(SpotsRefs { sk_p0: sk_p0xy.clone(), d_p1: d_p1xy.clone(), spots_p2: body_spots_f_9315, acc_p3: acc_p2.clone() }))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }).cycle()
    }
}

/// `Start DefRefs, x`: what the function value is when passed to `@Run`.
pub fn start_def_refs_f(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(DefRefs { sk_p0, d_p1 })
}

/// ```prism
/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
/// ```
pub fn spots_refs_f(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, spots_p2: &crate::prelude::Array<crate::check::shrink::walk::Spot>, acc_p3: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::run_to_end(crate::prelude::fold_job(spots_p2.clone(), acc_p3.clone(), {
        let sk_p0x = sk_p0.clone();
        let d_p1x = d_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::shrink::walk::Spot)| {
            let sk_p0xy = sk_p0x.clone();
            let d_p1xy = d_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let a1_p4 = p0;
                let sp_p5 = p1;
                crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5.clone()), move |spot_sites_f_9490: crate::prelude::Array<crate::check::shrink::walk::Site>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&spot_sites_f_9490, &a1_p4, &(|a2_p6: &crate::prelude::Array<crate::prelude::Text>, site_p7: &crate::check::shrink::walk::Site| match crate::check::shrink::locals::local_target_o(&sk_p0xy, &d_p1xy, site_p7) {
                    ::std::option::Option::Some(t_p8) => crate::check::types::add_text_f(a2_p6, &t_p8),
                    ::std::option::Option::None => if crate::check::shrink::relations::is_local_f(&site_p7.rels_p, &site_p7.callee_p) || crate::check::env::has_key_f(&sk_p0xy.local_of_p, &d_p1xy.qk_p) {
                        a2_p6.clone()
                    } else {
                        match crate::check::shrink::locals::resolve_callee_o(&sk_p0xy.g_p, &d_p1xy.home_p, &site_p7.callee_p) {
                            ::std::option::Option::Some(k_p9) => crate::prelude::fold(&crate::check::shrink::types::targets_of_f(&sk_p0xy, &k_p9), a2_p6, &(|a3_pa: &crate::prelude::Array<crate::prelude::Text>, t_pb: &crate::prelude::Text| if crate::check::env::has_key_f(&sk_p0xy.by_key_p, t_pb) {
                                crate::check::types::add_text_f(a3_pa, t_pb)
                            } else {
                                a3_pa.clone()
                            })),
                            ::std::option::Option::None => a2_p6.clone(),
                        }
                    },
                }))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }))
}

/// The step machine of `SpotsRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
/// ```
pub struct SpotsRefs {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub spots_p2: crate::prelude::Array<crate::check::shrink::walk::Spot>,
    pub acc_p3: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for SpotsRefs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let spots_p2 = &self.spots_p2;
        let acc_p3 = &self.acc_p3;
        crate::prelude::fold_job(spots_p2.clone(), acc_p3.clone(), {
            let sk_p0x = sk_p0.clone();
            let d_p1x = d_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::shrink::walk::Spot)| {
                let sk_p0xy = sk_p0x.clone();
                let d_p1xy = d_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a1_p4 = p0;
                    let sp_p5 = p1;
                    crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5.clone()), move |spot_sites_f_9490: crate::prelude::Array<crate::check::shrink::walk::Site>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&spot_sites_f_9490, &a1_p4, &(|a2_p6: &crate::prelude::Array<crate::prelude::Text>, site_p7: &crate::check::shrink::walk::Site| match crate::check::shrink::locals::local_target_o(&sk_p0xy, &d_p1xy, site_p7) {
                        ::std::option::Option::Some(t_p8) => crate::check::types::add_text_f(a2_p6, &t_p8),
                        ::std::option::Option::None => if crate::check::shrink::relations::is_local_f(&site_p7.rels_p, &site_p7.callee_p) || crate::check::env::has_key_f(&sk_p0xy.local_of_p, &d_p1xy.qk_p) {
                            a2_p6.clone()
                        } else {
                            match crate::check::shrink::locals::resolve_callee_o(&sk_p0xy.g_p, &d_p1xy.home_p, &site_p7.callee_p) {
                                ::std::option::Option::Some(k_p9) => crate::prelude::fold(&crate::check::shrink::types::targets_of_f(&sk_p0xy, &k_p9), a2_p6, &(|a3_pa: &crate::prelude::Array<crate::prelude::Text>, t_pb: &crate::prelude::Text| if crate::check::env::has_key_f(&sk_p0xy.by_key_p, t_pb) {
                                    crate::check::types::add_text_f(a3_pa, t_pb)
                                } else {
                                    a3_pa.clone()
                                })),
                                ::std::option::Option::None => a2_p6.clone(),
                            }
                        },
                    }))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }).cycle()
    }
}

/// `Start SpotsRefs, x`: what the function value is when passed to `@Run`.
pub fn start_spots_refs_f(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, spots_p2: crate::prelude::Array<crate::check::shrink::walk::Spot>, acc_p3: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(SpotsRefs { sk_p0, d_p1, spots_p2, acc_p3 })
}
