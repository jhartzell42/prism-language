//! The module `Check.Shrink.Calls`, from `target/bootstrap/src/prismc/check/shrink/calls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Slot`:
///
/// ```prism
/// type Slot = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Slot_ {
    pub owner: Text,
    pub at: Nat,
    pub arity: Nat,
}

impl Show for Slot_ {
    fn show(&self, p: &mut Printer) {
        p.record("Slot", &[("owner", &self.owner), ("at", &self.at), ("arity", &self.arity)]);
    }
}

impl ToPod for Slot_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Slot", vec![("owner", self.owner.to_pod()), ("at", self.at.to_pod()), ("arity", self.arity.to_pod())])
    }
}

impl FromPod for Slot_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Slot_ { owner: FromPod::from_pod(field(p, "owner")?)?, at: FromPod::from_pod(field(p, "at")?)?, arity: FromPod::from_pod(field(p, "arity")?)? })
    }
}

/// ```prism
/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
/// ```
pub fn hof_seeds(sk: &crate::check::shrink::Shrink, homes: &Array<Text>) -> Map<Text, Map<Text, crate::check::shrink::Rel>> {
    let cands = hof_candidates(sk);
    let cleared = clear_slots(sk, homes, &cands, &Nat::from(0u32));
    let sums = slot_sums(sk, homes, &cleared, &top_sums(&cleared), &Nat::from(0u32));
    fold(homes, &Map::new(), &(|m: &Map<Text, Map<Text, crate::check::shrink::Rel>>, h: &Text| insert(m, h, &slot_seeds(sk, h, &cleared, &sums, &false))))
}

/// The step machine of `HofSeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
/// ```
pub struct HofSeeds {
    pub sk: crate::check::shrink::Shrink,
    pub homes: Array<Text>,
}

impl prism_rtl::Job<Map<Text, Map<Text, crate::check::shrink::Rel>>> for HofSeeds {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Map<Text, crate::check::shrink::Rel>>> {
        let sk = &self.sk;
        let homes = &self.homes;
        let cands = hof_candidates(sk);
        let homes = homes.clone();
        let sk = sk.clone();
        call_then(start_clear_slots(sk.clone(), homes.clone(), cands.clone(), Nat::from(0u32)), move |clear_slots_2618: Array<Slot_>| {
            let cleared = clear_slots_2618;
            call_then(start_slot_sums(sk.clone(), homes.clone(), cleared.clone(), top_sums(&cleared), Nat::from(0u32)), move |slot_sums_2664: Map<Text, crate::check::shrink::Rel>| {
                let sums = slot_sums_2664;
                prism_rtl::Turn::Finished(fold(&homes, &Map::new(), &(|m: &Map<Text, Map<Text, crate::check::shrink::Rel>>, h: &Text| insert(m, h, &slot_seeds(&sk, h, &cleared, &sums, &false)))))
            })
        })
    }
}

/// `Start HofSeeds, x`: what the function value is when passed to `@Run`.
pub fn start_hof_seeds(sk: crate::check::shrink::Shrink, homes: Array<Text>) -> Rc<dyn prism_rtl::Job<Map<Text, Map<Text, crate::check::shrink::Rel>>>> {
    Rc::new(HofSeeds { sk, homes })
}

/// ```prism
/// HofCandidates: fn Shrink -> [Slot]
/// ```
pub fn hof_candidates(sk: &crate::check::shrink::Shrink) -> Array<Slot_> {
    fold(&sk.fns, &Array::new(), &(|acc: &Array<Slot_>, d: &crate::check::env::Def| match &d.body {
        crate::check::env::DefBody::DbFn(clauses) => match get(&sk.g.vals, &d.qk) {
            Some(v_) => match &v_.scheme.ty {
                crate::check::types::Ty::TyFn(_, ps, _) => fold(&crate::check::errors::range0(&len(ps)), acc, &(|a2: &Array<Slot_>, j: &Nat| match index(ps, j) {
                    Some(crate::check::types::Ty::TyFn(_, fps, _)) => if fold(clauses, &true, &(|ok_: &bool, c: &crate::syntax::decls::FnClause| *ok_ && slot_named(c, j))) {
                        push(a2, &Slot_ { owner: d.qk.clone(), at: j.clone(), arity: len(&fps) })
                    } else {
                        a2.clone()
                    },
                    _ => a2.clone(),
                })),
                _ => acc.clone(),
            },
            None => acc.clone(),
        },
        _ => acc.clone(),
    }))
}

/// ```prism
/// SlotNamed: fn FnClause, Nat -> Bool
/// ```
pub fn slot_named(c: &crate::syntax::decls::FnClause, j: &Nat) -> bool {
    match index(&c.params, j) {
        Some(p_) => match &*p_.kind {
            crate::syntax::PatternKind::PName(_) => true,
            crate::syntax::PatternKind::PIgnore => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// SlotName: fn FnClause, Nat -> Text
/// ```
pub fn slot_name(c: &crate::syntax::decls::FnClause, j: &Nat) -> Text {
    match index(&c.params, j) {
        Some(p_) => match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => crate::check::env::sname_key(n),
            _ => Text::lit(""),
        },
        None => Text::lit(""),
    }
}

/// ```prism
/// SlotSeeds: fn Shrink, Text, [Slot], (Text ==> Rel), Bool -> (Text ==> Rel)
/// ```
pub fn slot_seeds(sk: &crate::check::shrink::Shrink, h: &Text, slots: &Array<Slot_>, sums: &Map<Text, crate::check::shrink::Rel>, with_top: &bool) -> Map<Text, crate::check::shrink::Rel> {
    let pre = or(&get(&sk.seeds, h), &Map::new());
    let start = if *with_top {
        insert(&pre, &Text::lit("⊤"), &crate::check::shrink::Rel { param: crate::check::shrink::walk::top_param(), strict: false })
    } else {
        pre.clone()
    };
    fold(slots, &start, &(|m: &Map<Text, crate::check::shrink::Rel>, sl: &Slot_| fold(&spellings(&sk.g, h, &sl.owner), m, &(|m2: &Map<Text, crate::check::shrink::Rel>, sp: &Text| {
        let m3 = insert(m2, &Text::from(format!("acc:{}:{}", sp, &sl.at)), &crate::check::shrink::Rel { param: sl.arity.clone(), strict: false });
        fold(&crate::check::errors::range0(&sl.arity), &m3, &(|m4: &Map<Text, crate::check::shrink::Rel>, q: &Nat| match get(sums, &Text::from(format!("{}:{}:{}", &sl.owner, &sl.at, q))) {
            Some(r) => if (&r.param == &crate::check::shrink::walk::top_param()) && !*with_top {
                m4.clone()
            } else {
                insert(m4, &Text::from(format!("sum:{}:{}:{}", sp, &sl.at, q)), &r)
            },
            None => m4.clone(),
        }))
    }))))
}

/// ```prism
/// Spellings: fn G, Text, Text -> [Text]
/// ```
pub fn spellings(g: &crate::check::env::G, h: &Text, k: &Text) -> Array<Text> {
    filter(&crate::check::types::add_text(&Array::from(vec![crate::check::types::bare_name(k)]), k), &(|sp: &Text| &crate::check::shrink::locals::resolve_name(g, h, sp) == &Some(k.clone())))
}

/// ```prism
/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
/// ```
pub fn clear_slots(sk: &crate::check::shrink::Shrink, homes: &Array<Text>, slots: &Array<Slot_>, round: &Nat) -> Array<Slot_> {
    let sks = seeds_for(sk, homes, slots, &Map::new(), &false);
    let kept = run_to_end(filter_job(slots.clone(), {
        let sks = sks.clone();
        Rc::new(move |p0: Slot_| {
            let sks = sks.clone();
            entered(once_job(move || {
                let sl = p0;
                call_then(start_slot_escapes(sks.clone(), sl.clone()), move |slot_escapes_5090: bool| prism_rtl::Turn::Finished(!slot_escapes_5090))
            }))
        }) as Rc<dyn Fn(Slot_) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    if &len(&kept) == &len(slots) {
        kept.clone()
    } else {
        if round > &Nat::from(20u32) {
            Array::new()
        } else {
            clear_slots(sk, homes, &kept, &(round + &Nat::from(1u32)))
        }
    }
}

/// The step machine of `ClearSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
/// ```
pub struct ClearSlots {
    pub sk: crate::check::shrink::Shrink,
    pub homes: Array<Text>,
    pub slots: Array<Slot_>,
    pub round: Nat,
}

impl prism_rtl::Job<Array<Slot_>> for ClearSlots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Slot_>> {
        let sk = &self.sk;
        let homes = &self.homes;
        let slots = &self.slots;
        let round = &self.round;
        let sks = seeds_for(sk, homes, slots, &Map::new(), &false);
        let homes = homes.clone();
        let round = round.clone();
        let sk = sk.clone();
        let slots = slots.clone();
        call_value(filter_job(slots.clone(), {
            let sks = sks.clone();
            Rc::new(move |p0: Slot_| {
                let sks = sks.clone();
                entered(once_job(move || {
                    let sl = p0;
                    call_then(start_slot_escapes(sks.clone(), sl.clone()), move |slot_escapes_5090: bool| prism_rtl::Turn::Finished(!slot_escapes_5090))
                }))
            }) as Rc<dyn Fn(Slot_) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |filter_5065: Array<Slot_>| {
            let kept = filter_5065;
            if &len(&kept) == &len(&slots) {
                prism_rtl::Turn::Finished(kept.clone())
            } else {
                if &round > &Nat::from(20u32) {
                    prism_rtl::Turn::Finished(Array::new())
                } else {
                    prism_rtl::Turn::More(Rc::new(ClearSlots { sk: sk.clone(), homes: homes.clone(), slots: kept.clone(), round: &round + &Nat::from(1u32) }))
                }
            }
        })
    }
}

/// `Start ClearSlots, x`: what the function value is when passed to `@Run`.
pub fn start_clear_slots(sk: crate::check::shrink::Shrink, homes: Array<Text>, slots: Array<Slot_>, round: Nat) -> Rc<dyn prism_rtl::Job<Array<Slot_>>> {
    Rc::new(ClearSlots { sk, homes, slots, round })
}

/// ```prism
/// SeedsFor: fn Shrink, [Text], [Slot], (Text ==> Rel), Bool -> Shrink
/// ```
pub fn seeds_for(sk: &crate::check::shrink::Shrink, homes: &Array<Text>, slots: &Array<Slot_>, sums: &Map<Text, crate::check::shrink::Rel>, with_top: &bool) -> crate::check::shrink::Shrink {
    let mut this: crate::check::shrink::Shrink = sk.clone();
    this.seeds = fold(homes, &Map::new(), &(|m: &Map<Text, Map<Text, crate::check::shrink::Rel>>, h: &Text| insert(m, h, &slot_seeds(sk, h, slots, sums, with_top))));
    this
}

/// ```prism
/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
/// ```
pub fn slot_escapes(sk: &crate::check::shrink::Shrink, sl: &Slot_) -> bool {
    match get(&sk.by_key, &sl.owner) {
        Some(d) => run_to_end(fold_job(crate::check::shrink::types::def_clauses(&d), false, {
            let sl = sl.clone();
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                let sl = sl.clone();
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let c = p1;
                    {
                        let n = slot_name(&c, &sl.at);
                        if seen || (&n == &Text::lit("")) {
                            prism_rtl::Turn::Finished(seen)
                        } else {
                            call_then(crate::check::shrink::locals::start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_5891: Map<Text, crate::check::shrink::Rel>| call_then(crate::check::shrink::walk::start_body_spots(c.body.clone(), clause_base_5891), move |body_spots_5872: Array<crate::check::shrink::walk::Spot>| fold_job(body_spots_5872, false, {
                                let n = n.clone();
                                let sl = sl.clone();
                                Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                                    let n = n.clone();
                                    let sl = sl.clone();
                                    entered(once_job(move || {
                                        let esc = p0;
                                        let sp = p1;
                                        prism_rtl::Turn::Finished(esc || spot_escapes(&sp, &n, &sl.at))
                                    }))
                                }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }).cycle()))
                        }
                    }
                }))
            }) as Rc<dyn Fn((bool, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        None => true,
    }
}

/// The step machine of `SlotEscapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
/// ```
pub struct SlotEscapes {
    pub sk: crate::check::shrink::Shrink,
    pub sl: Slot_,
}

impl prism_rtl::Job<bool> for SlotEscapes {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let sk = &self.sk;
        let sl = &self.sl;
        match get(&sk.by_key, &sl.owner) {
            Some(d) => fold_job(crate::check::shrink::types::def_clauses(&d), false, {
                let sl = sl.clone();
                let sk = sk.clone();
                let d = d.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                    let sl = sl.clone();
                    let sk = sk.clone();
                    let d = d.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let c = p1;
                        {
                            let n = slot_name(&c, &sl.at);
                            if seen || (&n == &Text::lit("")) {
                                prism_rtl::Turn::Finished(seen)
                            } else {
                                call_then(crate::check::shrink::locals::start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_5891: Map<Text, crate::check::shrink::Rel>| call_then(crate::check::shrink::walk::start_body_spots(c.body.clone(), clause_base_5891), move |body_spots_5872: Array<crate::check::shrink::walk::Spot>| fold_job(body_spots_5872, false, {
                                    let n = n.clone();
                                    let sl = sl.clone();
                                    Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                                        let n = n.clone();
                                        let sl = sl.clone();
                                        entered(once_job(move || {
                                            let esc = p0;
                                            let sp = p1;
                                            prism_rtl::Turn::Finished(esc || spot_escapes(&sp, &n, &sl.at))
                                        }))
                                    }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
                                }).cycle()))
                            }
                        }
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            None => prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start SlotEscapes, x`: what the function value is when passed to `@Run`.
pub fn start_slot_escapes(sk: crate::check::shrink::Shrink, sl: Slot_) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SlotEscapes { sk, sl })
}

/// ```prism
/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub fn spot_escapes(sp: &crate::check::shrink::walk::Spot, n: &Text, j: &Nat) -> bool {
    match sp {
        crate::check::shrink::walk::Spot::SpotExpr(e, m) => match &*e.kind {
            crate::syntax::ExprKind::EName(x) => (&crate::check::env::sname_key(x) == n) && is_slot_param(m, n, j),
            _ => fold(&crate::check::shrink::walk::spot_sites(sp), &false, &(|seen: &bool, site: &crate::check::shrink::walk::Site| *seen || (((&site.callee == n) && is_slot_param(&site.rels, n, j)) && crate::check::env::has_key(&site.rels, &Text::lit("lam:"))))),
        },
        crate::check::shrink::walk::Spot::SpotStmt(_, _) => false,
    }
}

/// The step machine of `SpotEscapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub struct SpotEscapes {
    pub sp: crate::check::shrink::walk::Spot,
    pub n: Text,
    pub j: Nat,
}

impl prism_rtl::Job<bool> for SpotEscapes {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let sp = &self.sp;
        let n = &self.n;
        let j = &self.j;
        match sp {
            crate::check::shrink::walk::Spot::SpotExpr(e, m) => match &*e.kind {
                crate::syntax::ExprKind::EName(x) => prism_rtl::Turn::Finished((&crate::check::env::sname_key(x) == n) && is_slot_param(m, n, j)),
                _ => {
                    let j = j.clone();
                    let n = n.clone();
                    let sp = sp.clone();
                    call_then(crate::check::shrink::walk::start_spot_sites(sp.clone()), move |spot_sites_6182: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(fold(&spot_sites_6182, &false, &(|seen: &bool, site: &crate::check::shrink::walk::Site| *seen || (((&site.callee == &n) && is_slot_param(&site.rels, &n, &j)) && crate::check::env::has_key(&site.rels, &Text::lit("lam:")))))))
                },
            },
            crate::check::shrink::walk::Spot::SpotStmt(_, _) => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start SpotEscapes, x`: what the function value is when passed to `@Run`.
pub fn start_spot_escapes(sp: crate::check::shrink::walk::Spot, n: Text, j: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SpotEscapes { sp, n, j })
}

/// ```prism
/// IsSlotParam: fn (Text ==> Rel), Text, Nat -> Bool
/// ```
pub fn is_slot_param(m: &Map<Text, crate::check::shrink::Rel>, n: &Text, j: &Nat) -> bool {
    &get(m, n) == &Some(crate::check::shrink::Rel { param: j.clone(), strict: false })
}

/// ```prism
/// TopSums: fn [Slot] -> (Text ==> Rel)
/// ```
pub fn top_sums(slots: &Array<Slot_>) -> Map<Text, crate::check::shrink::Rel> {
    fold(slots, &Map::new(), &(|m: &Map<Text, crate::check::shrink::Rel>, sl: &Slot_| fold(&crate::check::errors::range0(&sl.arity), m, &(|m2: &Map<Text, crate::check::shrink::Rel>, q: &Nat| insert(m2, &Text::from(format!("{}:{}:{}", &sl.owner, &sl.at, q)), &crate::check::shrink::Rel { param: crate::check::shrink::walk::top_param(), strict: false })))))
}

/// ```prism
/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
/// ```
pub fn slot_sums(sk: &crate::check::shrink::Shrink, homes: &Array<Text>, slots: &Array<Slot_>, sums: &Map<Text, crate::check::shrink::Rel>, round: &Nat) -> Map<Text, crate::check::shrink::Rel> {
    let sks = seeds_for(sk, homes, slots, sums, &true);
    let next_ = run_to_end(fold_job(slots.clone(), Map::new(), {
        let sks = sks.clone();
        Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Slot_)| {
            let sks = sks.clone();
            entered(once_job(move || {
                let m = p0;
                let sl = p1;
                call_then(start_slot_calls(sks.clone(), sl.clone()), move |slot_calls_7327: Array<crate::check::shrink::walk::Site>| {
                    let calls = slot_calls_7327;
                    fold_job(crate::check::errors::range0(&sl.arity), m.clone(), {
                        let calls = calls.clone();
                        let sl = sl.clone();
                        Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Nat)| {
                            let calls = calls.clone();
                            let sl = sl.clone();
                            entered(once_job(move || {
                                let m2 = p0;
                                let q = p1;
                                call_then(start_meet_args(calls.clone(), q.clone()), move |meet_args_7395: Option<crate::check::shrink::Rel>| match meet_args_7395 {
                                    Some(r) => prism_rtl::Turn::Finished(insert(&m2, &Text::from(format!("{}:{}:{}", &sl.owner, &sl.at, &q)), &r)),
                                    None => prism_rtl::Turn::Finished(m2.clone()),
                                })
                            }))
                        }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
                    }).cycle()
                })
            }))
        }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Slot_)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
    }));
    if &next_ == sums {
        next_.clone()
    } else {
        if round > &Nat::from(12u32) {
            Map::new()
        } else {
            slot_sums(sk, homes, slots, &next_, &(round + &Nat::from(1u32)))
        }
    }
}

/// The step machine of `SlotSums`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
/// ```
pub struct SlotSums {
    pub sk: crate::check::shrink::Shrink,
    pub homes: Array<Text>,
    pub slots: Array<Slot_>,
    pub sums: Map<Text, crate::check::shrink::Rel>,
    pub round: Nat,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for SlotSums {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let sk = &self.sk;
        let homes = &self.homes;
        let slots = &self.slots;
        let sums = &self.sums;
        let round = &self.round;
        let sks = seeds_for(sk, homes, slots, sums, &true);
        let homes = homes.clone();
        let round = round.clone();
        let sk = sk.clone();
        let slots = slots.clone();
        let sums = sums.clone();
        call_value(fold_job(slots.clone(), Map::new(), {
            let sks = sks.clone();
            Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Slot_)| {
                let sks = sks.clone();
                entered(once_job(move || {
                    let m = p0;
                    let sl = p1;
                    call_then(start_slot_calls(sks.clone(), sl.clone()), move |slot_calls_7327: Array<crate::check::shrink::walk::Site>| {
                        let calls = slot_calls_7327;
                        fold_job(crate::check::errors::range0(&sl.arity), m.clone(), {
                            let calls = calls.clone();
                            let sl = sl.clone();
                            Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Nat)| {
                                let calls = calls.clone();
                                let sl = sl.clone();
                                entered(once_job(move || {
                                    let m2 = p0;
                                    let q = p1;
                                    call_then(start_meet_args(calls.clone(), q.clone()), move |meet_args_7395: Option<crate::check::shrink::Rel>| match meet_args_7395 {
                                        Some(r) => prism_rtl::Turn::Finished(insert(&m2, &Text::from(format!("{}:{}:{}", &sl.owner, &sl.at, &q)), &r)),
                                        None => prism_rtl::Turn::Finished(m2.clone()),
                                    })
                                }))
                            }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
                        }).cycle()
                    })
                }))
            }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Slot_)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
        }), move |fold_7282: Map<Text, crate::check::shrink::Rel>| {
            let next_ = fold_7282;
            if &next_ == &sums {
                prism_rtl::Turn::Finished(next_.clone())
            } else {
                if &round > &Nat::from(12u32) {
                    prism_rtl::Turn::Finished(Map::new())
                } else {
                    prism_rtl::Turn::More(Rc::new(SlotSums { sk: sk.clone(), homes: homes.clone(), slots: slots.clone(), sums: next_.clone(), round: &round + &Nat::from(1u32) }))
                }
            }
        })
    }
}

/// `Start SlotSums, x`: what the function value is when passed to `@Run`.
pub fn start_slot_sums(sk: crate::check::shrink::Shrink, homes: Array<Text>, slots: Array<Slot_>, sums: Map<Text, crate::check::shrink::Rel>, round: Nat) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(SlotSums { sk, homes, slots, sums, round })
}

/// ```prism
/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
/// ```
pub fn slot_calls(sk: &crate::check::shrink::Shrink, sl: &Slot_) -> Array<crate::check::shrink::walk::Site> {
    match get(&sk.by_key, &sl.owner) {
        Some(d) => run_to_end(fold_job(crate::check::shrink::types::def_clauses(&d), Array::new(), {
            let sl = sl.clone();
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause)| {
                let sl = sl.clone();
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let c = p1;
                    {
                        let n = slot_name(&c, &sl.at);
                        if &n == &Text::lit("") {
                            prism_rtl::Turn::Finished(acc.clone())
                        } else {
                            call_then(crate::check::shrink::locals::start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_7920: Map<Text, crate::check::shrink::Rel>| {
                                let base = clause_base_7920;
                                call_then(crate::check::shrink::walk::start_body_spots(c.body.clone(), base.clone()), move |body_spots_7984: Array<crate::check::shrink::walk::Spot>| call_then(crate::check::shrink::summaries::start_summary_seeds(sk.clone(), d.clone(), body_spots_7984, base.clone()), move |summary_seeds_7963: Map<Text, crate::check::shrink::Rel>| {
                                    let rels = summary_seeds_7963;
                                    call_then(crate::check::shrink::walk::start_body_spots(c.body.clone(), rels.clone()), move |body_spots_8032: Array<crate::check::shrink::walk::Spot>| fold_job(body_spots_8032, acc.clone(), {
                                        let n = n.clone();
                                        let sl = sl.clone();
                                        Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)| {
                                            let n = n.clone();
                                            let sl = sl.clone();
                                            entered(once_job(move || {
                                                let a2 = p0;
                                                let sp = p1;
                                                match &sp {
                                                    crate::check::shrink::walk::Spot::SpotExpr(e, _) => match &*e.kind {
                                                        crate::syntax::ExprKind::EName(_) => prism_rtl::Turn::Finished(a2.clone()),
                                                        _ => call_then(crate::check::shrink::walk::start_spot_sites(sp.clone()), move |spot_sites_8220: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(append(&a2, &filter(&spot_sites_8220, &(|site: &crate::check::shrink::walk::Site| (&site.callee == &n) && is_slot_param(&site.rels, &n, &sl.at)))))),
                                                    },
                                                    _ => prism_rtl::Turn::Finished(a2.clone()),
                                                }
                                            }))
                                        }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Site>>>>
                                    }).cycle())
                                }))
                            })
                        }
                    }
                }))
            }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Site>>>>
        })),
        None => Array::new(),
    }
}

/// The step machine of `SlotCalls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
/// ```
pub struct SlotCalls {
    pub sk: crate::check::shrink::Shrink,
    pub sl: Slot_,
}

impl prism_rtl::Job<Array<crate::check::shrink::walk::Site>> for SlotCalls {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::shrink::walk::Site>> {
        let sk = &self.sk;
        let sl = &self.sl;
        match get(&sk.by_key, &sl.owner) {
            Some(d) => fold_job(crate::check::shrink::types::def_clauses(&d), Array::new(), {
                let sl = sl.clone();
                let sk = sk.clone();
                let d = d.clone();
                Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause)| {
                    let sl = sl.clone();
                    let sk = sk.clone();
                    let d = d.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let c = p1;
                        {
                            let n = slot_name(&c, &sl.at);
                            if &n == &Text::lit("") {
                                prism_rtl::Turn::Finished(acc.clone())
                            } else {
                                call_then(crate::check::shrink::locals::start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_7920: Map<Text, crate::check::shrink::Rel>| {
                                    let base = clause_base_7920;
                                    call_then(crate::check::shrink::walk::start_body_spots(c.body.clone(), base.clone()), move |body_spots_7984: Array<crate::check::shrink::walk::Spot>| call_then(crate::check::shrink::summaries::start_summary_seeds(sk.clone(), d.clone(), body_spots_7984, base.clone()), move |summary_seeds_7963: Map<Text, crate::check::shrink::Rel>| {
                                        let rels = summary_seeds_7963;
                                        call_then(crate::check::shrink::walk::start_body_spots(c.body.clone(), rels.clone()), move |body_spots_8032: Array<crate::check::shrink::walk::Spot>| fold_job(body_spots_8032, acc.clone(), {
                                            let n = n.clone();
                                            let sl = sl.clone();
                                            Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)| {
                                                let n = n.clone();
                                                let sl = sl.clone();
                                                entered(once_job(move || {
                                                    let a2 = p0;
                                                    let sp = p1;
                                                    match &sp {
                                                        crate::check::shrink::walk::Spot::SpotExpr(e, _) => match &*e.kind {
                                                            crate::syntax::ExprKind::EName(_) => prism_rtl::Turn::Finished(a2.clone()),
                                                            _ => call_then(crate::check::shrink::walk::start_spot_sites(sp.clone()), move |spot_sites_8220: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(append(&a2, &filter(&spot_sites_8220, &(|site: &crate::check::shrink::walk::Site| (&site.callee == &n) && is_slot_param(&site.rels, &n, &sl.at)))))),
                                                        },
                                                        _ => prism_rtl::Turn::Finished(a2.clone()),
                                                    }
                                                }))
                                            }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Site>>>>
                                        }).cycle())
                                    }))
                                })
                            }
                        }
                    }))
                }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Site>>>>
            }).cycle(),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start SlotCalls, x`: what the function value is when passed to `@Run`.
pub fn start_slot_calls(sk: crate::check::shrink::Shrink, sl: Slot_) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Site>>> {
    Rc::new(SlotCalls { sk, sl })
}

/// ```prism
/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
/// ```
pub fn meet_args(calls: &Array<crate::check::shrink::walk::Site>, q: &Nat) -> Option<crate::check::shrink::Rel> {
    run_to_end(fold_job(calls.clone(), Some(crate::check::shrink::Rel { param: crate::check::shrink::walk::top_param(), strict: false }), {
        let q = q.clone();
        Rc::new(move |(p0, p1): (Option<crate::check::shrink::Rel>, crate::check::shrink::walk::Site)| {
            let q = q.clone();
            entered(once_job(move || {
                let acc_opt = p0;
                let site = p1;
                match &acc_opt {
                    None => prism_rtl::Turn::Finished(None),
                    Some(acc) => match index(&site.args, &q) {
                        Some(a) => if &a.name != &None {
                            prism_rtl::Turn::Finished(None)
                        } else {
                            {
                                let acc = acc.clone();
                                call_then(crate::check::shrink::walk::start_rel_of(site.rels.clone(), a.value.clone()), move |rel_of_8797: Option<crate::check::shrink::Rel>| match rel_of_8797 {
                                    Some(r) => if &r.param == &crate::check::shrink::walk::top_param() {
                                        prism_rtl::Turn::Finished(Some(acc.clone()))
                                    } else {
                                        if &acc.param == &crate::check::shrink::walk::top_param() {
                                            prism_rtl::Turn::Finished(Some(r.clone()))
                                        } else {
                                            if &acc.param == &r.param {
                                                prism_rtl::Turn::Finished(Some(crate::check::shrink::Rel { param: r.param.clone(), strict: acc.strict && r.strict }))
                                            } else {
                                                prism_rtl::Turn::Finished(None)
                                            }
                                        }
                                    },
                                    None => prism_rtl::Turn::Finished(None),
                                })
                            }
                        },
                        None => prism_rtl::Turn::Finished(None),
                    },
                }
            }))
        }) as Rc<dyn Fn((Option<crate::check::shrink::Rel>, crate::check::shrink::walk::Site)) -> Rc<dyn prism_rtl::Job<Option<crate::check::shrink::Rel>>>>
    }))
}

/// The step machine of `MeetArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
/// ```
pub struct MeetArgs {
    pub calls: Array<crate::check::shrink::walk::Site>,
    pub q: Nat,
}

impl prism_rtl::Job<Option<crate::check::shrink::Rel>> for MeetArgs {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::check::shrink::Rel>> {
        let calls = &self.calls;
        let q = &self.q;
        fold_job(calls.clone(), Some(crate::check::shrink::Rel { param: crate::check::shrink::walk::top_param(), strict: false }), {
            let q = q.clone();
            Rc::new(move |(p0, p1): (Option<crate::check::shrink::Rel>, crate::check::shrink::walk::Site)| {
                let q = q.clone();
                entered(once_job(move || {
                    let acc_opt = p0;
                    let site = p1;
                    match &acc_opt {
                        None => prism_rtl::Turn::Finished(None),
                        Some(acc) => match index(&site.args, &q) {
                            Some(a) => if &a.name != &None {
                                prism_rtl::Turn::Finished(None)
                            } else {
                                {
                                    let acc = acc.clone();
                                    call_then(crate::check::shrink::walk::start_rel_of(site.rels.clone(), a.value.clone()), move |rel_of_8797: Option<crate::check::shrink::Rel>| match rel_of_8797 {
                                        Some(r) => if &r.param == &crate::check::shrink::walk::top_param() {
                                            prism_rtl::Turn::Finished(Some(acc.clone()))
                                        } else {
                                            if &acc.param == &crate::check::shrink::walk::top_param() {
                                                prism_rtl::Turn::Finished(Some(r.clone()))
                                            } else {
                                                if &acc.param == &r.param {
                                                    prism_rtl::Turn::Finished(Some(crate::check::shrink::Rel { param: r.param.clone(), strict: acc.strict && r.strict }))
                                                } else {
                                                    prism_rtl::Turn::Finished(None)
                                                }
                                            }
                                        },
                                        None => prism_rtl::Turn::Finished(None),
                                    })
                                }
                            },
                            None => prism_rtl::Turn::Finished(None),
                        },
                    }
                }))
            }) as Rc<dyn Fn((Option<crate::check::shrink::Rel>, crate::check::shrink::walk::Site)) -> Rc<dyn prism_rtl::Job<Option<crate::check::shrink::Rel>>>>
        }).cycle()
    }
}

/// `Start MeetArgs, x`: what the function value is when passed to `@Run`.
pub fn start_meet_args(calls: Array<crate::check::shrink::walk::Site>, q: Nat) -> Rc<dyn prism_rtl::Job<Option<crate::check::shrink::Rel>>> {
    Rc::new(MeetArgs { calls, q })
}

/// ```prism
/// DefRefs: unbounded fn Shrink, Def -> [Text]
/// ```
pub fn def_refs(sk: &crate::check::shrink::Shrink, d: &crate::check::env::Def) -> Array<Text> {
    run_to_end(fold_job(crate::check::shrink::types::def_clauses(d), Array::new(), {
        let sk = sk.clone();
        let d = d.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::decls::FnClause)| {
            let sk = sk.clone();
            let d = d.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                call_then(crate::check::shrink::locals::start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_9334: Map<Text, crate::check::shrink::Rel>| call_then(crate::check::shrink::walk::start_body_spots(c.body.clone(), clause_base_9334), move |body_spots_9315: Array<crate::check::shrink::walk::Spot>| prism_rtl::Turn::More(Rc::new(SpotsRefs { sk: sk.clone(), d: d.clone(), spots: body_spots_9315, acc: acc.clone() }))))
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `DefRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefRefs: unbounded fn Shrink, Def -> [Text]
/// ```
pub struct DefRefs {
    pub sk: crate::check::shrink::Shrink,
    pub d: crate::check::env::Def,
}

impl prism_rtl::Job<Array<Text>> for DefRefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let d = &self.d;
        fold_job(crate::check::shrink::types::def_clauses(d), Array::new(), {
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::decls::FnClause)| {
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let c = p1;
                    call_then(crate::check::shrink::locals::start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_9334: Map<Text, crate::check::shrink::Rel>| call_then(crate::check::shrink::walk::start_body_spots(c.body.clone(), clause_base_9334), move |body_spots_9315: Array<crate::check::shrink::walk::Spot>| prism_rtl::Turn::More(Rc::new(SpotsRefs { sk: sk.clone(), d: d.clone(), spots: body_spots_9315, acc: acc.clone() }))))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start DefRefs, x`: what the function value is when passed to `@Run`.
pub fn start_def_refs(sk: crate::check::shrink::Shrink, d: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(DefRefs { sk, d })
}

/// ```prism
/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
/// ```
pub fn spots_refs(sk: &crate::check::shrink::Shrink, d: &crate::check::env::Def, spots: &Array<crate::check::shrink::walk::Spot>, acc: &Array<Text>) -> Array<Text> {
    run_to_end(fold_job(spots.clone(), acc.clone(), {
        let sk = sk.clone();
        let d = d.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::walk::Spot)| {
            let sk = sk.clone();
            let d = d.clone();
            entered(once_job(move || {
                let a1 = p0;
                let sp = p1;
                call_then(crate::check::shrink::walk::start_spot_sites(sp.clone()), move |spot_sites_9490: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(fold(&spot_sites_9490, &a1, &(|a2: &Array<Text>, site: &crate::check::shrink::walk::Site| match crate::check::shrink::locals::local_target(&sk, &d, site) {
                    Some(t) => crate::check::types::add_text(a2, &t),
                    None => if crate::check::shrink::relations::is_local(&site.rels, &site.callee) || crate::check::env::has_key(&sk.local_of, &d.qk) {
                        a2.clone()
                    } else {
                        match crate::check::shrink::locals::resolve_callee(&sk.g, &d.home, &site.callee) {
                            Some(k) => fold(&crate::check::shrink::types::targets_of(&sk, &k), a2, &(|a3: &Array<Text>, t: &Text| if crate::check::env::has_key(&sk.by_key, t) {
                                crate::check::types::add_text(a3, t)
                            } else {
                                a3.clone()
                            })),
                            None => a2.clone(),
                        }
                    },
                }))))
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `SpotsRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
/// ```
pub struct SpotsRefs {
    pub sk: crate::check::shrink::Shrink,
    pub d: crate::check::env::Def,
    pub spots: Array<crate::check::shrink::walk::Spot>,
    pub acc: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for SpotsRefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let d = &self.d;
        let spots = &self.spots;
        let acc = &self.acc;
        fold_job(spots.clone(), acc.clone(), {
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::walk::Spot)| {
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let a1 = p0;
                    let sp = p1;
                    call_then(crate::check::shrink::walk::start_spot_sites(sp.clone()), move |spot_sites_9490: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(fold(&spot_sites_9490, &a1, &(|a2: &Array<Text>, site: &crate::check::shrink::walk::Site| match crate::check::shrink::locals::local_target(&sk, &d, site) {
                        Some(t) => crate::check::types::add_text(a2, &t),
                        None => if crate::check::shrink::relations::is_local(&site.rels, &site.callee) || crate::check::env::has_key(&sk.local_of, &d.qk) {
                            a2.clone()
                        } else {
                            match crate::check::shrink::locals::resolve_callee(&sk.g, &d.home, &site.callee) {
                                Some(k) => fold(&crate::check::shrink::types::targets_of(&sk, &k), a2, &(|a3: &Array<Text>, t: &Text| if crate::check::env::has_key(&sk.by_key, t) {
                                    crate::check::types::add_text(a3, t)
                                } else {
                                    a3.clone()
                                })),
                                None => a2.clone(),
                            }
                        },
                    }))))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start SpotsRefs, x`: what the function value is when passed to `@Run`.
pub fn start_spots_refs(sk: crate::check::shrink::Shrink, d: crate::check::env::Def, spots: Array<crate::check::shrink::walk::Spot>, acc: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotsRefs { sk, d, spots, acc })
}
