//! The module `Check.Shrink.Calls`, from `target/bootstrap/src/prismc/check/shrink/calls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Slot`:
///
/// ```prism
/// type Slot = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Slot_ {
    pub owner: Text,
    pub at: Nat,
    pub arity: Nat,
}

impl Show for Slot_ {
    fn show(&self, p: &mut Printer) {
        p.record("Slot", &[("owner", &self.owner), ("at", &self.at), ("arity", &self.arity)]);
    }
}

impl ToPod for Slot_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Slot", vec![("owner", self.owner.to_pod()), ("at", self.at.to_pod()), ("arity", self.arity.to_pod())])
    }
}

impl FromPod for Slot_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Slot_ { owner: FromPod::from_pod(field(p, "owner")?)?, at: FromPod::from_pod(field(p, "at")?)?, arity: FromPod::from_pod(field(p, "arity")?)? })
    }
}

/// ```prism
/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
/// ```
pub fn hof_seeds(sk_p0: &crate::check::shrink::Shrink, homes_p1: &Array<Text>) -> Map<Text, Map<Text, crate::check::shrink::Rel>> {
    let cands_p2 = hof_candidates(sk_p0);
    let cleared_p3 = clear_slots(sk_p0, homes_p1, &cands_p2, &Nat::from(0u32));
    let sums_p4 = slot_sums(sk_p0, homes_p1, &cleared_p3, &top_sums(&cleared_p3), &Nat::from(0u32));
    fold(homes_p1, &Map::new(), &(|m_p5: &Map<Text, Map<Text, crate::check::shrink::Rel>>, h_p6: &Text| insert(m_p5, h_p6, &slot_seeds(sk_p0, h_p6, &cleared_p3, &sums_p4, &false))))
}

/// The step machine of `HofSeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
/// ```
pub struct HofSeeds {
    pub sk_p0: crate::check::shrink::Shrink,
    pub homes_p1: Array<Text>,
}

impl prism_rtl::Job<Map<Text, Map<Text, crate::check::shrink::Rel>>> for HofSeeds {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Map<Text, crate::check::shrink::Rel>>> {
        let sk_p0 = &self.sk_p0;
        let homes_p1 = &self.homes_p1;
        let cands_p2 = hof_candidates(sk_p0);
        let homes_p1 = homes_p1.clone();
        let sk_p0 = sk_p0.clone();
        call_then(start_clear_slots(sk_p0.clone(), homes_p1.clone(), cands_p2.clone(), Nat::from(0u32)), move |clear_slots_2618: Array<Slot_>| {
            let cleared_p3 = clear_slots_2618;
            call_then(start_slot_sums(sk_p0.clone(), homes_p1.clone(), cleared_p3.clone(), top_sums(&cleared_p3), Nat::from(0u32)), move |slot_sums_2664: Map<Text, crate::check::shrink::Rel>| {
                let sums_p4 = slot_sums_2664;
                prism_rtl::Turn::Finished(fold(&homes_p1, &Map::new(), &(|m_p5: &Map<Text, Map<Text, crate::check::shrink::Rel>>, h_p6: &Text| insert(m_p5, h_p6, &slot_seeds(&sk_p0, h_p6, &cleared_p3, &sums_p4, &false)))))
            })
        })
    }
}

/// `Start HofSeeds, x`: what the function value is when passed to `@Run`.
pub fn start_hof_seeds(sk_p0: crate::check::shrink::Shrink, homes_p1: Array<Text>) -> Rc<dyn prism_rtl::Job<Map<Text, Map<Text, crate::check::shrink::Rel>>>> {
    Rc::new(HofSeeds { sk_p0, homes_p1 })
}

/// ```prism
/// HofCandidates: fn Shrink -> [Slot]
/// ```
pub fn hof_candidates(sk_p0: &crate::check::shrink::Shrink) -> Array<Slot_> {
    fold(&sk_p0.fns, &Array::new(), &(|acc_p1: &Array<Slot_>, d_p2: &crate::check::env::Def| match &d_p2.body {
        crate::check::env::DefBody::DbFn(clauses_p3) => match get(&sk_p0.g.vals, &d_p2.qk) {
            Some(v_p4) => match &v_p4.scheme.ty {
                crate::check::types::Ty::TyFn(_, ps_p5, _) => fold(&crate::check::errors::range0(&len(ps_p5)), acc_p1, &(|a2_p6: &Array<Slot_>, j_p7: &Nat| match index(ps_p5, j_p7) {
                    Some(crate::check::types::Ty::TyFn(_, fps_p8, _)) => if fold(clauses_p3, &true, &(|ok_p9: &bool, c_pa: &crate::syntax::decls::FnClause| *ok_p9 && slot_named(c_pa, j_p7))) {
                        push(a2_p6, &Slot_ { owner: d_p2.qk.clone(), at: j_p7.clone(), arity: len(&fps_p8) })
                    } else {
                        a2_p6.clone()
                    },
                    _ => a2_p6.clone(),
                })),
                _ => acc_p1.clone(),
            },
            None => acc_p1.clone(),
        },
        _ => acc_p1.clone(),
    }))
}

/// ```prism
/// SlotNamed: fn FnClause, Nat -> Bool
/// ```
pub fn slot_named(c_p0: &crate::syntax::decls::FnClause, j_p1: &Nat) -> bool {
    match index(&c_p0.params, j_p1) {
        Some(p_p2) => match &*p_p2.kind {
            crate::syntax::PatternKind::PName(_) => true,
            crate::syntax::PatternKind::PIgnore => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// SlotName: fn FnClause, Nat -> Text
/// ```
pub fn slot_name(c_p0: &crate::syntax::decls::FnClause, j_p1: &Nat) -> Text {
    match index(&c_p0.params, j_p1) {
        Some(p_p2) => match &*p_p2.kind {
            crate::syntax::PatternKind::PName(n_p3) => crate::check::env::sname_key(n_p3),
            _ => Text::lit(""),
        },
        None => Text::lit(""),
    }
}

/// ```prism
/// SlotSeeds: fn Shrink, Text, [Slot], (Text ==> Rel), Bool -> (Text ==> Rel)
/// ```
pub fn slot_seeds(sk_p0: &crate::check::shrink::Shrink, h_p1: &Text, slots_p2: &Array<Slot_>, sums_p3: &Map<Text, crate::check::shrink::Rel>, with_top_p4: &bool) -> Map<Text, crate::check::shrink::Rel> {
    let pre_p5 = or(&get(&sk_p0.seeds, h_p1), &Map::new());
    let start_p6 = if *with_top_p4 {
        insert(&pre_p5, &Text::lit("⊤"), &crate::check::shrink::Rel { param: crate::check::shrink::walk::top_param(), strict: false })
    } else {
        pre_p5.clone()
    };
    fold(slots_p2, &start_p6, &(|m_p7: &Map<Text, crate::check::shrink::Rel>, sl_p8: &Slot_| fold(&spellings(&sk_p0.g, h_p1, &sl_p8.owner), m_p7, &(|m2_p9: &Map<Text, crate::check::shrink::Rel>, sp_pa: &Text| {
        let m3_pb = insert(m2_p9, &Text::from(format!("acc:{}:{}", sp_pa, &sl_p8.at)), &crate::check::shrink::Rel { param: sl_p8.arity.clone(), strict: false });
        fold(&crate::check::errors::range0(&sl_p8.arity), &m3_pb, &(|m4_pc: &Map<Text, crate::check::shrink::Rel>, q_pd: &Nat| match get(sums_p3, &Text::from(format!("{}:{}:{}", &sl_p8.owner, &sl_p8.at, q_pd))) {
            Some(r_pe) => if (&r_pe.param == &crate::check::shrink::walk::top_param()) && !*with_top_p4 {
                m4_pc.clone()
            } else {
                insert(m4_pc, &Text::from(format!("sum:{}:{}:{}", sp_pa, &sl_p8.at, q_pd)), &r_pe)
            },
            None => m4_pc.clone(),
        }))
    }))))
}

/// ```prism
/// Spellings: fn G, Text, Text -> [Text]
/// ```
pub fn spellings(g_p0: &crate::check::env::G, h_p1: &Text, k_p2: &Text) -> Array<Text> {
    filter(&crate::check::types::add_text(&Array::from(vec![crate::check::types::bare_name(k_p2)]), k_p2), &(|sp_p3: &Text| &crate::check::shrink::locals::resolve_name(g_p0, h_p1, sp_p3) == &Some(k_p2.clone())))
}

/// ```prism
/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
/// ```
pub fn clear_slots(sk_p0: &crate::check::shrink::Shrink, homes_p1: &Array<Text>, slots_p2: &Array<Slot_>, round_p3: &Nat) -> Array<Slot_> {
    let sks_p4 = seeds_for(sk_p0, homes_p1, slots_p2, &Map::new(), &false);
    let kept_p5 = run_to_end(filter_job(slots_p2.clone(), {
        let sks_p4 = sks_p4.clone();
        Rc::new(move |p0: Slot_| {
            let sks_p4 = sks_p4.clone();
            entered(once_job(move || {
                let sl_p6 = p0;
                call_then(start_slot_escapes(sks_p4.clone(), sl_p6.clone()), move |slot_escapes_5090: bool| prism_rtl::Turn::Finished(!slot_escapes_5090))
            }))
        }) as Rc<dyn Fn(Slot_) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    if &len(&kept_p5) == &len(slots_p2) {
        kept_p5.clone()
    } else {
        if round_p3 > &Nat::from(20u32) {
            Array::new()
        } else {
            clear_slots(sk_p0, homes_p1, &kept_p5, &(round_p3 + &Nat::from(1u32)))
        }
    }
}

/// The step machine of `ClearSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
/// ```
pub struct ClearSlots {
    pub sk_p0: crate::check::shrink::Shrink,
    pub homes_p1: Array<Text>,
    pub slots_p2: Array<Slot_>,
    pub round_p3: Nat,
}

impl prism_rtl::Job<Array<Slot_>> for ClearSlots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Slot_>> {
        let sk_p0 = &self.sk_p0;
        let homes_p1 = &self.homes_p1;
        let slots_p2 = &self.slots_p2;
        let round_p3 = &self.round_p3;
        let sks_p4 = seeds_for(sk_p0, homes_p1, slots_p2, &Map::new(), &false);
        let homes_p1 = homes_p1.clone();
        let round_p3 = round_p3.clone();
        let sk_p0 = sk_p0.clone();
        let slots_p2 = slots_p2.clone();
        call_value(filter_job(slots_p2.clone(), {
            let sks_p4 = sks_p4.clone();
            Rc::new(move |p0: Slot_| {
                let sks_p4 = sks_p4.clone();
                entered(once_job(move || {
                    let sl_p6 = p0;
                    call_then(start_slot_escapes(sks_p4.clone(), sl_p6.clone()), move |slot_escapes_5090: bool| prism_rtl::Turn::Finished(!slot_escapes_5090))
                }))
            }) as Rc<dyn Fn(Slot_) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |filter_5065: Array<Slot_>| {
            let kept_p5 = filter_5065;
            if &len(&kept_p5) == &len(&slots_p2) {
                prism_rtl::Turn::Finished(kept_p5.clone())
            } else {
                if &round_p3 > &Nat::from(20u32) {
                    prism_rtl::Turn::Finished(Array::new())
                } else {
                    prism_rtl::Turn::More(Rc::new(ClearSlots { sk_p0: sk_p0.clone(), homes_p1: homes_p1.clone(), slots_p2: kept_p5.clone(), round_p3: &round_p3 + &Nat::from(1u32) }))
                }
            }
        })
    }
}

/// `Start ClearSlots, x`: what the function value is when passed to `@Run`.
pub fn start_clear_slots(sk_p0: crate::check::shrink::Shrink, homes_p1: Array<Text>, slots_p2: Array<Slot_>, round_p3: Nat) -> Rc<dyn prism_rtl::Job<Array<Slot_>>> {
    Rc::new(ClearSlots { sk_p0, homes_p1, slots_p2, round_p3 })
}

/// ```prism
/// SeedsFor: fn Shrink, [Text], [Slot], (Text ==> Rel), Bool -> Shrink
/// ```
pub fn seeds_for(sk_p0: &crate::check::shrink::Shrink, homes_p1: &Array<Text>, slots_p2: &Array<Slot_>, sums_p3: &Map<Text, crate::check::shrink::Rel>, with_top_p4: &bool) -> crate::check::shrink::Shrink {
    let mut this: crate::check::shrink::Shrink = sk_p0.clone();
    this.seeds = fold(homes_p1, &Map::new(), &(|m_p5: &Map<Text, Map<Text, crate::check::shrink::Rel>>, h_p6: &Text| insert(m_p5, h_p6, &slot_seeds(sk_p0, h_p6, slots_p2, sums_p3, with_top_p4))));
    this
}

/// ```prism
/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
/// ```
pub fn slot_escapes(sk_p0: &crate::check::shrink::Shrink, sl_p1: &Slot_) -> bool {
    match get(&sk_p0.by_key, &sl_p1.owner) {
        Some(d_p2) => run_to_end(fold_job(crate::check::shrink::types::def_clauses(&d_p2), false, {
            let sl_p1 = sl_p1.clone();
            let sk_p0 = sk_p0.clone();
            let d_p2 = d_p2.clone();
            Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                let sl_p1 = sl_p1.clone();
                let sk_p0 = sk_p0.clone();
                let d_p2 = d_p2.clone();
                entered(once_job(move || {
                    let seen_p3 = p0;
                    let c_p4 = p1;
                    {
                        let n_p5 = slot_name(&c_p4, &sl_p1.at);
                        if seen_p3 || (&n_p5 == &Text::lit("")) {
                            prism_rtl::Turn::Finished(seen_p3)
                        } else {
                            call_then(crate::check::shrink::locals::start_clause_base(sk_p0.clone(), d_p2.clone(), c_p4.clone()), move |clause_base_5891: Map<Text, crate::check::shrink::Rel>| call_then(crate::check::shrink::walk::start_body_spots(c_p4.body.clone(), clause_base_5891), move |body_spots_5872: Array<crate::check::shrink::walk::Spot>| fold_job(body_spots_5872, false, {
                                let n_p5 = n_p5.clone();
                                let sl_p1 = sl_p1.clone();
                                Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                                    let n_p5 = n_p5.clone();
                                    let sl_p1 = sl_p1.clone();
                                    entered(once_job(move || {
                                        let esc_p6 = p0;
                                        let sp_p7 = p1;
                                        prism_rtl::Turn::Finished(esc_p6 || spot_escapes(&sp_p7, &n_p5, &sl_p1.at))
                                    }))
                                }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }).cycle()))
                        }
                    }
                }))
            }) as Rc<dyn Fn((bool, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        None => true,
    }
}

/// The step machine of `SlotEscapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
/// ```
pub struct SlotEscapes {
    pub sk_p0: crate::check::shrink::Shrink,
    pub sl_p1: Slot_,
}

impl prism_rtl::Job<bool> for SlotEscapes {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let sk_p0 = &self.sk_p0;
        let sl_p1 = &self.sl_p1;
        match get(&sk_p0.by_key, &sl_p1.owner) {
            Some(d_p2) => fold_job(crate::check::shrink::types::def_clauses(&d_p2), false, {
                let sl_p1 = sl_p1.clone();
                let sk_p0 = sk_p0.clone();
                let d_p2 = d_p2.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                    let sl_p1 = sl_p1.clone();
                    let sk_p0 = sk_p0.clone();
                    let d_p2 = d_p2.clone();
                    entered(once_job(move || {
                        let seen_p3 = p0;
                        let c_p4 = p1;
                        {
                            let n_p5 = slot_name(&c_p4, &sl_p1.at);
                            if seen_p3 || (&n_p5 == &Text::lit("")) {
                                prism_rtl::Turn::Finished(seen_p3)
                            } else {
                                call_then(crate::check::shrink::locals::start_clause_base(sk_p0.clone(), d_p2.clone(), c_p4.clone()), move |clause_base_5891: Map<Text, crate::check::shrink::Rel>| call_then(crate::check::shrink::walk::start_body_spots(c_p4.body.clone(), clause_base_5891), move |body_spots_5872: Array<crate::check::shrink::walk::Spot>| fold_job(body_spots_5872, false, {
                                    let n_p5 = n_p5.clone();
                                    let sl_p1 = sl_p1.clone();
                                    Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                                        let n_p5 = n_p5.clone();
                                        let sl_p1 = sl_p1.clone();
                                        entered(once_job(move || {
                                            let esc_p6 = p0;
                                            let sp_p7 = p1;
                                            prism_rtl::Turn::Finished(esc_p6 || spot_escapes(&sp_p7, &n_p5, &sl_p1.at))
                                        }))
                                    }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
                                }).cycle()))
                            }
                        }
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            None => prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start SlotEscapes, x`: what the function value is when passed to `@Run`.
pub fn start_slot_escapes(sk_p0: crate::check::shrink::Shrink, sl_p1: Slot_) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SlotEscapes { sk_p0, sl_p1 })
}

/// ```prism
/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub fn spot_escapes(sp_p0: &crate::check::shrink::walk::Spot, n_p1: &Text, j_p2: &Nat) -> bool {
    match sp_p0 {
        crate::check::shrink::walk::Spot::SpotExpr(e_p3, m_p4) => match &*e_p3.kind {
            crate::syntax::ExprKind::EName(x_p5) => (&crate::check::env::sname_key(x_p5) == n_p1) && is_slot_param(m_p4, n_p1, j_p2),
            _ => fold(&crate::check::shrink::walk::spot_sites(sp_p0), &false, &(|seen_p6: &bool, site_p7: &crate::check::shrink::walk::Site| *seen_p6 || (((&site_p7.callee == n_p1) && is_slot_param(&site_p7.rels, n_p1, j_p2)) && crate::check::env::has_key(&site_p7.rels, &Text::lit("lam:"))))),
        },
        crate::check::shrink::walk::Spot::SpotStmt(_, _) => false,
    }
}

/// The step machine of `SpotEscapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub struct SpotEscapes {
    pub sp_p0: crate::check::shrink::walk::Spot,
    pub n_p1: Text,
    pub j_p2: Nat,
}

impl prism_rtl::Job<bool> for SpotEscapes {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let sp_p0 = &self.sp_p0;
        let n_p1 = &self.n_p1;
        let j_p2 = &self.j_p2;
        match sp_p0 {
            crate::check::shrink::walk::Spot::SpotExpr(e_p3, m_p4) => match &*e_p3.kind {
                crate::syntax::ExprKind::EName(x_p5) => prism_rtl::Turn::Finished((&crate::check::env::sname_key(x_p5) == n_p1) && is_slot_param(m_p4, n_p1, j_p2)),
                _ => {
                    let j_p2 = j_p2.clone();
                    let n_p1 = n_p1.clone();
                    let sp_p0 = sp_p0.clone();
                    call_then(crate::check::shrink::walk::start_spot_sites(sp_p0.clone()), move |spot_sites_6182: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(fold(&spot_sites_6182, &false, &(|seen_p6: &bool, site_p7: &crate::check::shrink::walk::Site| *seen_p6 || (((&site_p7.callee == &n_p1) && is_slot_param(&site_p7.rels, &n_p1, &j_p2)) && crate::check::env::has_key(&site_p7.rels, &Text::lit("lam:")))))))
                },
            },
            crate::check::shrink::walk::Spot::SpotStmt(_, _) => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start SpotEscapes, x`: what the function value is when passed to `@Run`.
pub fn start_spot_escapes(sp_p0: crate::check::shrink::walk::Spot, n_p1: Text, j_p2: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SpotEscapes { sp_p0, n_p1, j_p2 })
}

/// ```prism
/// IsSlotParam: fn (Text ==> Rel), Text, Nat -> Bool
/// ```
pub fn is_slot_param(m_p0: &Map<Text, crate::check::shrink::Rel>, n_p1: &Text, j_p2: &Nat) -> bool {
    &get(m_p0, n_p1) == &Some(crate::check::shrink::Rel { param: j_p2.clone(), strict: false })
}

/// ```prism
/// TopSums: fn [Slot] -> (Text ==> Rel)
/// ```
pub fn top_sums(slots_p0: &Array<Slot_>) -> Map<Text, crate::check::shrink::Rel> {
    fold(slots_p0, &Map::new(), &(|m_p1: &Map<Text, crate::check::shrink::Rel>, sl_p2: &Slot_| fold(&crate::check::errors::range0(&sl_p2.arity), m_p1, &(|m2_p3: &Map<Text, crate::check::shrink::Rel>, q_p4: &Nat| insert(m2_p3, &Text::from(format!("{}:{}:{}", &sl_p2.owner, &sl_p2.at, q_p4)), &crate::check::shrink::Rel { param: crate::check::shrink::walk::top_param(), strict: false })))))
}

/// ```prism
/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
/// ```
pub fn slot_sums(sk_p0: &crate::check::shrink::Shrink, homes_p1: &Array<Text>, slots_p2: &Array<Slot_>, sums_p3: &Map<Text, crate::check::shrink::Rel>, round_p4: &Nat) -> Map<Text, crate::check::shrink::Rel> {
    let sks_p5 = seeds_for(sk_p0, homes_p1, slots_p2, sums_p3, &true);
    let next_p6 = run_to_end(fold_job(slots_p2.clone(), Map::new(), {
        let sks_p5 = sks_p5.clone();
        Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Slot_)| {
            let sks_p5 = sks_p5.clone();
            entered(once_job(move || {
                let m_p7 = p0;
                let sl_p8 = p1;
                call_then(start_slot_calls(sks_p5.clone(), sl_p8.clone()), move |slot_calls_7327: Array<crate::check::shrink::walk::Site>| {
                    let calls_p9 = slot_calls_7327;
                    fold_job(crate::check::errors::range0(&sl_p8.arity), m_p7.clone(), {
                        let calls_p9 = calls_p9.clone();
                        let sl_p8 = sl_p8.clone();
                        Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Nat)| {
                            let calls_p9 = calls_p9.clone();
                            let sl_p8 = sl_p8.clone();
                            entered(once_job(move || {
                                let m2_pa = p0;
                                let q_pb = p1;
                                call_then(start_meet_args(calls_p9.clone(), q_pb.clone()), move |meet_args_7395: Option<crate::check::shrink::Rel>| match meet_args_7395 {
                                    Some(r_pc) => prism_rtl::Turn::Finished(insert(&m2_pa, &Text::from(format!("{}:{}:{}", &sl_p8.owner, &sl_p8.at, &q_pb)), &r_pc)),
                                    None => prism_rtl::Turn::Finished(m2_pa.clone()),
                                })
                            }))
                        }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
                    }).cycle()
                })
            }))
        }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Slot_)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
    }));
    if &next_p6 == sums_p3 {
        next_p6.clone()
    } else {
        if round_p4 > &Nat::from(12u32) {
            Map::new()
        } else {
            slot_sums(sk_p0, homes_p1, slots_p2, &next_p6, &(round_p4 + &Nat::from(1u32)))
        }
    }
}

/// The step machine of `SlotSums`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
/// ```
pub struct SlotSums {
    pub sk_p0: crate::check::shrink::Shrink,
    pub homes_p1: Array<Text>,
    pub slots_p2: Array<Slot_>,
    pub sums_p3: Map<Text, crate::check::shrink::Rel>,
    pub round_p4: Nat,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for SlotSums {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let sk_p0 = &self.sk_p0;
        let homes_p1 = &self.homes_p1;
        let slots_p2 = &self.slots_p2;
        let sums_p3 = &self.sums_p3;
        let round_p4 = &self.round_p4;
        let sks_p5 = seeds_for(sk_p0, homes_p1, slots_p2, sums_p3, &true);
        let homes_p1 = homes_p1.clone();
        let round_p4 = round_p4.clone();
        let sk_p0 = sk_p0.clone();
        let slots_p2 = slots_p2.clone();
        let sums_p3 = sums_p3.clone();
        call_value(fold_job(slots_p2.clone(), Map::new(), {
            let sks_p5 = sks_p5.clone();
            Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Slot_)| {
                let sks_p5 = sks_p5.clone();
                entered(once_job(move || {
                    let m_p7 = p0;
                    let sl_p8 = p1;
                    call_then(start_slot_calls(sks_p5.clone(), sl_p8.clone()), move |slot_calls_7327: Array<crate::check::shrink::walk::Site>| {
                        let calls_p9 = slot_calls_7327;
                        fold_job(crate::check::errors::range0(&sl_p8.arity), m_p7.clone(), {
                            let calls_p9 = calls_p9.clone();
                            let sl_p8 = sl_p8.clone();
                            Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Nat)| {
                                let calls_p9 = calls_p9.clone();
                                let sl_p8 = sl_p8.clone();
                                entered(once_job(move || {
                                    let m2_pa = p0;
                                    let q_pb = p1;
                                    call_then(start_meet_args(calls_p9.clone(), q_pb.clone()), move |meet_args_7395: Option<crate::check::shrink::Rel>| match meet_args_7395 {
                                        Some(r_pc) => prism_rtl::Turn::Finished(insert(&m2_pa, &Text::from(format!("{}:{}:{}", &sl_p8.owner, &sl_p8.at, &q_pb)), &r_pc)),
                                        None => prism_rtl::Turn::Finished(m2_pa.clone()),
                                    })
                                }))
                            }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
                        }).cycle()
                    })
                }))
            }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Slot_)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
        }), move |fold_7282: Map<Text, crate::check::shrink::Rel>| {
            let next_p6 = fold_7282;
            if &next_p6 == &sums_p3 {
                prism_rtl::Turn::Finished(next_p6.clone())
            } else {
                if &round_p4 > &Nat::from(12u32) {
                    prism_rtl::Turn::Finished(Map::new())
                } else {
                    prism_rtl::Turn::More(Rc::new(SlotSums { sk_p0: sk_p0.clone(), homes_p1: homes_p1.clone(), slots_p2: slots_p2.clone(), sums_p3: next_p6.clone(), round_p4: &round_p4 + &Nat::from(1u32) }))
                }
            }
        })
    }
}

/// `Start SlotSums, x`: what the function value is when passed to `@Run`.
pub fn start_slot_sums(sk_p0: crate::check::shrink::Shrink, homes_p1: Array<Text>, slots_p2: Array<Slot_>, sums_p3: Map<Text, crate::check::shrink::Rel>, round_p4: Nat) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(SlotSums { sk_p0, homes_p1, slots_p2, sums_p3, round_p4 })
}

/// ```prism
/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
/// ```
pub fn slot_calls(sk_p0: &crate::check::shrink::Shrink, sl_p1: &Slot_) -> Array<crate::check::shrink::walk::Site> {
    match get(&sk_p0.by_key, &sl_p1.owner) {
        Some(d_p2) => run_to_end(fold_job(crate::check::shrink::types::def_clauses(&d_p2), Array::new(), {
            let sl_p1 = sl_p1.clone();
            let sk_p0 = sk_p0.clone();
            let d_p2 = d_p2.clone();
            Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause)| {
                let sl_p1 = sl_p1.clone();
                let sk_p0 = sk_p0.clone();
                let d_p2 = d_p2.clone();
                entered(once_job(move || {
                    let acc_p3 = p0;
                    let c_p4 = p1;
                    {
                        let n_p5 = slot_name(&c_p4, &sl_p1.at);
                        if &n_p5 == &Text::lit("") {
                            prism_rtl::Turn::Finished(acc_p3.clone())
                        } else {
                            call_then(crate::check::shrink::locals::start_clause_base(sk_p0.clone(), d_p2.clone(), c_p4.clone()), move |clause_base_7920: Map<Text, crate::check::shrink::Rel>| {
                                let base_p6 = clause_base_7920;
                                call_then(crate::check::shrink::walk::start_body_spots(c_p4.body.clone(), base_p6.clone()), move |body_spots_7984: Array<crate::check::shrink::walk::Spot>| call_then(crate::check::shrink::summaries::start_summary_seeds(sk_p0.clone(), d_p2.clone(), body_spots_7984, base_p6.clone()), move |summary_seeds_7963: Map<Text, crate::check::shrink::Rel>| {
                                    let rels_p7 = summary_seeds_7963;
                                    call_then(crate::check::shrink::walk::start_body_spots(c_p4.body.clone(), rels_p7.clone()), move |body_spots_8032: Array<crate::check::shrink::walk::Spot>| fold_job(body_spots_8032, acc_p3.clone(), {
                                        let n_p5 = n_p5.clone();
                                        let sl_p1 = sl_p1.clone();
                                        Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)| {
                                            let n_p5 = n_p5.clone();
                                            let sl_p1 = sl_p1.clone();
                                            entered(once_job(move || {
                                                let a2_p8 = p0;
                                                let sp_p9 = p1;
                                                match &sp_p9 {
                                                    crate::check::shrink::walk::Spot::SpotExpr(e_pa, _) => match &*e_pa.kind {
                                                        crate::syntax::ExprKind::EName(_) => prism_rtl::Turn::Finished(a2_p8.clone()),
                                                        _ => call_then(crate::check::shrink::walk::start_spot_sites(sp_p9.clone()), move |spot_sites_8220: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(append(&a2_p8, &filter(&spot_sites_8220, &(|site_pb: &crate::check::shrink::walk::Site| (&site_pb.callee == &n_p5) && is_slot_param(&site_pb.rels, &n_p5, &sl_p1.at)))))),
                                                    },
                                                    _ => prism_rtl::Turn::Finished(a2_p8.clone()),
                                                }
                                            }))
                                        }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Site>>>>
                                    }).cycle())
                                }))
                            })
                        }
                    }
                }))
            }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Site>>>>
        })),
        None => Array::new(),
    }
}

/// The step machine of `SlotCalls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
/// ```
pub struct SlotCalls {
    pub sk_p0: crate::check::shrink::Shrink,
    pub sl_p1: Slot_,
}

impl prism_rtl::Job<Array<crate::check::shrink::walk::Site>> for SlotCalls {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::shrink::walk::Site>> {
        let sk_p0 = &self.sk_p0;
        let sl_p1 = &self.sl_p1;
        match get(&sk_p0.by_key, &sl_p1.owner) {
            Some(d_p2) => fold_job(crate::check::shrink::types::def_clauses(&d_p2), Array::new(), {
                let sl_p1 = sl_p1.clone();
                let sk_p0 = sk_p0.clone();
                let d_p2 = d_p2.clone();
                Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause)| {
                    let sl_p1 = sl_p1.clone();
                    let sk_p0 = sk_p0.clone();
                    let d_p2 = d_p2.clone();
                    entered(once_job(move || {
                        let acc_p3 = p0;
                        let c_p4 = p1;
                        {
                            let n_p5 = slot_name(&c_p4, &sl_p1.at);
                            if &n_p5 == &Text::lit("") {
                                prism_rtl::Turn::Finished(acc_p3.clone())
                            } else {
                                call_then(crate::check::shrink::locals::start_clause_base(sk_p0.clone(), d_p2.clone(), c_p4.clone()), move |clause_base_7920: Map<Text, crate::check::shrink::Rel>| {
                                    let base_p6 = clause_base_7920;
                                    call_then(crate::check::shrink::walk::start_body_spots(c_p4.body.clone(), base_p6.clone()), move |body_spots_7984: Array<crate::check::shrink::walk::Spot>| call_then(crate::check::shrink::summaries::start_summary_seeds(sk_p0.clone(), d_p2.clone(), body_spots_7984, base_p6.clone()), move |summary_seeds_7963: Map<Text, crate::check::shrink::Rel>| {
                                        let rels_p7 = summary_seeds_7963;
                                        call_then(crate::check::shrink::walk::start_body_spots(c_p4.body.clone(), rels_p7.clone()), move |body_spots_8032: Array<crate::check::shrink::walk::Spot>| fold_job(body_spots_8032, acc_p3.clone(), {
                                            let n_p5 = n_p5.clone();
                                            let sl_p1 = sl_p1.clone();
                                            Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)| {
                                                let n_p5 = n_p5.clone();
                                                let sl_p1 = sl_p1.clone();
                                                entered(once_job(move || {
                                                    let a2_p8 = p0;
                                                    let sp_p9 = p1;
                                                    match &sp_p9 {
                                                        crate::check::shrink::walk::Spot::SpotExpr(e_pa, _) => match &*e_pa.kind {
                                                            crate::syntax::ExprKind::EName(_) => prism_rtl::Turn::Finished(a2_p8.clone()),
                                                            _ => call_then(crate::check::shrink::walk::start_spot_sites(sp_p9.clone()), move |spot_sites_8220: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(append(&a2_p8, &filter(&spot_sites_8220, &(|site_pb: &crate::check::shrink::walk::Site| (&site_pb.callee == &n_p5) && is_slot_param(&site_pb.rels, &n_p5, &sl_p1.at)))))),
                                                        },
                                                        _ => prism_rtl::Turn::Finished(a2_p8.clone()),
                                                    }
                                                }))
                                            }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Site>>>>
                                        }).cycle())
                                    }))
                                })
                            }
                        }
                    }))
                }) as Rc<dyn Fn((Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Site>>>>
            }).cycle(),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start SlotCalls, x`: what the function value is when passed to `@Run`.
pub fn start_slot_calls(sk_p0: crate::check::shrink::Shrink, sl_p1: Slot_) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Site>>> {
    Rc::new(SlotCalls { sk_p0, sl_p1 })
}

/// ```prism
/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
/// ```
pub fn meet_args(calls_p0: &Array<crate::check::shrink::walk::Site>, q_p1: &Nat) -> Option<crate::check::shrink::Rel> {
    run_to_end(fold_job(calls_p0.clone(), Some(crate::check::shrink::Rel { param: crate::check::shrink::walk::top_param(), strict: false }), {
        let q_p1 = q_p1.clone();
        Rc::new(move |(p0, p1): (Option<crate::check::shrink::Rel>, crate::check::shrink::walk::Site)| {
            let q_p1 = q_p1.clone();
            entered(once_job(move || {
                let acc_o2 = p0;
                let site_p3 = p1;
                match &acc_o2 {
                    None => prism_rtl::Turn::Finished(None),
                    Some(acc_p4) => match index(&site_p3.args, &q_p1) {
                        Some(a_p5) => if &a_p5.name != &None {
                            prism_rtl::Turn::Finished(None)
                        } else {
                            {
                                let acc_p4 = acc_p4.clone();
                                call_then(crate::check::shrink::walk::start_rel_of(site_p3.rels.clone(), a_p5.value.clone()), move |rel_of_8797: Option<crate::check::shrink::Rel>| match rel_of_8797 {
                                    Some(r_p6) => if &r_p6.param == &crate::check::shrink::walk::top_param() {
                                        prism_rtl::Turn::Finished(Some(acc_p4.clone()))
                                    } else {
                                        if &acc_p4.param == &crate::check::shrink::walk::top_param() {
                                            prism_rtl::Turn::Finished(Some(r_p6.clone()))
                                        } else {
                                            if &acc_p4.param == &r_p6.param {
                                                prism_rtl::Turn::Finished(Some(crate::check::shrink::Rel { param: r_p6.param.clone(), strict: acc_p4.strict && r_p6.strict }))
                                            } else {
                                                prism_rtl::Turn::Finished(None)
                                            }
                                        }
                                    },
                                    None => prism_rtl::Turn::Finished(None),
                                })
                            }
                        },
                        None => prism_rtl::Turn::Finished(None),
                    },
                }
            }))
        }) as Rc<dyn Fn((Option<crate::check::shrink::Rel>, crate::check::shrink::walk::Site)) -> Rc<dyn prism_rtl::Job<Option<crate::check::shrink::Rel>>>>
    }))
}

/// The step machine of `MeetArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
/// ```
pub struct MeetArgs {
    pub calls_p0: Array<crate::check::shrink::walk::Site>,
    pub q_p1: Nat,
}

impl prism_rtl::Job<Option<crate::check::shrink::Rel>> for MeetArgs {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::check::shrink::Rel>> {
        let calls_p0 = &self.calls_p0;
        let q_p1 = &self.q_p1;
        fold_job(calls_p0.clone(), Some(crate::check::shrink::Rel { param: crate::check::shrink::walk::top_param(), strict: false }), {
            let q_p1 = q_p1.clone();
            Rc::new(move |(p0, p1): (Option<crate::check::shrink::Rel>, crate::check::shrink::walk::Site)| {
                let q_p1 = q_p1.clone();
                entered(once_job(move || {
                    let acc_o2 = p0;
                    let site_p3 = p1;
                    match &acc_o2 {
                        None => prism_rtl::Turn::Finished(None),
                        Some(acc_p4) => match index(&site_p3.args, &q_p1) {
                            Some(a_p5) => if &a_p5.name != &None {
                                prism_rtl::Turn::Finished(None)
                            } else {
                                {
                                    let acc_p4 = acc_p4.clone();
                                    call_then(crate::check::shrink::walk::start_rel_of(site_p3.rels.clone(), a_p5.value.clone()), move |rel_of_8797: Option<crate::check::shrink::Rel>| match rel_of_8797 {
                                        Some(r_p6) => if &r_p6.param == &crate::check::shrink::walk::top_param() {
                                            prism_rtl::Turn::Finished(Some(acc_p4.clone()))
                                        } else {
                                            if &acc_p4.param == &crate::check::shrink::walk::top_param() {
                                                prism_rtl::Turn::Finished(Some(r_p6.clone()))
                                            } else {
                                                if &acc_p4.param == &r_p6.param {
                                                    prism_rtl::Turn::Finished(Some(crate::check::shrink::Rel { param: r_p6.param.clone(), strict: acc_p4.strict && r_p6.strict }))
                                                } else {
                                                    prism_rtl::Turn::Finished(None)
                                                }
                                            }
                                        },
                                        None => prism_rtl::Turn::Finished(None),
                                    })
                                }
                            },
                            None => prism_rtl::Turn::Finished(None),
                        },
                    }
                }))
            }) as Rc<dyn Fn((Option<crate::check::shrink::Rel>, crate::check::shrink::walk::Site)) -> Rc<dyn prism_rtl::Job<Option<crate::check::shrink::Rel>>>>
        }).cycle()
    }
}

/// `Start MeetArgs, x`: what the function value is when passed to `@Run`.
pub fn start_meet_args(calls_p0: Array<crate::check::shrink::walk::Site>, q_p1: Nat) -> Rc<dyn prism_rtl::Job<Option<crate::check::shrink::Rel>>> {
    Rc::new(MeetArgs { calls_p0, q_p1 })
}

/// ```prism
/// DefRefs: unbounded fn Shrink, Def -> [Text]
/// ```
pub fn def_refs(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def) -> Array<Text> {
    run_to_end(fold_job(crate::check::shrink::types::def_clauses(d_p1), Array::new(), {
        let sk_p0 = sk_p0.clone();
        let d_p1 = d_p1.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::decls::FnClause)| {
            let sk_p0 = sk_p0.clone();
            let d_p1 = d_p1.clone();
            entered(once_job(move || {
                let acc_p2 = p0;
                let c_p3 = p1;
                call_then(crate::check::shrink::locals::start_clause_base(sk_p0.clone(), d_p1.clone(), c_p3.clone()), move |clause_base_9334: Map<Text, crate::check::shrink::Rel>| call_then(crate::check::shrink::walk::start_body_spots(c_p3.body.clone(), clause_base_9334), move |body_spots_9315: Array<crate::check::shrink::walk::Spot>| prism_rtl::Turn::More(Rc::new(SpotsRefs { sk_p0: sk_p0.clone(), d_p1: d_p1.clone(), spots_p2: body_spots_9315, acc_p3: acc_p2.clone() }))))
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `DefRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefRefs: unbounded fn Shrink, Def -> [Text]
/// ```
pub struct DefRefs {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
}

impl prism_rtl::Job<Array<Text>> for DefRefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        fold_job(crate::check::shrink::types::def_clauses(d_p1), Array::new(), {
            let sk_p0 = sk_p0.clone();
            let d_p1 = d_p1.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::decls::FnClause)| {
                let sk_p0 = sk_p0.clone();
                let d_p1 = d_p1.clone();
                entered(once_job(move || {
                    let acc_p2 = p0;
                    let c_p3 = p1;
                    call_then(crate::check::shrink::locals::start_clause_base(sk_p0.clone(), d_p1.clone(), c_p3.clone()), move |clause_base_9334: Map<Text, crate::check::shrink::Rel>| call_then(crate::check::shrink::walk::start_body_spots(c_p3.body.clone(), clause_base_9334), move |body_spots_9315: Array<crate::check::shrink::walk::Spot>| prism_rtl::Turn::More(Rc::new(SpotsRefs { sk_p0: sk_p0.clone(), d_p1: d_p1.clone(), spots_p2: body_spots_9315, acc_p3: acc_p2.clone() }))))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start DefRefs, x`: what the function value is when passed to `@Run`.
pub fn start_def_refs(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(DefRefs { sk_p0, d_p1 })
}

/// ```prism
/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
/// ```
pub fn spots_refs(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, spots_p2: &Array<crate::check::shrink::walk::Spot>, acc_p3: &Array<Text>) -> Array<Text> {
    run_to_end(fold_job(spots_p2.clone(), acc_p3.clone(), {
        let sk_p0 = sk_p0.clone();
        let d_p1 = d_p1.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::walk::Spot)| {
            let sk_p0 = sk_p0.clone();
            let d_p1 = d_p1.clone();
            entered(once_job(move || {
                let a1_p4 = p0;
                let sp_p5 = p1;
                call_then(crate::check::shrink::walk::start_spot_sites(sp_p5.clone()), move |spot_sites_9490: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(fold(&spot_sites_9490, &a1_p4, &(|a2_p6: &Array<Text>, site_p7: &crate::check::shrink::walk::Site| match crate::check::shrink::locals::local_target(&sk_p0, &d_p1, site_p7) {
                    Some(t_p8) => crate::check::types::add_text(a2_p6, &t_p8),
                    None => if crate::check::shrink::relations::is_local(&site_p7.rels, &site_p7.callee) || crate::check::env::has_key(&sk_p0.local_of, &d_p1.qk) {
                        a2_p6.clone()
                    } else {
                        match crate::check::shrink::locals::resolve_callee(&sk_p0.g, &d_p1.home, &site_p7.callee) {
                            Some(k_p9) => fold(&crate::check::shrink::types::targets_of(&sk_p0, &k_p9), a2_p6, &(|a3_pa: &Array<Text>, t_pb: &Text| if crate::check::env::has_key(&sk_p0.by_key, t_pb) {
                                crate::check::types::add_text(a3_pa, t_pb)
                            } else {
                                a3_pa.clone()
                            })),
                            None => a2_p6.clone(),
                        }
                    },
                }))))
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `SpotsRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
/// ```
pub struct SpotsRefs {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub spots_p2: Array<crate::check::shrink::walk::Spot>,
    pub acc_p3: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for SpotsRefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let spots_p2 = &self.spots_p2;
        let acc_p3 = &self.acc_p3;
        fold_job(spots_p2.clone(), acc_p3.clone(), {
            let sk_p0 = sk_p0.clone();
            let d_p1 = d_p1.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::walk::Spot)| {
                let sk_p0 = sk_p0.clone();
                let d_p1 = d_p1.clone();
                entered(once_job(move || {
                    let a1_p4 = p0;
                    let sp_p5 = p1;
                    call_then(crate::check::shrink::walk::start_spot_sites(sp_p5.clone()), move |spot_sites_9490: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(fold(&spot_sites_9490, &a1_p4, &(|a2_p6: &Array<Text>, site_p7: &crate::check::shrink::walk::Site| match crate::check::shrink::locals::local_target(&sk_p0, &d_p1, site_p7) {
                        Some(t_p8) => crate::check::types::add_text(a2_p6, &t_p8),
                        None => if crate::check::shrink::relations::is_local(&site_p7.rels, &site_p7.callee) || crate::check::env::has_key(&sk_p0.local_of, &d_p1.qk) {
                            a2_p6.clone()
                        } else {
                            match crate::check::shrink::locals::resolve_callee(&sk_p0.g, &d_p1.home, &site_p7.callee) {
                                Some(k_p9) => fold(&crate::check::shrink::types::targets_of(&sk_p0, &k_p9), a2_p6, &(|a3_pa: &Array<Text>, t_pb: &Text| if crate::check::env::has_key(&sk_p0.by_key, t_pb) {
                                    crate::check::types::add_text(a3_pa, t_pb)
                                } else {
                                    a3_pa.clone()
                                })),
                                None => a2_p6.clone(),
                            }
                        },
                    }))))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start SpotsRefs, x`: what the function value is when passed to `@Run`.
pub fn start_spots_refs(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, spots_p2: Array<crate::check::shrink::walk::Spot>, acc_p3: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotsRefs { sk_p0, d_p1, spots_p2, acc_p3 })
}
