//! The module `Check.Shrink`, from `target/bootstrap/src/prismc/check/shrink/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod calls;
pub mod locals;
pub mod relations;
pub mod summaries;
pub mod types;
pub mod walk;

/// `Rel`:
///
/// ```prism
/// type Rel = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Rel {
    pub param_p: crate::prelude::Nat,
    pub strict_p: bool,
}

impl crate::prelude::Show for Rel {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Rel", &[("param", &self.param_p), ("strict", &self.strict_p)]);
    }
}

impl crate::prelude::ToPod for Rel {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Rel", vec![("param", self.param_p.to_pod()), ("strict", self.strict_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Rel {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Rel { param_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "param")?)?, strict_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "strict")?)? })
    }
}

/// `Sc`:
///
/// ```prism
/// type Sc = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Sc {
    pub caller_p: crate::prelude::Text,
    pub callee_p: crate::prelude::Text,
    pub edges_p: crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>,
    pub span_p: crate::syntax::Range,
    pub file_p: crate::prelude::Nat,
    pub arg_p: crate::prelude::Text,
}

impl crate::prelude::Show for Sc {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Sc", &[("caller", &self.caller_p), ("callee", &self.callee_p), ("edges", &self.edges_p), ("span", &self.span_p), ("file", &self.file_p), ("arg", &self.arg_p)]);
    }
}

impl crate::prelude::ToPod for Sc {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Sc", vec![("caller", self.caller_p.to_pod()), ("callee", self.callee_p.to_pod()), ("edges", self.edges_p.to_pod()), ("span", self.span_p.to_pod()), ("file", self.file_p.to_pod()), ("arg", self.arg_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Sc {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Sc { caller_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "caller")?)?, callee_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "callee")?)?, edges_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "edges")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, arg_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "arg")?)? })
    }
}

/// `Shrink`:
///
/// ```prism
/// type Shrink = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Shrink {
    pub g_p: crate::check::env::G,
    pub fns_p: crate::prelude::Array<crate::check::env::Def>,
    pub by_key_p: crate::prelude::Map<crate::prelude::Text, crate::check::env::Def>,
    pub targets_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>,
    pub impl_defs_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>,
    pub choices_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>,
    pub sums_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>,
    pub seeds_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, Rel>>,
    pub local_of_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>,
    pub local_base_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, Rel>>,
}

impl crate::prelude::Show for Shrink {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Shrink", &[("g", &self.g_p), ("fns", &self.fns_p), ("byKey", &self.by_key_p), ("targets", &self.targets_p), ("implDefs", &self.impl_defs_p), ("choices", &self.choices_p), ("sums", &self.sums_p), ("seeds", &self.seeds_p), ("localOf", &self.local_of_p), ("localBase", &self.local_base_p)]);
    }
}

impl crate::prelude::ToPod for Shrink {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Shrink", vec![("g", self.g_p.to_pod()), ("fns", self.fns_p.to_pod()), ("byKey", self.by_key_p.to_pod()), ("targets", self.targets_p.to_pod()), ("implDefs", self.impl_defs_p.to_pod()), ("choices", self.choices_p.to_pod()), ("sums", self.sums_p.to_pod()), ("seeds", self.seeds_p.to_pod()), ("localOf", self.local_of_p.to_pod()), ("localBase", self.local_base_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Shrink {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Shrink { g_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "g")?)?, fns_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fns")?)?, by_key_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "byKey")?)?, targets_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "targets")?)?, impl_defs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "implDefs")?)?, choices_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "choices")?)?, sums_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "sums")?)?, seeds_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "seeds")?)?, local_of_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "localOf")?)?, local_base_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "localBase")?)? })
    }
}

/// ```prism
/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
/// ```
pub fn shrink_check_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, defs_p2: &crate::prelude::Array<crate::check::env::Def>) -> (crate::check::types::St, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>) {
    let fns_p3 = crate::prelude::each(&crate::prelude::filter(defs_p2, &(|d_pi: &crate::check::env::Def| &crate::prelude::len(&crate::check::shrink::types::def_clauses_f(d_pi)) > &crate::prelude::Nat::from(0u32))), &(|d_pj: &crate::check::env::Def| crate::check::shrink::types::own_key_f(d_pj)));
    let by_key_p4 = crate::prelude::fold(&fns_p3, &crate::prelude::Map::new(), &(|m_pk: &crate::prelude::Map<crate::prelude::Text, crate::check::env::Def>, d_pl: &crate::check::env::Def| crate::prelude::insert(m_pk, &d_pl.qk_p, d_pl)));
    let homes_p5 = crate::prelude::fold(&fns_p3, &crate::prelude::Array::new(), &(|acc_pm: &crate::prelude::Array<crate::prelude::Text>, d_pn: &crate::check::env::Def| crate::check::types::add_text_f(acc_pm, &d_pn.home_p)));
    let nats_p6 = crate::check::shrink::types::nat_minus_seeds_f(st_p1);
    let pre_p7 = crate::prelude::fold(&homes_p5, &crate::prelude::Map::new(), &(|m_po: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, Rel>>, h_pp: &crate::prelude::Text| crate::prelude::insert(m_po, h_pp, &crate::prelude::fold(&crate::prelude::keys(&nats_p6), &crate::check::shrink::relations::prelude_seeds_f(g_p0, h_pp), &(|m2_pq: &crate::prelude::Map<crate::prelude::Text, Rel>, k_pr: &crate::prelude::Text| crate::prelude::insert(m2_pq, k_pr, &crate::check::shrink::relations::no_rel_p()))))));
    let sk0_p8 = Shrink { g_p: g_p0.clone(), fns_p: fns_p3.clone(), by_key_p: by_key_p4.clone(), targets_p: crate::check::shrink::types::method_targets_f(g_p0, &fns_p3), impl_defs_p: crate::check::shrink::types::impl_defs_f(g_p0, &fns_p3), choices_p: st_p1.choices_p.clone(), sums_p: crate::prelude::Map::new(), seeds_p: pre_p7.clone(), local_of_p: crate::prelude::Map::new(), local_base_p: crate::prelude::Map::new() };
    let sk1_p9 = {
        let mut this: Shrink = sk0_p8.clone();
        this.sums_p = crate::check::shrink::summaries::parts_summaries_f(&sk0_p8, &fns_p3);
        this
    };
    let skg_pa = {
        let mut this: Shrink = sk1_p9.clone();
        this.seeds_p = crate::check::shrink::calls::hof_seeds_f(&sk1_p9, &homes_p5);
        this
    };
    let walked_pb = crate::prelude::run_to_end(crate::prelude::each_job(fns_p3.clone(), {
        let skg_pax = skg_pa.clone();
        ::std::rc::Rc::new(move |p0: crate::check::env::Def| {
            let skg_paxy = skg_pax.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let d_ps = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::shrink::locals::DefWalk { sk_p0: skg_paxy.clone(), d_p1: d_ps.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>)>>>
    }));
    let sk_pc = crate::check::shrink::locals::with_locals_f(&skg_pa, &crate::prelude::fold(&walked_pb, &crate::prelude::Array::new(), &(|acc_pt: &crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>, (_, _, ls_pu): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>)| crate::prelude::append(acc_pt, ls_pu))));
    let refs_pd = crate::prelude::append(&crate::prelude::each(&walked_pb, &(|(k_pv, rs_p10, _): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>)| (k_pv.clone(), rs_p10.clone()))), &crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::drop(&sk_pc.fns_p, &crate::prelude::len(&fns_p3)), {
        let sk_pcx = sk_pc.clone();
        ::std::rc::Rc::new(move |p0: crate::check::env::Def| {
            let sk_pcxy = sk_pcx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let d_p11 = p0;
                crate::prelude::call_then(crate::check::shrink::calls::start_def_refs_f(sk_pcxy.clone(), d_p11.clone()), move |def_refs_f_3915: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished((d_p11.qk_p.clone(), def_refs_f_3915)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>>>
    })));
    let keys_pe = crate::prelude::each(&sk_pc.fns_p, &(|d_p12: &crate::check::env::Def| d_p12.qk_p.clone()));
    let sccs_pf = crate::check::shrink::locals::sccs_f(&keys_pe, &refs_pd);
    let st2_pg = crate::prelude::run_to_end(crate::prelude::fold_job(sccs_pf.clone(), crate::check::shrink::types::negative_types_f(g_p0, st_p1), {
        let sk_pcx = sk_pc.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Array<crate::prelude::Text>)| {
            let sk_pcxy = sk_pcx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p13 = p0;
                let comp_p14 = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::shrink::locals::ShrinkComponent { sk_p0: sk_pcxy.clone(), st0_p1: s_p13.clone(), comp_p2: comp_p14.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Array<crate::prelude::Text>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }));
    let st3_ph = crate::prelude::run_to_end(crate::prelude::fold_job(fns_p3.clone(), st2_pg.clone(), {
        let sk_pcx = sk_pc.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::Def)| {
            let sk_pcxy = sk_pcx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p15 = p0;
                let d_p16 = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::shrink::summaries::LoopsOf { sk_p0: sk_pcxy.clone(), st_p1: s_p15.clone(), d_p2: d_p16.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }));
    (st3_ph.clone(), refs_pd.clone())
}

/// The step machine of `ShrinkCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
/// ```
pub struct ShrinkCheck {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub defs_p2: crate::prelude::Array<crate::check::env::Def>,
}

impl ::prism_rtl::Job<(crate::check::types::St, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>)> for ShrinkCheck {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::St, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let defs_p2 = &self.defs_p2;
        let fns_p3 = crate::prelude::each(&crate::prelude::filter(defs_p2, &(|d_pi: &crate::check::env::Def| &crate::prelude::len(&crate::check::shrink::types::def_clauses_f(d_pi)) > &crate::prelude::Nat::from(0u32))), &(|d_pj: &crate::check::env::Def| crate::check::shrink::types::own_key_f(d_pj)));
        let by_key_p4 = crate::prelude::fold(&fns_p3, &crate::prelude::Map::new(), &(|m_pk: &crate::prelude::Map<crate::prelude::Text, crate::check::env::Def>, d_pl: &crate::check::env::Def| crate::prelude::insert(m_pk, &d_pl.qk_p, d_pl)));
        let homes_p5 = crate::prelude::fold(&fns_p3, &crate::prelude::Array::new(), &(|acc_pm: &crate::prelude::Array<crate::prelude::Text>, d_pn: &crate::check::env::Def| crate::check::types::add_text_f(acc_pm, &d_pn.home_p)));
        let g_p0x = g_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::shrink::types::start_nat_minus_seeds_f(st_p1x.clone()), move |nat_minus_seeds_f_3210: crate::prelude::Map<crate::prelude::Text, Rel>| {
            let nats_p6 = nat_minus_seeds_f_3210;
            let pre_p7 = crate::prelude::fold(&homes_p5, &crate::prelude::Map::new(), &(|m_po: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, Rel>>, h_pp: &crate::prelude::Text| crate::prelude::insert(m_po, h_pp, &crate::prelude::fold(&crate::prelude::keys(&nats_p6), &crate::check::shrink::relations::prelude_seeds_f(&g_p0x, h_pp), &(|m2_pq: &crate::prelude::Map<crate::prelude::Text, Rel>, k_pr: &crate::prelude::Text| crate::prelude::insert(m2_pq, k_pr, &crate::check::shrink::relations::no_rel_p()))))));
            let sk0_p8 = Shrink { g_p: g_p0x.clone(), fns_p: fns_p3.clone(), by_key_p: by_key_p4.clone(), targets_p: crate::check::shrink::types::method_targets_f(&g_p0x, &fns_p3), impl_defs_p: crate::check::shrink::types::impl_defs_f(&g_p0x, &fns_p3), choices_p: st_p1x.choices_p.clone(), sums_p: crate::prelude::Map::new(), seeds_p: pre_p7.clone(), local_of_p: crate::prelude::Map::new(), local_base_p: crate::prelude::Map::new() };
            let sk1_p9 = {
                let mut this: Shrink = sk0_p8.clone();
                this.sums_p = crate::check::shrink::summaries::parts_summaries_f(&sk0_p8, &fns_p3);
                this
            };
            let skg_pa = {
                let mut this: Shrink = sk1_p9.clone();
                this.seeds_p = crate::check::shrink::calls::hof_seeds_f(&sk1_p9, &homes_p5);
                this
            };
            crate::prelude::call_value(crate::prelude::each_job(fns_p3.clone(), {
                let skg_pax = skg_pa.clone();
                ::std::rc::Rc::new(move |p0: crate::check::env::Def| {
                    let skg_paxy = skg_pax.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let d_ps = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::shrink::locals::DefWalk { sk_p0: skg_paxy.clone(), d_p1: d_ps.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>)>>>
            }), move |each_3674: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>)>| {
                let walked_pb = each_3674;
                crate::prelude::call_then(crate::check::shrink::locals::start_with_locals_f(skg_pa.clone(), crate::prelude::fold(&walked_pb, &crate::prelude::Array::new(), &(|acc_pt: &crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>, (_, _, ls_pu): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>)| crate::prelude::append(acc_pt, ls_pu)))), move |with_locals_f_3717: Shrink| {
                    let sk_pc = with_locals_f_3717;
                    crate::prelude::call_value(crate::prelude::each_job(crate::prelude::drop(&sk_pc.fns_p, &crate::prelude::len(&fns_p3)), {
                        let sk_pcx = sk_pc.clone();
                        ::std::rc::Rc::new(move |p0: crate::check::env::Def| {
                            let sk_pcxy = sk_pcx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let d_p11 = p0;
                                crate::prelude::call_then(crate::check::shrink::calls::start_def_refs_f(sk_pcxy.clone(), d_p11.clone()), move |def_refs_f_3915: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished((d_p11.qk_p.clone(), def_refs_f_3915)))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>>>
                    }), move |each_3870: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>| {
                        let refs_pd = crate::prelude::append(&crate::prelude::each(&walked_pb, &(|(k_pv, rs_p10, _): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>)| (k_pv.clone(), rs_p10.clone()))), &each_3870);
                        let keys_pe = crate::prelude::each(&sk_pc.fns_p, &(|d_p12: &crate::check::env::Def| d_p12.qk_p.clone()));
                        crate::prelude::call_then(crate::check::shrink::locals::start_sccs_f(keys_pe.clone(), refs_pd.clone()), move |sccs_f_3986: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| {
                            let sccs_pf = sccs_f_3986;
                            crate::prelude::call_then(crate::check::shrink::types::start_negative_types_f(g_p0x.clone(), st_p1x.clone()), move |negative_types_f_4028: crate::check::types::St| crate::prelude::call_value(crate::prelude::fold_job(sccs_pf.clone(), negative_types_f_4028, {
                                let sk_pcx = sk_pc.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Array<crate::prelude::Text>)| {
                                    let sk_pcxy = sk_pcx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let s_p13 = p0;
                                        let comp_p14 = p1;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::shrink::locals::ShrinkComponent { sk_p0: sk_pcxy.clone(), st0_p1: s_p13.clone(), comp_p2: comp_p14.clone() }))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Array<crate::prelude::Text>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                            }), move |fold_4016: crate::check::types::St| {
                                let st2_pg = fold_4016;
                                crate::prelude::call_value(crate::prelude::fold_job(fns_p3.clone(), st2_pg.clone(), {
                                    let sk_pcx = sk_pc.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::Def)| {
                                        let sk_pcxy = sk_pcx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let s_p15 = p0;
                                            let d_p16 = p1;
                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::shrink::summaries::LoopsOf { sk_p0: sk_pcxy.clone(), st_p1: s_p15.clone(), d_p2: d_p16.clone() }))
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                                }), move |fold_4103: crate::check::types::St| {
                                    let st3_ph = fold_4103;
                                    ::prism_rtl::Turn::Finished((st3_ph.clone(), refs_pd.clone()))
                                })
                            }))
                        })
                    })
                })
            })
        })
    }
}

/// `Start ShrinkCheck, x`: what the function value is when passed to `@Run`.
pub fn start_shrink_check_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, defs_p2: crate::prelude::Array<crate::check::env::Def>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::St, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>)>> {
    ::std::rc::Rc::new(ShrinkCheck { g_p0, st_p1, defs_p2 })
}

/// ```prism
/// UnusedDefs: unbounded fn [Def], [((Text, [Text]))], Nat -> [CDiag]
/// ```
pub fn unused_defs_f(defs_p0: &crate::prelude::Array<crate::check::env::Def>, refs_p1: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>, shown_p2: &crate::prelude::Nat) -> crate::prelude::Array<crate::check::errors::CDiag> {
    let used0_p3 = crate::prelude::fold(refs_p1, &crate::prelude::Map::new(), &(|m_p6: &crate::prelude::Map<crate::prelude::Text, ()>, (k_p7, rs_p8): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| crate::prelude::fold(rs_p8, m_p6, &(|m2_p9: &crate::prelude::Map<crate::prelude::Text, ()>, r_pa: &crate::prelude::Text| if r_pa == k_p7 { m2_p9.clone() } else { crate::prelude::insert(m2_p9, r_pa, &()) }))));
    let used_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(defs_p0.clone(), used0_p3.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, ()>, crate::check::env::Def)| crate::prelude::entered(crate::prelude::once_job(move || {
        let m_pb = p0;
        let d_pc = p1;
        match &d_pc.body_p {
            crate::check::env::DefBody::DbCheck(c_pd) => crate::prelude::fold_job(c_pd.lines_p.clone(), m_pb.clone(), {
                let d_pcx = d_pc.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, ()>, crate::syntax::decls::CheckLine)| {
                    let d_pcxy = d_pcx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let m2_pe = p0;
                        let l_pf = p1;
                        crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(l_pf.expr_p.clone()), move |exprs_in_f_4836: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&exprs_in_f_4836, &m2_pe, &(|m3_pg: &crate::prelude::Map<crate::prelude::Text, ()>, e_ph: &crate::syntax::Expr| match &*e_ph.kind_p {
                            crate::syntax::ExprKind::EName(n_pi) => crate::prelude::insert(&crate::prelude::insert(m3_pg, &crate::check::env::sname_key_f(n_pi), &()), &crate::check::env::qual_key_f(&d_pcxy.home_p, &crate::check::env::sname_key_f(n_pi)), &()),
                            _ => m3_pg.clone(),
                        }))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, ()>, crate::syntax::decls::CheckLine)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, ()>>>>
            }).cycle(),
            _ => ::prism_rtl::Turn::Finished(m_pb.clone()),
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, ()>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, ()>>>>));
    let own_p5 = crate::prelude::filter(defs_p0, &(|d_pj: &crate::check::env::Def| ((((&d_pj.file_p < shown_p2) && !crate::check::env::has_key_f(&used_p4, &d_pj.qk_p)) && (&d_pj.name_p != &crate::prelude::Text::lit("@main"))) && !is_method_def_f(d_pj)) && !is_testing_def_f(d_pj)));
    crate::prelude::each(&own_p5, &(|d_pk: &crate::check::env::Def| crate::check::errors::CDiag { code_p: crate::prelude::Text::lit("unused"), file_p: d_pk.file_p.clone(), span_p: d_pk.span_p.clone(), message_p: crate::prelude::Text::from(format!("nothing uses `{}`", &d_pk.name_p)), fix_p: crate::prelude::Text::lit("delete it, or use it") }))
}

/// The step machine of `UnusedDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnusedDefs: unbounded fn [Def], [((Text, [Text]))], Nat -> [CDiag]
/// ```
pub struct UnusedDefs {
    pub defs_p0: crate::prelude::Array<crate::check::env::Def>,
    pub refs_p1: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>,
    pub shown_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::check::errors::CDiag>> for UnusedDefs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::check::errors::CDiag>> {
        let defs_p0 = &self.defs_p0;
        let refs_p1 = &self.refs_p1;
        let shown_p2 = &self.shown_p2;
        let used0_p3 = crate::prelude::fold(refs_p1, &crate::prelude::Map::new(), &(|m_p6: &crate::prelude::Map<crate::prelude::Text, ()>, (k_p7, rs_p8): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| crate::prelude::fold(rs_p8, m_p6, &(|m2_p9: &crate::prelude::Map<crate::prelude::Text, ()>, r_pa: &crate::prelude::Text| if r_pa == k_p7 { m2_p9.clone() } else { crate::prelude::insert(m2_p9, r_pa, &()) }))));
        let defs_p0x = defs_p0.clone();
        let shown_p2x = shown_p2.clone();
        crate::prelude::call_value(crate::prelude::fold_job(defs_p0x.clone(), used0_p3.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, ()>, crate::check::env::Def)| crate::prelude::entered(crate::prelude::once_job(move || {
            let m_pb = p0;
            let d_pc = p1;
            match &d_pc.body_p {
                crate::check::env::DefBody::DbCheck(c_pd) => crate::prelude::fold_job(c_pd.lines_p.clone(), m_pb.clone(), {
                    let d_pcx = d_pc.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, ()>, crate::syntax::decls::CheckLine)| {
                        let d_pcxy = d_pcx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let m2_pe = p0;
                            let l_pf = p1;
                            crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(l_pf.expr_p.clone()), move |exprs_in_f_4836: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&exprs_in_f_4836, &m2_pe, &(|m3_pg: &crate::prelude::Map<crate::prelude::Text, ()>, e_ph: &crate::syntax::Expr| match &*e_ph.kind_p {
                                crate::syntax::ExprKind::EName(n_pi) => crate::prelude::insert(&crate::prelude::insert(m3_pg, &crate::check::env::sname_key_f(n_pi), &()), &crate::check::env::qual_key_f(&d_pcxy.home_p, &crate::check::env::sname_key_f(n_pi)), &()),
                                _ => m3_pg.clone(),
                            }))))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, ()>, crate::syntax::decls::CheckLine)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, ()>>>>
                }).cycle(),
                _ => ::prism_rtl::Turn::Finished(m_pb.clone()),
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, ()>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, ()>>>>), move |fold_4745: crate::prelude::Map<crate::prelude::Text, ()>| {
            let used_p4 = fold_4745;
            let own_p5 = crate::prelude::filter(&defs_p0x, &(|d_pj: &crate::check::env::Def| ((((&d_pj.file_p < &shown_p2x) && !crate::check::env::has_key_f(&used_p4, &d_pj.qk_p)) && (&d_pj.name_p != &crate::prelude::Text::lit("@main"))) && !is_method_def_f(d_pj)) && !is_testing_def_f(d_pj)));
            ::prism_rtl::Turn::Finished(crate::prelude::each(&own_p5, &(|d_pk: &crate::check::env::Def| crate::check::errors::CDiag { code_p: crate::prelude::Text::lit("unused"), file_p: d_pk.file_p.clone(), span_p: d_pk.span_p.clone(), message_p: crate::prelude::Text::from(format!("nothing uses `{}`", &d_pk.name_p)), fix_p: crate::prelude::Text::lit("delete it, or use it") })))
        })
    }
}

/// `Start UnusedDefs, x`: what the function value is when passed to `@Run`.
pub fn start_unused_defs_f(defs_p0: crate::prelude::Array<crate::check::env::Def>, refs_p1: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>, shown_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::errors::CDiag>>> {
    ::std::rc::Rc::new(UnusedDefs { defs_p0, refs_p1, shown_p2 })
}

/// ```prism
/// TestOnlyReached: fn [Src], [Def], [((Text, [Text]))] -> [CDiag]
/// ```
pub fn test_only_reached_f(srcs_p0: &crate::prelude::Array<crate::check::errors::Src>, defs_p1: &crate::prelude::Array<crate::check::env::Def>, refs_p2: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>) -> crate::prelude::Array<crate::check::errors::CDiag> {
    let in_test_p3 = crate::prelude::fold(defs_p1, &crate::prelude::Map::new(), &(|m_p4: &crate::prelude::Map<crate::prelude::Text, crate::check::env::Def>, d_p5: &crate::check::env::Def| if &def_role_f(srcs_p0, d_p5) == &crate::prelude::Text::lit("test") {
        crate::prelude::insert(m_p4, &d_p5.qk_p, d_p5)
    } else {
        m_p4.clone()
    }));
    if &crate::prelude::size(&in_test_p3) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Array::new()
    } else {
        {
            let by_key_p6 = crate::prelude::fold(defs_p1, &crate::prelude::Map::new(), &(|m_p7: &crate::prelude::Map<crate::prelude::Text, crate::check::env::Def>, d_p8: &crate::check::env::Def| crate::prelude::insert(m_p7, &d_p8.qk_p, d_p8)));
            crate::prelude::fold(refs_p2, &crate::prelude::Array::new(), &(|acc_p9: &crate::prelude::Array<crate::check::errors::CDiag>, (k_pa, rs_pb): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| match crate::prelude::get(&by_key_p6, k_pa) {
                ::std::option::Option::Some(d_pc) => if &def_role_f(srcs_p0, &d_pc) == &crate::prelude::Text::lit("test") {
                    acc_p9.clone()
                } else {
                    crate::prelude::fold(rs_pb, acc_p9, &(|a_pd: &crate::prelude::Array<crate::check::errors::CDiag>, r_pe: &crate::prelude::Text| match crate::prelude::get(&in_test_p3, r_pe) {
                        ::std::option::Option::Some(t_pf) => crate::prelude::push(a_pd, &crate::check::errors::CDiag { code_p: crate::prelude::Text::lit("test-only-reached"), file_p: d_pc.file_p.clone(), span_p: d_pc.span_p.clone(), message_p: crate::prelude::Text::from(format!("`{}` names `{}`, which a test module declares ({}): only test modules name it", &d_pc.name_p, &t_pf.qk_p, &last_path_part_f(&crate::check::errors::seg_at_f(&crate::prelude::or(&crate::prelude::index(srcs_p0, &t_pf.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::lit(""))), &t_pf.span_p.start_p).path_p))), fix_p: crate::prelude::Text::from(format!("move `{}` out of the test module, or `{}` into one", &t_pf.qk_p, &d_pc.name_p)) }),
                        ::std::option::Option::None => a_pd.clone(),
                    }))
                },
                ::std::option::Option::None => acc_p9.clone(),
            }))
        }
    }
}

/// ```prism
/// DefRole: fn [Src], Def -> Text
/// ```
pub fn def_role_f(srcs_p0: &crate::prelude::Array<crate::check::errors::Src>, d_p1: &crate::check::env::Def) -> crate::prelude::Text {
    crate::check::errors::seg_at_f(&crate::prelude::or(&crate::prelude::index(srcs_p0, &d_p1.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::lit(""))), &d_p1.span_p.start_p).role_p.clone()
}

/// ```prism
/// LastPathPart: fn Text -> Text
/// ```
pub fn last_path_part_f(p_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::or(&crate::syntax::lexer::chars::last_o(&crate::prelude::split_on(p_p0, &crate::prelude::Text::lit("/"))), p_p0)
}

/// ```prism
/// IsTestingDef: fn Def -> Bool
/// ```
pub fn is_testing_def_f(d_p0: &crate::check::env::Def) -> bool {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbCheck(_) => true,
        crate::check::env::DefBody::DbTest(_) => true,
        _ => false,
    }
}

/// ```prism
/// IsMethodDef: fn Def -> Bool
/// ```
pub fn is_method_def_f(d_p0: &crate::check::env::Def) -> bool {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbMethod(_, _, _) => true,
        _ => false,
    }
}
