//! The module `Check.Shrink`, from `target/bootstrap/src/prismc/check/shrink/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod calls;
pub mod locals;
pub mod relations;
pub mod summaries;
pub mod types;
pub mod walk;

/// `Rel`:
///
/// ```prism
/// type Rel = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Rel {
    pub param: Nat,
    pub strict: bool,
}

impl Show for Rel {
    fn show(&self, p: &mut Printer) {
        p.record("Rel", &[("param", &self.param), ("strict", &self.strict)]);
    }
}

impl ToPod for Rel {
    fn to_pod(&self) -> Pod {
        Pod::record("Rel", vec![("param", self.param.to_pod()), ("strict", self.strict.to_pod())])
    }
}

impl FromPod for Rel {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Rel { param: FromPod::from_pod(field(p, "param")?)?, strict: FromPod::from_pod(field(p, "strict")?)? })
    }
}

/// `Sc`:
///
/// ```prism
/// type Sc = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Sc {
    pub caller: Text,
    pub callee: Text,
    pub edges: Array<(Nat, Nat, bool)>,
    pub span: crate::syntax::Range,
    pub file: Nat,
    pub arg: Text,
}

impl Show for Sc {
    fn show(&self, p: &mut Printer) {
        p.record("Sc", &[("caller", &self.caller), ("callee", &self.callee), ("edges", &self.edges), ("span", &self.span), ("file", &self.file), ("arg", &self.arg)]);
    }
}

impl ToPod for Sc {
    fn to_pod(&self) -> Pod {
        Pod::record("Sc", vec![("caller", self.caller.to_pod()), ("callee", self.callee.to_pod()), ("edges", self.edges.to_pod()), ("span", self.span.to_pod()), ("file", self.file.to_pod()), ("arg", self.arg.to_pod())])
    }
}

impl FromPod for Sc {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Sc { caller: FromPod::from_pod(field(p, "caller")?)?, callee: FromPod::from_pod(field(p, "callee")?)?, edges: FromPod::from_pod(field(p, "edges")?)?, span: FromPod::from_pod(field(p, "span")?)?, file: FromPod::from_pod(field(p, "file")?)?, arg: FromPod::from_pod(field(p, "arg")?)? })
    }
}

/// `Shrink`:
///
/// ```prism
/// type Shrink = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Shrink {
    pub g: crate::check::env::G,
    pub fns: Array<crate::check::env::Def>,
    pub by_key: Map<Text, crate::check::env::Def>,
    pub targets: Map<Text, Array<Text>>,
    pub impl_defs: Map<Text, Text>,
    pub choices: Map<Text, Array<Text>>,
    pub sums: Map<Text, Nat>,
    pub seeds: Map<Text, Map<Text, Rel>>,
    pub local_of: Map<Text, Text>,
    pub local_base: Map<Text, Map<Text, Rel>>,
}

impl Show for Shrink {
    fn show(&self, p: &mut Printer) {
        p.record("Shrink", &[("g", &self.g), ("fns", &self.fns), ("by_key", &self.by_key), ("targets", &self.targets), ("impl_defs", &self.impl_defs), ("choices", &self.choices), ("sums", &self.sums), ("seeds", &self.seeds), ("local_of", &self.local_of), ("local_base", &self.local_base)]);
    }
}

impl ToPod for Shrink {
    fn to_pod(&self) -> Pod {
        Pod::record("Shrink", vec![("g", self.g.to_pod()), ("fns", self.fns.to_pod()), ("by_key", self.by_key.to_pod()), ("targets", self.targets.to_pod()), ("impl_defs", self.impl_defs.to_pod()), ("choices", self.choices.to_pod()), ("sums", self.sums.to_pod()), ("seeds", self.seeds.to_pod()), ("local_of", self.local_of.to_pod()), ("local_base", self.local_base.to_pod())])
    }
}

impl FromPod for Shrink {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Shrink { g: FromPod::from_pod(field(p, "g")?)?, fns: FromPod::from_pod(field(p, "fns")?)?, by_key: FromPod::from_pod(field(p, "by_key")?)?, targets: FromPod::from_pod(field(p, "targets")?)?, impl_defs: FromPod::from_pod(field(p, "impl_defs")?)?, choices: FromPod::from_pod(field(p, "choices")?)?, sums: FromPod::from_pod(field(p, "sums")?)?, seeds: FromPod::from_pod(field(p, "seeds")?)?, local_of: FromPod::from_pod(field(p, "local_of")?)?, local_base: FromPod::from_pod(field(p, "local_base")?)? })
    }
}

/// ```prism
/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
/// ```
pub fn shrink_check(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, defs_p2: &Array<crate::check::env::Def>) -> (crate::check::types::St, Array<(Text, Array<Text>)>) {
    let fns_p3 = each(&filter(defs_p2, &(|d_pi: &crate::check::env::Def| &len(&crate::check::shrink::types::def_clauses(d_pi)) > &Nat::from(0u32))), &(|d_pj: &crate::check::env::Def| crate::check::shrink::types::own_key(d_pj)));
    let by_key_p4 = fold(&fns_p3, &Map::new(), &(|m_pk: &Map<Text, crate::check::env::Def>, d_pl: &crate::check::env::Def| insert(m_pk, &d_pl.qk, d_pl)));
    let homes_p5 = fold(&fns_p3, &Array::new(), &(|acc_pm: &Array<Text>, d_pn: &crate::check::env::Def| crate::check::types::add_text(acc_pm, &d_pn.home)));
    let nats_p6 = crate::check::shrink::types::nat_minus_seeds(st_p1);
    let pre_p7 = fold(&homes_p5, &Map::new(), &(|m_po: &Map<Text, Map<Text, Rel>>, h_pp: &Text| insert(m_po, h_pp, &fold(&keys(&nats_p6), &crate::check::shrink::relations::prelude_seeds(g_p0, h_pp), &(|m2_pq: &Map<Text, Rel>, k_pr: &Text| insert(m2_pq, k_pr, &crate::check::shrink::relations::no_rel()))))));
    let sk0_p8 = Shrink { g: g_p0.clone(), fns: fns_p3.clone(), by_key: by_key_p4.clone(), targets: crate::check::shrink::types::method_targets(g_p0, &fns_p3), impl_defs: crate::check::shrink::types::impl_defs(g_p0, &fns_p3), choices: st_p1.choices.clone(), sums: Map::new(), seeds: pre_p7.clone(), local_of: Map::new(), local_base: Map::new() };
    let sk1_p9 = {
        let mut this: Shrink = sk0_p8.clone();
        this.sums = crate::check::shrink::summaries::parts_summaries(&sk0_p8, &fns_p3);
        this
    };
    let skg_pa = {
        let mut this: Shrink = sk1_p9.clone();
        this.seeds = crate::check::shrink::calls::hof_seeds(&sk1_p9, &homes_p5);
        this
    };
    let walked_pb = run_to_end(each_job(fns_p3.clone(), {
        let skg_pa = skg_pa.clone();
        Rc::new(move |p0: crate::check::env::Def| {
            let skg_pa = skg_pa.clone();
            entered(once_job(move || {
                let d_ps = p0;
                prism_rtl::Turn::More(Rc::new(crate::check::shrink::locals::DefWalk { sk_p0: skg_pa.clone(), d_p1: d_ps.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)>>>
    }));
    let sk_pc = crate::check::shrink::locals::with_locals(&skg_pa, &fold(&walked_pb, &Array::new(), &(|acc_pt: &Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>, (_, _, ls_pu): &(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)| append(acc_pt, ls_pu))));
    let refs_pd = append(&each(&walked_pb, &(|(k_pv, rs_p10, _): &(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)| (k_pv.clone(), rs_p10.clone()))), &run_to_end(each_job(drop(&sk_pc.fns, &len(&fns_p3)), {
        let sk_pc = sk_pc.clone();
        Rc::new(move |p0: crate::check::env::Def| {
            let sk_pc = sk_pc.clone();
            entered(once_job(move || {
                let d_p11 = p0;
                call_then(crate::check::shrink::calls::start_def_refs(sk_pc.clone(), d_p11.clone()), move |def_refs_3915: Array<Text>| prism_rtl::Turn::Finished((d_p11.qk.clone(), def_refs_3915)))
            }))
        }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>)>>>
    })));
    let keys_pe = each(&sk_pc.fns, &(|d_p12: &crate::check::env::Def| d_p12.qk.clone()));
    let sccs_pf = crate::check::shrink::locals::sccs(&keys_pe, &refs_pd);
    let st2_pg = run_to_end(fold_job(sccs_pf.clone(), crate::check::shrink::types::negative_types(g_p0, st_p1), {
        let sk_pc = sk_pc.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, Array<Text>)| {
            let sk_pc = sk_pc.clone();
            entered(once_job(move || {
                let s_p13 = p0;
                let comp_p14 = p1;
                prism_rtl::Turn::More(Rc::new(crate::check::shrink::locals::ShrinkComponent { sk_p0: sk_pc.clone(), st_p1: s_p13.clone(), comp_p2: comp_p14.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, Array<Text>)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    let st3_ph = run_to_end(fold_job(fns_p3.clone(), st2_pg.clone(), {
        let sk_pc = sk_pc.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::Def)| {
            let sk_pc = sk_pc.clone();
            entered(once_job(move || {
                let s_p15 = p0;
                let d_p16 = p1;
                prism_rtl::Turn::More(Rc::new(crate::check::shrink::summaries::LoopsOf { sk_p0: sk_pc.clone(), st_p1: s_p15.clone(), d_p2: d_p16.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    (st3_ph.clone(), refs_pd.clone())
}

/// The step machine of `ShrinkCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
/// ```
pub struct ShrinkCheck {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub defs_p2: Array<crate::check::env::Def>,
}

impl prism_rtl::Job<(crate::check::types::St, Array<(Text, Array<Text>)>)> for ShrinkCheck {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::St, Array<(Text, Array<Text>)>)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let defs_p2 = &self.defs_p2;
        let fns_p3 = each(&filter(defs_p2, &(|d_pi: &crate::check::env::Def| &len(&crate::check::shrink::types::def_clauses(d_pi)) > &Nat::from(0u32))), &(|d_pj: &crate::check::env::Def| crate::check::shrink::types::own_key(d_pj)));
        let by_key_p4 = fold(&fns_p3, &Map::new(), &(|m_pk: &Map<Text, crate::check::env::Def>, d_pl: &crate::check::env::Def| insert(m_pk, &d_pl.qk, d_pl)));
        let homes_p5 = fold(&fns_p3, &Array::new(), &(|acc_pm: &Array<Text>, d_pn: &crate::check::env::Def| crate::check::types::add_text(acc_pm, &d_pn.home)));
        let g_p0 = g_p0.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::shrink::types::start_nat_minus_seeds(st_p1.clone()), move |nat_minus_seeds_3210: Map<Text, Rel>| {
            let nats_p6 = nat_minus_seeds_3210;
            let pre_p7 = fold(&homes_p5, &Map::new(), &(|m_po: &Map<Text, Map<Text, Rel>>, h_pp: &Text| insert(m_po, h_pp, &fold(&keys(&nats_p6), &crate::check::shrink::relations::prelude_seeds(&g_p0, h_pp), &(|m2_pq: &Map<Text, Rel>, k_pr: &Text| insert(m2_pq, k_pr, &crate::check::shrink::relations::no_rel()))))));
            let sk0_p8 = Shrink { g: g_p0.clone(), fns: fns_p3.clone(), by_key: by_key_p4.clone(), targets: crate::check::shrink::types::method_targets(&g_p0, &fns_p3), impl_defs: crate::check::shrink::types::impl_defs(&g_p0, &fns_p3), choices: st_p1.choices.clone(), sums: Map::new(), seeds: pre_p7.clone(), local_of: Map::new(), local_base: Map::new() };
            let sk1_p9 = {
                let mut this: Shrink = sk0_p8.clone();
                this.sums = crate::check::shrink::summaries::parts_summaries(&sk0_p8, &fns_p3);
                this
            };
            let skg_pa = {
                let mut this: Shrink = sk1_p9.clone();
                this.seeds = crate::check::shrink::calls::hof_seeds(&sk1_p9, &homes_p5);
                this
            };
            call_value(each_job(fns_p3.clone(), {
                let skg_pa = skg_pa.clone();
                Rc::new(move |p0: crate::check::env::Def| {
                    let skg_pa = skg_pa.clone();
                    entered(once_job(move || {
                        let d_ps = p0;
                        prism_rtl::Turn::More(Rc::new(crate::check::shrink::locals::DefWalk { sk_p0: skg_pa.clone(), d_p1: d_ps.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)>>>
            }), move |each_3674: Array<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)>| {
                let walked_pb = each_3674;
                call_then(crate::check::shrink::locals::start_with_locals(skg_pa.clone(), fold(&walked_pb, &Array::new(), &(|acc_pt: &Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>, (_, _, ls_pu): &(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)| append(acc_pt, ls_pu)))), move |with_locals_3717: Shrink| {
                    let sk_pc = with_locals_3717;
                    call_value(each_job(drop(&sk_pc.fns, &len(&fns_p3)), {
                        let sk_pc = sk_pc.clone();
                        Rc::new(move |p0: crate::check::env::Def| {
                            let sk_pc = sk_pc.clone();
                            entered(once_job(move || {
                                let d_p11 = p0;
                                call_then(crate::check::shrink::calls::start_def_refs(sk_pc.clone(), d_p11.clone()), move |def_refs_3915: Array<Text>| prism_rtl::Turn::Finished((d_p11.qk.clone(), def_refs_3915)))
                            }))
                        }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>)>>>
                    }), move |each_3870: Array<(Text, Array<Text>)>| {
                        let refs_pd = append(&each(&walked_pb, &(|(k_pv, rs_p10, _): &(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)| (k_pv.clone(), rs_p10.clone()))), &each_3870);
                        let keys_pe = each(&sk_pc.fns, &(|d_p12: &crate::check::env::Def| d_p12.qk.clone()));
                        call_then(crate::check::shrink::locals::start_sccs(keys_pe.clone(), refs_pd.clone()), move |sccs_3986: Array<Array<Text>>| {
                            let sccs_pf = sccs_3986;
                            call_then(crate::check::shrink::types::start_negative_types(g_p0.clone(), st_p1.clone()), move |negative_types_4028: crate::check::types::St| call_value(fold_job(sccs_pf.clone(), negative_types_4028, {
                                let sk_pc = sk_pc.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, Array<Text>)| {
                                    let sk_pc = sk_pc.clone();
                                    entered(once_job(move || {
                                        let s_p13 = p0;
                                        let comp_p14 = p1;
                                        prism_rtl::Turn::More(Rc::new(crate::check::shrink::locals::ShrinkComponent { sk_p0: sk_pc.clone(), st_p1: s_p13.clone(), comp_p2: comp_p14.clone() }))
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, Array<Text>)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }), move |fold_4016: crate::check::types::St| {
                                let st2_pg = fold_4016;
                                call_value(fold_job(fns_p3.clone(), st2_pg.clone(), {
                                    let sk_pc = sk_pc.clone();
                                    Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::Def)| {
                                        let sk_pc = sk_pc.clone();
                                        entered(once_job(move || {
                                            let s_p15 = p0;
                                            let d_p16 = p1;
                                            prism_rtl::Turn::More(Rc::new(crate::check::shrink::summaries::LoopsOf { sk_p0: sk_pc.clone(), st_p1: s_p15.clone(), d_p2: d_p16.clone() }))
                                        }))
                                    }) as Rc<dyn Fn((crate::check::types::St, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                                }), move |fold_4103: crate::check::types::St| {
                                    let st3_ph = fold_4103;
                                    prism_rtl::Turn::Finished((st3_ph.clone(), refs_pd.clone()))
                                })
                            }))
                        })
                    })
                })
            })
        })
    }
}

/// `Start ShrinkCheck, x`: what the function value is when passed to `@Run`.
pub fn start_shrink_check(g_p0: crate::check::env::G, st_p1: crate::check::types::St, defs_p2: Array<crate::check::env::Def>) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, Array<(Text, Array<Text>)>)>> {
    Rc::new(ShrinkCheck { g_p0, st_p1, defs_p2 })
}

/// ```prism
/// UnusedDefs: unbounded fn [Def], [((Text, [Text]))], Nat -> [CDiag]
/// ```
pub fn unused_defs(defs_p0: &Array<crate::check::env::Def>, refs_p1: &Array<(Text, Array<Text>)>, shown_p2: &Nat) -> Array<crate::check::errors::CDiag> {
    let used0_p3 = fold(refs_p1, &Map::new(), &(|m_p6: &Map<Text, ()>, (k_p7, rs_p8): &(Text, Array<Text>)| fold(rs_p8, m_p6, &(|m2_p9: &Map<Text, ()>, r_pa: &Text| if r_pa == k_p7 { m2_p9.clone() } else { insert(m2_p9, r_pa, &()) }))));
    let used_p4 = run_to_end(fold_job(defs_p0.clone(), used0_p3.clone(), Rc::new(move |(p0, p1): (Map<Text, ()>, crate::check::env::Def)| entered(once_job(move || {
        let m_pb = p0;
        let d_pc = p1;
        match &d_pc.body {
            crate::check::env::DefBody::DbCheck(c_pd) => fold_job(c_pd.lines.clone(), m_pb.clone(), {
                let d_pc = d_pc.clone();
                Rc::new(move |(p0, p1): (Map<Text, ()>, crate::syntax::decls::CheckLine)| {
                    let d_pc = d_pc.clone();
                    entered(once_job(move || {
                        let m2_pe = p0;
                        let l_pf = p1;
                        call_then(crate::check::typed::print::start_exprs_in(l_pf.expr.clone()), move |exprs_in_4836: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(fold(&exprs_in_4836, &m2_pe, &(|m3_pg: &Map<Text, ()>, e_ph: &crate::syntax::Expr| match &*e_ph.kind {
                            crate::syntax::ExprKind::EName(n_pi) => insert(&insert(m3_pg, &crate::check::env::sname_key(n_pi), &()), &crate::check::env::qual_key(&d_pc.home, &crate::check::env::sname_key(n_pi)), &()),
                            _ => m3_pg.clone(),
                        }))))
                    }))
                }) as Rc<dyn Fn((Map<Text, ()>, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<Map<Text, ()>>>>
            }).cycle(),
            _ => prism_rtl::Turn::Finished(m_pb.clone()),
        }
    }))) as Rc<dyn Fn((Map<Text, ()>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Map<Text, ()>>>>));
    let own_p5 = filter(defs_p0, &(|d_pj: &crate::check::env::Def| ((((&d_pj.file < shown_p2) && !crate::check::env::has_key(&used_p4, &d_pj.qk)) && (&d_pj.name != &Text::lit("@main"))) && !is_method_def(d_pj)) && !is_testing_def(d_pj)));
    each(&own_p5, &(|d_pk: &crate::check::env::Def| crate::check::errors::CDiag { code: Text::lit("unused"), file: d_pk.file.clone(), span: d_pk.span.clone(), message: Text::from(format!("nothing uses `{}`", &d_pk.name)), fix: Text::lit("delete it, or use it") }))
}

/// The step machine of `UnusedDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnusedDefs: unbounded fn [Def], [((Text, [Text]))], Nat -> [CDiag]
/// ```
pub struct UnusedDefs {
    pub defs_p0: Array<crate::check::env::Def>,
    pub refs_p1: Array<(Text, Array<Text>)>,
    pub shown_p2: Nat,
}

impl prism_rtl::Job<Array<crate::check::errors::CDiag>> for UnusedDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::errors::CDiag>> {
        let defs_p0 = &self.defs_p0;
        let refs_p1 = &self.refs_p1;
        let shown_p2 = &self.shown_p2;
        let used0_p3 = fold(refs_p1, &Map::new(), &(|m_p6: &Map<Text, ()>, (k_p7, rs_p8): &(Text, Array<Text>)| fold(rs_p8, m_p6, &(|m2_p9: &Map<Text, ()>, r_pa: &Text| if r_pa == k_p7 { m2_p9.clone() } else { insert(m2_p9, r_pa, &()) }))));
        let defs_p0 = defs_p0.clone();
        let shown_p2 = shown_p2.clone();
        call_value(fold_job(defs_p0.clone(), used0_p3.clone(), Rc::new(move |(p0, p1): (Map<Text, ()>, crate::check::env::Def)| entered(once_job(move || {
            let m_pb = p0;
            let d_pc = p1;
            match &d_pc.body {
                crate::check::env::DefBody::DbCheck(c_pd) => fold_job(c_pd.lines.clone(), m_pb.clone(), {
                    let d_pc = d_pc.clone();
                    Rc::new(move |(p0, p1): (Map<Text, ()>, crate::syntax::decls::CheckLine)| {
                        let d_pc = d_pc.clone();
                        entered(once_job(move || {
                            let m2_pe = p0;
                            let l_pf = p1;
                            call_then(crate::check::typed::print::start_exprs_in(l_pf.expr.clone()), move |exprs_in_4836: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(fold(&exprs_in_4836, &m2_pe, &(|m3_pg: &Map<Text, ()>, e_ph: &crate::syntax::Expr| match &*e_ph.kind {
                                crate::syntax::ExprKind::EName(n_pi) => insert(&insert(m3_pg, &crate::check::env::sname_key(n_pi), &()), &crate::check::env::qual_key(&d_pc.home, &crate::check::env::sname_key(n_pi)), &()),
                                _ => m3_pg.clone(),
                            }))))
                        }))
                    }) as Rc<dyn Fn((Map<Text, ()>, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<Map<Text, ()>>>>
                }).cycle(),
                _ => prism_rtl::Turn::Finished(m_pb.clone()),
            }
        }))) as Rc<dyn Fn((Map<Text, ()>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Map<Text, ()>>>>), move |fold_4745: Map<Text, ()>| {
            let used_p4 = fold_4745;
            let own_p5 = filter(&defs_p0, &(|d_pj: &crate::check::env::Def| ((((&d_pj.file < &shown_p2) && !crate::check::env::has_key(&used_p4, &d_pj.qk)) && (&d_pj.name != &Text::lit("@main"))) && !is_method_def(d_pj)) && !is_testing_def(d_pj)));
            prism_rtl::Turn::Finished(each(&own_p5, &(|d_pk: &crate::check::env::Def| crate::check::errors::CDiag { code: Text::lit("unused"), file: d_pk.file.clone(), span: d_pk.span.clone(), message: Text::from(format!("nothing uses `{}`", &d_pk.name)), fix: Text::lit("delete it, or use it") })))
        })
    }
}

/// `Start UnusedDefs, x`: what the function value is when passed to `@Run`.
pub fn start_unused_defs(defs_p0: Array<crate::check::env::Def>, refs_p1: Array<(Text, Array<Text>)>, shown_p2: Nat) -> Rc<dyn prism_rtl::Job<Array<crate::check::errors::CDiag>>> {
    Rc::new(UnusedDefs { defs_p0, refs_p1, shown_p2 })
}

/// ```prism
/// TestOnlyReached: fn [Src], [Def], [((Text, [Text]))] -> [CDiag]
/// ```
pub fn test_only_reached(srcs_p0: &Array<crate::check::errors::Src>, defs_p1: &Array<crate::check::env::Def>, refs_p2: &Array<(Text, Array<Text>)>) -> Array<crate::check::errors::CDiag> {
    let in_test_p3 = fold(defs_p1, &Map::new(), &(|m_p4: &Map<Text, crate::check::env::Def>, d_p5: &crate::check::env::Def| if &def_role(srcs_p0, d_p5) == &Text::lit("test") {
        insert(m_p4, &d_p5.qk, d_p5)
    } else {
        m_p4.clone()
    }));
    if &size(&in_test_p3) == &Nat::from(0u32) {
        Array::new()
    } else {
        {
            let by_key_p6 = fold(defs_p1, &Map::new(), &(|m_p7: &Map<Text, crate::check::env::Def>, d_p8: &crate::check::env::Def| insert(m_p7, &d_p8.qk, d_p8)));
            fold(refs_p2, &Array::new(), &(|acc_p9: &Array<crate::check::errors::CDiag>, (k_pa, rs_pb): &(Text, Array<Text>)| match get(&by_key_p6, k_pa) {
                Some(d_pc) => if &def_role(srcs_p0, &d_pc) == &Text::lit("test") {
                    acc_p9.clone()
                } else {
                    fold(rs_pb, acc_p9, &(|a_pd: &Array<crate::check::errors::CDiag>, r_pe: &Text| match get(&in_test_p3, r_pe) {
                        Some(t_pf) => push(a_pd, &crate::check::errors::CDiag { code: Text::lit("test-only-reached"), file: d_pc.file.clone(), span: d_pc.span.clone(), message: Text::from(format!("`{}` names `{}`, which a test module declares ({}): only test modules name it", &d_pc.name, &t_pf.qk, &last_path_part(&crate::check::errors::seg_at(&or(&index(srcs_p0, &t_pf.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))), &t_pf.span.start).path_))), fix: Text::from(format!("move `{}` out of the test module, or `{}` into one", &t_pf.qk, &d_pc.name)) }),
                        None => a_pd.clone(),
                    }))
                },
                None => acc_p9.clone(),
            }))
        }
    }
}

/// ```prism
/// DefRole: fn [Src], Def -> Text
/// ```
pub fn def_role(srcs_p0: &Array<crate::check::errors::Src>, d_p1: &crate::check::env::Def) -> Text {
    crate::check::errors::seg_at(&or(&index(srcs_p0, &d_p1.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))), &d_p1.span.start).role.clone()
}

/// ```prism
/// LastPathPart: fn Text -> Text
/// ```
pub fn last_path_part(p_p0: &Text) -> Text {
    or(&crate::syntax::lexer::chars::last(&split_on(p_p0, &Text::lit("/"))), p_p0)
}

/// ```prism
/// IsTestingDef: fn Def -> Bool
/// ```
pub fn is_testing_def(d_p0: &crate::check::env::Def) -> bool {
    match &d_p0.body {
        crate::check::env::DefBody::DbCheck(_) => true,
        crate::check::env::DefBody::DbTest(_) => true,
        _ => false,
    }
}

/// ```prism
/// IsMethodDef: fn Def -> Bool
/// ```
pub fn is_method_def(d_p0: &crate::check::env::Def) -> bool {
    match &d_p0.body {
        crate::check::env::DefBody::DbMethod(_, _, _) => true,
        _ => false,
    }
}
