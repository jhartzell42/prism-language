//! The module `Check.Shrink`, from `target/bootstrap/src/prismc/check/shrink/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod calls;
pub mod locals;
pub mod relations;
pub mod summaries;
pub mod types;
pub mod walk;

/// `Rel`:
///
/// ```prism
/// type Rel = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Rel {
    pub param: Nat,
    pub strict: bool,
}

impl Show for Rel {
    fn show(&self, p: &mut Printer) {
        p.record("Rel", &[("param", &self.param), ("strict", &self.strict)]);
    }
}

impl ToPod for Rel {
    fn to_pod(&self) -> Pod {
        Pod::record("Rel", vec![("param", self.param.to_pod()), ("strict", self.strict.to_pod())])
    }
}

impl FromPod for Rel {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Rel { param: FromPod::from_pod(field(p, "param")?)?, strict: FromPod::from_pod(field(p, "strict")?)? })
    }
}

/// `Sc`:
///
/// ```prism
/// type Sc = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Sc {
    pub caller: Text,
    pub callee: Text,
    pub edges: Array<(Nat, Nat, bool)>,
    pub span: crate::syntax::Range,
    pub file: Nat,
    pub arg: Text,
}

impl Show for Sc {
    fn show(&self, p: &mut Printer) {
        p.record("Sc", &[("caller", &self.caller), ("callee", &self.callee), ("edges", &self.edges), ("span", &self.span), ("file", &self.file), ("arg", &self.arg)]);
    }
}

impl ToPod for Sc {
    fn to_pod(&self) -> Pod {
        Pod::record("Sc", vec![("caller", self.caller.to_pod()), ("callee", self.callee.to_pod()), ("edges", self.edges.to_pod()), ("span", self.span.to_pod()), ("file", self.file.to_pod()), ("arg", self.arg.to_pod())])
    }
}

impl FromPod for Sc {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Sc { caller: FromPod::from_pod(field(p, "caller")?)?, callee: FromPod::from_pod(field(p, "callee")?)?, edges: FromPod::from_pod(field(p, "edges")?)?, span: FromPod::from_pod(field(p, "span")?)?, file: FromPod::from_pod(field(p, "file")?)?, arg: FromPod::from_pod(field(p, "arg")?)? })
    }
}

/// `Shrink`:
///
/// ```prism
/// type Shrink = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Shrink {
    pub g: crate::check::env::G,
    pub fns: Array<crate::check::env::Def>,
    pub by_key: Map<Text, crate::check::env::Def>,
    pub targets: Map<Text, Array<Text>>,
    pub impl_defs: Map<Text, Text>,
    pub choices: Map<Text, Array<Text>>,
    pub sums: Map<Text, Nat>,
    pub seeds: Map<Text, Map<Text, Rel>>,
    pub local_of: Map<Text, Text>,
    pub local_base: Map<Text, Map<Text, Rel>>,
}

impl Show for Shrink {
    fn show(&self, p: &mut Printer) {
        p.record("Shrink", &[("g", &self.g), ("fns", &self.fns), ("by_key", &self.by_key), ("targets", &self.targets), ("impl_defs", &self.impl_defs), ("choices", &self.choices), ("sums", &self.sums), ("seeds", &self.seeds), ("local_of", &self.local_of), ("local_base", &self.local_base)]);
    }
}

impl ToPod for Shrink {
    fn to_pod(&self) -> Pod {
        Pod::record("Shrink", vec![("g", self.g.to_pod()), ("fns", self.fns.to_pod()), ("by_key", self.by_key.to_pod()), ("targets", self.targets.to_pod()), ("impl_defs", self.impl_defs.to_pod()), ("choices", self.choices.to_pod()), ("sums", self.sums.to_pod()), ("seeds", self.seeds.to_pod()), ("local_of", self.local_of.to_pod()), ("local_base", self.local_base.to_pod())])
    }
}

impl FromPod for Shrink {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Shrink { g: FromPod::from_pod(field(p, "g")?)?, fns: FromPod::from_pod(field(p, "fns")?)?, by_key: FromPod::from_pod(field(p, "by_key")?)?, targets: FromPod::from_pod(field(p, "targets")?)?, impl_defs: FromPod::from_pod(field(p, "impl_defs")?)?, choices: FromPod::from_pod(field(p, "choices")?)?, sums: FromPod::from_pod(field(p, "sums")?)?, seeds: FromPod::from_pod(field(p, "seeds")?)?, local_of: FromPod::from_pod(field(p, "local_of")?)?, local_base: FromPod::from_pod(field(p, "local_base")?)? })
    }
}

/// ```prism
/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
/// ```
pub fn shrink_check(g: &crate::check::env::G, st: &crate::check::types::St, defs: &Array<crate::check::env::Def>) -> (crate::check::types::St, Array<(Text, Array<Text>)>) {
    let fns = each(&filter(defs, &(|d: &crate::check::env::Def| &len(&crate::check::shrink::types::def_clauses(d)) > &Nat::from(0u32))), &(|d: &crate::check::env::Def| crate::check::shrink::types::own_key(d)));
    let by_key = fold(&fns, &Map::new(), &(|m: &Map<Text, crate::check::env::Def>, d: &crate::check::env::Def| insert(m, &d.qk, d)));
    let homes = fold(&fns, &Array::new(), &(|acc: &Array<Text>, d: &crate::check::env::Def| crate::check::types::add_text(acc, &d.home)));
    let nats = crate::check::shrink::types::nat_minus_seeds(st);
    let pre = fold(&homes, &Map::new(), &(|m: &Map<Text, Map<Text, Rel>>, h: &Text| insert(m, h, &fold(&keys(&nats), &crate::check::shrink::relations::prelude_seeds(g, h), &(|m2: &Map<Text, Rel>, k: &Text| insert(m2, k, &crate::check::shrink::relations::no_rel()))))));
    let sk0 = Shrink { g: g.clone(), fns: fns.clone(), by_key: by_key.clone(), targets: crate::check::shrink::types::method_targets(g, &fns), impl_defs: crate::check::shrink::types::impl_defs(g, &fns), choices: st.choices.clone(), sums: Map::new(), seeds: pre.clone(), local_of: Map::new(), local_base: Map::new() };
    let sk1 = {
        let mut this: Shrink = sk0.clone();
        this.sums = crate::check::shrink::summaries::parts_summaries(&sk0, &fns);
        this
    };
    let skg = {
        let mut this: Shrink = sk1.clone();
        this.seeds = crate::check::shrink::calls::hof_seeds(&sk1, &homes);
        this
    };
    let walked = run_to_end(each_job(fns.clone(), {
        let skg = skg.clone();
        Rc::new(move |p0: crate::check::env::Def| {
            let skg = skg.clone();
            entered(once_job(move || {
                let d = p0;
                prism_rtl::Turn::More(Rc::new(crate::check::shrink::locals::DefWalk { sk: skg.clone(), d: d.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)>>>
    }));
    let sk = crate::check::shrink::locals::with_locals(&skg, &fold(&walked, &Array::new(), &(|acc: &Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>, (_, _, ls): &(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)| append(acc, ls))));
    let refs = append(&each(&walked, &(|(k, rs, _): &(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)| (k.clone(), rs.clone()))), &run_to_end(each_job(drop(&sk.fns, &len(&fns)), {
        let sk = sk.clone();
        Rc::new(move |p0: crate::check::env::Def| {
            let sk = sk.clone();
            entered(once_job(move || {
                let d = p0;
                call_then(crate::check::shrink::calls::start_def_refs(sk.clone(), d.clone()), move |def_refs_3915: Array<Text>| prism_rtl::Turn::Finished((d.qk.clone(), def_refs_3915)))
            }))
        }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>)>>>
    })));
    let keys_ = each(&sk.fns, &(|d: &crate::check::env::Def| d.qk.clone()));
    let sccs = crate::check::shrink::locals::sccs(&keys_, &refs);
    let st2 = run_to_end(fold_job(sccs.clone(), crate::check::shrink::types::negative_types(g, st), {
        let sk = sk.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, Array<Text>)| {
            let sk = sk.clone();
            entered(once_job(move || {
                let s = p0;
                let comp = p1;
                prism_rtl::Turn::More(Rc::new(crate::check::shrink::locals::ShrinkComponent { sk: sk.clone(), st: s.clone(), comp: comp.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, Array<Text>)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    let st3 = run_to_end(fold_job(fns.clone(), st2.clone(), {
        let sk = sk.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::Def)| {
            let sk = sk.clone();
            entered(once_job(move || {
                let s = p0;
                let d = p1;
                prism_rtl::Turn::More(Rc::new(crate::check::shrink::summaries::LoopsOf { sk: sk.clone(), st: s.clone(), d: d.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    (st3.clone(), refs.clone())
}

/// The step machine of `ShrinkCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
/// ```
pub struct ShrinkCheck {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub defs: Array<crate::check::env::Def>,
}

impl prism_rtl::Job<(crate::check::types::St, Array<(Text, Array<Text>)>)> for ShrinkCheck {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::St, Array<(Text, Array<Text>)>)> {
        let g = &self.g;
        let st = &self.st;
        let defs = &self.defs;
        let fns = each(&filter(defs, &(|d: &crate::check::env::Def| &len(&crate::check::shrink::types::def_clauses(d)) > &Nat::from(0u32))), &(|d: &crate::check::env::Def| crate::check::shrink::types::own_key(d)));
        let by_key = fold(&fns, &Map::new(), &(|m: &Map<Text, crate::check::env::Def>, d: &crate::check::env::Def| insert(m, &d.qk, d)));
        let homes = fold(&fns, &Array::new(), &(|acc: &Array<Text>, d: &crate::check::env::Def| crate::check::types::add_text(acc, &d.home)));
        let g = g.clone();
        let st = st.clone();
        call_then(crate::check::shrink::types::start_nat_minus_seeds(st.clone()), move |nat_minus_seeds_3210: Map<Text, Rel>| {
            let nats = nat_minus_seeds_3210;
            let pre = fold(&homes, &Map::new(), &(|m: &Map<Text, Map<Text, Rel>>, h: &Text| insert(m, h, &fold(&keys(&nats), &crate::check::shrink::relations::prelude_seeds(&g, h), &(|m2: &Map<Text, Rel>, k: &Text| insert(m2, k, &crate::check::shrink::relations::no_rel()))))));
            let sk0 = Shrink { g: g.clone(), fns: fns.clone(), by_key: by_key.clone(), targets: crate::check::shrink::types::method_targets(&g, &fns), impl_defs: crate::check::shrink::types::impl_defs(&g, &fns), choices: st.choices.clone(), sums: Map::new(), seeds: pre.clone(), local_of: Map::new(), local_base: Map::new() };
            let sk1 = {
                let mut this: Shrink = sk0.clone();
                this.sums = crate::check::shrink::summaries::parts_summaries(&sk0, &fns);
                this
            };
            let skg = {
                let mut this: Shrink = sk1.clone();
                this.seeds = crate::check::shrink::calls::hof_seeds(&sk1, &homes);
                this
            };
            call_value(each_job(fns.clone(), {
                let skg = skg.clone();
                Rc::new(move |p0: crate::check::env::Def| {
                    let skg = skg.clone();
                    entered(once_job(move || {
                        let d = p0;
                        prism_rtl::Turn::More(Rc::new(crate::check::shrink::locals::DefWalk { sk: skg.clone(), d: d.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)>>>
            }), move |each_3674: Array<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)>| {
                let walked = each_3674;
                call_then(crate::check::shrink::locals::start_with_locals(skg.clone(), fold(&walked, &Array::new(), &(|acc: &Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>, (_, _, ls): &(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)| append(acc, ls)))), move |with_locals_3717: Shrink| {
                    let sk = with_locals_3717;
                    call_value(each_job(drop(&sk.fns, &len(&fns)), {
                        let sk = sk.clone();
                        Rc::new(move |p0: crate::check::env::Def| {
                            let sk = sk.clone();
                            entered(once_job(move || {
                                let d = p0;
                                call_then(crate::check::shrink::calls::start_def_refs(sk.clone(), d.clone()), move |def_refs_3915: Array<Text>| prism_rtl::Turn::Finished((d.qk.clone(), def_refs_3915)))
                            }))
                        }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>)>>>
                    }), move |each_3870: Array<(Text, Array<Text>)>| {
                        let refs = append(&each(&walked, &(|(k, rs, _): &(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)| (k.clone(), rs.clone()))), &each_3870);
                        let keys_ = each(&sk.fns, &(|d: &crate::check::env::Def| d.qk.clone()));
                        call_then(crate::check::shrink::locals::start_sccs(keys_.clone(), refs.clone()), move |sccs_3986: Array<Array<Text>>| {
                            let sccs = sccs_3986;
                            call_then(crate::check::shrink::types::start_negative_types(g.clone(), st.clone()), move |negative_types_4028: crate::check::types::St| call_value(fold_job(sccs.clone(), negative_types_4028, {
                                let sk = sk.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, Array<Text>)| {
                                    let sk = sk.clone();
                                    entered(once_job(move || {
                                        let s = p0;
                                        let comp = p1;
                                        prism_rtl::Turn::More(Rc::new(crate::check::shrink::locals::ShrinkComponent { sk: sk.clone(), st: s.clone(), comp: comp.clone() }))
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, Array<Text>)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }), move |fold_4016: crate::check::types::St| {
                                let st2 = fold_4016;
                                call_value(fold_job(fns.clone(), st2.clone(), {
                                    let sk = sk.clone();
                                    Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::Def)| {
                                        let sk = sk.clone();
                                        entered(once_job(move || {
                                            let s = p0;
                                            let d = p1;
                                            prism_rtl::Turn::More(Rc::new(crate::check::shrink::summaries::LoopsOf { sk: sk.clone(), st: s.clone(), d: d.clone() }))
                                        }))
                                    }) as Rc<dyn Fn((crate::check::types::St, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                                }), move |fold_4103: crate::check::types::St| {
                                    let st3 = fold_4103;
                                    prism_rtl::Turn::Finished((st3.clone(), refs.clone()))
                                })
                            }))
                        })
                    })
                })
            })
        })
    }
}

/// `Start ShrinkCheck, x`: what the function value is when passed to `@Run`.
pub fn start_shrink_check(g: crate::check::env::G, st: crate::check::types::St, defs: Array<crate::check::env::Def>) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, Array<(Text, Array<Text>)>)>> {
    Rc::new(ShrinkCheck { g, st, defs })
}

/// ```prism
/// UnusedDefs: unbounded fn [Def], [((Text, [Text]))], Nat -> [CDiag]
/// ```
pub fn unused_defs(defs: &Array<crate::check::env::Def>, refs: &Array<(Text, Array<Text>)>, shown: &Nat) -> Array<crate::check::errors::CDiag> {
    let used0 = fold(refs, &Map::new(), &(|m: &Map<Text, ()>, (k, rs): &(Text, Array<Text>)| fold(rs, m, &(|m2: &Map<Text, ()>, r: &Text| if r == k { m2.clone() } else { insert(m2, r, &()) }))));
    let used = run_to_end(fold_job(defs.clone(), used0.clone(), Rc::new(move |(p0, p1): (Map<Text, ()>, crate::check::env::Def)| entered(once_job(move || {
        let m = p0;
        let d = p1;
        match &d.body {
            crate::check::env::DefBody::DbCheck(c) => fold_job(c.lines.clone(), m.clone(), {
                let d = d.clone();
                Rc::new(move |(p0, p1): (Map<Text, ()>, crate::syntax::decls::CheckLine)| {
                    let d = d.clone();
                    entered(once_job(move || {
                        let m2 = p0;
                        let l = p1;
                        call_then(crate::check::typed::print::start_exprs_in(l.expr.clone()), move |exprs_in_4836: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(fold(&exprs_in_4836, &m2, &(|m3: &Map<Text, ()>, e: &crate::syntax::Expr| match &*e.kind {
                            crate::syntax::ExprKind::EName(n) => insert(&insert(m3, &crate::check::env::sname_key(n), &()), &crate::check::env::qual_key(&d.home, &crate::check::env::sname_key(n)), &()),
                            _ => m3.clone(),
                        }))))
                    }))
                }) as Rc<dyn Fn((Map<Text, ()>, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<Map<Text, ()>>>>
            }).cycle(),
            _ => prism_rtl::Turn::Finished(m.clone()),
        }
    }))) as Rc<dyn Fn((Map<Text, ()>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Map<Text, ()>>>>));
    let own = filter(defs, &(|d: &crate::check::env::Def| ((((&d.file < shown) && !crate::check::env::has_key(&used, &d.qk)) && (&d.name != &Text::lit("@main"))) && !is_method_def(d)) && !is_testing_def(d)));
    each(&own, &(|d: &crate::check::env::Def| crate::check::errors::CDiag { code: Text::lit("unused"), file: d.file.clone(), span: d.span.clone(), message: Text::from(format!("nothing uses `{}`", &d.name)), fix: Text::lit("delete it, or use it") }))
}

/// The step machine of `UnusedDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnusedDefs: unbounded fn [Def], [((Text, [Text]))], Nat -> [CDiag]
/// ```
pub struct UnusedDefs {
    pub defs: Array<crate::check::env::Def>,
    pub refs: Array<(Text, Array<Text>)>,
    pub shown: Nat,
}

impl prism_rtl::Job<Array<crate::check::errors::CDiag>> for UnusedDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::errors::CDiag>> {
        let defs = &self.defs;
        let refs = &self.refs;
        let shown = &self.shown;
        let used0 = fold(refs, &Map::new(), &(|m: &Map<Text, ()>, (k, rs): &(Text, Array<Text>)| fold(rs, m, &(|m2: &Map<Text, ()>, r: &Text| if r == k { m2.clone() } else { insert(m2, r, &()) }))));
        let defs = defs.clone();
        let shown = shown.clone();
        call_value(fold_job(defs.clone(), used0.clone(), Rc::new(move |(p0, p1): (Map<Text, ()>, crate::check::env::Def)| entered(once_job(move || {
            let m = p0;
            let d = p1;
            match &d.body {
                crate::check::env::DefBody::DbCheck(c) => fold_job(c.lines.clone(), m.clone(), {
                    let d = d.clone();
                    Rc::new(move |(p0, p1): (Map<Text, ()>, crate::syntax::decls::CheckLine)| {
                        let d = d.clone();
                        entered(once_job(move || {
                            let m2 = p0;
                            let l = p1;
                            call_then(crate::check::typed::print::start_exprs_in(l.expr.clone()), move |exprs_in_4836: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(fold(&exprs_in_4836, &m2, &(|m3: &Map<Text, ()>, e: &crate::syntax::Expr| match &*e.kind {
                                crate::syntax::ExprKind::EName(n) => insert(&insert(m3, &crate::check::env::sname_key(n), &()), &crate::check::env::qual_key(&d.home, &crate::check::env::sname_key(n)), &()),
                                _ => m3.clone(),
                            }))))
                        }))
                    }) as Rc<dyn Fn((Map<Text, ()>, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<Map<Text, ()>>>>
                }).cycle(),
                _ => prism_rtl::Turn::Finished(m.clone()),
            }
        }))) as Rc<dyn Fn((Map<Text, ()>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Map<Text, ()>>>>), move |fold_4745: Map<Text, ()>| {
            let used = fold_4745;
            let own = filter(&defs, &(|d: &crate::check::env::Def| ((((&d.file < &shown) && !crate::check::env::has_key(&used, &d.qk)) && (&d.name != &Text::lit("@main"))) && !is_method_def(d)) && !is_testing_def(d)));
            prism_rtl::Turn::Finished(each(&own, &(|d: &crate::check::env::Def| crate::check::errors::CDiag { code: Text::lit("unused"), file: d.file.clone(), span: d.span.clone(), message: Text::from(format!("nothing uses `{}`", &d.name)), fix: Text::lit("delete it, or use it") })))
        })
    }
}

/// `Start UnusedDefs, x`: what the function value is when passed to `@Run`.
pub fn start_unused_defs(defs: Array<crate::check::env::Def>, refs: Array<(Text, Array<Text>)>, shown: Nat) -> Rc<dyn prism_rtl::Job<Array<crate::check::errors::CDiag>>> {
    Rc::new(UnusedDefs { defs, refs, shown })
}

/// ```prism
/// TestOnlyReached: fn [Src], [Def], [((Text, [Text]))] -> [CDiag]
/// ```
pub fn test_only_reached(srcs: &Array<crate::check::errors::Src>, defs: &Array<crate::check::env::Def>, refs: &Array<(Text, Array<Text>)>) -> Array<crate::check::errors::CDiag> {
    let in_test = fold(defs, &Map::new(), &(|m: &Map<Text, crate::check::env::Def>, d: &crate::check::env::Def| if &def_role(srcs, d) == &Text::lit("test") { insert(m, &d.qk, d) } else { m.clone() }));
    if &size(&in_test) == &Nat::from(0u32) {
        Array::new()
    } else {
        {
            let by_key = fold(defs, &Map::new(), &(|m: &Map<Text, crate::check::env::Def>, d: &crate::check::env::Def| insert(m, &d.qk, d)));
            fold(refs, &Array::new(), &(|acc: &Array<crate::check::errors::CDiag>, (k, rs): &(Text, Array<Text>)| match get(&by_key, k) {
                Some(d) => if &def_role(srcs, &d) == &Text::lit("test") {
                    acc.clone()
                } else {
                    fold(rs, acc, &(|a: &Array<crate::check::errors::CDiag>, r: &Text| match get(&in_test, r) {
                        Some(t) => push(a, &crate::check::errors::CDiag { code: Text::lit("test-only-reached"), file: d.file.clone(), span: d.span.clone(), message: Text::from(format!("`{}` names `{}`, which a test module declares ({}): only test modules name it", &d.name, &t.qk, &last_path_part(&crate::check::errors::seg_at(&or(&index(srcs, &t.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))), &t.span.start).path_))), fix: Text::from(format!("move `{}` out of the test module, or `{}` into one", &t.qk, &d.name)) }),
                        None => a.clone(),
                    }))
                },
                None => acc.clone(),
            }))
        }
    }
}

/// ```prism
/// DefRole: fn [Src], Def -> Text
/// ```
pub fn def_role(srcs: &Array<crate::check::errors::Src>, d: &crate::check::env::Def) -> Text {
    crate::check::errors::seg_at(&or(&index(srcs, &d.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))), &d.span.start).role.clone()
}

/// ```prism
/// LastPathPart: fn Text -> Text
/// ```
pub fn last_path_part(p_: &Text) -> Text {
    or(&crate::syntax::lexer::chars::last(&split(p_, &Text::lit("/"))), p_)
}

/// ```prism
/// IsTestingDef: fn Def -> Bool
/// ```
pub fn is_testing_def(d: &crate::check::env::Def) -> bool {
    match &d.body {
        crate::check::env::DefBody::DbCheck(_) => true,
        crate::check::env::DefBody::DbTest(_) => true,
        _ => false,
    }
}

/// ```prism
/// IsMethodDef: fn Def -> Bool
/// ```
pub fn is_method_def(d: &crate::check::env::Def) -> bool {
    match &d.body {
        crate::check::env::DefBody::DbMethod(_, _, _) => true,
        _ => false,
    }
}
