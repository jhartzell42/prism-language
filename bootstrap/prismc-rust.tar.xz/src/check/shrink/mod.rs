//! The module `Check.Shrink`, from `target/bootstrap/src/prismc/check/shrink/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (docs/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Kid`:
///
/// ```prism
/// type Kid = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Kid {
    KidExpr(crate::syntax::Expr, Map<Text, Rel>),
    KidStmts(Array<crate::syntax::Stmt>, Map<Text, Rel>),
}

impl Show for Kid {
    fn show(&self, p: &mut Printer) {
        match self {
            Kid::KidExpr(a0, a1) => p.choice("KidExpr", &[a0, a1]),
            Kid::KidStmts(a0, a1) => p.choice("KidStmts", &[a0, a1]),
        }
    }
}

impl ToPod for Kid {
    fn to_pod(&self) -> Pod {
        match self {
            Kid::KidExpr(a0, a1) => Pod::Choice("KidExpr".into(), vec![a0.to_pod(), a1.to_pod()]),
            Kid::KidStmts(a0, a1) => Pod::Choice("KidStmts".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Kid {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "KidExpr" && a.len() == 2 => Ok(Kid::KidExpr(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KidStmts" && a.len() == 2 => Ok(Kid::KidStmts(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Kid", other),
        }
    }
}

/// `Rel`:
///
/// ```prism
/// type Rel = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Rel {
    pub param: Nat,
    pub strict: bool,
}

impl Show for Rel {
    fn show(&self, p: &mut Printer) {
        p.record("Rel", &[("param", &self.param), ("strict", &self.strict)]);
    }
}

impl ToPod for Rel {
    fn to_pod(&self) -> Pod {
        Pod::record("Rel", vec![("param", self.param.to_pod()), ("strict", self.strict.to_pod())])
    }
}

impl FromPod for Rel {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Rel { param: FromPod::from_pod(field(p, "param")?)?, strict: FromPod::from_pod(field(p, "strict")?)? })
    }
}

/// `Sc`:
///
/// ```prism
/// type Sc = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Sc {
    pub caller: Text,
    pub callee: Text,
    pub edges: Array<(Nat, Nat, bool)>,
    pub span: crate::syntax::Range,
    pub file: Nat,
    pub arg: Text,
}

impl Show for Sc {
    fn show(&self, p: &mut Printer) {
        p.record("Sc", &[("caller", &self.caller), ("callee", &self.callee), ("edges", &self.edges), ("span", &self.span), ("file", &self.file), ("arg", &self.arg)]);
    }
}

impl ToPod for Sc {
    fn to_pod(&self) -> Pod {
        Pod::record("Sc", vec![("caller", self.caller.to_pod()), ("callee", self.callee.to_pod()), ("edges", self.edges.to_pod()), ("span", self.span.to_pod()), ("file", self.file.to_pod()), ("arg", self.arg.to_pod())])
    }
}

impl FromPod for Sc {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Sc { caller: FromPod::from_pod(field(p, "caller")?)?, callee: FromPod::from_pod(field(p, "callee")?)?, edges: FromPod::from_pod(field(p, "edges")?)?, span: FromPod::from_pod(field(p, "span")?)?, file: FromPod::from_pod(field(p, "file")?)?, arg: FromPod::from_pod(field(p, "arg")?)? })
    }
}

/// `Shrink`:
///
/// ```prism
/// type Shrink = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Shrink {
    pub g: crate::check::env::G,
    pub fns: Array<crate::check::env::Def>,
    pub by_key: Map<Text, crate::check::env::Def>,
    pub targets: Map<Text, Array<Text>>,
    pub impl_defs: Map<Text, Text>,
    pub choices: Map<Text, Array<Text>>,
    pub sums: Map<Text, Nat>,
    pub seeds: Map<Text, Map<Text, Rel>>,
    pub local_of: Map<Text, Text>,
    pub local_base: Map<Text, Map<Text, Rel>>,
}

impl Show for Shrink {
    fn show(&self, p: &mut Printer) {
        p.record("Shrink", &[("g", &self.g), ("fns", &self.fns), ("by_key", &self.by_key), ("targets", &self.targets), ("impl_defs", &self.impl_defs), ("choices", &self.choices), ("sums", &self.sums), ("seeds", &self.seeds), ("local_of", &self.local_of), ("local_base", &self.local_base)]);
    }
}

impl ToPod for Shrink {
    fn to_pod(&self) -> Pod {
        Pod::record("Shrink", vec![("g", self.g.to_pod()), ("fns", self.fns.to_pod()), ("by_key", self.by_key.to_pod()), ("targets", self.targets.to_pod()), ("impl_defs", self.impl_defs.to_pod()), ("choices", self.choices.to_pod()), ("sums", self.sums.to_pod()), ("seeds", self.seeds.to_pod()), ("local_of", self.local_of.to_pod()), ("local_base", self.local_base.to_pod())])
    }
}

impl FromPod for Shrink {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Shrink { g: FromPod::from_pod(field(p, "g")?)?, fns: FromPod::from_pod(field(p, "fns")?)?, by_key: FromPod::from_pod(field(p, "by_key")?)?, targets: FromPod::from_pod(field(p, "targets")?)?, impl_defs: FromPod::from_pod(field(p, "impl_defs")?)?, choices: FromPod::from_pod(field(p, "choices")?)?, sums: FromPod::from_pod(field(p, "sums")?)?, seeds: FromPod::from_pod(field(p, "seeds")?)?, local_of: FromPod::from_pod(field(p, "local_of")?)?, local_base: FromPod::from_pod(field(p, "local_base")?)? })
    }
}

/// `Site`:
///
/// ```prism
/// type Site = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Site {
    pub callee: Text,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
    pub rels: Map<Text, Rel>,
}

impl Show for Site {
    fn show(&self, p: &mut Printer) {
        p.record("Site", &[("callee", &self.callee), ("args", &self.args), ("span", &self.span), ("rels", &self.rels)]);
    }
}

impl ToPod for Site {
    fn to_pod(&self) -> Pod {
        Pod::record("Site", vec![("callee", self.callee.to_pod()), ("args", self.args.to_pod()), ("span", self.span.to_pod()), ("rels", self.rels.to_pod())])
    }
}

impl FromPod for Site {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Site { callee: FromPod::from_pod(field(p, "callee")?)?, args: FromPod::from_pod(field(p, "args")?)?, span: FromPod::from_pod(field(p, "span")?)?, rels: FromPod::from_pod(field(p, "rels")?)? })
    }
}

/// `Slot`:
///
/// ```prism
/// type Slot = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Slot_ {
    pub owner: Text,
    pub at: Nat,
    pub arity: Nat,
}

impl Show for Slot_ {
    fn show(&self, p: &mut Printer) {
        p.record("Slot", &[("owner", &self.owner), ("at", &self.at), ("arity", &self.arity)]);
    }
}

impl ToPod for Slot_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Slot", vec![("owner", self.owner.to_pod()), ("at", self.at.to_pod()), ("arity", self.arity.to_pod())])
    }
}

impl FromPod for Slot_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Slot_ { owner: FromPod::from_pod(field(p, "owner")?)?, at: FromPod::from_pod(field(p, "at")?)?, arity: FromPod::from_pod(field(p, "arity")?)? })
    }
}

/// `Spot`:
///
/// ```prism
/// type Spot = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Spot {
    SpotExpr(crate::syntax::Expr, Map<Text, Rel>),
    SpotStmt(crate::syntax::Stmt, Map<Text, Rel>),
}

impl Show for Spot {
    fn show(&self, p: &mut Printer) {
        match self {
            Spot::SpotExpr(a0, a1) => p.choice("SpotExpr", &[a0, a1]),
            Spot::SpotStmt(a0, a1) => p.choice("SpotStmt", &[a0, a1]),
        }
    }
}

impl ToPod for Spot {
    fn to_pod(&self) -> Pod {
        match self {
            Spot::SpotExpr(a0, a1) => Pod::Choice("SpotExpr".into(), vec![a0.to_pod(), a1.to_pod()]),
            Spot::SpotStmt(a0, a1) => Pod::Choice("SpotStmt".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Spot {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "SpotExpr" && a.len() == 2 => Ok(Spot::SpotExpr(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "SpotStmt" && a.len() == 2 => Ok(Spot::SpotStmt(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Spot", other),
        }
    }
}

/// ```prism
/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
/// ```
pub fn shrink_check(g: &crate::check::env::G, st: &crate::check::types::St, defs: &Array<crate::check::env::Def>) -> (crate::check::types::St, Array<(Text, Array<Text>)>) {
    let fns = each(&filter(defs, &(|d: &crate::check::env::Def| &len(&def_clauses(d)) > &Nat::from(0u32))), &(|d: &crate::check::env::Def| own_key(d)));
    let by_key = fold(&fns, &Map::new(), &(|m: &Map<Text, crate::check::env::Def>, d: &crate::check::env::Def| insert(m, &d.qk, d)));
    let homes = fold(&fns, &Array::new(), &(|acc: &Array<Text>, d: &crate::check::env::Def| crate::check::types::add_text(acc, &d.home)));
    let nats = nat_minus_seeds(st);
    let pre = fold(&homes, &Map::new(), &(|m: &Map<Text, Map<Text, Rel>>, h: &Text| insert(m, h, &fold(&keys(&nats), &prelude_seeds(g, h), &(|m2: &Map<Text, Rel>, k: &Text| insert(m2, k, &no_rel()))))));
    let sk0 = Shrink { g: g.clone(), fns: fns.clone(), by_key: by_key.clone(), targets: method_targets(g, &fns), impl_defs: impl_defs(g, &fns), choices: st.choices.clone(), sums: Map::new(), seeds: pre.clone(), local_of: Map::new(), local_base: Map::new() };
    let sk1 = {
        let mut this: Shrink = sk0.clone();
        this.sums = parts_summaries(&sk0, &fns);
        this
    };
    let skg = {
        let mut this: Shrink = sk1.clone();
        this.seeds = hof_seeds(&sk1, &homes);
        this
    };
    let walked = run_to_end(each_job(fns.clone(), {
        let skg = skg.clone();
        Rc::new(move |p0: crate::check::env::Def| {
            let skg = skg.clone();
            entered(once_job(move || {
                let d = p0;
                prism_rtl::Turn::More(Rc::new(DefWalk { sk: skg.clone(), d: d.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>)>>>
    }));
    let sk = with_locals(&skg, &fold(&walked, &Array::new(), &(|acc: &Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>, (_, _, ls): &(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>)| append(acc, ls))));
    let refs = append(&each(&walked, &(|(k, rs, _): &(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>)| (k.clone(), rs.clone()))), &run_to_end(each_job(drop(&sk.fns, &len(&fns)), {
        let sk = sk.clone();
        Rc::new(move |p0: crate::check::env::Def| {
            let sk = sk.clone();
            entered(once_job(move || {
                let d = p0;
                call_then(start_def_refs(sk.clone(), d.clone()), move |def_refs_3129: Array<Text>| prism_rtl::Turn::Finished((d.qk.clone(), def_refs_3129)))
            }))
        }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>)>>>
    })));
    let keys_ = each(&sk.fns, &(|d: &crate::check::env::Def| d.qk.clone()));
    let sccs_ = sccs(&keys_, &refs);
    let st2 = run_to_end(fold_job(sccs_.clone(), negative_types(g, st), {
        let sk = sk.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, Array<Text>)| {
            let sk = sk.clone();
            entered(once_job(move || {
                let s = p0;
                let comp = p1;
                prism_rtl::Turn::More(Rc::new(ShrinkComponent { sk: sk.clone(), st: s.clone(), comp: comp.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, Array<Text>)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    let st3 = run_to_end(fold_job(fns.clone(), st2.clone(), {
        let sk = sk.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::Def)| {
            let sk = sk.clone();
            entered(once_job(move || {
                let s = p0;
                let d = p1;
                prism_rtl::Turn::More(Rc::new(LoopsOf { sk: sk.clone(), st: s.clone(), d: d.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    (st3.clone(), refs.clone())
}

/// The step machine of `ShrinkCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
/// ```
pub struct ShrinkCheck {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub defs: Array<crate::check::env::Def>,
}

impl prism_rtl::Job<(crate::check::types::St, Array<(Text, Array<Text>)>)> for ShrinkCheck {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::St, Array<(Text, Array<Text>)>)> {
        let g = &self.g;
        let st = &self.st;
        let defs = &self.defs;
        let fns = each(&filter(defs, &(|d: &crate::check::env::Def| &len(&def_clauses(d)) > &Nat::from(0u32))), &(|d: &crate::check::env::Def| own_key(d)));
        let by_key = fold(&fns, &Map::new(), &(|m: &Map<Text, crate::check::env::Def>, d: &crate::check::env::Def| insert(m, &d.qk, d)));
        let homes = fold(&fns, &Array::new(), &(|acc: &Array<Text>, d: &crate::check::env::Def| crate::check::types::add_text(acc, &d.home)));
        let g = g.clone();
        let st = st.clone();
        call_then(start_nat_minus_seeds(st.clone()), move |nat_minus_seeds_2424: Map<Text, Rel>| {
            let nats = nat_minus_seeds_2424;
            let pre = fold(&homes, &Map::new(), &(|m: &Map<Text, Map<Text, Rel>>, h: &Text| insert(m, h, &fold(&keys(&nats), &prelude_seeds(&g, h), &(|m2: &Map<Text, Rel>, k: &Text| insert(m2, k, &no_rel()))))));
            let sk0 = Shrink { g: g.clone(), fns: fns.clone(), by_key: by_key.clone(), targets: method_targets(&g, &fns), impl_defs: impl_defs(&g, &fns), choices: st.choices.clone(), sums: Map::new(), seeds: pre.clone(), local_of: Map::new(), local_base: Map::new() };
            let sk1 = {
                let mut this: Shrink = sk0.clone();
                this.sums = parts_summaries(&sk0, &fns);
                this
            };
            let skg = {
                let mut this: Shrink = sk1.clone();
                this.seeds = hof_seeds(&sk1, &homes);
                this
            };
            call_value(each_job(fns.clone(), {
                let skg = skg.clone();
                Rc::new(move |p0: crate::check::env::Def| {
                    let skg = skg.clone();
                    entered(once_job(move || {
                        let d = p0;
                        prism_rtl::Turn::More(Rc::new(DefWalk { sk: skg.clone(), d: d.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>)>>>
            }), move |each_2888: Array<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>)>| {
                let walked = each_2888;
                call_then(start_with_locals(skg.clone(), fold(&walked, &Array::new(), &(|acc: &Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>, (_, _, ls): &(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>)| append(acc, ls)))), move |with_locals_2931: Shrink| {
                    let sk = with_locals_2931;
                    call_value(each_job(drop(&sk.fns, &len(&fns)), {
                        let sk = sk.clone();
                        Rc::new(move |p0: crate::check::env::Def| {
                            let sk = sk.clone();
                            entered(once_job(move || {
                                let d = p0;
                                call_then(start_def_refs(sk.clone(), d.clone()), move |def_refs_3129: Array<Text>| prism_rtl::Turn::Finished((d.qk.clone(), def_refs_3129)))
                            }))
                        }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>)>>>
                    }), move |each_3084: Array<(Text, Array<Text>)>| {
                        let refs = append(&each(&walked, &(|(k, rs, _): &(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>)| (k.clone(), rs.clone()))), &each_3084);
                        let keys_ = each(&sk.fns, &(|d: &crate::check::env::Def| d.qk.clone()));
                        call_then(start_sccs(keys_.clone(), refs.clone()), move |sccs_3200: Array<Array<Text>>| {
                            let sccs_ = sccs_3200;
                            call_then(start_negative_types(g.clone(), st.clone()), move |negative_types_3242: crate::check::types::St| call_value(fold_job(sccs_.clone(), negative_types_3242, {
                                let sk = sk.clone();
                                Rc::new(move |(p0, p1): (crate::check::types::St, Array<Text>)| {
                                    let sk = sk.clone();
                                    entered(once_job(move || {
                                        let s = p0;
                                        let comp = p1;
                                        prism_rtl::Turn::More(Rc::new(ShrinkComponent { sk: sk.clone(), st: s.clone(), comp: comp.clone() }))
                                    }))
                                }) as Rc<dyn Fn((crate::check::types::St, Array<Text>)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            }), move |fold_3230: crate::check::types::St| {
                                let st2 = fold_3230;
                                call_value(fold_job(fns.clone(), st2.clone(), {
                                    let sk = sk.clone();
                                    Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::env::Def)| {
                                        let sk = sk.clone();
                                        entered(once_job(move || {
                                            let s = p0;
                                            let d = p1;
                                            prism_rtl::Turn::More(Rc::new(LoopsOf { sk: sk.clone(), st: s.clone(), d: d.clone() }))
                                        }))
                                    }) as Rc<dyn Fn((crate::check::types::St, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                                }), move |fold_3317: crate::check::types::St| {
                                    let st3 = fold_3317;
                                    prism_rtl::Turn::Finished((st3.clone(), refs.clone()))
                                })
                            }))
                        })
                    })
                })
            })
        })
    }
}

/// `Start ShrinkCheck, x`: what the function value is when passed to `@Run`.
pub fn start_shrink_check(g: crate::check::env::G, st: crate::check::types::St, defs: Array<crate::check::env::Def>) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, Array<(Text, Array<Text>)>)>> {
    Rc::new(ShrinkCheck { g, st, defs })
}

/// ```prism
/// UnusedDefs: unbounded fn [Def], [((Text, [Text]))], Nat -> [CDiag]
/// ```
pub fn unused_defs(defs: &Array<crate::check::env::Def>, refs: &Array<(Text, Array<Text>)>, shown: &Nat) -> Array<crate::check::errors::CDiag> {
    let used0 = fold(refs, &Map::new(), &(|m: &Map<Text, ()>, (k, rs): &(Text, Array<Text>)| fold(rs, m, &(|m2: &Map<Text, ()>, r: &Text| if r == k { m2.clone() } else { insert(m2, r, &()) }))));
    let used = run_to_end(fold_job(defs.clone(), used0.clone(), Rc::new(move |(p0, p1): (Map<Text, ()>, crate::check::env::Def)| entered(once_job(move || {
        let m = p0;
        let d = p1;
        match &d.body {
            crate::check::env::DefBody::DbCheck(c) => fold_job(c.lines.clone(), m.clone(), {
                let d = d.clone();
                Rc::new(move |(p0, p1): (Map<Text, ()>, crate::syntax::CheckLine)| {
                    let d = d.clone();
                    entered(once_job(move || {
                        let m2 = p0;
                        let l = p1;
                        call_then(crate::check::typed::start_exprs_in(l.expr.clone()), move |exprs_in_4050: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(fold(&exprs_in_4050, &m2, &(|m3: &Map<Text, ()>, e: &crate::syntax::Expr| match &*e.kind {
                            crate::syntax::ExprKind::EName(n) => insert(&insert(m3, &crate::check::env::sname_key(n), &()), &crate::check::env::qual_key(&d.home, &crate::check::env::sname_key(n)), &()),
                            _ => m3.clone(),
                        }))))
                    }))
                }) as Rc<dyn Fn((Map<Text, ()>, crate::syntax::CheckLine)) -> Rc<dyn prism_rtl::Job<Map<Text, ()>>>>
            }).cycle(),
            _ => prism_rtl::Turn::Finished(m.clone()),
        }
    }))) as Rc<dyn Fn((Map<Text, ()>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Map<Text, ()>>>>));
    let own = filter(defs, &(|d: &crate::check::env::Def| ((((&d.file < shown) && !crate::check::env::has_key(&used, &d.qk)) && (&d.name != &Text::lit("@main"))) && !is_method_def(d)) && !is_testing_def(d)));
    each(&own, &(|d: &crate::check::env::Def| crate::check::errors::CDiag { code: Text::lit("unused"), file: d.file.clone(), span: d.span.clone(), message: Text::from(format!("nothing uses `{}`", &d.name)), fix: Text::lit("delete it, or use it") }))
}

/// The step machine of `UnusedDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnusedDefs: unbounded fn [Def], [((Text, [Text]))], Nat -> [CDiag]
/// ```
pub struct UnusedDefs {
    pub defs: Array<crate::check::env::Def>,
    pub refs: Array<(Text, Array<Text>)>,
    pub shown: Nat,
}

impl prism_rtl::Job<Array<crate::check::errors::CDiag>> for UnusedDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::errors::CDiag>> {
        let defs = &self.defs;
        let refs = &self.refs;
        let shown = &self.shown;
        let used0 = fold(refs, &Map::new(), &(|m: &Map<Text, ()>, (k, rs): &(Text, Array<Text>)| fold(rs, m, &(|m2: &Map<Text, ()>, r: &Text| if r == k { m2.clone() } else { insert(m2, r, &()) }))));
        let defs = defs.clone();
        let shown = shown.clone();
        call_value(fold_job(defs.clone(), used0.clone(), Rc::new(move |(p0, p1): (Map<Text, ()>, crate::check::env::Def)| entered(once_job(move || {
            let m = p0;
            let d = p1;
            match &d.body {
                crate::check::env::DefBody::DbCheck(c) => fold_job(c.lines.clone(), m.clone(), {
                    let d = d.clone();
                    Rc::new(move |(p0, p1): (Map<Text, ()>, crate::syntax::CheckLine)| {
                        let d = d.clone();
                        entered(once_job(move || {
                            let m2 = p0;
                            let l = p1;
                            call_then(crate::check::typed::start_exprs_in(l.expr.clone()), move |exprs_in_4050: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(fold(&exprs_in_4050, &m2, &(|m3: &Map<Text, ()>, e: &crate::syntax::Expr| match &*e.kind {
                                crate::syntax::ExprKind::EName(n) => insert(&insert(m3, &crate::check::env::sname_key(n), &()), &crate::check::env::qual_key(&d.home, &crate::check::env::sname_key(n)), &()),
                                _ => m3.clone(),
                            }))))
                        }))
                    }) as Rc<dyn Fn((Map<Text, ()>, crate::syntax::CheckLine)) -> Rc<dyn prism_rtl::Job<Map<Text, ()>>>>
                }).cycle(),
                _ => prism_rtl::Turn::Finished(m.clone()),
            }
        }))) as Rc<dyn Fn((Map<Text, ()>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Map<Text, ()>>>>), move |fold_3959: Map<Text, ()>| {
            let used = fold_3959;
            let own = filter(&defs, &(|d: &crate::check::env::Def| ((((&d.file < &shown) && !crate::check::env::has_key(&used, &d.qk)) && (&d.name != &Text::lit("@main"))) && !is_method_def(d)) && !is_testing_def(d)));
            prism_rtl::Turn::Finished(each(&own, &(|d: &crate::check::env::Def| crate::check::errors::CDiag { code: Text::lit("unused"), file: d.file.clone(), span: d.span.clone(), message: Text::from(format!("nothing uses `{}`", &d.name)), fix: Text::lit("delete it, or use it") })))
        })
    }
}

/// `Start UnusedDefs, x`: what the function value is when passed to `@Run`.
pub fn start_unused_defs(defs: Array<crate::check::env::Def>, refs: Array<(Text, Array<Text>)>, shown: Nat) -> Rc<dyn prism_rtl::Job<Array<crate::check::errors::CDiag>>> {
    Rc::new(UnusedDefs { defs, refs, shown })
}

/// ```prism
/// TestOnlyReached: fn [Src], [Def], [((Text, [Text]))] -> [CDiag]
/// ```
pub fn test_only_reached(srcs: &Array<crate::check::errors::Src>, defs: &Array<crate::check::env::Def>, refs: &Array<(Text, Array<Text>)>) -> Array<crate::check::errors::CDiag> {
    let in_test = fold(defs, &Map::new(), &(|m: &Map<Text, crate::check::env::Def>, d: &crate::check::env::Def| if &def_role(srcs, d) == &Text::lit("test") { insert(m, &d.qk, d) } else { m.clone() }));
    if &size(&in_test) == &Nat::from(0u32) {
        Array::new()
    } else {
        {
            let by_key = fold(defs, &Map::new(), &(|m: &Map<Text, crate::check::env::Def>, d: &crate::check::env::Def| insert(m, &d.qk, d)));
            fold(refs, &Array::new(), &(|acc: &Array<crate::check::errors::CDiag>, (k, rs): &(Text, Array<Text>)| match get(&by_key, k) {
                Some(d) => if &def_role(srcs, &d) == &Text::lit("test") {
                    acc.clone()
                } else {
                    fold(rs, acc, &(|a: &Array<crate::check::errors::CDiag>, r: &Text| match get(&in_test, r) {
                        Some(t) => push(a, &crate::check::errors::CDiag { code: Text::lit("test-only-reached"), file: d.file.clone(), span: d.span.clone(), message: Text::from(format!("`{}` names `{}`, which a test module declares ({}): only test modules name it", &d.name, &t.name, &last_path_part(&crate::check::errors::seg_at(&or(&index(srcs, &t.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))), &t.span.start).path_))), fix: Text::from(format!("move `{}` out of the test module, or `{}` into one", &t.name, &d.name)) }),
                        None => a.clone(),
                    }))
                },
                None => acc.clone(),
            }))
        }
    }
}

/// ```prism
/// DefRole: fn [Src], Def -> Text
/// ```
pub fn def_role(srcs: &Array<crate::check::errors::Src>, d: &crate::check::env::Def) -> Text {
    crate::check::errors::seg_at(&or(&index(srcs, &d.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))), &d.span.start).role.clone()
}

/// ```prism
/// LastPathPart: fn Text -> Text
/// ```
pub fn last_path_part(p_: &Text) -> Text {
    or(&crate::syntax::lexer::last(&split(p_, &Text::lit("/"))), p_)
}

/// ```prism
/// IsTestingDef: fn Def -> Bool
/// ```
pub fn is_testing_def(d: &crate::check::env::Def) -> bool {
    match &d.body {
        crate::check::env::DefBody::DbCheck(_) => true,
        crate::check::env::DefBody::DbTest(_) => true,
        _ => false,
    }
}

/// ```prism
/// IsMethodDef: fn Def -> Bool
/// ```
pub fn is_method_def(d: &crate::check::env::Def) -> bool {
    match &d.body {
        crate::check::env::DefBody::DbMethod(_, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// NegativeTypes: unbounded fn G, St -> St
/// ```
pub fn negative_types(g: &crate::check::env::G, st: &crate::check::types::St) -> crate::check::types::St {
    let arrowy = arrowy_types(g);
    run_to_end(fold_job(keys(&g.types), st.clone(), {
        let g = g.clone();
        let arrowy = arrowy.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
            let g = g.clone();
            let arrowy = arrowy.clone();
            entered(once_job(move || {
                let s = p0;
                let n = p1;
                prism_rtl::Turn::More(Rc::new(NegativeType { g: g.clone(), s: s.clone(), arrowy: arrowy.clone(), n: n.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `NegativeTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegativeTypes: unbounded fn G, St -> St
/// ```
pub struct NegativeTypes {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for NegativeTypes {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let g = g.clone();
        let st = st.clone();
        call_then(start_arrowy_types(g.clone()), move |arrowy_types_7121: Map<Text, bool>| {
            let arrowy = arrowy_types_7121;
            fold_job(keys(&g.types), st.clone(), {
                let g = g.clone();
                let arrowy = arrowy.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
                    let g = g.clone();
                    let arrowy = arrowy.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let n = p1;
                        prism_rtl::Turn::More(Rc::new(NegativeType { g: g.clone(), s: s.clone(), arrowy: arrowy.clone(), n: n.clone() }))
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }).cycle()
        })
    }
}

/// `Start NegativeTypes, x`: what the function value is when passed to `@Run`.
pub fn start_negative_types(g: crate::check::env::G, st: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(NegativeTypes { g, st })
}

/// ```prism
/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
/// ```
pub fn negative_type(g: &crate::check::env::G, s: &crate::check::types::St, arrowy: &Map<Text, bool>, n: &Text) -> crate::check::types::St {
    match get(&g.types, n) {
        Some(ti) => {
            let (neg, _) = if (&ti.file >= &g.prelude_from) || !crate::check::env::has_key(arrowy, n) {
                (false, Map::new())
            } else {
                neg_walks(g, n, &body_tys(&ti), &false, &Map::new())
            };
            if !neg {
                s.clone()
            } else {
                {
                    let s0 = {
                        let mut this: crate::check::types::St = s.clone();
                        this.file = ti.file.clone();
                        this
                    };
                    let s1 = crate::check::types::err_fix(&s0, &Text::lit("may-not-end"), &ti.span, &Text::from(format!("`{}` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks", &crate::check::types::bare_name(n))), &Text::from(format!("keep `{}` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded", &crate::check::types::bare_name(n))));
                    {
                        let mut this: crate::check::types::St = s1.clone();
                        this.file = s.file.clone();
                        this
                    }
                }
            }
        },
        None => s.clone(),
    }
}

/// The step machine of `NegativeType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
/// ```
pub struct NegativeType {
    pub g: crate::check::env::G,
    pub s: crate::check::types::St,
    pub arrowy: Map<Text, bool>,
    pub n: Text,
}

impl prism_rtl::Job<crate::check::types::St> for NegativeType {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let s = &self.s;
        let arrowy = &self.arrowy;
        let n = &self.n;
        match get(&g.types, n) {
            Some(ti) => {
                let (neg, _) = if (&ti.file >= &g.prelude_from) || !crate::check::env::has_key(arrowy, n) {
                    (false, Map::new())
                } else {
                    neg_walks(g, n, &body_tys(&ti), &false, &Map::new())
                };
                if !neg {
                    prism_rtl::Turn::Finished(s.clone())
                } else {
                    {
                        let s0 = {
                            let mut this: crate::check::types::St = s.clone();
                            this.file = ti.file.clone();
                            this
                        };
                        let s1 = crate::check::types::err_fix(&s0, &Text::lit("may-not-end"), &ti.span, &Text::from(format!("`{}` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks", &crate::check::types::bare_name(n))), &Text::from(format!("keep `{}` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded", &crate::check::types::bare_name(n))));
                        prism_rtl::Turn::Finished({
                            let mut this: crate::check::types::St = s1.clone();
                            this.file = s.file.clone();
                            this
                        })
                    }
                }
            },
            None => prism_rtl::Turn::Finished(s.clone()),
        }
    }
}

/// `Start NegativeType, x`: what the function value is when passed to `@Run`.
pub fn start_negative_type(g: crate::check::env::G, s: crate::check::types::St, arrowy: Map<Text, bool>, n: Text) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(NegativeType { g, s, arrowy, n })
}

/// ```prism
/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
/// ```
pub fn arrowy_types(g: &crate::check::env::G) -> Map<Text, bool> {
    let names = run_to_end(fold_job(keys(&g.types), Map::new(), {
        let g = g.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
            let g = g.clone();
            entered(once_job(move || {
                let m = p0;
                let n = p1;
                match get(&g.types, &n) {
                    Some(ti) => call_value(fold_job(body_tys(&ti), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                        let acc = p0;
                        let t = p1;
                        call_then(start_ty_names_in(t.clone()), move |ty_names_in_8417: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_8417)))
                    }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_8365: Array<Text>| prism_rtl::Turn::Finished(insert(&m, &n, &fold_8365))),
                    None => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
    }));
    let direct = run_to_end(fold_job(keys(&g.types), Map::new(), {
        let g = g.clone();
        Rc::new(move |(p0, p1): (Map<Text, bool>, Text)| {
            let g = g.clone();
            entered(once_job(move || {
                let m = p0;
                let n = p1;
                match get(&g.types, &n) {
                    Some(ti) => call_value(fold_job(body_tys(&ti), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| entered(once_job(move || {
                        let seen = p0;
                        let t = p1;
                        prism_rtl::Turn::Finished(seen || has_arrow(&t))
                    }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_8531: bool| if fold_8531 {
                        prism_rtl::Turn::Finished(insert(&m, &n, &true))
                    } else {
                        prism_rtl::Turn::Finished(m.clone())
                    }),
                    None => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, bool>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>>>
    }));
    arrowy_from(&names, &direct)
}

/// The step machine of `ArrowyTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
/// ```
pub struct ArrowyTypes {
    pub g: crate::check::env::G,
}

impl prism_rtl::Job<Map<Text, bool>> for ArrowyTypes {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, bool>> {
        let g = &self.g;
        let g = g.clone();
        call_value(fold_job(keys(&g.types), Map::new(), {
            let g = g.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                let g = g.clone();
                entered(once_job(move || {
                    let m = p0;
                    let n = p1;
                    match get(&g.types, &n) {
                        Some(ti) => call_value(fold_job(body_tys(&ti), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                            let acc = p0;
                            let t = p1;
                            call_then(start_ty_names_in(t.clone()), move |ty_names_in_8417: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_8417)))
                        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_8365: Array<Text>| prism_rtl::Turn::Finished(insert(&m, &n, &fold_8365))),
                        None => prism_rtl::Turn::Finished(m.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        }), move |fold_8286: Map<Text, Array<Text>>| {
            let names = fold_8286;
            call_value(fold_job(keys(&g.types), Map::new(), {
                let g = g.clone();
                Rc::new(move |(p0, p1): (Map<Text, bool>, Text)| {
                    let g = g.clone();
                    entered(once_job(move || {
                        let m = p0;
                        let n = p1;
                        match get(&g.types, &n) {
                            Some(ti) => call_value(fold_job(body_tys(&ti), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| entered(once_job(move || {
                                let seen = p0;
                                let t = p1;
                                prism_rtl::Turn::Finished(seen || has_arrow(&t))
                            }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_8531: bool| if fold_8531 {
                                prism_rtl::Turn::Finished(insert(&m, &n, &true))
                            } else {
                                prism_rtl::Turn::Finished(m.clone())
                            }),
                            None => prism_rtl::Turn::Finished(m.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((Map<Text, bool>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>>>
            }), move |fold_8463: Map<Text, bool>| {
                let direct = fold_8463;
                prism_rtl::Turn::More(Rc::new(ArrowyFrom { names: names.clone(), got: direct.clone() }))
            })
        })
    }
}

/// `Start ArrowyTypes, x`: what the function value is when passed to `@Run`.
pub fn start_arrowy_types(g: crate::check::env::G) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>> {
    Rc::new(ArrowyTypes { g })
}

/// ```prism
/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
/// ```
pub fn arrowy_from(names: &Map<Text, Array<Text>>, got: &Map<Text, bool>) -> Map<Text, bool> {
    let next = fold(&keys(names), got, &(|m: &Map<Text, bool>, n: &Text| if crate::check::env::has_key(m, n) {
        m.clone()
    } else {
        if fold(&or(&get(names, n), &Array::new()), &false, &(|seen: &bool, r: &Text| *seen || crate::check::env::has_key(got, r))) {
            insert(m, n, &true)
        } else {
            m.clone()
        }
    }));
    if &len(&keys(&next)) == &len(&keys(got)) {
        got.clone()
    } else {
        arrowy_from(names, &next)
    }
}

/// The step machine of `ArrowyFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
/// ```
pub struct ArrowyFrom {
    pub names: Map<Text, Array<Text>>,
    pub got: Map<Text, bool>,
}

impl prism_rtl::Job<Map<Text, bool>> for ArrowyFrom {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, bool>> {
        let names = &self.names;
        let got = &self.got;
        let next = fold(&keys(names), got, &(|m: &Map<Text, bool>, n: &Text| if crate::check::env::has_key(m, n) {
            m.clone()
        } else {
            if fold(&or(&get(names, n), &Array::new()), &false, &(|seen: &bool, r: &Text| *seen || crate::check::env::has_key(got, r))) {
                insert(m, n, &true)
            } else {
                m.clone()
            }
        }));
        if &len(&keys(&next)) == &len(&keys(got)) {
            prism_rtl::Turn::Finished(got.clone())
        } else {
            prism_rtl::Turn::More(Rc::new(ArrowyFrom { names: names.clone(), got: next.clone() }))
        }
    }
}

/// `Start ArrowyFrom, x`: what the function value is when passed to `@Run`.
pub fn start_arrowy_from(names: Map<Text, Array<Text>>, got: Map<Text, bool>) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>> {
    Rc::new(ArrowyFrom { names, got })
}

/// ```prism
/// TyNamesIn: unbounded fn Ty -> [Text]
/// ```
pub fn ty_names_in(t: &crate::check::types::Ty) -> Array<Text> {
    match t {
        crate::check::types::Ty::TyCon(c, args) => run_to_end(fold_job(args.clone(), Array::from(vec![c.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_ty_names_in(a.clone()), move |ty_names_in_9213: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_9213)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyFn(_, ps, res) => run_to_end(fold_job(ps.clone(), ty_names_in(&**res), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_ty_names_in(a.clone()), move |ty_names_in_9305: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_9305)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_ty_names_in(a.clone()), move |ty_names_in_9376: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_9376)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyArray(e) => ty_names_in(&**e),
        crate::check::types::Ty::TyMap(k, v_) => crate::check::types::union_texts(&ty_names_in(&**k), &ty_names_in(&**v_)),
        crate::check::types::Ty::TySig(_, i) => ty_names_in(&**i),
        crate::check::types::Ty::TyAt(i, _) => ty_names_in(&**i),
        crate::check::types::Ty::TyElem(_, i) => ty_names_in(&**i),
        crate::check::types::Ty::TyAssoc(_, i) => ty_names_in(&**i),
        _ => Array::new(),
    }
}

/// The step machine of `TyNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyNamesIn: unbounded fn Ty -> [Text]
/// ```
pub struct TyNamesIn {
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Text>> for TyNamesIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyCon(c, args) => fold_job(args.clone(), Array::from(vec![c.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_ty_names_in(a.clone()), move |ty_names_in_9213: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_9213)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyFn(_, ps, res) => {
                let ps = ps.clone();
                let res = (**res).clone();
                call_then(start_ty_names_in(res.clone()), move |ty_names_in_9262: Array<Text>| fold_job(ps.clone(), ty_names_in_9262, Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_ty_names_in(a.clone()), move |ty_names_in_9305: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_9305)))
                }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_ty_names_in(a.clone()), move |ty_names_in_9376: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_9376)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**e).clone() })),
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_ty_names_in(k.clone()), move |ty_names_in_9444: Array<Text>| call_then(start_ty_names_in(v_.clone()), move |ty_names_in_9459: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&ty_names_in_9444, &ty_names_in_9459))))
            },
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**i).clone() })),
            crate::check::types::Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**i).clone() })),
            crate::check::types::Ty::TyElem(_, i) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**i).clone() })),
            crate::check::types::Ty::TyAssoc(_, i) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**i).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start TyNamesIn, x`: what the function value is when passed to `@Run`.
pub fn start_ty_names_in(t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TyNamesIn { t })
}

/// ```prism
/// HasArrow: unbounded fn Ty -> Bool
/// ```
pub fn has_arrow(t: &crate::check::types::Ty) -> bool {
    match t {
        crate::check::types::Ty::TyFn(_, _, _) => true,
        crate::check::types::Ty::TyCon(_, args) => run_to_end(fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || has_arrow(&a))
        }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || has_arrow(&a))
        }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::check::types::Ty::TyArray(e) => has_arrow(&**e),
        crate::check::types::Ty::TyMap(k, v_) => has_arrow(&**k) || has_arrow(&**v_),
        crate::check::types::Ty::TySig(_, i) => has_arrow(&**i),
        crate::check::types::Ty::TyAt(i, _) => has_arrow(&**i),
        crate::check::types::Ty::TyElem(_, i) => has_arrow(&**i),
        crate::check::types::Ty::TyAssoc(_, i) => has_arrow(&**i),
        _ => false,
    }
}

/// The step machine of `HasArrow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HasArrow: unbounded fn Ty -> Bool
/// ```
pub struct HasArrow {
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for HasArrow {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::Finished(true),
            crate::check::types::Ty::TyCon(_, args) => fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| entered(once_job(move || {
                let seen = p0;
                let a = p1;
                prism_rtl::Turn::Finished(seen || has_arrow(&a))
            }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| entered(once_job(move || {
                let seen = p0;
                let a = p1;
                prism_rtl::Turn::Finished(seen || has_arrow(&a))
            }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**e).clone() })),
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_has_arrow(k.clone()), move |has_arrow_9901: bool| prism_rtl::Turn::Finished(has_arrow_9901 || has_arrow(&v_)))
            },
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**i).clone() })),
            crate::check::types::Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**i).clone() })),
            crate::check::types::Ty::TyElem(_, i) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**i).clone() })),
            crate::check::types::Ty::TyAssoc(_, i) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**i).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start HasArrow, x`: what the function value is when passed to `@Run`.
pub fn start_has_arrow(t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HasArrow { t })
}

/// ```prism
/// BodyTys: fn TyInfo -> [Ty]
/// ```
pub fn body_tys(ti: &crate::check::env::TyInfo) -> Array<crate::check::types::Ty> {
    match &ti.body {
        crate::check::env::TyBody::BRecord(fields) => each(fields, &(|(_, t): &(Text, crate::check::types::Ty)| t.clone())),
        crate::check::env::TyBody::BChoice(cases) => fold(cases, &Array::new(), &(|acc: &Array<crate::check::types::Ty>, (_, args): &(Text, Array<crate::check::types::Ty>)| append(acc, args))),
        crate::check::env::TyBody::BAlias(t) => Array::from(vec![t.clone()]),
        _ => Array::new(),
    }
}

/// ```prism
/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub fn neg_walk(g: &crate::check::env::G, target: &Text, t: &crate::check::types::Ty, b: &bool, seen: &Map<Text, bool>) -> (bool, Map<Text, bool>) {
    match t {
        crate::check::types::Ty::TyCon(c, args) => if c == target {
            (*b, seen.clone())
        } else {
            match get(&g.types, c) {
                Some(ti) => {
                    let sk = Text::from(format!("{}{}", &(if *b { Text::lit("-") } else { Text::lit("+") }), &crate::check::types::show_ty(&crate::check::types::new_st(&Nat::from(0u32)), t)));
                    if crate::check::env::has_key(seen, &sk) {
                        (false, seen.clone())
                    } else {
                        if &len(&keys(seen)) > &Nat::from(400u32) {
                            (true, seen.clone())
                        } else {
                            neg_walks(g, target, &run_to_end(each_job(body_tys(&ti), {
                                let ti = ti.clone();
                                let args = args.clone();
                                Rc::new(move |p0: crate::check::types::Ty| {
                                    let ti = ti.clone();
                                    let args = args.clone();
                                    entered(once_job(move || {
                                        let bt = p0;
                                        prism_rtl::Turn::More(Rc::new(crate::check::types::SubstQ { m: crate::check::env::param_inst(&ti.params, &args), t: bt.clone() }))
                                    }))
                                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                            })), b, &insert(seen, &sk, &true))
                        }
                    }
                },
                None => neg_walks(g, target, args, b, seen),
            }
        },
        crate::check::types::Ty::TyFn(col, ps, res) => {
            let (bad, seen2) = neg_walks(g, target, ps, &(*b || (col != &crate::check::types::Col::CUnbound)), seen);
            if bad { (true, seen2.clone()) } else { neg_walk(g, target, &**res, b, &seen2) }
        },
        crate::check::types::Ty::TyTuple(ts) => neg_walks(g, target, ts, b, seen),
        crate::check::types::Ty::TyArray(e) => neg_walk(g, target, &**e, b, seen),
        crate::check::types::Ty::TyMap(k, v_) => neg_walks(g, target, &Array::from(vec![(**k).clone(), (**v_).clone()]), b, seen),
        crate::check::types::Ty::TySig(_, i) => neg_walk(g, target, &**i, b, seen),
        crate::check::types::Ty::TyAt(i, _) => neg_walk(g, target, &**i, b, seen),
        crate::check::types::Ty::TyElem(_, i) => neg_walk(g, target, &**i, b, seen),
        crate::check::types::Ty::TyAssoc(_, i) => neg_walk(g, target, &**i, b, seen),
        _ => (false, seen.clone()),
    }
}

/// The step machine of `NegWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub struct NegWalk {
    pub g: crate::check::env::G,
    pub target: Text,
    pub t: crate::check::types::Ty,
    pub b: bool,
    pub seen: Map<Text, bool>,
}

impl prism_rtl::Job<(bool, Map<Text, bool>)> for NegWalk {
    fn cycle(&self) -> prism_rtl::Turn<(bool, Map<Text, bool>)> {
        let g = &self.g;
        let target = &self.target;
        let t = &self.t;
        let b = &self.b;
        let seen = &self.seen;
        match t {
            crate::check::types::Ty::TyCon(c, args) => if c == target {
                prism_rtl::Turn::Finished((*b, seen.clone()))
            } else {
                match get(&g.types, c) {
                    Some(ti) => {
                        let args = args.clone();
                        let b = *b;
                        let g = g.clone();
                        let seen = seen.clone();
                        let t = t.clone();
                        let target = target.clone();
                        call_then(crate::check::types::start_show_ty(crate::check::types::new_st(&Nat::from(0u32)), t.clone()), move |show_ty_11038: Text| {
                            let sk = Text::from(format!("{}{}", &(if b { Text::lit("-") } else { Text::lit("+") }), &show_ty_11038));
                            if crate::check::env::has_key(&seen, &sk) {
                                prism_rtl::Turn::Finished((false, seen.clone()))
                            } else {
                                if &len(&keys(&seen)) > &Nat::from(400u32) {
                                    prism_rtl::Turn::Finished((true, seen.clone()))
                                } else {
                                    call_value(each_job(body_tys(&ti), {
                                        let ti = ti.clone();
                                        let args = args.clone();
                                        Rc::new(move |p0: crate::check::types::Ty| {
                                            let ti = ti.clone();
                                            let args = args.clone();
                                            entered(once_job(move || {
                                                let bt = p0;
                                                prism_rtl::Turn::More(Rc::new(crate::check::types::SubstQ { m: crate::check::env::param_inst(&ti.params, &args), t: bt.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                                    }), move |each_11220: Array<crate::check::types::Ty>| prism_rtl::Turn::More(Rc::new(NegWalks { g: g.clone(), target: target.clone(), ts: each_11220, b, seen: insert(&seen, &sk, &true) })))
                                }
                            }
                        })
                    },
                    None => prism_rtl::Turn::More(Rc::new(NegWalks { g: g.clone(), target: target.clone(), ts: args.clone(), b: *b, seen: seen.clone() })),
                }
            },
            crate::check::types::Ty::TyFn(col, ps, res) => {
                let b = *b;
                let col = col.clone();
                let g = g.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                let seen = seen.clone();
                let target = target.clone();
                call_then(start_neg_walks(g.clone(), target.clone(), ps.clone(), b || (&col != &crate::check::types::Col::CUnbound), seen.clone()), move |neg_walks_11416: (bool, Map<Text, bool>)| {
                    let (bad, seen2) = neg_walks_11416;
                    if bad {
                        prism_rtl::Turn::Finished((true, seen2.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: res.clone(), b, seen: seen2.clone() }))
                    }
                })
            },
            crate::check::types::Ty::TyTuple(ts) => prism_rtl::Turn::More(Rc::new(NegWalks { g: g.clone(), target: target.clone(), ts: ts.clone(), b: *b, seen: seen.clone() })),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**e).clone(), b: *b, seen: seen.clone() })),
            crate::check::types::Ty::TyMap(k, v_) => prism_rtl::Turn::More(Rc::new(NegWalks { g: g.clone(), target: target.clone(), ts: Array::from(vec![(**k).clone(), (**v_).clone()]), b: *b, seen: seen.clone() })),
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**i).clone(), b: *b, seen: seen.clone() })),
            crate::check::types::Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**i).clone(), b: *b, seen: seen.clone() })),
            crate::check::types::Ty::TyElem(_, i) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**i).clone(), b: *b, seen: seen.clone() })),
            crate::check::types::Ty::TyAssoc(_, i) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**i).clone(), b: *b, seen: seen.clone() })),
            _ => prism_rtl::Turn::Finished((false, seen.clone())),
        }
    }
}

/// `Start NegWalk, x`: what the function value is when passed to `@Run`.
pub fn start_neg_walk(g: crate::check::env::G, target: Text, t: crate::check::types::Ty, b: bool, seen: Map<Text, bool>) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>> {
    Rc::new(NegWalk { g, target, t, b, seen })
}

/// ```prism
/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub fn neg_walks(g: &crate::check::env::G, target: &Text, ts: &Array<crate::check::types::Ty>, b: &bool, seen: &Map<Text, bool>) -> (bool, Map<Text, bool>) {
    run_to_end(fold_job(ts.clone(), (false, seen.clone()), {
        let g = g.clone();
        let target = target.clone();
        let b = *b;
        Rc::new(move |(p0, p1): ((bool, Map<Text, bool>), crate::check::types::Ty)| {
            let g = g.clone();
            let target = target.clone();
            let b = b;
            entered(once_job(move || {
                let (bad, sn) = p0;
                let t = p1;
                if bad {
                    prism_rtl::Turn::Finished((true, sn.clone()))
                } else {
                    prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: t.clone(), b, seen: sn.clone() }))
                }
            }))
        }) as Rc<dyn Fn(((bool, Map<Text, bool>), crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>>>
    }))
}

/// The step machine of `NegWalks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub struct NegWalks {
    pub g: crate::check::env::G,
    pub target: Text,
    pub ts: Array<crate::check::types::Ty>,
    pub b: bool,
    pub seen: Map<Text, bool>,
}

impl prism_rtl::Job<(bool, Map<Text, bool>)> for NegWalks {
    fn cycle(&self) -> prism_rtl::Turn<(bool, Map<Text, bool>)> {
        let g = &self.g;
        let target = &self.target;
        let ts = &self.ts;
        let b = &self.b;
        let seen = &self.seen;
        fold_job(ts.clone(), (false, seen.clone()), {
            let g = g.clone();
            let target = target.clone();
            let b = *b;
            Rc::new(move |(p0, p1): ((bool, Map<Text, bool>), crate::check::types::Ty)| {
                let g = g.clone();
                let target = target.clone();
                let b = b;
                entered(once_job(move || {
                    let (bad, sn) = p0;
                    let t = p1;
                    if bad {
                        prism_rtl::Turn::Finished((true, sn.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: t.clone(), b, seen: sn.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(((bool, Map<Text, bool>), crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>>>
        }).cycle()
    }
}

/// `Start NegWalks, x`: what the function value is when passed to `@Run`.
pub fn start_neg_walks(g: crate::check::env::G, target: Text, ts: Array<crate::check::types::Ty>, b: bool, seen: Map<Text, bool>) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>> {
    Rc::new(NegWalks { g, target, ts, b, seen })
}

/// ```prism
/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
/// ```
pub fn nat_minus_seeds(st: &crate::check::types::St) -> Map<Text, Rel> {
    run_to_end(fold_job(keys(&st.size_tys), Map::new(), {
        let st = st.clone();
        Rc::new(move |(p0, p1): (Map<Text, Rel>, Text)| {
            let st = st.clone();
            entered(once_job(move || {
                let m = p0;
                let k = p1;
                match get(&st.size_tys, &k) {
                    Some(t) => call_then(crate::check::types::start_zonk(st.clone(), t.clone()), move |zonk_12379: crate::check::types::Ty| if &zonk_12379 == &crate::check::types::t_nat() {
                        prism_rtl::Turn::Finished(insert(&m, &Text::from(format!("nat:{}", &k)), &no_rel()))
                    } else {
                        prism_rtl::Turn::Finished(m.clone())
                    }),
                    None => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Rel>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
    }))
}

/// The step machine of `NatMinusSeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
/// ```
pub struct NatMinusSeeds {
    pub st: crate::check::types::St,
}

impl prism_rtl::Job<Map<Text, Rel>> for NatMinusSeeds {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let st = &self.st;
        fold_job(keys(&st.size_tys), Map::new(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Map<Text, Rel>, Text)| {
                let st = st.clone();
                entered(once_job(move || {
                    let m = p0;
                    let k = p1;
                    match get(&st.size_tys, &k) {
                        Some(t) => call_then(crate::check::types::start_zonk(st.clone(), t.clone()), move |zonk_12379: crate::check::types::Ty| if &zonk_12379 == &crate::check::types::t_nat() {
                            prism_rtl::Turn::Finished(insert(&m, &Text::from(format!("nat:{}", &k)), &no_rel()))
                        } else {
                            prism_rtl::Turn::Finished(m.clone())
                        }),
                        None => prism_rtl::Turn::Finished(m.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Rel>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
        }).cycle()
    }
}

/// `Start NatMinusSeeds, x`: what the function value is when passed to `@Run`.
pub fn start_nat_minus_seeds(st: crate::check::types::St) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(NatMinusSeeds { st })
}

/// ```prism
/// DefClauses: fn Def -> [FnClause]
/// ```
pub fn def_clauses(d: &crate::check::env::Def) -> Array<crate::syntax::FnClause> {
    match &d.body {
        crate::check::env::DefBody::DbFn(clauses) => clauses.clone(),
        crate::check::env::DefBody::DbMethod(clauses, _, _) => clauses.clone(),
        crate::check::env::DefBody::DbDefault(clauses, _) => clauses.clone(),
        crate::check::env::DefBody::DbWidget(w) => Array::from(vec![crate::syntax::FnClause { name: crate::syntax::DefName::DefSName(w.name.clone()), params: Array::new(), body: crate::syntax::FnBody::BodyBlock(w.body.clone()), span: w.span.clone() }]),
        crate::check::env::DefBody::DbLet(l) => Array::from(vec![crate::syntax::FnClause { name: crate::syntax::DefName::DefOp(d.name.clone(), l.span.clone()), params: Array::new(), body: crate::syntax::FnBody::BodyExpr(l.value.clone()), span: l.span.clone() }]),
        _ => Array::new(),
    }
}

/// ```prism
/// OwnKey: fn Def -> Def
/// ```
pub fn own_key(d: &crate::check::env::Def) -> crate::check::env::Def {
    match &d.body {
        crate::check::env::DefBody::DbMethod(_, _, im) => {
            let mut this: crate::check::env::Def = d.clone();
            this.qk = Text::from(format!("{} #{}.{}", &d.qk, &im.file, &im.span.start));
            this
        },
        _ => d.clone(),
    }
}

/// ```prism
/// ?MethodOf: fn G, Def -> ?Text
/// ```
pub fn method_of(g: &crate::check::env::G, d: &crate::check::env::Def) -> Option<Text> {
    match &d.body {
        crate::check::env::DefBody::DbMethod(_, cls, _) => crate::check::method_key(g, cls, &d.name),
        crate::check::env::DefBody::DbDefault(_, cls) => crate::check::method_key(g, cls, &d.name),
        _ => None,
    }
}

/// ```prism
/// MethodTargets: fn G, [Def] -> (Text ==> [Text])
/// ```
pub fn method_targets(g: &crate::check::env::G, fns: &Array<crate::check::env::Def>) -> Map<Text, Array<Text>> {
    fold(fns, &Map::new(), &(|m: &Map<Text, Array<Text>>, d: &crate::check::env::Def| match method_of(g, d) {
        Some(mk) => insert(m, &mk, &crate::check::types::add_text(&or(&get(m, &mk), &Array::new()), &d.qk)),
        None => m.clone(),
    }))
}

/// ```prism
/// ImplDefs: fn G, [Def] -> (Text ==> Text)
/// ```
pub fn impl_defs(g: &crate::check::env::G, fns: &Array<crate::check::env::Def>) -> Map<Text, Text> {
    fold(fns, &Map::new(), &(|m: &Map<Text, Text>, d: &crate::check::env::Def| match &d.body {
        crate::check::env::DefBody::DbMethod(_, _, im) => match method_of(g, d) {
            Some(mk) => insert(m, &Text::from(format!("{}|{}.{}", &mk, &im.file, &im.span.start)), &d.qk),
            None => m.clone(),
        },
        _ => m.clone(),
    }))
}

/// ```prism
/// ?MethodClass: fn G, Text -> ?Text
/// ```
pub fn method_class(g: &crate::check::env::G, k: &Text) -> Option<Text> {
    match get(&g.vals, k) {
        Some(v_) => if &v_.sort != &Text::lit("method") {
            None
        } else {
            match index(&v_.scheme.bounds, &Nat::from(0u32)) {
                Some((_, cls)) => Some(cls.clone()),
                None => None,
            }
        },
        None => None,
    }
}

/// ```prism
/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
/// ```
pub fn dispatch_targets(sk: &Shrink, d: &crate::check::env::Def, site: &Site, k: &Text) -> Array<Text> {
    let all = targets_of(sk, k);
    match method_class(&sk.g, k) {
        None => all.clone(),
        Some(cls) => {
            let ck = crate::check::types::choice_key(&d.file, &site.span, &cls);
            match get(&sk.choices, &ck) {
                None => all.clone(),
                Some(cs) => run_to_end(fold_job(cs.clone(), Array::new(), {
                    let sk = sk.clone();
                    let k = k.clone();
                    let cls = cls.clone();
                    let all = all.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let sk = sk.clone();
                        let k = k.clone();
                        let cls = cls.clone();
                        let all = all.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let ch = p1;
                            call_then(start_choice_targets(sk.clone(), k.clone(), cls.clone(), all.clone(), ch.clone(), Array::new()), move |choice_targets_15772: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &choice_targets_15772)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                })),
            }
        },
    }
}

/// The step machine of `DispatchTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
/// ```
pub struct DispatchTargets {
    pub sk: Shrink,
    pub d: crate::check::env::Def,
    pub site: Site,
    pub k: Text,
}

impl prism_rtl::Job<Array<Text>> for DispatchTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let d = &self.d;
        let site = &self.site;
        let k = &self.k;
        let all = targets_of(sk, k);
        match method_class(&sk.g, k) {
            None => prism_rtl::Turn::Finished(all.clone()),
            Some(cls) => {
                let ck = crate::check::types::choice_key(&d.file, &site.span, &cls);
                match get(&sk.choices, &ck) {
                    None => prism_rtl::Turn::Finished(all.clone()),
                    Some(cs) => fold_job(cs.clone(), Array::new(), {
                        let sk = sk.clone();
                        let k = k.clone();
                        let cls = cls.clone();
                        let all = all.clone();
                        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                            let sk = sk.clone();
                            let k = k.clone();
                            let cls = cls.clone();
                            let all = all.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let ch = p1;
                                call_then(start_choice_targets(sk.clone(), k.clone(), cls.clone(), all.clone(), ch.clone(), Array::new()), move |choice_targets_15772: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &choice_targets_15772)))
                            }))
                        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }).cycle(),
                }
            },
        }
    }
}

/// `Start DispatchTargets, x`: what the function value is when passed to `@Run`.
pub fn start_dispatch_targets(sk: Shrink, d: crate::check::env::Def, site: Site, k: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(DispatchTargets { sk, d, site, k })
}

/// ```prism
/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub fn choice_targets(sk: &Shrink, k: &Text, cls: &Text, all: &Array<Text>, ch: &Text, seen: &Array<Text>) -> Array<Text> {
    if ch == &Text::lit("none") {
        Array::new()
    } else {
        if crate::syntax::lexer::has_prefix(ch, &Text::lit("impl:")) {
            match get(&sk.impl_defs, &Text::from(format!("{}|{}", k, &crate::syntax::lexer::drop_prefix(ch, &Text::lit("impl:"))))) {
                Some(q) => Array::from(vec![q.clone()]),
                None => filter(all, &(|q: &Text| q == k)),
            }
        } else {
            if crate::syntax::lexer::has_prefix(ch, &Text::lit("derived:")) {
                derived_targets(sk, k, cls, all, &crate::syntax::lexer::drop_prefix(ch, &Text::lit("derived:")), seen)
            } else {
                all.clone()
            }
        }
    }
}

/// The step machine of `ChoiceTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub struct ChoiceTargets {
    pub sk: Shrink,
    pub k: Text,
    pub cls: Text,
    pub all: Array<Text>,
    pub ch: Text,
    pub seen: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for ChoiceTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let k = &self.k;
        let cls = &self.cls;
        let all = &self.all;
        let ch = &self.ch;
        let seen = &self.seen;
        if ch == &Text::lit("none") {
            prism_rtl::Turn::Finished(Array::new())
        } else {
            if crate::syntax::lexer::has_prefix(ch, &Text::lit("impl:")) {
                match get(&sk.impl_defs, &Text::from(format!("{}|{}", k, &crate::syntax::lexer::drop_prefix(ch, &Text::lit("impl:"))))) {
                    Some(q) => prism_rtl::Turn::Finished(Array::from(vec![q.clone()])),
                    None => prism_rtl::Turn::Finished(filter(all, &(|q: &Text| q == k))),
                }
            } else {
                if crate::syntax::lexer::has_prefix(ch, &Text::lit("derived:")) {
                    prism_rtl::Turn::More(Rc::new(DerivedTargets { sk: sk.clone(), k: k.clone(), cls: cls.clone(), all: all.clone(), n: crate::syntax::lexer::drop_prefix(ch, &Text::lit("derived:")), seen: seen.clone() }))
                } else {
                    prism_rtl::Turn::Finished(all.clone())
                }
            }
        }
    }
}

/// `Start ChoiceTargets, x`: what the function value is when passed to `@Run`.
pub fn start_choice_targets(sk: Shrink, k: Text, cls: Text, all: Array<Text>, ch: Text, seen: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ChoiceTargets { sk, k, cls, all, ch, seen })
}

/// ```prism
/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub fn derived_targets(sk: &Shrink, k: &Text, cls: &Text, all: &Array<Text>, n: &Text, seen: &Array<Text>) -> Array<Text> {
    if crate::check::types::has_text(seen, n) {
        Array::new()
    } else {
        {
            let tys = match get(&sk.g.types, n) {
                Some(ti) => match &ti.body {
                    crate::check::env::TyBody::BRecord(fields) => each(fields, &(|(_, t): &(Text, crate::check::types::Ty)| t.clone())),
                    crate::check::env::TyBody::BChoice(cases) => fold(cases, &Array::new(), &(|acc: &Array<crate::check::types::Ty>, (_, args): &(Text, Array<crate::check::types::Ty>)| append(acc, args))),
                    crate::check::env::TyBody::BAlias(t) => Array::from(vec![t.clone()]),
                    _ => Array::new(),
                },
                None => Array::new(),
            };
            let heads = fold(&tys, &Array::new(), &(|acc: &Array<Text>, t: &crate::check::types::Ty| crate::check::types::union_texts(acc, &ty_heads(t))));
            run_to_end(fold_job(heads.clone(), Array::new(), {
                let sk = sk.clone();
                let k = k.clone();
                let cls = cls.clone();
                let all = all.clone();
                let seen = seen.clone();
                let n = n.clone();
                Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                    let sk = sk.clone();
                    let k = k.clone();
                    let cls = cls.clone();
                    let all = all.clone();
                    let seen = seen.clone();
                    let n = n.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let h = p1;
                        prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &head_targets(&sk, &k, &cls, &all, &h, &push(&seen, &n))))
                    }))
                }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }))
        }
    }
}

/// The step machine of `DerivedTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub struct DerivedTargets {
    pub sk: Shrink,
    pub k: Text,
    pub cls: Text,
    pub all: Array<Text>,
    pub n: Text,
    pub seen: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for DerivedTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let k = &self.k;
        let cls = &self.cls;
        let all = &self.all;
        let n = &self.n;
        let seen = &self.seen;
        if crate::check::types::has_text(seen, n) {
            prism_rtl::Turn::Finished(Array::new())
        } else {
            {
                let tys = match get(&sk.g.types, n) {
                    Some(ti) => match &ti.body {
                        crate::check::env::TyBody::BRecord(fields) => each(fields, &(|(_, t): &(Text, crate::check::types::Ty)| t.clone())),
                        crate::check::env::TyBody::BChoice(cases) => fold(cases, &Array::new(), &(|acc: &Array<crate::check::types::Ty>, (_, args): &(Text, Array<crate::check::types::Ty>)| append(acc, args))),
                        crate::check::env::TyBody::BAlias(t) => Array::from(vec![t.clone()]),
                        _ => Array::new(),
                    },
                    None => Array::new(),
                };
                let heads = fold(&tys, &Array::new(), &(|acc: &Array<Text>, t: &crate::check::types::Ty| crate::check::types::union_texts(acc, &ty_heads(t))));
                fold_job(heads.clone(), Array::new(), {
                    let sk = sk.clone();
                    let k = k.clone();
                    let cls = cls.clone();
                    let all = all.clone();
                    let seen = seen.clone();
                    let n = n.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let sk = sk.clone();
                        let k = k.clone();
                        let cls = cls.clone();
                        let all = all.clone();
                        let seen = seen.clone();
                        let n = n.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let h = p1;
                            prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &head_targets(&sk, &k, &cls, &all, &h, &push(&seen, &n))))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle()
            }
        }
    }
}

/// `Start DerivedTargets, x`: what the function value is when passed to `@Run`.
pub fn start_derived_targets(sk: Shrink, k: Text, cls: Text, all: Array<Text>, n: Text, seen: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(DerivedTargets { sk, k, cls, all, n, seen })
}

/// ```prism
/// TyHeads: fn Ty -> [Text]
/// ```
pub fn ty_heads(t: &crate::check::types::Ty) -> Array<Text> {
    match t {
        crate::check::types::Ty::TyCon(n, args) => fold(args, &Array::from(vec![n.clone()]), &(|acc: &Array<Text>, a: &crate::check::types::Ty| crate::check::types::union_texts(acc, &ty_heads(a)))),
        crate::check::types::Ty::TyTuple(ts) => fold(ts, &Array::new(), &(|acc: &Array<Text>, a: &crate::check::types::Ty| crate::check::types::union_texts(acc, &ty_heads(a)))),
        crate::check::types::Ty::TyArray(e) => ty_heads(&**e),
        crate::check::types::Ty::TyMap(a, b) => crate::check::types::union_texts(&ty_heads(&**a), &ty_heads(&**b)),
        crate::check::types::Ty::TySig(_, i) => ty_heads(&**i),
        crate::check::types::Ty::TyQ(_) => Array::new(),
        crate::check::types::Ty::TyRigid(_) => Array::new(),
        crate::check::types::Ty::TyFn(_, _, _) => Array::new(),
        crate::check::types::Ty::TyElem(_, _) => Array::new(),
        crate::check::types::Ty::TyElemAny(_) => Array::new(),
        _ => Array::from(vec![Text::lit("?")]),
    }
}

/// ```prism
/// HeadTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub fn head_targets(sk: &Shrink, k: &Text, cls: &Text, all: &Array<Text>, h: &Text, seen: &Array<Text>) -> Array<Text> {
    if h == &Text::lit("?") {
        all.clone()
    } else {
        if crate::check::env::builtin_has(cls, h) || crate::check::env::is_prim_type(h) {
            Array::new()
        } else {
            match index(&filter(&or(&get(&sk.g.impls, cls), &Array::new()), &(|im: &crate::check::env::ImplInfo| &head_key(&im.head) == &Some(h.clone()))), &Nat::from(0u32)) {
                Some(im) => choice_targets(sk, k, cls, all, &crate::check::env::impl_choice(&im), seen),
                None => all.clone(),
            }
        }
    }
}

/// ```prism
/// ?HeadKey: fn Ty -> ?Text
/// ```
pub fn head_key(ty0: &crate::check::types::Ty) -> Option<Text> {
    match ty0 {
        crate::check::types::Ty::TyCon(n, _) => Some(n.clone()),
        _ => None,
    }
}

/// ```prism
/// TargetsOf: fn Shrink, Text -> [Text]
/// ```
pub fn targets_of(sk: &Shrink, k: &Text) -> Array<Text> {
    or(&get(&sk.targets, k), &Array::from(vec![k.clone()]))
}

/// ```prism
/// SigKeyOf: fn Shrink, Text -> Text
/// ```
pub fn sig_key_of(sk: &Shrink, k: &Text) -> Text {
    match get(&sk.by_key, k) {
        Some(d) => or(&method_of(&sk.g, &d), k),
        None => k.clone(),
    }
}

/// ```prism
/// ShownKey: fn Text -> Text
/// ```
pub fn shown_key(k: &Text) -> Text {
    crate::check::types::bare_name(&or(&index(&split(&or(&crate::syntax::lexer::last(&split(k, &Text::lit(" impl "))), k), &Text::lit(" #")), &Nat::from(0u32)), k))
}

/// ```prism
/// IsUnboundedKey: fn G, Text -> Bool
/// ```
pub fn is_unbounded_key(g: &crate::check::env::G, k: &Text) -> bool {
    match get(&g.vals, k) {
        Some(v_) => match &v_.scheme.ty {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CUnbound, _, _) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
/// ```
pub fn hof_seeds(sk: &Shrink, homes: &Array<Text>) -> Map<Text, Map<Text, Rel>> {
    let cands = hof_candidates(sk);
    let cleared = clear_slots(sk, homes, &cands, &Nat::from(0u32));
    let sums = slot_sums(sk, homes, &cleared, &top_sums(&cleared), &Nat::from(0u32));
    fold(homes, &Map::new(), &(|m: &Map<Text, Map<Text, Rel>>, h: &Text| insert(m, h, &slot_seeds(sk, h, &cleared, &sums, &false))))
}

/// The step machine of `HofSeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
/// ```
pub struct HofSeeds {
    pub sk: Shrink,
    pub homes: Array<Text>,
}

impl prism_rtl::Job<Map<Text, Map<Text, Rel>>> for HofSeeds {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Map<Text, Rel>>> {
        let sk = &self.sk;
        let homes = &self.homes;
        let cands = hof_candidates(sk);
        let homes = homes.clone();
        let sk = sk.clone();
        call_then(start_clear_slots(sk.clone(), homes.clone(), cands.clone(), Nat::from(0u32)), move |clear_slots_20485: Array<Slot_>| {
            let cleared = clear_slots_20485;
            call_then(start_slot_sums(sk.clone(), homes.clone(), cleared.clone(), top_sums(&cleared), Nat::from(0u32)), move |slot_sums_20531: Map<Text, Rel>| {
                let sums = slot_sums_20531;
                prism_rtl::Turn::Finished(fold(&homes, &Map::new(), &(|m: &Map<Text, Map<Text, Rel>>, h: &Text| insert(m, h, &slot_seeds(&sk, h, &cleared, &sums, &false)))))
            })
        })
    }
}

/// `Start HofSeeds, x`: what the function value is when passed to `@Run`.
pub fn start_hof_seeds(sk: Shrink, homes: Array<Text>) -> Rc<dyn prism_rtl::Job<Map<Text, Map<Text, Rel>>>> {
    Rc::new(HofSeeds { sk, homes })
}

/// ```prism
/// HofCandidates: fn Shrink -> [Slot]
/// ```
pub fn hof_candidates(sk: &Shrink) -> Array<Slot_> {
    fold(&sk.fns, &Array::new(), &(|acc: &Array<Slot_>, d: &crate::check::env::Def| match &d.body {
        crate::check::env::DefBody::DbFn(clauses) => match get(&sk.g.vals, &d.qk) {
            Some(v_) => match &v_.scheme.ty {
                crate::check::types::Ty::TyFn(_, ps, _) => fold(&crate::check::errors::range0(&len(ps)), acc, &(|a2: &Array<Slot_>, j: &Nat| match index(ps, j) {
                    Some(crate::check::types::Ty::TyFn(_, fps, _)) => if fold(clauses, &true, &(|ok: &bool, c: &crate::syntax::FnClause| *ok && slot_named(c, j))) {
                        push(a2, &Slot_ { owner: d.qk.clone(), at: j.clone(), arity: len(&fps) })
                    } else {
                        a2.clone()
                    },
                    _ => a2.clone(),
                })),
                _ => acc.clone(),
            },
            None => acc.clone(),
        },
        _ => acc.clone(),
    }))
}

/// ```prism
/// SlotNamed: fn FnClause, Nat -> Bool
/// ```
pub fn slot_named(c: &crate::syntax::FnClause, j: &Nat) -> bool {
    match index(&c.params, j) {
        Some(p_) => match &*p_.kind {
            crate::syntax::PatternKind::PName(_) => true,
            crate::syntax::PatternKind::PIgnore => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// SlotName: fn FnClause, Nat -> Text
/// ```
pub fn slot_name(c: &crate::syntax::FnClause, j: &Nat) -> Text {
    match index(&c.params, j) {
        Some(p_) => match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => crate::check::env::sname_key(n),
            _ => Text::lit(""),
        },
        None => Text::lit(""),
    }
}

/// ```prism
/// SlotSeeds: fn Shrink, Text, [Slot], (Text ==> Rel), Bool -> (Text ==> Rel)
/// ```
pub fn slot_seeds(sk: &Shrink, h: &Text, slots: &Array<Slot_>, sums: &Map<Text, Rel>, with_top: &bool) -> Map<Text, Rel> {
    let pre = or(&get(&sk.seeds, h), &Map::new());
    let start = if *with_top {
        insert(&pre, &Text::lit("⊤"), &Rel { param: top_param(), strict: false })
    } else {
        pre.clone()
    };
    fold(slots, &start, &(|m: &Map<Text, Rel>, sl: &Slot_| fold(&spellings(&sk.g, h, &sl.owner), m, &(|m2: &Map<Text, Rel>, sp: &Text| {
        let m3 = insert(m2, &Text::from(format!("acc:{}:{}", sp, &sl.at)), &Rel { param: sl.arity.clone(), strict: false });
        fold(&crate::check::errors::range0(&sl.arity), &m3, &(|m4: &Map<Text, Rel>, q: &Nat| match get(sums, &Text::from(format!("{}:{}:{}", &sl.owner, &sl.at, q))) {
            Some(r) => if (&r.param == &top_param()) && !*with_top {
                m4.clone()
            } else {
                insert(m4, &Text::from(format!("sum:{}:{}:{}", sp, &sl.at, q)), &r)
            },
            None => m4.clone(),
        }))
    }))))
}

/// ```prism
/// Spellings: fn G, Text, Text -> [Text]
/// ```
pub fn spellings(g: &crate::check::env::G, h: &Text, k: &Text) -> Array<Text> {
    filter(&crate::check::types::add_text(&Array::from(vec![crate::check::types::bare_name(k)]), k), &(|sp: &Text| &resolve_name(g, h, sp) == &Some(k.clone())))
}

/// ```prism
/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
/// ```
pub fn clear_slots(sk: &Shrink, homes: &Array<Text>, slots: &Array<Slot_>, round: &Nat) -> Array<Slot_> {
    let sks = seeds_for(sk, homes, slots, &Map::new(), &false);
    let kept = run_to_end(filter_job(slots.clone(), {
        let sks = sks.clone();
        Rc::new(move |p0: Slot_| {
            let sks = sks.clone();
            entered(once_job(move || {
                let sl = p0;
                call_then(start_slot_escapes(sks.clone(), sl.clone()), move |slot_escapes_22957: bool| prism_rtl::Turn::Finished(!slot_escapes_22957))
            }))
        }) as Rc<dyn Fn(Slot_) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    if &len(&kept) == &len(slots) {
        kept.clone()
    } else {
        if round > &Nat::from(20u32) {
            Array::new()
        } else {
            clear_slots(sk, homes, &kept, &(round + &Nat::from(1u32)))
        }
    }
}

/// The step machine of `ClearSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
/// ```
pub struct ClearSlots {
    pub sk: Shrink,
    pub homes: Array<Text>,
    pub slots: Array<Slot_>,
    pub round: Nat,
}

impl prism_rtl::Job<Array<Slot_>> for ClearSlots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Slot_>> {
        let sk = &self.sk;
        let homes = &self.homes;
        let slots = &self.slots;
        let round = &self.round;
        let sks = seeds_for(sk, homes, slots, &Map::new(), &false);
        let homes = homes.clone();
        let round = round.clone();
        let sk = sk.clone();
        let slots = slots.clone();
        call_value(filter_job(slots.clone(), {
            let sks = sks.clone();
            Rc::new(move |p0: Slot_| {
                let sks = sks.clone();
                entered(once_job(move || {
                    let sl = p0;
                    call_then(start_slot_escapes(sks.clone(), sl.clone()), move |slot_escapes_22957: bool| prism_rtl::Turn::Finished(!slot_escapes_22957))
                }))
            }) as Rc<dyn Fn(Slot_) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |filter_22932: Array<Slot_>| {
            let kept = filter_22932;
            if &len(&kept) == &len(&slots) {
                prism_rtl::Turn::Finished(kept.clone())
            } else {
                if &round > &Nat::from(20u32) {
                    prism_rtl::Turn::Finished(Array::new())
                } else {
                    prism_rtl::Turn::More(Rc::new(ClearSlots { sk: sk.clone(), homes: homes.clone(), slots: kept.clone(), round: &round + &Nat::from(1u32) }))
                }
            }
        })
    }
}

/// `Start ClearSlots, x`: what the function value is when passed to `@Run`.
pub fn start_clear_slots(sk: Shrink, homes: Array<Text>, slots: Array<Slot_>, round: Nat) -> Rc<dyn prism_rtl::Job<Array<Slot_>>> {
    Rc::new(ClearSlots { sk, homes, slots, round })
}

/// ```prism
/// SeedsFor: fn Shrink, [Text], [Slot], (Text ==> Rel), Bool -> Shrink
/// ```
pub fn seeds_for(sk: &Shrink, homes: &Array<Text>, slots: &Array<Slot_>, sums: &Map<Text, Rel>, with_top: &bool) -> Shrink {
    let mut this: Shrink = sk.clone();
    this.seeds = fold(homes, &Map::new(), &(|m: &Map<Text, Map<Text, Rel>>, h: &Text| insert(m, h, &slot_seeds(sk, h, slots, sums, with_top))));
    this
}

/// ```prism
/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
/// ```
pub fn slot_escapes(sk: &Shrink, sl: &Slot_) -> bool {
    match get(&sk.by_key, &sl.owner) {
        Some(d) => run_to_end(fold_job(def_clauses(&d), false, {
            let sl = sl.clone();
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): (bool, crate::syntax::FnClause)| {
                let sl = sl.clone();
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let c = p1;
                    {
                        let n = slot_name(&c, &sl.at);
                        if seen || (&n == &Text::lit("")) {
                            prism_rtl::Turn::Finished(seen)
                        } else {
                            call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_23758: Map<Text, Rel>| call_then(start_body_spots(c.body.clone(), clause_base_23758), move |body_spots_23739: Array<Spot>| fold_job(body_spots_23739, false, {
                                let n = n.clone();
                                let sl = sl.clone();
                                Rc::new(move |(p0, p1): (bool, Spot)| {
                                    let n = n.clone();
                                    let sl = sl.clone();
                                    entered(once_job(move || {
                                        let esc = p0;
                                        let sp = p1;
                                        prism_rtl::Turn::Finished(esc || spot_escapes(&sp, &n, &sl.at))
                                    }))
                                }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }).cycle()))
                        }
                    }
                }))
            }) as Rc<dyn Fn((bool, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        None => true,
    }
}

/// The step machine of `SlotEscapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
/// ```
pub struct SlotEscapes {
    pub sk: Shrink,
    pub sl: Slot_,
}

impl prism_rtl::Job<bool> for SlotEscapes {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let sk = &self.sk;
        let sl = &self.sl;
        match get(&sk.by_key, &sl.owner) {
            Some(d) => fold_job(def_clauses(&d), false, {
                let sl = sl.clone();
                let sk = sk.clone();
                let d = d.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::FnClause)| {
                    let sl = sl.clone();
                    let sk = sk.clone();
                    let d = d.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let c = p1;
                        {
                            let n = slot_name(&c, &sl.at);
                            if seen || (&n == &Text::lit("")) {
                                prism_rtl::Turn::Finished(seen)
                            } else {
                                call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_23758: Map<Text, Rel>| call_then(start_body_spots(c.body.clone(), clause_base_23758), move |body_spots_23739: Array<Spot>| fold_job(body_spots_23739, false, {
                                    let n = n.clone();
                                    let sl = sl.clone();
                                    Rc::new(move |(p0, p1): (bool, Spot)| {
                                        let n = n.clone();
                                        let sl = sl.clone();
                                        entered(once_job(move || {
                                            let esc = p0;
                                            let sp = p1;
                                            prism_rtl::Turn::Finished(esc || spot_escapes(&sp, &n, &sl.at))
                                        }))
                                    }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
                                }).cycle()))
                            }
                        }
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            None => prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start SlotEscapes, x`: what the function value is when passed to `@Run`.
pub fn start_slot_escapes(sk: Shrink, sl: Slot_) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SlotEscapes { sk, sl })
}

/// ```prism
/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub fn spot_escapes(sp: &Spot, n: &Text, j: &Nat) -> bool {
    match sp {
        Spot::SpotExpr(e, m) => match &*e.kind {
            crate::syntax::ExprKind::EName(x) => (&crate::check::env::sname_key(x) == n) && is_slot_param(m, n, j),
            _ => fold(&spot_sites(sp), &false, &(|seen: &bool, site: &Site| *seen || (((&site.callee == n) && is_slot_param(&site.rels, n, j)) && crate::check::env::has_key(&site.rels, &Text::lit("lam:"))))),
        },
        Spot::SpotStmt(_, _) => false,
    }
}

/// The step machine of `SpotEscapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub struct SpotEscapes {
    pub sp: Spot,
    pub n: Text,
    pub j: Nat,
}

impl prism_rtl::Job<bool> for SpotEscapes {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let sp = &self.sp;
        let n = &self.n;
        let j = &self.j;
        match sp {
            Spot::SpotExpr(e, m) => match &*e.kind {
                crate::syntax::ExprKind::EName(x) => prism_rtl::Turn::Finished((&crate::check::env::sname_key(x) == n) && is_slot_param(m, n, j)),
                _ => {
                    let j = j.clone();
                    let n = n.clone();
                    let sp = sp.clone();
                    call_then(start_spot_sites(sp.clone()), move |spot_sites_24049: Array<Site>| prism_rtl::Turn::Finished(fold(&spot_sites_24049, &false, &(|seen: &bool, site: &Site| *seen || (((&site.callee == &n) && is_slot_param(&site.rels, &n, &j)) && crate::check::env::has_key(&site.rels, &Text::lit("lam:")))))))
                },
            },
            Spot::SpotStmt(_, _) => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start SpotEscapes, x`: what the function value is when passed to `@Run`.
pub fn start_spot_escapes(sp: Spot, n: Text, j: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SpotEscapes { sp, n, j })
}

/// ```prism
/// IsSlotParam: fn (Text ==> Rel), Text, Nat -> Bool
/// ```
pub fn is_slot_param(m: &Map<Text, Rel>, n: &Text, j: &Nat) -> bool {
    &get(m, n) == &Some(Rel { param: j.clone(), strict: false })
}

/// ```prism
/// TopSums: fn [Slot] -> (Text ==> Rel)
/// ```
pub fn top_sums(slots: &Array<Slot_>) -> Map<Text, Rel> {
    fold(slots, &Map::new(), &(|m: &Map<Text, Rel>, sl: &Slot_| fold(&crate::check::errors::range0(&sl.arity), m, &(|m2: &Map<Text, Rel>, q: &Nat| insert(m2, &Text::from(format!("{}:{}:{}", &sl.owner, &sl.at, q)), &Rel { param: top_param(), strict: false })))))
}

/// ```prism
/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
/// ```
pub fn slot_sums(sk: &Shrink, homes: &Array<Text>, slots: &Array<Slot_>, sums: &Map<Text, Rel>, round: &Nat) -> Map<Text, Rel> {
    let sks = seeds_for(sk, homes, slots, sums, &true);
    let next = run_to_end(fold_job(slots.clone(), Map::new(), {
        let sks = sks.clone();
        Rc::new(move |(p0, p1): (Map<Text, Rel>, Slot_)| {
            let sks = sks.clone();
            entered(once_job(move || {
                let m = p0;
                let sl = p1;
                call_then(start_slot_calls(sks.clone(), sl.clone()), move |slot_calls_25194: Array<Site>| {
                    let calls = slot_calls_25194;
                    fold_job(crate::check::errors::range0(&sl.arity), m.clone(), {
                        let calls = calls.clone();
                        let sl = sl.clone();
                        Rc::new(move |(p0, p1): (Map<Text, Rel>, Nat)| {
                            let calls = calls.clone();
                            let sl = sl.clone();
                            entered(once_job(move || {
                                let m2 = p0;
                                let q = p1;
                                call_then(start_meet_args(calls.clone(), q.clone()), move |meet_args_25262: Option<Rel>| match meet_args_25262 {
                                    Some(r) => prism_rtl::Turn::Finished(insert(&m2, &Text::from(format!("{}:{}:{}", &sl.owner, &sl.at, &q)), &r)),
                                    None => prism_rtl::Turn::Finished(m2.clone()),
                                })
                            }))
                        }) as Rc<dyn Fn((Map<Text, Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
                    }).cycle()
                })
            }))
        }) as Rc<dyn Fn((Map<Text, Rel>, Slot_)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
    }));
    if &next == sums {
        next.clone()
    } else {
        if round > &Nat::from(12u32) {
            Map::new()
        } else {
            slot_sums(sk, homes, slots, &next, &(round + &Nat::from(1u32)))
        }
    }
}

/// The step machine of `SlotSums`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
/// ```
pub struct SlotSums {
    pub sk: Shrink,
    pub homes: Array<Text>,
    pub slots: Array<Slot_>,
    pub sums: Map<Text, Rel>,
    pub round: Nat,
}

impl prism_rtl::Job<Map<Text, Rel>> for SlotSums {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let sk = &self.sk;
        let homes = &self.homes;
        let slots = &self.slots;
        let sums = &self.sums;
        let round = &self.round;
        let sks = seeds_for(sk, homes, slots, sums, &true);
        let homes = homes.clone();
        let round = round.clone();
        let sk = sk.clone();
        let slots = slots.clone();
        let sums = sums.clone();
        call_value(fold_job(slots.clone(), Map::new(), {
            let sks = sks.clone();
            Rc::new(move |(p0, p1): (Map<Text, Rel>, Slot_)| {
                let sks = sks.clone();
                entered(once_job(move || {
                    let m = p0;
                    let sl = p1;
                    call_then(start_slot_calls(sks.clone(), sl.clone()), move |slot_calls_25194: Array<Site>| {
                        let calls = slot_calls_25194;
                        fold_job(crate::check::errors::range0(&sl.arity), m.clone(), {
                            let calls = calls.clone();
                            let sl = sl.clone();
                            Rc::new(move |(p0, p1): (Map<Text, Rel>, Nat)| {
                                let calls = calls.clone();
                                let sl = sl.clone();
                                entered(once_job(move || {
                                    let m2 = p0;
                                    let q = p1;
                                    call_then(start_meet_args(calls.clone(), q.clone()), move |meet_args_25262: Option<Rel>| match meet_args_25262 {
                                        Some(r) => prism_rtl::Turn::Finished(insert(&m2, &Text::from(format!("{}:{}:{}", &sl.owner, &sl.at, &q)), &r)),
                                        None => prism_rtl::Turn::Finished(m2.clone()),
                                    })
                                }))
                            }) as Rc<dyn Fn((Map<Text, Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
                        }).cycle()
                    })
                }))
            }) as Rc<dyn Fn((Map<Text, Rel>, Slot_)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
        }), move |fold_25149: Map<Text, Rel>| {
            let next = fold_25149;
            if &next == &sums {
                prism_rtl::Turn::Finished(next.clone())
            } else {
                if &round > &Nat::from(12u32) {
                    prism_rtl::Turn::Finished(Map::new())
                } else {
                    prism_rtl::Turn::More(Rc::new(SlotSums { sk: sk.clone(), homes: homes.clone(), slots: slots.clone(), sums: next.clone(), round: &round + &Nat::from(1u32) }))
                }
            }
        })
    }
}

/// `Start SlotSums, x`: what the function value is when passed to `@Run`.
pub fn start_slot_sums(sk: Shrink, homes: Array<Text>, slots: Array<Slot_>, sums: Map<Text, Rel>, round: Nat) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(SlotSums { sk, homes, slots, sums, round })
}

/// ```prism
/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
/// ```
pub fn slot_calls(sk: &Shrink, sl: &Slot_) -> Array<Site> {
    match get(&sk.by_key, &sl.owner) {
        Some(d) => run_to_end(fold_job(def_clauses(&d), Array::new(), {
            let sl = sl.clone();
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): (Array<Site>, crate::syntax::FnClause)| {
                let sl = sl.clone();
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let c = p1;
                    {
                        let n = slot_name(&c, &sl.at);
                        if &n == &Text::lit("") {
                            prism_rtl::Turn::Finished(acc.clone())
                        } else {
                            call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_25787: Map<Text, Rel>| {
                                let base = clause_base_25787;
                                call_then(start_body_spots(c.body.clone(), base.clone()), move |body_spots_25851: Array<Spot>| call_then(start_summary_seeds(sk.clone(), d.clone(), body_spots_25851, base.clone()), move |summary_seeds_25830: Map<Text, Rel>| {
                                    let rels = summary_seeds_25830;
                                    call_then(start_body_spots(c.body.clone(), rels.clone()), move |body_spots_25899: Array<Spot>| fold_job(body_spots_25899, acc.clone(), {
                                        let n = n.clone();
                                        let sl = sl.clone();
                                        Rc::new(move |(p0, p1): (Array<Site>, Spot)| {
                                            let n = n.clone();
                                            let sl = sl.clone();
                                            entered(once_job(move || {
                                                let a2 = p0;
                                                let sp = p1;
                                                match &sp {
                                                    Spot::SpotExpr(e, _) => match &*e.kind {
                                                        crate::syntax::ExprKind::EName(_) => prism_rtl::Turn::Finished(a2.clone()),
                                                        _ => call_then(start_spot_sites(sp.clone()), move |spot_sites_26087: Array<Site>| prism_rtl::Turn::Finished(append(&a2, &filter(&spot_sites_26087, &(|site: &Site| (&site.callee == &n) && is_slot_param(&site.rels, &n, &sl.at)))))),
                                                    },
                                                    _ => prism_rtl::Turn::Finished(a2.clone()),
                                                }
                                            }))
                                        }) as Rc<dyn Fn((Array<Site>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>
                                    }).cycle())
                                }))
                            })
                        }
                    }
                }))
            }) as Rc<dyn Fn((Array<Site>, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>
        })),
        None => Array::new(),
    }
}

/// The step machine of `SlotCalls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
/// ```
pub struct SlotCalls {
    pub sk: Shrink,
    pub sl: Slot_,
}

impl prism_rtl::Job<Array<Site>> for SlotCalls {
    fn cycle(&self) -> prism_rtl::Turn<Array<Site>> {
        let sk = &self.sk;
        let sl = &self.sl;
        match get(&sk.by_key, &sl.owner) {
            Some(d) => fold_job(def_clauses(&d), Array::new(), {
                let sl = sl.clone();
                let sk = sk.clone();
                let d = d.clone();
                Rc::new(move |(p0, p1): (Array<Site>, crate::syntax::FnClause)| {
                    let sl = sl.clone();
                    let sk = sk.clone();
                    let d = d.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let c = p1;
                        {
                            let n = slot_name(&c, &sl.at);
                            if &n == &Text::lit("") {
                                prism_rtl::Turn::Finished(acc.clone())
                            } else {
                                call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_25787: Map<Text, Rel>| {
                                    let base = clause_base_25787;
                                    call_then(start_body_spots(c.body.clone(), base.clone()), move |body_spots_25851: Array<Spot>| call_then(start_summary_seeds(sk.clone(), d.clone(), body_spots_25851, base.clone()), move |summary_seeds_25830: Map<Text, Rel>| {
                                        let rels = summary_seeds_25830;
                                        call_then(start_body_spots(c.body.clone(), rels.clone()), move |body_spots_25899: Array<Spot>| fold_job(body_spots_25899, acc.clone(), {
                                            let n = n.clone();
                                            let sl = sl.clone();
                                            Rc::new(move |(p0, p1): (Array<Site>, Spot)| {
                                                let n = n.clone();
                                                let sl = sl.clone();
                                                entered(once_job(move || {
                                                    let a2 = p0;
                                                    let sp = p1;
                                                    match &sp {
                                                        Spot::SpotExpr(e, _) => match &*e.kind {
                                                            crate::syntax::ExprKind::EName(_) => prism_rtl::Turn::Finished(a2.clone()),
                                                            _ => call_then(start_spot_sites(sp.clone()), move |spot_sites_26087: Array<Site>| prism_rtl::Turn::Finished(append(&a2, &filter(&spot_sites_26087, &(|site: &Site| (&site.callee == &n) && is_slot_param(&site.rels, &n, &sl.at)))))),
                                                        },
                                                        _ => prism_rtl::Turn::Finished(a2.clone()),
                                                    }
                                                }))
                                            }) as Rc<dyn Fn((Array<Site>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>
                                        }).cycle())
                                    }))
                                })
                            }
                        }
                    }))
                }) as Rc<dyn Fn((Array<Site>, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>
            }).cycle(),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start SlotCalls, x`: what the function value is when passed to `@Run`.
pub fn start_slot_calls(sk: Shrink, sl: Slot_) -> Rc<dyn prism_rtl::Job<Array<Site>>> {
    Rc::new(SlotCalls { sk, sl })
}

/// ```prism
/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
/// ```
pub fn meet_args(calls: &Array<Site>, q: &Nat) -> Option<Rel> {
    run_to_end(fold_job(calls.clone(), Some(Rel { param: top_param(), strict: false }), {
        let q = q.clone();
        Rc::new(move |(p0, p1): (Option<Rel>, Site)| {
            let q = q.clone();
            entered(once_job(move || {
                let acc_opt = p0;
                let site = p1;
                match &acc_opt {
                    None => prism_rtl::Turn::Finished(None),
                    Some(acc) => match index(&site.args, &q) {
                        Some(a) => if &a.name != &None {
                            prism_rtl::Turn::Finished(None)
                        } else {
                            {
                                let acc = acc.clone();
                                call_then(start_rel_of(site.rels.clone(), a.value.clone()), move |rel_of_26664: Option<Rel>| match rel_of_26664 {
                                    Some(r) => if &r.param == &top_param() {
                                        prism_rtl::Turn::Finished(Some(acc.clone()))
                                    } else {
                                        if &acc.param == &top_param() {
                                            prism_rtl::Turn::Finished(Some(r.clone()))
                                        } else {
                                            if &acc.param == &r.param {
                                                prism_rtl::Turn::Finished(Some(Rel { param: r.param.clone(), strict: acc.strict && r.strict }))
                                            } else {
                                                prism_rtl::Turn::Finished(None)
                                            }
                                        }
                                    },
                                    None => prism_rtl::Turn::Finished(None),
                                })
                            }
                        },
                        None => prism_rtl::Turn::Finished(None),
                    },
                }
            }))
        }) as Rc<dyn Fn((Option<Rel>, Site)) -> Rc<dyn prism_rtl::Job<Option<Rel>>>>
    }))
}

/// The step machine of `MeetArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
/// ```
pub struct MeetArgs {
    pub calls: Array<Site>,
    pub q: Nat,
}

impl prism_rtl::Job<Option<Rel>> for MeetArgs {
    fn cycle(&self) -> prism_rtl::Turn<Option<Rel>> {
        let calls = &self.calls;
        let q = &self.q;
        fold_job(calls.clone(), Some(Rel { param: top_param(), strict: false }), {
            let q = q.clone();
            Rc::new(move |(p0, p1): (Option<Rel>, Site)| {
                let q = q.clone();
                entered(once_job(move || {
                    let acc_opt = p0;
                    let site = p1;
                    match &acc_opt {
                        None => prism_rtl::Turn::Finished(None),
                        Some(acc) => match index(&site.args, &q) {
                            Some(a) => if &a.name != &None {
                                prism_rtl::Turn::Finished(None)
                            } else {
                                {
                                    let acc = acc.clone();
                                    call_then(start_rel_of(site.rels.clone(), a.value.clone()), move |rel_of_26664: Option<Rel>| match rel_of_26664 {
                                        Some(r) => if &r.param == &top_param() {
                                            prism_rtl::Turn::Finished(Some(acc.clone()))
                                        } else {
                                            if &acc.param == &top_param() {
                                                prism_rtl::Turn::Finished(Some(r.clone()))
                                            } else {
                                                if &acc.param == &r.param {
                                                    prism_rtl::Turn::Finished(Some(Rel { param: r.param.clone(), strict: acc.strict && r.strict }))
                                                } else {
                                                    prism_rtl::Turn::Finished(None)
                                                }
                                            }
                                        },
                                        None => prism_rtl::Turn::Finished(None),
                                    })
                                }
                            },
                            None => prism_rtl::Turn::Finished(None),
                        },
                    }
                }))
            }) as Rc<dyn Fn((Option<Rel>, Site)) -> Rc<dyn prism_rtl::Job<Option<Rel>>>>
        }).cycle()
    }
}

/// `Start MeetArgs, x`: what the function value is when passed to `@Run`.
pub fn start_meet_args(calls: Array<Site>, q: Nat) -> Rc<dyn prism_rtl::Job<Option<Rel>>> {
    Rc::new(MeetArgs { calls, q })
}

/// ```prism
/// DefRefs: unbounded fn Shrink, Def -> [Text]
/// ```
pub fn def_refs(sk: &Shrink, d: &crate::check::env::Def) -> Array<Text> {
    run_to_end(fold_job(def_clauses(d), Array::new(), {
        let sk = sk.clone();
        let d = d.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::FnClause)| {
            let sk = sk.clone();
            let d = d.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_27201: Map<Text, Rel>| call_then(start_body_spots(c.body.clone(), clause_base_27201), move |body_spots_27182: Array<Spot>| prism_rtl::Turn::More(Rc::new(SpotsRefs { sk: sk.clone(), d: d.clone(), spots: body_spots_27182, acc: acc.clone() }))))
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `DefRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefRefs: unbounded fn Shrink, Def -> [Text]
/// ```
pub struct DefRefs {
    pub sk: Shrink,
    pub d: crate::check::env::Def,
}

impl prism_rtl::Job<Array<Text>> for DefRefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let d = &self.d;
        fold_job(def_clauses(d), Array::new(), {
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::FnClause)| {
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let c = p1;
                    call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_27201: Map<Text, Rel>| call_then(start_body_spots(c.body.clone(), clause_base_27201), move |body_spots_27182: Array<Spot>| prism_rtl::Turn::More(Rc::new(SpotsRefs { sk: sk.clone(), d: d.clone(), spots: body_spots_27182, acc: acc.clone() }))))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start DefRefs, x`: what the function value is when passed to `@Run`.
pub fn start_def_refs(sk: Shrink, d: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(DefRefs { sk, d })
}

/// ```prism
/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
/// ```
pub fn spots_refs(sk: &Shrink, d: &crate::check::env::Def, spots: &Array<Spot>, acc: &Array<Text>) -> Array<Text> {
    run_to_end(fold_job(spots.clone(), acc.clone(), {
        let sk = sk.clone();
        let d = d.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Spot)| {
            let sk = sk.clone();
            let d = d.clone();
            entered(once_job(move || {
                let a1 = p0;
                let sp = p1;
                call_then(start_spot_sites(sp.clone()), move |spot_sites_27357: Array<Site>| prism_rtl::Turn::Finished(fold(&spot_sites_27357, &a1, &(|a2: &Array<Text>, site: &Site| match local_target(&sk, &d, site) {
                    Some(t) => crate::check::types::add_text(a2, &t),
                    None => if is_local(&site.rels, &site.callee) || crate::check::env::has_key(&sk.local_of, &d.qk) {
                        a2.clone()
                    } else {
                        match resolve_callee(&sk.g, &d.home, &site.callee) {
                            Some(k) => fold(&targets_of(&sk, &k), a2, &(|a3: &Array<Text>, t: &Text| if crate::check::env::has_key(&sk.by_key, t) {
                                crate::check::types::add_text(a3, t)
                            } else {
                                a3.clone()
                            })),
                            None => a2.clone(),
                        }
                    },
                }))))
            }))
        }) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `SpotsRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
/// ```
pub struct SpotsRefs {
    pub sk: Shrink,
    pub d: crate::check::env::Def,
    pub spots: Array<Spot>,
    pub acc: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for SpotsRefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let d = &self.d;
        let spots = &self.spots;
        let acc = &self.acc;
        fold_job(spots.clone(), acc.clone(), {
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Spot)| {
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let a1 = p0;
                    let sp = p1;
                    call_then(start_spot_sites(sp.clone()), move |spot_sites_27357: Array<Site>| prism_rtl::Turn::Finished(fold(&spot_sites_27357, &a1, &(|a2: &Array<Text>, site: &Site| match local_target(&sk, &d, site) {
                        Some(t) => crate::check::types::add_text(a2, &t),
                        None => if is_local(&site.rels, &site.callee) || crate::check::env::has_key(&sk.local_of, &d.qk) {
                            a2.clone()
                        } else {
                            match resolve_callee(&sk.g, &d.home, &site.callee) {
                                Some(k) => fold(&targets_of(&sk, &k), a2, &(|a3: &Array<Text>, t: &Text| if crate::check::env::has_key(&sk.by_key, t) {
                                    crate::check::types::add_text(a3, t)
                                } else {
                                    a3.clone()
                                })),
                                None => a2.clone(),
                            }
                        },
                    }))))
                }))
            }) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start SpotsRefs, x`: what the function value is when passed to `@Run`.
pub fn start_spots_refs(sk: Shrink, d: crate::check::env::Def, spots: Array<Spot>, acc: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotsRefs { sk, d, spots, acc })
}

/// ```prism
/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
/// ```
pub fn with_locals(sk: &Shrink, found: &Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>) -> Shrink {
    let (bases, owners, clauses, wdecls) = fold(found, &(Map::new(), Map::new(), Map::new(), Map::new()), &(|(bs, os, cs, ws): &(Map<Text, Map<Text, Rel>>, Map<Text, Text>, Map<Text, Array<crate::syntax::FnClause>>, Map<Text, (crate::check::env::Def, crate::syntax::WidgetDecl)>), (d, gk, n, m, c_opt, w_opt): &(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)| {
        let qk = local_key(n, &d.qk, gk);
        let bs2 = if crate::check::env::has_key(bs, &qk) {
            bs.clone()
        } else {
            insert(bs, &qk, &marks(m))
        };
        let os2 = insert(os, &qk, &d.qk);
        let cs2 = match c_opt {
            Some(c) => insert(cs, &qk, &push(&or(&get(cs, &qk), &Array::new()), c)),
            None => cs.clone(),
        };
        let ws2 = match w_opt {
            Some(w) => insert(ws, &qk, &(d.clone(), w.clone())),
            None => ws.clone(),
        };
        (bs2.clone(), os2.clone(), cs2.clone(), ws2.clone())
    }));
    let fn_defs = fold(&keys(&clauses), &Array::new(), &(|acc: &Array<crate::check::env::Def>, qk: &Text| match (get(&owners, qk), get(&clauses, qk)) {
        (Some(oq), Some(cl)) => match get(&sk.by_key, &oq) {
            Some(d) => push(acc, &crate::check::env::Def { qk: qk.clone(), name: or(&index(&split(qk, &Text::lit(" #")), &Nat::from(0u32)), qk), home: d.home.clone(), file: d.file.clone(), span: d.span.clone(), body: crate::check::env::DefBody::DbFn(cl.clone()) }),
            None => acc.clone(),
        },
        _ => acc.clone(),
    }));
    let w_defs = fold(&keys(&wdecls), &Array::new(), &(|acc: &Array<crate::check::env::Def>, qk: &Text| match get(&wdecls, qk) {
        Some((d, w)) => push(acc, &crate::check::env::Def { qk: qk.clone(), name: crate::check::env::sname_key(&w.name), home: d.home.clone(), file: d.file.clone(), span: w.span.clone(), body: crate::check::env::DefBody::DbWidget(w.clone()) }),
        None => acc.clone(),
    }));
    let locals = append(&fn_defs, &w_defs);
    let mut this: Shrink = sk.clone();
    this.fns = append(&this.fns, &locals);
    this.by_key = fold(&locals, &this.by_key, &(|m: &Map<Text, crate::check::env::Def>, d: &crate::check::env::Def| insert(m, &d.qk, d)));
    this.local_of = owners.clone();
    this.local_base = bases.clone();
    this
}

/// The step machine of `WithLocals`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
/// ```
pub struct WithLocals {
    pub sk: Shrink,
    pub found: Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>,
}

impl prism_rtl::Job<Shrink> for WithLocals {
    fn cycle(&self) -> prism_rtl::Turn<Shrink> {
        let sk = &self.sk;
        let found = &self.found;
        let (bases, owners, clauses, wdecls) = fold(found, &(Map::new(), Map::new(), Map::new(), Map::new()), &(|(bs, os, cs, ws): &(Map<Text, Map<Text, Rel>>, Map<Text, Text>, Map<Text, Array<crate::syntax::FnClause>>, Map<Text, (crate::check::env::Def, crate::syntax::WidgetDecl)>), (d, gk, n, m, c_opt, w_opt): &(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)| {
            let qk = local_key(n, &d.qk, gk);
            let bs2 = if crate::check::env::has_key(bs, &qk) {
                bs.clone()
            } else {
                insert(bs, &qk, &marks(m))
            };
            let os2 = insert(os, &qk, &d.qk);
            let cs2 = match c_opt {
                Some(c) => insert(cs, &qk, &push(&or(&get(cs, &qk), &Array::new()), c)),
                None => cs.clone(),
            };
            let ws2 = match w_opt {
                Some(w) => insert(ws, &qk, &(d.clone(), w.clone())),
                None => ws.clone(),
            };
            (bs2.clone(), os2.clone(), cs2.clone(), ws2.clone())
        }));
        let fn_defs = fold(&keys(&clauses), &Array::new(), &(|acc: &Array<crate::check::env::Def>, qk: &Text| match (get(&owners, qk), get(&clauses, qk)) {
            (Some(oq), Some(cl)) => match get(&sk.by_key, &oq) {
                Some(d) => push(acc, &crate::check::env::Def { qk: qk.clone(), name: or(&index(&split(qk, &Text::lit(" #")), &Nat::from(0u32)), qk), home: d.home.clone(), file: d.file.clone(), span: d.span.clone(), body: crate::check::env::DefBody::DbFn(cl.clone()) }),
                None => acc.clone(),
            },
            _ => acc.clone(),
        }));
        let w_defs = fold(&keys(&wdecls), &Array::new(), &(|acc: &Array<crate::check::env::Def>, qk: &Text| match get(&wdecls, qk) {
            Some((d, w)) => push(acc, &crate::check::env::Def { qk: qk.clone(), name: crate::check::env::sname_key(&w.name), home: d.home.clone(), file: d.file.clone(), span: w.span.clone(), body: crate::check::env::DefBody::DbWidget(w.clone()) }),
            None => acc.clone(),
        }));
        let locals = append(&fn_defs, &w_defs);
        prism_rtl::Turn::Finished({
            let mut this: Shrink = sk.clone();
            this.fns = append(&this.fns, &locals);
            this.by_key = fold(&locals, &this.by_key, &(|m: &Map<Text, crate::check::env::Def>, d: &crate::check::env::Def| insert(m, &d.qk, d)));
            this.local_of = owners.clone();
            this.local_base = bases.clone();
            this
        })
    }
}

/// `Start WithLocals, x`: what the function value is when passed to `@Run`.
pub fn start_with_locals(sk: Shrink, found: Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>) -> Rc<dyn prism_rtl::Job<Shrink>> {
    Rc::new(WithLocals { sk, found })
}

/// ```prism
/// LocalKey: fn Text, Text, Text -> Text
/// ```
pub fn local_key(n: &Text, owner: &Text, gk: &Text) -> Text {
    Text::from(format!("{} #local {} {}", n, owner, gk))
}

/// ```prism
/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
/// ```
pub fn def_walk(sk: &Shrink, d: &crate::check::env::Def) -> (Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>) {
    let (refs, locals) = run_to_end(fold_job(def_clauses(d), (Array::new(), Array::new()), {
        let sk = sk.clone();
        let d = d.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>), crate::syntax::FnClause)| {
            let sk = sk.clone();
            let d = d.clone();
            entered(once_job(move || {
                let (rs, ls) = p0;
                let c = p1;
                call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_30977: Map<Text, Rel>| call_then(start_body_spots(c.body.clone(), clause_base_30977), move |body_spots_30958: Array<Spot>| {
                    let spots = body_spots_30958;
                    call_then(start_spots_refs(sk.clone(), d.clone(), spots.clone(), rs.clone()), move |spots_refs_31009: Array<Text>| prism_rtl::Turn::Finished((spots_refs_31009, fold(&spots, &ls, &(|a2: &Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>, sp: &Spot| append(a2, &spot_local(&d, sp)))))))
                }))
            }))
        }) as Rc<dyn Fn(((Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>), crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>)>>>
    }));
    (d.qk.clone(), refs.clone(), locals.clone())
}

/// The step machine of `DefWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
/// ```
pub struct DefWalk {
    pub sk: Shrink,
    pub d: crate::check::env::Def,
}

impl prism_rtl::Job<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>)> for DefWalk {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>)> {
        let sk = &self.sk;
        let d = &self.d;
        let d = d.clone();
        let sk = sk.clone();
        call_value(fold_job(def_clauses(&d), (Array::new(), Array::new()), {
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): ((Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>), crate::syntax::FnClause)| {
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let (rs, ls) = p0;
                    let c = p1;
                    call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_30977: Map<Text, Rel>| call_then(start_body_spots(c.body.clone(), clause_base_30977), move |body_spots_30958: Array<Spot>| {
                        let spots = body_spots_30958;
                        call_then(start_spots_refs(sk.clone(), d.clone(), spots.clone(), rs.clone()), move |spots_refs_31009: Array<Text>| prism_rtl::Turn::Finished((spots_refs_31009, fold(&spots, &ls, &(|a2: &Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>, sp: &Spot| append(a2, &spot_local(&d, sp)))))))
                    }))
                }))
            }) as Rc<dyn Fn(((Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>), crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>)>>>
        }), move |fold_30884: (Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>)| {
            let (refs, locals) = fold_30884;
            prism_rtl::Turn::Finished((d.qk.clone(), refs.clone(), locals.clone()))
        })
    }
}

/// `Start DefWalk, x`: what the function value is when passed to `@Run`.
pub fn start_def_walk(sk: Shrink, d: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)>)>> {
    Rc::new(DefWalk { sk, d })
}

/// ```prism
/// SpotLocal: fn Def, Spot -> [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]
/// ```
pub fn spot_local(d: &crate::check::env::Def, sp: &Spot) -> Array<(crate::check::env::Def, Text, Text, Map<Text, Rel>, Option<crate::syntax::FnClause>, Option<crate::syntax::WidgetDecl>)> {
    match sp {
        Spot::SpotStmt(s, m) => match &s.kind {
            crate::syntax::StmtKind::SFn(f) => {
                let n = crate::check::env::def_name_text(&f.name);
                match get(m, &Text::from(format!("lfn:{}", &n))) {
                    Some(r) => Array::from(vec![(d.clone(), Text::from(format!("{}.{}", &d.file, &r.param)), n.clone(), m.clone(), Some(f.clone()), None)]),
                    None => Array::new(),
                }
            },
            crate::syntax::StmtKind::SWidget(w) => {
                let n = crate::check::env::sname_key(&w.name);
                match get(m, &Text::from(format!("lfn:{}", &n))) {
                    Some(r) => Array::from(vec![(d.clone(), Text::from(format!("{}.{}", &d.file, &r.param)), n.clone(), m.clone(), None, Some(w.clone()))]),
                    None => Array::new(),
                }
            },
            _ => Array::new(),
        },
        _ => Array::new(),
    }
}

/// ```prism
/// ?LocalTarget: fn Shrink, Def, Site -> ?Text
/// ```
pub fn local_target(sk: &Shrink, d: &crate::check::env::Def, site: &Site) -> Option<Text> {
    match get(&site.rels, &Text::from(format!("lfn:{}", &site.callee))) {
        Some(r) => Some(local_key(&site.callee, &or(&get(&sk.local_of, &d.qk), &d.qk), &Text::from(format!("{}.{}", &d.file, &r.param)))),
        None => None,
    }
}

/// ```prism
/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
/// ```
pub fn clause_base(sk: &Shrink, d: &crate::check::env::Def, c: &crate::syntax::FnClause) -> Map<Text, Rel> {
    match get(&sk.local_base, &d.qk) {
        Some(b) => param_rels_on(&b, &c.params),
        None => param_rels_on(&insert(&or(&get(&sk.seeds, &d.home), &Map::new()), &Text::lit("file:"), &Rel { param: d.file.clone(), strict: false }), &c.params),
    }
}

/// The step machine of `ClauseBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
/// ```
pub struct ClauseBase {
    pub sk: Shrink,
    pub d: crate::check::env::Def,
    pub c: crate::syntax::FnClause,
}

impl prism_rtl::Job<Map<Text, Rel>> for ClauseBase {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let sk = &self.sk;
        let d = &self.d;
        let c = &self.c;
        match get(&sk.local_base, &d.qk) {
            Some(b) => prism_rtl::Turn::More(Rc::new(ParamRelsOn { base: b.clone(), ps: c.params.clone() })),
            None => prism_rtl::Turn::More(Rc::new(ParamRelsOn { base: insert(&or(&get(&sk.seeds, &d.home), &Map::new()), &Text::lit("file:"), &Rel { param: d.file.clone(), strict: false }), ps: c.params.clone() })),
        }
    }
}

/// `Start ClauseBase, x`: what the function value is when passed to `@Run`.
pub fn start_clause_base(sk: Shrink, d: crate::check::env::Def, c: crate::syntax::FnClause) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(ClauseBase { sk, d, c })
}

/// ```prism
/// ?ResolveCallee: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_callee(g: &crate::check::env::G, m: &Text, n: &Text) -> Option<Text> {
    if is_op_text(n) {
        resolve_op(g, m, n)
    } else {
        match resolve_name(g, m, n) {
            Some(k) => Some(k.clone()),
            None => if crate::syntax::lexer::has_prefix(n, &Text::lit("@")) {
                resolve_name(g, m, &crate::syntax::lexer::after_first(n))
            } else {
                None
            },
        }
    }
}

/// ```prism
/// ?ResolveOp: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_op(g: &crate::check::env::G, m: &Text, op: &Text) -> Option<Text> {
    let (k_opt, _) = crate::check::env::resolve_value(g, m, &crate::syntax::SName { sigils: Text::lit(""), path_: Array::from(vec![op.clone()]), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
    k_opt.clone()
}

/// ```prism
/// IsOpText: fn Text -> Bool
/// ```
pub fn is_op_text(n: &Text) -> bool {
    (&len_text(n) > &Nat::from(0u32)) && !crate::syntax::lexer::fold_chars(n, &false, &(Rc::new(move |(p0, p1): (bool, Text)| once_job(move || {
        let seen = p0;
        let ch = p1;
        prism_rtl::Turn::Finished(((seen || crate::syntax::lexer::is_upper(&ch)) || crate::syntax::lexer::is_lower(&ch)) || (&ch == &Text::lit("_")))
    })) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// ```prism
/// ?ResolveName: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_name(g: &crate::check::env::G, m: &Text, n: &Text) -> Option<Text> {
    let marks_ = crate::check::types::marks_of(n);
    let path_ = split(&crate::syntax::lexer::drop_prefix(n, &marks_), &Text::lit("."));
    let (k_opt, _) = crate::check::env::resolve_value(g, m, &crate::syntax::SName { sigils: marks_.clone(), path_: path_.clone(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
    k_opt.clone()
}

/// ```prism
/// NamesInStmt: unbounded fn Stmt -> [Text]
/// ```
pub fn names_in_stmt(s: &crate::syntax::Stmt) -> Array<Text> {
    spots_names(&stmt_spots(s, &Map::new()))
}

/// The step machine of `NamesInStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamesInStmt: unbounded fn Stmt -> [Text]
/// ```
pub struct NamesInStmt {
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<Text>> for NamesInStmt {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s = &self.s;
        let s = s.clone();
        call_then(start_stmt_spots(s.clone(), Map::new()), move |stmt_spots_33480: Array<Spot>| prism_rtl::Turn::More(Rc::new(SpotsNames { spots: stmt_spots_33480 })))
    }
}

/// `Start NamesInStmt, x`: what the function value is when passed to `@Run`.
pub fn start_names_in_stmt(s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(NamesInStmt { s })
}

/// ```prism
/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
/// ```
pub fn sccs(keys_: &Array<Text>, refs: &Array<(Text, Array<Text>)>) -> Array<Array<Text>> {
    let adj = fold(refs, &Map::new(), &(|m: &Map<Text, Array<Text>>, (k, rs): &(Text, Array<Text>)| insert(m, k, rs)));
    let rev = fold(refs, &Map::new(), &(|m: &Map<Text, Array<Text>>, (k, rs): &(Text, Array<Text>)| fold(rs, m, &(|m2: &Map<Text, Array<Text>>, r: &Text| insert(m2, r, &push(&or(&get(m2, r), &Array::new()), k))))));
    let (_, post) = run_to_end(fold_job(keys_.clone(), (Map::new(), Array::new()), {
        let adj = adj.clone();
        Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
            let adj = adj.clone();
            entered(once_job(move || {
                let (seen, out) = p0;
                let k = p1;
                prism_rtl::Turn::More(Rc::new(PostVisit { adj: adj.clone(), seen: seen.clone(), out: out.clone(), k: k.clone() }))
            }))
        }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
    }));
    let (ignore2, comps) = run_to_end(fold_job(crate::check::types::reverse2(&post), (Map::new(), Array::new()), {
        let rev = rev.clone();
        Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Array<Text>>), Text)| {
            let rev = rev.clone();
            entered(once_job(move || {
                let (seen, acc) = p0;
                let k = p1;
                if crate::check::env::has_key(&seen, &k) {
                    prism_rtl::Turn::Finished((seen.clone(), acc.clone()))
                } else {
                    call_then(start_collect(rev.clone(), seen.clone(), Array::new(), k.clone()), move |collect_34322: (Map<Text, bool>, Array<Text>)| {
                        let (seen2, comp) = collect_34322;
                        prism_rtl::Turn::Finished((seen2.clone(), push(&acc, &comp)))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Map<Text, bool>, Array<Array<Text>>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Array<Text>>)>>>
    }));
    filter(&comps, &(|c: &Array<Text>| (&len(c) > &Nat::from(1u32)) || fold(c, &false, &(|self_: &bool, k: &Text| *self_ || crate::check::types::has_text(&or(&get(&adj, k), &Array::new()), k)))))
}

/// The step machine of `Sccs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
/// ```
pub struct Sccs {
    pub keys_: Array<Text>,
    pub refs: Array<(Text, Array<Text>)>,
}

impl prism_rtl::Job<Array<Array<Text>>> for Sccs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Array<Text>>> {
        let keys_ = &self.keys_;
        let refs = &self.refs;
        let adj = fold(refs, &Map::new(), &(|m: &Map<Text, Array<Text>>, (k, rs): &(Text, Array<Text>)| insert(m, k, rs)));
        let rev = fold(refs, &Map::new(), &(|m: &Map<Text, Array<Text>>, (k, rs): &(Text, Array<Text>)| fold(rs, m, &(|m2: &Map<Text, Array<Text>>, r: &Text| insert(m2, r, &push(&or(&get(m2, r), &Array::new()), k))))));
        let keys_ = keys_.clone();
        call_value(fold_job(keys_.clone(), (Map::new(), Array::new()), {
            let adj = adj.clone();
            Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                let adj = adj.clone();
                entered(once_job(move || {
                    let (seen, out) = p0;
                    let k = p1;
                    prism_rtl::Turn::More(Rc::new(PostVisit { adj: adj.clone(), seen: seen.clone(), out: out.clone(), k: k.clone() }))
                }))
            }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
        }), move |fold_34075: (Map<Text, bool>, Array<Text>)| {
            let (_, post) = fold_34075;
            call_value(fold_job(crate::check::types::reverse2(&post), (Map::new(), Array::new()), {
                let rev = rev.clone();
                Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Array<Text>>), Text)| {
                    let rev = rev.clone();
                    entered(once_job(move || {
                        let (seen, acc) = p0;
                        let k = p1;
                        if crate::check::env::has_key(&seen, &k) {
                            prism_rtl::Turn::Finished((seen.clone(), acc.clone()))
                        } else {
                            call_then(start_collect(rev.clone(), seen.clone(), Array::new(), k.clone()), move |collect_34322: (Map<Text, bool>, Array<Text>)| {
                                let (seen2, comp) = collect_34322;
                                prism_rtl::Turn::Finished((seen2.clone(), push(&acc, &comp)))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(((Map<Text, bool>, Array<Array<Text>>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Array<Text>>)>>>
            }), move |fold_34177: (Map<Text, bool>, Array<Array<Text>>)| {
                let (ignore2, comps) = fold_34177;
                prism_rtl::Turn::Finished(filter(&comps, &(|c: &Array<Text>| (&len(c) > &Nat::from(1u32)) || fold(c, &false, &(|self_: &bool, k: &Text| *self_ || crate::check::types::has_text(&or(&get(&adj, k), &Array::new()), k))))))
            })
        })
    }
}

/// `Start Sccs, x`: what the function value is when passed to `@Run`.
pub fn start_sccs(keys_: Array<Text>, refs: Array<(Text, Array<Text>)>) -> Rc<dyn prism_rtl::Job<Array<Array<Text>>>> {
    Rc::new(Sccs { keys_, refs })
}

/// ```prism
/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub fn post_visit(adj: &Map<Text, Array<Text>>, seen: &Map<Text, bool>, out: &Array<Text>, k: &Text) -> (Map<Text, bool>, Array<Text>) {
    if crate::check::env::has_key(seen, k) {
        (seen.clone(), out.clone())
    } else {
        {
            let (seen2, out2) = run_to_end(fold_job(or(&get(adj, k), &Array::new()), (insert(seen, k, &true), out.clone()), {
                let adj = adj.clone();
                Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                    let adj = adj.clone();
                    entered(once_job(move || {
                        let (s, o) = p0;
                        let n = p1;
                        prism_rtl::Turn::More(Rc::new(PostVisit { adj: adj.clone(), seen: s.clone(), out: o.clone(), k: n.clone() }))
                    }))
                }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
            }));
            (seen2.clone(), push(&out2, k))
        }
    }
}

/// The step machine of `PostVisit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub struct PostVisit {
    pub adj: Map<Text, Array<Text>>,
    pub seen: Map<Text, bool>,
    pub out: Array<Text>,
    pub k: Text,
}

impl prism_rtl::Job<(Map<Text, bool>, Array<Text>)> for PostVisit {
    fn cycle(&self) -> prism_rtl::Turn<(Map<Text, bool>, Array<Text>)> {
        let adj = &self.adj;
        let seen = &self.seen;
        let out = &self.out;
        let k = &self.k;
        if crate::check::env::has_key(seen, k) {
            prism_rtl::Turn::Finished((seen.clone(), out.clone()))
        } else {
            {
                let adj = adj.clone();
                let k = k.clone();
                let out = out.clone();
                let seen = seen.clone();
                call_value(fold_job(or(&get(&adj, &k), &Array::new()), (insert(&seen, &k, &true), out.clone()), {
                    let adj = adj.clone();
                    Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                        let adj = adj.clone();
                        entered(once_job(move || {
                            let (s, o) = p0;
                            let n = p1;
                            prism_rtl::Turn::More(Rc::new(PostVisit { adj: adj.clone(), seen: s.clone(), out: o.clone(), k: n.clone() }))
                        }))
                    }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
                }), move |fold_34706: (Map<Text, bool>, Array<Text>)| {
                    let (seen2, out2) = fold_34706;
                    prism_rtl::Turn::Finished((seen2.clone(), push(&out2, &k)))
                })
            }
        }
    }
}

/// `Start PostVisit, x`: what the function value is when passed to `@Run`.
pub fn start_post_visit(adj: Map<Text, Array<Text>>, seen: Map<Text, bool>, out: Array<Text>, k: Text) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>> {
    Rc::new(PostVisit { adj, seen, out, k })
}

/// ```prism
/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub fn collect(rev: &Map<Text, Array<Text>>, seen: &Map<Text, bool>, comp: &Array<Text>, k: &Text) -> (Map<Text, bool>, Array<Text>) {
    if crate::check::env::has_key(seen, k) {
        (seen.clone(), comp.clone())
    } else {
        run_to_end(fold_job(or(&get(rev, k), &Array::new()), (insert(seen, k, &true), push(comp, k)), {
            let rev = rev.clone();
            Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                let rev = rev.clone();
                entered(once_job(move || {
                    let (s, c) = p0;
                    let n = p1;
                    prism_rtl::Turn::More(Rc::new(Collect { rev: rev.clone(), seen: s.clone(), comp: c.clone(), k: n.clone() }))
                }))
            }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
        }))
    }
}

/// The step machine of `Collect`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub struct Collect {
    pub rev: Map<Text, Array<Text>>,
    pub seen: Map<Text, bool>,
    pub comp: Array<Text>,
    pub k: Text,
}

impl prism_rtl::Job<(Map<Text, bool>, Array<Text>)> for Collect {
    fn cycle(&self) -> prism_rtl::Turn<(Map<Text, bool>, Array<Text>)> {
        let rev = &self.rev;
        let seen = &self.seen;
        let comp = &self.comp;
        let k = &self.k;
        if crate::check::env::has_key(seen, k) {
            prism_rtl::Turn::Finished((seen.clone(), comp.clone()))
        } else {
            fold_job(or(&get(rev, k), &Array::new()), (insert(seen, k, &true), push(comp, k)), {
                let rev = rev.clone();
                Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                    let rev = rev.clone();
                    entered(once_job(move || {
                        let (s, c) = p0;
                        let n = p1;
                        prism_rtl::Turn::More(Rc::new(Collect { rev: rev.clone(), seen: s.clone(), comp: c.clone(), k: n.clone() }))
                    }))
                }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
            }).cycle()
        }
    }
}

/// `Start Collect, x`: what the function value is when passed to `@Run`.
pub fn start_collect(rev: Map<Text, Array<Text>>, seen: Map<Text, bool>, comp: Array<Text>, k: Text) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>> {
    Rc::new(Collect { rev, seen, comp, k })
}

/// ```prism
/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
/// ```
pub fn shrink_component(sk: &Shrink, st: &crate::check::types::St, comp: &Array<Text>) -> crate::check::types::St {
    if fold(comp, &true, &(|ok: &bool, k: &Text| *ok && is_unbounded_key(&sk.g, &sig_key_of(sk, &or(&get(&sk.local_of, k), k))))) {
        st.clone()
    } else {
        {
            let graphs = run_to_end(fold_job(sk.fns.clone(), Array::new(), {
                let comp = comp.clone();
                let sk = sk.clone();
                Rc::new(move |(p0, p1): (Array<Sc>, crate::check::env::Def)| {
                    let comp = comp.clone();
                    let sk = sk.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let d = p1;
                        if crate::check::types::has_text(&comp, &d.qk) {
                            call_then(start_call_graphs(sk.clone(), d.clone(), comp.clone()), move |call_graphs_35621: Array<Sc>| prism_rtl::Turn::Finished(append(&acc, &call_graphs_35621)))
                        } else {
                            prism_rtl::Turn::Finished(acc.clone())
                        }
                    }))
                }) as Rc<dyn Fn((Array<Sc>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
            }));
            let closure_ = closure(&graphs);
            let bad = filter(&closure_, &(|sc: &Sc| ((&sc.caller == &sc.callee) && (&compose(sc, sc).edges == &sc.edges)) && !fold(&sc.edges, &false, &(|seen: &bool, (a, b, s): &(Nat, Nat, bool)| *seen || ((a == b) && *s)))));
            match index(&bad, &Nat::from(0u32)) {
                Some(sc) => {
                    let s2 = {
                        let mut this: crate::check::types::St = st.clone();
                        this.file = sc.file.clone();
                        this
                    };
                    let what = if &sc.arg == &Text::lit("") {
                        Text::lit("")
                    } else {
                        Text::from(format!(" on `{}`", &sc.arg))
                    };
                    let st3 = crate::check::types::err_fix(&s2, &Text::lit("may-not-end"), &sc.span, &Text::from(format!("`{}` calls {}{}, not smaller than what it was given", &shown_key(&sc.caller), &(if &sc.caller == &sc.callee {
                        Text::lit("itself")
                    } else {
                        Text::from(format!("`{}`", &shown_key(&sc.callee)))
                    }), &what)), &Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle's functions `unbounded fn`"));
                    {
                        let mut this: crate::check::types::St = st3.clone();
                        this.file = st.file.clone();
                        this
                    }
                },
                None => st.clone(),
            }
        }
    }
}

/// The step machine of `ShrinkComponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
/// ```
pub struct ShrinkComponent {
    pub sk: Shrink,
    pub st: crate::check::types::St,
    pub comp: Array<Text>,
}

impl prism_rtl::Job<crate::check::types::St> for ShrinkComponent {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let sk = &self.sk;
        let st = &self.st;
        let comp = &self.comp;
        if fold(comp, &true, &(|ok: &bool, k: &Text| *ok && is_unbounded_key(&sk.g, &sig_key_of(sk, &or(&get(&sk.local_of, k), k))))) {
            prism_rtl::Turn::Finished(st.clone())
        } else {
            {
                let comp = comp.clone();
                let sk = sk.clone();
                let st = st.clone();
                call_value(fold_job(sk.fns.clone(), Array::new(), {
                    let comp = comp.clone();
                    let sk = sk.clone();
                    Rc::new(move |(p0, p1): (Array<Sc>, crate::check::env::Def)| {
                        let comp = comp.clone();
                        let sk = sk.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let d = p1;
                            if crate::check::types::has_text(&comp, &d.qk) {
                                call_then(start_call_graphs(sk.clone(), d.clone(), comp.clone()), move |call_graphs_35621: Array<Sc>| prism_rtl::Turn::Finished(append(&acc, &call_graphs_35621)))
                            } else {
                                prism_rtl::Turn::Finished(acc.clone())
                            }
                        }))
                    }) as Rc<dyn Fn((Array<Sc>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
                }), move |fold_35556: Array<Sc>| {
                    let graphs = fold_35556;
                    call_then(start_closure(graphs.clone()), move |closure_35677: Array<Sc>| {
                        let closure_ = closure_35677;
                        let bad = filter(&closure_, &(|sc: &Sc| ((&sc.caller == &sc.callee) && (&compose(sc, sc).edges == &sc.edges)) && !fold(&sc.edges, &false, &(|seen: &bool, (a, b, s): &(Nat, Nat, bool)| *seen || ((a == b) && *s)))));
                        match index(&bad, &Nat::from(0u32)) {
                            Some(sc) => {
                                let s2 = {
                                    let mut this: crate::check::types::St = st.clone();
                                    this.file = sc.file.clone();
                                    this
                                };
                                let what = if &sc.arg == &Text::lit("") {
                                    Text::lit("")
                                } else {
                                    Text::from(format!(" on `{}`", &sc.arg))
                                };
                                let st3 = crate::check::types::err_fix(&s2, &Text::lit("may-not-end"), &sc.span, &Text::from(format!("`{}` calls {}{}, not smaller than what it was given", &shown_key(&sc.caller), &(if &sc.caller == &sc.callee {
                                    Text::lit("itself")
                                } else {
                                    Text::from(format!("`{}`", &shown_key(&sc.callee)))
                                }), &what)), &Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle's functions `unbounded fn`"));
                                prism_rtl::Turn::Finished({
                                    let mut this: crate::check::types::St = st3.clone();
                                    this.file = st.file.clone();
                                    this
                                })
                            },
                            None => prism_rtl::Turn::Finished(st.clone()),
                        }
                    })
                })
            }
        }
    }
}

/// `Start ShrinkComponent, x`: what the function value is when passed to `@Run`.
pub fn start_shrink_component(sk: Shrink, st: crate::check::types::St, comp: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ShrinkComponent { sk, st, comp })
}

/// ```prism
/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
/// ```
pub fn call_graphs(sk: &Shrink, d: &crate::check::env::Def, comp: &Array<Text>) -> Array<Sc> {
    run_to_end(fold_job(def_clauses(d), Array::new(), {
        let sk = sk.clone();
        let d = d.clone();
        let comp = comp.clone();
        Rc::new(move |(p0, p1): (Array<Sc>, crate::syntax::FnClause)| {
            let sk = sk.clone();
            let d = d.clone();
            let comp = comp.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                call_then(start_clause_graphs(sk.clone(), d.clone(), c.clone(), comp.clone()), move |clause_graphs_36739: Array<Sc>| prism_rtl::Turn::Finished(append(&acc, &clause_graphs_36739)))
            }))
        }) as Rc<dyn Fn((Array<Sc>, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
    }))
}

/// The step machine of `CallGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
/// ```
pub struct CallGraphs {
    pub sk: Shrink,
    pub d: crate::check::env::Def,
    pub comp: Array<Text>,
}

impl prism_rtl::Job<Array<Sc>> for CallGraphs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Sc>> {
        let sk = &self.sk;
        let d = &self.d;
        let comp = &self.comp;
        fold_job(def_clauses(d), Array::new(), {
            let sk = sk.clone();
            let d = d.clone();
            let comp = comp.clone();
            Rc::new(move |(p0, p1): (Array<Sc>, crate::syntax::FnClause)| {
                let sk = sk.clone();
                let d = d.clone();
                let comp = comp.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let c = p1;
                    call_then(start_clause_graphs(sk.clone(), d.clone(), c.clone(), comp.clone()), move |clause_graphs_36739: Array<Sc>| prism_rtl::Turn::Finished(append(&acc, &clause_graphs_36739)))
                }))
            }) as Rc<dyn Fn((Array<Sc>, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
        }).cycle()
    }
}

/// `Start CallGraphs, x`: what the function value is when passed to `@Run`.
pub fn start_call_graphs(sk: Shrink, d: crate::check::env::Def, comp: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Sc>>> {
    Rc::new(CallGraphs { sk, d, comp })
}

/// ```prism
/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
/// ```
pub fn clause_graphs(sk: &Shrink, d: &crate::check::env::Def, c: &crate::syntax::FnClause, comp: &Array<Text>) -> Array<Sc> {
    let base = clause_base(sk, d, c);
    let rels = summary_seeds(sk, d, &body_spots(&c.body, &base), &base);
    run_to_end(fold_job(body_sites(&c.body, &rels), Array::new(), {
        let sk = sk.clone();
        let d = d.clone();
        let comp = comp.clone();
        Rc::new(move |(p0, p1): (Array<Sc>, Site)| {
            let sk = sk.clone();
            let d = d.clone();
            let comp = comp.clone();
            entered(once_job(move || {
                let acc = p0;
                let site = p1;
                match local_target(&sk, &d, &site) {
                    Some(t) => if crate::check::types::has_text(&comp, &t) {
                        call_then(start_site_graph(sk.clone(), d.clone(), site.clone(), t.clone()), move |site_graph_37097: Sc| prism_rtl::Turn::Finished(push(&acc, &site_graph_37097)))
                    } else {
                        prism_rtl::Turn::Finished(acc.clone())
                    },
                    None => if is_local(&site.rels, &site.callee) || crate::check::env::has_key(&sk.local_of, &d.qk) {
                        prism_rtl::Turn::Finished(acc.clone())
                    } else {
                        match resolve_callee(&sk.g, &d.home, &site.callee) {
                            Some(k) => call_then(start_dispatch_targets(sk.clone(), d.clone(), site.clone(), k.clone()), move |dispatch_targets_37319: Array<Text>| fold_job(dispatch_targets_37319, acc.clone(), {
                                let comp = comp.clone();
                                let sk = sk.clone();
                                let d = d.clone();
                                let site = site.clone();
                                Rc::new(move |(p0, p1): (Array<Sc>, Text)| {
                                    let comp = comp.clone();
                                    let sk = sk.clone();
                                    let d = d.clone();
                                    let site = site.clone();
                                    entered(once_job(move || {
                                        let acc2 = p0;
                                        let t = p1;
                                        if crate::check::types::has_text(&comp, &t) {
                                            call_then(start_site_graph(sk.clone(), d.clone(), site.clone(), t.clone()), move |site_graph_37400: Sc| prism_rtl::Turn::Finished(push(&acc2, &site_graph_37400)))
                                        } else {
                                            prism_rtl::Turn::Finished(acc2.clone())
                                        }
                                    }))
                                }) as Rc<dyn Fn((Array<Sc>, Text)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
                            }).cycle()),
                            None => prism_rtl::Turn::Finished(acc.clone()),
                        }
                    },
                }
            }))
        }) as Rc<dyn Fn((Array<Sc>, Site)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
    }))
}

/// The step machine of `ClauseGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
/// ```
pub struct ClauseGraphs {
    pub sk: Shrink,
    pub d: crate::check::env::Def,
    pub c: crate::syntax::FnClause,
    pub comp: Array<Text>,
}

impl prism_rtl::Job<Array<Sc>> for ClauseGraphs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Sc>> {
        let sk = &self.sk;
        let d = &self.d;
        let c = &self.c;
        let comp = &self.comp;
        let c = c.clone();
        let comp = comp.clone();
        let d = d.clone();
        let sk = sk.clone();
        call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_36881: Map<Text, Rel>| {
            let base = clause_base_36881;
            call_then(start_body_spots(c.body.clone(), base.clone()), move |body_spots_36937: Array<Spot>| call_then(start_summary_seeds(sk.clone(), d.clone(), body_spots_36937, base.clone()), move |summary_seeds_36916: Map<Text, Rel>| {
                let rels = summary_seeds_36916;
                call_then(start_body_sites(c.body.clone(), rels.clone()), move |body_sites_36977: Array<Site>| fold_job(body_sites_36977, Array::new(), {
                    let sk = sk.clone();
                    let d = d.clone();
                    let comp = comp.clone();
                    Rc::new(move |(p0, p1): (Array<Sc>, Site)| {
                        let sk = sk.clone();
                        let d = d.clone();
                        let comp = comp.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let site = p1;
                            match local_target(&sk, &d, &site) {
                                Some(t) => if crate::check::types::has_text(&comp, &t) {
                                    call_then(start_site_graph(sk.clone(), d.clone(), site.clone(), t.clone()), move |site_graph_37097: Sc| prism_rtl::Turn::Finished(push(&acc, &site_graph_37097)))
                                } else {
                                    prism_rtl::Turn::Finished(acc.clone())
                                },
                                None => if is_local(&site.rels, &site.callee) || crate::check::env::has_key(&sk.local_of, &d.qk) {
                                    prism_rtl::Turn::Finished(acc.clone())
                                } else {
                                    match resolve_callee(&sk.g, &d.home, &site.callee) {
                                        Some(k) => call_then(start_dispatch_targets(sk.clone(), d.clone(), site.clone(), k.clone()), move |dispatch_targets_37319: Array<Text>| fold_job(dispatch_targets_37319, acc.clone(), {
                                            let comp = comp.clone();
                                            let sk = sk.clone();
                                            let d = d.clone();
                                            let site = site.clone();
                                            Rc::new(move |(p0, p1): (Array<Sc>, Text)| {
                                                let comp = comp.clone();
                                                let sk = sk.clone();
                                                let d = d.clone();
                                                let site = site.clone();
                                                entered(once_job(move || {
                                                    let acc2 = p0;
                                                    let t = p1;
                                                    if crate::check::types::has_text(&comp, &t) {
                                                        call_then(start_site_graph(sk.clone(), d.clone(), site.clone(), t.clone()), move |site_graph_37400: Sc| prism_rtl::Turn::Finished(push(&acc2, &site_graph_37400)))
                                                    } else {
                                                        prism_rtl::Turn::Finished(acc2.clone())
                                                    }
                                                }))
                                            }) as Rc<dyn Fn((Array<Sc>, Text)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
                                        }).cycle()),
                                        None => prism_rtl::Turn::Finished(acc.clone()),
                                    }
                                },
                            }
                        }))
                    }) as Rc<dyn Fn((Array<Sc>, Site)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
                }).cycle())
            }))
        })
    }
}

/// `Start ClauseGraphs, x`: what the function value is when passed to `@Run`.
pub fn start_clause_graphs(sk: Shrink, d: crate::check::env::Def, c: crate::syntax::FnClause, comp: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Sc>>> {
    Rc::new(ClauseGraphs { sk, d, c, comp })
}

/// ```prism
/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
/// ```
pub fn site_graph(sk: &Shrink, d: &crate::check::env::Def, site: &Site, k: &Text) -> Sc {
    let edges = run_to_end(fold_job(arg_slots(sk, &site.args, k), Array::new(), {
        let site = site.clone();
        Rc::new(move |(p0, p1): (Array<(Nat, Nat, bool)>, (Nat, crate::syntax::Arg))| {
            let site = site.clone();
            entered(once_job(move || {
                let es = p0;
                let (j, a) = p1;
                call_then(start_rel_of(site.rels.clone(), a.value.clone()), move |rel_of_37738: Option<Rel>| match rel_of_37738 {
                    Some(r) => prism_rtl::Turn::Finished(push(&es, &(r.param.clone(), j.clone(), r.strict))),
                    None => prism_rtl::Turn::Finished(es.clone()),
                })
            }))
        }) as Rc<dyn Fn((Array<(Nat, Nat, bool)>, (Nat, crate::syntax::Arg))) -> Rc<dyn prism_rtl::Job<Array<(Nat, Nat, bool)>>>>
    }));
    let arg_text = match index(&site.args, &Nat::from(0u32)) {
        Some(a) => expr_name(&a.value),
        None => Text::lit(""),
    };
    Sc { caller: d.qk.clone(), callee: k.clone(), edges: edges.clone(), span: site.span.clone(), file: d.file.clone(), arg: arg_text.clone() }
}

/// The step machine of `SiteGraph`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
/// ```
pub struct SiteGraph {
    pub sk: Shrink,
    pub d: crate::check::env::Def,
    pub site: Site,
    pub k: Text,
}

impl prism_rtl::Job<Sc> for SiteGraph {
    fn cycle(&self) -> prism_rtl::Turn<Sc> {
        let sk = &self.sk;
        let d = &self.d;
        let site = &self.site;
        let k = &self.k;
        let d = d.clone();
        let k = k.clone();
        let site = site.clone();
        let sk = sk.clone();
        call_then(start_arg_slots(sk.clone(), site.args.clone(), k.clone()), move |arg_slots_37682: Array<(Nat, crate::syntax::Arg)>| call_value(fold_job(arg_slots_37682, Array::new(), {
            let site = site.clone();
            Rc::new(move |(p0, p1): (Array<(Nat, Nat, bool)>, (Nat, crate::syntax::Arg))| {
                let site = site.clone();
                entered(once_job(move || {
                    let es = p0;
                    let (j, a) = p1;
                    call_then(start_rel_of(site.rels.clone(), a.value.clone()), move |rel_of_37738: Option<Rel>| match rel_of_37738 {
                        Some(r) => prism_rtl::Turn::Finished(push(&es, &(r.param.clone(), j.clone(), r.strict))),
                        None => prism_rtl::Turn::Finished(es.clone()),
                    })
                }))
            }) as Rc<dyn Fn((Array<(Nat, Nat, bool)>, (Nat, crate::syntax::Arg))) -> Rc<dyn prism_rtl::Job<Array<(Nat, Nat, bool)>>>>
        }), move |fold_37676: Array<(Nat, Nat, bool)>| {
            let edges = fold_37676;
            let arg_text = match index(&site.args, &Nat::from(0u32)) {
                Some(a) => expr_name(&a.value),
                None => Text::lit(""),
            };
            prism_rtl::Turn::Finished(Sc { caller: d.qk.clone(), callee: k.clone(), edges: edges.clone(), span: site.span.clone(), file: d.file.clone(), arg: arg_text.clone() })
        }))
    }
}

/// `Start SiteGraph, x`: what the function value is when passed to `@Run`.
pub fn start_site_graph(sk: Shrink, d: crate::check::env::Def, site: Site, k: Text) -> Rc<dyn prism_rtl::Job<Sc>> {
    Rc::new(SiteGraph { sk, d, site, k })
}

/// ```prism
/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
/// ```
pub fn arg_slots(sk: &Shrink, args: &Array<crate::syntax::Arg>, k: &Text) -> Array<(Nat, crate::syntax::Arg)> {
    let (_, out) = run_to_end(fold_job(args.clone(), (Nat::from(0u32), Array::new()), {
        let sk = sk.clone();
        let k = k.clone();
        Rc::new(move |(p0, p1): ((Nat, Array<(Nat, crate::syntax::Arg)>), crate::syntax::Arg)| {
            let sk = sk.clone();
            let k = k.clone();
            entered(once_job(move || {
                let (pos, acc) = p0;
                let a = p1;
                match &a.name {
                    None => prism_rtl::Turn::Finished((&pos + &Nat::from(1u32), push(&acc, &(pos.clone(), a.clone())))),
                    Some(id) => {
                        let id = id.clone();
                        call_then(start_param_named(sk.clone(), k.clone(), id.name.clone()), move |param_named_38552: Option<Nat>| match param_named_38552 {
                            Some(j) => prism_rtl::Turn::Finished((pos.clone(), push(&acc, &(j.clone(), a.clone())))),
                            None => prism_rtl::Turn::Finished((pos.clone(), acc.clone())),
                        })
                    },
                }
            }))
        }) as Rc<dyn Fn(((Nat, Array<(Nat, crate::syntax::Arg)>), crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<(Nat, Array<(Nat, crate::syntax::Arg)>)>>>
    }));
    out.clone()
}

/// The step machine of `ArgSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
/// ```
pub struct ArgSlots {
    pub sk: Shrink,
    pub args: Array<crate::syntax::Arg>,
    pub k: Text,
}

impl prism_rtl::Job<Array<(Nat, crate::syntax::Arg)>> for ArgSlots {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Nat, crate::syntax::Arg)>> {
        let sk = &self.sk;
        let args = &self.args;
        let k = &self.k;
        let args = args.clone();
        let k = k.clone();
        let sk = sk.clone();
        call_value(fold_job(args.clone(), (Nat::from(0u32), Array::new()), {
            let sk = sk.clone();
            let k = k.clone();
            Rc::new(move |(p0, p1): ((Nat, Array<(Nat, crate::syntax::Arg)>), crate::syntax::Arg)| {
                let sk = sk.clone();
                let k = k.clone();
                entered(once_job(move || {
                    let (pos, acc) = p0;
                    let a = p1;
                    match &a.name {
                        None => prism_rtl::Turn::Finished((&pos + &Nat::from(1u32), push(&acc, &(pos.clone(), a.clone())))),
                        Some(id) => {
                            let id = id.clone();
                            call_then(start_param_named(sk.clone(), k.clone(), id.name.clone()), move |param_named_38552: Option<Nat>| match param_named_38552 {
                                Some(j) => prism_rtl::Turn::Finished((pos.clone(), push(&acc, &(j.clone(), a.clone())))),
                                None => prism_rtl::Turn::Finished((pos.clone(), acc.clone())),
                            })
                        },
                    }
                }))
            }) as Rc<dyn Fn(((Nat, Array<(Nat, crate::syntax::Arg)>), crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<(Nat, Array<(Nat, crate::syntax::Arg)>)>>>
        }), move |fold_38425: (Nat, Array<(Nat, crate::syntax::Arg)>)| {
            let (_, out) = fold_38425;
            prism_rtl::Turn::Finished(out.clone())
        })
    }
}

/// `Start ArgSlots, x`: what the function value is when passed to `@Run`.
pub fn start_arg_slots(sk: Shrink, args: Array<crate::syntax::Arg>, k: Text) -> Rc<dyn prism_rtl::Job<Array<(Nat, crate::syntax::Arg)>>> {
    Rc::new(ArgSlots { sk, args, k })
}

/// ```prism
/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
/// ```
pub fn param_named(sk: &Shrink, k: &Text, name: &Text) -> Option<Nat> {
    let clauses = def_clauses(&or(&get(&sk.by_key, k), &crate::check::env::dummy_def()));
    if name == &Text::lit("#body") {
        match index(&clauses, &Nat::from(0u32)) {
            Some(c) => if &len(&c.params) > &Nat::from(0u32) {
                Some(crate::syntax::lexer::dec(&len(&c.params)))
            } else {
                None
            },
            None => None,
        }
    } else {
        param_named_in(&clauses, name)
    }
}

/// The step machine of `ParamNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
/// ```
pub struct ParamNamed {
    pub sk: Shrink,
    pub k: Text,
    pub name: Text,
}

impl prism_rtl::Job<Option<Nat>> for ParamNamed {
    fn cycle(&self) -> prism_rtl::Turn<Option<Nat>> {
        let sk = &self.sk;
        let k = &self.k;
        let name = &self.name;
        let clauses = def_clauses(&or(&get(&sk.by_key, k), &crate::check::env::dummy_def()));
        if name == &Text::lit("#body") {
            match index(&clauses, &Nat::from(0u32)) {
                Some(c) => if &len(&c.params) > &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(Some(crate::syntax::lexer::dec(&len(&c.params))))
                } else {
                    prism_rtl::Turn::Finished(None)
                },
                None => prism_rtl::Turn::Finished(None),
            }
        } else {
            prism_rtl::Turn::Finished(param_named_in(&clauses, name))
        }
    }
}

/// `Start ParamNamed, x`: what the function value is when passed to `@Run`.
pub fn start_param_named(sk: Shrink, k: Text, name: Text) -> Rc<dyn prism_rtl::Job<Option<Nat>>> {
    Rc::new(ParamNamed { sk, k, name })
}

/// ```prism
/// ?ParamNamedIn: unbounded fn [FnClause], Text -> ?Nat
/// ```
pub fn param_named_in(clauses: &Array<crate::syntax::FnClause>, name: &Text) -> Option<Nat> {
    let found = run_to_end(fold_job(clauses.clone(), Array::new(), {
        let name = name.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::syntax::FnClause)| {
            let name = name.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                fold_job(crate::check::errors::range0(&len(&c.params)), acc.clone(), {
                    let c = c.clone();
                    let name = name.clone();
                    Rc::new(move |(p0, p1): (Array<Nat>, Nat)| {
                        let c = c.clone();
                        let name = name.clone();
                        entered(once_job(move || {
                            let a2 = p0;
                            let i = p1;
                            match index(&c.params, &i) {
                                Some(p_) => if (&param_name_of(&p_) == &name) && !crate::check::types::has_nat(&a2, &i) {
                                    prism_rtl::Turn::Finished(push(&a2, &i))
                                } else {
                                    prism_rtl::Turn::Finished(a2.clone())
                                },
                                None => prism_rtl::Turn::Finished(a2.clone()),
                            }
                        }))
                    }) as Rc<dyn Fn((Array<Nat>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    if &len(&found) == &Nat::from(1u32) { index(&found, &Nat::from(0u32)) } else { None }
}

/// ```prism
/// ParamNameOf: unbounded fn Pattern -> Text
/// ```
pub fn param_name_of(p_: &crate::syntax::Pattern_) -> Text {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => {
            let text = crate::check::env::sname_key(n);
            crate::syntax::lexer::drop_prefix(&text, &crate::check::types::marks_of(&text))
        },
        crate::syntax::PatternKind::PGroup(q) => param_name_of(&**q),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ExprName: fn Expr -> Text
/// ```
pub fn expr_name(e: &crate::syntax::Expr) -> Text {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => crate::check::env::sname_key(n),
        crate::syntax::ExprKind::EGroup(x) => expr_name(&**x),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
/// ```
pub fn param_rels_on(base: &Map<Text, Rel>, ps: &Array<crate::syntax::Pattern_>) -> Map<Text, Rel> {
    run_to_end(fold_job(crate::check::errors::range0(&len(ps)), hide(base, &patterns_names(ps)), {
        let ps = ps.clone();
        Rc::new(move |(p0, p1): (Map<Text, Rel>, Nat)| {
            let ps = ps.clone();
            entered(once_job(move || {
                let m = p0;
                let i = p1;
                match index(&ps, &i) {
                    Some(p_) => match &*p_.kind {
                        crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::Finished(insert(&m, &crate::check::env::sname_key(n), &Rel { param: i.clone(), strict: false })),
                        _ => call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_40325: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_40325, &m, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, &Rel { param: i.clone(), strict: true }))))),
                    },
                    None => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
    }))
}

/// The step machine of `ParamRelsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
/// ```
pub struct ParamRelsOn {
    pub base: Map<Text, Rel>,
    pub ps: Array<crate::syntax::Pattern_>,
}

impl prism_rtl::Job<Map<Text, Rel>> for ParamRelsOn {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let base = &self.base;
        let ps = &self.ps;
        let base = base.clone();
        let ps = ps.clone();
        call_then(start_patterns_names(ps.clone()), move |patterns_names_40168: Array<Text>| fold_job(crate::check::errors::range0(&len(&ps)), hide(&base, &patterns_names_40168), {
            let ps = ps.clone();
            Rc::new(move |(p0, p1): (Map<Text, Rel>, Nat)| {
                let ps = ps.clone();
                entered(once_job(move || {
                    let m = p0;
                    let i = p1;
                    match index(&ps, &i) {
                        Some(p_) => match &*p_.kind {
                            crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::Finished(insert(&m, &crate::check::env::sname_key(n), &Rel { param: i.clone(), strict: false })),
                            _ => call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_40325: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_40325, &m, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, &Rel { param: i.clone(), strict: true }))))),
                        },
                        None => prism_rtl::Turn::Finished(m.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
        }).cycle())
    }
}

/// `Start ParamRelsOn, x`: what the function value is when passed to `@Run`.
pub fn start_param_rels_on(base: Map<Text, Rel>, ps: Array<crate::syntax::Pattern_>) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(ParamRelsOn { base, ps })
}

/// ```prism
/// Hide: fn (Text ==> Rel), [Text] -> (Text ==> Rel)
/// ```
pub fn hide(m: &Map<Text, Rel>, names: &Array<Text>) -> Map<Text, Rel> {
    fold(names, m, &(|m2: &Map<Text, Rel>, n: &Text| insert(&remove(&remove(&remove(&remove(m2, n), &Text::from(format!("ne:{}", n))), &Text::from(format!("lamlet:{}", n))), &Text::from(format!("lfn:{}", n))), &Text::from(format!("local:{}", n)), &no_rel())))
}

/// ```prism
/// let noRel
/// ```
pub fn no_rel() -> Rel {
    Rel { param: Nat::from(0u32), strict: false }
}

/// ```prism
/// IsLocal: fn (Text ==> Rel), Text -> Bool
/// ```
pub fn is_local(m: &Map<Text, Rel>, n: &Text) -> bool {
    crate::check::env::has_key(m, &Text::from(format!("local:{}", n)))
}

/// ```prism
/// PreIs: fn (Text ==> Rel), Text, Text -> Bool
/// ```
pub fn pre_is(m: &Map<Text, Rel>, n: &Text, bare: &Text) -> bool {
    (((n == bare) || (n == &Text::from(format!("Prelude.{}", bare)))) && crate::check::env::has_key(m, &Text::from(format!("pre:{}", n)))) && !is_local(m, n)
}

/// ```prism
/// let preludeNames
/// ```
pub fn prelude_names() -> Array<Text> {
    Array::from(vec![Text::lit("Drop"), Text::lit("Take"), Text::lit("Filter"), Text::lit("Remove"), Text::lit("Min"), Text::lit("Values"), Text::lit("Keys"), Text::lit("?Step"), Text::lit("Fold"), Text::lit("Each"), Text::lit("Push"), Text::lit("Insert"), Text::lit("Append"), Text::lit("Freeze"), Text::lit("-?"), Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")])
}

/// ```prism
/// PreludeSeeds: fn G, Text -> (Text ==> Rel)
/// ```
pub fn prelude_seeds(g: &crate::check::env::G, h: &Text) -> Map<Text, Rel> {
    fold(&prelude_names(), &Map::new(), &(|m: &Map<Text, Rel>, n: &Text| {
        let q = Text::from(format!("Prelude.{}", n));
        if !is_prelude_key(g, &q) {
            m.clone()
        } else {
            fold(&Array::from(vec![n.clone(), q.clone()]), m, &(|m2: &Map<Text, Rel>, sp: &Text| if &resolve_callee(g, h, sp) == &Some(q.clone()) {
                insert(m2, &Text::from(format!("pre:{}", sp)), &no_rel())
            } else {
                m2.clone()
            }))
        }
    }))
}

/// ```prism
/// IsPreludeKey: fn G, Text -> Bool
/// ```
pub fn is_prelude_key(g: &crate::check::env::G, q: &Text) -> bool {
    match get(&g.vals, q) {
        Some(v_) => (crate::syntax::lexer::has_prefix(q, &Text::lit("Prelude.")) && (&v_.home == &Text::lit("Prelude"))) && (&v_.file >= &g.prelude_from),
        None => false,
    }
}

/// ```prism
/// BlockRels: unbounded fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn block_rels(stmts: &Array<crate::syntax::Stmt>, m: &Map<Text, Rel>) -> Map<Text, Rel> {
    run_to_end(fold_job(stmts.clone(), local_fn_marks(stmts, &hide(m, &stmts_binders(stmts))), Rc::new(move |(p0, p1): (Map<Text, Rel>, crate::syntax::Stmt)| entered(once_job(move || {
        let m2 = p0;
        let s = p1;
        call_then(start_stmt_rels(s.clone(), m2.clone()), move |stmt_rels_43878: Map<Text, Rel>| prism_rtl::Turn::Finished(crate::check::passes::lam_let_rels(&s, &stmt_rels_43878)))
    }))) as Rc<dyn Fn((Map<Text, Rel>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>))
}

/// The step machine of `BlockRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockRels: unbounded fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct BlockRels {
    pub stmts: Array<crate::syntax::Stmt>,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Map<Text, Rel>> for BlockRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let stmts = &self.stmts;
        let m = &self.m;
        let m = m.clone();
        let stmts = stmts.clone();
        call_then(start_stmts_binders(stmts.clone()), move |stmts_binders_43831: Array<Text>| fold_job(stmts.clone(), local_fn_marks(&stmts, &hide(&m, &stmts_binders_43831)), Rc::new(move |(p0, p1): (Map<Text, Rel>, crate::syntax::Stmt)| entered(once_job(move || {
            let m2 = p0;
            let s = p1;
            call_then(start_stmt_rels(s.clone(), m2.clone()), move |stmt_rels_43878: Map<Text, Rel>| prism_rtl::Turn::Finished(crate::check::passes::lam_let_rels(&s, &stmt_rels_43878)))
        }))) as Rc<dyn Fn((Map<Text, Rel>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>).cycle())
    }
}

/// `Start BlockRels, x`: what the function value is when passed to `@Run`.
pub fn start_block_rels(stmts: Array<crate::syntax::Stmt>, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(BlockRels { stmts, m })
}

/// ```prism
/// LocalFnMarks: fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn local_fn_marks(stmts: &Array<crate::syntax::Stmt>, m: &Map<Text, Rel>) -> Map<Text, Rel> {
    fold(stmts, m, &(|m2: &Map<Text, Rel>, s: &crate::syntax::Stmt| {
        let n_opt = match &s.kind {
            crate::syntax::StmtKind::SFn(f) => Some(crate::check::env::def_name_text(&f.name)),
            crate::syntax::StmtKind::SWidget(w) => Some(crate::check::env::sname_key(&w.name)),
            _ => None,
        };
        match &n_opt {
            Some(n) => if crate::check::env::has_key(m2, &Text::from(format!("lfn:{}", n))) {
                m2.clone()
            } else {
                insert(m2, &Text::from(format!("lfn:{}", n)), &Rel { param: s.span.start.clone(), strict: false })
            },
            None => m2.clone(),
        }
    }))
}

/// ```prism
/// StmtsBinders: unbounded fn [Stmt] -> [Text]
/// ```
pub fn stmts_binders(stmts: &Array<crate::syntax::Stmt>) -> Array<Text> {
    run_to_end(fold_job(stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| entered(once_job(move || {
        let acc = p0;
        let s = p1;
        match &s.kind {
            crate::syntax::StmtKind::SLet(p_, _, _) => {
                let p_ = p_.clone();
                call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_44552: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &pattern_names_44552)))
            },
            crate::syntax::StmtKind::SBind(p_, _, _) => {
                let p_ = p_.clone();
                call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_44614: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &pattern_names_44614)))
            },
            crate::syntax::StmtKind::SFn(f) => prism_rtl::Turn::Finished(crate::check::types::add_text(&acc, &crate::check::env::def_name_text(&f.name))),
            crate::syntax::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(crate::check::types::add_text(&acc, &crate::check::env::sname_key(&w.name))),
            _ => prism_rtl::Turn::Finished(acc.clone()),
        }
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `StmtsBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsBinders: unbounded fn [Stmt] -> [Text]
/// ```
pub struct StmtsBinders {
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<Text>> for StmtsBinders {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let stmts = &self.stmts;
        fold_job(stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| entered(once_job(move || {
            let acc = p0;
            let s = p1;
            match &s.kind {
                crate::syntax::StmtKind::SLet(p_, _, _) => {
                    let p_ = p_.clone();
                    call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_44552: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &pattern_names_44552)))
                },
                crate::syntax::StmtKind::SBind(p_, _, _) => {
                    let p_ = p_.clone();
                    call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_44614: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &pattern_names_44614)))
                },
                crate::syntax::StmtKind::SFn(f) => prism_rtl::Turn::Finished(crate::check::types::add_text(&acc, &crate::check::env::def_name_text(&f.name))),
                crate::syntax::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(crate::check::types::add_text(&acc, &crate::check::env::sname_key(&w.name))),
                _ => prism_rtl::Turn::Finished(acc.clone()),
            }
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
    }
}

/// `Start StmtsBinders, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_binders(stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(StmtsBinders { stmts })
}

/// ```prism
/// StmtRels: unbounded fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn stmt_rels(s: &crate::syntax::Stmt, m: &Map<Text, Rel>) -> Map<Text, Rel> {
    match &s.kind {
        crate::syntax::StmtKind::SLet(p_, _, e) => bind_rels(p_, e, m, &false),
        crate::syntax::StmtKind::SBind(p_, e, None) => bind_rels(p_, e, m, &true),
        _ => m.clone(),
    }
}

/// The step machine of `StmtRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtRels: unbounded fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct StmtRels {
    pub s: crate::syntax::Stmt,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Map<Text, Rel>> for StmtRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let s = &self.s;
        let m = &self.m;
        match &s.kind {
            crate::syntax::StmtKind::SLet(p_, _, e) => prism_rtl::Turn::More(Rc::new(BindRels { p_: p_.clone(), e: e.clone(), m: m.clone(), refutable: false })),
            crate::syntax::StmtKind::SBind(p_, e, None) => prism_rtl::Turn::More(Rc::new(BindRels { p_: p_.clone(), e: e.clone(), m: m.clone(), refutable: true })),
            _ => prism_rtl::Turn::Finished(m.clone()),
        }
    }
}

/// `Start StmtRels, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_rels(s: crate::syntax::Stmt, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(StmtRels { s, m })
}

/// ```prism
/// BindRels: unbounded fn Pattern, Expr, (Text ==> Rel), Bool -> (Text ==> Rel)
/// ```
pub fn bind_rels(p_: &crate::syntax::Pattern_, e: &crate::syntax::Expr, m: &Map<Text, Rel>, refutable: &bool) -> Map<Text, Rel> {
    let base_opt = rel_of(m, e);
    let dec_opt = decrement_of(m, e);
    let h = non_empty_rels(&hide(m, &crate::check::env::pattern_names(p_)), p_, e, refutable);
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => match &base_opt {
            Some(r) => insert(&h, &crate::check::env::sname_key(n), r),
            None => match &dec_opt {
                Some(r) => if *refutable { insert(&h, &crate::check::env::sname_key(n), r) } else { h.clone() },
                None => h.clone(),
            },
        },
        crate::syntax::PatternKind::PSigil(m45378_1_0, inner) if (m45378_1_0 == &Text::lit("?")) => match &dec_opt {
            Some(r) => fold(&crate::check::env::pattern_names(&**inner), &h, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, r))),
            None => match &base_opt {
                Some(r) => fold(&crate::check::env::pattern_names(&**inner), &h, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, &Rel { param: r.param.clone(), strict: true }))),
                None => h.clone(),
            },
        },
        _ => match &base_opt {
            Some(r) => fold(&crate::check::env::pattern_names(p_), &h, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, &Rel { param: r.param.clone(), strict: true }))),
            None => h.clone(),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BindRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindRels: unbounded fn Pattern, Expr, (Text ==> Rel), Bool -> (Text ==> Rel)
/// ```
pub struct BindRels {
    pub p_: crate::syntax::Pattern_,
    pub e: crate::syntax::Expr,
    pub m: Map<Text, Rel>,
    pub refutable: bool,
}

impl prism_rtl::Job<Map<Text, Rel>> for BindRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let p_ = &self.p_;
        let e = &self.e;
        let m = &self.m;
        let refutable = &self.refutable;
        let e = e.clone();
        let m = m.clone();
        let p_ = p_.clone();
        let refutable = *refutable;
        call_then(start_rel_of(m.clone(), e.clone()), move |rel_of_45260: Option<Rel>| {
            let base_opt = rel_of_45260;
            call_then(start_decrement_of(m.clone(), e.clone()), move |decrement_of_45287: Option<Rel>| {
                let dec_opt = decrement_of_45287;
                call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_45340: Array<Text>| call_then(start_non_empty_rels(hide(&m, &pattern_names_45340), p_.clone(), e.clone(), refutable), move |non_empty_rels_45317: Map<Text, Rel>| {
                    let h = non_empty_rels_45317;
                    match &*p_.kind {
                        crate::syntax::PatternKind::PName(n) => match &base_opt {
                            Some(r) => prism_rtl::Turn::Finished(insert(&h, &crate::check::env::sname_key(n), r)),
                            None => match &dec_opt {
                                Some(r) => if refutable {
                                    prism_rtl::Turn::Finished(insert(&h, &crate::check::env::sname_key(n), r))
                                } else {
                                    prism_rtl::Turn::Finished(h.clone())
                                },
                                None => prism_rtl::Turn::Finished(h.clone()),
                            },
                        },
                        crate::syntax::PatternKind::PSigil(m45378_1_0, inner) if (m45378_1_0 == &Text::lit("?")) => match &dec_opt {
                            Some(r) => {
                                let inner = (**inner).clone();
                                let r = r.clone();
                                call_then(crate::check::env::start_pattern_names(inner.clone()), move |pattern_names_45648: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_45648, &h, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, &r)))))
                            },
                            None => match &base_opt {
                                Some(r) => {
                                    let inner = (**inner).clone();
                                    let r = r.clone();
                                    call_then(crate::check::env::start_pattern_names(inner.clone()), move |pattern_names_45754: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_45754, &h, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, &Rel { param: r.param.clone(), strict: true })))))
                                },
                                None => prism_rtl::Turn::Finished(h.clone()),
                            },
                        },
                        _ => match &base_opt {
                            Some(r) => {
                                let r = r.clone();
                                call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_45911: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_45911, &h, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, &Rel { param: r.param.clone(), strict: true })))))
                            },
                            None => prism_rtl::Turn::Finished(h.clone()),
                        },
                        _ => unreachable!("no arm matched"),
                    }
                }))
            })
        })
    }
}

/// `Start BindRels, x`: what the function value is when passed to `@Run`.
pub fn start_bind_rels(p_: crate::syntax::Pattern_, e: crate::syntax::Expr, m: Map<Text, Rel>, refutable: bool) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(BindRels { p_, e, m, refutable })
}

/// ```prism
/// NonEmptyRels: unbounded fn (Text ==> Rel), Pattern, Expr, Bool -> (Text ==> Rel)
/// ```
pub fn non_empty_rels(m: &Map<Text, Rel>, p_: &crate::syntax::Pattern_, e: &crate::syntax::Expr, refutable: &bool) -> Map<Text, Rel> {
    if !*refutable {
        m.clone()
    } else {
        match non_empty_name(p_, e) {
            Some(n) => if crate::check::types::has_text(&crate::check::env::pattern_names(p_), &n) {
                m.clone()
            } else {
                insert(m, &Text::from(format!("ne:{}", &n)), &no_rel())
            },
            None => m.clone(),
        }
    }
}

/// The step machine of `NonEmptyRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NonEmptyRels: unbounded fn (Text ==> Rel), Pattern, Expr, Bool -> (Text ==> Rel)
/// ```
pub struct NonEmptyRels {
    pub m: Map<Text, Rel>,
    pub p_: crate::syntax::Pattern_,
    pub e: crate::syntax::Expr,
    pub refutable: bool,
}

impl prism_rtl::Job<Map<Text, Rel>> for NonEmptyRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let m = &self.m;
        let p_ = &self.p_;
        let e = &self.e;
        let refutable = &self.refutable;
        if !*refutable {
            prism_rtl::Turn::Finished(m.clone())
        } else {
            match non_empty_name(p_, e) {
                Some(n) => {
                    let m = m.clone();
                    let p_ = p_.clone();
                    call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_46447: Array<Text>| if crate::check::types::has_text(&pattern_names_46447, &n) {
                        prism_rtl::Turn::Finished(m.clone())
                    } else {
                        prism_rtl::Turn::Finished(insert(&m, &Text::from(format!("ne:{}", &n)), &no_rel()))
                    })
                },
                None => prism_rtl::Turn::Finished(m.clone()),
            }
        }
    }
}

/// `Start NonEmptyRels, x`: what the function value is when passed to `@Run`.
pub fn start_non_empty_rels(m: Map<Text, Rel>, p_: crate::syntax::Pattern_, e: crate::syntax::Expr, refutable: bool) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(NonEmptyRels { m, p_, e, refutable })
}

/// ```prism
/// ?NonEmptyName: fn Pattern, Expr -> ?Text
/// ```
pub fn non_empty_name(p_: &crate::syntax::Pattern_, e: &crate::syntax::Expr) -> Option<Text> {
    match &*e.kind {
        crate::syntax::ExprKind::EGroup(x) => non_empty_name(p_, &**x),
        crate::syntax::ExprKind::EIndex(r, _) => match &*p_.kind {
            crate::syntax::PatternKind::PSigil(m46647_0_0, _) if (m46647_0_0 == &Text::lit("?")) => name_of(&**r),
            crate::syntax::PatternKind::PGroup(q) => non_empty_name(&**q, e),
            _ => None,
            _ => unreachable!("no arm matched"),
        },
        crate::syntax::ExprKind::EName(n) => match &*p_.kind {
            crate::syntax::PatternKind::PArray(ps) => if &len(ps) > &Nat::from(0u32) { Some(crate::check::env::sname_key(n)) } else { None },
            crate::syntax::PatternKind::PGroup(q) => non_empty_name(&**q, e),
            _ => None,
        },
        _ => None,
    }
}

/// ```prism
/// ?NameOf: fn Expr -> ?Text
/// ```
pub fn name_of(e: &crate::syntax::Expr) -> Option<Text> {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => Some(crate::check::env::sname_key(n)),
        crate::syntax::ExprKind::EGroup(x) => name_of(&**x),
        _ => None,
    }
}

/// ```prism
/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn arm_pat_rels(s: &crate::syntax::Expr, a: &crate::syntax::Arm, m: &Map<Text, Rel>) -> Map<Text, Rel> {
    match &a.pattern {
        Some(p_) => bind_rels(p_, s, m, &true),
        None => m.clone(),
    }
}

/// The step machine of `ArmPatRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct ArmPatRels {
    pub s: crate::syntax::Expr,
    pub a: crate::syntax::Arm,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Map<Text, Rel>> for ArmPatRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let s = &self.s;
        let a = &self.a;
        let m = &self.m;
        match &a.pattern {
            Some(p_) => prism_rtl::Turn::More(Rc::new(BindRels { p_: p_.clone(), e: s.clone(), m: m.clone(), refutable: true })),
            None => prism_rtl::Turn::Finished(m.clone()),
        }
    }
}

/// `Start ArmPatRels, x`: what the function value is when passed to `@Run`.
pub fn start_arm_pat_rels(s: crate::syntax::Expr, a: crate::syntax::Arm, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(ArmPatRels { s, a, m })
}

/// ```prism
/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn cond_rels(c: &crate::syntax::Cond, m: &Map<Text, Rel>) -> Map<Text, Rel> {
    match c {
        crate::syntax::Cond::CondBind(p_, x, _) => bind_rels(p_, &**x, m, &true),
        crate::syntax::Cond::CondExpr(_) => m.clone(),
    }
}

/// The step machine of `CondRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct CondRels {
    pub c: crate::syntax::Cond,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Map<Text, Rel>> for CondRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let c = &self.c;
        let m = &self.m;
        match c {
            crate::syntax::Cond::CondBind(p_, x, _) => prism_rtl::Turn::More(Rc::new(BindRels { p_: p_.clone(), e: (**x).clone(), m: m.clone(), refutable: true })),
            crate::syntax::Cond::CondExpr(_) => prism_rtl::Turn::Finished(m.clone()),
        }
    }
}

/// `Start CondRels, x`: what the function value is when passed to `@Run`.
pub fn start_cond_rels(c: crate::syntax::Cond, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(CondRels { c, m })
}

/// ```prism
/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
/// ```
pub fn step_rels(m: &Map<Text, Rel>, coll: &crate::syntax::Expr, ps: &Array<crate::syntax::Pattern_>, at_: &Nat) -> Map<Text, Rel> {
    let h = hide(m, &run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
        let a = p0;
        let p_ = p1;
        call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_48136: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &pattern_names_48136)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)));
    match rel_of(m, coll) {
        Some(r) => run_to_end(fold_job(drop(ps, at_), h.clone(), {
            let r = r.clone();
            Rc::new(move |(p0, p1): (Map<Text, Rel>, crate::syntax::Pattern_)| {
                let r = r.clone();
                entered(once_job(move || {
                    let m2 = p0;
                    let p_ = p1;
                    call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_48230: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_48230, &m2, &(|m3: &Map<Text, Rel>, n: &Text| insert(m3, n, &Rel { param: r.param.clone(), strict: true })))))
                }))
            }) as Rc<dyn Fn((Map<Text, Rel>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
        })),
        None => h.clone(),
    }
}

/// The step machine of `StepRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
/// ```
pub struct StepRels {
    pub m: Map<Text, Rel>,
    pub coll: crate::syntax::Expr,
    pub ps: Array<crate::syntax::Pattern_>,
    pub at_: Nat,
}

impl prism_rtl::Job<Map<Text, Rel>> for StepRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let m = &self.m;
        let coll = &self.coll;
        let ps = &self.ps;
        let at_ = &self.at_;
        let at_ = at_.clone();
        let coll = coll.clone();
        let m = m.clone();
        let ps = ps.clone();
        call_value(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let a = p0;
            let p_ = p1;
            call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_48136: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &pattern_names_48136)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_48098: Array<Text>| {
            let h = hide(&m, &fold_48098);
            call_then(start_rel_of(m.clone(), coll.clone()), move |rel_of_48163: Option<Rel>| match rel_of_48163 {
                Some(r) => fold_job(drop(&ps, &at_), h.clone(), {
                    let r = r.clone();
                    Rc::new(move |(p0, p1): (Map<Text, Rel>, crate::syntax::Pattern_)| {
                        let r = r.clone();
                        entered(once_job(move || {
                            let m2 = p0;
                            let p_ = p1;
                            call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_48230: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_48230, &m2, &(|m3: &Map<Text, Rel>, n: &Text| insert(m3, n, &Rel { param: r.param.clone(), strict: true })))))
                        }))
                    }) as Rc<dyn Fn((Map<Text, Rel>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
                }).cycle(),
                None => prism_rtl::Turn::Finished(h.clone()),
            })
        })
    }
}

/// `Start StepRels, x`: what the function value is when passed to `@Run`.
pub fn start_step_rels(m: Map<Text, Rel>, coll: crate::syntax::Expr, ps: Array<crate::syntax::Pattern_>, at_: Nat) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(StepRels { m, coll, ps, at_ })
}

/// ```prism
/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
/// ```
pub fn expr_spots(e: &crate::syntax::Expr, m: &Map<Text, Rel>) -> Array<Spot> {
    run_to_end(fold_job(expr_kids(e, m), Array::from(vec![Spot::SpotExpr(e.clone(), m.clone())]), Rc::new(move |(p0, p1): (Array<Spot>, Kid)| entered(once_job(move || {
        let acc = p0;
        let k = p1;
        call_then(start_kid_spots(k.clone()), move |kid_spots_49517: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &kid_spots_49517)))
    }))) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>))
}

/// The step machine of `ExprSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
/// ```
pub struct ExprSpots {
    pub e: crate::syntax::Expr,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Spot>> for ExprSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let e = &self.e;
        let m = &self.m;
        let e = e.clone();
        let m = m.clone();
        call_then(start_expr_kids(e.clone(), m.clone()), move |expr_kids_49457: Array<Kid>| fold_job(expr_kids_49457, Array::from(vec![Spot::SpotExpr(e.clone(), m.clone())]), Rc::new(move |(p0, p1): (Array<Spot>, Kid)| entered(once_job(move || {
            let acc = p0;
            let k = p1;
            call_then(start_kid_spots(k.clone()), move |kid_spots_49517: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &kid_spots_49517)))
        }))) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>).cycle())
    }
}

/// `Start ExprSpots, x`: what the function value is when passed to `@Run`.
pub fn start_expr_spots(e: crate::syntax::Expr, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(ExprSpots { e, m })
}

/// ```prism
/// KidSpots: unbounded fn Kid -> [Spot]
/// ```
pub fn kid_spots(kid0: &Kid) -> Array<Spot> {
    match kid0 {
        Kid::KidExpr(x, m) => expr_spots(x, m),
        Kid::KidStmts(ss, m) => stmts_spots(ss, m),
    }
}

/// The step machine of `KidSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KidSpots: unbounded fn Kid -> [Spot]
/// ```
pub struct KidSpots {
    pub kid0: Kid,
}

impl prism_rtl::Job<Array<Spot>> for KidSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let kid0 = &self.kid0;
        match kid0 {
            Kid::KidExpr(x, m) => prism_rtl::Turn::More(Rc::new(ExprSpots { e: x.clone(), m: m.clone() })),
            Kid::KidStmts(ss, m) => prism_rtl::Turn::More(Rc::new(StmtsSpots { stmts: ss.clone(), m: m.clone() })),
        }
    }
}

/// `Start KidSpots, x`: what the function value is when passed to `@Run`.
pub fn start_kid_spots(kid0: Kid) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(KidSpots { kid0 })
}

/// ```prism
/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
/// ```
pub fn stmts_spots(stmts: &Array<crate::syntax::Stmt>, m: &Map<Text, Rel>) -> Array<Spot> {
    let bm = block_rels(stmts, m);
    run_to_end(fold_job(stmts.clone(), Array::new(), {
        let bm = bm.clone();
        Rc::new(move |(p0, p1): (Array<Spot>, crate::syntax::Stmt)| {
            let bm = bm.clone();
            entered(once_job(move || {
                let acc = p0;
                let s = p1;
                call_then(start_stmt_spots(s.clone(), bm.clone()), move |stmt_spots_49904: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &stmt_spots_49904)))
            }))
        }) as Rc<dyn Fn((Array<Spot>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>
    }))
}

/// The step machine of `StmtsSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
/// ```
pub struct StmtsSpots {
    pub stmts: Array<crate::syntax::Stmt>,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Spot>> for StmtsSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let stmts = &self.stmts;
        let m = &self.m;
        let m = m.clone();
        let stmts = stmts.clone();
        call_then(start_block_rels(stmts.clone(), m.clone()), move |block_rels_49840: Map<Text, Rel>| {
            let bm = block_rels_49840;
            fold_job(stmts.clone(), Array::new(), {
                let bm = bm.clone();
                Rc::new(move |(p0, p1): (Array<Spot>, crate::syntax::Stmt)| {
                    let bm = bm.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let s = p1;
                        call_then(start_stmt_spots(s.clone(), bm.clone()), move |stmt_spots_49904: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &stmt_spots_49904)))
                    }))
                }) as Rc<dyn Fn((Array<Spot>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>
            }).cycle()
        })
    }
}

/// `Start StmtsSpots, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_spots(stmts: Array<crate::syntax::Stmt>, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(StmtsSpots { stmts, m })
}

/// ```prism
/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
/// ```
pub fn stmt_spots(s: &crate::syntax::Stmt, m: &Map<Text, Rel>) -> Array<Spot> {
    run_to_end(fold_job(stmt_kids(s, m), Array::from(vec![Spot::SpotStmt(s.clone(), m.clone())]), Rc::new(move |(p0, p1): (Array<Spot>, Kid)| entered(once_job(move || {
        let acc = p0;
        let k = p1;
        call_then(start_kid_spots(k.clone()), move |kid_spots_50063: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &kid_spots_50063)))
    }))) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>))
}

/// The step machine of `StmtSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
/// ```
pub struct StmtSpots {
    pub s: crate::syntax::Stmt,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Spot>> for StmtSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let s = &self.s;
        let m = &self.m;
        let m = m.clone();
        let s = s.clone();
        call_then(start_stmt_kids(s.clone(), m.clone()), move |stmt_kids_50003: Array<Kid>| fold_job(stmt_kids_50003, Array::from(vec![Spot::SpotStmt(s.clone(), m.clone())]), Rc::new(move |(p0, p1): (Array<Spot>, Kid)| entered(once_job(move || {
            let acc = p0;
            let k = p1;
            call_then(start_kid_spots(k.clone()), move |kid_spots_50063: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &kid_spots_50063)))
        }))) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>).cycle())
    }
}

/// `Start StmtSpots, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_spots(s: crate::syntax::Stmt, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(StmtSpots { s, m })
}

/// ```prism
/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
/// ```
pub fn body_spots(fn_body0: &crate::syntax::FnBody, m: &Map<Text, Rel>) -> Array<Spot> {
    match fn_body0 {
        crate::syntax::FnBody::BodyExpr(e) => expr_spots(e, m),
        crate::syntax::FnBody::BodyBlock(b) => stmts_spots(&b.stmts, m),
    }
}

/// The step machine of `BodySpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
/// ```
pub struct BodySpots {
    pub fn_body0: crate::syntax::FnBody,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Spot>> for BodySpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let fn_body0 = &self.fn_body0;
        let m = &self.m;
        match fn_body0 {
            crate::syntax::FnBody::BodyExpr(e) => prism_rtl::Turn::More(Rc::new(ExprSpots { e: e.clone(), m: m.clone() })),
            crate::syntax::FnBody::BodyBlock(b) => prism_rtl::Turn::More(Rc::new(StmtsSpots { stmts: b.stmts.clone(), m: m.clone() })),
        }
    }
}

/// `Start BodySpots, x`: what the function value is when passed to `@Run`.
pub fn start_body_spots(fn_body0: crate::syntax::FnBody, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(BodySpots { fn_body0, m })
}

/// ```prism
/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
/// ```
pub fn expr_kids(e: &crate::syntax::Expr, m: &Map<Text, Rel>) -> Array<Kid> {
    match &*e.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => call_kids(&**c, args, m),
        crate::syntax::ExprKind::EMethod(r, n, args) => call_kids(&method_callee(n), &method_args(&**r, args), m),
        crate::syntax::ExprKind::EBinary(_, l, r) => exprs_kids(&Array::from(vec![(**l).clone(), (**r).clone()]), m),
        crate::syntax::ExprKind::ESuffixed(_, _, l, r) => exprs_kids(&Array::from(vec![(**l).clone(), (**r).clone()]), m),
        crate::syntax::ExprKind::EIndex(r, i) => exprs_kids(&Array::from(vec![(**r).clone(), (**i).clone()]), m),
        crate::syntax::ExprKind::EUnary(_, x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::EFreeSigil(_, x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::EField(r, _, _) => Array::from(vec![Kid::KidExpr((**r).clone(), m.clone())]),
        crate::syntax::ExprKind::ETopicIndex(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::EGroup(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::ETypeArgs(x, _) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::ECast(x, _, _) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::ENonEmpty(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::EAny(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::ExprKind::ETuple(es) => exprs_kids(es, m),
        crate::syntax::ExprKind::EArray(es) => exprs_kids(es, m),
        crate::syntax::ExprKind::EMap(kvs) => fold(kvs, &Array::new(), &(|acc: &Array<Kid>, (k, v_): &(crate::syntax::Expr, crate::syntax::Expr)| append(acc, &exprs_kids(&Array::from(vec![k.clone(), v_.clone()]), m)))),
        crate::syntax::ExprKind::ELit(l) => match &l.kind {
            crate::syntax::LitKind::LText(segs) => fold(segs, &Array::new(), &(|acc: &Array<Kid>, sg: &crate::syntax::TextSeg| match sg {
                crate::syntax::TextSeg::SegPlaceholder(x) => push(acc, &Kid::KidExpr(x.clone(), m.clone())),
                _ => acc.clone(),
            })),
            _ => Array::new(),
        },
        crate::syntax::ExprKind::ELambda(ps_opt, body) => Array::from(vec![lambda_kid(&**body, &later(&hide(m, &patterns_names(&or(ps_opt, &Array::new())))))]),
        crate::syntax::ExprKind::EIf(c, t, el_opt) => {
            let with_then = push(&cond_kids(&**c, m), &Kid::KidStmts(t.stmts.clone(), cond_rels(&**c, m)));
            match el_opt {
                Some(b) => push(&with_then, &Kid::KidStmts(b.stmts.clone(), m.clone())),
                None => with_then.clone(),
            }
        },
        crate::syntax::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), Array::from(vec![Kid::KidExpr((**s).clone(), m.clone())]), {
            let s = (**s).clone();
            let m = m.clone();
            Rc::new(move |(p0, p1): (Array<Kid>, crate::syntax::Arm)| {
                let s = s.clone();
                let m = m.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_arm_pat_rels(s.clone(), a.clone(), m.clone()), move |arm_pat_rels_51666: Map<Text, Rel>| {
                        let am = arm_pat_rels_51666;
                        prism_rtl::Turn::Finished(push(&append(&acc, &opt_kids(&a.guard, &am)), &Kid::KidStmts(a.body.stmts.clone(), am.clone())))
                    })
                }))
            }) as Rc<dyn Fn((Array<Kid>, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<Array<Kid>>>>
        })),
        crate::syntax::ExprKind::ERebuild(s, b) => Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), later(m))]),
        crate::syntax::ExprKind::EUpdate(s, b) => Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), m.clone())]),
        crate::syntax::ExprKind::EMonad(s, b) => Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), m.clone())]),
        crate::syntax::ExprKind::EFor(fb_opt, s, b) => {
            let names = match fb_opt {
                Some(fb) => crate::check::types::union_texts(&crate::check::env::pattern_names(&fb.first), &opt_names(&fb.second)),
                None => Array::new(),
            };
            Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), hide(m, &names))])
        },
        crate::syntax::ExprKind::EGiven(b) => Array::from(vec![Kid::KidStmts(b.stmts.clone(), m.clone())]),
        crate::syntax::ExprKind::EWidgetBlock(b) => Array::from(vec![Kid::KidStmts(b.stmts.clone(), later(m))]),
        crate::syntax::ExprKind::ETemplate(t) => template_kids(&t.parts, m),
        _ => Array::new(),
    }
}

/// The step machine of `ExprKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
/// ```
pub struct ExprKids {
    pub e: crate::syntax::Expr,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Kid>> for ExprKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let e = &self.e;
        let m = &self.m;
        match &*e.kind {
            crate::syntax::ExprKind::ECall(c, args, _, _) => prism_rtl::Turn::More(Rc::new(CallKids { c: (**c).clone(), args: args.clone(), m: m.clone() })),
            crate::syntax::ExprKind::EMethod(r, n, args) => prism_rtl::Turn::More(Rc::new(CallKids { c: method_callee(n), args: method_args(&**r, args), m: m.clone() })),
            crate::syntax::ExprKind::EBinary(_, l, r) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![(**l).clone(), (**r).clone()]), m)),
            crate::syntax::ExprKind::ESuffixed(_, _, l, r) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![(**l).clone(), (**r).clone()]), m)),
            crate::syntax::ExprKind::EIndex(r, i) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![(**r).clone(), (**i).clone()]), m)),
            crate::syntax::ExprKind::EUnary(_, x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::EFreeSigil(_, x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::EField(r, _, _) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**r).clone(), m.clone())])),
            crate::syntax::ExprKind::ETopicIndex(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::ETypeArgs(x, _) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::ECast(x, _, _) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::ENonEmpty(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::EAny(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::ExprKind::ETuple(es) => prism_rtl::Turn::Finished(exprs_kids(es, m)),
            crate::syntax::ExprKind::EArray(es) => prism_rtl::Turn::Finished(exprs_kids(es, m)),
            crate::syntax::ExprKind::EMap(kvs) => prism_rtl::Turn::Finished(fold(kvs, &Array::new(), &(|acc: &Array<Kid>, (k, v_): &(crate::syntax::Expr, crate::syntax::Expr)| append(acc, &exprs_kids(&Array::from(vec![k.clone(), v_.clone()]), m))))),
            crate::syntax::ExprKind::ELit(l) => match &l.kind {
                crate::syntax::LitKind::LText(segs) => prism_rtl::Turn::Finished(fold(segs, &Array::new(), &(|acc: &Array<Kid>, sg: &crate::syntax::TextSeg| match sg {
                    crate::syntax::TextSeg::SegPlaceholder(x) => push(acc, &Kid::KidExpr(x.clone(), m.clone())),
                    _ => acc.clone(),
                }))),
                _ => prism_rtl::Turn::Finished(Array::new()),
            },
            crate::syntax::ExprKind::ELambda(ps_opt, body) => {
                let ps_opt = ps_opt.clone();
                let body = (**body).clone();
                let m = m.clone();
                call_then(start_patterns_names(or(&ps_opt, &Array::new())), move |patterns_names_51354: Array<Text>| prism_rtl::Turn::Finished(Array::from(vec![lambda_kid(&body, &later(&hide(&m, &patterns_names_51354)))])))
            },
            crate::syntax::ExprKind::EIf(c, t, el_opt) => {
                let el_opt = el_opt.clone();
                let c = (**c).clone();
                let m = m.clone();
                let t = t.clone();
                call_then(start_cond_kids(c.clone(), m.clone()), move |cond_kids_51437: Array<Kid>| call_then(start_cond_rels(c.clone(), m.clone()), move |cond_rels_51473: Map<Text, Rel>| {
                    let with_then = push(&cond_kids_51437, &Kid::KidStmts(t.stmts.clone(), cond_rels_51473));
                    match &el_opt {
                        Some(b) => prism_rtl::Turn::Finished(push(&with_then, &Kid::KidStmts(b.stmts.clone(), m.clone()))),
                        None => prism_rtl::Turn::Finished(with_then.clone()),
                    }
                }))
            },
            crate::syntax::ExprKind::EMatch(s, arms) => fold_job(arms.clone(), Array::from(vec![Kid::KidExpr((**s).clone(), m.clone())]), {
                let s = (**s).clone();
                let m = m.clone();
                Rc::new(move |(p0, p1): (Array<Kid>, crate::syntax::Arm)| {
                    let s = s.clone();
                    let m = m.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let a = p1;
                        call_then(start_arm_pat_rels(s.clone(), a.clone(), m.clone()), move |arm_pat_rels_51666: Map<Text, Rel>| {
                            let am = arm_pat_rels_51666;
                            prism_rtl::Turn::Finished(push(&append(&acc, &opt_kids(&a.guard, &am)), &Kid::KidStmts(a.body.stmts.clone(), am.clone())))
                        })
                    }))
                }) as Rc<dyn Fn((Array<Kid>, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<Array<Kid>>>>
            }).cycle(),
            crate::syntax::ExprKind::ERebuild(s, b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), later(m))])),
            crate::syntax::ExprKind::EUpdate(s, b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), m.clone())])),
            crate::syntax::ExprKind::EMonad(s, b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), m.clone())])),
            crate::syntax::ExprKind::EFor(fb_opt, s, b) => {
                let names = match fb_opt {
                    Some(fb) => crate::check::types::union_texts(&crate::check::env::pattern_names(&fb.first), &opt_names(&fb.second)),
                    None => Array::new(),
                };
                prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), hide(m, &names))]))
            },
            crate::syntax::ExprKind::EGiven(b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidStmts(b.stmts.clone(), m.clone())])),
            crate::syntax::ExprKind::EWidgetBlock(b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidStmts(b.stmts.clone(), later(m))])),
            crate::syntax::ExprKind::ETemplate(t) => prism_rtl::Turn::More(Rc::new(TemplateKids { parts: t.parts.clone(), m: m.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ExprKids, x`: what the function value is when passed to `@Run`.
pub fn start_expr_kids(e: crate::syntax::Expr, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(ExprKids { e, m })
}

/// ```prism
/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
/// ```
pub fn stmt_kids(s: &crate::syntax::Stmt, m: &Map<Text, Rel>) -> Array<Kid> {
    match &s.kind {
        crate::syntax::StmtKind::SBind(_, e, t_opt) => append(&Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]), &opt_kids(t_opt, m)),
        crate::syntax::StmtKind::SIgnore(e) => Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]),
        crate::syntax::StmtKind::SLet(_, _, e) => Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]),
        crate::syntax::StmtKind::SFn(f) => Array::from(vec![body_kid(&f.body, &later(&hide(m, &patterns_names(&f.params))))]),
        crate::syntax::StmtKind::SWidget(w) => Array::from(vec![Kid::KidStmts(w.body.stmts.clone(), later(m))]),
        crate::syntax::StmtKind::SSet(t, v_) => exprs_kids(&Array::from(vec![t.clone(), v_.clone()]), m),
        crate::syntax::StmtKind::SAccum(t, _, v_) => exprs_kids(&Array::from(vec![t.clone(), v_.clone()]), m),
        crate::syntax::StmtKind::SRequire(c) => Array::from(vec![Kid::KidExpr(c.clone(), m.clone())]),
        crate::syntax::StmtKind::SForbid(c) => Array::from(vec![Kid::KidExpr(c.clone(), m.clone())]),
        crate::syntax::StmtKind::SReturn(e) => Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]),
        crate::syntax::StmtKind::SWhile(c, b) => push(&cond_kids(c, m), &Kid::KidStmts(b.stmts.clone(), cond_rels(c, m))),
        crate::syntax::StmtKind::SExpr(e) => Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]),
        _ => Array::new(),
    }
}

/// The step machine of `StmtKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
/// ```
pub struct StmtKids {
    pub s: crate::syntax::Stmt,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Kid>> for StmtKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let s = &self.s;
        let m = &self.m;
        match &s.kind {
            crate::syntax::StmtKind::SBind(_, e, t_opt) => prism_rtl::Turn::Finished(append(&Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]), &opt_kids(t_opt, m))),
            crate::syntax::StmtKind::SIgnore(e) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(e.clone(), m.clone())])),
            crate::syntax::StmtKind::SLet(_, _, e) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(e.clone(), m.clone())])),
            crate::syntax::StmtKind::SFn(f) => {
                let f = f.clone();
                let m = m.clone();
                call_then(start_patterns_names(f.params.clone()), move |patterns_names_52603: Array<Text>| prism_rtl::Turn::Finished(Array::from(vec![body_kid(&f.body, &later(&hide(&m, &patterns_names_52603)))])))
            },
            crate::syntax::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidStmts(w.body.stmts.clone(), later(m))])),
            crate::syntax::StmtKind::SSet(t, v_) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![t.clone(), v_.clone()]), m)),
            crate::syntax::StmtKind::SAccum(t, _, v_) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![t.clone(), v_.clone()]), m)),
            crate::syntax::StmtKind::SRequire(c) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(c.clone(), m.clone())])),
            crate::syntax::StmtKind::SForbid(c) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(c.clone(), m.clone())])),
            crate::syntax::StmtKind::SReturn(e) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(e.clone(), m.clone())])),
            crate::syntax::StmtKind::SWhile(c, b) => {
                let b = b.clone();
                let c = c.clone();
                let m = m.clone();
                call_then(start_cond_kids(c.clone(), m.clone()), move |cond_kids_52896: Array<Kid>| call_then(start_cond_rels(c.clone(), m.clone()), move |cond_rels_52932: Map<Text, Rel>| prism_rtl::Turn::Finished(push(&cond_kids_52896, &Kid::KidStmts(b.stmts.clone(), cond_rels_52932)))))
            },
            crate::syntax::StmtKind::SExpr(e) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(e.clone(), m.clone())])),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start StmtKids, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_kids(s: crate::syntax::Stmt, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(StmtKids { s, m })
}

/// ```prism
/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
/// ```
pub fn cond_kids(c: &crate::syntax::Cond, m: &Map<Text, Rel>) -> Array<Kid> {
    match c {
        crate::syntax::Cond::CondExpr(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        crate::syntax::Cond::CondBind(_, x, g_opt) => append(&Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]), &opt_kids(&**g_opt, &cond_rels(c, m))),
    }
}

/// The step machine of `CondKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
/// ```
pub struct CondKids {
    pub c: crate::syntax::Cond,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Kid>> for CondKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let c = &self.c;
        let m = &self.m;
        match c {
            crate::syntax::Cond::CondExpr(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            crate::syntax::Cond::CondBind(_, x, g_opt) => {
                let g_opt = (**g_opt).clone();
                let c = c.clone();
                let m = m.clone();
                let x = (**x).clone();
                call_then(start_cond_rels(c.clone(), m.clone()), move |cond_rels_53272: Map<Text, Rel>| prism_rtl::Turn::Finished(append(&Array::from(vec![Kid::KidExpr(x.clone(), m.clone())]), &opt_kids(&g_opt, &cond_rels_53272))))
            },
        }
    }
}

/// `Start CondKids, x`: what the function value is when passed to `@Run`.
pub fn start_cond_kids(c: crate::syntax::Cond, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(CondKids { c, m })
}

/// ```prism
/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
/// ```
pub fn call_kids(c: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>, m: &Map<Text, Rel>) -> Array<Kid> {
    let callee = match callee_name(c) {
        Some(_) => Array::new(),
        None => Array::from(vec![Kid::KidExpr(c.clone(), m.clone())]),
    };
    match traversal_of(m, c, args) {
        None => match acc_callee(m, c, args) {
            Some(cn) => append(&callee, &run_to_end(fold_job(crate::check::errors::range0(&len(args)), Array::new(), {
                let m = m.clone();
                let cn = cn.clone();
                let args = args.clone();
                Rc::new(move |(p0, p1): (Array<Kid>, Nat)| {
                    let m = m.clone();
                    let cn = cn.clone();
                    let args = args.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let i = p1;
                        call_then(start_acc_kids(m.clone(), cn.clone(), args.clone(), i.clone()), move |acc_kids_54132: Array<Kid>| prism_rtl::Turn::Finished(append(&acc, &acc_kids_54132)))
                    }))
                }) as Rc<dyn Fn((Array<Kid>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Kid>>>>
            }))),
            None => append(&callee, &exprs_kids(&each(args, &(|a: &crate::syntax::Arg| a.value.clone())), m)),
        },
        Some((coll, step_, at_)) => {
            let others = fold(&crate::check::errors::range0(&len(args)), &callee, &(|acc: &Array<Kid>, i: &Nat| if i == &(&at_ + &Nat::from(1u32)) {
                acc.clone()
            } else {
                match index(args, i) {
                    Some(a) => push(acc, &Kid::KidExpr(a.value.clone(), m.clone())),
                    None => acc.clone(),
                }
            }));
            match &*step_.kind {
                crate::syntax::ExprKind::ELambda(Some(ps), body) => push(&others, &lambda_kid(&**body, &step_rels(m, &coll, ps, &at_))),
                crate::syntax::ExprKind::EName(_) => others.clone(),
                _ => push(&others, &Kid::KidExpr(step_.clone(), m.clone())),
            }
        },
    }
}

/// The step machine of `CallKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
/// ```
pub struct CallKids {
    pub c: crate::syntax::Expr,
    pub args: Array<crate::syntax::Arg>,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Kid>> for CallKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let c = &self.c;
        let args = &self.args;
        let m = &self.m;
        let callee = match callee_name(c) {
            Some(_) => Array::new(),
            None => Array::from(vec![Kid::KidExpr(c.clone(), m.clone())]),
        };
        match traversal_of(m, c, args) {
            None => match acc_callee(m, c, args) {
                Some(cn) => {
                    let args = args.clone();
                    let m = m.clone();
                    call_value(fold_job(crate::check::errors::range0(&len(&args)), Array::new(), {
                        let m = m.clone();
                        let cn = cn.clone();
                        let args = args.clone();
                        Rc::new(move |(p0, p1): (Array<Kid>, Nat)| {
                            let m = m.clone();
                            let cn = cn.clone();
                            let args = args.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let i = p1;
                                call_then(start_acc_kids(m.clone(), cn.clone(), args.clone(), i.clone()), move |acc_kids_54132: Array<Kid>| prism_rtl::Turn::Finished(append(&acc, &acc_kids_54132)))
                            }))
                        }) as Rc<dyn Fn((Array<Kid>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Kid>>>>
                    }), move |fold_54077: Array<Kid>| prism_rtl::Turn::Finished(append(&callee, &fold_54077)))
                },
                None => prism_rtl::Turn::Finished(append(&callee, &exprs_kids(&each(args, &(|a: &crate::syntax::Arg| a.value.clone())), m))),
            },
            Some((coll, step_, at_)) => {
                let others = fold(&crate::check::errors::range0(&len(args)), &callee, &(|acc: &Array<Kid>, i: &Nat| if i == &(&at_ + &Nat::from(1u32)) {
                    acc.clone()
                } else {
                    match index(args, i) {
                        Some(a) => push(acc, &Kid::KidExpr(a.value.clone(), m.clone())),
                        None => acc.clone(),
                    }
                }));
                match &*step_.kind {
                    crate::syntax::ExprKind::ELambda(Some(ps), body) => {
                        let body = (**body).clone();
                        let m = m.clone();
                        let ps = ps.clone();
                        call_then(start_step_rels(m.clone(), coll.clone(), ps.clone(), at_.clone()), move |step_rels_54545: Map<Text, Rel>| prism_rtl::Turn::Finished(push(&others, &lambda_kid(&body, &step_rels_54545))))
                    },
                    crate::syntax::ExprKind::EName(_) => prism_rtl::Turn::Finished(others.clone()),
                    _ => prism_rtl::Turn::Finished(push(&others, &Kid::KidExpr(step_.clone(), m.clone()))),
                }
            },
        }
    }
}

/// `Start CallKids, x`: what the function value is when passed to `@Run`.
pub fn start_call_kids(c: crate::syntax::Expr, args: Array<crate::syntax::Arg>, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(CallKids { c, args, m })
}

/// ```prism
/// Later: fn (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn later(m: &Map<Text, Rel>) -> Map<Text, Rel> {
    insert(m, &Text::lit("lam:"), &no_rel())
}

/// ```prism
/// ?AccCallee: fn (Text ==> Rel), Expr, [Arg] -> ?Text
/// ```
pub fn acc_callee(m: &Map<Text, Rel>, c: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>) -> Option<Text> {
    match callee_name(c) {
        Some(cn) => if is_local(m, &cn) {
            None
        } else {
            if !fold(args, &true, &(|ok: &bool, a: &crate::syntax::Arg| *ok && (&a.name == &None))) {
                None
            } else {
                if fold(&crate::check::errors::range0(&len(args)), &false, &(|seen: &bool, i: &Nat| *seen || crate::check::env::has_key(m, &Text::from(format!("acc:{}:{}", &cn, i))))) {
                    Some(cn.clone())
                } else {
                    None
                }
            }
        },
        None => None,
    }
}

/// ```prism
/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
/// ```
pub fn acc_kids(m: &Map<Text, Rel>, cn: &Text, args: &Array<crate::syntax::Arg>, i: &Nat) -> Array<Kid> {
    let a = or(&index(args, i), &dummy_arg());
    if !crate::check::env::has_key(m, &Text::from(format!("acc:{}:{}", cn, i))) {
        Array::from(vec![Kid::KidExpr(a.value.clone(), m.clone())])
    } else {
        match &*a.value.kind {
            crate::syntax::ExprKind::ELambda(ps_opt, body) => Array::from(vec![lambda_kid(&**body, &acc_lambda_rels(m, cn, i, &or(ps_opt, &Array::new()), args))]),
            crate::syntax::ExprKind::EName(_) => Array::new(),
            _ => Array::from(vec![Kid::KidExpr(a.value.clone(), m.clone())]),
        }
    }
}

/// The step machine of `AccKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
/// ```
pub struct AccKids {
    pub m: Map<Text, Rel>,
    pub cn: Text,
    pub args: Array<crate::syntax::Arg>,
    pub i: Nat,
}

impl prism_rtl::Job<Array<Kid>> for AccKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let m = &self.m;
        let cn = &self.cn;
        let args = &self.args;
        let i = &self.i;
        let a = or(&index(args, i), &dummy_arg());
        if !crate::check::env::has_key(m, &Text::from(format!("acc:{}:{}", cn, i))) {
            prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(a.value.clone(), m.clone())]))
        } else {
            match &*a.value.kind {
                crate::syntax::ExprKind::ELambda(ps_opt, body) => prism_rtl::Turn::Finished(Array::from(vec![lambda_kid(&**body, &acc_lambda_rels(m, cn, i, &or(ps_opt, &Array::new()), args))])),
                crate::syntax::ExprKind::EName(_) => prism_rtl::Turn::Finished(Array::new()),
                _ => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(a.value.clone(), m.clone())])),
            }
        }
    }
}

/// `Start AccKids, x`: what the function value is when passed to `@Run`.
pub fn start_acc_kids(m: Map<Text, Rel>, cn: Text, args: Array<crate::syntax::Arg>, i: Nat) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(AccKids { m, cn, args, i })
}

/// ```prism
/// AccLambdaRels: unbounded fn (Text ==> Rel), Text, Nat, [Pattern], [Arg] -> (Text ==> Rel)
/// ```
pub fn acc_lambda_rels(m: &Map<Text, Rel>, cn: &Text, j: &Nat, ps: &Array<crate::syntax::Pattern_>, args: &Array<crate::syntax::Arg>) -> Map<Text, Rel> {
    let h = hide(m, &patterns_names(ps));
    run_to_end(fold_job(crate::check::errors::range0(&len(ps)), h.clone(), {
        let m = m.clone();
        let cn = cn.clone();
        let j = j.clone();
        let ps = ps.clone();
        let args = args.clone();
        Rc::new(move |(p0, p1): (Map<Text, Rel>, Nat)| {
            let m = m.clone();
            let cn = cn.clone();
            let j = j.clone();
            let ps = ps.clone();
            let args = args.clone();
            entered(once_job(move || {
                let m2 = p0;
                let q = p1;
                match (get(&m, &Text::from(format!("sum:{}:{}:{}", &cn, &j, &q))), index(&ps, &q)) {
                    (Some(s), Some(p_)) => if &s.param == &top_param() {
                        prism_rtl::Turn::Finished(m2.clone())
                    } else {
                        match index(&args, &s.param) {
                            Some(a) => call_then(start_rel_of(m.clone(), a.value.clone()), move |rel_of_56533: Option<Rel>| match rel_of_56533 {
                                Some(r) => match &*p_.kind {
                                    crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::Finished(insert(&m2, &crate::check::env::sname_key(n), &Rel { param: r.param.clone(), strict: r.strict || s.strict })),
                                    _ => call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_56728: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_56728, &m2, &(|m3: &Map<Text, Rel>, n: &Text| insert(m3, n, &Rel { param: r.param.clone(), strict: true }))))),
                                },
                                None => prism_rtl::Turn::Finished(m2.clone()),
                            }),
                            None => prism_rtl::Turn::Finished(m2.clone()),
                        }
                    },
                    _ => prism_rtl::Turn::Finished(m2.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
    }))
}

/// ```prism
/// let topParam
/// ```
pub fn top_param() -> Nat {
    Nat::from(9999u32)
}

/// ```prism
/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
/// ```
pub fn template_kids(parts: &Array<crate::syntax::TemplatePart>, m: &Map<Text, Rel>) -> Array<Kid> {
    fold(parts, &Array::new(), &(|acc: &Array<Kid>, p_: &crate::syntax::TemplatePart| match p_ {
        crate::syntax::TemplatePart::TpPlaceholder(x, _) => push(acc, &Kid::KidExpr(x.clone(), m.clone())),
        crate::syntax::TemplatePart::TpBlock(b) => push(acc, &Kid::KidStmts(b.stmts.clone(), m.clone())),
        crate::syntax::TemplatePart::TpCall(n, args, ps_opt, span) => push(acc, &Kid::KidExpr(template_call_expr(n, args, ps_opt, span), m.clone())),
        _ => acc.clone(),
    }))
}

/// The step machine of `TemplateKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
/// ```
pub struct TemplateKids {
    pub parts: Array<crate::syntax::TemplatePart>,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Kid>> for TemplateKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let parts = &self.parts;
        let m = &self.m;
        prism_rtl::Turn::Finished(fold(parts, &Array::new(), &(|acc: &Array<Kid>, p_: &crate::syntax::TemplatePart| match p_ {
            crate::syntax::TemplatePart::TpPlaceholder(x, _) => push(acc, &Kid::KidExpr(x.clone(), m.clone())),
            crate::syntax::TemplatePart::TpBlock(b) => push(acc, &Kid::KidStmts(b.stmts.clone(), m.clone())),
            crate::syntax::TemplatePart::TpCall(n, args, ps_opt, span) => push(acc, &Kid::KidExpr(template_call_expr(n, args, ps_opt, span), m.clone())),
            _ => acc.clone(),
        })))
    }
}

/// `Start TemplateKids, x`: what the function value is when passed to `@Run`.
pub fn start_template_kids(parts: Array<crate::syntax::TemplatePart>, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(TemplateKids { parts, m })
}

/// ```prism
/// TemplateCallExpr: fn SName, [Arg], ?[TemplatePart], Range -> Expr
/// ```
pub fn template_call_expr(n: &crate::syntax::SName, args: &Array<crate::syntax::Arg>, ps_opt: &Option<Array<crate::syntax::TemplatePart>>, span: &crate::syntax::Range) -> crate::syntax::Expr {
    let body = match ps_opt {
        Some(ps) => Array::from(vec![crate::syntax::Arg { name: Some(crate::syntax::Ident { name: Text::lit("#body"), span: span.clone() }), value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(crate::syntax::Template { keyword: Text::lit("InlineText"), lang: Text::lit(""), delims: Text::lit("double"), parts: ps.clone(), span: span.clone() })), span: span.clone() }, span: span.clone() }]),
        None => Array::new(),
    };
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(n.clone())), span: n.span.clone() }), append(args, &body), false, false)), span: span.clone() }
}

/// ```prism
/// ArgOf: fn Expr -> Arg
/// ```
pub fn arg_of(x: &crate::syntax::Expr) -> crate::syntax::Arg {
    crate::syntax::Arg { name: None, value: x.clone(), span: x.span.clone() }
}

/// ```prism
/// ExprsKids: fn [Expr], (Text ==> Rel) -> [Kid]
/// ```
pub fn exprs_kids(xs: &Array<crate::syntax::Expr>, m: &Map<Text, Rel>) -> Array<Kid> {
    each(xs, &(|x: &crate::syntax::Expr| Kid::KidExpr(x.clone(), m.clone())))
}

/// ```prism
/// OptKids: fn ?Expr, (Text ==> Rel) -> [Kid]
/// ```
pub fn opt_kids(opt0: &Option<crate::syntax::Expr>, map1: &Map<Text, Rel>) -> Array<Kid> {
    match (opt0, map1) {
        (Some(x), m) => Array::from(vec![Kid::KidExpr(x.clone(), m.clone())]),
        (None, _) => Array::new(),
    }
}

/// ```prism
/// LambdaKid: fn LambdaBody, (Text ==> Rel) -> Kid
/// ```
pub fn lambda_kid(lambda_body0: &crate::syntax::LambdaBody, m: &Map<Text, Rel>) -> Kid {
    match lambda_body0 {
        crate::syntax::LambdaBody::LbExpr(x) => Kid::KidExpr((**x).clone(), m.clone()),
        crate::syntax::LambdaBody::LbBlock(b) => Kid::KidStmts(b.stmts.clone(), m.clone()),
    }
}

/// ```prism
/// BodyKid: fn FnBody, (Text ==> Rel) -> Kid
/// ```
pub fn body_kid(fn_body0: &crate::syntax::FnBody, m: &Map<Text, Rel>) -> Kid {
    match fn_body0 {
        crate::syntax::FnBody::BodyExpr(x) => Kid::KidExpr(x.clone(), m.clone()),
        crate::syntax::FnBody::BodyBlock(b) => Kid::KidStmts(b.stmts.clone(), m.clone()),
    }
}

/// ```prism
/// PatternsNames: unbounded fn [Pattern] -> [Text]
/// ```
pub fn patterns_names(ps: &Array<crate::syntax::Pattern_>) -> Array<Text> {
    run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
        let a = p0;
        let p_ = p1;
        call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_58687: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &pattern_names_58687)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `PatternsNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatternsNames: unbounded fn [Pattern] -> [Text]
/// ```
pub struct PatternsNames {
    pub ps: Array<crate::syntax::Pattern_>,
}

impl prism_rtl::Job<Array<Text>> for PatternsNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let ps = &self.ps;
        fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let a = p0;
            let p_ = p1;
            call_then(crate::check::env::start_pattern_names(p_.clone()), move |pattern_names_58687: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &pattern_names_58687)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
    }
}

/// `Start PatternsNames, x`: what the function value is when passed to `@Run`.
pub fn start_patterns_names(ps: Array<crate::syntax::Pattern_>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatternsNames { ps })
}

/// ```prism
/// ?CalleeName: fn Expr -> ?Text
/// ```
pub fn callee_name(c: &crate::syntax::Expr) -> Option<Text> {
    match &*c.kind {
        crate::syntax::ExprKind::EName(n) => Some(crate::check::env::sname_key(n)),
        crate::syntax::ExprKind::ETypeArgs(t, _) => match &*t.kind {
            crate::syntax::ExprKind::EName(n) => Some(crate::check::env::sname_key(n)),
            _ => None,
        },
        _ => None,
    }
}

/// ```prism
/// MethodCallee: fn SName -> Expr
/// ```
pub fn method_callee(n: &crate::syntax::SName) -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(n.clone())), span: n.span.clone() }
}

/// ```prism
/// MethodArgs: fn Expr, [Arg] -> [Arg]
/// ```
pub fn method_args(r: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>) -> Array<crate::syntax::Arg> {
    append(&Array::from(vec![crate::syntax::Arg { name: None, value: r.clone(), span: r.span.clone() }]), args)
}

/// ```prism
/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
/// ```
pub fn body_sites(body: &crate::syntax::FnBody, m: &Map<Text, Rel>) -> Array<Site> {
    run_to_end(fold_job(body_spots(body, m), Array::new(), Rc::new(move |(p0, p1): (Array<Site>, Spot)| entered(once_job(move || {
        let acc = p0;
        let sp = p1;
        call_then(start_spot_sites(sp.clone()), move |spot_sites_59644: Array<Site>| prism_rtl::Turn::Finished(append(&acc, &spot_sites_59644)))
    }))) as Rc<dyn Fn((Array<Site>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>))
}

/// The step machine of `BodySites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
/// ```
pub struct BodySites {
    pub body: crate::syntax::FnBody,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Site>> for BodySites {
    fn cycle(&self) -> prism_rtl::Turn<Array<Site>> {
        let body = &self.body;
        let m = &self.m;
        let body = body.clone();
        let m = m.clone();
        call_then(start_body_spots(body.clone(), m.clone()), move |body_spots_59594: Array<Spot>| fold_job(body_spots_59594, Array::new(), Rc::new(move |(p0, p1): (Array<Site>, Spot)| entered(once_job(move || {
            let acc = p0;
            let sp = p1;
            call_then(start_spot_sites(sp.clone()), move |spot_sites_59644: Array<Site>| prism_rtl::Turn::Finished(append(&acc, &spot_sites_59644)))
        }))) as Rc<dyn Fn((Array<Site>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>).cycle())
    }
}

/// `Start BodySites, x`: what the function value is when passed to `@Run`.
pub fn start_body_sites(body: crate::syntax::FnBody, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Site>>> {
    Rc::new(BodySites { body, m })
}

/// ```prism
/// SpotSites: unbounded fn Spot -> [Site]
/// ```
pub fn spot_sites(spot0: &Spot) -> Array<Site> {
    match spot0 {
        Spot::SpotStmt(_, _) => Array::new(),
        Spot::SpotExpr(e, m) => match &*e.kind {
            crate::syntax::ExprKind::EName(n) => Array::from(vec![Site { callee: crate::check::env::sname_key(n), args: Array::new(), span: e.span.clone(), rels: m.clone() }]),
            crate::syntax::ExprKind::ECall(c, args, _, _) => call_sites(&**c, args, &e.span, m),
            crate::syntax::ExprKind::EMethod(r, n, args) => call_sites(&method_callee(n), &method_args(&**r, args), &e.span, m),
            crate::syntax::ExprKind::EBinary(op, l, r) => if is_called_op(op) {
                Array::from(vec![Site { callee: op.clone(), args: Array::from(vec![arg_of(&**l), arg_of(&**r)]), span: e.span.clone(), rels: m.clone() }])
            } else {
                Array::new()
            },
            _ => Array::new(),
        },
    }
}

/// The step machine of `SpotSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotSites: unbounded fn Spot -> [Site]
/// ```
pub struct SpotSites {
    pub spot0: Spot,
}

impl prism_rtl::Job<Array<Site>> for SpotSites {
    fn cycle(&self) -> prism_rtl::Turn<Array<Site>> {
        let spot0 = &self.spot0;
        match spot0 {
            Spot::SpotStmt(_, _) => prism_rtl::Turn::Finished(Array::new()),
            Spot::SpotExpr(e, m) => match &*e.kind {
                crate::syntax::ExprKind::EName(n) => prism_rtl::Turn::Finished(Array::from(vec![Site { callee: crate::check::env::sname_key(n), args: Array::new(), span: e.span.clone(), rels: m.clone() }])),
                crate::syntax::ExprKind::ECall(c, args, _, _) => prism_rtl::Turn::More(Rc::new(CallSites { c: (**c).clone(), args: args.clone(), span: e.span.clone(), m: m.clone() })),
                crate::syntax::ExprKind::EMethod(r, n, args) => prism_rtl::Turn::More(Rc::new(CallSites { c: method_callee(n), args: method_args(&**r, args), span: e.span.clone(), m: m.clone() })),
                crate::syntax::ExprKind::EBinary(op, l, r) => if is_called_op(op) {
                    prism_rtl::Turn::Finished(Array::from(vec![Site { callee: op.clone(), args: Array::from(vec![arg_of(&**l), arg_of(&**r)]), span: e.span.clone(), rels: m.clone() }]))
                } else {
                    prism_rtl::Turn::Finished(Array::new())
                },
                _ => prism_rtl::Turn::Finished(Array::new()),
            },
        }
    }
}

/// `Start SpotSites, x`: what the function value is when passed to `@Run`.
pub fn start_spot_sites(spot0: Spot) -> Rc<dyn prism_rtl::Job<Array<Site>>> {
    Rc::new(SpotSites { spot0 })
}

/// ```prism
/// IsCalledOp: fn Text -> Bool
/// ```
pub fn is_called_op(op: &Text) -> bool {
    !crate::check::types::has_text(&Array::from(vec![Text::lit("and"), Text::lit("or"), Text::lit("on"), Text::lit("<|"), Text::lit("mod")]), op)
}

/// ```prism
/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
/// ```
pub fn call_sites(c: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range, m: &Map<Text, Rel>) -> Array<Site> {
    let direct = match callee_name(c) {
        Some(n) => Array::from(vec![Site { callee: n.clone(), args: args.clone(), span: span.clone(), rels: m.clone() }]),
        None => Array::new(),
    };
    match traversal_of(m, c, args) {
        Some((coll, step_, at_)) => match &*step_.kind {
            crate::syntax::ExprKind::EName(n) => {
                let call_args = if &at_ == &Nat::from(1u32) {
                    Array::from(vec![or(&index(args, &Nat::from(1u32)), &dummy_arg()), arg_of(&part_of(&coll))])
                } else {
                    Array::from(vec![arg_of(&part_of(&coll))])
                };
                push(&direct, &Site { callee: crate::check::env::sname_key(n), args: call_args.clone(), span: step_.span.clone(), rels: m.clone() })
            },
            _ => direct.clone(),
        },
        None => match acc_callee(m, c, args) {
            Some(cn) => append(&direct, &acc_sites(m, &cn, args)),
            None => direct.clone(),
        },
    }
}

/// The step machine of `CallSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
/// ```
pub struct CallSites {
    pub c: crate::syntax::Expr,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Site>> for CallSites {
    fn cycle(&self) -> prism_rtl::Turn<Array<Site>> {
        let c = &self.c;
        let args = &self.args;
        let span = &self.span;
        let m = &self.m;
        let direct = match callee_name(c) {
            Some(n) => Array::from(vec![Site { callee: n.clone(), args: args.clone(), span: span.clone(), rels: m.clone() }]),
            None => Array::new(),
        };
        match traversal_of(m, c, args) {
            Some((coll, step_, at_)) => match &*step_.kind {
                crate::syntax::ExprKind::EName(n) => {
                    let call_args = if &at_ == &Nat::from(1u32) {
                        Array::from(vec![or(&index(args, &Nat::from(1u32)), &dummy_arg()), arg_of(&part_of(&coll))])
                    } else {
                        Array::from(vec![arg_of(&part_of(&coll))])
                    };
                    prism_rtl::Turn::Finished(push(&direct, &Site { callee: crate::check::env::sname_key(n), args: call_args.clone(), span: step_.span.clone(), rels: m.clone() }))
                },
                _ => prism_rtl::Turn::Finished(direct.clone()),
            },
            None => match acc_callee(m, c, args) {
                Some(cn) => prism_rtl::Turn::Finished(append(&direct, &acc_sites(m, &cn, args))),
                None => prism_rtl::Turn::Finished(direct.clone()),
            },
        }
    }
}

/// `Start CallSites, x`: what the function value is when passed to `@Run`.
pub fn start_call_sites(c: crate::syntax::Expr, args: Array<crate::syntax::Arg>, span: crate::syntax::Range, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Site>>> {
    Rc::new(CallSites { c, args, span, m })
}

/// ```prism
/// PartOf: fn Expr -> Expr
/// ```
pub fn part_of(x: &crate::syntax::Expr) -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(x.clone()), Text::lit(""), crate::syntax::Ident { name: Text::lit("element"), span: x.span.clone() })), span: x.span.clone() }
}

/// ```prism
/// AccSites: fn (Text ==> Rel), Text, [Arg] -> [Site]
/// ```
pub fn acc_sites(m: &Map<Text, Rel>, cn: &Text, args: &Array<crate::syntax::Arg>) -> Array<Site> {
    fold(&crate::check::errors::range0(&len(args)), &Array::new(), &(|acc: &Array<Site>, j: &Nat| match (get(m, &Text::from(format!("acc:{}:{}", cn, j))), index(args, j)) {
        (Some(ar), Some(a)) => match &*a.value.kind {
            crate::syntax::ExprKind::EName(f) => push(acc, &Site { callee: crate::check::env::sname_key(f), args: each(&crate::check::errors::range0(&ar.param), &(|q: &Nat| acc_arg(m, cn, j, q, args))), span: a.value.span.clone(), rels: m.clone() }),
            _ => acc.clone(),
        },
        _ => acc.clone(),
    }))
}

/// ```prism
/// AccArg: fn (Text ==> Rel), Text, Nat, Nat, [Arg] -> Arg
/// ```
pub fn acc_arg(m: &Map<Text, Rel>, cn: &Text, j: &Nat, q: &Nat, args: &Array<crate::syntax::Arg>) -> crate::syntax::Arg {
    match get(m, &Text::from(format!("sum:{}:{}:{}", cn, j, q))) {
        Some(s) => if &s.param == &top_param() {
            arg_of(&top_expr())
        } else {
            match index(args, &s.param) {
                Some(a) => arg_of(&(if s.strict { part_of(&a.value) } else { a.value.clone() })),
                None => dummy_arg(),
            }
        },
        None => dummy_arg(),
    }
}

/// ```prism
/// let topExpr
/// ```
pub fn top_expr() -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(crate::syntax::SName { sigils: Text::lit(""), path_: Array::from(vec![Text::lit("⊤")]), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } })), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// SpotsNames: unbounded fn [Spot] -> [Text]
/// ```
pub fn spots_names(spots: &Array<Spot>) -> Array<Text> {
    run_to_end(fold_job(spots.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, Spot)| entered(once_job(move || {
        let acc = p0;
        let sp = p1;
        call_then(start_spot_names(sp.clone()), move |spot_names_62985: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &spot_names_62985)))
    }))) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `SpotsNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotsNames: unbounded fn [Spot] -> [Text]
/// ```
pub struct SpotsNames {
    pub spots: Array<Spot>,
}

impl prism_rtl::Job<Array<Text>> for SpotsNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let spots = &self.spots;
        fold_job(spots.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, Spot)| entered(once_job(move || {
            let acc = p0;
            let sp = p1;
            call_then(start_spot_names(sp.clone()), move |spot_names_62985: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &spot_names_62985)))
        }))) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
    }
}

/// `Start SpotsNames, x`: what the function value is when passed to `@Run`.
pub fn start_spots_names(spots: Array<Spot>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotsNames { spots })
}

/// ```prism
/// SpotNames: unbounded fn Spot -> [Text]
/// ```
pub fn spot_names(sp: &Spot) -> Array<Text> {
    let called = each(&spot_sites(sp), &(|s: &Site| s.callee.clone()));
    match sp {
        Spot::SpotExpr(_, _) => called.clone(),
        Spot::SpotStmt(s, _) => match &s.kind {
            crate::syntax::StmtKind::SWidget(w) => crate::check::types::add_text(&called, &crate::check::env::sname_key(&w.name)),
            _ => called.clone(),
        },
    }
}

/// The step machine of `SpotNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotNames: unbounded fn Spot -> [Text]
/// ```
pub struct SpotNames {
    pub sp: Spot,
}

impl prism_rtl::Job<Array<Text>> for SpotNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sp = &self.sp;
        let sp = sp.clone();
        call_then(start_spot_sites(sp.clone()), move |spot_sites_63079: Array<Site>| {
            let called = each(&spot_sites_63079, &(|s: &Site| s.callee.clone()));
            match &sp {
                Spot::SpotExpr(_, _) => prism_rtl::Turn::Finished(called.clone()),
                Spot::SpotStmt(s, _) => match &s.kind {
                    crate::syntax::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(crate::check::types::add_text(&called, &crate::check::env::sname_key(&w.name))),
                    _ => prism_rtl::Turn::Finished(called.clone()),
                },
            }
        })
    }
}

/// `Start SpotNames, x`: what the function value is when passed to `@Run`.
pub fn start_spot_names(sp: Spot) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotNames { sp })
}

/// ```prism
/// ?TraversalOf: fn (Text ==> Rel), Expr, [Arg] -> ?((Expr, Expr, Nat))
/// ```
pub fn traversal_of(m: &Map<Text, Rel>, c: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>) -> Option<(crate::syntax::Expr, crate::syntax::Expr, Nat)> {
    match &*c.kind {
        crate::syntax::ExprKind::EName(n) => {
            let name = crate::check::env::sname_key(n);
            if pre_is(m, &name, &Text::lit("Fold")) && (&len(args) == &Nat::from(3u32)) {
                match (index(args, &Nat::from(0u32)), index(args, &Nat::from(2u32))) {
                    (Some(a), Some(s)) => Some((a.value.clone(), s.value.clone(), Nat::from(1u32))),
                    _ => None,
                }
            } else {
                if (pre_is(m, &name, &Text::lit("Each")) || pre_is(m, &name, &Text::lit("Filter"))) && (&len(args) == &Nat::from(2u32)) {
                    match (index(args, &Nat::from(0u32)), index(args, &Nat::from(1u32))) {
                        (Some(a), Some(s)) => Some((a.value.clone(), s.value.clone(), Nat::from(0u32))),
                        _ => None,
                    }
                } else {
                    None
                }
            }
        },
        _ => None,
    }
}

/// ```prism
/// ?LastExpr: fn Block -> ?Expr
/// ```
pub fn last_expr(b: &crate::syntax::Block) -> Option<crate::syntax::Expr> {
    match crate::syntax::lexer::last(&b.stmts) {
        Some(s) => match &s.kind {
            crate::syntax::StmtKind::SExpr(x) => Some(x.clone()),
            _ => None,
        },
        None => None,
    }
}

/// ```prism
/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub fn rel_of(m: &Map<Text, Rel>, e: &crate::syntax::Expr) -> Option<Rel> {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => get(m, &crate::check::env::sname_key(n)),
        crate::syntax::ExprKind::EField(r, _, _) => match rel_of(m, &**r) {
            Some(x) => Some(Rel { param: x.param.clone(), strict: true }),
            None => None,
        },
        crate::syntax::ExprKind::EIndex(r, _) => rel_of(m, &**r),
        crate::syntax::ExprKind::EGroup(x) => rel_of(m, &**x),
        _ => match call_of(e) {
            Some((c, args)) => if is_non_nat_min(m, e, &c) { None } else { rel_of_call(m, &c, &args) },
            None => None,
        },
    }
}

/// The step machine of `RelOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub struct RelOf {
    pub m: Map<Text, Rel>,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<Option<Rel>> for RelOf {
    fn cycle(&self) -> prism_rtl::Turn<Option<Rel>> {
        let m = &self.m;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EName(n) => prism_rtl::Turn::Finished(get(m, &crate::check::env::sname_key(n))),
            crate::syntax::ExprKind::EField(r, _, _) => {
                let m = m.clone();
                let r = (**r).clone();
                call_then(start_rel_of(m.clone(), r.clone()), move |rel_of_65195: Option<Rel>| match rel_of_65195 {
                    Some(x) => prism_rtl::Turn::Finished(Some(Rel { param: x.param.clone(), strict: true })),
                    None => prism_rtl::Turn::Finished(None),
                })
            },
            crate::syntax::ExprKind::EIndex(r, _) => prism_rtl::Turn::More(Rc::new(RelOf { m: m.clone(), e: (**r).clone() })),
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(RelOf { m: m.clone(), e: (**x).clone() })),
            _ => match call_of(e) {
                Some((c, args)) => if is_non_nat_min(m, e, &c) {
                    prism_rtl::Turn::Finished(None)
                } else {
                    prism_rtl::Turn::More(Rc::new(RelOfCall { m: m.clone(), c: c.clone(), args: args.clone() }))
                },
                None => prism_rtl::Turn::Finished(None),
            },
        }
    }
}

/// `Start RelOf, x`: what the function value is when passed to `@Run`.
pub fn start_rel_of(m: Map<Text, Rel>, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Option<Rel>>> {
    Rc::new(RelOf { m, e })
}

/// ```prism
/// IsNonNatMin: fn (Text ==> Rel), Expr, Expr -> Bool
/// ```
pub fn is_non_nat_min(m: &Map<Text, Rel>, e: &crate::syntax::Expr, c: &crate::syntax::Expr) -> bool {
    match callee_name(c) {
        Some(n) => if pre_is(m, &n, &Text::lit("Min")) { !is_nat_at(m, e) } else { false },
        None => false,
    }
}

/// ```prism
/// IsNatAt: fn (Text ==> Rel), Expr -> Bool
/// ```
pub fn is_nat_at(m: &Map<Text, Rel>, e: &crate::syntax::Expr) -> bool {
    match get(m, &Text::lit("file:")) {
        Some(f) => crate::check::env::has_key(m, &Text::from(format!("nat:{}:{}:{}", &f.param, &e.span.start, &e.span.end))),
        None => false,
    }
}

/// ```prism
/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
/// ```
pub fn rel_of_call(m: &Map<Text, Rel>, c: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>) -> Option<Rel> {
    match &*c.kind {
        crate::syntax::ExprKind::EName(n) => {
            let name = crate::check::env::sname_key(n);
            if (pre_is(m, &name, &Text::lit("Drop")) && (&len(args) == &Nat::from(2u32))) && is_positive_lit(&or(&index(args, &Nat::from(1u32)), &dummy_arg()).value) {
                match index(args, &Nat::from(0u32)) {
                    Some(a) => match rel_of(m, &a.value) {
                        Some(x) => Some(Rel { param: x.param.clone(), strict: x.strict || known_non_empty(m, &a.value) }),
                        None => None,
                    },
                    None => None,
                }
            } else {
                if (pre_is(m, &name, &Text::lit("Values")) || pre_is(m, &name, &Text::lit("Keys"))) && (&len(args) == &Nat::from(1u32)) {
                    rel_of(m, &or(&index(args, &Nat::from(0u32)), &dummy_arg()).value)
                } else {
                    match no_larger_arg(m, c, args) {
                        Some(a) => rel_of(m, &a),
                        None => None,
                    }
                }
            }
        },
        _ => None,
    }
}

/// The step machine of `RelOfCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
/// ```
pub struct RelOfCall {
    pub m: Map<Text, Rel>,
    pub c: crate::syntax::Expr,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Option<Rel>> for RelOfCall {
    fn cycle(&self) -> prism_rtl::Turn<Option<Rel>> {
        let m = &self.m;
        let c = &self.c;
        let args = &self.args;
        match &*c.kind {
            crate::syntax::ExprKind::EName(n) => {
                let name = crate::check::env::sname_key(n);
                if (pre_is(m, &name, &Text::lit("Drop")) && (&len(args) == &Nat::from(2u32))) && is_positive_lit(&or(&index(args, &Nat::from(1u32)), &dummy_arg()).value) {
                    match index(args, &Nat::from(0u32)) {
                        Some(a) => {
                            let m = m.clone();
                            call_then(start_rel_of(m.clone(), a.value.clone()), move |rel_of_66352: Option<Rel>| match rel_of_66352 {
                                Some(x) => prism_rtl::Turn::Finished(Some(Rel { param: x.param.clone(), strict: x.strict || known_non_empty(&m, &a.value) })),
                                None => prism_rtl::Turn::Finished(None),
                            })
                        },
                        None => prism_rtl::Turn::Finished(None),
                    }
                } else {
                    if (pre_is(m, &name, &Text::lit("Values")) || pre_is(m, &name, &Text::lit("Keys"))) && (&len(args) == &Nat::from(1u32)) {
                        prism_rtl::Turn::More(Rc::new(RelOf { m: m.clone(), e: or(&index(args, &Nat::from(0u32)), &dummy_arg()).value.clone() }))
                    } else {
                        match no_larger_arg(m, c, args) {
                            Some(a) => prism_rtl::Turn::More(Rc::new(RelOf { m: m.clone(), e: a.clone() })),
                            None => prism_rtl::Turn::Finished(None),
                        }
                    }
                }
            },
            _ => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start RelOfCall, x`: what the function value is when passed to `@Run`.
pub fn start_rel_of_call(m: Map<Text, Rel>, c: crate::syntax::Expr, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Option<Rel>>> {
    Rc::new(RelOfCall { m, c, args })
}

/// ```prism
/// KnownNonEmpty: fn (Text ==> Rel), Expr -> Bool
/// ```
pub fn known_non_empty(m: &Map<Text, Rel>, e: &crate::syntax::Expr) -> bool {
    match name_of(e) {
        Some(n) => crate::check::env::has_key(m, &Text::from(format!("ne:{}", &n))),
        None => false,
    }
}

/// ```prism
/// ?CallOf: fn Expr -> ?((Expr, [Arg]))
/// ```
pub fn call_of(e: &crate::syntax::Expr) -> Option<(crate::syntax::Expr, Array<crate::syntax::Arg>)> {
    match &*e.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => Some(((**c).clone(), args.clone())),
        crate::syntax::ExprKind::EMethod(r, n, args) => Some((method_callee(n), method_args(&**r, args))),
        _ => None,
    }
}

/// ```prism
/// ?NoLargerArg: fn (Text ==> Rel), Expr, [Arg] -> ?Expr
/// ```
pub fn no_larger_arg(m: &Map<Text, Rel>, c: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>) -> Option<crate::syntax::Expr> {
    match callee_name(c) {
        Some(n) => if is_local(m, &n) {
            None
        } else {
            match get(m, &Text::from(format!("fn:{}", &n))) {
                Some(s) => match index(args, &s.param) {
                    Some(a) => Some(a.value.clone()),
                    None => None,
                },
                None => None,
            }
        },
        None => None,
    }
}

/// ```prism
/// IsNoLargerPrelude: fn G, Text -> Bool
/// ```
pub fn is_no_larger_prelude(g: &crate::check::env::G, k: &Text) -> bool {
    crate::check::types::has_text(&Array::from(vec![Text::lit("Prelude.Take"), Text::lit("Prelude.Drop"), Text::lit("Prelude.Filter"), Text::lit("Prelude.Remove"), Text::lit("Prelude.Min")]), k) && is_prelude_key(g, k)
}

/// ```prism
/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
/// ```
pub fn parts_summaries(sk: &Shrink, fns: &Array<crate::check::env::Def>) -> Map<Text, Nat> {
    run_to_end(fold_job(fns.clone(), Map::new(), {
        let sk = sk.clone();
        Rc::new(move |(p0, p1): (Map<Text, Nat>, crate::check::env::Def)| {
            let sk = sk.clone();
            entered(once_job(move || {
                let m = p0;
                let d = p1;
                match &d.body {
                    crate::check::env::DefBody::DbFn(clauses) => {
                        let n = match index(clauses, &Nat::from(0u32)) {
                            Some(c0) => len(&c0.params),
                            None => Nat::from(0u32),
                        };
                        let clauses = clauses.clone();
                        call_value(filter_job(crate::check::errors::range0(&n), {
                            let clauses = clauses.clone();
                            let sk = sk.clone();
                            let d = d.clone();
                            Rc::new(move |p0: Nat| {
                                let clauses = clauses.clone();
                                let sk = sk.clone();
                                let d = d.clone();
                                entered(once_job(move || {
                                    let i = p0;
                                    fold_job(clauses.clone(), true, {
                                        let sk = sk.clone();
                                        let d = d.clone();
                                        let i = i.clone();
                                        Rc::new(move |(p0, p1): (bool, crate::syntax::FnClause)| {
                                            let sk = sk.clone();
                                            let d = d.clone();
                                            let i = i.clone();
                                            entered(once_job(move || {
                                                let okc = p0;
                                                let c = p1;
                                                prism_rtl::Turn::Finished(okc && clause_within(&clause_base(&sk, &d, &c), &c, &i))
                                            }))
                                        }) as Rc<dyn Fn((bool, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }).cycle()
                                }))
                            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |filter_69126: Array<Nat>| {
                            let ok = filter_69126;
                            match index(&ok, &Nat::from(0u32)) {
                                Some(i) => prism_rtl::Turn::Finished(insert(&m, &d.qk, &i)),
                                None => prism_rtl::Turn::Finished(m.clone()),
                            }
                        })
                    },
                    _ => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Nat>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
    }))
}

/// The step machine of `PartsSummaries`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
/// ```
pub struct PartsSummaries {
    pub sk: Shrink,
    pub fns: Array<crate::check::env::Def>,
}

impl prism_rtl::Job<Map<Text, Nat>> for PartsSummaries {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Nat>> {
        let sk = &self.sk;
        let fns = &self.fns;
        fold_job(fns.clone(), Map::new(), {
            let sk = sk.clone();
            Rc::new(move |(p0, p1): (Map<Text, Nat>, crate::check::env::Def)| {
                let sk = sk.clone();
                entered(once_job(move || {
                    let m = p0;
                    let d = p1;
                    match &d.body {
                        crate::check::env::DefBody::DbFn(clauses) => {
                            let n = match index(clauses, &Nat::from(0u32)) {
                                Some(c0) => len(&c0.params),
                                None => Nat::from(0u32),
                            };
                            let clauses = clauses.clone();
                            call_value(filter_job(crate::check::errors::range0(&n), {
                                let clauses = clauses.clone();
                                let sk = sk.clone();
                                let d = d.clone();
                                Rc::new(move |p0: Nat| {
                                    let clauses = clauses.clone();
                                    let sk = sk.clone();
                                    let d = d.clone();
                                    entered(once_job(move || {
                                        let i = p0;
                                        fold_job(clauses.clone(), true, {
                                            let sk = sk.clone();
                                            let d = d.clone();
                                            let i = i.clone();
                                            Rc::new(move |(p0, p1): (bool, crate::syntax::FnClause)| {
                                                let sk = sk.clone();
                                                let d = d.clone();
                                                let i = i.clone();
                                                entered(once_job(move || {
                                                    let okc = p0;
                                                    let c = p1;
                                                    prism_rtl::Turn::Finished(okc && clause_within(&clause_base(&sk, &d, &c), &c, &i))
                                                }))
                                            }) as Rc<dyn Fn((bool, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
                                        }).cycle()
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<bool>>>
                            }), move |filter_69126: Array<Nat>| {
                                let ok = filter_69126;
                                match index(&ok, &Nat::from(0u32)) {
                                    Some(i) => prism_rtl::Turn::Finished(insert(&m, &d.qk, &i)),
                                    None => prism_rtl::Turn::Finished(m.clone()),
                                }
                            })
                        },
                        _ => prism_rtl::Turn::Finished(m.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Nat>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
        }).cycle()
    }
}

/// `Start PartsSummaries, x`: what the function value is when passed to `@Run`.
pub fn start_parts_summaries(sk: Shrink, fns: Array<crate::check::env::Def>) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>> {
    Rc::new(PartsSummaries { sk, fns })
}

/// ```prism
/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
/// ```
pub fn clause_within(base: &Map<Text, Rel>, c: &crate::syntax::FnClause, i: &Nat) -> bool {
    match &c.body {
        crate::syntax::FnBody::BodyExpr(e) => within(base, i, e),
        crate::syntax::FnBody::BodyBlock(b) => within_block(base, i, b),
    }
}

/// The step machine of `ClauseWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
/// ```
pub struct ClauseWithin {
    pub base: Map<Text, Rel>,
    pub c: crate::syntax::FnClause,
    pub i: Nat,
}

impl prism_rtl::Job<bool> for ClauseWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let base = &self.base;
        let c = &self.c;
        let i = &self.i;
        match &c.body {
            crate::syntax::FnBody::BodyExpr(e) => prism_rtl::Turn::More(Rc::new(Within { m: base.clone(), i: i.clone(), e: e.clone() })),
            crate::syntax::FnBody::BodyBlock(b) => prism_rtl::Turn::More(Rc::new(WithinBlock { m: base.clone(), i: i.clone(), b: b.clone() })),
        }
    }
}

/// `Start ClauseWithin, x`: what the function value is when passed to `@Run`.
pub fn start_clause_within(base: Map<Text, Rel>, c: crate::syntax::FnClause, i: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(ClauseWithin { base, c, i })
}

/// ```prism
/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub fn within(m: &Map<Text, Rel>, i: &Nat, e: &crate::syntax::Expr) -> bool {
    match rel_of(m, e) {
        Some(r) => &r.param == i,
        None => match &*e.kind {
            crate::syntax::ExprKind::EArray(es) => run_to_end(fold_job(es.clone(), true, {
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(ok && part(&m, &i, &x))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
            })),
            crate::syntax::ExprKind::EMap(kvs) => run_to_end(fold_job(kvs.clone(), true, {
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, (crate::syntax::Expr, crate::syntax::Expr))| {
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let (k, v_) = p1;
                        prism_rtl::Turn::Finished((ok && part(&m, &i, &k)) && part(&m, &i, &v_))
                    }))
                }) as Rc<dyn Fn((bool, (crate::syntax::Expr, crate::syntax::Expr))) -> Rc<dyn prism_rtl::Job<bool>>>
            })),
            crate::syntax::ExprKind::EGroup(x) => within(m, i, &**x),
            crate::syntax::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), true, {
                let s = (**s).clone();
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                    let s = s.clone();
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let a = p1;
                        prism_rtl::Turn::Finished(ok && within_block(&arm_pat_rels(&s, &a, &m), &i, &a.body))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
            })),
            crate::syntax::ExprKind::EIf(c, t, Some(el)) => within_block(&cond_rels(&**c, m), i, t) && within_block(m, i, el),
            crate::syntax::ExprKind::EUpdate(start, b) => within(m, i, &**start) && update_within(&insert(m, &Text::lit("&_"), &Rel { param: i.clone(), strict: false }), i, b),
            _ => match call_of(e) {
                Some((c, args)) => match traversal_of(m, &c, &args) {
                    Some((coll, step_, at_)) => within(m, i, &coll) && step_within(m, i, &expr_name(&c), &coll, &step_, &at_, &or(&index(&args, &Nat::from(1u32)), &dummy_arg()).value),
                    None => false,
                },
                None => false,
            },
        },
    }
}

/// The step machine of `Within`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub struct Within {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for Within {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let e = &self.e;
        let e = e.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(start_rel_of(m.clone(), e.clone()), move |rel_of_69586: Option<Rel>| match rel_of_69586 {
            Some(r) => prism_rtl::Turn::Finished(&r.param == &i),
            None => match &*e.kind {
                crate::syntax::ExprKind::EArray(es) => fold_job(es.clone(), true, {
                    let m = m.clone();
                    let i = i.clone();
                    Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                        let m = m.clone();
                        let i = i.clone();
                        entered(once_job(move || {
                            let ok = p0;
                            let x = p1;
                            prism_rtl::Turn::Finished(ok && part(&m, &i, &x))
                        }))
                    }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle(),
                crate::syntax::ExprKind::EMap(kvs) => fold_job(kvs.clone(), true, {
                    let m = m.clone();
                    let i = i.clone();
                    Rc::new(move |(p0, p1): (bool, (crate::syntax::Expr, crate::syntax::Expr))| {
                        let m = m.clone();
                        let i = i.clone();
                        entered(once_job(move || {
                            let ok = p0;
                            let (k, v_) = p1;
                            prism_rtl::Turn::Finished((ok && part(&m, &i, &k)) && part(&m, &i, &v_))
                        }))
                    }) as Rc<dyn Fn((bool, (crate::syntax::Expr, crate::syntax::Expr))) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle(),
                crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(Within { m: m.clone(), i: i.clone(), e: (**x).clone() })),
                crate::syntax::ExprKind::EMatch(s, arms) => fold_job(arms.clone(), true, {
                    let s = (**s).clone();
                    let m = m.clone();
                    let i = i.clone();
                    Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                        let s = s.clone();
                        let m = m.clone();
                        let i = i.clone();
                        entered(once_job(move || {
                            let ok = p0;
                            let a = p1;
                            prism_rtl::Turn::Finished(ok && within_block(&arm_pat_rels(&s, &a, &m), &i, &a.body))
                        }))
                    }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle(),
                crate::syntax::ExprKind::EIf(c, t, Some(el)) => {
                    let c = (**c).clone();
                    let el = el.clone();
                    let t = t.clone();
                    call_then(start_cond_rels(c.clone(), m.clone()), move |cond_rels_69970: Map<Text, Rel>| call_then(start_within_block(cond_rels_69970, i.clone(), t.clone()), move |within_block_69957: bool| prism_rtl::Turn::Finished(within_block_69957 && within_block(&m, &i, &el))))
                },
                crate::syntax::ExprKind::EUpdate(start, b) => {
                    let b = b.clone();
                    let start = (**start).clone();
                    call_then(start_within(m.clone(), i.clone(), start.clone()), move |within_70044: bool| prism_rtl::Turn::Finished(within_70044 && update_within(&insert(&m, &Text::lit("&_"), &Rel { param: i.clone(), strict: false }), &i, &b)))
                },
                _ => match call_of(&e) {
                    Some((c, args)) => match traversal_of(&m, &c, &args) {
                        Some((coll, step_, at_)) => call_then(start_within(m.clone(), i.clone(), coll.clone()), move |within_70265: bool| prism_rtl::Turn::Finished(within_70265 && step_within(&m, &i, &expr_name(&c), &coll, &step_, &at_, &or(&index(&args, &Nat::from(1u32)), &dummy_arg()).value))),
                        None => prism_rtl::Turn::Finished(false),
                    },
                    None => prism_rtl::Turn::Finished(false),
                },
            },
        })
    }
}

/// `Start Within, x`: what the function value is when passed to `@Run`.
pub fn start_within(m: Map<Text, Rel>, i: Nat, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Within { m, i, e })
}

/// ```prism
/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub fn update_within(m: &Map<Text, Rel>, i: &Nat, b: &crate::syntax::Block) -> bool {
    run_to_end(fold_job(stmts_spots(&b.stmts, m), true, {
        let i = i.clone();
        Rc::new(move |(p0, p1): (bool, Spot)| {
            let i = i.clone();
            entered(once_job(move || {
                let ok = p0;
                let sp = p1;
                prism_rtl::Turn::Finished(ok && spot_keeps_within(&sp, &i))
            }))
        }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `UpdateWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub struct UpdateWithin {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<bool> for UpdateWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let b = &self.b;
        let b = b.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(start_stmts_spots(b.stmts.clone(), m.clone()), move |stmts_spots_70727: Array<Spot>| fold_job(stmts_spots_70727, true, {
            let i = i.clone();
            Rc::new(move |(p0, p1): (bool, Spot)| {
                let i = i.clone();
                entered(once_job(move || {
                    let ok = p0;
                    let sp = p1;
                    prism_rtl::Turn::Finished(ok && spot_keeps_within(&sp, &i))
                }))
            }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start UpdateWithin, x`: what the function value is when passed to `@Run`.
pub fn start_update_within(m: Map<Text, Rel>, i: Nat, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(UpdateWithin { m, i, b })
}

/// ```prism
/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
/// ```
pub fn spot_keeps_within(spot0: &Spot, n1: &Nat) -> bool {
    match (spot0, n1) {
        (Spot::SpotStmt(s, m), i) => match &s.kind {
            crate::syntax::StmtKind::SSet(t, value) => if &take(&crate::check::passes::ref_path(t), &Nat::from(1u32)) != &Array::from(vec![Text::lit("&_")]) {
                true
            } else {
                (&crate::check::passes::ref_path(t) == &Array::from(vec![Text::lit("&_")])) && within(m, i, value)
            },
            crate::syntax::StmtKind::SAccum(t, _, _) => &take(&crate::check::passes::ref_path(t), &Nat::from(1u32)) != &Array::from(vec![Text::lit("&_")]),
            _ => true,
        },
        (Spot::SpotExpr(_, _), _) => true,
    }
}

/// The step machine of `SpotKeepsWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
/// ```
pub struct SpotKeepsWithin {
    pub spot0: Spot,
    pub n1: Nat,
}

impl prism_rtl::Job<bool> for SpotKeepsWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let spot0 = &self.spot0;
        let n1 = &self.n1;
        match (spot0, n1) {
            (Spot::SpotStmt(s, m), i) => match &s.kind {
                crate::syntax::StmtKind::SSet(t, value) => {
                    let i = i.clone();
                    let m = m.clone();
                    let t = t.clone();
                    let value = value.clone();
                    call_then(crate::check::passes::start_ref_path(t.clone()), move |ref_path_70936: Array<Text>| if &take(&ref_path_70936, &Nat::from(1u32)) != &Array::from(vec![Text::lit("&_")]) {
                        prism_rtl::Turn::Finished(true)
                    } else {
                        call_then(crate::check::passes::start_ref_path(t.clone()), move |ref_path_70984: Array<Text>| prism_rtl::Turn::Finished((&ref_path_70984 == &Array::from(vec![Text::lit("&_")])) && within(&m, &i, &value)))
                    })
                },
                crate::syntax::StmtKind::SAccum(t, _, _) => {
                    let t = t.clone();
                    call_then(crate::check::passes::start_ref_path(t.clone()), move |ref_path_71067: Array<Text>| prism_rtl::Turn::Finished(&take(&ref_path_71067, &Nat::from(1u32)) != &Array::from(vec![Text::lit("&_")])))
                },
                _ => prism_rtl::Turn::Finished(true),
            },
            (Spot::SpotExpr(_, _), _) => prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start SpotKeepsWithin, x`: what the function value is when passed to `@Run`.
pub fn start_spot_keeps_within(spot0: Spot, n1: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SpotKeepsWithin { spot0, n1 })
}

/// ```prism
/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub fn within_block(m: &Map<Text, Rel>, i: &Nat, b: &crate::syntax::Block) -> bool {
    within(&block_rels(&b.stmts, m), i, &last_or(b))
}

/// The step machine of `WithinBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub struct WithinBlock {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<bool> for WithinBlock {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let b = &self.b;
        let b = b.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(start_block_rels(b.stmts.clone(), m.clone()), move |block_rels_71331: Map<Text, Rel>| prism_rtl::Turn::More(Rc::new(Within { m: block_rels_71331, i: i.clone(), e: last_or(&b) })))
    }
}

/// `Start WithinBlock, x`: what the function value is when passed to `@Run`.
pub fn start_within_block(m: Map<Text, Rel>, i: Nat, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(WithinBlock { m, i, b })
}

/// ```prism
/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
/// ```
pub fn step_within(m: &Map<Text, Rel>, i: &Nat, f: &Text, coll: &crate::syntax::Expr, step_: &crate::syntax::Expr, at_: &Nat, z: &crate::syntax::Expr) -> bool {
    if pre_is(m, f, &Text::lit("Filter")) {
        true
    } else {
        match &*step_.kind {
            crate::syntax::ExprKind::ELambda(Some(ps), body) => {
                let sm = step_rels(m, coll, ps, at_);
                let (bm, x) = match &**body {
                    crate::syntax::LambdaBody::LbExpr(y) => (sm.clone(), (**y).clone()),
                    crate::syntax::LambdaBody::LbBlock(b) => (block_rels(&b.stmts, &sm), last_or(b)),
                };
                if pre_is(m, f, &Text::lit("Each")) {
                    part(&bm, i, &x)
                } else {
                    match index(ps, &Nat::from(0u32)) {
                        Some(acc) => match &*acc.kind {
                            crate::syntax::PatternKind::PName(n) => within(m, i, z) && builds_on(&bm, i, &crate::check::env::sname_key(n), &x),
                            _ => false,
                        },
                        None => false,
                    }
                }
            },
            _ => false,
        }
    }
}

/// The step machine of `StepWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
/// ```
pub struct StepWithin {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub f: Text,
    pub coll: crate::syntax::Expr,
    pub step_: crate::syntax::Expr,
    pub at_: Nat,
    pub z: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for StepWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let f = &self.f;
        let coll = &self.coll;
        let step_ = &self.step_;
        let at_ = &self.at_;
        let z = &self.z;
        if pre_is(m, f, &Text::lit("Filter")) {
            prism_rtl::Turn::Finished(true)
        } else {
            match &*step_.kind {
                crate::syntax::ExprKind::ELambda(Some(ps), body) => {
                    let at_ = at_.clone();
                    let body = (**body).clone();
                    let coll = coll.clone();
                    let f = f.clone();
                    let i = i.clone();
                    let m = m.clone();
                    let ps = ps.clone();
                    let z = z.clone();
                    call_then(start_step_rels(m.clone(), coll.clone(), ps.clone(), at_.clone()), move |step_rels_71761: Map<Text, Rel>| {
                        let sm = step_rels_71761;
                        let (bm, x) = match &body {
                            crate::syntax::LambdaBody::LbExpr(y) => (sm.clone(), (**y).clone()),
                            crate::syntax::LambdaBody::LbBlock(b) => (block_rels(&b.stmts, &sm), last_or(b)),
                        };
                        if pre_is(&m, &f, &Text::lit("Each")) {
                            prism_rtl::Turn::More(Rc::new(Part { m: bm.clone(), i: i.clone(), e: x.clone() }))
                        } else {
                            match index(&ps, &Nat::from(0u32)) {
                                Some(acc) => match &*acc.kind {
                                    crate::syntax::PatternKind::PName(n) => {
                                        let n = n.clone();
                                        call_then(start_within(m.clone(), i.clone(), z.clone()), move |within_72078: bool| prism_rtl::Turn::Finished(within_72078 && builds_on(&bm, &i, &crate::check::env::sname_key(&n), &x)))
                                    },
                                    _ => prism_rtl::Turn::Finished(false),
                                },
                                None => prism_rtl::Turn::Finished(false),
                            }
                        }
                    })
                },
                _ => prism_rtl::Turn::Finished(false),
            }
        }
    }
}

/// `Start StepWithin, x`: what the function value is when passed to `@Run`.
pub fn start_step_within(m: Map<Text, Rel>, i: Nat, f: Text, coll: crate::syntax::Expr, step_: crate::syntax::Expr, at_: Nat, z: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(StepWithin { m, i, f, coll, step_, at_, z })
}

/// ```prism
/// LastOr: fn Block -> Expr
/// ```
pub fn last_or(b: &crate::syntax::Block) -> crate::syntax::Expr {
    or(&last_expr(b), &dummy_arg().value)
}

/// ```prism
/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
/// ```
pub fn builds_on(m: &Map<Text, Rel>, i: &Nat, acc: &Text, e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => &crate::check::env::sname_key(n) == acc,
        crate::syntax::ExprKind::EGroup(x) => builds_on(m, i, acc, &**x),
        crate::syntax::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), true, {
            let acc = acc.clone();
            let s = (**s).clone();
            let m = m.clone();
            let i = i.clone();
            Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                let acc = acc.clone();
                let s = s.clone();
                let m = m.clone();
                let i = i.clone();
                entered(once_job(move || {
                    let ok = p0;
                    let a = p1;
                    prism_rtl::Turn::Finished((ok && !crate::check::types::has_text(&opt_names(&a.pattern), &acc)) && builds_on_block(&arm_pat_rels(&s, &a, &m), &i, &acc, &a.body))
                }))
            }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::syntax::ExprKind::EIf(c, t, Some(el)) => (!crate::check::types::has_text(&cond_names(&**c), acc) && builds_on_block(&cond_rels(&**c, m), i, acc, t)) && builds_on_block(m, i, acc, el),
        _ => match call_of(e) {
            Some((c, args)) => builds_on_call(m, i, acc, &c, &args),
            None => false,
        },
    }
}

/// The step machine of `BuildsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
/// ```
pub struct BuildsOn {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub acc: Text,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for BuildsOn {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let acc = &self.acc;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EName(n) => prism_rtl::Turn::Finished(&crate::check::env::sname_key(n) == acc),
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(BuildsOn { m: m.clone(), i: i.clone(), acc: acc.clone(), e: (**x).clone() })),
            crate::syntax::ExprKind::EMatch(s, arms) => fold_job(arms.clone(), true, {
                let acc = acc.clone();
                let s = (**s).clone();
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                    let acc = acc.clone();
                    let s = s.clone();
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let a = p1;
                        prism_rtl::Turn::Finished((ok && !crate::check::types::has_text(&opt_names(&a.pattern), &acc)) && builds_on_block(&arm_pat_rels(&s, &a, &m), &i, &acc, &a.body))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::syntax::ExprKind::EIf(c, t, Some(el)) => {
                let acc = acc.clone();
                let c = (**c).clone();
                let el = el.clone();
                let i = i.clone();
                let m = m.clone();
                let t = t.clone();
                call_then(start_cond_names(c.clone()), move |cond_names_72792: Array<Text>| prism_rtl::Turn::Finished((!crate::check::types::has_text(&cond_names_72792, &acc) && builds_on_block(&cond_rels(&c, &m), &i, &acc, &t)) && builds_on_block(&m, &i, &acc, &el)))
            },
            _ => match call_of(e) {
                Some((c, args)) => prism_rtl::Turn::More(Rc::new(BuildsOnCall { m: m.clone(), i: i.clone(), acc: acc.clone(), c: c.clone(), args: args.clone() })),
                None => prism_rtl::Turn::Finished(false),
            },
        }
    }
}

/// `Start BuildsOn, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on(m: Map<Text, Rel>, i: Nat, acc: Text, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(BuildsOn { m, i, acc, e })
}

/// ```prism
/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
/// ```
pub fn builds_on_call(m: &Map<Text, Rel>, i: &Nat, acc: &Text, c: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>) -> bool {
    let f = expr_name(c);
    let on_acc = builds_on(m, i, acc, &or(&index(args, &Nat::from(0u32)), &dummy_arg()).value);
    let rest = each(&drop(args, &Nat::from(1u32)), &(|a: &crate::syntax::Arg| a.value.clone()));
    let parts = run_to_end(fold_job(rest.clone(), true, {
        let m = m.clone();
        let i = i.clone();
        Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
            let m = m.clone();
            let i = i.clone();
            entered(once_job(move || {
                let ok = p0;
                let x = p1;
                prism_rtl::Turn::Finished(ok && part(&m, &i, &x))
            }))
        }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    if !on_acc {
        false
    } else {
        if pre_is(m, &f, &Text::lit("Push")) && (&len(&rest) == &Nat::from(1u32)) {
            parts
        } else {
            if pre_is(m, &f, &Text::lit("Insert")) && (&len(&rest) == &Nat::from(2u32)) {
                parts
            } else {
                if pre_is(m, &f, &Text::lit("Append")) && (&len(&rest) == &Nat::from(1u32)) {
                    within(m, i, &or(&index(&rest, &Nat::from(0u32)), &dummy_arg().value))
                } else {
                    false
                }
            }
        }
    }
}

/// The step machine of `BuildsOnCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
/// ```
pub struct BuildsOnCall {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub acc: Text,
    pub c: crate::syntax::Expr,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<bool> for BuildsOnCall {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let acc = &self.acc;
        let c = &self.c;
        let args = &self.args;
        let f = expr_name(c);
        let acc = acc.clone();
        let args = args.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(start_builds_on(m.clone(), i.clone(), acc.clone(), or(&index(&args, &Nat::from(0u32)), &dummy_arg()).value.clone()), move |builds_on_73222: bool| {
            let on_acc = builds_on_73222;
            let rest = each(&drop(&args, &Nat::from(1u32)), &(|a: &crate::syntax::Arg| a.value.clone()));
            call_value(fold_job(rest.clone(), true, {
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(ok && part(&m, &i, &x))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |fold_73336: bool| {
                let parts = fold_73336;
                if !on_acc {
                    prism_rtl::Turn::Finished(false)
                } else {
                    if pre_is(&m, &f, &Text::lit("Push")) && (&len(&rest) == &Nat::from(1u32)) {
                        prism_rtl::Turn::Finished(parts)
                    } else {
                        if pre_is(&m, &f, &Text::lit("Insert")) && (&len(&rest) == &Nat::from(2u32)) {
                            prism_rtl::Turn::Finished(parts)
                        } else {
                            if pre_is(&m, &f, &Text::lit("Append")) && (&len(&rest) == &Nat::from(1u32)) {
                                prism_rtl::Turn::More(Rc::new(Within { m: m.clone(), i: i.clone(), e: or(&index(&rest, &Nat::from(0u32)), &dummy_arg().value) }))
                            } else {
                                prism_rtl::Turn::Finished(false)
                            }
                        }
                    }
                }
            })
        })
    }
}

/// `Start BuildsOnCall, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on_call(m: Map<Text, Rel>, i: Nat, acc: Text, c: crate::syntax::Expr, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(BuildsOnCall { m, i, acc, c, args })
}

/// ```prism
/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
/// ```
pub fn builds_on_block(m: &Map<Text, Rel>, i: &Nat, acc: &Text, b: &crate::syntax::Block) -> bool {
    !crate::check::types::has_text(&stmts_binders(&b.stmts), acc) && builds_on(&block_rels(&b.stmts, m), i, acc, &last_or(b))
}

/// The step machine of `BuildsOnBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
/// ```
pub struct BuildsOnBlock {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub acc: Text,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<bool> for BuildsOnBlock {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let acc = &self.acc;
        let b = &self.b;
        let acc = acc.clone();
        let b = b.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(start_stmts_binders(b.stmts.clone()), move |stmts_binders_73896: Array<Text>| prism_rtl::Turn::Finished(!crate::check::types::has_text(&stmts_binders_73896, &acc) && builds_on(&block_rels(&b.stmts, &m), &i, &acc, &last_or(&b))))
    }
}

/// `Start BuildsOnBlock, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on_block(m: Map<Text, Rel>, i: Nat, acc: Text, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(BuildsOnBlock { m, i, acc, b })
}

/// ```prism
/// CondNames: unbounded fn Cond -> [Text]
/// ```
pub fn cond_names(cond0: &crate::syntax::Cond) -> Array<Text> {
    match cond0 {
        crate::syntax::Cond::CondBind(p_, _, _) => crate::check::env::pattern_names(p_),
        crate::syntax::Cond::CondExpr(_) => Array::new(),
    }
}

/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondNames: unbounded fn Cond -> [Text]
/// ```
pub struct CondNames {
    pub cond0: crate::syntax::Cond,
}

impl prism_rtl::Job<Array<Text>> for CondNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cond0 = &self.cond0;
        match cond0 {
            crate::syntax::Cond::CondBind(p_, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::PatternNames { p_: p_.clone() })),
            crate::syntax::Cond::CondExpr(_) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start CondNames, x`: what the function value is when passed to `@Run`.
pub fn start_cond_names(cond0: crate::syntax::Cond) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CondNames { cond0 })
}

/// ```prism
/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub fn part(m: &Map<Text, Rel>, i: &Nat, e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::ETuple(es) => run_to_end(fold_job(es.clone(), true, {
            let m = m.clone();
            let i = i.clone();
            Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                let m = m.clone();
                let i = i.clone();
                entered(once_job(move || {
                    let ok = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(ok && part(&m, &i, &x))
                }))
            }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::syntax::ExprKind::EGroup(x) => part(m, i, &**x),
        _ => match rel_of(m, e) {
            Some(r) => (&r.param == i) && r.strict,
            None => false,
        },
    }
}

/// The step machine of `Part`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub struct Part {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for Part {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::ETuple(es) => fold_job(es.clone(), true, {
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(ok && part(&m, &i, &x))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(Part { m: m.clone(), i: i.clone(), e: (**x).clone() })),
            _ => {
                let e = e.clone();
                let i = i.clone();
                let m = m.clone();
                call_then(start_rel_of(m.clone(), e.clone()), move |rel_of_74311: Option<Rel>| match rel_of_74311 {
                    Some(r) => prism_rtl::Turn::Finished((&r.param == &i) && r.strict),
                    None => prism_rtl::Turn::Finished(false),
                })
            },
        }
    }
}

/// `Start Part, x`: what the function value is when passed to `@Run`.
pub fn start_part(m: Map<Text, Rel>, i: Nat, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Part { m, i, e })
}

/// ```prism
/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn summary_seeds(sk: &Shrink, d: &crate::check::env::Def, spots: &Array<Spot>, rels: &Map<Text, Rel>) -> Map<Text, Rel> {
    fold(&run_to_end(fold_job(spots.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Site>, Spot)| entered(once_job(move || {
        let acc = p0;
        let sp = p1;
        call_then(start_spot_sites(sp.clone()), move |spot_sites_74987: Array<Site>| prism_rtl::Turn::Finished(append(&acc, &spot_sites_74987)))
    }))) as Rc<dyn Fn((Array<Site>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>)), rels, &(|m: &Map<Text, Rel>, site: &Site| if is_local(&site.rels, &site.callee) {
        m.clone()
    } else {
        match resolve_callee(&sk.g, &d.home, &site.callee) {
            Some(k) => match get(&sk.sums, &k) {
                Some(i) => insert(m, &Text::from(format!("fn:{}", &site.callee)), &Rel { param: i.clone(), strict: false }),
                None => if is_no_larger_prelude(&sk.g, &k) {
                    insert(m, &Text::from(format!("fn:{}", &site.callee)), &Rel { param: Nat::from(0u32), strict: false })
                } else {
                    m.clone()
                },
            },
            None => m.clone(),
        }
    }))
}

/// The step machine of `SummarySeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct SummarySeeds {
    pub sk: Shrink,
    pub d: crate::check::env::Def,
    pub spots: Array<Spot>,
    pub rels: Map<Text, Rel>,
}

impl prism_rtl::Job<Map<Text, Rel>> for SummarySeeds {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let sk = &self.sk;
        let d = &self.d;
        let spots = &self.spots;
        let rels = &self.rels;
        let d = d.clone();
        let rels = rels.clone();
        let sk = sk.clone();
        let spots = spots.clone();
        call_value(fold_job(spots.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Site>, Spot)| entered(once_job(move || {
            let acc = p0;
            let sp = p1;
            call_then(start_spot_sites(sp.clone()), move |spot_sites_74987: Array<Site>| prism_rtl::Turn::Finished(append(&acc, &spot_sites_74987)))
        }))) as Rc<dyn Fn((Array<Site>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>), move |fold_74945: Array<Site>| prism_rtl::Turn::Finished(fold(&fold_74945, &rels, &(|m: &Map<Text, Rel>, site: &Site| if is_local(&site.rels, &site.callee) {
            m.clone()
        } else {
            match resolve_callee(&sk.g, &d.home, &site.callee) {
                Some(k) => match get(&sk.sums, &k) {
                    Some(i) => insert(m, &Text::from(format!("fn:{}", &site.callee)), &Rel { param: i.clone(), strict: false }),
                    None => if is_no_larger_prelude(&sk.g, &k) {
                        insert(m, &Text::from(format!("fn:{}", &site.callee)), &Rel { param: Nat::from(0u32), strict: false })
                    } else {
                        m.clone()
                    },
                },
                None => m.clone(),
            }
        }))))
    }
}

/// `Start SummarySeeds, x`: what the function value is when passed to `@Run`.
pub fn start_summary_seeds(sk: Shrink, d: crate::check::env::Def, spots: Array<Spot>, rels: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(SummarySeeds { sk, d, spots, rels })
}

/// ```prism
/// OptNames: unbounded fn ?Pattern -> [Text]
/// ```
pub fn opt_names(opt0: &Option<crate::syntax::Pattern_>) -> Array<Text> {
    match opt0 {
        Some(p_) => crate::check::env::pattern_names(p_),
        None => Array::new(),
    }
}

/// The step machine of `OptNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptNames: unbounded fn ?Pattern -> [Text]
/// ```
pub struct OptNames {
    pub opt0: Option<crate::syntax::Pattern_>,
}

impl prism_rtl::Job<Array<Text>> for OptNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(p_) => prism_rtl::Turn::More(Rc::new(crate::check::env::PatternNames { p_: p_.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptNames, x`: what the function value is when passed to `@Run`.
pub fn start_opt_names(opt0: Option<crate::syntax::Pattern_>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(OptNames { opt0 })
}

/// ```prism
/// let dummyArg
/// ```
pub fn dummy_arg() -> crate::syntax::Arg {
    crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub fn decrement_of(m: &Map<Text, Rel>, e: &crate::syntax::Expr) -> Option<Rel> {
    match &*e.kind {
        crate::syntax::ExprKind::EBinary(m75795_0_0, l, r) if (m75795_0_0 == &Text::lit("-?")) => if is_positive_lit(&**r) && is_nat_minus(m, e) { smaller(m, &**l) } else { None },
        crate::syntax::ExprKind::EGroup(x) => decrement_of(m, &**x),
        _ => match call_of(e) {
            Some((c, args)) => match callee_name(&c) {
                Some(n) => if pre_is(m, &n, &Text::lit("?Step")) {
                    smaller(m, &or(&index(&args, &Nat::from(0u32)), &dummy_arg()).value)
                } else {
                    None
                },
                None => None,
            },
            None => None,
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DecrementOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub struct DecrementOf {
    pub m: Map<Text, Rel>,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<Option<Rel>> for DecrementOf {
    fn cycle(&self) -> prism_rtl::Turn<Option<Rel>> {
        let m = &self.m;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EBinary(m75795_0_0, l, r) if (m75795_0_0 == &Text::lit("-?")) => if is_positive_lit(&**r) && is_nat_minus(m, e) {
                prism_rtl::Turn::Finished(smaller(m, &**l))
            } else {
                prism_rtl::Turn::Finished(None)
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(DecrementOf { m: m.clone(), e: (**x).clone() })),
            _ => match call_of(e) {
                Some((c, args)) => match callee_name(&c) {
                    Some(n) => if pre_is(m, &n, &Text::lit("?Step")) {
                        prism_rtl::Turn::Finished(smaller(m, &or(&index(&args, &Nat::from(0u32)), &dummy_arg()).value))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    },
                    None => prism_rtl::Turn::Finished(None),
                },
                None => prism_rtl::Turn::Finished(None),
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DecrementOf, x`: what the function value is when passed to `@Run`.
pub fn start_decrement_of(m: Map<Text, Rel>, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Option<Rel>>> {
    Rc::new(DecrementOf { m, e })
}

/// ```prism
/// IsNatMinus: fn (Text ==> Rel), Expr -> Bool
/// ```
pub fn is_nat_minus(m: &Map<Text, Rel>, e: &crate::syntax::Expr) -> bool {
    pre_is(m, &Text::lit("-?"), &Text::lit("-?")) && is_nat_at(m, e)
}

/// ```prism
/// ?Smaller: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub fn smaller(m: &Map<Text, Rel>, x: &crate::syntax::Expr) -> Option<Rel> {
    match rel_of(m, x) {
        Some(r) => Some(Rel { param: r.param.clone(), strict: true }),
        None => None,
    }
}

/// ```prism
/// IsPositiveLit: fn Expr -> Bool
/// ```
pub fn is_positive_lit(e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::ELit(l) => match &l.kind {
            crate::syntax::LitKind::LInt(d) => d != &Text::lit("0"),
            _ => false,
        },
        crate::syntax::ExprKind::EGroup(x) => is_positive_lit(&**x),
        _ => false,
    }
}

/// ```prism
/// Closure: unbounded fn [Sc] -> [Sc]
/// ```
pub fn closure(graphs: &Array<Sc>) -> Array<Sc> {
    closure_from(graphs, &dedup(graphs), &dedup(graphs))
}

/// The step machine of `Closure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Closure: unbounded fn [Sc] -> [Sc]
/// ```
pub struct Closure {
    pub graphs: Array<Sc>,
}

impl prism_rtl::Job<Array<Sc>> for Closure {
    fn cycle(&self) -> prism_rtl::Turn<Array<Sc>> {
        let graphs = &self.graphs;
        prism_rtl::Turn::More(Rc::new(ClosureFrom { base: graphs.clone(), acc: dedup(graphs), frontier: dedup(graphs) }))
    }
}

/// `Start Closure, x`: what the function value is when passed to `@Run`.
pub fn start_closure(graphs: Array<Sc>) -> Rc<dyn prism_rtl::Job<Array<Sc>>> {
    Rc::new(Closure { graphs })
}

/// ```prism
/// Dedup: fn [Sc] -> [Sc]
/// ```
pub fn dedup(gs: &Array<Sc>) -> Array<Sc> {
    fold(gs, &Array::new(), &(|acc: &Array<Sc>, g: &Sc| if has_sc(acc, g) { acc.clone() } else { push(acc, g) }))
}

/// ```prism
/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
/// ```
pub fn closure_from(base: &Array<Sc>, acc: &Array<Sc>, frontier: &Array<Sc>) -> Array<Sc> {
    let fresh = fold(frontier, &Array::new(), &(|out: &Array<Sc>, a: &Sc| fold(base, out, &(|out2: &Array<Sc>, b: &Sc| add_composed(acc, out2, a, b)))));
    if &len(&fresh) == &Nat::from(0u32) {
        acc.clone()
    } else {
        closure_from(base, &append(acc, &fresh), &fresh)
    }
}

/// The step machine of `ClosureFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
/// ```
pub struct ClosureFrom {
    pub base: Array<Sc>,
    pub acc: Array<Sc>,
    pub frontier: Array<Sc>,
}

impl prism_rtl::Job<Array<Sc>> for ClosureFrom {
    fn cycle(&self) -> prism_rtl::Turn<Array<Sc>> {
        let base = &self.base;
        let acc = &self.acc;
        let frontier = &self.frontier;
        let fresh = fold(frontier, &Array::new(), &(|out: &Array<Sc>, a: &Sc| fold(base, out, &(|out2: &Array<Sc>, b: &Sc| add_composed(acc, out2, a, b)))));
        if &len(&fresh) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(acc.clone())
        } else {
            prism_rtl::Turn::More(Rc::new(ClosureFrom { base: base.clone(), acc: append(acc, &fresh), frontier: fresh.clone() }))
        }
    }
}

/// `Start ClosureFrom, x`: what the function value is when passed to `@Run`.
pub fn start_closure_from(base: Array<Sc>, acc: Array<Sc>, frontier: Array<Sc>) -> Rc<dyn prism_rtl::Job<Array<Sc>>> {
    Rc::new(ClosureFrom { base, acc, frontier })
}

/// ```prism
/// AddComposed: fn [Sc], [Sc], Sc, Sc -> [Sc]
/// ```
pub fn add_composed(acc: &Array<Sc>, out: &Array<Sc>, a: &Sc, b: &Sc) -> Array<Sc> {
    if &a.callee != &b.caller {
        out.clone()
    } else {
        {
            let c = compose(a, b);
            if has_sc(acc, &c) || has_sc(out, &c) { out.clone() } else { push(out, &c) }
        }
    }
}

/// ```prism
/// HasSc: fn [Sc], Sc -> Bool
/// ```
pub fn has_sc(xs: &Array<Sc>, c: &Sc) -> bool {
    fold(xs, &false, &(|seen: &bool, x: &Sc| *seen || (((&x.caller == &c.caller) && (&x.callee == &c.callee)) && (&x.edges == &c.edges))))
}

/// ```prism
/// Compose: fn Sc, Sc -> Sc
/// ```
pub fn compose(a: &Sc, b: &Sc) -> Sc {
    let pairs = fold(&a.edges, &Array::new(), &(|acc: &Array<(Nat, Nat, bool)>, (x, y, s1): &(Nat, Nat, bool)| fold(&b.edges, acc, &(|acc2: &Array<(Nat, Nat, bool)>, (y2, z, s2): &(Nat, Nat, bool)| if y == y2 { add_edge(acc2, x, z, &(*s1 || *s2)) } else { acc2.clone() }))));
    Sc { caller: a.caller.clone(), callee: b.callee.clone(), edges: sort_edges(&pairs), span: a.span.clone(), file: a.file.clone(), arg: a.arg.clone() }
}

/// ```prism
/// AddEdge: fn [((Nat, Nat, Bool))], Nat, Nat, Bool -> [((Nat, Nat, Bool))]
/// ```
pub fn add_edge(es: &Array<(Nat, Nat, bool)>, x: &Nat, z: &Nat, s: &bool) -> Array<(Nat, Nat, bool)> {
    let others = filter(es, &(|(a, b, _): &(Nat, Nat, bool)| !((a == x) && (b == z))));
    let had = fold(es, &false, &(|seen: &bool, (a, b, t): &(Nat, Nat, bool)| *seen || (((a == x) && (b == z)) && *t)));
    push(&others, &(x.clone(), z.clone(), *s || had))
}

/// ```prism
/// SortEdges: fn [((Nat, Nat, Bool))] -> [((Nat, Nat, Bool))]
/// ```
pub fn sort_edges(es: &Array<(Nat, Nat, bool)>) -> Array<(Nat, Nat, bool)> {
    fold(es, &Array::new(), &(|acc: &Array<(Nat, Nat, bool)>, e: &(Nat, Nat, bool)| append(&push(&filter(acc, &(|x: &(Nat, Nat, bool)| edge_before(x, e))), e), &filter(acc, &(|x: &(Nat, Nat, bool)| !edge_before(x, e))))))
}

/// ```prism
/// EdgeBefore: fn ((Nat, Nat, Bool)), ((Nat, Nat, Bool)) -> Bool
/// ```
pub fn edge_before(arg0: &(Nat, Nat, bool), arg1: &(Nat, Nat, bool)) -> bool {
    match (arg0, arg1) {
        ((a1, b1, _), (a2, b2, _)) => (a1 < a2) || ((a1 == a2) && (b1 < b2)),
    }
}

/// ```prism
/// LoopsOf: unbounded fn Shrink, St, Def -> St
/// ```
pub fn loops_of(sk: &Shrink, st: &crate::check::types::St, d: &crate::check::env::Def) -> crate::check::types::St {
    let unb = is_unbounded_key(&sk.g, &sig_key_of(sk, &d.qk));
    if unb && !st.recording {
        st.clone()
    } else {
        {
            let s0 = {
                let mut this: crate::check::types::St = st.clone();
                this.file = d.file.clone();
                this
            };
            let s1 = run_to_end(fold_job(def_clauses(d), s0.clone(), {
                let sk = sk.clone();
                let d = d.clone();
                let unb = unb;
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::FnClause)| {
                    let sk = sk.clone();
                    let d = d.clone();
                    let unb = unb;
                    entered(once_job(move || {
                        let s = p0;
                        let c = p1;
                        prism_rtl::Turn::More(Rc::new(ClauseLoops { sk: sk.clone(), st: s.clone(), d: d.clone(), c: c.clone(), unb }))
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }));
            {
                let mut this: crate::check::types::St = s1.clone();
                this.file = st.file.clone();
                this
            }
        }
    }
}

/// The step machine of `LoopsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LoopsOf: unbounded fn Shrink, St, Def -> St
/// ```
pub struct LoopsOf {
    pub sk: Shrink,
    pub st: crate::check::types::St,
    pub d: crate::check::env::Def,
}

impl prism_rtl::Job<crate::check::types::St> for LoopsOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let sk = &self.sk;
        let st = &self.st;
        let d = &self.d;
        let unb = is_unbounded_key(&sk.g, &sig_key_of(sk, &d.qk));
        if unb && !st.recording {
            prism_rtl::Turn::Finished(st.clone())
        } else {
            {
                let s0 = {
                    let mut this: crate::check::types::St = st.clone();
                    this.file = d.file.clone();
                    this
                };
                let d = d.clone();
                let sk = sk.clone();
                let st = st.clone();
                call_value(fold_job(def_clauses(&d), s0.clone(), {
                    let sk = sk.clone();
                    let d = d.clone();
                    let unb = unb;
                    Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::FnClause)| {
                        let sk = sk.clone();
                        let d = d.clone();
                        let unb = unb;
                        entered(once_job(move || {
                            let s = p0;
                            let c = p1;
                            prism_rtl::Turn::More(Rc::new(ClauseLoops { sk: sk.clone(), st: s.clone(), d: d.clone(), c: c.clone(), unb }))
                        }))
                    }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                }), move |fold_79766: crate::check::types::St| {
                    let s1 = fold_79766;
                    prism_rtl::Turn::Finished({
                        let mut this: crate::check::types::St = s1.clone();
                        this.file = st.file.clone();
                        this
                    })
                })
            }
        }
    }
}

/// `Start LoopsOf, x`: what the function value is when passed to `@Run`.
pub fn start_loops_of(sk: Shrink, st: crate::check::types::St, d: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(LoopsOf { sk, st, d })
}

/// ```prism
/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
/// ```
pub fn clause_loops(sk: &Shrink, st: &crate::check::types::St, d: &crate::check::env::Def, c: &crate::syntax::FnClause, unb: &bool) -> crate::check::types::St {
    let base = clause_base(sk, d, c);
    let spots0 = body_spots(&c.body, &base);
    if !fold(&spots0, &false, &(|seen: &bool, sp: &Spot| *seen || is_while_spot(sp))) {
        st.clone()
    } else {
        {
            let spots = body_spots(&c.body, &summary_seeds(sk, d, &spots0, &base));
            run_to_end(fold_job(filter(&spots, &(|sp: &Spot| is_while_spot(sp))), st.clone(), {
                let d = d.clone();
                let unb = *unb;
                Rc::new(move |(p0, p1): (crate::check::types::St, Spot)| {
                    let d = d.clone();
                    let unb = unb;
                    entered(once_job(move || {
                        let s = p0;
                        let sp = p1;
                        match &sp {
                            Spot::SpotStmt(w, m) => match &w.kind {
                                crate::syntax::StmtKind::SWhile(cond, body) => prism_rtl::Turn::More(Rc::new(CheckWhile { st: s.clone(), c: cond.clone(), body: body.clone(), span: w.span.clone(), name: d.name.clone(), seeds: marks(m), unb })),
                                _ => prism_rtl::Turn::Finished(s.clone()),
                            },
                            _ => prism_rtl::Turn::Finished(s.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, Spot)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }))
        }
    }
}

/// The step machine of `ClauseLoops`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
/// ```
pub struct ClauseLoops {
    pub sk: Shrink,
    pub st: crate::check::types::St,
    pub d: crate::check::env::Def,
    pub c: crate::syntax::FnClause,
    pub unb: bool,
}

impl prism_rtl::Job<crate::check::types::St> for ClauseLoops {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let sk = &self.sk;
        let st = &self.st;
        let d = &self.d;
        let c = &self.c;
        let unb = &self.unb;
        let c = c.clone();
        let d = d.clone();
        let sk = sk.clone();
        let st = st.clone();
        let unb = *unb;
        call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_79992: Map<Text, Rel>| {
            let base = clause_base_79992;
            call_then(start_body_spots(c.body.clone(), base.clone()), move |body_spots_80029: Array<Spot>| {
                let spots0 = body_spots_80029;
                if !fold(&spots0, &false, &(|seen: &bool, sp: &Spot| *seen || is_while_spot(sp))) {
                    prism_rtl::Turn::Finished(st.clone())
                } else {
                    call_then(start_summary_seeds(sk.clone(), d.clone(), spots0.clone(), base.clone()), move |summary_seeds_80173: Map<Text, Rel>| call_then(start_body_spots(c.body.clone(), summary_seeds_80173), move |body_spots_80154: Array<Spot>| {
                        let spots = body_spots_80154;
                        fold_job(filter(&spots, &(|sp: &Spot| is_while_spot(sp))), st.clone(), {
                            let d = d.clone();
                            let unb = unb;
                            Rc::new(move |(p0, p1): (crate::check::types::St, Spot)| {
                                let d = d.clone();
                                let unb = unb;
                                entered(once_job(move || {
                                    let s = p0;
                                    let sp = p1;
                                    match &sp {
                                        Spot::SpotStmt(w, m) => match &w.kind {
                                            crate::syntax::StmtKind::SWhile(cond, body) => prism_rtl::Turn::More(Rc::new(CheckWhile { st: s.clone(), c: cond.clone(), body: body.clone(), span: w.span.clone(), name: d.name.clone(), seeds: marks(m), unb })),
                                            _ => prism_rtl::Turn::Finished(s.clone()),
                                        },
                                        _ => prism_rtl::Turn::Finished(s.clone()),
                                    }
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, Spot)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle()
                    }))
                }
            })
        })
    }
}

/// `Start ClauseLoops, x`: what the function value is when passed to `@Run`.
pub fn start_clause_loops(sk: Shrink, st: crate::check::types::St, d: crate::check::env::Def, c: crate::syntax::FnClause, unb: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ClauseLoops { sk, st, d, c, unb })
}

/// ```prism
/// Marks: fn (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn marks(m: &Map<Text, Rel>) -> Map<Text, Rel> {
    fold(&keys(m), m, &(|m2: &Map<Text, Rel>, k: &Text| if crate::syntax::lexer::contains(k, &Text::lit(":")) {
        m2.clone()
    } else {
        remove(m2, k)
    }))
}

/// ```prism
/// IsWhileSpot: fn Spot -> Bool
/// ```
pub fn is_while_spot(spot0: &Spot) -> bool {
    match spot0 {
        Spot::SpotStmt(s, _) => match &s.kind {
            crate::syntax::StmtKind::SWhile(_, _) => true,
            _ => false,
        },
        Spot::SpotExpr(_, _) => false,
    }
}

/// ```prism
/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
/// ```
pub fn check_while(st: &crate::check::types::St, c: &crate::syntax::Cond, body: &crate::syntax::Block, span: &crate::syntax::Range, name: &Text, seeds: &Map<Text, Rel>, unb: &bool) -> crate::check::types::St {
    let vars = set_targets(&body.stmts);
    let base = fold(&crate::check::errors::range0(&len(&vars)), seeds, &(|m: &Map<Text, Rel>, i: &Nat| insert(m, &or(&index(&vars, i), &Text::lit("")), &Rel { param: i.clone(), strict: false })));
    let rels = cond_rels(c, &base);
    let ok = run_to_end(fold_job(crate::check::errors::range0(&len(&vars)), false, {
        let body = body.clone();
        let vars = vars.clone();
        let rels = rels.clone();
        Rc::new(move |(p0, p1): (bool, Nat)| {
            let body = body.clone();
            let vars = vars.clone();
            let rels = rels.clone();
            entered(once_job(move || {
                let seen = p0;
                let i = p1;
                prism_rtl::Turn::Finished(seen || all_paths_strict(&body.stmts, &or(&index(&vars, &i), &Text::lit("")), &i, &rels))
            }))
        }) as Rc<dyn Fn((bool, Nat)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    if ok {
        st.clone()
    } else {
        if *unb {
            note_unshrunk(st, span)
        } else {
            crate::check::types::err_fix(st, &Text::lit("may-not-end"), span, &Text::from(format!("this loop in `{}` may not end: nothing it sets gets smaller on every turn", name)), &Text::from(format!("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `{}` `unbounded fn`", name)))
        }
    }
}

/// The step machine of `CheckWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
/// ```
pub struct CheckWhile {
    pub st: crate::check::types::St,
    pub c: crate::syntax::Cond,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
    pub name: Text,
    pub seeds: Map<Text, Rel>,
    pub unb: bool,
}

impl prism_rtl::Job<crate::check::types::St> for CheckWhile {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let c = &self.c;
        let body = &self.body;
        let span = &self.span;
        let name = &self.name;
        let seeds = &self.seeds;
        let unb = &self.unb;
        let body = body.clone();
        let c = c.clone();
        let name = name.clone();
        let seeds = seeds.clone();
        let span = span.clone();
        let st = st.clone();
        let unb = *unb;
        call_then(start_set_targets(body.stmts.clone()), move |set_targets_81280: Array<Text>| {
            let vars = set_targets_81280;
            let base = fold(&crate::check::errors::range0(&len(&vars)), &seeds, &(|m: &Map<Text, Rel>, i: &Nat| insert(m, &or(&index(&vars, i), &Text::lit("")), &Rel { param: i.clone(), strict: false })));
            call_then(start_cond_rels(c.clone(), base.clone()), move |cond_rels_81594: Map<Text, Rel>| {
                let rels = cond_rels_81594;
                call_value(fold_job(crate::check::errors::range0(&len(&vars)), false, {
                    let body = body.clone();
                    let vars = vars.clone();
                    let rels = rels.clone();
                    Rc::new(move |(p0, p1): (bool, Nat)| {
                        let body = body.clone();
                        let vars = vars.clone();
                        let rels = rels.clone();
                        entered(once_job(move || {
                            let seen = p0;
                            let i = p1;
                            prism_rtl::Turn::Finished(seen || all_paths_strict(&body.stmts, &or(&index(&vars, &i), &Text::lit("")), &i, &rels))
                        }))
                    }) as Rc<dyn Fn((bool, Nat)) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |fold_81624: bool| {
                    let ok = fold_81624;
                    if ok {
                        prism_rtl::Turn::Finished(st.clone())
                    } else {
                        if unb {
                            prism_rtl::Turn::Finished(note_unshrunk(&st, &span))
                        } else {
                            prism_rtl::Turn::Finished(crate::check::types::err_fix(&st, &Text::lit("may-not-end"), &span, &Text::from(format!("this loop in `{}` may not end: nothing it sets gets smaller on every turn", &name)), &Text::from(format!("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `{}` `unbounded fn`", &name))))
                        }
                    }
                })
            })
        })
    }
}

/// `Start CheckWhile, x`: what the function value is when passed to `@Run`.
pub fn start_check_while(st: crate::check::types::St, c: crate::syntax::Cond, body: crate::syntax::Block, span: crate::syntax::Range, name: Text, seeds: Map<Text, Rel>, unb: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckWhile { st, c, body, span, name, seeds, unb })
}

/// ```prism
/// NoteUnshrunk: fn St, Range -> St
/// ```
pub fn note_unshrunk(st: &crate::check::types::St, span: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st.clone();
    this.typed.unshrunk = push(&this.typed.unshrunk, &crate::check::types::at_here(st, span));
    this
}

/// ```prism
/// SetTargets: unbounded fn [Stmt] -> [Text]
/// ```
pub fn set_targets(stmts: &Array<crate::syntax::Stmt>) -> Array<Text> {
    run_to_end(fold_job(stmts_spots(stmts, &Map::new()), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, Spot)| entered(once_job(move || {
        let acc = p0;
        let sp = p1;
        call_then(start_spot_set_root(sp.clone()), move |spot_set_root_82490: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &spot_set_root_82490)))
    }))) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `SetTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetTargets: unbounded fn [Stmt] -> [Text]
/// ```
pub struct SetTargets {
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<Text>> for SetTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let stmts = &self.stmts;
        let stmts = stmts.clone();
        call_then(start_stmts_spots(stmts.clone(), Map::new()), move |stmts_spots_82433: Array<Spot>| fold_job(stmts_spots_82433, Array::new(), Rc::new(move |(p0, p1): (Array<Text>, Spot)| entered(once_job(move || {
            let acc = p0;
            let sp = p1;
            call_then(start_spot_set_root(sp.clone()), move |spot_set_root_82490: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &spot_set_root_82490)))
        }))) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
    }
}

/// `Start SetTargets, x`: what the function value is when passed to `@Run`.
pub fn start_set_targets(stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SetTargets { stmts })
}

/// ```prism
/// SpotSetRoot: unbounded fn Spot -> [Text]
/// ```
pub fn spot_set_root(spot0: &Spot) -> Array<Text> {
    match spot0 {
        Spot::SpotStmt(s, _) => match &s.kind {
            crate::syntax::StmtKind::SSet(t, _) => take(&crate::check::passes::ref_path(t), &Nat::from(1u32)),
            crate::syntax::StmtKind::SAccum(t, _, _) => take(&crate::check::passes::ref_path(t), &Nat::from(1u32)),
            _ => Array::new(),
        },
        Spot::SpotExpr(_, _) => Array::new(),
    }
}

/// The step machine of `SpotSetRoot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotSetRoot: unbounded fn Spot -> [Text]
/// ```
pub struct SpotSetRoot {
    pub spot0: Spot,
}

impl prism_rtl::Job<Array<Text>> for SpotSetRoot {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let spot0 = &self.spot0;
        match spot0 {
            Spot::SpotStmt(s, _) => match &s.kind {
                crate::syntax::StmtKind::SSet(t, _) => {
                    let t = t.clone();
                    call_then(crate::check::passes::start_ref_path(t.clone()), move |ref_path_82626: Array<Text>| prism_rtl::Turn::Finished(take(&ref_path_82626, &Nat::from(1u32))))
                },
                crate::syntax::StmtKind::SAccum(t, _, _) => {
                    let t = t.clone();
                    call_then(crate::check::passes::start_ref_path(t.clone()), move |ref_path_82676: Array<Text>| prism_rtl::Turn::Finished(take(&ref_path_82676, &Nat::from(1u32))))
                },
                _ => prism_rtl::Turn::Finished(Array::new()),
            },
            Spot::SpotExpr(_, _) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start SpotSetRoot, x`: what the function value is when passed to `@Run`.
pub fn start_spot_set_root(spot0: Spot) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotSetRoot { spot0 })
}

/// ```prism
/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn all_paths_strict(stmts: &Array<crate::syntax::Stmt>, v_: &Text, vi: &Nat, outer: &Map<Text, Rel>) -> bool {
    let rels = block_rels(stmts, outer);
    run_to_end(fold_job(stmts.clone(), false, {
        let v_ = v_.clone();
        let vi = vi.clone();
        let rels = rels.clone();
        Rc::new(move |(p0, p1): (bool, crate::syntax::Stmt)| {
            let v_ = v_.clone();
            let vi = vi.clone();
            let rels = rels.clone();
            entered(once_job(move || {
                let ok = p0;
                let s = p1;
                match &s.kind {
                    crate::syntax::StmtKind::SSet(t, value) => {
                        let t = t.clone();
                        let value = value.clone();
                        call_then(crate::check::passes::start_ref_path(t.clone()), move |ref_path_83361: Array<Text>| if &ref_path_83361 == &Array::from(vec![v_.clone()]) {
                            if is_zero_lit(&value) {
                                prism_rtl::Turn::Finished(ok)
                            } else {
                                prism_rtl::Turn::More(Rc::new(SetsStrict { e: value.clone(), v_: v_.clone(), vi: vi.clone(), rels: rels.clone() }))
                            }
                        } else {
                            prism_rtl::Turn::Finished(ok && !stmt_sets_weak(&s, &v_, &vi, &rels))
                        })
                    },
                    crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                        crate::syntax::ExprKind::EIf(c, tb, eb_opt) => {
                            let eb_opt = eb_opt.clone();
                            let c = (**c).clone();
                            let tb = tb.clone();
                            call_then(start_cond_rels(c.clone(), rels.clone()), move |cond_rels_83586: Map<Text, Rel>| {
                                let tr = cond_rels_83586;
                                match &eb_opt {
                                    Some(b) => {
                                        let b = b.clone();
                                        call_then(start_all_paths_strict(tb.stmts.clone(), v_.clone(), vi.clone(), tr.clone()), move |all_paths_strict_83659: bool| if all_paths_strict_83659 && all_paths_strict(&b.stmts, &v_, &vi, &rels) {
                                            prism_rtl::Turn::Finished(true)
                                        } else {
                                            prism_rtl::Turn::Finished((ok && !sets_weak(&tb.stmts, &v_, &vi, &tr)) && !sets_weak(&b.stmts, &v_, &vi, &rels))
                                        })
                                    },
                                    None => prism_rtl::Turn::Finished(ok && !sets_weak(&tb.stmts, &v_, &vi, &tr)),
                                }
                            })
                        },
                        crate::syntax::ExprKind::EMatch(subj, arms) => {
                            let arms = arms.clone();
                            let subj = (**subj).clone();
                            call_value(fold_job(arms.clone(), true, {
                                let v_ = v_.clone();
                                let vi = vi.clone();
                                let subj = subj.clone();
                                let rels = rels.clone();
                                Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                    let v_ = v_.clone();
                                    let vi = vi.clone();
                                    let subj = subj.clone();
                                    let rels = rels.clone();
                                    entered(once_job(move || {
                                        let all_arms = p0;
                                        let a = p1;
                                        prism_rtl::Turn::Finished(all_arms && all_paths_strict(&a.body.stmts, &v_, &vi, &arm_pat_rels(&subj, &a, &rels)))
                                    }))
                                }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }), move |fold_83948: bool| if fold_83948 {
                                prism_rtl::Turn::Finished(true)
                            } else {
                                prism_rtl::Turn::Finished(ok && !run_to_end(fold_job(arms.clone(), false, {
                                    let v_ = v_.clone();
                                    let vi = vi.clone();
                                    let subj = subj.clone();
                                    let rels = rels.clone();
                                    Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                        let v_ = v_.clone();
                                        let vi = vi.clone();
                                        let subj = subj.clone();
                                        let rels = rels.clone();
                                        entered(once_job(move || {
                                            let any_arm = p0;
                                            let a = p1;
                                            prism_rtl::Turn::Finished(any_arm || sets_weak(&a.body.stmts, &v_, &vi, &arm_pat_rels(&subj, &a, &rels)))
                                        }))
                                    }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                                })))
                            })
                        },
                        _ => prism_rtl::Turn::Finished(ok && !stmt_sets_weak(&s, &v_, &vi, &rels)),
                    },
                    _ => prism_rtl::Turn::Finished(ok && !stmt_sets_weak(&s, &v_, &vi, &rels)),
                }
            }))
        }) as Rc<dyn Fn((bool, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `AllPathsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct AllPathsStrict {
    pub stmts: Array<crate::syntax::Stmt>,
    pub v_: Text,
    pub vi: Nat,
    pub outer: Map<Text, Rel>,
}

impl prism_rtl::Job<bool> for AllPathsStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let stmts = &self.stmts;
        let v_ = &self.v_;
        let vi = &self.vi;
        let outer = &self.outer;
        let outer = outer.clone();
        let stmts = stmts.clone();
        let v_ = v_.clone();
        let vi = vi.clone();
        call_then(start_block_rels(stmts.clone(), outer.clone()), move |block_rels_83253: Map<Text, Rel>| {
            let rels = block_rels_83253;
            fold_job(stmts.clone(), false, {
                let v_ = v_.clone();
                let vi = vi.clone();
                let rels = rels.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Stmt)| {
                    let v_ = v_.clone();
                    let vi = vi.clone();
                    let rels = rels.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let s = p1;
                        match &s.kind {
                            crate::syntax::StmtKind::SSet(t, value) => {
                                let t = t.clone();
                                let value = value.clone();
                                call_then(crate::check::passes::start_ref_path(t.clone()), move |ref_path_83361: Array<Text>| if &ref_path_83361 == &Array::from(vec![v_.clone()]) {
                                    if is_zero_lit(&value) {
                                        prism_rtl::Turn::Finished(ok)
                                    } else {
                                        prism_rtl::Turn::More(Rc::new(SetsStrict { e: value.clone(), v_: v_.clone(), vi: vi.clone(), rels: rels.clone() }))
                                    }
                                } else {
                                    prism_rtl::Turn::Finished(ok && !stmt_sets_weak(&s, &v_, &vi, &rels))
                                })
                            },
                            crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                                crate::syntax::ExprKind::EIf(c, tb, eb_opt) => {
                                    let eb_opt = eb_opt.clone();
                                    let c = (**c).clone();
                                    let tb = tb.clone();
                                    call_then(start_cond_rels(c.clone(), rels.clone()), move |cond_rels_83586: Map<Text, Rel>| {
                                        let tr = cond_rels_83586;
                                        match &eb_opt {
                                            Some(b) => {
                                                let b = b.clone();
                                                call_then(start_all_paths_strict(tb.stmts.clone(), v_.clone(), vi.clone(), tr.clone()), move |all_paths_strict_83659: bool| if all_paths_strict_83659 && all_paths_strict(&b.stmts, &v_, &vi, &rels) {
                                                    prism_rtl::Turn::Finished(true)
                                                } else {
                                                    prism_rtl::Turn::Finished((ok && !sets_weak(&tb.stmts, &v_, &vi, &tr)) && !sets_weak(&b.stmts, &v_, &vi, &rels))
                                                })
                                            },
                                            None => prism_rtl::Turn::Finished(ok && !sets_weak(&tb.stmts, &v_, &vi, &tr)),
                                        }
                                    })
                                },
                                crate::syntax::ExprKind::EMatch(subj, arms) => {
                                    let arms = arms.clone();
                                    let subj = (**subj).clone();
                                    call_value(fold_job(arms.clone(), true, {
                                        let v_ = v_.clone();
                                        let vi = vi.clone();
                                        let subj = subj.clone();
                                        let rels = rels.clone();
                                        Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                            let v_ = v_.clone();
                                            let vi = vi.clone();
                                            let subj = subj.clone();
                                            let rels = rels.clone();
                                            entered(once_job(move || {
                                                let all_arms = p0;
                                                let a = p1;
                                                prism_rtl::Turn::Finished(all_arms && all_paths_strict(&a.body.stmts, &v_, &vi, &arm_pat_rels(&subj, &a, &rels)))
                                            }))
                                        }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }), move |fold_83948: bool| if fold_83948 {
                                        prism_rtl::Turn::Finished(true)
                                    } else {
                                        prism_rtl::Turn::Finished(ok && !run_to_end(fold_job(arms.clone(), false, {
                                            let v_ = v_.clone();
                                            let vi = vi.clone();
                                            let subj = subj.clone();
                                            let rels = rels.clone();
                                            Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                                let v_ = v_.clone();
                                                let vi = vi.clone();
                                                let subj = subj.clone();
                                                let rels = rels.clone();
                                                entered(once_job(move || {
                                                    let any_arm = p0;
                                                    let a = p1;
                                                    prism_rtl::Turn::Finished(any_arm || sets_weak(&a.body.stmts, &v_, &vi, &arm_pat_rels(&subj, &a, &rels)))
                                                }))
                                            }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                                        })))
                                    })
                                },
                                _ => prism_rtl::Turn::Finished(ok && !stmt_sets_weak(&s, &v_, &vi, &rels)),
                            },
                            _ => prism_rtl::Turn::Finished(ok && !stmt_sets_weak(&s, &v_, &vi, &rels)),
                        }
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle()
        })
    }
}

/// `Start AllPathsStrict, x`: what the function value is when passed to `@Run`.
pub fn start_all_paths_strict(stmts: Array<crate::syntax::Stmt>, v_: Text, vi: Nat, outer: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(AllPathsStrict { stmts, v_, vi, outer })
}

/// ```prism
/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn sets_weak(stmts: &Array<crate::syntax::Stmt>, v_: &Text, vi: &Nat, outer: &Map<Text, Rel>) -> bool {
    run_to_end(fold_job(stmts_spots(stmts, outer), false, {
        let v_ = v_.clone();
        let vi = vi.clone();
        Rc::new(move |(p0, p1): (bool, Spot)| {
            let v_ = v_.clone();
            let vi = vi.clone();
            entered(once_job(move || {
                let seen = p0;
                let sp = p1;
                prism_rtl::Turn::Finished(seen || spot_sets_weak(&sp, &v_, &vi))
            }))
        }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `SetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct SetsWeak {
    pub stmts: Array<crate::syntax::Stmt>,
    pub v_: Text,
    pub vi: Nat,
    pub outer: Map<Text, Rel>,
}

impl prism_rtl::Job<bool> for SetsWeak {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let stmts = &self.stmts;
        let v_ = &self.v_;
        let vi = &self.vi;
        let outer = &self.outer;
        let outer = outer.clone();
        let stmts = stmts.clone();
        let v_ = v_.clone();
        let vi = vi.clone();
        call_then(start_stmts_spots(stmts.clone(), outer.clone()), move |stmts_spots_84595: Array<Spot>| fold_job(stmts_spots_84595, false, {
            let v_ = v_.clone();
            let vi = vi.clone();
            Rc::new(move |(p0, p1): (bool, Spot)| {
                let v_ = v_.clone();
                let vi = vi.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let sp = p1;
                    prism_rtl::Turn::Finished(seen || spot_sets_weak(&sp, &v_, &vi))
                }))
            }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start SetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_sets_weak(stmts: Array<crate::syntax::Stmt>, v_: Text, vi: Nat, outer: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SetsWeak { stmts, v_, vi, outer })
}

/// ```prism
/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn stmt_sets_weak(s: &crate::syntax::Stmt, v_: &Text, vi: &Nat, rels: &Map<Text, Rel>) -> bool {
    run_to_end(fold_job(stmt_spots(s, rels), false, {
        let v_ = v_.clone();
        let vi = vi.clone();
        Rc::new(move |(p0, p1): (bool, Spot)| {
            let v_ = v_.clone();
            let vi = vi.clone();
            entered(once_job(move || {
                let seen = p0;
                let sp = p1;
                prism_rtl::Turn::Finished(seen || spot_sets_weak(&sp, &v_, &vi))
            }))
        }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `StmtSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct StmtSetsWeak {
    pub s: crate::syntax::Stmt,
    pub v_: Text,
    pub vi: Nat,
    pub rels: Map<Text, Rel>,
}

impl prism_rtl::Job<bool> for StmtSetsWeak {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let s = &self.s;
        let v_ = &self.v_;
        let vi = &self.vi;
        let rels = &self.rels;
        let rels = rels.clone();
        let s = s.clone();
        let v_ = v_.clone();
        let vi = vi.clone();
        call_then(start_stmt_spots(s.clone(), rels.clone()), move |stmt_spots_84778: Array<Spot>| fold_job(stmt_spots_84778, false, {
            let v_ = v_.clone();
            let vi = vi.clone();
            Rc::new(move |(p0, p1): (bool, Spot)| {
                let v_ = v_.clone();
                let vi = vi.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let sp = p1;
                    prism_rtl::Turn::Finished(seen || spot_sets_weak(&sp, &v_, &vi))
                }))
            }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start StmtSetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_sets_weak(s: crate::syntax::Stmt, v_: Text, vi: Nat, rels: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(StmtSetsWeak { s, v_, vi, rels })
}

/// ```prism
/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub fn spot_sets_weak(spot0: &Spot, text1: &Text, n2: &Nat) -> bool {
    match (spot0, text1, n2) {
        (Spot::SpotStmt(s, m), v_, vi) => match &s.kind {
            crate::syntax::StmtKind::SSet(t, value) => ((&take(&crate::check::passes::ref_path(t), &Nat::from(1u32)) == &Array::from(vec![v_.clone()])) && !sets_strict(value, v_, vi, m)) && !((&crate::check::passes::ref_path(t) == &Array::from(vec![v_.clone()])) && is_zero_lit(value)),
            crate::syntax::StmtKind::SAccum(t, _, _) => &take(&crate::check::passes::ref_path(t), &Nat::from(1u32)) == &Array::from(vec![v_.clone()]),
            _ => false,
        },
        (Spot::SpotExpr(_, _), _, _) => false,
    }
}

/// The step machine of `SpotSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub struct SpotSetsWeak {
    pub spot0: Spot,
    pub text1: Text,
    pub n2: Nat,
}

impl prism_rtl::Job<bool> for SpotSetsWeak {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let spot0 = &self.spot0;
        let text1 = &self.text1;
        let n2 = &self.n2;
        match (spot0, text1, n2) {
            (Spot::SpotStmt(s, m), v_, vi) => match &s.kind {
                crate::syntax::StmtKind::SSet(t, value) => {
                    let m = m.clone();
                    let t = t.clone();
                    let v_ = v_.clone();
                    let value = value.clone();
                    let vi = vi.clone();
                    call_then(crate::check::passes::start_ref_path(t.clone()), move |ref_path_84981: Array<Text>| prism_rtl::Turn::Finished(((&take(&ref_path_84981, &Nat::from(1u32)) == &Array::from(vec![v_.clone()])) && !sets_strict(&value, &v_, &vi, &m)) && !((&crate::check::passes::ref_path(&t) == &Array::from(vec![v_.clone()])) && is_zero_lit(&value))))
                },
                crate::syntax::StmtKind::SAccum(t, _, _) => {
                    let t = t.clone();
                    let v_ = v_.clone();
                    call_then(crate::check::passes::start_ref_path(t.clone()), move |ref_path_85130: Array<Text>| prism_rtl::Turn::Finished(&take(&ref_path_85130, &Nat::from(1u32)) == &Array::from(vec![v_.clone()])))
                },
                _ => prism_rtl::Turn::Finished(false),
            },
            (Spot::SpotExpr(_, _), _, _) => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start SpotSetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_spot_sets_weak(spot0: Spot, text1: Text, n2: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SpotSetsWeak { spot0, text1, n2 })
}

/// ```prism
/// IsZeroLit: fn Expr -> Bool
/// ```
pub fn is_zero_lit(e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::ELit(l) => match &l.kind {
            crate::syntax::LitKind::LInt(d) => d == &Text::lit("0"),
            _ => false,
        },
        crate::syntax::ExprKind::EGroup(x) => is_zero_lit(&**x),
        _ => false,
    }
}

/// ```prism
/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn sets_strict(e: &crate::syntax::Expr, v_: &Text, vi: &Nat, rels: &Map<Text, Rel>) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::EGroup(x) => sets_strict(&**x, v_, vi, rels),
        crate::syntax::ExprKind::EBinary(m86507_1_0, l, _) if (m86507_1_0 == &Text::lit("-?")) => is_nat_minus(rels, e) && sets_strict(&**l, v_, vi, rels),
        _ => rel_strict(rels, e, vi) || call_strict(e, v_, vi, rels),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SetsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct SetsStrict {
    pub e: crate::syntax::Expr,
    pub v_: Text,
    pub vi: Nat,
    pub rels: Map<Text, Rel>,
}

impl prism_rtl::Job<bool> for SetsStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let e = &self.e;
        let v_ = &self.v_;
        let vi = &self.vi;
        let rels = &self.rels;
        match &*e.kind {
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(SetsStrict { e: (**x).clone(), v_: v_.clone(), vi: vi.clone(), rels: rels.clone() })),
            crate::syntax::ExprKind::EBinary(m86507_1_0, l, _) if (m86507_1_0 == &Text::lit("-?")) => prism_rtl::Turn::Finished(is_nat_minus(rels, e) && sets_strict(&**l, v_, vi, rels)),
            _ => {
                let e = e.clone();
                let rels = rels.clone();
                let v_ = v_.clone();
                let vi = vi.clone();
                call_then(start_rel_strict(rels.clone(), e.clone(), vi.clone()), move |rel_strict_86657: bool| prism_rtl::Turn::Finished(rel_strict_86657 || call_strict(&e, &v_, &vi, &rels)))
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SetsStrict, x`: what the function value is when passed to `@Run`.
pub fn start_sets_strict(e: crate::syntax::Expr, v_: Text, vi: Nat, rels: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SetsStrict { e, v_, vi, rels })
}

/// ```prism
/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
/// ```
pub fn rel_strict(rels: &Map<Text, Rel>, e: &crate::syntax::Expr, vi: &Nat) -> bool {
    match rel_of(rels, e) {
        Some(r) => r.strict && (&r.param == vi),
        None => false,
    }
}

/// The step machine of `RelStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
/// ```
pub struct RelStrict {
    pub rels: Map<Text, Rel>,
    pub e: crate::syntax::Expr,
    pub vi: Nat,
}

impl prism_rtl::Job<bool> for RelStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let rels = &self.rels;
        let e = &self.e;
        let vi = &self.vi;
        let e = e.clone();
        let rels = rels.clone();
        let vi = vi.clone();
        call_then(start_rel_of(rels.clone(), e.clone()), move |rel_of_86803: Option<Rel>| match rel_of_86803 {
            Some(r) => prism_rtl::Turn::Finished(r.strict && (&r.param == &vi)),
            None => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start RelStrict, x`: what the function value is when passed to `@Run`.
pub fn start_rel_strict(rels: Map<Text, Rel>, e: crate::syntax::Expr, vi: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(RelStrict { rels, e, vi })
}

/// ```prism
/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn call_strict(e: &crate::syntax::Expr, v_: &Text, vi: &Nat, rels: &Map<Text, Rel>) -> bool {
    match call_of(e) {
        Some((c, args)) => if is_non_nat_min(rels, e, &c) {
            false
        } else {
            match no_larger_arg(rels, &c, &args) {
                Some(a) => sets_strict(&a, v_, vi, rels),
                None => false,
            }
        },
        None => false,
    }
}

/// The step machine of `CallStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct CallStrict {
    pub e: crate::syntax::Expr,
    pub v_: Text,
    pub vi: Nat,
    pub rels: Map<Text, Rel>,
}

impl prism_rtl::Job<bool> for CallStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let e = &self.e;
        let v_ = &self.v_;
        let vi = &self.vi;
        let rels = &self.rels;
        match call_of(e) {
            Some((c, args)) => if is_non_nat_min(rels, e, &c) {
                prism_rtl::Turn::Finished(false)
            } else {
                match no_larger_arg(rels, &c, &args) {
                    Some(a) => prism_rtl::Turn::More(Rc::new(SetsStrict { e: a.clone(), v_: v_.clone(), vi: vi.clone(), rels: rels.clone() })),
                    None => prism_rtl::Turn::Finished(false),
                }
            },
            None => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start CallStrict, x`: what the function value is when passed to `@Run`.
pub fn start_call_strict(e: crate::syntax::Expr, v_: Text, vi: Nat, rels: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(CallStrict { e, v_, vi, rels })
}
