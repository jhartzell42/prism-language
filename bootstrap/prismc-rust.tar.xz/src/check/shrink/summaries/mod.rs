//! The module `Check.Shrink.Summaries`, from `target/bootstrap/src/prismc/check/shrink/summaries.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
/// ```
pub fn parts_summaries_f(sk_p0: &crate::check::shrink::Shrink, fns_p1: &Array<crate::check::env::Def>) -> Map<Text, Nat> {
    crate::prelude::run_to_end(crate::prelude::fold_job(fns_p1.clone(), Map::new(), {
        let sk_p0x = sk_p0.clone();
        Rc::new(move |(p0, p1): (Map<Text, Nat>, crate::check::env::Def)| {
            let sk_p0xy = sk_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p2 = p0;
                let d_p3 = p1;
                match &d_p3.body_p {
                    crate::check::env::DefBody::DbFn(clauses_p4) => {
                        let n_p5 = match crate::prelude::index(clauses_p4, &Nat::from(0u32)) {
                            Some(c0_p7) => crate::prelude::len(&c0_p7.params_p),
                            None => Nat::from(0u32),
                        };
                        let clauses_p4x = clauses_p4.clone();
                        crate::prelude::call_value(crate::prelude::filter_job(crate::check::errors::range0_f(&n_p5), {
                            let clauses_p4xx = clauses_p4x.clone();
                            let sk_p0xyx = sk_p0xy.clone();
                            let d_p3x = d_p3.clone();
                            Rc::new(move |p0: Nat| {
                                let clauses_p4xxy = clauses_p4xx.clone();
                                let sk_p0xyxy = sk_p0xyx.clone();
                                let d_p3xy = d_p3x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let i_p8 = p0;
                                    crate::prelude::fold_job(clauses_p4xxy.clone(), true, {
                                        let sk_p0xyxyx = sk_p0xyxy.clone();
                                        let d_p3xyx = d_p3xy.clone();
                                        let i_p8x = i_p8.clone();
                                        Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                                            let sk_p0xyxyxy = sk_p0xyxyx.clone();
                                            let d_p3xyxy = d_p3xyx.clone();
                                            let i_p8xy = i_p8x.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let okc_p9 = p0;
                                                let c_pa = p1;
                                                prism_rtl::Turn::Finished(okc_p9 && clause_within_f(&crate::check::shrink::locals::clause_base_f(&sk_p0xyxyxy, &d_p3xyxy, &c_pa), &c_pa, &i_p8xy))
                                            }))
                                        }) as Rc<dyn Fn((bool, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }).cycle()
                                }))
                            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |filter_2084: Array<Nat>| {
                            let ok_p6 = filter_2084;
                            match crate::prelude::index(&ok_p6, &Nat::from(0u32)) {
                                Some(i_pb) => prism_rtl::Turn::Finished(crate::prelude::insert(&m_p2, &d_p3.qk_p, &i_pb)),
                                None => prism_rtl::Turn::Finished(m_p2.clone()),
                            }
                        })
                    },
                    _ => prism_rtl::Turn::Finished(m_p2.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Nat>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
    }))
}

/// The step machine of `PartsSummaries`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
/// ```
pub struct PartsSummaries {
    pub sk_p0: crate::check::shrink::Shrink,
    pub fns_p1: Array<crate::check::env::Def>,
}

impl prism_rtl::Job<Map<Text, Nat>> for PartsSummaries {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Nat>> {
        let sk_p0 = &self.sk_p0;
        let fns_p1 = &self.fns_p1;
        crate::prelude::fold_job(fns_p1.clone(), Map::new(), {
            let sk_p0x = sk_p0.clone();
            Rc::new(move |(p0, p1): (Map<Text, Nat>, crate::check::env::Def)| {
                let sk_p0xy = sk_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m_p2 = p0;
                    let d_p3 = p1;
                    match &d_p3.body_p {
                        crate::check::env::DefBody::DbFn(clauses_p4) => {
                            let n_p5 = match crate::prelude::index(clauses_p4, &Nat::from(0u32)) {
                                Some(c0_p7) => crate::prelude::len(&c0_p7.params_p),
                                None => Nat::from(0u32),
                            };
                            let clauses_p4x = clauses_p4.clone();
                            crate::prelude::call_value(crate::prelude::filter_job(crate::check::errors::range0_f(&n_p5), {
                                let clauses_p4xx = clauses_p4x.clone();
                                let sk_p0xyx = sk_p0xy.clone();
                                let d_p3x = d_p3.clone();
                                Rc::new(move |p0: Nat| {
                                    let clauses_p4xxy = clauses_p4xx.clone();
                                    let sk_p0xyxy = sk_p0xyx.clone();
                                    let d_p3xy = d_p3x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let i_p8 = p0;
                                        crate::prelude::fold_job(clauses_p4xxy.clone(), true, {
                                            let sk_p0xyxyx = sk_p0xyxy.clone();
                                            let d_p3xyx = d_p3xy.clone();
                                            let i_p8x = i_p8.clone();
                                            Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                                                let sk_p0xyxyxy = sk_p0xyxyx.clone();
                                                let d_p3xyxy = d_p3xyx.clone();
                                                let i_p8xy = i_p8x.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let okc_p9 = p0;
                                                    let c_pa = p1;
                                                    prism_rtl::Turn::Finished(okc_p9 && clause_within_f(&crate::check::shrink::locals::clause_base_f(&sk_p0xyxyxy, &d_p3xyxy, &c_pa), &c_pa, &i_p8xy))
                                                }))
                                            }) as Rc<dyn Fn((bool, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
                                        }).cycle()
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<bool>>>
                            }), move |filter_2084: Array<Nat>| {
                                let ok_p6 = filter_2084;
                                match crate::prelude::index(&ok_p6, &Nat::from(0u32)) {
                                    Some(i_pb) => prism_rtl::Turn::Finished(crate::prelude::insert(&m_p2, &d_p3.qk_p, &i_pb)),
                                    None => prism_rtl::Turn::Finished(m_p2.clone()),
                                }
                            })
                        },
                        _ => prism_rtl::Turn::Finished(m_p2.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Nat>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
        }).cycle()
    }
}

/// `Start PartsSummaries, x`: what the function value is when passed to `@Run`.
pub fn start_parts_summaries_f(sk_p0: crate::check::shrink::Shrink, fns_p1: Array<crate::check::env::Def>) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>> {
    Rc::new(PartsSummaries { sk_p0, fns_p1 })
}

/// ```prism
/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
/// ```
pub fn clause_within_f(base_p0: &Map<Text, crate::check::shrink::Rel>, c_p1: &crate::syntax::decls::FnClause, i_p2: &Nat) -> bool {
    match &c_p1.body_p {
        crate::syntax::decls::FnBody::BodyExpr(e_p3) => within_f(base_p0, i_p2, e_p3),
        crate::syntax::decls::FnBody::BodyBlock(b_p4) => within_block_f(base_p0, i_p2, b_p4),
    }
}

/// The step machine of `ClauseWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
/// ```
pub struct ClauseWithin {
    pub base_p0: Map<Text, crate::check::shrink::Rel>,
    pub c_p1: crate::syntax::decls::FnClause,
    pub i_p2: Nat,
}

impl prism_rtl::Job<bool> for ClauseWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let base_p0 = &self.base_p0;
        let c_p1 = &self.c_p1;
        let i_p2 = &self.i_p2;
        match &c_p1.body_p {
            crate::syntax::decls::FnBody::BodyExpr(e_p3) => prism_rtl::Turn::More(Rc::new(Within { m_p0: base_p0.clone(), i_p1: i_p2.clone(), e_p2: e_p3.clone() })),
            crate::syntax::decls::FnBody::BodyBlock(b_p4) => prism_rtl::Turn::More(Rc::new(WithinBlock { m_p0: base_p0.clone(), i_p1: i_p2.clone(), b_p2: b_p4.clone() })),
        }
    }
}

/// `Start ClauseWithin, x`: what the function value is when passed to `@Run`.
pub fn start_clause_within_f(base_p0: Map<Text, crate::check::shrink::Rel>, c_p1: crate::syntax::decls::FnClause, i_p2: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(ClauseWithin { base_p0, c_p1, i_p2 })
}

/// ```prism
/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub fn within_f(m_p0: &Map<Text, crate::check::shrink::Rel>, i_p1: &Nat, e_p2: &crate::syntax::Expr) -> bool {
    match crate::check::shrink::walk::rel_of_o(m_p0, e_p2) {
        Some(r_p3) => &r_p3.param_p == i_p1,
        None => match &*e_p2.kind_p {
            crate::syntax::ExprKind::EArray(es_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(es_p4.clone(), true, {
                let m_p0x = m_p0.clone();
                let i_p1x = i_p1.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                    let m_p0xy = m_p0x.clone();
                    let i_p1xy = i_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p5 = p0;
                        let x_p6 = p1;
                        prism_rtl::Turn::Finished(ok_p5 && part_f(&m_p0xy, &i_p1xy, &x_p6))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
            })),
            crate::syntax::ExprKind::EMap(kvs_p7) => crate::prelude::run_to_end(crate::prelude::fold_job(kvs_p7.clone(), true, {
                let m_p0x = m_p0.clone();
                let i_p1x = i_p1.clone();
                Rc::new(move |(p0, p1): (bool, (crate::syntax::Expr, crate::syntax::Expr))| {
                    let m_p0xy = m_p0x.clone();
                    let i_p1xy = i_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p8 = p0;
                        let (k_p9, v_pa) = p1;
                        prism_rtl::Turn::Finished((ok_p8 && part_f(&m_p0xy, &i_p1xy, &k_p9)) && part_f(&m_p0xy, &i_p1xy, &v_pa))
                    }))
                }) as Rc<dyn Fn((bool, (crate::syntax::Expr, crate::syntax::Expr))) -> Rc<dyn prism_rtl::Job<bool>>>
            })),
            crate::syntax::ExprKind::EGroup(x_pb) => within_f(m_p0, i_p1, &**x_pb),
            crate::syntax::ExprKind::EMatch(s_pc, arms_pd) => crate::prelude::run_to_end(crate::prelude::fold_job(arms_pd.clone(), true, {
                let s_pcx = (**s_pc).clone();
                let m_p0x = m_p0.clone();
                let i_p1x = i_p1.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                    let s_pcxy = s_pcx.clone();
                    let m_p0xy = m_p0x.clone();
                    let i_p1xy = i_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_pe = p0;
                        let a_pf = p1;
                        prism_rtl::Turn::Finished(ok_pe && within_block_f(&crate::check::shrink::relations::arm_pat_rels_f(&s_pcxy, &a_pf, &m_p0xy), &i_p1xy, &a_pf.body_p))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
            })),
            crate::syntax::ExprKind::EIf(c_pg, t_ph, Some(el_pi)) => within_block_f(&crate::check::shrink::relations::cond_rels_f(&**c_pg, m_p0), i_p1, t_ph) && within_block_f(m_p0, i_p1, el_pi),
            crate::syntax::ExprKind::EUpdate(start_pj, b_pk) => within_f(m_p0, i_p1, &**start_pj) && update_within_f(&crate::prelude::insert(m_p0, &Text::lit("&_"), &crate::check::shrink::Rel { param_p: i_p1.clone(), strict_p: false }), i_p1, b_pk),
            _ => match crate::check::shrink::walk::call_of_o(e_p2) {
                Some((c_pl, args_pm)) => match crate::check::shrink::walk::traversal_of_o(m_p0, &c_pl, &args_pm) {
                    Some((coll_pn, step_po, at_pp)) => within_f(m_p0, i_p1, &coll_pn) && step_within_f(m_p0, i_p1, &crate::check::shrink::locals::expr_name_f(&c_pl), &coll_pn, &step_po, &at_pp, &crate::prelude::or(&crate::prelude::index(&args_pm, &Nat::from(1u32)), &dummy_arg_p()).value_p),
                    None => false,
                },
                None => false,
            },
        },
    }
}

/// The step machine of `Within`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub struct Within {
    pub m_p0: Map<Text, crate::check::shrink::Rel>,
    pub i_p1: Nat,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for Within {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let e_p2 = &self.e_p2;
        let e_p2x = e_p2.clone();
        let i_p1x = i_p1.clone();
        let m_p0x = m_p0.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(m_p0x.clone(), e_p2x.clone()), move |rel_of_o_2544: Option<crate::check::shrink::Rel>| match rel_of_o_2544 {
            Some(r_p3) => prism_rtl::Turn::Finished(&r_p3.param_p == &i_p1x),
            None => match &*e_p2x.kind_p {
                crate::syntax::ExprKind::EArray(es_p4) => crate::prelude::fold_job(es_p4.clone(), true, {
                    let m_p0xx = m_p0x.clone();
                    let i_p1xx = i_p1x.clone();
                    Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                        let m_p0xxy = m_p0xx.clone();
                        let i_p1xxy = i_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let ok_p5 = p0;
                            let x_p6 = p1;
                            prism_rtl::Turn::Finished(ok_p5 && part_f(&m_p0xxy, &i_p1xxy, &x_p6))
                        }))
                    }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle(),
                crate::syntax::ExprKind::EMap(kvs_p7) => crate::prelude::fold_job(kvs_p7.clone(), true, {
                    let m_p0xx = m_p0x.clone();
                    let i_p1xx = i_p1x.clone();
                    Rc::new(move |(p0, p1): (bool, (crate::syntax::Expr, crate::syntax::Expr))| {
                        let m_p0xxy = m_p0xx.clone();
                        let i_p1xxy = i_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let ok_p8 = p0;
                            let (k_p9, v_pa) = p1;
                            prism_rtl::Turn::Finished((ok_p8 && part_f(&m_p0xxy, &i_p1xxy, &k_p9)) && part_f(&m_p0xxy, &i_p1xxy, &v_pa))
                        }))
                    }) as Rc<dyn Fn((bool, (crate::syntax::Expr, crate::syntax::Expr))) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle(),
                crate::syntax::ExprKind::EGroup(x_pb) => prism_rtl::Turn::More(Rc::new(Within { m_p0: m_p0x.clone(), i_p1: i_p1x.clone(), e_p2: (**x_pb).clone() })),
                crate::syntax::ExprKind::EMatch(s_pc, arms_pd) => crate::prelude::fold_job(arms_pd.clone(), true, {
                    let s_pcx = (**s_pc).clone();
                    let m_p0xx = m_p0x.clone();
                    let i_p1xx = i_p1x.clone();
                    Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                        let s_pcxy = s_pcx.clone();
                        let m_p0xxy = m_p0xx.clone();
                        let i_p1xxy = i_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let ok_pe = p0;
                            let a_pf = p1;
                            prism_rtl::Turn::Finished(ok_pe && within_block_f(&crate::check::shrink::relations::arm_pat_rels_f(&s_pcxy, &a_pf, &m_p0xxy), &i_p1xxy, &a_pf.body_p))
                        }))
                    }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle(),
                crate::syntax::ExprKind::EIf(c_pg, t_ph, Some(el_pi)) => {
                    let c_pgx = (**c_pg).clone();
                    let el_pix = el_pi.clone();
                    let t_phx = t_ph.clone();
                    crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_pgx.clone(), m_p0x.clone()), move |cond_rels_f_2928: Map<Text, crate::check::shrink::Rel>| crate::prelude::call_then(start_within_block_f(cond_rels_f_2928, i_p1x.clone(), t_phx.clone()), move |within_block_f_2915: bool| prism_rtl::Turn::Finished(within_block_f_2915 && within_block_f(&m_p0x, &i_p1x, &el_pix))))
                },
                crate::syntax::ExprKind::EUpdate(start_pj, b_pk) => {
                    let b_pkx = b_pk.clone();
                    let start_pjx = (**start_pj).clone();
                    crate::prelude::call_then(start_within_f(m_p0x.clone(), i_p1x.clone(), start_pjx.clone()), move |within_f_3002: bool| prism_rtl::Turn::Finished(within_f_3002 && update_within_f(&crate::prelude::insert(&m_p0x, &Text::lit("&_"), &crate::check::shrink::Rel { param_p: i_p1x.clone(), strict_p: false }), &i_p1x, &b_pkx)))
                },
                _ => match crate::check::shrink::walk::call_of_o(&e_p2x) {
                    Some((c_pl, args_pm)) => match crate::check::shrink::walk::traversal_of_o(&m_p0x, &c_pl, &args_pm) {
                        Some((coll_pn, step_po, at_pp)) => crate::prelude::call_then(start_within_f(m_p0x.clone(), i_p1x.clone(), coll_pn.clone()), move |within_f_3223: bool| prism_rtl::Turn::Finished(within_f_3223 && step_within_f(&m_p0x, &i_p1x, &crate::check::shrink::locals::expr_name_f(&c_pl), &coll_pn, &step_po, &at_pp, &crate::prelude::or(&crate::prelude::index(&args_pm, &Nat::from(1u32)), &dummy_arg_p()).value_p))),
                        None => prism_rtl::Turn::Finished(false),
                    },
                    None => prism_rtl::Turn::Finished(false),
                },
            },
        })
    }
}

/// `Start Within, x`: what the function value is when passed to `@Run`.
pub fn start_within_f(m_p0: Map<Text, crate::check::shrink::Rel>, i_p1: Nat, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Within { m_p0, i_p1, e_p2 })
}

/// ```prism
/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub fn update_within_f(m_p0: &Map<Text, crate::check::shrink::Rel>, i_p1: &Nat, b_p2: &crate::syntax::Block) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmts_spots_f(&b_p2.stmts_p, m_p0), true, {
        let i_p1x = i_p1.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
            let i_p1xy = i_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p3 = p0;
                let sp_p4 = p1;
                prism_rtl::Turn::Finished(ok_p3 && spot_keeps_within_f(&sp_p4, &i_p1xy))
            }))
        }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `UpdateWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub struct UpdateWithin {
    pub m_p0: Map<Text, crate::check::shrink::Rel>,
    pub i_p1: Nat,
    pub b_p2: crate::syntax::Block,
}

impl prism_rtl::Job<bool> for UpdateWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let b_p2 = &self.b_p2;
        let b_p2x = b_p2.clone();
        let i_p1x = i_p1.clone();
        let m_p0x = m_p0.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_stmts_spots_f(b_p2x.stmts_p.clone(), m_p0x.clone()), move |stmts_spots_f_3685: Array<crate::check::shrink::walk::Spot>| crate::prelude::fold_job(stmts_spots_f_3685, true, {
            let i_p1xx = i_p1x.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                let i_p1xxy = i_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_p3 = p0;
                    let sp_p4 = p1;
                    prism_rtl::Turn::Finished(ok_p3 && spot_keeps_within_f(&sp_p4, &i_p1xxy))
                }))
            }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start UpdateWithin, x`: what the function value is when passed to `@Run`.
pub fn start_update_within_f(m_p0: Map<Text, crate::check::shrink::Rel>, i_p1: Nat, b_p2: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(UpdateWithin { m_p0, i_p1, b_p2 })
}

/// ```prism
/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
/// ```
pub fn spot_keeps_within_f(spot0: &crate::check::shrink::walk::Spot, n1: &Nat) -> bool {
    match (spot0, n1) {
        (crate::check::shrink::walk::Spot::SpotStmt(s_p0, m_p1), i_p2) => match &s_p0.kind_p {
            crate::syntax::StmtKind::SSet(t_p3, value_p4) => if &crate::prelude::take(&crate::check::passes::borrows::ref_path_f(t_p3), &Nat::from(1u32)) != &Array::from(vec![Text::lit("&_")]) {
                true
            } else {
                (&crate::check::passes::borrows::ref_path_f(t_p3) == &Array::from(vec![Text::lit("&_")])) && within_f(m_p1, i_p2, value_p4)
            },
            crate::syntax::StmtKind::SAccum(t_p5, _, _) => &crate::prelude::take(&crate::check::passes::borrows::ref_path_f(t_p5), &Nat::from(1u32)) != &Array::from(vec![Text::lit("&_")]),
            _ => true,
        },
        (crate::check::shrink::walk::Spot::SpotExpr(_, _), _) => true,
    }
}

/// The step machine of `SpotKeepsWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
/// ```
pub struct SpotKeepsWithin {
    pub spot0: crate::check::shrink::walk::Spot,
    pub n1: Nat,
}

impl prism_rtl::Job<bool> for SpotKeepsWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let spot0 = &self.spot0;
        let n1 = &self.n1;
        match (spot0, n1) {
            (crate::check::shrink::walk::Spot::SpotStmt(s_p0, m_p1), i_p2) => match &s_p0.kind_p {
                crate::syntax::StmtKind::SSet(t_p3, value_p4) => {
                    let i_p2x = i_p2.clone();
                    let m_p1x = m_p1.clone();
                    let t_p3x = t_p3.clone();
                    let value_p4x = value_p4.clone();
                    crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p3x.clone()), move |ref_path_f_3894: Array<Text>| if &crate::prelude::take(&ref_path_f_3894, &Nat::from(1u32)) != &Array::from(vec![Text::lit("&_")]) {
                        prism_rtl::Turn::Finished(true)
                    } else {
                        crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p3x.clone()), move |ref_path_f_3942: Array<Text>| prism_rtl::Turn::Finished((&ref_path_f_3942 == &Array::from(vec![Text::lit("&_")])) && within_f(&m_p1x, &i_p2x, &value_p4x)))
                    })
                },
                crate::syntax::StmtKind::SAccum(t_p5, _, _) => {
                    let t_p5x = t_p5.clone();
                    crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p5x.clone()), move |ref_path_f_4025: Array<Text>| prism_rtl::Turn::Finished(&crate::prelude::take(&ref_path_f_4025, &Nat::from(1u32)) != &Array::from(vec![Text::lit("&_")])))
                },
                _ => prism_rtl::Turn::Finished(true),
            },
            (crate::check::shrink::walk::Spot::SpotExpr(_, _), _) => prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start SpotKeepsWithin, x`: what the function value is when passed to `@Run`.
pub fn start_spot_keeps_within_f(spot0: crate::check::shrink::walk::Spot, n1: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SpotKeepsWithin { spot0, n1 })
}

/// ```prism
/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub fn within_block_f(m_p0: &Map<Text, crate::check::shrink::Rel>, i_p1: &Nat, b_p2: &crate::syntax::Block) -> bool {
    within_f(&crate::check::shrink::relations::block_rels_f(&b_p2.stmts_p, m_p0), i_p1, &last_or_f(b_p2))
}

/// The step machine of `WithinBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub struct WithinBlock {
    pub m_p0: Map<Text, crate::check::shrink::Rel>,
    pub i_p1: Nat,
    pub b_p2: crate::syntax::Block,
}

impl prism_rtl::Job<bool> for WithinBlock {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let b_p2 = &self.b_p2;
        let b_p2x = b_p2.clone();
        let i_p1x = i_p1.clone();
        let m_p0x = m_p0.clone();
        crate::prelude::call_then(crate::check::shrink::relations::start_block_rels_f(b_p2x.stmts_p.clone(), m_p0x.clone()), move |block_rels_f_4289: Map<Text, crate::check::shrink::Rel>| prism_rtl::Turn::More(Rc::new(Within { m_p0: block_rels_f_4289, i_p1: i_p1x.clone(), e_p2: last_or_f(&b_p2x) })))
    }
}

/// `Start WithinBlock, x`: what the function value is when passed to `@Run`.
pub fn start_within_block_f(m_p0: Map<Text, crate::check::shrink::Rel>, i_p1: Nat, b_p2: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(WithinBlock { m_p0, i_p1, b_p2 })
}

/// ```prism
/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
/// ```
pub fn step_within_f(m_p0: &Map<Text, crate::check::shrink::Rel>, i_p1: &Nat, f_p2: &Text, coll_p3: &crate::syntax::Expr, step_p4: &crate::syntax::Expr, at_p5: &Nat, z_p6: &crate::syntax::Expr) -> bool {
    if crate::check::shrink::relations::pre_is_f(m_p0, f_p2, &Text::lit("Filter")) {
        true
    } else {
        match &*step_p4.kind_p {
            crate::syntax::ExprKind::ELambda(Some(ps_p7), body_p8) => {
                let sm_p9 = crate::check::shrink::relations::step_rels_f(m_p0, coll_p3, ps_p7, at_p5);
                let (bm_pc, x_pd) = match &**body_p8 {
                    crate::syntax::LambdaBody::LbExpr(y_pa) => (sm_p9.clone(), (**y_pa).clone()),
                    crate::syntax::LambdaBody::LbBlock(b_pb) => (crate::check::shrink::relations::block_rels_f(&b_pb.stmts_p, &sm_p9), last_or_f(b_pb)),
                };
                if crate::check::shrink::relations::pre_is_f(m_p0, f_p2, &Text::lit("Each")) {
                    part_f(&bm_pc, i_p1, &x_pd)
                } else {
                    match crate::prelude::index(ps_p7, &Nat::from(0u32)) {
                        Some(acc_pe) => match &*acc_pe.kind_p {
                            crate::syntax::PatternKind::PName(n_pf) => within_f(m_p0, i_p1, z_p6) && builds_on_f(&bm_pc, i_p1, &crate::check::env::sname_key_f(n_pf), &x_pd),
                            _ => false,
                        },
                        None => false,
                    }
                }
            },
            _ => false,
        }
    }
}

/// The step machine of `StepWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
/// ```
pub struct StepWithin {
    pub m_p0: Map<Text, crate::check::shrink::Rel>,
    pub i_p1: Nat,
    pub f_p2: Text,
    pub coll_p3: crate::syntax::Expr,
    pub step_p4: crate::syntax::Expr,
    pub at_p5: Nat,
    pub z_p6: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for StepWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let f_p2 = &self.f_p2;
        let coll_p3 = &self.coll_p3;
        let step_p4 = &self.step_p4;
        let at_p5 = &self.at_p5;
        let z_p6 = &self.z_p6;
        if crate::check::shrink::relations::pre_is_f(m_p0, f_p2, &Text::lit("Filter")) {
            prism_rtl::Turn::Finished(true)
        } else {
            match &*step_p4.kind_p {
                crate::syntax::ExprKind::ELambda(Some(ps_p7), body_p8) => {
                    let at_p5x = at_p5.clone();
                    let body_p8x = (**body_p8).clone();
                    let coll_p3x = coll_p3.clone();
                    let f_p2x = f_p2.clone();
                    let i_p1x = i_p1.clone();
                    let m_p0x = m_p0.clone();
                    let ps_p7x = ps_p7.clone();
                    let z_p6x = z_p6.clone();
                    crate::prelude::call_then(crate::check::shrink::relations::start_step_rels_f(m_p0x.clone(), coll_p3x.clone(), ps_p7x.clone(), at_p5x.clone()), move |step_rels_f_4719: Map<Text, crate::check::shrink::Rel>| {
                        let sm_p9 = step_rels_f_4719;
                        let (bm_pc, x_pd) = match &body_p8x {
                            crate::syntax::LambdaBody::LbExpr(y_pa) => (sm_p9.clone(), (**y_pa).clone()),
                            crate::syntax::LambdaBody::LbBlock(b_pb) => (crate::check::shrink::relations::block_rels_f(&b_pb.stmts_p, &sm_p9), last_or_f(b_pb)),
                        };
                        if crate::check::shrink::relations::pre_is_f(&m_p0x, &f_p2x, &Text::lit("Each")) {
                            prism_rtl::Turn::More(Rc::new(Part { m_p0: bm_pc.clone(), i_p1: i_p1x.clone(), e_p2: x_pd.clone() }))
                        } else {
                            match crate::prelude::index(&ps_p7x, &Nat::from(0u32)) {
                                Some(acc_pe) => match &*acc_pe.kind_p {
                                    crate::syntax::PatternKind::PName(n_pf) => {
                                        let n_pfx = n_pf.clone();
                                        crate::prelude::call_then(start_within_f(m_p0x.clone(), i_p1x.clone(), z_p6x.clone()), move |within_f_5036: bool| prism_rtl::Turn::Finished(within_f_5036 && builds_on_f(&bm_pc, &i_p1x, &crate::check::env::sname_key_f(&n_pfx), &x_pd)))
                                    },
                                    _ => prism_rtl::Turn::Finished(false),
                                },
                                None => prism_rtl::Turn::Finished(false),
                            }
                        }
                    })
                },
                _ => prism_rtl::Turn::Finished(false),
            }
        }
    }
}

/// `Start StepWithin, x`: what the function value is when passed to `@Run`.
pub fn start_step_within_f(m_p0: Map<Text, crate::check::shrink::Rel>, i_p1: Nat, f_p2: Text, coll_p3: crate::syntax::Expr, step_p4: crate::syntax::Expr, at_p5: Nat, z_p6: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(StepWithin { m_p0, i_p1, f_p2, coll_p3, step_p4, at_p5, z_p6 })
}

/// ```prism
/// LastOr: fn Block -> Expr
/// ```
pub fn last_or_f(b_p0: &crate::syntax::Block) -> crate::syntax::Expr {
    crate::prelude::or(&crate::check::shrink::walk::last_expr_o(b_p0), &dummy_arg_p().value_p)
}

/// ```prism
/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
/// ```
pub fn builds_on_f(m_p0: &Map<Text, crate::check::shrink::Rel>, i_p1: &Nat, acc_p2: &Text, e_p3: &crate::syntax::Expr) -> bool {
    match &*e_p3.kind_p {
        crate::syntax::ExprKind::EName(n_p4) => &crate::check::env::sname_key_f(n_p4) == acc_p2,
        crate::syntax::ExprKind::EGroup(x_p5) => builds_on_f(m_p0, i_p1, acc_p2, &**x_p5),
        crate::syntax::ExprKind::EMatch(s_p6, arms_p7) => crate::prelude::run_to_end(crate::prelude::fold_job(arms_p7.clone(), true, {
            let acc_p2x = acc_p2.clone();
            let s_p6x = (**s_p6).clone();
            let m_p0x = m_p0.clone();
            let i_p1x = i_p1.clone();
            Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                let acc_p2xy = acc_p2x.clone();
                let s_p6xy = s_p6x.clone();
                let m_p0xy = m_p0x.clone();
                let i_p1xy = i_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_p8 = p0;
                    let a_p9 = p1;
                    prism_rtl::Turn::Finished((ok_p8 && !crate::check::types::has_text_f(&opt_names_f(&a_p9.pattern_o), &acc_p2xy)) && builds_on_block_f(&crate::check::shrink::relations::arm_pat_rels_f(&s_p6xy, &a_p9, &m_p0xy), &i_p1xy, &acc_p2xy, &a_p9.body_p))
                }))
            }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::syntax::ExprKind::EIf(c_pa, t_pb, Some(el_pc)) => (!crate::check::types::has_text_f(&cond_names_f(&**c_pa), acc_p2) && builds_on_block_f(&crate::check::shrink::relations::cond_rels_f(&**c_pa, m_p0), i_p1, acc_p2, t_pb)) && builds_on_block_f(m_p0, i_p1, acc_p2, el_pc),
        _ => match crate::check::shrink::walk::call_of_o(e_p3) {
            Some((c_pd, args_pe)) => builds_on_call_f(m_p0, i_p1, acc_p2, &c_pd, &args_pe),
            None => false,
        },
    }
}

/// The step machine of `BuildsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
/// ```
pub struct BuildsOn {
    pub m_p0: Map<Text, crate::check::shrink::Rel>,
    pub i_p1: Nat,
    pub acc_p2: Text,
    pub e_p3: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for BuildsOn {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let acc_p2 = &self.acc_p2;
        let e_p3 = &self.e_p3;
        match &*e_p3.kind_p {
            crate::syntax::ExprKind::EName(n_p4) => prism_rtl::Turn::Finished(&crate::check::env::sname_key_f(n_p4) == acc_p2),
            crate::syntax::ExprKind::EGroup(x_p5) => prism_rtl::Turn::More(Rc::new(BuildsOn { m_p0: m_p0.clone(), i_p1: i_p1.clone(), acc_p2: acc_p2.clone(), e_p3: (**x_p5).clone() })),
            crate::syntax::ExprKind::EMatch(s_p6, arms_p7) => crate::prelude::fold_job(arms_p7.clone(), true, {
                let acc_p2x = acc_p2.clone();
                let s_p6x = (**s_p6).clone();
                let m_p0x = m_p0.clone();
                let i_p1x = i_p1.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                    let acc_p2xy = acc_p2x.clone();
                    let s_p6xy = s_p6x.clone();
                    let m_p0xy = m_p0x.clone();
                    let i_p1xy = i_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p8 = p0;
                        let a_p9 = p1;
                        prism_rtl::Turn::Finished((ok_p8 && !crate::check::types::has_text_f(&opt_names_f(&a_p9.pattern_o), &acc_p2xy)) && builds_on_block_f(&crate::check::shrink::relations::arm_pat_rels_f(&s_p6xy, &a_p9, &m_p0xy), &i_p1xy, &acc_p2xy, &a_p9.body_p))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::syntax::ExprKind::EIf(c_pa, t_pb, Some(el_pc)) => {
                let acc_p2x = acc_p2.clone();
                let c_pax = (**c_pa).clone();
                let el_pcx = el_pc.clone();
                let i_p1x = i_p1.clone();
                let m_p0x = m_p0.clone();
                let t_pbx = t_pb.clone();
                crate::prelude::call_then(start_cond_names_f(c_pax.clone()), move |cond_names_f_5750: Array<Text>| prism_rtl::Turn::Finished((!crate::check::types::has_text_f(&cond_names_f_5750, &acc_p2x) && builds_on_block_f(&crate::check::shrink::relations::cond_rels_f(&c_pax, &m_p0x), &i_p1x, &acc_p2x, &t_pbx)) && builds_on_block_f(&m_p0x, &i_p1x, &acc_p2x, &el_pcx)))
            },
            _ => match crate::check::shrink::walk::call_of_o(e_p3) {
                Some((c_pd, args_pe)) => prism_rtl::Turn::More(Rc::new(BuildsOnCall { m_p0: m_p0.clone(), i_p1: i_p1.clone(), acc_p2: acc_p2.clone(), c_p3: c_pd.clone(), args_p4: args_pe.clone() })),
                None => prism_rtl::Turn::Finished(false),
            },
        }
    }
}

/// `Start BuildsOn, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on_f(m_p0: Map<Text, crate::check::shrink::Rel>, i_p1: Nat, acc_p2: Text, e_p3: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(BuildsOn { m_p0, i_p1, acc_p2, e_p3 })
}

/// ```prism
/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
/// ```
pub fn builds_on_call_f(m_p0: &Map<Text, crate::check::shrink::Rel>, i_p1: &Nat, acc_p2: &Text, c_p3: &crate::syntax::Expr, args_p4: &Array<crate::syntax::Arg>) -> bool {
    let f_p5 = crate::check::shrink::locals::expr_name_f(c_p3);
    let on_acc_p6 = builds_on_f(m_p0, i_p1, acc_p2, &crate::prelude::or(&crate::prelude::index(args_p4, &Nat::from(0u32)), &dummy_arg_p()).value_p);
    let rest_p7 = crate::prelude::each(&crate::prelude::drop(args_p4, &Nat::from(1u32)), &(|a_p9: &crate::syntax::Arg| a_p9.value_p.clone()));
    let parts_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(rest_p7.clone(), true, {
        let m_p0x = m_p0.clone();
        let i_p1x = i_p1.clone();
        Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
            let m_p0xy = m_p0x.clone();
            let i_p1xy = i_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_pa = p0;
                let x_pb = p1;
                prism_rtl::Turn::Finished(ok_pa && part_f(&m_p0xy, &i_p1xy, &x_pb))
            }))
        }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    if !on_acc_p6 {
        false
    } else {
        if crate::check::shrink::relations::pre_is_f(m_p0, &f_p5, &Text::lit("Push")) && (&crate::prelude::len(&rest_p7) == &Nat::from(1u32)) {
            parts_p8
        } else {
            if crate::check::shrink::relations::pre_is_f(m_p0, &f_p5, &Text::lit("Insert")) && (&crate::prelude::len(&rest_p7) == &Nat::from(2u32)) {
                parts_p8
            } else {
                if crate::check::shrink::relations::pre_is_f(m_p0, &f_p5, &Text::lit("Append")) && (&crate::prelude::len(&rest_p7) == &Nat::from(1u32)) {
                    within_f(m_p0, i_p1, &crate::prelude::or(&crate::prelude::index(&rest_p7, &Nat::from(0u32)), &dummy_arg_p().value_p))
                } else {
                    false
                }
            }
        }
    }
}

/// The step machine of `BuildsOnCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
/// ```
pub struct BuildsOnCall {
    pub m_p0: Map<Text, crate::check::shrink::Rel>,
    pub i_p1: Nat,
    pub acc_p2: Text,
    pub c_p3: crate::syntax::Expr,
    pub args_p4: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<bool> for BuildsOnCall {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let acc_p2 = &self.acc_p2;
        let c_p3 = &self.c_p3;
        let args_p4 = &self.args_p4;
        let f_p5 = crate::check::shrink::locals::expr_name_f(c_p3);
        let acc_p2x = acc_p2.clone();
        let args_p4x = args_p4.clone();
        let i_p1x = i_p1.clone();
        let m_p0x = m_p0.clone();
        crate::prelude::call_then(start_builds_on_f(m_p0x.clone(), i_p1x.clone(), acc_p2x.clone(), crate::prelude::or(&crate::prelude::index(&args_p4x, &Nat::from(0u32)), &dummy_arg_p()).value_p.clone()), move |builds_on_f_6180: bool| {
            let on_acc_p6 = builds_on_f_6180;
            let rest_p7 = crate::prelude::each(&crate::prelude::drop(&args_p4x, &Nat::from(1u32)), &(|a_p9: &crate::syntax::Arg| a_p9.value_p.clone()));
            crate::prelude::call_value(crate::prelude::fold_job(rest_p7.clone(), true, {
                let m_p0xx = m_p0x.clone();
                let i_p1xx = i_p1x.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                    let m_p0xxy = m_p0xx.clone();
                    let i_p1xxy = i_p1xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_pa = p0;
                        let x_pb = p1;
                        prism_rtl::Turn::Finished(ok_pa && part_f(&m_p0xxy, &i_p1xxy, &x_pb))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |fold_6294: bool| {
                let parts_p8 = fold_6294;
                if !on_acc_p6 {
                    prism_rtl::Turn::Finished(false)
                } else {
                    if crate::check::shrink::relations::pre_is_f(&m_p0x, &f_p5, &Text::lit("Push")) && (&crate::prelude::len(&rest_p7) == &Nat::from(1u32)) {
                        prism_rtl::Turn::Finished(parts_p8)
                    } else {
                        if crate::check::shrink::relations::pre_is_f(&m_p0x, &f_p5, &Text::lit("Insert")) && (&crate::prelude::len(&rest_p7) == &Nat::from(2u32)) {
                            prism_rtl::Turn::Finished(parts_p8)
                        } else {
                            if crate::check::shrink::relations::pre_is_f(&m_p0x, &f_p5, &Text::lit("Append")) && (&crate::prelude::len(&rest_p7) == &Nat::from(1u32)) {
                                prism_rtl::Turn::More(Rc::new(Within { m_p0: m_p0x.clone(), i_p1: i_p1x.clone(), e_p2: crate::prelude::or(&crate::prelude::index(&rest_p7, &Nat::from(0u32)), &dummy_arg_p().value_p) }))
                            } else {
                                prism_rtl::Turn::Finished(false)
                            }
                        }
                    }
                }
            })
        })
    }
}

/// `Start BuildsOnCall, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on_call_f(m_p0: Map<Text, crate::check::shrink::Rel>, i_p1: Nat, acc_p2: Text, c_p3: crate::syntax::Expr, args_p4: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(BuildsOnCall { m_p0, i_p1, acc_p2, c_p3, args_p4 })
}

/// ```prism
/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
/// ```
pub fn builds_on_block_f(m_p0: &Map<Text, crate::check::shrink::Rel>, i_p1: &Nat, acc_p2: &Text, b_p3: &crate::syntax::Block) -> bool {
    !crate::check::types::has_text_f(&crate::check::shrink::relations::stmts_binders_f(&b_p3.stmts_p), acc_p2) && builds_on_f(&crate::check::shrink::relations::block_rels_f(&b_p3.stmts_p, m_p0), i_p1, acc_p2, &last_or_f(b_p3))
}

/// The step machine of `BuildsOnBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
/// ```
pub struct BuildsOnBlock {
    pub m_p0: Map<Text, crate::check::shrink::Rel>,
    pub i_p1: Nat,
    pub acc_p2: Text,
    pub b_p3: crate::syntax::Block,
}

impl prism_rtl::Job<bool> for BuildsOnBlock {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let acc_p2 = &self.acc_p2;
        let b_p3 = &self.b_p3;
        let acc_p2x = acc_p2.clone();
        let b_p3x = b_p3.clone();
        let i_p1x = i_p1.clone();
        let m_p0x = m_p0.clone();
        crate::prelude::call_then(crate::check::shrink::relations::start_stmts_binders_f(b_p3x.stmts_p.clone()), move |stmts_binders_f_6854: Array<Text>| prism_rtl::Turn::Finished(!crate::check::types::has_text_f(&stmts_binders_f_6854, &acc_p2x) && builds_on_f(&crate::check::shrink::relations::block_rels_f(&b_p3x.stmts_p, &m_p0x), &i_p1x, &acc_p2x, &last_or_f(&b_p3x))))
    }
}

/// `Start BuildsOnBlock, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on_block_f(m_p0: Map<Text, crate::check::shrink::Rel>, i_p1: Nat, acc_p2: Text, b_p3: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(BuildsOnBlock { m_p0, i_p1, acc_p2, b_p3 })
}

/// ```prism
/// CondNames: unbounded fn Cond -> [Text]
/// ```
pub fn cond_names_f(cond0: &crate::syntax::Cond) -> Array<Text> {
    match cond0 {
        crate::syntax::Cond::CondBind(p_p0, _, _) => crate::check::env::names::pattern_names_f(p_p0),
        crate::syntax::Cond::CondExpr(_) => Array::new(),
    }
}

/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondNames: unbounded fn Cond -> [Text]
/// ```
pub struct CondNames {
    pub cond0: crate::syntax::Cond,
}

impl prism_rtl::Job<Array<Text>> for CondNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cond0 = &self.cond0;
        match cond0 {
            crate::syntax::Cond::CondBind(p_p0, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::names::PatternNames { p_p0: p_p0.clone() })),
            crate::syntax::Cond::CondExpr(_) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start CondNames, x`: what the function value is when passed to `@Run`.
pub fn start_cond_names_f(cond0: crate::syntax::Cond) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CondNames { cond0 })
}

/// ```prism
/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub fn part_f(m_p0: &Map<Text, crate::check::shrink::Rel>, i_p1: &Nat, e_p2: &crate::syntax::Expr) -> bool {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::ETuple(es_p3) => crate::prelude::run_to_end(crate::prelude::fold_job(es_p3.clone(), true, {
            let m_p0x = m_p0.clone();
            let i_p1x = i_p1.clone();
            Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                let m_p0xy = m_p0x.clone();
                let i_p1xy = i_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_p4 = p0;
                    let x_p5 = p1;
                    prism_rtl::Turn::Finished(ok_p4 && part_f(&m_p0xy, &i_p1xy, &x_p5))
                }))
            }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::syntax::ExprKind::EGroup(x_p6) => part_f(m_p0, i_p1, &**x_p6),
        _ => match crate::check::shrink::walk::rel_of_o(m_p0, e_p2) {
            Some(r_p7) => (&r_p7.param_p == i_p1) && r_p7.strict_p,
            None => false,
        },
    }
}

/// The step machine of `Part`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub struct Part {
    pub m_p0: Map<Text, crate::check::shrink::Rel>,
    pub i_p1: Nat,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for Part {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::ETuple(es_p3) => crate::prelude::fold_job(es_p3.clone(), true, {
                let m_p0x = m_p0.clone();
                let i_p1x = i_p1.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                    let m_p0xy = m_p0x.clone();
                    let i_p1xy = i_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p4 = p0;
                        let x_p5 = p1;
                        prism_rtl::Turn::Finished(ok_p4 && part_f(&m_p0xy, &i_p1xy, &x_p5))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::syntax::ExprKind::EGroup(x_p6) => prism_rtl::Turn::More(Rc::new(Part { m_p0: m_p0.clone(), i_p1: i_p1.clone(), e_p2: (**x_p6).clone() })),
            _ => {
                let e_p2x = e_p2.clone();
                let i_p1x = i_p1.clone();
                let m_p0x = m_p0.clone();
                crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(m_p0x.clone(), e_p2x.clone()), move |rel_of_o_7269: Option<crate::check::shrink::Rel>| match rel_of_o_7269 {
                    Some(r_p7) => prism_rtl::Turn::Finished((&r_p7.param_p == &i_p1x) && r_p7.strict_p),
                    None => prism_rtl::Turn::Finished(false),
                })
            },
        }
    }
}

/// `Start Part, x`: what the function value is when passed to `@Run`.
pub fn start_part_f(m_p0: Map<Text, crate::check::shrink::Rel>, i_p1: Nat, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Part { m_p0, i_p1, e_p2 })
}

/// ```prism
/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn summary_seeds_f(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, spots_p2: &Array<crate::check::shrink::walk::Spot>, rels_p3: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    crate::prelude::fold(&crate::prelude::run_to_end(crate::prelude::fold_job(spots_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p4 = p0;
        let sp_p5 = p1;
        crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5.clone()), move |spot_sites_f_7945: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &spot_sites_f_7945)))
    }))) as Rc<dyn Fn((Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Site>>>>)), rels_p3, &(|m_p6: &Map<Text, crate::check::shrink::Rel>, site_p7: &crate::check::shrink::walk::Site| if crate::check::shrink::relations::is_local_f(&site_p7.rels_p, &site_p7.callee_p) {
        m_p6.clone()
    } else {
        match crate::check::shrink::locals::resolve_callee_o(&sk_p0.g_p, &d_p1.home_p, &site_p7.callee_p) {
            Some(k_p8) => match crate::prelude::get(&sk_p0.sums_p, &k_p8) {
                Some(i_p9) => crate::prelude::insert(m_p6, &Text::from(format!("fn:{}", &site_p7.callee_p)), &crate::check::shrink::Rel { param_p: i_p9, strict_p: false }),
                None => if crate::check::shrink::walk::is_no_larger_prelude_f(&sk_p0.g_p, &k_p8) {
                    crate::prelude::insert(m_p6, &Text::from(format!("fn:{}", &site_p7.callee_p)), &crate::check::shrink::Rel { param_p: Nat::from(0u32), strict_p: false })
                } else {
                    m_p6.clone()
                },
            },
            None => m_p6.clone(),
        }
    }))
}

/// The step machine of `SummarySeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct SummarySeeds {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub spots_p2: Array<crate::check::shrink::walk::Spot>,
    pub rels_p3: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for SummarySeeds {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let spots_p2 = &self.spots_p2;
        let rels_p3 = &self.rels_p3;
        let d_p1x = d_p1.clone();
        let rels_p3x = rels_p3.clone();
        let sk_p0x = sk_p0.clone();
        let spots_p2x = spots_p2.clone();
        crate::prelude::call_value(crate::prelude::fold_job(spots_p2x.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p4 = p0;
            let sp_p5 = p1;
            crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5.clone()), move |spot_sites_f_7945: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &spot_sites_f_7945)))
        }))) as Rc<dyn Fn((Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Site>>>>), move |fold_7903: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(crate::prelude::fold(&fold_7903, &rels_p3x, &(|m_p6: &Map<Text, crate::check::shrink::Rel>, site_p7: &crate::check::shrink::walk::Site| if crate::check::shrink::relations::is_local_f(&site_p7.rels_p, &site_p7.callee_p) {
            m_p6.clone()
        } else {
            match crate::check::shrink::locals::resolve_callee_o(&sk_p0x.g_p, &d_p1x.home_p, &site_p7.callee_p) {
                Some(k_p8) => match crate::prelude::get(&sk_p0x.sums_p, &k_p8) {
                    Some(i_p9) => crate::prelude::insert(m_p6, &Text::from(format!("fn:{}", &site_p7.callee_p)), &crate::check::shrink::Rel { param_p: i_p9, strict_p: false }),
                    None => if crate::check::shrink::walk::is_no_larger_prelude_f(&sk_p0x.g_p, &k_p8) {
                        crate::prelude::insert(m_p6, &Text::from(format!("fn:{}", &site_p7.callee_p)), &crate::check::shrink::Rel { param_p: Nat::from(0u32), strict_p: false })
                    } else {
                        m_p6.clone()
                    },
                },
                None => m_p6.clone(),
            }
        }))))
    }
}

/// `Start SummarySeeds, x`: what the function value is when passed to `@Run`.
pub fn start_summary_seeds_f(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, spots_p2: Array<crate::check::shrink::walk::Spot>, rels_p3: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(SummarySeeds { sk_p0, d_p1, spots_p2, rels_p3 })
}

/// ```prism
/// OptNames: unbounded fn ?Pattern -> [Text]
/// ```
pub fn opt_names_f(opt0: &Option<crate::syntax::Pattern_>) -> Array<Text> {
    match opt0 {
        Some(p_p0) => crate::check::env::names::pattern_names_f(p_p0),
        None => Array::new(),
    }
}

/// The step machine of `OptNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptNames: unbounded fn ?Pattern -> [Text]
/// ```
pub struct OptNames {
    pub opt0: Option<crate::syntax::Pattern_>,
}

impl prism_rtl::Job<Array<Text>> for OptNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(p_p0) => prism_rtl::Turn::More(Rc::new(crate::check::env::names::PatternNames { p_p0: p_p0.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptNames, x`: what the function value is when passed to `@Run`.
pub fn start_opt_names_f(opt0: Option<crate::syntax::Pattern_>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(OptNames { opt0 })
}

/// ```prism
/// let dummyArg
/// ```
pub fn dummy_arg_p() -> crate::syntax::Arg {
    crate::syntax::Arg { name_o: None, value_p: crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }, span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }
}

/// ```prism
/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub fn decrement_of_o(m_p0: &Map<Text, crate::check::shrink::Rel>, e_p1: &crate::syntax::Expr) -> Option<crate::check::shrink::Rel> {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::EBinary(m8753_0_0, l_p2, r_p3) if (m8753_0_0 == &Text::lit("-?")) => if is_positive_lit_f(&**r_p3) && is_nat_minus_f(m_p0, e_p1) {
            smaller_o(m_p0, &**l_p2)
        } else {
            None
        },
        crate::syntax::ExprKind::EGroup(x_p4) => decrement_of_o(m_p0, &**x_p4),
        _ => match crate::check::shrink::walk::call_of_o(e_p1) {
            Some((c_p5, args_p6)) => match crate::check::shrink::walk::callee_name_o(&c_p5) {
                Some(n_p7) => if crate::check::shrink::relations::pre_is_f(m_p0, &n_p7, &Text::lit("?Step")) {
                    smaller_o(m_p0, &crate::prelude::or(&crate::prelude::index(&args_p6, &Nat::from(0u32)), &dummy_arg_p()).value_p)
                } else {
                    None
                },
                None => None,
            },
            None => None,
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DecrementOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub struct DecrementOf {
    pub m_p0: Map<Text, crate::check::shrink::Rel>,
    pub e_p1: crate::syntax::Expr,
}

impl prism_rtl::Job<Option<crate::check::shrink::Rel>> for DecrementOf {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::check::shrink::Rel>> {
        let m_p0 = &self.m_p0;
        let e_p1 = &self.e_p1;
        match &*e_p1.kind_p {
            crate::syntax::ExprKind::EBinary(m8753_0_0, l_p2, r_p3) if (m8753_0_0 == &Text::lit("-?")) => if is_positive_lit_f(&**r_p3) && is_nat_minus_f(m_p0, e_p1) {
                prism_rtl::Turn::Finished(smaller_o(m_p0, &**l_p2))
            } else {
                prism_rtl::Turn::Finished(None)
            },
            crate::syntax::ExprKind::EGroup(x_p4) => prism_rtl::Turn::More(Rc::new(DecrementOf { m_p0: m_p0.clone(), e_p1: (**x_p4).clone() })),
            _ => match crate::check::shrink::walk::call_of_o(e_p1) {
                Some((c_p5, args_p6)) => match crate::check::shrink::walk::callee_name_o(&c_p5) {
                    Some(n_p7) => if crate::check::shrink::relations::pre_is_f(m_p0, &n_p7, &Text::lit("?Step")) {
                        prism_rtl::Turn::Finished(smaller_o(m_p0, &crate::prelude::or(&crate::prelude::index(&args_p6, &Nat::from(0u32)), &dummy_arg_p()).value_p))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    },
                    None => prism_rtl::Turn::Finished(None),
                },
                None => prism_rtl::Turn::Finished(None),
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DecrementOf, x`: what the function value is when passed to `@Run`.
pub fn start_decrement_of_o(m_p0: Map<Text, crate::check::shrink::Rel>, e_p1: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Option<crate::check::shrink::Rel>>> {
    Rc::new(DecrementOf { m_p0, e_p1 })
}

/// ```prism
/// IsNatMinus: fn (Text ==> Rel), Expr -> Bool
/// ```
pub fn is_nat_minus_f(m_p0: &Map<Text, crate::check::shrink::Rel>, e_p1: &crate::syntax::Expr) -> bool {
    crate::check::shrink::relations::pre_is_f(m_p0, &Text::lit("-?"), &Text::lit("-?")) && crate::check::shrink::walk::is_nat_at_f(m_p0, e_p1)
}

/// ```prism
/// ?Smaller: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub fn smaller_o(m_p0: &Map<Text, crate::check::shrink::Rel>, x_p1: &crate::syntax::Expr) -> Option<crate::check::shrink::Rel> {
    match crate::check::shrink::walk::rel_of_o(m_p0, x_p1) {
        Some(r_p2) => Some(crate::check::shrink::Rel { param_p: r_p2.param_p.clone(), strict_p: true }),
        None => None,
    }
}

/// ```prism
/// IsPositiveLit: fn Expr -> Bool
/// ```
pub fn is_positive_lit_f(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ELit(l_p1) => match &l_p1.kind_p {
            crate::syntax::LitKind::LInt(d_p2) => d_p2 != &Text::lit("0"),
            _ => false,
        },
        crate::syntax::ExprKind::EGroup(x_p3) => is_positive_lit_f(&**x_p3),
        _ => false,
    }
}

/// ```prism
/// Closure: unbounded fn [Sc] -> [Sc]
/// ```
pub fn closure_f(graphs_p0: &Array<crate::check::shrink::Sc>) -> Array<crate::check::shrink::Sc> {
    closure_from_f(graphs_p0, &dedup_f(graphs_p0), &dedup_f(graphs_p0))
}

/// The step machine of `Closure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Closure: unbounded fn [Sc] -> [Sc]
/// ```
pub struct Closure {
    pub graphs_p0: Array<crate::check::shrink::Sc>,
}

impl prism_rtl::Job<Array<crate::check::shrink::Sc>> for Closure {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::shrink::Sc>> {
        let graphs_p0 = &self.graphs_p0;
        prism_rtl::Turn::More(Rc::new(ClosureFrom { base_p0: graphs_p0.clone(), acc_p1: dedup_f(graphs_p0), frontier_p2: dedup_f(graphs_p0) }))
    }
}

/// `Start Closure, x`: what the function value is when passed to `@Run`.
pub fn start_closure_f(graphs_p0: Array<crate::check::shrink::Sc>) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>> {
    Rc::new(Closure { graphs_p0 })
}

/// ```prism
/// Dedup: fn [Sc] -> [Sc]
/// ```
pub fn dedup_f(gs_p0: &Array<crate::check::shrink::Sc>) -> Array<crate::check::shrink::Sc> {
    crate::prelude::fold(gs_p0, &Array::new(), &(|acc_p1: &Array<crate::check::shrink::Sc>, g_p2: &crate::check::shrink::Sc| if has_sc_f(acc_p1, g_p2) {
        acc_p1.clone()
    } else {
        crate::prelude::push(acc_p1, g_p2)
    }))
}

/// ```prism
/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
/// ```
pub fn closure_from_f(base_p0: &Array<crate::check::shrink::Sc>, acc_p1: &Array<crate::check::shrink::Sc>, frontier_p2: &Array<crate::check::shrink::Sc>) -> Array<crate::check::shrink::Sc> {
    let fresh_p3 = crate::prelude::fold(frontier_p2, &Array::new(), &(|out_p4: &Array<crate::check::shrink::Sc>, a_p5: &crate::check::shrink::Sc| crate::prelude::fold(base_p0, out_p4, &(|out2_p6: &Array<crate::check::shrink::Sc>, b_p7: &crate::check::shrink::Sc| add_composed_f(acc_p1, out2_p6, a_p5, b_p7)))));
    if &crate::prelude::len(&fresh_p3) == &Nat::from(0u32) {
        acc_p1.clone()
    } else {
        closure_from_f(base_p0, &crate::prelude::append(acc_p1, &fresh_p3), &fresh_p3)
    }
}

/// The step machine of `ClosureFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
/// ```
pub struct ClosureFrom {
    pub base_p0: Array<crate::check::shrink::Sc>,
    pub acc_p1: Array<crate::check::shrink::Sc>,
    pub frontier_p2: Array<crate::check::shrink::Sc>,
}

impl prism_rtl::Job<Array<crate::check::shrink::Sc>> for ClosureFrom {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::shrink::Sc>> {
        let base_p0 = &self.base_p0;
        let acc_p1 = &self.acc_p1;
        let frontier_p2 = &self.frontier_p2;
        let fresh_p3 = crate::prelude::fold(frontier_p2, &Array::new(), &(|out_p4: &Array<crate::check::shrink::Sc>, a_p5: &crate::check::shrink::Sc| crate::prelude::fold(base_p0, out_p4, &(|out2_p6: &Array<crate::check::shrink::Sc>, b_p7: &crate::check::shrink::Sc| add_composed_f(acc_p1, out2_p6, a_p5, b_p7)))));
        if &crate::prelude::len(&fresh_p3) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(acc_p1.clone())
        } else {
            prism_rtl::Turn::More(Rc::new(ClosureFrom { base_p0: base_p0.clone(), acc_p1: crate::prelude::append(acc_p1, &fresh_p3), frontier_p2: fresh_p3.clone() }))
        }
    }
}

/// `Start ClosureFrom, x`: what the function value is when passed to `@Run`.
pub fn start_closure_from_f(base_p0: Array<crate::check::shrink::Sc>, acc_p1: Array<crate::check::shrink::Sc>, frontier_p2: Array<crate::check::shrink::Sc>) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>> {
    Rc::new(ClosureFrom { base_p0, acc_p1, frontier_p2 })
}

/// ```prism
/// AddComposed: fn [Sc], [Sc], Sc, Sc -> [Sc]
/// ```
pub fn add_composed_f(acc_p0: &Array<crate::check::shrink::Sc>, out_p1: &Array<crate::check::shrink::Sc>, a_p2: &crate::check::shrink::Sc, b_p3: &crate::check::shrink::Sc) -> Array<crate::check::shrink::Sc> {
    if &a_p2.callee_p != &b_p3.caller_p {
        out_p1.clone()
    } else {
        {
            let c_p4 = compose_f(a_p2, b_p3);
            if has_sc_f(acc_p0, &c_p4) || has_sc_f(out_p1, &c_p4) {
                out_p1.clone()
            } else {
                crate::prelude::push(out_p1, &c_p4)
            }
        }
    }
}

/// ```prism
/// HasSc: fn [Sc], Sc -> Bool
/// ```
pub fn has_sc_f(xs_p0: &Array<crate::check::shrink::Sc>, c_p1: &crate::check::shrink::Sc) -> bool {
    crate::prelude::fold(xs_p0, &false, &(|seen_p2: &bool, x_p3: &crate::check::shrink::Sc| *seen_p2 || (((&x_p3.caller_p == &c_p1.caller_p) && (&x_p3.callee_p == &c_p1.callee_p)) && (&x_p3.edges_p == &c_p1.edges_p))))
}

/// ```prism
/// Compose: fn Sc, Sc -> Sc
/// ```
pub fn compose_f(a_p0: &crate::check::shrink::Sc, b_p1: &crate::check::shrink::Sc) -> crate::check::shrink::Sc {
    let pairs_p2 = crate::prelude::fold(&a_p0.edges_p, &Array::new(), &(|acc_p3: &Array<(Nat, Nat, bool)>, (x_p4, y_p5, s1_p6): &(Nat, Nat, bool)| crate::prelude::fold(&b_p1.edges_p, acc_p3, &(|acc2_p7: &Array<(Nat, Nat, bool)>, (y2_p8, z_p9, s2_pa): &(Nat, Nat, bool)| if y_p5 == y2_p8 {
        add_edge_f(acc2_p7, x_p4, z_p9, &(*s1_p6 || *s2_pa))
    } else {
        acc2_p7.clone()
    }))));
    crate::check::shrink::Sc { caller_p: a_p0.caller_p.clone(), callee_p: b_p1.callee_p.clone(), edges_p: sort_edges_f(&pairs_p2), span_p: a_p0.span_p.clone(), file_p: a_p0.file_p.clone(), arg_p: a_p0.arg_p.clone() }
}

/// ```prism
/// AddEdge: fn [((Nat, Nat, Bool))], Nat, Nat, Bool -> [((Nat, Nat, Bool))]
/// ```
pub fn add_edge_f(es_p0: &Array<(Nat, Nat, bool)>, x_p1: &Nat, z_p2: &Nat, s_p3: &bool) -> Array<(Nat, Nat, bool)> {
    let others_p4 = crate::prelude::filter(es_p0, &(|(a_p6, b_p7, _): &(Nat, Nat, bool)| !((a_p6 == x_p1) && (b_p7 == z_p2))));
    let had_p5 = crate::prelude::fold(es_p0, &false, &(|seen_p8: &bool, (a_p9, b_pa, t_pb): &(Nat, Nat, bool)| *seen_p8 || (((a_p9 == x_p1) && (b_pa == z_p2)) && *t_pb)));
    crate::prelude::push(&others_p4, &(x_p1.clone(), z_p2.clone(), *s_p3 || had_p5))
}

/// ```prism
/// SortEdges: fn [((Nat, Nat, Bool))] -> [((Nat, Nat, Bool))]
/// ```
pub fn sort_edges_f(es_p0: &Array<(Nat, Nat, bool)>) -> Array<(Nat, Nat, bool)> {
    crate::prelude::fold(es_p0, &Array::new(), &(|acc_p1: &Array<(Nat, Nat, bool)>, e_p2: &(Nat, Nat, bool)| crate::prelude::append(&crate::prelude::push(&crate::prelude::filter(acc_p1, &(|x_p3: &(Nat, Nat, bool)| edge_before_f(x_p3, e_p2))), e_p2), &crate::prelude::filter(acc_p1, &(|x_p4: &(Nat, Nat, bool)| !edge_before_f(x_p4, e_p2))))))
}

/// ```prism
/// EdgeBefore: fn ((Nat, Nat, Bool)), ((Nat, Nat, Bool)) -> Bool
/// ```
pub fn edge_before_f(arg0: &(Nat, Nat, bool), arg1: &(Nat, Nat, bool)) -> bool {
    match (arg0, arg1) {
        ((a1_p0, b1_p1, _), (a2_p2, b2_p3, _)) => (a1_p0 < a2_p2) || ((a1_p0 == a2_p2) && (b1_p1 < b2_p3)),
    }
}

/// ```prism
/// LoopsOf: unbounded fn Shrink, St, Def -> St
/// ```
pub fn loops_of_f(sk_p0: &crate::check::shrink::Shrink, st_p1: &crate::check::types::St, d_p2: &crate::check::env::Def) -> crate::check::types::St {
    let unb_p3 = crate::check::shrink::types::is_unbounded_key_f(&sk_p0.g_p, &crate::check::shrink::types::sig_key_of_f(sk_p0, &d_p2.qk_p));
    if unb_p3 && !st_p1.recording_p {
        st_p1.clone()
    } else {
        {
            let s0_p4 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file_p = d_p2.file_p.clone();
                this
            };
            let s1_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p2), s0_p4.clone(), {
                let sk_p0x = sk_p0.clone();
                let d_p2x = d_p2.clone();
                let unb_p3x = unb_p3;
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                    let sk_p0xy = sk_p0x.clone();
                    let d_p2xy = d_p2x.clone();
                    let unb_p3xy = unb_p3x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_p6 = p0;
                        let c_p7 = p1;
                        prism_rtl::Turn::More(Rc::new(ClauseLoops { sk_p0: sk_p0xy.clone(), st_p1: s_p6.clone(), d_p2: d_p2xy.clone(), c_p3: c_p7.clone(), unb_p4: unb_p3xy }))
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }));
            {
                let mut this: crate::check::types::St = s1_p5.clone();
                this.file_p = st_p1.file_p.clone();
                this
            }
        }
    }
}

/// The step machine of `LoopsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LoopsOf: unbounded fn Shrink, St, Def -> St
/// ```
pub struct LoopsOf {
    pub sk_p0: crate::check::shrink::Shrink,
    pub st_p1: crate::check::types::St,
    pub d_p2: crate::check::env::Def,
}

impl prism_rtl::Job<crate::check::types::St> for LoopsOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let sk_p0 = &self.sk_p0;
        let st_p1 = &self.st_p1;
        let d_p2 = &self.d_p2;
        let unb_p3 = crate::check::shrink::types::is_unbounded_key_f(&sk_p0.g_p, &crate::check::shrink::types::sig_key_of_f(sk_p0, &d_p2.qk_p));
        if unb_p3 && !st_p1.recording_p {
            prism_rtl::Turn::Finished(st_p1.clone())
        } else {
            {
                let s0_p4 = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.file_p = d_p2.file_p.clone();
                    this
                };
                let d_p2x = d_p2.clone();
                let sk_p0x = sk_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_value(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(&d_p2x), s0_p4.clone(), {
                    let sk_p0xx = sk_p0x.clone();
                    let d_p2xx = d_p2x.clone();
                    let unb_p3x = unb_p3;
                    Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                        let sk_p0xxy = sk_p0xx.clone();
                        let d_p2xxy = d_p2xx.clone();
                        let unb_p3xy = unb_p3x;
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let s_p6 = p0;
                            let c_p7 = p1;
                            prism_rtl::Turn::More(Rc::new(ClauseLoops { sk_p0: sk_p0xxy.clone(), st_p1: s_p6.clone(), d_p2: d_p2xxy.clone(), c_p3: c_p7.clone(), unb_p4: unb_p3xy }))
                        }))
                    }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                }), move |fold_12724: crate::check::types::St| {
                    let s1_p5 = fold_12724;
                    prism_rtl::Turn::Finished({
                        let mut this: crate::check::types::St = s1_p5.clone();
                        this.file_p = st_p1x.file_p.clone();
                        this
                    })
                })
            }
        }
    }
}

/// `Start LoopsOf, x`: what the function value is when passed to `@Run`.
pub fn start_loops_of_f(sk_p0: crate::check::shrink::Shrink, st_p1: crate::check::types::St, d_p2: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(LoopsOf { sk_p0, st_p1, d_p2 })
}

/// ```prism
/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
/// ```
pub fn clause_loops_f(sk_p0: &crate::check::shrink::Shrink, st_p1: &crate::check::types::St, d_p2: &crate::check::env::Def, c_p3: &crate::syntax::decls::FnClause, unb_p4: &bool) -> crate::check::types::St {
    let base_p5 = crate::check::shrink::locals::clause_base_f(sk_p0, d_p2, c_p3);
    let spots0_p6 = crate::check::shrink::walk::body_spots_f(&c_p3.body_p, &base_p5);
    if !crate::prelude::fold(&spots0_p6, &false, &(|seen_p7: &bool, sp_p8: &crate::check::shrink::walk::Spot| *seen_p7 || is_while_spot_f(sp_p8))) {
        st_p1.clone()
    } else {
        {
            let spots_p9 = crate::check::shrink::walk::body_spots_f(&c_p3.body_p, &summary_seeds_f(sk_p0, d_p2, &spots0_p6, &base_p5));
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(&spots_p9, &(|sp_pa: &crate::check::shrink::walk::Spot| is_while_spot_f(sp_pa))), st_p1.clone(), {
                let d_p2x = d_p2.clone();
                let unb_p4x = *unb_p4;
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::shrink::walk::Spot)| {
                    let d_p2xy = d_p2x.clone();
                    let unb_p4xy = unb_p4x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_pb = p0;
                        let sp_pc = p1;
                        match &sp_pc {
                            crate::check::shrink::walk::Spot::SpotStmt(w_pd, m_pe) => match &w_pd.kind_p {
                                crate::syntax::StmtKind::SWhile(cond_pf, body_pg) => prism_rtl::Turn::More(Rc::new(CheckWhile { st_p0: s_pb.clone(), c_p1: cond_pf.clone(), body_p2: body_pg.clone(), span_p3: w_pd.span_p.clone(), name_p4: d_p2xy.name_p.clone(), seeds_p5: marks_f(m_pe), unb_p6: unb_p4xy })),
                                _ => prism_rtl::Turn::Finished(s_pb.clone()),
                            },
                            _ => prism_rtl::Turn::Finished(s_pb.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }))
        }
    }
}

/// The step machine of `ClauseLoops`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
/// ```
pub struct ClauseLoops {
    pub sk_p0: crate::check::shrink::Shrink,
    pub st_p1: crate::check::types::St,
    pub d_p2: crate::check::env::Def,
    pub c_p3: crate::syntax::decls::FnClause,
    pub unb_p4: bool,
}

impl prism_rtl::Job<crate::check::types::St> for ClauseLoops {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let sk_p0 = &self.sk_p0;
        let st_p1 = &self.st_p1;
        let d_p2 = &self.d_p2;
        let c_p3 = &self.c_p3;
        let unb_p4 = &self.unb_p4;
        let c_p3x = c_p3.clone();
        let d_p2x = d_p2.clone();
        let sk_p0x = sk_p0.clone();
        let st_p1x = st_p1.clone();
        let unb_p4x = *unb_p4;
        crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0x.clone(), d_p2x.clone(), c_p3x.clone()), move |clause_base_f_12950: Map<Text, crate::check::shrink::Rel>| {
            let base_p5 = clause_base_f_12950;
            crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p3x.body_p.clone(), base_p5.clone()), move |body_spots_f_12987: Array<crate::check::shrink::walk::Spot>| {
                let spots0_p6 = body_spots_f_12987;
                if !crate::prelude::fold(&spots0_p6, &false, &(|seen_p7: &bool, sp_p8: &crate::check::shrink::walk::Spot| *seen_p7 || is_while_spot_f(sp_p8))) {
                    prism_rtl::Turn::Finished(st_p1x.clone())
                } else {
                    crate::prelude::call_then(start_summary_seeds_f(sk_p0x.clone(), d_p2x.clone(), spots0_p6.clone(), base_p5.clone()), move |summary_seeds_f_13131: Map<Text, crate::check::shrink::Rel>| crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p3x.body_p.clone(), summary_seeds_f_13131), move |body_spots_f_13112: Array<crate::check::shrink::walk::Spot>| {
                        let spots_p9 = body_spots_f_13112;
                        crate::prelude::fold_job(crate::prelude::filter(&spots_p9, &(|sp_pa: &crate::check::shrink::walk::Spot| is_while_spot_f(sp_pa))), st_p1x.clone(), {
                            let d_p2xx = d_p2x.clone();
                            let unb_p4xx = unb_p4x;
                            Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::shrink::walk::Spot)| {
                                let d_p2xxy = d_p2xx.clone();
                                let unb_p4xxy = unb_p4xx;
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s_pb = p0;
                                    let sp_pc = p1;
                                    match &sp_pc {
                                        crate::check::shrink::walk::Spot::SpotStmt(w_pd, m_pe) => match &w_pd.kind_p {
                                            crate::syntax::StmtKind::SWhile(cond_pf, body_pg) => prism_rtl::Turn::More(Rc::new(CheckWhile { st_p0: s_pb.clone(), c_p1: cond_pf.clone(), body_p2: body_pg.clone(), span_p3: w_pd.span_p.clone(), name_p4: d_p2xxy.name_p.clone(), seeds_p5: marks_f(m_pe), unb_p6: unb_p4xxy })),
                                            _ => prism_rtl::Turn::Finished(s_pb.clone()),
                                        },
                                        _ => prism_rtl::Turn::Finished(s_pb.clone()),
                                    }
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle()
                    }))
                }
            })
        })
    }
}

/// `Start ClauseLoops, x`: what the function value is when passed to `@Run`.
pub fn start_clause_loops_f(sk_p0: crate::check::shrink::Shrink, st_p1: crate::check::types::St, d_p2: crate::check::env::Def, c_p3: crate::syntax::decls::FnClause, unb_p4: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ClauseLoops { sk_p0, st_p1, d_p2, c_p3, unb_p4 })
}

/// ```prism
/// Marks: fn (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn marks_f(m_p0: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    crate::prelude::fold(&crate::prelude::keys(m_p0), m_p0, &(|m2_p1: &Map<Text, crate::check::shrink::Rel>, k_p2: &Text| if crate::syntax::lexer::chars::contains_f(k_p2, &Text::lit(":")) {
        m2_p1.clone()
    } else {
        crate::prelude::remove(m2_p1, k_p2)
    }))
}

/// ```prism
/// IsWhileSpot: fn Spot -> Bool
/// ```
pub fn is_while_spot_f(spot0: &crate::check::shrink::walk::Spot) -> bool {
    match spot0 {
        crate::check::shrink::walk::Spot::SpotStmt(s_p0, _) => match &s_p0.kind_p {
            crate::syntax::StmtKind::SWhile(_, _) => true,
            _ => false,
        },
        crate::check::shrink::walk::Spot::SpotExpr(_, _) => false,
    }
}

/// ```prism
/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
/// ```
pub fn check_while_f(st_p0: &crate::check::types::St, c_p1: &crate::syntax::Cond, body_p2: &crate::syntax::Block, span_p3: &crate::syntax::Range, name_p4: &Text, seeds_p5: &Map<Text, crate::check::shrink::Rel>, unb_p6: &bool) -> crate::check::types::St {
    let vars_p7 = set_targets_f(&body_p2.stmts_p);
    let base_p8 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&vars_p7)), seeds_p5, &(|m_pb: &Map<Text, crate::check::shrink::Rel>, i_pc: &Nat| crate::prelude::insert(m_pb, &crate::prelude::or(&crate::prelude::index(&vars_p7, i_pc), &Text::lit("")), &crate::check::shrink::Rel { param_p: i_pc.clone(), strict_p: false })));
    let rels_p9 = crate::check::shrink::relations::cond_rels_f(c_p1, &base_p8);
    let ok_pa = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&vars_p7)), false, {
        let body_p2x = body_p2.clone();
        let vars_p7x = vars_p7.clone();
        let rels_p9x = rels_p9.clone();
        Rc::new(move |(p0, p1): (bool, Nat)| {
            let body_p2xy = body_p2x.clone();
            let vars_p7xy = vars_p7x.clone();
            let rels_p9xy = rels_p9x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_pd = p0;
                let i_pe = p1;
                prism_rtl::Turn::Finished(seen_pd || all_paths_strict_f(&body_p2xy.stmts_p, &crate::prelude::or(&crate::prelude::index(&vars_p7xy, &i_pe), &Text::lit("")), &i_pe, &rels_p9xy))
            }))
        }) as Rc<dyn Fn((bool, Nat)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    if ok_pa {
        st_p0.clone()
    } else {
        if *unb_p6 {
            note_unshrunk_f(st_p0, span_p3)
        } else {
            crate::check::types::recording::err_fix_f(st_p0, &Text::lit("may-not-end"), span_p3, &Text::from(format!("this loop in `{}` may not end: nothing it sets gets smaller on every turn", name_p4)), &Text::from(format!("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `{}` `unbounded fn`", name_p4)))
        }
    }
}

/// The step machine of `CheckWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
/// ```
pub struct CheckWhile {
    pub st_p0: crate::check::types::St,
    pub c_p1: crate::syntax::Cond,
    pub body_p2: crate::syntax::Block,
    pub span_p3: crate::syntax::Range,
    pub name_p4: Text,
    pub seeds_p5: Map<Text, crate::check::shrink::Rel>,
    pub unb_p6: bool,
}

impl prism_rtl::Job<crate::check::types::St> for CheckWhile {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let c_p1 = &self.c_p1;
        let body_p2 = &self.body_p2;
        let span_p3 = &self.span_p3;
        let name_p4 = &self.name_p4;
        let seeds_p5 = &self.seeds_p5;
        let unb_p6 = &self.unb_p6;
        let body_p2x = body_p2.clone();
        let c_p1x = c_p1.clone();
        let name_p4x = name_p4.clone();
        let seeds_p5x = seeds_p5.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        let unb_p6x = *unb_p6;
        crate::prelude::call_then(start_set_targets_f(body_p2x.stmts_p.clone()), move |set_targets_f_14238: Array<Text>| {
            let vars_p7 = set_targets_f_14238;
            let base_p8 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&vars_p7)), &seeds_p5x, &(|m_pb: &Map<Text, crate::check::shrink::Rel>, i_pc: &Nat| crate::prelude::insert(m_pb, &crate::prelude::or(&crate::prelude::index(&vars_p7, i_pc), &Text::lit("")), &crate::check::shrink::Rel { param_p: i_pc.clone(), strict_p: false })));
            crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_p1x.clone(), base_p8.clone()), move |cond_rels_f_14552: Map<Text, crate::check::shrink::Rel>| {
                let rels_p9 = cond_rels_f_14552;
                crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&vars_p7)), false, {
                    let body_p2xx = body_p2x.clone();
                    let vars_p7x = vars_p7.clone();
                    let rels_p9x = rels_p9.clone();
                    Rc::new(move |(p0, p1): (bool, Nat)| {
                        let body_p2xxy = body_p2xx.clone();
                        let vars_p7xy = vars_p7x.clone();
                        let rels_p9xy = rels_p9x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let seen_pd = p0;
                            let i_pe = p1;
                            prism_rtl::Turn::Finished(seen_pd || all_paths_strict_f(&body_p2xxy.stmts_p, &crate::prelude::or(&crate::prelude::index(&vars_p7xy, &i_pe), &Text::lit("")), &i_pe, &rels_p9xy))
                        }))
                    }) as Rc<dyn Fn((bool, Nat)) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |fold_14582: bool| {
                    let ok_pa = fold_14582;
                    if ok_pa {
                        prism_rtl::Turn::Finished(st_p0x.clone())
                    } else {
                        if unb_p6x {
                            prism_rtl::Turn::Finished(note_unshrunk_f(&st_p0x, &span_p3x))
                        } else {
                            prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p0x, &Text::lit("may-not-end"), &span_p3x, &Text::from(format!("this loop in `{}` may not end: nothing it sets gets smaller on every turn", &name_p4x)), &Text::from(format!("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `{}` `unbounded fn`", &name_p4x))))
                        }
                    }
                })
            })
        })
    }
}

/// `Start CheckWhile, x`: what the function value is when passed to `@Run`.
pub fn start_check_while_f(st_p0: crate::check::types::St, c_p1: crate::syntax::Cond, body_p2: crate::syntax::Block, span_p3: crate::syntax::Range, name_p4: Text, seeds_p5: Map<Text, crate::check::shrink::Rel>, unb_p6: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckWhile { st_p0, c_p1, body_p2, span_p3, name_p4, seeds_p5, unb_p6 })
}

/// ```prism
/// NoteUnshrunk: fn St, Range -> St
/// ```
pub fn note_unshrunk_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.typed_p.unshrunk_p = crate::prelude::push(&this.typed_p.unshrunk_p, &crate::check::types::recording::at_here_f(st_p0, span_p1));
    this
}

/// ```prism
/// SetTargets: unbounded fn [Stmt] -> [Text]
/// ```
pub fn set_targets_f(stmts_p0: &Array<crate::syntax::Stmt>) -> Array<Text> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmts_spots_f(stmts_p0, &Map::new()), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::walk::Spot)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p1 = p0;
        let sp_p2 = p1;
        crate::prelude::call_then(start_spot_set_root_f(sp_p2.clone()), move |spot_set_root_f_15448: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p1, &spot_set_root_f_15448)))
    }))) as Rc<dyn Fn((Array<Text>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `SetTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetTargets: unbounded fn [Stmt] -> [Text]
/// ```
pub struct SetTargets {
    pub stmts_p0: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<Text>> for SetTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let stmts_p0 = &self.stmts_p0;
        let stmts_p0x = stmts_p0.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_stmts_spots_f(stmts_p0x.clone(), Map::new()), move |stmts_spots_f_15391: Array<crate::check::shrink::walk::Spot>| crate::prelude::fold_job(stmts_spots_f_15391, Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::walk::Spot)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p1 = p0;
            let sp_p2 = p1;
            crate::prelude::call_then(start_spot_set_root_f(sp_p2.clone()), move |spot_set_root_f_15448: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p1, &spot_set_root_f_15448)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
    }
}

/// `Start SetTargets, x`: what the function value is when passed to `@Run`.
pub fn start_set_targets_f(stmts_p0: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SetTargets { stmts_p0 })
}

/// ```prism
/// SpotSetRoot: unbounded fn Spot -> [Text]
/// ```
pub fn spot_set_root_f(spot0: &crate::check::shrink::walk::Spot) -> Array<Text> {
    match spot0 {
        crate::check::shrink::walk::Spot::SpotStmt(s_p0, _) => match &s_p0.kind_p {
            crate::syntax::StmtKind::SSet(t_p1, _) => crate::prelude::take(&crate::check::passes::borrows::ref_path_f(t_p1), &Nat::from(1u32)),
            crate::syntax::StmtKind::SAccum(t_p2, _, _) => crate::prelude::take(&crate::check::passes::borrows::ref_path_f(t_p2), &Nat::from(1u32)),
            _ => Array::new(),
        },
        crate::check::shrink::walk::Spot::SpotExpr(_, _) => Array::new(),
    }
}

/// The step machine of `SpotSetRoot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotSetRoot: unbounded fn Spot -> [Text]
/// ```
pub struct SpotSetRoot {
    pub spot0: crate::check::shrink::walk::Spot,
}

impl prism_rtl::Job<Array<Text>> for SpotSetRoot {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let spot0 = &self.spot0;
        match spot0 {
            crate::check::shrink::walk::Spot::SpotStmt(s_p0, _) => match &s_p0.kind_p {
                crate::syntax::StmtKind::SSet(t_p1, _) => {
                    let t_p1x = t_p1.clone();
                    crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p1x.clone()), move |ref_path_f_15584: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::take(&ref_path_f_15584, &Nat::from(1u32))))
                },
                crate::syntax::StmtKind::SAccum(t_p2, _, _) => {
                    let t_p2x = t_p2.clone();
                    crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p2x.clone()), move |ref_path_f_15634: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::take(&ref_path_f_15634, &Nat::from(1u32))))
                },
                _ => prism_rtl::Turn::Finished(Array::new()),
            },
            crate::check::shrink::walk::Spot::SpotExpr(_, _) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start SpotSetRoot, x`: what the function value is when passed to `@Run`.
pub fn start_spot_set_root_f(spot0: crate::check::shrink::walk::Spot) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotSetRoot { spot0 })
}

/// ```prism
/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn all_paths_strict_f(stmts_p0: &Array<crate::syntax::Stmt>, v_p1: &Text, vi_p2: &Nat, outer_p3: &Map<Text, crate::check::shrink::Rel>) -> bool {
    let rels_p4 = crate::check::shrink::relations::block_rels_f(stmts_p0, outer_p3);
    crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p0.clone(), false, {
        let v_p1x = v_p1.clone();
        let vi_p2x = vi_p2.clone();
        let rels_p4x = rels_p4.clone();
        Rc::new(move |(p0, p1): (bool, crate::syntax::Stmt)| {
            let v_p1xy = v_p1x.clone();
            let vi_p2xy = vi_p2x.clone();
            let rels_p4xy = rels_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p5 = p0;
                let s_p6 = p1;
                match &s_p6.kind_p {
                    crate::syntax::StmtKind::SSet(t_p7, value_p8) => {
                        let t_p7x = t_p7.clone();
                        let value_p8x = value_p8.clone();
                        crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p7x.clone()), move |ref_path_f_16319: Array<Text>| if &ref_path_f_16319 == &Array::from(vec![v_p1xy.clone()]) {
                            if is_zero_lit_f(&value_p8x) {
                                prism_rtl::Turn::Finished(ok_p5)
                            } else {
                                prism_rtl::Turn::More(Rc::new(SetsStrict { e_p0: value_p8x.clone(), v_p1: v_p1xy.clone(), vi_p2: vi_p2xy.clone(), rels_p3: rels_p4xy.clone() }))
                            }
                        } else {
                            prism_rtl::Turn::Finished(ok_p5 && !stmt_sets_weak_f(&s_p6, &v_p1xy, &vi_p2xy, &rels_p4xy))
                        })
                    },
                    crate::syntax::StmtKind::SExpr(e_p9) => match &*e_p9.kind_p {
                        crate::syntax::ExprKind::EIf(c_pa, tb_pb, eb_oc) => {
                            let eb_ocx = eb_oc.clone();
                            let c_pax = (**c_pa).clone();
                            let tb_pbx = tb_pb.clone();
                            crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_pax.clone(), rels_p4xy.clone()), move |cond_rels_f_16544: Map<Text, crate::check::shrink::Rel>| {
                                let tr_pd = cond_rels_f_16544;
                                match &eb_ocx {
                                    Some(b_pe) => {
                                        let b_pex = b_pe.clone();
                                        crate::prelude::call_then(start_all_paths_strict_f(tb_pbx.stmts_p.clone(), v_p1xy.clone(), vi_p2xy.clone(), tr_pd.clone()), move |all_paths_strict_f_16617: bool| if all_paths_strict_f_16617 && all_paths_strict_f(&b_pex.stmts_p, &v_p1xy, &vi_p2xy, &rels_p4xy) {
                                            prism_rtl::Turn::Finished(true)
                                        } else {
                                            prism_rtl::Turn::Finished((ok_p5 && !sets_weak_f(&tb_pbx.stmts_p, &v_p1xy, &vi_p2xy, &tr_pd)) && !sets_weak_f(&b_pex.stmts_p, &v_p1xy, &vi_p2xy, &rels_p4xy))
                                        })
                                    },
                                    None => prism_rtl::Turn::Finished(ok_p5 && !sets_weak_f(&tb_pbx.stmts_p, &v_p1xy, &vi_p2xy, &tr_pd)),
                                }
                            })
                        },
                        crate::syntax::ExprKind::EMatch(subj_pf, arms_pg) => {
                            let arms_pgx = arms_pg.clone();
                            let subj_pfx = (**subj_pf).clone();
                            crate::prelude::call_value(crate::prelude::fold_job(arms_pgx.clone(), true, {
                                let v_p1xyx = v_p1xy.clone();
                                let vi_p2xyx = vi_p2xy.clone();
                                let subj_pfxx = subj_pfx.clone();
                                let rels_p4xyx = rels_p4xy.clone();
                                Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                    let v_p1xyxy = v_p1xyx.clone();
                                    let vi_p2xyxy = vi_p2xyx.clone();
                                    let subj_pfxxy = subj_pfxx.clone();
                                    let rels_p4xyxy = rels_p4xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let all_arms_ph = p0;
                                        let a_pi = p1;
                                        prism_rtl::Turn::Finished(all_arms_ph && all_paths_strict_f(&a_pi.body_p.stmts_p, &v_p1xyxy, &vi_p2xyxy, &crate::check::shrink::relations::arm_pat_rels_f(&subj_pfxxy, &a_pi, &rels_p4xyxy)))
                                    }))
                                }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }), move |fold_16906: bool| if fold_16906 {
                                prism_rtl::Turn::Finished(true)
                            } else {
                                prism_rtl::Turn::Finished(ok_p5 && !crate::prelude::run_to_end(crate::prelude::fold_job(arms_pgx.clone(), false, {
                                    let v_p1xyx = v_p1xy.clone();
                                    let vi_p2xyx = vi_p2xy.clone();
                                    let subj_pfxx = subj_pfx.clone();
                                    let rels_p4xyx = rels_p4xy.clone();
                                    Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                        let v_p1xyxy = v_p1xyx.clone();
                                        let vi_p2xyxy = vi_p2xyx.clone();
                                        let subj_pfxxy = subj_pfxx.clone();
                                        let rels_p4xyxy = rels_p4xyx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let any_arm_pj = p0;
                                            let a_pk = p1;
                                            prism_rtl::Turn::Finished(any_arm_pj || sets_weak_f(&a_pk.body_p.stmts_p, &v_p1xyxy, &vi_p2xyxy, &crate::check::shrink::relations::arm_pat_rels_f(&subj_pfxxy, &a_pk, &rels_p4xyxy)))
                                        }))
                                    }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                                })))
                            })
                        },
                        _ => prism_rtl::Turn::Finished(ok_p5 && !stmt_sets_weak_f(&s_p6, &v_p1xy, &vi_p2xy, &rels_p4xy)),
                    },
                    _ => prism_rtl::Turn::Finished(ok_p5 && !stmt_sets_weak_f(&s_p6, &v_p1xy, &vi_p2xy, &rels_p4xy)),
                }
            }))
        }) as Rc<dyn Fn((bool, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `AllPathsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct AllPathsStrict {
    pub stmts_p0: Array<crate::syntax::Stmt>,
    pub v_p1: Text,
    pub vi_p2: Nat,
    pub outer_p3: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<bool> for AllPathsStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let stmts_p0 = &self.stmts_p0;
        let v_p1 = &self.v_p1;
        let vi_p2 = &self.vi_p2;
        let outer_p3 = &self.outer_p3;
        let outer_p3x = outer_p3.clone();
        let stmts_p0x = stmts_p0.clone();
        let v_p1x = v_p1.clone();
        let vi_p2x = vi_p2.clone();
        crate::prelude::call_then(crate::check::shrink::relations::start_block_rels_f(stmts_p0x.clone(), outer_p3x.clone()), move |block_rels_f_16211: Map<Text, crate::check::shrink::Rel>| {
            let rels_p4 = block_rels_f_16211;
            crate::prelude::fold_job(stmts_p0x.clone(), false, {
                let v_p1xx = v_p1x.clone();
                let vi_p2xx = vi_p2x.clone();
                let rels_p4x = rels_p4.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Stmt)| {
                    let v_p1xxy = v_p1xx.clone();
                    let vi_p2xxy = vi_p2xx.clone();
                    let rels_p4xy = rels_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p5 = p0;
                        let s_p6 = p1;
                        match &s_p6.kind_p {
                            crate::syntax::StmtKind::SSet(t_p7, value_p8) => {
                                let t_p7x = t_p7.clone();
                                let value_p8x = value_p8.clone();
                                crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p7x.clone()), move |ref_path_f_16319: Array<Text>| if &ref_path_f_16319 == &Array::from(vec![v_p1xxy.clone()]) {
                                    if is_zero_lit_f(&value_p8x) {
                                        prism_rtl::Turn::Finished(ok_p5)
                                    } else {
                                        prism_rtl::Turn::More(Rc::new(SetsStrict { e_p0: value_p8x.clone(), v_p1: v_p1xxy.clone(), vi_p2: vi_p2xxy.clone(), rels_p3: rels_p4xy.clone() }))
                                    }
                                } else {
                                    prism_rtl::Turn::Finished(ok_p5 && !stmt_sets_weak_f(&s_p6, &v_p1xxy, &vi_p2xxy, &rels_p4xy))
                                })
                            },
                            crate::syntax::StmtKind::SExpr(e_p9) => match &*e_p9.kind_p {
                                crate::syntax::ExprKind::EIf(c_pa, tb_pb, eb_oc) => {
                                    let eb_ocx = eb_oc.clone();
                                    let c_pax = (**c_pa).clone();
                                    let tb_pbx = tb_pb.clone();
                                    crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_pax.clone(), rels_p4xy.clone()), move |cond_rels_f_16544: Map<Text, crate::check::shrink::Rel>| {
                                        let tr_pd = cond_rels_f_16544;
                                        match &eb_ocx {
                                            Some(b_pe) => {
                                                let b_pex = b_pe.clone();
                                                crate::prelude::call_then(start_all_paths_strict_f(tb_pbx.stmts_p.clone(), v_p1xxy.clone(), vi_p2xxy.clone(), tr_pd.clone()), move |all_paths_strict_f_16617: bool| if all_paths_strict_f_16617 && all_paths_strict_f(&b_pex.stmts_p, &v_p1xxy, &vi_p2xxy, &rels_p4xy) {
                                                    prism_rtl::Turn::Finished(true)
                                                } else {
                                                    prism_rtl::Turn::Finished((ok_p5 && !sets_weak_f(&tb_pbx.stmts_p, &v_p1xxy, &vi_p2xxy, &tr_pd)) && !sets_weak_f(&b_pex.stmts_p, &v_p1xxy, &vi_p2xxy, &rels_p4xy))
                                                })
                                            },
                                            None => prism_rtl::Turn::Finished(ok_p5 && !sets_weak_f(&tb_pbx.stmts_p, &v_p1xxy, &vi_p2xxy, &tr_pd)),
                                        }
                                    })
                                },
                                crate::syntax::ExprKind::EMatch(subj_pf, arms_pg) => {
                                    let arms_pgx = arms_pg.clone();
                                    let subj_pfx = (**subj_pf).clone();
                                    crate::prelude::call_value(crate::prelude::fold_job(arms_pgx.clone(), true, {
                                        let v_p1xxyx = v_p1xxy.clone();
                                        let vi_p2xxyx = vi_p2xxy.clone();
                                        let subj_pfxx = subj_pfx.clone();
                                        let rels_p4xyx = rels_p4xy.clone();
                                        Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                            let v_p1xxyxy = v_p1xxyx.clone();
                                            let vi_p2xxyxy = vi_p2xxyx.clone();
                                            let subj_pfxxy = subj_pfxx.clone();
                                            let rels_p4xyxy = rels_p4xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let all_arms_ph = p0;
                                                let a_pi = p1;
                                                prism_rtl::Turn::Finished(all_arms_ph && all_paths_strict_f(&a_pi.body_p.stmts_p, &v_p1xxyxy, &vi_p2xxyxy, &crate::check::shrink::relations::arm_pat_rels_f(&subj_pfxxy, &a_pi, &rels_p4xyxy)))
                                            }))
                                        }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }), move |fold_16906: bool| if fold_16906 {
                                        prism_rtl::Turn::Finished(true)
                                    } else {
                                        prism_rtl::Turn::Finished(ok_p5 && !crate::prelude::run_to_end(crate::prelude::fold_job(arms_pgx.clone(), false, {
                                            let v_p1xxyx = v_p1xxy.clone();
                                            let vi_p2xxyx = vi_p2xxy.clone();
                                            let subj_pfxx = subj_pfx.clone();
                                            let rels_p4xyx = rels_p4xy.clone();
                                            Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                                let v_p1xxyxy = v_p1xxyx.clone();
                                                let vi_p2xxyxy = vi_p2xxyx.clone();
                                                let subj_pfxxy = subj_pfxx.clone();
                                                let rels_p4xyxy = rels_p4xyx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let any_arm_pj = p0;
                                                    let a_pk = p1;
                                                    prism_rtl::Turn::Finished(any_arm_pj || sets_weak_f(&a_pk.body_p.stmts_p, &v_p1xxyxy, &vi_p2xxyxy, &crate::check::shrink::relations::arm_pat_rels_f(&subj_pfxxy, &a_pk, &rels_p4xyxy)))
                                                }))
                                            }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                                        })))
                                    })
                                },
                                _ => prism_rtl::Turn::Finished(ok_p5 && !stmt_sets_weak_f(&s_p6, &v_p1xxy, &vi_p2xxy, &rels_p4xy)),
                            },
                            _ => prism_rtl::Turn::Finished(ok_p5 && !stmt_sets_weak_f(&s_p6, &v_p1xxy, &vi_p2xxy, &rels_p4xy)),
                        }
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle()
        })
    }
}

/// `Start AllPathsStrict, x`: what the function value is when passed to `@Run`.
pub fn start_all_paths_strict_f(stmts_p0: Array<crate::syntax::Stmt>, v_p1: Text, vi_p2: Nat, outer_p3: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(AllPathsStrict { stmts_p0, v_p1, vi_p2, outer_p3 })
}

/// ```prism
/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn sets_weak_f(stmts_p0: &Array<crate::syntax::Stmt>, v_p1: &Text, vi_p2: &Nat, outer_p3: &Map<Text, crate::check::shrink::Rel>) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmts_spots_f(stmts_p0, outer_p3), false, {
        let v_p1x = v_p1.clone();
        let vi_p2x = vi_p2.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
            let v_p1xy = v_p1x.clone();
            let vi_p2xy = vi_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_p4 = p0;
                let sp_p5 = p1;
                prism_rtl::Turn::Finished(seen_p4 || spot_sets_weak_f(&sp_p5, &v_p1xy, &vi_p2xy))
            }))
        }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `SetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct SetsWeak {
    pub stmts_p0: Array<crate::syntax::Stmt>,
    pub v_p1: Text,
    pub vi_p2: Nat,
    pub outer_p3: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<bool> for SetsWeak {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let stmts_p0 = &self.stmts_p0;
        let v_p1 = &self.v_p1;
        let vi_p2 = &self.vi_p2;
        let outer_p3 = &self.outer_p3;
        let outer_p3x = outer_p3.clone();
        let stmts_p0x = stmts_p0.clone();
        let v_p1x = v_p1.clone();
        let vi_p2x = vi_p2.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_stmts_spots_f(stmts_p0x.clone(), outer_p3x.clone()), move |stmts_spots_f_17553: Array<crate::check::shrink::walk::Spot>| crate::prelude::fold_job(stmts_spots_f_17553, false, {
            let v_p1xx = v_p1x.clone();
            let vi_p2xx = vi_p2x.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                let v_p1xxy = v_p1xx.clone();
                let vi_p2xxy = vi_p2xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_p4 = p0;
                    let sp_p5 = p1;
                    prism_rtl::Turn::Finished(seen_p4 || spot_sets_weak_f(&sp_p5, &v_p1xxy, &vi_p2xxy))
                }))
            }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start SetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_sets_weak_f(stmts_p0: Array<crate::syntax::Stmt>, v_p1: Text, vi_p2: Nat, outer_p3: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SetsWeak { stmts_p0, v_p1, vi_p2, outer_p3 })
}

/// ```prism
/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn stmt_sets_weak_f(s_p0: &crate::syntax::Stmt, v_p1: &Text, vi_p2: &Nat, rels_p3: &Map<Text, crate::check::shrink::Rel>) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmt_spots_f(s_p0, rels_p3), false, {
        let v_p1x = v_p1.clone();
        let vi_p2x = vi_p2.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
            let v_p1xy = v_p1x.clone();
            let vi_p2xy = vi_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_p4 = p0;
                let sp_p5 = p1;
                prism_rtl::Turn::Finished(seen_p4 || spot_sets_weak_f(&sp_p5, &v_p1xy, &vi_p2xy))
            }))
        }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `StmtSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct StmtSetsWeak {
    pub s_p0: crate::syntax::Stmt,
    pub v_p1: Text,
    pub vi_p2: Nat,
    pub rels_p3: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<bool> for StmtSetsWeak {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let s_p0 = &self.s_p0;
        let v_p1 = &self.v_p1;
        let vi_p2 = &self.vi_p2;
        let rels_p3 = &self.rels_p3;
        let rels_p3x = rels_p3.clone();
        let s_p0x = s_p0.clone();
        let v_p1x = v_p1.clone();
        let vi_p2x = vi_p2.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_stmt_spots_f(s_p0x.clone(), rels_p3x.clone()), move |stmt_spots_f_17736: Array<crate::check::shrink::walk::Spot>| crate::prelude::fold_job(stmt_spots_f_17736, false, {
            let v_p1xx = v_p1x.clone();
            let vi_p2xx = vi_p2x.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                let v_p1xxy = v_p1xx.clone();
                let vi_p2xxy = vi_p2xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_p4 = p0;
                    let sp_p5 = p1;
                    prism_rtl::Turn::Finished(seen_p4 || spot_sets_weak_f(&sp_p5, &v_p1xxy, &vi_p2xxy))
                }))
            }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start StmtSetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_sets_weak_f(s_p0: crate::syntax::Stmt, v_p1: Text, vi_p2: Nat, rels_p3: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(StmtSetsWeak { s_p0, v_p1, vi_p2, rels_p3 })
}

/// ```prism
/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub fn spot_sets_weak_f(spot0: &crate::check::shrink::walk::Spot, text1: &Text, n2: &Nat) -> bool {
    match (spot0, text1, n2) {
        (crate::check::shrink::walk::Spot::SpotStmt(s_p0, m_p1), v_p2, vi_p3) => match &s_p0.kind_p {
            crate::syntax::StmtKind::SSet(t_p4, value_p5) => ((&crate::prelude::take(&crate::check::passes::borrows::ref_path_f(t_p4), &Nat::from(1u32)) == &Array::from(vec![v_p2.clone()])) && !sets_strict_f(value_p5, v_p2, vi_p3, m_p1)) && !((&crate::check::passes::borrows::ref_path_f(t_p4) == &Array::from(vec![v_p2.clone()])) && is_zero_lit_f(value_p5)),
            crate::syntax::StmtKind::SAccum(t_p6, _, _) => &crate::prelude::take(&crate::check::passes::borrows::ref_path_f(t_p6), &Nat::from(1u32)) == &Array::from(vec![v_p2.clone()]),
            _ => false,
        },
        (crate::check::shrink::walk::Spot::SpotExpr(_, _), _, _) => false,
    }
}

/// The step machine of `SpotSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub struct SpotSetsWeak {
    pub spot0: crate::check::shrink::walk::Spot,
    pub text1: Text,
    pub n2: Nat,
}

impl prism_rtl::Job<bool> for SpotSetsWeak {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let spot0 = &self.spot0;
        let text1 = &self.text1;
        let n2 = &self.n2;
        match (spot0, text1, n2) {
            (crate::check::shrink::walk::Spot::SpotStmt(s_p0, m_p1), v_p2, vi_p3) => match &s_p0.kind_p {
                crate::syntax::StmtKind::SSet(t_p4, value_p5) => {
                    let m_p1x = m_p1.clone();
                    let t_p4x = t_p4.clone();
                    let v_p2x = v_p2.clone();
                    let value_p5x = value_p5.clone();
                    let vi_p3x = vi_p3.clone();
                    crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p4x.clone()), move |ref_path_f_17939: Array<Text>| prism_rtl::Turn::Finished(((&crate::prelude::take(&ref_path_f_17939, &Nat::from(1u32)) == &Array::from(vec![v_p2x.clone()])) && !sets_strict_f(&value_p5x, &v_p2x, &vi_p3x, &m_p1x)) && !((&crate::check::passes::borrows::ref_path_f(&t_p4x) == &Array::from(vec![v_p2x.clone()])) && is_zero_lit_f(&value_p5x))))
                },
                crate::syntax::StmtKind::SAccum(t_p6, _, _) => {
                    let t_p6x = t_p6.clone();
                    let v_p2x = v_p2.clone();
                    crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p6x.clone()), move |ref_path_f_18088: Array<Text>| prism_rtl::Turn::Finished(&crate::prelude::take(&ref_path_f_18088, &Nat::from(1u32)) == &Array::from(vec![v_p2x.clone()])))
                },
                _ => prism_rtl::Turn::Finished(false),
            },
            (crate::check::shrink::walk::Spot::SpotExpr(_, _), _, _) => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start SpotSetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_spot_sets_weak_f(spot0: crate::check::shrink::walk::Spot, text1: Text, n2: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SpotSetsWeak { spot0, text1, n2 })
}

/// ```prism
/// IsZeroLit: fn Expr -> Bool
/// ```
pub fn is_zero_lit_f(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ELit(l_p1) => match &l_p1.kind_p {
            crate::syntax::LitKind::LInt(d_p2) => d_p2 == &Text::lit("0"),
            _ => false,
        },
        crate::syntax::ExprKind::EGroup(x_p3) => is_zero_lit_f(&**x_p3),
        _ => false,
    }
}

/// ```prism
/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn sets_strict_f(e_p0: &crate::syntax::Expr, v_p1: &Text, vi_p2: &Nat, rels_p3: &Map<Text, crate::check::shrink::Rel>) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::EGroup(x_p4) => sets_strict_f(&**x_p4, v_p1, vi_p2, rels_p3),
        crate::syntax::ExprKind::EBinary(m19465_1_0, l_p5, _) if (m19465_1_0 == &Text::lit("-?")) => is_nat_minus_f(rels_p3, e_p0) && sets_strict_f(&**l_p5, v_p1, vi_p2, rels_p3),
        _ => rel_strict_f(rels_p3, e_p0, vi_p2) || call_strict_f(e_p0, v_p1, vi_p2, rels_p3),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SetsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct SetsStrict {
    pub e_p0: crate::syntax::Expr,
    pub v_p1: Text,
    pub vi_p2: Nat,
    pub rels_p3: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<bool> for SetsStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let e_p0 = &self.e_p0;
        let v_p1 = &self.v_p1;
        let vi_p2 = &self.vi_p2;
        let rels_p3 = &self.rels_p3;
        match &*e_p0.kind_p {
            crate::syntax::ExprKind::EGroup(x_p4) => prism_rtl::Turn::More(Rc::new(SetsStrict { e_p0: (**x_p4).clone(), v_p1: v_p1.clone(), vi_p2: vi_p2.clone(), rels_p3: rels_p3.clone() })),
            crate::syntax::ExprKind::EBinary(m19465_1_0, l_p5, _) if (m19465_1_0 == &Text::lit("-?")) => prism_rtl::Turn::Finished(is_nat_minus_f(rels_p3, e_p0) && sets_strict_f(&**l_p5, v_p1, vi_p2, rels_p3)),
            _ => {
                let e_p0x = e_p0.clone();
                let rels_p3x = rels_p3.clone();
                let v_p1x = v_p1.clone();
                let vi_p2x = vi_p2.clone();
                crate::prelude::call_then(start_rel_strict_f(rels_p3x.clone(), e_p0x.clone(), vi_p2x.clone()), move |rel_strict_f_19615: bool| prism_rtl::Turn::Finished(rel_strict_f_19615 || call_strict_f(&e_p0x, &v_p1x, &vi_p2x, &rels_p3x)))
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SetsStrict, x`: what the function value is when passed to `@Run`.
pub fn start_sets_strict_f(e_p0: crate::syntax::Expr, v_p1: Text, vi_p2: Nat, rels_p3: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SetsStrict { e_p0, v_p1, vi_p2, rels_p3 })
}

/// ```prism
/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
/// ```
pub fn rel_strict_f(rels_p0: &Map<Text, crate::check::shrink::Rel>, e_p1: &crate::syntax::Expr, vi_p2: &Nat) -> bool {
    match crate::check::shrink::walk::rel_of_o(rels_p0, e_p1) {
        Some(r_p3) => r_p3.strict_p && (&r_p3.param_p == vi_p2),
        None => false,
    }
}

/// The step machine of `RelStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
/// ```
pub struct RelStrict {
    pub rels_p0: Map<Text, crate::check::shrink::Rel>,
    pub e_p1: crate::syntax::Expr,
    pub vi_p2: Nat,
}

impl prism_rtl::Job<bool> for RelStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let rels_p0 = &self.rels_p0;
        let e_p1 = &self.e_p1;
        let vi_p2 = &self.vi_p2;
        let e_p1x = e_p1.clone();
        let rels_p0x = rels_p0.clone();
        let vi_p2x = vi_p2.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(rels_p0x.clone(), e_p1x.clone()), move |rel_of_o_19761: Option<crate::check::shrink::Rel>| match rel_of_o_19761 {
            Some(r_p3) => prism_rtl::Turn::Finished(r_p3.strict_p && (&r_p3.param_p == &vi_p2x)),
            None => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start RelStrict, x`: what the function value is when passed to `@Run`.
pub fn start_rel_strict_f(rels_p0: Map<Text, crate::check::shrink::Rel>, e_p1: crate::syntax::Expr, vi_p2: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(RelStrict { rels_p0, e_p1, vi_p2 })
}

/// ```prism
/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn call_strict_f(e_p0: &crate::syntax::Expr, v_p1: &Text, vi_p2: &Nat, rels_p3: &Map<Text, crate::check::shrink::Rel>) -> bool {
    match crate::check::shrink::walk::call_of_o(e_p0) {
        Some((c_p4, args_p5)) => if crate::check::shrink::walk::is_non_nat_min_f(rels_p3, e_p0, &c_p4) {
            false
        } else {
            match crate::check::shrink::walk::no_larger_arg_o(rels_p3, &c_p4, &args_p5) {
                Some(a_p6) => sets_strict_f(&a_p6, v_p1, vi_p2, rels_p3),
                None => false,
            }
        },
        None => false,
    }
}

/// The step machine of `CallStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct CallStrict {
    pub e_p0: crate::syntax::Expr,
    pub v_p1: Text,
    pub vi_p2: Nat,
    pub rels_p3: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<bool> for CallStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let e_p0 = &self.e_p0;
        let v_p1 = &self.v_p1;
        let vi_p2 = &self.vi_p2;
        let rels_p3 = &self.rels_p3;
        match crate::check::shrink::walk::call_of_o(e_p0) {
            Some((c_p4, args_p5)) => if crate::check::shrink::walk::is_non_nat_min_f(rels_p3, e_p0, &c_p4) {
                prism_rtl::Turn::Finished(false)
            } else {
                match crate::check::shrink::walk::no_larger_arg_o(rels_p3, &c_p4, &args_p5) {
                    Some(a_p6) => prism_rtl::Turn::More(Rc::new(SetsStrict { e_p0: a_p6.clone(), v_p1: v_p1.clone(), vi_p2: vi_p2.clone(), rels_p3: rels_p3.clone() })),
                    None => prism_rtl::Turn::Finished(false),
                }
            },
            None => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start CallStrict, x`: what the function value is when passed to `@Run`.
pub fn start_call_strict_f(e_p0: crate::syntax::Expr, v_p1: Text, vi_p2: Nat, rels_p3: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(CallStrict { e_p0, v_p1, vi_p2, rels_p3 })
}
