//! The module `Check.Shrink.Summaries`, from `target/bootstrap/src/prismc/check/shrink/summaries.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
/// ```
pub fn parts_summaries_f(sk_p0: &crate::check::shrink::Shrink, fns_p1: &crate::prelude::Array<crate::check::env::Def>) -> crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat> {
    crate::prelude::run_to_end(crate::prelude::fold_job(fns_p1.clone(), crate::prelude::Map::new(), {
        let sk_p0x = sk_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>, crate::check::env::Def)| {
            let sk_p0xy = sk_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p2 = p0;
                let d_p3 = p1;
                match &d_p3.body_p {
                    crate::check::env::DefBody::DbFn(clauses_p4) => {
                        let n_p5 = match crate::prelude::index(clauses_p4, &crate::prelude::Nat::from(0u32)) {
                            ::std::option::Option::Some(c0_p7) => crate::prelude::len(&c0_p7.params_p),
                            ::std::option::Option::None => crate::prelude::Nat::from(0u32),
                        };
                        let clauses_p4x = clauses_p4.clone();
                        crate::prelude::call_value(crate::prelude::filter_job(crate::check::errors::range0_f(&n_p5), {
                            let clauses_p4xx = clauses_p4x.clone();
                            let sk_p0xyx = sk_p0xy.clone();
                            let d_p3x = d_p3.clone();
                            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                                let clauses_p4xxy = clauses_p4xx.clone();
                                let sk_p0xyxy = sk_p0xyx.clone();
                                let d_p3xy = d_p3x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let i_p8 = p0;
                                    crate::prelude::fold_job(clauses_p4xxy.clone(), true, {
                                        let sk_p0xyxyx = sk_p0xyxy.clone();
                                        let d_p3xyx = d_p3xy.clone();
                                        let i_p8x = i_p8.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                                            let sk_p0xyxyxy = sk_p0xyxyx.clone();
                                            let d_p3xyxy = d_p3xyx.clone();
                                            let i_p8xy = i_p8x.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let okc_p9 = p0;
                                                let c_pa = p1;
                                                if okc_p9 {
                                                    crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0xyxyxy.clone(), d_p3xyxy.clone(), c_pa.clone()), move |clause_base_f_2160: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::More(::std::rc::Rc::new(ClauseWithin { base_p0: clause_base_f_2160, c_p1: c_pa.clone(), i_p2: i_p8xy.clone() })))
                                                } else {
                                                    ::prism_rtl::Turn::Finished(false)
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                    }).cycle()
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                        }), move |filter_2084: crate::prelude::Array<crate::prelude::Nat>| {
                            let ok_p6 = filter_2084;
                            match crate::prelude::index(&ok_p6, &crate::prelude::Nat::from(0u32)) {
                                ::std::option::Option::Some(i_pb) => ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_p2, &d_p3.qk_p, &i_pb)),
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(m_p2.clone()),
                            }
                        })
                    },
                    _ => ::prism_rtl::Turn::Finished(m_p2.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>>>>
    }))
}

/// The step machine of `PartsSummaries`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
/// ```
pub struct PartsSummaries {
    pub sk_p0: crate::check::shrink::Shrink,
    pub fns_p1: crate::prelude::Array<crate::check::env::Def>,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>> for PartsSummaries {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>> {
        let sk_p0 = &self.sk_p0;
        let fns_p1 = &self.fns_p1;
        crate::prelude::fold_job(fns_p1.clone(), crate::prelude::Map::new(), {
            let sk_p0x = sk_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>, crate::check::env::Def)| {
                let sk_p0xy = sk_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m_p2 = p0;
                    let d_p3 = p1;
                    match &d_p3.body_p {
                        crate::check::env::DefBody::DbFn(clauses_p4) => {
                            let n_p5 = match crate::prelude::index(clauses_p4, &crate::prelude::Nat::from(0u32)) {
                                ::std::option::Option::Some(c0_p7) => crate::prelude::len(&c0_p7.params_p),
                                ::std::option::Option::None => crate::prelude::Nat::from(0u32),
                            };
                            let clauses_p4x = clauses_p4.clone();
                            crate::prelude::call_value(crate::prelude::filter_job(crate::check::errors::range0_f(&n_p5), {
                                let clauses_p4xx = clauses_p4x.clone();
                                let sk_p0xyx = sk_p0xy.clone();
                                let d_p3x = d_p3.clone();
                                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                                    let clauses_p4xxy = clauses_p4xx.clone();
                                    let sk_p0xyxy = sk_p0xyx.clone();
                                    let d_p3xy = d_p3x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let i_p8 = p0;
                                        crate::prelude::fold_job(clauses_p4xxy.clone(), true, {
                                            let sk_p0xyxyx = sk_p0xyxy.clone();
                                            let d_p3xyx = d_p3xy.clone();
                                            let i_p8x = i_p8.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                                                let sk_p0xyxyxy = sk_p0xyxyx.clone();
                                                let d_p3xyxy = d_p3xyx.clone();
                                                let i_p8xy = i_p8x.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let okc_p9 = p0;
                                                    let c_pa = p1;
                                                    if okc_p9 {
                                                        crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0xyxyxy.clone(), d_p3xyxy.clone(), c_pa.clone()), move |clause_base_f_2160: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::More(::std::rc::Rc::new(ClauseWithin { base_p0: clause_base_f_2160, c_p1: c_pa.clone(), i_p2: i_p8xy.clone() })))
                                                    } else {
                                                        ::prism_rtl::Turn::Finished(false)
                                                    }
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                        }).cycle()
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            }), move |filter_2084: crate::prelude::Array<crate::prelude::Nat>| {
                                let ok_p6 = filter_2084;
                                match crate::prelude::index(&ok_p6, &crate::prelude::Nat::from(0u32)) {
                                    ::std::option::Option::Some(i_pb) => ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_p2, &d_p3.qk_p, &i_pb)),
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(m_p2.clone()),
                                }
                            })
                        },
                        _ => ::prism_rtl::Turn::Finished(m_p2.clone()),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>>>>
        }).cycle()
    }
}

/// `Start PartsSummaries, x`: what the function value is when passed to `@Run`.
pub fn start_parts_summaries_f(sk_p0: crate::check::shrink::Shrink, fns_p1: crate::prelude::Array<crate::check::env::Def>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>>> {
    ::std::rc::Rc::new(PartsSummaries { sk_p0, fns_p1 })
}

/// ```prism
/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
/// ```
pub fn clause_within_f(base_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, c_p1: &crate::syntax::decls::FnClause, i_p2: &crate::prelude::Nat) -> bool {
    match &c_p1.body_p {
        crate::syntax::decls::FnBody::BodyExpr(e_p3) => within_f(base_p0, i_p2, e_p3),
        crate::syntax::decls::FnBody::BodyBlock(b_p4) => within_block_f(base_p0, i_p2, b_p4),
    }
}

/// The step machine of `ClauseWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
/// ```
pub struct ClauseWithin {
    pub base_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub c_p1: crate::syntax::decls::FnClause,
    pub i_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<bool> for ClauseWithin {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let base_p0 = &self.base_p0;
        let c_p1 = &self.c_p1;
        let i_p2 = &self.i_p2;
        match &c_p1.body_p {
            crate::syntax::decls::FnBody::BodyExpr(e_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Within { m_p0: base_p0.clone(), i_p1: i_p2.clone(), e_p2: e_p3.clone() })),
            crate::syntax::decls::FnBody::BodyBlock(b_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(WithinBlock { m_p0: base_p0.clone(), i_p1: i_p2.clone(), b_p2: b_p4.clone() })),
        }
    }
}

/// `Start ClauseWithin, x`: what the function value is when passed to `@Run`.
pub fn start_clause_within_f(base_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, c_p1: crate::syntax::decls::FnClause, i_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(ClauseWithin { base_p0, c_p1, i_p2 })
}

/// ```prism
/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub fn within_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: &crate::prelude::Nat, e_p2: &crate::syntax::Expr) -> bool {
    match crate::check::shrink::walk::rel_of_o(m_p0, e_p2) {
        ::std::option::Option::Some(r_p3) => &r_p3.param_p == i_p1,
        ::std::option::Option::None => match &*e_p2.kind_p {
            crate::syntax::ExprKind::EArray(es_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(es_p4.clone(), true, {
                let m_p0x = m_p0.clone();
                let i_p1x = i_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                    let m_p0xy = m_p0x.clone();
                    let i_p1xy = i_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p5 = p0;
                        let x_p6 = p1;
                        if ok_p5 {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(Part { m_p0: m_p0xy.clone(), i_p1: i_p1xy.clone(), e_p2: x_p6.clone() }))
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            })),
            crate::syntax::ExprKind::EMap(kvs_p7) => crate::prelude::run_to_end(crate::prelude::fold_job(kvs_p7.clone(), true, {
                let m_p0x = m_p0.clone();
                let i_p1x = i_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::syntax::Expr, crate::syntax::Expr))| {
                    let m_p0xy = m_p0x.clone();
                    let i_p1xy = i_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p8 = p0;
                        let (k_p9, v_pa) = p1;
                        if ok_p8 && part_f(&m_p0xy, &i_p1xy, &k_p9) {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(Part { m_p0: m_p0xy.clone(), i_p1: i_p1xy.clone(), e_p2: v_pa.clone() }))
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::syntax::Expr, crate::syntax::Expr))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            })),
            crate::syntax::ExprKind::EGroup(x_pb) => within_f(m_p0, i_p1, &**x_pb),
            crate::syntax::ExprKind::EMatch(s_pc, arms_pd) => crate::prelude::run_to_end(crate::prelude::fold_job(arms_pd.clone(), true, {
                let s_pcx = (**s_pc).clone();
                let m_p0x = m_p0.clone();
                let i_p1x = i_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                    let s_pcxy = s_pcx.clone();
                    let m_p0xy = m_p0x.clone();
                    let i_p1xy = i_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_pe = p0;
                        let a_pf = p1;
                        if ok_pe {
                            crate::prelude::call_then(crate::check::shrink::relations::start_arm_pat_rels_f(s_pcxy.clone(), a_pf.clone(), m_p0xy.clone()), move |arm_pat_rels_f_2857: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::More(::std::rc::Rc::new(WithinBlock { m_p0: arm_pat_rels_f_2857, i_p1: i_p1xy.clone(), b_p2: a_pf.body_p.clone() })))
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            })),
            crate::syntax::ExprKind::EIf(c_pg, t_ph, ::std::option::Option::Some(el_pi)) => within_block_f(&crate::check::shrink::relations::cond_rels_f(&**c_pg, m_p0), i_p1, t_ph) && within_block_f(m_p0, i_p1, el_pi),
            crate::syntax::ExprKind::EUpdate(start_pj, b_pk) => within_f(m_p0, i_p1, &**start_pj) && update_within_f(&crate::prelude::insert(m_p0, &crate::prelude::Text::lit("&_"), &crate::check::shrink::Rel { param_p: i_p1.clone(), strict_p: false }), i_p1, b_pk),
            _ => match crate::check::shrink::walk::call_of_o(e_p2) {
                ::std::option::Option::Some((c_pl, args_pm)) => match crate::check::shrink::walk::traversal_of_o(m_p0, &c_pl, &args_pm) {
                    ::std::option::Option::Some((coll_pn, step_po, at_pp)) => within_f(m_p0, i_p1, &coll_pn) && step_within_f(m_p0, i_p1, &crate::check::shrink::locals::expr_name_f(&c_pl), &coll_pn, &step_po, &at_pp, &crate::prelude::or(&crate::prelude::index(&args_pm, &crate::prelude::Nat::from(1u32)), &dummy_arg_p()).value_p),
                    ::std::option::Option::None => false,
                },
                ::std::option::Option::None => false,
            },
        },
    }
}

/// The step machine of `Within`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub struct Within {
    pub m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub i_p1: crate::prelude::Nat,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for Within {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let e_p2 = &self.e_p2;
        let e_p2x = e_p2.clone();
        let i_p1x = i_p1.clone();
        let m_p0x = m_p0.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(m_p0x.clone(), e_p2x.clone()), move |rel_of_o_2544: ::std::option::Option<crate::check::shrink::Rel>| match rel_of_o_2544 {
            ::std::option::Option::Some(r_p3) => ::prism_rtl::Turn::Finished(&r_p3.param_p == &i_p1x),
            ::std::option::Option::None => match &*e_p2x.kind_p {
                crate::syntax::ExprKind::EArray(es_p4) => crate::prelude::fold_job(es_p4.clone(), true, {
                    let m_p0xx = m_p0x.clone();
                    let i_p1xx = i_p1x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                        let m_p0xxy = m_p0xx.clone();
                        let i_p1xxy = i_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let ok_p5 = p0;
                            let x_p6 = p1;
                            if ok_p5 {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(Part { m_p0: m_p0xxy.clone(), i_p1: i_p1xxy.clone(), e_p2: x_p6.clone() }))
                            } else {
                                ::prism_rtl::Turn::Finished(false)
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }).cycle(),
                crate::syntax::ExprKind::EMap(kvs_p7) => crate::prelude::fold_job(kvs_p7.clone(), true, {
                    let m_p0xx = m_p0x.clone();
                    let i_p1xx = i_p1x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::syntax::Expr, crate::syntax::Expr))| {
                        let m_p0xxy = m_p0xx.clone();
                        let i_p1xxy = i_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let ok_p8 = p0;
                            let (k_p9, v_pa) = p1;
                            if ok_p8 && part_f(&m_p0xxy, &i_p1xxy, &k_p9) {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(Part { m_p0: m_p0xxy.clone(), i_p1: i_p1xxy.clone(), e_p2: v_pa.clone() }))
                            } else {
                                ::prism_rtl::Turn::Finished(false)
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::syntax::Expr, crate::syntax::Expr))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }).cycle(),
                crate::syntax::ExprKind::EGroup(x_pb) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Within { m_p0: m_p0x.clone(), i_p1: i_p1x.clone(), e_p2: (**x_pb).clone() })),
                crate::syntax::ExprKind::EMatch(s_pc, arms_pd) => crate::prelude::fold_job(arms_pd.clone(), true, {
                    let s_pcx = (**s_pc).clone();
                    let m_p0xx = m_p0x.clone();
                    let i_p1xx = i_p1x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                        let s_pcxy = s_pcx.clone();
                        let m_p0xxy = m_p0xx.clone();
                        let i_p1xxy = i_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let ok_pe = p0;
                            let a_pf = p1;
                            if ok_pe {
                                crate::prelude::call_then(crate::check::shrink::relations::start_arm_pat_rels_f(s_pcxy.clone(), a_pf.clone(), m_p0xxy.clone()), move |arm_pat_rels_f_2857: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::More(::std::rc::Rc::new(WithinBlock { m_p0: arm_pat_rels_f_2857, i_p1: i_p1xxy.clone(), b_p2: a_pf.body_p.clone() })))
                            } else {
                                ::prism_rtl::Turn::Finished(false)
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }).cycle(),
                crate::syntax::ExprKind::EIf(c_pg, t_ph, ::std::option::Option::Some(el_pi)) => {
                    let c_pgx = (**c_pg).clone();
                    let el_pix = el_pi.clone();
                    let t_phx = t_ph.clone();
                    crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_pgx.clone(), m_p0x.clone()), move |cond_rels_f_2928: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| crate::prelude::call_then(start_within_block_f(cond_rels_f_2928, i_p1x.clone(), t_phx.clone()), move |within_block_f_2915: bool| if within_block_f_2915 {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(WithinBlock { m_p0: m_p0x.clone(), i_p1: i_p1x.clone(), b_p2: el_pix.clone() }))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    }))
                },
                crate::syntax::ExprKind::EUpdate(start_pj, b_pk) => {
                    let b_pkx = b_pk.clone();
                    let start_pjx = (**start_pj).clone();
                    crate::prelude::call_then(start_within_f(m_p0x.clone(), i_p1x.clone(), start_pjx.clone()), move |within_f_3002: bool| if within_f_3002 {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdateWithin { m_p0: crate::prelude::insert(&m_p0x, &crate::prelude::Text::lit("&_"), &crate::check::shrink::Rel { param_p: i_p1x.clone(), strict_p: false }), i_p1: i_p1x.clone(), b_p2: b_pkx.clone() }))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    })
                },
                _ => match crate::check::shrink::walk::call_of_o(&e_p2x) {
                    ::std::option::Option::Some((c_pl, args_pm)) => match crate::check::shrink::walk::traversal_of_o(&m_p0x, &c_pl, &args_pm) {
                        ::std::option::Option::Some((coll_pn, step_po, at_pp)) => crate::prelude::call_then(start_within_f(m_p0x.clone(), i_p1x.clone(), coll_pn.clone()), move |within_f_3223: bool| if within_f_3223 {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(StepWithin { m_p0: m_p0x.clone(), i_p1: i_p1x.clone(), f_p2: crate::check::shrink::locals::expr_name_f(&c_pl), coll_p3: coll_pn.clone(), step_p4: step_po.clone(), at_p5: at_pp.clone(), z_p6: crate::prelude::or(&crate::prelude::index(&args_pm, &crate::prelude::Nat::from(1u32)), &dummy_arg_p()).value_p.clone() }))
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        }),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                    },
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                },
            },
        })
    }
}

/// `Start Within, x`: what the function value is when passed to `@Run`.
pub fn start_within_f(m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: crate::prelude::Nat, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(Within { m_p0, i_p1, e_p2 })
}

/// ```prism
/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub fn update_within_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: &crate::prelude::Nat, b_p2: &crate::syntax::Block) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmts_spots_f(&b_p2.stmts_p, m_p0), true, {
        let i_p1x = i_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
            let i_p1xy = i_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p3 = p0;
                let sp_p4 = p1;
                if ok_p3 {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SpotKeepsWithin { spot0: sp_p4.clone(), n1: i_p1xy.clone() }))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `UpdateWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub struct UpdateWithin {
    pub m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub i_p1: crate::prelude::Nat,
    pub b_p2: crate::syntax::Block,
}

impl ::prism_rtl::Job<bool> for UpdateWithin {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let b_p2 = &self.b_p2;
        let b_p2x = b_p2.clone();
        let i_p1x = i_p1.clone();
        let m_p0x = m_p0.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_stmts_spots_f(b_p2x.stmts_p.clone(), m_p0x.clone()), move |stmts_spots_f_3685: crate::prelude::Array<crate::check::shrink::walk::Spot>| crate::prelude::fold_job(stmts_spots_f_3685, true, {
            let i_p1xx = i_p1x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                let i_p1xxy = i_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_p3 = p0;
                    let sp_p4 = p1;
                    if ok_p3 {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(SpotKeepsWithin { spot0: sp_p4.clone(), n1: i_p1xxy.clone() }))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start UpdateWithin, x`: what the function value is when passed to `@Run`.
pub fn start_update_within_f(m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: crate::prelude::Nat, b_p2: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(UpdateWithin { m_p0, i_p1, b_p2 })
}

/// ```prism
/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
/// ```
pub fn spot_keeps_within_f(spot0: &crate::check::shrink::walk::Spot, n1: &crate::prelude::Nat) -> bool {
    match (spot0, n1) {
        (crate::check::shrink::walk::Spot::SpotStmt(s_p0, m_p1), i_p2) => match &s_p0.kind_p {
            crate::syntax::StmtKind::SSet(t_p3, value_p4) => if &crate::prelude::take(&crate::check::passes::borrows::ref_path_f(t_p3), &crate::prelude::Nat::from(1u32)) != &crate::prelude::Array::from(vec![crate::prelude::Text::lit("&_")]) {
                true
            } else {
                (&crate::check::passes::borrows::ref_path_f(t_p3) == &crate::prelude::Array::from(vec![crate::prelude::Text::lit("&_")])) && within_f(m_p1, i_p2, value_p4)
            },
            crate::syntax::StmtKind::SAccum(t_p5, _, _) => &crate::prelude::take(&crate::check::passes::borrows::ref_path_f(t_p5), &crate::prelude::Nat::from(1u32)) != &crate::prelude::Array::from(vec![crate::prelude::Text::lit("&_")]),
            _ => true,
        },
        (crate::check::shrink::walk::Spot::SpotExpr(_, _), _) => true,
    }
}

/// The step machine of `SpotKeepsWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
/// ```
pub struct SpotKeepsWithin {
    pub spot0: crate::check::shrink::walk::Spot,
    pub n1: crate::prelude::Nat,
}

impl ::prism_rtl::Job<bool> for SpotKeepsWithin {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let spot0 = &self.spot0;
        let n1 = &self.n1;
        match (spot0, n1) {
            (crate::check::shrink::walk::Spot::SpotStmt(s_p0, m_p1), i_p2) => match &s_p0.kind_p {
                crate::syntax::StmtKind::SSet(t_p3, value_p4) => {
                    let i_p2x = i_p2.clone();
                    let m_p1x = m_p1.clone();
                    let t_p3x = t_p3.clone();
                    let value_p4x = value_p4.clone();
                    crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p3x.clone()), move |ref_path_f_3894: crate::prelude::Array<crate::prelude::Text>| if &crate::prelude::take(&ref_path_f_3894, &crate::prelude::Nat::from(1u32)) != &crate::prelude::Array::from(vec![crate::prelude::Text::lit("&_")]) {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p3x.clone()), move |ref_path_f_3942: crate::prelude::Array<crate::prelude::Text>| if &ref_path_f_3942 == &crate::prelude::Array::from(vec![crate::prelude::Text::lit("&_")]) {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(Within { m_p0: m_p1x.clone(), i_p1: i_p2x.clone(), e_p2: value_p4x.clone() }))
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        })
                    })
                },
                crate::syntax::StmtKind::SAccum(t_p5, _, _) => {
                    let t_p5x = t_p5.clone();
                    crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p5x.clone()), move |ref_path_f_4025: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(&crate::prelude::take(&ref_path_f_4025, &crate::prelude::Nat::from(1u32)) != &crate::prelude::Array::from(vec![crate::prelude::Text::lit("&_")])))
                },
                _ => ::prism_rtl::Turn::Finished(true),
            },
            (crate::check::shrink::walk::Spot::SpotExpr(_, _), _) => ::prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start SpotKeepsWithin, x`: what the function value is when passed to `@Run`.
pub fn start_spot_keeps_within_f(spot0: crate::check::shrink::walk::Spot, n1: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(SpotKeepsWithin { spot0, n1 })
}

/// ```prism
/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub fn within_block_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: &crate::prelude::Nat, b_p2: &crate::syntax::Block) -> bool {
    within_f(&crate::check::shrink::relations::block_rels_f(&b_p2.stmts_p, m_p0), i_p1, &last_or_f(b_p2))
}

/// The step machine of `WithinBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub struct WithinBlock {
    pub m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub i_p1: crate::prelude::Nat,
    pub b_p2: crate::syntax::Block,
}

impl ::prism_rtl::Job<bool> for WithinBlock {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let b_p2 = &self.b_p2;
        let b_p2x = b_p2.clone();
        let i_p1x = i_p1.clone();
        let m_p0x = m_p0.clone();
        crate::prelude::call_then(crate::check::shrink::relations::start_block_rels_f(b_p2x.stmts_p.clone(), m_p0x.clone()), move |block_rels_f_4289: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::More(::std::rc::Rc::new(Within { m_p0: block_rels_f_4289, i_p1: i_p1x.clone(), e_p2: last_or_f(&b_p2x) })))
    }
}

/// `Start WithinBlock, x`: what the function value is when passed to `@Run`.
pub fn start_within_block_f(m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: crate::prelude::Nat, b_p2: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(WithinBlock { m_p0, i_p1, b_p2 })
}

/// ```prism
/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
/// ```
pub fn step_within_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: &crate::prelude::Nat, f_p2: &crate::prelude::Text, coll_p3: &crate::syntax::Expr, step_p4: &crate::syntax::Expr, at_p5: &crate::prelude::Nat, z_p6: &crate::syntax::Expr) -> bool {
    if crate::check::shrink::relations::pre_is_f(m_p0, f_p2, &crate::prelude::Text::lit("Filter")) {
        true
    } else {
        match &*step_p4.kind_p {
            crate::syntax::ExprKind::ELambda(::std::option::Option::Some(ps_p7), body_p8) => {
                let sm_p9 = crate::check::shrink::relations::step_rels_f(m_p0, coll_p3, ps_p7, at_p5);
                let (bm_pc, x_pd) = match &**body_p8 {
                    crate::syntax::LambdaBody::LbExpr(y_pa) => (sm_p9.clone(), (**y_pa).clone()),
                    crate::syntax::LambdaBody::LbBlock(b_pb) => (crate::check::shrink::relations::block_rels_f(&b_pb.stmts_p, &sm_p9), last_or_f(b_pb)),
                };
                if crate::check::shrink::relations::pre_is_f(m_p0, f_p2, &crate::prelude::Text::lit("Each")) {
                    part_f(&bm_pc, i_p1, &x_pd)
                } else {
                    match crate::prelude::index(ps_p7, &crate::prelude::Nat::from(0u32)) {
                        ::std::option::Option::Some(acc_pe) => match &*acc_pe.kind_p {
                            crate::syntax::PatternKind::PName(n_pf) => within_f(m_p0, i_p1, z_p6) && builds_on_f(&bm_pc, i_p1, &crate::check::env::sname_key_f(n_pf), &x_pd),
                            _ => false,
                        },
                        ::std::option::Option::None => false,
                    }
                }
            },
            _ => false,
        }
    }
}

/// The step machine of `StepWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
/// ```
pub struct StepWithin {
    pub m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub i_p1: crate::prelude::Nat,
    pub f_p2: crate::prelude::Text,
    pub coll_p3: crate::syntax::Expr,
    pub step_p4: crate::syntax::Expr,
    pub at_p5: crate::prelude::Nat,
    pub z_p6: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for StepWithin {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let f_p2 = &self.f_p2;
        let coll_p3 = &self.coll_p3;
        let step_p4 = &self.step_p4;
        let at_p5 = &self.at_p5;
        let z_p6 = &self.z_p6;
        if crate::check::shrink::relations::pre_is_f(m_p0, f_p2, &crate::prelude::Text::lit("Filter")) {
            ::prism_rtl::Turn::Finished(true)
        } else {
            match &*step_p4.kind_p {
                crate::syntax::ExprKind::ELambda(::std::option::Option::Some(ps_p7), body_p8) => {
                    let at_p5x = at_p5.clone();
                    let body_p8x = (**body_p8).clone();
                    let coll_p3x = coll_p3.clone();
                    let f_p2x = f_p2.clone();
                    let i_p1x = i_p1.clone();
                    let m_p0x = m_p0.clone();
                    let ps_p7x = ps_p7.clone();
                    let z_p6x = z_p6.clone();
                    crate::prelude::call_then(crate::check::shrink::relations::start_step_rels_f(m_p0x.clone(), coll_p3x.clone(), ps_p7x.clone(), at_p5x.clone()), move |step_rels_f_4719: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                        let sm_p9 = step_rels_f_4719;
                        let f_p2xz = f_p2x.clone();
                        let i_p1xz = i_p1x.clone();
                        let m_p0xz = m_p0x.clone();
                        let ps_p7xz = ps_p7x.clone();
                        let z_p6xz = z_p6x.clone();
                        let k_let4756 = move |v4756: (crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, crate::syntax::Expr)| {
                            let (bm_pc, x_pd) = v4756;
                            if crate::check::shrink::relations::pre_is_f(&m_p0xz, &f_p2xz, &crate::prelude::Text::lit("Each")) {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(Part { m_p0: bm_pc.clone(), i_p1: i_p1xz.clone(), e_p2: x_pd.clone() }))
                            } else {
                                match crate::prelude::index(&ps_p7xz, &crate::prelude::Nat::from(0u32)) {
                                    ::std::option::Option::Some(acc_pe) => match &*acc_pe.kind_p {
                                        crate::syntax::PatternKind::PName(n_pf) => {
                                            let n_pfx = n_pf.clone();
                                            crate::prelude::call_then(start_within_f(m_p0xz.clone(), i_p1xz.clone(), z_p6xz.clone()), move |within_f_5036: bool| if within_f_5036 {
                                                ::prism_rtl::Turn::More(::std::rc::Rc::new(BuildsOn { m_p0: bm_pc.clone(), i_p1: i_p1xz.clone(), acc_p2: crate::check::env::sname_key_f(&n_pfx), e_p3: x_pd.clone() }))
                                            } else {
                                                ::prism_rtl::Turn::Finished(false)
                                            })
                                        },
                                        _ => ::prism_rtl::Turn::Finished(false),
                                    },
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                                }
                            }
                        };
                        match body_p8x.clone() {
                            crate::syntax::LambdaBody::LbExpr(y_pa) => k_let4756((sm_p9.clone(), (*y_pa).clone())),
                            crate::syntax::LambdaBody::LbBlock(b_pb) => crate::prelude::call_then(crate::check::shrink::relations::start_block_rels_f(b_pb.stmts_p.clone(), sm_p9.clone()), move |block_rels_f_4850: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| k_let4756((block_rels_f_4850, last_or_f(&b_pb)))),
                        }
                    })
                },
                _ => ::prism_rtl::Turn::Finished(false),
            }
        }
    }
}

/// `Start StepWithin, x`: what the function value is when passed to `@Run`.
pub fn start_step_within_f(m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: crate::prelude::Nat, f_p2: crate::prelude::Text, coll_p3: crate::syntax::Expr, step_p4: crate::syntax::Expr, at_p5: crate::prelude::Nat, z_p6: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(StepWithin { m_p0, i_p1, f_p2, coll_p3, step_p4, at_p5, z_p6 })
}

/// ```prism
/// LastOr: fn Block -> Expr
/// ```
pub fn last_or_f(b_p0: &crate::syntax::Block) -> crate::syntax::Expr {
    crate::prelude::or(&crate::check::shrink::walk::last_expr_o(b_p0), &dummy_arg_p().value_p)
}

/// ```prism
/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
/// ```
pub fn builds_on_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: &crate::prelude::Nat, acc_p2: &crate::prelude::Text, e_p3: &crate::syntax::Expr) -> bool {
    match &*e_p3.kind_p {
        crate::syntax::ExprKind::EName(n_p4) => &crate::check::env::sname_key_f(n_p4) == acc_p2,
        crate::syntax::ExprKind::EGroup(x_p5) => builds_on_f(m_p0, i_p1, acc_p2, &**x_p5),
        crate::syntax::ExprKind::EMatch(s_p6, arms_p7) => crate::prelude::run_to_end(crate::prelude::fold_job(arms_p7.clone(), true, {
            let acc_p2x = acc_p2.clone();
            let s_p6x = (**s_p6).clone();
            let m_p0x = m_p0.clone();
            let i_p1x = i_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                let acc_p2xy = acc_p2x.clone();
                let s_p6xy = s_p6x.clone();
                let m_p0xy = m_p0x.clone();
                let i_p1xy = i_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_p8 = p0;
                    let a_p9 = p1;
                    if ok_p8 && !crate::check::types::has_text_f(&opt_names_f(&a_p9.pattern_o), &acc_p2xy) {
                        crate::prelude::call_then(crate::check::shrink::relations::start_arm_pat_rels_f(s_p6xy.clone(), a_p9.clone(), m_p0xy.clone()), move |arm_pat_rels_f_5677: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::More(::std::rc::Rc::new(BuildsOnBlock { m_p0: arm_pat_rels_f_5677, i_p1: i_p1xy.clone(), acc_p2: acc_p2xy.clone(), b_p3: a_p9.body_p.clone() })))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        crate::syntax::ExprKind::EIf(c_pa, t_pb, ::std::option::Option::Some(el_pc)) => (!crate::check::types::has_text_f(&cond_names_f(&**c_pa), acc_p2) && builds_on_block_f(&crate::check::shrink::relations::cond_rels_f(&**c_pa, m_p0), i_p1, acc_p2, t_pb)) && builds_on_block_f(m_p0, i_p1, acc_p2, el_pc),
        _ => match crate::check::shrink::walk::call_of_o(e_p3) {
            ::std::option::Option::Some((c_pd, args_pe)) => builds_on_call_f(m_p0, i_p1, acc_p2, &c_pd, &args_pe),
            ::std::option::Option::None => false,
        },
    }
}

/// The step machine of `BuildsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
/// ```
pub struct BuildsOn {
    pub m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub i_p1: crate::prelude::Nat,
    pub acc_p2: crate::prelude::Text,
    pub e_p3: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for BuildsOn {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let acc_p2 = &self.acc_p2;
        let e_p3 = &self.e_p3;
        match &*e_p3.kind_p {
            crate::syntax::ExprKind::EName(n_p4) => ::prism_rtl::Turn::Finished(&crate::check::env::sname_key_f(n_p4) == acc_p2),
            crate::syntax::ExprKind::EGroup(x_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BuildsOn { m_p0: m_p0.clone(), i_p1: i_p1.clone(), acc_p2: acc_p2.clone(), e_p3: (**x_p5).clone() })),
            crate::syntax::ExprKind::EMatch(s_p6, arms_p7) => crate::prelude::fold_job(arms_p7.clone(), true, {
                let acc_p2x = acc_p2.clone();
                let s_p6x = (**s_p6).clone();
                let m_p0x = m_p0.clone();
                let i_p1x = i_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                    let acc_p2xy = acc_p2x.clone();
                    let s_p6xy = s_p6x.clone();
                    let m_p0xy = m_p0x.clone();
                    let i_p1xy = i_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p8 = p0;
                        let a_p9 = p1;
                        if ok_p8 && !crate::check::types::has_text_f(&opt_names_f(&a_p9.pattern_o), &acc_p2xy) {
                            crate::prelude::call_then(crate::check::shrink::relations::start_arm_pat_rels_f(s_p6xy.clone(), a_p9.clone(), m_p0xy.clone()), move |arm_pat_rels_f_5677: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::More(::std::rc::Rc::new(BuildsOnBlock { m_p0: arm_pat_rels_f_5677, i_p1: i_p1xy.clone(), acc_p2: acc_p2xy.clone(), b_p3: a_p9.body_p.clone() })))
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle(),
            crate::syntax::ExprKind::EIf(c_pa, t_pb, ::std::option::Option::Some(el_pc)) => {
                let acc_p2x = acc_p2.clone();
                let c_pax = (**c_pa).clone();
                let el_pcx = el_pc.clone();
                let i_p1x = i_p1.clone();
                let m_p0x = m_p0.clone();
                let t_pbx = t_pb.clone();
                crate::prelude::call_then(start_cond_names_f(c_pax.clone()), move |cond_names_f_5750: crate::prelude::Array<crate::prelude::Text>| if !crate::check::types::has_text_f(&cond_names_f_5750, &acc_p2x) && builds_on_block_f(&crate::check::shrink::relations::cond_rels_f(&c_pax, &m_p0x), &i_p1x, &acc_p2x, &t_pbx) {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(BuildsOnBlock { m_p0: m_p0x.clone(), i_p1: i_p1x.clone(), acc_p2: acc_p2x.clone(), b_p3: el_pcx.clone() }))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                })
            },
            _ => match crate::check::shrink::walk::call_of_o(e_p3) {
                ::std::option::Option::Some((c_pd, args_pe)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BuildsOnCall { m_p0: m_p0.clone(), i_p1: i_p1.clone(), acc_p2: acc_p2.clone(), c_p3: c_pd.clone(), args_p4: args_pe.clone() })),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
            },
        }
    }
}

/// `Start BuildsOn, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on_f(m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: crate::prelude::Nat, acc_p2: crate::prelude::Text, e_p3: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(BuildsOn { m_p0, i_p1, acc_p2, e_p3 })
}

/// ```prism
/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
/// ```
pub fn builds_on_call_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: &crate::prelude::Nat, acc_p2: &crate::prelude::Text, c_p3: &crate::syntax::Expr, args_p4: &crate::prelude::Array<crate::syntax::Arg>) -> bool {
    let f_p5 = crate::check::shrink::locals::expr_name_f(c_p3);
    let on_acc_p6 = builds_on_f(m_p0, i_p1, acc_p2, &crate::prelude::or(&crate::prelude::index(args_p4, &crate::prelude::Nat::from(0u32)), &dummy_arg_p()).value_p);
    let rest_p7 = crate::prelude::each(&crate::prelude::drop(args_p4, &crate::prelude::Nat::from(1u32)), &(|a_p9: &crate::syntax::Arg| a_p9.value_p.clone()));
    let parts_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(rest_p7.clone(), true, {
        let m_p0x = m_p0.clone();
        let i_p1x = i_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
            let m_p0xy = m_p0x.clone();
            let i_p1xy = i_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_pa = p0;
                let x_pb = p1;
                if ok_pa {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Part { m_p0: m_p0xy.clone(), i_p1: i_p1xy.clone(), e_p2: x_pb.clone() }))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    if !on_acc_p6 {
        false
    } else {
        if crate::check::shrink::relations::pre_is_f(m_p0, &f_p5, &crate::prelude::Text::lit("Push")) && (&crate::prelude::len(&rest_p7) == &crate::prelude::Nat::from(1u32)) {
            parts_p8
        } else {
            if crate::check::shrink::relations::pre_is_f(m_p0, &f_p5, &crate::prelude::Text::lit("Insert")) && (&crate::prelude::len(&rest_p7) == &crate::prelude::Nat::from(2u32)) {
                parts_p8
            } else {
                if crate::check::shrink::relations::pre_is_f(m_p0, &f_p5, &crate::prelude::Text::lit("Append")) && (&crate::prelude::len(&rest_p7) == &crate::prelude::Nat::from(1u32)) {
                    within_f(m_p0, i_p1, &crate::prelude::or(&crate::prelude::index(&rest_p7, &crate::prelude::Nat::from(0u32)), &dummy_arg_p().value_p))
                } else {
                    false
                }
            }
        }
    }
}

/// The step machine of `BuildsOnCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
/// ```
pub struct BuildsOnCall {
    pub m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub i_p1: crate::prelude::Nat,
    pub acc_p2: crate::prelude::Text,
    pub c_p3: crate::syntax::Expr,
    pub args_p4: crate::prelude::Array<crate::syntax::Arg>,
}

impl ::prism_rtl::Job<bool> for BuildsOnCall {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let acc_p2 = &self.acc_p2;
        let c_p3 = &self.c_p3;
        let args_p4 = &self.args_p4;
        let f_p5 = crate::check::shrink::locals::expr_name_f(c_p3);
        let acc_p2x = acc_p2.clone();
        let args_p4x = args_p4.clone();
        let i_p1x = i_p1.clone();
        let m_p0x = m_p0.clone();
        crate::prelude::call_then(start_builds_on_f(m_p0x.clone(), i_p1x.clone(), acc_p2x.clone(), crate::prelude::or(&crate::prelude::index(&args_p4x, &crate::prelude::Nat::from(0u32)), &dummy_arg_p()).value_p.clone()), move |builds_on_f_6180: bool| {
            let on_acc_p6 = builds_on_f_6180;
            let rest_p7 = crate::prelude::each(&crate::prelude::drop(&args_p4x, &crate::prelude::Nat::from(1u32)), &(|a_p9: &crate::syntax::Arg| a_p9.value_p.clone()));
            crate::prelude::call_value(crate::prelude::fold_job(rest_p7.clone(), true, {
                let m_p0xx = m_p0x.clone();
                let i_p1xx = i_p1x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                    let m_p0xxy = m_p0xx.clone();
                    let i_p1xxy = i_p1xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_pa = p0;
                        let x_pb = p1;
                        if ok_pa {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(Part { m_p0: m_p0xxy.clone(), i_p1: i_p1xxy.clone(), e_p2: x_pb.clone() }))
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }), move |fold_6294: bool| {
                let parts_p8 = fold_6294;
                if !on_acc_p6 {
                    ::prism_rtl::Turn::Finished(false)
                } else {
                    if crate::check::shrink::relations::pre_is_f(&m_p0x, &f_p5, &crate::prelude::Text::lit("Push")) && (&crate::prelude::len(&rest_p7) == &crate::prelude::Nat::from(1u32)) {
                        ::prism_rtl::Turn::Finished(parts_p8)
                    } else {
                        if crate::check::shrink::relations::pre_is_f(&m_p0x, &f_p5, &crate::prelude::Text::lit("Insert")) && (&crate::prelude::len(&rest_p7) == &crate::prelude::Nat::from(2u32)) {
                            ::prism_rtl::Turn::Finished(parts_p8)
                        } else {
                            if crate::check::shrink::relations::pre_is_f(&m_p0x, &f_p5, &crate::prelude::Text::lit("Append")) && (&crate::prelude::len(&rest_p7) == &crate::prelude::Nat::from(1u32)) {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(Within { m_p0: m_p0x.clone(), i_p1: i_p1x.clone(), e_p2: crate::prelude::or(&crate::prelude::index(&rest_p7, &crate::prelude::Nat::from(0u32)), &dummy_arg_p().value_p) }))
                            } else {
                                ::prism_rtl::Turn::Finished(false)
                            }
                        }
                    }
                }
            })
        })
    }
}

/// `Start BuildsOnCall, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on_call_f(m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: crate::prelude::Nat, acc_p2: crate::prelude::Text, c_p3: crate::syntax::Expr, args_p4: crate::prelude::Array<crate::syntax::Arg>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(BuildsOnCall { m_p0, i_p1, acc_p2, c_p3, args_p4 })
}

/// ```prism
/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
/// ```
pub fn builds_on_block_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: &crate::prelude::Nat, acc_p2: &crate::prelude::Text, b_p3: &crate::syntax::Block) -> bool {
    !crate::check::types::has_text_f(&crate::check::shrink::relations::stmts_binders_f(&b_p3.stmts_p), acc_p2) && builds_on_f(&crate::check::shrink::relations::block_rels_f(&b_p3.stmts_p, m_p0), i_p1, acc_p2, &last_or_f(b_p3))
}

/// The step machine of `BuildsOnBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
/// ```
pub struct BuildsOnBlock {
    pub m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub i_p1: crate::prelude::Nat,
    pub acc_p2: crate::prelude::Text,
    pub b_p3: crate::syntax::Block,
}

impl ::prism_rtl::Job<bool> for BuildsOnBlock {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let acc_p2 = &self.acc_p2;
        let b_p3 = &self.b_p3;
        let acc_p2x = acc_p2.clone();
        let b_p3x = b_p3.clone();
        let i_p1x = i_p1.clone();
        let m_p0x = m_p0.clone();
        crate::prelude::call_then(crate::check::shrink::relations::start_stmts_binders_f(b_p3x.stmts_p.clone()), move |stmts_binders_f_6854: crate::prelude::Array<crate::prelude::Text>| if !crate::check::types::has_text_f(&stmts_binders_f_6854, &acc_p2x) {
            crate::prelude::call_then(crate::check::shrink::relations::start_block_rels_f(b_p3x.stmts_p.clone(), m_p0x.clone()), move |block_rels_f_6897: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::More(::std::rc::Rc::new(BuildsOn { m_p0: block_rels_f_6897, i_p1: i_p1x.clone(), acc_p2: acc_p2x.clone(), e_p3: last_or_f(&b_p3x) })))
        } else {
            ::prism_rtl::Turn::Finished(false)
        })
    }
}

/// `Start BuildsOnBlock, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on_block_f(m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: crate::prelude::Nat, acc_p2: crate::prelude::Text, b_p3: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(BuildsOnBlock { m_p0, i_p1, acc_p2, b_p3 })
}

/// ```prism
/// CondNames: unbounded fn Cond -> [Text]
/// ```
pub fn cond_names_f(cond0: &crate::syntax::Cond) -> crate::prelude::Array<crate::prelude::Text> {
    match cond0 {
        crate::syntax::Cond::CondBind(p_p0, _, _) => crate::check::env::names::pattern_names_f(p_p0),
        crate::syntax::Cond::CondExpr(_) => crate::prelude::Array::new(),
    }
}

/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondNames: unbounded fn Cond -> [Text]
/// ```
pub struct CondNames {
    pub cond0: crate::syntax::Cond,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for CondNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let cond0 = &self.cond0;
        match cond0 {
            crate::syntax::Cond::CondBind(p_p0, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::names::PatternNames { p_p0: p_p0.clone() })),
            crate::syntax::Cond::CondExpr(_) => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start CondNames, x`: what the function value is when passed to `@Run`.
pub fn start_cond_names_f(cond0: crate::syntax::Cond) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(CondNames { cond0 })
}

/// ```prism
/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub fn part_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: &crate::prelude::Nat, e_p2: &crate::syntax::Expr) -> bool {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::ETuple(es_p3) => crate::prelude::run_to_end(crate::prelude::fold_job(es_p3.clone(), true, {
            let m_p0x = m_p0.clone();
            let i_p1x = i_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                let m_p0xy = m_p0x.clone();
                let i_p1xy = i_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_p4 = p0;
                    let x_p5 = p1;
                    if ok_p4 {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Part { m_p0: m_p0xy.clone(), i_p1: i_p1xy.clone(), e_p2: x_p5.clone() }))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        crate::syntax::ExprKind::EGroup(x_p6) => part_f(m_p0, i_p1, &**x_p6),
        _ => match crate::check::shrink::walk::rel_of_o(m_p0, e_p2) {
            ::std::option::Option::Some(r_p7) => (&r_p7.param_p == i_p1) && r_p7.strict_p,
            ::std::option::Option::None => false,
        },
    }
}

/// The step machine of `Part`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub struct Part {
    pub m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub i_p1: crate::prelude::Nat,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for Part {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let m_p0 = &self.m_p0;
        let i_p1 = &self.i_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::ETuple(es_p3) => crate::prelude::fold_job(es_p3.clone(), true, {
                let m_p0x = m_p0.clone();
                let i_p1x = i_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                    let m_p0xy = m_p0x.clone();
                    let i_p1xy = i_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p4 = p0;
                        let x_p5 = p1;
                        if ok_p4 {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(Part { m_p0: m_p0xy.clone(), i_p1: i_p1xy.clone(), e_p2: x_p5.clone() }))
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle(),
            crate::syntax::ExprKind::EGroup(x_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Part { m_p0: m_p0.clone(), i_p1: i_p1.clone(), e_p2: (**x_p6).clone() })),
            _ => {
                let e_p2x = e_p2.clone();
                let i_p1x = i_p1.clone();
                let m_p0x = m_p0.clone();
                crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(m_p0x.clone(), e_p2x.clone()), move |rel_of_o_7269: ::std::option::Option<crate::check::shrink::Rel>| match rel_of_o_7269 {
                    ::std::option::Option::Some(r_p7) => ::prism_rtl::Turn::Finished((&r_p7.param_p == &i_p1x) && r_p7.strict_p),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                })
            },
        }
    }
}

/// `Start Part, x`: what the function value is when passed to `@Run`.
pub fn start_part_f(m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p1: crate::prelude::Nat, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(Part { m_p0, i_p1, e_p2 })
}

/// ```prism
/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn summary_seeds_f(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, spots_p2: &crate::prelude::Array<crate::check::shrink::walk::Spot>, rels_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel> {
    crate::prelude::fold(&crate::prelude::run_to_end(crate::prelude::fold_job(spots_p2.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p4 = p0;
        let sp_p5 = p1;
        crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5.clone()), move |spot_sites_f_7945: crate::prelude::Array<crate::check::shrink::walk::Site>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &spot_sites_f_7945)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Site>>>>)), rels_p3, &(|m_p6: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, site_p7: &crate::check::shrink::walk::Site| if crate::check::shrink::relations::is_local_f(&site_p7.rels_p, &site_p7.callee_p) {
        m_p6.clone()
    } else {
        match crate::check::shrink::locals::resolve_callee_o(&sk_p0.g_p, &d_p1.home_p, &site_p7.callee_p) {
            ::std::option::Option::Some(k_p8) => match crate::prelude::get(&sk_p0.sums_p, &k_p8) {
                ::std::option::Option::Some(i_p9) => crate::prelude::insert(m_p6, &crate::prelude::Text::from(format!("fn:{}", &site_p7.callee_p)), &crate::check::shrink::Rel { param_p: i_p9, strict_p: false }),
                ::std::option::Option::None => if crate::check::shrink::walk::is_no_larger_prelude_f(&sk_p0.g_p, &k_p8) {
                    crate::prelude::insert(m_p6, &crate::prelude::Text::from(format!("fn:{}", &site_p7.callee_p)), &crate::check::shrink::Rel { param_p: crate::prelude::Nat::from(0u32), strict_p: false })
                } else {
                    m_p6.clone()
                },
            },
            ::std::option::Option::None => m_p6.clone(),
        }
    }))
}

/// The step machine of `SummarySeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct SummarySeeds {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub spots_p2: crate::prelude::Array<crate::check::shrink::walk::Spot>,
    pub rels_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>> for SummarySeeds {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let spots_p2 = &self.spots_p2;
        let rels_p3 = &self.rels_p3;
        let d_p1x = d_p1.clone();
        let rels_p3x = rels_p3.clone();
        let sk_p0x = sk_p0.clone();
        let spots_p2x = spots_p2.clone();
        crate::prelude::call_value(crate::prelude::fold_job(spots_p2x.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p4 = p0;
            let sp_p5 = p1;
            crate::prelude::call_then(crate::check::shrink::walk::start_spot_sites_f(sp_p5.clone()), move |spot_sites_f_7945: crate::prelude::Array<crate::check::shrink::walk::Site>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &spot_sites_f_7945)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::walk::Site>>>>), move |fold_7903: crate::prelude::Array<crate::check::shrink::walk::Site>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&fold_7903, &rels_p3x, &(|m_p6: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, site_p7: &crate::check::shrink::walk::Site| if crate::check::shrink::relations::is_local_f(&site_p7.rels_p, &site_p7.callee_p) {
            m_p6.clone()
        } else {
            match crate::check::shrink::locals::resolve_callee_o(&sk_p0x.g_p, &d_p1x.home_p, &site_p7.callee_p) {
                ::std::option::Option::Some(k_p8) => match crate::prelude::get(&sk_p0x.sums_p, &k_p8) {
                    ::std::option::Option::Some(i_p9) => crate::prelude::insert(m_p6, &crate::prelude::Text::from(format!("fn:{}", &site_p7.callee_p)), &crate::check::shrink::Rel { param_p: i_p9, strict_p: false }),
                    ::std::option::Option::None => if crate::check::shrink::walk::is_no_larger_prelude_f(&sk_p0x.g_p, &k_p8) {
                        crate::prelude::insert(m_p6, &crate::prelude::Text::from(format!("fn:{}", &site_p7.callee_p)), &crate::check::shrink::Rel { param_p: crate::prelude::Nat::from(0u32), strict_p: false })
                    } else {
                        m_p6.clone()
                    },
                },
                ::std::option::Option::None => m_p6.clone(),
            }
        }))))
    }
}

/// `Start SummarySeeds, x`: what the function value is when passed to `@Run`.
pub fn start_summary_seeds_f(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, spots_p2: crate::prelude::Array<crate::check::shrink::walk::Spot>, rels_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>> {
    ::std::rc::Rc::new(SummarySeeds { sk_p0, d_p1, spots_p2, rels_p3 })
}

/// ```prism
/// OptNames: unbounded fn ?Pattern -> [Text]
/// ```
pub fn opt_names_f(opt0: &::std::option::Option<crate::syntax::Pattern>) -> crate::prelude::Array<crate::prelude::Text> {
    match opt0 {
        ::std::option::Option::Some(p_p0) => crate::check::env::names::pattern_names_f(p_p0),
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// The step machine of `OptNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptNames: unbounded fn ?Pattern -> [Text]
/// ```
pub struct OptNames {
    pub opt0: ::std::option::Option<crate::syntax::Pattern>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for OptNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let opt0 = &self.opt0;
        match opt0 {
            ::std::option::Option::Some(p_p0) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::names::PatternNames { p_p0: p_p0.clone() })),
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start OptNames, x`: what the function value is when passed to `@Run`.
pub fn start_opt_names_f(opt0: ::std::option::Option<crate::syntax::Pattern>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(OptNames { opt0 })
}

/// ```prism
/// let dummyArg
/// ```
pub fn dummy_arg_p() -> crate::syntax::Arg {
    crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }, span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub fn decrement_of_o(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, e_p1: &crate::syntax::Expr) -> ::std::option::Option<crate::check::shrink::Rel> {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::EBinary(m8764_0_0, l_p2, r_p3) if (m8764_0_0 == &crate::prelude::Text::lit("-?")) => if is_positive_lit_f(&**r_p3) && is_nat_minus_f(m_p0, e_p1) {
            smaller_o(m_p0, &**l_p2)
        } else {
            ::std::option::Option::None
        },
        crate::syntax::ExprKind::EGroup(x_p4) => decrement_of_o(m_p0, &**x_p4),
        _ => match crate::check::shrink::walk::call_of_o(e_p1) {
            ::std::option::Option::Some((c_p5, args_p6)) => match crate::check::shrink::walk::callee_name_o(&c_p5) {
                ::std::option::Option::Some(n_p7) => if crate::check::shrink::relations::pre_is_f(m_p0, &n_p7, &crate::prelude::Text::lit("?Step")) {
                    smaller_o(m_p0, &crate::prelude::or(&crate::prelude::index(&args_p6, &crate::prelude::Nat::from(0u32)), &dummy_arg_p()).value_p)
                } else {
                    ::std::option::Option::None
                },
                ::std::option::Option::None => ::std::option::Option::None,
            },
            ::std::option::Option::None => ::std::option::Option::None,
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DecrementOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub struct DecrementOf {
    pub m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub e_p1: crate::syntax::Expr,
}

impl ::prism_rtl::Job<::std::option::Option<crate::check::shrink::Rel>> for DecrementOf {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::check::shrink::Rel>> {
        let m_p0 = &self.m_p0;
        let e_p1 = &self.e_p1;
        match &*e_p1.kind_p {
            crate::syntax::ExprKind::EBinary(m8764_0_0, l_p2, r_p3) if (m8764_0_0 == &crate::prelude::Text::lit("-?")) => if is_positive_lit_f(&**r_p3) && is_nat_minus_f(m_p0, e_p1) {
                ::prism_rtl::Turn::Finished(smaller_o(m_p0, &**l_p2))
            } else {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            },
            crate::syntax::ExprKind::EGroup(x_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(DecrementOf { m_p0: m_p0.clone(), e_p1: (**x_p4).clone() })),
            _ => match crate::check::shrink::walk::call_of_o(e_p1) {
                ::std::option::Option::Some((c_p5, args_p6)) => match crate::check::shrink::walk::callee_name_o(&c_p5) {
                    ::std::option::Option::Some(n_p7) => if crate::check::shrink::relations::pre_is_f(m_p0, &n_p7, &crate::prelude::Text::lit("?Step")) {
                        ::prism_rtl::Turn::Finished(smaller_o(m_p0, &crate::prelude::or(&crate::prelude::index(&args_p6, &crate::prelude::Nat::from(0u32)), &dummy_arg_p()).value_p))
                    } else {
                        ::prism_rtl::Turn::Finished(::std::option::Option::None)
                    },
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DecrementOf, x`: what the function value is when passed to `@Run`.
pub fn start_decrement_of_o(m_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, e_p1: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::check::shrink::Rel>>> {
    ::std::rc::Rc::new(DecrementOf { m_p0, e_p1 })
}

/// ```prism
/// IsNatMinus: fn (Text ==> Rel), Expr -> Bool
/// ```
pub fn is_nat_minus_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, e_p1: &crate::syntax::Expr) -> bool {
    crate::check::shrink::relations::pre_is_f(m_p0, &crate::prelude::Text::lit("-?"), &crate::prelude::Text::lit("-?")) && crate::check::shrink::walk::is_nat_at_f(m_p0, e_p1)
}

/// ```prism
/// ?Smaller: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub fn smaller_o(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, x_p1: &crate::syntax::Expr) -> ::std::option::Option<crate::check::shrink::Rel> {
    match crate::check::shrink::walk::rel_of_o(m_p0, x_p1) {
        ::std::option::Option::Some(r_p2) => ::std::option::Option::Some(crate::check::shrink::Rel { param_p: r_p2.param_p.clone(), strict_p: true }),
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// IsPositiveLit: fn Expr -> Bool
/// ```
pub fn is_positive_lit_f(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ELit(l_p1) => match &l_p1.kind_p {
            crate::syntax::LitKind::LInt(d_p2) => d_p2 != &crate::prelude::Text::lit("0"),
            _ => false,
        },
        crate::syntax::ExprKind::EGroup(x_p3) => is_positive_lit_f(&**x_p3),
        _ => false,
    }
}

/// ```prism
/// Closure: unbounded fn [Sc] -> [Sc]
/// ```
pub fn closure_f(graphs_p0: &crate::prelude::Array<crate::check::shrink::Sc>) -> crate::prelude::Array<crate::check::shrink::Sc> {
    closure_from_f(graphs_p0, &dedup_f(graphs_p0), &dedup_f(graphs_p0))
}

/// The step machine of `Closure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Closure: unbounded fn [Sc] -> [Sc]
/// ```
pub struct Closure {
    pub graphs_p0: crate::prelude::Array<crate::check::shrink::Sc>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>> for Closure {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::check::shrink::Sc>> {
        let graphs_p0 = &self.graphs_p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(ClosureFrom { base_p0: graphs_p0.clone(), acc_p1: dedup_f(graphs_p0), frontier_p2: dedup_f(graphs_p0) }))
    }
}

/// `Start Closure, x`: what the function value is when passed to `@Run`.
pub fn start_closure_f(graphs_p0: crate::prelude::Array<crate::check::shrink::Sc>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>>> {
    ::std::rc::Rc::new(Closure { graphs_p0 })
}

/// ```prism
/// Dedup: fn [Sc] -> [Sc]
/// ```
pub fn dedup_f(gs_p0: &crate::prelude::Array<crate::check::shrink::Sc>) -> crate::prelude::Array<crate::check::shrink::Sc> {
    crate::prelude::fold(gs_p0, &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<crate::check::shrink::Sc>, g_p2: &crate::check::shrink::Sc| if has_sc_f(acc_p1, g_p2) {
        acc_p1.clone()
    } else {
        crate::prelude::push(acc_p1, g_p2)
    }))
}

/// ```prism
/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
/// ```
pub fn closure_from_f(base_p0: &crate::prelude::Array<crate::check::shrink::Sc>, acc_p1: &crate::prelude::Array<crate::check::shrink::Sc>, frontier_p2: &crate::prelude::Array<crate::check::shrink::Sc>) -> crate::prelude::Array<crate::check::shrink::Sc> {
    let fresh_p3 = crate::prelude::fold(frontier_p2, &crate::prelude::Array::new(), &(|out_p4: &crate::prelude::Array<crate::check::shrink::Sc>, a_p5: &crate::check::shrink::Sc| crate::prelude::fold(base_p0, out_p4, &(|out2_p6: &crate::prelude::Array<crate::check::shrink::Sc>, b_p7: &crate::check::shrink::Sc| add_composed_f(acc_p1, out2_p6, a_p5, b_p7)))));
    if &crate::prelude::len(&fresh_p3) == &crate::prelude::Nat::from(0u32) {
        acc_p1.clone()
    } else {
        closure_from_f(base_p0, &crate::prelude::append(acc_p1, &fresh_p3), &fresh_p3)
    }
}

/// The step machine of `ClosureFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
/// ```
pub struct ClosureFrom {
    pub base_p0: crate::prelude::Array<crate::check::shrink::Sc>,
    pub acc_p1: crate::prelude::Array<crate::check::shrink::Sc>,
    pub frontier_p2: crate::prelude::Array<crate::check::shrink::Sc>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>> for ClosureFrom {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::check::shrink::Sc>> {
        let base_p0 = &self.base_p0;
        let acc_p1 = &self.acc_p1;
        let frontier_p2 = &self.frontier_p2;
        let fresh_p3 = crate::prelude::fold(frontier_p2, &crate::prelude::Array::new(), &(|out_p4: &crate::prelude::Array<crate::check::shrink::Sc>, a_p5: &crate::check::shrink::Sc| crate::prelude::fold(base_p0, out_p4, &(|out2_p6: &crate::prelude::Array<crate::check::shrink::Sc>, b_p7: &crate::check::shrink::Sc| add_composed_f(acc_p1, out2_p6, a_p5, b_p7)))));
        if &crate::prelude::len(&fresh_p3) == &crate::prelude::Nat::from(0u32) {
            ::prism_rtl::Turn::Finished(acc_p1.clone())
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(ClosureFrom { base_p0: base_p0.clone(), acc_p1: crate::prelude::append(acc_p1, &fresh_p3), frontier_p2: fresh_p3.clone() }))
        }
    }
}

/// `Start ClosureFrom, x`: what the function value is when passed to `@Run`.
pub fn start_closure_from_f(base_p0: crate::prelude::Array<crate::check::shrink::Sc>, acc_p1: crate::prelude::Array<crate::check::shrink::Sc>, frontier_p2: crate::prelude::Array<crate::check::shrink::Sc>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>>> {
    ::std::rc::Rc::new(ClosureFrom { base_p0, acc_p1, frontier_p2 })
}

/// ```prism
/// AddComposed: fn [Sc], [Sc], Sc, Sc -> [Sc]
/// ```
pub fn add_composed_f(acc_p0: &crate::prelude::Array<crate::check::shrink::Sc>, out_p1: &crate::prelude::Array<crate::check::shrink::Sc>, a_p2: &crate::check::shrink::Sc, b_p3: &crate::check::shrink::Sc) -> crate::prelude::Array<crate::check::shrink::Sc> {
    if &a_p2.callee_p != &b_p3.caller_p {
        out_p1.clone()
    } else {
        {
            let c_p4 = compose_f(a_p2, b_p3);
            if has_sc_f(acc_p0, &c_p4) || has_sc_f(out_p1, &c_p4) {
                out_p1.clone()
            } else {
                crate::prelude::push(out_p1, &c_p4)
            }
        }
    }
}

/// ```prism
/// HasSc: fn [Sc], Sc -> Bool
/// ```
pub fn has_sc_f(xs_p0: &crate::prelude::Array<crate::check::shrink::Sc>, c_p1: &crate::check::shrink::Sc) -> bool {
    crate::prelude::fold(xs_p0, &false, &(|seen_p2: &bool, x_p3: &crate::check::shrink::Sc| *seen_p2 || (((&x_p3.caller_p == &c_p1.caller_p) && (&x_p3.callee_p == &c_p1.callee_p)) && (&x_p3.edges_p == &c_p1.edges_p))))
}

/// ```prism
/// Compose: fn Sc, Sc -> Sc
/// ```
pub fn compose_f(a_p0: &crate::check::shrink::Sc, b_p1: &crate::check::shrink::Sc) -> crate::check::shrink::Sc {
    let pairs_p2 = crate::prelude::fold(&a_p0.edges_p, &crate::prelude::Array::new(), &(|acc_p3: &crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>, (x_p4, y_p5, s1_p6): &(crate::prelude::Nat, crate::prelude::Nat, bool)| crate::prelude::fold(&b_p1.edges_p, acc_p3, &(|acc2_p7: &crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>, (y2_p8, z_p9, s2_pa): &(crate::prelude::Nat, crate::prelude::Nat, bool)| if y_p5 == y2_p8 {
        add_edge_f(acc2_p7, x_p4, z_p9, &(*s1_p6 || *s2_pa))
    } else {
        acc2_p7.clone()
    }))));
    crate::check::shrink::Sc { caller_p: a_p0.caller_p.clone(), callee_p: b_p1.callee_p.clone(), edges_p: sort_edges_f(&pairs_p2), span_p: a_p0.span_p.clone(), file_p: a_p0.file_p.clone(), arg_p: a_p0.arg_p.clone() }
}

/// ```prism
/// AddEdge: fn [((Nat, Nat, Bool))], Nat, Nat, Bool -> [((Nat, Nat, Bool))]
/// ```
pub fn add_edge_f(es_p0: &crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>, x_p1: &crate::prelude::Nat, z_p2: &crate::prelude::Nat, s_p3: &bool) -> crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)> {
    let others_p4 = crate::prelude::filter(es_p0, &(|(a_p6, b_p7, _): &(crate::prelude::Nat, crate::prelude::Nat, bool)| !((a_p6 == x_p1) && (b_p7 == z_p2))));
    let had_p5 = crate::prelude::fold(es_p0, &false, &(|seen_p8: &bool, (a_p9, b_pa, t_pb): &(crate::prelude::Nat, crate::prelude::Nat, bool)| *seen_p8 || (((a_p9 == x_p1) && (b_pa == z_p2)) && *t_pb)));
    crate::prelude::push(&others_p4, &(x_p1.clone(), z_p2.clone(), *s_p3 || had_p5))
}

/// ```prism
/// SortEdges: fn [((Nat, Nat, Bool))] -> [((Nat, Nat, Bool))]
/// ```
pub fn sort_edges_f(es_p0: &crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>) -> crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)> {
    crate::prelude::fold(es_p0, &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>, e_p2: &(crate::prelude::Nat, crate::prelude::Nat, bool)| crate::prelude::append(&crate::prelude::push(&crate::prelude::filter(acc_p1, &(|x_p3: &(crate::prelude::Nat, crate::prelude::Nat, bool)| edge_before_f(x_p3, e_p2))), e_p2), &crate::prelude::filter(acc_p1, &(|x_p4: &(crate::prelude::Nat, crate::prelude::Nat, bool)| !edge_before_f(x_p4, e_p2))))))
}

/// ```prism
/// EdgeBefore: fn ((Nat, Nat, Bool)), ((Nat, Nat, Bool)) -> Bool
/// ```
pub fn edge_before_f(arg0: &(crate::prelude::Nat, crate::prelude::Nat, bool), arg1: &(crate::prelude::Nat, crate::prelude::Nat, bool)) -> bool {
    match (arg0, arg1) {
        ((a1_p0, b1_p1, _), (a2_p2, b2_p3, _)) => (a1_p0 < a2_p2) || ((a1_p0 == a2_p2) && (b1_p1 < b2_p3)),
    }
}

/// ```prism
/// LoopsOf: unbounded fn Shrink, St, Def -> St
/// ```
pub fn loops_of_f(sk_p0: &crate::check::shrink::Shrink, st_p1: &crate::check::types::St, d_p2: &crate::check::env::Def) -> crate::check::types::St {
    let unb_p3 = crate::check::shrink::types::is_unbounded_key_f(&sk_p0.g_p, &crate::check::shrink::types::sig_key_of_f(sk_p0, &d_p2.qk_p));
    if unb_p3 && !st_p1.recording_p {
        st_p1.clone()
    } else {
        {
            let s0_p4 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.file_p = d_p2.file_p.clone();
                this
            };
            let s1_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p2), s0_p4.clone(), {
                let sk_p0x = sk_p0.clone();
                let d_p2x = d_p2.clone();
                let unb_p3x = unb_p3;
                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                    let sk_p0xy = sk_p0x.clone();
                    let d_p2xy = d_p2x.clone();
                    let unb_p3xy = unb_p3x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_p6 = p0;
                        let c_p7 = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ClauseLoops { sk_p0: sk_p0xy.clone(), st_p1: s_p6.clone(), d_p2: d_p2xy.clone(), c_p3: c_p7.clone(), unb_p4: unb_p3xy }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
            }));
            {
                let mut this: crate::check::types::St = s1_p5.clone();
                this.file_p = st_p1.file_p.clone();
                this
            }
        }
    }
}

/// The step machine of `LoopsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LoopsOf: unbounded fn Shrink, St, Def -> St
/// ```
pub struct LoopsOf {
    pub sk_p0: crate::check::shrink::Shrink,
    pub st_p1: crate::check::types::St,
    pub d_p2: crate::check::env::Def,
}

impl ::prism_rtl::Job<crate::check::types::St> for LoopsOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let sk_p0 = &self.sk_p0;
        let st_p1 = &self.st_p1;
        let d_p2 = &self.d_p2;
        let unb_p3 = crate::check::shrink::types::is_unbounded_key_f(&sk_p0.g_p, &crate::check::shrink::types::sig_key_of_f(sk_p0, &d_p2.qk_p));
        if unb_p3 && !st_p1.recording_p {
            ::prism_rtl::Turn::Finished(st_p1.clone())
        } else {
            {
                let s0_p4 = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.file_p = d_p2.file_p.clone();
                    this
                };
                let d_p2x = d_p2.clone();
                let sk_p0x = sk_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_value(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(&d_p2x), s0_p4.clone(), {
                    let sk_p0xx = sk_p0x.clone();
                    let d_p2xx = d_p2x.clone();
                    let unb_p3x = unb_p3;
                    ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                        let sk_p0xxy = sk_p0xx.clone();
                        let d_p2xxy = d_p2xx.clone();
                        let unb_p3xy = unb_p3x;
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let s_p6 = p0;
                            let c_p7 = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ClauseLoops { sk_p0: sk_p0xxy.clone(), st_p1: s_p6.clone(), d_p2: d_p2xxy.clone(), c_p3: c_p7.clone(), unb_p4: unb_p3xy }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                }), move |fold_12735: crate::check::types::St| {
                    let s1_p5 = fold_12735;
                    ::prism_rtl::Turn::Finished({
                        let mut this: crate::check::types::St = s1_p5.clone();
                        this.file_p = st_p1x.file_p.clone();
                        this
                    })
                })
            }
        }
    }
}

/// `Start LoopsOf, x`: what the function value is when passed to `@Run`.
pub fn start_loops_of_f(sk_p0: crate::check::shrink::Shrink, st_p1: crate::check::types::St, d_p2: crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(LoopsOf { sk_p0, st_p1, d_p2 })
}

/// ```prism
/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
/// ```
pub fn clause_loops_f(sk_p0: &crate::check::shrink::Shrink, st_p1: &crate::check::types::St, d_p2: &crate::check::env::Def, c_p3: &crate::syntax::decls::FnClause, unb_p4: &bool) -> crate::check::types::St {
    let base_p5 = crate::check::shrink::locals::clause_base_f(sk_p0, d_p2, c_p3);
    let spots0_p6 = crate::check::shrink::walk::body_spots_f(&c_p3.body_p, &base_p5);
    if !crate::prelude::fold(&spots0_p6, &false, &(|seen_p7: &bool, sp_p8: &crate::check::shrink::walk::Spot| *seen_p7 || is_while_spot_f(sp_p8))) {
        st_p1.clone()
    } else {
        {
            let spots_p9 = crate::check::shrink::walk::body_spots_f(&c_p3.body_p, &summary_seeds_f(sk_p0, d_p2, &spots0_p6, &base_p5));
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(&spots_p9, &(|sp_pa: &crate::check::shrink::walk::Spot| is_while_spot_f(sp_pa))), st_p1.clone(), {
                let d_p2x = d_p2.clone();
                let unb_p4x = *unb_p4;
                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::shrink::walk::Spot)| {
                    let d_p2xy = d_p2x.clone();
                    let unb_p4xy = unb_p4x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_pb = p0;
                        let sp_pc = p1;
                        match &sp_pc {
                            crate::check::shrink::walk::Spot::SpotStmt(w_pd, m_pe) => match &w_pd.kind_p {
                                crate::syntax::StmtKind::SWhile(cond_pf, body_pg) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckWhile { st_p0: s_pb.clone(), c_p1: cond_pf.clone(), body_p2: body_pg.clone(), span_p3: w_pd.span_p.clone(), name_p4: d_p2xy.name_p.clone(), seeds_p5: marks_f(m_pe), unb_p6: unb_p4xy })),
                                _ => ::prism_rtl::Turn::Finished(s_pb.clone()),
                            },
                            _ => ::prism_rtl::Turn::Finished(s_pb.clone()),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
            }))
        }
    }
}

/// The step machine of `ClauseLoops`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
/// ```
pub struct ClauseLoops {
    pub sk_p0: crate::check::shrink::Shrink,
    pub st_p1: crate::check::types::St,
    pub d_p2: crate::check::env::Def,
    pub c_p3: crate::syntax::decls::FnClause,
    pub unb_p4: bool,
}

impl ::prism_rtl::Job<crate::check::types::St> for ClauseLoops {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let sk_p0 = &self.sk_p0;
        let st_p1 = &self.st_p1;
        let d_p2 = &self.d_p2;
        let c_p3 = &self.c_p3;
        let unb_p4 = &self.unb_p4;
        let c_p3x = c_p3.clone();
        let d_p2x = d_p2.clone();
        let sk_p0x = sk_p0.clone();
        let st_p1x = st_p1.clone();
        let unb_p4x = *unb_p4;
        crate::prelude::call_then(crate::check::shrink::locals::start_clause_base_f(sk_p0x.clone(), d_p2x.clone(), c_p3x.clone()), move |clause_base_f_12961: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
            let base_p5 = clause_base_f_12961;
            crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p3x.body_p.clone(), base_p5.clone()), move |body_spots_f_12998: crate::prelude::Array<crate::check::shrink::walk::Spot>| {
                let spots0_p6 = body_spots_f_12998;
                if !crate::prelude::fold(&spots0_p6, &false, &(|seen_p7: &bool, sp_p8: &crate::check::shrink::walk::Spot| *seen_p7 || is_while_spot_f(sp_p8))) {
                    ::prism_rtl::Turn::Finished(st_p1x.clone())
                } else {
                    crate::prelude::call_then(start_summary_seeds_f(sk_p0x.clone(), d_p2x.clone(), spots0_p6.clone(), base_p5.clone()), move |summary_seeds_f_13142: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p3x.body_p.clone(), summary_seeds_f_13142), move |body_spots_f_13123: crate::prelude::Array<crate::check::shrink::walk::Spot>| {
                        let spots_p9 = body_spots_f_13123;
                        crate::prelude::fold_job(crate::prelude::filter(&spots_p9, &(|sp_pa: &crate::check::shrink::walk::Spot| is_while_spot_f(sp_pa))), st_p1x.clone(), {
                            let d_p2xx = d_p2x.clone();
                            let unb_p4xx = unb_p4x;
                            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::shrink::walk::Spot)| {
                                let d_p2xxy = d_p2xx.clone();
                                let unb_p4xxy = unb_p4xx;
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s_pb = p0;
                                    let sp_pc = p1;
                                    match &sp_pc {
                                        crate::check::shrink::walk::Spot::SpotStmt(w_pd, m_pe) => match &w_pd.kind_p {
                                            crate::syntax::StmtKind::SWhile(cond_pf, body_pg) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckWhile { st_p0: s_pb.clone(), c_p1: cond_pf.clone(), body_p2: body_pg.clone(), span_p3: w_pd.span_p.clone(), name_p4: d_p2xxy.name_p.clone(), seeds_p5: marks_f(m_pe), unb_p6: unb_p4xxy })),
                                            _ => ::prism_rtl::Turn::Finished(s_pb.clone()),
                                        },
                                        _ => ::prism_rtl::Turn::Finished(s_pb.clone()),
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                        }).cycle()
                    }))
                }
            })
        })
    }
}

/// `Start ClauseLoops, x`: what the function value is when passed to `@Run`.
pub fn start_clause_loops_f(sk_p0: crate::check::shrink::Shrink, st_p1: crate::check::types::St, d_p2: crate::check::env::Def, c_p3: crate::syntax::decls::FnClause, unb_p4: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(ClauseLoops { sk_p0, st_p1, d_p2, c_p3, unb_p4 })
}

/// ```prism
/// Marks: fn (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn marks_f(m_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel> {
    crate::prelude::fold(&crate::prelude::keys(m_p0), m_p0, &(|m2_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, k_p2: &crate::prelude::Text| if crate::syntax::lexer::chars::contains_f(k_p2, &crate::prelude::Text::lit(":")) {
        m2_p1.clone()
    } else {
        crate::prelude::remove(m2_p1, k_p2)
    }))
}

/// ```prism
/// IsWhileSpot: fn Spot -> Bool
/// ```
pub fn is_while_spot_f(spot0: &crate::check::shrink::walk::Spot) -> bool {
    match spot0 {
        crate::check::shrink::walk::Spot::SpotStmt(s_p0, _) => match &s_p0.kind_p {
            crate::syntax::StmtKind::SWhile(_, _) => true,
            _ => false,
        },
        crate::check::shrink::walk::Spot::SpotExpr(_, _) => false,
    }
}

/// ```prism
/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
/// ```
pub fn check_while_f(st_p0: &crate::check::types::St, c_p1: &crate::syntax::Cond, body_p2: &crate::syntax::Block, span_p3: &crate::syntax::Range, name_p4: &crate::prelude::Text, seeds_p5: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, unb_p6: &bool) -> crate::check::types::St {
    let vars_p7 = set_targets_f(&body_p2.stmts_p);
    let base_p8 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&vars_p7)), seeds_p5, &(|m_pb: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_pc: &crate::prelude::Nat| crate::prelude::insert(m_pb, &crate::prelude::or(&crate::prelude::index(&vars_p7, i_pc), &crate::prelude::Text::lit("")), &crate::check::shrink::Rel { param_p: i_pc.clone(), strict_p: false })));
    let rels_p9 = crate::check::shrink::relations::cond_rels_f(c_p1, &base_p8);
    let ok_pa = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&vars_p7)), false, {
        let body_p2x = body_p2.clone();
        let vars_p7x = vars_p7.clone();
        let rels_p9x = rels_p9.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Nat)| {
            let body_p2xy = body_p2x.clone();
            let vars_p7xy = vars_p7x.clone();
            let rels_p9xy = rels_p9x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_pd = p0;
                let i_pe = p1;
                if seen_pd {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(AllPathsStrict { stmts_p0: body_p2xy.stmts_p.clone(), v_p1: crate::prelude::or(&crate::prelude::index(&vars_p7xy, &i_pe), &crate::prelude::Text::lit("")), vi_p2: i_pe.clone(), outer_p3: rels_p9xy.clone() }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    if ok_pa {
        st_p0.clone()
    } else {
        if *unb_p6 {
            note_unshrunk_f(st_p0, span_p3)
        } else {
            crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("may-not-end"), span_p3, &crate::prelude::Text::from(format!("this loop in `{}` may not end: nothing it sets gets smaller on every turn", name_p4)), &crate::prelude::Text::from(format!("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `{}` `unbounded fn`", name_p4)))
        }
    }
}

/// The step machine of `CheckWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
/// ```
pub struct CheckWhile {
    pub st_p0: crate::check::types::St,
    pub c_p1: crate::syntax::Cond,
    pub body_p2: crate::syntax::Block,
    pub span_p3: crate::syntax::Range,
    pub name_p4: crate::prelude::Text,
    pub seeds_p5: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub unb_p6: bool,
}

impl ::prism_rtl::Job<crate::check::types::St> for CheckWhile {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let c_p1 = &self.c_p1;
        let body_p2 = &self.body_p2;
        let span_p3 = &self.span_p3;
        let name_p4 = &self.name_p4;
        let seeds_p5 = &self.seeds_p5;
        let unb_p6 = &self.unb_p6;
        let body_p2x = body_p2.clone();
        let c_p1x = c_p1.clone();
        let name_p4x = name_p4.clone();
        let seeds_p5x = seeds_p5.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        let unb_p6x = *unb_p6;
        crate::prelude::call_then(start_set_targets_f(body_p2x.stmts_p.clone()), move |set_targets_f_14249: crate::prelude::Array<crate::prelude::Text>| {
            let vars_p7 = set_targets_f_14249;
            let base_p8 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&vars_p7)), &seeds_p5x, &(|m_pb: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_pc: &crate::prelude::Nat| crate::prelude::insert(m_pb, &crate::prelude::or(&crate::prelude::index(&vars_p7, i_pc), &crate::prelude::Text::lit("")), &crate::check::shrink::Rel { param_p: i_pc.clone(), strict_p: false })));
            crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_p1x.clone(), base_p8.clone()), move |cond_rels_f_14563: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                let rels_p9 = cond_rels_f_14563;
                crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&vars_p7)), false, {
                    let body_p2xx = body_p2x.clone();
                    let vars_p7x = vars_p7.clone();
                    let rels_p9x = rels_p9.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Nat)| {
                        let body_p2xxy = body_p2xx.clone();
                        let vars_p7xy = vars_p7x.clone();
                        let rels_p9xy = rels_p9x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let seen_pd = p0;
                            let i_pe = p1;
                            if seen_pd {
                                ::prism_rtl::Turn::Finished(true)
                            } else {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(AllPathsStrict { stmts_p0: body_p2xxy.stmts_p.clone(), v_p1: crate::prelude::or(&crate::prelude::index(&vars_p7xy, &i_pe), &crate::prelude::Text::lit("")), vi_p2: i_pe.clone(), outer_p3: rels_p9xy.clone() }))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }), move |fold_14593: bool| {
                    let ok_pa = fold_14593;
                    if ok_pa {
                        ::prism_rtl::Turn::Finished(st_p0x.clone())
                    } else {
                        if unb_p6x {
                            ::prism_rtl::Turn::Finished(note_unshrunk_f(&st_p0x, &span_p3x))
                        } else {
                            ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p0x, &crate::prelude::Text::lit("may-not-end"), &span_p3x, &crate::prelude::Text::from(format!("this loop in `{}` may not end: nothing it sets gets smaller on every turn", &name_p4x)), &crate::prelude::Text::from(format!("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `{}` `unbounded fn`", &name_p4x))))
                        }
                    }
                })
            })
        })
    }
}

/// `Start CheckWhile, x`: what the function value is when passed to `@Run`.
pub fn start_check_while_f(st_p0: crate::check::types::St, c_p1: crate::syntax::Cond, body_p2: crate::syntax::Block, span_p3: crate::syntax::Range, name_p4: crate::prelude::Text, seeds_p5: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, unb_p6: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CheckWhile { st_p0, c_p1, body_p2, span_p3, name_p4, seeds_p5, unb_p6 })
}

/// ```prism
/// NoteUnshrunk: fn St, Range -> St
/// ```
pub fn note_unshrunk_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.typed_p.unshrunk_p = crate::prelude::push(&this.typed_p.unshrunk_p, &crate::check::types::recording::at_here_f(st_p0, span_p1));
    this
}

/// ```prism
/// SetTargets: unbounded fn [Stmt] -> [Text]
/// ```
pub fn set_targets_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmts_spots_f(stmts_p0, &crate::prelude::Map::new()), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::shrink::walk::Spot)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p1 = p0;
        let sp_p2 = p1;
        crate::prelude::call_then(start_spot_set_root_f(sp_p2.clone()), move |spot_set_root_f_15459: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p1, &spot_set_root_f_15459)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>))
}

/// The step machine of `SetTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetTargets: unbounded fn [Stmt] -> [Text]
/// ```
pub struct SetTargets {
    pub stmts_p0: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for SetTargets {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let stmts_p0 = &self.stmts_p0;
        let stmts_p0x = stmts_p0.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_stmts_spots_f(stmts_p0x.clone(), crate::prelude::Map::new()), move |stmts_spots_f_15402: crate::prelude::Array<crate::check::shrink::walk::Spot>| crate::prelude::fold_job(stmts_spots_f_15402, crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::shrink::walk::Spot)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p1 = p0;
            let sp_p2 = p1;
            crate::prelude::call_then(start_spot_set_root_f(sp_p2.clone()), move |spot_set_root_f_15459: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p1, &spot_set_root_f_15459)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle())
    }
}

/// `Start SetTargets, x`: what the function value is when passed to `@Run`.
pub fn start_set_targets_f(stmts_p0: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(SetTargets { stmts_p0 })
}

/// ```prism
/// SpotSetRoot: unbounded fn Spot -> [Text]
/// ```
pub fn spot_set_root_f(spot0: &crate::check::shrink::walk::Spot) -> crate::prelude::Array<crate::prelude::Text> {
    match spot0 {
        crate::check::shrink::walk::Spot::SpotStmt(s_p0, _) => match &s_p0.kind_p {
            crate::syntax::StmtKind::SSet(t_p1, _) => crate::prelude::take(&crate::check::passes::borrows::ref_path_f(t_p1), &crate::prelude::Nat::from(1u32)),
            crate::syntax::StmtKind::SAccum(t_p2, _, _) => crate::prelude::take(&crate::check::passes::borrows::ref_path_f(t_p2), &crate::prelude::Nat::from(1u32)),
            _ => crate::prelude::Array::new(),
        },
        crate::check::shrink::walk::Spot::SpotExpr(_, _) => crate::prelude::Array::new(),
    }
}

/// The step machine of `SpotSetRoot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotSetRoot: unbounded fn Spot -> [Text]
/// ```
pub struct SpotSetRoot {
    pub spot0: crate::check::shrink::walk::Spot,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for SpotSetRoot {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let spot0 = &self.spot0;
        match spot0 {
            crate::check::shrink::walk::Spot::SpotStmt(s_p0, _) => match &s_p0.kind_p {
                crate::syntax::StmtKind::SSet(t_p1, _) => {
                    let t_p1x = t_p1.clone();
                    crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p1x.clone()), move |ref_path_f_15595: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::take(&ref_path_f_15595, &crate::prelude::Nat::from(1u32))))
                },
                crate::syntax::StmtKind::SAccum(t_p2, _, _) => {
                    let t_p2x = t_p2.clone();
                    crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p2x.clone()), move |ref_path_f_15645: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::take(&ref_path_f_15645, &crate::prelude::Nat::from(1u32))))
                },
                _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
            },
            crate::check::shrink::walk::Spot::SpotExpr(_, _) => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start SpotSetRoot, x`: what the function value is when passed to `@Run`.
pub fn start_spot_set_root_f(spot0: crate::check::shrink::walk::Spot) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(SpotSetRoot { spot0 })
}

/// ```prism
/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn all_paths_strict_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>, v_p1: &crate::prelude::Text, vi_p2: &crate::prelude::Nat, outer_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> bool {
    let rels_p4 = crate::check::shrink::relations::block_rels_f(stmts_p0, outer_p3);
    crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p0.clone(), false, {
        let v_p1x = v_p1.clone();
        let vi_p2x = vi_p2.clone();
        let rels_p4x = rels_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Stmt)| {
            let v_p1xy = v_p1x.clone();
            let vi_p2xy = vi_p2x.clone();
            let rels_p4xy = rels_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p5 = p0;
                let s_p6 = p1;
                match &s_p6.kind_p {
                    crate::syntax::StmtKind::SSet(t_p7, value_p8) => {
                        let t_p7x = t_p7.clone();
                        let value_p8x = value_p8.clone();
                        crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p7x.clone()), move |ref_path_f_16330: crate::prelude::Array<crate::prelude::Text>| if &ref_path_f_16330 == &crate::prelude::Array::from(vec![v_p1xy.clone()]) {
                            if is_zero_lit_f(&value_p8x) {
                                ::prism_rtl::Turn::Finished(ok_p5)
                            } else {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(SetsStrict { e_p0: value_p8x.clone(), v_p1: v_p1xy.clone(), vi_p2: vi_p2xy.clone(), rels_p3: rels_p4xy.clone() }))
                            }
                        } else {
                            if ok_p5 {
                                crate::prelude::call_then(start_stmt_sets_weak_f(s_p6.clone(), v_p1xy.clone(), vi_p2xy.clone(), rels_p4xy.clone()), move |stmt_sets_weak_f_16442: bool| ::prism_rtl::Turn::Finished(!stmt_sets_weak_f_16442))
                            } else {
                                ::prism_rtl::Turn::Finished(false)
                            }
                        })
                    },
                    crate::syntax::StmtKind::SExpr(e_p9) => match &*e_p9.kind_p {
                        crate::syntax::ExprKind::EIf(c_pa, tb_pb, eb_oc) => {
                            let eb_ocx = eb_oc.clone();
                            let c_pax = (**c_pa).clone();
                            let tb_pbx = tb_pb.clone();
                            crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_pax.clone(), rels_p4xy.clone()), move |cond_rels_f_16555: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                                let tr_pd = cond_rels_f_16555;
                                match &eb_ocx {
                                    ::std::option::Option::Some(b_pe) => {
                                        let b_pex = b_pe.clone();
                                        crate::prelude::call_then(start_all_paths_strict_f(tb_pbx.stmts_p.clone(), v_p1xy.clone(), vi_p2xy.clone(), tr_pd.clone()), move |all_paths_strict_f_16628: bool| if all_paths_strict_f_16628 && all_paths_strict_f(&b_pex.stmts_p, &v_p1xy, &vi_p2xy, &rels_p4xy) {
                                            ::prism_rtl::Turn::Finished(true)
                                        } else {
                                            if ok_p5 && !sets_weak_f(&tb_pbx.stmts_p, &v_p1xy, &vi_p2xy, &tr_pd) {
                                                crate::prelude::call_then(start_sets_weak_f(b_pex.stmts_p.clone(), v_p1xy.clone(), vi_p2xy.clone(), rels_p4xy.clone()), move |sets_weak_f_16769: bool| ::prism_rtl::Turn::Finished(!sets_weak_f_16769))
                                            } else {
                                                ::prism_rtl::Turn::Finished(false)
                                            }
                                        })
                                    },
                                    ::std::option::Option::None => if ok_p5 {
                                        crate::prelude::call_then(start_sets_weak_f(tb_pbx.stmts_p.clone(), v_p1xy.clone(), vi_p2xy.clone(), tr_pd.clone()), move |sets_weak_f_16837: bool| ::prism_rtl::Turn::Finished(!sets_weak_f_16837))
                                    } else {
                                        ::prism_rtl::Turn::Finished(false)
                                    },
                                }
                            })
                        },
                        crate::syntax::ExprKind::EMatch(subj_pf, arms_pg) => {
                            let arms_pgx = arms_pg.clone();
                            let subj_pfx = (**subj_pf).clone();
                            crate::prelude::call_value(crate::prelude::fold_job(arms_pgx.clone(), true, {
                                let v_p1xyx = v_p1xy.clone();
                                let vi_p2xyx = vi_p2xy.clone();
                                let subj_pfxx = subj_pfx.clone();
                                let rels_p4xyx = rels_p4xy.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                    let v_p1xyxy = v_p1xyx.clone();
                                    let vi_p2xyxy = vi_p2xyx.clone();
                                    let subj_pfxxy = subj_pfxx.clone();
                                    let rels_p4xyxy = rels_p4xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let all_arms_ph = p0;
                                        let a_pi = p1;
                                        if all_arms_ph {
                                            crate::prelude::call_then(crate::check::shrink::relations::start_arm_pat_rels_f(subj_pfxxy.clone(), a_pi.clone(), rels_p4xyxy.clone()), move |arm_pat_rels_f_16997: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::More(::std::rc::Rc::new(AllPathsStrict { stmts_p0: a_pi.body_p.stmts_p.clone(), v_p1: v_p1xyxy.clone(), vi_p2: vi_p2xyxy.clone(), outer_p3: arm_pat_rels_f_16997 })))
                                        } else {
                                            ::prism_rtl::Turn::Finished(false)
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            }), move |fold_16917: bool| if fold_16917 {
                                ::prism_rtl::Turn::Finished(true)
                            } else {
                                if ok_p5 {
                                    crate::prelude::call_value(crate::prelude::fold_job(arms_pgx.clone(), false, {
                                        let v_p1xyx = v_p1xy.clone();
                                        let vi_p2xyx = vi_p2xy.clone();
                                        let subj_pfxx = subj_pfx.clone();
                                        let rels_p4xyx = rels_p4xy.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                            let v_p1xyxy = v_p1xyx.clone();
                                            let vi_p2xyxy = vi_p2xyx.clone();
                                            let subj_pfxxy = subj_pfxx.clone();
                                            let rels_p4xyxy = rels_p4xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let any_arm_pj = p0;
                                                let a_pk = p1;
                                                if any_arm_pj {
                                                    ::prism_rtl::Turn::Finished(true)
                                                } else {
                                                    crate::prelude::call_then(crate::check::shrink::relations::start_arm_pat_rels_f(subj_pfxxy.clone(), a_pk.clone(), rels_p4xyxy.clone()), move |arm_pat_rels_f_17135: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::More(::std::rc::Rc::new(SetsWeak { stmts_p0: a_pk.body_p.stmts_p.clone(), v_p1: v_p1xyxy.clone(), vi_p2: vi_p2xyxy.clone(), outer_p3: arm_pat_rels_f_17135 })))
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                    }), move |fold_17063: bool| ::prism_rtl::Turn::Finished(!fold_17063))
                                } else {
                                    ::prism_rtl::Turn::Finished(false)
                                }
                            })
                        },
                        _ => if ok_p5 {
                            crate::prelude::call_then(start_stmt_sets_weak_f(s_p6.clone(), v_p1xy.clone(), vi_p2xy.clone(), rels_p4xy.clone()), move |stmt_sets_weak_f_17197: bool| ::prism_rtl::Turn::Finished(!stmt_sets_weak_f_17197))
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        },
                    },
                    _ => if ok_p5 {
                        crate::prelude::call_then(start_stmt_sets_weak_f(s_p6.clone(), v_p1xy.clone(), vi_p2xy.clone(), rels_p4xy.clone()), move |stmt_sets_weak_f_17257: bool| ::prism_rtl::Turn::Finished(!stmt_sets_weak_f_17257))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    },
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `AllPathsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct AllPathsStrict {
    pub stmts_p0: crate::prelude::Array<crate::syntax::Stmt>,
    pub v_p1: crate::prelude::Text,
    pub vi_p2: crate::prelude::Nat,
    pub outer_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<bool> for AllPathsStrict {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let stmts_p0 = &self.stmts_p0;
        let v_p1 = &self.v_p1;
        let vi_p2 = &self.vi_p2;
        let outer_p3 = &self.outer_p3;
        let outer_p3x = outer_p3.clone();
        let stmts_p0x = stmts_p0.clone();
        let v_p1x = v_p1.clone();
        let vi_p2x = vi_p2.clone();
        crate::prelude::call_then(crate::check::shrink::relations::start_block_rels_f(stmts_p0x.clone(), outer_p3x.clone()), move |block_rels_f_16222: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
            let rels_p4 = block_rels_f_16222;
            crate::prelude::fold_job(stmts_p0x.clone(), false, {
                let v_p1xx = v_p1x.clone();
                let vi_p2xx = vi_p2x.clone();
                let rels_p4x = rels_p4.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Stmt)| {
                    let v_p1xxy = v_p1xx.clone();
                    let vi_p2xxy = vi_p2xx.clone();
                    let rels_p4xy = rels_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p5 = p0;
                        let s_p6 = p1;
                        match &s_p6.kind_p {
                            crate::syntax::StmtKind::SSet(t_p7, value_p8) => {
                                let t_p7x = t_p7.clone();
                                let value_p8x = value_p8.clone();
                                crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p7x.clone()), move |ref_path_f_16330: crate::prelude::Array<crate::prelude::Text>| if &ref_path_f_16330 == &crate::prelude::Array::from(vec![v_p1xxy.clone()]) {
                                    if is_zero_lit_f(&value_p8x) {
                                        ::prism_rtl::Turn::Finished(ok_p5)
                                    } else {
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(SetsStrict { e_p0: value_p8x.clone(), v_p1: v_p1xxy.clone(), vi_p2: vi_p2xxy.clone(), rels_p3: rels_p4xy.clone() }))
                                    }
                                } else {
                                    if ok_p5 {
                                        crate::prelude::call_then(start_stmt_sets_weak_f(s_p6.clone(), v_p1xxy.clone(), vi_p2xxy.clone(), rels_p4xy.clone()), move |stmt_sets_weak_f_16442: bool| ::prism_rtl::Turn::Finished(!stmt_sets_weak_f_16442))
                                    } else {
                                        ::prism_rtl::Turn::Finished(false)
                                    }
                                })
                            },
                            crate::syntax::StmtKind::SExpr(e_p9) => match &*e_p9.kind_p {
                                crate::syntax::ExprKind::EIf(c_pa, tb_pb, eb_oc) => {
                                    let eb_ocx = eb_oc.clone();
                                    let c_pax = (**c_pa).clone();
                                    let tb_pbx = tb_pb.clone();
                                    crate::prelude::call_then(crate::check::shrink::relations::start_cond_rels_f(c_pax.clone(), rels_p4xy.clone()), move |cond_rels_f_16555: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                                        let tr_pd = cond_rels_f_16555;
                                        match &eb_ocx {
                                            ::std::option::Option::Some(b_pe) => {
                                                let b_pex = b_pe.clone();
                                                crate::prelude::call_then(start_all_paths_strict_f(tb_pbx.stmts_p.clone(), v_p1xxy.clone(), vi_p2xxy.clone(), tr_pd.clone()), move |all_paths_strict_f_16628: bool| if all_paths_strict_f_16628 && all_paths_strict_f(&b_pex.stmts_p, &v_p1xxy, &vi_p2xxy, &rels_p4xy) {
                                                    ::prism_rtl::Turn::Finished(true)
                                                } else {
                                                    if ok_p5 && !sets_weak_f(&tb_pbx.stmts_p, &v_p1xxy, &vi_p2xxy, &tr_pd) {
                                                        crate::prelude::call_then(start_sets_weak_f(b_pex.stmts_p.clone(), v_p1xxy.clone(), vi_p2xxy.clone(), rels_p4xy.clone()), move |sets_weak_f_16769: bool| ::prism_rtl::Turn::Finished(!sets_weak_f_16769))
                                                    } else {
                                                        ::prism_rtl::Turn::Finished(false)
                                                    }
                                                })
                                            },
                                            ::std::option::Option::None => if ok_p5 {
                                                crate::prelude::call_then(start_sets_weak_f(tb_pbx.stmts_p.clone(), v_p1xxy.clone(), vi_p2xxy.clone(), tr_pd.clone()), move |sets_weak_f_16837: bool| ::prism_rtl::Turn::Finished(!sets_weak_f_16837))
                                            } else {
                                                ::prism_rtl::Turn::Finished(false)
                                            },
                                        }
                                    })
                                },
                                crate::syntax::ExprKind::EMatch(subj_pf, arms_pg) => {
                                    let arms_pgx = arms_pg.clone();
                                    let subj_pfx = (**subj_pf).clone();
                                    crate::prelude::call_value(crate::prelude::fold_job(arms_pgx.clone(), true, {
                                        let v_p1xxyx = v_p1xxy.clone();
                                        let vi_p2xxyx = vi_p2xxy.clone();
                                        let subj_pfxx = subj_pfx.clone();
                                        let rels_p4xyx = rels_p4xy.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                            let v_p1xxyxy = v_p1xxyx.clone();
                                            let vi_p2xxyxy = vi_p2xxyx.clone();
                                            let subj_pfxxy = subj_pfxx.clone();
                                            let rels_p4xyxy = rels_p4xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let all_arms_ph = p0;
                                                let a_pi = p1;
                                                if all_arms_ph {
                                                    crate::prelude::call_then(crate::check::shrink::relations::start_arm_pat_rels_f(subj_pfxxy.clone(), a_pi.clone(), rels_p4xyxy.clone()), move |arm_pat_rels_f_16997: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::More(::std::rc::Rc::new(AllPathsStrict { stmts_p0: a_pi.body_p.stmts_p.clone(), v_p1: v_p1xxyxy.clone(), vi_p2: vi_p2xxyxy.clone(), outer_p3: arm_pat_rels_f_16997 })))
                                                } else {
                                                    ::prism_rtl::Turn::Finished(false)
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                    }), move |fold_16917: bool| if fold_16917 {
                                        ::prism_rtl::Turn::Finished(true)
                                    } else {
                                        if ok_p5 {
                                            crate::prelude::call_value(crate::prelude::fold_job(arms_pgx.clone(), false, {
                                                let v_p1xxyx = v_p1xxy.clone();
                                                let vi_p2xxyx = vi_p2xxy.clone();
                                                let subj_pfxx = subj_pfx.clone();
                                                let rels_p4xyx = rels_p4xy.clone();
                                                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                                    let v_p1xxyxy = v_p1xxyx.clone();
                                                    let vi_p2xxyxy = vi_p2xxyx.clone();
                                                    let subj_pfxxy = subj_pfxx.clone();
                                                    let rels_p4xyxy = rels_p4xyx.clone();
                                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let any_arm_pj = p0;
                                                        let a_pk = p1;
                                                        if any_arm_pj {
                                                            ::prism_rtl::Turn::Finished(true)
                                                        } else {
                                                            crate::prelude::call_then(crate::check::shrink::relations::start_arm_pat_rels_f(subj_pfxxy.clone(), a_pk.clone(), rels_p4xyxy.clone()), move |arm_pat_rels_f_17135: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| ::prism_rtl::Turn::More(::std::rc::Rc::new(SetsWeak { stmts_p0: a_pk.body_p.stmts_p.clone(), v_p1: v_p1xxyxy.clone(), vi_p2: vi_p2xxyxy.clone(), outer_p3: arm_pat_rels_f_17135 })))
                                                        }
                                                    }))
                                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                            }), move |fold_17063: bool| ::prism_rtl::Turn::Finished(!fold_17063))
                                        } else {
                                            ::prism_rtl::Turn::Finished(false)
                                        }
                                    })
                                },
                                _ => if ok_p5 {
                                    crate::prelude::call_then(start_stmt_sets_weak_f(s_p6.clone(), v_p1xxy.clone(), vi_p2xxy.clone(), rels_p4xy.clone()), move |stmt_sets_weak_f_17197: bool| ::prism_rtl::Turn::Finished(!stmt_sets_weak_f_17197))
                                } else {
                                    ::prism_rtl::Turn::Finished(false)
                                },
                            },
                            _ => if ok_p5 {
                                crate::prelude::call_then(start_stmt_sets_weak_f(s_p6.clone(), v_p1xxy.clone(), vi_p2xxy.clone(), rels_p4xy.clone()), move |stmt_sets_weak_f_17257: bool| ::prism_rtl::Turn::Finished(!stmt_sets_weak_f_17257))
                            } else {
                                ::prism_rtl::Turn::Finished(false)
                            },
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle()
        })
    }
}

/// `Start AllPathsStrict, x`: what the function value is when passed to `@Run`.
pub fn start_all_paths_strict_f(stmts_p0: crate::prelude::Array<crate::syntax::Stmt>, v_p1: crate::prelude::Text, vi_p2: crate::prelude::Nat, outer_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(AllPathsStrict { stmts_p0, v_p1, vi_p2, outer_p3 })
}

/// ```prism
/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn sets_weak_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>, v_p1: &crate::prelude::Text, vi_p2: &crate::prelude::Nat, outer_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmts_spots_f(stmts_p0, outer_p3), false, {
        let v_p1x = v_p1.clone();
        let vi_p2x = vi_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
            let v_p1xy = v_p1x.clone();
            let vi_p2xy = vi_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_p4 = p0;
                let sp_p5 = p1;
                if seen_p4 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SpotSetsWeak { spot0: sp_p5.clone(), text1: v_p1xy.clone(), n2: vi_p2xy.clone() }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `SetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct SetsWeak {
    pub stmts_p0: crate::prelude::Array<crate::syntax::Stmt>,
    pub v_p1: crate::prelude::Text,
    pub vi_p2: crate::prelude::Nat,
    pub outer_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<bool> for SetsWeak {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let stmts_p0 = &self.stmts_p0;
        let v_p1 = &self.v_p1;
        let vi_p2 = &self.vi_p2;
        let outer_p3 = &self.outer_p3;
        let outer_p3x = outer_p3.clone();
        let stmts_p0x = stmts_p0.clone();
        let v_p1x = v_p1.clone();
        let vi_p2x = vi_p2.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_stmts_spots_f(stmts_p0x.clone(), outer_p3x.clone()), move |stmts_spots_f_17564: crate::prelude::Array<crate::check::shrink::walk::Spot>| crate::prelude::fold_job(stmts_spots_f_17564, false, {
            let v_p1xx = v_p1x.clone();
            let vi_p2xx = vi_p2x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                let v_p1xxy = v_p1xx.clone();
                let vi_p2xxy = vi_p2xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_p4 = p0;
                    let sp_p5 = p1;
                    if seen_p4 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(SpotSetsWeak { spot0: sp_p5.clone(), text1: v_p1xxy.clone(), n2: vi_p2xxy.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start SetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_sets_weak_f(stmts_p0: crate::prelude::Array<crate::syntax::Stmt>, v_p1: crate::prelude::Text, vi_p2: crate::prelude::Nat, outer_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(SetsWeak { stmts_p0, v_p1, vi_p2, outer_p3 })
}

/// ```prism
/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn stmt_sets_weak_f(s_p0: &crate::syntax::Stmt, v_p1: &crate::prelude::Text, vi_p2: &crate::prelude::Nat, rels_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::stmt_spots_f(s_p0, rels_p3), false, {
        let v_p1x = v_p1.clone();
        let vi_p2x = vi_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
            let v_p1xy = v_p1x.clone();
            let vi_p2xy = vi_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_p4 = p0;
                let sp_p5 = p1;
                if seen_p4 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SpotSetsWeak { spot0: sp_p5.clone(), text1: v_p1xy.clone(), n2: vi_p2xy.clone() }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `StmtSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct StmtSetsWeak {
    pub s_p0: crate::syntax::Stmt,
    pub v_p1: crate::prelude::Text,
    pub vi_p2: crate::prelude::Nat,
    pub rels_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<bool> for StmtSetsWeak {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let s_p0 = &self.s_p0;
        let v_p1 = &self.v_p1;
        let vi_p2 = &self.vi_p2;
        let rels_p3 = &self.rels_p3;
        let rels_p3x = rels_p3.clone();
        let s_p0x = s_p0.clone();
        let v_p1x = v_p1.clone();
        let vi_p2x = vi_p2.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_stmt_spots_f(s_p0x.clone(), rels_p3x.clone()), move |stmt_spots_f_17747: crate::prelude::Array<crate::check::shrink::walk::Spot>| crate::prelude::fold_job(stmt_spots_f_17747, false, {
            let v_p1xx = v_p1x.clone();
            let vi_p2xx = vi_p2x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                let v_p1xxy = v_p1xx.clone();
                let vi_p2xxy = vi_p2xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_p4 = p0;
                    let sp_p5 = p1;
                    if seen_p4 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(SpotSetsWeak { spot0: sp_p5.clone(), text1: v_p1xxy.clone(), n2: vi_p2xxy.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::shrink::walk::Spot)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start StmtSetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_sets_weak_f(s_p0: crate::syntax::Stmt, v_p1: crate::prelude::Text, vi_p2: crate::prelude::Nat, rels_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(StmtSetsWeak { s_p0, v_p1, vi_p2, rels_p3 })
}

/// ```prism
/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub fn spot_sets_weak_f(spot0: &crate::check::shrink::walk::Spot, text1: &crate::prelude::Text, n2: &crate::prelude::Nat) -> bool {
    match (spot0, text1, n2) {
        (crate::check::shrink::walk::Spot::SpotStmt(s_p0, m_p1), v_p2, vi_p3) => match &s_p0.kind_p {
            crate::syntax::StmtKind::SSet(t_p4, value_p5) => ((&crate::prelude::take(&crate::check::passes::borrows::ref_path_f(t_p4), &crate::prelude::Nat::from(1u32)) == &crate::prelude::Array::from(vec![v_p2.clone()])) && !sets_strict_f(value_p5, v_p2, vi_p3, m_p1)) && !((&crate::check::passes::borrows::ref_path_f(t_p4) == &crate::prelude::Array::from(vec![v_p2.clone()])) && is_zero_lit_f(value_p5)),
            crate::syntax::StmtKind::SAccum(t_p6, _, _) => &crate::prelude::take(&crate::check::passes::borrows::ref_path_f(t_p6), &crate::prelude::Nat::from(1u32)) == &crate::prelude::Array::from(vec![v_p2.clone()]),
            _ => false,
        },
        (crate::check::shrink::walk::Spot::SpotExpr(_, _), _, _) => false,
    }
}

/// The step machine of `SpotSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub struct SpotSetsWeak {
    pub spot0: crate::check::shrink::walk::Spot,
    pub text1: crate::prelude::Text,
    pub n2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<bool> for SpotSetsWeak {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let spot0 = &self.spot0;
        let text1 = &self.text1;
        let n2 = &self.n2;
        match (spot0, text1, n2) {
            (crate::check::shrink::walk::Spot::SpotStmt(s_p0, m_p1), v_p2, vi_p3) => match &s_p0.kind_p {
                crate::syntax::StmtKind::SSet(t_p4, value_p5) => {
                    let m_p1x = m_p1.clone();
                    let t_p4x = t_p4.clone();
                    let v_p2x = v_p2.clone();
                    let value_p5x = value_p5.clone();
                    let vi_p3x = vi_p3.clone();
                    crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p4x.clone()), move |ref_path_f_17950: crate::prelude::Array<crate::prelude::Text>| if (&crate::prelude::take(&ref_path_f_17950, &crate::prelude::Nat::from(1u32)) == &crate::prelude::Array::from(vec![v_p2x.clone()])) && !sets_strict_f(&value_p5x, &v_p2x, &vi_p3x, &m_p1x) {
                        crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p4x.clone()), move |ref_path_f_18021: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(!((&ref_path_f_18021 == &crate::prelude::Array::from(vec![v_p2x.clone()])) && is_zero_lit_f(&value_p5x))))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    })
                },
                crate::syntax::StmtKind::SAccum(t_p6, _, _) => {
                    let t_p6x = t_p6.clone();
                    let v_p2x = v_p2.clone();
                    crate::prelude::call_then(crate::check::passes::borrows::start_ref_path_f(t_p6x.clone()), move |ref_path_f_18099: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(&crate::prelude::take(&ref_path_f_18099, &crate::prelude::Nat::from(1u32)) == &crate::prelude::Array::from(vec![v_p2x.clone()])))
                },
                _ => ::prism_rtl::Turn::Finished(false),
            },
            (crate::check::shrink::walk::Spot::SpotExpr(_, _), _, _) => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start SpotSetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_spot_sets_weak_f(spot0: crate::check::shrink::walk::Spot, text1: crate::prelude::Text, n2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(SpotSetsWeak { spot0, text1, n2 })
}

/// ```prism
/// IsZeroLit: fn Expr -> Bool
/// ```
pub fn is_zero_lit_f(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ELit(l_p1) => match &l_p1.kind_p {
            crate::syntax::LitKind::LInt(d_p2) => d_p2 == &crate::prelude::Text::lit("0"),
            _ => false,
        },
        crate::syntax::ExprKind::EGroup(x_p3) => is_zero_lit_f(&**x_p3),
        _ => false,
    }
}

/// ```prism
/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn sets_strict_f(e_p0: &crate::syntax::Expr, v_p1: &crate::prelude::Text, vi_p2: &crate::prelude::Nat, rels_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::EGroup(x_p4) => sets_strict_f(&**x_p4, v_p1, vi_p2, rels_p3),
        crate::syntax::ExprKind::EBinary(m19476_1_0, l_p5, _) if (m19476_1_0 == &crate::prelude::Text::lit("-?")) => is_nat_minus_f(rels_p3, e_p0) && sets_strict_f(&**l_p5, v_p1, vi_p2, rels_p3),
        _ => rel_strict_f(rels_p3, e_p0, vi_p2) || call_strict_f(e_p0, v_p1, vi_p2, rels_p3),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SetsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct SetsStrict {
    pub e_p0: crate::syntax::Expr,
    pub v_p1: crate::prelude::Text,
    pub vi_p2: crate::prelude::Nat,
    pub rels_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<bool> for SetsStrict {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let e_p0 = &self.e_p0;
        let v_p1 = &self.v_p1;
        let vi_p2 = &self.vi_p2;
        let rels_p3 = &self.rels_p3;
        match &*e_p0.kind_p {
            crate::syntax::ExprKind::EGroup(x_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(SetsStrict { e_p0: (**x_p4).clone(), v_p1: v_p1.clone(), vi_p2: vi_p2.clone(), rels_p3: rels_p3.clone() })),
            crate::syntax::ExprKind::EBinary(m19476_1_0, l_p5, _) if (m19476_1_0 == &crate::prelude::Text::lit("-?")) => if is_nat_minus_f(rels_p3, e_p0) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(SetsStrict { e_p0: (**l_p5).clone(), v_p1: v_p1.clone(), vi_p2: vi_p2.clone(), rels_p3: rels_p3.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(false)
            },
            _ => {
                let e_p0x = e_p0.clone();
                let rels_p3x = rels_p3.clone();
                let v_p1x = v_p1.clone();
                let vi_p2x = vi_p2.clone();
                crate::prelude::call_then(start_rel_strict_f(rels_p3x.clone(), e_p0x.clone(), vi_p2x.clone()), move |rel_strict_f_19626: bool| if rel_strict_f_19626 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(CallStrict { e_p0: e_p0x.clone(), v_p1: v_p1x.clone(), vi_p2: vi_p2x.clone(), rels_p3: rels_p3x.clone() }))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SetsStrict, x`: what the function value is when passed to `@Run`.
pub fn start_sets_strict_f(e_p0: crate::syntax::Expr, v_p1: crate::prelude::Text, vi_p2: crate::prelude::Nat, rels_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(SetsStrict { e_p0, v_p1, vi_p2, rels_p3 })
}

/// ```prism
/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
/// ```
pub fn rel_strict_f(rels_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, e_p1: &crate::syntax::Expr, vi_p2: &crate::prelude::Nat) -> bool {
    match crate::check::shrink::walk::rel_of_o(rels_p0, e_p1) {
        ::std::option::Option::Some(r_p3) => r_p3.strict_p && (&r_p3.param_p == vi_p2),
        ::std::option::Option::None => false,
    }
}

/// The step machine of `RelStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
/// ```
pub struct RelStrict {
    pub rels_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub e_p1: crate::syntax::Expr,
    pub vi_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<bool> for RelStrict {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let rels_p0 = &self.rels_p0;
        let e_p1 = &self.e_p1;
        let vi_p2 = &self.vi_p2;
        let e_p1x = e_p1.clone();
        let rels_p0x = rels_p0.clone();
        let vi_p2x = vi_p2.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(rels_p0x.clone(), e_p1x.clone()), move |rel_of_o_19772: ::std::option::Option<crate::check::shrink::Rel>| match rel_of_o_19772 {
            ::std::option::Option::Some(r_p3) => ::prism_rtl::Turn::Finished(r_p3.strict_p && (&r_p3.param_p == &vi_p2x)),
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start RelStrict, x`: what the function value is when passed to `@Run`.
pub fn start_rel_strict_f(rels_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, e_p1: crate::syntax::Expr, vi_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(RelStrict { rels_p0, e_p1, vi_p2 })
}

/// ```prism
/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn call_strict_f(e_p0: &crate::syntax::Expr, v_p1: &crate::prelude::Text, vi_p2: &crate::prelude::Nat, rels_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> bool {
    match crate::check::shrink::walk::call_of_o(e_p0) {
        ::std::option::Option::Some((c_p4, args_p5)) => if crate::check::shrink::walk::is_non_nat_min_f(rels_p3, e_p0, &c_p4) {
            false
        } else {
            match crate::check::shrink::walk::no_larger_arg_o(rels_p3, &c_p4, &args_p5) {
                ::std::option::Option::Some(a_p6) => sets_strict_f(&a_p6, v_p1, vi_p2, rels_p3),
                ::std::option::Option::None => false,
            }
        },
        ::std::option::Option::None => false,
    }
}

/// The step machine of `CallStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct CallStrict {
    pub e_p0: crate::syntax::Expr,
    pub v_p1: crate::prelude::Text,
    pub vi_p2: crate::prelude::Nat,
    pub rels_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
}

impl ::prism_rtl::Job<bool> for CallStrict {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let e_p0 = &self.e_p0;
        let v_p1 = &self.v_p1;
        let vi_p2 = &self.vi_p2;
        let rels_p3 = &self.rels_p3;
        match crate::check::shrink::walk::call_of_o(e_p0) {
            ::std::option::Option::Some((c_p4, args_p5)) => if crate::check::shrink::walk::is_non_nat_min_f(rels_p3, e_p0, &c_p4) {
                ::prism_rtl::Turn::Finished(false)
            } else {
                match crate::check::shrink::walk::no_larger_arg_o(rels_p3, &c_p4, &args_p5) {
                    ::std::option::Option::Some(a_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(SetsStrict { e_p0: a_p6.clone(), v_p1: v_p1.clone(), vi_p2: vi_p2.clone(), rels_p3: rels_p3.clone() })),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                }
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start CallStrict, x`: what the function value is when passed to `@Run`.
pub fn start_call_strict_f(e_p0: crate::syntax::Expr, v_p1: crate::prelude::Text, vi_p2: crate::prelude::Nat, rels_p3: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(CallStrict { e_p0, v_p1, vi_p2, rels_p3 })
}
