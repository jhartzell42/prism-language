//! The module `Check.Shrink.Summaries`, from `target/bootstrap/src/prismc/check/shrink/summaries.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
/// ```
pub fn parts_summaries(sk: &crate::check::shrink::Shrink, fns: &Array<crate::check::env::Def>) -> Map<Text, Nat> {
    run_to_end(fold_job(fns.clone(), Map::new(), {
        let sk = sk.clone();
        Rc::new(move |(p0, p1): (Map<Text, Nat>, crate::check::env::Def)| {
            let sk = sk.clone();
            entered(once_job(move || {
                let m = p0;
                let d = p1;
                match &d.body {
                    crate::check::env::DefBody::DbFn(clauses) => {
                        let n = match index(clauses, &Nat::from(0u32)) {
                            Some(c0) => len(&c0.params),
                            None => Nat::from(0u32),
                        };
                        let clauses = clauses.clone();
                        call_value(filter_job(crate::check::errors::range0(&n), {
                            let clauses = clauses.clone();
                            let sk = sk.clone();
                            let d = d.clone();
                            Rc::new(move |p0: Nat| {
                                let clauses = clauses.clone();
                                let sk = sk.clone();
                                let d = d.clone();
                                entered(once_job(move || {
                                    let i = p0;
                                    fold_job(clauses.clone(), true, {
                                        let sk = sk.clone();
                                        let d = d.clone();
                                        let i = i.clone();
                                        Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                                            let sk = sk.clone();
                                            let d = d.clone();
                                            let i = i.clone();
                                            entered(once_job(move || {
                                                let okc = p0;
                                                let c = p1;
                                                prism_rtl::Turn::Finished(okc && clause_within(&crate::check::shrink::locals::clause_base(&sk, &d, &c), &c, &i))
                                            }))
                                        }) as Rc<dyn Fn((bool, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }).cycle()
                                }))
                            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |filter_2084: Array<Nat>| {
                            let ok_ = filter_2084;
                            match index(&ok_, &Nat::from(0u32)) {
                                Some(i) => prism_rtl::Turn::Finished(insert(&m, &d.qk, &i)),
                                None => prism_rtl::Turn::Finished(m.clone()),
                            }
                        })
                    },
                    _ => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Nat>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
    }))
}

/// The step machine of `PartsSummaries`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
/// ```
pub struct PartsSummaries {
    pub sk: crate::check::shrink::Shrink,
    pub fns: Array<crate::check::env::Def>,
}

impl prism_rtl::Job<Map<Text, Nat>> for PartsSummaries {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Nat>> {
        let sk = &self.sk;
        let fns = &self.fns;
        fold_job(fns.clone(), Map::new(), {
            let sk = sk.clone();
            Rc::new(move |(p0, p1): (Map<Text, Nat>, crate::check::env::Def)| {
                let sk = sk.clone();
                entered(once_job(move || {
                    let m = p0;
                    let d = p1;
                    match &d.body {
                        crate::check::env::DefBody::DbFn(clauses) => {
                            let n = match index(clauses, &Nat::from(0u32)) {
                                Some(c0) => len(&c0.params),
                                None => Nat::from(0u32),
                            };
                            let clauses = clauses.clone();
                            call_value(filter_job(crate::check::errors::range0(&n), {
                                let clauses = clauses.clone();
                                let sk = sk.clone();
                                let d = d.clone();
                                Rc::new(move |p0: Nat| {
                                    let clauses = clauses.clone();
                                    let sk = sk.clone();
                                    let d = d.clone();
                                    entered(once_job(move || {
                                        let i = p0;
                                        fold_job(clauses.clone(), true, {
                                            let sk = sk.clone();
                                            let d = d.clone();
                                            let i = i.clone();
                                            Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                                                let sk = sk.clone();
                                                let d = d.clone();
                                                let i = i.clone();
                                                entered(once_job(move || {
                                                    let okc = p0;
                                                    let c = p1;
                                                    prism_rtl::Turn::Finished(okc && clause_within(&crate::check::shrink::locals::clause_base(&sk, &d, &c), &c, &i))
                                                }))
                                            }) as Rc<dyn Fn((bool, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
                                        }).cycle()
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<bool>>>
                            }), move |filter_2084: Array<Nat>| {
                                let ok_ = filter_2084;
                                match index(&ok_, &Nat::from(0u32)) {
                                    Some(i) => prism_rtl::Turn::Finished(insert(&m, &d.qk, &i)),
                                    None => prism_rtl::Turn::Finished(m.clone()),
                                }
                            })
                        },
                        _ => prism_rtl::Turn::Finished(m.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Nat>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
        }).cycle()
    }
}

/// `Start PartsSummaries, x`: what the function value is when passed to `@Run`.
pub fn start_parts_summaries(sk: crate::check::shrink::Shrink, fns: Array<crate::check::env::Def>) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>> {
    Rc::new(PartsSummaries { sk, fns })
}

/// ```prism
/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
/// ```
pub fn clause_within(base: &Map<Text, crate::check::shrink::Rel>, c: &crate::syntax::decls::FnClause, i: &Nat) -> bool {
    match &c.body {
        crate::syntax::decls::FnBody::BodyExpr(e) => within(base, i, e),
        crate::syntax::decls::FnBody::BodyBlock(b) => within_block(base, i, b),
    }
}

/// The step machine of `ClauseWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
/// ```
pub struct ClauseWithin {
    pub base: Map<Text, crate::check::shrink::Rel>,
    pub c: crate::syntax::decls::FnClause,
    pub i: Nat,
}

impl prism_rtl::Job<bool> for ClauseWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let base = &self.base;
        let c = &self.c;
        let i = &self.i;
        match &c.body {
            crate::syntax::decls::FnBody::BodyExpr(e) => prism_rtl::Turn::More(Rc::new(Within { m: base.clone(), i: i.clone(), e: e.clone() })),
            crate::syntax::decls::FnBody::BodyBlock(b) => prism_rtl::Turn::More(Rc::new(WithinBlock { m: base.clone(), i: i.clone(), b: b.clone() })),
        }
    }
}

/// `Start ClauseWithin, x`: what the function value is when passed to `@Run`.
pub fn start_clause_within(base: Map<Text, crate::check::shrink::Rel>, c: crate::syntax::decls::FnClause, i: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(ClauseWithin { base, c, i })
}

/// ```prism
/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub fn within(m: &Map<Text, crate::check::shrink::Rel>, i: &Nat, e: &crate::syntax::Expr) -> bool {
    match crate::check::shrink::walk::rel_of(m, e) {
        Some(r) => &r.param == i,
        None => match &*e.kind {
            crate::syntax::ExprKind::EArray(es) => run_to_end(fold_job(es.clone(), true, {
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok_ = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(ok_ && part(&m, &i, &x))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
            })),
            crate::syntax::ExprKind::EMap(kvs) => run_to_end(fold_job(kvs.clone(), true, {
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, (crate::syntax::Expr, crate::syntax::Expr))| {
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok_ = p0;
                        let (k, v_) = p1;
                        prism_rtl::Turn::Finished((ok_ && part(&m, &i, &k)) && part(&m, &i, &v_))
                    }))
                }) as Rc<dyn Fn((bool, (crate::syntax::Expr, crate::syntax::Expr))) -> Rc<dyn prism_rtl::Job<bool>>>
            })),
            crate::syntax::ExprKind::EGroup(x) => within(m, i, &**x),
            crate::syntax::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), true, {
                let s = (**s).clone();
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                    let s = s.clone();
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok_ = p0;
                        let a = p1;
                        prism_rtl::Turn::Finished(ok_ && within_block(&crate::check::shrink::relations::arm_pat_rels(&s, &a, &m), &i, &a.body))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
            })),
            crate::syntax::ExprKind::EIf(c, t, Some(el)) => within_block(&crate::check::shrink::relations::cond_rels(&**c, m), i, t) && within_block(m, i, el),
            crate::syntax::ExprKind::EUpdate(start, b) => within(m, i, &**start) && update_within(&insert(m, &Text::lit("&_"), &crate::check::shrink::Rel { param: i.clone(), strict: false }), i, b),
            _ => match crate::check::shrink::walk::call_of(e) {
                Some((c, args)) => match crate::check::shrink::walk::traversal_of(m, &c, &args) {
                    Some((coll, step_, at_)) => within(m, i, &coll) && step_within(m, i, &crate::check::shrink::locals::expr_name(&c), &coll, &step_, &at_, &or(&index(&args, &Nat::from(1u32)), &dummy_arg()).value),
                    None => false,
                },
                None => false,
            },
        },
    }
}

/// The step machine of `Within`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub struct Within {
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub i: Nat,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for Within {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let e = &self.e;
        let e = e.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(crate::check::shrink::walk::start_rel_of(m.clone(), e.clone()), move |rel_of_2544: Option<crate::check::shrink::Rel>| match rel_of_2544 {
            Some(r) => prism_rtl::Turn::Finished(&r.param == &i),
            None => match &*e.kind {
                crate::syntax::ExprKind::EArray(es) => fold_job(es.clone(), true, {
                    let m = m.clone();
                    let i = i.clone();
                    Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                        let m = m.clone();
                        let i = i.clone();
                        entered(once_job(move || {
                            let ok_ = p0;
                            let x = p1;
                            prism_rtl::Turn::Finished(ok_ && part(&m, &i, &x))
                        }))
                    }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle(),
                crate::syntax::ExprKind::EMap(kvs) => fold_job(kvs.clone(), true, {
                    let m = m.clone();
                    let i = i.clone();
                    Rc::new(move |(p0, p1): (bool, (crate::syntax::Expr, crate::syntax::Expr))| {
                        let m = m.clone();
                        let i = i.clone();
                        entered(once_job(move || {
                            let ok_ = p0;
                            let (k, v_) = p1;
                            prism_rtl::Turn::Finished((ok_ && part(&m, &i, &k)) && part(&m, &i, &v_))
                        }))
                    }) as Rc<dyn Fn((bool, (crate::syntax::Expr, crate::syntax::Expr))) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle(),
                crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(Within { m: m.clone(), i: i.clone(), e: (**x).clone() })),
                crate::syntax::ExprKind::EMatch(s, arms) => fold_job(arms.clone(), true, {
                    let s = (**s).clone();
                    let m = m.clone();
                    let i = i.clone();
                    Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                        let s = s.clone();
                        let m = m.clone();
                        let i = i.clone();
                        entered(once_job(move || {
                            let ok_ = p0;
                            let a = p1;
                            prism_rtl::Turn::Finished(ok_ && within_block(&crate::check::shrink::relations::arm_pat_rels(&s, &a, &m), &i, &a.body))
                        }))
                    }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle(),
                crate::syntax::ExprKind::EIf(c, t, Some(el)) => {
                    let c = (**c).clone();
                    let el = el.clone();
                    let t = t.clone();
                    call_then(crate::check::shrink::relations::start_cond_rels(c.clone(), m.clone()), move |cond_rels_2928: Map<Text, crate::check::shrink::Rel>| call_then(start_within_block(cond_rels_2928, i.clone(), t.clone()), move |within_block_2915: bool| prism_rtl::Turn::Finished(within_block_2915 && within_block(&m, &i, &el))))
                },
                crate::syntax::ExprKind::EUpdate(start, b) => {
                    let b = b.clone();
                    let start = (**start).clone();
                    call_then(start_within(m.clone(), i.clone(), start.clone()), move |within_3002: bool| prism_rtl::Turn::Finished(within_3002 && update_within(&insert(&m, &Text::lit("&_"), &crate::check::shrink::Rel { param: i.clone(), strict: false }), &i, &b)))
                },
                _ => match crate::check::shrink::walk::call_of(&e) {
                    Some((c, args)) => match crate::check::shrink::walk::traversal_of(&m, &c, &args) {
                        Some((coll, step_, at_)) => call_then(start_within(m.clone(), i.clone(), coll.clone()), move |within_3223: bool| prism_rtl::Turn::Finished(within_3223 && step_within(&m, &i, &crate::check::shrink::locals::expr_name(&c), &coll, &step_, &at_, &or(&index(&args, &Nat::from(1u32)), &dummy_arg()).value))),
                        None => prism_rtl::Turn::Finished(false),
                    },
                    None => prism_rtl::Turn::Finished(false),
                },
            },
        })
    }
}

/// `Start Within, x`: what the function value is when passed to `@Run`.
pub fn start_within(m: Map<Text, crate::check::shrink::Rel>, i: Nat, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Within { m, i, e })
}

/// ```prism
/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub fn update_within(m: &Map<Text, crate::check::shrink::Rel>, i: &Nat, b: &crate::syntax::Block) -> bool {
    run_to_end(fold_job(crate::check::shrink::walk::stmts_spots(&b.stmts, m), true, {
        let i = i.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
            let i = i.clone();
            entered(once_job(move || {
                let ok_ = p0;
                let sp = p1;
                prism_rtl::Turn::Finished(ok_ && spot_keeps_within(&sp, &i))
            }))
        }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `UpdateWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub struct UpdateWithin {
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub i: Nat,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<bool> for UpdateWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let b = &self.b;
        let b = b.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(crate::check::shrink::walk::start_stmts_spots(b.stmts.clone(), m.clone()), move |stmts_spots_3685: Array<crate::check::shrink::walk::Spot>| fold_job(stmts_spots_3685, true, {
            let i = i.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                let i = i.clone();
                entered(once_job(move || {
                    let ok_ = p0;
                    let sp = p1;
                    prism_rtl::Turn::Finished(ok_ && spot_keeps_within(&sp, &i))
                }))
            }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start UpdateWithin, x`: what the function value is when passed to `@Run`.
pub fn start_update_within(m: Map<Text, crate::check::shrink::Rel>, i: Nat, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(UpdateWithin { m, i, b })
}

/// ```prism
/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
/// ```
pub fn spot_keeps_within(spot0: &crate::check::shrink::walk::Spot, n1: &Nat) -> bool {
    match (spot0, n1) {
        (crate::check::shrink::walk::Spot::SpotStmt(s, m), i) => match &s.kind {
            crate::syntax::StmtKind::SSet(t, value) => if &take(&crate::check::passes::borrows::ref_path(t), &Nat::from(1u32)) != &Array::from(vec![Text::lit("&_")]) {
                true
            } else {
                (&crate::check::passes::borrows::ref_path(t) == &Array::from(vec![Text::lit("&_")])) && within(m, i, value)
            },
            crate::syntax::StmtKind::SAccum(t, _, _) => &take(&crate::check::passes::borrows::ref_path(t), &Nat::from(1u32)) != &Array::from(vec![Text::lit("&_")]),
            _ => true,
        },
        (crate::check::shrink::walk::Spot::SpotExpr(_, _), _) => true,
    }
}

/// The step machine of `SpotKeepsWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
/// ```
pub struct SpotKeepsWithin {
    pub spot0: crate::check::shrink::walk::Spot,
    pub n1: Nat,
}

impl prism_rtl::Job<bool> for SpotKeepsWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let spot0 = &self.spot0;
        let n1 = &self.n1;
        match (spot0, n1) {
            (crate::check::shrink::walk::Spot::SpotStmt(s, m), i) => match &s.kind {
                crate::syntax::StmtKind::SSet(t, value) => {
                    let i = i.clone();
                    let m = m.clone();
                    let t = t.clone();
                    let value = value.clone();
                    call_then(crate::check::passes::borrows::start_ref_path(t.clone()), move |ref_path_3894: Array<Text>| if &take(&ref_path_3894, &Nat::from(1u32)) != &Array::from(vec![Text::lit("&_")]) {
                        prism_rtl::Turn::Finished(true)
                    } else {
                        call_then(crate::check::passes::borrows::start_ref_path(t.clone()), move |ref_path_3942: Array<Text>| prism_rtl::Turn::Finished((&ref_path_3942 == &Array::from(vec![Text::lit("&_")])) && within(&m, &i, &value)))
                    })
                },
                crate::syntax::StmtKind::SAccum(t, _, _) => {
                    let t = t.clone();
                    call_then(crate::check::passes::borrows::start_ref_path(t.clone()), move |ref_path_4025: Array<Text>| prism_rtl::Turn::Finished(&take(&ref_path_4025, &Nat::from(1u32)) != &Array::from(vec![Text::lit("&_")])))
                },
                _ => prism_rtl::Turn::Finished(true),
            },
            (crate::check::shrink::walk::Spot::SpotExpr(_, _), _) => prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start SpotKeepsWithin, x`: what the function value is when passed to `@Run`.
pub fn start_spot_keeps_within(spot0: crate::check::shrink::walk::Spot, n1: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SpotKeepsWithin { spot0, n1 })
}

/// ```prism
/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub fn within_block(m: &Map<Text, crate::check::shrink::Rel>, i: &Nat, b: &crate::syntax::Block) -> bool {
    within(&crate::check::shrink::relations::block_rels(&b.stmts, m), i, &last_or(b))
}

/// The step machine of `WithinBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub struct WithinBlock {
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub i: Nat,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<bool> for WithinBlock {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let b = &self.b;
        let b = b.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(crate::check::shrink::relations::start_block_rels(b.stmts.clone(), m.clone()), move |block_rels_4289: Map<Text, crate::check::shrink::Rel>| prism_rtl::Turn::More(Rc::new(Within { m: block_rels_4289, i: i.clone(), e: last_or(&b) })))
    }
}

/// `Start WithinBlock, x`: what the function value is when passed to `@Run`.
pub fn start_within_block(m: Map<Text, crate::check::shrink::Rel>, i: Nat, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(WithinBlock { m, i, b })
}

/// ```prism
/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
/// ```
pub fn step_within(m: &Map<Text, crate::check::shrink::Rel>, i: &Nat, f: &Text, coll: &crate::syntax::Expr, step_: &crate::syntax::Expr, at_: &Nat, z: &crate::syntax::Expr) -> bool {
    if crate::check::shrink::relations::pre_is(m, f, &Text::lit("Filter")) {
        true
    } else {
        match &*step_.kind {
            crate::syntax::ExprKind::ELambda(Some(ps), body) => {
                let sm = crate::check::shrink::relations::step_rels(m, coll, ps, at_);
                let (bm, x) = match &**body {
                    crate::syntax::LambdaBody::LbExpr(y) => (sm.clone(), (**y).clone()),
                    crate::syntax::LambdaBody::LbBlock(b) => (crate::check::shrink::relations::block_rels(&b.stmts, &sm), last_or(b)),
                };
                if crate::check::shrink::relations::pre_is(m, f, &Text::lit("Each")) {
                    part(&bm, i, &x)
                } else {
                    match index(ps, &Nat::from(0u32)) {
                        Some(acc) => match &*acc.kind {
                            crate::syntax::PatternKind::PName(n) => within(m, i, z) && builds_on(&bm, i, &crate::check::env::sname_key(n), &x),
                            _ => false,
                        },
                        None => false,
                    }
                }
            },
            _ => false,
        }
    }
}

/// The step machine of `StepWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
/// ```
pub struct StepWithin {
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub i: Nat,
    pub f: Text,
    pub coll: crate::syntax::Expr,
    pub step_: crate::syntax::Expr,
    pub at_: Nat,
    pub z: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for StepWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let f = &self.f;
        let coll = &self.coll;
        let step_ = &self.step_;
        let at_ = &self.at_;
        let z = &self.z;
        if crate::check::shrink::relations::pre_is(m, f, &Text::lit("Filter")) {
            prism_rtl::Turn::Finished(true)
        } else {
            match &*step_.kind {
                crate::syntax::ExprKind::ELambda(Some(ps), body) => {
                    let at_ = at_.clone();
                    let body = (**body).clone();
                    let coll = coll.clone();
                    let f = f.clone();
                    let i = i.clone();
                    let m = m.clone();
                    let ps = ps.clone();
                    let z = z.clone();
                    call_then(crate::check::shrink::relations::start_step_rels(m.clone(), coll.clone(), ps.clone(), at_.clone()), move |step_rels_4719: Map<Text, crate::check::shrink::Rel>| {
                        let sm = step_rels_4719;
                        let (bm, x) = match &body {
                            crate::syntax::LambdaBody::LbExpr(y) => (sm.clone(), (**y).clone()),
                            crate::syntax::LambdaBody::LbBlock(b) => (crate::check::shrink::relations::block_rels(&b.stmts, &sm), last_or(b)),
                        };
                        if crate::check::shrink::relations::pre_is(&m, &f, &Text::lit("Each")) {
                            prism_rtl::Turn::More(Rc::new(Part { m: bm.clone(), i: i.clone(), e: x.clone() }))
                        } else {
                            match index(&ps, &Nat::from(0u32)) {
                                Some(acc) => match &*acc.kind {
                                    crate::syntax::PatternKind::PName(n) => {
                                        let n = n.clone();
                                        call_then(start_within(m.clone(), i.clone(), z.clone()), move |within_5036: bool| prism_rtl::Turn::Finished(within_5036 && builds_on(&bm, &i, &crate::check::env::sname_key(&n), &x)))
                                    },
                                    _ => prism_rtl::Turn::Finished(false),
                                },
                                None => prism_rtl::Turn::Finished(false),
                            }
                        }
                    })
                },
                _ => prism_rtl::Turn::Finished(false),
            }
        }
    }
}

/// `Start StepWithin, x`: what the function value is when passed to `@Run`.
pub fn start_step_within(m: Map<Text, crate::check::shrink::Rel>, i: Nat, f: Text, coll: crate::syntax::Expr, step_: crate::syntax::Expr, at_: Nat, z: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(StepWithin { m, i, f, coll, step_, at_, z })
}

/// ```prism
/// LastOr: fn Block -> Expr
/// ```
pub fn last_or(b: &crate::syntax::Block) -> crate::syntax::Expr {
    or(&crate::check::shrink::walk::last_expr(b), &dummy_arg().value)
}

/// ```prism
/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
/// ```
pub fn builds_on(m: &Map<Text, crate::check::shrink::Rel>, i: &Nat, acc: &Text, e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => &crate::check::env::sname_key(n) == acc,
        crate::syntax::ExprKind::EGroup(x) => builds_on(m, i, acc, &**x),
        crate::syntax::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), true, {
            let acc = acc.clone();
            let s = (**s).clone();
            let m = m.clone();
            let i = i.clone();
            Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                let acc = acc.clone();
                let s = s.clone();
                let m = m.clone();
                let i = i.clone();
                entered(once_job(move || {
                    let ok_ = p0;
                    let a = p1;
                    prism_rtl::Turn::Finished((ok_ && !crate::check::types::has_text(&opt_names(&a.pattern), &acc)) && builds_on_block(&crate::check::shrink::relations::arm_pat_rels(&s, &a, &m), &i, &acc, &a.body))
                }))
            }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::syntax::ExprKind::EIf(c, t, Some(el)) => (!crate::check::types::has_text(&cond_names(&**c), acc) && builds_on_block(&crate::check::shrink::relations::cond_rels(&**c, m), i, acc, t)) && builds_on_block(m, i, acc, el),
        _ => match crate::check::shrink::walk::call_of(e) {
            Some((c, args)) => builds_on_call(m, i, acc, &c, &args),
            None => false,
        },
    }
}

/// The step machine of `BuildsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
/// ```
pub struct BuildsOn {
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub i: Nat,
    pub acc: Text,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for BuildsOn {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let acc = &self.acc;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EName(n) => prism_rtl::Turn::Finished(&crate::check::env::sname_key(n) == acc),
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(BuildsOn { m: m.clone(), i: i.clone(), acc: acc.clone(), e: (**x).clone() })),
            crate::syntax::ExprKind::EMatch(s, arms) => fold_job(arms.clone(), true, {
                let acc = acc.clone();
                let s = (**s).clone();
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                    let acc = acc.clone();
                    let s = s.clone();
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok_ = p0;
                        let a = p1;
                        prism_rtl::Turn::Finished((ok_ && !crate::check::types::has_text(&opt_names(&a.pattern), &acc)) && builds_on_block(&crate::check::shrink::relations::arm_pat_rels(&s, &a, &m), &i, &acc, &a.body))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::syntax::ExprKind::EIf(c, t, Some(el)) => {
                let acc = acc.clone();
                let c = (**c).clone();
                let el = el.clone();
                let i = i.clone();
                let m = m.clone();
                let t = t.clone();
                call_then(start_cond_names(c.clone()), move |cond_names_5750: Array<Text>| prism_rtl::Turn::Finished((!crate::check::types::has_text(&cond_names_5750, &acc) && builds_on_block(&crate::check::shrink::relations::cond_rels(&c, &m), &i, &acc, &t)) && builds_on_block(&m, &i, &acc, &el)))
            },
            _ => match crate::check::shrink::walk::call_of(e) {
                Some((c, args)) => prism_rtl::Turn::More(Rc::new(BuildsOnCall { m: m.clone(), i: i.clone(), acc: acc.clone(), c: c.clone(), args: args.clone() })),
                None => prism_rtl::Turn::Finished(false),
            },
        }
    }
}

/// `Start BuildsOn, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on(m: Map<Text, crate::check::shrink::Rel>, i: Nat, acc: Text, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(BuildsOn { m, i, acc, e })
}

/// ```prism
/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
/// ```
pub fn builds_on_call(m: &Map<Text, crate::check::shrink::Rel>, i: &Nat, acc: &Text, c: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>) -> bool {
    let f = crate::check::shrink::locals::expr_name(c);
    let on_acc = builds_on(m, i, acc, &or(&index(args, &Nat::from(0u32)), &dummy_arg()).value);
    let rest = each(&drop(args, &Nat::from(1u32)), &(|a: &crate::syntax::Arg| a.value.clone()));
    let parts = run_to_end(fold_job(rest.clone(), true, {
        let m = m.clone();
        let i = i.clone();
        Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
            let m = m.clone();
            let i = i.clone();
            entered(once_job(move || {
                let ok_ = p0;
                let x = p1;
                prism_rtl::Turn::Finished(ok_ && part(&m, &i, &x))
            }))
        }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    if !on_acc {
        false
    } else {
        if crate::check::shrink::relations::pre_is(m, &f, &Text::lit("Push")) && (&len(&rest) == &Nat::from(1u32)) {
            parts
        } else {
            if crate::check::shrink::relations::pre_is(m, &f, &Text::lit("Insert")) && (&len(&rest) == &Nat::from(2u32)) {
                parts
            } else {
                if crate::check::shrink::relations::pre_is(m, &f, &Text::lit("Append")) && (&len(&rest) == &Nat::from(1u32)) {
                    within(m, i, &or(&index(&rest, &Nat::from(0u32)), &dummy_arg().value))
                } else {
                    false
                }
            }
        }
    }
}

/// The step machine of `BuildsOnCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
/// ```
pub struct BuildsOnCall {
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub i: Nat,
    pub acc: Text,
    pub c: crate::syntax::Expr,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<bool> for BuildsOnCall {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let acc = &self.acc;
        let c = &self.c;
        let args = &self.args;
        let f = crate::check::shrink::locals::expr_name(c);
        let acc = acc.clone();
        let args = args.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(start_builds_on(m.clone(), i.clone(), acc.clone(), or(&index(&args, &Nat::from(0u32)), &dummy_arg()).value.clone()), move |builds_on_6180: bool| {
            let on_acc = builds_on_6180;
            let rest = each(&drop(&args, &Nat::from(1u32)), &(|a: &crate::syntax::Arg| a.value.clone()));
            call_value(fold_job(rest.clone(), true, {
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok_ = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(ok_ && part(&m, &i, &x))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |fold_6294: bool| {
                let parts = fold_6294;
                if !on_acc {
                    prism_rtl::Turn::Finished(false)
                } else {
                    if crate::check::shrink::relations::pre_is(&m, &f, &Text::lit("Push")) && (&len(&rest) == &Nat::from(1u32)) {
                        prism_rtl::Turn::Finished(parts)
                    } else {
                        if crate::check::shrink::relations::pre_is(&m, &f, &Text::lit("Insert")) && (&len(&rest) == &Nat::from(2u32)) {
                            prism_rtl::Turn::Finished(parts)
                        } else {
                            if crate::check::shrink::relations::pre_is(&m, &f, &Text::lit("Append")) && (&len(&rest) == &Nat::from(1u32)) {
                                prism_rtl::Turn::More(Rc::new(Within { m: m.clone(), i: i.clone(), e: or(&index(&rest, &Nat::from(0u32)), &dummy_arg().value) }))
                            } else {
                                prism_rtl::Turn::Finished(false)
                            }
                        }
                    }
                }
            })
        })
    }
}

/// `Start BuildsOnCall, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on_call(m: Map<Text, crate::check::shrink::Rel>, i: Nat, acc: Text, c: crate::syntax::Expr, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(BuildsOnCall { m, i, acc, c, args })
}

/// ```prism
/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
/// ```
pub fn builds_on_block(m: &Map<Text, crate::check::shrink::Rel>, i: &Nat, acc: &Text, b: &crate::syntax::Block) -> bool {
    !crate::check::types::has_text(&crate::check::shrink::relations::stmts_binders(&b.stmts), acc) && builds_on(&crate::check::shrink::relations::block_rels(&b.stmts, m), i, acc, &last_or(b))
}

/// The step machine of `BuildsOnBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
/// ```
pub struct BuildsOnBlock {
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub i: Nat,
    pub acc: Text,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<bool> for BuildsOnBlock {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let acc = &self.acc;
        let b = &self.b;
        let acc = acc.clone();
        let b = b.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(crate::check::shrink::relations::start_stmts_binders(b.stmts.clone()), move |stmts_binders_6854: Array<Text>| prism_rtl::Turn::Finished(!crate::check::types::has_text(&stmts_binders_6854, &acc) && builds_on(&crate::check::shrink::relations::block_rels(&b.stmts, &m), &i, &acc, &last_or(&b))))
    }
}

/// `Start BuildsOnBlock, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on_block(m: Map<Text, crate::check::shrink::Rel>, i: Nat, acc: Text, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(BuildsOnBlock { m, i, acc, b })
}

/// ```prism
/// CondNames: unbounded fn Cond -> [Text]
/// ```
pub fn cond_names(cond0: &crate::syntax::Cond) -> Array<Text> {
    match cond0 {
        crate::syntax::Cond::CondBind(p_, _, _) => crate::check::env::names::pattern_names(p_),
        crate::syntax::Cond::CondExpr(_) => Array::new(),
    }
}

/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondNames: unbounded fn Cond -> [Text]
/// ```
pub struct CondNames {
    pub cond0: crate::syntax::Cond,
}

impl prism_rtl::Job<Array<Text>> for CondNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cond0 = &self.cond0;
        match cond0 {
            crate::syntax::Cond::CondBind(p_, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::names::PatternNames { p_: p_.clone() })),
            crate::syntax::Cond::CondExpr(_) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start CondNames, x`: what the function value is when passed to `@Run`.
pub fn start_cond_names(cond0: crate::syntax::Cond) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CondNames { cond0 })
}

/// ```prism
/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub fn part(m: &Map<Text, crate::check::shrink::Rel>, i: &Nat, e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::ETuple(es) => run_to_end(fold_job(es.clone(), true, {
            let m = m.clone();
            let i = i.clone();
            Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                let m = m.clone();
                let i = i.clone();
                entered(once_job(move || {
                    let ok_ = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(ok_ && part(&m, &i, &x))
                }))
            }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::syntax::ExprKind::EGroup(x) => part(m, i, &**x),
        _ => match crate::check::shrink::walk::rel_of(m, e) {
            Some(r) => (&r.param == i) && r.strict,
            None => false,
        },
    }
}

/// The step machine of `Part`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub struct Part {
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub i: Nat,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for Part {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::ETuple(es) => fold_job(es.clone(), true, {
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok_ = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(ok_ && part(&m, &i, &x))
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(Part { m: m.clone(), i: i.clone(), e: (**x).clone() })),
            _ => {
                let e = e.clone();
                let i = i.clone();
                let m = m.clone();
                call_then(crate::check::shrink::walk::start_rel_of(m.clone(), e.clone()), move |rel_of_7269: Option<crate::check::shrink::Rel>| match rel_of_7269 {
                    Some(r) => prism_rtl::Turn::Finished((&r.param == &i) && r.strict),
                    None => prism_rtl::Turn::Finished(false),
                })
            },
        }
    }
}

/// `Start Part, x`: what the function value is when passed to `@Run`.
pub fn start_part(m: Map<Text, crate::check::shrink::Rel>, i: Nat, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Part { m, i, e })
}

/// ```prism
/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn summary_seeds(sk: &crate::check::shrink::Shrink, d: &crate::check::env::Def, spots: &Array<crate::check::shrink::walk::Spot>, rels: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    fold(&run_to_end(fold_job(spots.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)| entered(once_job(move || {
        let acc = p0;
        let sp = p1;
        call_then(crate::check::shrink::walk::start_spot_sites(sp.clone()), move |spot_sites_7945: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(append(&acc, &spot_sites_7945)))
    }))) as Rc<dyn Fn((Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Site>>>>)), rels, &(|m: &Map<Text, crate::check::shrink::Rel>, site: &crate::check::shrink::walk::Site| if crate::check::shrink::relations::is_local(&site.rels, &site.callee) {
        m.clone()
    } else {
        match crate::check::shrink::locals::resolve_callee(&sk.g, &d.home, &site.callee) {
            Some(k) => match get(&sk.sums, &k) {
                Some(i) => insert(m, &Text::from(format!("fn:{}", &site.callee)), &crate::check::shrink::Rel { param: i, strict: false }),
                None => if crate::check::shrink::walk::is_no_larger_prelude(&sk.g, &k) {
                    insert(m, &Text::from(format!("fn:{}", &site.callee)), &crate::check::shrink::Rel { param: Nat::from(0u32), strict: false })
                } else {
                    m.clone()
                },
            },
            None => m.clone(),
        }
    }))
}

/// The step machine of `SummarySeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct SummarySeeds {
    pub sk: crate::check::shrink::Shrink,
    pub d: crate::check::env::Def,
    pub spots: Array<crate::check::shrink::walk::Spot>,
    pub rels: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for SummarySeeds {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let sk = &self.sk;
        let d = &self.d;
        let spots = &self.spots;
        let rels = &self.rels;
        let d = d.clone();
        let rels = rels.clone();
        let sk = sk.clone();
        let spots = spots.clone();
        call_value(fold_job(spots.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)| entered(once_job(move || {
            let acc = p0;
            let sp = p1;
            call_then(crate::check::shrink::walk::start_spot_sites(sp.clone()), move |spot_sites_7945: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(append(&acc, &spot_sites_7945)))
        }))) as Rc<dyn Fn((Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::walk::Site>>>>), move |fold_7903: Array<crate::check::shrink::walk::Site>| prism_rtl::Turn::Finished(fold(&fold_7903, &rels, &(|m: &Map<Text, crate::check::shrink::Rel>, site: &crate::check::shrink::walk::Site| if crate::check::shrink::relations::is_local(&site.rels, &site.callee) {
            m.clone()
        } else {
            match crate::check::shrink::locals::resolve_callee(&sk.g, &d.home, &site.callee) {
                Some(k) => match get(&sk.sums, &k) {
                    Some(i) => insert(m, &Text::from(format!("fn:{}", &site.callee)), &crate::check::shrink::Rel { param: i, strict: false }),
                    None => if crate::check::shrink::walk::is_no_larger_prelude(&sk.g, &k) {
                        insert(m, &Text::from(format!("fn:{}", &site.callee)), &crate::check::shrink::Rel { param: Nat::from(0u32), strict: false })
                    } else {
                        m.clone()
                    },
                },
                None => m.clone(),
            }
        }))))
    }
}

/// `Start SummarySeeds, x`: what the function value is when passed to `@Run`.
pub fn start_summary_seeds(sk: crate::check::shrink::Shrink, d: crate::check::env::Def, spots: Array<crate::check::shrink::walk::Spot>, rels: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(SummarySeeds { sk, d, spots, rels })
}

/// ```prism
/// OptNames: unbounded fn ?Pattern -> [Text]
/// ```
pub fn opt_names(opt0: &Option<crate::syntax::Pattern_>) -> Array<Text> {
    match opt0 {
        Some(p_) => crate::check::env::names::pattern_names(p_),
        None => Array::new(),
    }
}

/// The step machine of `OptNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptNames: unbounded fn ?Pattern -> [Text]
/// ```
pub struct OptNames {
    pub opt0: Option<crate::syntax::Pattern_>,
}

impl prism_rtl::Job<Array<Text>> for OptNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(p_) => prism_rtl::Turn::More(Rc::new(crate::check::env::names::PatternNames { p_: p_.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptNames, x`: what the function value is when passed to `@Run`.
pub fn start_opt_names(opt0: Option<crate::syntax::Pattern_>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(OptNames { opt0 })
}

/// ```prism
/// let dummyArg
/// ```
pub fn dummy_arg() -> crate::syntax::Arg {
    crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub fn decrement_of(m: &Map<Text, crate::check::shrink::Rel>, e: &crate::syntax::Expr) -> Option<crate::check::shrink::Rel> {
    match &*e.kind {
        crate::syntax::ExprKind::EBinary(m8753_0_0, l, r) if (m8753_0_0 == &Text::lit("-?")) => if is_positive_lit(&**r) && is_nat_minus(m, e) { smaller(m, &**l) } else { None },
        crate::syntax::ExprKind::EGroup(x) => decrement_of(m, &**x),
        _ => match crate::check::shrink::walk::call_of(e) {
            Some((c, args)) => match crate::check::shrink::walk::callee_name(&c) {
                Some(n) => if crate::check::shrink::relations::pre_is(m, &n, &Text::lit("?Step")) {
                    smaller(m, &or(&index(&args, &Nat::from(0u32)), &dummy_arg()).value)
                } else {
                    None
                },
                None => None,
            },
            None => None,
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DecrementOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub struct DecrementOf {
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<Option<crate::check::shrink::Rel>> for DecrementOf {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::check::shrink::Rel>> {
        let m = &self.m;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EBinary(m8753_0_0, l, r) if (m8753_0_0 == &Text::lit("-?")) => if is_positive_lit(&**r) && is_nat_minus(m, e) {
                prism_rtl::Turn::Finished(smaller(m, &**l))
            } else {
                prism_rtl::Turn::Finished(None)
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(DecrementOf { m: m.clone(), e: (**x).clone() })),
            _ => match crate::check::shrink::walk::call_of(e) {
                Some((c, args)) => match crate::check::shrink::walk::callee_name(&c) {
                    Some(n) => if crate::check::shrink::relations::pre_is(m, &n, &Text::lit("?Step")) {
                        prism_rtl::Turn::Finished(smaller(m, &or(&index(&args, &Nat::from(0u32)), &dummy_arg()).value))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    },
                    None => prism_rtl::Turn::Finished(None),
                },
                None => prism_rtl::Turn::Finished(None),
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DecrementOf, x`: what the function value is when passed to `@Run`.
pub fn start_decrement_of(m: Map<Text, crate::check::shrink::Rel>, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Option<crate::check::shrink::Rel>>> {
    Rc::new(DecrementOf { m, e })
}

/// ```prism
/// IsNatMinus: fn (Text ==> Rel), Expr -> Bool
/// ```
pub fn is_nat_minus(m: &Map<Text, crate::check::shrink::Rel>, e: &crate::syntax::Expr) -> bool {
    crate::check::shrink::relations::pre_is(m, &Text::lit("-?"), &Text::lit("-?")) && crate::check::shrink::walk::is_nat_at(m, e)
}

/// ```prism
/// ?Smaller: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub fn smaller(m: &Map<Text, crate::check::shrink::Rel>, x: &crate::syntax::Expr) -> Option<crate::check::shrink::Rel> {
    match crate::check::shrink::walk::rel_of(m, x) {
        Some(r) => Some(crate::check::shrink::Rel { param: r.param.clone(), strict: true }),
        None => None,
    }
}

/// ```prism
/// IsPositiveLit: fn Expr -> Bool
/// ```
pub fn is_positive_lit(e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::ELit(l) => match &l.kind {
            crate::syntax::LitKind::LInt(d) => d != &Text::lit("0"),
            _ => false,
        },
        crate::syntax::ExprKind::EGroup(x) => is_positive_lit(&**x),
        _ => false,
    }
}

/// ```prism
/// Closure: unbounded fn [Sc] -> [Sc]
/// ```
pub fn closure(graphs: &Array<crate::check::shrink::Sc>) -> Array<crate::check::shrink::Sc> {
    closure_from(graphs, &dedup(graphs), &dedup(graphs))
}

/// The step machine of `Closure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Closure: unbounded fn [Sc] -> [Sc]
/// ```
pub struct Closure {
    pub graphs: Array<crate::check::shrink::Sc>,
}

impl prism_rtl::Job<Array<crate::check::shrink::Sc>> for Closure {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::shrink::Sc>> {
        let graphs = &self.graphs;
        prism_rtl::Turn::More(Rc::new(ClosureFrom { base: graphs.clone(), acc: dedup(graphs), frontier: dedup(graphs) }))
    }
}

/// `Start Closure, x`: what the function value is when passed to `@Run`.
pub fn start_closure(graphs: Array<crate::check::shrink::Sc>) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>> {
    Rc::new(Closure { graphs })
}

/// ```prism
/// Dedup: fn [Sc] -> [Sc]
/// ```
pub fn dedup(gs: &Array<crate::check::shrink::Sc>) -> Array<crate::check::shrink::Sc> {
    fold(gs, &Array::new(), &(|acc: &Array<crate::check::shrink::Sc>, g: &crate::check::shrink::Sc| if has_sc(acc, g) { acc.clone() } else { push(acc, g) }))
}

/// ```prism
/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
/// ```
pub fn closure_from(base: &Array<crate::check::shrink::Sc>, acc: &Array<crate::check::shrink::Sc>, frontier: &Array<crate::check::shrink::Sc>) -> Array<crate::check::shrink::Sc> {
    let fresh = fold(frontier, &Array::new(), &(|out: &Array<crate::check::shrink::Sc>, a: &crate::check::shrink::Sc| fold(base, out, &(|out2: &Array<crate::check::shrink::Sc>, b: &crate::check::shrink::Sc| add_composed(acc, out2, a, b)))));
    if &len(&fresh) == &Nat::from(0u32) {
        acc.clone()
    } else {
        closure_from(base, &append(acc, &fresh), &fresh)
    }
}

/// The step machine of `ClosureFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
/// ```
pub struct ClosureFrom {
    pub base: Array<crate::check::shrink::Sc>,
    pub acc: Array<crate::check::shrink::Sc>,
    pub frontier: Array<crate::check::shrink::Sc>,
}

impl prism_rtl::Job<Array<crate::check::shrink::Sc>> for ClosureFrom {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::shrink::Sc>> {
        let base = &self.base;
        let acc = &self.acc;
        let frontier = &self.frontier;
        let fresh = fold(frontier, &Array::new(), &(|out: &Array<crate::check::shrink::Sc>, a: &crate::check::shrink::Sc| fold(base, out, &(|out2: &Array<crate::check::shrink::Sc>, b: &crate::check::shrink::Sc| add_composed(acc, out2, a, b)))));
        if &len(&fresh) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(acc.clone())
        } else {
            prism_rtl::Turn::More(Rc::new(ClosureFrom { base: base.clone(), acc: append(acc, &fresh), frontier: fresh.clone() }))
        }
    }
}

/// `Start ClosureFrom, x`: what the function value is when passed to `@Run`.
pub fn start_closure_from(base: Array<crate::check::shrink::Sc>, acc: Array<crate::check::shrink::Sc>, frontier: Array<crate::check::shrink::Sc>) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>> {
    Rc::new(ClosureFrom { base, acc, frontier })
}

/// ```prism
/// AddComposed: fn [Sc], [Sc], Sc, Sc -> [Sc]
/// ```
pub fn add_composed(acc: &Array<crate::check::shrink::Sc>, out: &Array<crate::check::shrink::Sc>, a: &crate::check::shrink::Sc, b: &crate::check::shrink::Sc) -> Array<crate::check::shrink::Sc> {
    if &a.callee != &b.caller {
        out.clone()
    } else {
        {
            let c = compose(a, b);
            if has_sc(acc, &c) || has_sc(out, &c) { out.clone() } else { push(out, &c) }
        }
    }
}

/// ```prism
/// HasSc: fn [Sc], Sc -> Bool
/// ```
pub fn has_sc(xs: &Array<crate::check::shrink::Sc>, c: &crate::check::shrink::Sc) -> bool {
    fold(xs, &false, &(|seen: &bool, x: &crate::check::shrink::Sc| *seen || (((&x.caller == &c.caller) && (&x.callee == &c.callee)) && (&x.edges == &c.edges))))
}

/// ```prism
/// Compose: fn Sc, Sc -> Sc
/// ```
pub fn compose(a: &crate::check::shrink::Sc, b: &crate::check::shrink::Sc) -> crate::check::shrink::Sc {
    let pairs = fold(&a.edges, &Array::new(), &(|acc: &Array<(Nat, Nat, bool)>, (x, y, s1): &(Nat, Nat, bool)| fold(&b.edges, acc, &(|acc2: &Array<(Nat, Nat, bool)>, (y2, z, s2): &(Nat, Nat, bool)| if y == y2 { add_edge(acc2, x, z, &(*s1 || *s2)) } else { acc2.clone() }))));
    crate::check::shrink::Sc { caller: a.caller.clone(), callee: b.callee.clone(), edges: sort_edges(&pairs), span: a.span.clone(), file: a.file.clone(), arg: a.arg.clone() }
}

/// ```prism
/// AddEdge: fn [((Nat, Nat, Bool))], Nat, Nat, Bool -> [((Nat, Nat, Bool))]
/// ```
pub fn add_edge(es: &Array<(Nat, Nat, bool)>, x: &Nat, z: &Nat, s: &bool) -> Array<(Nat, Nat, bool)> {
    let others = filter(es, &(|(a, b, _): &(Nat, Nat, bool)| !((a == x) && (b == z))));
    let had = fold(es, &false, &(|seen: &bool, (a, b, t): &(Nat, Nat, bool)| *seen || (((a == x) && (b == z)) && *t)));
    push(&others, &(x.clone(), z.clone(), *s || had))
}

/// ```prism
/// SortEdges: fn [((Nat, Nat, Bool))] -> [((Nat, Nat, Bool))]
/// ```
pub fn sort_edges(es: &Array<(Nat, Nat, bool)>) -> Array<(Nat, Nat, bool)> {
    fold(es, &Array::new(), &(|acc: &Array<(Nat, Nat, bool)>, e: &(Nat, Nat, bool)| append(&push(&filter(acc, &(|x: &(Nat, Nat, bool)| edge_before(x, e))), e), &filter(acc, &(|x: &(Nat, Nat, bool)| !edge_before(x, e))))))
}

/// ```prism
/// EdgeBefore: fn ((Nat, Nat, Bool)), ((Nat, Nat, Bool)) -> Bool
/// ```
pub fn edge_before(arg0: &(Nat, Nat, bool), arg1: &(Nat, Nat, bool)) -> bool {
    match (arg0, arg1) {
        ((a1, b1, _), (a2, b2, _)) => (a1 < a2) || ((a1 == a2) && (b1 < b2)),
    }
}

/// ```prism
/// LoopsOf: unbounded fn Shrink, St, Def -> St
/// ```
pub fn loops_of(sk: &crate::check::shrink::Shrink, st: &crate::check::types::St, d: &crate::check::env::Def) -> crate::check::types::St {
    let unb = crate::check::shrink::types::is_unbounded_key(&sk.g, &crate::check::shrink::types::sig_key_of(sk, &d.qk));
    if unb && !st.recording {
        st.clone()
    } else {
        {
            let s0 = {
                let mut this: crate::check::types::St = st.clone();
                this.file = d.file.clone();
                this
            };
            let s1 = run_to_end(fold_job(crate::check::shrink::types::def_clauses(d), s0.clone(), {
                let sk = sk.clone();
                let d = d.clone();
                let unb = unb;
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                    let sk = sk.clone();
                    let d = d.clone();
                    let unb = unb;
                    entered(once_job(move || {
                        let s = p0;
                        let c = p1;
                        prism_rtl::Turn::More(Rc::new(ClauseLoops { sk: sk.clone(), st: s.clone(), d: d.clone(), c: c.clone(), unb }))
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }));
            {
                let mut this: crate::check::types::St = s1.clone();
                this.file = st.file.clone();
                this
            }
        }
    }
}

/// The step machine of `LoopsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LoopsOf: unbounded fn Shrink, St, Def -> St
/// ```
pub struct LoopsOf {
    pub sk: crate::check::shrink::Shrink,
    pub st: crate::check::types::St,
    pub d: crate::check::env::Def,
}

impl prism_rtl::Job<crate::check::types::St> for LoopsOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let sk = &self.sk;
        let st = &self.st;
        let d = &self.d;
        let unb = crate::check::shrink::types::is_unbounded_key(&sk.g, &crate::check::shrink::types::sig_key_of(sk, &d.qk));
        if unb && !st.recording {
            prism_rtl::Turn::Finished(st.clone())
        } else {
            {
                let s0 = {
                    let mut this: crate::check::types::St = st.clone();
                    this.file = d.file.clone();
                    this
                };
                let d = d.clone();
                let sk = sk.clone();
                let st = st.clone();
                call_value(fold_job(crate::check::shrink::types::def_clauses(&d), s0.clone(), {
                    let sk = sk.clone();
                    let d = d.clone();
                    let unb = unb;
                    Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                        let sk = sk.clone();
                        let d = d.clone();
                        let unb = unb;
                        entered(once_job(move || {
                            let s = p0;
                            let c = p1;
                            prism_rtl::Turn::More(Rc::new(ClauseLoops { sk: sk.clone(), st: s.clone(), d: d.clone(), c: c.clone(), unb }))
                        }))
                    }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                }), move |fold_12724: crate::check::types::St| {
                    let s1 = fold_12724;
                    prism_rtl::Turn::Finished({
                        let mut this: crate::check::types::St = s1.clone();
                        this.file = st.file.clone();
                        this
                    })
                })
            }
        }
    }
}

/// `Start LoopsOf, x`: what the function value is when passed to `@Run`.
pub fn start_loops_of(sk: crate::check::shrink::Shrink, st: crate::check::types::St, d: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(LoopsOf { sk, st, d })
}

/// ```prism
/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
/// ```
pub fn clause_loops(sk: &crate::check::shrink::Shrink, st: &crate::check::types::St, d: &crate::check::env::Def, c: &crate::syntax::decls::FnClause, unb: &bool) -> crate::check::types::St {
    let base = crate::check::shrink::locals::clause_base(sk, d, c);
    let spots0 = crate::check::shrink::walk::body_spots(&c.body, &base);
    if !fold(&spots0, &false, &(|seen: &bool, sp: &crate::check::shrink::walk::Spot| *seen || is_while_spot(sp))) {
        st.clone()
    } else {
        {
            let spots = crate::check::shrink::walk::body_spots(&c.body, &summary_seeds(sk, d, &spots0, &base));
            run_to_end(fold_job(filter(&spots, &(|sp: &crate::check::shrink::walk::Spot| is_while_spot(sp))), st.clone(), {
                let d = d.clone();
                let unb = *unb;
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::shrink::walk::Spot)| {
                    let d = d.clone();
                    let unb = unb;
                    entered(once_job(move || {
                        let s = p0;
                        let sp = p1;
                        match &sp {
                            crate::check::shrink::walk::Spot::SpotStmt(w, m) => match &w.kind {
                                crate::syntax::StmtKind::SWhile(cond, body) => prism_rtl::Turn::More(Rc::new(CheckWhile { st: s.clone(), c: cond.clone(), body: body.clone(), span: w.span.clone(), name: d.name.clone(), seeds: marks(m), unb })),
                                _ => prism_rtl::Turn::Finished(s.clone()),
                            },
                            _ => prism_rtl::Turn::Finished(s.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }))
        }
    }
}

/// The step machine of `ClauseLoops`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
/// ```
pub struct ClauseLoops {
    pub sk: crate::check::shrink::Shrink,
    pub st: crate::check::types::St,
    pub d: crate::check::env::Def,
    pub c: crate::syntax::decls::FnClause,
    pub unb: bool,
}

impl prism_rtl::Job<crate::check::types::St> for ClauseLoops {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let sk = &self.sk;
        let st = &self.st;
        let d = &self.d;
        let c = &self.c;
        let unb = &self.unb;
        let c = c.clone();
        let d = d.clone();
        let sk = sk.clone();
        let st = st.clone();
        let unb = *unb;
        call_then(crate::check::shrink::locals::start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_12950: Map<Text, crate::check::shrink::Rel>| {
            let base = clause_base_12950;
            call_then(crate::check::shrink::walk::start_body_spots(c.body.clone(), base.clone()), move |body_spots_12987: Array<crate::check::shrink::walk::Spot>| {
                let spots0 = body_spots_12987;
                if !fold(&spots0, &false, &(|seen: &bool, sp: &crate::check::shrink::walk::Spot| *seen || is_while_spot(sp))) {
                    prism_rtl::Turn::Finished(st.clone())
                } else {
                    call_then(start_summary_seeds(sk.clone(), d.clone(), spots0.clone(), base.clone()), move |summary_seeds_13131: Map<Text, crate::check::shrink::Rel>| call_then(crate::check::shrink::walk::start_body_spots(c.body.clone(), summary_seeds_13131), move |body_spots_13112: Array<crate::check::shrink::walk::Spot>| {
                        let spots = body_spots_13112;
                        fold_job(filter(&spots, &(|sp: &crate::check::shrink::walk::Spot| is_while_spot(sp))), st.clone(), {
                            let d = d.clone();
                            let unb = unb;
                            Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::shrink::walk::Spot)| {
                                let d = d.clone();
                                let unb = unb;
                                entered(once_job(move || {
                                    let s = p0;
                                    let sp = p1;
                                    match &sp {
                                        crate::check::shrink::walk::Spot::SpotStmt(w, m) => match &w.kind {
                                            crate::syntax::StmtKind::SWhile(cond, body) => prism_rtl::Turn::More(Rc::new(CheckWhile { st: s.clone(), c: cond.clone(), body: body.clone(), span: w.span.clone(), name: d.name.clone(), seeds: marks(m), unb })),
                                            _ => prism_rtl::Turn::Finished(s.clone()),
                                        },
                                        _ => prism_rtl::Turn::Finished(s.clone()),
                                    }
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }).cycle()
                    }))
                }
            })
        })
    }
}

/// `Start ClauseLoops, x`: what the function value is when passed to `@Run`.
pub fn start_clause_loops(sk: crate::check::shrink::Shrink, st: crate::check::types::St, d: crate::check::env::Def, c: crate::syntax::decls::FnClause, unb: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ClauseLoops { sk, st, d, c, unb })
}

/// ```prism
/// Marks: fn (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn marks(m: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    fold(&keys(m), m, &(|m2: &Map<Text, crate::check::shrink::Rel>, k: &Text| if crate::syntax::lexer::chars::contains(k, &Text::lit(":")) {
        m2.clone()
    } else {
        remove(m2, k)
    }))
}

/// ```prism
/// IsWhileSpot: fn Spot -> Bool
/// ```
pub fn is_while_spot(spot0: &crate::check::shrink::walk::Spot) -> bool {
    match spot0 {
        crate::check::shrink::walk::Spot::SpotStmt(s, _) => match &s.kind {
            crate::syntax::StmtKind::SWhile(_, _) => true,
            _ => false,
        },
        crate::check::shrink::walk::Spot::SpotExpr(_, _) => false,
    }
}

/// ```prism
/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
/// ```
pub fn check_while(st: &crate::check::types::St, c: &crate::syntax::Cond, body: &crate::syntax::Block, span: &crate::syntax::Range, name: &Text, seeds: &Map<Text, crate::check::shrink::Rel>, unb: &bool) -> crate::check::types::St {
    let vars = set_targets(&body.stmts);
    let base = fold(&crate::check::errors::range0(&len(&vars)), seeds, &(|m: &Map<Text, crate::check::shrink::Rel>, i: &Nat| insert(m, &or(&index(&vars, i), &Text::lit("")), &crate::check::shrink::Rel { param: i.clone(), strict: false })));
    let rels = crate::check::shrink::relations::cond_rels(c, &base);
    let ok_ = run_to_end(fold_job(crate::check::errors::range0(&len(&vars)), false, {
        let body = body.clone();
        let vars = vars.clone();
        let rels = rels.clone();
        Rc::new(move |(p0, p1): (bool, Nat)| {
            let body = body.clone();
            let vars = vars.clone();
            let rels = rels.clone();
            entered(once_job(move || {
                let seen = p0;
                let i = p1;
                prism_rtl::Turn::Finished(seen || all_paths_strict(&body.stmts, &or(&index(&vars, &i), &Text::lit("")), &i, &rels))
            }))
        }) as Rc<dyn Fn((bool, Nat)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    if ok_ {
        st.clone()
    } else {
        if *unb {
            note_unshrunk(st, span)
        } else {
            crate::check::types::recording::err_fix(st, &Text::lit("may-not-end"), span, &Text::from(format!("this loop in `{}` may not end: nothing it sets gets smaller on every turn", name)), &Text::from(format!("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `{}` `unbounded fn`", name)))
        }
    }
}

/// The step machine of `CheckWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
/// ```
pub struct CheckWhile {
    pub st: crate::check::types::St,
    pub c: crate::syntax::Cond,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
    pub name: Text,
    pub seeds: Map<Text, crate::check::shrink::Rel>,
    pub unb: bool,
}

impl prism_rtl::Job<crate::check::types::St> for CheckWhile {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let c = &self.c;
        let body = &self.body;
        let span = &self.span;
        let name = &self.name;
        let seeds = &self.seeds;
        let unb = &self.unb;
        let body = body.clone();
        let c = c.clone();
        let name = name.clone();
        let seeds = seeds.clone();
        let span = span.clone();
        let st = st.clone();
        let unb = *unb;
        call_then(start_set_targets(body.stmts.clone()), move |set_targets_14238: Array<Text>| {
            let vars = set_targets_14238;
            let base = fold(&crate::check::errors::range0(&len(&vars)), &seeds, &(|m: &Map<Text, crate::check::shrink::Rel>, i: &Nat| insert(m, &or(&index(&vars, i), &Text::lit("")), &crate::check::shrink::Rel { param: i.clone(), strict: false })));
            call_then(crate::check::shrink::relations::start_cond_rels(c.clone(), base.clone()), move |cond_rels_14552: Map<Text, crate::check::shrink::Rel>| {
                let rels = cond_rels_14552;
                call_value(fold_job(crate::check::errors::range0(&len(&vars)), false, {
                    let body = body.clone();
                    let vars = vars.clone();
                    let rels = rels.clone();
                    Rc::new(move |(p0, p1): (bool, Nat)| {
                        let body = body.clone();
                        let vars = vars.clone();
                        let rels = rels.clone();
                        entered(once_job(move || {
                            let seen = p0;
                            let i = p1;
                            prism_rtl::Turn::Finished(seen || all_paths_strict(&body.stmts, &or(&index(&vars, &i), &Text::lit("")), &i, &rels))
                        }))
                    }) as Rc<dyn Fn((bool, Nat)) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |fold_14582: bool| {
                    let ok_ = fold_14582;
                    if ok_ {
                        prism_rtl::Turn::Finished(st.clone())
                    } else {
                        if unb {
                            prism_rtl::Turn::Finished(note_unshrunk(&st, &span))
                        } else {
                            prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st, &Text::lit("may-not-end"), &span, &Text::from(format!("this loop in `{}` may not end: nothing it sets gets smaller on every turn", &name)), &Text::from(format!("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `{}` `unbounded fn`", &name))))
                        }
                    }
                })
            })
        })
    }
}

/// `Start CheckWhile, x`: what the function value is when passed to `@Run`.
pub fn start_check_while(st: crate::check::types::St, c: crate::syntax::Cond, body: crate::syntax::Block, span: crate::syntax::Range, name: Text, seeds: Map<Text, crate::check::shrink::Rel>, unb: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckWhile { st, c, body, span, name, seeds, unb })
}

/// ```prism
/// NoteUnshrunk: fn St, Range -> St
/// ```
pub fn note_unshrunk(st: &crate::check::types::St, span: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st.clone();
    this.typed.unshrunk = push(&this.typed.unshrunk, &crate::check::types::recording::at_here(st, span));
    this
}

/// ```prism
/// SetTargets: unbounded fn [Stmt] -> [Text]
/// ```
pub fn set_targets(stmts: &Array<crate::syntax::Stmt>) -> Array<Text> {
    run_to_end(fold_job(crate::check::shrink::walk::stmts_spots(stmts, &Map::new()), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::walk::Spot)| entered(once_job(move || {
        let acc = p0;
        let sp = p1;
        call_then(start_spot_set_root(sp.clone()), move |spot_set_root_15448: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &spot_set_root_15448)))
    }))) as Rc<dyn Fn((Array<Text>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `SetTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetTargets: unbounded fn [Stmt] -> [Text]
/// ```
pub struct SetTargets {
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<Text>> for SetTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let stmts = &self.stmts;
        let stmts = stmts.clone();
        call_then(crate::check::shrink::walk::start_stmts_spots(stmts.clone(), Map::new()), move |stmts_spots_15391: Array<crate::check::shrink::walk::Spot>| fold_job(stmts_spots_15391, Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::shrink::walk::Spot)| entered(once_job(move || {
            let acc = p0;
            let sp = p1;
            call_then(start_spot_set_root(sp.clone()), move |spot_set_root_15448: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &spot_set_root_15448)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
    }
}

/// `Start SetTargets, x`: what the function value is when passed to `@Run`.
pub fn start_set_targets(stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SetTargets { stmts })
}

/// ```prism
/// SpotSetRoot: unbounded fn Spot -> [Text]
/// ```
pub fn spot_set_root(spot0: &crate::check::shrink::walk::Spot) -> Array<Text> {
    match spot0 {
        crate::check::shrink::walk::Spot::SpotStmt(s, _) => match &s.kind {
            crate::syntax::StmtKind::SSet(t, _) => take(&crate::check::passes::borrows::ref_path(t), &Nat::from(1u32)),
            crate::syntax::StmtKind::SAccum(t, _, _) => take(&crate::check::passes::borrows::ref_path(t), &Nat::from(1u32)),
            _ => Array::new(),
        },
        crate::check::shrink::walk::Spot::SpotExpr(_, _) => Array::new(),
    }
}

/// The step machine of `SpotSetRoot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotSetRoot: unbounded fn Spot -> [Text]
/// ```
pub struct SpotSetRoot {
    pub spot0: crate::check::shrink::walk::Spot,
}

impl prism_rtl::Job<Array<Text>> for SpotSetRoot {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let spot0 = &self.spot0;
        match spot0 {
            crate::check::shrink::walk::Spot::SpotStmt(s, _) => match &s.kind {
                crate::syntax::StmtKind::SSet(t, _) => {
                    let t = t.clone();
                    call_then(crate::check::passes::borrows::start_ref_path(t.clone()), move |ref_path_15584: Array<Text>| prism_rtl::Turn::Finished(take(&ref_path_15584, &Nat::from(1u32))))
                },
                crate::syntax::StmtKind::SAccum(t, _, _) => {
                    let t = t.clone();
                    call_then(crate::check::passes::borrows::start_ref_path(t.clone()), move |ref_path_15634: Array<Text>| prism_rtl::Turn::Finished(take(&ref_path_15634, &Nat::from(1u32))))
                },
                _ => prism_rtl::Turn::Finished(Array::new()),
            },
            crate::check::shrink::walk::Spot::SpotExpr(_, _) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start SpotSetRoot, x`: what the function value is when passed to `@Run`.
pub fn start_spot_set_root(spot0: crate::check::shrink::walk::Spot) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotSetRoot { spot0 })
}

/// ```prism
/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn all_paths_strict(stmts: &Array<crate::syntax::Stmt>, v_: &Text, vi: &Nat, outer: &Map<Text, crate::check::shrink::Rel>) -> bool {
    let rels = crate::check::shrink::relations::block_rels(stmts, outer);
    run_to_end(fold_job(stmts.clone(), false, {
        let v_ = v_.clone();
        let vi = vi.clone();
        let rels = rels.clone();
        Rc::new(move |(p0, p1): (bool, crate::syntax::Stmt)| {
            let v_ = v_.clone();
            let vi = vi.clone();
            let rels = rels.clone();
            entered(once_job(move || {
                let ok_ = p0;
                let s = p1;
                match &s.kind {
                    crate::syntax::StmtKind::SSet(t, value) => {
                        let t = t.clone();
                        let value = value.clone();
                        call_then(crate::check::passes::borrows::start_ref_path(t.clone()), move |ref_path_16319: Array<Text>| if &ref_path_16319 == &Array::from(vec![v_.clone()]) {
                            if is_zero_lit(&value) {
                                prism_rtl::Turn::Finished(ok_)
                            } else {
                                prism_rtl::Turn::More(Rc::new(SetsStrict { e: value.clone(), v_: v_.clone(), vi: vi.clone(), rels: rels.clone() }))
                            }
                        } else {
                            prism_rtl::Turn::Finished(ok_ && !stmt_sets_weak(&s, &v_, &vi, &rels))
                        })
                    },
                    crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                        crate::syntax::ExprKind::EIf(c, tb, eb_opt) => {
                            let eb_opt = eb_opt.clone();
                            let c = (**c).clone();
                            let tb = tb.clone();
                            call_then(crate::check::shrink::relations::start_cond_rels(c.clone(), rels.clone()), move |cond_rels_16544: Map<Text, crate::check::shrink::Rel>| {
                                let tr = cond_rels_16544;
                                match &eb_opt {
                                    Some(b) => {
                                        let b = b.clone();
                                        call_then(start_all_paths_strict(tb.stmts.clone(), v_.clone(), vi.clone(), tr.clone()), move |all_paths_strict_16617: bool| if all_paths_strict_16617 && all_paths_strict(&b.stmts, &v_, &vi, &rels) {
                                            prism_rtl::Turn::Finished(true)
                                        } else {
                                            prism_rtl::Turn::Finished((ok_ && !sets_weak(&tb.stmts, &v_, &vi, &tr)) && !sets_weak(&b.stmts, &v_, &vi, &rels))
                                        })
                                    },
                                    None => prism_rtl::Turn::Finished(ok_ && !sets_weak(&tb.stmts, &v_, &vi, &tr)),
                                }
                            })
                        },
                        crate::syntax::ExprKind::EMatch(subj, arms) => {
                            let arms = arms.clone();
                            let subj = (**subj).clone();
                            call_value(fold_job(arms.clone(), true, {
                                let v_ = v_.clone();
                                let vi = vi.clone();
                                let subj = subj.clone();
                                let rels = rels.clone();
                                Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                    let v_ = v_.clone();
                                    let vi = vi.clone();
                                    let subj = subj.clone();
                                    let rels = rels.clone();
                                    entered(once_job(move || {
                                        let all_arms = p0;
                                        let a = p1;
                                        prism_rtl::Turn::Finished(all_arms && all_paths_strict(&a.body.stmts, &v_, &vi, &crate::check::shrink::relations::arm_pat_rels(&subj, &a, &rels)))
                                    }))
                                }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }), move |fold_16906: bool| if fold_16906 {
                                prism_rtl::Turn::Finished(true)
                            } else {
                                prism_rtl::Turn::Finished(ok_ && !run_to_end(fold_job(arms.clone(), false, {
                                    let v_ = v_.clone();
                                    let vi = vi.clone();
                                    let subj = subj.clone();
                                    let rels = rels.clone();
                                    Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                        let v_ = v_.clone();
                                        let vi = vi.clone();
                                        let subj = subj.clone();
                                        let rels = rels.clone();
                                        entered(once_job(move || {
                                            let any_arm = p0;
                                            let a = p1;
                                            prism_rtl::Turn::Finished(any_arm || sets_weak(&a.body.stmts, &v_, &vi, &crate::check::shrink::relations::arm_pat_rels(&subj, &a, &rels)))
                                        }))
                                    }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                                })))
                            })
                        },
                        _ => prism_rtl::Turn::Finished(ok_ && !stmt_sets_weak(&s, &v_, &vi, &rels)),
                    },
                    _ => prism_rtl::Turn::Finished(ok_ && !stmt_sets_weak(&s, &v_, &vi, &rels)),
                }
            }))
        }) as Rc<dyn Fn((bool, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `AllPathsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct AllPathsStrict {
    pub stmts: Array<crate::syntax::Stmt>,
    pub v_: Text,
    pub vi: Nat,
    pub outer: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<bool> for AllPathsStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let stmts = &self.stmts;
        let v_ = &self.v_;
        let vi = &self.vi;
        let outer = &self.outer;
        let outer = outer.clone();
        let stmts = stmts.clone();
        let v_ = v_.clone();
        let vi = vi.clone();
        call_then(crate::check::shrink::relations::start_block_rels(stmts.clone(), outer.clone()), move |block_rels_16211: Map<Text, crate::check::shrink::Rel>| {
            let rels = block_rels_16211;
            fold_job(stmts.clone(), false, {
                let v_ = v_.clone();
                let vi = vi.clone();
                let rels = rels.clone();
                Rc::new(move |(p0, p1): (bool, crate::syntax::Stmt)| {
                    let v_ = v_.clone();
                    let vi = vi.clone();
                    let rels = rels.clone();
                    entered(once_job(move || {
                        let ok_ = p0;
                        let s = p1;
                        match &s.kind {
                            crate::syntax::StmtKind::SSet(t, value) => {
                                let t = t.clone();
                                let value = value.clone();
                                call_then(crate::check::passes::borrows::start_ref_path(t.clone()), move |ref_path_16319: Array<Text>| if &ref_path_16319 == &Array::from(vec![v_.clone()]) {
                                    if is_zero_lit(&value) {
                                        prism_rtl::Turn::Finished(ok_)
                                    } else {
                                        prism_rtl::Turn::More(Rc::new(SetsStrict { e: value.clone(), v_: v_.clone(), vi: vi.clone(), rels: rels.clone() }))
                                    }
                                } else {
                                    prism_rtl::Turn::Finished(ok_ && !stmt_sets_weak(&s, &v_, &vi, &rels))
                                })
                            },
                            crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                                crate::syntax::ExprKind::EIf(c, tb, eb_opt) => {
                                    let eb_opt = eb_opt.clone();
                                    let c = (**c).clone();
                                    let tb = tb.clone();
                                    call_then(crate::check::shrink::relations::start_cond_rels(c.clone(), rels.clone()), move |cond_rels_16544: Map<Text, crate::check::shrink::Rel>| {
                                        let tr = cond_rels_16544;
                                        match &eb_opt {
                                            Some(b) => {
                                                let b = b.clone();
                                                call_then(start_all_paths_strict(tb.stmts.clone(), v_.clone(), vi.clone(), tr.clone()), move |all_paths_strict_16617: bool| if all_paths_strict_16617 && all_paths_strict(&b.stmts, &v_, &vi, &rels) {
                                                    prism_rtl::Turn::Finished(true)
                                                } else {
                                                    prism_rtl::Turn::Finished((ok_ && !sets_weak(&tb.stmts, &v_, &vi, &tr)) && !sets_weak(&b.stmts, &v_, &vi, &rels))
                                                })
                                            },
                                            None => prism_rtl::Turn::Finished(ok_ && !sets_weak(&tb.stmts, &v_, &vi, &tr)),
                                        }
                                    })
                                },
                                crate::syntax::ExprKind::EMatch(subj, arms) => {
                                    let arms = arms.clone();
                                    let subj = (**subj).clone();
                                    call_value(fold_job(arms.clone(), true, {
                                        let v_ = v_.clone();
                                        let vi = vi.clone();
                                        let subj = subj.clone();
                                        let rels = rels.clone();
                                        Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                            let v_ = v_.clone();
                                            let vi = vi.clone();
                                            let subj = subj.clone();
                                            let rels = rels.clone();
                                            entered(once_job(move || {
                                                let all_arms = p0;
                                                let a = p1;
                                                prism_rtl::Turn::Finished(all_arms && all_paths_strict(&a.body.stmts, &v_, &vi, &crate::check::shrink::relations::arm_pat_rels(&subj, &a, &rels)))
                                            }))
                                        }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }), move |fold_16906: bool| if fold_16906 {
                                        prism_rtl::Turn::Finished(true)
                                    } else {
                                        prism_rtl::Turn::Finished(ok_ && !run_to_end(fold_job(arms.clone(), false, {
                                            let v_ = v_.clone();
                                            let vi = vi.clone();
                                            let subj = subj.clone();
                                            let rels = rels.clone();
                                            Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                                let v_ = v_.clone();
                                                let vi = vi.clone();
                                                let subj = subj.clone();
                                                let rels = rels.clone();
                                                entered(once_job(move || {
                                                    let any_arm = p0;
                                                    let a = p1;
                                                    prism_rtl::Turn::Finished(any_arm || sets_weak(&a.body.stmts, &v_, &vi, &crate::check::shrink::relations::arm_pat_rels(&subj, &a, &rels)))
                                                }))
                                            }) as Rc<dyn Fn((bool, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                                        })))
                                    })
                                },
                                _ => prism_rtl::Turn::Finished(ok_ && !stmt_sets_weak(&s, &v_, &vi, &rels)),
                            },
                            _ => prism_rtl::Turn::Finished(ok_ && !stmt_sets_weak(&s, &v_, &vi, &rels)),
                        }
                    }))
                }) as Rc<dyn Fn((bool, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle()
        })
    }
}

/// `Start AllPathsStrict, x`: what the function value is when passed to `@Run`.
pub fn start_all_paths_strict(stmts: Array<crate::syntax::Stmt>, v_: Text, vi: Nat, outer: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(AllPathsStrict { stmts, v_, vi, outer })
}

/// ```prism
/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn sets_weak(stmts: &Array<crate::syntax::Stmt>, v_: &Text, vi: &Nat, outer: &Map<Text, crate::check::shrink::Rel>) -> bool {
    run_to_end(fold_job(crate::check::shrink::walk::stmts_spots(stmts, outer), false, {
        let v_ = v_.clone();
        let vi = vi.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
            let v_ = v_.clone();
            let vi = vi.clone();
            entered(once_job(move || {
                let seen = p0;
                let sp = p1;
                prism_rtl::Turn::Finished(seen || spot_sets_weak(&sp, &v_, &vi))
            }))
        }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `SetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct SetsWeak {
    pub stmts: Array<crate::syntax::Stmt>,
    pub v_: Text,
    pub vi: Nat,
    pub outer: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<bool> for SetsWeak {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let stmts = &self.stmts;
        let v_ = &self.v_;
        let vi = &self.vi;
        let outer = &self.outer;
        let outer = outer.clone();
        let stmts = stmts.clone();
        let v_ = v_.clone();
        let vi = vi.clone();
        call_then(crate::check::shrink::walk::start_stmts_spots(stmts.clone(), outer.clone()), move |stmts_spots_17553: Array<crate::check::shrink::walk::Spot>| fold_job(stmts_spots_17553, false, {
            let v_ = v_.clone();
            let vi = vi.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                let v_ = v_.clone();
                let vi = vi.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let sp = p1;
                    prism_rtl::Turn::Finished(seen || spot_sets_weak(&sp, &v_, &vi))
                }))
            }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start SetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_sets_weak(stmts: Array<crate::syntax::Stmt>, v_: Text, vi: Nat, outer: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SetsWeak { stmts, v_, vi, outer })
}

/// ```prism
/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn stmt_sets_weak(s: &crate::syntax::Stmt, v_: &Text, vi: &Nat, rels: &Map<Text, crate::check::shrink::Rel>) -> bool {
    run_to_end(fold_job(crate::check::shrink::walk::stmt_spots(s, rels), false, {
        let v_ = v_.clone();
        let vi = vi.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
            let v_ = v_.clone();
            let vi = vi.clone();
            entered(once_job(move || {
                let seen = p0;
                let sp = p1;
                prism_rtl::Turn::Finished(seen || spot_sets_weak(&sp, &v_, &vi))
            }))
        }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `StmtSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct StmtSetsWeak {
    pub s: crate::syntax::Stmt,
    pub v_: Text,
    pub vi: Nat,
    pub rels: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<bool> for StmtSetsWeak {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let s = &self.s;
        let v_ = &self.v_;
        let vi = &self.vi;
        let rels = &self.rels;
        let rels = rels.clone();
        let s = s.clone();
        let v_ = v_.clone();
        let vi = vi.clone();
        call_then(crate::check::shrink::walk::start_stmt_spots(s.clone(), rels.clone()), move |stmt_spots_17736: Array<crate::check::shrink::walk::Spot>| fold_job(stmt_spots_17736, false, {
            let v_ = v_.clone();
            let vi = vi.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::shrink::walk::Spot)| {
                let v_ = v_.clone();
                let vi = vi.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let sp = p1;
                    prism_rtl::Turn::Finished(seen || spot_sets_weak(&sp, &v_, &vi))
                }))
            }) as Rc<dyn Fn((bool, crate::check::shrink::walk::Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start StmtSetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_sets_weak(s: crate::syntax::Stmt, v_: Text, vi: Nat, rels: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(StmtSetsWeak { s, v_, vi, rels })
}

/// ```prism
/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub fn spot_sets_weak(spot0: &crate::check::shrink::walk::Spot, text1: &Text, n2: &Nat) -> bool {
    match (spot0, text1, n2) {
        (crate::check::shrink::walk::Spot::SpotStmt(s, m), v_, vi) => match &s.kind {
            crate::syntax::StmtKind::SSet(t, value) => ((&take(&crate::check::passes::borrows::ref_path(t), &Nat::from(1u32)) == &Array::from(vec![v_.clone()])) && !sets_strict(value, v_, vi, m)) && !((&crate::check::passes::borrows::ref_path(t) == &Array::from(vec![v_.clone()])) && is_zero_lit(value)),
            crate::syntax::StmtKind::SAccum(t, _, _) => &take(&crate::check::passes::borrows::ref_path(t), &Nat::from(1u32)) == &Array::from(vec![v_.clone()]),
            _ => false,
        },
        (crate::check::shrink::walk::Spot::SpotExpr(_, _), _, _) => false,
    }
}

/// The step machine of `SpotSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub struct SpotSetsWeak {
    pub spot0: crate::check::shrink::walk::Spot,
    pub text1: Text,
    pub n2: Nat,
}

impl prism_rtl::Job<bool> for SpotSetsWeak {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let spot0 = &self.spot0;
        let text1 = &self.text1;
        let n2 = &self.n2;
        match (spot0, text1, n2) {
            (crate::check::shrink::walk::Spot::SpotStmt(s, m), v_, vi) => match &s.kind {
                crate::syntax::StmtKind::SSet(t, value) => {
                    let m = m.clone();
                    let t = t.clone();
                    let v_ = v_.clone();
                    let value = value.clone();
                    let vi = vi.clone();
                    call_then(crate::check::passes::borrows::start_ref_path(t.clone()), move |ref_path_17939: Array<Text>| prism_rtl::Turn::Finished(((&take(&ref_path_17939, &Nat::from(1u32)) == &Array::from(vec![v_.clone()])) && !sets_strict(&value, &v_, &vi, &m)) && !((&crate::check::passes::borrows::ref_path(&t) == &Array::from(vec![v_.clone()])) && is_zero_lit(&value))))
                },
                crate::syntax::StmtKind::SAccum(t, _, _) => {
                    let t = t.clone();
                    let v_ = v_.clone();
                    call_then(crate::check::passes::borrows::start_ref_path(t.clone()), move |ref_path_18088: Array<Text>| prism_rtl::Turn::Finished(&take(&ref_path_18088, &Nat::from(1u32)) == &Array::from(vec![v_.clone()])))
                },
                _ => prism_rtl::Turn::Finished(false),
            },
            (crate::check::shrink::walk::Spot::SpotExpr(_, _), _, _) => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start SpotSetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_spot_sets_weak(spot0: crate::check::shrink::walk::Spot, text1: Text, n2: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SpotSetsWeak { spot0, text1, n2 })
}

/// ```prism
/// IsZeroLit: fn Expr -> Bool
/// ```
pub fn is_zero_lit(e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::ELit(l) => match &l.kind {
            crate::syntax::LitKind::LInt(d) => d == &Text::lit("0"),
            _ => false,
        },
        crate::syntax::ExprKind::EGroup(x) => is_zero_lit(&**x),
        _ => false,
    }
}

/// ```prism
/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn sets_strict(e: &crate::syntax::Expr, v_: &Text, vi: &Nat, rels: &Map<Text, crate::check::shrink::Rel>) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::EGroup(x) => sets_strict(&**x, v_, vi, rels),
        crate::syntax::ExprKind::EBinary(m19465_1_0, l, _) if (m19465_1_0 == &Text::lit("-?")) => is_nat_minus(rels, e) && sets_strict(&**l, v_, vi, rels),
        _ => rel_strict(rels, e, vi) || call_strict(e, v_, vi, rels),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SetsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct SetsStrict {
    pub e: crate::syntax::Expr,
    pub v_: Text,
    pub vi: Nat,
    pub rels: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<bool> for SetsStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let e = &self.e;
        let v_ = &self.v_;
        let vi = &self.vi;
        let rels = &self.rels;
        match &*e.kind {
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(SetsStrict { e: (**x).clone(), v_: v_.clone(), vi: vi.clone(), rels: rels.clone() })),
            crate::syntax::ExprKind::EBinary(m19465_1_0, l, _) if (m19465_1_0 == &Text::lit("-?")) => prism_rtl::Turn::Finished(is_nat_minus(rels, e) && sets_strict(&**l, v_, vi, rels)),
            _ => {
                let e = e.clone();
                let rels = rels.clone();
                let v_ = v_.clone();
                let vi = vi.clone();
                call_then(start_rel_strict(rels.clone(), e.clone(), vi.clone()), move |rel_strict_19615: bool| prism_rtl::Turn::Finished(rel_strict_19615 || call_strict(&e, &v_, &vi, &rels)))
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SetsStrict, x`: what the function value is when passed to `@Run`.
pub fn start_sets_strict(e: crate::syntax::Expr, v_: Text, vi: Nat, rels: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SetsStrict { e, v_, vi, rels })
}

/// ```prism
/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
/// ```
pub fn rel_strict(rels: &Map<Text, crate::check::shrink::Rel>, e: &crate::syntax::Expr, vi: &Nat) -> bool {
    match crate::check::shrink::walk::rel_of(rels, e) {
        Some(r) => r.strict && (&r.param == vi),
        None => false,
    }
}

/// The step machine of `RelStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
/// ```
pub struct RelStrict {
    pub rels: Map<Text, crate::check::shrink::Rel>,
    pub e: crate::syntax::Expr,
    pub vi: Nat,
}

impl prism_rtl::Job<bool> for RelStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let rels = &self.rels;
        let e = &self.e;
        let vi = &self.vi;
        let e = e.clone();
        let rels = rels.clone();
        let vi = vi.clone();
        call_then(crate::check::shrink::walk::start_rel_of(rels.clone(), e.clone()), move |rel_of_19761: Option<crate::check::shrink::Rel>| match rel_of_19761 {
            Some(r) => prism_rtl::Turn::Finished(r.strict && (&r.param == &vi)),
            None => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start RelStrict, x`: what the function value is when passed to `@Run`.
pub fn start_rel_strict(rels: Map<Text, crate::check::shrink::Rel>, e: crate::syntax::Expr, vi: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(RelStrict { rels, e, vi })
}

/// ```prism
/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn call_strict(e: &crate::syntax::Expr, v_: &Text, vi: &Nat, rels: &Map<Text, crate::check::shrink::Rel>) -> bool {
    match crate::check::shrink::walk::call_of(e) {
        Some((c, args)) => if crate::check::shrink::walk::is_non_nat_min(rels, e, &c) {
            false
        } else {
            match crate::check::shrink::walk::no_larger_arg(rels, &c, &args) {
                Some(a) => sets_strict(&a, v_, vi, rels),
                None => false,
            }
        },
        None => false,
    }
}

/// The step machine of `CallStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct CallStrict {
    pub e: crate::syntax::Expr,
    pub v_: Text,
    pub vi: Nat,
    pub rels: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<bool> for CallStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let e = &self.e;
        let v_ = &self.v_;
        let vi = &self.vi;
        let rels = &self.rels;
        match crate::check::shrink::walk::call_of(e) {
            Some((c, args)) => if crate::check::shrink::walk::is_non_nat_min(rels, e, &c) {
                prism_rtl::Turn::Finished(false)
            } else {
                match crate::check::shrink::walk::no_larger_arg(rels, &c, &args) {
                    Some(a) => prism_rtl::Turn::More(Rc::new(SetsStrict { e: a.clone(), v_: v_.clone(), vi: vi.clone(), rels: rels.clone() })),
                    None => prism_rtl::Turn::Finished(false),
                }
            },
            None => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start CallStrict, x`: what the function value is when passed to `@Run`.
pub fn start_call_strict(e: crate::syntax::Expr, v_: Text, vi: Nat, rels: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(CallStrict { e, v_, vi, rels })
}
