//! The module `Check.Shrink.Relations`, from `target/bootstrap/src/prismc/check/shrink/relations.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Hide: fn (Text ==> Rel), [Text] -> (Text ==> Rel)
/// ```
pub fn hide_f(m_p0: &Map<Text, crate::check::shrink::Rel>, names_p1: &Array<Text>) -> Map<Text, crate::check::shrink::Rel> {
    crate::prelude::fold(names_p1, m_p0, &(|m2_p2: &Map<Text, crate::check::shrink::Rel>, n_p3: &Text| crate::prelude::insert(&crate::prelude::remove(&crate::prelude::remove(&crate::prelude::remove(&crate::prelude::remove(m2_p2, n_p3), &Text::from(format!("ne:{}", n_p3))), &Text::from(format!("lamlet:{}", n_p3))), &Text::from(format!("lfn:{}", n_p3))), &Text::from(format!("local:{}", n_p3)), &no_rel_p())))
}

/// ```prism
/// let noRel
/// ```
pub fn no_rel_p() -> crate::check::shrink::Rel {
    crate::check::shrink::Rel { param_p: Nat::from(0u32), strict_p: false }
}

/// ```prism
/// IsLocal: fn (Text ==> Rel), Text -> Bool
/// ```
pub fn is_local_f(m_p0: &Map<Text, crate::check::shrink::Rel>, n_p1: &Text) -> bool {
    crate::check::env::has_key_f(m_p0, &Text::from(format!("local:{}", n_p1)))
}

/// ```prism
/// PreIs: fn (Text ==> Rel), Text, Text -> Bool
/// ```
pub fn pre_is_f(m_p0: &Map<Text, crate::check::shrink::Rel>, n_p1: &Text, bare_p2: &Text) -> bool {
    (((n_p1 == bare_p2) || (n_p1 == &Text::from(format!("Prelude.{}", bare_p2)))) && crate::check::env::has_key_f(m_p0, &Text::from(format!("pre:{}", n_p1)))) && !is_local_f(m_p0, n_p1)
}

/// ```prism
/// let preludeNames
/// ```
pub fn prelude_names_p() -> Array<Text> {
    Array::from(vec![Text::lit("Drop"), Text::lit("Take"), Text::lit("Filter"), Text::lit("Remove"), Text::lit("Min"), Text::lit("Values"), Text::lit("Keys"), Text::lit("?Step"), Text::lit("Fold"), Text::lit("Each"), Text::lit("Push"), Text::lit("Insert"), Text::lit("Append"), Text::lit("Freeze"), Text::lit("-?"), Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")])
}

/// ```prism
/// PreludeSeeds: fn G, Text -> (Text ==> Rel)
/// ```
pub fn prelude_seeds_f(g_p0: &crate::check::env::G, h_p1: &Text) -> Map<Text, crate::check::shrink::Rel> {
    crate::prelude::fold(&prelude_names_p(), &Map::new(), &(|m_p2: &Map<Text, crate::check::shrink::Rel>, n_p3: &Text| {
        let q_p4 = Text::from(format!("Prelude.{}", n_p3));
        if !is_prelude_key_f(g_p0, &q_p4) {
            m_p2.clone()
        } else {
            crate::prelude::fold(&Array::from(vec![n_p3.clone(), q_p4.clone()]), m_p2, &(|m2_p5: &Map<Text, crate::check::shrink::Rel>, sp_p6: &Text| if &crate::check::shrink::locals::resolve_callee_o(g_p0, h_p1, sp_p6) == &Some(q_p4.clone()) {
                crate::prelude::insert(m2_p5, &Text::from(format!("pre:{}", sp_p6)), &no_rel_p())
            } else {
                m2_p5.clone()
            }))
        }
    }))
}

/// ```prism
/// IsPreludeKey: fn G, Text -> Bool
/// ```
pub fn is_prelude_key_f(g_p0: &crate::check::env::G, q_p1: &Text) -> bool {
    match crate::prelude::get(&g_p0.vals_p, q_p1) {
        Some(v_p2) => (crate::syntax::lexer::chars::has_prefix_f(q_p1, &Text::lit("Prelude.")) && (&v_p2.home_p == &Text::lit("Prelude"))) && (&v_p2.file_p >= &g_p0.prelude_from_p),
        None => false,
    }
}

/// ```prism
/// BlockRels: unbounded fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn block_rels_f(stmts_p0: &Array<crate::syntax::Stmt>, m_p1: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p0.clone(), local_fn_marks_f(stmts_p0, &hide_f(m_p1, &stmts_binders_f(stmts_p0))), Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let m2_p2 = p0;
        let s_p3 = p1;
        crate::prelude::call_then(start_stmt_rels_f(s_p3.clone(), m2_p2.clone()), move |stmt_rels_f_4447: Map<Text, crate::check::shrink::Rel>| prism_rtl::Turn::Finished(crate::check::passes::cycles::lam_let_rels_f(&s_p3, &stmt_rels_f_4447)))
    }))) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>))
}

/// The step machine of `BlockRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockRels: unbounded fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct BlockRels {
    pub stmts_p0: Array<crate::syntax::Stmt>,
    pub m_p1: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for BlockRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let stmts_p0 = &self.stmts_p0;
        let m_p1 = &self.m_p1;
        let m_p1x = m_p1.clone();
        let stmts_p0x = stmts_p0.clone();
        crate::prelude::call_then(start_stmts_binders_f(stmts_p0x.clone()), move |stmts_binders_f_4400: Array<Text>| crate::prelude::fold_job(stmts_p0x.clone(), local_fn_marks_f(&stmts_p0x, &hide_f(&m_p1x, &stmts_binders_f_4400)), Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
            let m2_p2 = p0;
            let s_p3 = p1;
            crate::prelude::call_then(start_stmt_rels_f(s_p3.clone(), m2_p2.clone()), move |stmt_rels_f_4447: Map<Text, crate::check::shrink::Rel>| prism_rtl::Turn::Finished(crate::check::passes::cycles::lam_let_rels_f(&s_p3, &stmt_rels_f_4447)))
        }))) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>).cycle())
    }
}

/// `Start BlockRels, x`: what the function value is when passed to `@Run`.
pub fn start_block_rels_f(stmts_p0: Array<crate::syntax::Stmt>, m_p1: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(BlockRels { stmts_p0, m_p1 })
}

/// ```prism
/// LocalFnMarks: fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn local_fn_marks_f(stmts_p0: &Array<crate::syntax::Stmt>, m_p1: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    crate::prelude::fold(stmts_p0, m_p1, &(|m2_p2: &Map<Text, crate::check::shrink::Rel>, s_p3: &crate::syntax::Stmt| {
        let n_o4 = match &s_p3.kind_p {
            crate::syntax::StmtKind::SFn(f_p5) => Some(crate::check::env::def_name_text_f(&f_p5.name_p)),
            crate::syntax::StmtKind::SWidget(w_p6) => Some(crate::check::env::sname_key_f(&w_p6.name_p)),
            _ => None,
        };
        match &n_o4 {
            Some(n_p7) => if crate::check::env::has_key_f(m2_p2, &Text::from(format!("lfn:{}", n_p7))) {
                m2_p2.clone()
            } else {
                crate::prelude::insert(m2_p2, &Text::from(format!("lfn:{}", n_p7)), &crate::check::shrink::Rel { param_p: s_p3.span_p.start_p.clone(), strict_p: false })
            },
            None => m2_p2.clone(),
        }
    }))
}

/// ```prism
/// StmtsBinders: unbounded fn [Stmt] -> [Text]
/// ```
pub fn stmts_binders_f(stmts_p0: &Array<crate::syntax::Stmt>) -> Array<Text> {
    crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p1 = p0;
        let s_p2 = p1;
        match &s_p2.kind_p {
            crate::syntax::StmtKind::SLet(p_p3, _, _) => {
                let p_p3x = p_p3.clone();
                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p3x.clone()), move |pattern_names_f_5121: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p1, &pattern_names_f_5121)))
            },
            crate::syntax::StmtKind::SBind(p_p4, _, _) => {
                let p_p4x = p_p4.clone();
                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p4x.clone()), move |pattern_names_f_5183: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p1, &pattern_names_f_5183)))
            },
            crate::syntax::StmtKind::SFn(f_p5) => prism_rtl::Turn::Finished(crate::check::types::add_text_f(&acc_p1, &crate::check::env::def_name_text_f(&f_p5.name_p))),
            crate::syntax::StmtKind::SWidget(w_p6) => prism_rtl::Turn::Finished(crate::check::types::add_text_f(&acc_p1, &crate::check::env::sname_key_f(&w_p6.name_p))),
            _ => prism_rtl::Turn::Finished(acc_p1.clone()),
        }
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `StmtsBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsBinders: unbounded fn [Stmt] -> [Text]
/// ```
pub struct StmtsBinders {
    pub stmts_p0: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<Text>> for StmtsBinders {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let stmts_p0 = &self.stmts_p0;
        crate::prelude::fold_job(stmts_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p1 = p0;
            let s_p2 = p1;
            match &s_p2.kind_p {
                crate::syntax::StmtKind::SLet(p_p3, _, _) => {
                    let p_p3x = p_p3.clone();
                    crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p3x.clone()), move |pattern_names_f_5121: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p1, &pattern_names_f_5121)))
                },
                crate::syntax::StmtKind::SBind(p_p4, _, _) => {
                    let p_p4x = p_p4.clone();
                    crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p4x.clone()), move |pattern_names_f_5183: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p1, &pattern_names_f_5183)))
                },
                crate::syntax::StmtKind::SFn(f_p5) => prism_rtl::Turn::Finished(crate::check::types::add_text_f(&acc_p1, &crate::check::env::def_name_text_f(&f_p5.name_p))),
                crate::syntax::StmtKind::SWidget(w_p6) => prism_rtl::Turn::Finished(crate::check::types::add_text_f(&acc_p1, &crate::check::env::sname_key_f(&w_p6.name_p))),
                _ => prism_rtl::Turn::Finished(acc_p1.clone()),
            }
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
    }
}

/// `Start StmtsBinders, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_binders_f(stmts_p0: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(StmtsBinders { stmts_p0 })
}

/// ```prism
/// StmtRels: unbounded fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn stmt_rels_f(s_p0: &crate::syntax::Stmt, m_p1: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SLet(p_p2, _, e_p3) => bind_rels_f(p_p2, e_p3, m_p1, &false),
        crate::syntax::StmtKind::SBind(p_p4, e_p5, None) => bind_rels_f(p_p4, e_p5, m_p1, &true),
        _ => m_p1.clone(),
    }
}

/// The step machine of `StmtRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtRels: unbounded fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct StmtRels {
    pub s_p0: crate::syntax::Stmt,
    pub m_p1: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for StmtRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let s_p0 = &self.s_p0;
        let m_p1 = &self.m_p1;
        match &s_p0.kind_p {
            crate::syntax::StmtKind::SLet(p_p2, _, e_p3) => prism_rtl::Turn::More(Rc::new(BindRels { p_p0: p_p2.clone(), e_p1: e_p3.clone(), m_p2: m_p1.clone(), refutable_p3: false })),
            crate::syntax::StmtKind::SBind(p_p4, e_p5, None) => prism_rtl::Turn::More(Rc::new(BindRels { p_p0: p_p4.clone(), e_p1: e_p5.clone(), m_p2: m_p1.clone(), refutable_p3: true })),
            _ => prism_rtl::Turn::Finished(m_p1.clone()),
        }
    }
}

/// `Start StmtRels, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_rels_f(s_p0: crate::syntax::Stmt, m_p1: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(StmtRels { s_p0, m_p1 })
}

/// ```prism
/// BindRels: unbounded fn Pattern, Expr, (Text ==> Rel), Bool -> (Text ==> Rel)
/// ```
pub fn bind_rels_f(p_p0: &crate::syntax::Pattern_, e_p1: &crate::syntax::Expr, m_p2: &Map<Text, crate::check::shrink::Rel>, refutable_p3: &bool) -> Map<Text, crate::check::shrink::Rel> {
    let base_o4 = crate::check::shrink::walk::rel_of_o(m_p2, e_p1);
    let dec_o5 = crate::check::shrink::summaries::decrement_of_o(m_p2, e_p1);
    let h_p6 = non_empty_rels_f(&hide_f(m_p2, &crate::check::env::names::pattern_names_f(p_p0)), p_p0, e_p1, refutable_p3);
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p7) => match &base_o4 {
            Some(r_p8) => crate::prelude::insert(&h_p6, &crate::check::env::sname_key_f(n_p7), r_p8),
            None => match &dec_o5 {
                Some(r_p9) => if *refutable_p3 {
                    crate::prelude::insert(&h_p6, &crate::check::env::sname_key_f(n_p7), r_p9)
                } else {
                    h_p6.clone()
                },
                None => h_p6.clone(),
            },
        },
        crate::syntax::PatternKind::PSigil(m5947_1_0, inner_pa) if (m5947_1_0 == &Text::lit("?")) => match &dec_o5 {
            Some(r_pb) => crate::prelude::fold(&crate::check::env::names::pattern_names_f(&**inner_pa), &h_p6, &(|m2_pc: &Map<Text, crate::check::shrink::Rel>, n_pd: &Text| crate::prelude::insert(m2_pc, n_pd, r_pb))),
            None => match &base_o4 {
                Some(r_pe) => crate::prelude::fold(&crate::check::env::names::pattern_names_f(&**inner_pa), &h_p6, &(|m2_pf: &Map<Text, crate::check::shrink::Rel>, n_pg: &Text| crate::prelude::insert(m2_pf, n_pg, &crate::check::shrink::Rel { param_p: r_pe.param_p.clone(), strict_p: true }))),
                None => h_p6.clone(),
            },
        },
        _ => match &base_o4 {
            Some(r_ph) => crate::prelude::fold(&crate::check::env::names::pattern_names_f(p_p0), &h_p6, &(|m2_pi: &Map<Text, crate::check::shrink::Rel>, n_pj: &Text| crate::prelude::insert(m2_pi, n_pj, &crate::check::shrink::Rel { param_p: r_ph.param_p.clone(), strict_p: true }))),
            None => h_p6.clone(),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BindRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindRels: unbounded fn Pattern, Expr, (Text ==> Rel), Bool -> (Text ==> Rel)
/// ```
pub struct BindRels {
    pub p_p0: crate::syntax::Pattern_,
    pub e_p1: crate::syntax::Expr,
    pub m_p2: Map<Text, crate::check::shrink::Rel>,
    pub refutable_p3: bool,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for BindRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let p_p0 = &self.p_p0;
        let e_p1 = &self.e_p1;
        let m_p2 = &self.m_p2;
        let refutable_p3 = &self.refutable_p3;
        let e_p1x = e_p1.clone();
        let m_p2x = m_p2.clone();
        let p_p0x = p_p0.clone();
        let refutable_p3x = *refutable_p3;
        crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(m_p2x.clone(), e_p1x.clone()), move |rel_of_o_5829: Option<crate::check::shrink::Rel>| {
            let base_o4 = rel_of_o_5829;
            crate::prelude::call_then(crate::check::shrink::summaries::start_decrement_of_o(m_p2x.clone(), e_p1x.clone()), move |decrement_of_o_5856: Option<crate::check::shrink::Rel>| {
                let dec_o5 = decrement_of_o_5856;
                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p0x.clone()), move |pattern_names_f_5909: Array<Text>| crate::prelude::call_then(start_non_empty_rels_f(hide_f(&m_p2x, &pattern_names_f_5909), p_p0x.clone(), e_p1x.clone(), refutable_p3x), move |non_empty_rels_f_5886: Map<Text, crate::check::shrink::Rel>| {
                    let h_p6 = non_empty_rels_f_5886;
                    match &*p_p0x.kind_p {
                        crate::syntax::PatternKind::PName(n_p7) => match &base_o4 {
                            Some(r_p8) => prism_rtl::Turn::Finished(crate::prelude::insert(&h_p6, &crate::check::env::sname_key_f(n_p7), r_p8)),
                            None => match &dec_o5 {
                                Some(r_p9) => if refutable_p3x {
                                    prism_rtl::Turn::Finished(crate::prelude::insert(&h_p6, &crate::check::env::sname_key_f(n_p7), r_p9))
                                } else {
                                    prism_rtl::Turn::Finished(h_p6.clone())
                                },
                                None => prism_rtl::Turn::Finished(h_p6.clone()),
                            },
                        },
                        crate::syntax::PatternKind::PSigil(m5947_1_0, inner_pa) if (m5947_1_0 == &Text::lit("?")) => match &dec_o5 {
                            Some(r_pb) => {
                                let inner_pax = (**inner_pa).clone();
                                let r_pbx = r_pb.clone();
                                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(inner_pax.clone()), move |pattern_names_f_6217: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::fold(&pattern_names_f_6217, &h_p6, &(|m2_pc: &Map<Text, crate::check::shrink::Rel>, n_pd: &Text| crate::prelude::insert(m2_pc, n_pd, &r_pbx)))))
                            },
                            None => match &base_o4 {
                                Some(r_pe) => {
                                    let inner_pax = (**inner_pa).clone();
                                    let r_pex = r_pe.clone();
                                    crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(inner_pax.clone()), move |pattern_names_f_6323: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::fold(&pattern_names_f_6323, &h_p6, &(|m2_pf: &Map<Text, crate::check::shrink::Rel>, n_pg: &Text| crate::prelude::insert(m2_pf, n_pg, &crate::check::shrink::Rel { param_p: r_pex.param_p.clone(), strict_p: true })))))
                                },
                                None => prism_rtl::Turn::Finished(h_p6.clone()),
                            },
                        },
                        _ => match &base_o4 {
                            Some(r_ph) => {
                                let r_phx = r_ph.clone();
                                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p0x.clone()), move |pattern_names_f_6480: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::fold(&pattern_names_f_6480, &h_p6, &(|m2_pi: &Map<Text, crate::check::shrink::Rel>, n_pj: &Text| crate::prelude::insert(m2_pi, n_pj, &crate::check::shrink::Rel { param_p: r_phx.param_p.clone(), strict_p: true })))))
                            },
                            None => prism_rtl::Turn::Finished(h_p6.clone()),
                        },
                        _ => unreachable!("no arm matched"),
                    }
                }))
            })
        })
    }
}

/// `Start BindRels, x`: what the function value is when passed to `@Run`.
pub fn start_bind_rels_f(p_p0: crate::syntax::Pattern_, e_p1: crate::syntax::Expr, m_p2: Map<Text, crate::check::shrink::Rel>, refutable_p3: bool) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(BindRels { p_p0, e_p1, m_p2, refutable_p3 })
}

/// ```prism
/// NonEmptyRels: unbounded fn (Text ==> Rel), Pattern, Expr, Bool -> (Text ==> Rel)
/// ```
pub fn non_empty_rels_f(m_p0: &Map<Text, crate::check::shrink::Rel>, p_p1: &crate::syntax::Pattern_, e_p2: &crate::syntax::Expr, refutable_p3: &bool) -> Map<Text, crate::check::shrink::Rel> {
    if !*refutable_p3 {
        m_p0.clone()
    } else {
        match non_empty_name_o(p_p1, e_p2) {
            Some(n_p4) => if crate::check::types::has_text_f(&crate::check::env::names::pattern_names_f(p_p1), &n_p4) {
                m_p0.clone()
            } else {
                crate::prelude::insert(m_p0, &Text::from(format!("ne:{}", &n_p4)), &no_rel_p())
            },
            None => m_p0.clone(),
        }
    }
}

/// The step machine of `NonEmptyRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NonEmptyRels: unbounded fn (Text ==> Rel), Pattern, Expr, Bool -> (Text ==> Rel)
/// ```
pub struct NonEmptyRels {
    pub m_p0: Map<Text, crate::check::shrink::Rel>,
    pub p_p1: crate::syntax::Pattern_,
    pub e_p2: crate::syntax::Expr,
    pub refutable_p3: bool,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for NonEmptyRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let m_p0 = &self.m_p0;
        let p_p1 = &self.p_p1;
        let e_p2 = &self.e_p2;
        let refutable_p3 = &self.refutable_p3;
        if !*refutable_p3 {
            prism_rtl::Turn::Finished(m_p0.clone())
        } else {
            match non_empty_name_o(p_p1, e_p2) {
                Some(n_p4) => {
                    let m_p0x = m_p0.clone();
                    let p_p1x = p_p1.clone();
                    crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p1x.clone()), move |pattern_names_f_7016: Array<Text>| if crate::check::types::has_text_f(&pattern_names_f_7016, &n_p4) {
                        prism_rtl::Turn::Finished(m_p0x.clone())
                    } else {
                        prism_rtl::Turn::Finished(crate::prelude::insert(&m_p0x, &Text::from(format!("ne:{}", &n_p4)), &no_rel_p()))
                    })
                },
                None => prism_rtl::Turn::Finished(m_p0.clone()),
            }
        }
    }
}

/// `Start NonEmptyRels, x`: what the function value is when passed to `@Run`.
pub fn start_non_empty_rels_f(m_p0: Map<Text, crate::check::shrink::Rel>, p_p1: crate::syntax::Pattern_, e_p2: crate::syntax::Expr, refutable_p3: bool) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(NonEmptyRels { m_p0, p_p1, e_p2, refutable_p3 })
}

/// ```prism
/// ?NonEmptyName: fn Pattern, Expr -> ?Text
/// ```
pub fn non_empty_name_o(p_p0: &crate::syntax::Pattern_, e_p1: &crate::syntax::Expr) -> Option<Text> {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::EGroup(x_p2) => non_empty_name_o(p_p0, &**x_p2),
        crate::syntax::ExprKind::EIndex(r_p3, _) => match &*p_p0.kind_p {
            crate::syntax::PatternKind::PSigil(m7216_0_0, _) if (m7216_0_0 == &Text::lit("?")) => name_of_o(&**r_p3),
            crate::syntax::PatternKind::PGroup(q_p4) => non_empty_name_o(&**q_p4, e_p1),
            _ => None,
            _ => unreachable!("no arm matched"),
        },
        crate::syntax::ExprKind::EName(n_p5) => match &*p_p0.kind_p {
            crate::syntax::PatternKind::PArray(ps_p6) => if &crate::prelude::len(ps_p6) > &Nat::from(0u32) {
                Some(crate::check::env::sname_key_f(n_p5))
            } else {
                None
            },
            crate::syntax::PatternKind::PGroup(q_p7) => non_empty_name_o(&**q_p7, e_p1),
            _ => None,
        },
        _ => None,
    }
}

/// ```prism
/// ?NameOf: fn Expr -> ?Text
/// ```
pub fn name_of_o(e_p0: &crate::syntax::Expr) -> Option<Text> {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::EName(n_p1) => Some(crate::check::env::sname_key_f(n_p1)),
        crate::syntax::ExprKind::EGroup(x_p2) => name_of_o(&**x_p2),
        _ => None,
    }
}

/// ```prism
/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn arm_pat_rels_f(s_p0: &crate::syntax::Expr, a_p1: &crate::syntax::Arm, m_p2: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    match &a_p1.pattern_o {
        Some(p_p3) => bind_rels_f(p_p3, s_p0, m_p2, &true),
        None => m_p2.clone(),
    }
}

/// The step machine of `ArmPatRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct ArmPatRels {
    pub s_p0: crate::syntax::Expr,
    pub a_p1: crate::syntax::Arm,
    pub m_p2: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for ArmPatRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let s_p0 = &self.s_p0;
        let a_p1 = &self.a_p1;
        let m_p2 = &self.m_p2;
        match &a_p1.pattern_o {
            Some(p_p3) => prism_rtl::Turn::More(Rc::new(BindRels { p_p0: p_p3.clone(), e_p1: s_p0.clone(), m_p2: m_p2.clone(), refutable_p3: true })),
            None => prism_rtl::Turn::Finished(m_p2.clone()),
        }
    }
}

/// `Start ArmPatRels, x`: what the function value is when passed to `@Run`.
pub fn start_arm_pat_rels_f(s_p0: crate::syntax::Expr, a_p1: crate::syntax::Arm, m_p2: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(ArmPatRels { s_p0, a_p1, m_p2 })
}

/// ```prism
/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn cond_rels_f(c_p0: &crate::syntax::Cond, m_p1: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    match c_p0 {
        crate::syntax::Cond::CondBind(p_p2, x_p3, _) => bind_rels_f(p_p2, &**x_p3, m_p1, &true),
        crate::syntax::Cond::CondExpr(_) => m_p1.clone(),
    }
}

/// The step machine of `CondRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct CondRels {
    pub c_p0: crate::syntax::Cond,
    pub m_p1: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for CondRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let c_p0 = &self.c_p0;
        let m_p1 = &self.m_p1;
        match c_p0 {
            crate::syntax::Cond::CondBind(p_p2, x_p3, _) => prism_rtl::Turn::More(Rc::new(BindRels { p_p0: p_p2.clone(), e_p1: (**x_p3).clone(), m_p2: m_p1.clone(), refutable_p3: true })),
            crate::syntax::Cond::CondExpr(_) => prism_rtl::Turn::Finished(m_p1.clone()),
        }
    }
}

/// `Start CondRels, x`: what the function value is when passed to `@Run`.
pub fn start_cond_rels_f(c_p0: crate::syntax::Cond, m_p1: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(CondRels { c_p0, m_p1 })
}

/// ```prism
/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
/// ```
pub fn step_rels_f(m_p0: &Map<Text, crate::check::shrink::Rel>, coll_p1: &crate::syntax::Expr, ps_p2: &Array<crate::syntax::Pattern_>, at_p3: &Nat) -> Map<Text, crate::check::shrink::Rel> {
    let h_p4 = hide_f(m_p0, &crate::prelude::run_to_end(crate::prelude::fold_job(ps_p2.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
        let a_p5 = p0;
        let p_p6 = p1;
        crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p6.clone()), move |pattern_names_f_8705: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&a_p5, &pattern_names_f_8705)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)));
    match crate::check::shrink::walk::rel_of_o(m_p0, coll_p1) {
        Some(r_p7) => crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::drop(ps_p2, at_p3), h_p4.clone(), {
            let r_p7x = r_p7.clone();
            Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_)| {
                let r_p7xy = r_p7x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m2_p8 = p0;
                    let p_p9 = p1;
                    crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p9.clone()), move |pattern_names_f_8799: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::fold(&pattern_names_f_8799, &m2_p8, &(|m3_pa: &Map<Text, crate::check::shrink::Rel>, n_pb: &Text| crate::prelude::insert(m3_pa, n_pb, &crate::check::shrink::Rel { param_p: r_p7xy.param_p.clone(), strict_p: true })))))
                }))
            }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
        })),
        None => h_p4.clone(),
    }
}

/// The step machine of `StepRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
/// ```
pub struct StepRels {
    pub m_p0: Map<Text, crate::check::shrink::Rel>,
    pub coll_p1: crate::syntax::Expr,
    pub ps_p2: Array<crate::syntax::Pattern_>,
    pub at_p3: Nat,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for StepRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let m_p0 = &self.m_p0;
        let coll_p1 = &self.coll_p1;
        let ps_p2 = &self.ps_p2;
        let at_p3 = &self.at_p3;
        let at_p3x = at_p3.clone();
        let coll_p1x = coll_p1.clone();
        let m_p0x = m_p0.clone();
        let ps_p2x = ps_p2.clone();
        crate::prelude::call_value(crate::prelude::fold_job(ps_p2x.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_p5 = p0;
            let p_p6 = p1;
            crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p6.clone()), move |pattern_names_f_8705: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&a_p5, &pattern_names_f_8705)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_8667: Array<Text>| {
            let h_p4 = hide_f(&m_p0x, &fold_8667);
            crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(m_p0x.clone(), coll_p1x.clone()), move |rel_of_o_8732: Option<crate::check::shrink::Rel>| match rel_of_o_8732 {
                Some(r_p7) => crate::prelude::fold_job(crate::prelude::drop(&ps_p2x, &at_p3x), h_p4.clone(), {
                    let r_p7x = r_p7.clone();
                    Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_)| {
                        let r_p7xy = r_p7x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let m2_p8 = p0;
                            let p_p9 = p1;
                            crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p9.clone()), move |pattern_names_f_8799: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::fold(&pattern_names_f_8799, &m2_p8, &(|m3_pa: &Map<Text, crate::check::shrink::Rel>, n_pb: &Text| crate::prelude::insert(m3_pa, n_pb, &crate::check::shrink::Rel { param_p: r_p7xy.param_p.clone(), strict_p: true })))))
                        }))
                    }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
                }).cycle(),
                None => prism_rtl::Turn::Finished(h_p4.clone()),
            })
        })
    }
}

/// `Start StepRels, x`: what the function value is when passed to `@Run`.
pub fn start_step_rels_f(m_p0: Map<Text, crate::check::shrink::Rel>, coll_p1: crate::syntax::Expr, ps_p2: Array<crate::syntax::Pattern_>, at_p3: Nat) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(StepRels { m_p0, coll_p1, ps_p2, at_p3 })
}
