//! The module `Check.Shrink.Relations`, from `target/bootstrap/src/prismc/check/shrink/relations.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Hide: fn (Text ==> Rel), [Text] -> (Text ==> Rel)
/// ```
pub fn hide(m: &Map<Text, crate::check::shrink::Rel>, names: &Array<Text>) -> Map<Text, crate::check::shrink::Rel> {
    fold(names, m, &(|m2: &Map<Text, crate::check::shrink::Rel>, n: &Text| insert(&remove(&remove(&remove(&remove(m2, n), &Text::from(format!("ne:{}", n))), &Text::from(format!("lamlet:{}", n))), &Text::from(format!("lfn:{}", n))), &Text::from(format!("local:{}", n)), &no_rel())))
}

/// ```prism
/// let noRel
/// ```
pub fn no_rel() -> crate::check::shrink::Rel {
    crate::check::shrink::Rel { param: Nat::from(0u32), strict: false }
}

/// ```prism
/// IsLocal: fn (Text ==> Rel), Text -> Bool
/// ```
pub fn is_local(m: &Map<Text, crate::check::shrink::Rel>, n: &Text) -> bool {
    crate::check::env::has_key(m, &Text::from(format!("local:{}", n)))
}

/// ```prism
/// PreIs: fn (Text ==> Rel), Text, Text -> Bool
/// ```
pub fn pre_is(m: &Map<Text, crate::check::shrink::Rel>, n: &Text, bare: &Text) -> bool {
    (((n == bare) || (n == &Text::from(format!("Prelude.{}", bare)))) && crate::check::env::has_key(m, &Text::from(format!("pre:{}", n)))) && !is_local(m, n)
}

/// ```prism
/// let preludeNames
/// ```
pub fn prelude_names() -> Array<Text> {
    Array::from(vec![Text::lit("Drop"), Text::lit("Take"), Text::lit("Filter"), Text::lit("Remove"), Text::lit("Min"), Text::lit("Values"), Text::lit("Keys"), Text::lit("?Step"), Text::lit("Fold"), Text::lit("Each"), Text::lit("Push"), Text::lit("Insert"), Text::lit("Append"), Text::lit("Freeze"), Text::lit("-?"), Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")])
}

/// ```prism
/// PreludeSeeds: fn G, Text -> (Text ==> Rel)
/// ```
pub fn prelude_seeds(g: &crate::check::env::G, h: &Text) -> Map<Text, crate::check::shrink::Rel> {
    fold(&prelude_names(), &Map::new(), &(|m: &Map<Text, crate::check::shrink::Rel>, n: &Text| {
        let q = Text::from(format!("Prelude.{}", n));
        if !is_prelude_key(g, &q) {
            m.clone()
        } else {
            fold(&Array::from(vec![n.clone(), q.clone()]), m, &(|m2: &Map<Text, crate::check::shrink::Rel>, sp: &Text| if &crate::check::shrink::locals::resolve_callee(g, h, sp) == &Some(q.clone()) {
                insert(m2, &Text::from(format!("pre:{}", sp)), &no_rel())
            } else {
                m2.clone()
            }))
        }
    }))
}

/// ```prism
/// IsPreludeKey: fn G, Text -> Bool
/// ```
pub fn is_prelude_key(g: &crate::check::env::G, q: &Text) -> bool {
    match get(&g.vals, q) {
        Some(v_) => (crate::syntax::lexer::chars::has_prefix(q, &Text::lit("Prelude.")) && (&v_.home == &Text::lit("Prelude"))) && (&v_.file >= &g.prelude_from),
        None => false,
    }
}

/// ```prism
/// BlockRels: unbounded fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn block_rels(stmts: &Array<crate::syntax::Stmt>, m: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    run_to_end(fold_job(stmts.clone(), local_fn_marks(stmts, &hide(m, &stmts_binders(stmts))), Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt)| entered(once_job(move || {
        let m2 = p0;
        let s = p1;
        call_then(start_stmt_rels(s.clone(), m2.clone()), move |stmt_rels_4447: Map<Text, crate::check::shrink::Rel>| prism_rtl::Turn::Finished(crate::check::passes::cycles::lam_let_rels(&s, &stmt_rels_4447)))
    }))) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>))
}

/// The step machine of `BlockRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockRels: unbounded fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct BlockRels {
    pub stmts: Array<crate::syntax::Stmt>,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for BlockRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let stmts = &self.stmts;
        let m = &self.m;
        let m = m.clone();
        let stmts = stmts.clone();
        call_then(start_stmts_binders(stmts.clone()), move |stmts_binders_4400: Array<Text>| fold_job(stmts.clone(), local_fn_marks(&stmts, &hide(&m, &stmts_binders_4400)), Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt)| entered(once_job(move || {
            let m2 = p0;
            let s = p1;
            call_then(start_stmt_rels(s.clone(), m2.clone()), move |stmt_rels_4447: Map<Text, crate::check::shrink::Rel>| prism_rtl::Turn::Finished(crate::check::passes::cycles::lam_let_rels(&s, &stmt_rels_4447)))
        }))) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>).cycle())
    }
}

/// `Start BlockRels, x`: what the function value is when passed to `@Run`.
pub fn start_block_rels(stmts: Array<crate::syntax::Stmt>, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(BlockRels { stmts, m })
}

/// ```prism
/// LocalFnMarks: fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn local_fn_marks(stmts: &Array<crate::syntax::Stmt>, m: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    fold(stmts, m, &(|m2: &Map<Text, crate::check::shrink::Rel>, s: &crate::syntax::Stmt| {
        let n_opt = match &s.kind {
            crate::syntax::StmtKind::SFn(f) => Some(crate::check::env::def_name_text(&f.name)),
            crate::syntax::StmtKind::SWidget(w) => Some(crate::check::env::sname_key(&w.name)),
            _ => None,
        };
        match &n_opt {
            Some(n) => if crate::check::env::has_key(m2, &Text::from(format!("lfn:{}", n))) {
                m2.clone()
            } else {
                insert(m2, &Text::from(format!("lfn:{}", n)), &crate::check::shrink::Rel { param: s.span.start.clone(), strict: false })
            },
            None => m2.clone(),
        }
    }))
}

/// ```prism
/// StmtsBinders: unbounded fn [Stmt] -> [Text]
/// ```
pub fn stmts_binders(stmts: &Array<crate::syntax::Stmt>) -> Array<Text> {
    run_to_end(fold_job(stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| entered(once_job(move || {
        let acc = p0;
        let s = p1;
        match &s.kind {
            crate::syntax::StmtKind::SLet(p_, _, _) => {
                let p_ = p_.clone();
                call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_5121: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &pattern_names_5121)))
            },
            crate::syntax::StmtKind::SBind(p_, _, _) => {
                let p_ = p_.clone();
                call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_5183: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &pattern_names_5183)))
            },
            crate::syntax::StmtKind::SFn(f) => prism_rtl::Turn::Finished(crate::check::types::add_text(&acc, &crate::check::env::def_name_text(&f.name))),
            crate::syntax::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(crate::check::types::add_text(&acc, &crate::check::env::sname_key(&w.name))),
            _ => prism_rtl::Turn::Finished(acc.clone()),
        }
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `StmtsBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsBinders: unbounded fn [Stmt] -> [Text]
/// ```
pub struct StmtsBinders {
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<Text>> for StmtsBinders {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let stmts = &self.stmts;
        fold_job(stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Stmt)| entered(once_job(move || {
            let acc = p0;
            let s = p1;
            match &s.kind {
                crate::syntax::StmtKind::SLet(p_, _, _) => {
                    let p_ = p_.clone();
                    call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_5121: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &pattern_names_5121)))
                },
                crate::syntax::StmtKind::SBind(p_, _, _) => {
                    let p_ = p_.clone();
                    call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_5183: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &pattern_names_5183)))
                },
                crate::syntax::StmtKind::SFn(f) => prism_rtl::Turn::Finished(crate::check::types::add_text(&acc, &crate::check::env::def_name_text(&f.name))),
                crate::syntax::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(crate::check::types::add_text(&acc, &crate::check::env::sname_key(&w.name))),
                _ => prism_rtl::Turn::Finished(acc.clone()),
            }
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
    }
}

/// `Start StmtsBinders, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_binders(stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(StmtsBinders { stmts })
}

/// ```prism
/// StmtRels: unbounded fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn stmt_rels(s: &crate::syntax::Stmt, m: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    match &s.kind {
        crate::syntax::StmtKind::SLet(p_, _, e) => bind_rels(p_, e, m, &false),
        crate::syntax::StmtKind::SBind(p_, e, None) => bind_rels(p_, e, m, &true),
        _ => m.clone(),
    }
}

/// The step machine of `StmtRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtRels: unbounded fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct StmtRels {
    pub s: crate::syntax::Stmt,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for StmtRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let s = &self.s;
        let m = &self.m;
        match &s.kind {
            crate::syntax::StmtKind::SLet(p_, _, e) => prism_rtl::Turn::More(Rc::new(BindRels { p_: p_.clone(), e: e.clone(), m: m.clone(), refutable: false })),
            crate::syntax::StmtKind::SBind(p_, e, None) => prism_rtl::Turn::More(Rc::new(BindRels { p_: p_.clone(), e: e.clone(), m: m.clone(), refutable: true })),
            _ => prism_rtl::Turn::Finished(m.clone()),
        }
    }
}

/// `Start StmtRels, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_rels(s: crate::syntax::Stmt, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(StmtRels { s, m })
}

/// ```prism
/// BindRels: unbounded fn Pattern, Expr, (Text ==> Rel), Bool -> (Text ==> Rel)
/// ```
pub fn bind_rels(p_: &crate::syntax::Pattern_, e: &crate::syntax::Expr, m: &Map<Text, crate::check::shrink::Rel>, refutable: &bool) -> Map<Text, crate::check::shrink::Rel> {
    let base_opt = crate::check::shrink::walk::rel_of(m, e);
    let dec_opt = crate::check::shrink::summaries::decrement_of(m, e);
    let h = non_empty_rels(&hide(m, &crate::check::env::names::pattern_names(p_)), p_, e, refutable);
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => match &base_opt {
            Some(r) => insert(&h, &crate::check::env::sname_key(n), r),
            None => match &dec_opt {
                Some(r) => if *refutable { insert(&h, &crate::check::env::sname_key(n), r) } else { h.clone() },
                None => h.clone(),
            },
        },
        crate::syntax::PatternKind::PSigil(m5947_1_0, inner) if (m5947_1_0 == &Text::lit("?")) => match &dec_opt {
            Some(r) => fold(&crate::check::env::names::pattern_names(&**inner), &h, &(|m2: &Map<Text, crate::check::shrink::Rel>, n: &Text| insert(m2, n, r))),
            None => match &base_opt {
                Some(r) => fold(&crate::check::env::names::pattern_names(&**inner), &h, &(|m2: &Map<Text, crate::check::shrink::Rel>, n: &Text| insert(m2, n, &crate::check::shrink::Rel { param: r.param.clone(), strict: true }))),
                None => h.clone(),
            },
        },
        _ => match &base_opt {
            Some(r) => fold(&crate::check::env::names::pattern_names(p_), &h, &(|m2: &Map<Text, crate::check::shrink::Rel>, n: &Text| insert(m2, n, &crate::check::shrink::Rel { param: r.param.clone(), strict: true }))),
            None => h.clone(),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BindRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindRels: unbounded fn Pattern, Expr, (Text ==> Rel), Bool -> (Text ==> Rel)
/// ```
pub struct BindRels {
    pub p_: crate::syntax::Pattern_,
    pub e: crate::syntax::Expr,
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub refutable: bool,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for BindRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let p_ = &self.p_;
        let e = &self.e;
        let m = &self.m;
        let refutable = &self.refutable;
        let e = e.clone();
        let m = m.clone();
        let p_ = p_.clone();
        let refutable = *refutable;
        call_then(crate::check::shrink::walk::start_rel_of(m.clone(), e.clone()), move |rel_of_5829: Option<crate::check::shrink::Rel>| {
            let base_opt = rel_of_5829;
            call_then(crate::check::shrink::summaries::start_decrement_of(m.clone(), e.clone()), move |decrement_of_5856: Option<crate::check::shrink::Rel>| {
                let dec_opt = decrement_of_5856;
                call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_5909: Array<Text>| call_then(start_non_empty_rels(hide(&m, &pattern_names_5909), p_.clone(), e.clone(), refutable), move |non_empty_rels_5886: Map<Text, crate::check::shrink::Rel>| {
                    let h = non_empty_rels_5886;
                    match &*p_.kind {
                        crate::syntax::PatternKind::PName(n) => match &base_opt {
                            Some(r) => prism_rtl::Turn::Finished(insert(&h, &crate::check::env::sname_key(n), r)),
                            None => match &dec_opt {
                                Some(r) => if refutable {
                                    prism_rtl::Turn::Finished(insert(&h, &crate::check::env::sname_key(n), r))
                                } else {
                                    prism_rtl::Turn::Finished(h.clone())
                                },
                                None => prism_rtl::Turn::Finished(h.clone()),
                            },
                        },
                        crate::syntax::PatternKind::PSigil(m5947_1_0, inner) if (m5947_1_0 == &Text::lit("?")) => match &dec_opt {
                            Some(r) => {
                                let inner = (**inner).clone();
                                let r = r.clone();
                                call_then(crate::check::env::names::start_pattern_names(inner.clone()), move |pattern_names_6217: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_6217, &h, &(|m2: &Map<Text, crate::check::shrink::Rel>, n: &Text| insert(m2, n, &r)))))
                            },
                            None => match &base_opt {
                                Some(r) => {
                                    let inner = (**inner).clone();
                                    let r = r.clone();
                                    call_then(crate::check::env::names::start_pattern_names(inner.clone()), move |pattern_names_6323: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_6323, &h, &(|m2: &Map<Text, crate::check::shrink::Rel>, n: &Text| insert(m2, n, &crate::check::shrink::Rel { param: r.param.clone(), strict: true })))))
                                },
                                None => prism_rtl::Turn::Finished(h.clone()),
                            },
                        },
                        _ => match &base_opt {
                            Some(r) => {
                                let r = r.clone();
                                call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_6480: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_6480, &h, &(|m2: &Map<Text, crate::check::shrink::Rel>, n: &Text| insert(m2, n, &crate::check::shrink::Rel { param: r.param.clone(), strict: true })))))
                            },
                            None => prism_rtl::Turn::Finished(h.clone()),
                        },
                        _ => unreachable!("no arm matched"),
                    }
                }))
            })
        })
    }
}

/// `Start BindRels, x`: what the function value is when passed to `@Run`.
pub fn start_bind_rels(p_: crate::syntax::Pattern_, e: crate::syntax::Expr, m: Map<Text, crate::check::shrink::Rel>, refutable: bool) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(BindRels { p_, e, m, refutable })
}

/// ```prism
/// NonEmptyRels: unbounded fn (Text ==> Rel), Pattern, Expr, Bool -> (Text ==> Rel)
/// ```
pub fn non_empty_rels(m: &Map<Text, crate::check::shrink::Rel>, p_: &crate::syntax::Pattern_, e: &crate::syntax::Expr, refutable: &bool) -> Map<Text, crate::check::shrink::Rel> {
    if !*refutable {
        m.clone()
    } else {
        match non_empty_name(p_, e) {
            Some(n) => if crate::check::types::has_text(&crate::check::env::names::pattern_names(p_), &n) {
                m.clone()
            } else {
                insert(m, &Text::from(format!("ne:{}", &n)), &no_rel())
            },
            None => m.clone(),
        }
    }
}

/// The step machine of `NonEmptyRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NonEmptyRels: unbounded fn (Text ==> Rel), Pattern, Expr, Bool -> (Text ==> Rel)
/// ```
pub struct NonEmptyRels {
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub p_: crate::syntax::Pattern_,
    pub e: crate::syntax::Expr,
    pub refutable: bool,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for NonEmptyRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let m = &self.m;
        let p_ = &self.p_;
        let e = &self.e;
        let refutable = &self.refutable;
        if !*refutable {
            prism_rtl::Turn::Finished(m.clone())
        } else {
            match non_empty_name(p_, e) {
                Some(n) => {
                    let m = m.clone();
                    let p_ = p_.clone();
                    call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_7016: Array<Text>| if crate::check::types::has_text(&pattern_names_7016, &n) {
                        prism_rtl::Turn::Finished(m.clone())
                    } else {
                        prism_rtl::Turn::Finished(insert(&m, &Text::from(format!("ne:{}", &n)), &no_rel()))
                    })
                },
                None => prism_rtl::Turn::Finished(m.clone()),
            }
        }
    }
}

/// `Start NonEmptyRels, x`: what the function value is when passed to `@Run`.
pub fn start_non_empty_rels(m: Map<Text, crate::check::shrink::Rel>, p_: crate::syntax::Pattern_, e: crate::syntax::Expr, refutable: bool) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(NonEmptyRels { m, p_, e, refutable })
}

/// ```prism
/// ?NonEmptyName: fn Pattern, Expr -> ?Text
/// ```
pub fn non_empty_name(p_: &crate::syntax::Pattern_, e: &crate::syntax::Expr) -> Option<Text> {
    match &*e.kind {
        crate::syntax::ExprKind::EGroup(x) => non_empty_name(p_, &**x),
        crate::syntax::ExprKind::EIndex(r, _) => match &*p_.kind {
            crate::syntax::PatternKind::PSigil(m7216_0_0, _) if (m7216_0_0 == &Text::lit("?")) => name_of(&**r),
            crate::syntax::PatternKind::PGroup(q) => non_empty_name(&**q, e),
            _ => None,
            _ => unreachable!("no arm matched"),
        },
        crate::syntax::ExprKind::EName(n) => match &*p_.kind {
            crate::syntax::PatternKind::PArray(ps) => if &len(ps) > &Nat::from(0u32) { Some(crate::check::env::sname_key(n)) } else { None },
            crate::syntax::PatternKind::PGroup(q) => non_empty_name(&**q, e),
            _ => None,
        },
        _ => None,
    }
}

/// ```prism
/// ?NameOf: fn Expr -> ?Text
/// ```
pub fn name_of(e: &crate::syntax::Expr) -> Option<Text> {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => Some(crate::check::env::sname_key(n)),
        crate::syntax::ExprKind::EGroup(x) => name_of(&**x),
        _ => None,
    }
}

/// ```prism
/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn arm_pat_rels(s: &crate::syntax::Expr, a: &crate::syntax::Arm, m: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    match &a.pattern {
        Some(p_) => bind_rels(p_, s, m, &true),
        None => m.clone(),
    }
}

/// The step machine of `ArmPatRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct ArmPatRels {
    pub s: crate::syntax::Expr,
    pub a: crate::syntax::Arm,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for ArmPatRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let s = &self.s;
        let a = &self.a;
        let m = &self.m;
        match &a.pattern {
            Some(p_) => prism_rtl::Turn::More(Rc::new(BindRels { p_: p_.clone(), e: s.clone(), m: m.clone(), refutable: true })),
            None => prism_rtl::Turn::Finished(m.clone()),
        }
    }
}

/// `Start ArmPatRels, x`: what the function value is when passed to `@Run`.
pub fn start_arm_pat_rels(s: crate::syntax::Expr, a: crate::syntax::Arm, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(ArmPatRels { s, a, m })
}

/// ```prism
/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn cond_rels(c: &crate::syntax::Cond, m: &Map<Text, crate::check::shrink::Rel>) -> Map<Text, crate::check::shrink::Rel> {
    match c {
        crate::syntax::Cond::CondBind(p_, x, _) => bind_rels(p_, &**x, m, &true),
        crate::syntax::Cond::CondExpr(_) => m.clone(),
    }
}

/// The step machine of `CondRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct CondRels {
    pub c: crate::syntax::Cond,
    pub m: Map<Text, crate::check::shrink::Rel>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for CondRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let c = &self.c;
        let m = &self.m;
        match c {
            crate::syntax::Cond::CondBind(p_, x, _) => prism_rtl::Turn::More(Rc::new(BindRels { p_: p_.clone(), e: (**x).clone(), m: m.clone(), refutable: true })),
            crate::syntax::Cond::CondExpr(_) => prism_rtl::Turn::Finished(m.clone()),
        }
    }
}

/// `Start CondRels, x`: what the function value is when passed to `@Run`.
pub fn start_cond_rels(c: crate::syntax::Cond, m: Map<Text, crate::check::shrink::Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(CondRels { c, m })
}

/// ```prism
/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
/// ```
pub fn step_rels(m: &Map<Text, crate::check::shrink::Rel>, coll: &crate::syntax::Expr, ps: &Array<crate::syntax::Pattern_>, at_: &Nat) -> Map<Text, crate::check::shrink::Rel> {
    let h = hide(m, &run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
        let a = p0;
        let p_ = p1;
        call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_8705: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &pattern_names_8705)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)));
    match crate::check::shrink::walk::rel_of(m, coll) {
        Some(r) => run_to_end(fold_job(drop(ps, at_), h.clone(), {
            let r = r.clone();
            Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_)| {
                let r = r.clone();
                entered(once_job(move || {
                    let m2 = p0;
                    let p_ = p1;
                    call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_8799: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_8799, &m2, &(|m3: &Map<Text, crate::check::shrink::Rel>, n: &Text| insert(m3, n, &crate::check::shrink::Rel { param: r.param.clone(), strict: true })))))
                }))
            }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
        })),
        None => h.clone(),
    }
}

/// The step machine of `StepRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
/// ```
pub struct StepRels {
    pub m: Map<Text, crate::check::shrink::Rel>,
    pub coll: crate::syntax::Expr,
    pub ps: Array<crate::syntax::Pattern_>,
    pub at_: Nat,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for StepRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let m = &self.m;
        let coll = &self.coll;
        let ps = &self.ps;
        let at_ = &self.at_;
        let at_ = at_.clone();
        let coll = coll.clone();
        let m = m.clone();
        let ps = ps.clone();
        call_value(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let a = p0;
            let p_ = p1;
            call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_8705: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &pattern_names_8705)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_8667: Array<Text>| {
            let h = hide(&m, &fold_8667);
            call_then(crate::check::shrink::walk::start_rel_of(m.clone(), coll.clone()), move |rel_of_8732: Option<crate::check::shrink::Rel>| match rel_of_8732 {
                Some(r) => fold_job(drop(&ps, &at_), h.clone(), {
                    let r = r.clone();
                    Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_)| {
                        let r = r.clone();
                        entered(once_job(move || {
                            let m2 = p0;
                            let p_ = p1;
                            call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_8799: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_8799, &m2, &(|m3: &Map<Text, crate::check::shrink::Rel>, n: &Text| insert(m3, n, &crate::check::shrink::Rel { param: r.param.clone(), strict: true })))))
                        }))
                    }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
                }).cycle(),
                None => prism_rtl::Turn::Finished(h.clone()),
            })
        })
    }
}

/// `Start StepRels, x`: what the function value is when passed to `@Run`.
pub fn start_step_rels(m: Map<Text, crate::check::shrink::Rel>, coll: crate::syntax::Expr, ps: Array<crate::syntax::Pattern_>, at_: Nat) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(StepRels { m, coll, ps, at_ })
}
