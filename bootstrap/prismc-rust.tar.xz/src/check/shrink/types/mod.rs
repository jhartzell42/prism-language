//! The module `Check.Shrink.Types`, from `target/bootstrap/src/prismc/check/shrink/types.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// NegativeTypes: unbounded fn G, St -> St
/// ```
pub fn negative_types_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> crate::check::types::St {
    let arrowy_p2 = arrowy_types_f(g_p0);
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g_p0.types_p), st_p1.clone(), {
        let g_p0x = g_p0.clone();
        let arrowy_p2x = arrowy_p2.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
            let g_p0xy = g_p0x.clone();
            let arrowy_p2xy = arrowy_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p3 = p0;
                let n_p4 = p1;
                prism_rtl::Turn::More(Rc::new(NegativeType { g_p0: g_p0xy.clone(), s_p1: s_p3.clone(), arrowy_p2: arrowy_p2xy.clone(), n_p3: n_p4.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `NegativeTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegativeTypes: unbounded fn G, St -> St
/// ```
pub struct NegativeTypes {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for NegativeTypes {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let g_p0x = g_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_arrowy_types_f(g_p0x.clone()), move |arrowy_types_f_1927: Map<Text, bool>| {
            let arrowy_p2 = arrowy_types_f_1927;
            crate::prelude::fold_job(crate::prelude::keys(&g_p0x.types_p), st_p1x.clone(), {
                let g_p0xx = g_p0x.clone();
                let arrowy_p2x = arrowy_p2.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
                    let g_p0xxy = g_p0xx.clone();
                    let arrowy_p2xy = arrowy_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_p3 = p0;
                        let n_p4 = p1;
                        prism_rtl::Turn::More(Rc::new(NegativeType { g_p0: g_p0xxy.clone(), s_p1: s_p3.clone(), arrowy_p2: arrowy_p2xy.clone(), n_p3: n_p4.clone() }))
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }).cycle()
        })
    }
}

/// `Start NegativeTypes, x`: what the function value is when passed to `@Run`.
pub fn start_negative_types_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(NegativeTypes { g_p0, st_p1 })
}

/// ```prism
/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
/// ```
pub fn negative_type_f(g_p0: &crate::check::env::G, s_p1: &crate::check::types::St, arrowy_p2: &Map<Text, bool>, n_p3: &Text) -> crate::check::types::St {
    match crate::prelude::get(&g_p0.types_p, n_p3) {
        Some(ti_p4) => {
            let (neg_p5, _) = if (&ti_p4.file_p >= &g_p0.prelude_from_p) || !crate::check::env::has_key_f(arrowy_p2, n_p3) {
                (false, Map::new())
            } else {
                neg_walks_f(g_p0, n_p3, &body_tys_f(&ti_p4), &false, &Map::new())
            };
            if !neg_p5 {
                s_p1.clone()
            } else {
                {
                    let s0_p6 = {
                        let mut this: crate::check::types::St = s_p1.clone();
                        this.file_p = ti_p4.file_p.clone();
                        this
                    };
                    let s1_p7 = crate::check::types::recording::err_fix_f(&s0_p6, &Text::lit("may-not-end"), &ti_p4.span_p, &Text::from(format!("`{}` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks", &crate::check::types::bare_name_f(n_p3))), &Text::from(format!("keep `{}` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded", &crate::check::types::bare_name_f(n_p3))));
                    {
                        let mut this: crate::check::types::St = s1_p7.clone();
                        this.file_p = s_p1.file_p.clone();
                        this
                    }
                }
            }
        },
        None => s_p1.clone(),
    }
}

/// The step machine of `NegativeType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
/// ```
pub struct NegativeType {
    pub g_p0: crate::check::env::G,
    pub s_p1: crate::check::types::St,
    pub arrowy_p2: Map<Text, bool>,
    pub n_p3: Text,
}

impl prism_rtl::Job<crate::check::types::St> for NegativeType {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let s_p1 = &self.s_p1;
        let arrowy_p2 = &self.arrowy_p2;
        let n_p3 = &self.n_p3;
        match crate::prelude::get(&g_p0.types_p, n_p3) {
            Some(ti_p4) => {
                let (neg_p5, _) = if (&ti_p4.file_p >= &g_p0.prelude_from_p) || !crate::check::env::has_key_f(arrowy_p2, n_p3) {
                    (false, Map::new())
                } else {
                    neg_walks_f(g_p0, n_p3, &body_tys_f(&ti_p4), &false, &Map::new())
                };
                if !neg_p5 {
                    prism_rtl::Turn::Finished(s_p1.clone())
                } else {
                    {
                        let s0_p6 = {
                            let mut this: crate::check::types::St = s_p1.clone();
                            this.file_p = ti_p4.file_p.clone();
                            this
                        };
                        let s1_p7 = crate::check::types::recording::err_fix_f(&s0_p6, &Text::lit("may-not-end"), &ti_p4.span_p, &Text::from(format!("`{}` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks", &crate::check::types::bare_name_f(n_p3))), &Text::from(format!("keep `{}` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded", &crate::check::types::bare_name_f(n_p3))));
                        prism_rtl::Turn::Finished({
                            let mut this: crate::check::types::St = s1_p7.clone();
                            this.file_p = s_p1.file_p.clone();
                            this
                        })
                    }
                }
            },
            None => prism_rtl::Turn::Finished(s_p1.clone()),
        }
    }
}

/// `Start NegativeType, x`: what the function value is when passed to `@Run`.
pub fn start_negative_type_f(g_p0: crate::check::env::G, s_p1: crate::check::types::St, arrowy_p2: Map<Text, bool>, n_p3: Text) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(NegativeType { g_p0, s_p1, arrowy_p2, n_p3 })
}

/// ```prism
/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
/// ```
pub fn arrowy_types_f(g_p0: &crate::check::env::G) -> Map<Text, bool> {
    let names_p1 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g_p0.types_p), Map::new(), {
        let g_p0x = g_p0.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p3 = p0;
                let n_p4 = p1;
                match crate::prelude::get(&g_p0xy.types_p, &n_p4) {
                    Some(ti_p5) => crate::prelude::call_value(crate::prelude::fold_job(body_tys_f(&ti_p5), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p6 = p0;
                        let t_p7 = p1;
                        crate::prelude::call_then(start_ty_names_in_f(t_p7.clone()), move |ty_names_in_f_3223: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p6, &ty_names_in_f_3223)))
                    }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_3171: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::insert(&m_p3, &n_p4, &fold_3171))),
                    None => prism_rtl::Turn::Finished(m_p3.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
    }));
    let direct_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&g_p0.types_p), Map::new(), {
        let g_p0x = g_p0.clone();
        Rc::new(move |(p0, p1): (Map<Text, bool>, Text)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p8 = p0;
                let n_p9 = p1;
                match crate::prelude::get(&g_p0xy.types_p, &n_p9) {
                    Some(ti_pa) => crate::prelude::call_value(crate::prelude::fold_job(body_tys_f(&ti_pa), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let seen_pb = p0;
                        let t_pc = p1;
                        prism_rtl::Turn::Finished(seen_pb || has_arrow_f(&t_pc))
                    }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_3337: bool| if fold_3337 {
                        prism_rtl::Turn::Finished(crate::prelude::insert(&m_p8, &n_p9, &true))
                    } else {
                        prism_rtl::Turn::Finished(m_p8.clone())
                    }),
                    None => prism_rtl::Turn::Finished(m_p8.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, bool>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>>>
    }));
    arrowy_from_f(&names_p1, &direct_p2)
}

/// The step machine of `ArrowyTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
/// ```
pub struct ArrowyTypes {
    pub g_p0: crate::check::env::G,
}

impl prism_rtl::Job<Map<Text, bool>> for ArrowyTypes {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, bool>> {
        let g_p0 = &self.g_p0;
        let g_p0x = g_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(&g_p0x.types_p), Map::new(), {
            let g_p0xx = g_p0x.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                let g_p0xxy = g_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m_p3 = p0;
                    let n_p4 = p1;
                    match crate::prelude::get(&g_p0xxy.types_p, &n_p4) {
                        Some(ti_p5) => crate::prelude::call_value(crate::prelude::fold_job(body_tys_f(&ti_p5), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_p6 = p0;
                            let t_p7 = p1;
                            crate::prelude::call_then(start_ty_names_in_f(t_p7.clone()), move |ty_names_in_f_3223: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p6, &ty_names_in_f_3223)))
                        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_3171: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::insert(&m_p3, &n_p4, &fold_3171))),
                        None => prism_rtl::Turn::Finished(m_p3.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        }), move |fold_3092: Map<Text, Array<Text>>| {
            let names_p1 = fold_3092;
            crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(&g_p0x.types_p), Map::new(), {
                let g_p0xx = g_p0x.clone();
                Rc::new(move |(p0, p1): (Map<Text, bool>, Text)| {
                    let g_p0xxy = g_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let m_p8 = p0;
                        let n_p9 = p1;
                        match crate::prelude::get(&g_p0xxy.types_p, &n_p9) {
                            Some(ti_pa) => crate::prelude::call_value(crate::prelude::fold_job(body_tys_f(&ti_pa), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                                let seen_pb = p0;
                                let t_pc = p1;
                                prism_rtl::Turn::Finished(seen_pb || has_arrow_f(&t_pc))
                            }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_3337: bool| if fold_3337 {
                                prism_rtl::Turn::Finished(crate::prelude::insert(&m_p8, &n_p9, &true))
                            } else {
                                prism_rtl::Turn::Finished(m_p8.clone())
                            }),
                            None => prism_rtl::Turn::Finished(m_p8.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((Map<Text, bool>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>>>
            }), move |fold_3269: Map<Text, bool>| {
                let direct_p2 = fold_3269;
                prism_rtl::Turn::More(Rc::new(ArrowyFrom { names_p0: names_p1.clone(), got_p1: direct_p2.clone() }))
            })
        })
    }
}

/// `Start ArrowyTypes, x`: what the function value is when passed to `@Run`.
pub fn start_arrowy_types_f(g_p0: crate::check::env::G) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>> {
    Rc::new(ArrowyTypes { g_p0 })
}

/// ```prism
/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
/// ```
pub fn arrowy_from_f(names_p0: &Map<Text, Array<Text>>, got_p1: &Map<Text, bool>) -> Map<Text, bool> {
    let next_p2 = crate::prelude::fold(&crate::prelude::keys(names_p0), got_p1, &(|m_p3: &Map<Text, bool>, n_p4: &Text| if crate::check::env::has_key_f(m_p3, n_p4) {
        m_p3.clone()
    } else {
        if crate::prelude::fold(&crate::prelude::or(&crate::prelude::get(names_p0, n_p4), &Array::new()), &false, &(|seen_p5: &bool, r_p6: &Text| *seen_p5 || crate::check::env::has_key_f(got_p1, r_p6))) {
            crate::prelude::insert(m_p3, n_p4, &true)
        } else {
            m_p3.clone()
        }
    }));
    if &crate::prelude::len(&crate::prelude::keys(&next_p2)) == &crate::prelude::len(&crate::prelude::keys(got_p1)) {
        got_p1.clone()
    } else {
        arrowy_from_f(names_p0, &next_p2)
    }
}

/// The step machine of `ArrowyFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
/// ```
pub struct ArrowyFrom {
    pub names_p0: Map<Text, Array<Text>>,
    pub got_p1: Map<Text, bool>,
}

impl prism_rtl::Job<Map<Text, bool>> for ArrowyFrom {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, bool>> {
        let names_p0 = &self.names_p0;
        let got_p1 = &self.got_p1;
        let next_p2 = crate::prelude::fold(&crate::prelude::keys(names_p0), got_p1, &(|m_p3: &Map<Text, bool>, n_p4: &Text| if crate::check::env::has_key_f(m_p3, n_p4) {
            m_p3.clone()
        } else {
            if crate::prelude::fold(&crate::prelude::or(&crate::prelude::get(names_p0, n_p4), &Array::new()), &false, &(|seen_p5: &bool, r_p6: &Text| *seen_p5 || crate::check::env::has_key_f(got_p1, r_p6))) {
                crate::prelude::insert(m_p3, n_p4, &true)
            } else {
                m_p3.clone()
            }
        }));
        if &crate::prelude::len(&crate::prelude::keys(&next_p2)) == &crate::prelude::len(&crate::prelude::keys(got_p1)) {
            prism_rtl::Turn::Finished(got_p1.clone())
        } else {
            prism_rtl::Turn::More(Rc::new(ArrowyFrom { names_p0: names_p0.clone(), got_p1: next_p2.clone() }))
        }
    }
}

/// `Start ArrowyFrom, x`: what the function value is when passed to `@Run`.
pub fn start_arrowy_from_f(names_p0: Map<Text, Array<Text>>, got_p1: Map<Text, bool>) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>> {
    Rc::new(ArrowyFrom { names_p0, got_p1 })
}

/// ```prism
/// TyNamesIn: unbounded fn Ty -> [Text]
/// ```
pub fn ty_names_in_f(t_p0: &crate::check::types::Ty) -> Array<Text> {
    match t_p0 {
        crate::check::types::Ty::TyCon(c_p1, args_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p2.clone(), Array::from(vec![c_p1.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let a_p4 = p1;
            crate::prelude::call_then(start_ty_names_in_f(a_p4.clone()), move |ty_names_in_f_4019: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &ty_names_in_f_4019)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyFn(_, ps_p5, res_p6) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p5.clone(), ty_names_in_f(&**res_p6), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p7 = p0;
            let a_p8 = p1;
            crate::prelude::call_then(start_ty_names_in_f(a_p8.clone()), move |ty_names_in_f_4111: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p7, &ty_names_in_f_4111)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyTuple(ts_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pa = p0;
            let a_pb = p1;
            crate::prelude::call_then(start_ty_names_in_f(a_pb.clone()), move |ty_names_in_f_4182: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pa, &ty_names_in_f_4182)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyArray(e_pc) => ty_names_in_f(&**e_pc),
        crate::check::types::Ty::TyMap(k_pd, v_pe) => crate::check::types::union_texts_f(&ty_names_in_f(&**k_pd), &ty_names_in_f(&**v_pe)),
        crate::check::types::Ty::TySig(_, i_pf) => ty_names_in_f(&**i_pf),
        crate::check::types::Ty::TyAt(i_pg, _) => ty_names_in_f(&**i_pg),
        crate::check::types::Ty::TyElem(_, i_ph) => ty_names_in_f(&**i_ph),
        crate::check::types::Ty::TyAssoc(_, i_pi) => ty_names_in_f(&**i_pi),
        _ => Array::new(),
    }
}

/// The step machine of `TyNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyNamesIn: unbounded fn Ty -> [Text]
/// ```
pub struct TyNamesIn {
    pub t_p0: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Text>> for TyNamesIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyCon(c_p1, args_p2) => crate::prelude::fold_job(args_p2.clone(), Array::from(vec![c_p1.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let a_p4 = p1;
                crate::prelude::call_then(start_ty_names_in_f(a_p4.clone()), move |ty_names_in_f_4019: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &ty_names_in_f_4019)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyFn(_, ps_p5, res_p6) => {
                let ps_p5x = ps_p5.clone();
                let res_p6x = (**res_p6).clone();
                crate::prelude::call_then(start_ty_names_in_f(res_p6x.clone()), move |ty_names_in_f_4068: Array<Text>| crate::prelude::fold_job(ps_p5x.clone(), ty_names_in_f_4068, Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p7 = p0;
                    let a_p8 = p1;
                    crate::prelude::call_then(start_ty_names_in_f(a_p8.clone()), move |ty_names_in_f_4111: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p7, &ty_names_in_f_4111)))
                }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            crate::check::types::Ty::TyTuple(ts_p9) => crate::prelude::fold_job(ts_p9.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pa = p0;
                let a_pb = p1;
                crate::prelude::call_then(start_ty_names_in_f(a_pb.clone()), move |ty_names_in_f_4182: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pa, &ty_names_in_f_4182)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyArray(e_pc) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t_p0: (**e_pc).clone() })),
            crate::check::types::Ty::TyMap(k_pd, v_pe) => {
                let k_pdx = (**k_pd).clone();
                let v_pex = (**v_pe).clone();
                crate::prelude::call_then(start_ty_names_in_f(k_pdx.clone()), move |ty_names_in_f_4250: Array<Text>| crate::prelude::call_then(start_ty_names_in_f(v_pex.clone()), move |ty_names_in_f_4265: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&ty_names_in_f_4250, &ty_names_in_f_4265))))
            },
            crate::check::types::Ty::TySig(_, i_pf) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t_p0: (**i_pf).clone() })),
            crate::check::types::Ty::TyAt(i_pg, _) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t_p0: (**i_pg).clone() })),
            crate::check::types::Ty::TyElem(_, i_ph) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t_p0: (**i_ph).clone() })),
            crate::check::types::Ty::TyAssoc(_, i_pi) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t_p0: (**i_pi).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start TyNamesIn, x`: what the function value is when passed to `@Run`.
pub fn start_ty_names_in_f(t_p0: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TyNamesIn { t_p0 })
}

/// ```prism
/// HasArrow: unbounded fn Ty -> Bool
/// ```
pub fn has_arrow_f(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyFn(_, _, _) => true,
        crate::check::types::Ty::TyCon(_, args_p1) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p1.clone(), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_p2 = p0;
            let a_p3 = p1;
            prism_rtl::Turn::Finished(seen_p2 || has_arrow_f(&a_p3))
        }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::check::types::Ty::TyTuple(ts_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p4.clone(), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let seen_p5 = p0;
            let a_p6 = p1;
            prism_rtl::Turn::Finished(seen_p5 || has_arrow_f(&a_p6))
        }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::check::types::Ty::TyArray(e_p7) => has_arrow_f(&**e_p7),
        crate::check::types::Ty::TyMap(k_p8, v_p9) => has_arrow_f(&**k_p8) || has_arrow_f(&**v_p9),
        crate::check::types::Ty::TySig(_, i_pa) => has_arrow_f(&**i_pa),
        crate::check::types::Ty::TyAt(i_pb, _) => has_arrow_f(&**i_pb),
        crate::check::types::Ty::TyElem(_, i_pc) => has_arrow_f(&**i_pc),
        crate::check::types::Ty::TyAssoc(_, i_pd) => has_arrow_f(&**i_pd),
        _ => false,
    }
}

/// The step machine of `HasArrow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HasArrow: unbounded fn Ty -> Bool
/// ```
pub struct HasArrow {
    pub t_p0: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for HasArrow {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::Finished(true),
            crate::check::types::Ty::TyCon(_, args_p1) => crate::prelude::fold_job(args_p1.clone(), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_p2 = p0;
                let a_p3 = p1;
                prism_rtl::Turn::Finished(seen_p2 || has_arrow_f(&a_p3))
            }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::check::types::Ty::TyTuple(ts_p4) => crate::prelude::fold_job(ts_p4.clone(), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let seen_p5 = p0;
                let a_p6 = p1;
                prism_rtl::Turn::Finished(seen_p5 || has_arrow_f(&a_p6))
            }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::check::types::Ty::TyArray(e_p7) => prism_rtl::Turn::More(Rc::new(HasArrow { t_p0: (**e_p7).clone() })),
            crate::check::types::Ty::TyMap(k_p8, v_p9) => {
                let k_p8x = (**k_p8).clone();
                let v_p9x = (**v_p9).clone();
                crate::prelude::call_then(start_has_arrow_f(k_p8x.clone()), move |has_arrow_f_4707: bool| prism_rtl::Turn::Finished(has_arrow_f_4707 || has_arrow_f(&v_p9x)))
            },
            crate::check::types::Ty::TySig(_, i_pa) => prism_rtl::Turn::More(Rc::new(HasArrow { t_p0: (**i_pa).clone() })),
            crate::check::types::Ty::TyAt(i_pb, _) => prism_rtl::Turn::More(Rc::new(HasArrow { t_p0: (**i_pb).clone() })),
            crate::check::types::Ty::TyElem(_, i_pc) => prism_rtl::Turn::More(Rc::new(HasArrow { t_p0: (**i_pc).clone() })),
            crate::check::types::Ty::TyAssoc(_, i_pd) => prism_rtl::Turn::More(Rc::new(HasArrow { t_p0: (**i_pd).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start HasArrow, x`: what the function value is when passed to `@Run`.
pub fn start_has_arrow_f(t_p0: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HasArrow { t_p0 })
}

/// ```prism
/// BodyTys: fn TyInfo -> [Ty]
/// ```
pub fn body_tys_f(ti_p0: &crate::check::env::TyInfo) -> Array<crate::check::types::Ty> {
    match &ti_p0.body_p {
        crate::check::env::TyBody::BRecord(fields_p1) => crate::prelude::each(fields_p1, &(|(_, t_p2): &(Text, crate::check::types::Ty)| t_p2.clone())),
        crate::check::env::TyBody::BChoice(cases_p3) => crate::prelude::fold(cases_p3, &Array::new(), &(|acc_p4: &Array<crate::check::types::Ty>, (_, args_p5): &(Text, Array<crate::check::types::Ty>)| crate::prelude::append(acc_p4, args_p5))),
        crate::check::env::TyBody::BAlias(t_p6) => Array::from(vec![t_p6.clone()]),
        _ => Array::new(),
    }
}

/// ```prism
/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub fn neg_walk_f(g_p0: &crate::check::env::G, target_p1: &Text, t_p2: &crate::check::types::Ty, b_p3: &bool, seen_p4: &Map<Text, bool>) -> (bool, Map<Text, bool>) {
    match t_p2 {
        crate::check::types::Ty::TyCon(c_p5, args_p6) => if c_p5 == target_p1 {
            (*b_p3, seen_p4.clone())
        } else {
            match crate::prelude::get(&g_p0.types_p, c_p5) {
                Some(ti_p7) => {
                    let sk_p8 = Text::from(format!("{}{}", &(if *b_p3 { Text::lit("-") } else { Text::lit("+") }), &crate::check::types::show_ty_f(&crate::check::types::new_st_f(&Nat::from(0u32)), t_p2)));
                    if crate::check::env::has_key_f(seen_p4, &sk_p8) {
                        (false, seen_p4.clone())
                    } else {
                        if &crate::prelude::len(&crate::prelude::keys(seen_p4)) > &Nat::from(400u32) {
                            (true, seen_p4.clone())
                        } else {
                            neg_walks_f(g_p0, target_p1, &crate::prelude::run_to_end(crate::prelude::each_job(body_tys_f(&ti_p7), {
                                let ti_p7x = ti_p7.clone();
                                let args_p6x = args_p6.clone();
                                Rc::new(move |p0: crate::check::types::Ty| {
                                    let ti_p7xy = ti_p7x.clone();
                                    let args_p6xy = args_p6x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let bt_p9 = p0;
                                        prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: crate::check::env::reading::param_inst_f(&ti_p7xy.params_p, &args_p6xy), t_p1: bt_p9.clone() }))
                                    }))
                                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                            })), b_p3, &crate::prelude::insert(seen_p4, &sk_p8, &true))
                        }
                    }
                },
                None => neg_walks_f(g_p0, target_p1, args_p6, b_p3, seen_p4),
            }
        },
        crate::check::types::Ty::TyFn(col_pa, ps_pb, res_pc) => {
            let (bad_pd, seen2_pe) = neg_walks_f(g_p0, target_p1, ps_pb, &(*b_p3 || (col_pa != &crate::check::types::Col::CUnbound)), seen_p4);
            if bad_pd {
                (true, seen2_pe.clone())
            } else {
                neg_walk_f(g_p0, target_p1, &**res_pc, b_p3, &seen2_pe)
            }
        },
        crate::check::types::Ty::TyTuple(ts_pf) => neg_walks_f(g_p0, target_p1, ts_pf, b_p3, seen_p4),
        crate::check::types::Ty::TyArray(e_pg) => neg_walk_f(g_p0, target_p1, &**e_pg, b_p3, seen_p4),
        crate::check::types::Ty::TyMap(k_ph, v_pi) => neg_walks_f(g_p0, target_p1, &Array::from(vec![(**k_ph).clone(), (**v_pi).clone()]), b_p3, seen_p4),
        crate::check::types::Ty::TySig(_, i_pj) => neg_walk_f(g_p0, target_p1, &**i_pj, b_p3, seen_p4),
        crate::check::types::Ty::TyAt(i_pk, _) => neg_walk_f(g_p0, target_p1, &**i_pk, b_p3, seen_p4),
        crate::check::types::Ty::TyElem(_, i_pl) => neg_walk_f(g_p0, target_p1, &**i_pl, b_p3, seen_p4),
        crate::check::types::Ty::TyAssoc(_, i_pm) => neg_walk_f(g_p0, target_p1, &**i_pm, b_p3, seen_p4),
        _ => (false, seen_p4.clone()),
    }
}

/// The step machine of `NegWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub struct NegWalk {
    pub g_p0: crate::check::env::G,
    pub target_p1: Text,
    pub t_p2: crate::check::types::Ty,
    pub b_p3: bool,
    pub seen_p4: Map<Text, bool>,
}

impl prism_rtl::Job<(bool, Map<Text, bool>)> for NegWalk {
    fn cycle(&self) -> prism_rtl::Turn<(bool, Map<Text, bool>)> {
        let g_p0 = &self.g_p0;
        let target_p1 = &self.target_p1;
        let t_p2 = &self.t_p2;
        let b_p3 = &self.b_p3;
        let seen_p4 = &self.seen_p4;
        match t_p2 {
            crate::check::types::Ty::TyCon(c_p5, args_p6) => if c_p5 == target_p1 {
                prism_rtl::Turn::Finished((*b_p3, seen_p4.clone()))
            } else {
                match crate::prelude::get(&g_p0.types_p, c_p5) {
                    Some(ti_p7) => {
                        let args_p6x = args_p6.clone();
                        let b_p3x = *b_p3;
                        let g_p0x = g_p0.clone();
                        let seen_p4x = seen_p4.clone();
                        let t_p2x = t_p2.clone();
                        let target_p1x = target_p1.clone();
                        crate::prelude::call_then(crate::check::types::start_show_ty_f(crate::check::types::new_st_f(&Nat::from(0u32)), t_p2x.clone()), move |show_ty_f_5844: Text| {
                            let sk_p8 = Text::from(format!("{}{}", &(if b_p3x { Text::lit("-") } else { Text::lit("+") }), &show_ty_f_5844));
                            if crate::check::env::has_key_f(&seen_p4x, &sk_p8) {
                                prism_rtl::Turn::Finished((false, seen_p4x.clone()))
                            } else {
                                if &crate::prelude::len(&crate::prelude::keys(&seen_p4x)) > &Nat::from(400u32) {
                                    prism_rtl::Turn::Finished((true, seen_p4x.clone()))
                                } else {
                                    crate::prelude::call_value(crate::prelude::each_job(body_tys_f(&ti_p7), {
                                        let ti_p7x = ti_p7.clone();
                                        let args_p6xx = args_p6x.clone();
                                        Rc::new(move |p0: crate::check::types::Ty| {
                                            let ti_p7xy = ti_p7x.clone();
                                            let args_p6xxy = args_p6xx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let bt_p9 = p0;
                                                prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: crate::check::env::reading::param_inst_f(&ti_p7xy.params_p, &args_p6xxy), t_p1: bt_p9.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                                    }), move |each_6026: Array<crate::check::types::Ty>| prism_rtl::Turn::More(Rc::new(NegWalks { g_p0: g_p0x.clone(), target_p1: target_p1x.clone(), ts_p2: each_6026, b_p3: b_p3x, seen_p4: crate::prelude::insert(&seen_p4x, &sk_p8, &true) })))
                                }
                            }
                        })
                    },
                    None => prism_rtl::Turn::More(Rc::new(NegWalks { g_p0: g_p0.clone(), target_p1: target_p1.clone(), ts_p2: args_p6.clone(), b_p3: *b_p3, seen_p4: seen_p4.clone() })),
                }
            },
            crate::check::types::Ty::TyFn(col_pa, ps_pb, res_pc) => {
                let b_p3x = *b_p3;
                let col_pax = col_pa.clone();
                let g_p0x = g_p0.clone();
                let ps_pbx = ps_pb.clone();
                let res_pcx = (**res_pc).clone();
                let seen_p4x = seen_p4.clone();
                let target_p1x = target_p1.clone();
                crate::prelude::call_then(start_neg_walks_f(g_p0x.clone(), target_p1x.clone(), ps_pbx.clone(), b_p3x || (&col_pax != &crate::check::types::Col::CUnbound), seen_p4x.clone()), move |neg_walks_f_6222: (bool, Map<Text, bool>)| {
                    let (bad_pd, seen2_pe) = neg_walks_f_6222;
                    if bad_pd {
                        prism_rtl::Turn::Finished((true, seen2_pe.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(NegWalk { g_p0: g_p0x.clone(), target_p1: target_p1x.clone(), t_p2: res_pcx.clone(), b_p3: b_p3x, seen_p4: seen2_pe.clone() }))
                    }
                })
            },
            crate::check::types::Ty::TyTuple(ts_pf) => prism_rtl::Turn::More(Rc::new(NegWalks { g_p0: g_p0.clone(), target_p1: target_p1.clone(), ts_p2: ts_pf.clone(), b_p3: *b_p3, seen_p4: seen_p4.clone() })),
            crate::check::types::Ty::TyArray(e_pg) => prism_rtl::Turn::More(Rc::new(NegWalk { g_p0: g_p0.clone(), target_p1: target_p1.clone(), t_p2: (**e_pg).clone(), b_p3: *b_p3, seen_p4: seen_p4.clone() })),
            crate::check::types::Ty::TyMap(k_ph, v_pi) => prism_rtl::Turn::More(Rc::new(NegWalks { g_p0: g_p0.clone(), target_p1: target_p1.clone(), ts_p2: Array::from(vec![(**k_ph).clone(), (**v_pi).clone()]), b_p3: *b_p3, seen_p4: seen_p4.clone() })),
            crate::check::types::Ty::TySig(_, i_pj) => prism_rtl::Turn::More(Rc::new(NegWalk { g_p0: g_p0.clone(), target_p1: target_p1.clone(), t_p2: (**i_pj).clone(), b_p3: *b_p3, seen_p4: seen_p4.clone() })),
            crate::check::types::Ty::TyAt(i_pk, _) => prism_rtl::Turn::More(Rc::new(NegWalk { g_p0: g_p0.clone(), target_p1: target_p1.clone(), t_p2: (**i_pk).clone(), b_p3: *b_p3, seen_p4: seen_p4.clone() })),
            crate::check::types::Ty::TyElem(_, i_pl) => prism_rtl::Turn::More(Rc::new(NegWalk { g_p0: g_p0.clone(), target_p1: target_p1.clone(), t_p2: (**i_pl).clone(), b_p3: *b_p3, seen_p4: seen_p4.clone() })),
            crate::check::types::Ty::TyAssoc(_, i_pm) => prism_rtl::Turn::More(Rc::new(NegWalk { g_p0: g_p0.clone(), target_p1: target_p1.clone(), t_p2: (**i_pm).clone(), b_p3: *b_p3, seen_p4: seen_p4.clone() })),
            _ => prism_rtl::Turn::Finished((false, seen_p4.clone())),
        }
    }
}

/// `Start NegWalk, x`: what the function value is when passed to `@Run`.
pub fn start_neg_walk_f(g_p0: crate::check::env::G, target_p1: Text, t_p2: crate::check::types::Ty, b_p3: bool, seen_p4: Map<Text, bool>) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>> {
    Rc::new(NegWalk { g_p0, target_p1, t_p2, b_p3, seen_p4 })
}

/// ```prism
/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub fn neg_walks_f(g_p0: &crate::check::env::G, target_p1: &Text, ts_p2: &Array<crate::check::types::Ty>, b_p3: &bool, seen_p4: &Map<Text, bool>) -> (bool, Map<Text, bool>) {
    crate::prelude::run_to_end(crate::prelude::fold_job(ts_p2.clone(), (false, seen_p4.clone()), {
        let g_p0x = g_p0.clone();
        let target_p1x = target_p1.clone();
        let b_p3x = *b_p3;
        Rc::new(move |(p0, p1): ((bool, Map<Text, bool>), crate::check::types::Ty)| {
            let g_p0xy = g_p0x.clone();
            let target_p1xy = target_p1x.clone();
            let b_p3xy = b_p3x;
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (bad_p5, sn_p6) = p0;
                let t_p7 = p1;
                if bad_p5 {
                    prism_rtl::Turn::Finished((true, sn_p6.clone()))
                } else {
                    prism_rtl::Turn::More(Rc::new(NegWalk { g_p0: g_p0xy.clone(), target_p1: target_p1xy.clone(), t_p2: t_p7.clone(), b_p3: b_p3xy, seen_p4: sn_p6.clone() }))
                }
            }))
        }) as Rc<dyn Fn(((bool, Map<Text, bool>), crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>>>
    }))
}

/// The step machine of `NegWalks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub struct NegWalks {
    pub g_p0: crate::check::env::G,
    pub target_p1: Text,
    pub ts_p2: Array<crate::check::types::Ty>,
    pub b_p3: bool,
    pub seen_p4: Map<Text, bool>,
}

impl prism_rtl::Job<(bool, Map<Text, bool>)> for NegWalks {
    fn cycle(&self) -> prism_rtl::Turn<(bool, Map<Text, bool>)> {
        let g_p0 = &self.g_p0;
        let target_p1 = &self.target_p1;
        let ts_p2 = &self.ts_p2;
        let b_p3 = &self.b_p3;
        let seen_p4 = &self.seen_p4;
        crate::prelude::fold_job(ts_p2.clone(), (false, seen_p4.clone()), {
            let g_p0x = g_p0.clone();
            let target_p1x = target_p1.clone();
            let b_p3x = *b_p3;
            Rc::new(move |(p0, p1): ((bool, Map<Text, bool>), crate::check::types::Ty)| {
                let g_p0xy = g_p0x.clone();
                let target_p1xy = target_p1x.clone();
                let b_p3xy = b_p3x;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (bad_p5, sn_p6) = p0;
                    let t_p7 = p1;
                    if bad_p5 {
                        prism_rtl::Turn::Finished((true, sn_p6.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(NegWalk { g_p0: g_p0xy.clone(), target_p1: target_p1xy.clone(), t_p2: t_p7.clone(), b_p3: b_p3xy, seen_p4: sn_p6.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(((bool, Map<Text, bool>), crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>>>
        }).cycle()
    }
}

/// `Start NegWalks, x`: what the function value is when passed to `@Run`.
pub fn start_neg_walks_f(g_p0: crate::check::env::G, target_p1: Text, ts_p2: Array<crate::check::types::Ty>, b_p3: bool, seen_p4: Map<Text, bool>) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>> {
    Rc::new(NegWalks { g_p0, target_p1, ts_p2, b_p3, seen_p4 })
}

/// ```prism
/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
/// ```
pub fn nat_minus_seeds_f(st_p0: &crate::check::types::St) -> Map<Text, crate::check::shrink::Rel> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&st_p0.size_tys_p), Map::new(), {
        let st_p0x = st_p0.clone();
        Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Text)| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p1 = p0;
                let k_p2 = p1;
                match crate::prelude::get(&st_p0xy.size_tys_p, &k_p2) {
                    Some(t_p3) => crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0xy.clone(), t_p3.clone()), move |zonk_f_7185: crate::check::types::Ty| if &zonk_f_7185 == &crate::check::types::t_nat_p() {
                        prism_rtl::Turn::Finished(crate::prelude::insert(&m_p1, &Text::from(format!("nat:{}", &k_p2)), &crate::check::shrink::relations::no_rel_p()))
                    } else {
                        prism_rtl::Turn::Finished(m_p1.clone())
                    }),
                    None => prism_rtl::Turn::Finished(m_p1.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
    }))
}

/// The step machine of `NatMinusSeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
/// ```
pub struct NatMinusSeeds {
    pub st_p0: crate::check::types::St,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for NatMinusSeeds {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let st_p0 = &self.st_p0;
        crate::prelude::fold_job(crate::prelude::keys(&st_p0.size_tys_p), Map::new(), {
            let st_p0x = st_p0.clone();
            Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Text)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m_p1 = p0;
                    let k_p2 = p1;
                    match crate::prelude::get(&st_p0xy.size_tys_p, &k_p2) {
                        Some(t_p3) => crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0xy.clone(), t_p3.clone()), move |zonk_f_7185: crate::check::types::Ty| if &zonk_f_7185 == &crate::check::types::t_nat_p() {
                            prism_rtl::Turn::Finished(crate::prelude::insert(&m_p1, &Text::from(format!("nat:{}", &k_p2)), &crate::check::shrink::relations::no_rel_p()))
                        } else {
                            prism_rtl::Turn::Finished(m_p1.clone())
                        }),
                        None => prism_rtl::Turn::Finished(m_p1.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
        }).cycle()
    }
}

/// `Start NatMinusSeeds, x`: what the function value is when passed to `@Run`.
pub fn start_nat_minus_seeds_f(st_p0: crate::check::types::St) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(NatMinusSeeds { st_p0 })
}

/// ```prism
/// DefClauses: fn Def -> [FnClause]
/// ```
pub fn def_clauses_f(d_p0: &crate::check::env::Def) -> Array<crate::syntax::decls::FnClause> {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbFn(clauses_p1) => clauses_p1.clone(),
        crate::check::env::DefBody::DbMethod(clauses_p2, _, _) => clauses_p2.clone(),
        crate::check::env::DefBody::DbDefault(clauses_p3, _) => clauses_p3.clone(),
        crate::check::env::DefBody::DbWidget(w_p4) => Array::from(vec![crate::syntax::decls::FnClause { name_p: crate::syntax::decls::DefName::DefSName(w_p4.name_p.clone()), params_p: Array::new(), body_p: crate::syntax::decls::FnBody::BodyBlock(w_p4.body_p.clone()), span_p: w_p4.span_p.clone() }]),
        crate::check::env::DefBody::DbLet(l_p5) => Array::from(vec![crate::syntax::decls::FnClause { name_p: crate::syntax::decls::DefName::DefOp(d_p0.name_p.clone(), l_p5.span_p.clone()), params_p: Array::new(), body_p: crate::syntax::decls::FnBody::BodyExpr(l_p5.value_p.clone()), span_p: l_p5.span_p.clone() }]),
        _ => Array::new(),
    }
}

/// ```prism
/// OwnKey: fn Def -> Def
/// ```
pub fn own_key_f(d_p0: &crate::check::env::Def) -> crate::check::env::Def {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbMethod(_, _, im_p1) => {
            let mut this: crate::check::env::Def = d_p0.clone();
            this.qk_p = Text::from(format!("{} #{}.{}", &d_p0.qk_p, &im_p1.file_p, &im_p1.span_p.start_p));
            this
        },
        _ => d_p0.clone(),
    }
}

/// ```prism
/// ?MethodOf: fn G, Def -> ?Text
/// ```
pub fn method_of_o(g_p0: &crate::check::env::G, d_p1: &crate::check::env::Def) -> Option<Text> {
    match &d_p1.body_p {
        crate::check::env::DefBody::DbMethod(_, cls_p2, _) => crate::check::method_key_o(g_p0, cls_p2, &d_p1.name_p),
        crate::check::env::DefBody::DbDefault(_, cls_p3) => crate::check::method_key_o(g_p0, cls_p3, &d_p1.name_p),
        _ => None,
    }
}

/// ```prism
/// MethodTargets: fn G, [Def] -> (Text ==> [Text])
/// ```
pub fn method_targets_f(g_p0: &crate::check::env::G, fns_p1: &Array<crate::check::env::Def>) -> Map<Text, Array<Text>> {
    crate::prelude::fold(fns_p1, &Map::new(), &(|m_p2: &Map<Text, Array<Text>>, d_p3: &crate::check::env::Def| match method_of_o(g_p0, d_p3) {
        Some(mk_p4) => crate::prelude::insert(m_p2, &mk_p4, &crate::check::types::add_text_f(&crate::prelude::or(&crate::prelude::get(m_p2, &mk_p4), &Array::new()), &d_p3.qk_p)),
        None => m_p2.clone(),
    }))
}

/// ```prism
/// ImplDefs: fn G, [Def] -> (Text ==> Text)
/// ```
pub fn impl_defs_f(g_p0: &crate::check::env::G, fns_p1: &Array<crate::check::env::Def>) -> Map<Text, Text> {
    crate::prelude::fold(fns_p1, &Map::new(), &(|m_p2: &Map<Text, Text>, d_p3: &crate::check::env::Def| match &d_p3.body_p {
        crate::check::env::DefBody::DbMethod(_, _, im_p4) => match method_of_o(g_p0, d_p3) {
            Some(mk_p5) => crate::prelude::insert(m_p2, &Text::from(format!("{}|{}.{}", &mk_p5, &im_p4.file_p, &im_p4.span_p.start_p)), &d_p3.qk_p),
            None => m_p2.clone(),
        },
        _ => m_p2.clone(),
    }))
}

/// ```prism
/// ?MethodClass: fn G, Text -> ?Text
/// ```
pub fn method_class_o(g_p0: &crate::check::env::G, k_p1: &Text) -> Option<Text> {
    match crate::prelude::get(&g_p0.vals_p, k_p1) {
        Some(v_p2) => if &v_p2.sort_p != &Text::lit("method") {
            None
        } else {
            match crate::prelude::index(&v_p2.scheme_p.bounds_p, &Nat::from(0u32)) {
                Some((_, cls_p3)) => Some(cls_p3),
                None => None,
            }
        },
        None => None,
    }
}

/// ```prism
/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
/// ```
pub fn dispatch_targets_f(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, site_p2: &crate::check::shrink::walk::Site, k_p3: &Text) -> Array<Text> {
    let all_p4 = targets_of_f(sk_p0, k_p3);
    match method_class_o(&sk_p0.g_p, k_p3) {
        None => all_p4.clone(),
        Some(cls_p5) => {
            let ck_p6 = crate::check::types::recording::choice_key_f(&d_p1.file_p, &site_p2.span_p, &cls_p5);
            match crate::prelude::get(&sk_p0.choices_p, &ck_p6) {
                None => all_p4.clone(),
                Some(cs_p7) => crate::prelude::run_to_end(crate::prelude::fold_job(cs_p7.clone(), Array::new(), {
                    let sk_p0x = sk_p0.clone();
                    let k_p3x = k_p3.clone();
                    let cls_p5x = cls_p5.clone();
                    let all_p4x = all_p4.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let sk_p0xy = sk_p0x.clone();
                        let k_p3xy = k_p3x.clone();
                        let cls_p5xy = cls_p5x.clone();
                        let all_p4xy = all_p4x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_p8 = p0;
                            let ch_p9 = p1;
                            crate::prelude::call_then(start_choice_targets_f(sk_p0xy.clone(), k_p3xy.clone(), cls_p5xy.clone(), all_p4xy.clone(), ch_p9.clone(), Array::new()), move |choice_targets_f_10578: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p8, &choice_targets_f_10578)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                })),
            }
        },
    }
}

/// The step machine of `DispatchTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
/// ```
pub struct DispatchTargets {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub site_p2: crate::check::shrink::walk::Site,
    pub k_p3: Text,
}

impl prism_rtl::Job<Array<Text>> for DispatchTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let site_p2 = &self.site_p2;
        let k_p3 = &self.k_p3;
        let all_p4 = targets_of_f(sk_p0, k_p3);
        match method_class_o(&sk_p0.g_p, k_p3) {
            None => prism_rtl::Turn::Finished(all_p4.clone()),
            Some(cls_p5) => {
                let ck_p6 = crate::check::types::recording::choice_key_f(&d_p1.file_p, &site_p2.span_p, &cls_p5);
                match crate::prelude::get(&sk_p0.choices_p, &ck_p6) {
                    None => prism_rtl::Turn::Finished(all_p4.clone()),
                    Some(cs_p7) => crate::prelude::fold_job(cs_p7.clone(), Array::new(), {
                        let sk_p0x = sk_p0.clone();
                        let k_p3x = k_p3.clone();
                        let cls_p5x = cls_p5.clone();
                        let all_p4x = all_p4.clone();
                        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                            let sk_p0xy = sk_p0x.clone();
                            let k_p3xy = k_p3x.clone();
                            let cls_p5xy = cls_p5x.clone();
                            let all_p4xy = all_p4x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_p8 = p0;
                                let ch_p9 = p1;
                                crate::prelude::call_then(start_choice_targets_f(sk_p0xy.clone(), k_p3xy.clone(), cls_p5xy.clone(), all_p4xy.clone(), ch_p9.clone(), Array::new()), move |choice_targets_f_10578: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p8, &choice_targets_f_10578)))
                            }))
                        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }).cycle(),
                }
            },
        }
    }
}

/// `Start DispatchTargets, x`: what the function value is when passed to `@Run`.
pub fn start_dispatch_targets_f(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, site_p2: crate::check::shrink::walk::Site, k_p3: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(DispatchTargets { sk_p0, d_p1, site_p2, k_p3 })
}

/// ```prism
/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub fn choice_targets_f(sk_p0: &crate::check::shrink::Shrink, k_p1: &Text, cls_p2: &Text, all_p3: &Array<Text>, ch_p4: &Text, seen_p5: &Array<Text>) -> Array<Text> {
    if ch_p4 == &Text::lit("none") {
        Array::new()
    } else {
        if crate::syntax::lexer::chars::has_prefix_f(ch_p4, &Text::lit("impl:")) {
            match crate::prelude::get(&sk_p0.impl_defs_p, &Text::from(format!("{}|{}", k_p1, &crate::syntax::lexer::chars::drop_prefix_f(ch_p4, &Text::lit("impl:"))))) {
                Some(q_p6) => Array::from(vec![q_p6]),
                None => crate::prelude::filter(all_p3, &(|q_p7: &Text| q_p7 == k_p1)),
            }
        } else {
            if crate::syntax::lexer::chars::has_prefix_f(ch_p4, &Text::lit("derived:")) {
                derived_targets_f(sk_p0, k_p1, cls_p2, all_p3, &crate::syntax::lexer::chars::drop_prefix_f(ch_p4, &Text::lit("derived:")), seen_p5)
            } else {
                all_p3.clone()
            }
        }
    }
}

/// The step machine of `ChoiceTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub struct ChoiceTargets {
    pub sk_p0: crate::check::shrink::Shrink,
    pub k_p1: Text,
    pub cls_p2: Text,
    pub all_p3: Array<Text>,
    pub ch_p4: Text,
    pub seen_p5: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for ChoiceTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk_p0 = &self.sk_p0;
        let k_p1 = &self.k_p1;
        let cls_p2 = &self.cls_p2;
        let all_p3 = &self.all_p3;
        let ch_p4 = &self.ch_p4;
        let seen_p5 = &self.seen_p5;
        if ch_p4 == &Text::lit("none") {
            prism_rtl::Turn::Finished(Array::new())
        } else {
            if crate::syntax::lexer::chars::has_prefix_f(ch_p4, &Text::lit("impl:")) {
                match crate::prelude::get(&sk_p0.impl_defs_p, &Text::from(format!("{}|{}", k_p1, &crate::syntax::lexer::chars::drop_prefix_f(ch_p4, &Text::lit("impl:"))))) {
                    Some(q_p6) => prism_rtl::Turn::Finished(Array::from(vec![q_p6.clone()])),
                    None => prism_rtl::Turn::Finished(crate::prelude::filter(all_p3, &(|q_p7: &Text| q_p7 == k_p1))),
                }
            } else {
                if crate::syntax::lexer::chars::has_prefix_f(ch_p4, &Text::lit("derived:")) {
                    prism_rtl::Turn::More(Rc::new(DerivedTargets { sk_p0: sk_p0.clone(), k_p1: k_p1.clone(), cls_p2: cls_p2.clone(), all_p3: all_p3.clone(), n_p4: crate::syntax::lexer::chars::drop_prefix_f(ch_p4, &Text::lit("derived:")), seen_p5: seen_p5.clone() }))
                } else {
                    prism_rtl::Turn::Finished(all_p3.clone())
                }
            }
        }
    }
}

/// `Start ChoiceTargets, x`: what the function value is when passed to `@Run`.
pub fn start_choice_targets_f(sk_p0: crate::check::shrink::Shrink, k_p1: Text, cls_p2: Text, all_p3: Array<Text>, ch_p4: Text, seen_p5: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ChoiceTargets { sk_p0, k_p1, cls_p2, all_p3, ch_p4, seen_p5 })
}

/// ```prism
/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub fn derived_targets_f(sk_p0: &crate::check::shrink::Shrink, k_p1: &Text, cls_p2: &Text, all_p3: &Array<Text>, n_p4: &Text, seen_p5: &Array<Text>) -> Array<Text> {
    if crate::check::types::has_text_f(seen_p5, n_p4) {
        Array::new()
    } else {
        {
            let tys_p6 = match crate::prelude::get(&sk_p0.g_p.types_p, n_p4) {
                Some(ti_p8) => match &ti_p8.body_p {
                    crate::check::env::TyBody::BRecord(fields_p9) => crate::prelude::each(fields_p9, &(|(_, t_pa): &(Text, crate::check::types::Ty)| t_pa.clone())),
                    crate::check::env::TyBody::BChoice(cases_pb) => crate::prelude::fold(cases_pb, &Array::new(), &(|acc_pc: &Array<crate::check::types::Ty>, (_, args_pd): &(Text, Array<crate::check::types::Ty>)| crate::prelude::append(acc_pc, args_pd))),
                    crate::check::env::TyBody::BAlias(t_pe) => Array::from(vec![t_pe.clone()]),
                    _ => Array::new(),
                },
                None => Array::new(),
            };
            let heads_p7 = crate::prelude::fold(&tys_p6, &Array::new(), &(|acc_pf: &Array<Text>, t_pg: &crate::check::types::Ty| crate::check::types::union_texts_f(acc_pf, &ty_heads_f(t_pg))));
            crate::prelude::run_to_end(crate::prelude::fold_job(heads_p7.clone(), Array::new(), {
                let sk_p0x = sk_p0.clone();
                let k_p1x = k_p1.clone();
                let cls_p2x = cls_p2.clone();
                let all_p3x = all_p3.clone();
                let seen_p5x = seen_p5.clone();
                let n_p4x = n_p4.clone();
                Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                    let sk_p0xy = sk_p0x.clone();
                    let k_p1xy = k_p1x.clone();
                    let cls_p2xy = cls_p2x.clone();
                    let all_p3xy = all_p3x.clone();
                    let seen_p5xy = seen_p5x.clone();
                    let n_p4xy = n_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_ph = p0;
                        let h_pi = p1;
                        prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_ph, &head_targets_f(&sk_p0xy, &k_p1xy, &cls_p2xy, &all_p3xy, &h_pi, &crate::prelude::push(&seen_p5xy, &n_p4xy))))
                    }))
                }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }))
        }
    }
}

/// The step machine of `DerivedTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub struct DerivedTargets {
    pub sk_p0: crate::check::shrink::Shrink,
    pub k_p1: Text,
    pub cls_p2: Text,
    pub all_p3: Array<Text>,
    pub n_p4: Text,
    pub seen_p5: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for DerivedTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk_p0 = &self.sk_p0;
        let k_p1 = &self.k_p1;
        let cls_p2 = &self.cls_p2;
        let all_p3 = &self.all_p3;
        let n_p4 = &self.n_p4;
        let seen_p5 = &self.seen_p5;
        if crate::check::types::has_text_f(seen_p5, n_p4) {
            prism_rtl::Turn::Finished(Array::new())
        } else {
            {
                let tys_p6 = match crate::prelude::get(&sk_p0.g_p.types_p, n_p4) {
                    Some(ti_p8) => match &ti_p8.body_p {
                        crate::check::env::TyBody::BRecord(fields_p9) => crate::prelude::each(fields_p9, &(|(_, t_pa): &(Text, crate::check::types::Ty)| t_pa.clone())),
                        crate::check::env::TyBody::BChoice(cases_pb) => crate::prelude::fold(cases_pb, &Array::new(), &(|acc_pc: &Array<crate::check::types::Ty>, (_, args_pd): &(Text, Array<crate::check::types::Ty>)| crate::prelude::append(acc_pc, args_pd))),
                        crate::check::env::TyBody::BAlias(t_pe) => Array::from(vec![t_pe.clone()]),
                        _ => Array::new(),
                    },
                    None => Array::new(),
                };
                let heads_p7 = crate::prelude::fold(&tys_p6, &Array::new(), &(|acc_pf: &Array<Text>, t_pg: &crate::check::types::Ty| crate::check::types::union_texts_f(acc_pf, &ty_heads_f(t_pg))));
                crate::prelude::fold_job(heads_p7.clone(), Array::new(), {
                    let sk_p0x = sk_p0.clone();
                    let k_p1x = k_p1.clone();
                    let cls_p2x = cls_p2.clone();
                    let all_p3x = all_p3.clone();
                    let seen_p5x = seen_p5.clone();
                    let n_p4x = n_p4.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let sk_p0xy = sk_p0x.clone();
                        let k_p1xy = k_p1x.clone();
                        let cls_p2xy = cls_p2x.clone();
                        let all_p3xy = all_p3x.clone();
                        let seen_p5xy = seen_p5x.clone();
                        let n_p4xy = n_p4x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_ph = p0;
                            let h_pi = p1;
                            prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_ph, &head_targets_f(&sk_p0xy, &k_p1xy, &cls_p2xy, &all_p3xy, &h_pi, &crate::prelude::push(&seen_p5xy, &n_p4xy))))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle()
            }
        }
    }
}

/// `Start DerivedTargets, x`: what the function value is when passed to `@Run`.
pub fn start_derived_targets_f(sk_p0: crate::check::shrink::Shrink, k_p1: Text, cls_p2: Text, all_p3: Array<Text>, n_p4: Text, seen_p5: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(DerivedTargets { sk_p0, k_p1, cls_p2, all_p3, n_p4, seen_p5 })
}

/// ```prism
/// TyHeads: fn Ty -> [Text]
/// ```
pub fn ty_heads_f(t_p0: &crate::check::types::Ty) -> Array<Text> {
    match t_p0 {
        crate::check::types::Ty::TyCon(n_p1, args_p2) => crate::prelude::fold(args_p2, &Array::from(vec![n_p1.clone()]), &(|acc_p3: &Array<Text>, a_p4: &crate::check::types::Ty| crate::check::types::union_texts_f(acc_p3, &ty_heads_f(a_p4)))),
        crate::check::types::Ty::TyTuple(ts_p5) => crate::prelude::fold(ts_p5, &Array::new(), &(|acc_p6: &Array<Text>, a_p7: &crate::check::types::Ty| crate::check::types::union_texts_f(acc_p6, &ty_heads_f(a_p7)))),
        crate::check::types::Ty::TyArray(e_p8) => ty_heads_f(&**e_p8),
        crate::check::types::Ty::TyMap(a_p9, b_pa) => crate::check::types::union_texts_f(&ty_heads_f(&**a_p9), &ty_heads_f(&**b_pa)),
        crate::check::types::Ty::TySig(_, i_pb) => ty_heads_f(&**i_pb),
        crate::check::types::Ty::TyQ(_) => Array::new(),
        crate::check::types::Ty::TyRigid(_) => Array::new(),
        crate::check::types::Ty::TyFn(_, _, _) => Array::new(),
        crate::check::types::Ty::TyElem(_, _) => Array::new(),
        crate::check::types::Ty::TyElemAny(_) => Array::new(),
        _ => Array::from(vec![Text::lit("?")]),
    }
}

/// ```prism
/// HeadTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub fn head_targets_f(sk_p0: &crate::check::shrink::Shrink, k_p1: &Text, cls_p2: &Text, all_p3: &Array<Text>, h_p4: &Text, seen_p5: &Array<Text>) -> Array<Text> {
    if h_p4 == &Text::lit("?") {
        all_p3.clone()
    } else {
        if crate::check::env::traits::builtin_has_f(cls_p2, h_p4) || crate::check::env::is_prim_type_f(h_p4) {
            Array::new()
        } else {
            match crate::prelude::index(&crate::prelude::filter(&crate::prelude::or(&crate::prelude::get(&sk_p0.g_p.impls_p, cls_p2), &Array::new()), &(|im_p6: &crate::check::env::ImplInfo| &head_key_o(&im_p6.head_p) == &Some(h_p4.clone()))), &Nat::from(0u32)) {
                Some(im_p7) => choice_targets_f(sk_p0, k_p1, cls_p2, all_p3, &crate::check::env::traits::impl_choice_f(&im_p7), seen_p5),
                None => all_p3.clone(),
            }
        }
    }
}

/// ```prism
/// ?HeadKey: fn Ty -> ?Text
/// ```
pub fn head_key_o(ty0: &crate::check::types::Ty) -> Option<Text> {
    match ty0 {
        crate::check::types::Ty::TyCon(n_p0, _) => Some(n_p0.clone()),
        _ => None,
    }
}

/// ```prism
/// TargetsOf: fn Shrink, Text -> [Text]
/// ```
pub fn targets_of_f(sk_p0: &crate::check::shrink::Shrink, k_p1: &Text) -> Array<Text> {
    crate::prelude::or(&crate::prelude::get(&sk_p0.targets_p, k_p1), &Array::from(vec![k_p1.clone()]))
}

/// ```prism
/// SigKeyOf: fn Shrink, Text -> Text
/// ```
pub fn sig_key_of_f(sk_p0: &crate::check::shrink::Shrink, k_p1: &Text) -> Text {
    match crate::prelude::get(&sk_p0.by_key_p, k_p1) {
        Some(d_p2) => crate::prelude::or(&method_of_o(&sk_p0.g_p, &d_p2), k_p1),
        None => k_p1.clone(),
    }
}

/// ```prism
/// ShownKey: fn Text -> Text
/// ```
pub fn shown_key_f(k_p0: &Text) -> Text {
    crate::check::types::bare_name_f(&crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(&crate::prelude::or(&crate::syntax::lexer::chars::last_o(&crate::prelude::split_on(k_p0, &Text::lit(" impl "))), k_p0), &Text::lit(" #")), &Nat::from(0u32)), k_p0))
}

/// ```prism
/// IsUnboundedKey: fn G, Text -> Bool
/// ```
pub fn is_unbounded_key_f(g_p0: &crate::check::env::G, k_p1: &Text) -> bool {
    match crate::prelude::get(&g_p0.vals_p, k_p1) {
        Some(v_p2) => match &v_p2.scheme_p.ty_p {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CUnbound, _, _) => true,
            _ => false,
        },
        None => false,
    }
}
