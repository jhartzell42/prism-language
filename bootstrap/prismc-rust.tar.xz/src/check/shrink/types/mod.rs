//! The module `Check.Shrink.Types`, from `target/bootstrap/src/prismc/check/shrink/types.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// NegativeTypes: unbounded fn G, St -> St
/// ```
pub fn negative_types(g: &crate::check::env::G, st: &crate::check::types::St) -> crate::check::types::St {
    let arrowy = arrowy_types(g);
    run_to_end(fold_job(keys(&g.types), st.clone(), {
        let g = g.clone();
        let arrowy = arrowy.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
            let g = g.clone();
            let arrowy = arrowy.clone();
            entered(once_job(move || {
                let s = p0;
                let n = p1;
                prism_rtl::Turn::More(Rc::new(NegativeType { g: g.clone(), s: s.clone(), arrowy: arrowy.clone(), n: n.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `NegativeTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegativeTypes: unbounded fn G, St -> St
/// ```
pub struct NegativeTypes {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for NegativeTypes {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let g = g.clone();
        let st = st.clone();
        call_then(start_arrowy_types(g.clone()), move |arrowy_types_1927: Map<Text, bool>| {
            let arrowy = arrowy_types_1927;
            fold_job(keys(&g.types), st.clone(), {
                let g = g.clone();
                let arrowy = arrowy.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
                    let g = g.clone();
                    let arrowy = arrowy.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let n = p1;
                        prism_rtl::Turn::More(Rc::new(NegativeType { g: g.clone(), s: s.clone(), arrowy: arrowy.clone(), n: n.clone() }))
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }).cycle()
        })
    }
}

/// `Start NegativeTypes, x`: what the function value is when passed to `@Run`.
pub fn start_negative_types(g: crate::check::env::G, st: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(NegativeTypes { g, st })
}

/// ```prism
/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
/// ```
pub fn negative_type(g: &crate::check::env::G, s: &crate::check::types::St, arrowy: &Map<Text, bool>, n: &Text) -> crate::check::types::St {
    match get(&g.types, n) {
        Some(ti) => {
            let (neg, _) = if (&ti.file >= &g.prelude_from) || !crate::check::env::has_key(arrowy, n) {
                (false, Map::new())
            } else {
                neg_walks(g, n, &body_tys(&ti), &false, &Map::new())
            };
            if !neg {
                s.clone()
            } else {
                {
                    let s0 = {
                        let mut this: crate::check::types::St = s.clone();
                        this.file = ti.file.clone();
                        this
                    };
                    let s1 = crate::check::types::recording::err_fix(&s0, &Text::lit("may-not-end"), &ti.span, &Text::from(format!("`{}` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks", &crate::check::types::bare_name(n))), &Text::from(format!("keep `{}` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded", &crate::check::types::bare_name(n))));
                    {
                        let mut this: crate::check::types::St = s1.clone();
                        this.file = s.file.clone();
                        this
                    }
                }
            }
        },
        None => s.clone(),
    }
}

/// The step machine of `NegativeType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
/// ```
pub struct NegativeType {
    pub g: crate::check::env::G,
    pub s: crate::check::types::St,
    pub arrowy: Map<Text, bool>,
    pub n: Text,
}

impl prism_rtl::Job<crate::check::types::St> for NegativeType {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let s = &self.s;
        let arrowy = &self.arrowy;
        let n = &self.n;
        match get(&g.types, n) {
            Some(ti) => {
                let (neg, _) = if (&ti.file >= &g.prelude_from) || !crate::check::env::has_key(arrowy, n) {
                    (false, Map::new())
                } else {
                    neg_walks(g, n, &body_tys(&ti), &false, &Map::new())
                };
                if !neg {
                    prism_rtl::Turn::Finished(s.clone())
                } else {
                    {
                        let s0 = {
                            let mut this: crate::check::types::St = s.clone();
                            this.file = ti.file.clone();
                            this
                        };
                        let s1 = crate::check::types::recording::err_fix(&s0, &Text::lit("may-not-end"), &ti.span, &Text::from(format!("`{}` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks", &crate::check::types::bare_name(n))), &Text::from(format!("keep `{}` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded", &crate::check::types::bare_name(n))));
                        prism_rtl::Turn::Finished({
                            let mut this: crate::check::types::St = s1.clone();
                            this.file = s.file.clone();
                            this
                        })
                    }
                }
            },
            None => prism_rtl::Turn::Finished(s.clone()),
        }
    }
}

/// `Start NegativeType, x`: what the function value is when passed to `@Run`.
pub fn start_negative_type(g: crate::check::env::G, s: crate::check::types::St, arrowy: Map<Text, bool>, n: Text) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(NegativeType { g, s, arrowy, n })
}

/// ```prism
/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
/// ```
pub fn arrowy_types(g: &crate::check::env::G) -> Map<Text, bool> {
    let names = run_to_end(fold_job(keys(&g.types), Map::new(), {
        let g = g.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
            let g = g.clone();
            entered(once_job(move || {
                let m = p0;
                let n = p1;
                match get(&g.types, &n) {
                    Some(ti) => call_value(fold_job(body_tys(&ti), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                        let acc = p0;
                        let t = p1;
                        call_then(start_ty_names_in(t.clone()), move |ty_names_in_3223: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_3223)))
                    }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_3171: Array<Text>| prism_rtl::Turn::Finished(insert(&m, &n, &fold_3171))),
                    None => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
    }));
    let direct = run_to_end(fold_job(keys(&g.types), Map::new(), {
        let g = g.clone();
        Rc::new(move |(p0, p1): (Map<Text, bool>, Text)| {
            let g = g.clone();
            entered(once_job(move || {
                let m = p0;
                let n = p1;
                match get(&g.types, &n) {
                    Some(ti) => call_value(fold_job(body_tys(&ti), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| entered(once_job(move || {
                        let seen = p0;
                        let t = p1;
                        prism_rtl::Turn::Finished(seen || has_arrow(&t))
                    }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_3337: bool| if fold_3337 {
                        prism_rtl::Turn::Finished(insert(&m, &n, &true))
                    } else {
                        prism_rtl::Turn::Finished(m.clone())
                    }),
                    None => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, bool>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>>>
    }));
    arrowy_from(&names, &direct)
}

/// The step machine of `ArrowyTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
/// ```
pub struct ArrowyTypes {
    pub g: crate::check::env::G,
}

impl prism_rtl::Job<Map<Text, bool>> for ArrowyTypes {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, bool>> {
        let g = &self.g;
        let g = g.clone();
        call_value(fold_job(keys(&g.types), Map::new(), {
            let g = g.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                let g = g.clone();
                entered(once_job(move || {
                    let m = p0;
                    let n = p1;
                    match get(&g.types, &n) {
                        Some(ti) => call_value(fold_job(body_tys(&ti), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                            let acc = p0;
                            let t = p1;
                            call_then(start_ty_names_in(t.clone()), move |ty_names_in_3223: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_3223)))
                        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_3171: Array<Text>| prism_rtl::Turn::Finished(insert(&m, &n, &fold_3171))),
                        None => prism_rtl::Turn::Finished(m.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        }), move |fold_3092: Map<Text, Array<Text>>| {
            let names = fold_3092;
            call_value(fold_job(keys(&g.types), Map::new(), {
                let g = g.clone();
                Rc::new(move |(p0, p1): (Map<Text, bool>, Text)| {
                    let g = g.clone();
                    entered(once_job(move || {
                        let m = p0;
                        let n = p1;
                        match get(&g.types, &n) {
                            Some(ti) => call_value(fold_job(body_tys(&ti), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| entered(once_job(move || {
                                let seen = p0;
                                let t = p1;
                                prism_rtl::Turn::Finished(seen || has_arrow(&t))
                            }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_3337: bool| if fold_3337 {
                                prism_rtl::Turn::Finished(insert(&m, &n, &true))
                            } else {
                                prism_rtl::Turn::Finished(m.clone())
                            }),
                            None => prism_rtl::Turn::Finished(m.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((Map<Text, bool>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>>>
            }), move |fold_3269: Map<Text, bool>| {
                let direct = fold_3269;
                prism_rtl::Turn::More(Rc::new(ArrowyFrom { names: names.clone(), got: direct.clone() }))
            })
        })
    }
}

/// `Start ArrowyTypes, x`: what the function value is when passed to `@Run`.
pub fn start_arrowy_types(g: crate::check::env::G) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>> {
    Rc::new(ArrowyTypes { g })
}

/// ```prism
/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
/// ```
pub fn arrowy_from(names: &Map<Text, Array<Text>>, got: &Map<Text, bool>) -> Map<Text, bool> {
    let next_ = fold(&keys(names), got, &(|m: &Map<Text, bool>, n: &Text| if crate::check::env::has_key(m, n) {
        m.clone()
    } else {
        if fold(&or(&get(names, n), &Array::new()), &false, &(|seen: &bool, r: &Text| *seen || crate::check::env::has_key(got, r))) {
            insert(m, n, &true)
        } else {
            m.clone()
        }
    }));
    if &len(&keys(&next_)) == &len(&keys(got)) {
        got.clone()
    } else {
        arrowy_from(names, &next_)
    }
}

/// The step machine of `ArrowyFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
/// ```
pub struct ArrowyFrom {
    pub names: Map<Text, Array<Text>>,
    pub got: Map<Text, bool>,
}

impl prism_rtl::Job<Map<Text, bool>> for ArrowyFrom {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, bool>> {
        let names = &self.names;
        let got = &self.got;
        let next_ = fold(&keys(names), got, &(|m: &Map<Text, bool>, n: &Text| if crate::check::env::has_key(m, n) {
            m.clone()
        } else {
            if fold(&or(&get(names, n), &Array::new()), &false, &(|seen: &bool, r: &Text| *seen || crate::check::env::has_key(got, r))) {
                insert(m, n, &true)
            } else {
                m.clone()
            }
        }));
        if &len(&keys(&next_)) == &len(&keys(got)) {
            prism_rtl::Turn::Finished(got.clone())
        } else {
            prism_rtl::Turn::More(Rc::new(ArrowyFrom { names: names.clone(), got: next_.clone() }))
        }
    }
}

/// `Start ArrowyFrom, x`: what the function value is when passed to `@Run`.
pub fn start_arrowy_from(names: Map<Text, Array<Text>>, got: Map<Text, bool>) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>> {
    Rc::new(ArrowyFrom { names, got })
}

/// ```prism
/// TyNamesIn: unbounded fn Ty -> [Text]
/// ```
pub fn ty_names_in(t: &crate::check::types::Ty) -> Array<Text> {
    match t {
        crate::check::types::Ty::TyCon(c, args) => run_to_end(fold_job(args.clone(), Array::from(vec![c.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_ty_names_in(a.clone()), move |ty_names_in_4019: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_4019)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyFn(_, ps, res) => run_to_end(fold_job(ps.clone(), ty_names_in(&**res), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_ty_names_in(a.clone()), move |ty_names_in_4111: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_4111)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_ty_names_in(a.clone()), move |ty_names_in_4182: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_4182)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyArray(e) => ty_names_in(&**e),
        crate::check::types::Ty::TyMap(k, v_) => crate::check::types::union_texts(&ty_names_in(&**k), &ty_names_in(&**v_)),
        crate::check::types::Ty::TySig(_, i) => ty_names_in(&**i),
        crate::check::types::Ty::TyAt(i, _) => ty_names_in(&**i),
        crate::check::types::Ty::TyElem(_, i) => ty_names_in(&**i),
        crate::check::types::Ty::TyAssoc(_, i) => ty_names_in(&**i),
        _ => Array::new(),
    }
}

/// The step machine of `TyNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyNamesIn: unbounded fn Ty -> [Text]
/// ```
pub struct TyNamesIn {
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Text>> for TyNamesIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyCon(c, args) => fold_job(args.clone(), Array::from(vec![c.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_ty_names_in(a.clone()), move |ty_names_in_4019: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_4019)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyFn(_, ps, res) => {
                let ps = ps.clone();
                let res = (**res).clone();
                call_then(start_ty_names_in(res.clone()), move |ty_names_in_4068: Array<Text>| fold_job(ps.clone(), ty_names_in_4068, Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_ty_names_in(a.clone()), move |ty_names_in_4111: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_4111)))
                }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_ty_names_in(a.clone()), move |ty_names_in_4182: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &ty_names_in_4182)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**e).clone() })),
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_ty_names_in(k.clone()), move |ty_names_in_4250: Array<Text>| call_then(start_ty_names_in(v_.clone()), move |ty_names_in_4265: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&ty_names_in_4250, &ty_names_in_4265))))
            },
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**i).clone() })),
            crate::check::types::Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**i).clone() })),
            crate::check::types::Ty::TyElem(_, i) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**i).clone() })),
            crate::check::types::Ty::TyAssoc(_, i) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**i).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start TyNamesIn, x`: what the function value is when passed to `@Run`.
pub fn start_ty_names_in(t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TyNamesIn { t })
}

/// ```prism
/// HasArrow: unbounded fn Ty -> Bool
/// ```
pub fn has_arrow(t: &crate::check::types::Ty) -> bool {
    match t {
        crate::check::types::Ty::TyFn(_, _, _) => true,
        crate::check::types::Ty::TyCon(_, args) => run_to_end(fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || has_arrow(&a))
        }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || has_arrow(&a))
        }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::check::types::Ty::TyArray(e) => has_arrow(&**e),
        crate::check::types::Ty::TyMap(k, v_) => has_arrow(&**k) || has_arrow(&**v_),
        crate::check::types::Ty::TySig(_, i) => has_arrow(&**i),
        crate::check::types::Ty::TyAt(i, _) => has_arrow(&**i),
        crate::check::types::Ty::TyElem(_, i) => has_arrow(&**i),
        crate::check::types::Ty::TyAssoc(_, i) => has_arrow(&**i),
        _ => false,
    }
}

/// The step machine of `HasArrow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HasArrow: unbounded fn Ty -> Bool
/// ```
pub struct HasArrow {
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for HasArrow {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::Finished(true),
            crate::check::types::Ty::TyCon(_, args) => fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| entered(once_job(move || {
                let seen = p0;
                let a = p1;
                prism_rtl::Turn::Finished(seen || has_arrow(&a))
            }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| entered(once_job(move || {
                let seen = p0;
                let a = p1;
                prism_rtl::Turn::Finished(seen || has_arrow(&a))
            }))) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**e).clone() })),
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_has_arrow(k.clone()), move |has_arrow_4707: bool| prism_rtl::Turn::Finished(has_arrow_4707 || has_arrow(&v_)))
            },
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**i).clone() })),
            crate::check::types::Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**i).clone() })),
            crate::check::types::Ty::TyElem(_, i) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**i).clone() })),
            crate::check::types::Ty::TyAssoc(_, i) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**i).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start HasArrow, x`: what the function value is when passed to `@Run`.
pub fn start_has_arrow(t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HasArrow { t })
}

/// ```prism
/// BodyTys: fn TyInfo -> [Ty]
/// ```
pub fn body_tys(ti: &crate::check::env::TyInfo) -> Array<crate::check::types::Ty> {
    match &ti.body {
        crate::check::env::TyBody::BRecord(fields) => each(fields, &(|(_, t): &(Text, crate::check::types::Ty)| t.clone())),
        crate::check::env::TyBody::BChoice(cases) => fold(cases, &Array::new(), &(|acc: &Array<crate::check::types::Ty>, (_, args): &(Text, Array<crate::check::types::Ty>)| append(acc, args))),
        crate::check::env::TyBody::BAlias(t) => Array::from(vec![t.clone()]),
        _ => Array::new(),
    }
}

/// ```prism
/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub fn neg_walk(g: &crate::check::env::G, target: &Text, t: &crate::check::types::Ty, b: &bool, seen: &Map<Text, bool>) -> (bool, Map<Text, bool>) {
    match t {
        crate::check::types::Ty::TyCon(c, args) => if c == target {
            (*b, seen.clone())
        } else {
            match get(&g.types, c) {
                Some(ti) => {
                    let sk = Text::from(format!("{}{}", &(if *b { Text::lit("-") } else { Text::lit("+") }), &crate::check::types::show_ty(&crate::check::types::new_st(&Nat::from(0u32)), t)));
                    if crate::check::env::has_key(seen, &sk) {
                        (false, seen.clone())
                    } else {
                        if &len(&keys(seen)) > &Nat::from(400u32) {
                            (true, seen.clone())
                        } else {
                            neg_walks(g, target, &run_to_end(each_job(body_tys(&ti), {
                                let ti = ti.clone();
                                let args = args.clone();
                                Rc::new(move |p0: crate::check::types::Ty| {
                                    let ti = ti.clone();
                                    let args = args.clone();
                                    entered(once_job(move || {
                                        let bt = p0;
                                        prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m: crate::check::env::reading::param_inst(&ti.params, &args), t: bt.clone() }))
                                    }))
                                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                            })), b, &insert(seen, &sk, &true))
                        }
                    }
                },
                None => neg_walks(g, target, args, b, seen),
            }
        },
        crate::check::types::Ty::TyFn(col, ps, res) => {
            let (bad, seen2) = neg_walks(g, target, ps, &(*b || (col != &crate::check::types::Col::CUnbound)), seen);
            if bad { (true, seen2.clone()) } else { neg_walk(g, target, &**res, b, &seen2) }
        },
        crate::check::types::Ty::TyTuple(ts) => neg_walks(g, target, ts, b, seen),
        crate::check::types::Ty::TyArray(e) => neg_walk(g, target, &**e, b, seen),
        crate::check::types::Ty::TyMap(k, v_) => neg_walks(g, target, &Array::from(vec![(**k).clone(), (**v_).clone()]), b, seen),
        crate::check::types::Ty::TySig(_, i) => neg_walk(g, target, &**i, b, seen),
        crate::check::types::Ty::TyAt(i, _) => neg_walk(g, target, &**i, b, seen),
        crate::check::types::Ty::TyElem(_, i) => neg_walk(g, target, &**i, b, seen),
        crate::check::types::Ty::TyAssoc(_, i) => neg_walk(g, target, &**i, b, seen),
        _ => (false, seen.clone()),
    }
}

/// The step machine of `NegWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub struct NegWalk {
    pub g: crate::check::env::G,
    pub target: Text,
    pub t: crate::check::types::Ty,
    pub b: bool,
    pub seen: Map<Text, bool>,
}

impl prism_rtl::Job<(bool, Map<Text, bool>)> for NegWalk {
    fn cycle(&self) -> prism_rtl::Turn<(bool, Map<Text, bool>)> {
        let g = &self.g;
        let target = &self.target;
        let t = &self.t;
        let b = &self.b;
        let seen = &self.seen;
        match t {
            crate::check::types::Ty::TyCon(c, args) => if c == target {
                prism_rtl::Turn::Finished((*b, seen.clone()))
            } else {
                match get(&g.types, c) {
                    Some(ti) => {
                        let args = args.clone();
                        let b = *b;
                        let g = g.clone();
                        let seen = seen.clone();
                        let t = t.clone();
                        let target = target.clone();
                        call_then(crate::check::types::start_show_ty(crate::check::types::new_st(&Nat::from(0u32)), t.clone()), move |show_ty_5844: Text| {
                            let sk = Text::from(format!("{}{}", &(if b { Text::lit("-") } else { Text::lit("+") }), &show_ty_5844));
                            if crate::check::env::has_key(&seen, &sk) {
                                prism_rtl::Turn::Finished((false, seen.clone()))
                            } else {
                                if &len(&keys(&seen)) > &Nat::from(400u32) {
                                    prism_rtl::Turn::Finished((true, seen.clone()))
                                } else {
                                    call_value(each_job(body_tys(&ti), {
                                        let ti = ti.clone();
                                        let args = args.clone();
                                        Rc::new(move |p0: crate::check::types::Ty| {
                                            let ti = ti.clone();
                                            let args = args.clone();
                                            entered(once_job(move || {
                                                let bt = p0;
                                                prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m: crate::check::env::reading::param_inst(&ti.params, &args), t: bt.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                                    }), move |each_6026: Array<crate::check::types::Ty>| prism_rtl::Turn::More(Rc::new(NegWalks { g: g.clone(), target: target.clone(), ts: each_6026, b, seen: insert(&seen, &sk, &true) })))
                                }
                            }
                        })
                    },
                    None => prism_rtl::Turn::More(Rc::new(NegWalks { g: g.clone(), target: target.clone(), ts: args.clone(), b: *b, seen: seen.clone() })),
                }
            },
            crate::check::types::Ty::TyFn(col, ps, res) => {
                let b = *b;
                let col = col.clone();
                let g = g.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                let seen = seen.clone();
                let target = target.clone();
                call_then(start_neg_walks(g.clone(), target.clone(), ps.clone(), b || (&col != &crate::check::types::Col::CUnbound), seen.clone()), move |neg_walks_6222: (bool, Map<Text, bool>)| {
                    let (bad, seen2) = neg_walks_6222;
                    if bad {
                        prism_rtl::Turn::Finished((true, seen2.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: res.clone(), b, seen: seen2.clone() }))
                    }
                })
            },
            crate::check::types::Ty::TyTuple(ts) => prism_rtl::Turn::More(Rc::new(NegWalks { g: g.clone(), target: target.clone(), ts: ts.clone(), b: *b, seen: seen.clone() })),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**e).clone(), b: *b, seen: seen.clone() })),
            crate::check::types::Ty::TyMap(k, v_) => prism_rtl::Turn::More(Rc::new(NegWalks { g: g.clone(), target: target.clone(), ts: Array::from(vec![(**k).clone(), (**v_).clone()]), b: *b, seen: seen.clone() })),
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**i).clone(), b: *b, seen: seen.clone() })),
            crate::check::types::Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**i).clone(), b: *b, seen: seen.clone() })),
            crate::check::types::Ty::TyElem(_, i) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**i).clone(), b: *b, seen: seen.clone() })),
            crate::check::types::Ty::TyAssoc(_, i) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**i).clone(), b: *b, seen: seen.clone() })),
            _ => prism_rtl::Turn::Finished((false, seen.clone())),
        }
    }
}

/// `Start NegWalk, x`: what the function value is when passed to `@Run`.
pub fn start_neg_walk(g: crate::check::env::G, target: Text, t: crate::check::types::Ty, b: bool, seen: Map<Text, bool>) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>> {
    Rc::new(NegWalk { g, target, t, b, seen })
}

/// ```prism
/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub fn neg_walks(g: &crate::check::env::G, target: &Text, ts: &Array<crate::check::types::Ty>, b: &bool, seen: &Map<Text, bool>) -> (bool, Map<Text, bool>) {
    run_to_end(fold_job(ts.clone(), (false, seen.clone()), {
        let g = g.clone();
        let target = target.clone();
        let b = *b;
        Rc::new(move |(p0, p1): ((bool, Map<Text, bool>), crate::check::types::Ty)| {
            let g = g.clone();
            let target = target.clone();
            let b = b;
            entered(once_job(move || {
                let (bad, sn) = p0;
                let t = p1;
                if bad {
                    prism_rtl::Turn::Finished((true, sn.clone()))
                } else {
                    prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: t.clone(), b, seen: sn.clone() }))
                }
            }))
        }) as Rc<dyn Fn(((bool, Map<Text, bool>), crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>>>
    }))
}

/// The step machine of `NegWalks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub struct NegWalks {
    pub g: crate::check::env::G,
    pub target: Text,
    pub ts: Array<crate::check::types::Ty>,
    pub b: bool,
    pub seen: Map<Text, bool>,
}

impl prism_rtl::Job<(bool, Map<Text, bool>)> for NegWalks {
    fn cycle(&self) -> prism_rtl::Turn<(bool, Map<Text, bool>)> {
        let g = &self.g;
        let target = &self.target;
        let ts = &self.ts;
        let b = &self.b;
        let seen = &self.seen;
        fold_job(ts.clone(), (false, seen.clone()), {
            let g = g.clone();
            let target = target.clone();
            let b = *b;
            Rc::new(move |(p0, p1): ((bool, Map<Text, bool>), crate::check::types::Ty)| {
                let g = g.clone();
                let target = target.clone();
                let b = b;
                entered(once_job(move || {
                    let (bad, sn) = p0;
                    let t = p1;
                    if bad {
                        prism_rtl::Turn::Finished((true, sn.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: t.clone(), b, seen: sn.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(((bool, Map<Text, bool>), crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>>>
        }).cycle()
    }
}

/// `Start NegWalks, x`: what the function value is when passed to `@Run`.
pub fn start_neg_walks(g: crate::check::env::G, target: Text, ts: Array<crate::check::types::Ty>, b: bool, seen: Map<Text, bool>) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>> {
    Rc::new(NegWalks { g, target, ts, b, seen })
}

/// ```prism
/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
/// ```
pub fn nat_minus_seeds(st: &crate::check::types::St) -> Map<Text, crate::check::shrink::Rel> {
    run_to_end(fold_job(keys(&st.size_tys), Map::new(), {
        let st = st.clone();
        Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Text)| {
            let st = st.clone();
            entered(once_job(move || {
                let m = p0;
                let k = p1;
                match get(&st.size_tys, &k) {
                    Some(t) => call_then(crate::check::types::recording::start_zonk(st.clone(), t.clone()), move |zonk_7185: crate::check::types::Ty| if &zonk_7185 == &crate::check::types::t_nat() {
                        prism_rtl::Turn::Finished(insert(&m, &Text::from(format!("nat:{}", &k)), &crate::check::shrink::relations::no_rel()))
                    } else {
                        prism_rtl::Turn::Finished(m.clone())
                    }),
                    None => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
    }))
}

/// The step machine of `NatMinusSeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
/// ```
pub struct NatMinusSeeds {
    pub st: crate::check::types::St,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for NatMinusSeeds {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let st = &self.st;
        fold_job(keys(&st.size_tys), Map::new(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Text)| {
                let st = st.clone();
                entered(once_job(move || {
                    let m = p0;
                    let k = p1;
                    match get(&st.size_tys, &k) {
                        Some(t) => call_then(crate::check::types::recording::start_zonk(st.clone(), t.clone()), move |zonk_7185: crate::check::types::Ty| if &zonk_7185 == &crate::check::types::t_nat() {
                            prism_rtl::Turn::Finished(insert(&m, &Text::from(format!("nat:{}", &k)), &crate::check::shrink::relations::no_rel()))
                        } else {
                            prism_rtl::Turn::Finished(m.clone())
                        }),
                        None => prism_rtl::Turn::Finished(m.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
        }).cycle()
    }
}

/// `Start NatMinusSeeds, x`: what the function value is when passed to `@Run`.
pub fn start_nat_minus_seeds(st: crate::check::types::St) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(NatMinusSeeds { st })
}

/// ```prism
/// DefClauses: fn Def -> [FnClause]
/// ```
pub fn def_clauses(d: &crate::check::env::Def) -> Array<crate::syntax::decls::FnClause> {
    match &d.body {
        crate::check::env::DefBody::DbFn(clauses) => clauses.clone(),
        crate::check::env::DefBody::DbMethod(clauses, _, _) => clauses.clone(),
        crate::check::env::DefBody::DbDefault(clauses, _) => clauses.clone(),
        crate::check::env::DefBody::DbWidget(w) => Array::from(vec![crate::syntax::decls::FnClause { name: crate::syntax::decls::DefName::DefSName(w.name.clone()), params: Array::new(), body: crate::syntax::decls::FnBody::BodyBlock(w.body.clone()), span: w.span.clone() }]),
        crate::check::env::DefBody::DbLet(l) => Array::from(vec![crate::syntax::decls::FnClause { name: crate::syntax::decls::DefName::DefOp(d.name.clone(), l.span.clone()), params: Array::new(), body: crate::syntax::decls::FnBody::BodyExpr(l.value.clone()), span: l.span.clone() }]),
        _ => Array::new(),
    }
}

/// ```prism
/// OwnKey: fn Def -> Def
/// ```
pub fn own_key(d: &crate::check::env::Def) -> crate::check::env::Def {
    match &d.body {
        crate::check::env::DefBody::DbMethod(_, _, im) => {
            let mut this: crate::check::env::Def = d.clone();
            this.qk = Text::from(format!("{} #{}.{}", &d.qk, &im.file, &im.span.start));
            this
        },
        _ => d.clone(),
    }
}

/// ```prism
/// ?MethodOf: fn G, Def -> ?Text
/// ```
pub fn method_of(g: &crate::check::env::G, d: &crate::check::env::Def) -> Option<Text> {
    match &d.body {
        crate::check::env::DefBody::DbMethod(_, cls, _) => crate::check::method_key(g, cls, &d.name),
        crate::check::env::DefBody::DbDefault(_, cls) => crate::check::method_key(g, cls, &d.name),
        _ => None,
    }
}

/// ```prism
/// MethodTargets: fn G, [Def] -> (Text ==> [Text])
/// ```
pub fn method_targets(g: &crate::check::env::G, fns: &Array<crate::check::env::Def>) -> Map<Text, Array<Text>> {
    fold(fns, &Map::new(), &(|m: &Map<Text, Array<Text>>, d: &crate::check::env::Def| match method_of(g, d) {
        Some(mk) => insert(m, &mk, &crate::check::types::add_text(&or(&get(m, &mk), &Array::new()), &d.qk)),
        None => m.clone(),
    }))
}

/// ```prism
/// ImplDefs: fn G, [Def] -> (Text ==> Text)
/// ```
pub fn impl_defs(g: &crate::check::env::G, fns: &Array<crate::check::env::Def>) -> Map<Text, Text> {
    fold(fns, &Map::new(), &(|m: &Map<Text, Text>, d: &crate::check::env::Def| match &d.body {
        crate::check::env::DefBody::DbMethod(_, _, im) => match method_of(g, d) {
            Some(mk) => insert(m, &Text::from(format!("{}|{}.{}", &mk, &im.file, &im.span.start)), &d.qk),
            None => m.clone(),
        },
        _ => m.clone(),
    }))
}

/// ```prism
/// ?MethodClass: fn G, Text -> ?Text
/// ```
pub fn method_class(g: &crate::check::env::G, k: &Text) -> Option<Text> {
    match get(&g.vals, k) {
        Some(v_) => if &v_.sort != &Text::lit("method") {
            None
        } else {
            match index(&v_.scheme.bounds, &Nat::from(0u32)) {
                Some((_, cls)) => Some(cls),
                None => None,
            }
        },
        None => None,
    }
}

/// ```prism
/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
/// ```
pub fn dispatch_targets(sk: &crate::check::shrink::Shrink, d: &crate::check::env::Def, site: &crate::check::shrink::walk::Site, k: &Text) -> Array<Text> {
    let all = targets_of(sk, k);
    match method_class(&sk.g, k) {
        None => all.clone(),
        Some(cls) => {
            let ck = crate::check::types::recording::choice_key(&d.file, &site.span, &cls);
            match get(&sk.choices, &ck) {
                None => all.clone(),
                Some(cs) => run_to_end(fold_job(cs.clone(), Array::new(), {
                    let sk = sk.clone();
                    let k = k.clone();
                    let cls = cls.clone();
                    let all = all.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let sk = sk.clone();
                        let k = k.clone();
                        let cls = cls.clone();
                        let all = all.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let ch = p1;
                            call_then(start_choice_targets(sk.clone(), k.clone(), cls.clone(), all.clone(), ch.clone(), Array::new()), move |choice_targets_10578: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &choice_targets_10578)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                })),
            }
        },
    }
}

/// The step machine of `DispatchTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
/// ```
pub struct DispatchTargets {
    pub sk: crate::check::shrink::Shrink,
    pub d: crate::check::env::Def,
    pub site: crate::check::shrink::walk::Site,
    pub k: Text,
}

impl prism_rtl::Job<Array<Text>> for DispatchTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let d = &self.d;
        let site = &self.site;
        let k = &self.k;
        let all = targets_of(sk, k);
        match method_class(&sk.g, k) {
            None => prism_rtl::Turn::Finished(all.clone()),
            Some(cls) => {
                let ck = crate::check::types::recording::choice_key(&d.file, &site.span, &cls);
                match get(&sk.choices, &ck) {
                    None => prism_rtl::Turn::Finished(all.clone()),
                    Some(cs) => fold_job(cs.clone(), Array::new(), {
                        let sk = sk.clone();
                        let k = k.clone();
                        let cls = cls.clone();
                        let all = all.clone();
                        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                            let sk = sk.clone();
                            let k = k.clone();
                            let cls = cls.clone();
                            let all = all.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let ch = p1;
                                call_then(start_choice_targets(sk.clone(), k.clone(), cls.clone(), all.clone(), ch.clone(), Array::new()), move |choice_targets_10578: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &choice_targets_10578)))
                            }))
                        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }).cycle(),
                }
            },
        }
    }
}

/// `Start DispatchTargets, x`: what the function value is when passed to `@Run`.
pub fn start_dispatch_targets(sk: crate::check::shrink::Shrink, d: crate::check::env::Def, site: crate::check::shrink::walk::Site, k: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(DispatchTargets { sk, d, site, k })
}

/// ```prism
/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub fn choice_targets(sk: &crate::check::shrink::Shrink, k: &Text, cls: &Text, all: &Array<Text>, ch: &Text, seen: &Array<Text>) -> Array<Text> {
    if ch == &Text::lit("none") {
        Array::new()
    } else {
        if crate::syntax::lexer::chars::has_prefix(ch, &Text::lit("impl:")) {
            match get(&sk.impl_defs, &Text::from(format!("{}|{}", k, &crate::syntax::lexer::chars::drop_prefix(ch, &Text::lit("impl:"))))) {
                Some(q) => Array::from(vec![q]),
                None => filter(all, &(|q: &Text| q == k)),
            }
        } else {
            if crate::syntax::lexer::chars::has_prefix(ch, &Text::lit("derived:")) {
                derived_targets(sk, k, cls, all, &crate::syntax::lexer::chars::drop_prefix(ch, &Text::lit("derived:")), seen)
            } else {
                all.clone()
            }
        }
    }
}

/// The step machine of `ChoiceTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub struct ChoiceTargets {
    pub sk: crate::check::shrink::Shrink,
    pub k: Text,
    pub cls: Text,
    pub all: Array<Text>,
    pub ch: Text,
    pub seen: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for ChoiceTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let k = &self.k;
        let cls = &self.cls;
        let all = &self.all;
        let ch = &self.ch;
        let seen = &self.seen;
        if ch == &Text::lit("none") {
            prism_rtl::Turn::Finished(Array::new())
        } else {
            if crate::syntax::lexer::chars::has_prefix(ch, &Text::lit("impl:")) {
                match get(&sk.impl_defs, &Text::from(format!("{}|{}", k, &crate::syntax::lexer::chars::drop_prefix(ch, &Text::lit("impl:"))))) {
                    Some(q) => prism_rtl::Turn::Finished(Array::from(vec![q.clone()])),
                    None => prism_rtl::Turn::Finished(filter(all, &(|q: &Text| q == k))),
                }
            } else {
                if crate::syntax::lexer::chars::has_prefix(ch, &Text::lit("derived:")) {
                    prism_rtl::Turn::More(Rc::new(DerivedTargets { sk: sk.clone(), k: k.clone(), cls: cls.clone(), all: all.clone(), n: crate::syntax::lexer::chars::drop_prefix(ch, &Text::lit("derived:")), seen: seen.clone() }))
                } else {
                    prism_rtl::Turn::Finished(all.clone())
                }
            }
        }
    }
}

/// `Start ChoiceTargets, x`: what the function value is when passed to `@Run`.
pub fn start_choice_targets(sk: crate::check::shrink::Shrink, k: Text, cls: Text, all: Array<Text>, ch: Text, seen: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ChoiceTargets { sk, k, cls, all, ch, seen })
}

/// ```prism
/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub fn derived_targets(sk: &crate::check::shrink::Shrink, k: &Text, cls: &Text, all: &Array<Text>, n: &Text, seen: &Array<Text>) -> Array<Text> {
    if crate::check::types::has_text(seen, n) {
        Array::new()
    } else {
        {
            let tys = match get(&sk.g.types, n) {
                Some(ti) => match &ti.body {
                    crate::check::env::TyBody::BRecord(fields) => each(fields, &(|(_, t): &(Text, crate::check::types::Ty)| t.clone())),
                    crate::check::env::TyBody::BChoice(cases) => fold(cases, &Array::new(), &(|acc: &Array<crate::check::types::Ty>, (_, args): &(Text, Array<crate::check::types::Ty>)| append(acc, args))),
                    crate::check::env::TyBody::BAlias(t) => Array::from(vec![t.clone()]),
                    _ => Array::new(),
                },
                None => Array::new(),
            };
            let heads = fold(&tys, &Array::new(), &(|acc: &Array<Text>, t: &crate::check::types::Ty| crate::check::types::union_texts(acc, &ty_heads(t))));
            run_to_end(fold_job(heads.clone(), Array::new(), {
                let sk = sk.clone();
                let k = k.clone();
                let cls = cls.clone();
                let all = all.clone();
                let seen = seen.clone();
                let n = n.clone();
                Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                    let sk = sk.clone();
                    let k = k.clone();
                    let cls = cls.clone();
                    let all = all.clone();
                    let seen = seen.clone();
                    let n = n.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let h = p1;
                        prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &head_targets(&sk, &k, &cls, &all, &h, &push(&seen, &n))))
                    }))
                }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }))
        }
    }
}

/// The step machine of `DerivedTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub struct DerivedTargets {
    pub sk: crate::check::shrink::Shrink,
    pub k: Text,
    pub cls: Text,
    pub all: Array<Text>,
    pub n: Text,
    pub seen: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for DerivedTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let k = &self.k;
        let cls = &self.cls;
        let all = &self.all;
        let n = &self.n;
        let seen = &self.seen;
        if crate::check::types::has_text(seen, n) {
            prism_rtl::Turn::Finished(Array::new())
        } else {
            {
                let tys = match get(&sk.g.types, n) {
                    Some(ti) => match &ti.body {
                        crate::check::env::TyBody::BRecord(fields) => each(fields, &(|(_, t): &(Text, crate::check::types::Ty)| t.clone())),
                        crate::check::env::TyBody::BChoice(cases) => fold(cases, &Array::new(), &(|acc: &Array<crate::check::types::Ty>, (_, args): &(Text, Array<crate::check::types::Ty>)| append(acc, args))),
                        crate::check::env::TyBody::BAlias(t) => Array::from(vec![t.clone()]),
                        _ => Array::new(),
                    },
                    None => Array::new(),
                };
                let heads = fold(&tys, &Array::new(), &(|acc: &Array<Text>, t: &crate::check::types::Ty| crate::check::types::union_texts(acc, &ty_heads(t))));
                fold_job(heads.clone(), Array::new(), {
                    let sk = sk.clone();
                    let k = k.clone();
                    let cls = cls.clone();
                    let all = all.clone();
                    let seen = seen.clone();
                    let n = n.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let sk = sk.clone();
                        let k = k.clone();
                        let cls = cls.clone();
                        let all = all.clone();
                        let seen = seen.clone();
                        let n = n.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let h = p1;
                            prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &head_targets(&sk, &k, &cls, &all, &h, &push(&seen, &n))))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle()
            }
        }
    }
}

/// `Start DerivedTargets, x`: what the function value is when passed to `@Run`.
pub fn start_derived_targets(sk: crate::check::shrink::Shrink, k: Text, cls: Text, all: Array<Text>, n: Text, seen: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(DerivedTargets { sk, k, cls, all, n, seen })
}

/// ```prism
/// TyHeads: fn Ty -> [Text]
/// ```
pub fn ty_heads(t: &crate::check::types::Ty) -> Array<Text> {
    match t {
        crate::check::types::Ty::TyCon(n, args) => fold(args, &Array::from(vec![n.clone()]), &(|acc: &Array<Text>, a: &crate::check::types::Ty| crate::check::types::union_texts(acc, &ty_heads(a)))),
        crate::check::types::Ty::TyTuple(ts) => fold(ts, &Array::new(), &(|acc: &Array<Text>, a: &crate::check::types::Ty| crate::check::types::union_texts(acc, &ty_heads(a)))),
        crate::check::types::Ty::TyArray(e) => ty_heads(&**e),
        crate::check::types::Ty::TyMap(a, b) => crate::check::types::union_texts(&ty_heads(&**a), &ty_heads(&**b)),
        crate::check::types::Ty::TySig(_, i) => ty_heads(&**i),
        crate::check::types::Ty::TyQ(_) => Array::new(),
        crate::check::types::Ty::TyRigid(_) => Array::new(),
        crate::check::types::Ty::TyFn(_, _, _) => Array::new(),
        crate::check::types::Ty::TyElem(_, _) => Array::new(),
        crate::check::types::Ty::TyElemAny(_) => Array::new(),
        _ => Array::from(vec![Text::lit("?")]),
    }
}

/// ```prism
/// HeadTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub fn head_targets(sk: &crate::check::shrink::Shrink, k: &Text, cls: &Text, all: &Array<Text>, h: &Text, seen: &Array<Text>) -> Array<Text> {
    if h == &Text::lit("?") {
        all.clone()
    } else {
        if crate::check::env::traits::builtin_has(cls, h) || crate::check::env::is_prim_type(h) {
            Array::new()
        } else {
            match index(&filter(&or(&get(&sk.g.impls, cls), &Array::new()), &(|im: &crate::check::env::ImplInfo| &head_key(&im.head) == &Some(h.clone()))), &Nat::from(0u32)) {
                Some(im) => choice_targets(sk, k, cls, all, &crate::check::env::traits::impl_choice(&im), seen),
                None => all.clone(),
            }
        }
    }
}

/// ```prism
/// ?HeadKey: fn Ty -> ?Text
/// ```
pub fn head_key(ty0: &crate::check::types::Ty) -> Option<Text> {
    match ty0 {
        crate::check::types::Ty::TyCon(n, _) => Some(n.clone()),
        _ => None,
    }
}

/// ```prism
/// TargetsOf: fn Shrink, Text -> [Text]
/// ```
pub fn targets_of(sk: &crate::check::shrink::Shrink, k: &Text) -> Array<Text> {
    or(&get(&sk.targets, k), &Array::from(vec![k.clone()]))
}

/// ```prism
/// SigKeyOf: fn Shrink, Text -> Text
/// ```
pub fn sig_key_of(sk: &crate::check::shrink::Shrink, k: &Text) -> Text {
    match get(&sk.by_key, k) {
        Some(d) => or(&method_of(&sk.g, &d), k),
        None => k.clone(),
    }
}

/// ```prism
/// ShownKey: fn Text -> Text
/// ```
pub fn shown_key(k: &Text) -> Text {
    crate::check::types::bare_name(&or(&index(&split_on(&or(&crate::syntax::lexer::chars::last(&split_on(k, &Text::lit(" impl "))), k), &Text::lit(" #")), &Nat::from(0u32)), k))
}

/// ```prism
/// IsUnboundedKey: fn G, Text -> Bool
/// ```
pub fn is_unbounded_key(g: &crate::check::env::G, k: &Text) -> bool {
    match get(&g.vals, k) {
        Some(v_) => match &v_.scheme.ty {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CUnbound, _, _) => true,
            _ => false,
        },
        None => false,
    }
}
