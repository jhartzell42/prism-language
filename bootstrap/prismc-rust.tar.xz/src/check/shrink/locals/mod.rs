//! The module `Check.Shrink.Locals`, from `target/bootstrap/src/prismc/check/shrink/locals.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
/// ```
pub fn with_locals(sk: &crate::check::shrink::Shrink, found: &Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>) -> crate::check::shrink::Shrink {
    let (bases, owners, clauses, wdecls) = fold(found, &(Map::new(), Map::new(), Map::new(), Map::new()), &(|(bs, os, cs, ws): &(Map<Text, Map<Text, crate::check::shrink::Rel>>, Map<Text, Text>, Map<Text, Array<crate::syntax::decls::FnClause>>, Map<Text, (crate::check::env::Def, crate::syntax::decls::WidgetDecl)>), (d, gk, n, m, c_opt, w_opt): &(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)| {
        let qk = local_key(n, &d.qk, gk);
        let bs2 = if crate::check::env::has_key(bs, &qk) {
            bs.clone()
        } else {
            insert(bs, &qk, &crate::check::shrink::summaries::marks(m))
        };
        let os2 = insert(os, &qk, &d.qk);
        let cs2 = match c_opt {
            Some(c) => insert(cs, &qk, &push(&or(&get(cs, &qk), &Array::new()), c)),
            None => cs.clone(),
        };
        let ws2 = match w_opt {
            Some(w) => insert(ws, &qk, &(d.clone(), w.clone())),
            None => ws.clone(),
        };
        (bs2.clone(), os2.clone(), cs2.clone(), ws2.clone())
    }));
    let fn_defs = fold(&keys(&clauses), &Array::new(), &(|acc: &Array<crate::check::env::Def>, qk: &Text| match (get(&owners, qk), get(&clauses, qk)) {
        (Some(oq), Some(cl)) => match get(&sk.by_key, &oq) {
            Some(d) => push(acc, &crate::check::env::Def { qk: qk.clone(), name: or(&index(&split_on(qk, &Text::lit(" #")), &Nat::from(0u32)), qk), home: d.home.clone(), file: d.file.clone(), span: d.span.clone(), body: crate::check::env::DefBody::DbFn(cl) }),
            None => acc.clone(),
        },
        _ => acc.clone(),
    }));
    let w_defs = fold(&keys(&wdecls), &Array::new(), &(|acc: &Array<crate::check::env::Def>, qk: &Text| match get(&wdecls, qk) {
        Some((d, w)) => push(acc, &crate::check::env::Def { qk: qk.clone(), name: crate::check::env::sname_key(&w.name), home: d.home.clone(), file: d.file.clone(), span: w.span.clone(), body: crate::check::env::DefBody::DbWidget(w.clone()) }),
        None => acc.clone(),
    }));
    let locals = append(&fn_defs, &w_defs);
    let mut this: crate::check::shrink::Shrink = sk.clone();
    this.fns = append(&this.fns, &locals);
    this.by_key = fold(&locals, &this.by_key, &(|m: &Map<Text, crate::check::env::Def>, d: &crate::check::env::Def| insert(m, &d.qk, d)));
    this.local_of = owners.clone();
    this.local_base = bases.clone();
    this
}

/// The step machine of `WithLocals`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
/// ```
pub struct WithLocals {
    pub sk: crate::check::shrink::Shrink,
    pub found: Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>,
}

impl prism_rtl::Job<crate::check::shrink::Shrink> for WithLocals {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::shrink::Shrink> {
        let sk = &self.sk;
        let found = &self.found;
        let (bases, owners, clauses, wdecls) = fold(found, &(Map::new(), Map::new(), Map::new(), Map::new()), &(|(bs, os, cs, ws): &(Map<Text, Map<Text, crate::check::shrink::Rel>>, Map<Text, Text>, Map<Text, Array<crate::syntax::decls::FnClause>>, Map<Text, (crate::check::env::Def, crate::syntax::decls::WidgetDecl)>), (d, gk, n, m, c_opt, w_opt): &(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)| {
            let qk = local_key(n, &d.qk, gk);
            let bs2 = if crate::check::env::has_key(bs, &qk) {
                bs.clone()
            } else {
                insert(bs, &qk, &crate::check::shrink::summaries::marks(m))
            };
            let os2 = insert(os, &qk, &d.qk);
            let cs2 = match c_opt {
                Some(c) => insert(cs, &qk, &push(&or(&get(cs, &qk), &Array::new()), c)),
                None => cs.clone(),
            };
            let ws2 = match w_opt {
                Some(w) => insert(ws, &qk, &(d.clone(), w.clone())),
                None => ws.clone(),
            };
            (bs2.clone(), os2.clone(), cs2.clone(), ws2.clone())
        }));
        let fn_defs = fold(&keys(&clauses), &Array::new(), &(|acc: &Array<crate::check::env::Def>, qk: &Text| match (get(&owners, qk), get(&clauses, qk)) {
            (Some(oq), Some(cl)) => match get(&sk.by_key, &oq) {
                Some(d) => push(acc, &crate::check::env::Def { qk: qk.clone(), name: or(&index(&split_on(qk, &Text::lit(" #")), &Nat::from(0u32)), qk), home: d.home.clone(), file: d.file.clone(), span: d.span.clone(), body: crate::check::env::DefBody::DbFn(cl) }),
                None => acc.clone(),
            },
            _ => acc.clone(),
        }));
        let w_defs = fold(&keys(&wdecls), &Array::new(), &(|acc: &Array<crate::check::env::Def>, qk: &Text| match get(&wdecls, qk) {
            Some((d, w)) => push(acc, &crate::check::env::Def { qk: qk.clone(), name: crate::check::env::sname_key(&w.name), home: d.home.clone(), file: d.file.clone(), span: w.span.clone(), body: crate::check::env::DefBody::DbWidget(w.clone()) }),
            None => acc.clone(),
        }));
        let locals = append(&fn_defs, &w_defs);
        prism_rtl::Turn::Finished({
            let mut this: crate::check::shrink::Shrink = sk.clone();
            this.fns = append(&this.fns, &locals);
            this.by_key = fold(&locals, &this.by_key, &(|m: &Map<Text, crate::check::env::Def>, d: &crate::check::env::Def| insert(m, &d.qk, d)));
            this.local_of = owners.clone();
            this.local_base = bases.clone();
            this
        })
    }
}

/// `Start WithLocals, x`: what the function value is when passed to `@Run`.
pub fn start_with_locals(sk: crate::check::shrink::Shrink, found: Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>) -> Rc<dyn prism_rtl::Job<crate::check::shrink::Shrink>> {
    Rc::new(WithLocals { sk, found })
}

/// ```prism
/// LocalKey: fn Text, Text, Text -> Text
/// ```
pub fn local_key(n: &Text, owner: &Text, gk: &Text) -> Text {
    Text::from(format!("{} #local {} {}", n, owner, gk))
}

/// ```prism
/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
/// ```
pub fn def_walk(sk: &crate::check::shrink::Shrink, d: &crate::check::env::Def) -> (Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>) {
    let (refs, locals) = run_to_end(fold_job(crate::check::shrink::types::def_clauses(d), (Array::new(), Array::new()), {
        let sk = sk.clone();
        let d = d.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>), crate::syntax::decls::FnClause)| {
            let sk = sk.clone();
            let d = d.clone();
            entered(once_job(move || {
                let (rs, ls) = p0;
                let c = p1;
                call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_4223: Map<Text, crate::check::shrink::Rel>| call_then(crate::check::shrink::walk::start_body_spots(c.body.clone(), clause_base_4223), move |body_spots_4204: Array<crate::check::shrink::walk::Spot>| {
                    let spots = body_spots_4204;
                    call_then(crate::check::shrink::calls::start_spots_refs(sk.clone(), d.clone(), spots.clone(), rs.clone()), move |spots_refs_4255: Array<Text>| prism_rtl::Turn::Finished((spots_refs_4255, fold(&spots, &ls, &(|a2: &Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>, sp: &crate::check::shrink::walk::Spot| append(a2, &spot_local(&d, sp)))))))
                }))
            }))
        }) as Rc<dyn Fn(((Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>), crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)>>>
    }));
    (d.qk.clone(), refs.clone(), locals.clone())
}

/// The step machine of `DefWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
/// ```
pub struct DefWalk {
    pub sk: crate::check::shrink::Shrink,
    pub d: crate::check::env::Def,
}

impl prism_rtl::Job<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)> for DefWalk {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)> {
        let sk = &self.sk;
        let d = &self.d;
        let d = d.clone();
        let sk = sk.clone();
        call_value(fold_job(crate::check::shrink::types::def_clauses(&d), (Array::new(), Array::new()), {
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): ((Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>), crate::syntax::decls::FnClause)| {
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let (rs, ls) = p0;
                    let c = p1;
                    call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_4223: Map<Text, crate::check::shrink::Rel>| call_then(crate::check::shrink::walk::start_body_spots(c.body.clone(), clause_base_4223), move |body_spots_4204: Array<crate::check::shrink::walk::Spot>| {
                        let spots = body_spots_4204;
                        call_then(crate::check::shrink::calls::start_spots_refs(sk.clone(), d.clone(), spots.clone(), rs.clone()), move |spots_refs_4255: Array<Text>| prism_rtl::Turn::Finished((spots_refs_4255, fold(&spots, &ls, &(|a2: &Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>, sp: &crate::check::shrink::walk::Spot| append(a2, &spot_local(&d, sp)))))))
                    }))
                }))
            }) as Rc<dyn Fn(((Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>), crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)>>>
        }), move |fold_4130: (Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)| {
            let (refs, locals) = fold_4130;
            prism_rtl::Turn::Finished((d.qk.clone(), refs.clone(), locals.clone()))
        })
    }
}

/// `Start DefWalk, x`: what the function value is when passed to `@Run`.
pub fn start_def_walk(sk: crate::check::shrink::Shrink, d: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)>> {
    Rc::new(DefWalk { sk, d })
}

/// ```prism
/// SpotLocal: fn Def, Spot -> [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]
/// ```
pub fn spot_local(d: &crate::check::env::Def, sp: &crate::check::shrink::walk::Spot) -> Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)> {
    match sp {
        crate::check::shrink::walk::Spot::SpotStmt(s, m) => match &s.kind {
            crate::syntax::StmtKind::SFn(f) => {
                let n = crate::check::env::def_name_text(&f.name);
                match get(m, &Text::from(format!("lfn:{}", &n))) {
                    Some(r) => Array::from(vec![(d.clone(), Text::from(format!("{}.{}", &d.file, &r.param)), n.clone(), m.clone(), Some(f.clone()), None)]),
                    None => Array::new(),
                }
            },
            crate::syntax::StmtKind::SWidget(w) => {
                let n = crate::check::env::sname_key(&w.name);
                match get(m, &Text::from(format!("lfn:{}", &n))) {
                    Some(r) => Array::from(vec![(d.clone(), Text::from(format!("{}.{}", &d.file, &r.param)), n.clone(), m.clone(), None, Some(w.clone()))]),
                    None => Array::new(),
                }
            },
            _ => Array::new(),
        },
        _ => Array::new(),
    }
}

/// ```prism
/// ?LocalTarget: fn Shrink, Def, Site -> ?Text
/// ```
pub fn local_target(sk: &crate::check::shrink::Shrink, d: &crate::check::env::Def, site: &crate::check::shrink::walk::Site) -> Option<Text> {
    match get(&site.rels, &Text::from(format!("lfn:{}", &site.callee))) {
        Some(r) => Some(local_key(&site.callee, &or(&get(&sk.local_of, &d.qk), &d.qk), &Text::from(format!("{}.{}", &d.file, &r.param)))),
        None => None,
    }
}

/// ```prism
/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
/// ```
pub fn clause_base(sk: &crate::check::shrink::Shrink, d: &crate::check::env::Def, c: &crate::syntax::decls::FnClause) -> Map<Text, crate::check::shrink::Rel> {
    match get(&sk.local_base, &d.qk) {
        Some(b) => param_rels_on(&b, &c.params),
        None => param_rels_on(&insert(&or(&get(&sk.seeds, &d.home), &Map::new()), &Text::lit("file:"), &crate::check::shrink::Rel { param: d.file.clone(), strict: false }), &c.params),
    }
}

/// The step machine of `ClauseBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
/// ```
pub struct ClauseBase {
    pub sk: crate::check::shrink::Shrink,
    pub d: crate::check::env::Def,
    pub c: crate::syntax::decls::FnClause,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for ClauseBase {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let sk = &self.sk;
        let d = &self.d;
        let c = &self.c;
        match get(&sk.local_base, &d.qk) {
            Some(b) => prism_rtl::Turn::More(Rc::new(ParamRelsOn { base: b.clone(), ps: c.params.clone() })),
            None => prism_rtl::Turn::More(Rc::new(ParamRelsOn { base: insert(&or(&get(&sk.seeds, &d.home), &Map::new()), &Text::lit("file:"), &crate::check::shrink::Rel { param: d.file.clone(), strict: false }), ps: c.params.clone() })),
        }
    }
}

/// `Start ClauseBase, x`: what the function value is when passed to `@Run`.
pub fn start_clause_base(sk: crate::check::shrink::Shrink, d: crate::check::env::Def, c: crate::syntax::decls::FnClause) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(ClauseBase { sk, d, c })
}

/// ```prism
/// ?ResolveCallee: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_callee(g: &crate::check::env::G, m: &Text, n: &Text) -> Option<Text> {
    if is_op_text(n) {
        resolve_op(g, m, n)
    } else {
        match resolve_name(g, m, n) {
            Some(k) => Some(k),
            None => if crate::syntax::lexer::chars::has_prefix(n, &Text::lit("@")) {
                resolve_name(g, m, &crate::syntax::lexer::chars::after_first(n))
            } else {
                None
            },
        }
    }
}

/// ```prism
/// ?ResolveOp: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_op(g: &crate::check::env::G, m: &Text, op: &Text) -> Option<Text> {
    let (k_opt, _) = crate::check::env::names::resolve_value(g, m, &crate::syntax::SName { sigils: Text::lit(""), path_: Array::from(vec![op.clone()]), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
    k_opt.clone()
}

/// ```prism
/// IsOpText: fn Text -> Bool
/// ```
pub fn is_op_text(n: &Text) -> bool {
    (&len_text(n) > &Nat::from(0u32)) && !crate::syntax::lexer::chars::fold_chars(n, &false, &(Rc::new(move |(p0, p1): (bool, Text)| once_job(move || {
        let seen = p0;
        let ch = p1;
        prism_rtl::Turn::Finished(((seen || crate::syntax::lexer::chars::is_upper(&ch)) || crate::syntax::lexer::chars::is_lower(&ch)) || (&ch == &Text::lit("_")))
    })) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// ```prism
/// ?ResolveName: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_name(g: &crate::check::env::G, m: &Text, n: &Text) -> Option<Text> {
    let marks = crate::check::types::unify::marks_of(n);
    let path_ = split_on(&crate::syntax::lexer::chars::drop_prefix(n, &marks), &Text::lit("."));
    let (k_opt, _) = crate::check::env::names::resolve_value(g, m, &crate::syntax::SName { sigils: marks.clone(), path_: path_.clone(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
    k_opt.clone()
}

/// ```prism
/// NamesInStmt: unbounded fn Stmt -> [Text]
/// ```
pub fn names_in_stmt(s: &crate::syntax::Stmt) -> Array<Text> {
    crate::check::shrink::walk::spots_names(&crate::check::shrink::walk::stmt_spots(s, &Map::new()))
}

/// The step machine of `NamesInStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamesInStmt: unbounded fn Stmt -> [Text]
/// ```
pub struct NamesInStmt {
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<Text>> for NamesInStmt {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s = &self.s;
        let s = s.clone();
        call_then(crate::check::shrink::walk::start_stmt_spots(s.clone(), Map::new()), move |stmt_spots_6728: Array<crate::check::shrink::walk::Spot>| prism_rtl::Turn::More(Rc::new(crate::check::shrink::walk::SpotsNames { spots: stmt_spots_6728 })))
    }
}

/// `Start NamesInStmt, x`: what the function value is when passed to `@Run`.
pub fn start_names_in_stmt(s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(NamesInStmt { s })
}

/// ```prism
/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
/// ```
pub fn sccs(keys_: &Array<Text>, refs: &Array<(Text, Array<Text>)>) -> Array<Array<Text>> {
    let adj = fold(refs, &Map::new(), &(|m: &Map<Text, Array<Text>>, (k, rs): &(Text, Array<Text>)| insert(m, k, rs)));
    let rev = fold(refs, &Map::new(), &(|m: &Map<Text, Array<Text>>, (k, rs): &(Text, Array<Text>)| fold(rs, m, &(|m2: &Map<Text, Array<Text>>, r: &Text| insert(m2, r, &push(&or(&get(m2, r), &Array::new()), k))))));
    let (_, post) = run_to_end(fold_job(keys_.clone(), (Map::new(), Array::new()), {
        let adj = adj.clone();
        Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
            let adj = adj.clone();
            entered(once_job(move || {
                let (seen, out) = p0;
                let k = p1;
                prism_rtl::Turn::More(Rc::new(PostVisit { adj: adj.clone(), seen: seen.clone(), out: out.clone(), k: k.clone() }))
            }))
        }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
    }));
    let (ignore2, comps) = run_to_end(fold_job(crate::check::types::reverse2(&post), (Map::new(), Array::new()), {
        let rev = rev.clone();
        Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Array<Text>>), Text)| {
            let rev = rev.clone();
            entered(once_job(move || {
                let (seen, acc) = p0;
                let k = p1;
                if crate::check::env::has_key(&seen, &k) {
                    prism_rtl::Turn::Finished((seen.clone(), acc.clone()))
                } else {
                    call_then(start_collect(rev.clone(), seen.clone(), Array::new(), k.clone()), move |collect_7570: (Map<Text, bool>, Array<Text>)| {
                        let (seen2, comp) = collect_7570;
                        prism_rtl::Turn::Finished((seen2.clone(), push(&acc, &comp)))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Map<Text, bool>, Array<Array<Text>>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Array<Text>>)>>>
    }));
    filter(&comps, &(|c: &Array<Text>| (&len(c) > &Nat::from(1u32)) || fold(c, &false, &(|self_: &bool, k: &Text| *self_ || crate::check::types::has_text(&or(&get(&adj, k), &Array::new()), k)))))
}

/// The step machine of `Sccs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
/// ```
pub struct Sccs {
    pub keys_: Array<Text>,
    pub refs: Array<(Text, Array<Text>)>,
}

impl prism_rtl::Job<Array<Array<Text>>> for Sccs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Array<Text>>> {
        let keys_ = &self.keys_;
        let refs = &self.refs;
        let adj = fold(refs, &Map::new(), &(|m: &Map<Text, Array<Text>>, (k, rs): &(Text, Array<Text>)| insert(m, k, rs)));
        let rev = fold(refs, &Map::new(), &(|m: &Map<Text, Array<Text>>, (k, rs): &(Text, Array<Text>)| fold(rs, m, &(|m2: &Map<Text, Array<Text>>, r: &Text| insert(m2, r, &push(&or(&get(m2, r), &Array::new()), k))))));
        let keys_ = keys_.clone();
        call_value(fold_job(keys_.clone(), (Map::new(), Array::new()), {
            let adj = adj.clone();
            Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                let adj = adj.clone();
                entered(once_job(move || {
                    let (seen, out) = p0;
                    let k = p1;
                    prism_rtl::Turn::More(Rc::new(PostVisit { adj: adj.clone(), seen: seen.clone(), out: out.clone(), k: k.clone() }))
                }))
            }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
        }), move |fold_7323: (Map<Text, bool>, Array<Text>)| {
            let (_, post) = fold_7323;
            call_value(fold_job(crate::check::types::reverse2(&post), (Map::new(), Array::new()), {
                let rev = rev.clone();
                Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Array<Text>>), Text)| {
                    let rev = rev.clone();
                    entered(once_job(move || {
                        let (seen, acc) = p0;
                        let k = p1;
                        if crate::check::env::has_key(&seen, &k) {
                            prism_rtl::Turn::Finished((seen.clone(), acc.clone()))
                        } else {
                            call_then(start_collect(rev.clone(), seen.clone(), Array::new(), k.clone()), move |collect_7570: (Map<Text, bool>, Array<Text>)| {
                                let (seen2, comp) = collect_7570;
                                prism_rtl::Turn::Finished((seen2.clone(), push(&acc, &comp)))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(((Map<Text, bool>, Array<Array<Text>>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Array<Text>>)>>>
            }), move |fold_7425: (Map<Text, bool>, Array<Array<Text>>)| {
                let (ignore2, comps) = fold_7425;
                prism_rtl::Turn::Finished(filter(&comps, &(|c: &Array<Text>| (&len(c) > &Nat::from(1u32)) || fold(c, &false, &(|self_: &bool, k: &Text| *self_ || crate::check::types::has_text(&or(&get(&adj, k), &Array::new()), k))))))
            })
        })
    }
}

/// `Start Sccs, x`: what the function value is when passed to `@Run`.
pub fn start_sccs(keys_: Array<Text>, refs: Array<(Text, Array<Text>)>) -> Rc<dyn prism_rtl::Job<Array<Array<Text>>>> {
    Rc::new(Sccs { keys_, refs })
}

/// ```prism
/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub fn post_visit(adj: &Map<Text, Array<Text>>, seen: &Map<Text, bool>, out: &Array<Text>, k: &Text) -> (Map<Text, bool>, Array<Text>) {
    if crate::check::env::has_key(seen, k) {
        (seen.clone(), out.clone())
    } else {
        {
            let (seen2, out2) = run_to_end(fold_job(or(&get(adj, k), &Array::new()), (insert(seen, k, &true), out.clone()), {
                let adj = adj.clone();
                Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                    let adj = adj.clone();
                    entered(once_job(move || {
                        let (s, o) = p0;
                        let n = p1;
                        prism_rtl::Turn::More(Rc::new(PostVisit { adj: adj.clone(), seen: s.clone(), out: o.clone(), k: n.clone() }))
                    }))
                }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
            }));
            (seen2.clone(), push(&out2, k))
        }
    }
}

/// The step machine of `PostVisit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub struct PostVisit {
    pub adj: Map<Text, Array<Text>>,
    pub seen: Map<Text, bool>,
    pub out: Array<Text>,
    pub k: Text,
}

impl prism_rtl::Job<(Map<Text, bool>, Array<Text>)> for PostVisit {
    fn cycle(&self) -> prism_rtl::Turn<(Map<Text, bool>, Array<Text>)> {
        let adj = &self.adj;
        let seen = &self.seen;
        let out = &self.out;
        let k = &self.k;
        if crate::check::env::has_key(seen, k) {
            prism_rtl::Turn::Finished((seen.clone(), out.clone()))
        } else {
            {
                let adj = adj.clone();
                let k = k.clone();
                let out = out.clone();
                let seen = seen.clone();
                call_value(fold_job(or(&get(&adj, &k), &Array::new()), (insert(&seen, &k, &true), out.clone()), {
                    let adj = adj.clone();
                    Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                        let adj = adj.clone();
                        entered(once_job(move || {
                            let (s, o) = p0;
                            let n = p1;
                            prism_rtl::Turn::More(Rc::new(PostVisit { adj: adj.clone(), seen: s.clone(), out: o.clone(), k: n.clone() }))
                        }))
                    }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
                }), move |fold_7954: (Map<Text, bool>, Array<Text>)| {
                    let (seen2, out2) = fold_7954;
                    prism_rtl::Turn::Finished((seen2.clone(), push(&out2, &k)))
                })
            }
        }
    }
}

/// `Start PostVisit, x`: what the function value is when passed to `@Run`.
pub fn start_post_visit(adj: Map<Text, Array<Text>>, seen: Map<Text, bool>, out: Array<Text>, k: Text) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>> {
    Rc::new(PostVisit { adj, seen, out, k })
}

/// ```prism
/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub fn collect(rev: &Map<Text, Array<Text>>, seen: &Map<Text, bool>, comp: &Array<Text>, k: &Text) -> (Map<Text, bool>, Array<Text>) {
    if crate::check::env::has_key(seen, k) {
        (seen.clone(), comp.clone())
    } else {
        run_to_end(fold_job(or(&get(rev, k), &Array::new()), (insert(seen, k, &true), push(comp, k)), {
            let rev = rev.clone();
            Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                let rev = rev.clone();
                entered(once_job(move || {
                    let (s, c) = p0;
                    let n = p1;
                    prism_rtl::Turn::More(Rc::new(Collect { rev: rev.clone(), seen: s.clone(), comp: c.clone(), k: n.clone() }))
                }))
            }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
        }))
    }
}

/// The step machine of `Collect`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub struct Collect {
    pub rev: Map<Text, Array<Text>>,
    pub seen: Map<Text, bool>,
    pub comp: Array<Text>,
    pub k: Text,
}

impl prism_rtl::Job<(Map<Text, bool>, Array<Text>)> for Collect {
    fn cycle(&self) -> prism_rtl::Turn<(Map<Text, bool>, Array<Text>)> {
        let rev = &self.rev;
        let seen = &self.seen;
        let comp = &self.comp;
        let k = &self.k;
        if crate::check::env::has_key(seen, k) {
            prism_rtl::Turn::Finished((seen.clone(), comp.clone()))
        } else {
            fold_job(or(&get(rev, k), &Array::new()), (insert(seen, k, &true), push(comp, k)), {
                let rev = rev.clone();
                Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                    let rev = rev.clone();
                    entered(once_job(move || {
                        let (s, c) = p0;
                        let n = p1;
                        prism_rtl::Turn::More(Rc::new(Collect { rev: rev.clone(), seen: s.clone(), comp: c.clone(), k: n.clone() }))
                    }))
                }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
            }).cycle()
        }
    }
}

/// `Start Collect, x`: what the function value is when passed to `@Run`.
pub fn start_collect(rev: Map<Text, Array<Text>>, seen: Map<Text, bool>, comp: Array<Text>, k: Text) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>> {
    Rc::new(Collect { rev, seen, comp, k })
}

/// ```prism
/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
/// ```
pub fn shrink_component(sk: &crate::check::shrink::Shrink, st: &crate::check::types::St, comp: &Array<Text>) -> crate::check::types::St {
    if fold(comp, &true, &(|ok_: &bool, k: &Text| *ok_ && crate::check::shrink::types::is_unbounded_key(&sk.g, &crate::check::shrink::types::sig_key_of(sk, &or(&get(&sk.local_of, k), k))))) {
        st.clone()
    } else {
        {
            let graphs = run_to_end(fold_job(sk.fns.clone(), Array::new(), {
                let comp = comp.clone();
                let sk = sk.clone();
                Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, crate::check::env::Def)| {
                    let comp = comp.clone();
                    let sk = sk.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let d = p1;
                        if crate::check::types::has_text(&comp, &d.qk) {
                            call_then(start_call_graphs(sk.clone(), d.clone(), comp.clone()), move |call_graphs_8869: Array<crate::check::shrink::Sc>| prism_rtl::Turn::Finished(append(&acc, &call_graphs_8869)))
                        } else {
                            prism_rtl::Turn::Finished(acc.clone())
                        }
                    }))
                }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
            }));
            let closure = crate::check::shrink::summaries::closure(&graphs);
            let bad = filter(&closure, &(|sc: &crate::check::shrink::Sc| ((&sc.caller == &sc.callee) && (&crate::check::shrink::summaries::compose(sc, sc).edges == &sc.edges)) && !fold(&sc.edges, &false, &(|seen: &bool, (a, b, s): &(Nat, Nat, bool)| *seen || ((a == b) && *s)))));
            match index(&bad, &Nat::from(0u32)) {
                Some(sc) => {
                    let s2 = {
                        let mut this: crate::check::types::St = st.clone();
                        this.file = sc.file.clone();
                        this
                    };
                    let what = if &sc.arg == &Text::lit("") {
                        Text::lit("")
                    } else {
                        Text::from(format!(" on `{}`", &sc.arg))
                    };
                    let st3 = crate::check::types::recording::err_fix(&s2, &Text::lit("may-not-end"), &sc.span, &Text::from(format!("`{}` calls {}{}, not smaller than what it was given", &crate::check::shrink::types::shown_key(&sc.caller), &(if &sc.caller == &sc.callee {
                        Text::lit("itself")
                    } else {
                        Text::from(format!("`{}`", &crate::check::shrink::types::shown_key(&sc.callee)))
                    }), &what)), &Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle\'s functions `unbounded fn`"));
                    {
                        let mut this: crate::check::types::St = st3.clone();
                        this.file = st.file.clone();
                        this
                    }
                },
                None => st.clone(),
            }
        }
    }
}

/// The step machine of `ShrinkComponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
/// ```
pub struct ShrinkComponent {
    pub sk: crate::check::shrink::Shrink,
    pub st: crate::check::types::St,
    pub comp: Array<Text>,
}

impl prism_rtl::Job<crate::check::types::St> for ShrinkComponent {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let sk = &self.sk;
        let st = &self.st;
        let comp = &self.comp;
        if fold(comp, &true, &(|ok_: &bool, k: &Text| *ok_ && crate::check::shrink::types::is_unbounded_key(&sk.g, &crate::check::shrink::types::sig_key_of(sk, &or(&get(&sk.local_of, k), k))))) {
            prism_rtl::Turn::Finished(st.clone())
        } else {
            {
                let comp = comp.clone();
                let sk = sk.clone();
                let st = st.clone();
                call_value(fold_job(sk.fns.clone(), Array::new(), {
                    let comp = comp.clone();
                    let sk = sk.clone();
                    Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, crate::check::env::Def)| {
                        let comp = comp.clone();
                        let sk = sk.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let d = p1;
                            if crate::check::types::has_text(&comp, &d.qk) {
                                call_then(start_call_graphs(sk.clone(), d.clone(), comp.clone()), move |call_graphs_8869: Array<crate::check::shrink::Sc>| prism_rtl::Turn::Finished(append(&acc, &call_graphs_8869)))
                            } else {
                                prism_rtl::Turn::Finished(acc.clone())
                            }
                        }))
                    }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
                }), move |fold_8804: Array<crate::check::shrink::Sc>| {
                    let graphs = fold_8804;
                    call_then(crate::check::shrink::summaries::start_closure(graphs.clone()), move |closure_8925: Array<crate::check::shrink::Sc>| {
                        let closure = closure_8925;
                        let bad = filter(&closure, &(|sc: &crate::check::shrink::Sc| ((&sc.caller == &sc.callee) && (&crate::check::shrink::summaries::compose(sc, sc).edges == &sc.edges)) && !fold(&sc.edges, &false, &(|seen: &bool, (a, b, s): &(Nat, Nat, bool)| *seen || ((a == b) && *s)))));
                        match index(&bad, &Nat::from(0u32)) {
                            Some(sc) => {
                                let s2 = {
                                    let mut this: crate::check::types::St = st.clone();
                                    this.file = sc.file.clone();
                                    this
                                };
                                let what = if &sc.arg == &Text::lit("") {
                                    Text::lit("")
                                } else {
                                    Text::from(format!(" on `{}`", &sc.arg))
                                };
                                let st3 = crate::check::types::recording::err_fix(&s2, &Text::lit("may-not-end"), &sc.span, &Text::from(format!("`{}` calls {}{}, not smaller than what it was given", &crate::check::shrink::types::shown_key(&sc.caller), &(if &sc.caller == &sc.callee {
                                    Text::lit("itself")
                                } else {
                                    Text::from(format!("`{}`", &crate::check::shrink::types::shown_key(&sc.callee)))
                                }), &what)), &Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle\'s functions `unbounded fn`"));
                                prism_rtl::Turn::Finished({
                                    let mut this: crate::check::types::St = st3.clone();
                                    this.file = st.file.clone();
                                    this
                                })
                            },
                            None => prism_rtl::Turn::Finished(st.clone()),
                        }
                    })
                })
            }
        }
    }
}

/// `Start ShrinkComponent, x`: what the function value is when passed to `@Run`.
pub fn start_shrink_component(sk: crate::check::shrink::Shrink, st: crate::check::types::St, comp: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ShrinkComponent { sk, st, comp })
}

/// ```prism
/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
/// ```
pub fn call_graphs(sk: &crate::check::shrink::Shrink, d: &crate::check::env::Def, comp: &Array<Text>) -> Array<crate::check::shrink::Sc> {
    run_to_end(fold_job(crate::check::shrink::types::def_clauses(d), Array::new(), {
        let sk = sk.clone();
        let d = d.clone();
        let comp = comp.clone();
        Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause)| {
            let sk = sk.clone();
            let d = d.clone();
            let comp = comp.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                call_then(start_clause_graphs(sk.clone(), d.clone(), c.clone(), comp.clone()), move |clause_graphs_9987: Array<crate::check::shrink::Sc>| prism_rtl::Turn::Finished(append(&acc, &clause_graphs_9987)))
            }))
        }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
    }))
}

/// The step machine of `CallGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
/// ```
pub struct CallGraphs {
    pub sk: crate::check::shrink::Shrink,
    pub d: crate::check::env::Def,
    pub comp: Array<Text>,
}

impl prism_rtl::Job<Array<crate::check::shrink::Sc>> for CallGraphs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::shrink::Sc>> {
        let sk = &self.sk;
        let d = &self.d;
        let comp = &self.comp;
        fold_job(crate::check::shrink::types::def_clauses(d), Array::new(), {
            let sk = sk.clone();
            let d = d.clone();
            let comp = comp.clone();
            Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause)| {
                let sk = sk.clone();
                let d = d.clone();
                let comp = comp.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let c = p1;
                    call_then(start_clause_graphs(sk.clone(), d.clone(), c.clone(), comp.clone()), move |clause_graphs_9987: Array<crate::check::shrink::Sc>| prism_rtl::Turn::Finished(append(&acc, &clause_graphs_9987)))
                }))
            }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
        }).cycle()
    }
}

/// `Start CallGraphs, x`: what the function value is when passed to `@Run`.
pub fn start_call_graphs(sk: crate::check::shrink::Shrink, d: crate::check::env::Def, comp: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>> {
    Rc::new(CallGraphs { sk, d, comp })
}

/// ```prism
/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
/// ```
pub fn clause_graphs(sk: &crate::check::shrink::Shrink, d: &crate::check::env::Def, c: &crate::syntax::decls::FnClause, comp: &Array<Text>) -> Array<crate::check::shrink::Sc> {
    let base = clause_base(sk, d, c);
    let rels = crate::check::shrink::summaries::summary_seeds(sk, d, &crate::check::shrink::walk::body_spots(&c.body, &base), &base);
    run_to_end(fold_job(crate::check::shrink::walk::body_sites(&c.body, &rels), Array::new(), {
        let sk = sk.clone();
        let d = d.clone();
        let comp = comp.clone();
        Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site)| {
            let sk = sk.clone();
            let d = d.clone();
            let comp = comp.clone();
            entered(once_job(move || {
                let acc = p0;
                let site = p1;
                match local_target(&sk, &d, &site) {
                    Some(t) => if crate::check::types::has_text(&comp, &t) {
                        call_then(start_site_graph(sk.clone(), d.clone(), site.clone(), t.clone()), move |site_graph_10345: crate::check::shrink::Sc| prism_rtl::Turn::Finished(push(&acc, &site_graph_10345)))
                    } else {
                        prism_rtl::Turn::Finished(acc.clone())
                    },
                    None => if crate::check::shrink::relations::is_local(&site.rels, &site.callee) || crate::check::env::has_key(&sk.local_of, &d.qk) {
                        prism_rtl::Turn::Finished(acc.clone())
                    } else {
                        match resolve_callee(&sk.g, &d.home, &site.callee) {
                            Some(k) => call_then(crate::check::shrink::types::start_dispatch_targets(sk.clone(), d.clone(), site.clone(), k.clone()), move |dispatch_targets_10567: Array<Text>| fold_job(dispatch_targets_10567, acc.clone(), {
                                let comp = comp.clone();
                                let sk = sk.clone();
                                let d = d.clone();
                                let site = site.clone();
                                Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, Text)| {
                                    let comp = comp.clone();
                                    let sk = sk.clone();
                                    let d = d.clone();
                                    let site = site.clone();
                                    entered(once_job(move || {
                                        let acc2 = p0;
                                        let t = p1;
                                        if crate::check::types::has_text(&comp, &t) {
                                            call_then(start_site_graph(sk.clone(), d.clone(), site.clone(), t.clone()), move |site_graph_10648: crate::check::shrink::Sc| prism_rtl::Turn::Finished(push(&acc2, &site_graph_10648)))
                                        } else {
                                            prism_rtl::Turn::Finished(acc2.clone())
                                        }
                                    }))
                                }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, Text)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
                            }).cycle()),
                            None => prism_rtl::Turn::Finished(acc.clone()),
                        }
                    },
                }
            }))
        }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
    }))
}

/// The step machine of `ClauseGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
/// ```
pub struct ClauseGraphs {
    pub sk: crate::check::shrink::Shrink,
    pub d: crate::check::env::Def,
    pub c: crate::syntax::decls::FnClause,
    pub comp: Array<Text>,
}

impl prism_rtl::Job<Array<crate::check::shrink::Sc>> for ClauseGraphs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::shrink::Sc>> {
        let sk = &self.sk;
        let d = &self.d;
        let c = &self.c;
        let comp = &self.comp;
        let c = c.clone();
        let comp = comp.clone();
        let d = d.clone();
        let sk = sk.clone();
        call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_10129: Map<Text, crate::check::shrink::Rel>| {
            let base = clause_base_10129;
            call_then(crate::check::shrink::walk::start_body_spots(c.body.clone(), base.clone()), move |body_spots_10185: Array<crate::check::shrink::walk::Spot>| call_then(crate::check::shrink::summaries::start_summary_seeds(sk.clone(), d.clone(), body_spots_10185, base.clone()), move |summary_seeds_10164: Map<Text, crate::check::shrink::Rel>| {
                let rels = summary_seeds_10164;
                call_then(crate::check::shrink::walk::start_body_sites(c.body.clone(), rels.clone()), move |body_sites_10225: Array<crate::check::shrink::walk::Site>| fold_job(body_sites_10225, Array::new(), {
                    let sk = sk.clone();
                    let d = d.clone();
                    let comp = comp.clone();
                    Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site)| {
                        let sk = sk.clone();
                        let d = d.clone();
                        let comp = comp.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let site = p1;
                            match local_target(&sk, &d, &site) {
                                Some(t) => if crate::check::types::has_text(&comp, &t) {
                                    call_then(start_site_graph(sk.clone(), d.clone(), site.clone(), t.clone()), move |site_graph_10345: crate::check::shrink::Sc| prism_rtl::Turn::Finished(push(&acc, &site_graph_10345)))
                                } else {
                                    prism_rtl::Turn::Finished(acc.clone())
                                },
                                None => if crate::check::shrink::relations::is_local(&site.rels, &site.callee) || crate::check::env::has_key(&sk.local_of, &d.qk) {
                                    prism_rtl::Turn::Finished(acc.clone())
                                } else {
                                    match resolve_callee(&sk.g, &d.home, &site.callee) {
                                        Some(k) => call_then(crate::check::shrink::types::start_dispatch_targets(sk.clone(), d.clone(), site.clone(), k.clone()), move |dispatch_targets_10567: Array<Text>| fold_job(dispatch_targets_10567, acc.clone(), {
                                            let comp = comp.clone();
                                            let sk = sk.clone();
                                            let d = d.clone();
                                            let site = site.clone();
                                            Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, Text)| {
                                                let comp = comp.clone();
                                                let sk = sk.clone();
                                                let d = d.clone();
                                                let site = site.clone();
                                                entered(once_job(move || {
                                                    let acc2 = p0;
                                                    let t = p1;
                                                    if crate::check::types::has_text(&comp, &t) {
                                                        call_then(start_site_graph(sk.clone(), d.clone(), site.clone(), t.clone()), move |site_graph_10648: crate::check::shrink::Sc| prism_rtl::Turn::Finished(push(&acc2, &site_graph_10648)))
                                                    } else {
                                                        prism_rtl::Turn::Finished(acc2.clone())
                                                    }
                                                }))
                                            }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, Text)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
                                        }).cycle()),
                                        None => prism_rtl::Turn::Finished(acc.clone()),
                                    }
                                },
                            }
                        }))
                    }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
                }).cycle())
            }))
        })
    }
}

/// `Start ClauseGraphs, x`: what the function value is when passed to `@Run`.
pub fn start_clause_graphs(sk: crate::check::shrink::Shrink, d: crate::check::env::Def, c: crate::syntax::decls::FnClause, comp: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>> {
    Rc::new(ClauseGraphs { sk, d, c, comp })
}

/// ```prism
/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
/// ```
pub fn site_graph(sk: &crate::check::shrink::Shrink, d: &crate::check::env::Def, site: &crate::check::shrink::walk::Site, k: &Text) -> crate::check::shrink::Sc {
    let edges = run_to_end(fold_job(arg_slots(sk, &site.args, k), Array::new(), {
        let site = site.clone();
        Rc::new(move |(p0, p1): (Array<(Nat, Nat, bool)>, (Nat, crate::syntax::Arg))| {
            let site = site.clone();
            entered(once_job(move || {
                let es = p0;
                let (j, a) = p1;
                call_then(crate::check::shrink::walk::start_rel_of(site.rels.clone(), a.value.clone()), move |rel_of_10986: Option<crate::check::shrink::Rel>| match rel_of_10986 {
                    Some(r) => prism_rtl::Turn::Finished(push(&es, &(r.param.clone(), j.clone(), r.strict))),
                    None => prism_rtl::Turn::Finished(es.clone()),
                })
            }))
        }) as Rc<dyn Fn((Array<(Nat, Nat, bool)>, (Nat, crate::syntax::Arg))) -> Rc<dyn prism_rtl::Job<Array<(Nat, Nat, bool)>>>>
    }));
    let arg_text = match index(&site.args, &Nat::from(0u32)) {
        Some(a) => expr_name(&a.value),
        None => Text::lit(""),
    };
    crate::check::shrink::Sc { caller: d.qk.clone(), callee: k.clone(), edges: edges.clone(), span: site.span.clone(), file: d.file.clone(), arg: arg_text.clone() }
}

/// The step machine of `SiteGraph`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
/// ```
pub struct SiteGraph {
    pub sk: crate::check::shrink::Shrink,
    pub d: crate::check::env::Def,
    pub site: crate::check::shrink::walk::Site,
    pub k: Text,
}

impl prism_rtl::Job<crate::check::shrink::Sc> for SiteGraph {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::shrink::Sc> {
        let sk = &self.sk;
        let d = &self.d;
        let site = &self.site;
        let k = &self.k;
        let d = d.clone();
        let k = k.clone();
        let site = site.clone();
        let sk = sk.clone();
        call_then(start_arg_slots(sk.clone(), site.args.clone(), k.clone()), move |arg_slots_10930: Array<(Nat, crate::syntax::Arg)>| call_value(fold_job(arg_slots_10930, Array::new(), {
            let site = site.clone();
            Rc::new(move |(p0, p1): (Array<(Nat, Nat, bool)>, (Nat, crate::syntax::Arg))| {
                let site = site.clone();
                entered(once_job(move || {
                    let es = p0;
                    let (j, a) = p1;
                    call_then(crate::check::shrink::walk::start_rel_of(site.rels.clone(), a.value.clone()), move |rel_of_10986: Option<crate::check::shrink::Rel>| match rel_of_10986 {
                        Some(r) => prism_rtl::Turn::Finished(push(&es, &(r.param.clone(), j.clone(), r.strict))),
                        None => prism_rtl::Turn::Finished(es.clone()),
                    })
                }))
            }) as Rc<dyn Fn((Array<(Nat, Nat, bool)>, (Nat, crate::syntax::Arg))) -> Rc<dyn prism_rtl::Job<Array<(Nat, Nat, bool)>>>>
        }), move |fold_10924: Array<(Nat, Nat, bool)>| {
            let edges = fold_10924;
            let arg_text = match index(&site.args, &Nat::from(0u32)) {
                Some(a) => expr_name(&a.value),
                None => Text::lit(""),
            };
            prism_rtl::Turn::Finished(crate::check::shrink::Sc { caller: d.qk.clone(), callee: k.clone(), edges: edges.clone(), span: site.span.clone(), file: d.file.clone(), arg: arg_text.clone() })
        }))
    }
}

/// `Start SiteGraph, x`: what the function value is when passed to `@Run`.
pub fn start_site_graph(sk: crate::check::shrink::Shrink, d: crate::check::env::Def, site: crate::check::shrink::walk::Site, k: Text) -> Rc<dyn prism_rtl::Job<crate::check::shrink::Sc>> {
    Rc::new(SiteGraph { sk, d, site, k })
}

/// ```prism
/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
/// ```
pub fn arg_slots(sk: &crate::check::shrink::Shrink, args: &Array<crate::syntax::Arg>, k: &Text) -> Array<(Nat, crate::syntax::Arg)> {
    let (_, out) = run_to_end(fold_job(args.clone(), (Nat::from(0u32), Array::new()), {
        let sk = sk.clone();
        let k = k.clone();
        Rc::new(move |(p0, p1): ((Nat, Array<(Nat, crate::syntax::Arg)>), crate::syntax::Arg)| {
            let sk = sk.clone();
            let k = k.clone();
            entered(once_job(move || {
                let (pos, acc) = p0;
                let a = p1;
                match &a.name {
                    None => prism_rtl::Turn::Finished((&pos + &Nat::from(1u32), push(&acc, &(pos.clone(), a.clone())))),
                    Some(id) => {
                        let id = id.clone();
                        call_then(start_param_named(sk.clone(), k.clone(), id.name.clone()), move |param_named_11800: Option<Nat>| match param_named_11800 {
                            Some(j) => prism_rtl::Turn::Finished((pos.clone(), push(&acc, &(j.clone(), a.clone())))),
                            None => prism_rtl::Turn::Finished((pos.clone(), acc.clone())),
                        })
                    },
                }
            }))
        }) as Rc<dyn Fn(((Nat, Array<(Nat, crate::syntax::Arg)>), crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<(Nat, Array<(Nat, crate::syntax::Arg)>)>>>
    }));
    out.clone()
}

/// The step machine of `ArgSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
/// ```
pub struct ArgSlots {
    pub sk: crate::check::shrink::Shrink,
    pub args: Array<crate::syntax::Arg>,
    pub k: Text,
}

impl prism_rtl::Job<Array<(Nat, crate::syntax::Arg)>> for ArgSlots {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Nat, crate::syntax::Arg)>> {
        let sk = &self.sk;
        let args = &self.args;
        let k = &self.k;
        let args = args.clone();
        let k = k.clone();
        let sk = sk.clone();
        call_value(fold_job(args.clone(), (Nat::from(0u32), Array::new()), {
            let sk = sk.clone();
            let k = k.clone();
            Rc::new(move |(p0, p1): ((Nat, Array<(Nat, crate::syntax::Arg)>), crate::syntax::Arg)| {
                let sk = sk.clone();
                let k = k.clone();
                entered(once_job(move || {
                    let (pos, acc) = p0;
                    let a = p1;
                    match &a.name {
                        None => prism_rtl::Turn::Finished((&pos + &Nat::from(1u32), push(&acc, &(pos.clone(), a.clone())))),
                        Some(id) => {
                            let id = id.clone();
                            call_then(start_param_named(sk.clone(), k.clone(), id.name.clone()), move |param_named_11800: Option<Nat>| match param_named_11800 {
                                Some(j) => prism_rtl::Turn::Finished((pos.clone(), push(&acc, &(j.clone(), a.clone())))),
                                None => prism_rtl::Turn::Finished((pos.clone(), acc.clone())),
                            })
                        },
                    }
                }))
            }) as Rc<dyn Fn(((Nat, Array<(Nat, crate::syntax::Arg)>), crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<(Nat, Array<(Nat, crate::syntax::Arg)>)>>>
        }), move |fold_11673: (Nat, Array<(Nat, crate::syntax::Arg)>)| {
            let (_, out) = fold_11673;
            prism_rtl::Turn::Finished(out.clone())
        })
    }
}

/// `Start ArgSlots, x`: what the function value is when passed to `@Run`.
pub fn start_arg_slots(sk: crate::check::shrink::Shrink, args: Array<crate::syntax::Arg>, k: Text) -> Rc<dyn prism_rtl::Job<Array<(Nat, crate::syntax::Arg)>>> {
    Rc::new(ArgSlots { sk, args, k })
}

/// ```prism
/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
/// ```
pub fn param_named(sk: &crate::check::shrink::Shrink, k: &Text, name: &Text) -> Option<Nat> {
    let clauses = crate::check::shrink::types::def_clauses(&or(&get(&sk.by_key, k), &crate::check::env::decls::dummy_def()));
    if name == &Text::lit("#body") {
        match index(&clauses, &Nat::from(0u32)) {
            Some(c) => if &len(&c.params) > &Nat::from(0u32) {
                Some(crate::syntax::lexer::chars::dec(&len(&c.params)))
            } else {
                None
            },
            None => None,
        }
    } else {
        param_named_in(&clauses, name)
    }
}

/// The step machine of `ParamNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
/// ```
pub struct ParamNamed {
    pub sk: crate::check::shrink::Shrink,
    pub k: Text,
    pub name: Text,
}

impl prism_rtl::Job<Option<Nat>> for ParamNamed {
    fn cycle(&self) -> prism_rtl::Turn<Option<Nat>> {
        let sk = &self.sk;
        let k = &self.k;
        let name = &self.name;
        let clauses = crate::check::shrink::types::def_clauses(&or(&get(&sk.by_key, k), &crate::check::env::decls::dummy_def()));
        if name == &Text::lit("#body") {
            match index(&clauses, &Nat::from(0u32)) {
                Some(c) => if &len(&c.params) > &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(Some(crate::syntax::lexer::chars::dec(&len(&c.params))))
                } else {
                    prism_rtl::Turn::Finished(None)
                },
                None => prism_rtl::Turn::Finished(None),
            }
        } else {
            prism_rtl::Turn::Finished(param_named_in(&clauses, name))
        }
    }
}

/// `Start ParamNamed, x`: what the function value is when passed to `@Run`.
pub fn start_param_named(sk: crate::check::shrink::Shrink, k: Text, name: Text) -> Rc<dyn prism_rtl::Job<Option<Nat>>> {
    Rc::new(ParamNamed { sk, k, name })
}

/// ```prism
/// ?ParamNamedIn: unbounded fn [FnClause], Text -> ?Nat
/// ```
pub fn param_named_in(clauses: &Array<crate::syntax::decls::FnClause>, name: &Text) -> Option<Nat> {
    let found = run_to_end(fold_job(clauses.clone(), Array::new(), {
        let name = name.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::syntax::decls::FnClause)| {
            let name = name.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                fold_job(crate::check::errors::range0(&len(&c.params)), acc.clone(), {
                    let c = c.clone();
                    let name = name.clone();
                    Rc::new(move |(p0, p1): (Array<Nat>, Nat)| {
                        let c = c.clone();
                        let name = name.clone();
                        entered(once_job(move || {
                            let a2 = p0;
                            let i = p1;
                            match index(&c.params, &i) {
                                Some(p_) => if (&param_name_of(&p_) == &name) && !crate::check::types::has_nat(&a2, &i) {
                                    prism_rtl::Turn::Finished(push(&a2, &i))
                                } else {
                                    prism_rtl::Turn::Finished(a2.clone())
                                },
                                None => prism_rtl::Turn::Finished(a2.clone()),
                            }
                        }))
                    }) as Rc<dyn Fn((Array<Nat>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    if &len(&found) == &Nat::from(1u32) { index(&found, &Nat::from(0u32)) } else { None }
}

/// ```prism
/// ParamNameOf: unbounded fn Pattern -> Text
/// ```
pub fn param_name_of(p_: &crate::syntax::Pattern_) -> Text {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => {
            let text_ = crate::check::env::sname_key(n);
            crate::syntax::lexer::chars::drop_prefix(&text_, &crate::check::types::unify::marks_of(&text_))
        },
        crate::syntax::PatternKind::PGroup(q) => param_name_of(&**q),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ExprName: fn Expr -> Text
/// ```
pub fn expr_name(e: &crate::syntax::Expr) -> Text {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => crate::check::env::sname_key(n),
        crate::syntax::ExprKind::EGroup(x) => expr_name(&**x),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
/// ```
pub fn param_rels_on(base: &Map<Text, crate::check::shrink::Rel>, ps: &Array<crate::syntax::Pattern_>) -> Map<Text, crate::check::shrink::Rel> {
    run_to_end(fold_job(crate::check::errors::range0(&len(ps)), crate::check::shrink::relations::hide(base, &crate::check::shrink::walk::patterns_names(ps)), {
        let ps = ps.clone();
        Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Nat)| {
            let ps = ps.clone();
            entered(once_job(move || {
                let m = p0;
                let i = p1;
                match index(&ps, &i) {
                    Some(p_) => match &*p_.kind {
                        crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::Finished(insert(&m, &crate::check::env::sname_key(n), &crate::check::shrink::Rel { param: i.clone(), strict: false })),
                        _ => call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_13573: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_13573, &m, &(|m2: &Map<Text, crate::check::shrink::Rel>, n: &Text| insert(m2, n, &crate::check::shrink::Rel { param: i.clone(), strict: true }))))),
                    },
                    None => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
    }))
}

/// The step machine of `ParamRelsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
/// ```
pub struct ParamRelsOn {
    pub base: Map<Text, crate::check::shrink::Rel>,
    pub ps: Array<crate::syntax::Pattern_>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for ParamRelsOn {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let base = &self.base;
        let ps = &self.ps;
        let base = base.clone();
        let ps = ps.clone();
        call_then(crate::check::shrink::walk::start_patterns_names(ps.clone()), move |patterns_names_13416: Array<Text>| fold_job(crate::check::errors::range0(&len(&ps)), crate::check::shrink::relations::hide(&base, &patterns_names_13416), {
            let ps = ps.clone();
            Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Nat)| {
                let ps = ps.clone();
                entered(once_job(move || {
                    let m = p0;
                    let i = p1;
                    match index(&ps, &i) {
                        Some(p_) => match &*p_.kind {
                            crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::Finished(insert(&m, &crate::check::env::sname_key(n), &crate::check::shrink::Rel { param: i.clone(), strict: false })),
                            _ => call_then(crate::check::env::names::start_pattern_names(p_.clone()), move |pattern_names_13573: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_13573, &m, &(|m2: &Map<Text, crate::check::shrink::Rel>, n: &Text| insert(m2, n, &crate::check::shrink::Rel { param: i.clone(), strict: true }))))),
                        },
                        None => prism_rtl::Turn::Finished(m.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
        }).cycle())
    }
}

/// `Start ParamRelsOn, x`: what the function value is when passed to `@Run`.
pub fn start_param_rels_on(base: Map<Text, crate::check::shrink::Rel>, ps: Array<crate::syntax::Pattern_>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(ParamRelsOn { base, ps })
}
