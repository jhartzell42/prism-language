//! The module `Check.Shrink.Locals`, from `target/bootstrap/src/prismc/check/shrink/locals.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
/// ```
pub fn with_locals(sk_p0: &crate::check::shrink::Shrink, found_p1: &Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>) -> crate::check::shrink::Shrink {
    let (bases_pm, owners_pn, clauses_po, wdecls_pp) = fold(found_p1, &(Map::new(), Map::new(), Map::new(), Map::new()), &(|(bs_p5, os_p6, cs_p7, ws_p8): &(Map<Text, Map<Text, crate::check::shrink::Rel>>, Map<Text, Text>, Map<Text, Array<crate::syntax::decls::FnClause>>, Map<Text, (crate::check::env::Def, crate::syntax::decls::WidgetDecl)>), (d_p9, gk_pa, n_pb, m_pc, c_od, w_oe): &(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)| {
        let qk_pf = local_key(n_pb, &d_p9.qk, gk_pa);
        let bs2_pg = if crate::check::env::has_key(bs_p5, &qk_pf) {
            bs_p5.clone()
        } else {
            insert(bs_p5, &qk_pf, &crate::check::shrink::summaries::marks(m_pc))
        };
        let os2_ph = insert(os_p6, &qk_pf, &d_p9.qk);
        let cs2_pi = match c_od {
            Some(c_pk) => insert(cs_p7, &qk_pf, &push(&or(&get(cs_p7, &qk_pf), &Array::new()), c_pk)),
            None => cs_p7.clone(),
        };
        let ws2_pj = match w_oe {
            Some(w_pl) => insert(ws_p8, &qk_pf, &(d_p9.clone(), w_pl.clone())),
            None => ws_p8.clone(),
        };
        (bs2_pg.clone(), os2_ph.clone(), cs2_pi.clone(), ws2_pj.clone())
    }));
    let fn_defs_p2 = fold(&keys(&clauses_po), &Array::new(), &(|acc_pq: &Array<crate::check::env::Def>, qk_pr: &Text| match (get(&owners_pn, qk_pr), get(&clauses_po, qk_pr)) {
        (Some(oq_ps), Some(cl_pt)) => match get(&sk_p0.by_key, &oq_ps) {
            Some(d_pu) => push(acc_pq, &crate::check::env::Def { qk: qk_pr.clone(), name: or(&index(&split_on(qk_pr, &Text::lit(" #")), &Nat::from(0u32)), qk_pr), home: d_pu.home.clone(), file: d_pu.file.clone(), span: d_pu.span.clone(), body: crate::check::env::DefBody::DbFn(cl_pt) }),
            None => acc_pq.clone(),
        },
        _ => acc_pq.clone(),
    }));
    let w_defs_p3 = fold(&keys(&wdecls_pp), &Array::new(), &(|acc_pv: &Array<crate::check::env::Def>, qk_p10: &Text| match get(&wdecls_pp, qk_p10) {
        Some((d_p11, w_p12)) => push(acc_pv, &crate::check::env::Def { qk: qk_p10.clone(), name: crate::check::env::sname_key(&w_p12.name), home: d_p11.home.clone(), file: d_p11.file.clone(), span: w_p12.span.clone(), body: crate::check::env::DefBody::DbWidget(w_p12.clone()) }),
        None => acc_pv.clone(),
    }));
    let locals_p4 = append(&fn_defs_p2, &w_defs_p3);
    let mut this: crate::check::shrink::Shrink = sk_p0.clone();
    this.fns = append(&this.fns, &locals_p4);
    this.by_key = fold(&locals_p4, &this.by_key, &(|m_p13: &Map<Text, crate::check::env::Def>, d_p14: &crate::check::env::Def| insert(m_p13, &d_p14.qk, d_p14)));
    this.local_of = owners_pn.clone();
    this.local_base = bases_pm.clone();
    this
}

/// The step machine of `WithLocals`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
/// ```
pub struct WithLocals {
    pub sk_p0: crate::check::shrink::Shrink,
    pub found_p1: Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>,
}

impl prism_rtl::Job<crate::check::shrink::Shrink> for WithLocals {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::shrink::Shrink> {
        let sk_p0 = &self.sk_p0;
        let found_p1 = &self.found_p1;
        let (bases_pm, owners_pn, clauses_po, wdecls_pp) = fold(found_p1, &(Map::new(), Map::new(), Map::new(), Map::new()), &(|(bs_p5, os_p6, cs_p7, ws_p8): &(Map<Text, Map<Text, crate::check::shrink::Rel>>, Map<Text, Text>, Map<Text, Array<crate::syntax::decls::FnClause>>, Map<Text, (crate::check::env::Def, crate::syntax::decls::WidgetDecl)>), (d_p9, gk_pa, n_pb, m_pc, c_od, w_oe): &(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)| {
            let qk_pf = local_key(n_pb, &d_p9.qk, gk_pa);
            let bs2_pg = if crate::check::env::has_key(bs_p5, &qk_pf) {
                bs_p5.clone()
            } else {
                insert(bs_p5, &qk_pf, &crate::check::shrink::summaries::marks(m_pc))
            };
            let os2_ph = insert(os_p6, &qk_pf, &d_p9.qk);
            let cs2_pi = match c_od {
                Some(c_pk) => insert(cs_p7, &qk_pf, &push(&or(&get(cs_p7, &qk_pf), &Array::new()), c_pk)),
                None => cs_p7.clone(),
            };
            let ws2_pj = match w_oe {
                Some(w_pl) => insert(ws_p8, &qk_pf, &(d_p9.clone(), w_pl.clone())),
                None => ws_p8.clone(),
            };
            (bs2_pg.clone(), os2_ph.clone(), cs2_pi.clone(), ws2_pj.clone())
        }));
        let fn_defs_p2 = fold(&keys(&clauses_po), &Array::new(), &(|acc_pq: &Array<crate::check::env::Def>, qk_pr: &Text| match (get(&owners_pn, qk_pr), get(&clauses_po, qk_pr)) {
            (Some(oq_ps), Some(cl_pt)) => match get(&sk_p0.by_key, &oq_ps) {
                Some(d_pu) => push(acc_pq, &crate::check::env::Def { qk: qk_pr.clone(), name: or(&index(&split_on(qk_pr, &Text::lit(" #")), &Nat::from(0u32)), qk_pr), home: d_pu.home.clone(), file: d_pu.file.clone(), span: d_pu.span.clone(), body: crate::check::env::DefBody::DbFn(cl_pt) }),
                None => acc_pq.clone(),
            },
            _ => acc_pq.clone(),
        }));
        let w_defs_p3 = fold(&keys(&wdecls_pp), &Array::new(), &(|acc_pv: &Array<crate::check::env::Def>, qk_p10: &Text| match get(&wdecls_pp, qk_p10) {
            Some((d_p11, w_p12)) => push(acc_pv, &crate::check::env::Def { qk: qk_p10.clone(), name: crate::check::env::sname_key(&w_p12.name), home: d_p11.home.clone(), file: d_p11.file.clone(), span: w_p12.span.clone(), body: crate::check::env::DefBody::DbWidget(w_p12.clone()) }),
            None => acc_pv.clone(),
        }));
        let locals_p4 = append(&fn_defs_p2, &w_defs_p3);
        prism_rtl::Turn::Finished({
            let mut this: crate::check::shrink::Shrink = sk_p0.clone();
            this.fns = append(&this.fns, &locals_p4);
            this.by_key = fold(&locals_p4, &this.by_key, &(|m_p13: &Map<Text, crate::check::env::Def>, d_p14: &crate::check::env::Def| insert(m_p13, &d_p14.qk, d_p14)));
            this.local_of = owners_pn.clone();
            this.local_base = bases_pm.clone();
            this
        })
    }
}

/// `Start WithLocals, x`: what the function value is when passed to `@Run`.
pub fn start_with_locals(sk_p0: crate::check::shrink::Shrink, found_p1: Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>) -> Rc<dyn prism_rtl::Job<crate::check::shrink::Shrink>> {
    Rc::new(WithLocals { sk_p0, found_p1 })
}

/// ```prism
/// LocalKey: fn Text, Text, Text -> Text
/// ```
pub fn local_key(n_p0: &Text, owner_p1: &Text, gk_p2: &Text) -> Text {
    Text::from(format!("{} #local {} {}", n_p0, owner_p1, gk_p2))
}

/// ```prism
/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
/// ```
pub fn def_walk(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def) -> (Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>) {
    let (refs_p8, locals_p9) = run_to_end(fold_job(crate::check::shrink::types::def_clauses(d_p1), (Array::new(), Array::new()), {
        let sk_p0 = sk_p0.clone();
        let d_p1 = d_p1.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>), crate::syntax::decls::FnClause)| {
            let sk_p0 = sk_p0.clone();
            let d_p1 = d_p1.clone();
            entered(once_job(move || {
                let (rs_p2, ls_p3) = p0;
                let c_p4 = p1;
                call_then(start_clause_base(sk_p0.clone(), d_p1.clone(), c_p4.clone()), move |clause_base_4223: Map<Text, crate::check::shrink::Rel>| call_then(crate::check::shrink::walk::start_body_spots(c_p4.body.clone(), clause_base_4223), move |body_spots_4204: Array<crate::check::shrink::walk::Spot>| {
                    let spots_p5 = body_spots_4204;
                    call_then(crate::check::shrink::calls::start_spots_refs(sk_p0.clone(), d_p1.clone(), spots_p5.clone(), rs_p2.clone()), move |spots_refs_4255: Array<Text>| prism_rtl::Turn::Finished((spots_refs_4255, fold(&spots_p5, &ls_p3, &(|a2_p6: &Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>, sp_p7: &crate::check::shrink::walk::Spot| append(a2_p6, &spot_local(&d_p1, sp_p7)))))))
                }))
            }))
        }) as Rc<dyn Fn(((Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>), crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)>>>
    }));
    (d_p1.qk.clone(), refs_p8.clone(), locals_p9.clone())
}

/// The step machine of `DefWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
/// ```
pub struct DefWalk {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
}

impl prism_rtl::Job<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)> for DefWalk {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let d_p1 = d_p1.clone();
        let sk_p0 = sk_p0.clone();
        call_value(fold_job(crate::check::shrink::types::def_clauses(&d_p1), (Array::new(), Array::new()), {
            let sk_p0 = sk_p0.clone();
            let d_p1 = d_p1.clone();
            Rc::new(move |(p0, p1): ((Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>), crate::syntax::decls::FnClause)| {
                let sk_p0 = sk_p0.clone();
                let d_p1 = d_p1.clone();
                entered(once_job(move || {
                    let (rs_p2, ls_p3) = p0;
                    let c_p4 = p1;
                    call_then(start_clause_base(sk_p0.clone(), d_p1.clone(), c_p4.clone()), move |clause_base_4223: Map<Text, crate::check::shrink::Rel>| call_then(crate::check::shrink::walk::start_body_spots(c_p4.body.clone(), clause_base_4223), move |body_spots_4204: Array<crate::check::shrink::walk::Spot>| {
                        let spots_p5 = body_spots_4204;
                        call_then(crate::check::shrink::calls::start_spots_refs(sk_p0.clone(), d_p1.clone(), spots_p5.clone(), rs_p2.clone()), move |spots_refs_4255: Array<Text>| prism_rtl::Turn::Finished((spots_refs_4255, fold(&spots_p5, &ls_p3, &(|a2_p6: &Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>, sp_p7: &crate::check::shrink::walk::Spot| append(a2_p6, &spot_local(&d_p1, sp_p7)))))))
                    }))
                }))
            }) as Rc<dyn Fn(((Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>), crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)>>>
        }), move |fold_4130: (Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)| {
            let (refs_p8, locals_p9) = fold_4130;
            prism_rtl::Turn::Finished((d_p1.qk.clone(), refs_p8.clone(), locals_p9.clone()))
        })
    }
}

/// `Start DefWalk, x`: what the function value is when passed to `@Run`.
pub fn start_def_walk(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>, Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)>)>> {
    Rc::new(DefWalk { sk_p0, d_p1 })
}

/// ```prism
/// SpotLocal: fn Def, Spot -> [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]
/// ```
pub fn spot_local(d_p0: &crate::check::env::Def, sp_p1: &crate::check::shrink::walk::Spot) -> Array<(crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, Option<crate::syntax::decls::FnClause>, Option<crate::syntax::decls::WidgetDecl>)> {
    match sp_p1 {
        crate::check::shrink::walk::Spot::SpotStmt(s_p2, m_p3) => match &s_p2.kind {
            crate::syntax::StmtKind::SFn(f_p4) => {
                let n_p5 = crate::check::env::def_name_text(&f_p4.name);
                match get(m_p3, &Text::from(format!("lfn:{}", &n_p5))) {
                    Some(r_p6) => Array::from(vec![(d_p0.clone(), Text::from(format!("{}.{}", &d_p0.file, &r_p6.param)), n_p5.clone(), m_p3.clone(), Some(f_p4.clone()), None)]),
                    None => Array::new(),
                }
            },
            crate::syntax::StmtKind::SWidget(w_p7) => {
                let n_p8 = crate::check::env::sname_key(&w_p7.name);
                match get(m_p3, &Text::from(format!("lfn:{}", &n_p8))) {
                    Some(r_p9) => Array::from(vec![(d_p0.clone(), Text::from(format!("{}.{}", &d_p0.file, &r_p9.param)), n_p8.clone(), m_p3.clone(), None, Some(w_p7.clone()))]),
                    None => Array::new(),
                }
            },
            _ => Array::new(),
        },
        _ => Array::new(),
    }
}

/// ```prism
/// ?LocalTarget: fn Shrink, Def, Site -> ?Text
/// ```
pub fn local_target(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, site_p2: &crate::check::shrink::walk::Site) -> Option<Text> {
    match get(&site_p2.rels, &Text::from(format!("lfn:{}", &site_p2.callee))) {
        Some(r_p3) => Some(local_key(&site_p2.callee, &or(&get(&sk_p0.local_of, &d_p1.qk), &d_p1.qk), &Text::from(format!("{}.{}", &d_p1.file, &r_p3.param)))),
        None => None,
    }
}

/// ```prism
/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
/// ```
pub fn clause_base(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, c_p2: &crate::syntax::decls::FnClause) -> Map<Text, crate::check::shrink::Rel> {
    match get(&sk_p0.local_base, &d_p1.qk) {
        Some(b_p3) => param_rels_on(&b_p3, &c_p2.params),
        None => param_rels_on(&insert(&or(&get(&sk_p0.seeds, &d_p1.home), &Map::new()), &Text::lit("file:"), &crate::check::shrink::Rel { param: d_p1.file.clone(), strict: false }), &c_p2.params),
    }
}

/// The step machine of `ClauseBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
/// ```
pub struct ClauseBase {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub c_p2: crate::syntax::decls::FnClause,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for ClauseBase {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let c_p2 = &self.c_p2;
        match get(&sk_p0.local_base, &d_p1.qk) {
            Some(b_p3) => prism_rtl::Turn::More(Rc::new(ParamRelsOn { base_p0: b_p3.clone(), ps_p1: c_p2.params.clone() })),
            None => prism_rtl::Turn::More(Rc::new(ParamRelsOn { base_p0: insert(&or(&get(&sk_p0.seeds, &d_p1.home), &Map::new()), &Text::lit("file:"), &crate::check::shrink::Rel { param: d_p1.file.clone(), strict: false }), ps_p1: c_p2.params.clone() })),
        }
    }
}

/// `Start ClauseBase, x`: what the function value is when passed to `@Run`.
pub fn start_clause_base(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, c_p2: crate::syntax::decls::FnClause) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(ClauseBase { sk_p0, d_p1, c_p2 })
}

/// ```prism
/// ?ResolveCallee: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_callee(g_p0: &crate::check::env::G, m_p1: &Text, n_p2: &Text) -> Option<Text> {
    if is_op_text(n_p2) {
        resolve_op(g_p0, m_p1, n_p2)
    } else {
        match resolve_name(g_p0, m_p1, n_p2) {
            Some(k_p3) => Some(k_p3),
            None => if crate::syntax::lexer::chars::has_prefix(n_p2, &Text::lit("@")) {
                resolve_name(g_p0, m_p1, &crate::syntax::lexer::chars::after_first(n_p2))
            } else {
                None
            },
        }
    }
}

/// ```prism
/// ?ResolveOp: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_op(g_p0: &crate::check::env::G, m_p1: &Text, op_p2: &Text) -> Option<Text> {
    let (k_o3, _) = crate::check::env::names::resolve_value(g_p0, m_p1, &crate::syntax::SName { sigils: Text::lit(""), path_: Array::from(vec![op_p2.clone()]), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
    k_o3.clone()
}

/// ```prism
/// IsOpText: fn Text -> Bool
/// ```
pub fn is_op_text(n_p0: &Text) -> bool {
    (&len_text(n_p0) > &Nat::from(0u32)) && !crate::syntax::lexer::chars::fold_chars(n_p0, &false, &(Rc::new(move |(p0, p1): (bool, Text)| once_job(move || {
        let seen_p1 = p0;
        let ch_p2 = p1;
        prism_rtl::Turn::Finished(((seen_p1 || crate::syntax::lexer::chars::is_upper(&ch_p2)) || crate::syntax::lexer::chars::is_lower(&ch_p2)) || (&ch_p2 == &Text::lit("_")))
    })) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// ```prism
/// ?ResolveName: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_name(g_p0: &crate::check::env::G, m_p1: &Text, n_p2: &Text) -> Option<Text> {
    let marks_p3 = crate::check::types::unify::marks_of(n_p2);
    let path_p4 = split_on(&crate::syntax::lexer::chars::drop_prefix(n_p2, &marks_p3), &Text::lit("."));
    let (k_o5, _) = crate::check::env::names::resolve_value(g_p0, m_p1, &crate::syntax::SName { sigils: marks_p3.clone(), path_: path_p4.clone(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
    k_o5.clone()
}

/// ```prism
/// NamesInStmt: unbounded fn Stmt -> [Text]
/// ```
pub fn names_in_stmt(s_p0: &crate::syntax::Stmt) -> Array<Text> {
    crate::check::shrink::walk::spots_names(&crate::check::shrink::walk::stmt_spots(s_p0, &Map::new()))
}

/// The step machine of `NamesInStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamesInStmt: unbounded fn Stmt -> [Text]
/// ```
pub struct NamesInStmt {
    pub s_p0: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<Text>> for NamesInStmt {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s_p0 = &self.s_p0;
        let s_p0 = s_p0.clone();
        call_then(crate::check::shrink::walk::start_stmt_spots(s_p0.clone(), Map::new()), move |stmt_spots_6728: Array<crate::check::shrink::walk::Spot>| prism_rtl::Turn::More(Rc::new(crate::check::shrink::walk::SpotsNames { spots_p0: stmt_spots_6728 })))
    }
}

/// `Start NamesInStmt, x`: what the function value is when passed to `@Run`.
pub fn start_names_in_stmt(s_p0: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(NamesInStmt { s_p0 })
}

/// ```prism
/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
/// ```
pub fn sccs(keys_p0: &Array<Text>, refs_p1: &Array<(Text, Array<Text>)>) -> Array<Array<Text>> {
    let adj_p2 = fold(refs_p1, &Map::new(), &(|m_p4: &Map<Text, Array<Text>>, (k_p5, rs_p6): &(Text, Array<Text>)| insert(m_p4, k_p5, rs_p6)));
    let rev_p3 = fold(refs_p1, &Map::new(), &(|m_p7: &Map<Text, Array<Text>>, (k_p8, rs_p9): &(Text, Array<Text>)| fold(rs_p9, m_p7, &(|m2_pa: &Map<Text, Array<Text>>, r_pb: &Text| insert(m2_pa, r_pb, &push(&or(&get(m2_pa, r_pb), &Array::new()), k_p8))))));
    let (_, post_pf) = run_to_end(fold_job(keys_p0.clone(), (Map::new(), Array::new()), {
        let adj_p2 = adj_p2.clone();
        Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
            let adj_p2 = adj_p2.clone();
            entered(once_job(move || {
                let (seen_pc, out_pd) = p0;
                let k_pe = p1;
                prism_rtl::Turn::More(Rc::new(PostVisit { adj_p0: adj_p2.clone(), seen_p1: seen_pc.clone(), out_p2: out_pd.clone(), k_p3: k_pe.clone() }))
            }))
        }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
    }));
    let (ignore2_pl, comps_pm) = run_to_end(fold_job(crate::check::types::reverse2(&post_pf), (Map::new(), Array::new()), {
        let rev_p3 = rev_p3.clone();
        Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Array<Text>>), Text)| {
            let rev_p3 = rev_p3.clone();
            entered(once_job(move || {
                let (seen_pg, acc_ph) = p0;
                let k_pi = p1;
                if crate::check::env::has_key(&seen_pg, &k_pi) {
                    prism_rtl::Turn::Finished((seen_pg.clone(), acc_ph.clone()))
                } else {
                    call_then(start_collect(rev_p3.clone(), seen_pg.clone(), Array::new(), k_pi.clone()), move |collect_7570: (Map<Text, bool>, Array<Text>)| {
                        let (seen2_pj, comp_pk) = collect_7570;
                        prism_rtl::Turn::Finished((seen2_pj.clone(), push(&acc_ph, &comp_pk)))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Map<Text, bool>, Array<Array<Text>>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Array<Text>>)>>>
    }));
    filter(&comps_pm, &(|c_pn: &Array<Text>| (&len(c_pn) > &Nat::from(1u32)) || fold(c_pn, &false, &(|self_po: &bool, k_pp: &Text| *self_po || crate::check::types::has_text(&or(&get(&adj_p2, k_pp), &Array::new()), k_pp)))))
}

/// The step machine of `Sccs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
/// ```
pub struct Sccs {
    pub keys_p0: Array<Text>,
    pub refs_p1: Array<(Text, Array<Text>)>,
}

impl prism_rtl::Job<Array<Array<Text>>> for Sccs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Array<Text>>> {
        let keys_p0 = &self.keys_p0;
        let refs_p1 = &self.refs_p1;
        let adj_p2 = fold(refs_p1, &Map::new(), &(|m_p4: &Map<Text, Array<Text>>, (k_p5, rs_p6): &(Text, Array<Text>)| insert(m_p4, k_p5, rs_p6)));
        let rev_p3 = fold(refs_p1, &Map::new(), &(|m_p7: &Map<Text, Array<Text>>, (k_p8, rs_p9): &(Text, Array<Text>)| fold(rs_p9, m_p7, &(|m2_pa: &Map<Text, Array<Text>>, r_pb: &Text| insert(m2_pa, r_pb, &push(&or(&get(m2_pa, r_pb), &Array::new()), k_p8))))));
        let keys_p0 = keys_p0.clone();
        call_value(fold_job(keys_p0.clone(), (Map::new(), Array::new()), {
            let adj_p2 = adj_p2.clone();
            Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                let adj_p2 = adj_p2.clone();
                entered(once_job(move || {
                    let (seen_pc, out_pd) = p0;
                    let k_pe = p1;
                    prism_rtl::Turn::More(Rc::new(PostVisit { adj_p0: adj_p2.clone(), seen_p1: seen_pc.clone(), out_p2: out_pd.clone(), k_p3: k_pe.clone() }))
                }))
            }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
        }), move |fold_7323: (Map<Text, bool>, Array<Text>)| {
            let (_, post_pf) = fold_7323;
            call_value(fold_job(crate::check::types::reverse2(&post_pf), (Map::new(), Array::new()), {
                let rev_p3 = rev_p3.clone();
                Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Array<Text>>), Text)| {
                    let rev_p3 = rev_p3.clone();
                    entered(once_job(move || {
                        let (seen_pg, acc_ph) = p0;
                        let k_pi = p1;
                        if crate::check::env::has_key(&seen_pg, &k_pi) {
                            prism_rtl::Turn::Finished((seen_pg.clone(), acc_ph.clone()))
                        } else {
                            call_then(start_collect(rev_p3.clone(), seen_pg.clone(), Array::new(), k_pi.clone()), move |collect_7570: (Map<Text, bool>, Array<Text>)| {
                                let (seen2_pj, comp_pk) = collect_7570;
                                prism_rtl::Turn::Finished((seen2_pj.clone(), push(&acc_ph, &comp_pk)))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(((Map<Text, bool>, Array<Array<Text>>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Array<Text>>)>>>
            }), move |fold_7425: (Map<Text, bool>, Array<Array<Text>>)| {
                let (ignore2_pl, comps_pm) = fold_7425;
                prism_rtl::Turn::Finished(filter(&comps_pm, &(|c_pn: &Array<Text>| (&len(c_pn) > &Nat::from(1u32)) || fold(c_pn, &false, &(|self_po: &bool, k_pp: &Text| *self_po || crate::check::types::has_text(&or(&get(&adj_p2, k_pp), &Array::new()), k_pp))))))
            })
        })
    }
}

/// `Start Sccs, x`: what the function value is when passed to `@Run`.
pub fn start_sccs(keys_p0: Array<Text>, refs_p1: Array<(Text, Array<Text>)>) -> Rc<dyn prism_rtl::Job<Array<Array<Text>>>> {
    Rc::new(Sccs { keys_p0, refs_p1 })
}

/// ```prism
/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub fn post_visit(adj_p0: &Map<Text, Array<Text>>, seen_p1: &Map<Text, bool>, out_p2: &Array<Text>, k_p3: &Text) -> (Map<Text, bool>, Array<Text>) {
    if crate::check::env::has_key(seen_p1, k_p3) {
        (seen_p1.clone(), out_p2.clone())
    } else {
        {
            let (seen2_p7, out2_p8) = run_to_end(fold_job(or(&get(adj_p0, k_p3), &Array::new()), (insert(seen_p1, k_p3, &true), out_p2.clone()), {
                let adj_p0 = adj_p0.clone();
                Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                    let adj_p0 = adj_p0.clone();
                    entered(once_job(move || {
                        let (s_p4, o_p5) = p0;
                        let n_p6 = p1;
                        prism_rtl::Turn::More(Rc::new(PostVisit { adj_p0: adj_p0.clone(), seen_p1: s_p4.clone(), out_p2: o_p5.clone(), k_p3: n_p6.clone() }))
                    }))
                }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
            }));
            (seen2_p7.clone(), push(&out2_p8, k_p3))
        }
    }
}

/// The step machine of `PostVisit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub struct PostVisit {
    pub adj_p0: Map<Text, Array<Text>>,
    pub seen_p1: Map<Text, bool>,
    pub out_p2: Array<Text>,
    pub k_p3: Text,
}

impl prism_rtl::Job<(Map<Text, bool>, Array<Text>)> for PostVisit {
    fn cycle(&self) -> prism_rtl::Turn<(Map<Text, bool>, Array<Text>)> {
        let adj_p0 = &self.adj_p0;
        let seen_p1 = &self.seen_p1;
        let out_p2 = &self.out_p2;
        let k_p3 = &self.k_p3;
        if crate::check::env::has_key(seen_p1, k_p3) {
            prism_rtl::Turn::Finished((seen_p1.clone(), out_p2.clone()))
        } else {
            {
                let adj_p0 = adj_p0.clone();
                let k_p3 = k_p3.clone();
                let out_p2 = out_p2.clone();
                let seen_p1 = seen_p1.clone();
                call_value(fold_job(or(&get(&adj_p0, &k_p3), &Array::new()), (insert(&seen_p1, &k_p3, &true), out_p2.clone()), {
                    let adj_p0 = adj_p0.clone();
                    Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                        let adj_p0 = adj_p0.clone();
                        entered(once_job(move || {
                            let (s_p4, o_p5) = p0;
                            let n_p6 = p1;
                            prism_rtl::Turn::More(Rc::new(PostVisit { adj_p0: adj_p0.clone(), seen_p1: s_p4.clone(), out_p2: o_p5.clone(), k_p3: n_p6.clone() }))
                        }))
                    }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
                }), move |fold_7954: (Map<Text, bool>, Array<Text>)| {
                    let (seen2_p7, out2_p8) = fold_7954;
                    prism_rtl::Turn::Finished((seen2_p7.clone(), push(&out2_p8, &k_p3)))
                })
            }
        }
    }
}

/// `Start PostVisit, x`: what the function value is when passed to `@Run`.
pub fn start_post_visit(adj_p0: Map<Text, Array<Text>>, seen_p1: Map<Text, bool>, out_p2: Array<Text>, k_p3: Text) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>> {
    Rc::new(PostVisit { adj_p0, seen_p1, out_p2, k_p3 })
}

/// ```prism
/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub fn collect(rev_p0: &Map<Text, Array<Text>>, seen_p1: &Map<Text, bool>, comp_p2: &Array<Text>, k_p3: &Text) -> (Map<Text, bool>, Array<Text>) {
    if crate::check::env::has_key(seen_p1, k_p3) {
        (seen_p1.clone(), comp_p2.clone())
    } else {
        run_to_end(fold_job(or(&get(rev_p0, k_p3), &Array::new()), (insert(seen_p1, k_p3, &true), push(comp_p2, k_p3)), {
            let rev_p0 = rev_p0.clone();
            Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                let rev_p0 = rev_p0.clone();
                entered(once_job(move || {
                    let (s_p4, c_p5) = p0;
                    let n_p6 = p1;
                    prism_rtl::Turn::More(Rc::new(Collect { rev_p0: rev_p0.clone(), seen_p1: s_p4.clone(), comp_p2: c_p5.clone(), k_p3: n_p6.clone() }))
                }))
            }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
        }))
    }
}

/// The step machine of `Collect`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub struct Collect {
    pub rev_p0: Map<Text, Array<Text>>,
    pub seen_p1: Map<Text, bool>,
    pub comp_p2: Array<Text>,
    pub k_p3: Text,
}

impl prism_rtl::Job<(Map<Text, bool>, Array<Text>)> for Collect {
    fn cycle(&self) -> prism_rtl::Turn<(Map<Text, bool>, Array<Text>)> {
        let rev_p0 = &self.rev_p0;
        let seen_p1 = &self.seen_p1;
        let comp_p2 = &self.comp_p2;
        let k_p3 = &self.k_p3;
        if crate::check::env::has_key(seen_p1, k_p3) {
            prism_rtl::Turn::Finished((seen_p1.clone(), comp_p2.clone()))
        } else {
            fold_job(or(&get(rev_p0, k_p3), &Array::new()), (insert(seen_p1, k_p3, &true), push(comp_p2, k_p3)), {
                let rev_p0 = rev_p0.clone();
                Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                    let rev_p0 = rev_p0.clone();
                    entered(once_job(move || {
                        let (s_p4, c_p5) = p0;
                        let n_p6 = p1;
                        prism_rtl::Turn::More(Rc::new(Collect { rev_p0: rev_p0.clone(), seen_p1: s_p4.clone(), comp_p2: c_p5.clone(), k_p3: n_p6.clone() }))
                    }))
                }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
            }).cycle()
        }
    }
}

/// `Start Collect, x`: what the function value is when passed to `@Run`.
pub fn start_collect(rev_p0: Map<Text, Array<Text>>, seen_p1: Map<Text, bool>, comp_p2: Array<Text>, k_p3: Text) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>> {
    Rc::new(Collect { rev_p0, seen_p1, comp_p2, k_p3 })
}

/// ```prism
/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
/// ```
pub fn shrink_component(sk_p0: &crate::check::shrink::Shrink, st_p1: &crate::check::types::St, comp_p2: &Array<Text>) -> crate::check::types::St {
    if fold(comp_p2, &true, &(|ok_p3: &bool, k_p4: &Text| *ok_p3 && crate::check::shrink::types::is_unbounded_key(&sk_p0.g, &crate::check::shrink::types::sig_key_of(sk_p0, &or(&get(&sk_p0.local_of, k_p4), k_p4))))) {
        st_p1.clone()
    } else {
        {
            let graphs_p5 = run_to_end(fold_job(sk_p0.fns.clone(), Array::new(), {
                let comp_p2 = comp_p2.clone();
                let sk_p0 = sk_p0.clone();
                Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, crate::check::env::Def)| {
                    let comp_p2 = comp_p2.clone();
                    let sk_p0 = sk_p0.clone();
                    entered(once_job(move || {
                        let acc_p8 = p0;
                        let d_p9 = p1;
                        if crate::check::types::has_text(&comp_p2, &d_p9.qk) {
                            call_then(start_call_graphs(sk_p0.clone(), d_p9.clone(), comp_p2.clone()), move |call_graphs_8869: Array<crate::check::shrink::Sc>| prism_rtl::Turn::Finished(append(&acc_p8, &call_graphs_8869)))
                        } else {
                            prism_rtl::Turn::Finished(acc_p8.clone())
                        }
                    }))
                }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
            }));
            let closure_p6 = crate::check::shrink::summaries::closure(&graphs_p5);
            let bad_p7 = filter(&closure_p6, &(|sc_pa: &crate::check::shrink::Sc| ((&sc_pa.caller == &sc_pa.callee) && (&crate::check::shrink::summaries::compose(sc_pa, sc_pa).edges == &sc_pa.edges)) && !fold(&sc_pa.edges, &false, &(|seen_pb: &bool, (a_pc, b_pd, s_pe): &(Nat, Nat, bool)| *seen_pb || ((a_pc == b_pd) && *s_pe)))));
            match index(&bad_p7, &Nat::from(0u32)) {
                Some(sc_pf) => {
                    let s2_pg = {
                        let mut this: crate::check::types::St = st_p1.clone();
                        this.file = sc_pf.file.clone();
                        this
                    };
                    let what_ph = if &sc_pf.arg == &Text::lit("") {
                        Text::lit("")
                    } else {
                        Text::from(format!(" on `{}`", &sc_pf.arg))
                    };
                    let st3_pi = crate::check::types::recording::err_fix(&s2_pg, &Text::lit("may-not-end"), &sc_pf.span, &Text::from(format!("`{}` calls {}{}, not smaller than what it was given", &crate::check::shrink::types::shown_key(&sc_pf.caller), &(if &sc_pf.caller == &sc_pf.callee {
                        Text::lit("itself")
                    } else {
                        Text::from(format!("`{}`", &crate::check::shrink::types::shown_key(&sc_pf.callee)))
                    }), &what_ph)), &Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle\'s functions `unbounded fn`"));
                    {
                        let mut this: crate::check::types::St = st3_pi.clone();
                        this.file = st_p1.file.clone();
                        this
                    }
                },
                None => st_p1.clone(),
            }
        }
    }
}

/// The step machine of `ShrinkComponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
/// ```
pub struct ShrinkComponent {
    pub sk_p0: crate::check::shrink::Shrink,
    pub st_p1: crate::check::types::St,
    pub comp_p2: Array<Text>,
}

impl prism_rtl::Job<crate::check::types::St> for ShrinkComponent {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let sk_p0 = &self.sk_p0;
        let st_p1 = &self.st_p1;
        let comp_p2 = &self.comp_p2;
        if fold(comp_p2, &true, &(|ok_p3: &bool, k_p4: &Text| *ok_p3 && crate::check::shrink::types::is_unbounded_key(&sk_p0.g, &crate::check::shrink::types::sig_key_of(sk_p0, &or(&get(&sk_p0.local_of, k_p4), k_p4))))) {
            prism_rtl::Turn::Finished(st_p1.clone())
        } else {
            {
                let comp_p2 = comp_p2.clone();
                let sk_p0 = sk_p0.clone();
                let st_p1 = st_p1.clone();
                call_value(fold_job(sk_p0.fns.clone(), Array::new(), {
                    let comp_p2 = comp_p2.clone();
                    let sk_p0 = sk_p0.clone();
                    Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, crate::check::env::Def)| {
                        let comp_p2 = comp_p2.clone();
                        let sk_p0 = sk_p0.clone();
                        entered(once_job(move || {
                            let acc_p8 = p0;
                            let d_p9 = p1;
                            if crate::check::types::has_text(&comp_p2, &d_p9.qk) {
                                call_then(start_call_graphs(sk_p0.clone(), d_p9.clone(), comp_p2.clone()), move |call_graphs_8869: Array<crate::check::shrink::Sc>| prism_rtl::Turn::Finished(append(&acc_p8, &call_graphs_8869)))
                            } else {
                                prism_rtl::Turn::Finished(acc_p8.clone())
                            }
                        }))
                    }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
                }), move |fold_8804: Array<crate::check::shrink::Sc>| {
                    let graphs_p5 = fold_8804;
                    call_then(crate::check::shrink::summaries::start_closure(graphs_p5.clone()), move |closure_8925: Array<crate::check::shrink::Sc>| {
                        let closure_p6 = closure_8925;
                        let bad_p7 = filter(&closure_p6, &(|sc_pa: &crate::check::shrink::Sc| ((&sc_pa.caller == &sc_pa.callee) && (&crate::check::shrink::summaries::compose(sc_pa, sc_pa).edges == &sc_pa.edges)) && !fold(&sc_pa.edges, &false, &(|seen_pb: &bool, (a_pc, b_pd, s_pe): &(Nat, Nat, bool)| *seen_pb || ((a_pc == b_pd) && *s_pe)))));
                        match index(&bad_p7, &Nat::from(0u32)) {
                            Some(sc_pf) => {
                                let s2_pg = {
                                    let mut this: crate::check::types::St = st_p1.clone();
                                    this.file = sc_pf.file.clone();
                                    this
                                };
                                let what_ph = if &sc_pf.arg == &Text::lit("") {
                                    Text::lit("")
                                } else {
                                    Text::from(format!(" on `{}`", &sc_pf.arg))
                                };
                                let st3_pi = crate::check::types::recording::err_fix(&s2_pg, &Text::lit("may-not-end"), &sc_pf.span, &Text::from(format!("`{}` calls {}{}, not smaller than what it was given", &crate::check::shrink::types::shown_key(&sc_pf.caller), &(if &sc_pf.caller == &sc_pf.callee {
                                    Text::lit("itself")
                                } else {
                                    Text::from(format!("`{}`", &crate::check::shrink::types::shown_key(&sc_pf.callee)))
                                }), &what_ph)), &Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle\'s functions `unbounded fn`"));
                                prism_rtl::Turn::Finished({
                                    let mut this: crate::check::types::St = st3_pi.clone();
                                    this.file = st_p1.file.clone();
                                    this
                                })
                            },
                            None => prism_rtl::Turn::Finished(st_p1.clone()),
                        }
                    })
                })
            }
        }
    }
}

/// `Start ShrinkComponent, x`: what the function value is when passed to `@Run`.
pub fn start_shrink_component(sk_p0: crate::check::shrink::Shrink, st_p1: crate::check::types::St, comp_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ShrinkComponent { sk_p0, st_p1, comp_p2 })
}

/// ```prism
/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
/// ```
pub fn call_graphs(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, comp_p2: &Array<Text>) -> Array<crate::check::shrink::Sc> {
    run_to_end(fold_job(crate::check::shrink::types::def_clauses(d_p1), Array::new(), {
        let sk_p0 = sk_p0.clone();
        let d_p1 = d_p1.clone();
        let comp_p2 = comp_p2.clone();
        Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause)| {
            let sk_p0 = sk_p0.clone();
            let d_p1 = d_p1.clone();
            let comp_p2 = comp_p2.clone();
            entered(once_job(move || {
                let acc_p3 = p0;
                let c_p4 = p1;
                call_then(start_clause_graphs(sk_p0.clone(), d_p1.clone(), c_p4.clone(), comp_p2.clone()), move |clause_graphs_9987: Array<crate::check::shrink::Sc>| prism_rtl::Turn::Finished(append(&acc_p3, &clause_graphs_9987)))
            }))
        }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
    }))
}

/// The step machine of `CallGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
/// ```
pub struct CallGraphs {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub comp_p2: Array<Text>,
}

impl prism_rtl::Job<Array<crate::check::shrink::Sc>> for CallGraphs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::shrink::Sc>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let comp_p2 = &self.comp_p2;
        fold_job(crate::check::shrink::types::def_clauses(d_p1), Array::new(), {
            let sk_p0 = sk_p0.clone();
            let d_p1 = d_p1.clone();
            let comp_p2 = comp_p2.clone();
            Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause)| {
                let sk_p0 = sk_p0.clone();
                let d_p1 = d_p1.clone();
                let comp_p2 = comp_p2.clone();
                entered(once_job(move || {
                    let acc_p3 = p0;
                    let c_p4 = p1;
                    call_then(start_clause_graphs(sk_p0.clone(), d_p1.clone(), c_p4.clone(), comp_p2.clone()), move |clause_graphs_9987: Array<crate::check::shrink::Sc>| prism_rtl::Turn::Finished(append(&acc_p3, &clause_graphs_9987)))
                }))
            }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
        }).cycle()
    }
}

/// `Start CallGraphs, x`: what the function value is when passed to `@Run`.
pub fn start_call_graphs(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, comp_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>> {
    Rc::new(CallGraphs { sk_p0, d_p1, comp_p2 })
}

/// ```prism
/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
/// ```
pub fn clause_graphs(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, c_p2: &crate::syntax::decls::FnClause, comp_p3: &Array<Text>) -> Array<crate::check::shrink::Sc> {
    let base_p4 = clause_base(sk_p0, d_p1, c_p2);
    let rels_p5 = crate::check::shrink::summaries::summary_seeds(sk_p0, d_p1, &crate::check::shrink::walk::body_spots(&c_p2.body, &base_p4), &base_p4);
    run_to_end(fold_job(crate::check::shrink::walk::body_sites(&c_p2.body, &rels_p5), Array::new(), {
        let sk_p0 = sk_p0.clone();
        let d_p1 = d_p1.clone();
        let comp_p3 = comp_p3.clone();
        Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site)| {
            let sk_p0 = sk_p0.clone();
            let d_p1 = d_p1.clone();
            let comp_p3 = comp_p3.clone();
            entered(once_job(move || {
                let acc_p6 = p0;
                let site_p7 = p1;
                match local_target(&sk_p0, &d_p1, &site_p7) {
                    Some(t_p8) => if crate::check::types::has_text(&comp_p3, &t_p8) {
                        call_then(start_site_graph(sk_p0.clone(), d_p1.clone(), site_p7.clone(), t_p8.clone()), move |site_graph_10345: crate::check::shrink::Sc| prism_rtl::Turn::Finished(push(&acc_p6, &site_graph_10345)))
                    } else {
                        prism_rtl::Turn::Finished(acc_p6.clone())
                    },
                    None => if crate::check::shrink::relations::is_local(&site_p7.rels, &site_p7.callee) || crate::check::env::has_key(&sk_p0.local_of, &d_p1.qk) {
                        prism_rtl::Turn::Finished(acc_p6.clone())
                    } else {
                        match resolve_callee(&sk_p0.g, &d_p1.home, &site_p7.callee) {
                            Some(k_p9) => call_then(crate::check::shrink::types::start_dispatch_targets(sk_p0.clone(), d_p1.clone(), site_p7.clone(), k_p9.clone()), move |dispatch_targets_10567: Array<Text>| fold_job(dispatch_targets_10567, acc_p6.clone(), {
                                let comp_p3 = comp_p3.clone();
                                let sk_p0 = sk_p0.clone();
                                let d_p1 = d_p1.clone();
                                let site_p7 = site_p7.clone();
                                Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, Text)| {
                                    let comp_p3 = comp_p3.clone();
                                    let sk_p0 = sk_p0.clone();
                                    let d_p1 = d_p1.clone();
                                    let site_p7 = site_p7.clone();
                                    entered(once_job(move || {
                                        let acc2_pa = p0;
                                        let t_pb = p1;
                                        if crate::check::types::has_text(&comp_p3, &t_pb) {
                                            call_then(start_site_graph(sk_p0.clone(), d_p1.clone(), site_p7.clone(), t_pb.clone()), move |site_graph_10648: crate::check::shrink::Sc| prism_rtl::Turn::Finished(push(&acc2_pa, &site_graph_10648)))
                                        } else {
                                            prism_rtl::Turn::Finished(acc2_pa.clone())
                                        }
                                    }))
                                }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, Text)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
                            }).cycle()),
                            None => prism_rtl::Turn::Finished(acc_p6.clone()),
                        }
                    },
                }
            }))
        }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
    }))
}

/// The step machine of `ClauseGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
/// ```
pub struct ClauseGraphs {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub c_p2: crate::syntax::decls::FnClause,
    pub comp_p3: Array<Text>,
}

impl prism_rtl::Job<Array<crate::check::shrink::Sc>> for ClauseGraphs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::check::shrink::Sc>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let c_p2 = &self.c_p2;
        let comp_p3 = &self.comp_p3;
        let c_p2 = c_p2.clone();
        let comp_p3 = comp_p3.clone();
        let d_p1 = d_p1.clone();
        let sk_p0 = sk_p0.clone();
        call_then(start_clause_base(sk_p0.clone(), d_p1.clone(), c_p2.clone()), move |clause_base_10129: Map<Text, crate::check::shrink::Rel>| {
            let base_p4 = clause_base_10129;
            call_then(crate::check::shrink::walk::start_body_spots(c_p2.body.clone(), base_p4.clone()), move |body_spots_10185: Array<crate::check::shrink::walk::Spot>| call_then(crate::check::shrink::summaries::start_summary_seeds(sk_p0.clone(), d_p1.clone(), body_spots_10185, base_p4.clone()), move |summary_seeds_10164: Map<Text, crate::check::shrink::Rel>| {
                let rels_p5 = summary_seeds_10164;
                call_then(crate::check::shrink::walk::start_body_sites(c_p2.body.clone(), rels_p5.clone()), move |body_sites_10225: Array<crate::check::shrink::walk::Site>| fold_job(body_sites_10225, Array::new(), {
                    let sk_p0 = sk_p0.clone();
                    let d_p1 = d_p1.clone();
                    let comp_p3 = comp_p3.clone();
                    Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site)| {
                        let sk_p0 = sk_p0.clone();
                        let d_p1 = d_p1.clone();
                        let comp_p3 = comp_p3.clone();
                        entered(once_job(move || {
                            let acc_p6 = p0;
                            let site_p7 = p1;
                            match local_target(&sk_p0, &d_p1, &site_p7) {
                                Some(t_p8) => if crate::check::types::has_text(&comp_p3, &t_p8) {
                                    call_then(start_site_graph(sk_p0.clone(), d_p1.clone(), site_p7.clone(), t_p8.clone()), move |site_graph_10345: crate::check::shrink::Sc| prism_rtl::Turn::Finished(push(&acc_p6, &site_graph_10345)))
                                } else {
                                    prism_rtl::Turn::Finished(acc_p6.clone())
                                },
                                None => if crate::check::shrink::relations::is_local(&site_p7.rels, &site_p7.callee) || crate::check::env::has_key(&sk_p0.local_of, &d_p1.qk) {
                                    prism_rtl::Turn::Finished(acc_p6.clone())
                                } else {
                                    match resolve_callee(&sk_p0.g, &d_p1.home, &site_p7.callee) {
                                        Some(k_p9) => call_then(crate::check::shrink::types::start_dispatch_targets(sk_p0.clone(), d_p1.clone(), site_p7.clone(), k_p9.clone()), move |dispatch_targets_10567: Array<Text>| fold_job(dispatch_targets_10567, acc_p6.clone(), {
                                            let comp_p3 = comp_p3.clone();
                                            let sk_p0 = sk_p0.clone();
                                            let d_p1 = d_p1.clone();
                                            let site_p7 = site_p7.clone();
                                            Rc::new(move |(p0, p1): (Array<crate::check::shrink::Sc>, Text)| {
                                                let comp_p3 = comp_p3.clone();
                                                let sk_p0 = sk_p0.clone();
                                                let d_p1 = d_p1.clone();
                                                let site_p7 = site_p7.clone();
                                                entered(once_job(move || {
                                                    let acc2_pa = p0;
                                                    let t_pb = p1;
                                                    if crate::check::types::has_text(&comp_p3, &t_pb) {
                                                        call_then(start_site_graph(sk_p0.clone(), d_p1.clone(), site_p7.clone(), t_pb.clone()), move |site_graph_10648: crate::check::shrink::Sc| prism_rtl::Turn::Finished(push(&acc2_pa, &site_graph_10648)))
                                                    } else {
                                                        prism_rtl::Turn::Finished(acc2_pa.clone())
                                                    }
                                                }))
                                            }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, Text)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
                                        }).cycle()),
                                        None => prism_rtl::Turn::Finished(acc_p6.clone()),
                                    }
                                },
                            }
                        }))
                    }) as Rc<dyn Fn((Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site)) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>>>
                }).cycle())
            }))
        })
    }
}

/// `Start ClauseGraphs, x`: what the function value is when passed to `@Run`.
pub fn start_clause_graphs(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, c_p2: crate::syntax::decls::FnClause, comp_p3: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<crate::check::shrink::Sc>>> {
    Rc::new(ClauseGraphs { sk_p0, d_p1, c_p2, comp_p3 })
}

/// ```prism
/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
/// ```
pub fn site_graph(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, site_p2: &crate::check::shrink::walk::Site, k_p3: &Text) -> crate::check::shrink::Sc {
    let edges_p4 = run_to_end(fold_job(arg_slots(sk_p0, &site_p2.args, k_p3), Array::new(), {
        let site_p2 = site_p2.clone();
        Rc::new(move |(p0, p1): (Array<(Nat, Nat, bool)>, (Nat, crate::syntax::Arg))| {
            let site_p2 = site_p2.clone();
            entered(once_job(move || {
                let es_p6 = p0;
                let (j_p7, a_p8) = p1;
                call_then(crate::check::shrink::walk::start_rel_of(site_p2.rels.clone(), a_p8.value.clone()), move |rel_of_10986: Option<crate::check::shrink::Rel>| match rel_of_10986 {
                    Some(r_p9) => prism_rtl::Turn::Finished(push(&es_p6, &(r_p9.param.clone(), j_p7.clone(), r_p9.strict))),
                    None => prism_rtl::Turn::Finished(es_p6.clone()),
                })
            }))
        }) as Rc<dyn Fn((Array<(Nat, Nat, bool)>, (Nat, crate::syntax::Arg))) -> Rc<dyn prism_rtl::Job<Array<(Nat, Nat, bool)>>>>
    }));
    let arg_text_p5 = match index(&site_p2.args, &Nat::from(0u32)) {
        Some(a_pa) => expr_name(&a_pa.value),
        None => Text::lit(""),
    };
    crate::check::shrink::Sc { caller: d_p1.qk.clone(), callee: k_p3.clone(), edges: edges_p4.clone(), span: site_p2.span.clone(), file: d_p1.file.clone(), arg: arg_text_p5.clone() }
}

/// The step machine of `SiteGraph`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
/// ```
pub struct SiteGraph {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub site_p2: crate::check::shrink::walk::Site,
    pub k_p3: Text,
}

impl prism_rtl::Job<crate::check::shrink::Sc> for SiteGraph {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::shrink::Sc> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let site_p2 = &self.site_p2;
        let k_p3 = &self.k_p3;
        let d_p1 = d_p1.clone();
        let k_p3 = k_p3.clone();
        let site_p2 = site_p2.clone();
        let sk_p0 = sk_p0.clone();
        call_then(start_arg_slots(sk_p0.clone(), site_p2.args.clone(), k_p3.clone()), move |arg_slots_10930: Array<(Nat, crate::syntax::Arg)>| call_value(fold_job(arg_slots_10930, Array::new(), {
            let site_p2 = site_p2.clone();
            Rc::new(move |(p0, p1): (Array<(Nat, Nat, bool)>, (Nat, crate::syntax::Arg))| {
                let site_p2 = site_p2.clone();
                entered(once_job(move || {
                    let es_p6 = p0;
                    let (j_p7, a_p8) = p1;
                    call_then(crate::check::shrink::walk::start_rel_of(site_p2.rels.clone(), a_p8.value.clone()), move |rel_of_10986: Option<crate::check::shrink::Rel>| match rel_of_10986 {
                        Some(r_p9) => prism_rtl::Turn::Finished(push(&es_p6, &(r_p9.param.clone(), j_p7.clone(), r_p9.strict))),
                        None => prism_rtl::Turn::Finished(es_p6.clone()),
                    })
                }))
            }) as Rc<dyn Fn((Array<(Nat, Nat, bool)>, (Nat, crate::syntax::Arg))) -> Rc<dyn prism_rtl::Job<Array<(Nat, Nat, bool)>>>>
        }), move |fold_10924: Array<(Nat, Nat, bool)>| {
            let edges_p4 = fold_10924;
            let arg_text_p5 = match index(&site_p2.args, &Nat::from(0u32)) {
                Some(a_pa) => expr_name(&a_pa.value),
                None => Text::lit(""),
            };
            prism_rtl::Turn::Finished(crate::check::shrink::Sc { caller: d_p1.qk.clone(), callee: k_p3.clone(), edges: edges_p4.clone(), span: site_p2.span.clone(), file: d_p1.file.clone(), arg: arg_text_p5.clone() })
        }))
    }
}

/// `Start SiteGraph, x`: what the function value is when passed to `@Run`.
pub fn start_site_graph(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, site_p2: crate::check::shrink::walk::Site, k_p3: Text) -> Rc<dyn prism_rtl::Job<crate::check::shrink::Sc>> {
    Rc::new(SiteGraph { sk_p0, d_p1, site_p2, k_p3 })
}

/// ```prism
/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
/// ```
pub fn arg_slots(sk_p0: &crate::check::shrink::Shrink, args_p1: &Array<crate::syntax::Arg>, k_p2: &Text) -> Array<(Nat, crate::syntax::Arg)> {
    let (_, out_p8) = run_to_end(fold_job(args_p1.clone(), (Nat::from(0u32), Array::new()), {
        let sk_p0 = sk_p0.clone();
        let k_p2 = k_p2.clone();
        Rc::new(move |(p0, p1): ((Nat, Array<(Nat, crate::syntax::Arg)>), crate::syntax::Arg)| {
            let sk_p0 = sk_p0.clone();
            let k_p2 = k_p2.clone();
            entered(once_job(move || {
                let (pos_p3, acc_p4) = p0;
                let a_p5 = p1;
                match &a_p5.name {
                    None => prism_rtl::Turn::Finished((&pos_p3 + &Nat::from(1u32), push(&acc_p4, &(pos_p3.clone(), a_p5.clone())))),
                    Some(id_p6) => {
                        let id_p6 = id_p6.clone();
                        call_then(start_param_named(sk_p0.clone(), k_p2.clone(), id_p6.name.clone()), move |param_named_11800: Option<Nat>| match param_named_11800 {
                            Some(j_p7) => prism_rtl::Turn::Finished((pos_p3.clone(), push(&acc_p4, &(j_p7.clone(), a_p5.clone())))),
                            None => prism_rtl::Turn::Finished((pos_p3.clone(), acc_p4.clone())),
                        })
                    },
                }
            }))
        }) as Rc<dyn Fn(((Nat, Array<(Nat, crate::syntax::Arg)>), crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<(Nat, Array<(Nat, crate::syntax::Arg)>)>>>
    }));
    out_p8.clone()
}

/// The step machine of `ArgSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
/// ```
pub struct ArgSlots {
    pub sk_p0: crate::check::shrink::Shrink,
    pub args_p1: Array<crate::syntax::Arg>,
    pub k_p2: Text,
}

impl prism_rtl::Job<Array<(Nat, crate::syntax::Arg)>> for ArgSlots {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Nat, crate::syntax::Arg)>> {
        let sk_p0 = &self.sk_p0;
        let args_p1 = &self.args_p1;
        let k_p2 = &self.k_p2;
        let args_p1 = args_p1.clone();
        let k_p2 = k_p2.clone();
        let sk_p0 = sk_p0.clone();
        call_value(fold_job(args_p1.clone(), (Nat::from(0u32), Array::new()), {
            let sk_p0 = sk_p0.clone();
            let k_p2 = k_p2.clone();
            Rc::new(move |(p0, p1): ((Nat, Array<(Nat, crate::syntax::Arg)>), crate::syntax::Arg)| {
                let sk_p0 = sk_p0.clone();
                let k_p2 = k_p2.clone();
                entered(once_job(move || {
                    let (pos_p3, acc_p4) = p0;
                    let a_p5 = p1;
                    match &a_p5.name {
                        None => prism_rtl::Turn::Finished((&pos_p3 + &Nat::from(1u32), push(&acc_p4, &(pos_p3.clone(), a_p5.clone())))),
                        Some(id_p6) => {
                            let id_p6 = id_p6.clone();
                            call_then(start_param_named(sk_p0.clone(), k_p2.clone(), id_p6.name.clone()), move |param_named_11800: Option<Nat>| match param_named_11800 {
                                Some(j_p7) => prism_rtl::Turn::Finished((pos_p3.clone(), push(&acc_p4, &(j_p7.clone(), a_p5.clone())))),
                                None => prism_rtl::Turn::Finished((pos_p3.clone(), acc_p4.clone())),
                            })
                        },
                    }
                }))
            }) as Rc<dyn Fn(((Nat, Array<(Nat, crate::syntax::Arg)>), crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<(Nat, Array<(Nat, crate::syntax::Arg)>)>>>
        }), move |fold_11673: (Nat, Array<(Nat, crate::syntax::Arg)>)| {
            let (_, out_p8) = fold_11673;
            prism_rtl::Turn::Finished(out_p8.clone())
        })
    }
}

/// `Start ArgSlots, x`: what the function value is when passed to `@Run`.
pub fn start_arg_slots(sk_p0: crate::check::shrink::Shrink, args_p1: Array<crate::syntax::Arg>, k_p2: Text) -> Rc<dyn prism_rtl::Job<Array<(Nat, crate::syntax::Arg)>>> {
    Rc::new(ArgSlots { sk_p0, args_p1, k_p2 })
}

/// ```prism
/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
/// ```
pub fn param_named(sk_p0: &crate::check::shrink::Shrink, k_p1: &Text, name_p2: &Text) -> Option<Nat> {
    let clauses_p3 = crate::check::shrink::types::def_clauses(&or(&get(&sk_p0.by_key, k_p1), &crate::check::env::decls::dummy_def()));
    if name_p2 == &Text::lit("#body") {
        match index(&clauses_p3, &Nat::from(0u32)) {
            Some(c_p4) => if &len(&c_p4.params) > &Nat::from(0u32) {
                Some(crate::syntax::lexer::chars::dec(&len(&c_p4.params)))
            } else {
                None
            },
            None => None,
        }
    } else {
        param_named_in(&clauses_p3, name_p2)
    }
}

/// The step machine of `ParamNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
/// ```
pub struct ParamNamed {
    pub sk_p0: crate::check::shrink::Shrink,
    pub k_p1: Text,
    pub name_p2: Text,
}

impl prism_rtl::Job<Option<Nat>> for ParamNamed {
    fn cycle(&self) -> prism_rtl::Turn<Option<Nat>> {
        let sk_p0 = &self.sk_p0;
        let k_p1 = &self.k_p1;
        let name_p2 = &self.name_p2;
        let clauses_p3 = crate::check::shrink::types::def_clauses(&or(&get(&sk_p0.by_key, k_p1), &crate::check::env::decls::dummy_def()));
        if name_p2 == &Text::lit("#body") {
            match index(&clauses_p3, &Nat::from(0u32)) {
                Some(c_p4) => if &len(&c_p4.params) > &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(Some(crate::syntax::lexer::chars::dec(&len(&c_p4.params))))
                } else {
                    prism_rtl::Turn::Finished(None)
                },
                None => prism_rtl::Turn::Finished(None),
            }
        } else {
            prism_rtl::Turn::Finished(param_named_in(&clauses_p3, name_p2))
        }
    }
}

/// `Start ParamNamed, x`: what the function value is when passed to `@Run`.
pub fn start_param_named(sk_p0: crate::check::shrink::Shrink, k_p1: Text, name_p2: Text) -> Rc<dyn prism_rtl::Job<Option<Nat>>> {
    Rc::new(ParamNamed { sk_p0, k_p1, name_p2 })
}

/// ```prism
/// ?ParamNamedIn: unbounded fn [FnClause], Text -> ?Nat
/// ```
pub fn param_named_in(clauses_p0: &Array<crate::syntax::decls::FnClause>, name_p1: &Text) -> Option<Nat> {
    let found_p7 = run_to_end(fold_job(clauses_p0.clone(), Array::new(), {
        let name_p1 = name_p1.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::syntax::decls::FnClause)| {
            let name_p1 = name_p1.clone();
            entered(once_job(move || {
                let acc_p2 = p0;
                let c_p3 = p1;
                fold_job(crate::check::errors::range0(&len(&c_p3.params)), acc_p2.clone(), {
                    let c_p3 = c_p3.clone();
                    let name_p1 = name_p1.clone();
                    Rc::new(move |(p0, p1): (Array<Nat>, Nat)| {
                        let c_p3 = c_p3.clone();
                        let name_p1 = name_p1.clone();
                        entered(once_job(move || {
                            let a2_p4 = p0;
                            let i_p5 = p1;
                            match index(&c_p3.params, &i_p5) {
                                Some(p_p6) => if (&param_name_of(&p_p6) == &name_p1) && !crate::check::types::has_nat(&a2_p4, &i_p5) {
                                    prism_rtl::Turn::Finished(push(&a2_p4, &i_p5))
                                } else {
                                    prism_rtl::Turn::Finished(a2_p4.clone())
                                },
                                None => prism_rtl::Turn::Finished(a2_p4.clone()),
                            }
                        }))
                    }) as Rc<dyn Fn((Array<Nat>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    if &len(&found_p7) == &Nat::from(1u32) {
        index(&found_p7, &Nat::from(0u32))
    } else {
        None
    }
}

/// ```prism
/// ParamNameOf: unbounded fn Pattern -> Text
/// ```
pub fn param_name_of(p_p0: &crate::syntax::Pattern_) -> Text {
    match &*p_p0.kind {
        crate::syntax::PatternKind::PName(n_p1) => {
            let text_p2 = crate::check::env::sname_key(n_p1);
            crate::syntax::lexer::chars::drop_prefix(&text_p2, &crate::check::types::unify::marks_of(&text_p2))
        },
        crate::syntax::PatternKind::PGroup(q_p3) => param_name_of(&**q_p3),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ExprName: fn Expr -> Text
/// ```
pub fn expr_name(e_p0: &crate::syntax::Expr) -> Text {
    match &*e_p0.kind {
        crate::syntax::ExprKind::EName(n_p1) => crate::check::env::sname_key(n_p1),
        crate::syntax::ExprKind::EGroup(x_p2) => expr_name(&**x_p2),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
/// ```
pub fn param_rels_on(base_p0: &Map<Text, crate::check::shrink::Rel>, ps_p1: &Array<crate::syntax::Pattern_>) -> Map<Text, crate::check::shrink::Rel> {
    run_to_end(fold_job(crate::check::errors::range0(&len(ps_p1)), crate::check::shrink::relations::hide(base_p0, &crate::check::shrink::walk::patterns_names(ps_p1)), {
        let ps_p1 = ps_p1.clone();
        Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Nat)| {
            let ps_p1 = ps_p1.clone();
            entered(once_job(move || {
                let m_p2 = p0;
                let i_p3 = p1;
                match index(&ps_p1, &i_p3) {
                    Some(p_p4) => match &*p_p4.kind {
                        crate::syntax::PatternKind::PName(n_p5) => prism_rtl::Turn::Finished(insert(&m_p2, &crate::check::env::sname_key(n_p5), &crate::check::shrink::Rel { param: i_p3.clone(), strict: false })),
                        _ => call_then(crate::check::env::names::start_pattern_names(p_p4.clone()), move |pattern_names_13573: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_13573, &m_p2, &(|m2_p6: &Map<Text, crate::check::shrink::Rel>, n_p7: &Text| insert(m2_p6, n_p7, &crate::check::shrink::Rel { param: i_p3.clone(), strict: true }))))),
                    },
                    None => prism_rtl::Turn::Finished(m_p2.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
    }))
}

/// The step machine of `ParamRelsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
/// ```
pub struct ParamRelsOn {
    pub base_p0: Map<Text, crate::check::shrink::Rel>,
    pub ps_p1: Array<crate::syntax::Pattern_>,
}

impl prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> for ParamRelsOn {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> {
        let base_p0 = &self.base_p0;
        let ps_p1 = &self.ps_p1;
        let base_p0 = base_p0.clone();
        let ps_p1 = ps_p1.clone();
        call_then(crate::check::shrink::walk::start_patterns_names(ps_p1.clone()), move |patterns_names_13416: Array<Text>| fold_job(crate::check::errors::range0(&len(&ps_p1)), crate::check::shrink::relations::hide(&base_p0, &patterns_names_13416), {
            let ps_p1 = ps_p1.clone();
            Rc::new(move |(p0, p1): (Map<Text, crate::check::shrink::Rel>, Nat)| {
                let ps_p1 = ps_p1.clone();
                entered(once_job(move || {
                    let m_p2 = p0;
                    let i_p3 = p1;
                    match index(&ps_p1, &i_p3) {
                        Some(p_p4) => match &*p_p4.kind {
                            crate::syntax::PatternKind::PName(n_p5) => prism_rtl::Turn::Finished(insert(&m_p2, &crate::check::env::sname_key(n_p5), &crate::check::shrink::Rel { param: i_p3.clone(), strict: false })),
                            _ => call_then(crate::check::env::names::start_pattern_names(p_p4.clone()), move |pattern_names_13573: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_13573, &m_p2, &(|m2_p6: &Map<Text, crate::check::shrink::Rel>, n_p7: &Text| insert(m2_p6, n_p7, &crate::check::shrink::Rel { param: i_p3.clone(), strict: true }))))),
                        },
                        None => prism_rtl::Turn::Finished(m_p2.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, crate::check::shrink::Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>>>
        }).cycle())
    }
}

/// `Start ParamRelsOn, x`: what the function value is when passed to `@Run`.
pub fn start_param_rels_on(base_p0: Map<Text, crate::check::shrink::Rel>, ps_p1: Array<crate::syntax::Pattern_>) -> Rc<dyn prism_rtl::Job<Map<Text, crate::check::shrink::Rel>>> {
    Rc::new(ParamRelsOn { base_p0, ps_p1 })
}
