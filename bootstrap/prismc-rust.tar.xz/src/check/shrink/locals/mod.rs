//! The module `Check.Shrink.Locals`, from `target/bootstrap/src/prismc/check/shrink/locals.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
/// ```
pub fn with_locals_f(sk_p0: &crate::check::shrink::Shrink, found_p1: &crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>) -> crate::check::shrink::Shrink {
    let (bases_pm, owners_pn, clauses_po, wdecls_pp) = crate::prelude::fold(found_p1, &(crate::prelude::Map::new(), crate::prelude::Map::new(), crate::prelude::Map::new(), crate::prelude::Map::new()), &(|(bs_p5, os_p6, cs_p7, ws_p8): &(crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::syntax::decls::FnClause>>, crate::prelude::Map<crate::prelude::Text, (crate::check::env::Def, crate::syntax::decls::WidgetDecl)>), (d_p9, gk_pa, n_pb, m_pc, c_od, w_oe): &(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)| {
        let qk_pf = local_key_f(n_pb, &d_p9.qk_p, gk_pa);
        let bs2_pg = if crate::check::env::has_key_f(bs_p5, &qk_pf) {
            bs_p5.clone()
        } else {
            crate::prelude::insert(bs_p5, &qk_pf, &crate::check::shrink::summaries::marks_f(m_pc))
        };
        let os2_ph = crate::prelude::insert(os_p6, &qk_pf, &d_p9.qk_p);
        let cs2_pi = match c_od {
            ::std::option::Option::Some(c_pk) => crate::prelude::insert(cs_p7, &qk_pf, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(cs_p7, &qk_pf), &crate::prelude::Array::new()), c_pk)),
            ::std::option::Option::None => cs_p7.clone(),
        };
        let ws2_pj = match w_oe {
            ::std::option::Option::Some(w_pl) => crate::prelude::insert(ws_p8, &qk_pf, &(d_p9.clone(), w_pl.clone())),
            ::std::option::Option::None => ws_p8.clone(),
        };
        (bs2_pg.clone(), os2_ph.clone(), cs2_pi.clone(), ws2_pj.clone())
    }));
    let fn_defs_p2 = crate::prelude::fold(&crate::prelude::keys(&clauses_po), &crate::prelude::Array::new(), &(|acc_pq: &crate::prelude::Array<crate::check::env::Def>, qk_pr: &crate::prelude::Text| match (crate::prelude::get(&owners_pn, qk_pr), crate::prelude::get(&clauses_po, qk_pr)) {
        (::std::option::Option::Some(oq_ps), ::std::option::Option::Some(cl_pt)) => match crate::prelude::get(&sk_p0.by_key_p, &oq_ps) {
            ::std::option::Option::Some(d_pu) => crate::prelude::push(acc_pq, &crate::check::env::Def { qk_p: qk_pr.clone(), name_p: crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(qk_pr, &crate::prelude::Text::lit(" #")), &crate::prelude::Nat::from(0u32)), qk_pr), home_p: d_pu.home_p.clone(), file_p: d_pu.file_p.clone(), span_p: d_pu.span_p.clone(), body_p: crate::check::env::DefBody::DbFn(cl_pt) }),
            ::std::option::Option::None => acc_pq.clone(),
        },
        _ => acc_pq.clone(),
    }));
    let w_defs_p3 = crate::prelude::fold(&crate::prelude::keys(&wdecls_pp), &crate::prelude::Array::new(), &(|acc_pv: &crate::prelude::Array<crate::check::env::Def>, qk_p10: &crate::prelude::Text| match crate::prelude::get(&wdecls_pp, qk_p10) {
        ::std::option::Option::Some((d_p11, w_p12)) => crate::prelude::push(acc_pv, &crate::check::env::Def { qk_p: qk_p10.clone(), name_p: crate::check::env::sname_key_f(&w_p12.name_p), home_p: d_p11.home_p.clone(), file_p: d_p11.file_p.clone(), span_p: w_p12.span_p.clone(), body_p: crate::check::env::DefBody::DbWidget(w_p12.clone()) }),
        ::std::option::Option::None => acc_pv.clone(),
    }));
    let locals_p4 = crate::prelude::append(&fn_defs_p2, &w_defs_p3);
    let mut this: crate::check::shrink::Shrink = sk_p0.clone();
    this.fns_p = crate::prelude::append(&this.fns_p, &locals_p4);
    this.by_key_p = crate::prelude::fold(&locals_p4, &this.by_key_p, &(|m_p13: &crate::prelude::Map<crate::prelude::Text, crate::check::env::Def>, d_p14: &crate::check::env::Def| crate::prelude::insert(m_p13, &d_p14.qk_p, d_p14)));
    this.local_of_p = owners_pn.clone();
    this.local_base_p = bases_pm.clone();
    this
}

/// The step machine of `WithLocals`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
/// ```
pub struct WithLocals {
    pub sk_p0: crate::check::shrink::Shrink,
    pub found_p1: crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>,
}

impl ::prism_rtl::Job<crate::check::shrink::Shrink> for WithLocals {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::shrink::Shrink> {
        let sk_p0 = &self.sk_p0;
        let found_p1 = &self.found_p1;
        let (bases_pm, owners_pn, clauses_po, wdecls_pp) = crate::prelude::fold(found_p1, &(crate::prelude::Map::new(), crate::prelude::Map::new(), crate::prelude::Map::new(), crate::prelude::Map::new()), &(|(bs_p5, os_p6, cs_p7, ws_p8): &(crate::prelude::Map<crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::syntax::decls::FnClause>>, crate::prelude::Map<crate::prelude::Text, (crate::check::env::Def, crate::syntax::decls::WidgetDecl)>), (d_p9, gk_pa, n_pb, m_pc, c_od, w_oe): &(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)| {
            let qk_pf = local_key_f(n_pb, &d_p9.qk_p, gk_pa);
            let bs2_pg = if crate::check::env::has_key_f(bs_p5, &qk_pf) {
                bs_p5.clone()
            } else {
                crate::prelude::insert(bs_p5, &qk_pf, &crate::check::shrink::summaries::marks_f(m_pc))
            };
            let os2_ph = crate::prelude::insert(os_p6, &qk_pf, &d_p9.qk_p);
            let cs2_pi = match c_od {
                ::std::option::Option::Some(c_pk) => crate::prelude::insert(cs_p7, &qk_pf, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(cs_p7, &qk_pf), &crate::prelude::Array::new()), c_pk)),
                ::std::option::Option::None => cs_p7.clone(),
            };
            let ws2_pj = match w_oe {
                ::std::option::Option::Some(w_pl) => crate::prelude::insert(ws_p8, &qk_pf, &(d_p9.clone(), w_pl.clone())),
                ::std::option::Option::None => ws_p8.clone(),
            };
            (bs2_pg.clone(), os2_ph.clone(), cs2_pi.clone(), ws2_pj.clone())
        }));
        let fn_defs_p2 = crate::prelude::fold(&crate::prelude::keys(&clauses_po), &crate::prelude::Array::new(), &(|acc_pq: &crate::prelude::Array<crate::check::env::Def>, qk_pr: &crate::prelude::Text| match (crate::prelude::get(&owners_pn, qk_pr), crate::prelude::get(&clauses_po, qk_pr)) {
            (::std::option::Option::Some(oq_ps), ::std::option::Option::Some(cl_pt)) => match crate::prelude::get(&sk_p0.by_key_p, &oq_ps) {
                ::std::option::Option::Some(d_pu) => crate::prelude::push(acc_pq, &crate::check::env::Def { qk_p: qk_pr.clone(), name_p: crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(qk_pr, &crate::prelude::Text::lit(" #")), &crate::prelude::Nat::from(0u32)), qk_pr), home_p: d_pu.home_p.clone(), file_p: d_pu.file_p.clone(), span_p: d_pu.span_p.clone(), body_p: crate::check::env::DefBody::DbFn(cl_pt) }),
                ::std::option::Option::None => acc_pq.clone(),
            },
            _ => acc_pq.clone(),
        }));
        let w_defs_p3 = crate::prelude::fold(&crate::prelude::keys(&wdecls_pp), &crate::prelude::Array::new(), &(|acc_pv: &crate::prelude::Array<crate::check::env::Def>, qk_p10: &crate::prelude::Text| match crate::prelude::get(&wdecls_pp, qk_p10) {
            ::std::option::Option::Some((d_p11, w_p12)) => crate::prelude::push(acc_pv, &crate::check::env::Def { qk_p: qk_p10.clone(), name_p: crate::check::env::sname_key_f(&w_p12.name_p), home_p: d_p11.home_p.clone(), file_p: d_p11.file_p.clone(), span_p: w_p12.span_p.clone(), body_p: crate::check::env::DefBody::DbWidget(w_p12.clone()) }),
            ::std::option::Option::None => acc_pv.clone(),
        }));
        let locals_p4 = crate::prelude::append(&fn_defs_p2, &w_defs_p3);
        ::prism_rtl::Turn::Finished({
            let mut this: crate::check::shrink::Shrink = sk_p0.clone();
            this.fns_p = crate::prelude::append(&this.fns_p, &locals_p4);
            this.by_key_p = crate::prelude::fold(&locals_p4, &this.by_key_p, &(|m_p13: &crate::prelude::Map<crate::prelude::Text, crate::check::env::Def>, d_p14: &crate::check::env::Def| crate::prelude::insert(m_p13, &d_p14.qk_p, d_p14)));
            this.local_of_p = owners_pn.clone();
            this.local_base_p = bases_pm.clone();
            this
        })
    }
}

/// `Start WithLocals, x`: what the function value is when passed to `@Run`.
pub fn start_with_locals_f(sk_p0: crate::check::shrink::Shrink, found_p1: crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::shrink::Shrink>> {
    ::std::rc::Rc::new(WithLocals { sk_p0, found_p1 })
}

/// ```prism
/// LocalKey: fn Text, Text, Text -> Text
/// ```
pub fn local_key_f(n_p0: &crate::prelude::Text, owner_p1: &crate::prelude::Text, gk_p2: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{} #local {} {}", n_p0, owner_p1, gk_p2))
}

/// ```prism
/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
/// ```
pub fn def_walk_f(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def) -> (crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>) {
    let (refs_p8, locals_p9) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p1), (crate::prelude::Array::new(), crate::prelude::Array::new()), {
        let sk_p0x = sk_p0.clone();
        let d_p1x = d_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>), crate::syntax::decls::FnClause)| {
            let sk_p0xy = sk_p0x.clone();
            let d_p1xy = d_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (rs_p2, ls_p3) = p0;
                let c_p4 = p1;
                crate::prelude::call_then(start_clause_base_f(sk_p0xy.clone(), d_p1xy.clone(), c_p4.clone()), move |clause_base_f_4223: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p4.body_p.clone(), clause_base_f_4223), move |body_spots_f_4204: crate::prelude::Array<crate::check::shrink::walk::Spot>| {
                    let spots_p5 = body_spots_f_4204;
                    crate::prelude::call_then(crate::check::shrink::calls::start_spots_refs_f(sk_p0xy.clone(), d_p1xy.clone(), spots_p5.clone(), rs_p2.clone()), move |spots_refs_f_4255: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished((spots_refs_f_4255, crate::prelude::fold(&spots_p5, &ls_p3, &(|a2_p6: &crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>, sp_p7: &crate::check::shrink::walk::Spot| crate::prelude::append(a2_p6, &spot_local_f(&d_p1xy, sp_p7)))))))
                }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>), crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>)>>>
    }));
    (d_p1.qk_p.clone(), refs_p8.clone(), locals_p9.clone())
}

/// The step machine of `DefWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
/// ```
pub struct DefWalk {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>)> for DefWalk {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>)> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let d_p1x = d_p1.clone();
        let sk_p0x = sk_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(&d_p1x), (crate::prelude::Array::new(), crate::prelude::Array::new()), {
            let sk_p0xx = sk_p0x.clone();
            let d_p1xx = d_p1x.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>), crate::syntax::decls::FnClause)| {
                let sk_p0xxy = sk_p0xx.clone();
                let d_p1xxy = d_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (rs_p2, ls_p3) = p0;
                    let c_p4 = p1;
                    crate::prelude::call_then(start_clause_base_f(sk_p0xxy.clone(), d_p1xxy.clone(), c_p4.clone()), move |clause_base_f_4223: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p4.body_p.clone(), clause_base_f_4223), move |body_spots_f_4204: crate::prelude::Array<crate::check::shrink::walk::Spot>| {
                        let spots_p5 = body_spots_f_4204;
                        crate::prelude::call_then(crate::check::shrink::calls::start_spots_refs_f(sk_p0xxy.clone(), d_p1xxy.clone(), spots_p5.clone(), rs_p2.clone()), move |spots_refs_f_4255: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished((spots_refs_f_4255, crate::prelude::fold(&spots_p5, &ls_p3, &(|a2_p6: &crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>, sp_p7: &crate::check::shrink::walk::Spot| crate::prelude::append(a2_p6, &spot_local_f(&d_p1xxy, sp_p7)))))))
                    }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>), crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>)>>>
        }), move |fold_4130: (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>)| {
            let (refs_p8, locals_p9) = fold_4130;
            ::prism_rtl::Turn::Finished((d_p1x.qk_p.clone(), refs_p8.clone(), locals_p9.clone()))
        })
    }
}

/// `Start DefWalk, x`: what the function value is when passed to `@Run`.
pub fn start_def_walk_f(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)>)>> {
    ::std::rc::Rc::new(DefWalk { sk_p0, d_p1 })
}

/// ```prism
/// SpotLocal: fn Def, Spot -> [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]
/// ```
pub fn spot_local_f(d_p0: &crate::check::env::Def, sp_p1: &crate::check::shrink::walk::Spot) -> crate::prelude::Array<(crate::check::env::Def, crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ::std::option::Option<crate::syntax::decls::FnClause>, ::std::option::Option<crate::syntax::decls::WidgetDecl>)> {
    match sp_p1 {
        crate::check::shrink::walk::Spot::SpotStmt(s_p2, m_p3) => match &s_p2.kind_p {
            crate::syntax::StmtKind::SFn(f_p4) => {
                let n_p5 = crate::check::env::def_name_text_f(&f_p4.name_p);
                match crate::prelude::get(m_p3, &crate::prelude::Text::from(format!("lfn:{}", &n_p5))) {
                    ::std::option::Option::Some(r_p6) => crate::prelude::Array::from(vec![(d_p0.clone(), crate::prelude::Text::from(format!("{}.{}", &d_p0.file_p, &r_p6.param_p)), n_p5.clone(), m_p3.clone(), ::std::option::Option::Some(f_p4.clone()), ::std::option::Option::None)]),
                    ::std::option::Option::None => crate::prelude::Array::new(),
                }
            },
            crate::syntax::StmtKind::SWidget(w_p7) => {
                let n_p8 = crate::check::env::sname_key_f(&w_p7.name_p);
                match crate::prelude::get(m_p3, &crate::prelude::Text::from(format!("lfn:{}", &n_p8))) {
                    ::std::option::Option::Some(r_p9) => crate::prelude::Array::from(vec![(d_p0.clone(), crate::prelude::Text::from(format!("{}.{}", &d_p0.file_p, &r_p9.param_p)), n_p8.clone(), m_p3.clone(), ::std::option::Option::None, ::std::option::Option::Some(w_p7.clone()))]),
                    ::std::option::Option::None => crate::prelude::Array::new(),
                }
            },
            _ => crate::prelude::Array::new(),
        },
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// ?LocalTarget: fn Shrink, Def, Site -> ?Text
/// ```
pub fn local_target_o(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, site_p2: &crate::check::shrink::walk::Site) -> ::std::option::Option<crate::prelude::Text> {
    match crate::prelude::get(&site_p2.rels_p, &crate::prelude::Text::from(format!("lfn:{}", &site_p2.callee_p))) {
        ::std::option::Option::Some(r_p3) => ::std::option::Option::Some(local_key_f(&site_p2.callee_p, &crate::prelude::or(&crate::prelude::get(&sk_p0.local_of_p, &d_p1.qk_p), &d_p1.qk_p), &crate::prelude::Text::from(format!("{}.{}", &d_p1.file_p, &r_p3.param_p)))),
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
/// ```
pub fn clause_base_f(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, c_p2: &crate::syntax::decls::FnClause) -> crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel> {
    let base_p3 = match crate::prelude::get(&sk_p0.local_base_p, &d_p1.qk_p) {
        ::std::option::Option::Some(b_p4) => param_rels_on_f(&b_p4, &c_p2.params_p),
        ::std::option::Option::None => param_rels_on_f(&crate::prelude::insert(&crate::prelude::or(&crate::prelude::get(&sk_p0.seeds_p, &d_p1.home_p), &crate::prelude::Map::new()), &crate::prelude::Text::lit("file:"), &crate::check::shrink::Rel { param_p: d_p1.file_p.clone(), strict_p: false }), &c_p2.params_p),
    };
    non_empty_params_f(sk_p0, d_p1, c_p2, &base_p3)
}

/// The step machine of `ClauseBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
/// ```
pub struct ClauseBase {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub c_p2: crate::syntax::decls::FnClause,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>> for ClauseBase {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let c_p2 = &self.c_p2;
        let c_p2z = c_p2.clone();
        let d_p1z = d_p1.clone();
        let sk_p0z = sk_p0.clone();
        let k_let5399 = move |v5399: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
            let base_p3 = v5399;
            ::prism_rtl::Turn::Finished(non_empty_params_f(&sk_p0z, &d_p1z, &c_p2z, &base_p3))
        };
        match crate::prelude::get(&sk_p0.local_base_p, &d_p1.qk_p) {
            ::std::option::Option::Some(b_p4) => {
                let c_p2x = c_p2.clone();
                crate::prelude::call_then(start_param_rels_on_f(b_p4.clone(), c_p2x.params_p.clone()), move |param_rels_on_f_5449: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| k_let5399(param_rels_on_f_5449))
            },
            ::std::option::Option::None => {
                let c_p2x = c_p2.clone();
                let d_p1x = d_p1.clone();
                let sk_p0x = sk_p0.clone();
                crate::prelude::call_then(start_param_rels_on_f(crate::prelude::insert(&crate::prelude::or(&crate::prelude::get(&sk_p0x.seeds_p, &d_p1x.home_p), &crate::prelude::Map::new()), &crate::prelude::Text::lit("file:"), &crate::check::shrink::Rel { param_p: d_p1x.file_p.clone(), strict_p: false }), c_p2x.params_p.clone()), move |param_rels_on_f_5486: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| k_let5399(param_rels_on_f_5486))
            },
        }
    }
}

/// `Start ClauseBase, x`: what the function value is when passed to `@Run`.
pub fn start_clause_base_f(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, c_p2: crate::syntax::decls::FnClause) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>> {
    ::std::rc::Rc::new(ClauseBase { sk_p0, d_p1, c_p2 })
}

/// ```prism
/// NonEmptyParams: fn Shrink, Def, FnClause, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn non_empty_params_f(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, c_p2: &crate::syntax::decls::FnClause, base_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>) -> crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel> {
    match crate::prelude::get(&sk_p0.g_p.vals_p, &d_p1.qk_p) {
        ::std::option::Option::Some(v_p4) => match &v_p4.scheme_p.ty_p {
            crate::check::types::Ty::TyFn(_, declared_p5, _) => crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p2.params_p)), base_p3, &(|m_p6: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, i_p7: &crate::prelude::Nat| match (crate::prelude::index(&c_p2.params_p, i_p7), crate::prelude::index(declared_p5, i_p7)) {
                (::std::option::Option::Some(p_p8), ::std::option::Option::Some(crate::check::types::Ty::TyCon(m6057_0_1_0, _))) if (&m6057_0_1_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) => match &*p_p8.kind_p {
                    crate::syntax::PatternKind::PName(n_p9) => crate::prelude::insert(m_p6, &crate::prelude::Text::from(format!("ne:{}", &crate::check::env::sname_key_f(n_p9))), &crate::check::shrink::relations::no_rel_p()),
                    _ => m_p6.clone(),
                },
                _ => m_p6.clone(),
                _ => unreachable!("no arm matched"),
            })),
            _ => base_p3.clone(),
        },
        ::std::option::Option::None => base_p3.clone(),
    }
}

/// ```prism
/// ?ResolveCallee: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_callee_o(g_p0: &crate::check::env::G, m_p1: &crate::prelude::Text, n_p2: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Text> {
    if is_op_text_f(n_p2) {
        resolve_op_o(g_p0, m_p1, n_p2)
    } else {
        match resolve_name_o(g_p0, m_p1, n_p2) {
            ::std::option::Option::Some(k_p3) => ::std::option::Option::Some(k_p3),
            ::std::option::Option::None => if crate::syntax::lexer::chars::has_prefix_f(n_p2, &crate::prelude::Text::lit("@")) {
                resolve_name_o(g_p0, m_p1, &crate::syntax::lexer::chars::after_first_f(n_p2))
            } else {
                ::std::option::Option::None
            },
        }
    }
}

/// ```prism
/// ?ResolveOp: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_op_o(g_p0: &crate::check::env::G, m_p1: &crate::prelude::Text, op_p2: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Text> {
    let (k_o3, _) = crate::check::env::names::resolve_value_f(g_p0, m_p1, &crate::syntax::SName { sigils_p: crate::prelude::Text::lit(""), path_p: crate::prelude::Array::from(vec![op_p2.clone()]), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } });
    k_o3.clone()
}

/// ```prism
/// IsOpText: fn Text -> Bool
/// ```
pub fn is_op_text_f(n_p0: &crate::prelude::Text) -> bool {
    (&crate::prelude::len_text(n_p0) > &crate::prelude::Nat::from(0u32)) && !crate::syntax::lexer::chars::fold_chars_f(n_p0, &false, &(::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Text)| crate::prelude::once_job(move || {
        let seen_p1 = p0;
        let ch_p2 = p1;
        ::prism_rtl::Turn::Finished(((seen_p1 || crate::syntax::lexer::chars::is_upper_f(&ch_p2)) || crate::syntax::lexer::chars::is_lower_f(&ch_p2)) || (&ch_p2 == &crate::prelude::Text::lit("_")))
    })) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>))
}

/// ```prism
/// ?ResolveName: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_name_o(g_p0: &crate::check::env::G, m_p1: &crate::prelude::Text, n_p2: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Text> {
    let marks_p3 = crate::check::types::unify::marks_of_f(n_p2);
    let path_p4 = crate::prelude::split_on(&crate::syntax::lexer::chars::drop_prefix_f(n_p2, &marks_p3), &crate::prelude::Text::lit("."));
    let (k_o5, _) = crate::check::env::names::resolve_value_f(g_p0, m_p1, &crate::syntax::SName { sigils_p: marks_p3.clone(), path_p: path_p4.clone(), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } });
    k_o5.clone()
}

/// ```prism
/// NamesInStmt: unbounded fn Stmt -> [Text]
/// ```
pub fn names_in_stmt_f(s_p0: &crate::syntax::Stmt) -> crate::prelude::Array<crate::prelude::Text> {
    crate::check::shrink::walk::spots_names_f(&crate::check::shrink::walk::stmt_spots_f(s_p0, &crate::prelude::Map::new()))
}

/// The step machine of `NamesInStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamesInStmt: unbounded fn Stmt -> [Text]
/// ```
pub struct NamesInStmt {
    pub s_p0: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for NamesInStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let s_p0 = &self.s_p0;
        let s_p0x = s_p0.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_stmt_spots_f(s_p0x.clone(), crate::prelude::Map::new()), move |stmt_spots_f_7483: crate::prelude::Array<crate::check::shrink::walk::Spot>| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::shrink::walk::SpotsNames { spots_p0: stmt_spots_f_7483 })))
    }
}

/// `Start NamesInStmt, x`: what the function value is when passed to `@Run`.
pub fn start_names_in_stmt_f(s_p0: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(NamesInStmt { s_p0 })
}

/// ```prism
/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
/// ```
pub fn sccs_f(keys_p0: &crate::prelude::Array<crate::prelude::Text>, refs_p1: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>) -> crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>> {
    let adj_p2 = crate::prelude::fold(refs_p1, &crate::prelude::Map::new(), &(|m_p4: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, (k_p5, rs_p6): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| crate::prelude::insert(m_p4, k_p5, rs_p6)));
    let rev_p3 = crate::prelude::fold(refs_p1, &crate::prelude::Map::new(), &(|m_p7: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, (k_p8, rs_p9): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| crate::prelude::fold(rs_p9, m_p7, &(|m2_pa: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, r_pb: &crate::prelude::Text| crate::prelude::insert(m2_pa, r_pb, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m2_pa, r_pb), &crate::prelude::Array::new()), k_p8))))));
    let (_, post_pf) = crate::prelude::run_to_end(crate::prelude::fold_job(keys_p0.clone(), (crate::prelude::Map::new(), crate::prelude::Array::new()), {
        let adj_p2x = adj_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>), crate::prelude::Text)| {
            let adj_p2xy = adj_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (seen_pc, out_pd) = p0;
                let k_pe = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(PostVisit { adj_p0: adj_p2xy.clone(), seen_p1: seen_pc.clone(), out_p2: out_pd.clone(), k_p3: k_pe.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)>>>
    }));
    let (ignore2_pl, comps_pm) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::types::reverse2_f(&post_pf), (crate::prelude::Map::new(), crate::prelude::Array::new()), {
        let rev_p3x = rev_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>), crate::prelude::Text)| {
            let rev_p3xy = rev_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (seen_pg, acc_ph) = p0;
                let k_pi = p1;
                if crate::check::env::has_key_f(&seen_pg, &k_pi) {
                    ::prism_rtl::Turn::Finished((seen_pg.clone(), acc_ph.clone()))
                } else {
                    crate::prelude::call_then(start_collect_f(rev_p3xy.clone(), seen_pg.clone(), crate::prelude::Array::new(), k_pi.clone()), move |collect_f_8325: (crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)| {
                        let (seen2_pj, comp_pk) = collect_f_8325;
                        ::prism_rtl::Turn::Finished((seen2_pj.clone(), crate::prelude::push(&acc_ph, &comp_pk)))
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>)>>>
    }));
    crate::prelude::filter(&comps_pm, &(|c_pn: &crate::prelude::Array<crate::prelude::Text>| (&crate::prelude::len(c_pn) > &crate::prelude::Nat::from(1u32)) || crate::prelude::fold(c_pn, &false, &(|self_po: &bool, k_pp: &crate::prelude::Text| *self_po || crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::get(&adj_p2, k_pp), &crate::prelude::Array::new()), k_pp)))))
}

/// The step machine of `Sccs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
/// ```
pub struct Sccs {
    pub keys_p0: crate::prelude::Array<crate::prelude::Text>,
    pub refs_p1: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>> for Sccs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>> {
        let keys_p0 = &self.keys_p0;
        let refs_p1 = &self.refs_p1;
        let adj_p2 = crate::prelude::fold(refs_p1, &crate::prelude::Map::new(), &(|m_p4: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, (k_p5, rs_p6): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| crate::prelude::insert(m_p4, k_p5, rs_p6)));
        let rev_p3 = crate::prelude::fold(refs_p1, &crate::prelude::Map::new(), &(|m_p7: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, (k_p8, rs_p9): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| crate::prelude::fold(rs_p9, m_p7, &(|m2_pa: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, r_pb: &crate::prelude::Text| crate::prelude::insert(m2_pa, r_pb, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m2_pa, r_pb), &crate::prelude::Array::new()), k_p8))))));
        let keys_p0x = keys_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(keys_p0x.clone(), (crate::prelude::Map::new(), crate::prelude::Array::new()), {
            let adj_p2x = adj_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>), crate::prelude::Text)| {
                let adj_p2xy = adj_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (seen_pc, out_pd) = p0;
                    let k_pe = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(PostVisit { adj_p0: adj_p2xy.clone(), seen_p1: seen_pc.clone(), out_p2: out_pd.clone(), k_p3: k_pe.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)>>>
        }), move |fold_8078: (crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)| {
            let (_, post_pf) = fold_8078;
            crate::prelude::call_value(crate::prelude::fold_job(crate::check::types::reverse2_f(&post_pf), (crate::prelude::Map::new(), crate::prelude::Array::new()), {
                let rev_p3x = rev_p3.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>), crate::prelude::Text)| {
                    let rev_p3xy = rev_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (seen_pg, acc_ph) = p0;
                        let k_pi = p1;
                        if crate::check::env::has_key_f(&seen_pg, &k_pi) {
                            ::prism_rtl::Turn::Finished((seen_pg.clone(), acc_ph.clone()))
                        } else {
                            crate::prelude::call_then(start_collect_f(rev_p3xy.clone(), seen_pg.clone(), crate::prelude::Array::new(), k_pi.clone()), move |collect_f_8325: (crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)| {
                                let (seen2_pj, comp_pk) = collect_f_8325;
                                ::prism_rtl::Turn::Finished((seen2_pj.clone(), crate::prelude::push(&acc_ph, &comp_pk)))
                            })
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>)>>>
            }), move |fold_8180: (crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>)| {
                let (ignore2_pl, comps_pm) = fold_8180;
                ::prism_rtl::Turn::Finished(crate::prelude::filter(&comps_pm, &(|c_pn: &crate::prelude::Array<crate::prelude::Text>| (&crate::prelude::len(c_pn) > &crate::prelude::Nat::from(1u32)) || crate::prelude::fold(c_pn, &false, &(|self_po: &bool, k_pp: &crate::prelude::Text| *self_po || crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::get(&adj_p2, k_pp), &crate::prelude::Array::new()), k_pp))))))
            })
        })
    }
}

/// `Start Sccs, x`: what the function value is when passed to `@Run`.
pub fn start_sccs_f(keys_p0: crate::prelude::Array<crate::prelude::Text>, refs_p1: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>>> {
    ::std::rc::Rc::new(Sccs { keys_p0, refs_p1 })
}

/// ```prism
/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub fn post_visit_f(adj_p0: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, seen_p1: &crate::prelude::Map<crate::prelude::Text, bool>, out_p2: &crate::prelude::Array<crate::prelude::Text>, k_p3: &crate::prelude::Text) -> (crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>) {
    if crate::check::env::has_key_f(seen_p1, k_p3) {
        (seen_p1.clone(), out_p2.clone())
    } else {
        {
            let (seen2_p7, out2_p8) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(adj_p0, k_p3), &crate::prelude::Array::new()), (crate::prelude::insert(seen_p1, k_p3, &true), out_p2.clone()), {
                let adj_p0x = adj_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>), crate::prelude::Text)| {
                    let adj_p0xy = adj_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (s_p4, o_p5) = p0;
                        let n_p6 = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(PostVisit { adj_p0: adj_p0xy.clone(), seen_p1: s_p4.clone(), out_p2: o_p5.clone(), k_p3: n_p6.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)>>>
            }));
            (seen2_p7.clone(), crate::prelude::push(&out2_p8, k_p3))
        }
    }
}

/// The step machine of `PostVisit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub struct PostVisit {
    pub adj_p0: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>,
    pub seen_p1: crate::prelude::Map<crate::prelude::Text, bool>,
    pub out_p2: crate::prelude::Array<crate::prelude::Text>,
    pub k_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)> for PostVisit {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)> {
        let adj_p0 = &self.adj_p0;
        let seen_p1 = &self.seen_p1;
        let out_p2 = &self.out_p2;
        let k_p3 = &self.k_p3;
        if crate::check::env::has_key_f(seen_p1, k_p3) {
            ::prism_rtl::Turn::Finished((seen_p1.clone(), out_p2.clone()))
        } else {
            {
                let adj_p0x = adj_p0.clone();
                let k_p3x = k_p3.clone();
                let out_p2x = out_p2.clone();
                let seen_p1x = seen_p1.clone();
                crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&adj_p0x, &k_p3x), &crate::prelude::Array::new()), (crate::prelude::insert(&seen_p1x, &k_p3x, &true), out_p2x.clone()), {
                    let adj_p0xx = adj_p0x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>), crate::prelude::Text)| {
                        let adj_p0xxy = adj_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (s_p4, o_p5) = p0;
                            let n_p6 = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(PostVisit { adj_p0: adj_p0xxy.clone(), seen_p1: s_p4.clone(), out_p2: o_p5.clone(), k_p3: n_p6.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)>>>
                }), move |fold_8709: (crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)| {
                    let (seen2_p7, out2_p8) = fold_8709;
                    ::prism_rtl::Turn::Finished((seen2_p7.clone(), crate::prelude::push(&out2_p8, &k_p3x)))
                })
            }
        }
    }
}

/// `Start PostVisit, x`: what the function value is when passed to `@Run`.
pub fn start_post_visit_f(adj_p0: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, seen_p1: crate::prelude::Map<crate::prelude::Text, bool>, out_p2: crate::prelude::Array<crate::prelude::Text>, k_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)>> {
    ::std::rc::Rc::new(PostVisit { adj_p0, seen_p1, out_p2, k_p3 })
}

/// ```prism
/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub fn collect_f(rev_p0: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, seen_p1: &crate::prelude::Map<crate::prelude::Text, bool>, comp_p2: &crate::prelude::Array<crate::prelude::Text>, k_p3: &crate::prelude::Text) -> (crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>) {
    if crate::check::env::has_key_f(seen_p1, k_p3) {
        (seen_p1.clone(), comp_p2.clone())
    } else {
        crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(rev_p0, k_p3), &crate::prelude::Array::new()), (crate::prelude::insert(seen_p1, k_p3, &true), crate::prelude::push(comp_p2, k_p3)), {
            let rev_p0x = rev_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>), crate::prelude::Text)| {
                let rev_p0xy = rev_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (s_p4, c_p5) = p0;
                    let n_p6 = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Collect { rev_p0: rev_p0xy.clone(), seen_p1: s_p4.clone(), comp_p2: c_p5.clone(), k_p3: n_p6.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)>>>
        }))
    }
}

/// The step machine of `Collect`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub struct Collect {
    pub rev_p0: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>,
    pub seen_p1: crate::prelude::Map<crate::prelude::Text, bool>,
    pub comp_p2: crate::prelude::Array<crate::prelude::Text>,
    pub k_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)> for Collect {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)> {
        let rev_p0 = &self.rev_p0;
        let seen_p1 = &self.seen_p1;
        let comp_p2 = &self.comp_p2;
        let k_p3 = &self.k_p3;
        if crate::check::env::has_key_f(seen_p1, k_p3) {
            ::prism_rtl::Turn::Finished((seen_p1.clone(), comp_p2.clone()))
        } else {
            crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(rev_p0, k_p3), &crate::prelude::Array::new()), (crate::prelude::insert(seen_p1, k_p3, &true), crate::prelude::push(comp_p2, k_p3)), {
                let rev_p0x = rev_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>), crate::prelude::Text)| {
                    let rev_p0xy = rev_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (s_p4, c_p5) = p0;
                        let n_p6 = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Collect { rev_p0: rev_p0xy.clone(), seen_p1: s_p4.clone(), comp_p2: c_p5.clone(), k_p3: n_p6.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)>>>
            }).cycle()
        }
    }
}

/// `Start Collect, x`: what the function value is when passed to `@Run`.
pub fn start_collect_f(rev_p0: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, seen_p1: crate::prelude::Map<crate::prelude::Text, bool>, comp_p2: crate::prelude::Array<crate::prelude::Text>, k_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, bool>, crate::prelude::Array<crate::prelude::Text>)>> {
    ::std::rc::Rc::new(Collect { rev_p0, seen_p1, comp_p2, k_p3 })
}

/// ```prism
/// UnsignedOnCycle: unbounded fn Shrink, St, [Text] -> St
/// ```
pub fn unsigned_on_cycle_f(sk_p0: &crate::check::shrink::Shrink, st_p1: &crate::check::types::St, comp_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::check::types::St {
    crate::prelude::fold(comp_p2, st_p1, &(|s_p3: &crate::check::types::St, k_p4: &crate::prelude::Text| match (crate::prelude::get(&sk_p0.by_key_p, k_p4), crate::syntax::lexer::chars::last_o(&crate::prelude::split_on(k_p4, &crate::prelude::Text::lit(" ")))) {
        (::std::option::Option::Some(d_p5), ::std::option::Option::Some(place_p6)) if (crate::syntax::lexer::chars::contains_f(k_p4, &crate::prelude::Text::lit(" #local ")) && crate::check::types::has_text_f(&st_p1.unsigned_fns_p, &place_p6)) => match &d_p5.body_p {
            crate::check::env::DefBody::DbFn(clauses_p7) => match crate::prelude::index(clauses_p7, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(first_p8) => {
                    let others_p9 = crate::prelude::filter(comp_p2, &(|other_pc: &crate::prelude::Text| other_pc != k_p4));
                    let how_pa = if &crate::prelude::len(&others_p9) == &crate::prelude::Nat::from(0u32) {
                        crate::prelude::Text::lit("calls itself")
                    } else {
                        crate::prelude::Text::from(format!("calls itself through {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&others_p9, &(|other_pd: &crate::prelude::Text| crate::prelude::Text::from(format!("`{}`", &crate::check::shrink::types::shown_key_f(other_pd))))), &crate::prelude::Text::lit(", "))))
                    };
                    let s2_pb = crate::check::types::recording::err_fix_f(&crate::check::env::traits::with_file_f(s_p3, &d_p5.file_p), &crate::prelude::Text::lit("no-signature"), &first_p8.span_p, &crate::prelude::Text::from(format!("`{}` {} and has no signature line: a block\'s function that calls itself needs one, as a top-level function does", &crate::check::shrink::types::shown_key_f(k_p4), &how_pa)), &crate::prelude::Text::from(format!("write `{}: fn ... -> ...` above it, in its block", &crate::check::shrink::types::shown_key_f(k_p4))));
                    crate::check::env::traits::with_file_f(&s2_pb, &s_p3.file_p)
                },
                ::std::option::Option::None => s_p3.clone(),
            },
            _ => s_p3.clone(),
        },
        _ => s_p3.clone(),
        _ => unreachable!("no arm matched"),
    }))
}

/// The step machine of `UnsignedOnCycle`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnsignedOnCycle: unbounded fn Shrink, St, [Text] -> St
/// ```
pub struct UnsignedOnCycle {
    pub sk_p0: crate::check::shrink::Shrink,
    pub st_p1: crate::check::types::St,
    pub comp_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::check::types::St> for UnsignedOnCycle {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let sk_p0 = &self.sk_p0;
        let st_p1 = &self.st_p1;
        let comp_p2 = &self.comp_p2;
        ::prism_rtl::Turn::Finished(crate::prelude::fold(comp_p2, st_p1, &(|s_p3: &crate::check::types::St, k_p4: &crate::prelude::Text| match (crate::prelude::get(&sk_p0.by_key_p, k_p4), crate::syntax::lexer::chars::last_o(&crate::prelude::split_on(k_p4, &crate::prelude::Text::lit(" ")))) {
            (::std::option::Option::Some(d_p5), ::std::option::Option::Some(place_p6)) if (crate::syntax::lexer::chars::contains_f(k_p4, &crate::prelude::Text::lit(" #local ")) && crate::check::types::has_text_f(&st_p1.unsigned_fns_p, &place_p6)) => match &d_p5.body_p {
                crate::check::env::DefBody::DbFn(clauses_p7) => match crate::prelude::index(clauses_p7, &crate::prelude::Nat::from(0u32)) {
                    ::std::option::Option::Some(first_p8) => {
                        let others_p9 = crate::prelude::filter(comp_p2, &(|other_pc: &crate::prelude::Text| other_pc != k_p4));
                        let how_pa = if &crate::prelude::len(&others_p9) == &crate::prelude::Nat::from(0u32) {
                            crate::prelude::Text::lit("calls itself")
                        } else {
                            crate::prelude::Text::from(format!("calls itself through {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&others_p9, &(|other_pd: &crate::prelude::Text| crate::prelude::Text::from(format!("`{}`", &crate::check::shrink::types::shown_key_f(other_pd))))), &crate::prelude::Text::lit(", "))))
                        };
                        let s2_pb = crate::check::types::recording::err_fix_f(&crate::check::env::traits::with_file_f(s_p3, &d_p5.file_p), &crate::prelude::Text::lit("no-signature"), &first_p8.span_p, &crate::prelude::Text::from(format!("`{}` {} and has no signature line: a block\'s function that calls itself needs one, as a top-level function does", &crate::check::shrink::types::shown_key_f(k_p4), &how_pa)), &crate::prelude::Text::from(format!("write `{}: fn ... -> ...` above it, in its block", &crate::check::shrink::types::shown_key_f(k_p4))));
                        crate::check::env::traits::with_file_f(&s2_pb, &s_p3.file_p)
                    },
                    ::std::option::Option::None => s_p3.clone(),
                },
                _ => s_p3.clone(),
            },
            _ => s_p3.clone(),
            _ => unreachable!("no arm matched"),
        })))
    }
}

/// `Start UnsignedOnCycle, x`: what the function value is when passed to `@Run`.
pub fn start_unsigned_on_cycle_f(sk_p0: crate::check::shrink::Shrink, st_p1: crate::check::types::St, comp_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(UnsignedOnCycle { sk_p0, st_p1, comp_p2 })
}

/// ```prism
/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
/// ```
pub fn shrink_component_f(sk_p0: &crate::check::shrink::Shrink, st0_p1: &crate::check::types::St, comp_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::check::types::St {
    let st_p3 = unsigned_on_cycle_f(sk_p0, st0_p1, comp_p2);
    if &crate::prelude::len(&st_p3.diags_p) > &crate::prelude::len(&st0_p1.diags_p) {
        st_p3.clone()
    } else {
        if crate::prelude::fold(comp_p2, &true, &(|ok_p4: &bool, k_p5: &crate::prelude::Text| *ok_p4 && crate::check::shrink::types::is_unbounded_key_f(&sk_p0.g_p, &crate::check::shrink::types::sig_key_of_f(sk_p0, &crate::prelude::or(&crate::prelude::get(&sk_p0.local_of_p, k_p5), k_p5))))) {
            st_p3.clone()
        } else {
            {
                let graphs_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(sk_p0.fns_p.clone(), crate::prelude::Array::new(), {
                    let comp_p2x = comp_p2.clone();
                    let sk_p0x = sk_p0.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::Sc>, crate::check::env::Def)| {
                        let comp_p2xy = comp_p2x.clone();
                        let sk_p0xy = sk_p0x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_p9 = p0;
                            let d_pa = p1;
                            if crate::check::types::has_text_f(&comp_p2xy, &d_pa.qk_p) {
                                crate::prelude::call_then(start_call_graphs_f(sk_p0xy.clone(), d_pa.clone(), comp_p2xy.clone()), move |call_graphs_f_11012: crate::prelude::Array<crate::check::shrink::Sc>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p9, &call_graphs_f_11012)))
                            } else {
                                ::prism_rtl::Turn::Finished(acc_p9.clone())
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::Sc>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>>>>
                }));
                let closure_p7 = crate::check::shrink::summaries::closure_f(&graphs_p6);
                let bad_p8 = crate::prelude::filter(&closure_p7, &(|sc_pb: &crate::check::shrink::Sc| ((&sc_pb.caller_p == &sc_pb.callee_p) && (&crate::check::shrink::summaries::compose_f(sc_pb, sc_pb).edges_p == &sc_pb.edges_p)) && !crate::prelude::fold(&sc_pb.edges_p, &false, &(|seen_pc: &bool, (a_pd, b_pe, s_pf): &(crate::prelude::Nat, crate::prelude::Nat, bool)| *seen_pc || ((a_pd == b_pe) && *s_pf)))));
                match crate::prelude::index(&bad_p8, &crate::prelude::Nat::from(0u32)) {
                    ::std::option::Option::Some(sc_pg) => {
                        let s2_ph = {
                            let mut this: crate::check::types::St = st_p3.clone();
                            this.file_p = sc_pg.file_p.clone();
                            this
                        };
                        let what_pi = if &sc_pg.arg_p == &crate::prelude::Text::lit("") {
                            crate::prelude::Text::lit("")
                        } else {
                            crate::prelude::Text::from(format!(" on `{}`", &sc_pg.arg_p))
                        };
                        let st3_pj = crate::check::types::recording::err_fix_f(&s2_ph, &crate::prelude::Text::lit("may-not-end"), &sc_pg.span_p, &crate::prelude::Text::from(format!("`{}` calls {}{}, not smaller than what it was given", &crate::check::shrink::types::shown_key_f(&sc_pg.caller_p), &(if &sc_pg.caller_p == &sc_pg.callee_p {
                            crate::prelude::Text::lit("itself")
                        } else {
                            crate::prelude::Text::from(format!("`{}`", &crate::check::shrink::types::shown_key_f(&sc_pg.callee_p)))
                        }), &what_pi)), &crate::prelude::Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle\'s functions `unbounded fn`"));
                        {
                            let mut this: crate::check::types::St = st3_pj.clone();
                            this.file_p = st_p3.file_p.clone();
                            this
                        }
                    },
                    ::std::option::Option::None => st_p3.clone(),
                }
            }
        }
    }
}

/// The step machine of `ShrinkComponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
/// ```
pub struct ShrinkComponent {
    pub sk_p0: crate::check::shrink::Shrink,
    pub st0_p1: crate::check::types::St,
    pub comp_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::check::types::St> for ShrinkComponent {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let sk_p0 = &self.sk_p0;
        let st0_p1 = &self.st0_p1;
        let comp_p2 = &self.comp_p2;
        let comp_p2x = comp_p2.clone();
        let sk_p0x = sk_p0.clone();
        let st0_p1x = st0_p1.clone();
        crate::prelude::call_then(start_unsigned_on_cycle_f(sk_p0x.clone(), st0_p1x.clone(), comp_p2x.clone()), move |unsigned_on_cycle_f_10734: crate::check::types::St| {
            let st_p3 = unsigned_on_cycle_f_10734;
            if &crate::prelude::len(&st_p3.diags_p) > &crate::prelude::len(&st0_p1x.diags_p) {
                ::prism_rtl::Turn::Finished(st_p3.clone())
            } else {
                if crate::prelude::fold(&comp_p2x, &true, &(|ok_p4: &bool, k_p5: &crate::prelude::Text| *ok_p4 && crate::check::shrink::types::is_unbounded_key_f(&sk_p0x.g_p, &crate::check::shrink::types::sig_key_of_f(&sk_p0x, &crate::prelude::or(&crate::prelude::get(&sk_p0x.local_of_p, k_p5), k_p5))))) {
                    ::prism_rtl::Turn::Finished(st_p3.clone())
                } else {
                    crate::prelude::call_value(crate::prelude::fold_job(sk_p0x.fns_p.clone(), crate::prelude::Array::new(), {
                        let comp_p2xx = comp_p2x.clone();
                        let sk_p0xx = sk_p0x.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::Sc>, crate::check::env::Def)| {
                            let comp_p2xxy = comp_p2xx.clone();
                            let sk_p0xxy = sk_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_p9 = p0;
                                let d_pa = p1;
                                if crate::check::types::has_text_f(&comp_p2xxy, &d_pa.qk_p) {
                                    crate::prelude::call_then(start_call_graphs_f(sk_p0xxy.clone(), d_pa.clone(), comp_p2xxy.clone()), move |call_graphs_f_11012: crate::prelude::Array<crate::check::shrink::Sc>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p9, &call_graphs_f_11012)))
                                } else {
                                    ::prism_rtl::Turn::Finished(acc_p9.clone())
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::Sc>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>>>>
                    }), move |fold_10947: crate::prelude::Array<crate::check::shrink::Sc>| {
                        let graphs_p6 = fold_10947;
                        crate::prelude::call_then(crate::check::shrink::summaries::start_closure_f(graphs_p6.clone()), move |closure_f_11068: crate::prelude::Array<crate::check::shrink::Sc>| {
                            let closure_p7 = closure_f_11068;
                            let bad_p8 = crate::prelude::filter(&closure_p7, &(|sc_pb: &crate::check::shrink::Sc| ((&sc_pb.caller_p == &sc_pb.callee_p) && (&crate::check::shrink::summaries::compose_f(sc_pb, sc_pb).edges_p == &sc_pb.edges_p)) && !crate::prelude::fold(&sc_pb.edges_p, &false, &(|seen_pc: &bool, (a_pd, b_pe, s_pf): &(crate::prelude::Nat, crate::prelude::Nat, bool)| *seen_pc || ((a_pd == b_pe) && *s_pf)))));
                            match crate::prelude::index(&bad_p8, &crate::prelude::Nat::from(0u32)) {
                                ::std::option::Option::Some(sc_pg) => {
                                    let s2_ph = {
                                        let mut this: crate::check::types::St = st_p3.clone();
                                        this.file_p = sc_pg.file_p.clone();
                                        this
                                    };
                                    let what_pi = if &sc_pg.arg_p == &crate::prelude::Text::lit("") {
                                        crate::prelude::Text::lit("")
                                    } else {
                                        crate::prelude::Text::from(format!(" on `{}`", &sc_pg.arg_p))
                                    };
                                    let st3_pj = crate::check::types::recording::err_fix_f(&s2_ph, &crate::prelude::Text::lit("may-not-end"), &sc_pg.span_p, &crate::prelude::Text::from(format!("`{}` calls {}{}, not smaller than what it was given", &crate::check::shrink::types::shown_key_f(&sc_pg.caller_p), &(if &sc_pg.caller_p == &sc_pg.callee_p {
                                        crate::prelude::Text::lit("itself")
                                    } else {
                                        crate::prelude::Text::from(format!("`{}`", &crate::check::shrink::types::shown_key_f(&sc_pg.callee_p)))
                                    }), &what_pi)), &crate::prelude::Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle\'s functions `unbounded fn`"));
                                    ::prism_rtl::Turn::Finished({
                                        let mut this: crate::check::types::St = st3_pj.clone();
                                        this.file_p = st_p3.file_p.clone();
                                        this
                                    })
                                },
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(st_p3.clone()),
                            }
                        })
                    })
                }
            }
        })
    }
}

/// `Start ShrinkComponent, x`: what the function value is when passed to `@Run`.
pub fn start_shrink_component_f(sk_p0: crate::check::shrink::Shrink, st0_p1: crate::check::types::St, comp_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(ShrinkComponent { sk_p0, st0_p1, comp_p2 })
}

/// ```prism
/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
/// ```
pub fn call_graphs_f(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, comp_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::check::shrink::Sc> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p1), crate::prelude::Array::new(), {
        let sk_p0x = sk_p0.clone();
        let d_p1x = d_p1.clone();
        let comp_p2x = comp_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause)| {
            let sk_p0xy = sk_p0x.clone();
            let d_p1xy = d_p1x.clone();
            let comp_p2xy = comp_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let c_p4 = p1;
                crate::prelude::call_then(start_clause_graphs_f(sk_p0xy.clone(), d_p1xy.clone(), c_p4.clone(), comp_p2xy.clone()), move |clause_graphs_f_12130: crate::prelude::Array<crate::check::shrink::Sc>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &clause_graphs_f_12130)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>>>>
    }))
}

/// The step machine of `CallGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
/// ```
pub struct CallGraphs {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub comp_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>> for CallGraphs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::check::shrink::Sc>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let comp_p2 = &self.comp_p2;
        crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p1), crate::prelude::Array::new(), {
            let sk_p0x = sk_p0.clone();
            let d_p1x = d_p1.clone();
            let comp_p2x = comp_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause)| {
                let sk_p0xy = sk_p0x.clone();
                let d_p1xy = d_p1x.clone();
                let comp_p2xy = comp_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p3 = p0;
                    let c_p4 = p1;
                    crate::prelude::call_then(start_clause_graphs_f(sk_p0xy.clone(), d_p1xy.clone(), c_p4.clone(), comp_p2xy.clone()), move |clause_graphs_f_12130: crate::prelude::Array<crate::check::shrink::Sc>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &clause_graphs_f_12130)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>>>>
        }).cycle()
    }
}

/// `Start CallGraphs, x`: what the function value is when passed to `@Run`.
pub fn start_call_graphs_f(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, comp_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>>> {
    ::std::rc::Rc::new(CallGraphs { sk_p0, d_p1, comp_p2 })
}

/// ```prism
/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
/// ```
pub fn clause_graphs_f(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, c_p2: &crate::syntax::decls::FnClause, comp_p3: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::check::shrink::Sc> {
    let base_p4 = clause_base_f(sk_p0, d_p1, c_p2);
    let rels_p5 = crate::check::shrink::summaries::summary_seeds_f(sk_p0, d_p1, &crate::check::shrink::walk::body_spots_f(&c_p2.body_p, &base_p4), &base_p4);
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::body_sites_f(&c_p2.body_p, &rels_p5), crate::prelude::Array::new(), {
        let sk_p0x = sk_p0.clone();
        let d_p1x = d_p1.clone();
        let comp_p3x = comp_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site)| {
            let sk_p0xy = sk_p0x.clone();
            let d_p1xy = d_p1x.clone();
            let comp_p3xy = comp_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let site_p7 = p1;
                match local_target_o(&sk_p0xy, &d_p1xy, &site_p7) {
                    ::std::option::Option::Some(t_p8) => if crate::check::types::has_text_f(&comp_p3xy, &t_p8) {
                        crate::prelude::call_then(start_site_graph_f(sk_p0xy.clone(), d_p1xy.clone(), site_p7.clone(), t_p8.clone()), move |site_graph_f_12488: crate::check::shrink::Sc| ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p6, &site_graph_f_12488)))
                    } else {
                        ::prism_rtl::Turn::Finished(acc_p6.clone())
                    },
                    ::std::option::Option::None => if crate::check::shrink::relations::is_local_f(&site_p7.rels_p, &site_p7.callee_p) || crate::check::env::has_key_f(&sk_p0xy.local_of_p, &d_p1xy.qk_p) {
                        ::prism_rtl::Turn::Finished(acc_p6.clone())
                    } else {
                        match resolve_callee_o(&sk_p0xy.g_p, &d_p1xy.home_p, &site_p7.callee_p) {
                            ::std::option::Option::Some(k_p9) => crate::prelude::call_then(crate::check::shrink::types::start_dispatch_targets_f(sk_p0xy.clone(), d_p1xy.clone(), site_p7.clone(), k_p9.clone()), move |dispatch_targets_f_12710: crate::prelude::Array<crate::prelude::Text>| crate::prelude::fold_job(dispatch_targets_f_12710, acc_p6.clone(), {
                                let comp_p3xyx = comp_p3xy.clone();
                                let sk_p0xyx = sk_p0xy.clone();
                                let d_p1xyx = d_p1xy.clone();
                                let site_p7x = site_p7.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::Sc>, crate::prelude::Text)| {
                                    let comp_p3xyxy = comp_p3xyx.clone();
                                    let sk_p0xyxy = sk_p0xyx.clone();
                                    let d_p1xyxy = d_p1xyx.clone();
                                    let site_p7xy = site_p7x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let acc2_pa = p0;
                                        let t_pb = p1;
                                        if crate::check::types::has_text_f(&comp_p3xyxy, &t_pb) {
                                            crate::prelude::call_then(start_site_graph_f(sk_p0xyxy.clone(), d_p1xyxy.clone(), site_p7xy.clone(), t_pb.clone()), move |site_graph_f_12791: crate::check::shrink::Sc| ::prism_rtl::Turn::Finished(crate::prelude::push(&acc2_pa, &site_graph_f_12791)))
                                        } else {
                                            ::prism_rtl::Turn::Finished(acc2_pa.clone())
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::Sc>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>>>>
                            }).cycle()),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_p6.clone()),
                        }
                    },
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>>>>
    }))
}

/// The step machine of `ClauseGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
/// ```
pub struct ClauseGraphs {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub c_p2: crate::syntax::decls::FnClause,
    pub comp_p3: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>> for ClauseGraphs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::check::shrink::Sc>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let c_p2 = &self.c_p2;
        let comp_p3 = &self.comp_p3;
        let c_p2x = c_p2.clone();
        let comp_p3x = comp_p3.clone();
        let d_p1x = d_p1.clone();
        let sk_p0x = sk_p0.clone();
        crate::prelude::call_then(start_clause_base_f(sk_p0x.clone(), d_p1x.clone(), c_p2x.clone()), move |clause_base_f_12272: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
            let base_p4 = clause_base_f_12272;
            crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(c_p2x.body_p.clone(), base_p4.clone()), move |body_spots_f_12328: crate::prelude::Array<crate::check::shrink::walk::Spot>| crate::prelude::call_then(crate::check::shrink::summaries::start_summary_seeds_f(sk_p0x.clone(), d_p1x.clone(), body_spots_f_12328, base_p4.clone()), move |summary_seeds_f_12307: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>| {
                let rels_p5 = summary_seeds_f_12307;
                crate::prelude::call_then(crate::check::shrink::walk::start_body_sites_f(c_p2x.body_p.clone(), rels_p5.clone()), move |body_sites_f_12368: crate::prelude::Array<crate::check::shrink::walk::Site>| crate::prelude::fold_job(body_sites_f_12368, crate::prelude::Array::new(), {
                    let sk_p0xx = sk_p0x.clone();
                    let d_p1xx = d_p1x.clone();
                    let comp_p3xx = comp_p3x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site)| {
                        let sk_p0xxy = sk_p0xx.clone();
                        let d_p1xxy = d_p1xx.clone();
                        let comp_p3xxy = comp_p3xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_p6 = p0;
                            let site_p7 = p1;
                            match local_target_o(&sk_p0xxy, &d_p1xxy, &site_p7) {
                                ::std::option::Option::Some(t_p8) => if crate::check::types::has_text_f(&comp_p3xxy, &t_p8) {
                                    crate::prelude::call_then(start_site_graph_f(sk_p0xxy.clone(), d_p1xxy.clone(), site_p7.clone(), t_p8.clone()), move |site_graph_f_12488: crate::check::shrink::Sc| ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p6, &site_graph_f_12488)))
                                } else {
                                    ::prism_rtl::Turn::Finished(acc_p6.clone())
                                },
                                ::std::option::Option::None => if crate::check::shrink::relations::is_local_f(&site_p7.rels_p, &site_p7.callee_p) || crate::check::env::has_key_f(&sk_p0xxy.local_of_p, &d_p1xxy.qk_p) {
                                    ::prism_rtl::Turn::Finished(acc_p6.clone())
                                } else {
                                    match resolve_callee_o(&sk_p0xxy.g_p, &d_p1xxy.home_p, &site_p7.callee_p) {
                                        ::std::option::Option::Some(k_p9) => crate::prelude::call_then(crate::check::shrink::types::start_dispatch_targets_f(sk_p0xxy.clone(), d_p1xxy.clone(), site_p7.clone(), k_p9.clone()), move |dispatch_targets_f_12710: crate::prelude::Array<crate::prelude::Text>| crate::prelude::fold_job(dispatch_targets_f_12710, acc_p6.clone(), {
                                            let comp_p3xxyx = comp_p3xxy.clone();
                                            let sk_p0xxyx = sk_p0xxy.clone();
                                            let d_p1xxyx = d_p1xxy.clone();
                                            let site_p7x = site_p7.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::check::shrink::Sc>, crate::prelude::Text)| {
                                                let comp_p3xxyxy = comp_p3xxyx.clone();
                                                let sk_p0xxyxy = sk_p0xxyx.clone();
                                                let d_p1xxyxy = d_p1xxyx.clone();
                                                let site_p7xy = site_p7x.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let acc2_pa = p0;
                                                    let t_pb = p1;
                                                    if crate::check::types::has_text_f(&comp_p3xxyxy, &t_pb) {
                                                        crate::prelude::call_then(start_site_graph_f(sk_p0xxyxy.clone(), d_p1xxyxy.clone(), site_p7xy.clone(), t_pb.clone()), move |site_graph_f_12791: crate::check::shrink::Sc| ::prism_rtl::Turn::Finished(crate::prelude::push(&acc2_pa, &site_graph_f_12791)))
                                                    } else {
                                                        ::prism_rtl::Turn::Finished(acc2_pa.clone())
                                                    }
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::Sc>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>>>>
                                        }).cycle()),
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_p6.clone()),
                                    }
                                },
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>>>>
                }).cycle())
            }))
        })
    }
}

/// `Start ClauseGraphs, x`: what the function value is when passed to `@Run`.
pub fn start_clause_graphs_f(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, c_p2: crate::syntax::decls::FnClause, comp_p3: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::shrink::Sc>>> {
    ::std::rc::Rc::new(ClauseGraphs { sk_p0, d_p1, c_p2, comp_p3 })
}

/// ```prism
/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
/// ```
pub fn site_graph_f(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, site_p2: &crate::check::shrink::walk::Site, k_p3: &crate::prelude::Text) -> crate::check::shrink::Sc {
    let edges_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(arg_slots_f(sk_p0, &site_p2.args_p, k_p3), crate::prelude::Array::new(), {
        let site_p2x = site_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>, (crate::prelude::Nat, crate::syntax::Arg))| {
            let site_p2xy = site_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let es_p6 = p0;
                let (j_p7, a_p8) = p1;
                crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(site_p2xy.rels_p.clone(), a_p8.value_p.clone()), move |rel_of_o_13129: ::std::option::Option<crate::check::shrink::Rel>| match rel_of_o_13129 {
                    ::std::option::Option::Some(r_p9) => ::prism_rtl::Turn::Finished(crate::prelude::push(&es_p6, &(r_p9.param_p.clone(), j_p7.clone(), r_p9.strict_p))),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(es_p6.clone()),
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>, (crate::prelude::Nat, crate::syntax::Arg))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>>>>
    }));
    let arg_text_p5 = match crate::prelude::index(&site_p2.args_p, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(a_pa) => expr_name_f(&a_pa.value_p),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    };
    crate::check::shrink::Sc { caller_p: d_p1.qk_p.clone(), callee_p: k_p3.clone(), edges_p: crate::prelude::append(&edges_p4, &self_type_edges_f(sk_p0, d_p1, site_p2, k_p3)), span_p: site_p2.span_p.clone(), file_p: d_p1.file_p.clone(), arg_p: arg_text_p5.clone() }
}

/// The step machine of `SiteGraph`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
/// ```
pub struct SiteGraph {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub site_p2: crate::check::shrink::walk::Site,
    pub k_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::check::shrink::Sc> for SiteGraph {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::shrink::Sc> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let site_p2 = &self.site_p2;
        let k_p3 = &self.k_p3;
        let d_p1x = d_p1.clone();
        let k_p3x = k_p3.clone();
        let site_p2x = site_p2.clone();
        let sk_p0x = sk_p0.clone();
        crate::prelude::call_then(start_arg_slots_f(sk_p0x.clone(), site_p2x.args_p.clone(), k_p3x.clone()), move |arg_slots_f_13073: crate::prelude::Array<(crate::prelude::Nat, crate::syntax::Arg)>| crate::prelude::call_value(crate::prelude::fold_job(arg_slots_f_13073, crate::prelude::Array::new(), {
            let site_p2xx = site_p2x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>, (crate::prelude::Nat, crate::syntax::Arg))| {
                let site_p2xxy = site_p2xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let es_p6 = p0;
                    let (j_p7, a_p8) = p1;
                    crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(site_p2xxy.rels_p.clone(), a_p8.value_p.clone()), move |rel_of_o_13129: ::std::option::Option<crate::check::shrink::Rel>| match rel_of_o_13129 {
                        ::std::option::Option::Some(r_p9) => ::prism_rtl::Turn::Finished(crate::prelude::push(&es_p6, &(r_p9.param_p.clone(), j_p7.clone(), r_p9.strict_p))),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(es_p6.clone()),
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>, (crate::prelude::Nat, crate::syntax::Arg))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>>>>
        }), move |fold_13067: crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>| {
            let edges_p4 = fold_13067;
            let arg_text_p5 = match crate::prelude::index(&site_p2x.args_p, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(a_pa) => expr_name_f(&a_pa.value_p),
                ::std::option::Option::None => crate::prelude::Text::lit(""),
            };
            crate::prelude::call_then(start_self_type_edges_f(sk_p0x.clone(), d_p1x.clone(), site_p2x.clone(), k_p3x.clone()), move |self_type_edges_f_13355: crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>| ::prism_rtl::Turn::Finished(crate::check::shrink::Sc { caller_p: d_p1x.qk_p.clone(), callee_p: k_p3x.clone(), edges_p: crate::prelude::append(&edges_p4, &self_type_edges_f_13355), span_p: site_p2x.span_p.clone(), file_p: d_p1x.file_p.clone(), arg_p: arg_text_p5.clone() }))
        }))
    }
}

/// `Start SiteGraph, x`: what the function value is when passed to `@Run`.
pub fn start_site_graph_f(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, site_p2: crate::check::shrink::walk::Site, k_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::shrink::Sc>> {
    ::std::rc::Rc::new(SiteGraph { sk_p0, d_p1, site_p2, k_p3 })
}

/// ```prism
/// SelfTypeEdges: unbounded fn Shrink, Def, Site, Text -> [((Nat, Nat, Bool))]
/// ```
pub fn self_type_edges_f(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, site_p2: &crate::check::shrink::walk::Site, k_p3: &crate::prelude::Text) -> crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)> {
    match &d_p1.body_p {
        crate::check::env::DefBody::DbMethod(_, cls_p4, im_p5) => match site_class_o(sk_p0, d_p1, site_p2) {
            ::std::option::Option::Some(kc_p6) if (&kc_p6 == cls_p4) => match crate::prelude::get(&sk_p0.choices_p, &crate::check::types::recording::choice_key_f(&d_p1.file_p, &site_p2.span_p, cls_p4)) {
                ::std::option::Option::Some(chs_p7) => if (&crate::prelude::len(&chs_p7) > &crate::prelude::Nat::from(0u32)) && crate::prelude::fold(&chs_p7, &true, &(|all_p8: &bool, ch_p9: &crate::prelude::Text| (*all_p8 && crate::syntax::lexer::chars::has_prefix_f(ch_p9, &crate::prelude::Text::lit("given:"))) && crate::check::types::has_text_f(&im_p5.qs_p, &crate::syntax::lexer::chars::drop_prefix_f(ch_p9, &crate::prelude::Text::lit("given:"))))) {
                    crate::prelude::Array::from(vec![(self_type_slot_p(), self_type_slot_p(), true)])
                } else {
                    crate::prelude::Array::new()
                },
                ::std::option::Option::None => crate::prelude::Array::new(),
            },
            _ => crate::prelude::Array::new(),
            _ => unreachable!("no arm matched"),
        },
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `SelfTypeEdges`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SelfTypeEdges: unbounded fn Shrink, Def, Site, Text -> [((Nat, Nat, Bool))]
/// ```
pub struct SelfTypeEdges {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub site_p2: crate::check::shrink::walk::Site,
    pub k_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>> for SelfTypeEdges {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let site_p2 = &self.site_p2;
        let k_p3 = &self.k_p3;
        match &d_p1.body_p {
            crate::check::env::DefBody::DbMethod(_, cls_p4, im_p5) => {
                let cls_p4x = cls_p4.clone();
                let d_p1x = d_p1.clone();
                let im_p5x = im_p5.clone();
                let site_p2x = site_p2.clone();
                let sk_p0x = sk_p0.clone();
                crate::prelude::call_then(start_site_class_o(sk_p0x.clone(), d_p1x.clone(), site_p2x.clone()), move |site_class_o_14008: ::std::option::Option<crate::prelude::Text>| match site_class_o_14008 {
                    ::std::option::Option::Some(kc_p6) if (&kc_p6 == &cls_p4x) => match crate::prelude::get(&sk_p0x.choices_p, &crate::check::types::recording::choice_key_f(&d_p1x.file_p, &site_p2x.span_p, &cls_p4x)) {
                        ::std::option::Option::Some(chs_p7) => if (&crate::prelude::len(&chs_p7) > &crate::prelude::Nat::from(0u32)) && crate::prelude::fold(&chs_p7, &true, &(|all_p8: &bool, ch_p9: &crate::prelude::Text| (*all_p8 && crate::syntax::lexer::chars::has_prefix_f(ch_p9, &crate::prelude::Text::lit("given:"))) && crate::check::types::has_text_f(&im_p5x.qs_p, &crate::syntax::lexer::chars::drop_prefix_f(ch_p9, &crate::prelude::Text::lit("given:"))))) {
                            ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![(self_type_slot_p(), self_type_slot_p(), true)]))
                        } else {
                            ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
                        },
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
                    },
                    _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
                    _ => unreachable!("no arm matched"),
                })
            },
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start SelfTypeEdges, x`: what the function value is when passed to `@Run`.
pub fn start_self_type_edges_f(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, site_p2: crate::check::shrink::walk::Site, k_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Nat, bool)>>> {
    ::std::rc::Rc::new(SelfTypeEdges { sk_p0, d_p1, site_p2, k_p3 })
}

/// ```prism
/// ?SiteClass: unbounded fn Shrink, Def, Site -> ?Text
/// ```
pub fn site_class_o(sk_p0: &crate::check::shrink::Shrink, d_p1: &crate::check::env::Def, site_p2: &crate::check::shrink::walk::Site) -> ::std::option::Option<crate::prelude::Text> {
    match resolve_callee_o(&sk_p0.g_p, &d_p1.home_p, &site_p2.callee_p) {
        ::std::option::Option::Some(mk_p3) => crate::check::shrink::types::method_class_o(&sk_p0.g_p, &mk_p3),
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// The step machine of `SiteClass`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?SiteClass: unbounded fn Shrink, Def, Site -> ?Text
/// ```
pub struct SiteClass {
    pub sk_p0: crate::check::shrink::Shrink,
    pub d_p1: crate::check::env::Def,
    pub site_p2: crate::check::shrink::walk::Site,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>> for SiteClass {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Text>> {
        let sk_p0 = &self.sk_p0;
        let d_p1 = &self.d_p1;
        let site_p2 = &self.site_p2;
        match resolve_callee_o(&sk_p0.g_p, &d_p1.home_p, &site_p2.callee_p) {
            ::std::option::Option::Some(mk_p3) => ::prism_rtl::Turn::Finished(crate::check::shrink::types::method_class_o(&sk_p0.g_p, &mk_p3)),
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start SiteClass, x`: what the function value is when passed to `@Run`.
pub fn start_site_class_o(sk_p0: crate::check::shrink::Shrink, d_p1: crate::check::env::Def, site_p2: crate::check::shrink::walk::Site) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>>> {
    ::std::rc::Rc::new(SiteClass { sk_p0, d_p1, site_p2 })
}

/// ```prism
/// let selfTypeSlot
/// ```
pub fn self_type_slot_p() -> crate::prelude::Nat {
    crate::prelude::Nat::from(4096u32)
}

/// ```prism
/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
/// ```
pub fn arg_slots_f(sk_p0: &crate::check::shrink::Shrink, args_p1: &crate::prelude::Array<crate::syntax::Arg>, k_p2: &crate::prelude::Text) -> crate::prelude::Array<(crate::prelude::Nat, crate::syntax::Arg)> {
    let (_, out_p8) = crate::prelude::run_to_end(crate::prelude::fold_job(args_p1.clone(), (crate::prelude::Nat::from(0u32), crate::prelude::Array::new()), {
        let sk_p0x = sk_p0.clone();
        let k_p2x = k_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Nat, crate::prelude::Array<(crate::prelude::Nat, crate::syntax::Arg)>), crate::syntax::Arg)| {
            let sk_p0xy = sk_p0x.clone();
            let k_p2xy = k_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (pos_p3, acc_p4) = p0;
                let a_p5 = p1;
                match &a_p5.name_o {
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished((&pos_p3 + &crate::prelude::Nat::from(1u32), crate::prelude::push(&acc_p4, &(pos_p3.clone(), a_p5.clone())))),
                    ::std::option::Option::Some(id_p6) => {
                        let id_p6x = id_p6.clone();
                        crate::prelude::call_then(start_param_named_o(sk_p0xy.clone(), k_p2xy.clone(), id_p6x.name_p.clone()), move |param_named_o_15328: ::std::option::Option<crate::prelude::Nat>| match param_named_o_15328 {
                            ::std::option::Option::Some(j_p7) => ::prism_rtl::Turn::Finished((pos_p3.clone(), crate::prelude::push(&acc_p4, &(j_p7.clone(), a_p5.clone())))),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished((pos_p3.clone(), acc_p4.clone())),
                        })
                    },
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Nat, crate::prelude::Array<(crate::prelude::Nat, crate::syntax::Arg)>), crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Nat, crate::prelude::Array<(crate::prelude::Nat, crate::syntax::Arg)>)>>>
    }));
    out_p8.clone()
}

/// The step machine of `ArgSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
/// ```
pub struct ArgSlots {
    pub sk_p0: crate::check::shrink::Shrink,
    pub args_p1: crate::prelude::Array<crate::syntax::Arg>,
    pub k_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Nat, crate::syntax::Arg)>> for ArgSlots {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Nat, crate::syntax::Arg)>> {
        let sk_p0 = &self.sk_p0;
        let args_p1 = &self.args_p1;
        let k_p2 = &self.k_p2;
        let args_p1x = args_p1.clone();
        let k_p2x = k_p2.clone();
        let sk_p0x = sk_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(args_p1x.clone(), (crate::prelude::Nat::from(0u32), crate::prelude::Array::new()), {
            let sk_p0xx = sk_p0x.clone();
            let k_p2xx = k_p2x.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Nat, crate::prelude::Array<(crate::prelude::Nat, crate::syntax::Arg)>), crate::syntax::Arg)| {
                let sk_p0xxy = sk_p0xx.clone();
                let k_p2xxy = k_p2xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (pos_p3, acc_p4) = p0;
                    let a_p5 = p1;
                    match &a_p5.name_o {
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((&pos_p3 + &crate::prelude::Nat::from(1u32), crate::prelude::push(&acc_p4, &(pos_p3.clone(), a_p5.clone())))),
                        ::std::option::Option::Some(id_p6) => {
                            let id_p6x = id_p6.clone();
                            crate::prelude::call_then(start_param_named_o(sk_p0xxy.clone(), k_p2xxy.clone(), id_p6x.name_p.clone()), move |param_named_o_15328: ::std::option::Option<crate::prelude::Nat>| match param_named_o_15328 {
                                ::std::option::Option::Some(j_p7) => ::prism_rtl::Turn::Finished((pos_p3.clone(), crate::prelude::push(&acc_p4, &(j_p7.clone(), a_p5.clone())))),
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished((pos_p3.clone(), acc_p4.clone())),
                            })
                        },
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Nat, crate::prelude::Array<(crate::prelude::Nat, crate::syntax::Arg)>), crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Nat, crate::prelude::Array<(crate::prelude::Nat, crate::syntax::Arg)>)>>>
        }), move |fold_15201: (crate::prelude::Nat, crate::prelude::Array<(crate::prelude::Nat, crate::syntax::Arg)>)| {
            let (_, out_p8) = fold_15201;
            ::prism_rtl::Turn::Finished(out_p8.clone())
        })
    }
}

/// `Start ArgSlots, x`: what the function value is when passed to `@Run`.
pub fn start_arg_slots_f(sk_p0: crate::check::shrink::Shrink, args_p1: crate::prelude::Array<crate::syntax::Arg>, k_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Nat, crate::syntax::Arg)>>> {
    ::std::rc::Rc::new(ArgSlots { sk_p0, args_p1, k_p2 })
}

/// ```prism
/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
/// ```
pub fn param_named_o(sk_p0: &crate::check::shrink::Shrink, k_p1: &crate::prelude::Text, name_p2: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Nat> {
    let clauses_p3 = crate::check::shrink::types::def_clauses_f(&crate::prelude::or(&crate::prelude::get(&sk_p0.by_key_p, k_p1), &crate::check::env::decls::dummy_def_p()));
    if name_p2 == &crate::prelude::Text::lit("#body") {
        match crate::prelude::index(&clauses_p3, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::Some(c_p4) => if &crate::prelude::len(&c_p4.params_p) > &crate::prelude::Nat::from(0u32) {
                ::std::option::Option::Some(crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&c_p4.params_p)))
            } else {
                ::std::option::Option::None
            },
            ::std::option::Option::None => ::std::option::Option::None,
        }
    } else {
        param_named_in_o(&clauses_p3, name_p2)
    }
}

/// The step machine of `ParamNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
/// ```
pub struct ParamNamed {
    pub sk_p0: crate::check::shrink::Shrink,
    pub k_p1: crate::prelude::Text,
    pub name_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Nat>> for ParamNamed {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Nat>> {
        let sk_p0 = &self.sk_p0;
        let k_p1 = &self.k_p1;
        let name_p2 = &self.name_p2;
        let clauses_p3 = crate::check::shrink::types::def_clauses_f(&crate::prelude::or(&crate::prelude::get(&sk_p0.by_key_p, k_p1), &crate::check::env::decls::dummy_def_p()));
        if name_p2 == &crate::prelude::Text::lit("#body") {
            match crate::prelude::index(&clauses_p3, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(c_p4) => if &crate::prelude::len(&c_p4.params_p) > &crate::prelude::Nat::from(0u32) {
                    ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&c_p4.params_p))))
                } else {
                    ::prism_rtl::Turn::Finished(::std::option::Option::None)
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
            }
        } else {
            ::prism_rtl::Turn::Finished(param_named_in_o(&clauses_p3, name_p2))
        }
    }
}

/// `Start ParamNamed, x`: what the function value is when passed to `@Run`.
pub fn start_param_named_o(sk_p0: crate::check::shrink::Shrink, k_p1: crate::prelude::Text, name_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Nat>>> {
    ::std::rc::Rc::new(ParamNamed { sk_p0, k_p1, name_p2 })
}

/// ```prism
/// ?ParamNamedIn: unbounded fn [FnClause], Text -> ?Nat
/// ```
pub fn param_named_in_o(clauses_p0: &crate::prelude::Array<crate::syntax::decls::FnClause>, name_p1: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Nat> {
    let found_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p0.clone(), crate::prelude::Array::new(), {
        let name_p1x = name_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::syntax::decls::FnClause)| {
            let name_p1xy = name_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p2 = p0;
                let c_p3 = p1;
                crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&c_p3.params_p)), acc_p2.clone(), {
                    let c_p3x = c_p3.clone();
                    let name_p1xyx = name_p1xy.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Nat)| {
                        let c_p3xy = c_p3x.clone();
                        let name_p1xyxy = name_p1xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a2_p4 = p0;
                            let i_p5 = p1;
                            match crate::prelude::index(&c_p3xy.params_p, &i_p5) {
                                ::std::option::Option::Some(p_p6) => if (&param_name_of_f(&p_p6) == &name_p1xyxy) && !crate::check::types::has_nat_f(&a2_p4, &i_p5) {
                                    ::prism_rtl::Turn::Finished(crate::prelude::push(&a2_p4, &i_p5))
                                } else {
                                    ::prism_rtl::Turn::Finished(a2_p4.clone())
                                },
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(a2_p4.clone()),
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
                }).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    if &crate::prelude::len(&found_p7) == &crate::prelude::Nat::from(1u32) {
        crate::prelude::index(&found_p7, &crate::prelude::Nat::from(0u32))
    } else {
        ::std::option::Option::None
    }
}

/// ```prism
/// ParamNameOf: unbounded fn Pattern -> Text
/// ```
pub fn param_name_of_f(p_p0: &crate::syntax::Pattern) -> crate::prelude::Text {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p1) => {
            let text_p2 = crate::check::env::sname_key_f(n_p1);
            crate::syntax::lexer::chars::drop_prefix_f(&text_p2, &crate::check::types::unify::marks_of_f(&text_p2))
        },
        crate::syntax::PatternKind::PGroup(q_p3) => param_name_of_f(&**q_p3),
        _ => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// ExprName: fn Expr -> Text
/// ```
pub fn expr_name_f(e_p0: &crate::syntax::Expr) -> crate::prelude::Text {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::EName(n_p1) => crate::check::env::sname_key_f(n_p1),
        crate::syntax::ExprKind::EGroup(x_p2) => expr_name_f(&**x_p2),
        _ => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
/// ```
pub fn param_rels_on_f(base_p0: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ps_p1: &crate::prelude::Array<crate::syntax::Pattern>) -> crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p1)), crate::check::shrink::relations::hide_f(base_p0, &crate::check::shrink::walk::patterns_names_f(ps_p1)), {
        let ps_p1x = ps_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, crate::prelude::Nat)| {
            let ps_p1xy = ps_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p2 = p0;
                let i_p3 = p1;
                match crate::prelude::index(&ps_p1xy, &i_p3) {
                    ::std::option::Option::Some(p_p4) => match &*p_p4.kind_p {
                        crate::syntax::PatternKind::PName(n_p5) => ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_p2, &crate::check::env::sname_key_f(n_p5), &crate::check::shrink::Rel { param_p: i_p3.clone(), strict_p: false })),
                        _ => crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p4.clone()), move |pattern_names_f_17101: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&pattern_names_f_17101, &m_p2, &(|m2_p6: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, n_p7: &crate::prelude::Text| crate::prelude::insert(m2_p6, n_p7, &crate::check::shrink::Rel { param_p: i_p3.clone(), strict_p: true }))))),
                    },
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(m_p2.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>>>
    }))
}

/// The step machine of `ParamRelsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
/// ```
pub struct ParamRelsOn {
    pub base_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>,
    pub ps_p1: crate::prelude::Array<crate::syntax::Pattern>,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>> for ParamRelsOn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>> {
        let base_p0 = &self.base_p0;
        let ps_p1 = &self.ps_p1;
        let base_p0x = base_p0.clone();
        let ps_p1x = ps_p1.clone();
        crate::prelude::call_then(crate::check::shrink::walk::start_patterns_names_f(ps_p1x.clone()), move |patterns_names_f_16944: crate::prelude::Array<crate::prelude::Text>| crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_p1x)), crate::check::shrink::relations::hide_f(&base_p0x, &patterns_names_f_16944), {
            let ps_p1xx = ps_p1x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, crate::prelude::Nat)| {
                let ps_p1xxy = ps_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m_p2 = p0;
                    let i_p3 = p1;
                    match crate::prelude::index(&ps_p1xxy, &i_p3) {
                        ::std::option::Option::Some(p_p4) => match &*p_p4.kind_p {
                            crate::syntax::PatternKind::PName(n_p5) => ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_p2, &crate::check::env::sname_key_f(n_p5), &crate::check::shrink::Rel { param_p: i_p3.clone(), strict_p: false })),
                            _ => crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p4.clone()), move |pattern_names_f_17101: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&pattern_names_f_17101, &m_p2, &(|m2_p6: &crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, n_p7: &crate::prelude::Text| crate::prelude::insert(m2_p6, n_p7, &crate::check::shrink::Rel { param_p: i_p3.clone(), strict_p: true }))))),
                        },
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(m_p2.clone()),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>>>
        }).cycle())
    }
}

/// `Start ParamRelsOn, x`: what the function value is when passed to `@Run`.
pub fn start_param_rels_on_f(base_p0: crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>, ps_p1: crate::prelude::Array<crate::syntax::Pattern>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::shrink::Rel>>> {
    ::std::rc::Rc::new(ParamRelsOn { base_p0, ps_p1 })
}
