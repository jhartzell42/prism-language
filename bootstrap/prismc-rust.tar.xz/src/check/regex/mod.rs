//! The module `Check.Regex`, from `target/bootstrap/src/prismc/check/regex/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `RxCp`:
///
/// ```prism
/// type RxCp = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum RxCp {
    RxLit(Text),
    RxNum(Nat),
}

impl Show for RxCp {
    fn show(&self, p: &mut Printer) {
        match self {
            RxCp::RxLit(a0) => p.choice("RxLit", &[a0]),
            RxCp::RxNum(a0) => p.choice("RxNum", &[a0]),
        }
    }
}

impl ToPod for RxCp {
    fn to_pod(&self) -> Pod {
        match self {
            RxCp::RxLit(a0) => Pod::Choice("RxLit".into(), vec![a0.to_pod()]),
            RxCp::RxNum(a0) => Pod::Choice("RxNum".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for RxCp {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "RxLit" && a.len() == 1 => Ok(RxCp::RxLit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "RxNum" && a.len() == 1 => Ok(RxCp::RxNum(FromPod::from_pod(&a[0])?)),
            other => mismatch("a RxCp", other),
        }
    }
}

/// `RxDiag`:
///
/// ```prism
/// type RxDiag = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct RxDiag {
    pub part_p: Text,
    pub at_p: Nat,
    pub message_p: Text,
}

impl Show for RxDiag {
    fn show(&self, p: &mut Printer) {
        p.record("RxDiag", &[("part", &self.part_p), ("at", &self.at_p), ("message", &self.message_p)]);
    }
}

impl ToPod for RxDiag {
    fn to_pod(&self) -> Pod {
        Pod::record("RxDiag", vec![("part", self.part_p.to_pod()), ("at", self.at_p.to_pod()), ("message", self.message_p.to_pod())])
    }
}

impl FromPod for RxDiag {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RxDiag { part_p: FromPod::from_pod(field(p, "part")?)?, at_p: FromPod::from_pod(field(p, "at")?)?, message_p: FromPod::from_pod(field(p, "message")?)? })
    }
}

/// `RxLast`:
///
/// ```prism
/// type RxLast = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum RxLast {
    RxLastNothing,
    RxLastFlagGroup,
    RxLastAssertion,
    RxLastRepetition,
    RxLastAtom,
}

impl Show for RxLast {
    fn show(&self, p: &mut Printer) {
        match self {
            RxLast::RxLastNothing => p.choice("RxLastNothing", &[]),
            RxLast::RxLastFlagGroup => p.choice("RxLastFlagGroup", &[]),
            RxLast::RxLastAssertion => p.choice("RxLastAssertion", &[]),
            RxLast::RxLastRepetition => p.choice("RxLastRepetition", &[]),
            RxLast::RxLastAtom => p.choice("RxLastAtom", &[]),
        }
    }
}

impl ToPod for RxLast {
    fn to_pod(&self) -> Pod {
        match self {
            RxLast::RxLastNothing => Pod::Choice("RxLastNothing".into(), vec![]),
            RxLast::RxLastFlagGroup => Pod::Choice("RxLastFlagGroup".into(), vec![]),
            RxLast::RxLastAssertion => Pod::Choice("RxLastAssertion".into(), vec![]),
            RxLast::RxLastRepetition => Pod::Choice("RxLastRepetition".into(), vec![]),
            RxLast::RxLastAtom => Pod::Choice("RxLastAtom".into(), vec![]),
        }
    }
}

impl FromPod for RxLast {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "RxLastNothing" && a.len() == 0 => Ok(RxLast::RxLastNothing),
            Pod::Choice(c, a) if &**c == "RxLastFlagGroup" && a.len() == 0 => Ok(RxLast::RxLastFlagGroup),
            Pod::Choice(c, a) if &**c == "RxLastAssertion" && a.len() == 0 => Ok(RxLast::RxLastAssertion),
            Pod::Choice(c, a) if &**c == "RxLastRepetition" && a.len() == 0 => Ok(RxLast::RxLastRepetition),
            Pod::Choice(c, a) if &**c == "RxLastAtom" && a.len() == 0 => Ok(RxLast::RxLastAtom),
            other => mismatch("a RxLast", other),
        }
    }
}

/// `RxMeasure`:
///
/// ```prism
/// type RxMeasure = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct RxMeasure {
    pub depth_p: Nat,
    pub size_p: Nat,
    pub product_p: Nat,
}

impl Show for RxMeasure {
    fn show(&self, p: &mut Printer) {
        p.record("RxMeasure", &[("depth", &self.depth_p), ("size", &self.size_p), ("product", &self.product_p)]);
    }
}

impl ToPod for RxMeasure {
    fn to_pod(&self) -> Pod {
        Pod::record("RxMeasure", vec![("depth", self.depth_p.to_pod()), ("size", self.size_p.to_pod()), ("product", self.product_p.to_pod())])
    }
}

impl FromPod for RxMeasure {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RxMeasure { depth_p: FromPod::from_pod(field(p, "depth")?)?, size_p: FromPod::from_pod(field(p, "size")?)?, product_p: FromPod::from_pod(field(p, "product")?)? })
    }
}

/// `RxState`:
///
/// ```prism
/// type RxState = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct RxState {
    pub s_p: Text,
    pub i_p: Nat,
    pub open_p: Nat,
    pub groups_p: Nat,
    pub names_p: Map<Text, Nat>,
    pub err_o: Option<RxDiag>,
}

impl Show for RxState {
    fn show(&self, p: &mut Printer) {
        p.record("RxState", &[("s", &self.s_p), ("i", &self.i_p), ("open", &self.open_p), ("groups", &self.groups_p), ("names", &self.names_p), ("err", &self.err_o)]);
    }
}

impl ToPod for RxState {
    fn to_pod(&self) -> Pod {
        Pod::record("RxState", vec![("s", self.s_p.to_pod()), ("i", self.i_p.to_pod()), ("open", self.open_p.to_pod()), ("groups", self.groups_p.to_pod()), ("names", self.names_p.to_pod()), ("err", self.err_o.to_pod())])
    }
}

impl FromPod for RxState {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RxState { s_p: FromPod::from_pod(field(p, "s")?)?, i_p: FromPod::from_pod(field(p, "i")?)?, open_p: FromPod::from_pod(field(p, "open")?)?, groups_p: FromPod::from_pod(field(p, "groups")?)?, names_p: FromPod::from_pod(field(p, "names")?)?, err_o: FromPod::from_pod(field(p, "err")?)? })
    }
}

/// ```prism
/// let rxUnknownFlag
/// ```
pub fn rx_unknown_flag_p() -> Text {
    Text::lit("an unknown flag: the flags are i, m and s")
}

/// ```prism
/// let rxFlagTwice
/// ```
pub fn rx_flag_twice_p() -> Text {
    Text::lit("a flag written twice")
}

/// ```prism
/// let rxStrayBracket
/// ```
pub fn rx_stray_bracket_p() -> Text {
    Text::lit("a ] outside a class: a literal one is \\]")
}

/// ```prism
/// let rxStrayBrace
/// ```
pub fn rx_stray_brace_p() -> Text {
    Text::lit("a } outside a count: a literal one is \\}")
}

/// ```prism
/// let rxTrailingBackslash
/// ```
pub fn rx_trailing_backslash_p() -> Text {
    Text::lit("a \\ at the end of the pattern")
}

/// ```prism
/// let rxHexTwo
/// ```
pub fn rx_hex_two_p() -> Text {
    Text::lit("a \\x escape needs two hex digits or braces")
}

/// ```prism
/// let rxHexBraces
/// ```
pub fn rx_hex_braces_p() -> Text {
    Text::lit("a \\x{...} escape needs one to six hex digits")
}

/// ```prism
/// let rxHexNoChar
/// ```
pub fn rx_hex_no_char_p() -> Text {
    Text::lit("a \\x escape names no character: a surrogate or past U+10FFFF")
}

/// ```prism
/// let rxWordBraces
/// ```
pub fn rx_word_braces_p() -> Text {
    Text::lit("\\b{...} is Rust\'s only: write \\b")
}

/// ```prism
/// let rxAngle
/// ```
pub fn rx_angle_p() -> Text {
    Text::lit("\\< and \\> are Rust\'s only: write \\b")
}

/// ```prism
/// let rxBackreference
/// ```
pub fn rx_backreference_p() -> Text {
    Text::lit("a backreference: refused so that every match is linear in its text")
}

/// ```prism
/// let rxOctal
/// ```
pub fn rx_octal_p() -> Text {
    Text::lit("an octal escape is RE2\'s only: write \\x")
}

/// ```prism
/// let rxQuote
/// ```
pub fn rx_quote_p() -> Text {
    Text::lit("\\Q...\\E is RE2\'s only: escape each character")
}

/// ```prism
/// let rxOneByte
/// ```
pub fn rx_one_byte_p() -> Text {
    Text::lit("\\C, one byte, is RE2\'s only")
}

/// ```prism
/// let rxUnknownEscape
/// ```
pub fn rx_unknown_escape_p() -> Text {
    Text::lit("an unknown escape")
}

/// ```prism
/// let rxPropertyName
/// ```
pub fn rx_property_name_p() -> Text {
    Text::lit("a \\p escape needs a property name")
}

/// ```prism
/// let rxPropertyOpen
/// ```
pub fn rx_property_open_p() -> Text {
    Text::lit("a \\p{ that is never closed")
}

/// ```prism
/// let rxPropertyNegated
/// ```
pub fn rx_property_negated_p() -> Text {
    Text::lit("a negated property is written \\P{...}")
}

/// ```prism
/// let rxPropertyRefused
/// ```
pub fn rx_property_refused_p() -> Text {
    Text::lit("the property is refused: RE2 and Rust disagree on C, Cn, Cs and LC")
}

/// ```prism
/// let rxPropertyUnknown
/// ```
pub fn rx_property_unknown_p() -> Text {
    Text::lit("an unknown property: general categories by short name, scripts and Any")
}

/// ```prism
/// let rxClassOpen
/// ```
pub fn rx_class_open_p() -> Text {
    Text::lit("a class opened here is never closed")
}

/// ```prism
/// let rxClassFirstBracket
/// ```
pub fn rx_class_first_bracket_p() -> Text {
    Text::lit("a ] first in a class: write \\]")
}

/// ```prism
/// let rxClassNested
/// ```
pub fn rx_class_nested_p() -> Text {
    Text::lit("a [ inside a class: write \\[ (nested classes are Rust\'s only)")
}

/// ```prism
/// let rxClassAsciiUnknown
/// ```
pub fn rx_class_ascii_unknown_p() -> Text {
    Text::lit("an unknown ASCII class")
}

/// ```prism
/// let rxClassSetOperation
/// ```
pub fn rx_class_set_operation_p() -> Text {
    Text::lit("&&, ~~ and -- in a class are Rust\'s set operations: escape them")
}

/// ```prism
/// let rxClassDash
/// ```
pub fn rx_class_dash_p() -> Text {
    Text::lit("a - in a class that is neither a range nor first or last: write \\-")
}

/// ```prism
/// let rxClassOrder
/// ```
pub fn rx_class_order_p() -> Text {
    Text::lit("a range whose ends are out of order")
}

/// ```prism
/// let rxClassRangeSet
/// ```
pub fn rx_class_range_set_p() -> Text {
    Text::lit("a range end that is a class")
}

/// ```prism
/// let rxClassNegatedUnderI
/// ```
pub fn rx_class_negated_under_i_p() -> Text {
    Text::lit("a negated class inside a class under i: write it outside the class")
}

/// ```prism
/// let rxClassEscape
/// ```
pub fn rx_class_escape_p() -> Text {
    Text::lit("an escape that a class cannot hold")
}

/// ```prism
/// let rxLookaround
/// ```
pub fn rx_lookaround_p() -> Text {
    Text::lit("a lookaround: refused so that every match is linear in its text")
}

/// ```prism
/// let rxUnknownGroup
/// ```
pub fn rx_unknown_group_p() -> Text {
    Text::lit("an unknown group: the groups are (re), (?:re), (?<name>re), (?P<name>re) and the flag groups")
}

/// ```prism
/// let rxNameShape
/// ```
pub fn rx_name_shape_p() -> Text {
    Text::lit("a group name is a lowercase value name, [a-z_][a-z0-9_]*")
}

/// ```prism
/// let rxNameOpen
/// ```
pub fn rx_name_open_p() -> Text {
    Text::lit("a group name that is never closed")
}

/// ```prism
/// let rxNameTwice
/// ```
pub fn rx_name_twice_p() -> Text {
    Text::lit("a group name used twice")
}

/// ```prism
/// let rxGroupOpen
/// ```
pub fn rx_group_open_p() -> Text {
    Text::lit("a group opened here is never closed")
}

/// ```prism
/// let rxGroupClose
/// ```
pub fn rx_group_close_p() -> Text {
    Text::lit("a ) that closes no group")
}

/// ```prism
/// let rxFlagsEmpty
/// ```
pub fn rx_flags_empty_p() -> Text {
    Text::lit("an empty flag group")
}

/// ```prism
/// let rxFlagsSecondDash
/// ```
pub fn rx_flags_second_dash_p() -> Text {
    Text::lit("a second - in a flag group")
}

/// ```prism
/// let rxFlagsDash
/// ```
pub fn rx_flags_dash_p() -> Text {
    Text::lit("a - that turns off no flag")
}

/// ```prism
/// let rxBrace
/// ```
pub fn rx_brace_p() -> Text {
    Text::lit("a brace that opens no count: a literal one is \\{")
}

/// ```prism
/// let rxCountZero
/// ```
pub fn rx_count_zero_p() -> Text {
    Text::lit("a count with a leading zero")
}

/// ```prism
/// let rxCountBound
/// ```
pub fn rx_count_bound_p() -> Text {
    Text::lit("a count above 1000")
}

/// ```prism
/// let rxCountOrder
/// ```
pub fn rx_count_order_p() -> Text {
    Text::lit("a count whose minimum exceeds its maximum")
}

/// ```prism
/// let rxNothingToRepeat
/// ```
pub fn rx_nothing_to_repeat_p() -> Text {
    Text::lit("a repetition with nothing to repeat")
}

/// ```prism
/// let rxRepeatRepeat
/// ```
pub fn rx_repeat_repeat_p() -> Text {
    Text::lit("a repetition of a repetition: write (?:a*)* to say it")
}

/// ```prism
/// let rxRepeatAssertion
/// ```
pub fn rx_repeat_assertion_p() -> Text {
    Text::lit("a repetition of an assertion")
}

/// ```prism
/// let rxProduct
/// ```
pub fn rx_product_p() -> Text {
    Text::lit("nested counts multiplying past 1000")
}

/// ```prism
/// let rxNesting
/// ```
pub fn rx_nesting_p() -> Text {
    Text::lit("groups and repetitions nested more than 100 deep")
}

/// ```prism
/// let rxSize
/// ```
pub fn rx_size_p() -> Text {
    Text::lit("the pattern expands past 10,000 atoms")
}

/// ```prism
/// let rxRZero
/// ```
pub fn rx_rzero_p() -> Text {
    Text::lit("a group number with a leading zero")
}

/// ```prism
/// let rxRBraces
/// ```
pub fn rx_rbraces_p() -> Text {
    Text::lit("a ${...} that is neither a group number nor a group name")
}

/// ```prism
/// let rxRDollar
/// ```
pub fn rx_rdollar_p() -> Text {
    Text::lit("a $ that is not $n, ${n}, ${name} or $$")
}

/// ```prism
/// let rxRNoNumber
/// ```
pub fn rx_rno_number_p() -> Text {
    Text::lit("the pattern has no group of that number")
}

/// ```prism
/// let rxRNoName
/// ```
pub fn rx_rno_name_p() -> Text {
    Text::lit("the pattern has no group of that name")
}

/// ```prism
/// let rxRUnicode
/// ```
pub fn rx_runicode_p() -> Text {
    Text::lit("a \\u{...} escape needs one to six hex digits naming a character")
}

/// ```prism
/// let rxREscape
/// ```
pub fn rx_rescape_p() -> Text {
    Text::lit("an unknown escape in a replacement: the escapes are \\\\, \\n, \\t, \\u{hex} and \\/")
}

/// ```prism
/// let rxCategories
/// ```
pub fn rx_categories_p() -> Array<Text> {
    Array::from(vec![Text::lit("Cc"), Text::lit("Cf"), Text::lit("Co"), Text::lit("L"), Text::lit("Ll"), Text::lit("Lm"), Text::lit("Lo"), Text::lit("Lt"), Text::lit("Lu"), Text::lit("M"), Text::lit("Mc"), Text::lit("Me"), Text::lit("Mn"), Text::lit("N"), Text::lit("Nd"), Text::lit("Nl"), Text::lit("No"), Text::lit("P"), Text::lit("Pc"), Text::lit("Pd"), Text::lit("Pe"), Text::lit("Pf"), Text::lit("Pi"), Text::lit("Po"), Text::lit("Ps"), Text::lit("S"), Text::lit("Sc"), Text::lit("Sk"), Text::lit("Sm"), Text::lit("So"), Text::lit("Z"), Text::lit("Zl"), Text::lit("Zp"), Text::lit("Zs")])
}

/// ```prism
/// let rxScripts
/// ```
pub fn rx_scripts_p() -> Array<Text> {
    Array::from(vec![Text::lit("Adlam"), Text::lit("Ahom"), Text::lit("Anatolian_Hieroglyphs"), Text::lit("Arabic"), Text::lit("Armenian"), Text::lit("Avestan"), Text::lit("Balinese"), Text::lit("Bamum"), Text::lit("Bassa_Vah"), Text::lit("Batak"), Text::lit("Bengali"), Text::lit("Bhaiksuki"), Text::lit("Bopomofo"), Text::lit("Brahmi"), Text::lit("Braille"), Text::lit("Buginese"), Text::lit("Buhid"), Text::lit("Canadian_Aboriginal"), Text::lit("Carian"), Text::lit("Caucasian_Albanian"), Text::lit("Chakma"), Text::lit("Cham"), Text::lit("Cherokee"), Text::lit("Chorasmian"), Text::lit("Common"), Text::lit("Coptic"), Text::lit("Cuneiform"), Text::lit("Cypriot"), Text::lit("Cypro_Minoan"), Text::lit("Cyrillic"), Text::lit("Deseret"), Text::lit("Devanagari"), Text::lit("Dives_Akuru"), Text::lit("Dogra"), Text::lit("Duployan"), Text::lit("Egyptian_Hieroglyphs"), Text::lit("Elbasan"), Text::lit("Elymaic"), Text::lit("Ethiopic"), Text::lit("Georgian"), Text::lit("Glagolitic"), Text::lit("Gothic"), Text::lit("Grantha"), Text::lit("Greek"), Text::lit("Gujarati"), Text::lit("Gunjala_Gondi"), Text::lit("Gurmukhi"), Text::lit("Han"), Text::lit("Hangul"), Text::lit("Hanifi_Rohingya"), Text::lit("Hanunoo"), Text::lit("Hatran"), Text::lit("Hebrew"), Text::lit("Hiragana"), Text::lit("Imperial_Aramaic"), Text::lit("Inherited"), Text::lit("Inscriptional_Pahlavi"), Text::lit("Inscriptional_Parthian"), Text::lit("Javanese"), Text::lit("Kaithi"), Text::lit("Kannada"), Text::lit("Katakana"), Text::lit("Kawi"), Text::lit("Kayah_Li"), Text::lit("Kharoshthi"), Text::lit("Khitan_Small_Script"), Text::lit("Khmer"), Text::lit("Khojki"), Text::lit("Khudawadi"), Text::lit("Lao"), Text::lit("Latin"), Text::lit("Lepcha"), Text::lit("Limbu"), Text::lit("Linear_A"), Text::lit("Linear_B"), Text::lit("Lisu"), Text::lit("Lycian"), Text::lit("Lydian"), Text::lit("Mahajani"), Text::lit("Makasar"), Text::lit("Malayalam"), Text::lit("Mandaic"), Text::lit("Manichaean"), Text::lit("Marchen"), Text::lit("Masaram_Gondi"), Text::lit("Medefaidrin"), Text::lit("Meetei_Mayek"), Text::lit("Mende_Kikakui"), Text::lit("Meroitic_Cursive"), Text::lit("Meroitic_Hieroglyphs"), Text::lit("Miao"), Text::lit("Modi"), Text::lit("Mongolian"), Text::lit("Mro"), Text::lit("Multani"), Text::lit("Myanmar"), Text::lit("Nabataean"), Text::lit("Nag_Mundari"), Text::lit("Nandinagari"), Text::lit("New_Tai_Lue"), Text::lit("Newa"), Text::lit("Nko"), Text::lit("Nushu"), Text::lit("Nyiakeng_Puachue_Hmong"), Text::lit("Ogham"), Text::lit("Ol_Chiki"), Text::lit("Old_Hungarian"), Text::lit("Old_Italic"), Text::lit("Old_North_Arabian"), Text::lit("Old_Permic"), Text::lit("Old_Persian"), Text::lit("Old_Sogdian"), Text::lit("Old_South_Arabian"), Text::lit("Old_Turkic"), Text::lit("Old_Uyghur"), Text::lit("Oriya"), Text::lit("Osage"), Text::lit("Osmanya"), Text::lit("Pahawh_Hmong"), Text::lit("Palmyrene"), Text::lit("Pau_Cin_Hau"), Text::lit("Phags_Pa"), Text::lit("Phoenician"), Text::lit("Psalter_Pahlavi"), Text::lit("Rejang"), Text::lit("Runic"), Text::lit("Samaritan"), Text::lit("Saurashtra"), Text::lit("Sharada"), Text::lit("Shavian"), Text::lit("Siddham"), Text::lit("SignWriting"), Text::lit("Sinhala"), Text::lit("Sogdian"), Text::lit("Sora_Sompeng"), Text::lit("Soyombo"), Text::lit("Sundanese"), Text::lit("Syloti_Nagri"), Text::lit("Syriac"), Text::lit("Tagalog"), Text::lit("Tagbanwa"), Text::lit("Tai_Le"), Text::lit("Tai_Tham"), Text::lit("Tai_Viet"), Text::lit("Takri"), Text::lit("Tamil"), Text::lit("Tangsa"), Text::lit("Tangut"), Text::lit("Telugu"), Text::lit("Thaana"), Text::lit("Thai"), Text::lit("Tibetan"), Text::lit("Tifinagh"), Text::lit("Tirhuta"), Text::lit("Toto"), Text::lit("Ugaritic"), Text::lit("Vai"), Text::lit("Vithkuqi"), Text::lit("Wancho"), Text::lit("Warang_Citi"), Text::lit("Yezidi"), Text::lit("Yi"), Text::lit("Zanabazar_Square")])
}

/// ```prism
/// let rxProperties
/// ```
pub fn rx_properties_p() -> Map<Text, bool> {
    crate::prelude::map(&crate::prelude::each(&crate::prelude::push(&crate::prelude::append(&rx_categories_p(), &rx_scripts_p()), &Text::lit("Any")), &(|n_p0: &Text| (n_p0.clone(), true))))
}

/// ```prism
/// let rxAsciiClasses
/// ```
pub fn rx_ascii_classes_p() -> Map<Text, bool> {
    crate::prelude::map(&crate::prelude::each(&Array::from(vec![Text::lit("alnum"), Text::lit("alpha"), Text::lit("ascii"), Text::lit("blank"), Text::lit("cntrl"), Text::lit("digit"), Text::lit("graph"), Text::lit("lower"), Text::lit("print"), Text::lit("punct"), Text::lit("space"), Text::lit("upper"), Text::lit("word"), Text::lit("xdigit")]), &(|n_p0: &Text| (n_p0.clone(), true))))
}

/// ```prism
/// let rxAscii
/// ```
pub fn rx_ascii_p() -> Text {
    Text::lit("\0\t\n\r !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")
}

/// ```prism
/// let rxPunctuation
/// ```
pub fn rx_punctuation_p() -> Text {
    Text::lit("!\"#$%&\'()*+,-./:;=?@[\\]^_`{|}~")
}

/// ```prism
/// let rxNone
/// ```
pub fn rx_none_p() -> RxMeasure {
    RxMeasure { depth_p: Nat::from(0u32), size_p: Nat::from(0u32), product_p: Nat::from(0u32) }
}

/// ```prism
/// let rxAtom
/// ```
pub fn rx_atom_p() -> RxMeasure {
    RxMeasure { depth_p: Nat::from(0u32), size_p: Nat::from(1u32), product_p: Nat::from(1u32) }
}

/// ```prism
/// RxThen: fn RxMeasure, RxMeasure -> RxMeasure
/// ```
pub fn rx_then_f(a_p0: &RxMeasure, b_p1: &RxMeasure) -> RxMeasure {
    RxMeasure { depth_p: crate::prelude::max(&a_p0.depth_p, &b_p1.depth_p), size_p: &a_p0.size_p + &b_p1.size_p, product_p: crate::prelude::max(&a_p0.product_p, &b_p1.product_p) }
}

/// ```prism
/// RxBad: fn RxState -> Bool
/// ```
pub fn rx_bad_f(st_p0: &RxState) -> bool {
    &st_p0.err_o != &None
}

/// ```prism
/// RxFail: fn RxState, Nat, Text -> RxState
/// ```
pub fn rx_fail_f(st_p0: &RxState, at_p1: &Nat, message_p2: &Text) -> RxState {
    if rx_bad_f(st_p0) {
        st_p0.clone()
    } else {
        RxState { s_p: st_p0.s_p.clone(), i_p: st_p0.i_p.clone(), open_p: st_p0.open_p.clone(), groups_p: st_p0.groups_p.clone(), names_p: st_p0.names_p.clone(), err_o: Some(RxDiag { part_p: Text::lit("pattern"), at_p: at_p1.clone(), message_p: message_p2.clone() }) }
    }
}

/// ```prism
/// RxGo: fn RxState, Nat -> RxState
/// ```
pub fn rx_go_f(st_p0: &RxState, n_p1: &Nat) -> RxState {
    let mut this: RxState = st_p0.clone();
    this.i_p = n_p1.clone();
    this
}

/// ```prism
/// RxPeek: fn RxState -> Text
/// ```
pub fn rx_peek_f(st_p0: &RxState) -> Text {
    rx_char_at_f(&st_p0.s_p, &st_p0.i_p)
}

/// ```prism
/// RxCharAt: fn Text, Nat -> Text
/// ```
pub fn rx_char_at_f(t_p0: &Text, n_p1: &Nat) -> Text {
    match crate::prelude::cursor_at(t_p0, n_p1) {
        Some(c_p2) => match crate::prelude::step(&crate::prelude::front(&crate::prelude::after(&c_p2))) {
            Some((_, one_p3)) => crate::prelude::before(&one_p3),
            None => Text::lit(""),
        },
        None => Text::lit(""),
    }
}

/// ```prism
/// RxSlice: fn Text, Nat, Nat -> Text
/// ```
pub fn rx_slice_f(t_p0: &Text, a_p1: &Nat, b_p2: &Nat) -> Text {
    match crate::prelude::cursor_at(t_p0, b_p2) {
        Some(cb_p3) => match crate::prelude::cursor_at(&crate::prelude::before(&cb_p3), a_p1) {
            Some(ca_p4) => crate::prelude::after(&ca_p4),
            None => Text::lit(""),
        },
        None => Text::lit(""),
    }
}

/// ```prism
/// ?RxFind: fn Text, Nat, Text -> ?Nat
/// ```
pub fn rx_find_o(t_p0: &Text, from_p1: &Nat, x_p2: &Text) -> Option<Nat> {
    match crate::prelude::cursor_at(t_p0, from_p1) {
        None => None,
        Some(c0_p3) => {
            let (found_o7, _) = {
                let mut this: (Option<Nat>, Cursor) = (None, c0_p3.clone());
                let mut c_p4: Cursor = c0_p3.clone();
                let mut found_o5: Option<Nat> = None;
                while let Some((_, next_p6)) = crate::prelude::step(&c_p4) {
                    if !(&found_o5 == &None) {
                        break;
                    }
                    if &rx_slice_f(t_p0, &crate::prelude::at(&c_p4), &crate::prelude::at(&next_p6)) == x_p2 {
                        found_o5 = Some(crate::prelude::at(&c_p4));
                    }
                    c_p4 = next_p6.clone();
                }
                this = (found_o5.clone(), c_p4.clone());
                this
            };
            found_o7.clone()
        },
    }
}

/// ```prism
/// RxIn: fn Text, Text -> Bool
/// ```
pub fn rx_in_f(set_p0: &Text, c_p1: &Text) -> bool {
    (c_p1 != &Text::lit("")) && (&rx_find_o(set_p0, &Nat::from(0u32), c_p1) != &None)
}

/// ```prism
/// RxIsDigit: fn Text -> Bool
/// ```
pub fn rx_is_digit_f(c_p0: &Text) -> bool {
    ((&Text::lit("0") <= c_p0) && (c_p0 <= &Text::lit("9"))) && (&crate::prelude::len_text(c_p0) == &Nat::from(1u32))
}

/// ```prism
/// RxIsLetter: fn Text -> Bool
/// ```
pub fn rx_is_letter_f(c_p0: &Text) -> bool {
    ((&Text::lit("a") <= c_p0) && (c_p0 <= &Text::lit("z"))) || ((&Text::lit("A") <= c_p0) && (c_p0 <= &Text::lit("Z")))
}

/// ```prism
/// RxIsHex: fn Text -> Bool
/// ```
pub fn rx_is_hex_f(c_p0: &Text) -> bool {
    (rx_is_digit_f(c_p0) || ((&Text::lit("a") <= c_p0) && (c_p0 <= &Text::lit("f")))) || ((&Text::lit("A") <= c_p0) && (c_p0 <= &Text::lit("F")))
}

/// ```prism
/// RxIsName: fn Text -> Bool
/// ```
pub fn rx_is_name_f(t_p0: &Text) -> bool {
    let first_p1 = rx_char_at_f(t_p0, &Nat::from(0u32));
    ((t_p0 != &Text::lit("")) && (((&Text::lit("a") <= &first_p1) && (&first_p1 <= &Text::lit("z"))) || (&first_p1 == &Text::lit("_")))) && rx_all_f(t_p0, &(Rc::new(move |p0: Text| crate::prelude::once_job(move || {
        let c_p2 = p0;
        prism_rtl::Turn::Finished((((&Text::lit("a") <= &c_p2) && (&c_p2 <= &Text::lit("z"))) || rx_is_digit_f(&c_p2)) || (&c_p2 == &Text::lit("_")))
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// ```prism
/// RxAll: fn Text, (fn Text -> Bool) -> Bool
/// ```
pub fn rx_all_f(t_p0: &Text, p_f1: &Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> bool {
    let mut this: bool = true;
    let mut c_p2: Cursor = crate::prelude::front(t_p0);
    while let Some((_, next_p3)) = crate::prelude::step(&c_p2) {
        if !crate::prelude::run_to_end(p_f1(rx_slice_f(t_p0, &crate::prelude::at(&c_p2), &crate::prelude::at(&next_p3)))) {
            this = false;
        }
        c_p2 = next_p3.clone();
    }
    this
}

/// The step machine of `RxAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxAll: fn Text, (fn Text -> Bool) -> Bool
/// ```
pub struct RxAll {
    pub t_p0: Text,
    pub p_f1: Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>,
}

impl prism_rtl::Job<bool> for RxAll {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        let p_f1 = &self.p_f1;
        prism_rtl::Turn::Finished({
            let mut this: bool = true;
            let mut c_p2: Cursor = crate::prelude::front(t_p0);
            while let Some((_, next_p3)) = crate::prelude::step(&c_p2) {
                if !crate::prelude::run_to_end(p_f1(rx_slice_f(t_p0, &crate::prelude::at(&c_p2), &crate::prelude::at(&next_p3)))) {
                    this = false;
                }
                c_p2 = next_p3.clone();
            }
            this
        })
    }
}

/// `Start RxAll, x`: what the function value is when passed to `@Run`.
pub fn start_rx_all_f(t_p0: Text, p_f1: Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(RxAll { t_p0, p_f1 })
}

/// ```prism
/// RxSpanEnd: unbounded fn Text, Nat, (fn Text -> Bool) -> Nat
/// ```
pub fn rx_span_end_f(t_p0: &Text, at_p1: &Nat, p_f2: &Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> Nat {
    let mut this: Nat = at_p1.clone();
    while crate::prelude::run_to_end(p_f2(rx_char_at_f(t_p0, &this))) {
        this = &this + &Nat::from(1u32);
    }
    this
}

/// The step machine of `RxSpanEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxSpanEnd: unbounded fn Text, Nat, (fn Text -> Bool) -> Nat
/// ```
pub struct RxSpanEnd {
    pub t_p0: Text,
    pub at_p1: Nat,
    pub p_f2: Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>,
}

impl prism_rtl::Job<Nat> for RxSpanEnd {
    fn cycle(&self) -> prism_rtl::Turn<Nat> {
        let t_p0 = &self.t_p0;
        let at_p1 = &self.at_p1;
        let p_f2 = &self.p_f2;
        let mut this: Nat = at_p1.clone();
        crate::prelude::call_then(crate::prelude::loop_job((this,), {
            let p_f2x = p_f2.clone();
            let t_p0x = t_p0.clone();
            move |(mut this,): (Nat,)| if crate::prelude::run_to_end((&p_f2x)(rx_char_at_f(&t_p0x, &this))) {
                {
                    this = &this + &Nat::from(1u32);
                    Ok((this,))
                }
            } else {
                Err((this,))
            }
        }), move |(mut this,): (Nat,)| prism_rtl::Turn::Finished(this))
    }
}

/// `Start RxSpanEnd, x`: what the function value is when passed to `@Run`.
pub fn start_rx_span_end_f(t_p0: Text, at_p1: Nat, p_f2: Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> Rc<dyn prism_rtl::Job<Nat>> {
    Rc::new(RxSpanEnd { t_p0, at_p1, p_f2 })
}

/// ```prism
/// RxHexValue: fn Text -> Nat
/// ```
pub fn rx_hex_value_f(t_p0: &Text) -> Nat {
    let mut this: Nat = Nat::from(0u32);
    let mut c_p1: Cursor = crate::prelude::front(t_p0);
    while let Some((_, next_p2)) = crate::prelude::step(&c_p1) {
        let d_p3 = rx_slice_f(t_p0, &crate::prelude::at(&c_p1), &crate::prelude::at(&next_p2));
        this = &(&this * &Nat::from(16u32)) + &crate::prelude::or(&rx_find_o(&Text::lit("0123456789abcdef"), &Nat::from(0u32), &crate::prelude::lower(&d_p3)), &Nat::from(0u32));
        c_p1 = next_p2.clone();
    }
    this
}

/// ```prism
/// RxCpOf: fn Nat -> RxCp
/// ```
pub fn rx_cp_of_f(v_p0: &Nat) -> RxCp {
    if v_p0 < &Nat::from(128u32) {
        RxCp::RxLit(rx_char_at_f(&rx_ascii_p(), v_p0))
    } else {
        RxCp::RxNum(v_p0.clone())
    }
}

/// ```prism
/// RxWidth: fn Nat -> Nat
/// ```
pub fn rx_width_f(v_p0: &Nat) -> Nat {
    if v_p0 < &Nat::from(128u32) {
        Nat::from(1u32)
    } else {
        if v_p0 < &Nat::from(2048u32) {
            Nat::from(2u32)
        } else {
            if v_p0 < &Nat::from(65536u32) { Nat::from(3u32) } else { Nat::from(4u32) }
        }
    }
}

/// ```prism
/// RxPast: fn RxCp, RxCp -> Bool
/// ```
pub fn rx_past_f(rx_cp0: &RxCp, rx_cp1: &RxCp) -> bool {
    match (rx_cp0, rx_cp1) {
        (RxCp::RxLit(a_p0), RxCp::RxLit(b_p1)) => a_p0 > b_p1,
        (RxCp::RxNum(a_p2), RxCp::RxNum(b_p3)) => a_p2 > b_p3,
        (RxCp::RxLit(a_p4), RxCp::RxNum(b_p5)) => if &crate::prelude::len_text(a_p4) != &rx_width_f(b_p5) {
            &crate::prelude::len_text(a_p4) > &rx_width_f(b_p5)
        } else {
            !rx_in_range_f(a_p4, &Nat::from(0u32), b_p5)
        },
        (RxCp::RxNum(a_p6), RxCp::RxLit(b_p7)) => if &rx_width_f(a_p6) != &crate::prelude::len_text(b_p7) {
            &rx_width_f(a_p6) > &crate::prelude::len_text(b_p7)
        } else {
            !rx_in_range_f(b_p7, a_p6, &Nat::from(1114111u32))
        },
    }
}

/// ```prism
/// RxInRange: fn Text, Nat, Nat -> Bool
/// ```
pub fn rx_in_range_f(c_p0: &Text, lo_p1: &Nat, hi_p2: &Nat) -> bool {
    match crate::prelude::regex(&Text::from(format!("[\\x{{{}}}-\\x{{{}}}]", &rx_hex_text_f(lo_p1), &rx_hex_text_f(hi_p2)))) {
        Some(r_p3) => &crate::prelude::find(&r_p3, c_p0) != &None,
        None => false,
    }
}

/// ```prism
/// RxHexText: fn Nat -> Text
/// ```
pub fn rx_hex_text_f(n_p0: &Nat) -> Text {
    let mut this: Text = Text::lit("");
    let mut k_p1: Nat = n_p0.clone();
    let mut fuel_p2: Nat = Nat::from(6u32);
    while let Some(left_p3) = (&fuel_p2).checked_sub(&Nat::from(1u32)) {
        fuel_p2 = left_p3.clone();
        this = Text::from(format!("{}{}", &rx_char_at_f(&Text::lit("0123456789abcdef"), &crate::prelude::or(&crate::prelude::mod_(&k_p1, &Nat::from(16u32)), &Nat::from(0u32))), &this));
        k_p1 = crate::prelude::or(&crate::prelude::div(&k_p1, &Nat::from(16u32)), &Nat::from(0u32));
    }
    this
}

/// ```prism
/// ?RegexRefusal: unbounded fn Text, Text, ?Text -> ?RxDiag
/// ```
pub fn regex_refusal_o(pattern_p0: &Text, flags_p1: &Text, replacement_o2: &Option<Text>) -> Option<RxDiag> {
    match rx_flags_refusal_o(flags_p1) {
        Some(d_p3) => Some(d_p3),
        None => {
            let st0_p4 = RxState { s_p: pattern_p0.clone(), i_p: Nat::from(0u32), open_p: Nat::from(0u32), groups_p: Nat::from(0u32), names_p: Map::new(), err_o: None };
            let (m_p5, st_p6) = rx_alternation_f(&st0_p4, &(&rx_find_o(flags_p1, &Nat::from(0u32), &Text::lit("i")) != &None));
            match &st_p6.err_o {
                Some(d_p7) => Some(d_p7.clone()),
                None => if &st_p6.i_p < &crate::prelude::len_text(pattern_p0) {
                    Some(RxDiag { part_p: Text::lit("pattern"), at_p: st_p6.i_p.clone(), message_p: rx_group_close_p() })
                } else {
                    if &m_p5.depth_p > &Nat::from(100u32) {
                        Some(RxDiag { part_p: Text::lit("pattern"), at_p: Nat::from(0u32), message_p: rx_nesting_p() })
                    } else {
                        if &m_p5.size_p > &Nat::from(10000u32) {
                            Some(RxDiag { part_p: Text::lit("pattern"), at_p: Nat::from(0u32), message_p: rx_size_p() })
                        } else {
                            match replacement_o2 {
                                None => None,
                                Some(r_p8) => rx_replacement_refusal_o(r_p8, &st_p6.groups_p, &st_p6.names_p),
                            }
                        }
                    }
                },
            }
        },
    }
}

/// The step machine of `RegexRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RegexRefusal: unbounded fn Text, Text, ?Text -> ?RxDiag
/// ```
pub struct RegexRefusal {
    pub pattern_p0: Text,
    pub flags_p1: Text,
    pub replacement_o2: Option<Text>,
}

impl prism_rtl::Job<Option<RxDiag>> for RegexRefusal {
    fn cycle(&self) -> prism_rtl::Turn<Option<RxDiag>> {
        let pattern_p0 = &self.pattern_p0;
        let flags_p1 = &self.flags_p1;
        let replacement_o2 = &self.replacement_o2;
        match rx_flags_refusal_o(flags_p1) {
            Some(d_p3) => prism_rtl::Turn::Finished(Some(d_p3.clone())),
            None => {
                let st0_p4 = RxState { s_p: pattern_p0.clone(), i_p: Nat::from(0u32), open_p: Nat::from(0u32), groups_p: Nat::from(0u32), names_p: Map::new(), err_o: None };
                let replacement_o2x = replacement_o2.clone();
                let flags_p1x = flags_p1.clone();
                let pattern_p0x = pattern_p0.clone();
                crate::prelude::call_then(start_rx_alternation_f(st0_p4.clone(), &rx_find_o(&flags_p1x, &Nat::from(0u32), &Text::lit("i")) != &None), move |rx_alternation_f_15542: (RxMeasure, RxState)| {
                    let (m_p5, st_p6) = rx_alternation_f_15542;
                    match &st_p6.err_o {
                        Some(d_p7) => prism_rtl::Turn::Finished(Some(d_p7.clone())),
                        None => if &st_p6.i_p < &crate::prelude::len_text(&pattern_p0x) {
                            prism_rtl::Turn::Finished(Some(RxDiag { part_p: Text::lit("pattern"), at_p: st_p6.i_p.clone(), message_p: rx_group_close_p() }))
                        } else {
                            if &m_p5.depth_p > &Nat::from(100u32) {
                                prism_rtl::Turn::Finished(Some(RxDiag { part_p: Text::lit("pattern"), at_p: Nat::from(0u32), message_p: rx_nesting_p() }))
                            } else {
                                if &m_p5.size_p > &Nat::from(10000u32) {
                                    prism_rtl::Turn::Finished(Some(RxDiag { part_p: Text::lit("pattern"), at_p: Nat::from(0u32), message_p: rx_size_p() }))
                                } else {
                                    match &replacement_o2x {
                                        None => prism_rtl::Turn::Finished(None),
                                        Some(r_p8) => prism_rtl::Turn::More(Rc::new(RxReplacementRefusal { r_p0: r_p8.clone(), groups_p1: st_p6.groups_p.clone(), names_p2: st_p6.names_p.clone() })),
                                    }
                                }
                            }
                        },
                    }
                })
            },
        }
    }
}

/// `Start RegexRefusal, x`: what the function value is when passed to `@Run`.
pub fn start_regex_refusal_o(pattern_p0: Text, flags_p1: Text, replacement_o2: Option<Text>) -> Rc<dyn prism_rtl::Job<Option<RxDiag>>> {
    Rc::new(RegexRefusal { pattern_p0, flags_p1, replacement_o2 })
}

/// ```prism
/// ?RxFlagsRefusal: fn Text -> ?RxDiag
/// ```
pub fn rx_flags_refusal_o(flags_p0: &Text) -> Option<RxDiag> {
    let (d_o6, _) = {
        let mut this: (Option<RxDiag>, Text) = (None, Text::lit(""));
        let mut c_p1: Cursor = crate::prelude::front(flags_p0);
        let mut d_o2: Option<RxDiag> = None;
        let mut seen_p3: Text = Text::lit("");
        while let Some((_, next_p4)) = crate::prelude::step(&c_p1) {
            if !(&d_o2 == &None) {
                break;
            }
            let ch_p5 = rx_slice_f(flags_p0, &crate::prelude::at(&c_p1), &crate::prelude::at(&next_p4));
            if !(((&ch_p5 == &Text::lit("i")) || (&ch_p5 == &Text::lit("m"))) || (&ch_p5 == &Text::lit("s"))) {
                d_o2 = Some(RxDiag { part_p: Text::lit("flags"), at_p: crate::prelude::at(&c_p1), message_p: rx_unknown_flag_p() });
            } else if rx_in_f(&seen_p3, &ch_p5) {
                d_o2 = Some(RxDiag { part_p: Text::lit("flags"), at_p: crate::prelude::at(&c_p1), message_p: rx_flag_twice_p() });
            } else {
                seen_p3 = Text::from(format!("{}{}", &seen_p3, &ch_p5));
            }
            c_p1 = next_p4.clone();
        }
        this = (d_o2.clone(), seen_p3.clone());
        this
    };
    d_o6.clone()
}

/// ```prism
/// RxAlternation: unbounded fn RxState, Bool -> ((RxMeasure, RxState))
/// ```
pub fn rx_alternation_f(st0_p0: &RxState, fi0_p1: &bool) -> (RxMeasure, RxState) {
    let (m0_p2, fi1_p3, st1_p4) = rx_sequence_f(st0_p0, fi0_p1);
    let mut this: (RxMeasure, RxState) = (m0_p2.clone(), st1_p4.clone());
    let mut m_p5: RxMeasure = m0_p2.clone();
    let mut fi_p6: bool = fi1_p3;
    let mut st_p7: RxState = st1_p4.clone();
    while !rx_bad_f(&st_p7) && (&rx_peek_f(&st_p7) == &Text::lit("|")) {
        let (m2_p8, fi2_p9, st2_pa) = rx_sequence_f(&rx_go_f(&st_p7, &(&st_p7.i_p + &Nat::from(1u32))), &fi_p6);
        m_p5 = rx_then_f(&m_p5, &m2_p8);
        fi_p6 = fi2_p9;
        st_p7 = st2_pa.clone();
    }
    this = (m_p5.clone(), st_p7.clone());
    this
}

/// The step machine of `RxAlternation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxAlternation: unbounded fn RxState, Bool -> ((RxMeasure, RxState))
/// ```
pub struct RxAlternation {
    pub st0_p0: RxState,
    pub fi0_p1: bool,
}

impl prism_rtl::Job<(RxMeasure, RxState)> for RxAlternation {
    fn cycle(&self) -> prism_rtl::Turn<(RxMeasure, RxState)> {
        let st0_p0 = &self.st0_p0;
        let fi0_p1 = &self.fi0_p1;
        let fi0_p1x = *fi0_p1;
        let st0_p0x = st0_p0.clone();
        crate::prelude::call_then(start_rx_sequence_f(st0_p0x.clone(), fi0_p1x), move |rx_sequence_f_17135: (RxMeasure, bool, RxState)| {
            let (m0_p2, fi1_p3, st1_p4) = rx_sequence_f_17135;
            let mut this: (RxMeasure, RxState) = (m0_p2.clone(), st1_p4.clone());
            let mut m_p5: RxMeasure = m0_p2.clone();
            let mut fi_p6: bool = fi1_p3;
            let mut st_p7: RxState = st1_p4.clone();
            crate::prelude::call_then(crate::prelude::loop_job((this, fi_p6, m_p5, st_p7), move |(mut this, mut fi_p6, mut m_p5, mut st_p7): ((RxMeasure, RxState), bool, RxMeasure, RxState)| if !rx_bad_f(&st_p7) && (&rx_peek_f(&st_p7) == &Text::lit("|")) {
                {
                    let (m2_p8, fi2_p9, st2_pa) = rx_sequence_f(&rx_go_f(&st_p7, &(&st_p7.i_p + &Nat::from(1u32))), &fi_p6);
                    m_p5 = rx_then_f(&m_p5, &m2_p8);
                    fi_p6 = fi2_p9;
                    st_p7 = st2_pa.clone();
                    Ok((this, fi_p6, m_p5, st_p7))
                }
            } else {
                Err((this, fi_p6, m_p5, st_p7))
            }), move |(mut this, mut fi_p6, mut m_p5, mut st_p7): ((RxMeasure, RxState), bool, RxMeasure, RxState)| {
                this = (m_p5.clone(), st_p7.clone());
                prism_rtl::Turn::Finished(this)
            })
        })
    }
}

/// `Start RxAlternation, x`: what the function value is when passed to `@Run`.
pub fn start_rx_alternation_f(st0_p0: RxState, fi0_p1: bool) -> Rc<dyn prism_rtl::Job<(RxMeasure, RxState)>> {
    Rc::new(RxAlternation { st0_p0, fi0_p1 })
}

/// ```prism
/// RxSequence: unbounded fn RxState, Bool -> ((RxMeasure, Bool, RxState))
/// ```
pub fn rx_sequence_f(st0_p0: &RxState, fi0_p1: &bool) -> (RxMeasure, bool, RxState) {
    let mut this: (RxMeasure, bool, RxState) = (rx_none_p(), *fi0_p1, st0_p0.clone());
    let mut total_p2: RxMeasure = rx_none_p();
    let mut fi_p3: bool = *fi0_p1;
    let mut st_p4: RxState = st0_p0.clone();
    let mut last_p5: RxLast = RxLast::RxLastNothing;
    let mut last_m_p6: RxMeasure = rx_none_p();
    let mut going_p7: bool = true;
    while going_p7 && !rx_bad_f(&st_p4) {
        let c_p8 = rx_peek_f(&st_p4);
        let at_p9 = st_p4.i_p.clone();
        if ((&c_p8 == &Text::lit("")) || (&c_p8 == &Text::lit("|"))) || (&c_p8 == &Text::lit(")")) {
            going_p7 = false;
        } else if (((&c_p8 == &Text::lit("*")) || (&c_p8 == &Text::lit("+"))) || (&c_p8 == &Text::lit("?"))) || (&c_p8 == &Text::lit("{")) {
            let (lo_pa, hi_ob, st2_pc) = if &c_p8 == &Text::lit("{") {
                rx_count_f(&st_p4)
            } else {
                rx_simple_repetition_f(&st_p4, &c_p8)
            };
            st_p4 = st2_pc.clone();
            if !rx_bad_f(&st_p4) {
                st_p4 = match &last_p5 {
                    RxLast::RxLastNothing => rx_fail_f(&st_p4, &at_p9, &rx_nothing_to_repeat_p()),
                    RxLast::RxLastFlagGroup => rx_fail_f(&st_p4, &at_p9, &rx_nothing_to_repeat_p()),
                    RxLast::RxLastRepetition => rx_fail_f(&st_p4, &at_p9, &rx_repeat_repeat_p()),
                    RxLast::RxLastAssertion => rx_fail_f(&st_p4, &at_p9, &rx_repeat_assertion_p()),
                    RxLast::RxLastAtom => st_p4.clone(),
                };
            }
            if !rx_bad_f(&st_p4) {
                let counted_pd = &c_p8 == &Text::lit("{");
                let factor_pe = if counted_pd {
                    crate::prelude::max(&crate::prelude::or(&hi_ob, &lo_pa), &Nat::from(1u32))
                } else {
                    Nat::from(1u32)
                };
                let product_pf = &factor_pe * &crate::prelude::max(&last_m_p6.product_p, &Nat::from(1u32));
                if counted_pd && (&product_pf > &Nat::from(1000u32)) {
                    st_p4 = rx_fail_f(&st_p4, &at_p9, &rx_product_p());
                } else {
                    if &rx_peek_f(&st_p4) == &Text::lit("?") {
                        st_p4 = rx_go_f(&st_p4, &(&st_p4.i_p + &Nat::from(1u32)));
                    }
                    let m_pg = RxMeasure { depth_p: &last_m_p6.depth_p + &Nat::from(1u32), size_p: &last_m_p6.size_p * &factor_pe, product_p: product_pf.clone() };
                    total_p2 = RxMeasure { depth_p: crate::prelude::max(&total_p2.depth_p, &m_pg.depth_p), size_p: &crate::prelude::or(&(&total_p2.size_p).checked_sub(&last_m_p6.size_p), &Nat::from(0u32)) + &m_pg.size_p, product_p: crate::prelude::max(&total_p2.product_p, &m_pg.product_p) };
                    last_p5 = RxLast::RxLastRepetition;
                    last_m_p6 = m_pg.clone();
                }
            }
        } else {
            let (kind_ph, m_pi, fi2_pj, st2_pk) = rx_piece_f(&st_p4, &fi_p3);
            st_p4 = st2_pk.clone();
            fi_p3 = fi2_pj;
            if &kind_ph != &RxLast::RxLastFlagGroup {
                total_p2 = rx_then_f(&total_p2, &m_pi);
            }
            last_p5 = kind_ph.clone();
            last_m_p6 = m_pi.clone();
        }
    }
    this = (total_p2.clone(), fi_p3, st_p4.clone());
    this
}

/// The step machine of `RxSequence`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxSequence: unbounded fn RxState, Bool -> ((RxMeasure, Bool, RxState))
/// ```
pub struct RxSequence {
    pub st0_p0: RxState,
    pub fi0_p1: bool,
}

impl prism_rtl::Job<(RxMeasure, bool, RxState)> for RxSequence {
    fn cycle(&self) -> prism_rtl::Turn<(RxMeasure, bool, RxState)> {
        let st0_p0 = &self.st0_p0;
        let fi0_p1 = &self.fi0_p1;
        let mut this: (RxMeasure, bool, RxState) = (rx_none_p(), *fi0_p1, st0_p0.clone());
        let mut total_p2: RxMeasure = rx_none_p();
        let mut fi_p3: bool = *fi0_p1;
        let mut st_p4: RxState = st0_p0.clone();
        let mut last_p5: RxLast = RxLast::RxLastNothing;
        let mut last_m_p6: RxMeasure = rx_none_p();
        let mut going_p7: bool = true;
        crate::prelude::call_then(crate::prelude::loop_job((this, fi_p3, going_p7, last_p5, last_m_p6, st_p4, total_p2), move |(mut this, mut fi_p3, mut going_p7, mut last_p5, mut last_m_p6, mut st_p4, mut total_p2): ((RxMeasure, bool, RxState), bool, bool, RxLast, RxMeasure, RxState, RxMeasure)| if going_p7 && !rx_bad_f(&st_p4) {
            {
                let c_p8 = rx_peek_f(&st_p4);
                let at_p9 = st_p4.i_p.clone();
                if ((&c_p8 == &Text::lit("")) || (&c_p8 == &Text::lit("|"))) || (&c_p8 == &Text::lit(")")) {
                    going_p7 = false;
                } else if (((&c_p8 == &Text::lit("*")) || (&c_p8 == &Text::lit("+"))) || (&c_p8 == &Text::lit("?"))) || (&c_p8 == &Text::lit("{")) {
                    let (lo_pa, hi_ob, st2_pc) = if &c_p8 == &Text::lit("{") {
                        rx_count_f(&st_p4)
                    } else {
                        rx_simple_repetition_f(&st_p4, &c_p8)
                    };
                    st_p4 = st2_pc.clone();
                    if !rx_bad_f(&st_p4) {
                        st_p4 = match &last_p5 {
                            RxLast::RxLastNothing => rx_fail_f(&st_p4, &at_p9, &rx_nothing_to_repeat_p()),
                            RxLast::RxLastFlagGroup => rx_fail_f(&st_p4, &at_p9, &rx_nothing_to_repeat_p()),
                            RxLast::RxLastRepetition => rx_fail_f(&st_p4, &at_p9, &rx_repeat_repeat_p()),
                            RxLast::RxLastAssertion => rx_fail_f(&st_p4, &at_p9, &rx_repeat_assertion_p()),
                            RxLast::RxLastAtom => st_p4.clone(),
                        };
                    }
                    if !rx_bad_f(&st_p4) {
                        let counted_pd = &c_p8 == &Text::lit("{");
                        let factor_pe = if counted_pd {
                            crate::prelude::max(&crate::prelude::or(&hi_ob, &lo_pa), &Nat::from(1u32))
                        } else {
                            Nat::from(1u32)
                        };
                        let product_pf = &factor_pe * &crate::prelude::max(&last_m_p6.product_p, &Nat::from(1u32));
                        if counted_pd && (&product_pf > &Nat::from(1000u32)) {
                            st_p4 = rx_fail_f(&st_p4, &at_p9, &rx_product_p());
                        } else {
                            if &rx_peek_f(&st_p4) == &Text::lit("?") {
                                st_p4 = rx_go_f(&st_p4, &(&st_p4.i_p + &Nat::from(1u32)));
                            }
                            let m_pg = RxMeasure { depth_p: &last_m_p6.depth_p + &Nat::from(1u32), size_p: &last_m_p6.size_p * &factor_pe, product_p: product_pf.clone() };
                            total_p2 = RxMeasure { depth_p: crate::prelude::max(&total_p2.depth_p, &m_pg.depth_p), size_p: &crate::prelude::or(&(&total_p2.size_p).checked_sub(&last_m_p6.size_p), &Nat::from(0u32)) + &m_pg.size_p, product_p: crate::prelude::max(&total_p2.product_p, &m_pg.product_p) };
                            last_p5 = RxLast::RxLastRepetition;
                            last_m_p6 = m_pg.clone();
                        }
                    }
                } else {
                    let (kind_ph, m_pi, fi2_pj, st2_pk) = rx_piece_f(&st_p4, &fi_p3);
                    st_p4 = st2_pk.clone();
                    fi_p3 = fi2_pj;
                    if &kind_ph != &RxLast::RxLastFlagGroup {
                        total_p2 = rx_then_f(&total_p2, &m_pi);
                    }
                    last_p5 = kind_ph.clone();
                    last_m_p6 = m_pi.clone();
                }
                Ok((this, fi_p3, going_p7, last_p5, last_m_p6, st_p4, total_p2))
            }
        } else {
            Err((this, fi_p3, going_p7, last_p5, last_m_p6, st_p4, total_p2))
        }), move |(mut this, mut fi_p3, mut going_p7, mut last_p5, mut last_m_p6, mut st_p4, mut total_p2): ((RxMeasure, bool, RxState), bool, bool, RxLast, RxMeasure, RxState, RxMeasure)| {
            this = (total_p2.clone(), fi_p3, st_p4.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start RxSequence, x`: what the function value is when passed to `@Run`.
pub fn start_rx_sequence_f(st0_p0: RxState, fi0_p1: bool) -> Rc<dyn prism_rtl::Job<(RxMeasure, bool, RxState)>> {
    Rc::new(RxSequence { st0_p0, fi0_p1 })
}

/// ```prism
/// RxSimpleRepetition: fn RxState, Text -> ((Nat, ?Nat, RxState))
/// ```
pub fn rx_simple_repetition_f(st_p0: &RxState, c_p1: &Text) -> (Nat, Option<Nat>, RxState) {
    let st2_p2 = rx_go_f(st_p0, &(&st_p0.i_p + &Nat::from(1u32)));
    if c_p1 == &Text::lit("*") {
        (Nat::from(0u32), None, st2_p2.clone())
    } else {
        if c_p1 == &Text::lit("+") {
            (Nat::from(1u32), None, st2_p2.clone())
        } else {
            (Nat::from(0u32), Some(Nat::from(1u32)), st2_p2.clone())
        }
    }
}

/// ```prism
/// RxCount: unbounded fn RxState -> ((Nat, ?Nat, RxState))
/// ```
pub fn rx_count_f(st_p0: &RxState) -> (Nat, Option<Nat>, RxState) {
    let at_p1 = st_p0.i_p.clone();
    let s_p2 = st_p0.s_p.clone();
    let j1_p3 = rx_span_end_f(&s_p2, &(&at_p1 + &Nat::from(1u32)), &{
        let f = Rc::new(rx_is_digit_f);
        Rc::new(move |a0: Text| {
            let fy = f.clone();
            crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
    });
    let first_p4 = rx_slice_f(&s_p2, &(&at_p1 + &Nat::from(1u32)), &j1_p3);
    let c_p5 = rx_char_at_f(&s_p2, &j1_p3);
    if &first_p4 == &Text::lit("") {
        (Nat::from(0u32), None, rx_fail_f(st_p0, &at_p1, &rx_brace_p()))
    } else {
        if &c_p5 == &Text::lit("}") {
            rx_count_checked_f(st_p0, &at_p1, &first_p4, &None, &(&j1_p3 + &Nat::from(1u32)))
        } else {
            if &c_p5 == &Text::lit(",") {
                {
                    let j2_p6 = rx_span_end_f(&s_p2, &(&j1_p3 + &Nat::from(1u32)), &{
                        let f = Rc::new(rx_is_digit_f);
                        Rc::new(move |a0: Text| {
                            let fy = f.clone();
                            crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                    });
                    if &rx_char_at_f(&s_p2, &j2_p6) != &Text::lit("}") {
                        (Nat::from(0u32), None, rx_fail_f(st_p0, &at_p1, &rx_brace_p()))
                    } else {
                        rx_count_checked_f(st_p0, &at_p1, &first_p4, &Some(rx_slice_f(&s_p2, &(&j1_p3 + &Nat::from(1u32)), &j2_p6)), &(&j2_p6 + &Nat::from(1u32)))
                    }
                }
            } else {
                (Nat::from(0u32), None, rx_fail_f(st_p0, &at_p1, &rx_brace_p()))
            }
        }
    }
}

/// ```prism
/// RxCountChecked: fn RxState, Nat, Text, ?Text, Nat -> ((Nat, ?Nat, RxState))
/// ```
pub fn rx_count_checked_f(st_p0: &RxState, at_p1: &Nat, first_p2: &Text, second_o3: &Option<Text>, next_p4: &Nat) -> (Nat, Option<Nat>, RxState) {
    let st1_p5 = rx_go_f(st_p0, next_p4);
    let lo_p6 = crate::prelude::or(&crate::prelude::parse_nat_opt(first_p2), &Nat::from(0u32));
    let hi_o7 = match second_o3 {
        None => Some(lo_p6.clone()),
        Some(m20974_1) if (m20974_1 == &Text::lit("")) => None,
        Some(d_p9) => crate::prelude::parse_nat_opt(d_p9),
        _ => unreachable!("no arm matched"),
    };
    let zero_p8 = rx_leading_zero_f(first_p2) || rx_leading_zero_f(&crate::prelude::or(second_o3, &Text::lit("")));
    if zero_p8 {
        (Nat::from(0u32), None, rx_fail_f(&st1_p5, at_p1, &rx_count_zero_p()))
    } else {
        if (&lo_p6 > &Nat::from(1000u32)) || (&crate::prelude::or(&hi_o7, &Nat::from(0u32)) > &Nat::from(1000u32)) {
            (Nat::from(0u32), None, rx_fail_f(&st1_p5, at_p1, &rx_count_bound_p()))
        } else {
            if &lo_p6 > &crate::prelude::or(&hi_o7, &lo_p6) {
                (Nat::from(0u32), None, rx_fail_f(&st1_p5, at_p1, &rx_count_order_p()))
            } else {
                (lo_p6.clone(), hi_o7.clone(), st1_p5.clone())
            }
        }
    }
}

/// ```prism
/// RxLeadingZero: fn Text -> Bool
/// ```
pub fn rx_leading_zero_f(d_p0: &Text) -> bool {
    (&crate::prelude::len_text(d_p0) > &Nat::from(1u32)) && (&rx_char_at_f(d_p0, &Nat::from(0u32)) == &Text::lit("0"))
}

/// ```prism
/// RxPiece: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_piece_f(st_p0: &RxState, fi_p1: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let at_p2 = st_p0.i_p.clone();
    let c_p3 = rx_peek_f(st_p0);
    match &c_p3 {
        m21753_0 if (m21753_0 == &Text::lit("(")) => rx_group_f(st_p0, fi_p1),
        m21753_1 if (m21753_1 == &Text::lit("[")) => (RxLast::RxLastAtom, rx_atom_p(), *fi_p1, rx_class_f(st_p0, fi_p1)),
        m21753_2 if (m21753_2 == &Text::lit("]")) => (RxLast::RxLastAtom, rx_atom_p(), *fi_p1, rx_fail_f(st_p0, &at_p2, &rx_stray_bracket_p())),
        m21753_3 if (m21753_3 == &Text::lit("}")) => (RxLast::RxLastAtom, rx_atom_p(), *fi_p1, rx_fail_f(st_p0, &at_p2, &rx_stray_brace_p())),
        m21753_4 if (m21753_4 == &Text::lit("^")) => (RxLast::RxLastAssertion, rx_atom_p(), *fi_p1, rx_go_f(st_p0, &(&at_p2 + &Nat::from(1u32)))),
        m21753_5 if (m21753_5 == &Text::lit("$")) => (RxLast::RxLastAssertion, rx_atom_p(), *fi_p1, rx_go_f(st_p0, &(&at_p2 + &Nat::from(1u32)))),
        m21753_6 if (m21753_6 == &Text::lit("\\")) => rx_escape_f(st_p0, fi_p1),
        _ => (RxLast::RxLastAtom, rx_atom_p(), *fi_p1, rx_go_f(st_p0, &(&at_p2 + &crate::prelude::len_text(&c_p3)))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RxEscape: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_escape_f(st_p0: &RxState, fi_p1: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let at_p2 = st_p0.i_p.clone();
    let s_p3 = st_p0.s_p.clone();
    let c_p4 = rx_char_at_f(&s_p3, &(&at_p2 + &Nat::from(1u32)));
    let atom_f5 = {
        let fi_p1x = *fi_p1;
        Rc::new(move |next_p6: &RxState| (RxLast::RxLastAtom, rx_atom_p(), fi_p1x, next_p6.clone())) as Rc<dyn Fn(&RxState) -> (RxLast, RxMeasure, bool, RxState)>
    };
    if &c_p4 == &Text::lit("") {
        (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_trailing_backslash_p()))
    } else {
        if (&c_p4 == &Text::lit("<")) || (&c_p4 == &Text::lit(">")) {
            (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_angle_p()))
        } else {
            if rx_in_f(&rx_punctuation_p(), &c_p4) {
                (&atom_f5)(&rx_go_f(st_p0, &(&at_p2 + &Nat::from(2u32))))
            } else {
                if rx_in_f(&Text::lit("tnrfva"), &c_p4) {
                    (&atom_f5)(&rx_go_f(st_p0, &(&at_p2 + &Nat::from(2u32))))
                } else {
                    if &c_p4 == &Text::lit("x") {
                        {
                            let (_, st2_p7) = rx_hex_f(st_p0, &at_p2);
                            (&atom_f5)(&st2_p7)
                        }
                    } else {
                        if rx_in_f(&Text::lit("dwsDWS"), &c_p4) {
                            (&atom_f5)(&rx_go_f(st_p0, &(&at_p2 + &Nat::from(2u32))))
                        } else {
                            if (&c_p4 == &Text::lit("p")) || (&c_p4 == &Text::lit("P")) {
                                {
                                    let (_, st2_p8) = rx_property_f(st_p0, &at_p2);
                                    (&atom_f5)(&st2_p8)
                                }
                            } else {
                                if rx_in_f(&Text::lit("AzbB"), &c_p4) {
                                    if (&c_p4 == &Text::lit("b")) && (&rx_char_at_f(&s_p3, &(&at_p2 + &Nat::from(2u32))) == &Text::lit("{")) {
                                        (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_word_braces_p()))
                                    } else {
                                        (RxLast::RxLastAssertion, rx_atom_p(), *fi_p1, rx_go_f(st_p0, &(&at_p2 + &Nat::from(2u32))))
                                    }
                                } else {
                                    if rx_in_f(&Text::lit("123456789"), &c_p4) {
                                        (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_backreference_p()))
                                    } else {
                                        if &c_p4 == &Text::lit("0") {
                                            (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_octal_p()))
                                        } else {
                                            if (&c_p4 == &Text::lit("Q")) || (&c_p4 == &Text::lit("E")) {
                                                (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_quote_p()))
                                            } else {
                                                if &c_p4 == &Text::lit("C") {
                                                    (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_one_byte_p()))
                                                } else {
                                                    (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_unknown_escape_p()))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxHex: unbounded fn RxState, Nat -> ((Nat, RxState))
/// ```
pub fn rx_hex_f(st_p0: &RxState, at_p1: &Nat) -> (Nat, RxState) {
    let s_p2 = st_p0.s_p.clone();
    let x_p3 = at_p1 + &Nat::from(1u32);
    if &rx_char_at_f(&s_p2, &(&x_p3 + &Nat::from(1u32))) == &Text::lit("{") {
        {
            let start_p4 = &x_p3 + &Nat::from(2u32);
            let j_p5 = rx_span_end_f(&s_p2, &start_p4, &{
                let f = Rc::new(rx_is_hex_f);
                Rc::new(move |a0: Text| {
                    let fy = f.clone();
                    crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
            });
            let digits_p6 = rx_slice_f(&s_p2, &start_p4, &j_p5);
            if ((&rx_char_at_f(&s_p2, &j_p5) != &Text::lit("}")) || (&digits_p6 == &Text::lit(""))) || (&crate::prelude::len_text(&digits_p6) > &Nat::from(6u32)) {
                (Nat::from(0u32), rx_fail_f(st_p0, at_p1, &rx_hex_braces_p()))
            } else {
                rx_hex_checked_f(&rx_go_f(st_p0, &(&j_p5 + &Nat::from(1u32))), at_p1, &rx_hex_value_f(&digits_p6))
            }
        }
    } else {
        {
            let a_p7 = rx_char_at_f(&s_p2, &(&x_p3 + &Nat::from(1u32)));
            let b_p8 = rx_char_at_f(&s_p2, &(&x_p3 + &Nat::from(2u32)));
            if rx_is_hex_f(&a_p7) && rx_is_hex_f(&b_p8) {
                rx_hex_checked_f(&rx_go_f(st_p0, &(&x_p3 + &Nat::from(3u32))), at_p1, &rx_hex_value_f(&Text::from(format!("{}{}", &a_p7, &b_p8))))
            } else {
                (Nat::from(0u32), rx_fail_f(st_p0, at_p1, &rx_hex_two_p()))
            }
        }
    }
}

/// ```prism
/// RxHexChecked: fn RxState, Nat, Nat -> ((Nat, RxState))
/// ```
pub fn rx_hex_checked_f(st_p0: &RxState, at_p1: &Nat, v_p2: &Nat) -> (Nat, RxState) {
    if ((&Nat::from(55296u32) <= v_p2) && (v_p2 <= &Nat::from(57343u32))) || (v_p2 > &Nat::from(1114111u32)) {
        (v_p2.clone(), rx_fail_f(st_p0, at_p1, &rx_hex_no_char_p()))
    } else {
        (v_p2.clone(), st_p0.clone())
    }
}

/// ```prism
/// RxProperty: unbounded fn RxState, Nat -> ((Text, RxState))
/// ```
pub fn rx_property_f(st_p0: &RxState, at_p1: &Nat) -> (Text, RxState) {
    let s_p2 = st_p0.s_p.clone();
    let c_p3 = rx_char_at_f(&s_p2, &(at_p1 + &Nat::from(2u32)));
    if &c_p3 == &Text::lit("{") {
        {
            let start_p4 = at_p1 + &Nat::from(3u32);
            match rx_find_o(&s_p2, &start_p4, &Text::lit("}")) {
                None => (Text::lit(""), rx_fail_f(st_p0, at_p1, &rx_property_open_p())),
                Some(close_p5) => {
                    let name_p6 = rx_slice_f(&s_p2, &start_p4, &close_p5);
                    if &rx_char_at_f(&name_p6, &Nat::from(0u32)) == &Text::lit("^") {
                        (name_p6.clone(), rx_fail_f(st_p0, at_p1, &rx_property_negated_p()))
                    } else {
                        rx_property_named_f(&rx_go_f(st_p0, &(&close_p5 + &Nat::from(1u32))), at_p1, &name_p6)
                    }
                },
            }
        }
    } else {
        if rx_is_letter_f(&c_p3) {
            rx_property_named_f(&rx_go_f(st_p0, &(at_p1 + &Nat::from(3u32))), at_p1, &c_p3)
        } else {
            (Text::lit(""), rx_fail_f(st_p0, at_p1, &rx_property_name_p()))
        }
    }
}

/// ```prism
/// RxPropertyNamed: fn RxState, Nat, Text -> ((Text, RxState))
/// ```
pub fn rx_property_named_f(st_p0: &RxState, at_p1: &Nat, name_p2: &Text) -> (Text, RxState) {
    if (((name_p2 == &Text::lit("C")) || (name_p2 == &Text::lit("Cn"))) || (name_p2 == &Text::lit("Cs"))) || (name_p2 == &Text::lit("LC")) {
        (name_p2.clone(), rx_fail_f(st_p0, at_p1, &rx_property_refused_p()))
    } else {
        if &crate::prelude::get(&rx_properties_p(), name_p2) != &None {
            (name_p2.clone(), st_p0.clone())
        } else {
            (name_p2.clone(), rx_fail_f(st_p0, at_p1, &rx_property_unknown_p()))
        }
    }
}

/// ```prism
/// RxClass: unbounded fn RxState, Bool -> RxState
/// ```
pub fn rx_class_f(st0_p0: &RxState, fi_p1: &bool) -> RxState {
    let open_p2 = st0_p0.i_p.clone();
    let start_p3 = if &rx_char_at_f(&st0_p0.s_p, &(&open_p2 + &Nat::from(1u32))) == &Text::lit("^") {
        &open_p2 + &Nat::from(2u32)
    } else {
        &open_p2 + &Nat::from(1u32)
    };
    let mut this: RxState = rx_go_f(st0_p0, &start_p3);
    let mut first_p4: bool = true;
    let mut done_p5: bool = false;
    while !done_p5 {
        let (closed_p6, st2_p7) = rx_class_item_f(&this, &open_p2, &start_p3, &first_p4, fi_p1);
        this = st2_p7.clone();
        first_p4 = false;
        done_p5 = closed_p6 || rx_bad_f(&st2_p7);
    }
    this
}

/// ```prism
/// RxAtSetOperation: fn RxState -> Bool
/// ```
pub fn rx_at_set_operation_f(st_p0: &RxState) -> bool {
    let c_p1 = rx_peek_f(st_p0);
    (((&c_p1 == &Text::lit("&")) || (&c_p1 == &Text::lit("~"))) || (&c_p1 == &Text::lit("-"))) && (&rx_char_at_f(&st_p0.s_p, &(&st_p0.i_p + &Nat::from(1u32))) == &c_p1)
}

/// ```prism
/// RxClassItem: unbounded fn RxState, Nat, Nat, Bool, Bool -> ((Bool, RxState))
/// ```
pub fn rx_class_item_f(st_p0: &RxState, open_p1: &Nat, start_p2: &Nat, first_p3: &bool, fi_p4: &bool) -> (bool, RxState) {
    let at_p5 = st_p0.i_p.clone();
    let c_p6 = rx_peek_f(st_p0);
    let next_p7 = rx_char_at_f(&st_p0.s_p, &(&at_p5 + &Nat::from(1u32)));
    if &c_p6 == &Text::lit("") {
        (true, rx_fail_f(st_p0, open_p1, &rx_class_open_p()))
    } else {
        if (&c_p6 == &Text::lit("]")) && *first_p3 {
            (true, rx_fail_f(st_p0, &at_p5, &rx_class_first_bracket_p()))
        } else {
            if &c_p6 == &Text::lit("]") {
                (true, rx_go_f(st_p0, &(&at_p5 + &Nat::from(1u32))))
            } else {
                if rx_at_set_operation_f(st_p0) {
                    (true, rx_fail_f(st_p0, &at_p5, &rx_class_set_operation_p()))
                } else {
                    if &c_p6 == &Text::lit("[") {
                        (false, rx_ascii_item_f(st_p0, fi_p4))
                    } else {
                        if (&c_p6 == &Text::lit("-")) && (&next_p7 == &Text::lit("")) {
                            (true, rx_fail_f(st_p0, open_p1, &rx_class_open_p()))
                        } else {
                            if (&c_p6 == &Text::lit("-")) && ((&at_p5 == start_p2) || (&next_p7 == &Text::lit("]"))) {
                                (false, rx_go_f(st_p0, &(&at_p5 + &Nat::from(1u32))))
                            } else {
                                if &c_p6 == &Text::lit("-") {
                                    (true, rx_fail_f(st_p0, &at_p5, &rx_class_dash_p()))
                                } else {
                                    (false, rx_class_range_f(st_p0, open_p1, fi_p4))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxClassRange: unbounded fn RxState, Nat, Bool -> RxState
/// ```
pub fn rx_class_range_f(st_p0: &RxState, open_p1: &Nat, fi_p2: &bool) -> RxState {
    let at_p3 = st_p0.i_p.clone();
    let (lo_o4, st1_p5) = rx_class_atom_f(st_p0, fi_p2);
    match &lo_o4 {
        None => st1_p5.clone(),
        Some(lo_p6) => {
            let s_p7 = st1_p5.s_p.clone();
            let ranged_p8 = (&rx_peek_f(&st1_p5) == &Text::lit("-")) && (&rx_char_at_f(&s_p7, &(&st1_p5.i_p + &Nat::from(1u32))) != &Text::lit("]"));
            if rx_bad_f(&st1_p5) || !ranged_p8 {
                st1_p5.clone()
            } else {
                if rx_at_set_operation_f(&st1_p5) {
                    rx_fail_f(&st1_p5, &st1_p5.i_p, &rx_class_set_operation_p())
                } else {
                    {
                        let right_p9 = &st1_p5.i_p + &Nat::from(1u32);
                        let st2_pa = rx_go_f(&st1_p5, &right_p9);
                        let rc_pb = rx_peek_f(&st2_pa);
                        if &rc_pb == &Text::lit("") {
                            rx_fail_f(&st2_pa, open_p1, &rx_class_open_p())
                        } else {
                            if &rc_pb == &Text::lit("[") {
                                rx_fail_f(&st2_pa, &right_p9, &rx_class_nested_p())
                            } else {
                                if rx_at_set_operation_f(&st2_pa) {
                                    rx_fail_f(&st2_pa, &right_p9, &rx_class_set_operation_p())
                                } else {
                                    {
                                        let (hi_oc, st3_pd) = rx_class_atom_f(&st2_pa, fi_p2);
                                        if rx_bad_f(&st3_pd) {
                                            st3_pd.clone()
                                        } else {
                                            match &hi_oc {
                                                None => rx_fail_f(&st3_pd, &right_p9, &rx_class_range_set_p()),
                                                Some(hi_pe) => if rx_past_f(lo_p6, hi_pe) {
                                                    rx_fail_f(&st3_pd, &at_p3, &rx_class_order_p())
                                                } else {
                                                    st3_pd.clone()
                                                },
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
    }
}

/// ```prism
/// RxClassAtom: unbounded fn RxState, Bool -> ((?RxCp, RxState))
/// ```
pub fn rx_class_atom_f(st_p0: &RxState, fi_p1: &bool) -> (Option<RxCp>, RxState) {
    let at_p2 = st_p0.i_p.clone();
    let s_p3 = st_p0.s_p.clone();
    let c_p4 = rx_peek_f(st_p0);
    if &c_p4 != &Text::lit("\\") {
        (Some(RxCp::RxLit(c_p4.clone())), rx_go_f(st_p0, &(&at_p2 + &crate::prelude::len_text(&c_p4))))
    } else {
        {
            let e_p5 = rx_char_at_f(&s_p3, &(&at_p2 + &Nat::from(1u32)));
            if &e_p5 == &Text::lit("") {
                (None, rx_fail_f(st_p0, &at_p2, &rx_trailing_backslash_p()))
            } else {
                if (&e_p5 == &Text::lit("<")) || (&e_p5 == &Text::lit(">")) {
                    (None, rx_fail_f(st_p0, &at_p2, &rx_class_escape_p()))
                } else {
                    if rx_in_f(&rx_punctuation_p(), &e_p5) {
                        (Some(RxCp::RxLit(e_p5.clone())), rx_go_f(st_p0, &(&at_p2 + &Nat::from(2u32))))
                    } else {
                        if rx_in_f(&Text::lit("tnrfva"), &e_p5) {
                            (Some(RxCp::RxLit(rx_control_f(&e_p5))), rx_go_f(st_p0, &(&at_p2 + &Nat::from(2u32))))
                        } else {
                            if &e_p5 == &Text::lit("x") {
                                {
                                    let (v_p6, st2_p7) = rx_hex_f(st_p0, &at_p2);
                                    (Some(rx_cp_of_f(&v_p6)), st2_p7.clone())
                                }
                            } else {
                                if rx_in_f(&Text::lit("dws"), &e_p5) {
                                    (None, rx_go_f(st_p0, &(&at_p2 + &Nat::from(2u32))))
                                } else {
                                    if rx_in_f(&Text::lit("DWS"), &e_p5) {
                                        if *fi_p1 {
                                            (None, rx_fail_f(st_p0, &at_p2, &rx_class_negated_under_i_p()))
                                        } else {
                                            (None, rx_go_f(st_p0, &(&at_p2 + &Nat::from(2u32))))
                                        }
                                    } else {
                                        if (&e_p5 == &Text::lit("p")) || (&e_p5 == &Text::lit("P")) {
                                            {
                                                let (_, st2_p8) = rx_property_f(st_p0, &at_p2);
                                                if ((&e_p5 == &Text::lit("P")) && *fi_p1) && !rx_bad_f(&st2_p8) {
                                                    (None, rx_fail_f(&st2_p8, &at_p2, &rx_class_negated_under_i_p()))
                                                } else {
                                                    (None, st2_p8.clone())
                                                }
                                            }
                                        } else {
                                            (None, rx_fail_f(st_p0, &at_p2, &rx_class_escape_p()))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxControl: fn Text -> Text
/// ```
pub fn rx_control_f(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("t")) => Text::lit("\t"),
        c1_0 if (c1_0 == &Text::lit("n")) => Text::lit("\n"),
        c2_0 if (c2_0 == &Text::lit("r")) => Text::lit("\r"),
        c3_0 if (c3_0 == &Text::lit("f")) => Text::lit(""),
        c4_0 if (c4_0 == &Text::lit("v")) => Text::lit(""),
        _ => Text::lit(""),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RxAsciiItem: unbounded fn RxState, Bool -> RxState
/// ```
pub fn rx_ascii_item_f(st_p0: &RxState, fi_p1: &bool) -> RxState {
    let at_p2 = st_p0.i_p.clone();
    let s_p3 = st_p0.s_p.clone();
    let negated_p4 = &rx_char_at_f(&s_p3, &(&at_p2 + &Nat::from(2u32))) == &Text::lit("^");
    let start_p5 = if negated_p4 { &at_p2 + &Nat::from(3u32) } else { &at_p2 + &Nat::from(2u32) };
    let j_p6 = rx_span_end_f(&s_p3, &start_p5, &{
        let f = Rc::new(rx_is_letter_f);
        Rc::new(move |a0: Text| {
            let fy = f.clone();
            crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
    });
    let shaped_p7 = (((&rx_char_at_f(&s_p3, &(&at_p2 + &Nat::from(1u32))) == &Text::lit(":")) && (&j_p6 > &start_p5)) && (&rx_char_at_f(&s_p3, &j_p6) == &Text::lit(":"))) && (&rx_char_at_f(&s_p3, &(&j_p6 + &Nat::from(1u32))) == &Text::lit("]"));
    if !shaped_p7 {
        rx_fail_f(st_p0, &at_p2, &rx_class_nested_p())
    } else {
        if &crate::prelude::get(&rx_ascii_classes_p(), &rx_slice_f(&s_p3, &start_p5, &j_p6)) == &None {
            rx_fail_f(st_p0, &at_p2, &rx_class_ascii_unknown_p())
        } else {
            if negated_p4 && *fi_p1 {
                rx_fail_f(st_p0, &at_p2, &rx_class_negated_under_i_p())
            } else {
                rx_go_f(st_p0, &(&j_p6 + &Nat::from(2u32)))
            }
        }
    }
}

/// ```prism
/// RxGroup: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_group_f(st_p0: &RxState, fi_p1: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let open_p2 = st_p0.i_p.clone();
    let s_p3 = st_p0.s_p.clone();
    let c_p4 = rx_char_at_f(&s_p3, &(&open_p2 + &Nat::from(1u32)));
    let d_p5 = rx_char_at_f(&s_p3, &(&open_p2 + &Nat::from(2u32)));
    let e_p6 = rx_char_at_f(&s_p3, &(&open_p2 + &Nat::from(3u32)));
    let fail_f7 = {
        let fi_p1x = *fi_p1;
        let st_p0x = st_p0.clone();
        let open_p2x = open_p2.clone();
        Rc::new(move |message_p8: &Text| (RxLast::RxLastAtom, rx_atom_p(), fi_p1x, rx_fail_f(&st_p0x, &open_p2x, message_p8))) as Rc<dyn Fn(&Text) -> (RxLast, RxMeasure, bool, RxState)>
    };
    if &c_p4 != &Text::lit("?") {
        rx_group_body_f(&rx_go_f(st_p0, &(&open_p2 + &Nat::from(1u32))), &open_p2, fi_p1, fi_p1, &true, &None)
    } else {
        if &d_p5 == &Text::lit("") {
            (&fail_f7)(&rx_group_open_p())
        } else {
            if &d_p5 == &Text::lit(":") {
                rx_group_body_f(&rx_go_f(st_p0, &(&open_p2 + &Nat::from(3u32))), &open_p2, fi_p1, fi_p1, &false, &None)
            } else {
                if (&d_p5 == &Text::lit("=")) || (&d_p5 == &Text::lit("!")) {
                    (&fail_f7)(&rx_lookaround_p())
                } else {
                    if (&d_p5 == &Text::lit("<")) && ((&e_p6 == &Text::lit("=")) || (&e_p6 == &Text::lit("!"))) {
                        (&fail_f7)(&rx_lookaround_p())
                    } else {
                        if &d_p5 == &Text::lit("<") {
                            rx_named_f(st_p0, &open_p2, &(&open_p2 + &Nat::from(3u32)), fi_p1)
                        } else {
                            if (&d_p5 == &Text::lit("P")) && (&e_p6 == &Text::lit("")) {
                                (&fail_f7)(&rx_group_open_p())
                            } else {
                                if (&d_p5 == &Text::lit("P")) && (&e_p6 == &Text::lit("<")) {
                                    rx_named_f(st_p0, &open_p2, &(&open_p2 + &Nat::from(4u32)), fi_p1)
                                } else {
                                    if (&d_p5 == &Text::lit("P")) && ((&e_p6 == &Text::lit("=")) || (&e_p6 == &Text::lit(">"))) {
                                        (&fail_f7)(&rx_backreference_p())
                                    } else {
                                        if &d_p5 == &Text::lit("P") {
                                            (&fail_f7)(&rx_unknown_group_p())
                                        } else {
                                            if (rx_is_letter_f(&d_p5) || (&d_p5 == &Text::lit("-"))) || (&d_p5 == &Text::lit(")")) {
                                                rx_flag_group_f(st_p0, &open_p2, fi_p1)
                                            } else {
                                                (&fail_f7)(&rx_unknown_group_p())
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxNamed: unbounded fn RxState, Nat, Nat, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_named_f(st_p0: &RxState, open_p1: &Nat, start_p2: &Nat, fi_p3: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    match rx_find_o(&st_p0.s_p, start_p2, &Text::lit(">")) {
        None => (RxLast::RxLastAtom, rx_atom_p(), *fi_p3, rx_fail_f(st_p0, open_p1, &rx_name_open_p())),
        Some(close_p4) => {
            let name_p5 = rx_slice_f(&st_p0.s_p, start_p2, &close_p4);
            if !rx_is_name_f(&name_p5) {
                (RxLast::RxLastAtom, rx_atom_p(), *fi_p3, rx_fail_f(st_p0, start_p2, &rx_name_shape_p()))
            } else {
                if &crate::prelude::get(&st_p0.names_p, &name_p5) != &None {
                    (RxLast::RxLastAtom, rx_atom_p(), *fi_p3, rx_fail_f(st_p0, open_p1, &rx_name_twice_p()))
                } else {
                    rx_group_body_f(&rx_go_f(st_p0, &(&close_p4 + &Nat::from(1u32))), open_p1, fi_p3, fi_p3, &true, &Some(name_p5.clone()))
                }
            }
        },
    }
}

/// ```prism
/// RxFlagGroup: unbounded fn RxState, Nat, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_flag_group_f(st_p0: &RxState, open_p1: &Nat, fi_p2: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let (bare_p3, inner_p4, st2_p5) = rx_flag_letters_f(st_p0, open_p1, fi_p2);
    if rx_bad_f(&st2_p5) {
        (RxLast::RxLastAtom, rx_atom_p(), *fi_p2, st2_p5.clone())
    } else {
        if bare_p3 {
            (RxLast::RxLastFlagGroup, rx_none_p(), inner_p4, st2_p5.clone())
        } else {
            rx_group_body_f(&st2_p5, open_p1, &inner_p4, fi_p2, &false, &None)
        }
    }
}

/// ```prism
/// RxFlagLetters: unbounded fn RxState, Nat, Bool -> ((Bool, Bool, RxState))
/// ```
pub fn rx_flag_letters_f(st0_p0: &RxState, open_p1: &Nat, fi0_p2: &bool) -> (bool, bool, RxState) {
    let mut this: (bool, bool, RxState) = (false, *fi0_p2, st0_p0.clone());
    let mut st_p3: RxState = rx_go_f(st0_p0, &(open_p1 + &Nat::from(2u32)));
    let mut fi_p4: bool = *fi0_p2;
    let mut seen_p5: Text = Text::lit("");
    let mut dash_o6: Option<Nat> = None;
    let mut after_dash_p7: bool = false;
    let mut named_p8: bool = false;
    let mut bare_p9: bool = false;
    let mut going_pa: bool = true;
    while going_pa && !rx_bad_f(&st_p3) {
        let at_pb = st_p3.i_p.clone();
        let c_pc = rx_peek_f(&st_p3);
        if &c_pc == &Text::lit("") {
            st_p3 = rx_fail_f(&st_p3, open_p1, &rx_group_open_p());
        } else if (&c_pc == &Text::lit(")")) || (&c_pc == &Text::lit(":")) {
            if !named_p8 && (&dash_o6 == &None) {
                st_p3 = rx_fail_f(&st_p3, open_p1, &rx_flags_empty_p());
            } else {
                match &dash_o6 {
                    Some(d_pd) if !after_dash_p7 => {
                        st_p3 = rx_fail_f(&st_p3, d_pd, &rx_flags_dash_p());
                        ()
                    },
                    _ => {
                        st_p3 = rx_go_f(&st_p3, &(&at_pb + &Nat::from(1u32)));
                        bare_p9 = &c_pc == &Text::lit(")");
                        going_pa = false;
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
            }
        } else if &c_pc == &Text::lit("-") {
            if &dash_o6 != &None {
                st_p3 = rx_fail_f(&st_p3, &at_pb, &rx_flags_second_dash_p());
            } else {
                dash_o6 = Some(at_pb.clone());
                st_p3 = rx_go_f(&st_p3, &(&at_pb + &Nat::from(1u32)));
            }
        } else if rx_is_letter_f(&c_pc) {
            if !(((&c_pc == &Text::lit("i")) || (&c_pc == &Text::lit("m"))) || (&c_pc == &Text::lit("s"))) {
                st_p3 = rx_fail_f(&st_p3, &at_pb, &rx_unknown_flag_p());
            } else if rx_in_f(&seen_p5, &c_pc) {
                st_p3 = rx_fail_f(&st_p3, &at_pb, &rx_flag_twice_p());
            } else {
                seen_p5 = Text::from(format!("{}{}", &seen_p5, &c_pc));
                named_p8 = true;
                if &dash_o6 != &None {
                    after_dash_p7 = true;
                }
                if &c_pc == &Text::lit("i") {
                    fi_p4 = &dash_o6 == &None;
                }
                st_p3 = rx_go_f(&st_p3, &(&at_pb + &Nat::from(1u32)));
            }
        } else {
            st_p3 = rx_fail_f(&st_p3, open_p1, &rx_unknown_group_p());
        }
    }
    this = (bare_p9, fi_p4, st_p3.clone());
    this
}

/// ```prism
/// RxGroupBody: unbounded fn RxState, Nat, Bool, Bool, Bool, ?Text -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_group_body_f(st0_p0: &RxState, open_p1: &Nat, inner_p2: &bool, outer_p3: &bool, capture_p4: &bool, name_o5: &Option<Text>) -> (RxLast, RxMeasure, bool, RxState) {
    let counted_p6 = if *capture_p4 { rx_capture_f(st0_p0, name_o5) } else { st0_p0.clone() };
    if &counted_p6.open_p == &Nat::from(100u32) {
        (RxLast::RxLastAtom, rx_atom_p(), *outer_p3, rx_fail_f(&counted_p6, &Nat::from(0u32), &rx_nesting_p()))
    } else {
        {
            let deeper_p7 = {
                let mut this: RxState = counted_p6.clone();
                this.open_p = &this.open_p + &Nat::from(1u32);
                this
            };
            let (m_p8, st2_p9) = rx_alternation_f(&deeper_p7, inner_p2);
            if rx_bad_f(&st2_p9) {
                (RxLast::RxLastAtom, rx_atom_p(), *outer_p3, st2_p9.clone())
            } else {
                if &rx_peek_f(&st2_p9) != &Text::lit(")") {
                    (RxLast::RxLastAtom, rx_atom_p(), *outer_p3, rx_fail_f(&st2_p9, open_p1, &rx_group_open_p()))
                } else {
                    {
                        let closed_pa = {
                            let mut this: RxState = st2_p9.clone();
                            this.i_p = &this.i_p + &Nat::from(1u32);
                            this.open_p = crate::prelude::or(&(&this.open_p).checked_sub(&Nat::from(1u32)), &Nat::from(0u32));
                            this
                        };
                        (RxLast::RxLastAtom, RxMeasure { depth_p: &m_p8.depth_p + &Nat::from(1u32), size_p: m_p8.size_p.clone(), product_p: m_p8.product_p.clone() }, *outer_p3, closed_pa.clone())
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxCapture: fn RxState, ?Text -> RxState
/// ```
pub fn rx_capture_f(st_p0: &RxState, name_o1: &Option<Text>) -> RxState {
    let n_p2 = &st_p0.groups_p + &Nat::from(1u32);
    let names_p3 = match name_o1 {
        Some(x_p4) => crate::prelude::insert(&st_p0.names_p, x_p4, &n_p2),
        None => st_p0.names_p.clone(),
    };
    RxState { s_p: st_p0.s_p.clone(), i_p: st_p0.i_p.clone(), open_p: st_p0.open_p.clone(), groups_p: n_p2.clone(), names_p: names_p3.clone(), err_o: st_p0.err_o.clone() }
}

/// ```prism
/// ?RxReplacementRefusal: unbounded fn Text, Nat, (Text ==> Nat) -> ?RxDiag
/// ```
pub fn rx_replacement_refusal_o(r_p0: &Text, groups_p1: &Nat, names_p2: &Map<Text, Nat>) -> Option<RxDiag> {
    let (d_of, _) = {
        let mut this: (Option<RxDiag>, Nat) = (None, Nat::from(0u32));
        let mut i_p3: Nat = Nat::from(0u32);
        let mut d_o4: Option<RxDiag> = None;
        while (&d_o4 == &None) && (&rx_char_at_f(r_p0, &i_p3) != &Text::lit("")) {
            let at_p5 = i_p3.clone();
            let c_p6 = rx_char_at_f(r_p0, &at_p5);
            let next_p7 = rx_char_at_f(r_p0, &(&at_p5 + &Nat::from(1u32)));
            if &c_p6 == &Text::lit("$") {
                if &next_p7 == &Text::lit("$") {
                    i_p3 = &at_p5 + &Nat::from(2u32);
                } else if rx_is_digit_f(&next_p7) {
                    let j_p8 = rx_span_end_f(r_p0, &(&at_p5 + &Nat::from(1u32)), &{
                        let f = Rc::new(rx_is_digit_f);
                        Rc::new(move |a0: Text| {
                            let fy = f.clone();
                            crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                    });
                    d_o4 = rx_group_number_o(&rx_slice_f(r_p0, &(&at_p5 + &Nat::from(1u32)), &j_p8), groups_p1, &at_p5);
                    i_p3 = j_p8.clone();
                } else if &next_p7 == &Text::lit("{") {
                    match &rx_find_o(r_p0, &(&at_p5 + &Nat::from(2u32)), &Text::lit("}")) {
                        None => {
                            d_o4 = rx_replacement_at_o(&at_p5, &rx_rbraces_p());
                        }
                        Some(close_p9) => {
                            let inner_pa = rx_slice_f(r_p0, &(&at_p5 + &Nat::from(2u32)), close_p9);
                            if (&inner_pa != &Text::lit("")) && rx_all_f(&inner_pa, &{
                                let f = Rc::new(rx_is_digit_f);
                                Rc::new(move |a0: Text| {
                                    let fy = f.clone();
                                    crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
                                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                            }) {
                                d_o4 = rx_group_number_o(&inner_pa, groups_p1, &at_p5);
                            } else if rx_is_name_f(&inner_pa) {
                                if &crate::prelude::get(names_p2, &inner_pa) == &None {
                                    d_o4 = rx_replacement_at_o(&at_p5, &rx_rno_name_p());
                                }
                            } else {
                                d_o4 = rx_replacement_at_o(&at_p5, &rx_rbraces_p());
                            }
                            i_p3 = close_p9 + &Nat::from(1u32);
                        }
                    }
                } else {
                    d_o4 = rx_replacement_at_o(&at_p5, &rx_rdollar_p());
                }
            } else if &c_p6 == &Text::lit("\\") {
                if (((&next_p7 == &Text::lit("\\")) || (&next_p7 == &Text::lit("n"))) || (&next_p7 == &Text::lit("t"))) || (&next_p7 == &Text::lit("/")) {
                    i_p3 = &at_p5 + &Nat::from(2u32);
                } else if &next_p7 == &Text::lit("u") {
                    let j_pb = rx_span_end_f(r_p0, &(&at_p5 + &Nat::from(3u32)), &{
                        let f = Rc::new(rx_is_hex_f);
                        Rc::new(move |a0: Text| {
                            let fy = f.clone();
                            crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                    });
                    let digits_pc = rx_slice_f(r_p0, &(&at_p5 + &Nat::from(3u32)), &j_pb);
                    let v_pd = rx_hex_value_f(&digits_pc);
                    let named_pe = ((((&rx_char_at_f(r_p0, &(&at_p5 + &Nat::from(2u32))) == &Text::lit("{")) && (&rx_char_at_f(r_p0, &j_pb) == &Text::lit("}"))) && (&digits_pc != &Text::lit(""))) && (&crate::prelude::len_text(&digits_pc) <= &Nat::from(6u32))) && !(((&Nat::from(55296u32) <= &v_pd) && (&v_pd <= &Nat::from(57343u32))) || (&v_pd > &Nat::from(1114111u32)));
                    if named_pe {
                        i_p3 = &j_pb + &Nat::from(1u32);
                    } else {
                        d_o4 = rx_replacement_at_o(&at_p5, &rx_runicode_p());
                    }
                } else {
                    d_o4 = rx_replacement_at_o(&at_p5, &rx_rescape_p());
                }
            } else {
                i_p3 = &at_p5 + &crate::prelude::len_text(&c_p6);
            }
        }
        this = (d_o4.clone(), i_p3.clone());
        this
    };
    d_of.clone()
}

/// The step machine of `RxReplacementRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RxReplacementRefusal: unbounded fn Text, Nat, (Text ==> Nat) -> ?RxDiag
/// ```
pub struct RxReplacementRefusal {
    pub r_p0: Text,
    pub groups_p1: Nat,
    pub names_p2: Map<Text, Nat>,
}

impl prism_rtl::Job<Option<RxDiag>> for RxReplacementRefusal {
    fn cycle(&self) -> prism_rtl::Turn<Option<RxDiag>> {
        let r_p0 = &self.r_p0;
        let groups_p1 = &self.groups_p1;
        let names_p2 = &self.names_p2;
        let mut this: (Option<RxDiag>, Nat) = (None, Nat::from(0u32));
        let mut i_p3: Nat = Nat::from(0u32);
        let mut d_o4: Option<RxDiag> = None;
        crate::prelude::call_then(crate::prelude::loop_job((d_o4, this, i_p3), {
            let groups_p1x = groups_p1.clone();
            let names_p2x = names_p2.clone();
            let r_p0x = r_p0.clone();
            move |(mut d_o4, mut this, mut i_p3): (Option<RxDiag>, (Option<RxDiag>, Nat), Nat)| if (&d_o4 == &None) && (&rx_char_at_f(&r_p0x, &i_p3) != &Text::lit("")) {
                {
                    let at_p5 = i_p3.clone();
                    let c_p6 = rx_char_at_f(&r_p0x, &at_p5);
                    let next_p7 = rx_char_at_f(&r_p0x, &(&at_p5 + &Nat::from(1u32)));
                    if &c_p6 == &Text::lit("$") {
                        if &next_p7 == &Text::lit("$") {
                            i_p3 = &at_p5 + &Nat::from(2u32);
                        } else if rx_is_digit_f(&next_p7) {
                            let j_p8 = rx_span_end_f(&r_p0x, &(&at_p5 + &Nat::from(1u32)), &{
                                let f = Rc::new(rx_is_digit_f);
                                Rc::new(move |a0: Text| {
                                    let fy = f.clone();
                                    crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
                                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                            });
                            d_o4 = rx_group_number_o(&rx_slice_f(&r_p0x, &(&at_p5 + &Nat::from(1u32)), &j_p8), &groups_p1x, &at_p5);
                            i_p3 = j_p8.clone();
                        } else if &next_p7 == &Text::lit("{") {
                            match &rx_find_o(&r_p0x, &(&at_p5 + &Nat::from(2u32)), &Text::lit("}")) {
                                None => {
                                    d_o4 = rx_replacement_at_o(&at_p5, &rx_rbraces_p());
                                }
                                Some(close_p9) => {
                                    let inner_pa = rx_slice_f(&r_p0x, &(&at_p5 + &Nat::from(2u32)), close_p9);
                                    if (&inner_pa != &Text::lit("")) && rx_all_f(&inner_pa, &{
                                        let f = Rc::new(rx_is_digit_f);
                                        Rc::new(move |a0: Text| {
                                            let fy = f.clone();
                                            crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
                                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }) {
                                        d_o4 = rx_group_number_o(&inner_pa, &groups_p1x, &at_p5);
                                    } else if rx_is_name_f(&inner_pa) {
                                        if &crate::prelude::get(&names_p2x, &inner_pa) == &None {
                                            d_o4 = rx_replacement_at_o(&at_p5, &rx_rno_name_p());
                                        }
                                    } else {
                                        d_o4 = rx_replacement_at_o(&at_p5, &rx_rbraces_p());
                                    }
                                    i_p3 = close_p9 + &Nat::from(1u32);
                                }
                            }
                        } else {
                            d_o4 = rx_replacement_at_o(&at_p5, &rx_rdollar_p());
                        }
                    } else if &c_p6 == &Text::lit("\\") {
                        if (((&next_p7 == &Text::lit("\\")) || (&next_p7 == &Text::lit("n"))) || (&next_p7 == &Text::lit("t"))) || (&next_p7 == &Text::lit("/")) {
                            i_p3 = &at_p5 + &Nat::from(2u32);
                        } else if &next_p7 == &Text::lit("u") {
                            let j_pb = rx_span_end_f(&r_p0x, &(&at_p5 + &Nat::from(3u32)), &{
                                let f = Rc::new(rx_is_hex_f);
                                Rc::new(move |a0: Text| {
                                    let fy = f.clone();
                                    crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
                                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                            });
                            let digits_pc = rx_slice_f(&r_p0x, &(&at_p5 + &Nat::from(3u32)), &j_pb);
                            let v_pd = rx_hex_value_f(&digits_pc);
                            let named_pe = ((((&rx_char_at_f(&r_p0x, &(&at_p5 + &Nat::from(2u32))) == &Text::lit("{")) && (&rx_char_at_f(&r_p0x, &j_pb) == &Text::lit("}"))) && (&digits_pc != &Text::lit(""))) && (&crate::prelude::len_text(&digits_pc) <= &Nat::from(6u32))) && !(((&Nat::from(55296u32) <= &v_pd) && (&v_pd <= &Nat::from(57343u32))) || (&v_pd > &Nat::from(1114111u32)));
                            if named_pe {
                                i_p3 = &j_pb + &Nat::from(1u32);
                            } else {
                                d_o4 = rx_replacement_at_o(&at_p5, &rx_runicode_p());
                            }
                        } else {
                            d_o4 = rx_replacement_at_o(&at_p5, &rx_rescape_p());
                        }
                    } else {
                        i_p3 = &at_p5 + &crate::prelude::len_text(&c_p6);
                    }
                    Ok((d_o4, this, i_p3))
                }
            } else {
                Err((d_o4, this, i_p3))
            }
        }), move |(mut d_o4, mut this, mut i_p3): (Option<RxDiag>, (Option<RxDiag>, Nat), Nat)| {
            this = (d_o4.clone(), i_p3.clone());
            let (d_of, _) = this;
            prism_rtl::Turn::Finished(d_of.clone())
        })
    }
}

/// `Start RxReplacementRefusal, x`: what the function value is when passed to `@Run`.
pub fn start_rx_replacement_refusal_o(r_p0: Text, groups_p1: Nat, names_p2: Map<Text, Nat>) -> Rc<dyn prism_rtl::Job<Option<RxDiag>>> {
    Rc::new(RxReplacementRefusal { r_p0, groups_p1, names_p2 })
}

/// ```prism
/// ?RxReplacementAt: fn Nat, Text -> ?RxDiag
/// ```
pub fn rx_replacement_at_o(at_p0: &Nat, message_p1: &Text) -> Option<RxDiag> {
    Some(RxDiag { part_p: Text::lit("replacement"), at_p: at_p0.clone(), message_p: message_p1.clone() })
}

/// ```prism
/// ?RxGroupNumber: fn Text, Nat, Nat -> ?RxDiag
/// ```
pub fn rx_group_number_o(digits_p0: &Text, groups_p1: &Nat, at_p2: &Nat) -> Option<RxDiag> {
    if rx_leading_zero_f(digits_p0) {
        rx_replacement_at_o(at_p2, &rx_rzero_p())
    } else {
        if &crate::prelude::or(&crate::prelude::parse_nat_opt(digits_p0), &Nat::from(0u32)) > groups_p1 {
            rx_replacement_at_o(at_p2, &rx_rno_number_p())
        } else {
            None
        }
    }
}
