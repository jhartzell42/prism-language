//! The module `Check.Regex`, from `target/bootstrap/src/prismc/check/regex/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `RxCp`:
///
/// ```prism
/// type RxCp = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum RxCp {
    RxLit(Text),
    RxNum(Nat),
}

impl Show for RxCp {
    fn show(&self, p: &mut Printer) {
        match self {
            RxCp::RxLit(a0) => p.choice("RxLit", &[a0]),
            RxCp::RxNum(a0) => p.choice("RxNum", &[a0]),
        }
    }
}

impl ToPod for RxCp {
    fn to_pod(&self) -> Pod {
        match self {
            RxCp::RxLit(a0) => Pod::Choice("RxLit".into(), vec![a0.to_pod()]),
            RxCp::RxNum(a0) => Pod::Choice("RxNum".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for RxCp {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "RxLit" && a.len() == 1 => Ok(RxCp::RxLit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "RxNum" && a.len() == 1 => Ok(RxCp::RxNum(FromPod::from_pod(&a[0])?)),
            other => mismatch("a RxCp", other),
        }
    }
}

/// `RxDiag`:
///
/// ```prism
/// type RxDiag = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct RxDiag {
    pub part: Text,
    pub at: Nat,
    pub message: Text,
}

impl Show for RxDiag {
    fn show(&self, p: &mut Printer) {
        p.record("RxDiag", &[("part", &self.part), ("at", &self.at), ("message", &self.message)]);
    }
}

impl ToPod for RxDiag {
    fn to_pod(&self) -> Pod {
        Pod::record("RxDiag", vec![("part", self.part.to_pod()), ("at", self.at.to_pod()), ("message", self.message.to_pod())])
    }
}

impl FromPod for RxDiag {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RxDiag { part: FromPod::from_pod(field(p, "part")?)?, at: FromPod::from_pod(field(p, "at")?)?, message: FromPod::from_pod(field(p, "message")?)? })
    }
}

/// `RxLast`:
///
/// ```prism
/// type RxLast = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum RxLast {
    RxLastNothing,
    RxLastFlagGroup,
    RxLastAssertion,
    RxLastRepetition,
    RxLastAtom,
}

impl Show for RxLast {
    fn show(&self, p: &mut Printer) {
        match self {
            RxLast::RxLastNothing => p.choice("RxLastNothing", &[]),
            RxLast::RxLastFlagGroup => p.choice("RxLastFlagGroup", &[]),
            RxLast::RxLastAssertion => p.choice("RxLastAssertion", &[]),
            RxLast::RxLastRepetition => p.choice("RxLastRepetition", &[]),
            RxLast::RxLastAtom => p.choice("RxLastAtom", &[]),
        }
    }
}

impl ToPod for RxLast {
    fn to_pod(&self) -> Pod {
        match self {
            RxLast::RxLastNothing => Pod::Choice("RxLastNothing".into(), vec![]),
            RxLast::RxLastFlagGroup => Pod::Choice("RxLastFlagGroup".into(), vec![]),
            RxLast::RxLastAssertion => Pod::Choice("RxLastAssertion".into(), vec![]),
            RxLast::RxLastRepetition => Pod::Choice("RxLastRepetition".into(), vec![]),
            RxLast::RxLastAtom => Pod::Choice("RxLastAtom".into(), vec![]),
        }
    }
}

impl FromPod for RxLast {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "RxLastNothing" && a.len() == 0 => Ok(RxLast::RxLastNothing),
            Pod::Choice(c, a) if &**c == "RxLastFlagGroup" && a.len() == 0 => Ok(RxLast::RxLastFlagGroup),
            Pod::Choice(c, a) if &**c == "RxLastAssertion" && a.len() == 0 => Ok(RxLast::RxLastAssertion),
            Pod::Choice(c, a) if &**c == "RxLastRepetition" && a.len() == 0 => Ok(RxLast::RxLastRepetition),
            Pod::Choice(c, a) if &**c == "RxLastAtom" && a.len() == 0 => Ok(RxLast::RxLastAtom),
            other => mismatch("a RxLast", other),
        }
    }
}

/// `RxMeasure`:
///
/// ```prism
/// type RxMeasure = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct RxMeasure {
    pub depth: Nat,
    pub size: Nat,
    pub product: Nat,
}

impl Show for RxMeasure {
    fn show(&self, p: &mut Printer) {
        p.record("RxMeasure", &[("depth", &self.depth), ("size", &self.size), ("product", &self.product)]);
    }
}

impl ToPod for RxMeasure {
    fn to_pod(&self) -> Pod {
        Pod::record("RxMeasure", vec![("depth", self.depth.to_pod()), ("size", self.size.to_pod()), ("product", self.product.to_pod())])
    }
}

impl FromPod for RxMeasure {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RxMeasure { depth: FromPod::from_pod(field(p, "depth")?)?, size: FromPod::from_pod(field(p, "size")?)?, product: FromPod::from_pod(field(p, "product")?)? })
    }
}

/// `RxState`:
///
/// ```prism
/// type RxState = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct RxState {
    pub s: Text,
    pub i: Nat,
    pub open: Nat,
    pub groups: Nat,
    pub names: Map<Text, Nat>,
    pub err: Option<RxDiag>,
}

impl Show for RxState {
    fn show(&self, p: &mut Printer) {
        p.record("RxState", &[("s", &self.s), ("i", &self.i), ("open", &self.open), ("groups", &self.groups), ("names", &self.names), ("err", &self.err)]);
    }
}

impl ToPod for RxState {
    fn to_pod(&self) -> Pod {
        Pod::record("RxState", vec![("s", self.s.to_pod()), ("i", self.i.to_pod()), ("open", self.open.to_pod()), ("groups", self.groups.to_pod()), ("names", self.names.to_pod()), ("err", self.err.to_pod())])
    }
}

impl FromPod for RxState {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RxState { s: FromPod::from_pod(field(p, "s")?)?, i: FromPod::from_pod(field(p, "i")?)?, open: FromPod::from_pod(field(p, "open")?)?, groups: FromPod::from_pod(field(p, "groups")?)?, names: FromPod::from_pod(field(p, "names")?)?, err: FromPod::from_pod(field(p, "err")?)? })
    }
}

/// ```prism
/// let rxUnknownFlag
/// ```
pub fn rx_unknown_flag() -> Text {
    Text::lit("an unknown flag: the flags are i, m and s")
}

/// ```prism
/// let rxFlagTwice
/// ```
pub fn rx_flag_twice() -> Text {
    Text::lit("a flag written twice")
}

/// ```prism
/// let rxStrayBracket
/// ```
pub fn rx_stray_bracket() -> Text {
    Text::lit("a ] outside a class: a literal one is \\]")
}

/// ```prism
/// let rxStrayBrace
/// ```
pub fn rx_stray_brace() -> Text {
    Text::lit("a } outside a count: a literal one is \\}")
}

/// ```prism
/// let rxTrailingBackslash
/// ```
pub fn rx_trailing_backslash() -> Text {
    Text::lit("a \\ at the end of the pattern")
}

/// ```prism
/// let rxHexTwo
/// ```
pub fn rx_hex_two() -> Text {
    Text::lit("a \\x escape needs two hex digits or braces")
}

/// ```prism
/// let rxHexBraces
/// ```
pub fn rx_hex_braces() -> Text {
    Text::lit("a \\x{...} escape needs one to six hex digits")
}

/// ```prism
/// let rxHexNoChar
/// ```
pub fn rx_hex_no_char() -> Text {
    Text::lit("a \\x escape names no character: a surrogate or past U+10FFFF")
}

/// ```prism
/// let rxWordBraces
/// ```
pub fn rx_word_braces() -> Text {
    Text::lit("\\b{...} is Rust\'s only: write \\b")
}

/// ```prism
/// let rxAngle
/// ```
pub fn rx_angle() -> Text {
    Text::lit("\\< and \\> are Rust\'s only: write \\b")
}

/// ```prism
/// let rxBackreference
/// ```
pub fn rx_backreference() -> Text {
    Text::lit("a backreference: refused so that every match is linear in its text")
}

/// ```prism
/// let rxOctal
/// ```
pub fn rx_octal() -> Text {
    Text::lit("an octal escape is RE2\'s only: write \\x")
}

/// ```prism
/// let rxQuote
/// ```
pub fn rx_quote() -> Text {
    Text::lit("\\Q...\\E is RE2\'s only: escape each character")
}

/// ```prism
/// let rxOneByte
/// ```
pub fn rx_one_byte() -> Text {
    Text::lit("\\C, one byte, is RE2\'s only")
}

/// ```prism
/// let rxUnknownEscape
/// ```
pub fn rx_unknown_escape() -> Text {
    Text::lit("an unknown escape")
}

/// ```prism
/// let rxPropertyName
/// ```
pub fn rx_property_name() -> Text {
    Text::lit("a \\p escape needs a property name")
}

/// ```prism
/// let rxPropertyOpen
/// ```
pub fn rx_property_open() -> Text {
    Text::lit("a \\p{ that is never closed")
}

/// ```prism
/// let rxPropertyNegated
/// ```
pub fn rx_property_negated() -> Text {
    Text::lit("a negated property is written \\P{...}")
}

/// ```prism
/// let rxPropertyRefused
/// ```
pub fn rx_property_refused() -> Text {
    Text::lit("the property is refused: RE2 and Rust disagree on C, Cn, Cs and LC")
}

/// ```prism
/// let rxPropertyUnknown
/// ```
pub fn rx_property_unknown() -> Text {
    Text::lit("an unknown property: general categories by short name, scripts and Any")
}

/// ```prism
/// let rxClassOpen
/// ```
pub fn rx_class_open() -> Text {
    Text::lit("a class opened here is never closed")
}

/// ```prism
/// let rxClassFirstBracket
/// ```
pub fn rx_class_first_bracket() -> Text {
    Text::lit("a ] first in a class: write \\]")
}

/// ```prism
/// let rxClassNested
/// ```
pub fn rx_class_nested() -> Text {
    Text::lit("a [ inside a class: write \\[ (nested classes are Rust\'s only)")
}

/// ```prism
/// let rxClassAsciiUnknown
/// ```
pub fn rx_class_ascii_unknown() -> Text {
    Text::lit("an unknown ASCII class")
}

/// ```prism
/// let rxClassSetOperation
/// ```
pub fn rx_class_set_operation() -> Text {
    Text::lit("&&, ~~ and -- in a class are Rust\'s set operations: escape them")
}

/// ```prism
/// let rxClassDash
/// ```
pub fn rx_class_dash() -> Text {
    Text::lit("a - in a class that is neither a range nor first or last: write \\-")
}

/// ```prism
/// let rxClassOrder
/// ```
pub fn rx_class_order() -> Text {
    Text::lit("a range whose ends are out of order")
}

/// ```prism
/// let rxClassRangeSet
/// ```
pub fn rx_class_range_set() -> Text {
    Text::lit("a range end that is a class")
}

/// ```prism
/// let rxClassNegatedUnderI
/// ```
pub fn rx_class_negated_under_i() -> Text {
    Text::lit("a negated class inside a class under i: write it outside the class")
}

/// ```prism
/// let rxClassEscape
/// ```
pub fn rx_class_escape() -> Text {
    Text::lit("an escape that a class cannot hold")
}

/// ```prism
/// let rxLookaround
/// ```
pub fn rx_lookaround() -> Text {
    Text::lit("a lookaround: refused so that every match is linear in its text")
}

/// ```prism
/// let rxUnknownGroup
/// ```
pub fn rx_unknown_group() -> Text {
    Text::lit("an unknown group: the groups are (re), (?:re), (?<name>re), (?P<name>re) and the flag groups")
}

/// ```prism
/// let rxNameShape
/// ```
pub fn rx_name_shape() -> Text {
    Text::lit("a group name is a lowercase value name, [a-z_][a-z0-9_]*")
}

/// ```prism
/// let rxNameOpen
/// ```
pub fn rx_name_open() -> Text {
    Text::lit("a group name that is never closed")
}

/// ```prism
/// let rxNameTwice
/// ```
pub fn rx_name_twice() -> Text {
    Text::lit("a group name used twice")
}

/// ```prism
/// let rxGroupOpen
/// ```
pub fn rx_group_open() -> Text {
    Text::lit("a group opened here is never closed")
}

/// ```prism
/// let rxGroupClose
/// ```
pub fn rx_group_close() -> Text {
    Text::lit("a ) that closes no group")
}

/// ```prism
/// let rxFlagsEmpty
/// ```
pub fn rx_flags_empty() -> Text {
    Text::lit("an empty flag group")
}

/// ```prism
/// let rxFlagsSecondDash
/// ```
pub fn rx_flags_second_dash() -> Text {
    Text::lit("a second - in a flag group")
}

/// ```prism
/// let rxFlagsDash
/// ```
pub fn rx_flags_dash() -> Text {
    Text::lit("a - that turns off no flag")
}

/// ```prism
/// let rxBrace
/// ```
pub fn rx_brace() -> Text {
    Text::lit("a brace that opens no count: a literal one is \\{")
}

/// ```prism
/// let rxCountZero
/// ```
pub fn rx_count_zero() -> Text {
    Text::lit("a count with a leading zero")
}

/// ```prism
/// let rxCountBound
/// ```
pub fn rx_count_bound() -> Text {
    Text::lit("a count above 1000")
}

/// ```prism
/// let rxCountOrder
/// ```
pub fn rx_count_order() -> Text {
    Text::lit("a count whose minimum exceeds its maximum")
}

/// ```prism
/// let rxNothingToRepeat
/// ```
pub fn rx_nothing_to_repeat() -> Text {
    Text::lit("a repetition with nothing to repeat")
}

/// ```prism
/// let rxRepeatRepeat
/// ```
pub fn rx_repeat_repeat() -> Text {
    Text::lit("a repetition of a repetition: write (?:a*)* to say it")
}

/// ```prism
/// let rxRepeatAssertion
/// ```
pub fn rx_repeat_assertion() -> Text {
    Text::lit("a repetition of an assertion")
}

/// ```prism
/// let rxProduct
/// ```
pub fn rx_product() -> Text {
    Text::lit("nested counts multiplying past 1000")
}

/// ```prism
/// let rxNesting
/// ```
pub fn rx_nesting() -> Text {
    Text::lit("groups and repetitions nested more than 100 deep")
}

/// ```prism
/// let rxSize
/// ```
pub fn rx_size() -> Text {
    Text::lit("the pattern expands past 10,000 atoms")
}

/// ```prism
/// let rxRZero
/// ```
pub fn rx_rzero() -> Text {
    Text::lit("a group number with a leading zero")
}

/// ```prism
/// let rxRBraces
/// ```
pub fn rx_rbraces() -> Text {
    Text::lit("a ${...} that is neither a group number nor a group name")
}

/// ```prism
/// let rxRDollar
/// ```
pub fn rx_rdollar() -> Text {
    Text::lit("a $ that is not $n, ${n}, ${name} or $$")
}

/// ```prism
/// let rxRNoNumber
/// ```
pub fn rx_rno_number() -> Text {
    Text::lit("the pattern has no group of that number")
}

/// ```prism
/// let rxRNoName
/// ```
pub fn rx_rno_name() -> Text {
    Text::lit("the pattern has no group of that name")
}

/// ```prism
/// let rxRUnicode
/// ```
pub fn rx_runicode() -> Text {
    Text::lit("a \\u{...} escape needs one to six hex digits naming a character")
}

/// ```prism
/// let rxREscape
/// ```
pub fn rx_rescape() -> Text {
    Text::lit("an unknown escape in a replacement: the escapes are \\\\, \\n, \\t, \\u{hex} and \\/")
}

/// ```prism
/// let rxCategories
/// ```
pub fn rx_categories() -> Array<Text> {
    Array::from(vec![Text::lit("Cc"), Text::lit("Cf"), Text::lit("Co"), Text::lit("L"), Text::lit("Ll"), Text::lit("Lm"), Text::lit("Lo"), Text::lit("Lt"), Text::lit("Lu"), Text::lit("M"), Text::lit("Mc"), Text::lit("Me"), Text::lit("Mn"), Text::lit("N"), Text::lit("Nd"), Text::lit("Nl"), Text::lit("No"), Text::lit("P"), Text::lit("Pc"), Text::lit("Pd"), Text::lit("Pe"), Text::lit("Pf"), Text::lit("Pi"), Text::lit("Po"), Text::lit("Ps"), Text::lit("S"), Text::lit("Sc"), Text::lit("Sk"), Text::lit("Sm"), Text::lit("So"), Text::lit("Z"), Text::lit("Zl"), Text::lit("Zp"), Text::lit("Zs")])
}

/// ```prism
/// let rxScripts
/// ```
pub fn rx_scripts() -> Array<Text> {
    Array::from(vec![Text::lit("Adlam"), Text::lit("Ahom"), Text::lit("Anatolian_Hieroglyphs"), Text::lit("Arabic"), Text::lit("Armenian"), Text::lit("Avestan"), Text::lit("Balinese"), Text::lit("Bamum"), Text::lit("Bassa_Vah"), Text::lit("Batak"), Text::lit("Bengali"), Text::lit("Bhaiksuki"), Text::lit("Bopomofo"), Text::lit("Brahmi"), Text::lit("Braille"), Text::lit("Buginese"), Text::lit("Buhid"), Text::lit("Canadian_Aboriginal"), Text::lit("Carian"), Text::lit("Caucasian_Albanian"), Text::lit("Chakma"), Text::lit("Cham"), Text::lit("Cherokee"), Text::lit("Chorasmian"), Text::lit("Common"), Text::lit("Coptic"), Text::lit("Cuneiform"), Text::lit("Cypriot"), Text::lit("Cypro_Minoan"), Text::lit("Cyrillic"), Text::lit("Deseret"), Text::lit("Devanagari"), Text::lit("Dives_Akuru"), Text::lit("Dogra"), Text::lit("Duployan"), Text::lit("Egyptian_Hieroglyphs"), Text::lit("Elbasan"), Text::lit("Elymaic"), Text::lit("Ethiopic"), Text::lit("Georgian"), Text::lit("Glagolitic"), Text::lit("Gothic"), Text::lit("Grantha"), Text::lit("Greek"), Text::lit("Gujarati"), Text::lit("Gunjala_Gondi"), Text::lit("Gurmukhi"), Text::lit("Han"), Text::lit("Hangul"), Text::lit("Hanifi_Rohingya"), Text::lit("Hanunoo"), Text::lit("Hatran"), Text::lit("Hebrew"), Text::lit("Hiragana"), Text::lit("Imperial_Aramaic"), Text::lit("Inherited"), Text::lit("Inscriptional_Pahlavi"), Text::lit("Inscriptional_Parthian"), Text::lit("Javanese"), Text::lit("Kaithi"), Text::lit("Kannada"), Text::lit("Katakana"), Text::lit("Kawi"), Text::lit("Kayah_Li"), Text::lit("Kharoshthi"), Text::lit("Khitan_Small_Script"), Text::lit("Khmer"), Text::lit("Khojki"), Text::lit("Khudawadi"), Text::lit("Lao"), Text::lit("Latin"), Text::lit("Lepcha"), Text::lit("Limbu"), Text::lit("Linear_A"), Text::lit("Linear_B"), Text::lit("Lisu"), Text::lit("Lycian"), Text::lit("Lydian"), Text::lit("Mahajani"), Text::lit("Makasar"), Text::lit("Malayalam"), Text::lit("Mandaic"), Text::lit("Manichaean"), Text::lit("Marchen"), Text::lit("Masaram_Gondi"), Text::lit("Medefaidrin"), Text::lit("Meetei_Mayek"), Text::lit("Mende_Kikakui"), Text::lit("Meroitic_Cursive"), Text::lit("Meroitic_Hieroglyphs"), Text::lit("Miao"), Text::lit("Modi"), Text::lit("Mongolian"), Text::lit("Mro"), Text::lit("Multani"), Text::lit("Myanmar"), Text::lit("Nabataean"), Text::lit("Nag_Mundari"), Text::lit("Nandinagari"), Text::lit("New_Tai_Lue"), Text::lit("Newa"), Text::lit("Nko"), Text::lit("Nushu"), Text::lit("Nyiakeng_Puachue_Hmong"), Text::lit("Ogham"), Text::lit("Ol_Chiki"), Text::lit("Old_Hungarian"), Text::lit("Old_Italic"), Text::lit("Old_North_Arabian"), Text::lit("Old_Permic"), Text::lit("Old_Persian"), Text::lit("Old_Sogdian"), Text::lit("Old_South_Arabian"), Text::lit("Old_Turkic"), Text::lit("Old_Uyghur"), Text::lit("Oriya"), Text::lit("Osage"), Text::lit("Osmanya"), Text::lit("Pahawh_Hmong"), Text::lit("Palmyrene"), Text::lit("Pau_Cin_Hau"), Text::lit("Phags_Pa"), Text::lit("Phoenician"), Text::lit("Psalter_Pahlavi"), Text::lit("Rejang"), Text::lit("Runic"), Text::lit("Samaritan"), Text::lit("Saurashtra"), Text::lit("Sharada"), Text::lit("Shavian"), Text::lit("Siddham"), Text::lit("SignWriting"), Text::lit("Sinhala"), Text::lit("Sogdian"), Text::lit("Sora_Sompeng"), Text::lit("Soyombo"), Text::lit("Sundanese"), Text::lit("Syloti_Nagri"), Text::lit("Syriac"), Text::lit("Tagalog"), Text::lit("Tagbanwa"), Text::lit("Tai_Le"), Text::lit("Tai_Tham"), Text::lit("Tai_Viet"), Text::lit("Takri"), Text::lit("Tamil"), Text::lit("Tangsa"), Text::lit("Tangut"), Text::lit("Telugu"), Text::lit("Thaana"), Text::lit("Thai"), Text::lit("Tibetan"), Text::lit("Tifinagh"), Text::lit("Tirhuta"), Text::lit("Toto"), Text::lit("Ugaritic"), Text::lit("Vai"), Text::lit("Vithkuqi"), Text::lit("Wancho"), Text::lit("Warang_Citi"), Text::lit("Yezidi"), Text::lit("Yi"), Text::lit("Zanabazar_Square")])
}

/// ```prism
/// let rxProperties
/// ```
pub fn rx_properties() -> Map<Text, bool> {
    map(&each(&push(&append(&rx_categories(), &rx_scripts()), &Text::lit("Any")), &(|n_p0: &Text| (n_p0.clone(), true))))
}

/// ```prism
/// let rxAsciiClasses
/// ```
pub fn rx_ascii_classes() -> Map<Text, bool> {
    map(&each(&Array::from(vec![Text::lit("alnum"), Text::lit("alpha"), Text::lit("ascii"), Text::lit("blank"), Text::lit("cntrl"), Text::lit("digit"), Text::lit("graph"), Text::lit("lower"), Text::lit("print"), Text::lit("punct"), Text::lit("space"), Text::lit("upper"), Text::lit("word"), Text::lit("xdigit")]), &(|n_p0: &Text| (n_p0.clone(), true))))
}

/// ```prism
/// let rxAscii
/// ```
pub fn rx_ascii() -> Text {
    Text::lit("\0\t\n\r !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")
}

/// ```prism
/// let rxPunctuation
/// ```
pub fn rx_punctuation() -> Text {
    Text::lit("!\"#$%&\'()*+,-./:;=?@[\\]^_`{|}~")
}

/// ```prism
/// let rxNone
/// ```
pub fn rx_none() -> RxMeasure {
    RxMeasure { depth: Nat::from(0u32), size: Nat::from(0u32), product: Nat::from(0u32) }
}

/// ```prism
/// let rxAtom
/// ```
pub fn rx_atom() -> RxMeasure {
    RxMeasure { depth: Nat::from(0u32), size: Nat::from(1u32), product: Nat::from(1u32) }
}

/// ```prism
/// RxThen: fn RxMeasure, RxMeasure -> RxMeasure
/// ```
pub fn rx_then(a_p0: &RxMeasure, b_p1: &RxMeasure) -> RxMeasure {
    RxMeasure { depth: max(&a_p0.depth, &b_p1.depth), size: &a_p0.size + &b_p1.size, product: max(&a_p0.product, &b_p1.product) }
}

/// ```prism
/// RxBad: fn RxState -> Bool
/// ```
pub fn rx_bad(st_p0: &RxState) -> bool {
    &st_p0.err != &None
}

/// ```prism
/// RxFail: fn RxState, Nat, Text -> RxState
/// ```
pub fn rx_fail(st_p0: &RxState, at_p1: &Nat, message_p2: &Text) -> RxState {
    if rx_bad(st_p0) {
        st_p0.clone()
    } else {
        RxState { s: st_p0.s.clone(), i: st_p0.i.clone(), open: st_p0.open.clone(), groups: st_p0.groups.clone(), names: st_p0.names.clone(), err: Some(RxDiag { part: Text::lit("pattern"), at: at_p1.clone(), message: message_p2.clone() }) }
    }
}

/// ```prism
/// RxGo: fn RxState, Nat -> RxState
/// ```
pub fn rx_go(st_p0: &RxState, n_p1: &Nat) -> RxState {
    let mut this: RxState = st_p0.clone();
    this.i = n_p1.clone();
    this
}

/// ```prism
/// RxPeek: fn RxState -> Text
/// ```
pub fn rx_peek(st_p0: &RxState) -> Text {
    rx_char_at(&st_p0.s, &st_p0.i)
}

/// ```prism
/// RxCharAt: fn Text, Nat -> Text
/// ```
pub fn rx_char_at(t_p0: &Text, n_p1: &Nat) -> Text {
    match cursor_at(t_p0, n_p1) {
        Some(c_p2) => match step(&front(&after(&c_p2))) {
            Some((_, one_p3)) => before(&one_p3),
            None => Text::lit(""),
        },
        None => Text::lit(""),
    }
}

/// ```prism
/// RxSlice: fn Text, Nat, Nat -> Text
/// ```
pub fn rx_slice(t_p0: &Text, a_p1: &Nat, b_p2: &Nat) -> Text {
    match cursor_at(t_p0, b_p2) {
        Some(cb_p3) => match cursor_at(&before(&cb_p3), a_p1) {
            Some(ca_p4) => after(&ca_p4),
            None => Text::lit(""),
        },
        None => Text::lit(""),
    }
}

/// ```prism
/// ?RxFind: fn Text, Nat, Text -> ?Nat
/// ```
pub fn rx_find(t_p0: &Text, from_p1: &Nat, x_p2: &Text) -> Option<Nat> {
    match cursor_at(t_p0, from_p1) {
        None => None,
        Some(c0_p3) => {
            let (found_o7, _) = {
                let mut this: (Option<Nat>, Cursor) = (None, c0_p3.clone());
                let mut c_p4: Cursor = c0_p3.clone();
                let mut found_o5: Option<Nat> = None;
                while let Some((_, next_p6)) = step(&c_p4) {
                    if !(&found_o5 == &None) {
                        break;
                    }
                    if &rx_slice(t_p0, &at(&c_p4), &at(&next_p6)) == x_p2 {
                        found_o5 = Some(at(&c_p4));
                    }
                    c_p4 = next_p6.clone();
                }
                this = (found_o5.clone(), c_p4.clone());
                this
            };
            found_o7.clone()
        },
    }
}

/// ```prism
/// RxIn: fn Text, Text -> Bool
/// ```
pub fn rx_in(set_p0: &Text, c_p1: &Text) -> bool {
    (c_p1 != &Text::lit("")) && (&rx_find(set_p0, &Nat::from(0u32), c_p1) != &None)
}

/// ```prism
/// RxIsDigit: fn Text -> Bool
/// ```
pub fn rx_is_digit(c_p0: &Text) -> bool {
    ((&Text::lit("0") <= c_p0) && (c_p0 <= &Text::lit("9"))) && (&len_text(c_p0) == &Nat::from(1u32))
}

/// ```prism
/// RxIsLetter: fn Text -> Bool
/// ```
pub fn rx_is_letter(c_p0: &Text) -> bool {
    ((&Text::lit("a") <= c_p0) && (c_p0 <= &Text::lit("z"))) || ((&Text::lit("A") <= c_p0) && (c_p0 <= &Text::lit("Z")))
}

/// ```prism
/// RxIsHex: fn Text -> Bool
/// ```
pub fn rx_is_hex(c_p0: &Text) -> bool {
    (rx_is_digit(c_p0) || ((&Text::lit("a") <= c_p0) && (c_p0 <= &Text::lit("f")))) || ((&Text::lit("A") <= c_p0) && (c_p0 <= &Text::lit("F")))
}

/// ```prism
/// RxIsName: fn Text -> Bool
/// ```
pub fn rx_is_name(t_p0: &Text) -> bool {
    let first_p1 = rx_char_at(t_p0, &Nat::from(0u32));
    ((t_p0 != &Text::lit("")) && (((&Text::lit("a") <= &first_p1) && (&first_p1 <= &Text::lit("z"))) || (&first_p1 == &Text::lit("_")))) && rx_all(t_p0, &(Rc::new(move |p0: Text| once_job(move || {
        let c_p2 = p0;
        prism_rtl::Turn::Finished((((&Text::lit("a") <= &c_p2) && (&c_p2 <= &Text::lit("z"))) || rx_is_digit(&c_p2)) || (&c_p2 == &Text::lit("_")))
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// ```prism
/// RxAll: fn Text, (fn Text -> Bool) -> Bool
/// ```
pub fn rx_all(t_p0: &Text, p_f1: &Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> bool {
    let mut this: bool = true;
    let mut c_p2: Cursor = front(t_p0);
    while let Some((_, next_p3)) = step(&c_p2) {
        if !run_to_end(p_f1(rx_slice(t_p0, &at(&c_p2), &at(&next_p3)))) {
            this = false;
        }
        c_p2 = next_p3.clone();
    }
    this
}

/// The step machine of `RxAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxAll: fn Text, (fn Text -> Bool) -> Bool
/// ```
pub struct RxAll {
    pub t_p0: Text,
    pub p_f1: Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>,
}

impl prism_rtl::Job<bool> for RxAll {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        let p_f1 = &self.p_f1;
        prism_rtl::Turn::Finished({
            let mut this: bool = true;
            let mut c_p2: Cursor = front(t_p0);
            while let Some((_, next_p3)) = step(&c_p2) {
                if !run_to_end(p_f1(rx_slice(t_p0, &at(&c_p2), &at(&next_p3)))) {
                    this = false;
                }
                c_p2 = next_p3.clone();
            }
            this
        })
    }
}

/// `Start RxAll, x`: what the function value is when passed to `@Run`.
pub fn start_rx_all(t_p0: Text, p_f1: Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(RxAll { t_p0, p_f1 })
}

/// ```prism
/// RxSpanEnd: unbounded fn Text, Nat, (fn Text -> Bool) -> Nat
/// ```
pub fn rx_span_end(t_p0: &Text, at_p1: &Nat, p_f2: &Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> Nat {
    let mut this: Nat = at_p1.clone();
    while run_to_end(p_f2(rx_char_at(t_p0, &this))) {
        this = &this + &Nat::from(1u32);
    }
    this
}

/// The step machine of `RxSpanEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxSpanEnd: unbounded fn Text, Nat, (fn Text -> Bool) -> Nat
/// ```
pub struct RxSpanEnd {
    pub t_p0: Text,
    pub at_p1: Nat,
    pub p_f2: Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>,
}

impl prism_rtl::Job<Nat> for RxSpanEnd {
    fn cycle(&self) -> prism_rtl::Turn<Nat> {
        let t_p0 = &self.t_p0;
        let at_p1 = &self.at_p1;
        let p_f2 = &self.p_f2;
        let mut this: Nat = at_p1.clone();
        call_then(loop_job((this,), {
            let p_f2 = p_f2.clone();
            let t_p0 = t_p0.clone();
            move |(mut this,): (Nat,)| if run_to_end((&p_f2)(rx_char_at(&t_p0, &this))) {
                {
                    this = &this + &Nat::from(1u32);
                    Ok((this,))
                }
            } else {
                Err((this,))
            }
        }), move |(mut this,): (Nat,)| prism_rtl::Turn::Finished(this))
    }
}

/// `Start RxSpanEnd, x`: what the function value is when passed to `@Run`.
pub fn start_rx_span_end(t_p0: Text, at_p1: Nat, p_f2: Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> Rc<dyn prism_rtl::Job<Nat>> {
    Rc::new(RxSpanEnd { t_p0, at_p1, p_f2 })
}

/// ```prism
/// RxHexValue: fn Text -> Nat
/// ```
pub fn rx_hex_value(t_p0: &Text) -> Nat {
    let mut this: Nat = Nat::from(0u32);
    let mut c_p1: Cursor = front(t_p0);
    while let Some((_, next_p2)) = step(&c_p1) {
        let d_p3 = rx_slice(t_p0, &at(&c_p1), &at(&next_p2));
        this = &(&this * &Nat::from(16u32)) + &or(&rx_find(&Text::lit("0123456789abcdef"), &Nat::from(0u32), &crate::prelude::lower(&d_p3)), &Nat::from(0u32));
        c_p1 = next_p2.clone();
    }
    this
}

/// ```prism
/// RxCpOf: fn Nat -> RxCp
/// ```
pub fn rx_cp_of(v_p0: &Nat) -> RxCp {
    if v_p0 < &Nat::from(128u32) {
        RxCp::RxLit(rx_char_at(&rx_ascii(), v_p0))
    } else {
        RxCp::RxNum(v_p0.clone())
    }
}

/// ```prism
/// RxWidth: fn Nat -> Nat
/// ```
pub fn rx_width(v_p0: &Nat) -> Nat {
    if v_p0 < &Nat::from(128u32) {
        Nat::from(1u32)
    } else {
        if v_p0 < &Nat::from(2048u32) {
            Nat::from(2u32)
        } else {
            if v_p0 < &Nat::from(65536u32) { Nat::from(3u32) } else { Nat::from(4u32) }
        }
    }
}

/// ```prism
/// RxPast: fn RxCp, RxCp -> Bool
/// ```
pub fn rx_past(rx_cp0: &RxCp, rx_cp1: &RxCp) -> bool {
    match (rx_cp0, rx_cp1) {
        (RxCp::RxLit(a_p0), RxCp::RxLit(b_p1)) => a_p0 > b_p1,
        (RxCp::RxNum(a_p2), RxCp::RxNum(b_p3)) => a_p2 > b_p3,
        (RxCp::RxLit(a_p4), RxCp::RxNum(b_p5)) => if &len_text(a_p4) != &rx_width(b_p5) {
            &len_text(a_p4) > &rx_width(b_p5)
        } else {
            !rx_in_range(a_p4, &Nat::from(0u32), b_p5)
        },
        (RxCp::RxNum(a_p6), RxCp::RxLit(b_p7)) => if &rx_width(a_p6) != &len_text(b_p7) {
            &rx_width(a_p6) > &len_text(b_p7)
        } else {
            !rx_in_range(b_p7, a_p6, &Nat::from(1114111u32))
        },
    }
}

/// ```prism
/// RxInRange: fn Text, Nat, Nat -> Bool
/// ```
pub fn rx_in_range(c_p0: &Text, lo_p1: &Nat, hi_p2: &Nat) -> bool {
    match crate::prelude::regex(&Text::from(format!("[\\x{{{}}}-\\x{{{}}}]", &rx_hex_text(lo_p1), &rx_hex_text(hi_p2)))) {
        Some(r_p3) => &find(&r_p3, c_p0) != &None,
        None => false,
    }
}

/// ```prism
/// RxHexText: fn Nat -> Text
/// ```
pub fn rx_hex_text(n_p0: &Nat) -> Text {
    let mut this: Text = Text::lit("");
    let mut k_p1: Nat = n_p0.clone();
    let mut fuel_p2: Nat = Nat::from(6u32);
    while let Some(left_p3) = (&fuel_p2).checked_sub(&Nat::from(1u32)) {
        fuel_p2 = left_p3.clone();
        this = Text::from(format!("{}{}", &rx_char_at(&Text::lit("0123456789abcdef"), &or(&mod_(&k_p1, &Nat::from(16u32)), &Nat::from(0u32))), &this));
        k_p1 = or(&div(&k_p1, &Nat::from(16u32)), &Nat::from(0u32));
    }
    this
}

/// ```prism
/// ?RegexRefusal: unbounded fn Text, Text, ?Text -> ?RxDiag
/// ```
pub fn regex_refusal(pattern_p0: &Text, flags_p1: &Text, replacement_o2: &Option<Text>) -> Option<RxDiag> {
    match rx_flags_refusal(flags_p1) {
        Some(d_p3) => Some(d_p3),
        None => {
            let st0_p4 = RxState { s: pattern_p0.clone(), i: Nat::from(0u32), open: Nat::from(0u32), groups: Nat::from(0u32), names: Map::new(), err: None };
            let (m_p5, st_p6) = rx_alternation(&st0_p4, &(&rx_find(flags_p1, &Nat::from(0u32), &Text::lit("i")) != &None));
            match &st_p6.err {
                Some(d_p7) => Some(d_p7.clone()),
                None => if &st_p6.i < &len_text(pattern_p0) {
                    Some(RxDiag { part: Text::lit("pattern"), at: st_p6.i.clone(), message: rx_group_close() })
                } else {
                    if &m_p5.depth > &Nat::from(100u32) {
                        Some(RxDiag { part: Text::lit("pattern"), at: Nat::from(0u32), message: rx_nesting() })
                    } else {
                        if &m_p5.size > &Nat::from(10000u32) {
                            Some(RxDiag { part: Text::lit("pattern"), at: Nat::from(0u32), message: rx_size() })
                        } else {
                            match replacement_o2 {
                                None => None,
                                Some(r_p8) => rx_replacement_refusal(r_p8, &st_p6.groups, &st_p6.names),
                            }
                        }
                    }
                },
            }
        },
    }
}

/// The step machine of `RegexRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RegexRefusal: unbounded fn Text, Text, ?Text -> ?RxDiag
/// ```
pub struct RegexRefusal {
    pub pattern_p0: Text,
    pub flags_p1: Text,
    pub replacement_o2: Option<Text>,
}

impl prism_rtl::Job<Option<RxDiag>> for RegexRefusal {
    fn cycle(&self) -> prism_rtl::Turn<Option<RxDiag>> {
        let pattern_p0 = &self.pattern_p0;
        let flags_p1 = &self.flags_p1;
        let replacement_o2 = &self.replacement_o2;
        match rx_flags_refusal(flags_p1) {
            Some(d_p3) => prism_rtl::Turn::Finished(Some(d_p3.clone())),
            None => {
                let st0_p4 = RxState { s: pattern_p0.clone(), i: Nat::from(0u32), open: Nat::from(0u32), groups: Nat::from(0u32), names: Map::new(), err: None };
                let replacement_o2 = replacement_o2.clone();
                let flags_p1 = flags_p1.clone();
                let pattern_p0 = pattern_p0.clone();
                call_then(start_rx_alternation(st0_p4.clone(), &rx_find(&flags_p1, &Nat::from(0u32), &Text::lit("i")) != &None), move |rx_alternation_15542: (RxMeasure, RxState)| {
                    let (m_p5, st_p6) = rx_alternation_15542;
                    match &st_p6.err {
                        Some(d_p7) => prism_rtl::Turn::Finished(Some(d_p7.clone())),
                        None => if &st_p6.i < &len_text(&pattern_p0) {
                            prism_rtl::Turn::Finished(Some(RxDiag { part: Text::lit("pattern"), at: st_p6.i.clone(), message: rx_group_close() }))
                        } else {
                            if &m_p5.depth > &Nat::from(100u32) {
                                prism_rtl::Turn::Finished(Some(RxDiag { part: Text::lit("pattern"), at: Nat::from(0u32), message: rx_nesting() }))
                            } else {
                                if &m_p5.size > &Nat::from(10000u32) {
                                    prism_rtl::Turn::Finished(Some(RxDiag { part: Text::lit("pattern"), at: Nat::from(0u32), message: rx_size() }))
                                } else {
                                    match &replacement_o2 {
                                        None => prism_rtl::Turn::Finished(None),
                                        Some(r_p8) => prism_rtl::Turn::More(Rc::new(RxReplacementRefusal { r_p0: r_p8.clone(), groups_p1: st_p6.groups.clone(), names_p2: st_p6.names.clone() })),
                                    }
                                }
                            }
                        },
                    }
                })
            },
        }
    }
}

/// `Start RegexRefusal, x`: what the function value is when passed to `@Run`.
pub fn start_regex_refusal(pattern_p0: Text, flags_p1: Text, replacement_o2: Option<Text>) -> Rc<dyn prism_rtl::Job<Option<RxDiag>>> {
    Rc::new(RegexRefusal { pattern_p0, flags_p1, replacement_o2 })
}

/// ```prism
/// ?RxFlagsRefusal: fn Text -> ?RxDiag
/// ```
pub fn rx_flags_refusal(flags_p0: &Text) -> Option<RxDiag> {
    let (d_o6, _) = {
        let mut this: (Option<RxDiag>, Text) = (None, Text::lit(""));
        let mut c_p1: Cursor = front(flags_p0);
        let mut d_o2: Option<RxDiag> = None;
        let mut seen_p3: Text = Text::lit("");
        while let Some((_, next_p4)) = step(&c_p1) {
            if !(&d_o2 == &None) {
                break;
            }
            let ch_p5 = rx_slice(flags_p0, &at(&c_p1), &at(&next_p4));
            if !(((&ch_p5 == &Text::lit("i")) || (&ch_p5 == &Text::lit("m"))) || (&ch_p5 == &Text::lit("s"))) {
                d_o2 = Some(RxDiag { part: Text::lit("flags"), at: at(&c_p1), message: rx_unknown_flag() });
            } else if rx_in(&seen_p3, &ch_p5) {
                d_o2 = Some(RxDiag { part: Text::lit("flags"), at: at(&c_p1), message: rx_flag_twice() });
            } else {
                seen_p3 = Text::from(format!("{}{}", &seen_p3, &ch_p5));
            }
            c_p1 = next_p4.clone();
        }
        this = (d_o2.clone(), seen_p3.clone());
        this
    };
    d_o6.clone()
}

/// ```prism
/// RxAlternation: unbounded fn RxState, Bool -> ((RxMeasure, RxState))
/// ```
pub fn rx_alternation(st0_p0: &RxState, fi0_p1: &bool) -> (RxMeasure, RxState) {
    let (m0_p2, fi1_p3, st1_p4) = rx_sequence(st0_p0, fi0_p1);
    let mut this: (RxMeasure, RxState) = (m0_p2.clone(), st1_p4.clone());
    let mut m_p5: RxMeasure = m0_p2.clone();
    let mut fi_p6: bool = fi1_p3;
    let mut st_p7: RxState = st1_p4.clone();
    while !rx_bad(&st_p7) && (&rx_peek(&st_p7) == &Text::lit("|")) {
        let (m2_p8, fi2_p9, st2_pa) = rx_sequence(&rx_go(&st_p7, &(&st_p7.i + &Nat::from(1u32))), &fi_p6);
        m_p5 = rx_then(&m_p5, &m2_p8);
        fi_p6 = fi2_p9;
        st_p7 = st2_pa.clone();
    }
    this = (m_p5.clone(), st_p7.clone());
    this
}

/// The step machine of `RxAlternation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxAlternation: unbounded fn RxState, Bool -> ((RxMeasure, RxState))
/// ```
pub struct RxAlternation {
    pub st0_p0: RxState,
    pub fi0_p1: bool,
}

impl prism_rtl::Job<(RxMeasure, RxState)> for RxAlternation {
    fn cycle(&self) -> prism_rtl::Turn<(RxMeasure, RxState)> {
        let st0_p0 = &self.st0_p0;
        let fi0_p1 = &self.fi0_p1;
        let fi0_p1 = *fi0_p1;
        let st0_p0 = st0_p0.clone();
        call_then(start_rx_sequence(st0_p0.clone(), fi0_p1), move |rx_sequence_17135: (RxMeasure, bool, RxState)| {
            let (m0_p2, fi1_p3, st1_p4) = rx_sequence_17135;
            let mut this: (RxMeasure, RxState) = (m0_p2.clone(), st1_p4.clone());
            let mut m_p5: RxMeasure = m0_p2.clone();
            let mut fi_p6: bool = fi1_p3;
            let mut st_p7: RxState = st1_p4.clone();
            call_then(loop_job((this, fi_p6, m_p5, st_p7), move |(mut this, mut fi_p6, mut m_p5, mut st_p7): ((RxMeasure, RxState), bool, RxMeasure, RxState)| if !rx_bad(&st_p7) && (&rx_peek(&st_p7) == &Text::lit("|")) {
                {
                    let (m2_p8, fi2_p9, st2_pa) = rx_sequence(&rx_go(&st_p7, &(&st_p7.i + &Nat::from(1u32))), &fi_p6);
                    m_p5 = rx_then(&m_p5, &m2_p8);
                    fi_p6 = fi2_p9;
                    st_p7 = st2_pa.clone();
                    Ok((this, fi_p6, m_p5, st_p7))
                }
            } else {
                Err((this, fi_p6, m_p5, st_p7))
            }), move |(mut this, mut fi_p6, mut m_p5, mut st_p7): ((RxMeasure, RxState), bool, RxMeasure, RxState)| {
                this = (m_p5.clone(), st_p7.clone());
                prism_rtl::Turn::Finished(this)
            })
        })
    }
}

/// `Start RxAlternation, x`: what the function value is when passed to `@Run`.
pub fn start_rx_alternation(st0_p0: RxState, fi0_p1: bool) -> Rc<dyn prism_rtl::Job<(RxMeasure, RxState)>> {
    Rc::new(RxAlternation { st0_p0, fi0_p1 })
}

/// ```prism
/// RxSequence: unbounded fn RxState, Bool -> ((RxMeasure, Bool, RxState))
/// ```
pub fn rx_sequence(st0_p0: &RxState, fi0_p1: &bool) -> (RxMeasure, bool, RxState) {
    let mut this: (RxMeasure, bool, RxState) = (rx_none(), *fi0_p1, st0_p0.clone());
    let mut total_p2: RxMeasure = rx_none();
    let mut fi_p3: bool = *fi0_p1;
    let mut st_p4: RxState = st0_p0.clone();
    let mut last_p5: RxLast = RxLast::RxLastNothing;
    let mut last_m_p6: RxMeasure = rx_none();
    let mut going_p7: bool = true;
    while going_p7 && !rx_bad(&st_p4) {
        let c_p8 = rx_peek(&st_p4);
        let at_p9 = st_p4.i.clone();
        if ((&c_p8 == &Text::lit("")) || (&c_p8 == &Text::lit("|"))) || (&c_p8 == &Text::lit(")")) {
            going_p7 = false;
        } else if (((&c_p8 == &Text::lit("*")) || (&c_p8 == &Text::lit("+"))) || (&c_p8 == &Text::lit("?"))) || (&c_p8 == &Text::lit("{")) {
            let (lo_pa, hi_ob, st2_pc) = if &c_p8 == &Text::lit("{") {
                rx_count(&st_p4)
            } else {
                rx_simple_repetition(&st_p4, &c_p8)
            };
            st_p4 = st2_pc.clone();
            if !rx_bad(&st_p4) {
                st_p4 = match &last_p5 {
                    RxLast::RxLastNothing => rx_fail(&st_p4, &at_p9, &rx_nothing_to_repeat()),
                    RxLast::RxLastFlagGroup => rx_fail(&st_p4, &at_p9, &rx_nothing_to_repeat()),
                    RxLast::RxLastRepetition => rx_fail(&st_p4, &at_p9, &rx_repeat_repeat()),
                    RxLast::RxLastAssertion => rx_fail(&st_p4, &at_p9, &rx_repeat_assertion()),
                    RxLast::RxLastAtom => st_p4.clone(),
                };
            }
            if !rx_bad(&st_p4) {
                let counted_pd = &c_p8 == &Text::lit("{");
                let factor_pe = if counted_pd { max(&or(&hi_ob, &lo_pa), &Nat::from(1u32)) } else { Nat::from(1u32) };
                let product_pf = &factor_pe * &max(&last_m_p6.product, &Nat::from(1u32));
                if counted_pd && (&product_pf > &Nat::from(1000u32)) {
                    st_p4 = rx_fail(&st_p4, &at_p9, &rx_product());
                } else {
                    if &rx_peek(&st_p4) == &Text::lit("?") {
                        st_p4 = rx_go(&st_p4, &(&st_p4.i + &Nat::from(1u32)));
                    }
                    let m_pg = RxMeasure { depth: &last_m_p6.depth + &Nat::from(1u32), size: &last_m_p6.size * &factor_pe, product: product_pf.clone() };
                    total_p2 = RxMeasure { depth: max(&total_p2.depth, &m_pg.depth), size: &or(&(&total_p2.size).checked_sub(&last_m_p6.size), &Nat::from(0u32)) + &m_pg.size, product: max(&total_p2.product, &m_pg.product) };
                    last_p5 = RxLast::RxLastRepetition;
                    last_m_p6 = m_pg.clone();
                }
            }
        } else {
            let (kind_ph, m_pi, fi2_pj, st2_pk) = rx_piece(&st_p4, &fi_p3);
            st_p4 = st2_pk.clone();
            fi_p3 = fi2_pj;
            if &kind_ph != &RxLast::RxLastFlagGroup {
                total_p2 = rx_then(&total_p2, &m_pi);
            }
            last_p5 = kind_ph.clone();
            last_m_p6 = m_pi.clone();
        }
    }
    this = (total_p2.clone(), fi_p3, st_p4.clone());
    this
}

/// The step machine of `RxSequence`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxSequence: unbounded fn RxState, Bool -> ((RxMeasure, Bool, RxState))
/// ```
pub struct RxSequence {
    pub st0_p0: RxState,
    pub fi0_p1: bool,
}

impl prism_rtl::Job<(RxMeasure, bool, RxState)> for RxSequence {
    fn cycle(&self) -> prism_rtl::Turn<(RxMeasure, bool, RxState)> {
        let st0_p0 = &self.st0_p0;
        let fi0_p1 = &self.fi0_p1;
        let mut this: (RxMeasure, bool, RxState) = (rx_none(), *fi0_p1, st0_p0.clone());
        let mut total_p2: RxMeasure = rx_none();
        let mut fi_p3: bool = *fi0_p1;
        let mut st_p4: RxState = st0_p0.clone();
        let mut last_p5: RxLast = RxLast::RxLastNothing;
        let mut last_m_p6: RxMeasure = rx_none();
        let mut going_p7: bool = true;
        call_then(loop_job((this, fi_p3, going_p7, last_p5, last_m_p6, st_p4, total_p2), move |(mut this, mut fi_p3, mut going_p7, mut last_p5, mut last_m_p6, mut st_p4, mut total_p2): ((RxMeasure, bool, RxState), bool, bool, RxLast, RxMeasure, RxState, RxMeasure)| if going_p7 && !rx_bad(&st_p4) {
            {
                let c_p8 = rx_peek(&st_p4);
                let at_p9 = st_p4.i.clone();
                if ((&c_p8 == &Text::lit("")) || (&c_p8 == &Text::lit("|"))) || (&c_p8 == &Text::lit(")")) {
                    going_p7 = false;
                } else if (((&c_p8 == &Text::lit("*")) || (&c_p8 == &Text::lit("+"))) || (&c_p8 == &Text::lit("?"))) || (&c_p8 == &Text::lit("{")) {
                    let (lo_pa, hi_ob, st2_pc) = if &c_p8 == &Text::lit("{") {
                        rx_count(&st_p4)
                    } else {
                        rx_simple_repetition(&st_p4, &c_p8)
                    };
                    st_p4 = st2_pc.clone();
                    if !rx_bad(&st_p4) {
                        st_p4 = match &last_p5 {
                            RxLast::RxLastNothing => rx_fail(&st_p4, &at_p9, &rx_nothing_to_repeat()),
                            RxLast::RxLastFlagGroup => rx_fail(&st_p4, &at_p9, &rx_nothing_to_repeat()),
                            RxLast::RxLastRepetition => rx_fail(&st_p4, &at_p9, &rx_repeat_repeat()),
                            RxLast::RxLastAssertion => rx_fail(&st_p4, &at_p9, &rx_repeat_assertion()),
                            RxLast::RxLastAtom => st_p4.clone(),
                        };
                    }
                    if !rx_bad(&st_p4) {
                        let counted_pd = &c_p8 == &Text::lit("{");
                        let factor_pe = if counted_pd { max(&or(&hi_ob, &lo_pa), &Nat::from(1u32)) } else { Nat::from(1u32) };
                        let product_pf = &factor_pe * &max(&last_m_p6.product, &Nat::from(1u32));
                        if counted_pd && (&product_pf > &Nat::from(1000u32)) {
                            st_p4 = rx_fail(&st_p4, &at_p9, &rx_product());
                        } else {
                            if &rx_peek(&st_p4) == &Text::lit("?") {
                                st_p4 = rx_go(&st_p4, &(&st_p4.i + &Nat::from(1u32)));
                            }
                            let m_pg = RxMeasure { depth: &last_m_p6.depth + &Nat::from(1u32), size: &last_m_p6.size * &factor_pe, product: product_pf.clone() };
                            total_p2 = RxMeasure { depth: max(&total_p2.depth, &m_pg.depth), size: &or(&(&total_p2.size).checked_sub(&last_m_p6.size), &Nat::from(0u32)) + &m_pg.size, product: max(&total_p2.product, &m_pg.product) };
                            last_p5 = RxLast::RxLastRepetition;
                            last_m_p6 = m_pg.clone();
                        }
                    }
                } else {
                    let (kind_ph, m_pi, fi2_pj, st2_pk) = rx_piece(&st_p4, &fi_p3);
                    st_p4 = st2_pk.clone();
                    fi_p3 = fi2_pj;
                    if &kind_ph != &RxLast::RxLastFlagGroup {
                        total_p2 = rx_then(&total_p2, &m_pi);
                    }
                    last_p5 = kind_ph.clone();
                    last_m_p6 = m_pi.clone();
                }
                Ok((this, fi_p3, going_p7, last_p5, last_m_p6, st_p4, total_p2))
            }
        } else {
            Err((this, fi_p3, going_p7, last_p5, last_m_p6, st_p4, total_p2))
        }), move |(mut this, mut fi_p3, mut going_p7, mut last_p5, mut last_m_p6, mut st_p4, mut total_p2): ((RxMeasure, bool, RxState), bool, bool, RxLast, RxMeasure, RxState, RxMeasure)| {
            this = (total_p2.clone(), fi_p3, st_p4.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start RxSequence, x`: what the function value is when passed to `@Run`.
pub fn start_rx_sequence(st0_p0: RxState, fi0_p1: bool) -> Rc<dyn prism_rtl::Job<(RxMeasure, bool, RxState)>> {
    Rc::new(RxSequence { st0_p0, fi0_p1 })
}

/// ```prism
/// RxSimpleRepetition: fn RxState, Text -> ((Nat, ?Nat, RxState))
/// ```
pub fn rx_simple_repetition(st_p0: &RxState, c_p1: &Text) -> (Nat, Option<Nat>, RxState) {
    let st2_p2 = rx_go(st_p0, &(&st_p0.i + &Nat::from(1u32)));
    if c_p1 == &Text::lit("*") {
        (Nat::from(0u32), None, st2_p2.clone())
    } else {
        if c_p1 == &Text::lit("+") {
            (Nat::from(1u32), None, st2_p2.clone())
        } else {
            (Nat::from(0u32), Some(Nat::from(1u32)), st2_p2.clone())
        }
    }
}

/// ```prism
/// RxCount: unbounded fn RxState -> ((Nat, ?Nat, RxState))
/// ```
pub fn rx_count(st_p0: &RxState) -> (Nat, Option<Nat>, RxState) {
    let at_p1 = st_p0.i.clone();
    let s_p2 = st_p0.s.clone();
    let j1_p3 = rx_span_end(&s_p2, &(&at_p1 + &Nat::from(1u32)), &{
        let f = Rc::new(rx_is_digit);
        Rc::new(move |a0: Text| {
            let f = f.clone();
            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
    });
    let first_p4 = rx_slice(&s_p2, &(&at_p1 + &Nat::from(1u32)), &j1_p3);
    let c_p5 = rx_char_at(&s_p2, &j1_p3);
    if &first_p4 == &Text::lit("") {
        (Nat::from(0u32), None, rx_fail(st_p0, &at_p1, &rx_brace()))
    } else {
        if &c_p5 == &Text::lit("}") {
            rx_count_checked(st_p0, &at_p1, &first_p4, &None, &(&j1_p3 + &Nat::from(1u32)))
        } else {
            if &c_p5 == &Text::lit(",") {
                {
                    let j2_p6 = rx_span_end(&s_p2, &(&j1_p3 + &Nat::from(1u32)), &{
                        let f = Rc::new(rx_is_digit);
                        Rc::new(move |a0: Text| {
                            let f = f.clone();
                            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                    });
                    if &rx_char_at(&s_p2, &j2_p6) != &Text::lit("}") {
                        (Nat::from(0u32), None, rx_fail(st_p0, &at_p1, &rx_brace()))
                    } else {
                        rx_count_checked(st_p0, &at_p1, &first_p4, &Some(rx_slice(&s_p2, &(&j1_p3 + &Nat::from(1u32)), &j2_p6)), &(&j2_p6 + &Nat::from(1u32)))
                    }
                }
            } else {
                (Nat::from(0u32), None, rx_fail(st_p0, &at_p1, &rx_brace()))
            }
        }
    }
}

/// ```prism
/// RxCountChecked: fn RxState, Nat, Text, ?Text, Nat -> ((Nat, ?Nat, RxState))
/// ```
pub fn rx_count_checked(st_p0: &RxState, at_p1: &Nat, first_p2: &Text, second_o3: &Option<Text>, next_p4: &Nat) -> (Nat, Option<Nat>, RxState) {
    let st1_p5 = rx_go(st_p0, next_p4);
    let lo_p6 = or(&parse_nat_opt(first_p2), &Nat::from(0u32));
    let hi_o7 = match second_o3 {
        None => Some(lo_p6.clone()),
        Some(m20974_1) if (m20974_1 == &Text::lit("")) => None,
        Some(d_p9) => parse_nat_opt(d_p9),
        _ => unreachable!("no arm matched"),
    };
    let zero_p8 = rx_leading_zero(first_p2) || rx_leading_zero(&or(second_o3, &Text::lit("")));
    if zero_p8 {
        (Nat::from(0u32), None, rx_fail(&st1_p5, at_p1, &rx_count_zero()))
    } else {
        if (&lo_p6 > &Nat::from(1000u32)) || (&or(&hi_o7, &Nat::from(0u32)) > &Nat::from(1000u32)) {
            (Nat::from(0u32), None, rx_fail(&st1_p5, at_p1, &rx_count_bound()))
        } else {
            if &lo_p6 > &or(&hi_o7, &lo_p6) {
                (Nat::from(0u32), None, rx_fail(&st1_p5, at_p1, &rx_count_order()))
            } else {
                (lo_p6.clone(), hi_o7.clone(), st1_p5.clone())
            }
        }
    }
}

/// ```prism
/// RxLeadingZero: fn Text -> Bool
/// ```
pub fn rx_leading_zero(d_p0: &Text) -> bool {
    (&len_text(d_p0) > &Nat::from(1u32)) && (&rx_char_at(d_p0, &Nat::from(0u32)) == &Text::lit("0"))
}

/// ```prism
/// RxPiece: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_piece(st_p0: &RxState, fi_p1: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let at_p2 = st_p0.i.clone();
    let c_p3 = rx_peek(st_p0);
    match &c_p3 {
        m21753_0 if (m21753_0 == &Text::lit("(")) => rx_group(st_p0, fi_p1),
        m21753_1 if (m21753_1 == &Text::lit("[")) => (RxLast::RxLastAtom, rx_atom(), *fi_p1, rx_class(st_p0, fi_p1)),
        m21753_2 if (m21753_2 == &Text::lit("]")) => (RxLast::RxLastAtom, rx_atom(), *fi_p1, rx_fail(st_p0, &at_p2, &rx_stray_bracket())),
        m21753_3 if (m21753_3 == &Text::lit("}")) => (RxLast::RxLastAtom, rx_atom(), *fi_p1, rx_fail(st_p0, &at_p2, &rx_stray_brace())),
        m21753_4 if (m21753_4 == &Text::lit("^")) => (RxLast::RxLastAssertion, rx_atom(), *fi_p1, rx_go(st_p0, &(&at_p2 + &Nat::from(1u32)))),
        m21753_5 if (m21753_5 == &Text::lit("$")) => (RxLast::RxLastAssertion, rx_atom(), *fi_p1, rx_go(st_p0, &(&at_p2 + &Nat::from(1u32)))),
        m21753_6 if (m21753_6 == &Text::lit("\\")) => rx_escape(st_p0, fi_p1),
        _ => (RxLast::RxLastAtom, rx_atom(), *fi_p1, rx_go(st_p0, &(&at_p2 + &len_text(&c_p3)))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RxEscape: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_escape(st_p0: &RxState, fi_p1: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let at_p2 = st_p0.i.clone();
    let s_p3 = st_p0.s.clone();
    let c_p4 = rx_char_at(&s_p3, &(&at_p2 + &Nat::from(1u32)));
    let atom_f5 = {
        let fi_p1 = *fi_p1;
        Rc::new(move |next_p6: &RxState| (RxLast::RxLastAtom, rx_atom(), fi_p1, next_p6.clone())) as Rc<dyn Fn(&RxState) -> (RxLast, RxMeasure, bool, RxState)>
    };
    if &c_p4 == &Text::lit("") {
        (&atom_f5)(&rx_fail(st_p0, &at_p2, &rx_trailing_backslash()))
    } else {
        if (&c_p4 == &Text::lit("<")) || (&c_p4 == &Text::lit(">")) {
            (&atom_f5)(&rx_fail(st_p0, &at_p2, &rx_angle()))
        } else {
            if rx_in(&rx_punctuation(), &c_p4) {
                (&atom_f5)(&rx_go(st_p0, &(&at_p2 + &Nat::from(2u32))))
            } else {
                if rx_in(&Text::lit("tnrfva"), &c_p4) {
                    (&atom_f5)(&rx_go(st_p0, &(&at_p2 + &Nat::from(2u32))))
                } else {
                    if &c_p4 == &Text::lit("x") {
                        {
                            let (_, st2_p7) = rx_hex(st_p0, &at_p2);
                            (&atom_f5)(&st2_p7)
                        }
                    } else {
                        if rx_in(&Text::lit("dwsDWS"), &c_p4) {
                            (&atom_f5)(&rx_go(st_p0, &(&at_p2 + &Nat::from(2u32))))
                        } else {
                            if (&c_p4 == &Text::lit("p")) || (&c_p4 == &Text::lit("P")) {
                                {
                                    let (_, st2_p8) = rx_property(st_p0, &at_p2);
                                    (&atom_f5)(&st2_p8)
                                }
                            } else {
                                if rx_in(&Text::lit("AzbB"), &c_p4) {
                                    if (&c_p4 == &Text::lit("b")) && (&rx_char_at(&s_p3, &(&at_p2 + &Nat::from(2u32))) == &Text::lit("{")) {
                                        (&atom_f5)(&rx_fail(st_p0, &at_p2, &rx_word_braces()))
                                    } else {
                                        (RxLast::RxLastAssertion, rx_atom(), *fi_p1, rx_go(st_p0, &(&at_p2 + &Nat::from(2u32))))
                                    }
                                } else {
                                    if rx_in(&Text::lit("123456789"), &c_p4) {
                                        (&atom_f5)(&rx_fail(st_p0, &at_p2, &rx_backreference()))
                                    } else {
                                        if &c_p4 == &Text::lit("0") {
                                            (&atom_f5)(&rx_fail(st_p0, &at_p2, &rx_octal()))
                                        } else {
                                            if (&c_p4 == &Text::lit("Q")) || (&c_p4 == &Text::lit("E")) {
                                                (&atom_f5)(&rx_fail(st_p0, &at_p2, &rx_quote()))
                                            } else {
                                                if &c_p4 == &Text::lit("C") {
                                                    (&atom_f5)(&rx_fail(st_p0, &at_p2, &rx_one_byte()))
                                                } else {
                                                    (&atom_f5)(&rx_fail(st_p0, &at_p2, &rx_unknown_escape()))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxHex: unbounded fn RxState, Nat -> ((Nat, RxState))
/// ```
pub fn rx_hex(st_p0: &RxState, at_p1: &Nat) -> (Nat, RxState) {
    let s_p2 = st_p0.s.clone();
    let x_p3 = at_p1 + &Nat::from(1u32);
    if &rx_char_at(&s_p2, &(&x_p3 + &Nat::from(1u32))) == &Text::lit("{") {
        {
            let start_p4 = &x_p3 + &Nat::from(2u32);
            let j_p5 = rx_span_end(&s_p2, &start_p4, &{
                let f = Rc::new(rx_is_hex);
                Rc::new(move |a0: Text| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
            });
            let digits_p6 = rx_slice(&s_p2, &start_p4, &j_p5);
            if ((&rx_char_at(&s_p2, &j_p5) != &Text::lit("}")) || (&digits_p6 == &Text::lit(""))) || (&len_text(&digits_p6) > &Nat::from(6u32)) {
                (Nat::from(0u32), rx_fail(st_p0, at_p1, &rx_hex_braces()))
            } else {
                rx_hex_checked(&rx_go(st_p0, &(&j_p5 + &Nat::from(1u32))), at_p1, &rx_hex_value(&digits_p6))
            }
        }
    } else {
        {
            let a_p7 = rx_char_at(&s_p2, &(&x_p3 + &Nat::from(1u32)));
            let b_p8 = rx_char_at(&s_p2, &(&x_p3 + &Nat::from(2u32)));
            if rx_is_hex(&a_p7) && rx_is_hex(&b_p8) {
                rx_hex_checked(&rx_go(st_p0, &(&x_p3 + &Nat::from(3u32))), at_p1, &rx_hex_value(&Text::from(format!("{}{}", &a_p7, &b_p8))))
            } else {
                (Nat::from(0u32), rx_fail(st_p0, at_p1, &rx_hex_two()))
            }
        }
    }
}

/// ```prism
/// RxHexChecked: fn RxState, Nat, Nat -> ((Nat, RxState))
/// ```
pub fn rx_hex_checked(st_p0: &RxState, at_p1: &Nat, v_p2: &Nat) -> (Nat, RxState) {
    if ((&Nat::from(55296u32) <= v_p2) && (v_p2 <= &Nat::from(57343u32))) || (v_p2 > &Nat::from(1114111u32)) {
        (v_p2.clone(), rx_fail(st_p0, at_p1, &rx_hex_no_char()))
    } else {
        (v_p2.clone(), st_p0.clone())
    }
}

/// ```prism
/// RxProperty: unbounded fn RxState, Nat -> ((Text, RxState))
/// ```
pub fn rx_property(st_p0: &RxState, at_p1: &Nat) -> (Text, RxState) {
    let s_p2 = st_p0.s.clone();
    let c_p3 = rx_char_at(&s_p2, &(at_p1 + &Nat::from(2u32)));
    if &c_p3 == &Text::lit("{") {
        {
            let start_p4 = at_p1 + &Nat::from(3u32);
            match rx_find(&s_p2, &start_p4, &Text::lit("}")) {
                None => (Text::lit(""), rx_fail(st_p0, at_p1, &rx_property_open())),
                Some(close_p5) => {
                    let name_p6 = rx_slice(&s_p2, &start_p4, &close_p5);
                    if &rx_char_at(&name_p6, &Nat::from(0u32)) == &Text::lit("^") {
                        (name_p6.clone(), rx_fail(st_p0, at_p1, &rx_property_negated()))
                    } else {
                        rx_property_named(&rx_go(st_p0, &(&close_p5 + &Nat::from(1u32))), at_p1, &name_p6)
                    }
                },
            }
        }
    } else {
        if rx_is_letter(&c_p3) {
            rx_property_named(&rx_go(st_p0, &(at_p1 + &Nat::from(3u32))), at_p1, &c_p3)
        } else {
            (Text::lit(""), rx_fail(st_p0, at_p1, &rx_property_name()))
        }
    }
}

/// ```prism
/// RxPropertyNamed: fn RxState, Nat, Text -> ((Text, RxState))
/// ```
pub fn rx_property_named(st_p0: &RxState, at_p1: &Nat, name_p2: &Text) -> (Text, RxState) {
    if (((name_p2 == &Text::lit("C")) || (name_p2 == &Text::lit("Cn"))) || (name_p2 == &Text::lit("Cs"))) || (name_p2 == &Text::lit("LC")) {
        (name_p2.clone(), rx_fail(st_p0, at_p1, &rx_property_refused()))
    } else {
        if &get(&rx_properties(), name_p2) != &None {
            (name_p2.clone(), st_p0.clone())
        } else {
            (name_p2.clone(), rx_fail(st_p0, at_p1, &rx_property_unknown()))
        }
    }
}

/// ```prism
/// RxClass: unbounded fn RxState, Bool -> RxState
/// ```
pub fn rx_class(st0_p0: &RxState, fi_p1: &bool) -> RxState {
    let open_p2 = st0_p0.i.clone();
    let start_p3 = if &rx_char_at(&st0_p0.s, &(&open_p2 + &Nat::from(1u32))) == &Text::lit("^") {
        &open_p2 + &Nat::from(2u32)
    } else {
        &open_p2 + &Nat::from(1u32)
    };
    let mut this: RxState = rx_go(st0_p0, &start_p3);
    let mut first_p4: bool = true;
    let mut done_p5: bool = false;
    while !done_p5 {
        let (closed_p6, st2_p7) = rx_class_item(&this, &open_p2, &start_p3, &first_p4, fi_p1);
        this = st2_p7.clone();
        first_p4 = false;
        done_p5 = closed_p6 || rx_bad(&st2_p7);
    }
    this
}

/// ```prism
/// RxAtSetOperation: fn RxState -> Bool
/// ```
pub fn rx_at_set_operation(st_p0: &RxState) -> bool {
    let c_p1 = rx_peek(st_p0);
    (((&c_p1 == &Text::lit("&")) || (&c_p1 == &Text::lit("~"))) || (&c_p1 == &Text::lit("-"))) && (&rx_char_at(&st_p0.s, &(&st_p0.i + &Nat::from(1u32))) == &c_p1)
}

/// ```prism
/// RxClassItem: unbounded fn RxState, Nat, Nat, Bool, Bool -> ((Bool, RxState))
/// ```
pub fn rx_class_item(st_p0: &RxState, open_p1: &Nat, start_p2: &Nat, first_p3: &bool, fi_p4: &bool) -> (bool, RxState) {
    let at_p5 = st_p0.i.clone();
    let c_p6 = rx_peek(st_p0);
    let next_p7 = rx_char_at(&st_p0.s, &(&at_p5 + &Nat::from(1u32)));
    if &c_p6 == &Text::lit("") {
        (true, rx_fail(st_p0, open_p1, &rx_class_open()))
    } else {
        if (&c_p6 == &Text::lit("]")) && *first_p3 {
            (true, rx_fail(st_p0, &at_p5, &rx_class_first_bracket()))
        } else {
            if &c_p6 == &Text::lit("]") {
                (true, rx_go(st_p0, &(&at_p5 + &Nat::from(1u32))))
            } else {
                if rx_at_set_operation(st_p0) {
                    (true, rx_fail(st_p0, &at_p5, &rx_class_set_operation()))
                } else {
                    if &c_p6 == &Text::lit("[") {
                        (false, rx_ascii_item(st_p0, fi_p4))
                    } else {
                        if (&c_p6 == &Text::lit("-")) && (&next_p7 == &Text::lit("")) {
                            (true, rx_fail(st_p0, open_p1, &rx_class_open()))
                        } else {
                            if (&c_p6 == &Text::lit("-")) && ((&at_p5 == start_p2) || (&next_p7 == &Text::lit("]"))) {
                                (false, rx_go(st_p0, &(&at_p5 + &Nat::from(1u32))))
                            } else {
                                if &c_p6 == &Text::lit("-") {
                                    (true, rx_fail(st_p0, &at_p5, &rx_class_dash()))
                                } else {
                                    (false, rx_class_range(st_p0, open_p1, fi_p4))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxClassRange: unbounded fn RxState, Nat, Bool -> RxState
/// ```
pub fn rx_class_range(st_p0: &RxState, open_p1: &Nat, fi_p2: &bool) -> RxState {
    let at_p3 = st_p0.i.clone();
    let (lo_o4, st1_p5) = rx_class_atom(st_p0, fi_p2);
    match &lo_o4 {
        None => st1_p5.clone(),
        Some(lo_p6) => {
            let s_p7 = st1_p5.s.clone();
            let ranged_p8 = (&rx_peek(&st1_p5) == &Text::lit("-")) && (&rx_char_at(&s_p7, &(&st1_p5.i + &Nat::from(1u32))) != &Text::lit("]"));
            if rx_bad(&st1_p5) || !ranged_p8 {
                st1_p5.clone()
            } else {
                if rx_at_set_operation(&st1_p5) {
                    rx_fail(&st1_p5, &st1_p5.i, &rx_class_set_operation())
                } else {
                    {
                        let right_p9 = &st1_p5.i + &Nat::from(1u32);
                        let st2_pa = rx_go(&st1_p5, &right_p9);
                        let rc_pb = rx_peek(&st2_pa);
                        if &rc_pb == &Text::lit("") {
                            rx_fail(&st2_pa, open_p1, &rx_class_open())
                        } else {
                            if &rc_pb == &Text::lit("[") {
                                rx_fail(&st2_pa, &right_p9, &rx_class_nested())
                            } else {
                                if rx_at_set_operation(&st2_pa) {
                                    rx_fail(&st2_pa, &right_p9, &rx_class_set_operation())
                                } else {
                                    {
                                        let (hi_oc, st3_pd) = rx_class_atom(&st2_pa, fi_p2);
                                        if rx_bad(&st3_pd) {
                                            st3_pd.clone()
                                        } else {
                                            match &hi_oc {
                                                None => rx_fail(&st3_pd, &right_p9, &rx_class_range_set()),
                                                Some(hi_pe) => if rx_past(lo_p6, hi_pe) {
                                                    rx_fail(&st3_pd, &at_p3, &rx_class_order())
                                                } else {
                                                    st3_pd.clone()
                                                },
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
    }
}

/// ```prism
/// RxClassAtom: unbounded fn RxState, Bool -> ((?RxCp, RxState))
/// ```
pub fn rx_class_atom(st_p0: &RxState, fi_p1: &bool) -> (Option<RxCp>, RxState) {
    let at_p2 = st_p0.i.clone();
    let s_p3 = st_p0.s.clone();
    let c_p4 = rx_peek(st_p0);
    if &c_p4 != &Text::lit("\\") {
        (Some(RxCp::RxLit(c_p4.clone())), rx_go(st_p0, &(&at_p2 + &len_text(&c_p4))))
    } else {
        {
            let e_p5 = rx_char_at(&s_p3, &(&at_p2 + &Nat::from(1u32)));
            if &e_p5 == &Text::lit("") {
                (None, rx_fail(st_p0, &at_p2, &rx_trailing_backslash()))
            } else {
                if (&e_p5 == &Text::lit("<")) || (&e_p5 == &Text::lit(">")) {
                    (None, rx_fail(st_p0, &at_p2, &rx_class_escape()))
                } else {
                    if rx_in(&rx_punctuation(), &e_p5) {
                        (Some(RxCp::RxLit(e_p5.clone())), rx_go(st_p0, &(&at_p2 + &Nat::from(2u32))))
                    } else {
                        if rx_in(&Text::lit("tnrfva"), &e_p5) {
                            (Some(RxCp::RxLit(rx_control(&e_p5))), rx_go(st_p0, &(&at_p2 + &Nat::from(2u32))))
                        } else {
                            if &e_p5 == &Text::lit("x") {
                                {
                                    let (v_p6, st2_p7) = rx_hex(st_p0, &at_p2);
                                    (Some(rx_cp_of(&v_p6)), st2_p7.clone())
                                }
                            } else {
                                if rx_in(&Text::lit("dws"), &e_p5) {
                                    (None, rx_go(st_p0, &(&at_p2 + &Nat::from(2u32))))
                                } else {
                                    if rx_in(&Text::lit("DWS"), &e_p5) {
                                        if *fi_p1 {
                                            (None, rx_fail(st_p0, &at_p2, &rx_class_negated_under_i()))
                                        } else {
                                            (None, rx_go(st_p0, &(&at_p2 + &Nat::from(2u32))))
                                        }
                                    } else {
                                        if (&e_p5 == &Text::lit("p")) || (&e_p5 == &Text::lit("P")) {
                                            {
                                                let (_, st2_p8) = rx_property(st_p0, &at_p2);
                                                if ((&e_p5 == &Text::lit("P")) && *fi_p1) && !rx_bad(&st2_p8) {
                                                    (None, rx_fail(&st2_p8, &at_p2, &rx_class_negated_under_i()))
                                                } else {
                                                    (None, st2_p8.clone())
                                                }
                                            }
                                        } else {
                                            (None, rx_fail(st_p0, &at_p2, &rx_class_escape()))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxControl: fn Text -> Text
/// ```
pub fn rx_control(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("t")) => Text::lit("\t"),
        c1_0 if (c1_0 == &Text::lit("n")) => Text::lit("\n"),
        c2_0 if (c2_0 == &Text::lit("r")) => Text::lit("\r"),
        c3_0 if (c3_0 == &Text::lit("f")) => Text::lit(""),
        c4_0 if (c4_0 == &Text::lit("v")) => Text::lit(""),
        _ => Text::lit(""),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RxAsciiItem: unbounded fn RxState, Bool -> RxState
/// ```
pub fn rx_ascii_item(st_p0: &RxState, fi_p1: &bool) -> RxState {
    let at_p2 = st_p0.i.clone();
    let s_p3 = st_p0.s.clone();
    let negated_p4 = &rx_char_at(&s_p3, &(&at_p2 + &Nat::from(2u32))) == &Text::lit("^");
    let start_p5 = if negated_p4 { &at_p2 + &Nat::from(3u32) } else { &at_p2 + &Nat::from(2u32) };
    let j_p6 = rx_span_end(&s_p3, &start_p5, &{
        let f = Rc::new(rx_is_letter);
        Rc::new(move |a0: Text| {
            let f = f.clone();
            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
    });
    let shaped_p7 = (((&rx_char_at(&s_p3, &(&at_p2 + &Nat::from(1u32))) == &Text::lit(":")) && (&j_p6 > &start_p5)) && (&rx_char_at(&s_p3, &j_p6) == &Text::lit(":"))) && (&rx_char_at(&s_p3, &(&j_p6 + &Nat::from(1u32))) == &Text::lit("]"));
    if !shaped_p7 {
        rx_fail(st_p0, &at_p2, &rx_class_nested())
    } else {
        if &get(&rx_ascii_classes(), &rx_slice(&s_p3, &start_p5, &j_p6)) == &None {
            rx_fail(st_p0, &at_p2, &rx_class_ascii_unknown())
        } else {
            if negated_p4 && *fi_p1 {
                rx_fail(st_p0, &at_p2, &rx_class_negated_under_i())
            } else {
                rx_go(st_p0, &(&j_p6 + &Nat::from(2u32)))
            }
        }
    }
}

/// ```prism
/// RxGroup: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_group(st_p0: &RxState, fi_p1: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let open_p2 = st_p0.i.clone();
    let s_p3 = st_p0.s.clone();
    let c_p4 = rx_char_at(&s_p3, &(&open_p2 + &Nat::from(1u32)));
    let d_p5 = rx_char_at(&s_p3, &(&open_p2 + &Nat::from(2u32)));
    let e_p6 = rx_char_at(&s_p3, &(&open_p2 + &Nat::from(3u32)));
    let fail_f7 = {
        let fi_p1 = *fi_p1;
        let st_p0 = st_p0.clone();
        let open_p2 = open_p2.clone();
        Rc::new(move |message_p8: &Text| (RxLast::RxLastAtom, rx_atom(), fi_p1, rx_fail(&st_p0, &open_p2, message_p8))) as Rc<dyn Fn(&Text) -> (RxLast, RxMeasure, bool, RxState)>
    };
    if &c_p4 != &Text::lit("?") {
        rx_group_body(&rx_go(st_p0, &(&open_p2 + &Nat::from(1u32))), &open_p2, fi_p1, fi_p1, &true, &None)
    } else {
        if &d_p5 == &Text::lit("") {
            (&fail_f7)(&rx_group_open())
        } else {
            if &d_p5 == &Text::lit(":") {
                rx_group_body(&rx_go(st_p0, &(&open_p2 + &Nat::from(3u32))), &open_p2, fi_p1, fi_p1, &false, &None)
            } else {
                if (&d_p5 == &Text::lit("=")) || (&d_p5 == &Text::lit("!")) {
                    (&fail_f7)(&rx_lookaround())
                } else {
                    if (&d_p5 == &Text::lit("<")) && ((&e_p6 == &Text::lit("=")) || (&e_p6 == &Text::lit("!"))) {
                        (&fail_f7)(&rx_lookaround())
                    } else {
                        if &d_p5 == &Text::lit("<") {
                            rx_named(st_p0, &open_p2, &(&open_p2 + &Nat::from(3u32)), fi_p1)
                        } else {
                            if (&d_p5 == &Text::lit("P")) && (&e_p6 == &Text::lit("")) {
                                (&fail_f7)(&rx_group_open())
                            } else {
                                if (&d_p5 == &Text::lit("P")) && (&e_p6 == &Text::lit("<")) {
                                    rx_named(st_p0, &open_p2, &(&open_p2 + &Nat::from(4u32)), fi_p1)
                                } else {
                                    if (&d_p5 == &Text::lit("P")) && ((&e_p6 == &Text::lit("=")) || (&e_p6 == &Text::lit(">"))) {
                                        (&fail_f7)(&rx_backreference())
                                    } else {
                                        if &d_p5 == &Text::lit("P") {
                                            (&fail_f7)(&rx_unknown_group())
                                        } else {
                                            if (rx_is_letter(&d_p5) || (&d_p5 == &Text::lit("-"))) || (&d_p5 == &Text::lit(")")) {
                                                rx_flag_group(st_p0, &open_p2, fi_p1)
                                            } else {
                                                (&fail_f7)(&rx_unknown_group())
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxNamed: unbounded fn RxState, Nat, Nat, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_named(st_p0: &RxState, open_p1: &Nat, start_p2: &Nat, fi_p3: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    match rx_find(&st_p0.s, start_p2, &Text::lit(">")) {
        None => (RxLast::RxLastAtom, rx_atom(), *fi_p3, rx_fail(st_p0, open_p1, &rx_name_open())),
        Some(close_p4) => {
            let name_p5 = rx_slice(&st_p0.s, start_p2, &close_p4);
            if !rx_is_name(&name_p5) {
                (RxLast::RxLastAtom, rx_atom(), *fi_p3, rx_fail(st_p0, start_p2, &rx_name_shape()))
            } else {
                if &get(&st_p0.names, &name_p5) != &None {
                    (RxLast::RxLastAtom, rx_atom(), *fi_p3, rx_fail(st_p0, open_p1, &rx_name_twice()))
                } else {
                    rx_group_body(&rx_go(st_p0, &(&close_p4 + &Nat::from(1u32))), open_p1, fi_p3, fi_p3, &true, &Some(name_p5.clone()))
                }
            }
        },
    }
}

/// ```prism
/// RxFlagGroup: unbounded fn RxState, Nat, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_flag_group(st_p0: &RxState, open_p1: &Nat, fi_p2: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let (bare_p3, inner_p4, st2_p5) = rx_flag_letters(st_p0, open_p1, fi_p2);
    if rx_bad(&st2_p5) {
        (RxLast::RxLastAtom, rx_atom(), *fi_p2, st2_p5.clone())
    } else {
        if bare_p3 {
            (RxLast::RxLastFlagGroup, rx_none(), inner_p4, st2_p5.clone())
        } else {
            rx_group_body(&st2_p5, open_p1, &inner_p4, fi_p2, &false, &None)
        }
    }
}

/// ```prism
/// RxFlagLetters: unbounded fn RxState, Nat, Bool -> ((Bool, Bool, RxState))
/// ```
pub fn rx_flag_letters(st0_p0: &RxState, open_p1: &Nat, fi0_p2: &bool) -> (bool, bool, RxState) {
    let mut this: (bool, bool, RxState) = (false, *fi0_p2, st0_p0.clone());
    let mut st_p3: RxState = rx_go(st0_p0, &(open_p1 + &Nat::from(2u32)));
    let mut fi_p4: bool = *fi0_p2;
    let mut seen_p5: Text = Text::lit("");
    let mut dash_o6: Option<Nat> = None;
    let mut after_dash_p7: bool = false;
    let mut named_p8: bool = false;
    let mut bare_p9: bool = false;
    let mut going_pa: bool = true;
    while going_pa && !rx_bad(&st_p3) {
        let at_pb = st_p3.i.clone();
        let c_pc = rx_peek(&st_p3);
        if &c_pc == &Text::lit("") {
            st_p3 = rx_fail(&st_p3, open_p1, &rx_group_open());
        } else if (&c_pc == &Text::lit(")")) || (&c_pc == &Text::lit(":")) {
            if !named_p8 && (&dash_o6 == &None) {
                st_p3 = rx_fail(&st_p3, open_p1, &rx_flags_empty());
            } else {
                match &dash_o6 {
                    Some(d_pd) if !after_dash_p7 => {
                        st_p3 = rx_fail(&st_p3, d_pd, &rx_flags_dash());
                        ()
                    },
                    _ => {
                        st_p3 = rx_go(&st_p3, &(&at_pb + &Nat::from(1u32)));
                        bare_p9 = &c_pc == &Text::lit(")");
                        going_pa = false;
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
            }
        } else if &c_pc == &Text::lit("-") {
            if &dash_o6 != &None {
                st_p3 = rx_fail(&st_p3, &at_pb, &rx_flags_second_dash());
            } else {
                dash_o6 = Some(at_pb.clone());
                st_p3 = rx_go(&st_p3, &(&at_pb + &Nat::from(1u32)));
            }
        } else if rx_is_letter(&c_pc) {
            if !(((&c_pc == &Text::lit("i")) || (&c_pc == &Text::lit("m"))) || (&c_pc == &Text::lit("s"))) {
                st_p3 = rx_fail(&st_p3, &at_pb, &rx_unknown_flag());
            } else if rx_in(&seen_p5, &c_pc) {
                st_p3 = rx_fail(&st_p3, &at_pb, &rx_flag_twice());
            } else {
                seen_p5 = Text::from(format!("{}{}", &seen_p5, &c_pc));
                named_p8 = true;
                if &dash_o6 != &None {
                    after_dash_p7 = true;
                }
                if &c_pc == &Text::lit("i") {
                    fi_p4 = &dash_o6 == &None;
                }
                st_p3 = rx_go(&st_p3, &(&at_pb + &Nat::from(1u32)));
            }
        } else {
            st_p3 = rx_fail(&st_p3, open_p1, &rx_unknown_group());
        }
    }
    this = (bare_p9, fi_p4, st_p3.clone());
    this
}

/// ```prism
/// RxGroupBody: unbounded fn RxState, Nat, Bool, Bool, Bool, ?Text -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_group_body(st0_p0: &RxState, open_p1: &Nat, inner_p2: &bool, outer_p3: &bool, capture_p4: &bool, name_o5: &Option<Text>) -> (RxLast, RxMeasure, bool, RxState) {
    let counted_p6 = if *capture_p4 { rx_capture(st0_p0, name_o5) } else { st0_p0.clone() };
    if &counted_p6.open == &Nat::from(100u32) {
        (RxLast::RxLastAtom, rx_atom(), *outer_p3, rx_fail(&counted_p6, &Nat::from(0u32), &rx_nesting()))
    } else {
        {
            let deeper_p7 = {
                let mut this: RxState = counted_p6.clone();
                this.open = &this.open + &Nat::from(1u32);
                this
            };
            let (m_p8, st2_p9) = rx_alternation(&deeper_p7, inner_p2);
            if rx_bad(&st2_p9) {
                (RxLast::RxLastAtom, rx_atom(), *outer_p3, st2_p9.clone())
            } else {
                if &rx_peek(&st2_p9) != &Text::lit(")") {
                    (RxLast::RxLastAtom, rx_atom(), *outer_p3, rx_fail(&st2_p9, open_p1, &rx_group_open()))
                } else {
                    {
                        let closed_pa = {
                            let mut this: RxState = st2_p9.clone();
                            this.i = &this.i + &Nat::from(1u32);
                            this.open = or(&(&this.open).checked_sub(&Nat::from(1u32)), &Nat::from(0u32));
                            this
                        };
                        (RxLast::RxLastAtom, RxMeasure { depth: &m_p8.depth + &Nat::from(1u32), size: m_p8.size.clone(), product: m_p8.product.clone() }, *outer_p3, closed_pa.clone())
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxCapture: fn RxState, ?Text -> RxState
/// ```
pub fn rx_capture(st_p0: &RxState, name_o1: &Option<Text>) -> RxState {
    let n_p2 = &st_p0.groups + &Nat::from(1u32);
    let names_p3 = match name_o1 {
        Some(x_p4) => insert(&st_p0.names, x_p4, &n_p2),
        None => st_p0.names.clone(),
    };
    RxState { s: st_p0.s.clone(), i: st_p0.i.clone(), open: st_p0.open.clone(), groups: n_p2.clone(), names: names_p3.clone(), err: st_p0.err.clone() }
}

/// ```prism
/// ?RxReplacementRefusal: unbounded fn Text, Nat, (Text ==> Nat) -> ?RxDiag
/// ```
pub fn rx_replacement_refusal(r_p0: &Text, groups_p1: &Nat, names_p2: &Map<Text, Nat>) -> Option<RxDiag> {
    let (d_of, _) = {
        let mut this: (Option<RxDiag>, Nat) = (None, Nat::from(0u32));
        let mut i_p3: Nat = Nat::from(0u32);
        let mut d_o4: Option<RxDiag> = None;
        while (&d_o4 == &None) && (&rx_char_at(r_p0, &i_p3) != &Text::lit("")) {
            let at_p5 = i_p3.clone();
            let c_p6 = rx_char_at(r_p0, &at_p5);
            let next_p7 = rx_char_at(r_p0, &(&at_p5 + &Nat::from(1u32)));
            if &c_p6 == &Text::lit("$") {
                if &next_p7 == &Text::lit("$") {
                    i_p3 = &at_p5 + &Nat::from(2u32);
                } else if rx_is_digit(&next_p7) {
                    let j_p8 = rx_span_end(r_p0, &(&at_p5 + &Nat::from(1u32)), &{
                        let f = Rc::new(rx_is_digit);
                        Rc::new(move |a0: Text| {
                            let f = f.clone();
                            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                    });
                    d_o4 = rx_group_number(&rx_slice(r_p0, &(&at_p5 + &Nat::from(1u32)), &j_p8), groups_p1, &at_p5);
                    i_p3 = j_p8.clone();
                } else if &next_p7 == &Text::lit("{") {
                    match &rx_find(r_p0, &(&at_p5 + &Nat::from(2u32)), &Text::lit("}")) {
                        None => {
                            d_o4 = rx_replacement_at(&at_p5, &rx_rbraces());
                        }
                        Some(close_p9) => {
                            let inner_pa = rx_slice(r_p0, &(&at_p5 + &Nat::from(2u32)), close_p9);
                            if (&inner_pa != &Text::lit("")) && rx_all(&inner_pa, &{
                                let f = Rc::new(rx_is_digit);
                                Rc::new(move |a0: Text| {
                                    let f = f.clone();
                                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                            }) {
                                d_o4 = rx_group_number(&inner_pa, groups_p1, &at_p5);
                            } else if rx_is_name(&inner_pa) {
                                if &get(names_p2, &inner_pa) == &None {
                                    d_o4 = rx_replacement_at(&at_p5, &rx_rno_name());
                                }
                            } else {
                                d_o4 = rx_replacement_at(&at_p5, &rx_rbraces());
                            }
                            i_p3 = close_p9 + &Nat::from(1u32);
                        }
                    }
                } else {
                    d_o4 = rx_replacement_at(&at_p5, &rx_rdollar());
                }
            } else if &c_p6 == &Text::lit("\\") {
                if (((&next_p7 == &Text::lit("\\")) || (&next_p7 == &Text::lit("n"))) || (&next_p7 == &Text::lit("t"))) || (&next_p7 == &Text::lit("/")) {
                    i_p3 = &at_p5 + &Nat::from(2u32);
                } else if &next_p7 == &Text::lit("u") {
                    let j_pb = rx_span_end(r_p0, &(&at_p5 + &Nat::from(3u32)), &{
                        let f = Rc::new(rx_is_hex);
                        Rc::new(move |a0: Text| {
                            let f = f.clone();
                            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                    });
                    let digits_pc = rx_slice(r_p0, &(&at_p5 + &Nat::from(3u32)), &j_pb);
                    let v_pd = rx_hex_value(&digits_pc);
                    let named_pe = ((((&rx_char_at(r_p0, &(&at_p5 + &Nat::from(2u32))) == &Text::lit("{")) && (&rx_char_at(r_p0, &j_pb) == &Text::lit("}"))) && (&digits_pc != &Text::lit(""))) && (&len_text(&digits_pc) <= &Nat::from(6u32))) && !(((&Nat::from(55296u32) <= &v_pd) && (&v_pd <= &Nat::from(57343u32))) || (&v_pd > &Nat::from(1114111u32)));
                    if named_pe {
                        i_p3 = &j_pb + &Nat::from(1u32);
                    } else {
                        d_o4 = rx_replacement_at(&at_p5, &rx_runicode());
                    }
                } else {
                    d_o4 = rx_replacement_at(&at_p5, &rx_rescape());
                }
            } else {
                i_p3 = &at_p5 + &len_text(&c_p6);
            }
        }
        this = (d_o4.clone(), i_p3.clone());
        this
    };
    d_of.clone()
}

/// The step machine of `RxReplacementRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RxReplacementRefusal: unbounded fn Text, Nat, (Text ==> Nat) -> ?RxDiag
/// ```
pub struct RxReplacementRefusal {
    pub r_p0: Text,
    pub groups_p1: Nat,
    pub names_p2: Map<Text, Nat>,
}

impl prism_rtl::Job<Option<RxDiag>> for RxReplacementRefusal {
    fn cycle(&self) -> prism_rtl::Turn<Option<RxDiag>> {
        let r_p0 = &self.r_p0;
        let groups_p1 = &self.groups_p1;
        let names_p2 = &self.names_p2;
        let mut this: (Option<RxDiag>, Nat) = (None, Nat::from(0u32));
        let mut i_p3: Nat = Nat::from(0u32);
        let mut d_o4: Option<RxDiag> = None;
        call_then(loop_job((d_o4, this, i_p3), {
            let groups_p1 = groups_p1.clone();
            let names_p2 = names_p2.clone();
            let r_p0 = r_p0.clone();
            move |(mut d_o4, mut this, mut i_p3): (Option<RxDiag>, (Option<RxDiag>, Nat), Nat)| if (&d_o4 == &None) && (&rx_char_at(&r_p0, &i_p3) != &Text::lit("")) {
                {
                    let at_p5 = i_p3.clone();
                    let c_p6 = rx_char_at(&r_p0, &at_p5);
                    let next_p7 = rx_char_at(&r_p0, &(&at_p5 + &Nat::from(1u32)));
                    if &c_p6 == &Text::lit("$") {
                        if &next_p7 == &Text::lit("$") {
                            i_p3 = &at_p5 + &Nat::from(2u32);
                        } else if rx_is_digit(&next_p7) {
                            let j_p8 = rx_span_end(&r_p0, &(&at_p5 + &Nat::from(1u32)), &{
                                let f = Rc::new(rx_is_digit);
                                Rc::new(move |a0: Text| {
                                    let f = f.clone();
                                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                            });
                            d_o4 = rx_group_number(&rx_slice(&r_p0, &(&at_p5 + &Nat::from(1u32)), &j_p8), &groups_p1, &at_p5);
                            i_p3 = j_p8.clone();
                        } else if &next_p7 == &Text::lit("{") {
                            match &rx_find(&r_p0, &(&at_p5 + &Nat::from(2u32)), &Text::lit("}")) {
                                None => {
                                    d_o4 = rx_replacement_at(&at_p5, &rx_rbraces());
                                }
                                Some(close_p9) => {
                                    let inner_pa = rx_slice(&r_p0, &(&at_p5 + &Nat::from(2u32)), close_p9);
                                    if (&inner_pa != &Text::lit("")) && rx_all(&inner_pa, &{
                                        let f = Rc::new(rx_is_digit);
                                        Rc::new(move |a0: Text| {
                                            let f = f.clone();
                                            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }) {
                                        d_o4 = rx_group_number(&inner_pa, &groups_p1, &at_p5);
                                    } else if rx_is_name(&inner_pa) {
                                        if &get(&names_p2, &inner_pa) == &None {
                                            d_o4 = rx_replacement_at(&at_p5, &rx_rno_name());
                                        }
                                    } else {
                                        d_o4 = rx_replacement_at(&at_p5, &rx_rbraces());
                                    }
                                    i_p3 = close_p9 + &Nat::from(1u32);
                                }
                            }
                        } else {
                            d_o4 = rx_replacement_at(&at_p5, &rx_rdollar());
                        }
                    } else if &c_p6 == &Text::lit("\\") {
                        if (((&next_p7 == &Text::lit("\\")) || (&next_p7 == &Text::lit("n"))) || (&next_p7 == &Text::lit("t"))) || (&next_p7 == &Text::lit("/")) {
                            i_p3 = &at_p5 + &Nat::from(2u32);
                        } else if &next_p7 == &Text::lit("u") {
                            let j_pb = rx_span_end(&r_p0, &(&at_p5 + &Nat::from(3u32)), &{
                                let f = Rc::new(rx_is_hex);
                                Rc::new(move |a0: Text| {
                                    let f = f.clone();
                                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                            });
                            let digits_pc = rx_slice(&r_p0, &(&at_p5 + &Nat::from(3u32)), &j_pb);
                            let v_pd = rx_hex_value(&digits_pc);
                            let named_pe = ((((&rx_char_at(&r_p0, &(&at_p5 + &Nat::from(2u32))) == &Text::lit("{")) && (&rx_char_at(&r_p0, &j_pb) == &Text::lit("}"))) && (&digits_pc != &Text::lit(""))) && (&len_text(&digits_pc) <= &Nat::from(6u32))) && !(((&Nat::from(55296u32) <= &v_pd) && (&v_pd <= &Nat::from(57343u32))) || (&v_pd > &Nat::from(1114111u32)));
                            if named_pe {
                                i_p3 = &j_pb + &Nat::from(1u32);
                            } else {
                                d_o4 = rx_replacement_at(&at_p5, &rx_runicode());
                            }
                        } else {
                            d_o4 = rx_replacement_at(&at_p5, &rx_rescape());
                        }
                    } else {
                        i_p3 = &at_p5 + &len_text(&c_p6);
                    }
                    Ok((d_o4, this, i_p3))
                }
            } else {
                Err((d_o4, this, i_p3))
            }
        }), move |(mut d_o4, mut this, mut i_p3): (Option<RxDiag>, (Option<RxDiag>, Nat), Nat)| {
            this = (d_o4.clone(), i_p3.clone());
            let (d_of, _) = this;
            prism_rtl::Turn::Finished(d_of.clone())
        })
    }
}

/// `Start RxReplacementRefusal, x`: what the function value is when passed to `@Run`.
pub fn start_rx_replacement_refusal(r_p0: Text, groups_p1: Nat, names_p2: Map<Text, Nat>) -> Rc<dyn prism_rtl::Job<Option<RxDiag>>> {
    Rc::new(RxReplacementRefusal { r_p0, groups_p1, names_p2 })
}

/// ```prism
/// ?RxReplacementAt: fn Nat, Text -> ?RxDiag
/// ```
pub fn rx_replacement_at(at_p0: &Nat, message_p1: &Text) -> Option<RxDiag> {
    Some(RxDiag { part: Text::lit("replacement"), at: at_p0.clone(), message: message_p1.clone() })
}

/// ```prism
/// ?RxGroupNumber: fn Text, Nat, Nat -> ?RxDiag
/// ```
pub fn rx_group_number(digits_p0: &Text, groups_p1: &Nat, at_p2: &Nat) -> Option<RxDiag> {
    if rx_leading_zero(digits_p0) {
        rx_replacement_at(at_p2, &rx_rzero())
    } else {
        if &or(&parse_nat_opt(digits_p0), &Nat::from(0u32)) > groups_p1 {
            rx_replacement_at(at_p2, &rx_rno_number())
        } else {
            None
        }
    }
}
