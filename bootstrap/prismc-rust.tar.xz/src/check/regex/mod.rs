//! The module `Check.Regex`, from `target/bootstrap/src/prismc/check/regex/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `RxCp`:
///
/// ```prism
/// type RxCp = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum RxCp {
    RxLit(Text),
    RxNum(Nat),
}

impl Show for RxCp {
    fn show(&self, p: &mut Printer) {
        match self {
            RxCp::RxLit(a0) => p.choice("RxLit", &[a0]),
            RxCp::RxNum(a0) => p.choice("RxNum", &[a0]),
        }
    }
}

impl ToPod for RxCp {
    fn to_pod(&self) -> Pod {
        match self {
            RxCp::RxLit(a0) => Pod::Choice("RxLit".into(), vec![a0.to_pod()]),
            RxCp::RxNum(a0) => Pod::Choice("RxNum".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for RxCp {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "RxLit" && a.len() == 1 => Ok(RxCp::RxLit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "RxNum" && a.len() == 1 => Ok(RxCp::RxNum(FromPod::from_pod(&a[0])?)),
            other => mismatch("a RxCp", other),
        }
    }
}

/// `RxDiag`:
///
/// ```prism
/// type RxDiag = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct RxDiag {
    pub part: Text,
    pub at: Nat,
    pub message: Text,
}

impl Show for RxDiag {
    fn show(&self, p: &mut Printer) {
        p.record("RxDiag", &[("part", &self.part), ("at", &self.at), ("message", &self.message)]);
    }
}

impl ToPod for RxDiag {
    fn to_pod(&self) -> Pod {
        Pod::record("RxDiag", vec![("part", self.part.to_pod()), ("at", self.at.to_pod()), ("message", self.message.to_pod())])
    }
}

impl FromPod for RxDiag {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RxDiag { part: FromPod::from_pod(field(p, "part")?)?, at: FromPod::from_pod(field(p, "at")?)?, message: FromPod::from_pod(field(p, "message")?)? })
    }
}

/// `RxLast`:
///
/// ```prism
/// type RxLast = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum RxLast {
    RxLastNothing,
    RxLastFlagGroup,
    RxLastAssertion,
    RxLastRepetition,
    RxLastAtom,
}

impl Show for RxLast {
    fn show(&self, p: &mut Printer) {
        match self {
            RxLast::RxLastNothing => p.choice("RxLastNothing", &[]),
            RxLast::RxLastFlagGroup => p.choice("RxLastFlagGroup", &[]),
            RxLast::RxLastAssertion => p.choice("RxLastAssertion", &[]),
            RxLast::RxLastRepetition => p.choice("RxLastRepetition", &[]),
            RxLast::RxLastAtom => p.choice("RxLastAtom", &[]),
        }
    }
}

impl ToPod for RxLast {
    fn to_pod(&self) -> Pod {
        match self {
            RxLast::RxLastNothing => Pod::Choice("RxLastNothing".into(), vec![]),
            RxLast::RxLastFlagGroup => Pod::Choice("RxLastFlagGroup".into(), vec![]),
            RxLast::RxLastAssertion => Pod::Choice("RxLastAssertion".into(), vec![]),
            RxLast::RxLastRepetition => Pod::Choice("RxLastRepetition".into(), vec![]),
            RxLast::RxLastAtom => Pod::Choice("RxLastAtom".into(), vec![]),
        }
    }
}

impl FromPod for RxLast {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "RxLastNothing" && a.len() == 0 => Ok(RxLast::RxLastNothing),
            Pod::Choice(c, a) if &**c == "RxLastFlagGroup" && a.len() == 0 => Ok(RxLast::RxLastFlagGroup),
            Pod::Choice(c, a) if &**c == "RxLastAssertion" && a.len() == 0 => Ok(RxLast::RxLastAssertion),
            Pod::Choice(c, a) if &**c == "RxLastRepetition" && a.len() == 0 => Ok(RxLast::RxLastRepetition),
            Pod::Choice(c, a) if &**c == "RxLastAtom" && a.len() == 0 => Ok(RxLast::RxLastAtom),
            other => mismatch("a RxLast", other),
        }
    }
}

/// `RxMeasure`:
///
/// ```prism
/// type RxMeasure = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct RxMeasure {
    pub depth: Nat,
    pub size: Nat,
    pub product: Nat,
}

impl Show for RxMeasure {
    fn show(&self, p: &mut Printer) {
        p.record("RxMeasure", &[("depth", &self.depth), ("size", &self.size), ("product", &self.product)]);
    }
}

impl ToPod for RxMeasure {
    fn to_pod(&self) -> Pod {
        Pod::record("RxMeasure", vec![("depth", self.depth.to_pod()), ("size", self.size.to_pod()), ("product", self.product.to_pod())])
    }
}

impl FromPod for RxMeasure {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RxMeasure { depth: FromPod::from_pod(field(p, "depth")?)?, size: FromPod::from_pod(field(p, "size")?)?, product: FromPod::from_pod(field(p, "product")?)? })
    }
}

/// `RxState`:
///
/// ```prism
/// type RxState = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct RxState {
    pub s: Text,
    pub i: Nat,
    pub open: Nat,
    pub groups: Nat,
    pub names: Map<Text, Nat>,
    pub err: Option<RxDiag>,
}

impl Show for RxState {
    fn show(&self, p: &mut Printer) {
        p.record("RxState", &[("s", &self.s), ("i", &self.i), ("open", &self.open), ("groups", &self.groups), ("names", &self.names), ("err", &self.err)]);
    }
}

impl ToPod for RxState {
    fn to_pod(&self) -> Pod {
        Pod::record("RxState", vec![("s", self.s.to_pod()), ("i", self.i.to_pod()), ("open", self.open.to_pod()), ("groups", self.groups.to_pod()), ("names", self.names.to_pod()), ("err", self.err.to_pod())])
    }
}

impl FromPod for RxState {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RxState { s: FromPod::from_pod(field(p, "s")?)?, i: FromPod::from_pod(field(p, "i")?)?, open: FromPod::from_pod(field(p, "open")?)?, groups: FromPod::from_pod(field(p, "groups")?)?, names: FromPod::from_pod(field(p, "names")?)?, err: FromPod::from_pod(field(p, "err")?)? })
    }
}

/// ```prism
/// let rxUnknownFlag
/// ```
pub fn rx_unknown_flag() -> Text {
    Text::lit("an unknown flag: the flags are i, m and s")
}

/// ```prism
/// let rxFlagTwice
/// ```
pub fn rx_flag_twice() -> Text {
    Text::lit("a flag written twice")
}

/// ```prism
/// let rxStrayBracket
/// ```
pub fn rx_stray_bracket() -> Text {
    Text::lit("a ] outside a class: a literal one is \\]")
}

/// ```prism
/// let rxStrayBrace
/// ```
pub fn rx_stray_brace() -> Text {
    Text::lit("a } outside a count: a literal one is \\}")
}

/// ```prism
/// let rxTrailingBackslash
/// ```
pub fn rx_trailing_backslash() -> Text {
    Text::lit("a \\ at the end of the pattern")
}

/// ```prism
/// let rxHexTwo
/// ```
pub fn rx_hex_two() -> Text {
    Text::lit("a \\x escape needs two hex digits or braces")
}

/// ```prism
/// let rxHexBraces
/// ```
pub fn rx_hex_braces() -> Text {
    Text::lit("a \\x{...} escape needs one to six hex digits")
}

/// ```prism
/// let rxHexNoChar
/// ```
pub fn rx_hex_no_char() -> Text {
    Text::lit("a \\x escape names no character: a surrogate or past U+10FFFF")
}

/// ```prism
/// let rxWordBraces
/// ```
pub fn rx_word_braces() -> Text {
    Text::lit("\\b{...} is Rust\'s only: write \\b")
}

/// ```prism
/// let rxAngle
/// ```
pub fn rx_angle() -> Text {
    Text::lit("\\< and \\> are Rust\'s only: write \\b")
}

/// ```prism
/// let rxBackreference
/// ```
pub fn rx_backreference() -> Text {
    Text::lit("a backreference: refused so that every match is linear in its text")
}

/// ```prism
/// let rxOctal
/// ```
pub fn rx_octal() -> Text {
    Text::lit("an octal escape is RE2\'s only: write \\x")
}

/// ```prism
/// let rxQuote
/// ```
pub fn rx_quote() -> Text {
    Text::lit("\\Q...\\E is RE2\'s only: escape each character")
}

/// ```prism
/// let rxOneByte
/// ```
pub fn rx_one_byte() -> Text {
    Text::lit("\\C, one byte, is RE2\'s only")
}

/// ```prism
/// let rxUnknownEscape
/// ```
pub fn rx_unknown_escape() -> Text {
    Text::lit("an unknown escape")
}

/// ```prism
/// let rxPropertyName
/// ```
pub fn rx_property_name() -> Text {
    Text::lit("a \\p escape needs a property name")
}

/// ```prism
/// let rxPropertyOpen
/// ```
pub fn rx_property_open() -> Text {
    Text::lit("a \\p{ that is never closed")
}

/// ```prism
/// let rxPropertyNegated
/// ```
pub fn rx_property_negated() -> Text {
    Text::lit("a negated property is written \\P{...}")
}

/// ```prism
/// let rxPropertyRefused
/// ```
pub fn rx_property_refused() -> Text {
    Text::lit("the property is refused: RE2 and Rust disagree on C, Cn, Cs and LC")
}

/// ```prism
/// let rxPropertyUnknown
/// ```
pub fn rx_property_unknown() -> Text {
    Text::lit("an unknown property: general categories by short name, scripts and Any")
}

/// ```prism
/// let rxClassOpen
/// ```
pub fn rx_class_open() -> Text {
    Text::lit("a class opened here is never closed")
}

/// ```prism
/// let rxClassFirstBracket
/// ```
pub fn rx_class_first_bracket() -> Text {
    Text::lit("a ] first in a class: write \\]")
}

/// ```prism
/// let rxClassNested
/// ```
pub fn rx_class_nested() -> Text {
    Text::lit("a [ inside a class: write \\[ (nested classes are Rust\'s only)")
}

/// ```prism
/// let rxClassAsciiUnknown
/// ```
pub fn rx_class_ascii_unknown() -> Text {
    Text::lit("an unknown ASCII class")
}

/// ```prism
/// let rxClassSetOperation
/// ```
pub fn rx_class_set_operation() -> Text {
    Text::lit("&&, ~~ and -- in a class are Rust\'s set operations: escape them")
}

/// ```prism
/// let rxClassDash
/// ```
pub fn rx_class_dash() -> Text {
    Text::lit("a - in a class that is neither a range nor first or last: write \\-")
}

/// ```prism
/// let rxClassOrder
/// ```
pub fn rx_class_order() -> Text {
    Text::lit("a range whose ends are out of order")
}

/// ```prism
/// let rxClassRangeSet
/// ```
pub fn rx_class_range_set() -> Text {
    Text::lit("a range end that is a class")
}

/// ```prism
/// let rxClassNegatedUnderI
/// ```
pub fn rx_class_negated_under_i() -> Text {
    Text::lit("a negated class inside a class under i: write it outside the class")
}

/// ```prism
/// let rxClassEscape
/// ```
pub fn rx_class_escape() -> Text {
    Text::lit("an escape that a class cannot hold")
}

/// ```prism
/// let rxLookaround
/// ```
pub fn rx_lookaround() -> Text {
    Text::lit("a lookaround: refused so that every match is linear in its text")
}

/// ```prism
/// let rxUnknownGroup
/// ```
pub fn rx_unknown_group() -> Text {
    Text::lit("an unknown group: the groups are (re), (?:re), (?<name>re), (?P<name>re) and the flag groups")
}

/// ```prism
/// let rxNameShape
/// ```
pub fn rx_name_shape() -> Text {
    Text::lit("a group name is a lowercase value name, [a-z_][a-z0-9_]*")
}

/// ```prism
/// let rxNameOpen
/// ```
pub fn rx_name_open() -> Text {
    Text::lit("a group name that is never closed")
}

/// ```prism
/// let rxNameTwice
/// ```
pub fn rx_name_twice() -> Text {
    Text::lit("a group name used twice")
}

/// ```prism
/// let rxGroupOpen
/// ```
pub fn rx_group_open() -> Text {
    Text::lit("a group opened here is never closed")
}

/// ```prism
/// let rxGroupClose
/// ```
pub fn rx_group_close() -> Text {
    Text::lit("a ) that closes no group")
}

/// ```prism
/// let rxFlagsEmpty
/// ```
pub fn rx_flags_empty() -> Text {
    Text::lit("an empty flag group")
}

/// ```prism
/// let rxFlagsSecondDash
/// ```
pub fn rx_flags_second_dash() -> Text {
    Text::lit("a second - in a flag group")
}

/// ```prism
/// let rxFlagsDash
/// ```
pub fn rx_flags_dash() -> Text {
    Text::lit("a - that turns off no flag")
}

/// ```prism
/// let rxBrace
/// ```
pub fn rx_brace() -> Text {
    Text::lit("a brace that opens no count: a literal one is \\{")
}

/// ```prism
/// let rxCountZero
/// ```
pub fn rx_count_zero() -> Text {
    Text::lit("a count with a leading zero")
}

/// ```prism
/// let rxCountBound
/// ```
pub fn rx_count_bound() -> Text {
    Text::lit("a count above 1000")
}

/// ```prism
/// let rxCountOrder
/// ```
pub fn rx_count_order() -> Text {
    Text::lit("a count whose minimum exceeds its maximum")
}

/// ```prism
/// let rxNothingToRepeat
/// ```
pub fn rx_nothing_to_repeat() -> Text {
    Text::lit("a repetition with nothing to repeat")
}

/// ```prism
/// let rxRepeatRepeat
/// ```
pub fn rx_repeat_repeat() -> Text {
    Text::lit("a repetition of a repetition: write (?:a*)* to say it")
}

/// ```prism
/// let rxRepeatAssertion
/// ```
pub fn rx_repeat_assertion() -> Text {
    Text::lit("a repetition of an assertion")
}

/// ```prism
/// let rxProduct
/// ```
pub fn rx_product() -> Text {
    Text::lit("nested counts multiplying past 1000")
}

/// ```prism
/// let rxNesting
/// ```
pub fn rx_nesting() -> Text {
    Text::lit("groups and repetitions nested more than 100 deep")
}

/// ```prism
/// let rxSize
/// ```
pub fn rx_size() -> Text {
    Text::lit("the pattern expands past 10,000 atoms")
}

/// ```prism
/// let rxRZero
/// ```
pub fn rx_rzero() -> Text {
    Text::lit("a group number with a leading zero")
}

/// ```prism
/// let rxRBraces
/// ```
pub fn rx_rbraces() -> Text {
    Text::lit("a ${...} that is neither a group number nor a group name")
}

/// ```prism
/// let rxRDollar
/// ```
pub fn rx_rdollar() -> Text {
    Text::lit("a $ that is not $n, ${n}, ${name} or $$")
}

/// ```prism
/// let rxRNoNumber
/// ```
pub fn rx_rno_number() -> Text {
    Text::lit("the pattern has no group of that number")
}

/// ```prism
/// let rxRNoName
/// ```
pub fn rx_rno_name() -> Text {
    Text::lit("the pattern has no group of that name")
}

/// ```prism
/// let rxRUnicode
/// ```
pub fn rx_runicode() -> Text {
    Text::lit("a \\u{...} escape needs one to six hex digits naming a character")
}

/// ```prism
/// let rxREscape
/// ```
pub fn rx_rescape() -> Text {
    Text::lit("an unknown escape in a replacement: the escapes are \\\\, \\n, \\t, \\u{hex} and \\/")
}

/// ```prism
/// let rxCategories
/// ```
pub fn rx_categories() -> Array<Text> {
    Array::from(vec![Text::lit("Cc"), Text::lit("Cf"), Text::lit("Co"), Text::lit("L"), Text::lit("Ll"), Text::lit("Lm"), Text::lit("Lo"), Text::lit("Lt"), Text::lit("Lu"), Text::lit("M"), Text::lit("Mc"), Text::lit("Me"), Text::lit("Mn"), Text::lit("N"), Text::lit("Nd"), Text::lit("Nl"), Text::lit("No"), Text::lit("P"), Text::lit("Pc"), Text::lit("Pd"), Text::lit("Pe"), Text::lit("Pf"), Text::lit("Pi"), Text::lit("Po"), Text::lit("Ps"), Text::lit("S"), Text::lit("Sc"), Text::lit("Sk"), Text::lit("Sm"), Text::lit("So"), Text::lit("Z"), Text::lit("Zl"), Text::lit("Zp"), Text::lit("Zs")])
}

/// ```prism
/// let rxScripts
/// ```
pub fn rx_scripts() -> Array<Text> {
    Array::from(vec![Text::lit("Adlam"), Text::lit("Ahom"), Text::lit("Anatolian_Hieroglyphs"), Text::lit("Arabic"), Text::lit("Armenian"), Text::lit("Avestan"), Text::lit("Balinese"), Text::lit("Bamum"), Text::lit("Bassa_Vah"), Text::lit("Batak"), Text::lit("Bengali"), Text::lit("Bhaiksuki"), Text::lit("Bopomofo"), Text::lit("Brahmi"), Text::lit("Braille"), Text::lit("Buginese"), Text::lit("Buhid"), Text::lit("Canadian_Aboriginal"), Text::lit("Carian"), Text::lit("Caucasian_Albanian"), Text::lit("Chakma"), Text::lit("Cham"), Text::lit("Cherokee"), Text::lit("Chorasmian"), Text::lit("Common"), Text::lit("Coptic"), Text::lit("Cuneiform"), Text::lit("Cypriot"), Text::lit("Cypro_Minoan"), Text::lit("Cyrillic"), Text::lit("Deseret"), Text::lit("Devanagari"), Text::lit("Dives_Akuru"), Text::lit("Dogra"), Text::lit("Duployan"), Text::lit("Egyptian_Hieroglyphs"), Text::lit("Elbasan"), Text::lit("Elymaic"), Text::lit("Ethiopic"), Text::lit("Georgian"), Text::lit("Glagolitic"), Text::lit("Gothic"), Text::lit("Grantha"), Text::lit("Greek"), Text::lit("Gujarati"), Text::lit("Gunjala_Gondi"), Text::lit("Gurmukhi"), Text::lit("Han"), Text::lit("Hangul"), Text::lit("Hanifi_Rohingya"), Text::lit("Hanunoo"), Text::lit("Hatran"), Text::lit("Hebrew"), Text::lit("Hiragana"), Text::lit("Imperial_Aramaic"), Text::lit("Inherited"), Text::lit("Inscriptional_Pahlavi"), Text::lit("Inscriptional_Parthian"), Text::lit("Javanese"), Text::lit("Kaithi"), Text::lit("Kannada"), Text::lit("Katakana"), Text::lit("Kawi"), Text::lit("Kayah_Li"), Text::lit("Kharoshthi"), Text::lit("Khitan_Small_Script"), Text::lit("Khmer"), Text::lit("Khojki"), Text::lit("Khudawadi"), Text::lit("Lao"), Text::lit("Latin"), Text::lit("Lepcha"), Text::lit("Limbu"), Text::lit("Linear_A"), Text::lit("Linear_B"), Text::lit("Lisu"), Text::lit("Lycian"), Text::lit("Lydian"), Text::lit("Mahajani"), Text::lit("Makasar"), Text::lit("Malayalam"), Text::lit("Mandaic"), Text::lit("Manichaean"), Text::lit("Marchen"), Text::lit("Masaram_Gondi"), Text::lit("Medefaidrin"), Text::lit("Meetei_Mayek"), Text::lit("Mende_Kikakui"), Text::lit("Meroitic_Cursive"), Text::lit("Meroitic_Hieroglyphs"), Text::lit("Miao"), Text::lit("Modi"), Text::lit("Mongolian"), Text::lit("Mro"), Text::lit("Multani"), Text::lit("Myanmar"), Text::lit("Nabataean"), Text::lit("Nag_Mundari"), Text::lit("Nandinagari"), Text::lit("New_Tai_Lue"), Text::lit("Newa"), Text::lit("Nko"), Text::lit("Nushu"), Text::lit("Nyiakeng_Puachue_Hmong"), Text::lit("Ogham"), Text::lit("Ol_Chiki"), Text::lit("Old_Hungarian"), Text::lit("Old_Italic"), Text::lit("Old_North_Arabian"), Text::lit("Old_Permic"), Text::lit("Old_Persian"), Text::lit("Old_Sogdian"), Text::lit("Old_South_Arabian"), Text::lit("Old_Turkic"), Text::lit("Old_Uyghur"), Text::lit("Oriya"), Text::lit("Osage"), Text::lit("Osmanya"), Text::lit("Pahawh_Hmong"), Text::lit("Palmyrene"), Text::lit("Pau_Cin_Hau"), Text::lit("Phags_Pa"), Text::lit("Phoenician"), Text::lit("Psalter_Pahlavi"), Text::lit("Rejang"), Text::lit("Runic"), Text::lit("Samaritan"), Text::lit("Saurashtra"), Text::lit("Sharada"), Text::lit("Shavian"), Text::lit("Siddham"), Text::lit("SignWriting"), Text::lit("Sinhala"), Text::lit("Sogdian"), Text::lit("Sora_Sompeng"), Text::lit("Soyombo"), Text::lit("Sundanese"), Text::lit("Syloti_Nagri"), Text::lit("Syriac"), Text::lit("Tagalog"), Text::lit("Tagbanwa"), Text::lit("Tai_Le"), Text::lit("Tai_Tham"), Text::lit("Tai_Viet"), Text::lit("Takri"), Text::lit("Tamil"), Text::lit("Tangsa"), Text::lit("Tangut"), Text::lit("Telugu"), Text::lit("Thaana"), Text::lit("Thai"), Text::lit("Tibetan"), Text::lit("Tifinagh"), Text::lit("Tirhuta"), Text::lit("Toto"), Text::lit("Ugaritic"), Text::lit("Vai"), Text::lit("Vithkuqi"), Text::lit("Wancho"), Text::lit("Warang_Citi"), Text::lit("Yezidi"), Text::lit("Yi"), Text::lit("Zanabazar_Square")])
}

/// ```prism
/// let rxProperties
/// ```
pub fn rx_properties() -> Map<Text, bool> {
    map(&each(&push(&append(&rx_categories(), &rx_scripts()), &Text::lit("Any")), &(|n: &Text| (n.clone(), true))))
}

/// ```prism
/// let rxAsciiClasses
/// ```
pub fn rx_ascii_classes() -> Map<Text, bool> {
    map(&each(&Array::from(vec![Text::lit("alnum"), Text::lit("alpha"), Text::lit("ascii"), Text::lit("blank"), Text::lit("cntrl"), Text::lit("digit"), Text::lit("graph"), Text::lit("lower"), Text::lit("print"), Text::lit("punct"), Text::lit("space"), Text::lit("upper"), Text::lit("word"), Text::lit("xdigit")]), &(|n: &Text| (n.clone(), true))))
}

/// ```prism
/// let rxAscii
/// ```
pub fn rx_ascii() -> Text {
    Text::lit("\0\t\n\r !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")
}

/// ```prism
/// let rxPunctuation
/// ```
pub fn rx_punctuation() -> Text {
    Text::lit("!\"#$%&\'()*+,-./:;=?@[\\]^_`{|}~")
}

/// ```prism
/// let rxNone
/// ```
pub fn rx_none() -> RxMeasure {
    RxMeasure { depth: Nat::from(0u32), size: Nat::from(0u32), product: Nat::from(0u32) }
}

/// ```prism
/// let rxAtom
/// ```
pub fn rx_atom() -> RxMeasure {
    RxMeasure { depth: Nat::from(0u32), size: Nat::from(1u32), product: Nat::from(1u32) }
}

/// ```prism
/// RxThen: fn RxMeasure, RxMeasure -> RxMeasure
/// ```
pub fn rx_then(a: &RxMeasure, b: &RxMeasure) -> RxMeasure {
    RxMeasure { depth: max(&a.depth, &b.depth), size: &a.size + &b.size, product: max(&a.product, &b.product) }
}

/// ```prism
/// RxBad: fn RxState -> Bool
/// ```
pub fn rx_bad(st: &RxState) -> bool {
    &st.err != &None
}

/// ```prism
/// RxFail: fn RxState, Nat, Text -> RxState
/// ```
pub fn rx_fail(st: &RxState, at_: &Nat, message: &Text) -> RxState {
    if rx_bad(st) {
        st.clone()
    } else {
        RxState { s: st.s.clone(), i: st.i.clone(), open: st.open.clone(), groups: st.groups.clone(), names: st.names.clone(), err: Some(RxDiag { part: Text::lit("pattern"), at: at_.clone(), message: message.clone() }) }
    }
}

/// ```prism
/// RxGo: fn RxState, Nat -> RxState
/// ```
pub fn rx_go(st: &RxState, n: &Nat) -> RxState {
    let mut this: RxState = st.clone();
    this.i = n.clone();
    this
}

/// ```prism
/// RxPeek: fn RxState -> Text
/// ```
pub fn rx_peek(st: &RxState) -> Text {
    rx_char_at(&st.s, &st.i)
}

/// ```prism
/// RxCharAt: fn Text, Nat -> Text
/// ```
pub fn rx_char_at(t: &Text, n: &Nat) -> Text {
    match cursor_at(t, n) {
        Some(c) => match step(&front(&after(&c))) {
            Some((_, one)) => before(&one),
            None => Text::lit(""),
        },
        None => Text::lit(""),
    }
}

/// ```prism
/// RxSlice: fn Text, Nat, Nat -> Text
/// ```
pub fn rx_slice(t: &Text, a: &Nat, b: &Nat) -> Text {
    match cursor_at(t, b) {
        Some(cb) => match cursor_at(&before(&cb), a) {
            Some(ca) => after(&ca),
            None => Text::lit(""),
        },
        None => Text::lit(""),
    }
}

/// ```prism
/// ?RxFind: fn Text, Nat, Text -> ?Nat
/// ```
pub fn rx_find(t: &Text, from: &Nat, x: &Text) -> Option<Nat> {
    match cursor_at(t, from) {
        None => None,
        Some(c0) => {
            let (found_opt, _) = {
                let mut this: (Option<Nat>, Cursor) = (None, c0.clone());
                let mut c: Cursor = c0.clone();
                let mut found_opt: Option<Nat> = None;
                while let Some((_, next_)) = step(&c) {
                    if !(&found_opt == &None) {
                        break;
                    }
                    if &rx_slice(t, &at(&c), &at(&next_)) == x {
                        found_opt = Some(at(&c));
                    }
                    c = next_.clone();
                }
                this = (found_opt.clone(), c.clone());
                this
            };
            found_opt.clone()
        },
    }
}

/// ```prism
/// RxIn: fn Text, Text -> Bool
/// ```
pub fn rx_in(set: &Text, c: &Text) -> bool {
    (c != &Text::lit("")) && (&rx_find(set, &Nat::from(0u32), c) != &None)
}

/// ```prism
/// RxIsDigit: fn Text -> Bool
/// ```
pub fn rx_is_digit(c: &Text) -> bool {
    ((&Text::lit("0") <= c) && (c <= &Text::lit("9"))) && (&len_text(c) == &Nat::from(1u32))
}

/// ```prism
/// RxIsLetter: fn Text -> Bool
/// ```
pub fn rx_is_letter(c: &Text) -> bool {
    ((&Text::lit("a") <= c) && (c <= &Text::lit("z"))) || ((&Text::lit("A") <= c) && (c <= &Text::lit("Z")))
}

/// ```prism
/// RxIsHex: fn Text -> Bool
/// ```
pub fn rx_is_hex(c: &Text) -> bool {
    (rx_is_digit(c) || ((&Text::lit("a") <= c) && (c <= &Text::lit("f")))) || ((&Text::lit("A") <= c) && (c <= &Text::lit("F")))
}

/// ```prism
/// RxIsName: fn Text -> Bool
/// ```
pub fn rx_is_name(t: &Text) -> bool {
    let first_ = rx_char_at(t, &Nat::from(0u32));
    ((t != &Text::lit("")) && (((&Text::lit("a") <= &first_) && (&first_ <= &Text::lit("z"))) || (&first_ == &Text::lit("_")))) && rx_all(t, &(Rc::new(move |p0: Text| once_job(move || {
        let c = p0;
        prism_rtl::Turn::Finished((((&Text::lit("a") <= &c) && (&c <= &Text::lit("z"))) || rx_is_digit(&c)) || (&c == &Text::lit("_")))
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// ```prism
/// RxAll: fn Text, (fn Text -> Bool) -> Bool
/// ```
pub fn rx_all(t: &Text, p__fn: &Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> bool {
    let mut this: bool = true;
    let mut c: Cursor = front(t);
    while let Some((_, next_)) = step(&c) {
        if !run_to_end(p__fn(rx_slice(t, &at(&c), &at(&next_)))) {
            this = false;
        }
        c = next_.clone();
    }
    this
}

/// The step machine of `RxAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxAll: fn Text, (fn Text -> Bool) -> Bool
/// ```
pub struct RxAll {
    pub t: Text,
    pub p__fn: Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>,
}

impl prism_rtl::Job<bool> for RxAll {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        let p__fn = &self.p__fn;
        prism_rtl::Turn::Finished({
            let mut this: bool = true;
            let mut c: Cursor = front(t);
            while let Some((_, next_)) = step(&c) {
                if !run_to_end(p__fn(rx_slice(t, &at(&c), &at(&next_)))) {
                    this = false;
                }
                c = next_.clone();
            }
            this
        })
    }
}

/// `Start RxAll, x`: what the function value is when passed to `@Run`.
pub fn start_rx_all(t: Text, p__fn: Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(RxAll { t, p__fn })
}

/// ```prism
/// RxSpanEnd: unbounded fn Text, Nat, (fn Text -> Bool) -> Nat
/// ```
pub fn rx_span_end(t: &Text, at_: &Nat, p__fn: &Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> Nat {
    let mut this: Nat = at_.clone();
    while run_to_end(p__fn(rx_char_at(t, &this))) {
        this = &this + &Nat::from(1u32);
    }
    this
}

/// The step machine of `RxSpanEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxSpanEnd: unbounded fn Text, Nat, (fn Text -> Bool) -> Nat
/// ```
pub struct RxSpanEnd {
    pub t: Text,
    pub at_: Nat,
    pub p__fn: Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>,
}

impl prism_rtl::Job<Nat> for RxSpanEnd {
    fn cycle(&self) -> prism_rtl::Turn<Nat> {
        let t = &self.t;
        let at_ = &self.at_;
        let p__fn = &self.p__fn;
        let mut this: Nat = at_.clone();
        call_then(loop_job((this,), {
            let p__fn = p__fn.clone();
            let t = t.clone();
            move |(mut this,): (Nat,)| if run_to_end((&p__fn)(rx_char_at(&t, &this))) {
                {
                    this = &this + &Nat::from(1u32);
                    Ok((this,))
                }
            } else {
                Err((this,))
            }
        }), move |(mut this,): (Nat,)| prism_rtl::Turn::Finished(this))
    }
}

/// `Start RxSpanEnd, x`: what the function value is when passed to `@Run`.
pub fn start_rx_span_end(t: Text, at_: Nat, p__fn: Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> Rc<dyn prism_rtl::Job<Nat>> {
    Rc::new(RxSpanEnd { t, at_, p__fn })
}

/// ```prism
/// RxHexValue: fn Text -> Nat
/// ```
pub fn rx_hex_value(t: &Text) -> Nat {
    let mut this: Nat = Nat::from(0u32);
    let mut c: Cursor = front(t);
    while let Some((_, next_)) = step(&c) {
        let d = rx_slice(t, &at(&c), &at(&next_));
        this = &(&this * &Nat::from(16u32)) + &or(&rx_find(&Text::lit("0123456789abcdef"), &Nat::from(0u32), &crate::prelude::lower(&d)), &Nat::from(0u32));
        c = next_.clone();
    }
    this
}

/// ```prism
/// RxCpOf: fn Nat -> RxCp
/// ```
pub fn rx_cp_of(v_: &Nat) -> RxCp {
    if v_ < &Nat::from(128u32) {
        RxCp::RxLit(rx_char_at(&rx_ascii(), v_))
    } else {
        RxCp::RxNum(v_.clone())
    }
}

/// ```prism
/// RxWidth: fn Nat -> Nat
/// ```
pub fn rx_width(v_: &Nat) -> Nat {
    if v_ < &Nat::from(128u32) {
        Nat::from(1u32)
    } else {
        if v_ < &Nat::from(2048u32) {
            Nat::from(2u32)
        } else {
            if v_ < &Nat::from(65536u32) { Nat::from(3u32) } else { Nat::from(4u32) }
        }
    }
}

/// ```prism
/// RxPast: fn RxCp, RxCp -> Bool
/// ```
pub fn rx_past(rx_cp0: &RxCp, rx_cp1: &RxCp) -> bool {
    match (rx_cp0, rx_cp1) {
        (RxCp::RxLit(a), RxCp::RxLit(b)) => a > b,
        (RxCp::RxNum(a), RxCp::RxNum(b)) => a > b,
        (RxCp::RxLit(a), RxCp::RxNum(b)) => if &len_text(a) != &rx_width(b) {
            &len_text(a) > &rx_width(b)
        } else {
            !rx_in_range(a, &Nat::from(0u32), b)
        },
        (RxCp::RxNum(a), RxCp::RxLit(b)) => if &rx_width(a) != &len_text(b) {
            &rx_width(a) > &len_text(b)
        } else {
            !rx_in_range(b, a, &Nat::from(1114111u32))
        },
    }
}

/// ```prism
/// RxInRange: fn Text, Nat, Nat -> Bool
/// ```
pub fn rx_in_range(c: &Text, lo: &Nat, hi: &Nat) -> bool {
    match crate::prelude::regex(&Text::from(format!("[\\x{{{}}}-\\x{{{}}}]", &rx_hex_text(lo), &rx_hex_text(hi)))) {
        Some(r) => &find(&r, c) != &None,
        None => false,
    }
}

/// ```prism
/// RxHexText: fn Nat -> Text
/// ```
pub fn rx_hex_text(n: &Nat) -> Text {
    let mut this: Text = Text::lit("");
    let mut k: Nat = n.clone();
    let mut fuel: Nat = Nat::from(6u32);
    while let Some(left) = (&fuel).checked_sub(&Nat::from(1u32)) {
        fuel = left.clone();
        this = Text::from(format!("{}{}", &rx_char_at(&Text::lit("0123456789abcdef"), &or(&mod_(&k, &Nat::from(16u32)), &Nat::from(0u32))), &this));
        k = or(&div(&k, &Nat::from(16u32)), &Nat::from(0u32));
    }
    this
}

/// ```prism
/// ?RegexRefusal: unbounded fn Text, Text, ?Text -> ?RxDiag
/// ```
pub fn regex_refusal(pattern: &Text, flags: &Text, replacement_opt: &Option<Text>) -> Option<RxDiag> {
    match rx_flags_refusal(flags) {
        Some(d) => Some(d),
        None => {
            let st0 = RxState { s: pattern.clone(), i: Nat::from(0u32), open: Nat::from(0u32), groups: Nat::from(0u32), names: Map::new(), err: None };
            let (m, st) = rx_alternation(&st0, &(&rx_find(flags, &Nat::from(0u32), &Text::lit("i")) != &None));
            match &st.err {
                Some(d) => Some(d.clone()),
                None => if &st.i < &len_text(pattern) {
                    Some(RxDiag { part: Text::lit("pattern"), at: st.i.clone(), message: rx_group_close() })
                } else {
                    if &m.depth > &Nat::from(100u32) {
                        Some(RxDiag { part: Text::lit("pattern"), at: Nat::from(0u32), message: rx_nesting() })
                    } else {
                        if &m.size > &Nat::from(10000u32) {
                            Some(RxDiag { part: Text::lit("pattern"), at: Nat::from(0u32), message: rx_size() })
                        } else {
                            match replacement_opt {
                                None => None,
                                Some(r) => rx_replacement_refusal(r, &st.groups, &st.names),
                            }
                        }
                    }
                },
            }
        },
    }
}

/// The step machine of `RegexRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RegexRefusal: unbounded fn Text, Text, ?Text -> ?RxDiag
/// ```
pub struct RegexRefusal {
    pub pattern: Text,
    pub flags: Text,
    pub replacement_opt: Option<Text>,
}

impl prism_rtl::Job<Option<RxDiag>> for RegexRefusal {
    fn cycle(&self) -> prism_rtl::Turn<Option<RxDiag>> {
        let pattern = &self.pattern;
        let flags = &self.flags;
        let replacement_opt = &self.replacement_opt;
        match rx_flags_refusal(flags) {
            Some(d) => prism_rtl::Turn::Finished(Some(d.clone())),
            None => {
                let st0 = RxState { s: pattern.clone(), i: Nat::from(0u32), open: Nat::from(0u32), groups: Nat::from(0u32), names: Map::new(), err: None };
                let replacement_opt = replacement_opt.clone();
                let flags = flags.clone();
                let pattern = pattern.clone();
                call_then(start_rx_alternation(st0.clone(), &rx_find(&flags, &Nat::from(0u32), &Text::lit("i")) != &None), move |rx_alternation_15542: (RxMeasure, RxState)| {
                    let (m, st) = rx_alternation_15542;
                    match &st.err {
                        Some(d) => prism_rtl::Turn::Finished(Some(d.clone())),
                        None => if &st.i < &len_text(&pattern) {
                            prism_rtl::Turn::Finished(Some(RxDiag { part: Text::lit("pattern"), at: st.i.clone(), message: rx_group_close() }))
                        } else {
                            if &m.depth > &Nat::from(100u32) {
                                prism_rtl::Turn::Finished(Some(RxDiag { part: Text::lit("pattern"), at: Nat::from(0u32), message: rx_nesting() }))
                            } else {
                                if &m.size > &Nat::from(10000u32) {
                                    prism_rtl::Turn::Finished(Some(RxDiag { part: Text::lit("pattern"), at: Nat::from(0u32), message: rx_size() }))
                                } else {
                                    match &replacement_opt {
                                        None => prism_rtl::Turn::Finished(None),
                                        Some(r) => prism_rtl::Turn::More(Rc::new(RxReplacementRefusal { r: r.clone(), groups: st.groups.clone(), names: st.names.clone() })),
                                    }
                                }
                            }
                        },
                    }
                })
            },
        }
    }
}

/// `Start RegexRefusal, x`: what the function value is when passed to `@Run`.
pub fn start_regex_refusal(pattern: Text, flags: Text, replacement_opt: Option<Text>) -> Rc<dyn prism_rtl::Job<Option<RxDiag>>> {
    Rc::new(RegexRefusal { pattern, flags, replacement_opt })
}

/// ```prism
/// ?RxFlagsRefusal: fn Text -> ?RxDiag
/// ```
pub fn rx_flags_refusal(flags: &Text) -> Option<RxDiag> {
    let (d_opt, _) = {
        let mut this: (Option<RxDiag>, Text) = (None, Text::lit(""));
        let mut c: Cursor = front(flags);
        let mut d_opt: Option<RxDiag> = None;
        let mut seen: Text = Text::lit("");
        while let Some((_, next_)) = step(&c) {
            if !(&d_opt == &None) {
                break;
            }
            let ch = rx_slice(flags, &at(&c), &at(&next_));
            if !(((&ch == &Text::lit("i")) || (&ch == &Text::lit("m"))) || (&ch == &Text::lit("s"))) {
                d_opt = Some(RxDiag { part: Text::lit("flags"), at: at(&c), message: rx_unknown_flag() });
            } else if rx_in(&seen, &ch) {
                d_opt = Some(RxDiag { part: Text::lit("flags"), at: at(&c), message: rx_flag_twice() });
            } else {
                seen = Text::from(format!("{}{}", &seen, &ch));
            }
            c = next_.clone();
        }
        this = (d_opt.clone(), seen.clone());
        this
    };
    d_opt.clone()
}

/// ```prism
/// RxAlternation: unbounded fn RxState, Bool -> ((RxMeasure, RxState))
/// ```
pub fn rx_alternation(st0: &RxState, fi0: &bool) -> (RxMeasure, RxState) {
    let (m0, fi1, st1) = rx_sequence(st0, fi0);
    let mut this: (RxMeasure, RxState) = (m0.clone(), st1.clone());
    let mut m: RxMeasure = m0.clone();
    let mut fi: bool = fi1;
    let mut st: RxState = st1.clone();
    while !rx_bad(&st) && (&rx_peek(&st) == &Text::lit("|")) {
        let (m2, fi2, st2) = rx_sequence(&rx_go(&st, &(&st.i + &Nat::from(1u32))), &fi);
        m = rx_then(&m, &m2);
        fi = fi2;
        st = st2.clone();
    }
    this = (m.clone(), st.clone());
    this
}

/// The step machine of `RxAlternation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxAlternation: unbounded fn RxState, Bool -> ((RxMeasure, RxState))
/// ```
pub struct RxAlternation {
    pub st0: RxState,
    pub fi0: bool,
}

impl prism_rtl::Job<(RxMeasure, RxState)> for RxAlternation {
    fn cycle(&self) -> prism_rtl::Turn<(RxMeasure, RxState)> {
        let st0 = &self.st0;
        let fi0 = &self.fi0;
        let fi0 = *fi0;
        let st0 = st0.clone();
        call_then(start_rx_sequence(st0.clone(), fi0), move |rx_sequence_17135: (RxMeasure, bool, RxState)| {
            let (m0, fi1, st1) = rx_sequence_17135;
            let mut this: (RxMeasure, RxState) = (m0.clone(), st1.clone());
            let mut m: RxMeasure = m0.clone();
            let mut fi: bool = fi1;
            let mut st: RxState = st1.clone();
            call_then(loop_job((this, fi, m, st), move |(mut this, mut fi, mut m, mut st): ((RxMeasure, RxState), bool, RxMeasure, RxState)| if !rx_bad(&st) && (&rx_peek(&st) == &Text::lit("|")) {
                {
                    let (m2, fi2, st2) = rx_sequence(&rx_go(&st, &(&st.i + &Nat::from(1u32))), &fi);
                    m = rx_then(&m, &m2);
                    fi = fi2;
                    st = st2.clone();
                    Ok((this, fi, m, st))
                }
            } else {
                Err((this, fi, m, st))
            }), move |(mut this, mut fi, mut m, mut st): ((RxMeasure, RxState), bool, RxMeasure, RxState)| {
                this = (m.clone(), st.clone());
                prism_rtl::Turn::Finished(this)
            })
        })
    }
}

/// `Start RxAlternation, x`: what the function value is when passed to `@Run`.
pub fn start_rx_alternation(st0: RxState, fi0: bool) -> Rc<dyn prism_rtl::Job<(RxMeasure, RxState)>> {
    Rc::new(RxAlternation { st0, fi0 })
}

/// ```prism
/// RxSequence: unbounded fn RxState, Bool -> ((RxMeasure, Bool, RxState))
/// ```
pub fn rx_sequence(st0: &RxState, fi0: &bool) -> (RxMeasure, bool, RxState) {
    let mut this: (RxMeasure, bool, RxState) = (rx_none(), *fi0, st0.clone());
    let mut total: RxMeasure = rx_none();
    let mut fi: bool = *fi0;
    let mut st: RxState = st0.clone();
    let mut last: RxLast = RxLast::RxLastNothing;
    let mut last_m: RxMeasure = rx_none();
    let mut going: bool = true;
    while going && !rx_bad(&st) {
        let c = rx_peek(&st);
        let at_ = st.i.clone();
        if ((&c == &Text::lit("")) || (&c == &Text::lit("|"))) || (&c == &Text::lit(")")) {
            going = false;
        } else if (((&c == &Text::lit("*")) || (&c == &Text::lit("+"))) || (&c == &Text::lit("?"))) || (&c == &Text::lit("{")) {
            let (lo, hi_opt, st2) = if &c == &Text::lit("{") { rx_count(&st) } else { rx_simple_repetition(&st, &c) };
            st = st2.clone();
            if !rx_bad(&st) {
                st = match &last {
                    RxLast::RxLastNothing => rx_fail(&st, &at_, &rx_nothing_to_repeat()),
                    RxLast::RxLastFlagGroup => rx_fail(&st, &at_, &rx_nothing_to_repeat()),
                    RxLast::RxLastRepetition => rx_fail(&st, &at_, &rx_repeat_repeat()),
                    RxLast::RxLastAssertion => rx_fail(&st, &at_, &rx_repeat_assertion()),
                    RxLast::RxLastAtom => st.clone(),
                };
            }
            if !rx_bad(&st) {
                let counted = &c == &Text::lit("{");
                let factor = if counted { max(&or(&hi_opt, &lo), &Nat::from(1u32)) } else { Nat::from(1u32) };
                let product = &factor * &max(&last_m.product, &Nat::from(1u32));
                if counted && (&product > &Nat::from(1000u32)) {
                    st = rx_fail(&st, &at_, &rx_product());
                } else {
                    if &rx_peek(&st) == &Text::lit("?") {
                        st = rx_go(&st, &(&st.i + &Nat::from(1u32)));
                    }
                    let m = RxMeasure { depth: &last_m.depth + &Nat::from(1u32), size: &last_m.size * &factor, product: product.clone() };
                    total = RxMeasure { depth: max(&total.depth, &m.depth), size: &or(&(&total.size).checked_sub(&last_m.size), &Nat::from(0u32)) + &m.size, product: max(&total.product, &m.product) };
                    last = RxLast::RxLastRepetition;
                    last_m = m.clone();
                }
            }
        } else {
            let (kind, m, fi2, st2) = rx_piece(&st, &fi);
            st = st2.clone();
            fi = fi2;
            if &kind != &RxLast::RxLastFlagGroup {
                total = rx_then(&total, &m);
            }
            last = kind.clone();
            last_m = m.clone();
        }
    }
    this = (total.clone(), fi, st.clone());
    this
}

/// The step machine of `RxSequence`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxSequence: unbounded fn RxState, Bool -> ((RxMeasure, Bool, RxState))
/// ```
pub struct RxSequence {
    pub st0: RxState,
    pub fi0: bool,
}

impl prism_rtl::Job<(RxMeasure, bool, RxState)> for RxSequence {
    fn cycle(&self) -> prism_rtl::Turn<(RxMeasure, bool, RxState)> {
        let st0 = &self.st0;
        let fi0 = &self.fi0;
        let mut this: (RxMeasure, bool, RxState) = (rx_none(), *fi0, st0.clone());
        let mut total: RxMeasure = rx_none();
        let mut fi: bool = *fi0;
        let mut st: RxState = st0.clone();
        let mut last: RxLast = RxLast::RxLastNothing;
        let mut last_m: RxMeasure = rx_none();
        let mut going: bool = true;
        call_then(loop_job((this, fi, going, last, last_m, st, total), move |(mut this, mut fi, mut going, mut last, mut last_m, mut st, mut total): ((RxMeasure, bool, RxState), bool, bool, RxLast, RxMeasure, RxState, RxMeasure)| if going && !rx_bad(&st) {
            {
                let c = rx_peek(&st);
                let at_ = st.i.clone();
                if ((&c == &Text::lit("")) || (&c == &Text::lit("|"))) || (&c == &Text::lit(")")) {
                    going = false;
                } else if (((&c == &Text::lit("*")) || (&c == &Text::lit("+"))) || (&c == &Text::lit("?"))) || (&c == &Text::lit("{")) {
                    let (lo, hi_opt, st2) = if &c == &Text::lit("{") { rx_count(&st) } else { rx_simple_repetition(&st, &c) };
                    st = st2.clone();
                    if !rx_bad(&st) {
                        st = match &last {
                            RxLast::RxLastNothing => rx_fail(&st, &at_, &rx_nothing_to_repeat()),
                            RxLast::RxLastFlagGroup => rx_fail(&st, &at_, &rx_nothing_to_repeat()),
                            RxLast::RxLastRepetition => rx_fail(&st, &at_, &rx_repeat_repeat()),
                            RxLast::RxLastAssertion => rx_fail(&st, &at_, &rx_repeat_assertion()),
                            RxLast::RxLastAtom => st.clone(),
                        };
                    }
                    if !rx_bad(&st) {
                        let counted = &c == &Text::lit("{");
                        let factor = if counted { max(&or(&hi_opt, &lo), &Nat::from(1u32)) } else { Nat::from(1u32) };
                        let product = &factor * &max(&last_m.product, &Nat::from(1u32));
                        if counted && (&product > &Nat::from(1000u32)) {
                            st = rx_fail(&st, &at_, &rx_product());
                        } else {
                            if &rx_peek(&st) == &Text::lit("?") {
                                st = rx_go(&st, &(&st.i + &Nat::from(1u32)));
                            }
                            let m = RxMeasure { depth: &last_m.depth + &Nat::from(1u32), size: &last_m.size * &factor, product: product.clone() };
                            total = RxMeasure { depth: max(&total.depth, &m.depth), size: &or(&(&total.size).checked_sub(&last_m.size), &Nat::from(0u32)) + &m.size, product: max(&total.product, &m.product) };
                            last = RxLast::RxLastRepetition;
                            last_m = m.clone();
                        }
                    }
                } else {
                    let (kind, m, fi2, st2) = rx_piece(&st, &fi);
                    st = st2.clone();
                    fi = fi2;
                    if &kind != &RxLast::RxLastFlagGroup {
                        total = rx_then(&total, &m);
                    }
                    last = kind.clone();
                    last_m = m.clone();
                }
                Ok((this, fi, going, last, last_m, st, total))
            }
        } else {
            Err((this, fi, going, last, last_m, st, total))
        }), move |(mut this, mut fi, mut going, mut last, mut last_m, mut st, mut total): ((RxMeasure, bool, RxState), bool, bool, RxLast, RxMeasure, RxState, RxMeasure)| {
            this = (total.clone(), fi, st.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start RxSequence, x`: what the function value is when passed to `@Run`.
pub fn start_rx_sequence(st0: RxState, fi0: bool) -> Rc<dyn prism_rtl::Job<(RxMeasure, bool, RxState)>> {
    Rc::new(RxSequence { st0, fi0 })
}

/// ```prism
/// RxSimpleRepetition: fn RxState, Text -> ((Nat, ?Nat, RxState))
/// ```
pub fn rx_simple_repetition(st: &RxState, c: &Text) -> (Nat, Option<Nat>, RxState) {
    let st2 = rx_go(st, &(&st.i + &Nat::from(1u32)));
    if c == &Text::lit("*") {
        (Nat::from(0u32), None, st2.clone())
    } else {
        if c == &Text::lit("+") {
            (Nat::from(1u32), None, st2.clone())
        } else {
            (Nat::from(0u32), Some(Nat::from(1u32)), st2.clone())
        }
    }
}

/// ```prism
/// RxCount: unbounded fn RxState -> ((Nat, ?Nat, RxState))
/// ```
pub fn rx_count(st: &RxState) -> (Nat, Option<Nat>, RxState) {
    let at_ = st.i.clone();
    let s = st.s.clone();
    let j1 = rx_span_end(&s, &(&at_ + &Nat::from(1u32)), &{
        let f = Rc::new(rx_is_digit);
        Rc::new(move |a0: Text| {
            let f = f.clone();
            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
    });
    let first_ = rx_slice(&s, &(&at_ + &Nat::from(1u32)), &j1);
    let c = rx_char_at(&s, &j1);
    if &first_ == &Text::lit("") {
        (Nat::from(0u32), None, rx_fail(st, &at_, &rx_brace()))
    } else {
        if &c == &Text::lit("}") {
            rx_count_checked(st, &at_, &first_, &None, &(&j1 + &Nat::from(1u32)))
        } else {
            if &c == &Text::lit(",") {
                {
                    let j2 = rx_span_end(&s, &(&j1 + &Nat::from(1u32)), &{
                        let f = Rc::new(rx_is_digit);
                        Rc::new(move |a0: Text| {
                            let f = f.clone();
                            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                    });
                    if &rx_char_at(&s, &j2) != &Text::lit("}") {
                        (Nat::from(0u32), None, rx_fail(st, &at_, &rx_brace()))
                    } else {
                        rx_count_checked(st, &at_, &first_, &Some(rx_slice(&s, &(&j1 + &Nat::from(1u32)), &j2)), &(&j2 + &Nat::from(1u32)))
                    }
                }
            } else {
                (Nat::from(0u32), None, rx_fail(st, &at_, &rx_brace()))
            }
        }
    }
}

/// ```prism
/// RxCountChecked: fn RxState, Nat, Text, ?Text, Nat -> ((Nat, ?Nat, RxState))
/// ```
pub fn rx_count_checked(st: &RxState, at_: &Nat, first_: &Text, second_opt: &Option<Text>, next_: &Nat) -> (Nat, Option<Nat>, RxState) {
    let st1 = rx_go(st, next_);
    let lo = or(&parse_nat_opt(first_), &Nat::from(0u32));
    let hi_opt = match second_opt {
        None => Some(lo.clone()),
        Some(m20974_1) if (m20974_1 == &Text::lit("")) => None,
        Some(d) => parse_nat_opt(d),
        _ => unreachable!("no arm matched"),
    };
    let zero = rx_leading_zero(first_) || rx_leading_zero(&or(second_opt, &Text::lit("")));
    if zero {
        (Nat::from(0u32), None, rx_fail(&st1, at_, &rx_count_zero()))
    } else {
        if (&lo > &Nat::from(1000u32)) || (&or(&hi_opt, &Nat::from(0u32)) > &Nat::from(1000u32)) {
            (Nat::from(0u32), None, rx_fail(&st1, at_, &rx_count_bound()))
        } else {
            if &lo > &or(&hi_opt, &lo) {
                (Nat::from(0u32), None, rx_fail(&st1, at_, &rx_count_order()))
            } else {
                (lo.clone(), hi_opt.clone(), st1.clone())
            }
        }
    }
}

/// ```prism
/// RxLeadingZero: fn Text -> Bool
/// ```
pub fn rx_leading_zero(d: &Text) -> bool {
    (&len_text(d) > &Nat::from(1u32)) && (&rx_char_at(d, &Nat::from(0u32)) == &Text::lit("0"))
}

/// ```prism
/// RxPiece: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_piece(st: &RxState, fi: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let at_ = st.i.clone();
    let c = rx_peek(st);
    match &c {
        m21753_0 if (m21753_0 == &Text::lit("(")) => rx_group(st, fi),
        m21753_1 if (m21753_1 == &Text::lit("[")) => (RxLast::RxLastAtom, rx_atom(), *fi, rx_class(st, fi)),
        m21753_2 if (m21753_2 == &Text::lit("]")) => (RxLast::RxLastAtom, rx_atom(), *fi, rx_fail(st, &at_, &rx_stray_bracket())),
        m21753_3 if (m21753_3 == &Text::lit("}")) => (RxLast::RxLastAtom, rx_atom(), *fi, rx_fail(st, &at_, &rx_stray_brace())),
        m21753_4 if (m21753_4 == &Text::lit("^")) => (RxLast::RxLastAssertion, rx_atom(), *fi, rx_go(st, &(&at_ + &Nat::from(1u32)))),
        m21753_5 if (m21753_5 == &Text::lit("$")) => (RxLast::RxLastAssertion, rx_atom(), *fi, rx_go(st, &(&at_ + &Nat::from(1u32)))),
        m21753_6 if (m21753_6 == &Text::lit("\\")) => rx_escape(st, fi),
        _ => (RxLast::RxLastAtom, rx_atom(), *fi, rx_go(st, &(&at_ + &len_text(&c)))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RxEscape: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_escape(st: &RxState, fi: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let at_ = st.i.clone();
    let s = st.s.clone();
    let c = rx_char_at(&s, &(&at_ + &Nat::from(1u32)));
    let atom_fn = {
        let fi = *fi;
        Rc::new(move |next_: &RxState| (RxLast::RxLastAtom, rx_atom(), fi, next_.clone()))
    };
    if &c == &Text::lit("") {
        (&atom_fn)(&rx_fail(st, &at_, &rx_trailing_backslash()))
    } else {
        if (&c == &Text::lit("<")) || (&c == &Text::lit(">")) {
            (&atom_fn)(&rx_fail(st, &at_, &rx_angle()))
        } else {
            if rx_in(&rx_punctuation(), &c) {
                (&atom_fn)(&rx_go(st, &(&at_ + &Nat::from(2u32))))
            } else {
                if rx_in(&Text::lit("tnrfva"), &c) {
                    (&atom_fn)(&rx_go(st, &(&at_ + &Nat::from(2u32))))
                } else {
                    if &c == &Text::lit("x") {
                        {
                            let (_, st2) = rx_hex(st, &at_);
                            (&atom_fn)(&st2)
                        }
                    } else {
                        if rx_in(&Text::lit("dwsDWS"), &c) {
                            (&atom_fn)(&rx_go(st, &(&at_ + &Nat::from(2u32))))
                        } else {
                            if (&c == &Text::lit("p")) || (&c == &Text::lit("P")) {
                                {
                                    let (_, st2) = rx_property(st, &at_);
                                    (&atom_fn)(&st2)
                                }
                            } else {
                                if rx_in(&Text::lit("AzbB"), &c) {
                                    if (&c == &Text::lit("b")) && (&rx_char_at(&s, &(&at_ + &Nat::from(2u32))) == &Text::lit("{")) {
                                        (&atom_fn)(&rx_fail(st, &at_, &rx_word_braces()))
                                    } else {
                                        (RxLast::RxLastAssertion, rx_atom(), *fi, rx_go(st, &(&at_ + &Nat::from(2u32))))
                                    }
                                } else {
                                    if rx_in(&Text::lit("123456789"), &c) {
                                        (&atom_fn)(&rx_fail(st, &at_, &rx_backreference()))
                                    } else {
                                        if &c == &Text::lit("0") {
                                            (&atom_fn)(&rx_fail(st, &at_, &rx_octal()))
                                        } else {
                                            if (&c == &Text::lit("Q")) || (&c == &Text::lit("E")) {
                                                (&atom_fn)(&rx_fail(st, &at_, &rx_quote()))
                                            } else {
                                                if &c == &Text::lit("C") {
                                                    (&atom_fn)(&rx_fail(st, &at_, &rx_one_byte()))
                                                } else {
                                                    (&atom_fn)(&rx_fail(st, &at_, &rx_unknown_escape()))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxHex: unbounded fn RxState, Nat -> ((Nat, RxState))
/// ```
pub fn rx_hex(st: &RxState, at_: &Nat) -> (Nat, RxState) {
    let s = st.s.clone();
    let x = at_ + &Nat::from(1u32);
    if &rx_char_at(&s, &(&x + &Nat::from(1u32))) == &Text::lit("{") {
        {
            let start = &x + &Nat::from(2u32);
            let j = rx_span_end(&s, &start, &{
                let f = Rc::new(rx_is_hex);
                Rc::new(move |a0: Text| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
            });
            let digits = rx_slice(&s, &start, &j);
            if ((&rx_char_at(&s, &j) != &Text::lit("}")) || (&digits == &Text::lit(""))) || (&len_text(&digits) > &Nat::from(6u32)) {
                (Nat::from(0u32), rx_fail(st, at_, &rx_hex_braces()))
            } else {
                rx_hex_checked(&rx_go(st, &(&j + &Nat::from(1u32))), at_, &rx_hex_value(&digits))
            }
        }
    } else {
        {
            let a = rx_char_at(&s, &(&x + &Nat::from(1u32)));
            let b = rx_char_at(&s, &(&x + &Nat::from(2u32)));
            if rx_is_hex(&a) && rx_is_hex(&b) {
                rx_hex_checked(&rx_go(st, &(&x + &Nat::from(3u32))), at_, &rx_hex_value(&Text::from(format!("{}{}", &a, &b))))
            } else {
                (Nat::from(0u32), rx_fail(st, at_, &rx_hex_two()))
            }
        }
    }
}

/// ```prism
/// RxHexChecked: fn RxState, Nat, Nat -> ((Nat, RxState))
/// ```
pub fn rx_hex_checked(st: &RxState, at_: &Nat, v_: &Nat) -> (Nat, RxState) {
    if ((&Nat::from(55296u32) <= v_) && (v_ <= &Nat::from(57343u32))) || (v_ > &Nat::from(1114111u32)) {
        (v_.clone(), rx_fail(st, at_, &rx_hex_no_char()))
    } else {
        (v_.clone(), st.clone())
    }
}

/// ```prism
/// RxProperty: unbounded fn RxState, Nat -> ((Text, RxState))
/// ```
pub fn rx_property(st: &RxState, at_: &Nat) -> (Text, RxState) {
    let s = st.s.clone();
    let c = rx_char_at(&s, &(at_ + &Nat::from(2u32)));
    if &c == &Text::lit("{") {
        {
            let start = at_ + &Nat::from(3u32);
            match rx_find(&s, &start, &Text::lit("}")) {
                None => (Text::lit(""), rx_fail(st, at_, &rx_property_open())),
                Some(close) => {
                    let name = rx_slice(&s, &start, &close);
                    if &rx_char_at(&name, &Nat::from(0u32)) == &Text::lit("^") {
                        (name.clone(), rx_fail(st, at_, &rx_property_negated()))
                    } else {
                        rx_property_named(&rx_go(st, &(&close + &Nat::from(1u32))), at_, &name)
                    }
                },
            }
        }
    } else {
        if rx_is_letter(&c) {
            rx_property_named(&rx_go(st, &(at_ + &Nat::from(3u32))), at_, &c)
        } else {
            (Text::lit(""), rx_fail(st, at_, &rx_property_name()))
        }
    }
}

/// ```prism
/// RxPropertyNamed: fn RxState, Nat, Text -> ((Text, RxState))
/// ```
pub fn rx_property_named(st: &RxState, at_: &Nat, name: &Text) -> (Text, RxState) {
    if (((name == &Text::lit("C")) || (name == &Text::lit("Cn"))) || (name == &Text::lit("Cs"))) || (name == &Text::lit("LC")) {
        (name.clone(), rx_fail(st, at_, &rx_property_refused()))
    } else {
        if &get(&rx_properties(), name) != &None {
            (name.clone(), st.clone())
        } else {
            (name.clone(), rx_fail(st, at_, &rx_property_unknown()))
        }
    }
}

/// ```prism
/// RxClass: unbounded fn RxState, Bool -> RxState
/// ```
pub fn rx_class(st0: &RxState, fi: &bool) -> RxState {
    let open = st0.i.clone();
    let start = if &rx_char_at(&st0.s, &(&open + &Nat::from(1u32))) == &Text::lit("^") {
        &open + &Nat::from(2u32)
    } else {
        &open + &Nat::from(1u32)
    };
    let mut this: RxState = rx_go(st0, &start);
    let mut first_: bool = true;
    let mut done: bool = false;
    while !done {
        let (closed, st2) = rx_class_item(&this, &open, &start, &first_, fi);
        this = st2.clone();
        first_ = false;
        done = closed || rx_bad(&st2);
    }
    this
}

/// ```prism
/// RxAtSetOperation: fn RxState -> Bool
/// ```
pub fn rx_at_set_operation(st: &RxState) -> bool {
    let c = rx_peek(st);
    (((&c == &Text::lit("&")) || (&c == &Text::lit("~"))) || (&c == &Text::lit("-"))) && (&rx_char_at(&st.s, &(&st.i + &Nat::from(1u32))) == &c)
}

/// ```prism
/// RxClassItem: unbounded fn RxState, Nat, Nat, Bool, Bool -> ((Bool, RxState))
/// ```
pub fn rx_class_item(st: &RxState, open: &Nat, start: &Nat, first_: &bool, fi: &bool) -> (bool, RxState) {
    let at_ = st.i.clone();
    let c = rx_peek(st);
    let next_ = rx_char_at(&st.s, &(&at_ + &Nat::from(1u32)));
    if &c == &Text::lit("") {
        (true, rx_fail(st, open, &rx_class_open()))
    } else {
        if (&c == &Text::lit("]")) && *first_ {
            (true, rx_fail(st, &at_, &rx_class_first_bracket()))
        } else {
            if &c == &Text::lit("]") {
                (true, rx_go(st, &(&at_ + &Nat::from(1u32))))
            } else {
                if rx_at_set_operation(st) {
                    (true, rx_fail(st, &at_, &rx_class_set_operation()))
                } else {
                    if &c == &Text::lit("[") {
                        (false, rx_ascii_item(st, fi))
                    } else {
                        if (&c == &Text::lit("-")) && (&next_ == &Text::lit("")) {
                            (true, rx_fail(st, open, &rx_class_open()))
                        } else {
                            if (&c == &Text::lit("-")) && ((&at_ == start) || (&next_ == &Text::lit("]"))) {
                                (false, rx_go(st, &(&at_ + &Nat::from(1u32))))
                            } else {
                                if &c == &Text::lit("-") {
                                    (true, rx_fail(st, &at_, &rx_class_dash()))
                                } else {
                                    (false, rx_class_range(st, open, fi))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxClassRange: unbounded fn RxState, Nat, Bool -> RxState
/// ```
pub fn rx_class_range(st: &RxState, open: &Nat, fi: &bool) -> RxState {
    let at_ = st.i.clone();
    let (lo_opt, st1) = rx_class_atom(st, fi);
    match &lo_opt {
        None => st1.clone(),
        Some(lo) => {
            let s = st1.s.clone();
            let ranged = (&rx_peek(&st1) == &Text::lit("-")) && (&rx_char_at(&s, &(&st1.i + &Nat::from(1u32))) != &Text::lit("]"));
            if rx_bad(&st1) || !ranged {
                st1.clone()
            } else {
                if rx_at_set_operation(&st1) {
                    rx_fail(&st1, &st1.i, &rx_class_set_operation())
                } else {
                    {
                        let right = &st1.i + &Nat::from(1u32);
                        let st2 = rx_go(&st1, &right);
                        let rc_ = rx_peek(&st2);
                        if &rc_ == &Text::lit("") {
                            rx_fail(&st2, open, &rx_class_open())
                        } else {
                            if &rc_ == &Text::lit("[") {
                                rx_fail(&st2, &right, &rx_class_nested())
                            } else {
                                if rx_at_set_operation(&st2) {
                                    rx_fail(&st2, &right, &rx_class_set_operation())
                                } else {
                                    {
                                        let (hi_opt, st3) = rx_class_atom(&st2, fi);
                                        if rx_bad(&st3) {
                                            st3.clone()
                                        } else {
                                            match &hi_opt {
                                                None => rx_fail(&st3, &right, &rx_class_range_set()),
                                                Some(hi) => if rx_past(lo, hi) { rx_fail(&st3, &at_, &rx_class_order()) } else { st3.clone() },
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
    }
}

/// ```prism
/// RxClassAtom: unbounded fn RxState, Bool -> ((?RxCp, RxState))
/// ```
pub fn rx_class_atom(st: &RxState, fi: &bool) -> (Option<RxCp>, RxState) {
    let at_ = st.i.clone();
    let s = st.s.clone();
    let c = rx_peek(st);
    if &c != &Text::lit("\\") {
        (Some(RxCp::RxLit(c.clone())), rx_go(st, &(&at_ + &len_text(&c))))
    } else {
        {
            let e = rx_char_at(&s, &(&at_ + &Nat::from(1u32)));
            if &e == &Text::lit("") {
                (None, rx_fail(st, &at_, &rx_trailing_backslash()))
            } else {
                if (&e == &Text::lit("<")) || (&e == &Text::lit(">")) {
                    (None, rx_fail(st, &at_, &rx_class_escape()))
                } else {
                    if rx_in(&rx_punctuation(), &e) {
                        (Some(RxCp::RxLit(e.clone())), rx_go(st, &(&at_ + &Nat::from(2u32))))
                    } else {
                        if rx_in(&Text::lit("tnrfva"), &e) {
                            (Some(RxCp::RxLit(rx_control(&e))), rx_go(st, &(&at_ + &Nat::from(2u32))))
                        } else {
                            if &e == &Text::lit("x") {
                                {
                                    let (v_, st2) = rx_hex(st, &at_);
                                    (Some(rx_cp_of(&v_)), st2.clone())
                                }
                            } else {
                                if rx_in(&Text::lit("dws"), &e) {
                                    (None, rx_go(st, &(&at_ + &Nat::from(2u32))))
                                } else {
                                    if rx_in(&Text::lit("DWS"), &e) {
                                        if *fi {
                                            (None, rx_fail(st, &at_, &rx_class_negated_under_i()))
                                        } else {
                                            (None, rx_go(st, &(&at_ + &Nat::from(2u32))))
                                        }
                                    } else {
                                        if (&e == &Text::lit("p")) || (&e == &Text::lit("P")) {
                                            {
                                                let (_, st2) = rx_property(st, &at_);
                                                if ((&e == &Text::lit("P")) && *fi) && !rx_bad(&st2) {
                                                    (None, rx_fail(&st2, &at_, &rx_class_negated_under_i()))
                                                } else {
                                                    (None, st2.clone())
                                                }
                                            }
                                        } else {
                                            (None, rx_fail(st, &at_, &rx_class_escape()))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxControl: fn Text -> Text
/// ```
pub fn rx_control(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("t")) => Text::lit("\t"),
        c1_0 if (c1_0 == &Text::lit("n")) => Text::lit("\n"),
        c2_0 if (c2_0 == &Text::lit("r")) => Text::lit("\r"),
        c3_0 if (c3_0 == &Text::lit("f")) => Text::lit(""),
        c4_0 if (c4_0 == &Text::lit("v")) => Text::lit(""),
        _ => Text::lit(""),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RxAsciiItem: unbounded fn RxState, Bool -> RxState
/// ```
pub fn rx_ascii_item(st: &RxState, fi: &bool) -> RxState {
    let at_ = st.i.clone();
    let s = st.s.clone();
    let negated = &rx_char_at(&s, &(&at_ + &Nat::from(2u32))) == &Text::lit("^");
    let start = if negated { &at_ + &Nat::from(3u32) } else { &at_ + &Nat::from(2u32) };
    let j = rx_span_end(&s, &start, &{
        let f = Rc::new(rx_is_letter);
        Rc::new(move |a0: Text| {
            let f = f.clone();
            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
    });
    let shaped = (((&rx_char_at(&s, &(&at_ + &Nat::from(1u32))) == &Text::lit(":")) && (&j > &start)) && (&rx_char_at(&s, &j) == &Text::lit(":"))) && (&rx_char_at(&s, &(&j + &Nat::from(1u32))) == &Text::lit("]"));
    if !shaped {
        rx_fail(st, &at_, &rx_class_nested())
    } else {
        if &get(&rx_ascii_classes(), &rx_slice(&s, &start, &j)) == &None {
            rx_fail(st, &at_, &rx_class_ascii_unknown())
        } else {
            if negated && *fi {
                rx_fail(st, &at_, &rx_class_negated_under_i())
            } else {
                rx_go(st, &(&j + &Nat::from(2u32)))
            }
        }
    }
}

/// ```prism
/// RxGroup: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_group(st: &RxState, fi: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let open = st.i.clone();
    let s = st.s.clone();
    let c = rx_char_at(&s, &(&open + &Nat::from(1u32)));
    let d = rx_char_at(&s, &(&open + &Nat::from(2u32)));
    let e = rx_char_at(&s, &(&open + &Nat::from(3u32)));
    let fail_fn = {
        let fi = *fi;
        let st = st.clone();
        let open = open.clone();
        Rc::new(move |message: &Text| (RxLast::RxLastAtom, rx_atom(), fi, rx_fail(&st, &open, message)))
    };
    if &c != &Text::lit("?") {
        rx_group_body(&rx_go(st, &(&open + &Nat::from(1u32))), &open, fi, fi, &true, &None)
    } else {
        if &d == &Text::lit("") {
            (&fail_fn)(&rx_group_open())
        } else {
            if &d == &Text::lit(":") {
                rx_group_body(&rx_go(st, &(&open + &Nat::from(3u32))), &open, fi, fi, &false, &None)
            } else {
                if (&d == &Text::lit("=")) || (&d == &Text::lit("!")) {
                    (&fail_fn)(&rx_lookaround())
                } else {
                    if (&d == &Text::lit("<")) && ((&e == &Text::lit("=")) || (&e == &Text::lit("!"))) {
                        (&fail_fn)(&rx_lookaround())
                    } else {
                        if &d == &Text::lit("<") {
                            rx_named(st, &open, &(&open + &Nat::from(3u32)), fi)
                        } else {
                            if (&d == &Text::lit("P")) && (&e == &Text::lit("")) {
                                (&fail_fn)(&rx_group_open())
                            } else {
                                if (&d == &Text::lit("P")) && (&e == &Text::lit("<")) {
                                    rx_named(st, &open, &(&open + &Nat::from(4u32)), fi)
                                } else {
                                    if (&d == &Text::lit("P")) && ((&e == &Text::lit("=")) || (&e == &Text::lit(">"))) {
                                        (&fail_fn)(&rx_backreference())
                                    } else {
                                        if &d == &Text::lit("P") {
                                            (&fail_fn)(&rx_unknown_group())
                                        } else {
                                            if (rx_is_letter(&d) || (&d == &Text::lit("-"))) || (&d == &Text::lit(")")) {
                                                rx_flag_group(st, &open, fi)
                                            } else {
                                                (&fail_fn)(&rx_unknown_group())
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxNamed: unbounded fn RxState, Nat, Nat, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_named(st: &RxState, open: &Nat, start: &Nat, fi: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    match rx_find(&st.s, start, &Text::lit(">")) {
        None => (RxLast::RxLastAtom, rx_atom(), *fi, rx_fail(st, open, &rx_name_open())),
        Some(close) => {
            let name = rx_slice(&st.s, start, &close);
            if !rx_is_name(&name) {
                (RxLast::RxLastAtom, rx_atom(), *fi, rx_fail(st, start, &rx_name_shape()))
            } else {
                if &get(&st.names, &name) != &None {
                    (RxLast::RxLastAtom, rx_atom(), *fi, rx_fail(st, open, &rx_name_twice()))
                } else {
                    rx_group_body(&rx_go(st, &(&close + &Nat::from(1u32))), open, fi, fi, &true, &Some(name.clone()))
                }
            }
        },
    }
}

/// ```prism
/// RxFlagGroup: unbounded fn RxState, Nat, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_flag_group(st: &RxState, open: &Nat, fi: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let (bare, inner, st2) = rx_flag_letters(st, open, fi);
    if rx_bad(&st2) {
        (RxLast::RxLastAtom, rx_atom(), *fi, st2.clone())
    } else {
        if bare {
            (RxLast::RxLastFlagGroup, rx_none(), inner, st2.clone())
        } else {
            rx_group_body(&st2, open, &inner, fi, &false, &None)
        }
    }
}

/// ```prism
/// RxFlagLetters: unbounded fn RxState, Nat, Bool -> ((Bool, Bool, RxState))
/// ```
pub fn rx_flag_letters(st0: &RxState, open: &Nat, fi0: &bool) -> (bool, bool, RxState) {
    let mut this: (bool, bool, RxState) = (false, *fi0, st0.clone());
    let mut st: RxState = rx_go(st0, &(open + &Nat::from(2u32)));
    let mut fi: bool = *fi0;
    let mut seen: Text = Text::lit("");
    let mut dash_opt: Option<Nat> = None;
    let mut after_dash: bool = false;
    let mut named_: bool = false;
    let mut bare: bool = false;
    let mut going: bool = true;
    while going && !rx_bad(&st) {
        let at_ = st.i.clone();
        let c = rx_peek(&st);
        if &c == &Text::lit("") {
            st = rx_fail(&st, open, &rx_group_open());
        } else if (&c == &Text::lit(")")) || (&c == &Text::lit(":")) {
            if !named_ && (&dash_opt == &None) {
                st = rx_fail(&st, open, &rx_flags_empty());
            } else {
                match &dash_opt {
                    Some(d) if !after_dash => {
                        st = rx_fail(&st, d, &rx_flags_dash());
                        ()
                    },
                    _ => {
                        st = rx_go(&st, &(&at_ + &Nat::from(1u32)));
                        bare = &c == &Text::lit(")");
                        going = false;
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
            }
        } else if &c == &Text::lit("-") {
            if &dash_opt != &None {
                st = rx_fail(&st, &at_, &rx_flags_second_dash());
            } else {
                dash_opt = Some(at_.clone());
                st = rx_go(&st, &(&at_ + &Nat::from(1u32)));
            }
        } else if rx_is_letter(&c) {
            if !(((&c == &Text::lit("i")) || (&c == &Text::lit("m"))) || (&c == &Text::lit("s"))) {
                st = rx_fail(&st, &at_, &rx_unknown_flag());
            } else if rx_in(&seen, &c) {
                st = rx_fail(&st, &at_, &rx_flag_twice());
            } else {
                seen = Text::from(format!("{}{}", &seen, &c));
                named_ = true;
                if &dash_opt != &None {
                    after_dash = true;
                }
                if &c == &Text::lit("i") {
                    fi = &dash_opt == &None;
                }
                st = rx_go(&st, &(&at_ + &Nat::from(1u32)));
            }
        } else {
            st = rx_fail(&st, open, &rx_unknown_group());
        }
    }
    this = (bare, fi, st.clone());
    this
}

/// ```prism
/// RxGroupBody: unbounded fn RxState, Nat, Bool, Bool, Bool, ?Text -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_group_body(st0: &RxState, open: &Nat, inner: &bool, outer: &bool, capture: &bool, name_opt: &Option<Text>) -> (RxLast, RxMeasure, bool, RxState) {
    let counted = if *capture { rx_capture(st0, name_opt) } else { st0.clone() };
    if &counted.open == &Nat::from(100u32) {
        (RxLast::RxLastAtom, rx_atom(), *outer, rx_fail(&counted, &Nat::from(0u32), &rx_nesting()))
    } else {
        {
            let deeper = {
                let mut this: RxState = counted.clone();
                this.open = &this.open + &Nat::from(1u32);
                this
            };
            let (m, st2) = rx_alternation(&deeper, inner);
            if rx_bad(&st2) {
                (RxLast::RxLastAtom, rx_atom(), *outer, st2.clone())
            } else {
                if &rx_peek(&st2) != &Text::lit(")") {
                    (RxLast::RxLastAtom, rx_atom(), *outer, rx_fail(&st2, open, &rx_group_open()))
                } else {
                    {
                        let closed = {
                            let mut this: RxState = st2.clone();
                            this.i = &this.i + &Nat::from(1u32);
                            this.open = or(&(&this.open).checked_sub(&Nat::from(1u32)), &Nat::from(0u32));
                            this
                        };
                        (RxLast::RxLastAtom, RxMeasure { depth: &m.depth + &Nat::from(1u32), size: m.size.clone(), product: m.product.clone() }, *outer, closed.clone())
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxCapture: fn RxState, ?Text -> RxState
/// ```
pub fn rx_capture(st: &RxState, name_opt: &Option<Text>) -> RxState {
    let n = &st.groups + &Nat::from(1u32);
    let names = match name_opt {
        Some(x) => insert(&st.names, x, &n),
        None => st.names.clone(),
    };
    RxState { s: st.s.clone(), i: st.i.clone(), open: st.open.clone(), groups: n.clone(), names: names.clone(), err: st.err.clone() }
}

/// ```prism
/// ?RxReplacementRefusal: unbounded fn Text, Nat, (Text ==> Nat) -> ?RxDiag
/// ```
pub fn rx_replacement_refusal(r: &Text, groups: &Nat, names: &Map<Text, Nat>) -> Option<RxDiag> {
    let (d_opt, _) = {
        let mut this: (Option<RxDiag>, Nat) = (None, Nat::from(0u32));
        let mut i: Nat = Nat::from(0u32);
        let mut d_opt: Option<RxDiag> = None;
        while (&d_opt == &None) && (&rx_char_at(r, &i) != &Text::lit("")) {
            let at_ = i.clone();
            let c = rx_char_at(r, &at_);
            let next_ = rx_char_at(r, &(&at_ + &Nat::from(1u32)));
            if &c == &Text::lit("$") {
                if &next_ == &Text::lit("$") {
                    i = &at_ + &Nat::from(2u32);
                } else if rx_is_digit(&next_) {
                    let j = rx_span_end(r, &(&at_ + &Nat::from(1u32)), &{
                        let f = Rc::new(rx_is_digit);
                        Rc::new(move |a0: Text| {
                            let f = f.clone();
                            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                    });
                    d_opt = rx_group_number(&rx_slice(r, &(&at_ + &Nat::from(1u32)), &j), groups, &at_);
                    i = j.clone();
                } else if &next_ == &Text::lit("{") {
                    match &rx_find(r, &(&at_ + &Nat::from(2u32)), &Text::lit("}")) {
                        None => {
                            d_opt = rx_replacement_at(&at_, &rx_rbraces());
                        }
                        Some(close) => {
                            let inner = rx_slice(r, &(&at_ + &Nat::from(2u32)), close);
                            if (&inner != &Text::lit("")) && rx_all(&inner, &{
                                let f = Rc::new(rx_is_digit);
                                Rc::new(move |a0: Text| {
                                    let f = f.clone();
                                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                            }) {
                                d_opt = rx_group_number(&inner, groups, &at_);
                            } else if rx_is_name(&inner) {
                                if &get(names, &inner) == &None {
                                    d_opt = rx_replacement_at(&at_, &rx_rno_name());
                                }
                            } else {
                                d_opt = rx_replacement_at(&at_, &rx_rbraces());
                            }
                            i = close + &Nat::from(1u32);
                        }
                    }
                } else {
                    d_opt = rx_replacement_at(&at_, &rx_rdollar());
                }
            } else if &c == &Text::lit("\\") {
                if (((&next_ == &Text::lit("\\")) || (&next_ == &Text::lit("n"))) || (&next_ == &Text::lit("t"))) || (&next_ == &Text::lit("/")) {
                    i = &at_ + &Nat::from(2u32);
                } else if &next_ == &Text::lit("u") {
                    let j = rx_span_end(r, &(&at_ + &Nat::from(3u32)), &{
                        let f = Rc::new(rx_is_hex);
                        Rc::new(move |a0: Text| {
                            let f = f.clone();
                            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                    });
                    let digits = rx_slice(r, &(&at_ + &Nat::from(3u32)), &j);
                    let v_ = rx_hex_value(&digits);
                    let named_ = ((((&rx_char_at(r, &(&at_ + &Nat::from(2u32))) == &Text::lit("{")) && (&rx_char_at(r, &j) == &Text::lit("}"))) && (&digits != &Text::lit(""))) && (&len_text(&digits) <= &Nat::from(6u32))) && !(((&Nat::from(55296u32) <= &v_) && (&v_ <= &Nat::from(57343u32))) || (&v_ > &Nat::from(1114111u32)));
                    if named_ {
                        i = &j + &Nat::from(1u32);
                    } else {
                        d_opt = rx_replacement_at(&at_, &rx_runicode());
                    }
                } else {
                    d_opt = rx_replacement_at(&at_, &rx_rescape());
                }
            } else {
                i = &at_ + &len_text(&c);
            }
        }
        this = (d_opt.clone(), i.clone());
        this
    };
    d_opt.clone()
}

/// The step machine of `RxReplacementRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RxReplacementRefusal: unbounded fn Text, Nat, (Text ==> Nat) -> ?RxDiag
/// ```
pub struct RxReplacementRefusal {
    pub r: Text,
    pub groups: Nat,
    pub names: Map<Text, Nat>,
}

impl prism_rtl::Job<Option<RxDiag>> for RxReplacementRefusal {
    fn cycle(&self) -> prism_rtl::Turn<Option<RxDiag>> {
        let r = &self.r;
        let groups = &self.groups;
        let names = &self.names;
        let mut this: (Option<RxDiag>, Nat) = (None, Nat::from(0u32));
        let mut i: Nat = Nat::from(0u32);
        let mut d_opt: Option<RxDiag> = None;
        call_then(loop_job((d_opt, this, i), {
            let groups = groups.clone();
            let names = names.clone();
            let r = r.clone();
            move |(mut d_opt, mut this, mut i): (Option<RxDiag>, (Option<RxDiag>, Nat), Nat)| if (&d_opt == &None) && (&rx_char_at(&r, &i) != &Text::lit("")) {
                {
                    let at_ = i.clone();
                    let c = rx_char_at(&r, &at_);
                    let next_ = rx_char_at(&r, &(&at_ + &Nat::from(1u32)));
                    if &c == &Text::lit("$") {
                        if &next_ == &Text::lit("$") {
                            i = &at_ + &Nat::from(2u32);
                        } else if rx_is_digit(&next_) {
                            let j = rx_span_end(&r, &(&at_ + &Nat::from(1u32)), &{
                                let f = Rc::new(rx_is_digit);
                                Rc::new(move |a0: Text| {
                                    let f = f.clone();
                                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                            });
                            d_opt = rx_group_number(&rx_slice(&r, &(&at_ + &Nat::from(1u32)), &j), &groups, &at_);
                            i = j.clone();
                        } else if &next_ == &Text::lit("{") {
                            match &rx_find(&r, &(&at_ + &Nat::from(2u32)), &Text::lit("}")) {
                                None => {
                                    d_opt = rx_replacement_at(&at_, &rx_rbraces());
                                }
                                Some(close) => {
                                    let inner = rx_slice(&r, &(&at_ + &Nat::from(2u32)), close);
                                    if (&inner != &Text::lit("")) && rx_all(&inner, &{
                                        let f = Rc::new(rx_is_digit);
                                        Rc::new(move |a0: Text| {
                                            let f = f.clone();
                                            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }) {
                                        d_opt = rx_group_number(&inner, &groups, &at_);
                                    } else if rx_is_name(&inner) {
                                        if &get(&names, &inner) == &None {
                                            d_opt = rx_replacement_at(&at_, &rx_rno_name());
                                        }
                                    } else {
                                        d_opt = rx_replacement_at(&at_, &rx_rbraces());
                                    }
                                    i = close + &Nat::from(1u32);
                                }
                            }
                        } else {
                            d_opt = rx_replacement_at(&at_, &rx_rdollar());
                        }
                    } else if &c == &Text::lit("\\") {
                        if (((&next_ == &Text::lit("\\")) || (&next_ == &Text::lit("n"))) || (&next_ == &Text::lit("t"))) || (&next_ == &Text::lit("/")) {
                            i = &at_ + &Nat::from(2u32);
                        } else if &next_ == &Text::lit("u") {
                            let j = rx_span_end(&r, &(&at_ + &Nat::from(3u32)), &{
                                let f = Rc::new(rx_is_hex);
                                Rc::new(move |a0: Text| {
                                    let f = f.clone();
                                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                            });
                            let digits = rx_slice(&r, &(&at_ + &Nat::from(3u32)), &j);
                            let v_ = rx_hex_value(&digits);
                            let named_ = ((((&rx_char_at(&r, &(&at_ + &Nat::from(2u32))) == &Text::lit("{")) && (&rx_char_at(&r, &j) == &Text::lit("}"))) && (&digits != &Text::lit(""))) && (&len_text(&digits) <= &Nat::from(6u32))) && !(((&Nat::from(55296u32) <= &v_) && (&v_ <= &Nat::from(57343u32))) || (&v_ > &Nat::from(1114111u32)));
                            if named_ {
                                i = &j + &Nat::from(1u32);
                            } else {
                                d_opt = rx_replacement_at(&at_, &rx_runicode());
                            }
                        } else {
                            d_opt = rx_replacement_at(&at_, &rx_rescape());
                        }
                    } else {
                        i = &at_ + &len_text(&c);
                    }
                    Ok((d_opt, this, i))
                }
            } else {
                Err((d_opt, this, i))
            }
        }), move |(mut d_opt, mut this, mut i): (Option<RxDiag>, (Option<RxDiag>, Nat), Nat)| {
            this = (d_opt.clone(), i.clone());
            let (d_opt, _) = this;
            prism_rtl::Turn::Finished(d_opt.clone())
        })
    }
}

/// `Start RxReplacementRefusal, x`: what the function value is when passed to `@Run`.
pub fn start_rx_replacement_refusal(r: Text, groups: Nat, names: Map<Text, Nat>) -> Rc<dyn prism_rtl::Job<Option<RxDiag>>> {
    Rc::new(RxReplacementRefusal { r, groups, names })
}

/// ```prism
/// ?RxReplacementAt: fn Nat, Text -> ?RxDiag
/// ```
pub fn rx_replacement_at(at_: &Nat, message: &Text) -> Option<RxDiag> {
    Some(RxDiag { part: Text::lit("replacement"), at: at_.clone(), message: message.clone() })
}

/// ```prism
/// ?RxGroupNumber: fn Text, Nat, Nat -> ?RxDiag
/// ```
pub fn rx_group_number(digits: &Text, groups: &Nat, at_: &Nat) -> Option<RxDiag> {
    if rx_leading_zero(digits) {
        rx_replacement_at(at_, &rx_rzero())
    } else {
        if &or(&parse_nat_opt(digits), &Nat::from(0u32)) > groups {
            rx_replacement_at(at_, &rx_rno_number())
        } else {
            None
        }
    }
}
