//! The module `Check.Regex`, from `target/bootstrap/src/prismc/check/regex/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `RxCp`:
///
/// ```prism
/// type RxCp = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum RxCp {
    RxLit(crate::prelude::Text),
    RxNum(crate::prelude::Nat),
}

impl crate::prelude::Show for RxCp {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            RxCp::RxLit(a0) => p.choice("RxLit", &[a0]),
            RxCp::RxNum(a0) => p.choice("RxNum", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for RxCp {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            RxCp::RxLit(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RxLit", 0), vec![a0.to_pod()]),
            RxCp::RxNum(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RxNum", 1), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for RxCp {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "RxLit" && a.len() == 1 => ::std::result::Result::Ok(RxCp::RxLit(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "RxNum" && a.len() == 1 => ::std::result::Result::Ok(RxCp::RxNum(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a RxCp", other),
        }
    }
}

/// `RxDiag`:
///
/// ```prism
/// type RxDiag = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct RxDiag {
    pub part_p: crate::prelude::Text,
    pub at_p: crate::prelude::Nat,
    pub message_p: crate::prelude::Text,
}

impl crate::prelude::Show for RxDiag {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("RxDiag", &[("part", &self.part_p), ("at", &self.at_p), ("message", &self.message_p)]);
    }
}

impl crate::prelude::ToPod for RxDiag {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("RxDiag", vec![("part", self.part_p.to_pod()), ("at", self.at_p.to_pod()), ("message", self.message_p.to_pod())])
    }
}

impl crate::prelude::FromPod for RxDiag {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(RxDiag { part_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "part")?)?, at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, message_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "message")?)? })
    }
}

/// `RxLast`:
///
/// ```prism
/// type RxLast = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum RxLast {
    RxLastNothing,
    RxLastFlagGroup,
    RxLastAssertion,
    RxLastRepetition,
    RxLastAtom,
}

impl crate::prelude::Show for RxLast {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            RxLast::RxLastNothing => p.choice("RxLastNothing", &[]),
            RxLast::RxLastFlagGroup => p.choice("RxLastFlagGroup", &[]),
            RxLast::RxLastAssertion => p.choice("RxLastAssertion", &[]),
            RxLast::RxLastRepetition => p.choice("RxLastRepetition", &[]),
            RxLast::RxLastAtom => p.choice("RxLastAtom", &[]),
        }
    }
}

impl crate::prelude::ToPod for RxLast {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            RxLast::RxLastNothing => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RxLastNothing", 0), vec![]),
            RxLast::RxLastFlagGroup => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RxLastFlagGroup", 1), vec![]),
            RxLast::RxLastAssertion => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RxLastAssertion", 2), vec![]),
            RxLast::RxLastRepetition => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RxLastRepetition", 3), vec![]),
            RxLast::RxLastAtom => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RxLastAtom", 4), vec![]),
        }
    }
}

impl crate::prelude::FromPod for RxLast {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "RxLastNothing" && a.len() == 0 => ::std::result::Result::Ok(RxLast::RxLastNothing),
            crate::prelude::Pod::Choice(c, a) if &**c == "RxLastFlagGroup" && a.len() == 0 => ::std::result::Result::Ok(RxLast::RxLastFlagGroup),
            crate::prelude::Pod::Choice(c, a) if &**c == "RxLastAssertion" && a.len() == 0 => ::std::result::Result::Ok(RxLast::RxLastAssertion),
            crate::prelude::Pod::Choice(c, a) if &**c == "RxLastRepetition" && a.len() == 0 => ::std::result::Result::Ok(RxLast::RxLastRepetition),
            crate::prelude::Pod::Choice(c, a) if &**c == "RxLastAtom" && a.len() == 0 => ::std::result::Result::Ok(RxLast::RxLastAtom),
            other => ::prism_rtl::pod::mismatch("a RxLast", other),
        }
    }
}

/// `RxMeasure`:
///
/// ```prism
/// type RxMeasure = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct RxMeasure {
    pub depth_p: crate::prelude::Nat,
    pub size_p: crate::prelude::Nat,
    pub product_p: crate::prelude::Nat,
}

impl crate::prelude::Show for RxMeasure {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("RxMeasure", &[("depth", &self.depth_p), ("size", &self.size_p), ("product", &self.product_p)]);
    }
}

impl crate::prelude::ToPod for RxMeasure {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("RxMeasure", vec![("depth", self.depth_p.to_pod()), ("size", self.size_p.to_pod()), ("product", self.product_p.to_pod())])
    }
}

impl crate::prelude::FromPod for RxMeasure {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(RxMeasure { depth_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "depth")?)?, size_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "size")?)?, product_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "product")?)? })
    }
}

/// `RxState`:
///
/// ```prism
/// type RxState = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct RxState {
    pub s_p: crate::prelude::Text,
    pub i_p: crate::prelude::Nat,
    pub open_p: crate::prelude::Nat,
    pub groups_p: crate::prelude::Nat,
    pub names_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>,
    pub err_o: ::std::option::Option<RxDiag>,
}

impl crate::prelude::Show for RxState {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("RxState", &[("s", &self.s_p), ("i", &self.i_p), ("open", &self.open_p), ("groups", &self.groups_p), ("names", &self.names_p), ("err", &self.err_o)]);
    }
}

impl crate::prelude::ToPod for RxState {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("RxState", vec![("s", self.s_p.to_pod()), ("i", self.i_p.to_pod()), ("open", self.open_p.to_pod()), ("groups", self.groups_p.to_pod()), ("names", self.names_p.to_pod()), ("err", self.err_o.to_pod())])
    }
}

impl crate::prelude::FromPod for RxState {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(RxState { s_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "s")?)?, i_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "i")?)?, open_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "open")?)?, groups_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "groups")?)?, names_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "names")?)?, err_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "err")?)? })
    }
}

/// ```prism
/// let rxUnknownFlag
/// ```
pub fn rx_unknown_flag_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("an unknown flag: the flags are i, m and s")
}

/// ```prism
/// let rxFlagTwice
/// ```
pub fn rx_flag_twice_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a flag written twice")
}

/// ```prism
/// let rxStrayBracket
/// ```
pub fn rx_stray_bracket_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a ] outside a class: a literal one is \\]")
}

/// ```prism
/// let rxStrayBrace
/// ```
pub fn rx_stray_brace_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a } outside a count: a literal one is \\}")
}

/// ```prism
/// let rxTrailingBackslash
/// ```
pub fn rx_trailing_backslash_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a \\ at the end of the pattern")
}

/// ```prism
/// let rxHexTwo
/// ```
pub fn rx_hex_two_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a \\x escape needs two hex digits or braces")
}

/// ```prism
/// let rxHexBraces
/// ```
pub fn rx_hex_braces_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a \\x{...} escape needs one to six hex digits")
}

/// ```prism
/// let rxHexNoChar
/// ```
pub fn rx_hex_no_char_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a \\x escape names no character: a surrogate or past U+10FFFF")
}

/// ```prism
/// let rxWordBraces
/// ```
pub fn rx_word_braces_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("\\b{...} is Rust\'s only: write \\b")
}

/// ```prism
/// let rxAngle
/// ```
pub fn rx_angle_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("\\< and \\> are Rust\'s only: write \\b")
}

/// ```prism
/// let rxBackreference
/// ```
pub fn rx_backreference_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a backreference: refused so that every match is linear in its text")
}

/// ```prism
/// let rxOctal
/// ```
pub fn rx_octal_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("an octal escape is RE2\'s only: write \\x")
}

/// ```prism
/// let rxQuote
/// ```
pub fn rx_quote_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("\\Q...\\E is RE2\'s only: escape each character")
}

/// ```prism
/// let rxOneByte
/// ```
pub fn rx_one_byte_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("\\C, one byte, is RE2\'s only")
}

/// ```prism
/// let rxUnknownEscape
/// ```
pub fn rx_unknown_escape_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("an unknown escape")
}

/// ```prism
/// let rxPropertyName
/// ```
pub fn rx_property_name_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a \\p escape needs a property name")
}

/// ```prism
/// let rxPropertyOpen
/// ```
pub fn rx_property_open_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a \\p{ that is never closed")
}

/// ```prism
/// let rxPropertyNegated
/// ```
pub fn rx_property_negated_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a negated property is written \\P{...}")
}

/// ```prism
/// let rxPropertyRefused
/// ```
pub fn rx_property_refused_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("the property is refused: RE2 and Rust disagree on C, Cn, Cs and LC")
}

/// ```prism
/// let rxPropertyUnknown
/// ```
pub fn rx_property_unknown_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("an unknown property: general categories by short name, scripts and Any")
}

/// ```prism
/// let rxClassOpen
/// ```
pub fn rx_class_open_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a class opened here is never closed")
}

/// ```prism
/// let rxClassFirstBracket
/// ```
pub fn rx_class_first_bracket_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a ] first in a class: write \\]")
}

/// ```prism
/// let rxClassNested
/// ```
pub fn rx_class_nested_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a [ inside a class: write \\[ (nested classes are Rust\'s only)")
}

/// ```prism
/// let rxClassAsciiUnknown
/// ```
pub fn rx_class_ascii_unknown_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("an unknown ASCII class")
}

/// ```prism
/// let rxClassSetOperation
/// ```
pub fn rx_class_set_operation_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("&&, ~~ and -- in a class are Rust\'s set operations: escape them")
}

/// ```prism
/// let rxClassDash
/// ```
pub fn rx_class_dash_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a - in a class that is neither a range nor first or last: write \\-")
}

/// ```prism
/// let rxClassOrder
/// ```
pub fn rx_class_order_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a range whose ends are out of order")
}

/// ```prism
/// let rxClassRangeSet
/// ```
pub fn rx_class_range_set_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a range end that is a class")
}

/// ```prism
/// let rxClassNegatedUnderI
/// ```
pub fn rx_class_negated_under_i_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a negated class inside a class under i: write it outside the class")
}

/// ```prism
/// let rxClassEscape
/// ```
pub fn rx_class_escape_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("an escape that a class cannot hold")
}

/// ```prism
/// let rxLookaround
/// ```
pub fn rx_lookaround_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a lookaround: refused so that every match is linear in its text")
}

/// ```prism
/// let rxUnknownGroup
/// ```
pub fn rx_unknown_group_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("an unknown group: the groups are (re), (?:re), (?<name>re), (?P<name>re) and the flag groups")
}

/// ```prism
/// let rxNameShape
/// ```
pub fn rx_name_shape_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a group name is a lowercase value name, [a-z_][a-z0-9_]*")
}

/// ```prism
/// let rxNameOpen
/// ```
pub fn rx_name_open_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a group name that is never closed")
}

/// ```prism
/// let rxNameTwice
/// ```
pub fn rx_name_twice_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a group name used twice")
}

/// ```prism
/// let rxGroupOpen
/// ```
pub fn rx_group_open_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a group opened here is never closed")
}

/// ```prism
/// let rxGroupClose
/// ```
pub fn rx_group_close_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a ) that closes no group")
}

/// ```prism
/// let rxFlagsEmpty
/// ```
pub fn rx_flags_empty_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("an empty flag group")
}

/// ```prism
/// let rxFlagsSecondDash
/// ```
pub fn rx_flags_second_dash_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a second - in a flag group")
}

/// ```prism
/// let rxFlagsDash
/// ```
pub fn rx_flags_dash_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a - that turns off no flag")
}

/// ```prism
/// let rxBrace
/// ```
pub fn rx_brace_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a brace that opens no count: a literal one is \\{")
}

/// ```prism
/// let rxCountZero
/// ```
pub fn rx_count_zero_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a count with a leading zero")
}

/// ```prism
/// let rxCountBound
/// ```
pub fn rx_count_bound_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a count above 1000")
}

/// ```prism
/// let rxCountOrder
/// ```
pub fn rx_count_order_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a count whose minimum exceeds its maximum")
}

/// ```prism
/// let rxNothingToRepeat
/// ```
pub fn rx_nothing_to_repeat_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a repetition with nothing to repeat")
}

/// ```prism
/// let rxRepeatRepeat
/// ```
pub fn rx_repeat_repeat_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a repetition of a repetition: write (?:a*)* to say it")
}

/// ```prism
/// let rxRepeatAssertion
/// ```
pub fn rx_repeat_assertion_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a repetition of an assertion")
}

/// ```prism
/// let rxProduct
/// ```
pub fn rx_product_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("nested counts multiplying past 1000")
}

/// ```prism
/// let rxNesting
/// ```
pub fn rx_nesting_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("groups and repetitions nested more than 100 deep")
}

/// ```prism
/// let rxSize
/// ```
pub fn rx_size_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("the pattern expands past 10,000 atoms")
}

/// ```prism
/// let rxRZero
/// ```
pub fn rx_rzero_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a group number with a leading zero")
}

/// ```prism
/// let rxRBraces
/// ```
pub fn rx_rbraces_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a ${...} that is neither a group number nor a group name")
}

/// ```prism
/// let rxRDollar
/// ```
pub fn rx_rdollar_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a $ that is not $n, ${n}, ${name} or $$")
}

/// ```prism
/// let rxRNoNumber
/// ```
pub fn rx_rno_number_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("the pattern has no group of that number")
}

/// ```prism
/// let rxRNoName
/// ```
pub fn rx_rno_name_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("the pattern has no group of that name")
}

/// ```prism
/// let rxRUnicode
/// ```
pub fn rx_runicode_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a \\u{...} escape needs one to six hex digits naming a character")
}

/// ```prism
/// let rxREscape
/// ```
pub fn rx_rescape_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("an unknown escape in a replacement: the escapes are \\\\, \\n, \\t, \\u{hex} and \\/")
}

/// ```prism
/// let rxCategories
/// ```
pub fn rx_categories_p() -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::Array::from(vec![crate::prelude::Text::lit("Cc"), crate::prelude::Text::lit("Cf"), crate::prelude::Text::lit("Co"), crate::prelude::Text::lit("L"), crate::prelude::Text::lit("Ll"), crate::prelude::Text::lit("Lm"), crate::prelude::Text::lit("Lo"), crate::prelude::Text::lit("Lt"), crate::prelude::Text::lit("Lu"), crate::prelude::Text::lit("M"), crate::prelude::Text::lit("Mc"), crate::prelude::Text::lit("Me"), crate::prelude::Text::lit("Mn"), crate::prelude::Text::lit("N"), crate::prelude::Text::lit("Nd"), crate::prelude::Text::lit("Nl"), crate::prelude::Text::lit("No"), crate::prelude::Text::lit("P"), crate::prelude::Text::lit("Pc"), crate::prelude::Text::lit("Pd"), crate::prelude::Text::lit("Pe"), crate::prelude::Text::lit("Pf"), crate::prelude::Text::lit("Pi"), crate::prelude::Text::lit("Po"), crate::prelude::Text::lit("Ps"), crate::prelude::Text::lit("S"), crate::prelude::Text::lit("Sc"), crate::prelude::Text::lit("Sk"), crate::prelude::Text::lit("Sm"), crate::prelude::Text::lit("So"), crate::prelude::Text::lit("Z"), crate::prelude::Text::lit("Zl"), crate::prelude::Text::lit("Zp"), crate::prelude::Text::lit("Zs")])
}

/// ```prism
/// let rxScripts
/// ```
pub fn rx_scripts_p() -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::Array::from(vec![crate::prelude::Text::lit("Adlam"), crate::prelude::Text::lit("Ahom"), crate::prelude::Text::lit("Anatolian_Hieroglyphs"), crate::prelude::Text::lit("Arabic"), crate::prelude::Text::lit("Armenian"), crate::prelude::Text::lit("Avestan"), crate::prelude::Text::lit("Balinese"), crate::prelude::Text::lit("Bamum"), crate::prelude::Text::lit("Bassa_Vah"), crate::prelude::Text::lit("Batak"), crate::prelude::Text::lit("Bengali"), crate::prelude::Text::lit("Bhaiksuki"), crate::prelude::Text::lit("Bopomofo"), crate::prelude::Text::lit("Brahmi"), crate::prelude::Text::lit("Braille"), crate::prelude::Text::lit("Buginese"), crate::prelude::Text::lit("Buhid"), crate::prelude::Text::lit("Canadian_Aboriginal"), crate::prelude::Text::lit("Carian"), crate::prelude::Text::lit("Caucasian_Albanian"), crate::prelude::Text::lit("Chakma"), crate::prelude::Text::lit("Cham"), crate::prelude::Text::lit("Cherokee"), crate::prelude::Text::lit("Chorasmian"), crate::prelude::Text::lit("Common"), crate::prelude::Text::lit("Coptic"), crate::prelude::Text::lit("Cuneiform"), crate::prelude::Text::lit("Cypriot"), crate::prelude::Text::lit("Cypro_Minoan"), crate::prelude::Text::lit("Cyrillic"), crate::prelude::Text::lit("Deseret"), crate::prelude::Text::lit("Devanagari"), crate::prelude::Text::lit("Dives_Akuru"), crate::prelude::Text::lit("Dogra"), crate::prelude::Text::lit("Duployan"), crate::prelude::Text::lit("Egyptian_Hieroglyphs"), crate::prelude::Text::lit("Elbasan"), crate::prelude::Text::lit("Elymaic"), crate::prelude::Text::lit("Ethiopic"), crate::prelude::Text::lit("Georgian"), crate::prelude::Text::lit("Glagolitic"), crate::prelude::Text::lit("Gothic"), crate::prelude::Text::lit("Grantha"), crate::prelude::Text::lit("Greek"), crate::prelude::Text::lit("Gujarati"), crate::prelude::Text::lit("Gunjala_Gondi"), crate::prelude::Text::lit("Gurmukhi"), crate::prelude::Text::lit("Han"), crate::prelude::Text::lit("Hangul"), crate::prelude::Text::lit("Hanifi_Rohingya"), crate::prelude::Text::lit("Hanunoo"), crate::prelude::Text::lit("Hatran"), crate::prelude::Text::lit("Hebrew"), crate::prelude::Text::lit("Hiragana"), crate::prelude::Text::lit("Imperial_Aramaic"), crate::prelude::Text::lit("Inherited"), crate::prelude::Text::lit("Inscriptional_Pahlavi"), crate::prelude::Text::lit("Inscriptional_Parthian"), crate::prelude::Text::lit("Javanese"), crate::prelude::Text::lit("Kaithi"), crate::prelude::Text::lit("Kannada"), crate::prelude::Text::lit("Katakana"), crate::prelude::Text::lit("Kawi"), crate::prelude::Text::lit("Kayah_Li"), crate::prelude::Text::lit("Kharoshthi"), crate::prelude::Text::lit("Khitan_Small_Script"), crate::prelude::Text::lit("Khmer"), crate::prelude::Text::lit("Khojki"), crate::prelude::Text::lit("Khudawadi"), crate::prelude::Text::lit("Lao"), crate::prelude::Text::lit("Latin"), crate::prelude::Text::lit("Lepcha"), crate::prelude::Text::lit("Limbu"), crate::prelude::Text::lit("Linear_A"), crate::prelude::Text::lit("Linear_B"), crate::prelude::Text::lit("Lisu"), crate::prelude::Text::lit("Lycian"), crate::prelude::Text::lit("Lydian"), crate::prelude::Text::lit("Mahajani"), crate::prelude::Text::lit("Makasar"), crate::prelude::Text::lit("Malayalam"), crate::prelude::Text::lit("Mandaic"), crate::prelude::Text::lit("Manichaean"), crate::prelude::Text::lit("Marchen"), crate::prelude::Text::lit("Masaram_Gondi"), crate::prelude::Text::lit("Medefaidrin"), crate::prelude::Text::lit("Meetei_Mayek"), crate::prelude::Text::lit("Mende_Kikakui"), crate::prelude::Text::lit("Meroitic_Cursive"), crate::prelude::Text::lit("Meroitic_Hieroglyphs"), crate::prelude::Text::lit("Miao"), crate::prelude::Text::lit("Modi"), crate::prelude::Text::lit("Mongolian"), crate::prelude::Text::lit("Mro"), crate::prelude::Text::lit("Multani"), crate::prelude::Text::lit("Myanmar"), crate::prelude::Text::lit("Nabataean"), crate::prelude::Text::lit("Nag_Mundari"), crate::prelude::Text::lit("Nandinagari"), crate::prelude::Text::lit("New_Tai_Lue"), crate::prelude::Text::lit("Newa"), crate::prelude::Text::lit("Nko"), crate::prelude::Text::lit("Nushu"), crate::prelude::Text::lit("Nyiakeng_Puachue_Hmong"), crate::prelude::Text::lit("Ogham"), crate::prelude::Text::lit("Ol_Chiki"), crate::prelude::Text::lit("Old_Hungarian"), crate::prelude::Text::lit("Old_Italic"), crate::prelude::Text::lit("Old_North_Arabian"), crate::prelude::Text::lit("Old_Permic"), crate::prelude::Text::lit("Old_Persian"), crate::prelude::Text::lit("Old_Sogdian"), crate::prelude::Text::lit("Old_South_Arabian"), crate::prelude::Text::lit("Old_Turkic"), crate::prelude::Text::lit("Old_Uyghur"), crate::prelude::Text::lit("Oriya"), crate::prelude::Text::lit("Osage"), crate::prelude::Text::lit("Osmanya"), crate::prelude::Text::lit("Pahawh_Hmong"), crate::prelude::Text::lit("Palmyrene"), crate::prelude::Text::lit("Pau_Cin_Hau"), crate::prelude::Text::lit("Phags_Pa"), crate::prelude::Text::lit("Phoenician"), crate::prelude::Text::lit("Psalter_Pahlavi"), crate::prelude::Text::lit("Rejang"), crate::prelude::Text::lit("Runic"), crate::prelude::Text::lit("Samaritan"), crate::prelude::Text::lit("Saurashtra"), crate::prelude::Text::lit("Sharada"), crate::prelude::Text::lit("Shavian"), crate::prelude::Text::lit("Siddham"), crate::prelude::Text::lit("SignWriting"), crate::prelude::Text::lit("Sinhala"), crate::prelude::Text::lit("Sogdian"), crate::prelude::Text::lit("Sora_Sompeng"), crate::prelude::Text::lit("Soyombo"), crate::prelude::Text::lit("Sundanese"), crate::prelude::Text::lit("Syloti_Nagri"), crate::prelude::Text::lit("Syriac"), crate::prelude::Text::lit("Tagalog"), crate::prelude::Text::lit("Tagbanwa"), crate::prelude::Text::lit("Tai_Le"), crate::prelude::Text::lit("Tai_Tham"), crate::prelude::Text::lit("Tai_Viet"), crate::prelude::Text::lit("Takri"), crate::prelude::Text::lit("Tamil"), crate::prelude::Text::lit("Tangsa"), crate::prelude::Text::lit("Tangut"), crate::prelude::Text::lit("Telugu"), crate::prelude::Text::lit("Thaana"), crate::prelude::Text::lit("Thai"), crate::prelude::Text::lit("Tibetan"), crate::prelude::Text::lit("Tifinagh"), crate::prelude::Text::lit("Tirhuta"), crate::prelude::Text::lit("Toto"), crate::prelude::Text::lit("Ugaritic"), crate::prelude::Text::lit("Vai"), crate::prelude::Text::lit("Vithkuqi"), crate::prelude::Text::lit("Wancho"), crate::prelude::Text::lit("Warang_Citi"), crate::prelude::Text::lit("Yezidi"), crate::prelude::Text::lit("Yi"), crate::prelude::Text::lit("Zanabazar_Square")])
}

/// ```prism
/// let rxProperties
/// ```
pub fn rx_properties_p() -> crate::prelude::Map<crate::prelude::Text, bool> {
    crate::prelude::map(&crate::prelude::each(&crate::prelude::push(&crate::prelude::append(&rx_categories_p(), &rx_scripts_p()), &crate::prelude::Text::lit("Any")), &(|n_p0: &crate::prelude::Text| (n_p0.clone(), true))))
}

/// ```prism
/// let rxAsciiClasses
/// ```
pub fn rx_ascii_classes_p() -> crate::prelude::Map<crate::prelude::Text, bool> {
    crate::prelude::map(&crate::prelude::each(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("alnum"), crate::prelude::Text::lit("alpha"), crate::prelude::Text::lit("ascii"), crate::prelude::Text::lit("blank"), crate::prelude::Text::lit("cntrl"), crate::prelude::Text::lit("digit"), crate::prelude::Text::lit("graph"), crate::prelude::Text::lit("lower"), crate::prelude::Text::lit("print"), crate::prelude::Text::lit("punct"), crate::prelude::Text::lit("space"), crate::prelude::Text::lit("upper"), crate::prelude::Text::lit("word"), crate::prelude::Text::lit("xdigit")]), &(|n_p0: &crate::prelude::Text| (n_p0.clone(), true))))
}

/// ```prism
/// let rxAscii
/// ```
pub fn rx_ascii_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("\0\t\n\r !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")
}

/// ```prism
/// let rxPunctuation
/// ```
pub fn rx_punctuation_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("!\"#$%&\'()*+,-./:;=?@[\\]^_`{|}~")
}

/// ```prism
/// let rxNone
/// ```
pub fn rx_none_p() -> RxMeasure {
    RxMeasure { depth_p: crate::prelude::Nat::from(0u32), size_p: crate::prelude::Nat::from(0u32), product_p: crate::prelude::Nat::from(0u32) }
}

/// ```prism
/// let rxAtom
/// ```
pub fn rx_atom_p() -> RxMeasure {
    RxMeasure { depth_p: crate::prelude::Nat::from(0u32), size_p: crate::prelude::Nat::from(1u32), product_p: crate::prelude::Nat::from(1u32) }
}

/// ```prism
/// RxThen: fn RxMeasure, RxMeasure -> RxMeasure
/// ```
pub fn rx_then_f(a_p0: &RxMeasure, b_p1: &RxMeasure) -> RxMeasure {
    RxMeasure { depth_p: crate::prelude::max(&a_p0.depth_p, &b_p1.depth_p), size_p: &a_p0.size_p + &b_p1.size_p, product_p: crate::prelude::max(&a_p0.product_p, &b_p1.product_p) }
}

/// ```prism
/// RxBad: fn RxState -> Bool
/// ```
pub fn rx_bad_f(st_p0: &RxState) -> bool {
    &st_p0.err_o != &::std::option::Option::None
}

/// ```prism
/// RxFail: fn RxState, Nat, Text -> RxState
/// ```
pub fn rx_fail_f(st_p0: &RxState, at_p1: &crate::prelude::Nat, message_p2: &crate::prelude::Text) -> RxState {
    if rx_bad_f(st_p0) {
        st_p0.clone()
    } else {
        RxState { s_p: st_p0.s_p.clone(), i_p: st_p0.i_p.clone(), open_p: st_p0.open_p.clone(), groups_p: st_p0.groups_p.clone(), names_p: st_p0.names_p.clone(), err_o: ::std::option::Option::Some(RxDiag { part_p: crate::prelude::Text::lit("pattern"), at_p: at_p1.clone(), message_p: message_p2.clone() }) }
    }
}

/// ```prism
/// RxGo: fn RxState, Nat -> RxState
/// ```
pub fn rx_go_f(st_p0: &RxState, n_p1: &crate::prelude::Nat) -> RxState {
    let mut this: RxState = st_p0.clone();
    this.i_p = n_p1.clone();
    this
}

/// ```prism
/// RxPeek: fn RxState -> Text
/// ```
pub fn rx_peek_f(st_p0: &RxState) -> crate::prelude::Text {
    rx_char_at_f(&st_p0.s_p, &st_p0.i_p)
}

/// ```prism
/// RxCharAt: fn Text, Nat -> Text
/// ```
pub fn rx_char_at_f(t_p0: &crate::prelude::Text, n_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    match crate::prelude::cursor_at(t_p0, n_p1) {
        ::std::option::Option::Some(c_p2) => match crate::prelude::step(&crate::prelude::front(&crate::prelude::after(&c_p2))) {
            ::std::option::Option::Some((_, one_p3)) => crate::prelude::before(&one_p3),
            ::std::option::Option::None => crate::prelude::Text::lit(""),
        },
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// RxSlice: fn Text, Nat, Nat -> Text
/// ```
pub fn rx_slice_f(t_p0: &crate::prelude::Text, a_p1: &crate::prelude::Nat, b_p2: &crate::prelude::Nat) -> crate::prelude::Text {
    match crate::prelude::cursor_at(t_p0, b_p2) {
        ::std::option::Option::Some(cb_p3) => match crate::prelude::cursor_at(&crate::prelude::before(&cb_p3), a_p1) {
            ::std::option::Option::Some(ca_p4) => crate::prelude::after(&ca_p4),
            ::std::option::Option::None => crate::prelude::Text::lit(""),
        },
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// ?RxFind: fn Text, Nat, Text -> ?Nat
/// ```
pub fn rx_find_o(t_p0: &crate::prelude::Text, from_p1: &crate::prelude::Nat, x_p2: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Nat> {
    match crate::prelude::cursor_at(t_p0, from_p1) {
        ::std::option::Option::None => ::std::option::Option::None,
        ::std::option::Option::Some(c0_p3) => {
            let (found_o7, _) = {
                let mut this: (::std::option::Option<crate::prelude::Nat>, crate::prelude::Cursor) = (::std::option::Option::None, c0_p3.clone());
                let mut c_p4: crate::prelude::Cursor = c0_p3.clone();
                let mut found_o5: ::std::option::Option<crate::prelude::Nat> = ::std::option::Option::None;
                while let ::std::option::Option::Some((_, next_p6)) = crate::prelude::step(&c_p4) {
                    if !(&found_o5 == &::std::option::Option::None) {
                        break;
                    }
                    if &rx_slice_f(t_p0, &crate::prelude::at(&c_p4), &crate::prelude::at(&next_p6)) == x_p2 {
                        found_o5 = ::std::option::Option::Some(crate::prelude::at(&c_p4));
                    }
                    c_p4 = next_p6.clone();
                }
                this = (found_o5.clone(), c_p4.clone());
                this
            };
            found_o7.clone()
        },
    }
}

/// ```prism
/// RxIn: fn Text, Text -> Bool
/// ```
pub fn rx_in_f(set_p0: &crate::prelude::Text, c_p1: &crate::prelude::Text) -> bool {
    (c_p1 != &crate::prelude::Text::lit("")) && (&rx_find_o(set_p0, &crate::prelude::Nat::from(0u32), c_p1) != &::std::option::Option::None)
}

/// ```prism
/// RxIsDigit: fn Text -> Bool
/// ```
pub fn rx_is_digit_f(c_p0: &crate::prelude::Text) -> bool {
    ((&crate::prelude::Text::lit("0") <= c_p0) && (c_p0 <= &crate::prelude::Text::lit("9"))) && (&crate::prelude::len_text(c_p0) == &crate::prelude::Nat::from(1u32))
}

/// ```prism
/// RxIsLetter: fn Text -> Bool
/// ```
pub fn rx_is_letter_f(c_p0: &crate::prelude::Text) -> bool {
    ((&crate::prelude::Text::lit("a") <= c_p0) && (c_p0 <= &crate::prelude::Text::lit("z"))) || ((&crate::prelude::Text::lit("A") <= c_p0) && (c_p0 <= &crate::prelude::Text::lit("Z")))
}

/// ```prism
/// RxIsHex: fn Text -> Bool
/// ```
pub fn rx_is_hex_f(c_p0: &crate::prelude::Text) -> bool {
    (rx_is_digit_f(c_p0) || ((&crate::prelude::Text::lit("a") <= c_p0) && (c_p0 <= &crate::prelude::Text::lit("f")))) || ((&crate::prelude::Text::lit("A") <= c_p0) && (c_p0 <= &crate::prelude::Text::lit("F")))
}

/// ```prism
/// RxIsName: fn Text -> Bool
/// ```
pub fn rx_is_name_f(t_p0: &crate::prelude::Text) -> bool {
    let first_p1 = rx_char_at_f(t_p0, &crate::prelude::Nat::from(0u32));
    ((t_p0 != &crate::prelude::Text::lit("")) && (((&crate::prelude::Text::lit("a") <= &first_p1) && (&first_p1 <= &crate::prelude::Text::lit("z"))) || (&first_p1 == &crate::prelude::Text::lit("_")))) && rx_all_f(t_p0, &(::std::rc::Rc::new(move |p0: crate::prelude::Text| crate::prelude::once_job(move || {
        let c_p2 = p0;
        ::prism_rtl::Turn::Finished((((&crate::prelude::Text::lit("a") <= &c_p2) && (&c_p2 <= &crate::prelude::Text::lit("z"))) || rx_is_digit_f(&c_p2)) || (&c_p2 == &crate::prelude::Text::lit("_")))
    })) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>))
}

/// ```prism
/// RxAll: fn Text, (fn Text -> Bool) -> Bool
/// ```
pub fn rx_all_f(t_p0: &crate::prelude::Text, p_f1: &::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>) -> bool {
    let mut this: bool = true;
    let mut c_p2: crate::prelude::Cursor = crate::prelude::front(t_p0);
    while let ::std::option::Option::Some((_, next_p3)) = crate::prelude::step(&c_p2) {
        if !crate::prelude::run_to_end(p_f1(rx_slice_f(t_p0, &crate::prelude::at(&c_p2), &crate::prelude::at(&next_p3)))) {
            this = false;
        }
        c_p2 = next_p3.clone();
    }
    this
}

/// The step machine of `RxAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxAll: fn Text, (fn Text -> Bool) -> Bool
/// ```
pub struct RxAll {
    pub t_p0: crate::prelude::Text,
    pub p_f1: ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>,
}

impl ::prism_rtl::Job<bool> for RxAll {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        let p_f1 = &self.p_f1;
        ::prism_rtl::Turn::Finished({
            let mut this: bool = true;
            let mut c_p2: crate::prelude::Cursor = crate::prelude::front(t_p0);
            while let ::std::option::Option::Some((_, next_p3)) = crate::prelude::step(&c_p2) {
                if !crate::prelude::run_to_end(p_f1(rx_slice_f(t_p0, &crate::prelude::at(&c_p2), &crate::prelude::at(&next_p3)))) {
                    this = false;
                }
                c_p2 = next_p3.clone();
            }
            this
        })
    }
}

/// `Start RxAll, x`: what the function value is when passed to `@Run`.
pub fn start_rx_all_f(t_p0: crate::prelude::Text, p_f1: ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(RxAll { t_p0, p_f1 })
}

/// ```prism
/// RxSpanEnd: unbounded fn Text, Nat, (fn Text -> Bool) -> Nat
/// ```
pub fn rx_span_end_f(t_p0: &crate::prelude::Text, at_p1: &crate::prelude::Nat, p_f2: &::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>) -> crate::prelude::Nat {
    let mut this: crate::prelude::Nat = at_p1.clone();
    while crate::prelude::run_to_end(p_f2(rx_char_at_f(t_p0, &this))) {
        this = &this + &crate::prelude::Nat::from(1u32);
    }
    this
}

/// The step machine of `RxSpanEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxSpanEnd: unbounded fn Text, Nat, (fn Text -> Bool) -> Nat
/// ```
pub struct RxSpanEnd {
    pub t_p0: crate::prelude::Text,
    pub at_p1: crate::prelude::Nat,
    pub p_f2: ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>,
}

impl ::prism_rtl::Job<crate::prelude::Nat> for RxSpanEnd {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Nat> {
        let t_p0 = &self.t_p0;
        let at_p1 = &self.at_p1;
        let p_f2 = &self.p_f2;
        let mut this: crate::prelude::Nat = at_p1.clone();
        crate::prelude::call_then(crate::prelude::loop_job((this,), {
            let p_f2x = p_f2.clone();
            let t_p0x = t_p0.clone();
            move |(mut this,): (crate::prelude::Nat,)| if crate::prelude::run_to_end((&p_f2x)(rx_char_at_f(&t_p0x, &this))) {
                {
                    this = &this + &crate::prelude::Nat::from(1u32);
                    ::std::result::Result::Ok((this,))
                }
            } else {
                ::std::result::Result::Err((this,))
            }
        }), move |(mut this,): (crate::prelude::Nat,)| ::prism_rtl::Turn::Finished(this))
    }
}

/// `Start RxSpanEnd, x`: what the function value is when passed to `@Run`.
pub fn start_rx_span_end_f(t_p0: crate::prelude::Text, at_p1: crate::prelude::Nat, p_f2: ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Nat>> {
    ::std::rc::Rc::new(RxSpanEnd { t_p0, at_p1, p_f2 })
}

/// ```prism
/// RxHexValue: fn Text -> Nat
/// ```
pub fn rx_hex_value_f(t_p0: &crate::prelude::Text) -> crate::prelude::Nat {
    let mut this: crate::prelude::Nat = crate::prelude::Nat::from(0u32);
    let mut c_p1: crate::prelude::Cursor = crate::prelude::front(t_p0);
    while let ::std::option::Option::Some((_, next_p2)) = crate::prelude::step(&c_p1) {
        let d_p3 = rx_slice_f(t_p0, &crate::prelude::at(&c_p1), &crate::prelude::at(&next_p2));
        this = &(&this * &crate::prelude::Nat::from(16u32)) + &crate::prelude::or(&rx_find_o(&crate::prelude::Text::lit("0123456789abcdef"), &crate::prelude::Nat::from(0u32), &crate::prelude::lower(&d_p3)), &crate::prelude::Nat::from(0u32));
        c_p1 = next_p2.clone();
    }
    this
}

/// ```prism
/// RxCpOf: fn Nat -> RxCp
/// ```
pub fn rx_cp_of_f(v_p0: &crate::prelude::Nat) -> RxCp {
    if v_p0 < &crate::prelude::Nat::from(128u32) {
        RxCp::RxLit(rx_char_at_f(&rx_ascii_p(), v_p0))
    } else {
        RxCp::RxNum(v_p0.clone())
    }
}

/// ```prism
/// RxWidth: fn Nat -> Nat
/// ```
pub fn rx_width_f(v_p0: &crate::prelude::Nat) -> crate::prelude::Nat {
    if v_p0 < &crate::prelude::Nat::from(128u32) {
        crate::prelude::Nat::from(1u32)
    } else {
        if v_p0 < &crate::prelude::Nat::from(2048u32) {
            crate::prelude::Nat::from(2u32)
        } else {
            if v_p0 < &crate::prelude::Nat::from(65536u32) {
                crate::prelude::Nat::from(3u32)
            } else {
                crate::prelude::Nat::from(4u32)
            }
        }
    }
}

/// ```prism
/// RxPast: fn RxCp, RxCp -> Bool
/// ```
pub fn rx_past_f(rx_cp0: &RxCp, rx_cp1: &RxCp) -> bool {
    match (rx_cp0, rx_cp1) {
        (RxCp::RxLit(a_p0), RxCp::RxLit(b_p1)) => a_p0 > b_p1,
        (RxCp::RxNum(a_p2), RxCp::RxNum(b_p3)) => a_p2 > b_p3,
        (RxCp::RxLit(a_p4), RxCp::RxNum(b_p5)) => if &crate::prelude::len_text(a_p4) != &rx_width_f(b_p5) {
            &crate::prelude::len_text(a_p4) > &rx_width_f(b_p5)
        } else {
            !rx_in_range_f(a_p4, &crate::prelude::Nat::from(0u32), b_p5)
        },
        (RxCp::RxNum(a_p6), RxCp::RxLit(b_p7)) => if &rx_width_f(a_p6) != &crate::prelude::len_text(b_p7) {
            &rx_width_f(a_p6) > &crate::prelude::len_text(b_p7)
        } else {
            !rx_in_range_f(b_p7, a_p6, &crate::prelude::Nat::from(1114111u32))
        },
    }
}

/// ```prism
/// RxInRange: fn Text, Nat, Nat -> Bool
/// ```
pub fn rx_in_range_f(c_p0: &crate::prelude::Text, lo_p1: &crate::prelude::Nat, hi_p2: &crate::prelude::Nat) -> bool {
    match crate::prelude::regex(&crate::prelude::Text::from(format!("[\\x{{{}}}-\\x{{{}}}]", &rx_hex_text_f(lo_p1), &rx_hex_text_f(hi_p2)))) {
        ::std::option::Option::Some(r_p3) => &crate::prelude::find(&r_p3, c_p0) != &::std::option::Option::None,
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// RxHexText: fn Nat -> Text
/// ```
pub fn rx_hex_text_f(n_p0: &crate::prelude::Nat) -> crate::prelude::Text {
    let mut this: crate::prelude::Text = crate::prelude::Text::lit("");
    let mut k_p1: crate::prelude::Nat = n_p0.clone();
    let mut fuel_p2: crate::prelude::Nat = crate::prelude::Nat::from(6u32);
    while let ::std::option::Option::Some(left_p3) = (&fuel_p2).checked_sub(&crate::prelude::Nat::from(1u32)) {
        fuel_p2 = left_p3.clone();
        this = crate::prelude::Text::from(format!("{}{}", &rx_char_at_f(&crate::prelude::Text::lit("0123456789abcdef"), &crate::prelude::or(&crate::prelude::mod_(&k_p1, &crate::prelude::Nat::from(16u32)), &crate::prelude::Nat::from(0u32))), &this));
        k_p1 = crate::prelude::or(&crate::prelude::div(&k_p1, &crate::prelude::Nat::from(16u32)), &crate::prelude::Nat::from(0u32));
    }
    this
}

/// ```prism
/// ?RegexRefusal: unbounded fn Text, Text, ?Text -> ?RxDiag
/// ```
pub fn regex_refusal_o(pattern_p0: &crate::prelude::Text, flags_p1: &crate::prelude::Text, replacement_o2: &::std::option::Option<crate::prelude::Text>) -> ::std::option::Option<RxDiag> {
    match rx_flags_refusal_o(flags_p1) {
        ::std::option::Option::Some(d_p3) => ::std::option::Option::Some(d_p3),
        ::std::option::Option::None => {
            let st0_p4 = RxState { s_p: pattern_p0.clone(), i_p: crate::prelude::Nat::from(0u32), open_p: crate::prelude::Nat::from(0u32), groups_p: crate::prelude::Nat::from(0u32), names_p: crate::prelude::Map::new(), err_o: ::std::option::Option::None };
            let (m_p5, st_p6) = rx_alternation_f(&st0_p4, &(&rx_find_o(flags_p1, &crate::prelude::Nat::from(0u32), &crate::prelude::Text::lit("i")) != &::std::option::Option::None));
            match &st_p6.err_o {
                ::std::option::Option::Some(d_p7) => ::std::option::Option::Some(d_p7.clone()),
                ::std::option::Option::None => if &st_p6.i_p < &crate::prelude::len_text(pattern_p0) {
                    ::std::option::Option::Some(RxDiag { part_p: crate::prelude::Text::lit("pattern"), at_p: st_p6.i_p.clone(), message_p: rx_group_close_p() })
                } else {
                    if &m_p5.depth_p > &crate::prelude::Nat::from(100u32) {
                        ::std::option::Option::Some(RxDiag { part_p: crate::prelude::Text::lit("pattern"), at_p: crate::prelude::Nat::from(0u32), message_p: rx_nesting_p() })
                    } else {
                        if &m_p5.size_p > &crate::prelude::Nat::from(10000u32) {
                            ::std::option::Option::Some(RxDiag { part_p: crate::prelude::Text::lit("pattern"), at_p: crate::prelude::Nat::from(0u32), message_p: rx_size_p() })
                        } else {
                            match replacement_o2 {
                                ::std::option::Option::None => ::std::option::Option::None,
                                ::std::option::Option::Some(r_p8) => rx_replacement_refusal_o(r_p8, &st_p6.groups_p, &st_p6.names_p),
                            }
                        }
                    }
                },
            }
        },
    }
}

/// The step machine of `RegexRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RegexRefusal: unbounded fn Text, Text, ?Text -> ?RxDiag
/// ```
pub struct RegexRefusal {
    pub pattern_p0: crate::prelude::Text,
    pub flags_p1: crate::prelude::Text,
    pub replacement_o2: ::std::option::Option<crate::prelude::Text>,
}

impl ::prism_rtl::Job<::std::option::Option<RxDiag>> for RegexRefusal {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<RxDiag>> {
        let pattern_p0 = &self.pattern_p0;
        let flags_p1 = &self.flags_p1;
        let replacement_o2 = &self.replacement_o2;
        match rx_flags_refusal_o(flags_p1) {
            ::std::option::Option::Some(d_p3) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(d_p3.clone())),
            ::std::option::Option::None => {
                let st0_p4 = RxState { s_p: pattern_p0.clone(), i_p: crate::prelude::Nat::from(0u32), open_p: crate::prelude::Nat::from(0u32), groups_p: crate::prelude::Nat::from(0u32), names_p: crate::prelude::Map::new(), err_o: ::std::option::Option::None };
                let replacement_o2x = replacement_o2.clone();
                let flags_p1x = flags_p1.clone();
                let pattern_p0x = pattern_p0.clone();
                crate::prelude::call_then(start_rx_alternation_f(st0_p4.clone(), &rx_find_o(&flags_p1x, &crate::prelude::Nat::from(0u32), &crate::prelude::Text::lit("i")) != &::std::option::Option::None), move |rx_alternation_f_15544: (RxMeasure, RxState)| {
                    let (m_p5, st_p6) = rx_alternation_f_15544;
                    match &st_p6.err_o {
                        ::std::option::Option::Some(d_p7) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(d_p7.clone())),
                        ::std::option::Option::None => if &st_p6.i_p < &crate::prelude::len_text(&pattern_p0x) {
                            ::prism_rtl::Turn::Finished(::std::option::Option::Some(RxDiag { part_p: crate::prelude::Text::lit("pattern"), at_p: st_p6.i_p.clone(), message_p: rx_group_close_p() }))
                        } else {
                            if &m_p5.depth_p > &crate::prelude::Nat::from(100u32) {
                                ::prism_rtl::Turn::Finished(::std::option::Option::Some(RxDiag { part_p: crate::prelude::Text::lit("pattern"), at_p: crate::prelude::Nat::from(0u32), message_p: rx_nesting_p() }))
                            } else {
                                if &m_p5.size_p > &crate::prelude::Nat::from(10000u32) {
                                    ::prism_rtl::Turn::Finished(::std::option::Option::Some(RxDiag { part_p: crate::prelude::Text::lit("pattern"), at_p: crate::prelude::Nat::from(0u32), message_p: rx_size_p() }))
                                } else {
                                    match &replacement_o2x {
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                                        ::std::option::Option::Some(r_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RxReplacementRefusal { r_p0: r_p8.clone(), groups_p1: st_p6.groups_p.clone(), names_p2: st_p6.names_p.clone() })),
                                    }
                                }
                            }
                        },
                    }
                })
            },
        }
    }
}

/// `Start RegexRefusal, x`: what the function value is when passed to `@Run`.
pub fn start_regex_refusal_o(pattern_p0: crate::prelude::Text, flags_p1: crate::prelude::Text, replacement_o2: ::std::option::Option<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<RxDiag>>> {
    ::std::rc::Rc::new(RegexRefusal { pattern_p0, flags_p1, replacement_o2 })
}

/// ```prism
/// ?RxFlagsRefusal: fn Text -> ?RxDiag
/// ```
pub fn rx_flags_refusal_o(flags_p0: &crate::prelude::Text) -> ::std::option::Option<RxDiag> {
    let (d_o6, _) = {
        let mut this: (::std::option::Option<RxDiag>, crate::prelude::Text) = (::std::option::Option::None, crate::prelude::Text::lit(""));
        let mut c_p1: crate::prelude::Cursor = crate::prelude::front(flags_p0);
        let mut d_o2: ::std::option::Option<RxDiag> = ::std::option::Option::None;
        let mut seen_p3: crate::prelude::Text = crate::prelude::Text::lit("");
        while let ::std::option::Option::Some((_, next_p4)) = crate::prelude::step(&c_p1) {
            if !(&d_o2 == &::std::option::Option::None) {
                break;
            }
            let ch_p5 = rx_slice_f(flags_p0, &crate::prelude::at(&c_p1), &crate::prelude::at(&next_p4));
            if !(((&ch_p5 == &crate::prelude::Text::lit("i")) || (&ch_p5 == &crate::prelude::Text::lit("m"))) || (&ch_p5 == &crate::prelude::Text::lit("s"))) {
                d_o2 = ::std::option::Option::Some(RxDiag { part_p: crate::prelude::Text::lit("flags"), at_p: crate::prelude::at(&c_p1), message_p: rx_unknown_flag_p() });
            } else if rx_in_f(&seen_p3, &ch_p5) {
                d_o2 = ::std::option::Option::Some(RxDiag { part_p: crate::prelude::Text::lit("flags"), at_p: crate::prelude::at(&c_p1), message_p: rx_flag_twice_p() });
            } else {
                seen_p3 = crate::prelude::Text::from(format!("{}{}", &seen_p3, &ch_p5));
            }
            c_p1 = next_p4.clone();
        }
        this = (d_o2.clone(), seen_p3.clone());
        this
    };
    d_o6.clone()
}

/// ```prism
/// RxAlternation: unbounded fn RxState, Bool -> ((RxMeasure, RxState))
/// ```
pub fn rx_alternation_f(st0_p0: &RxState, fi0_p1: &bool) -> (RxMeasure, RxState) {
    let (m0_p2, fi1_p3, st1_p4) = rx_sequence_f(st0_p0, fi0_p1);
    let mut this: (RxMeasure, RxState) = (m0_p2.clone(), st1_p4.clone());
    let mut m_p5: RxMeasure = m0_p2.clone();
    let mut fi_p6: bool = fi1_p3;
    let mut st_p7: RxState = st1_p4.clone();
    while !rx_bad_f(&st_p7) && (&rx_peek_f(&st_p7) == &crate::prelude::Text::lit("|")) {
        let (m2_p8, fi2_p9, st2_pa) = rx_sequence_f(&rx_go_f(&st_p7, &(&st_p7.i_p + &crate::prelude::Nat::from(1u32))), &fi_p6);
        m_p5 = rx_then_f(&m_p5, &m2_p8);
        fi_p6 = fi2_p9;
        st_p7 = st2_pa.clone();
    }
    this = (m_p5.clone(), st_p7.clone());
    this
}

/// The step machine of `RxAlternation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxAlternation: unbounded fn RxState, Bool -> ((RxMeasure, RxState))
/// ```
pub struct RxAlternation {
    pub st0_p0: RxState,
    pub fi0_p1: bool,
}

impl ::prism_rtl::Job<(RxMeasure, RxState)> for RxAlternation {
    fn cycle(&self) -> ::prism_rtl::Turn<(RxMeasure, RxState)> {
        let st0_p0 = &self.st0_p0;
        let fi0_p1 = &self.fi0_p1;
        let fi0_p1x = *fi0_p1;
        let st0_p0x = st0_p0.clone();
        crate::prelude::call_then(start_rx_sequence_f(st0_p0x.clone(), fi0_p1x), move |rx_sequence_f_17137: (RxMeasure, bool, RxState)| {
            let (m0_p2, fi1_p3, st1_p4) = rx_sequence_f_17137;
            let mut this: (RxMeasure, RxState) = (m0_p2.clone(), st1_p4.clone());
            let mut m_p5: RxMeasure = m0_p2.clone();
            let mut fi_p6: bool = fi1_p3;
            let mut st_p7: RxState = st1_p4.clone();
            crate::prelude::call_then(crate::prelude::loop_job((this, fi_p6, m_p5, st_p7), move |(mut this, mut fi_p6, mut m_p5, mut st_p7): ((RxMeasure, RxState), bool, RxMeasure, RxState)| if !rx_bad_f(&st_p7) && (&rx_peek_f(&st_p7) == &crate::prelude::Text::lit("|")) {
                {
                    let (m2_p8, fi2_p9, st2_pa) = rx_sequence_f(&rx_go_f(&st_p7, &(&st_p7.i_p + &crate::prelude::Nat::from(1u32))), &fi_p6);
                    m_p5 = rx_then_f(&m_p5, &m2_p8);
                    fi_p6 = fi2_p9;
                    st_p7 = st2_pa.clone();
                    ::std::result::Result::Ok((this, fi_p6, m_p5, st_p7))
                }
            } else {
                ::std::result::Result::Err((this, fi_p6, m_p5, st_p7))
            }), move |(mut this, mut fi_p6, mut m_p5, mut st_p7): ((RxMeasure, RxState), bool, RxMeasure, RxState)| {
                this = (m_p5.clone(), st_p7.clone());
                ::prism_rtl::Turn::Finished(this)
            })
        })
    }
}

/// `Start RxAlternation, x`: what the function value is when passed to `@Run`.
pub fn start_rx_alternation_f(st0_p0: RxState, fi0_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(RxMeasure, RxState)>> {
    ::std::rc::Rc::new(RxAlternation { st0_p0, fi0_p1 })
}

/// ```prism
/// RxSequence: unbounded fn RxState, Bool -> ((RxMeasure, Bool, RxState))
/// ```
pub fn rx_sequence_f(st0_p0: &RxState, fi0_p1: &bool) -> (RxMeasure, bool, RxState) {
    let mut this: (RxMeasure, bool, RxState) = (rx_none_p(), *fi0_p1, st0_p0.clone());
    let mut total_p2: RxMeasure = rx_none_p();
    let mut fi_p3: bool = *fi0_p1;
    let mut st_p4: RxState = st0_p0.clone();
    let mut last_p5: RxLast = RxLast::RxLastNothing;
    let mut last_m_p6: RxMeasure = rx_none_p();
    let mut going_p7: bool = true;
    while going_p7 && !rx_bad_f(&st_p4) {
        let c_p8 = rx_peek_f(&st_p4);
        let at_p9 = st_p4.i_p.clone();
        if ((&c_p8 == &crate::prelude::Text::lit("")) || (&c_p8 == &crate::prelude::Text::lit("|"))) || (&c_p8 == &crate::prelude::Text::lit(")")) {
            going_p7 = false;
        } else if (((&c_p8 == &crate::prelude::Text::lit("*")) || (&c_p8 == &crate::prelude::Text::lit("+"))) || (&c_p8 == &crate::prelude::Text::lit("?"))) || (&c_p8 == &crate::prelude::Text::lit("{")) {
            let (lo_pa, hi_ob, st2_pc) = if &c_p8 == &crate::prelude::Text::lit("{") {
                rx_count_f(&st_p4)
            } else {
                rx_simple_repetition_f(&st_p4, &c_p8)
            };
            st_p4 = st2_pc.clone();
            if !rx_bad_f(&st_p4) {
                st_p4 = match &last_p5 {
                    RxLast::RxLastNothing => rx_fail_f(&st_p4, &at_p9, &rx_nothing_to_repeat_p()),
                    RxLast::RxLastFlagGroup => rx_fail_f(&st_p4, &at_p9, &rx_nothing_to_repeat_p()),
                    RxLast::RxLastRepetition => rx_fail_f(&st_p4, &at_p9, &rx_repeat_repeat_p()),
                    RxLast::RxLastAssertion => rx_fail_f(&st_p4, &at_p9, &rx_repeat_assertion_p()),
                    RxLast::RxLastAtom => st_p4.clone(),
                };
            }
            if !rx_bad_f(&st_p4) {
                let counted_pd = &c_p8 == &crate::prelude::Text::lit("{");
                let factor_pe = if counted_pd {
                    crate::prelude::max(&crate::prelude::or(&hi_ob, &lo_pa), &crate::prelude::Nat::from(1u32))
                } else {
                    crate::prelude::Nat::from(1u32)
                };
                let product_pf = &factor_pe * &crate::prelude::max(&last_m_p6.product_p, &crate::prelude::Nat::from(1u32));
                if counted_pd && (&product_pf > &crate::prelude::Nat::from(1000u32)) {
                    st_p4 = rx_fail_f(&st_p4, &at_p9, &rx_product_p());
                } else {
                    if &rx_peek_f(&st_p4) == &crate::prelude::Text::lit("?") {
                        st_p4 = rx_go_f(&st_p4, &(&st_p4.i_p + &crate::prelude::Nat::from(1u32)));
                    }
                    let m_pg = RxMeasure { depth_p: &last_m_p6.depth_p + &crate::prelude::Nat::from(1u32), size_p: &last_m_p6.size_p * &factor_pe, product_p: product_pf.clone() };
                    total_p2 = RxMeasure { depth_p: crate::prelude::max(&total_p2.depth_p, &m_pg.depth_p), size_p: &crate::prelude::or(&(&total_p2.size_p).checked_sub(&last_m_p6.size_p), &crate::prelude::Nat::from(0u32)) + &m_pg.size_p, product_p: crate::prelude::max(&total_p2.product_p, &m_pg.product_p) };
                    last_p5 = RxLast::RxLastRepetition;
                    last_m_p6 = m_pg.clone();
                }
            }
        } else {
            let (kind_ph, m_pi, fi2_pj, st2_pk) = rx_piece_f(&st_p4, &fi_p3);
            st_p4 = st2_pk.clone();
            fi_p3 = fi2_pj;
            if &kind_ph != &RxLast::RxLastFlagGroup {
                total_p2 = rx_then_f(&total_p2, &m_pi);
            }
            last_p5 = kind_ph.clone();
            last_m_p6 = m_pi.clone();
        }
    }
    this = (total_p2.clone(), fi_p3, st_p4.clone());
    this
}

/// The step machine of `RxSequence`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RxSequence: unbounded fn RxState, Bool -> ((RxMeasure, Bool, RxState))
/// ```
pub struct RxSequence {
    pub st0_p0: RxState,
    pub fi0_p1: bool,
}

impl ::prism_rtl::Job<(RxMeasure, bool, RxState)> for RxSequence {
    fn cycle(&self) -> ::prism_rtl::Turn<(RxMeasure, bool, RxState)> {
        let st0_p0 = &self.st0_p0;
        let fi0_p1 = &self.fi0_p1;
        let mut this: (RxMeasure, bool, RxState) = (rx_none_p(), *fi0_p1, st0_p0.clone());
        let mut total_p2: RxMeasure = rx_none_p();
        let mut fi_p3: bool = *fi0_p1;
        let mut st_p4: RxState = st0_p0.clone();
        let mut last_p5: RxLast = RxLast::RxLastNothing;
        let mut last_m_p6: RxMeasure = rx_none_p();
        let mut going_p7: bool = true;
        crate::prelude::call_then(crate::prelude::loop_job((this, fi_p3, going_p7, last_p5, last_m_p6, st_p4, total_p2), move |(mut this, mut fi_p3, mut going_p7, mut last_p5, mut last_m_p6, mut st_p4, mut total_p2): ((RxMeasure, bool, RxState), bool, bool, RxLast, RxMeasure, RxState, RxMeasure)| if going_p7 && !rx_bad_f(&st_p4) {
            {
                let c_p8 = rx_peek_f(&st_p4);
                let at_p9 = st_p4.i_p.clone();
                if ((&c_p8 == &crate::prelude::Text::lit("")) || (&c_p8 == &crate::prelude::Text::lit("|"))) || (&c_p8 == &crate::prelude::Text::lit(")")) {
                    going_p7 = false;
                } else if (((&c_p8 == &crate::prelude::Text::lit("*")) || (&c_p8 == &crate::prelude::Text::lit("+"))) || (&c_p8 == &crate::prelude::Text::lit("?"))) || (&c_p8 == &crate::prelude::Text::lit("{")) {
                    let (lo_pa, hi_ob, st2_pc) = if &c_p8 == &crate::prelude::Text::lit("{") {
                        rx_count_f(&st_p4)
                    } else {
                        rx_simple_repetition_f(&st_p4, &c_p8)
                    };
                    st_p4 = st2_pc.clone();
                    if !rx_bad_f(&st_p4) {
                        st_p4 = match &last_p5 {
                            RxLast::RxLastNothing => rx_fail_f(&st_p4, &at_p9, &rx_nothing_to_repeat_p()),
                            RxLast::RxLastFlagGroup => rx_fail_f(&st_p4, &at_p9, &rx_nothing_to_repeat_p()),
                            RxLast::RxLastRepetition => rx_fail_f(&st_p4, &at_p9, &rx_repeat_repeat_p()),
                            RxLast::RxLastAssertion => rx_fail_f(&st_p4, &at_p9, &rx_repeat_assertion_p()),
                            RxLast::RxLastAtom => st_p4.clone(),
                        };
                    }
                    if !rx_bad_f(&st_p4) {
                        let counted_pd = &c_p8 == &crate::prelude::Text::lit("{");
                        let factor_pe = if counted_pd {
                            crate::prelude::max(&crate::prelude::or(&hi_ob, &lo_pa), &crate::prelude::Nat::from(1u32))
                        } else {
                            crate::prelude::Nat::from(1u32)
                        };
                        let product_pf = &factor_pe * &crate::prelude::max(&last_m_p6.product_p, &crate::prelude::Nat::from(1u32));
                        if counted_pd && (&product_pf > &crate::prelude::Nat::from(1000u32)) {
                            st_p4 = rx_fail_f(&st_p4, &at_p9, &rx_product_p());
                        } else {
                            if &rx_peek_f(&st_p4) == &crate::prelude::Text::lit("?") {
                                st_p4 = rx_go_f(&st_p4, &(&st_p4.i_p + &crate::prelude::Nat::from(1u32)));
                            }
                            let m_pg = RxMeasure { depth_p: &last_m_p6.depth_p + &crate::prelude::Nat::from(1u32), size_p: &last_m_p6.size_p * &factor_pe, product_p: product_pf.clone() };
                            total_p2 = RxMeasure { depth_p: crate::prelude::max(&total_p2.depth_p, &m_pg.depth_p), size_p: &crate::prelude::or(&(&total_p2.size_p).checked_sub(&last_m_p6.size_p), &crate::prelude::Nat::from(0u32)) + &m_pg.size_p, product_p: crate::prelude::max(&total_p2.product_p, &m_pg.product_p) };
                            last_p5 = RxLast::RxLastRepetition;
                            last_m_p6 = m_pg.clone();
                        }
                    }
                } else {
                    let (kind_ph, m_pi, fi2_pj, st2_pk) = rx_piece_f(&st_p4, &fi_p3);
                    st_p4 = st2_pk.clone();
                    fi_p3 = fi2_pj;
                    if &kind_ph != &RxLast::RxLastFlagGroup {
                        total_p2 = rx_then_f(&total_p2, &m_pi);
                    }
                    last_p5 = kind_ph.clone();
                    last_m_p6 = m_pi.clone();
                }
                ::std::result::Result::Ok((this, fi_p3, going_p7, last_p5, last_m_p6, st_p4, total_p2))
            }
        } else {
            ::std::result::Result::Err((this, fi_p3, going_p7, last_p5, last_m_p6, st_p4, total_p2))
        }), move |(mut this, mut fi_p3, mut going_p7, mut last_p5, mut last_m_p6, mut st_p4, mut total_p2): ((RxMeasure, bool, RxState), bool, bool, RxLast, RxMeasure, RxState, RxMeasure)| {
            this = (total_p2.clone(), fi_p3, st_p4.clone());
            ::prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start RxSequence, x`: what the function value is when passed to `@Run`.
pub fn start_rx_sequence_f(st0_p0: RxState, fi0_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(RxMeasure, bool, RxState)>> {
    ::std::rc::Rc::new(RxSequence { st0_p0, fi0_p1 })
}

/// ```prism
/// RxSimpleRepetition: fn RxState, Text -> ((Nat, ?Nat, RxState))
/// ```
pub fn rx_simple_repetition_f(st_p0: &RxState, c_p1: &crate::prelude::Text) -> (crate::prelude::Nat, ::std::option::Option<crate::prelude::Nat>, RxState) {
    let st2_p2 = rx_go_f(st_p0, &(&st_p0.i_p + &crate::prelude::Nat::from(1u32)));
    if c_p1 == &crate::prelude::Text::lit("*") {
        (crate::prelude::Nat::from(0u32), ::std::option::Option::None, st2_p2.clone())
    } else {
        if c_p1 == &crate::prelude::Text::lit("+") {
            (crate::prelude::Nat::from(1u32), ::std::option::Option::None, st2_p2.clone())
        } else {
            (crate::prelude::Nat::from(0u32), ::std::option::Option::Some(crate::prelude::Nat::from(1u32)), st2_p2.clone())
        }
    }
}

/// ```prism
/// RxCount: unbounded fn RxState -> ((Nat, ?Nat, RxState))
/// ```
pub fn rx_count_f(st_p0: &RxState) -> (crate::prelude::Nat, ::std::option::Option<crate::prelude::Nat>, RxState) {
    let at_p1 = st_p0.i_p.clone();
    let s_p2 = st_p0.s_p.clone();
    let j1_p3 = rx_span_end_f(&s_p2, &(&at_p1 + &crate::prelude::Nat::from(1u32)), &{
        let f = ::std::rc::Rc::new(rx_is_digit_f);
        ::std::rc::Rc::new(move |a0: crate::prelude::Text| {
            let fy = f.clone();
            crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    });
    let first_p4 = rx_slice_f(&s_p2, &(&at_p1 + &crate::prelude::Nat::from(1u32)), &j1_p3);
    let c_p5 = rx_char_at_f(&s_p2, &j1_p3);
    if &first_p4 == &crate::prelude::Text::lit("") {
        (crate::prelude::Nat::from(0u32), ::std::option::Option::None, rx_fail_f(st_p0, &at_p1, &rx_brace_p()))
    } else {
        if &c_p5 == &crate::prelude::Text::lit("}") {
            rx_count_checked_f(st_p0, &at_p1, &first_p4, &::std::option::Option::None, &(&j1_p3 + &crate::prelude::Nat::from(1u32)))
        } else {
            if &c_p5 == &crate::prelude::Text::lit(",") {
                {
                    let j2_p6 = rx_span_end_f(&s_p2, &(&j1_p3 + &crate::prelude::Nat::from(1u32)), &{
                        let f = ::std::rc::Rc::new(rx_is_digit_f);
                        ::std::rc::Rc::new(move |a0: crate::prelude::Text| {
                            let fy = f.clone();
                            crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    });
                    if &rx_char_at_f(&s_p2, &j2_p6) != &crate::prelude::Text::lit("}") {
                        (crate::prelude::Nat::from(0u32), ::std::option::Option::None, rx_fail_f(st_p0, &at_p1, &rx_brace_p()))
                    } else {
                        rx_count_checked_f(st_p0, &at_p1, &first_p4, &::std::option::Option::Some(rx_slice_f(&s_p2, &(&j1_p3 + &crate::prelude::Nat::from(1u32)), &j2_p6)), &(&j2_p6 + &crate::prelude::Nat::from(1u32)))
                    }
                }
            } else {
                (crate::prelude::Nat::from(0u32), ::std::option::Option::None, rx_fail_f(st_p0, &at_p1, &rx_brace_p()))
            }
        }
    }
}

/// ```prism
/// RxCountChecked: fn RxState, Nat, Text, ?Text, Nat -> ((Nat, ?Nat, RxState))
/// ```
pub fn rx_count_checked_f(st_p0: &RxState, at_p1: &crate::prelude::Nat, first_p2: &crate::prelude::Text, second_o3: &::std::option::Option<crate::prelude::Text>, next_p4: &crate::prelude::Nat) -> (crate::prelude::Nat, ::std::option::Option<crate::prelude::Nat>, RxState) {
    let st1_p5 = rx_go_f(st_p0, next_p4);
    let lo_p6 = crate::prelude::or(&crate::prelude::parse_nat_opt(first_p2), &crate::prelude::Nat::from(0u32));
    let hi_o7 = match second_o3 {
        ::std::option::Option::None => ::std::option::Option::Some(lo_p6.clone()),
        ::std::option::Option::Some(m20976_1) if (m20976_1 == &crate::prelude::Text::lit("")) => ::std::option::Option::None,
        ::std::option::Option::Some(d_p9) => crate::prelude::parse_nat_opt(d_p9),
        _ => unreachable!("no arm matched"),
    };
    let zero_p8 = rx_leading_zero_f(first_p2) || rx_leading_zero_f(&crate::prelude::or(second_o3, &crate::prelude::Text::lit("")));
    if zero_p8 {
        (crate::prelude::Nat::from(0u32), ::std::option::Option::None, rx_fail_f(&st1_p5, at_p1, &rx_count_zero_p()))
    } else {
        if (&lo_p6 > &crate::prelude::Nat::from(1000u32)) || (&crate::prelude::or(&hi_o7, &crate::prelude::Nat::from(0u32)) > &crate::prelude::Nat::from(1000u32)) {
            (crate::prelude::Nat::from(0u32), ::std::option::Option::None, rx_fail_f(&st1_p5, at_p1, &rx_count_bound_p()))
        } else {
            if &lo_p6 > &crate::prelude::or(&hi_o7, &lo_p6) {
                (crate::prelude::Nat::from(0u32), ::std::option::Option::None, rx_fail_f(&st1_p5, at_p1, &rx_count_order_p()))
            } else {
                (lo_p6.clone(), hi_o7.clone(), st1_p5.clone())
            }
        }
    }
}

/// ```prism
/// RxLeadingZero: fn Text -> Bool
/// ```
pub fn rx_leading_zero_f(d_p0: &crate::prelude::Text) -> bool {
    (&crate::prelude::len_text(d_p0) > &crate::prelude::Nat::from(1u32)) && (&rx_char_at_f(d_p0, &crate::prelude::Nat::from(0u32)) == &crate::prelude::Text::lit("0"))
}

/// ```prism
/// RxPiece: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_piece_f(st_p0: &RxState, fi_p1: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let at_p2 = st_p0.i_p.clone();
    let c_p3 = rx_peek_f(st_p0);
    match &c_p3 {
        m21755_0 if (m21755_0 == &crate::prelude::Text::lit("(")) => rx_group_f(st_p0, fi_p1),
        m21755_1 if (m21755_1 == &crate::prelude::Text::lit("[")) => (RxLast::RxLastAtom, rx_atom_p(), *fi_p1, rx_class_f(st_p0, fi_p1)),
        m21755_2 if (m21755_2 == &crate::prelude::Text::lit("]")) => (RxLast::RxLastAtom, rx_atom_p(), *fi_p1, rx_fail_f(st_p0, &at_p2, &rx_stray_bracket_p())),
        m21755_3 if (m21755_3 == &crate::prelude::Text::lit("}")) => (RxLast::RxLastAtom, rx_atom_p(), *fi_p1, rx_fail_f(st_p0, &at_p2, &rx_stray_brace_p())),
        m21755_4 if (m21755_4 == &crate::prelude::Text::lit("^")) => (RxLast::RxLastAssertion, rx_atom_p(), *fi_p1, rx_go_f(st_p0, &(&at_p2 + &crate::prelude::Nat::from(1u32)))),
        m21755_5 if (m21755_5 == &crate::prelude::Text::lit("$")) => (RxLast::RxLastAssertion, rx_atom_p(), *fi_p1, rx_go_f(st_p0, &(&at_p2 + &crate::prelude::Nat::from(1u32)))),
        m21755_6 if (m21755_6 == &crate::prelude::Text::lit("\\")) => rx_escape_f(st_p0, fi_p1),
        _ => (RxLast::RxLastAtom, rx_atom_p(), *fi_p1, rx_go_f(st_p0, &(&at_p2 + &crate::prelude::len_text(&c_p3)))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RxEscape: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_escape_f(st_p0: &RxState, fi_p1: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let at_p2 = st_p0.i_p.clone();
    let s_p3 = st_p0.s_p.clone();
    let c_p4 = rx_char_at_f(&s_p3, &(&at_p2 + &crate::prelude::Nat::from(1u32)));
    let atom_f5 = {
        let fi_p1x = *fi_p1;
        ::std::rc::Rc::new(move |next_p6: &RxState| (RxLast::RxLastAtom, rx_atom_p(), fi_p1x, next_p6.clone())) as ::std::rc::Rc<dyn ::std::ops::Fn(&RxState) -> (RxLast, RxMeasure, bool, RxState)>
    };
    if &c_p4 == &crate::prelude::Text::lit("") {
        (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_trailing_backslash_p()))
    } else {
        if (&c_p4 == &crate::prelude::Text::lit("<")) || (&c_p4 == &crate::prelude::Text::lit(">")) {
            (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_angle_p()))
        } else {
            if rx_in_f(&rx_punctuation_p(), &c_p4) {
                (&atom_f5)(&rx_go_f(st_p0, &(&at_p2 + &crate::prelude::Nat::from(2u32))))
            } else {
                if rx_in_f(&crate::prelude::Text::lit("tnrfva"), &c_p4) {
                    (&atom_f5)(&rx_go_f(st_p0, &(&at_p2 + &crate::prelude::Nat::from(2u32))))
                } else {
                    if &c_p4 == &crate::prelude::Text::lit("x") {
                        {
                            let (_, st2_p7) = rx_hex_f(st_p0, &at_p2);
                            (&atom_f5)(&st2_p7)
                        }
                    } else {
                        if rx_in_f(&crate::prelude::Text::lit("dwsDWS"), &c_p4) {
                            (&atom_f5)(&rx_go_f(st_p0, &(&at_p2 + &crate::prelude::Nat::from(2u32))))
                        } else {
                            if (&c_p4 == &crate::prelude::Text::lit("p")) || (&c_p4 == &crate::prelude::Text::lit("P")) {
                                {
                                    let (_, st2_p8) = rx_property_f(st_p0, &at_p2);
                                    (&atom_f5)(&st2_p8)
                                }
                            } else {
                                if rx_in_f(&crate::prelude::Text::lit("AzbB"), &c_p4) {
                                    if (&c_p4 == &crate::prelude::Text::lit("b")) && (&rx_char_at_f(&s_p3, &(&at_p2 + &crate::prelude::Nat::from(2u32))) == &crate::prelude::Text::lit("{")) {
                                        (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_word_braces_p()))
                                    } else {
                                        (RxLast::RxLastAssertion, rx_atom_p(), *fi_p1, rx_go_f(st_p0, &(&at_p2 + &crate::prelude::Nat::from(2u32))))
                                    }
                                } else {
                                    if rx_in_f(&crate::prelude::Text::lit("123456789"), &c_p4) {
                                        (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_backreference_p()))
                                    } else {
                                        if &c_p4 == &crate::prelude::Text::lit("0") {
                                            (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_octal_p()))
                                        } else {
                                            if (&c_p4 == &crate::prelude::Text::lit("Q")) || (&c_p4 == &crate::prelude::Text::lit("E")) {
                                                (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_quote_p()))
                                            } else {
                                                if &c_p4 == &crate::prelude::Text::lit("C") {
                                                    (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_one_byte_p()))
                                                } else {
                                                    (&atom_f5)(&rx_fail_f(st_p0, &at_p2, &rx_unknown_escape_p()))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxHex: unbounded fn RxState, Nat -> ((Nat, RxState))
/// ```
pub fn rx_hex_f(st_p0: &RxState, at_p1: &crate::prelude::Nat) -> (crate::prelude::Nat, RxState) {
    let s_p2 = st_p0.s_p.clone();
    let x_p3 = at_p1 + &crate::prelude::Nat::from(1u32);
    if &rx_char_at_f(&s_p2, &(&x_p3 + &crate::prelude::Nat::from(1u32))) == &crate::prelude::Text::lit("{") {
        {
            let start_p4 = &x_p3 + &crate::prelude::Nat::from(2u32);
            let j_p5 = rx_span_end_f(&s_p2, &start_p4, &{
                let f = ::std::rc::Rc::new(rx_is_hex_f);
                ::std::rc::Rc::new(move |a0: crate::prelude::Text| {
                    let fy = f.clone();
                    crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            });
            let digits_p6 = rx_slice_f(&s_p2, &start_p4, &j_p5);
            if ((&rx_char_at_f(&s_p2, &j_p5) != &crate::prelude::Text::lit("}")) || (&digits_p6 == &crate::prelude::Text::lit(""))) || (&crate::prelude::len_text(&digits_p6) > &crate::prelude::Nat::from(6u32)) {
                (crate::prelude::Nat::from(0u32), rx_fail_f(st_p0, at_p1, &rx_hex_braces_p()))
            } else {
                rx_hex_checked_f(&rx_go_f(st_p0, &(&j_p5 + &crate::prelude::Nat::from(1u32))), at_p1, &rx_hex_value_f(&digits_p6))
            }
        }
    } else {
        {
            let a_p7 = rx_char_at_f(&s_p2, &(&x_p3 + &crate::prelude::Nat::from(1u32)));
            let b_p8 = rx_char_at_f(&s_p2, &(&x_p3 + &crate::prelude::Nat::from(2u32)));
            if rx_is_hex_f(&a_p7) && rx_is_hex_f(&b_p8) {
                rx_hex_checked_f(&rx_go_f(st_p0, &(&x_p3 + &crate::prelude::Nat::from(3u32))), at_p1, &rx_hex_value_f(&crate::prelude::Text::from(format!("{}{}", &a_p7, &b_p8))))
            } else {
                (crate::prelude::Nat::from(0u32), rx_fail_f(st_p0, at_p1, &rx_hex_two_p()))
            }
        }
    }
}

/// ```prism
/// RxHexChecked: fn RxState, Nat, Nat -> ((Nat, RxState))
/// ```
pub fn rx_hex_checked_f(st_p0: &RxState, at_p1: &crate::prelude::Nat, v_p2: &crate::prelude::Nat) -> (crate::prelude::Nat, RxState) {
    if ((&crate::prelude::Nat::from(55296u32) <= v_p2) && (v_p2 <= &crate::prelude::Nat::from(57343u32))) || (v_p2 > &crate::prelude::Nat::from(1114111u32)) {
        (v_p2.clone(), rx_fail_f(st_p0, at_p1, &rx_hex_no_char_p()))
    } else {
        (v_p2.clone(), st_p0.clone())
    }
}

/// ```prism
/// RxProperty: unbounded fn RxState, Nat -> ((Text, RxState))
/// ```
pub fn rx_property_f(st_p0: &RxState, at_p1: &crate::prelude::Nat) -> (crate::prelude::Text, RxState) {
    let s_p2 = st_p0.s_p.clone();
    let c_p3 = rx_char_at_f(&s_p2, &(at_p1 + &crate::prelude::Nat::from(2u32)));
    if &c_p3 == &crate::prelude::Text::lit("{") {
        {
            let start_p4 = at_p1 + &crate::prelude::Nat::from(3u32);
            match rx_find_o(&s_p2, &start_p4, &crate::prelude::Text::lit("}")) {
                ::std::option::Option::None => (crate::prelude::Text::lit(""), rx_fail_f(st_p0, at_p1, &rx_property_open_p())),
                ::std::option::Option::Some(close_p5) => {
                    let name_p6 = rx_slice_f(&s_p2, &start_p4, &close_p5);
                    if &rx_char_at_f(&name_p6, &crate::prelude::Nat::from(0u32)) == &crate::prelude::Text::lit("^") {
                        (name_p6.clone(), rx_fail_f(st_p0, at_p1, &rx_property_negated_p()))
                    } else {
                        rx_property_named_f(&rx_go_f(st_p0, &(&close_p5 + &crate::prelude::Nat::from(1u32))), at_p1, &name_p6)
                    }
                },
            }
        }
    } else {
        if rx_is_letter_f(&c_p3) {
            rx_property_named_f(&rx_go_f(st_p0, &(at_p1 + &crate::prelude::Nat::from(3u32))), at_p1, &c_p3)
        } else {
            (crate::prelude::Text::lit(""), rx_fail_f(st_p0, at_p1, &rx_property_name_p()))
        }
    }
}

/// ```prism
/// RxPropertyNamed: fn RxState, Nat, Text -> ((Text, RxState))
/// ```
pub fn rx_property_named_f(st_p0: &RxState, at_p1: &crate::prelude::Nat, name_p2: &crate::prelude::Text) -> (crate::prelude::Text, RxState) {
    if (((name_p2 == &crate::prelude::Text::lit("C")) || (name_p2 == &crate::prelude::Text::lit("Cn"))) || (name_p2 == &crate::prelude::Text::lit("Cs"))) || (name_p2 == &crate::prelude::Text::lit("LC")) {
        (name_p2.clone(), rx_fail_f(st_p0, at_p1, &rx_property_refused_p()))
    } else {
        if &crate::prelude::get(&rx_properties_p(), name_p2) != &::std::option::Option::None {
            (name_p2.clone(), st_p0.clone())
        } else {
            (name_p2.clone(), rx_fail_f(st_p0, at_p1, &rx_property_unknown_p()))
        }
    }
}

/// ```prism
/// RxClass: unbounded fn RxState, Bool -> RxState
/// ```
pub fn rx_class_f(st0_p0: &RxState, fi_p1: &bool) -> RxState {
    let open_p2 = st0_p0.i_p.clone();
    let start_p3 = if &rx_char_at_f(&st0_p0.s_p, &(&open_p2 + &crate::prelude::Nat::from(1u32))) == &crate::prelude::Text::lit("^") {
        &open_p2 + &crate::prelude::Nat::from(2u32)
    } else {
        &open_p2 + &crate::prelude::Nat::from(1u32)
    };
    let mut this: RxState = rx_go_f(st0_p0, &start_p3);
    let mut first_p4: bool = true;
    let mut done_p5: bool = false;
    while !done_p5 {
        let (closed_p6, st2_p7) = rx_class_item_f(&this, &open_p2, &start_p3, &first_p4, fi_p1);
        this = st2_p7.clone();
        first_p4 = false;
        done_p5 = closed_p6 || rx_bad_f(&st2_p7);
    }
    this
}

/// ```prism
/// RxAtSetOperation: fn RxState -> Bool
/// ```
pub fn rx_at_set_operation_f(st_p0: &RxState) -> bool {
    let c_p1 = rx_peek_f(st_p0);
    (((&c_p1 == &crate::prelude::Text::lit("&")) || (&c_p1 == &crate::prelude::Text::lit("~"))) || (&c_p1 == &crate::prelude::Text::lit("-"))) && (&rx_char_at_f(&st_p0.s_p, &(&st_p0.i_p + &crate::prelude::Nat::from(1u32))) == &c_p1)
}

/// ```prism
/// RxClassItem: unbounded fn RxState, Nat, Nat, Bool, Bool -> ((Bool, RxState))
/// ```
pub fn rx_class_item_f(st_p0: &RxState, open_p1: &crate::prelude::Nat, start_p2: &crate::prelude::Nat, first_p3: &bool, fi_p4: &bool) -> (bool, RxState) {
    let at_p5 = st_p0.i_p.clone();
    let c_p6 = rx_peek_f(st_p0);
    let next_p7 = rx_char_at_f(&st_p0.s_p, &(&at_p5 + &crate::prelude::Nat::from(1u32)));
    if &c_p6 == &crate::prelude::Text::lit("") {
        (true, rx_fail_f(st_p0, open_p1, &rx_class_open_p()))
    } else {
        if (&c_p6 == &crate::prelude::Text::lit("]")) && *first_p3 {
            (true, rx_fail_f(st_p0, &at_p5, &rx_class_first_bracket_p()))
        } else {
            if &c_p6 == &crate::prelude::Text::lit("]") {
                (true, rx_go_f(st_p0, &(&at_p5 + &crate::prelude::Nat::from(1u32))))
            } else {
                if rx_at_set_operation_f(st_p0) {
                    (true, rx_fail_f(st_p0, &at_p5, &rx_class_set_operation_p()))
                } else {
                    if &c_p6 == &crate::prelude::Text::lit("[") {
                        (false, rx_ascii_item_f(st_p0, fi_p4))
                    } else {
                        if (&c_p6 == &crate::prelude::Text::lit("-")) && (&next_p7 == &crate::prelude::Text::lit("")) {
                            (true, rx_fail_f(st_p0, open_p1, &rx_class_open_p()))
                        } else {
                            if (&c_p6 == &crate::prelude::Text::lit("-")) && ((&at_p5 == start_p2) || (&next_p7 == &crate::prelude::Text::lit("]"))) {
                                (false, rx_go_f(st_p0, &(&at_p5 + &crate::prelude::Nat::from(1u32))))
                            } else {
                                if &c_p6 == &crate::prelude::Text::lit("-") {
                                    (true, rx_fail_f(st_p0, &at_p5, &rx_class_dash_p()))
                                } else {
                                    (false, rx_class_range_f(st_p0, open_p1, fi_p4))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxClassRange: unbounded fn RxState, Nat, Bool -> RxState
/// ```
pub fn rx_class_range_f(st_p0: &RxState, open_p1: &crate::prelude::Nat, fi_p2: &bool) -> RxState {
    let at_p3 = st_p0.i_p.clone();
    let (lo_o4, st1_p5) = rx_class_atom_f(st_p0, fi_p2);
    match &lo_o4 {
        ::std::option::Option::None => st1_p5.clone(),
        ::std::option::Option::Some(lo_p6) => {
            let s_p7 = st1_p5.s_p.clone();
            let ranged_p8 = (&rx_peek_f(&st1_p5) == &crate::prelude::Text::lit("-")) && (&rx_char_at_f(&s_p7, &(&st1_p5.i_p + &crate::prelude::Nat::from(1u32))) != &crate::prelude::Text::lit("]"));
            if rx_bad_f(&st1_p5) || !ranged_p8 {
                st1_p5.clone()
            } else {
                if rx_at_set_operation_f(&st1_p5) {
                    rx_fail_f(&st1_p5, &st1_p5.i_p, &rx_class_set_operation_p())
                } else {
                    {
                        let right_p9 = &st1_p5.i_p + &crate::prelude::Nat::from(1u32);
                        let st2_pa = rx_go_f(&st1_p5, &right_p9);
                        let rc_pb = rx_peek_f(&st2_pa);
                        if &rc_pb == &crate::prelude::Text::lit("") {
                            rx_fail_f(&st2_pa, open_p1, &rx_class_open_p())
                        } else {
                            if &rc_pb == &crate::prelude::Text::lit("[") {
                                rx_fail_f(&st2_pa, &right_p9, &rx_class_nested_p())
                            } else {
                                if rx_at_set_operation_f(&st2_pa) {
                                    rx_fail_f(&st2_pa, &right_p9, &rx_class_set_operation_p())
                                } else {
                                    {
                                        let (hi_oc, st3_pd) = rx_class_atom_f(&st2_pa, fi_p2);
                                        if rx_bad_f(&st3_pd) {
                                            st3_pd.clone()
                                        } else {
                                            match &hi_oc {
                                                ::std::option::Option::None => rx_fail_f(&st3_pd, &right_p9, &rx_class_range_set_p()),
                                                ::std::option::Option::Some(hi_pe) => if rx_past_f(lo_p6, hi_pe) {
                                                    rx_fail_f(&st3_pd, &at_p3, &rx_class_order_p())
                                                } else {
                                                    st3_pd.clone()
                                                },
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
    }
}

/// ```prism
/// RxClassAtom: unbounded fn RxState, Bool -> ((?RxCp, RxState))
/// ```
pub fn rx_class_atom_f(st_p0: &RxState, fi_p1: &bool) -> (::std::option::Option<RxCp>, RxState) {
    let at_p2 = st_p0.i_p.clone();
    let s_p3 = st_p0.s_p.clone();
    let c_p4 = rx_peek_f(st_p0);
    if &c_p4 != &crate::prelude::Text::lit("\\") {
        (::std::option::Option::Some(RxCp::RxLit(c_p4.clone())), rx_go_f(st_p0, &(&at_p2 + &crate::prelude::len_text(&c_p4))))
    } else {
        {
            let e_p5 = rx_char_at_f(&s_p3, &(&at_p2 + &crate::prelude::Nat::from(1u32)));
            if &e_p5 == &crate::prelude::Text::lit("") {
                (::std::option::Option::None, rx_fail_f(st_p0, &at_p2, &rx_trailing_backslash_p()))
            } else {
                if (&e_p5 == &crate::prelude::Text::lit("<")) || (&e_p5 == &crate::prelude::Text::lit(">")) {
                    (::std::option::Option::None, rx_fail_f(st_p0, &at_p2, &rx_class_escape_p()))
                } else {
                    if rx_in_f(&rx_punctuation_p(), &e_p5) {
                        (::std::option::Option::Some(RxCp::RxLit(e_p5.clone())), rx_go_f(st_p0, &(&at_p2 + &crate::prelude::Nat::from(2u32))))
                    } else {
                        if rx_in_f(&crate::prelude::Text::lit("tnrfva"), &e_p5) {
                            (::std::option::Option::Some(RxCp::RxLit(rx_control_f(&e_p5))), rx_go_f(st_p0, &(&at_p2 + &crate::prelude::Nat::from(2u32))))
                        } else {
                            if &e_p5 == &crate::prelude::Text::lit("x") {
                                {
                                    let (v_p6, st2_p7) = rx_hex_f(st_p0, &at_p2);
                                    (::std::option::Option::Some(rx_cp_of_f(&v_p6)), st2_p7.clone())
                                }
                            } else {
                                if rx_in_f(&crate::prelude::Text::lit("dws"), &e_p5) {
                                    (::std::option::Option::None, rx_go_f(st_p0, &(&at_p2 + &crate::prelude::Nat::from(2u32))))
                                } else {
                                    if rx_in_f(&crate::prelude::Text::lit("DWS"), &e_p5) {
                                        if *fi_p1 {
                                            (::std::option::Option::None, rx_fail_f(st_p0, &at_p2, &rx_class_negated_under_i_p()))
                                        } else {
                                            (::std::option::Option::None, rx_go_f(st_p0, &(&at_p2 + &crate::prelude::Nat::from(2u32))))
                                        }
                                    } else {
                                        if (&e_p5 == &crate::prelude::Text::lit("p")) || (&e_p5 == &crate::prelude::Text::lit("P")) {
                                            {
                                                let (_, st2_p8) = rx_property_f(st_p0, &at_p2);
                                                if ((&e_p5 == &crate::prelude::Text::lit("P")) && *fi_p1) && !rx_bad_f(&st2_p8) {
                                                    (::std::option::Option::None, rx_fail_f(&st2_p8, &at_p2, &rx_class_negated_under_i_p()))
                                                } else {
                                                    (::std::option::Option::None, st2_p8.clone())
                                                }
                                            }
                                        } else {
                                            (::std::option::Option::None, rx_fail_f(st_p0, &at_p2, &rx_class_escape_p()))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxControl: fn Text -> Text
/// ```
pub fn rx_control_f(text0: &crate::prelude::Text) -> crate::prelude::Text {
    match text0 {
        c0_0 if (c0_0 == &crate::prelude::Text::lit("t")) => crate::prelude::Text::lit("\t"),
        c1_0 if (c1_0 == &crate::prelude::Text::lit("n")) => crate::prelude::Text::lit("\n"),
        c2_0 if (c2_0 == &crate::prelude::Text::lit("r")) => crate::prelude::Text::lit("\r"),
        c3_0 if (c3_0 == &crate::prelude::Text::lit("f")) => crate::prelude::Text::lit(""),
        c4_0 if (c4_0 == &crate::prelude::Text::lit("v")) => crate::prelude::Text::lit(""),
        _ => crate::prelude::Text::lit(""),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RxAsciiItem: unbounded fn RxState, Bool -> RxState
/// ```
pub fn rx_ascii_item_f(st_p0: &RxState, fi_p1: &bool) -> RxState {
    let at_p2 = st_p0.i_p.clone();
    let s_p3 = st_p0.s_p.clone();
    let negated_p4 = &rx_char_at_f(&s_p3, &(&at_p2 + &crate::prelude::Nat::from(2u32))) == &crate::prelude::Text::lit("^");
    let start_p5 = if negated_p4 {
        &at_p2 + &crate::prelude::Nat::from(3u32)
    } else {
        &at_p2 + &crate::prelude::Nat::from(2u32)
    };
    let j_p6 = rx_span_end_f(&s_p3, &start_p5, &{
        let f = ::std::rc::Rc::new(rx_is_letter_f);
        ::std::rc::Rc::new(move |a0: crate::prelude::Text| {
            let fy = f.clone();
            crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    });
    let shaped_p7 = (((&rx_char_at_f(&s_p3, &(&at_p2 + &crate::prelude::Nat::from(1u32))) == &crate::prelude::Text::lit(":")) && (&j_p6 > &start_p5)) && (&rx_char_at_f(&s_p3, &j_p6) == &crate::prelude::Text::lit(":"))) && (&rx_char_at_f(&s_p3, &(&j_p6 + &crate::prelude::Nat::from(1u32))) == &crate::prelude::Text::lit("]"));
    if !shaped_p7 {
        rx_fail_f(st_p0, &at_p2, &rx_class_nested_p())
    } else {
        if &crate::prelude::get(&rx_ascii_classes_p(), &rx_slice_f(&s_p3, &start_p5, &j_p6)) == &::std::option::Option::None {
            rx_fail_f(st_p0, &at_p2, &rx_class_ascii_unknown_p())
        } else {
            if negated_p4 && *fi_p1 {
                rx_fail_f(st_p0, &at_p2, &rx_class_negated_under_i_p())
            } else {
                rx_go_f(st_p0, &(&j_p6 + &crate::prelude::Nat::from(2u32)))
            }
        }
    }
}

/// ```prism
/// RxGroup: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_group_f(st_p0: &RxState, fi_p1: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let open_p2 = st_p0.i_p.clone();
    let s_p3 = st_p0.s_p.clone();
    let c_p4 = rx_char_at_f(&s_p3, &(&open_p2 + &crate::prelude::Nat::from(1u32)));
    let d_p5 = rx_char_at_f(&s_p3, &(&open_p2 + &crate::prelude::Nat::from(2u32)));
    let e_p6 = rx_char_at_f(&s_p3, &(&open_p2 + &crate::prelude::Nat::from(3u32)));
    let fail_f7 = {
        let fi_p1x = *fi_p1;
        let st_p0x = st_p0.clone();
        let open_p2x = open_p2.clone();
        ::std::rc::Rc::new(move |message_p8: &crate::prelude::Text| (RxLast::RxLastAtom, rx_atom_p(), fi_p1x, rx_fail_f(&st_p0x, &open_p2x, message_p8))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Text) -> (RxLast, RxMeasure, bool, RxState)>
    };
    if &c_p4 != &crate::prelude::Text::lit("?") {
        rx_group_body_f(&rx_go_f(st_p0, &(&open_p2 + &crate::prelude::Nat::from(1u32))), &open_p2, fi_p1, fi_p1, &true, &::std::option::Option::None)
    } else {
        if &d_p5 == &crate::prelude::Text::lit("") {
            (&fail_f7)(&rx_group_open_p())
        } else {
            if &d_p5 == &crate::prelude::Text::lit(":") {
                rx_group_body_f(&rx_go_f(st_p0, &(&open_p2 + &crate::prelude::Nat::from(3u32))), &open_p2, fi_p1, fi_p1, &false, &::std::option::Option::None)
            } else {
                if (&d_p5 == &crate::prelude::Text::lit("=")) || (&d_p5 == &crate::prelude::Text::lit("!")) {
                    (&fail_f7)(&rx_lookaround_p())
                } else {
                    if (&d_p5 == &crate::prelude::Text::lit("<")) && ((&e_p6 == &crate::prelude::Text::lit("=")) || (&e_p6 == &crate::prelude::Text::lit("!"))) {
                        (&fail_f7)(&rx_lookaround_p())
                    } else {
                        if &d_p5 == &crate::prelude::Text::lit("<") {
                            rx_named_f(st_p0, &open_p2, &(&open_p2 + &crate::prelude::Nat::from(3u32)), fi_p1)
                        } else {
                            if (&d_p5 == &crate::prelude::Text::lit("P")) && (&e_p6 == &crate::prelude::Text::lit("")) {
                                (&fail_f7)(&rx_group_open_p())
                            } else {
                                if (&d_p5 == &crate::prelude::Text::lit("P")) && (&e_p6 == &crate::prelude::Text::lit("<")) {
                                    rx_named_f(st_p0, &open_p2, &(&open_p2 + &crate::prelude::Nat::from(4u32)), fi_p1)
                                } else {
                                    if (&d_p5 == &crate::prelude::Text::lit("P")) && ((&e_p6 == &crate::prelude::Text::lit("=")) || (&e_p6 == &crate::prelude::Text::lit(">"))) {
                                        (&fail_f7)(&rx_backreference_p())
                                    } else {
                                        if &d_p5 == &crate::prelude::Text::lit("P") {
                                            (&fail_f7)(&rx_unknown_group_p())
                                        } else {
                                            if (rx_is_letter_f(&d_p5) || (&d_p5 == &crate::prelude::Text::lit("-"))) || (&d_p5 == &crate::prelude::Text::lit(")")) {
                                                rx_flag_group_f(st_p0, &open_p2, fi_p1)
                                            } else {
                                                (&fail_f7)(&rx_unknown_group_p())
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxNamed: unbounded fn RxState, Nat, Nat, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_named_f(st_p0: &RxState, open_p1: &crate::prelude::Nat, start_p2: &crate::prelude::Nat, fi_p3: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    match rx_find_o(&st_p0.s_p, start_p2, &crate::prelude::Text::lit(">")) {
        ::std::option::Option::None => (RxLast::RxLastAtom, rx_atom_p(), *fi_p3, rx_fail_f(st_p0, open_p1, &rx_name_open_p())),
        ::std::option::Option::Some(close_p4) => {
            let name_p5 = rx_slice_f(&st_p0.s_p, start_p2, &close_p4);
            if !rx_is_name_f(&name_p5) {
                (RxLast::RxLastAtom, rx_atom_p(), *fi_p3, rx_fail_f(st_p0, start_p2, &rx_name_shape_p()))
            } else {
                if &crate::prelude::get(&st_p0.names_p, &name_p5) != &::std::option::Option::None {
                    (RxLast::RxLastAtom, rx_atom_p(), *fi_p3, rx_fail_f(st_p0, open_p1, &rx_name_twice_p()))
                } else {
                    rx_group_body_f(&rx_go_f(st_p0, &(&close_p4 + &crate::prelude::Nat::from(1u32))), open_p1, fi_p3, fi_p3, &true, &::std::option::Option::Some(name_p5.clone()))
                }
            }
        },
    }
}

/// ```prism
/// RxFlagGroup: unbounded fn RxState, Nat, Bool -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_flag_group_f(st_p0: &RxState, open_p1: &crate::prelude::Nat, fi_p2: &bool) -> (RxLast, RxMeasure, bool, RxState) {
    let (bare_p3, inner_p4, st2_p5) = rx_flag_letters_f(st_p0, open_p1, fi_p2);
    if rx_bad_f(&st2_p5) {
        (RxLast::RxLastAtom, rx_atom_p(), *fi_p2, st2_p5.clone())
    } else {
        if bare_p3 {
            (RxLast::RxLastFlagGroup, rx_none_p(), inner_p4, st2_p5.clone())
        } else {
            rx_group_body_f(&st2_p5, open_p1, &inner_p4, fi_p2, &false, &::std::option::Option::None)
        }
    }
}

/// ```prism
/// RxFlagLetters: unbounded fn RxState, Nat, Bool -> ((Bool, Bool, RxState))
/// ```
pub fn rx_flag_letters_f(st0_p0: &RxState, open_p1: &crate::prelude::Nat, fi0_p2: &bool) -> (bool, bool, RxState) {
    let mut this: (bool, bool, RxState) = (false, *fi0_p2, st0_p0.clone());
    let mut st_p3: RxState = rx_go_f(st0_p0, &(open_p1 + &crate::prelude::Nat::from(2u32)));
    let mut fi_p4: bool = *fi0_p2;
    let mut seen_p5: crate::prelude::Text = crate::prelude::Text::lit("");
    let mut dash_o6: ::std::option::Option<crate::prelude::Nat> = ::std::option::Option::None;
    let mut after_dash_p7: bool = false;
    let mut named_p8: bool = false;
    let mut bare_p9: bool = false;
    let mut going_pa: bool = true;
    while going_pa && !rx_bad_f(&st_p3) {
        let at_pb = st_p3.i_p.clone();
        let c_pc = rx_peek_f(&st_p3);
        if &c_pc == &crate::prelude::Text::lit("") {
            st_p3 = rx_fail_f(&st_p3, open_p1, &rx_group_open_p());
        } else if (&c_pc == &crate::prelude::Text::lit(")")) || (&c_pc == &crate::prelude::Text::lit(":")) {
            if !named_p8 && (&dash_o6 == &::std::option::Option::None) {
                st_p3 = rx_fail_f(&st_p3, open_p1, &rx_flags_empty_p());
            } else {
                match &dash_o6 {
                    ::std::option::Option::Some(d_pd) if !after_dash_p7 => {
                        st_p3 = rx_fail_f(&st_p3, d_pd, &rx_flags_dash_p());
                        ()
                    },
                    _ => {
                        st_p3 = rx_go_f(&st_p3, &(&at_pb + &crate::prelude::Nat::from(1u32)));
                        bare_p9 = &c_pc == &crate::prelude::Text::lit(")");
                        going_pa = false;
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
            }
        } else if &c_pc == &crate::prelude::Text::lit("-") {
            if &dash_o6 != &::std::option::Option::None {
                st_p3 = rx_fail_f(&st_p3, &at_pb, &rx_flags_second_dash_p());
            } else {
                dash_o6 = ::std::option::Option::Some(at_pb.clone());
                st_p3 = rx_go_f(&st_p3, &(&at_pb + &crate::prelude::Nat::from(1u32)));
            }
        } else if rx_is_letter_f(&c_pc) {
            if !(((&c_pc == &crate::prelude::Text::lit("i")) || (&c_pc == &crate::prelude::Text::lit("m"))) || (&c_pc == &crate::prelude::Text::lit("s"))) {
                st_p3 = rx_fail_f(&st_p3, &at_pb, &rx_unknown_flag_p());
            } else if rx_in_f(&seen_p5, &c_pc) {
                st_p3 = rx_fail_f(&st_p3, &at_pb, &rx_flag_twice_p());
            } else {
                seen_p5 = crate::prelude::Text::from(format!("{}{}", &seen_p5, &c_pc));
                named_p8 = true;
                if &dash_o6 != &::std::option::Option::None {
                    after_dash_p7 = true;
                }
                if &c_pc == &crate::prelude::Text::lit("i") {
                    fi_p4 = &dash_o6 == &::std::option::Option::None;
                }
                st_p3 = rx_go_f(&st_p3, &(&at_pb + &crate::prelude::Nat::from(1u32)));
            }
        } else {
            st_p3 = rx_fail_f(&st_p3, open_p1, &rx_unknown_group_p());
        }
    }
    this = (bare_p9, fi_p4, st_p3.clone());
    this
}

/// ```prism
/// RxGroupBody: unbounded fn RxState, Nat, Bool, Bool, Bool, ?Text -> ((RxLast, RxMeasure, Bool, RxState))
/// ```
pub fn rx_group_body_f(st0_p0: &RxState, open_p1: &crate::prelude::Nat, inner_p2: &bool, outer_p3: &bool, capture_p4: &bool, name_o5: &::std::option::Option<crate::prelude::Text>) -> (RxLast, RxMeasure, bool, RxState) {
    let counted_p6 = if *capture_p4 { rx_capture_f(st0_p0, name_o5) } else { st0_p0.clone() };
    if &counted_p6.open_p == &crate::prelude::Nat::from(100u32) {
        (RxLast::RxLastAtom, rx_atom_p(), *outer_p3, rx_fail_f(&counted_p6, &crate::prelude::Nat::from(0u32), &rx_nesting_p()))
    } else {
        {
            let deeper_p7 = {
                let mut this: RxState = counted_p6.clone();
                this.open_p = &this.open_p + &crate::prelude::Nat::from(1u32);
                this
            };
            let (m_p8, st2_p9) = rx_alternation_f(&deeper_p7, inner_p2);
            if rx_bad_f(&st2_p9) {
                (RxLast::RxLastAtom, rx_atom_p(), *outer_p3, st2_p9.clone())
            } else {
                if &rx_peek_f(&st2_p9) != &crate::prelude::Text::lit(")") {
                    (RxLast::RxLastAtom, rx_atom_p(), *outer_p3, rx_fail_f(&st2_p9, open_p1, &rx_group_open_p()))
                } else {
                    {
                        let closed_pa = {
                            let mut this: RxState = st2_p9.clone();
                            this.i_p = &this.i_p + &crate::prelude::Nat::from(1u32);
                            this.open_p = crate::prelude::or(&(&this.open_p).checked_sub(&crate::prelude::Nat::from(1u32)), &crate::prelude::Nat::from(0u32));
                            this
                        };
                        (RxLast::RxLastAtom, RxMeasure { depth_p: &m_p8.depth_p + &crate::prelude::Nat::from(1u32), size_p: m_p8.size_p.clone(), product_p: m_p8.product_p.clone() }, *outer_p3, closed_pa.clone())
                    }
                }
            }
        }
    }
}

/// ```prism
/// RxCapture: fn RxState, ?Text -> RxState
/// ```
pub fn rx_capture_f(st_p0: &RxState, name_o1: &::std::option::Option<crate::prelude::Text>) -> RxState {
    let n_p2 = &st_p0.groups_p + &crate::prelude::Nat::from(1u32);
    let names_p3 = match name_o1 {
        ::std::option::Option::Some(x_p4) => crate::prelude::insert(&st_p0.names_p, x_p4, &n_p2),
        ::std::option::Option::None => st_p0.names_p.clone(),
    };
    RxState { s_p: st_p0.s_p.clone(), i_p: st_p0.i_p.clone(), open_p: st_p0.open_p.clone(), groups_p: n_p2.clone(), names_p: names_p3.clone(), err_o: st_p0.err_o.clone() }
}

/// ```prism
/// ?RxReplacementRefusal: unbounded fn Text, Nat, (Text ==> Nat) -> ?RxDiag
/// ```
pub fn rx_replacement_refusal_o(r_p0: &crate::prelude::Text, groups_p1: &crate::prelude::Nat, names_p2: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>) -> ::std::option::Option<RxDiag> {
    let (d_of, _) = {
        let mut this: (::std::option::Option<RxDiag>, crate::prelude::Nat) = (::std::option::Option::None, crate::prelude::Nat::from(0u32));
        let mut i_p3: crate::prelude::Nat = crate::prelude::Nat::from(0u32);
        let mut d_o4: ::std::option::Option<RxDiag> = ::std::option::Option::None;
        while (&d_o4 == &::std::option::Option::None) && (&rx_char_at_f(r_p0, &i_p3) != &crate::prelude::Text::lit("")) {
            let at_p5 = i_p3.clone();
            let c_p6 = rx_char_at_f(r_p0, &at_p5);
            let next_p7 = rx_char_at_f(r_p0, &(&at_p5 + &crate::prelude::Nat::from(1u32)));
            if &c_p6 == &crate::prelude::Text::lit("$") {
                if &next_p7 == &crate::prelude::Text::lit("$") {
                    i_p3 = &at_p5 + &crate::prelude::Nat::from(2u32);
                } else if rx_is_digit_f(&next_p7) {
                    let j_p8 = rx_span_end_f(r_p0, &(&at_p5 + &crate::prelude::Nat::from(1u32)), &{
                        let f = ::std::rc::Rc::new(rx_is_digit_f);
                        ::std::rc::Rc::new(move |a0: crate::prelude::Text| {
                            let fy = f.clone();
                            crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    });
                    d_o4 = rx_group_number_o(&rx_slice_f(r_p0, &(&at_p5 + &crate::prelude::Nat::from(1u32)), &j_p8), groups_p1, &at_p5);
                    i_p3 = j_p8.clone();
                } else if &next_p7 == &crate::prelude::Text::lit("{") {
                    match &rx_find_o(r_p0, &(&at_p5 + &crate::prelude::Nat::from(2u32)), &crate::prelude::Text::lit("}")) {
                        ::std::option::Option::None => {
                            d_o4 = rx_replacement_at_o(&at_p5, &rx_rbraces_p());
                        }
                        ::std::option::Option::Some(close_p9) => {
                            let inner_pa = rx_slice_f(r_p0, &(&at_p5 + &crate::prelude::Nat::from(2u32)), close_p9);
                            if (&inner_pa != &crate::prelude::Text::lit("")) && rx_all_f(&inner_pa, &{
                                let f = ::std::rc::Rc::new(rx_is_digit_f);
                                ::std::rc::Rc::new(move |a0: crate::prelude::Text| {
                                    let fy = f.clone();
                                    crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            }) {
                                d_o4 = rx_group_number_o(&inner_pa, groups_p1, &at_p5);
                            } else if rx_is_name_f(&inner_pa) {
                                if &crate::prelude::get(names_p2, &inner_pa) == &::std::option::Option::None {
                                    d_o4 = rx_replacement_at_o(&at_p5, &rx_rno_name_p());
                                }
                            } else {
                                d_o4 = rx_replacement_at_o(&at_p5, &rx_rbraces_p());
                            }
                            i_p3 = close_p9 + &crate::prelude::Nat::from(1u32);
                        }
                    }
                } else {
                    d_o4 = rx_replacement_at_o(&at_p5, &rx_rdollar_p());
                }
            } else if &c_p6 == &crate::prelude::Text::lit("\\") {
                if (((&next_p7 == &crate::prelude::Text::lit("\\")) || (&next_p7 == &crate::prelude::Text::lit("n"))) || (&next_p7 == &crate::prelude::Text::lit("t"))) || (&next_p7 == &crate::prelude::Text::lit("/")) {
                    i_p3 = &at_p5 + &crate::prelude::Nat::from(2u32);
                } else if &next_p7 == &crate::prelude::Text::lit("u") {
                    let j_pb = rx_span_end_f(r_p0, &(&at_p5 + &crate::prelude::Nat::from(3u32)), &{
                        let f = ::std::rc::Rc::new(rx_is_hex_f);
                        ::std::rc::Rc::new(move |a0: crate::prelude::Text| {
                            let fy = f.clone();
                            crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    });
                    let digits_pc = rx_slice_f(r_p0, &(&at_p5 + &crate::prelude::Nat::from(3u32)), &j_pb);
                    let v_pd = rx_hex_value_f(&digits_pc);
                    let named_pe = ((((&rx_char_at_f(r_p0, &(&at_p5 + &crate::prelude::Nat::from(2u32))) == &crate::prelude::Text::lit("{")) && (&rx_char_at_f(r_p0, &j_pb) == &crate::prelude::Text::lit("}"))) && (&digits_pc != &crate::prelude::Text::lit(""))) && (&crate::prelude::len_text(&digits_pc) <= &crate::prelude::Nat::from(6u32))) && !(((&crate::prelude::Nat::from(55296u32) <= &v_pd) && (&v_pd <= &crate::prelude::Nat::from(57343u32))) || (&v_pd > &crate::prelude::Nat::from(1114111u32)));
                    if named_pe {
                        i_p3 = &j_pb + &crate::prelude::Nat::from(1u32);
                    } else {
                        d_o4 = rx_replacement_at_o(&at_p5, &rx_runicode_p());
                    }
                } else {
                    d_o4 = rx_replacement_at_o(&at_p5, &rx_rescape_p());
                }
            } else {
                i_p3 = &at_p5 + &crate::prelude::len_text(&c_p6);
            }
        }
        this = (d_o4.clone(), i_p3.clone());
        this
    };
    d_of.clone()
}

/// The step machine of `RxReplacementRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RxReplacementRefusal: unbounded fn Text, Nat, (Text ==> Nat) -> ?RxDiag
/// ```
pub struct RxReplacementRefusal {
    pub r_p0: crate::prelude::Text,
    pub groups_p1: crate::prelude::Nat,
    pub names_p2: crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>,
}

impl ::prism_rtl::Job<::std::option::Option<RxDiag>> for RxReplacementRefusal {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<RxDiag>> {
        let r_p0 = &self.r_p0;
        let groups_p1 = &self.groups_p1;
        let names_p2 = &self.names_p2;
        let mut this: (::std::option::Option<RxDiag>, crate::prelude::Nat) = (::std::option::Option::None, crate::prelude::Nat::from(0u32));
        let mut i_p3: crate::prelude::Nat = crate::prelude::Nat::from(0u32);
        let mut d_o4: ::std::option::Option<RxDiag> = ::std::option::Option::None;
        crate::prelude::call_then(crate::prelude::loop_job((d_o4, this, i_p3), {
            let groups_p1x = groups_p1.clone();
            let names_p2x = names_p2.clone();
            let r_p0x = r_p0.clone();
            move |(mut d_o4, mut this, mut i_p3): (::std::option::Option<RxDiag>, (::std::option::Option<RxDiag>, crate::prelude::Nat), crate::prelude::Nat)| if (&d_o4 == &::std::option::Option::None) && (&rx_char_at_f(&r_p0x, &i_p3) != &crate::prelude::Text::lit("")) {
                {
                    let at_p5 = i_p3.clone();
                    let c_p6 = rx_char_at_f(&r_p0x, &at_p5);
                    let next_p7 = rx_char_at_f(&r_p0x, &(&at_p5 + &crate::prelude::Nat::from(1u32)));
                    if &c_p6 == &crate::prelude::Text::lit("$") {
                        if &next_p7 == &crate::prelude::Text::lit("$") {
                            i_p3 = &at_p5 + &crate::prelude::Nat::from(2u32);
                        } else if rx_is_digit_f(&next_p7) {
                            let j_p8 = rx_span_end_f(&r_p0x, &(&at_p5 + &crate::prelude::Nat::from(1u32)), &{
                                let f = ::std::rc::Rc::new(rx_is_digit_f);
                                ::std::rc::Rc::new(move |a0: crate::prelude::Text| {
                                    let fy = f.clone();
                                    crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            });
                            d_o4 = rx_group_number_o(&rx_slice_f(&r_p0x, &(&at_p5 + &crate::prelude::Nat::from(1u32)), &j_p8), &groups_p1x, &at_p5);
                            i_p3 = j_p8.clone();
                        } else if &next_p7 == &crate::prelude::Text::lit("{") {
                            match &rx_find_o(&r_p0x, &(&at_p5 + &crate::prelude::Nat::from(2u32)), &crate::prelude::Text::lit("}")) {
                                ::std::option::Option::None => {
                                    d_o4 = rx_replacement_at_o(&at_p5, &rx_rbraces_p());
                                }
                                ::std::option::Option::Some(close_p9) => {
                                    let inner_pa = rx_slice_f(&r_p0x, &(&at_p5 + &crate::prelude::Nat::from(2u32)), close_p9);
                                    if (&inner_pa != &crate::prelude::Text::lit("")) && rx_all_f(&inner_pa, &{
                                        let f = ::std::rc::Rc::new(rx_is_digit_f);
                                        ::std::rc::Rc::new(move |a0: crate::prelude::Text| {
                                            let fy = f.clone();
                                            crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                    }) {
                                        d_o4 = rx_group_number_o(&inner_pa, &groups_p1x, &at_p5);
                                    } else if rx_is_name_f(&inner_pa) {
                                        if &crate::prelude::get(&names_p2x, &inner_pa) == &::std::option::Option::None {
                                            d_o4 = rx_replacement_at_o(&at_p5, &rx_rno_name_p());
                                        }
                                    } else {
                                        d_o4 = rx_replacement_at_o(&at_p5, &rx_rbraces_p());
                                    }
                                    i_p3 = close_p9 + &crate::prelude::Nat::from(1u32);
                                }
                            }
                        } else {
                            d_o4 = rx_replacement_at_o(&at_p5, &rx_rdollar_p());
                        }
                    } else if &c_p6 == &crate::prelude::Text::lit("\\") {
                        if (((&next_p7 == &crate::prelude::Text::lit("\\")) || (&next_p7 == &crate::prelude::Text::lit("n"))) || (&next_p7 == &crate::prelude::Text::lit("t"))) || (&next_p7 == &crate::prelude::Text::lit("/")) {
                            i_p3 = &at_p5 + &crate::prelude::Nat::from(2u32);
                        } else if &next_p7 == &crate::prelude::Text::lit("u") {
                            let j_pb = rx_span_end_f(&r_p0x, &(&at_p5 + &crate::prelude::Nat::from(3u32)), &{
                                let f = ::std::rc::Rc::new(rx_is_hex_f);
                                ::std::rc::Rc::new(move |a0: crate::prelude::Text| {
                                    let fy = f.clone();
                                    crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            });
                            let digits_pc = rx_slice_f(&r_p0x, &(&at_p5 + &crate::prelude::Nat::from(3u32)), &j_pb);
                            let v_pd = rx_hex_value_f(&digits_pc);
                            let named_pe = ((((&rx_char_at_f(&r_p0x, &(&at_p5 + &crate::prelude::Nat::from(2u32))) == &crate::prelude::Text::lit("{")) && (&rx_char_at_f(&r_p0x, &j_pb) == &crate::prelude::Text::lit("}"))) && (&digits_pc != &crate::prelude::Text::lit(""))) && (&crate::prelude::len_text(&digits_pc) <= &crate::prelude::Nat::from(6u32))) && !(((&crate::prelude::Nat::from(55296u32) <= &v_pd) && (&v_pd <= &crate::prelude::Nat::from(57343u32))) || (&v_pd > &crate::prelude::Nat::from(1114111u32)));
                            if named_pe {
                                i_p3 = &j_pb + &crate::prelude::Nat::from(1u32);
                            } else {
                                d_o4 = rx_replacement_at_o(&at_p5, &rx_runicode_p());
                            }
                        } else {
                            d_o4 = rx_replacement_at_o(&at_p5, &rx_rescape_p());
                        }
                    } else {
                        i_p3 = &at_p5 + &crate::prelude::len_text(&c_p6);
                    }
                    ::std::result::Result::Ok((d_o4, this, i_p3))
                }
            } else {
                ::std::result::Result::Err((d_o4, this, i_p3))
            }
        }), move |(mut d_o4, mut this, mut i_p3): (::std::option::Option<RxDiag>, (::std::option::Option<RxDiag>, crate::prelude::Nat), crate::prelude::Nat)| {
            this = (d_o4.clone(), i_p3.clone());
            let (d_of, _) = this;
            ::prism_rtl::Turn::Finished(d_of.clone())
        })
    }
}

/// `Start RxReplacementRefusal, x`: what the function value is when passed to `@Run`.
pub fn start_rx_replacement_refusal_o(r_p0: crate::prelude::Text, groups_p1: crate::prelude::Nat, names_p2: crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<RxDiag>>> {
    ::std::rc::Rc::new(RxReplacementRefusal { r_p0, groups_p1, names_p2 })
}

/// ```prism
/// ?RxReplacementAt: fn Nat, Text -> ?RxDiag
/// ```
pub fn rx_replacement_at_o(at_p0: &crate::prelude::Nat, message_p1: &crate::prelude::Text) -> ::std::option::Option<RxDiag> {
    ::std::option::Option::Some(RxDiag { part_p: crate::prelude::Text::lit("replacement"), at_p: at_p0.clone(), message_p: message_p1.clone() })
}

/// ```prism
/// ?RxGroupNumber: fn Text, Nat, Nat -> ?RxDiag
/// ```
pub fn rx_group_number_o(digits_p0: &crate::prelude::Text, groups_p1: &crate::prelude::Nat, at_p2: &crate::prelude::Nat) -> ::std::option::Option<RxDiag> {
    if rx_leading_zero_f(digits_p0) {
        rx_replacement_at_o(at_p2, &rx_rzero_p())
    } else {
        if &crate::prelude::or(&crate::prelude::parse_nat_opt(digits_p0), &crate::prelude::Nat::from(0u32)) > groups_p1 {
            rx_replacement_at_o(at_p2, &rx_rno_number_p())
        } else {
            ::std::option::Option::None
        }
    }
}
