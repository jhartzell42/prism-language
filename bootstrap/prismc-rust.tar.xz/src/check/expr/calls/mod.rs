//! The module `Check.Expr.Calls`, from `target/bootstrap/src/prismc/check/expr/calls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Peeled`:
///
/// ```prism
/// type Peeled = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Peeled {
    pub events: Array<crate::syntax::Range>,
    pub dyns: Array<crate::syntax::Range>,
    pub opts: Array<Text>,
    pub lifted: Text,
    pub broken: bool,
}

impl Show for Peeled {
    fn show(&self, p: &mut Printer) {
        p.record("Peeled", &[("events", &self.events), ("dyns", &self.dyns), ("opts", &self.opts), ("lifted", &self.lifted), ("broken", &self.broken)]);
    }
}

impl ToPod for Peeled {
    fn to_pod(&self) -> Pod {
        Pod::record("Peeled", vec![("events", self.events.to_pod()), ("dyns", self.dyns.to_pod()), ("opts", self.opts.to_pod()), ("lifted", self.lifted.to_pod()), ("broken", self.broken.to_pod())])
    }
}

impl FromPod for Peeled {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Peeled { events: FromPod::from_pod(field(p, "events")?)?, dyns: FromPod::from_pod(field(p, "dyns")?)?, opts: FromPod::from_pod(field(p, "opts")?)?, lifted: FromPod::from_pod(field(p, "lifted")?)?, broken: FromPod::from_pod(field(p, "broken")?)? })
    }
}

/// ```prism
/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
/// ```
pub fn infer_call(env: &crate::check::expr::Env, st: &crate::check::types::St, callee: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*callee.kind {
        crate::syntax::ExprKind::EName(n) => {
            let local = crate::check::env::sname_key(n);
            match get(&env.locals, &local) {
                Some(sc) => {
                    let (t, st2) = crate::check::expr::instantiate_local(st, &sc, &callee.span, &local);
                    apply_fn(env, &crate::check::types::recording::note_ty(&st2, &callee.span, &t), &local, &t, &positional(args), span)
                },
                None => call_global(env, st, n, args, span, &Array::new(), &callee.span),
            }
        },
        crate::syntax::ExprKind::ETypeArgs(target, tys) => match &*target.kind {
            crate::syntax::ExprKind::EName(n) => {
                let cx_ = crate::check::expr::env_cx(env);
                let (given2, st2) = crate::check::env::reading::conv_types(&cx_, st, tys);
                call_global(env, &st2, n, args, span, &given2, &callee.span)
            },
            _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("mismatch"), &callee.span, &Text::lit("`<<T>>` applies to a function's name"))),
        },
        crate::syntax::ExprKind::EGroup(x) => infer_call(env, st, &**x, args, span),
        _ => {
            let (t, st2) = crate::check::expr::infer(env, st, callee);
            apply_fn(env, &st2, &crate::check::expr::src_text(env, &callee.span), &t, &positional(args), span)
        },
    }
}

/// The step machine of `InferCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
/// ```
pub struct InferCall {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub callee: crate::syntax::Expr,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferCall {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let callee = &self.callee;
        let args = &self.args;
        let span = &self.span;
        match &*callee.kind {
            crate::syntax::ExprKind::EName(n) => {
                let local = crate::check::env::sname_key(n);
                match get(&env.locals, &local) {
                    Some(sc) => {
                        let args = args.clone();
                        let callee = callee.clone();
                        let env = env.clone();
                        let span = span.clone();
                        let st = st.clone();
                        call_then(crate::check::expr::start_instantiate_local(st.clone(), sc.clone(), callee.span.clone(), local.clone()), move |instantiate_local_1491: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t, st2) = instantiate_local_1491;
                            prism_rtl::Turn::More(Rc::new(ApplyFn { env: env.clone(), st: crate::check::types::recording::note_ty(&st2, &callee.span, &t), fname: local.clone(), fty: t.clone(), args: positional(&args), span: span.clone() }))
                        })
                    },
                    None => prism_rtl::Turn::More(Rc::new(CallGlobal { env: env.clone(), st0: st.clone(), n: n.clone(), args: args.clone(), span: span.clone(), explicit: Array::new(), cspan: callee.span.clone() })),
                }
            },
            crate::syntax::ExprKind::ETypeArgs(target, tys) => match &*target.kind {
                crate::syntax::ExprKind::EName(n) => {
                    let cx_ = crate::check::expr::env_cx(env);
                    let args = args.clone();
                    let callee = callee.clone();
                    let env = env.clone();
                    let n = n.clone();
                    let span = span.clone();
                    let st = st.clone();
                    let tys = tys.clone();
                    call_then(crate::check::env::reading::start_conv_types(cx_.clone(), st.clone(), tys.clone()), move |conv_types_1826: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                        let (given2, st2) = conv_types_1826;
                        prism_rtl::Turn::More(Rc::new(CallGlobal { env: env.clone(), st0: st2.clone(), n: n.clone(), args: args.clone(), span: span.clone(), explicit: given2.clone(), cspan: callee.span.clone() }))
                    })
                },
                _ => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("mismatch"), &callee.span, &Text::lit("`<<T>>` applies to a function's name")))),
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(InferCall { env: env.clone(), st: st.clone(), callee: (**x).clone(), args: args.clone(), span: span.clone() })),
            _ => {
                let args = args.clone();
                let callee = callee.clone();
                let env = env.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), callee.clone()), move |infer_2107: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_2107;
                    prism_rtl::Turn::More(Rc::new(ApplyFn { env: env.clone(), st: st2.clone(), fname: crate::check::expr::src_text(&env, &callee.span), fty: t.clone(), args: positional(&args), span: span.clone() }))
                })
            },
        }
    }
}

/// `Start InferCall, x`: what the function value is when passed to `@Run`.
pub fn start_infer_call(env: crate::check::expr::Env, st: crate::check::types::St, callee: crate::syntax::Expr, args: Array<crate::syntax::Arg>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferCall { env, st, callee, args, span })
}

/// ```prism
/// Positional: fn [Arg] -> [Arg]
/// ```
pub fn positional(args: &Array<crate::syntax::Arg>) -> Array<crate::syntax::Arg> {
    args.clone()
}

/// ```prism
/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
/// ```
pub fn call_global(env: &crate::check::expr::Env, st0: &crate::check::types::St, n: &crate::syntax::SName, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range, explicit: &Array<crate::check::types::Ty>, cspan: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (qk_opt, why) = crate::check::env::names::resolve_value(&env.g, &env.home, n);
    let name = crate::check::env::sname_key(n);
    let st = crate::check::expr::collision_at(env, st0, &why, &name, &n.span);
    match &qk_opt {
        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("nothing declares `{}` here", &name)))),
        Some(qk) => if &why == &Text::lit("tag") {
            tag_app(env, &st, qk, args, span, cspan)
        } else {
            if is_local_maker(qk) && !env.in_update {
                (crate::check::types::Ty::TyErr, local_outside(&st, qk, span))
            } else {
                match get(&env.g.vals, qk) {
                    Some(v_) => {
                        let (t, st2i, inst) = crate::check::types::schemes::instantiate_with(&st, &v_.scheme, span, explicit);
                        let (rigids, st2) = rank_two(&st2i, &v_.scheme, &inst, &len(explicit), span);
                        let st3a = note_callee(&note_method_use(&st2, &v_, span), &n.span, cspan, &t);
                        let st3 = if &crate::check::types::bare_name(qk) == &Text::lit("Min") {
                            crate::check::types::recording::note_size_ty(&st3a, span, &crate::check::types::recording::walk(&st3a, &t))
                        } else {
                            st3a.clone()
                        };
                        if (&crate::check::types::bare_name(qk) == &Text::lit("Fold")) && (&v_.home == &Text::lit("Prelude")) {
                            fold_app(env, &st3, &t, args, span)
                        } else {
                            {
                                let (rt, st4) = apply_fn(env, &st3, &name, &t, args, span);
                                (rt.clone(), escaped(env, &st4, &rigids, &rt, &name, span))
                            }
                        }
                    },
                    None => match get(&env.g.ctors, qk) {
                        Some(c) => ctor_app(env, &st, &c, args, span, cspan),
                        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("`{}` has no signature line", &name)))),
                    },
                }
            }
        },
    }
}

/// The step machine of `CallGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
/// ```
pub struct CallGlobal {
    pub env: crate::check::expr::Env,
    pub st0: crate::check::types::St,
    pub n: crate::syntax::SName,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
    pub explicit: Array<crate::check::types::Ty>,
    pub cspan: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for CallGlobal {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st0 = &self.st0;
        let n = &self.n;
        let args = &self.args;
        let span = &self.span;
        let explicit = &self.explicit;
        let cspan = &self.cspan;
        let (qk_opt, why) = crate::check::env::names::resolve_value(&env.g, &env.home, n);
        let name = crate::check::env::sname_key(n);
        let st = crate::check::expr::collision_at(env, st0, &why, &name, &n.span);
        match &qk_opt {
            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("nothing declares `{}` here", &name))))),
            Some(qk) => if &why == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(TagApp { env: env.clone(), st: st.clone(), name: qk.clone(), args: args.clone(), span: span.clone(), cspan: cspan.clone() }))
            } else {
                if is_local_maker(qk) && !env.in_update {
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, local_outside(&st, qk, span)))
                } else {
                    match get(&env.g.vals, qk) {
                        Some(v_) => {
                            let args = args.clone();
                            let cspan = cspan.clone();
                            let env = env.clone();
                            let explicit = explicit.clone();
                            let n = n.clone();
                            let qk = qk.clone();
                            let span = span.clone();
                            call_then(crate::check::types::schemes::start_instantiate_with(st.clone(), v_.scheme.clone(), span.clone(), explicit.clone()), move |instantiate_with_2931: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                                let (t, st2i, inst) = instantiate_with_2931;
                                call_then(start_rank_two(st2i.clone(), v_.scheme.clone(), inst.clone(), len(&explicit), span.clone()), move |rank_two_3018: (Array<Text>, crate::check::types::St)| {
                                    let (rigids, st2) = rank_two_3018;
                                    let st3a = note_callee(&note_method_use(&st2, &v_, &span), &n.span, &cspan, &t);
                                    let st3 = if &crate::check::types::bare_name(&qk) == &Text::lit("Min") {
                                        crate::check::types::recording::note_size_ty(&st3a, &span, &crate::check::types::recording::walk(&st3a, &t))
                                    } else {
                                        st3a.clone()
                                    };
                                    if (&crate::check::types::bare_name(&qk) == &Text::lit("Fold")) && (&v_.home == &Text::lit("Prelude")) {
                                        prism_rtl::Turn::More(Rc::new(FoldApp { env: env.clone(), st: st3.clone(), t: t.clone(), args: args.clone(), span: span.clone() }))
                                    } else {
                                        call_then(start_apply_fn(env.clone(), st3.clone(), name.clone(), t.clone(), args.clone(), span.clone()), move |apply_fn_3436: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (rt, st4) = apply_fn_3436;
                                            call_then(start_escaped(env.clone(), st4.clone(), rigids.clone(), rt.clone(), name.clone(), span.clone()), move |escaped_3505: crate::check::types::St| prism_rtl::Turn::Finished((rt.clone(), escaped_3505)))
                                        })
                                    }
                                })
                            })
                        },
                        None => match get(&env.g.ctors, qk) {
                            Some(c) => prism_rtl::Turn::More(Rc::new(CtorApp { env: env.clone(), st: st.clone(), c: c.clone(), args: args.clone(), span: span.clone(), cspan: cspan.clone() })),
                            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("`{}` has no signature line", &name))))),
                        },
                    }
                }
            },
        }
    }
}

/// `Start CallGlobal, x`: what the function value is when passed to `@Run`.
pub fn start_call_global(env: crate::check::expr::Env, st0: crate::check::types::St, n: crate::syntax::SName, args: Array<crate::syntax::Arg>, span: crate::syntax::Range, explicit: Array<crate::check::types::Ty>, cspan: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(CallGlobal { env, st0, n, args, span, explicit, cspan })
}

/// ```prism
/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
/// ```
pub fn rank_two(st: &crate::check::types::St, sc: &crate::check::types::Scheme, inst: &crate::check::types::schemes::Inst, n_explicit: &Nat, span: &crate::syntax::Range) -> (Array<Text>, crate::check::types::St) {
    let qs = filter(&crate::check::errors::range0(&len(&sc.qs)), &(|i: &Nat| (i >= n_explicit) && is_rank_two(&or(&index(&sc.qs, i), &Text::lit("")), &sc.ty)));
    run_to_end(fold_job(qs.clone(), (Array::new(), st.clone()), {
        let sc = sc.clone();
        let inst = inst.clone();
        let span = span.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, crate::check::types::St), Nat)| {
            let sc = sc.clone();
            let inst = inst.clone();
            let span = span.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let i = p1;
                {
                    let q = or(&index(&sc.qs, &i), &Text::lit(""));
                    let rigid = Text::from(format!("{}'{}", &q, &s.next));
                    let s2 = {
                        let mut this: crate::check::types::St = s.clone();
                        this.next = &this.next + &Nat::from(1u32);
                        this
                    };
                    call_then(crate::check::types::unify::start_unify(s2.clone(), or(&get(&inst.tys, &q), &crate::check::types::Ty::TyErr), crate::check::types::Ty::TyRigid(rigid.clone()), span.clone()), move |unify_4584: crate::check::types::St| prism_rtl::Turn::Finished((push(&acc, &rigid), unify_4584)))
                }
            }))
        }) as Rc<dyn Fn(((Array<Text>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>>>
    }))
}

/// The step machine of `RankTwo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
/// ```
pub struct RankTwo {
    pub st: crate::check::types::St,
    pub sc: crate::check::types::Scheme,
    pub inst: crate::check::types::schemes::Inst,
    pub n_explicit: Nat,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(Array<Text>, crate::check::types::St)> for RankTwo {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, crate::check::types::St)> {
        let st = &self.st;
        let sc = &self.sc;
        let inst = &self.inst;
        let n_explicit = &self.n_explicit;
        let span = &self.span;
        let qs = filter(&crate::check::errors::range0(&len(&sc.qs)), &(|i: &Nat| (i >= n_explicit) && is_rank_two(&or(&index(&sc.qs, i), &Text::lit("")), &sc.ty)));
        fold_job(qs.clone(), (Array::new(), st.clone()), {
            let sc = sc.clone();
            let inst = inst.clone();
            let span = span.clone();
            Rc::new(move |(p0, p1): ((Array<Text>, crate::check::types::St), Nat)| {
                let sc = sc.clone();
                let inst = inst.clone();
                let span = span.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let i = p1;
                    {
                        let q = or(&index(&sc.qs, &i), &Text::lit(""));
                        let rigid = Text::from(format!("{}'{}", &q, &s.next));
                        let s2 = {
                            let mut this: crate::check::types::St = s.clone();
                            this.next = &this.next + &Nat::from(1u32);
                            this
                        };
                        call_then(crate::check::types::unify::start_unify(s2.clone(), or(&get(&inst.tys, &q), &crate::check::types::Ty::TyErr), crate::check::types::Ty::TyRigid(rigid.clone()), span.clone()), move |unify_4584: crate::check::types::St| prism_rtl::Turn::Finished((push(&acc, &rigid), unify_4584)))
                    }
                }))
            }) as Rc<dyn Fn(((Array<Text>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start RankTwo, x`: what the function value is when passed to `@Run`.
pub fn start_rank_two(st: crate::check::types::St, sc: crate::check::types::Scheme, inst: crate::check::types::schemes::Inst, n_explicit: Nat, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>> {
    Rc::new(RankTwo { st, sc, inst, n_explicit, span })
}

/// ```prism
/// IsRankTwo: fn Text, Ty -> Bool
/// ```
pub fn is_rank_two(q: &Text, t: &crate::check::types::Ty) -> bool {
    match t {
        crate::check::types::Ty::TyFn(_, ps, res) => {
            let holding = filter(ps, &(|p_: &crate::check::types::Ty| qoccurs(q, p_)));
            if (&len(&holding) != &Nat::from(1u32)) || qoccurs(q, &**res) {
                false
            } else {
                match index(&holding, &Nat::from(0u32)) {
                    Some(crate::check::types::Ty::TyFn(_, _, _)) => elem_out_q(q, &or(&index(&holding, &Nat::from(0u32)), &crate::check::types::Ty::TyErr)),
                    _ => false,
                }
            }
        },
        _ => false,
    }
}

/// ```prism
/// QOccurs: fn Text, Ty -> Bool
/// ```
pub fn qoccurs(q: &Text, t: &crate::check::types::Ty) -> bool {
    match t {
        crate::check::types::Ty::TyQ(n) => n == q,
        crate::check::types::Ty::TyCon(_, args) => fold(args, &false, &(|seen: &bool, a: &crate::check::types::Ty| *seen || qoccurs(q, a))),
        crate::check::types::Ty::TyFn(_, ps, r) => fold(ps, &qoccurs(q, &**r), &(|seen: &bool, a: &crate::check::types::Ty| *seen || qoccurs(q, a))),
        crate::check::types::Ty::TyTuple(ts) => fold(ts, &false, &(|seen: &bool, a: &crate::check::types::Ty| *seen || qoccurs(q, a))),
        crate::check::types::Ty::TyArray(e) => qoccurs(q, &**e),
        crate::check::types::Ty::TyMap(k, v_) => qoccurs(q, &**k) || qoccurs(q, &**v_),
        crate::check::types::Ty::TySig(_, i) => qoccurs(q, &**i),
        crate::check::types::Ty::TyAt(i, _) => qoccurs(q, &**i),
        crate::check::types::Ty::TyElem(_, o) => qoccurs(q, &**o),
        crate::check::types::Ty::TyAssoc(_, i) => qoccurs(q, &**i),
        _ => false,
    }
}

/// ```prism
/// ElemOutQ: fn Text, Ty -> Bool
/// ```
pub fn elem_out_q(q: &Text, t: &crate::check::types::Ty) -> bool {
    match t {
        crate::check::types::Ty::TyElem(_, o) => (&**o == &crate::check::types::Ty::TyQ(q.clone())) || elem_out_q(q, &**o),
        crate::check::types::Ty::TyCon(_, args) => fold(args, &false, &(|seen: &bool, a: &crate::check::types::Ty| *seen || elem_out_q(q, a))),
        crate::check::types::Ty::TyFn(_, ps, r) => fold(ps, &elem_out_q(q, &**r), &(|seen: &bool, a: &crate::check::types::Ty| *seen || elem_out_q(q, a))),
        crate::check::types::Ty::TyTuple(ts) => fold(ts, &false, &(|seen: &bool, a: &crate::check::types::Ty| *seen || elem_out_q(q, a))),
        crate::check::types::Ty::TyArray(e) => elem_out_q(q, &**e),
        crate::check::types::Ty::TyMap(k, v_) => elem_out_q(q, &**k) || elem_out_q(q, &**v_),
        crate::check::types::Ty::TySig(_, i) => elem_out_q(q, &**i),
        crate::check::types::Ty::TyAt(i, _) => elem_out_q(q, &**i),
        _ => false,
    }
}

/// ```prism
/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
/// ```
pub fn escaped(env: &crate::check::expr::Env, st: &crate::check::types::St, rigids: &Array<Text>, rt: &crate::check::types::Ty, fname: &Text, span: &crate::syntax::Range) -> crate::check::types::St {
    run_to_end(fold_job(rigids.clone(), st.clone(), {
        let env = env.clone();
        let rt = rt.clone();
        let span = span.clone();
        let fname = fname.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
            let env = env.clone();
            let rt = rt.clone();
            let span = span.clone();
            let fname = fname.clone();
            entered(once_job(move || {
                let s = p0;
                let r = p1;
                call_value(filter_job(keys(&env.locals), {
                    let s = s.clone();
                    let r = r.clone();
                    let env = env.clone();
                    Rc::new(move |p0: Text| {
                        let s = s.clone();
                        let r = r.clone();
                        let env = env.clone();
                        entered(once_job(move || {
                            let k = p0;
                            prism_rtl::Turn::More(Rc::new(HasRigid { st: s.clone(), r: r.clone(), t: or(&get(&env.locals, &k), &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)).ty.clone() }))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |filter_6547: Array<Text>| {
                    let outside = filter_6547;
                    call_then(start_has_rigid(s.clone(), r.clone(), rt.clone()), move |has_rigid_6636: bool| if has_rigid_6636 {
                        prism_rtl::Turn::Finished(crate::check::types::recording::err(&s, &Text::lit("refinement-escape"), &span, &Text::from(format!("the call's result takes the output of the element `{}`'s supplier answers, which is the supplier's alone (rank-2)", &fname))))
                    } else {
                        match index(&outside, &Nat::from(0u32)) {
                            Some(k) => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s, &Text::lit("refinement-escape"), &span, &Text::from(format!("`{}`, outside the supplier `{}` is given, takes the output of the element the supplier answers, which is the supplier's alone (rank-2)", &k, &fname)))),
                            None => prism_rtl::Turn::Finished(s.clone()),
                        }
                    })
                })
            }))
        }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `Escaped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
/// ```
pub struct Escaped {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub rigids: Array<Text>,
    pub rt: crate::check::types::Ty,
    pub fname: Text,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for Escaped {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let rigids = &self.rigids;
        let rt = &self.rt;
        let fname = &self.fname;
        let span = &self.span;
        fold_job(rigids.clone(), st.clone(), {
            let env = env.clone();
            let rt = rt.clone();
            let span = span.clone();
            let fname = fname.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
                let env = env.clone();
                let rt = rt.clone();
                let span = span.clone();
                let fname = fname.clone();
                entered(once_job(move || {
                    let s = p0;
                    let r = p1;
                    call_value(filter_job(keys(&env.locals), {
                        let s = s.clone();
                        let r = r.clone();
                        let env = env.clone();
                        Rc::new(move |p0: Text| {
                            let s = s.clone();
                            let r = r.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let k = p0;
                                prism_rtl::Turn::More(Rc::new(HasRigid { st: s.clone(), r: r.clone(), t: or(&get(&env.locals, &k), &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)).ty.clone() }))
                            }))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |filter_6547: Array<Text>| {
                        let outside = filter_6547;
                        call_then(start_has_rigid(s.clone(), r.clone(), rt.clone()), move |has_rigid_6636: bool| if has_rigid_6636 {
                            prism_rtl::Turn::Finished(crate::check::types::recording::err(&s, &Text::lit("refinement-escape"), &span, &Text::from(format!("the call's result takes the output of the element `{}`'s supplier answers, which is the supplier's alone (rank-2)", &fname))))
                        } else {
                            match index(&outside, &Nat::from(0u32)) {
                                Some(k) => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s, &Text::lit("refinement-escape"), &span, &Text::from(format!("`{}`, outside the supplier `{}` is given, takes the output of the element the supplier answers, which is the supplier's alone (rank-2)", &k, &fname)))),
                                None => prism_rtl::Turn::Finished(s.clone()),
                            }
                        })
                    })
                }))
            }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start Escaped, x`: what the function value is when passed to `@Run`.
pub fn start_escaped(env: crate::check::expr::Env, st: crate::check::types::St, rigids: Array<Text>, rt: crate::check::types::Ty, fname: Text, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Escaped { env, st, rigids, rt, fname, span })
}

/// ```prism
/// HasRigid: unbounded fn St, Text, Ty -> Bool
/// ```
pub fn has_rigid(st: &crate::check::types::St, r: &Text, t: &crate::check::types::Ty) -> bool {
    rigid_in(r, &crate::check::types::recording::zonk(st, t))
}

/// The step machine of `HasRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HasRigid: unbounded fn St, Text, Ty -> Bool
/// ```
pub struct HasRigid {
    pub st: crate::check::types::St,
    pub r: Text,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for HasRigid {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st = &self.st;
        let r = &self.r;
        let t = &self.t;
        let r = r.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_zonk(st.clone(), t.clone()), move |zonk_7123: crate::check::types::Ty| prism_rtl::Turn::Finished(rigid_in(&r, &zonk_7123)))
    }
}

/// `Start HasRigid, x`: what the function value is when passed to `@Run`.
pub fn start_has_rigid(st: crate::check::types::St, r: Text, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HasRigid { st, r, t })
}

/// ```prism
/// RigidIn: fn Text, Ty -> Bool
/// ```
pub fn rigid_in(r: &Text, t: &crate::check::types::Ty) -> bool {
    match t {
        crate::check::types::Ty::TyRigid(n) => n == r,
        crate::check::types::Ty::TyCon(_, args) => fold(args, &false, &(|seen: &bool, a: &crate::check::types::Ty| *seen || rigid_in(r, a))),
        crate::check::types::Ty::TyFn(_, ps, res) => fold(ps, &rigid_in(r, &**res), &(|seen: &bool, a: &crate::check::types::Ty| *seen || rigid_in(r, a))),
        crate::check::types::Ty::TyTuple(ts) => fold(ts, &false, &(|seen: &bool, a: &crate::check::types::Ty| *seen || rigid_in(r, a))),
        crate::check::types::Ty::TyArray(e) => rigid_in(r, &**e),
        crate::check::types::Ty::TyMap(k, v_) => rigid_in(r, &**k) || rigid_in(r, &**v_),
        crate::check::types::Ty::TySig(_, i) => rigid_in(r, &**i),
        crate::check::types::Ty::TyAt(i, _) => rigid_in(r, &**i),
        crate::check::types::Ty::TyElem(_, o) => rigid_in(r, &**o),
        crate::check::types::Ty::TyAssoc(_, i) => rigid_in(r, &**i),
        _ => false,
    }
}

/// ```prism
/// IsLocalMaker: fn Text -> Bool
/// ```
pub fn is_local_maker(qk: &Text) -> bool {
    crate::check::types::has_text(&Array::from(vec![Text::lit("Buffer.Numbered"), Text::lit("Buffer.Empty"), Text::lit("Table.Empty")]), qk)
}

/// ```prism
/// LocalOutside: fn St, Text, Range -> St
/// ```
pub fn local_outside(st: &crate::check::types::St, qk: &Text, span: &crate::syntax::Range) -> crate::check::types::St {
    crate::check::types::recording::err_fix(st, &Text::lit("local-escapes"), span, &Text::from(format!("a `{}` lives only in an `&` block's local", &or(&index(&split_on(qk, &Text::lit(".")), &Nat::from(0u32)), qk))), &Text::from(format!("make it inside `update ...:` as `let &b = {} ...`, and `Freeze &b` for the plain value", qk)))
}

/// ```prism
/// NoteCallee: fn St, Range, Range, Ty -> St
/// ```
pub fn note_callee(st: &crate::check::types::St, at_: &crate::syntax::Range, cspan: &crate::syntax::Range, t: &crate::check::types::Ty) -> crate::check::types::St {
    if at_ == cspan {
        crate::check::types::recording::note_ty(st, at_, t)
    } else {
        crate::check::types::recording::note_ty(&crate::check::types::recording::note_ty(st, at_, t), cspan, t)
    }
}

/// ```prism
/// NoteMethodUse: fn St, ValInfo, Range -> St
/// ```
pub fn note_method_use(st: &crate::check::types::St, v_: &crate::check::env::ValInfo, span: &crate::syntax::Range) -> crate::check::types::St {
    if &v_.sort != &Text::lit("method") {
        st.clone()
    } else {
        {
            let (_, cls) = or(&index(&v_.scheme.bounds, &Nat::from(0u32)), &(Text::lit(""), Text::lit("")));
            crate::check::types::recording::note_method(st, span, &v_.qk, &cls)
        }
    }
}

/// ```prism
/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn fold_app(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::check::types::Ty, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let lambda_arity_ = match index(args, &Nat::from(2u32)) {
        Some(a) => lambda_arity(&a.value),
        None => Nat::from(2u32),
    };
    if &lambda_arity_ == &Nat::from(3u32) {
        match crate::check::types::recording::walk(st, t) {
            crate::check::types::Ty::TyFn(col, params, res) => {
                let (k, st1) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                let (v_, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
                let (b, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
                let step_col = match index(&params, &Nat::from(2u32)) {
                    Some(crate::check::types::Ty::TyFn(c, _, _)) => c.clone(),
                    _ => col.clone(),
                };
                let params2 = Array::from(vec![crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone())), b.clone(), crate::check::types::Ty::TyFn(step_col.clone(), Array::from(vec![b.clone(), k.clone(), v_.clone()]), Rc::new(b.clone()))]);
                apply_rule(env, &st3, &Text::lit("Fold"), &col, &params2, &b, args, span)
            },
            _ => apply_fn(env, st, &Text::lit("Fold"), t, args, span),
        }
    } else {
        apply_fn(env, st, &Text::lit("Fold"), t, args, span)
    }
}

/// The step machine of `FoldApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct FoldApp {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for FoldApp {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let args = &self.args;
        let span = &self.span;
        let lambda_arity_ = match index(args, &Nat::from(2u32)) {
            Some(a) => lambda_arity(&a.value),
            None => Nat::from(2u32),
        };
        if &lambda_arity_ == &Nat::from(3u32) {
            {
                let args = args.clone();
                let env = env.clone();
                let span = span.clone();
                let st = st.clone();
                let t = t.clone();
                call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_9063: crate::check::types::Ty| match walk_9063 {
                    crate::check::types::Ty::TyFn(col, params, res) => {
                        let (k, st1) = crate::check::types::fresh_var(&st, &false, &Text::lit(""));
                        let (v_, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
                        let (b, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
                        let step_col = match index(&params, &Nat::from(2u32)) {
                            Some(crate::check::types::Ty::TyFn(c, _, _)) => c.clone(),
                            _ => col.clone(),
                        };
                        let params2 = Array::from(vec![crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone())), b.clone(), crate::check::types::Ty::TyFn(step_col.clone(), Array::from(vec![b.clone(), k.clone(), v_.clone()]), Rc::new(b.clone()))]);
                        prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st3.clone(), fname: Text::lit("Fold"), col: col.clone(), params: params2.clone(), res: b.clone(), args: args.clone(), span: span.clone() }))
                    },
                    _ => prism_rtl::Turn::More(Rc::new(ApplyFn { env: env.clone(), st: st.clone(), fname: Text::lit("Fold"), fty: t.clone(), args: args.clone(), span: span.clone() })),
                })
            }
        } else {
            prism_rtl::Turn::More(Rc::new(ApplyFn { env: env.clone(), st: st.clone(), fname: Text::lit("Fold"), fty: t.clone(), args: args.clone(), span: span.clone() }))
        }
    }
}

/// `Start FoldApp, x`: what the function value is when passed to `@Run`.
pub fn start_fold_app(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::check::types::Ty, args: Array<crate::syntax::Arg>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(FoldApp { env, st, t, args, span })
}

/// ```prism
/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn apply_fn(env: &crate::check::expr::Env, st: &crate::check::types::St, fname: &Text, fty: &crate::check::types::Ty, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let named = filter(args, &(|a: &crate::syntax::Arg| &a.name != &None));
    let st0 = if &len(&named) > &Nat::from(0u32) {
        crate::check::types::recording::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`{}` takes its arguments by position; named arguments are a record's or a tag's", fname)))
    } else {
        st.clone()
    };
    match crate::check::types::recording::walk(&st0, fty) {
        crate::check::types::Ty::TyFn(col, params, res) => if &len(&params) != &len(args) {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st0, &Text::lit("mismatch"), span, &Text::from(format!("`{}` takes {} argument{}; here it has {}", fname, &crate::check::errors::count_word(&len(&params)), &(if &len(&params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(args))))))
        } else {
            apply_rule(env, &st0, fname, &col, &params, &*res, args, span)
        },
        crate::check::types::Ty::TyFlex(_) => {
            let (params, st1) = fold(args, &(Array::new(), st0.clone()), &(|(acc, s): &(Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Arg| {
                let (v_, s2) = crate::check::types::fresh_var(s, &false, &Text::lit(""));
                (push(acc, &v_), s2.clone())
            }));
            let (res, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
            let (col, st2b) = crate::check::types::fresh_col(&st2);
            let st3 = crate::check::types::unify::unify(&st2b, fty, &crate::check::types::Ty::TyFn(col.clone(), params.clone(), Rc::new(res.clone())), span);
            apply_rule(env, &st3, fname, &col, &params, &res, args, span)
        },
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st0.clone()),
        other => if &len(args) == &Nat::from(0u32) {
            (other.clone(), st0.clone())
        } else {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st0, &Text::lit("mismatch"), span, &Text::from(format!("`{}` is a `{}`, not a function", fname, &crate::check::types::show_ty(&st0, &other)))))
        },
    }
}

/// The step machine of `ApplyFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct ApplyFn {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub fname: Text,
    pub fty: crate::check::types::Ty,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ApplyFn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let fname = &self.fname;
        let fty = &self.fty;
        let args = &self.args;
        let span = &self.span;
        let named = filter(args, &(|a: &crate::syntax::Arg| &a.name != &None));
        let st0 = if &len(&named) > &Nat::from(0u32) {
            crate::check::types::recording::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`{}` takes its arguments by position; named arguments are a record's or a tag's", fname)))
        } else {
            st.clone()
        };
        let args = args.clone();
        let env = env.clone();
        let fname = fname.clone();
        let fty = fty.clone();
        let span = span.clone();
        call_then(crate::check::types::recording::start_walk(st0.clone(), fty.clone()), move |walk_10097: crate::check::types::Ty| match walk_10097 {
            crate::check::types::Ty::TyFn(col, params, res) => if &len(&params) != &len(&args) {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st0, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` takes {} argument{}; here it has {}", &fname, &crate::check::errors::count_word(&len(&params)), &(if &len(&params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(&args)))))))
            } else {
                prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st0.clone(), fname: fname.clone(), col: col.clone(), params: params.clone(), res: (*res).clone(), args: args.clone(), span: span.clone() }))
            },
            crate::check::types::Ty::TyFlex(_) => {
                let (params, st1) = fold(&args, &(Array::new(), st0.clone()), &(|(acc, s): &(Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Arg| {
                    let (v_, s2) = crate::check::types::fresh_var(s, &false, &Text::lit(""));
                    (push(acc, &v_), s2.clone())
                }));
                let (res, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
                let (col, st2b) = crate::check::types::fresh_col(&st2);
                call_then(crate::check::types::unify::start_unify(st2b.clone(), fty.clone(), crate::check::types::Ty::TyFn(col.clone(), params.clone(), Rc::new(res.clone())), span.clone()), move |unify_10759: crate::check::types::St| {
                    let st3 = unify_10759;
                    prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st3.clone(), fname: fname.clone(), col: col.clone(), params: params.clone(), res: res.clone(), args: args.clone(), span: span.clone() }))
                })
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st0.clone())),
            other => if &len(&args) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished((other.clone(), st0.clone()))
            } else {
                call_then(crate::check::types::start_show_ty(st0.clone(), other.clone()), move |show_ty_11039: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st0, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` is a `{}`, not a function", &fname, &show_ty_11039))))))
            },
        })
    }
}

/// `Start ApplyFn, x`: what the function value is when passed to `@Run`.
pub fn start_apply_fn(env: crate::check::expr::Env, st: crate::check::types::St, fname: Text, fty: crate::check::types::Ty, args: Array<crate::syntax::Arg>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(ApplyFn { env, st, fname, fty, args, span })
}

/// ```prism
/// Broken: fn Peeled, Bool -> Peeled
/// ```
pub fn broken(p_: &Peeled, b: &bool) -> Peeled {
    if !*b {
        p_.clone()
    } else {
        {
            let mut this: Peeled = p_.clone();
            this.broken = true;
            this
        }
    }
}

/// ```prism
/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn apply_rule(env: &crate::check::expr::Env, st: &crate::check::types::St, fname: &Text, col: &crate::check::types::Col, params: &Array<crate::check::types::Ty>, res: &crate::check::types::Ty, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let n = len(args);
    let cmp = crate::check::expr::is_comparison(fname);
    let (arg_tys, st1) = run_to_end(fold_job(crate::check::errors::range0(&n), (Array::new(), st.clone()), {
        let args = args.clone();
        let span = span.clone();
        let env = env.clone();
        let params = params.clone();
        let fname = fname.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
            let args = args.clone();
            let span = span.clone();
            let env = env.clone();
            let params = params.clone();
            let fname = fname.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let i = p1;
                {
                    let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, span: span.clone() });
                    if crate::check::expr::is_lambda(&a.value) {
                        prism_rtl::Turn::Finished((push(&acc, &crate::check::types::Ty::TyErr), s.clone()))
                    } else {
                        call_then(crate::check::expr::start_infer(env.clone(), s.clone(), a.value.clone()), move |infer_12422: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t, s2) = infer_12422;
                            call_then(crate::check::types::recording::start_walk(s2.clone(), or(&index(&params, &i), &crate::check::types::Ty::TyErr)), move |walk_12465: crate::check::types::Ty| call_then(crate::check::types::recording::start_walk(s2.clone(), t.clone()), move |walk_12499: crate::check::types::Ty| match (walk_12465, walk_12499) {
                                (crate::check::types::Ty::TyFn(pc, _, _), crate::check::types::Ty::TyFn(ac, aps, ar)) => call_then(crate::check::types::colors::start_add_leq(s2.clone(), ac.clone(), pc.clone(), a.value.span.clone(), Text::lit("arg"), fname.clone(), Text::lit("")), move |add_leq_12616: crate::check::types::St| prism_rtl::Turn::Finished((push(&acc, &crate::check::types::Ty::TyFn(pc.clone(), aps.clone(), Rc::new((*ar).clone()))), add_leq_12616))),
                                _ => prism_rtl::Turn::Finished((push(&acc, &t), s2.clone())),
                            }))
                        })
                    }
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }));
    let (st2, whole) = run_to_end(fold_job(crate::check::errors::range0(&n), (st1.clone(), Array::new()), {
        let args = args.clone();
        let span = span.clone();
        let arg_tys = arg_tys.clone();
        let params = params.clone();
        let env = env.clone();
        let fname = fname.clone();
        Rc::new(move |(p0, p1): ((crate::check::types::St, Array<Nat>), Nat)| {
            let args = args.clone();
            let span = span.clone();
            let arg_tys = arg_tys.clone();
            let params = params.clone();
            let env = env.clone();
            let fname = fname.clone();
            entered(once_job(move || {
                let (s, done) = p0;
                let i = p1;
                {
                    let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, span: span.clone() });
                    let at_ = or(&index(&arg_tys, &i), &crate::check::types::Ty::TyErr);
                    call_then(crate::check::types::recording::start_walk(s.clone(), or(&index(&params, &i), &crate::check::types::Ty::TyErr)), move |walk_12938: crate::check::types::Ty| {
                        let pnow = walk_12938;
                        call_then(crate::check::types::start_head_sigil(s.clone(), pnow.clone()), move |head_sigil_13005: Text| {
                            let whole_now = crate::check::expr::is_time_sigil(&head_sigil_13005) || (&crate::check::types::head_sigil(&s, &pnow) == &Text::lit("@"));
                            if crate::check::expr::is_lambda(&a.value) {
                                prism_rtl::Turn::Finished((s.clone(), done.clone()))
                            } else {
                                if whole_now && (&crate::check::types::stack_of(&s, &at_) != &Text::lit("")) {
                                    call_then(crate::check::types::unify::start_unify(s.clone(), pnow.clone(), at_.clone(), a.value.span.clone()), move |unify_13152: crate::check::types::St| prism_rtl::Turn::Finished((unify_13152, push(&done, &i))))
                                } else {
                                    call_then(crate::check::types::start_stack_of(s.clone(), at_.clone()), move |stack_of_13221: Text| if (&stack_of_13221 != &Text::lit("")) || crate::check::types::is_free_headed(&s, &at_) {
                                        prism_rtl::Turn::Finished((s.clone(), done.clone()))
                                    } else {
                                        call_then(start_plain_arg(env.clone(), s.clone(), fname.clone(), or(&index(&params, &i), &crate::check::types::Ty::TyErr), at_.clone(), a.clone()), move |plain_arg_13296: crate::check::types::St| prism_rtl::Turn::Finished((plain_arg_13296, done.clone())))
                                    })
                                }
                            }
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(((crate::check::types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, Array<Nat>)>>>
    }));
    let (_, st3) = run_to_end(fold_job(crate::check::errors::range0(&n), (Map::new(), st2.clone()), {
        let args = args.clone();
        let span = span.clone();
        let params = params.clone();
        let env = env.clone();
        let fname = fname.clone();
        Rc::new(move |(p0, p1): ((Map<(), ()>, crate::check::types::St), Nat)| {
            let args = args.clone();
            let span = span.clone();
            let params = params.clone();
            let env = env.clone();
            let fname = fname.clone();
            entered(once_job(move || {
                let (m, s) = p0;
                let i = p1;
                {
                    let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, span: span.clone() });
                    if crate::check::expr::is_lambda(&a.value) {
                        call_then(crate::check::types::recording::start_walk(s.clone(), or(&index(&params, &i), &crate::check::types::Ty::TyErr)), move |walk_13567: crate::check::types::Ty| {
                            let p_ = walk_13567;
                            call_then(start_infer_lambda(env.clone(), s.clone(), a.value.clone(), Some(p_.clone())), move |infer_lambda_13626: (crate::check::types::Ty, crate::check::types::St)| {
                                let (lt, s2) = infer_lambda_13626;
                                let s3 = match (p_.clone(), lt.clone()) {
                                    (crate::check::types::Ty::TyFn(pc, _, _), crate::check::types::Ty::TyFn(lc, lps, lr)) => crate::check::types::colors::add_leq(&crate::check::types::unify::unify(&crate::check::types::recording::note_ty(&s2, &a.value.span, &lt), &p_, &crate::check::types::Ty::TyFn(pc.clone(), lps.clone(), Rc::new((*lr).clone())), &a.value.span), &lc, &pc, &a.value.span, &Text::lit("arg"), &fname, &Text::lit("")),
                                    _ => crate::check::types::unify::unify(&crate::check::types::recording::note_ty(&s2, &a.value.span, &lt), &p_, &lt, &a.value.span),
                                };
                                prism_rtl::Turn::Finished((m.clone(), s3.clone()))
                            })
                        })
                    } else {
                        prism_rtl::Turn::Finished((m.clone(), s.clone()))
                    }
                }
            }))
        }) as Rc<dyn Fn(((Map<(), ()>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Map<(), ()>, crate::check::types::St)>>>
    }));
    let (pl, st4) = run_to_end(fold_job(crate::check::errors::range0(&n), (Peeled { events: Array::new(), dyns: Array::new(), opts: Array::new(), lifted: Text::lit(""), broken: false }, st3.clone()), {
        let args = args.clone();
        let span = span.clone();
        let arg_tys = arg_tys.clone();
        let whole = whole.clone();
        let env = env.clone();
        let fname = fname.clone();
        let cmp = cmp;
        let params = params.clone();
        Rc::new(move |(p0, p1): ((Peeled, crate::check::types::St), Nat)| {
            let args = args.clone();
            let span = span.clone();
            let arg_tys = arg_tys.clone();
            let whole = whole.clone();
            let env = env.clone();
            let fname = fname.clone();
            let cmp = cmp;
            let params = params.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let i = p1;
                {
                    let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, span: span.clone() });
                    let at_ = or(&index(&arg_tys, &i), &crate::check::types::Ty::TyErr);
                    if (crate::check::expr::is_lambda(&a.value) || crate::check::types::has_nat(&whole, &i)) || ((&crate::check::types::stack_of(&s, &at_) == &Text::lit("")) && !crate::check::types::is_free_headed(&s, &at_)) {
                        prism_rtl::Turn::Finished((acc.clone(), s.clone()))
                    } else {
                        {
                            let before_ = len(&s.diags);
                            call_then(start_layered_arg(env.clone(), s.clone(), acc.clone(), fname.clone(), cmp, or(&index(&params, &i), &crate::check::types::Ty::TyErr), at_.clone(), a.clone()), move |layered_arg_14477: (Peeled, crate::check::types::St)| {
                                let (acc2, s2) = layered_arg_14477;
                                let broke = (&len(&s2.diags) > &before_) && fold(&drop(&s2.diags, &before_), &false, &(|seen: &bool, d: &crate::check::errors::CDiag| *seen || crate::check::types::has_text(&Array::from(vec![Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")]), &d.code)));
                                prism_rtl::Turn::Finished((broken(&acc2, &broke), s2.clone()))
                            })
                        }
                    }
                }
            }))
        }) as Rc<dyn Fn(((Peeled, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check::types::St)>>>
    }));
    let st5 = if &len(&pl.events) > &Nat::from(1u32) {
        crate::check::types::recording::err_fix(&st4, &Text::lit("two-events"), &or(&index(&pl.events, &Nat::from(1u32)), span), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
    } else {
        st4.clone()
    };
    let st6 = if &len(&pl.opts) > &Nat::from(1u32) {
        crate::check::types::recording::err(&st5, &Text::lit("optional-and-fault"), span, &Text::lit("`?` and `~` in one operation"))
    } else {
        st5.clone()
    };
    let layer = if &len(&pl.events) > &Nat::from(0u32) {
        Text::lit("!")
    } else {
        if &len(&pl.dyns) > &Nat::from(0u32) { Text::lit("$") } else { Text::lit("") }
    };
    let with_opt = match index(&pl.opts, &Nat::from(0u32)) {
        Some(o) => crate::check::types::Ty::TySig(o.clone(), Rc::new(res.clone())),
        None => res.clone(),
    };
    let result = if pl.broken {
        crate::check::types::Ty::TyErr
    } else {
        if &layer == &Text::lit("") {
            with_opt.clone()
        } else {
            crate::check::types::Ty::TySig(layer.clone(), Rc::new(with_opt.clone()))
        }
    };
    let call_col = crate::check::types::colors::walk_col(&st6, col);
    let st7 = if (&layer != &Text::lit("")) && crate::check::types::colors::is_flex_col(&call_col) {
        crate::check::types::colors::add_leq(&st6, &call_col, &crate::check::types::Col::CBound, span, &Text::lit("lifted"), fname, &pl.lifted)
    } else {
        st6.clone()
    };
    let lifted_bad = ((&layer != &Text::lit("")) && (&call_col != &crate::check::types::Col::CBound)) && !crate::check::types::colors::is_flex_col(&call_col);
    let st8 = if lifted_bad {
        crate::check::types::recording::err_fix(&st7, &Text::lit("lifted-unbounded"), span, &Text::from(format!("{} `{}` lifted over `{}`; use `@Run`", &crate::check::types::colors::col_word(&call_col), fname, &pl.lifted)), &Text::from(format!("run it through `!done <- @Run {}, ...`", fname)))
    } else {
        st7.clone()
    };
    let st9 = crate::check::types::colors::use_color(&st8, &call_col, fname, span);
    let kind = if (&layer == &Text::lit("!")) && (&len(&pl.dyns) > &Nat::from(0u32)) {
        Text::lit("sample")
    } else {
        if &layer != &Text::lit("") {
            Text::lit("map")
        } else {
            if fname == &Text::lit("$") { Text::lit("const") } else { Text::lit("plain") }
        }
    };
    let peeled = append(&pl.events, &pl.dyns);
    let lifted = filter(&crate::check::errors::range0(&n), &(|i: &Nat| has_range(&peeled, &or(&index(args, i), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, span: span.clone() }).value.span)));
    (result.clone(), crate::check::types::recording::note_app(&st9, span, fname, &kind, &layer, &lifted, &or(&index(&pl.opts, &Nat::from(0u32)), &Text::lit("")), &call_col))
}

/// The step machine of `ApplyRule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct ApplyRule {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub fname: Text,
    pub col: crate::check::types::Col,
    pub params: Array<crate::check::types::Ty>,
    pub res: crate::check::types::Ty,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ApplyRule {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let fname = &self.fname;
        let col = &self.col;
        let params = &self.params;
        let res = &self.res;
        let args = &self.args;
        let span = &self.span;
        let n = len(args);
        let cmp = crate::check::expr::is_comparison(fname);
        let args = args.clone();
        let col = col.clone();
        let env = env.clone();
        let fname = fname.clone();
        let params = params.clone();
        let res = res.clone();
        let span = span.clone();
        let st = st.clone();
        call_value(fold_job(crate::check::errors::range0(&n), (Array::new(), st.clone()), {
            let args = args.clone();
            let span = span.clone();
            let env = env.clone();
            let params = params.clone();
            let fname = fname.clone();
            Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
                let args = args.clone();
                let span = span.clone();
                let env = env.clone();
                let params = params.clone();
                let fname = fname.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let i = p1;
                    {
                        let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, span: span.clone() });
                        if crate::check::expr::is_lambda(&a.value) {
                            prism_rtl::Turn::Finished((push(&acc, &crate::check::types::Ty::TyErr), s.clone()))
                        } else {
                            call_then(crate::check::expr::start_infer(env.clone(), s.clone(), a.value.clone()), move |infer_12422: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t, s2) = infer_12422;
                                call_then(crate::check::types::recording::start_walk(s2.clone(), or(&index(&params, &i), &crate::check::types::Ty::TyErr)), move |walk_12465: crate::check::types::Ty| call_then(crate::check::types::recording::start_walk(s2.clone(), t.clone()), move |walk_12499: crate::check::types::Ty| match (walk_12465, walk_12499) {
                                    (crate::check::types::Ty::TyFn(pc, _, _), crate::check::types::Ty::TyFn(ac, aps, ar)) => call_then(crate::check::types::colors::start_add_leq(s2.clone(), ac.clone(), pc.clone(), a.value.span.clone(), Text::lit("arg"), fname.clone(), Text::lit("")), move |add_leq_12616: crate::check::types::St| prism_rtl::Turn::Finished((push(&acc, &crate::check::types::Ty::TyFn(pc.clone(), aps.clone(), Rc::new((*ar).clone()))), add_leq_12616))),
                                    _ => prism_rtl::Turn::Finished((push(&acc, &t), s2.clone())),
                                }))
                            })
                        }
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }), move |fold_12189: (Array<crate::check::types::Ty>, crate::check::types::St)| {
            let (arg_tys, st1) = fold_12189;
            call_value(fold_job(crate::check::errors::range0(&n), (st1.clone(), Array::new()), {
                let args = args.clone();
                let span = span.clone();
                let arg_tys = arg_tys.clone();
                let params = params.clone();
                let env = env.clone();
                let fname = fname.clone();
                Rc::new(move |(p0, p1): ((crate::check::types::St, Array<Nat>), Nat)| {
                    let args = args.clone();
                    let span = span.clone();
                    let arg_tys = arg_tys.clone();
                    let params = params.clone();
                    let env = env.clone();
                    let fname = fname.clone();
                    entered(once_job(move || {
                        let (s, done) = p0;
                        let i = p1;
                        {
                            let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, span: span.clone() });
                            let at_ = or(&index(&arg_tys, &i), &crate::check::types::Ty::TyErr);
                            call_then(crate::check::types::recording::start_walk(s.clone(), or(&index(&params, &i), &crate::check::types::Ty::TyErr)), move |walk_12938: crate::check::types::Ty| {
                                let pnow = walk_12938;
                                call_then(crate::check::types::start_head_sigil(s.clone(), pnow.clone()), move |head_sigil_13005: Text| {
                                    let whole_now = crate::check::expr::is_time_sigil(&head_sigil_13005) || (&crate::check::types::head_sigil(&s, &pnow) == &Text::lit("@"));
                                    if crate::check::expr::is_lambda(&a.value) {
                                        prism_rtl::Turn::Finished((s.clone(), done.clone()))
                                    } else {
                                        if whole_now && (&crate::check::types::stack_of(&s, &at_) != &Text::lit("")) {
                                            call_then(crate::check::types::unify::start_unify(s.clone(), pnow.clone(), at_.clone(), a.value.span.clone()), move |unify_13152: crate::check::types::St| prism_rtl::Turn::Finished((unify_13152, push(&done, &i))))
                                        } else {
                                            call_then(crate::check::types::start_stack_of(s.clone(), at_.clone()), move |stack_of_13221: Text| if (&stack_of_13221 != &Text::lit("")) || crate::check::types::is_free_headed(&s, &at_) {
                                                prism_rtl::Turn::Finished((s.clone(), done.clone()))
                                            } else {
                                                call_then(start_plain_arg(env.clone(), s.clone(), fname.clone(), or(&index(&params, &i), &crate::check::types::Ty::TyErr), at_.clone(), a.clone()), move |plain_arg_13296: crate::check::types::St| prism_rtl::Turn::Finished((plain_arg_13296, done.clone())))
                                            })
                                        }
                                    }
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(((crate::check::types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, Array<Nat>)>>>
            }), move |fold_12743: (crate::check::types::St, Array<Nat>)| {
                let (st2, whole) = fold_12743;
                call_value(fold_job(crate::check::errors::range0(&n), (Map::new(), st2.clone()), {
                    let args = args.clone();
                    let span = span.clone();
                    let params = params.clone();
                    let env = env.clone();
                    let fname = fname.clone();
                    Rc::new(move |(p0, p1): ((Map<(), ()>, crate::check::types::St), Nat)| {
                        let args = args.clone();
                        let span = span.clone();
                        let params = params.clone();
                        let env = env.clone();
                        let fname = fname.clone();
                        entered(once_job(move || {
                            let (m, s) = p0;
                            let i = p1;
                            {
                                let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, span: span.clone() });
                                if crate::check::expr::is_lambda(&a.value) {
                                    call_then(crate::check::types::recording::start_walk(s.clone(), or(&index(&params, &i), &crate::check::types::Ty::TyErr)), move |walk_13567: crate::check::types::Ty| {
                                        let p_ = walk_13567;
                                        call_then(start_infer_lambda(env.clone(), s.clone(), a.value.clone(), Some(p_.clone())), move |infer_lambda_13626: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (lt, s2) = infer_lambda_13626;
                                            let s3 = match (p_.clone(), lt.clone()) {
                                                (crate::check::types::Ty::TyFn(pc, _, _), crate::check::types::Ty::TyFn(lc, lps, lr)) => crate::check::types::colors::add_leq(&crate::check::types::unify::unify(&crate::check::types::recording::note_ty(&s2, &a.value.span, &lt), &p_, &crate::check::types::Ty::TyFn(pc.clone(), lps.clone(), Rc::new((*lr).clone())), &a.value.span), &lc, &pc, &a.value.span, &Text::lit("arg"), &fname, &Text::lit("")),
                                                _ => crate::check::types::unify::unify(&crate::check::types::recording::note_ty(&s2, &a.value.span, &lt), &p_, &lt, &a.value.span),
                                            };
                                            prism_rtl::Turn::Finished((m.clone(), s3.clone()))
                                        })
                                    })
                                } else {
                                    prism_rtl::Turn::Finished((m.clone(), s.clone()))
                                }
                            }
                        }))
                    }) as Rc<dyn Fn(((Map<(), ()>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Map<(), ()>, crate::check::types::St)>>>
                }), move |fold_13384: (Map<(), ()>, crate::check::types::St)| {
                    let (_, st3) = fold_13384;
                    call_value(fold_job(crate::check::errors::range0(&n), (Peeled { events: Array::new(), dyns: Array::new(), opts: Array::new(), lifted: Text::lit(""), broken: false }, st3.clone()), {
                        let args = args.clone();
                        let span = span.clone();
                        let arg_tys = arg_tys.clone();
                        let whole = whole.clone();
                        let env = env.clone();
                        let fname = fname.clone();
                        let cmp = cmp;
                        let params = params.clone();
                        Rc::new(move |(p0, p1): ((Peeled, crate::check::types::St), Nat)| {
                            let args = args.clone();
                            let span = span.clone();
                            let arg_tys = arg_tys.clone();
                            let whole = whole.clone();
                            let env = env.clone();
                            let fname = fname.clone();
                            let cmp = cmp;
                            let params = params.clone();
                            entered(once_job(move || {
                                let (acc, s) = p0;
                                let i = p1;
                                {
                                    let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, span: span.clone() });
                                    let at_ = or(&index(&arg_tys, &i), &crate::check::types::Ty::TyErr);
                                    if (crate::check::expr::is_lambda(&a.value) || crate::check::types::has_nat(&whole, &i)) || ((&crate::check::types::stack_of(&s, &at_) == &Text::lit("")) && !crate::check::types::is_free_headed(&s, &at_)) {
                                        prism_rtl::Turn::Finished((acc.clone(), s.clone()))
                                    } else {
                                        {
                                            let before_ = len(&s.diags);
                                            call_then(start_layered_arg(env.clone(), s.clone(), acc.clone(), fname.clone(), cmp, or(&index(&params, &i), &crate::check::types::Ty::TyErr), at_.clone(), a.clone()), move |layered_arg_14477: (Peeled, crate::check::types::St)| {
                                                let (acc2, s2) = layered_arg_14477;
                                                let broke = (&len(&s2.diags) > &before_) && fold(&drop(&s2.diags, &before_), &false, &(|seen: &bool, d: &crate::check::errors::CDiag| *seen || crate::check::types::has_text(&Array::from(vec![Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")]), &d.code)));
                                                prism_rtl::Turn::Finished((broken(&acc2, &broke), s2.clone()))
                                            })
                                        }
                                    }
                                }
                            }))
                        }) as Rc<dyn Fn(((Peeled, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check::types::St)>>>
                    }), move |fold_14039: (Peeled, crate::check::types::St)| {
                        let (pl, st4) = fold_14039;
                        let st5 = if &len(&pl.events) > &Nat::from(1u32) {
                            crate::check::types::recording::err_fix(&st4, &Text::lit("two-events"), &or(&index(&pl.events, &Nat::from(1u32)), &span), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
                        } else {
                            st4.clone()
                        };
                        let st6 = if &len(&pl.opts) > &Nat::from(1u32) {
                            crate::check::types::recording::err(&st5, &Text::lit("optional-and-fault"), &span, &Text::lit("`?` and `~` in one operation"))
                        } else {
                            st5.clone()
                        };
                        let layer = if &len(&pl.events) > &Nat::from(0u32) {
                            Text::lit("!")
                        } else {
                            if &len(&pl.dyns) > &Nat::from(0u32) { Text::lit("$") } else { Text::lit("") }
                        };
                        let with_opt = match index(&pl.opts, &Nat::from(0u32)) {
                            Some(o) => crate::check::types::Ty::TySig(o.clone(), Rc::new(res.clone())),
                            None => res.clone(),
                        };
                        let result = if pl.broken {
                            crate::check::types::Ty::TyErr
                        } else {
                            if &layer == &Text::lit("") {
                                with_opt.clone()
                            } else {
                                crate::check::types::Ty::TySig(layer.clone(), Rc::new(with_opt.clone()))
                            }
                        };
                        call_then(crate::check::types::colors::start_walk_col(st6.clone(), col.clone()), move |walk_col_15525: crate::check::types::Col| {
                            let call_col = walk_col_15525;
                            let st7 = if (&layer != &Text::lit("")) && crate::check::types::colors::is_flex_col(&call_col) {
                                crate::check::types::colors::add_leq(&st6, &call_col, &crate::check::types::Col::CBound, &span, &Text::lit("lifted"), &fname, &pl.lifted)
                            } else {
                                st6.clone()
                            };
                            let lifted_bad = ((&layer != &Text::lit("")) && (&call_col != &crate::check::types::Col::CBound)) && !crate::check::types::colors::is_flex_col(&call_col);
                            let st8 = if lifted_bad {
                                crate::check::types::recording::err_fix(&st7, &Text::lit("lifted-unbounded"), &span, &Text::from(format!("{} `{}` lifted over `{}`; use `@Run`", &crate::check::types::colors::col_word(&call_col), &fname, &pl.lifted)), &Text::from(format!("run it through `!done <- @Run {}, ...`", &fname)))
                            } else {
                                st7.clone()
                            };
                            call_then(crate::check::types::colors::start_use_color(st8.clone(), call_col.clone(), fname.clone(), span.clone()), move |use_color_15955: crate::check::types::St| {
                                let st9 = use_color_15955;
                                let kind = if (&layer == &Text::lit("!")) && (&len(&pl.dyns) > &Nat::from(0u32)) {
                                    Text::lit("sample")
                                } else {
                                    if &layer != &Text::lit("") {
                                        Text::lit("map")
                                    } else {
                                        if &fname == &Text::lit("$") { Text::lit("const") } else { Text::lit("plain") }
                                    }
                                };
                                let peeled = append(&pl.events, &pl.dyns);
                                let lifted = filter(&crate::check::errors::range0(&n), &(|i: &Nat| has_range(&peeled, &or(&index(&args, i), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, span: span.clone() }).value.span)));
                                prism_rtl::Turn::Finished((result.clone(), crate::check::types::recording::note_app(&st9, &span, &fname, &kind, &layer, &lifted, &or(&index(&pl.opts, &Nat::from(0u32)), &Text::lit("")), &call_col)))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start ApplyRule, x`: what the function value is when passed to `@Run`.
pub fn start_apply_rule(env: crate::check::expr::Env, st: crate::check::types::St, fname: Text, col: crate::check::types::Col, params: Array<crate::check::types::Ty>, res: crate::check::types::Ty, args: Array<crate::syntax::Arg>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(ApplyRule { env, st, fname, col, params, res, args, span })
}

/// ```prism
/// HasRange: fn [Range], Range -> Bool
/// ```
pub fn has_range(rs: &Array<crate::syntax::Range>, r: &crate::syntax::Range) -> bool {
    fold(rs, &false, &(|seen: &bool, x: &crate::syntax::Range| *seen || (x == r)))
}

/// ```prism
/// Elab: fn St, Range, Text, Text, Text -> St
/// ```
pub fn elab(st: &crate::check::types::St, span: &crate::syntax::Range, what: &Text, kind: &Text, layer: &Text) -> crate::check::types::St {
    crate::check::types::recording::note_app(st, span, what, kind, layer, &Array::new(), &Text::lit(""), &crate::check::types::Col::CBound)
}

/// ```prism
/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
/// ```
pub fn plain_arg(env: &crate::check::expr::Env, st: &crate::check::types::St, fname: &Text, param: &crate::check::types::Ty, at_: &crate::check::types::Ty, a: &crate::syntax::Arg) -> crate::check::types::St {
    let p_ = crate::check::types::recording::walk(st, param);
    let ph = crate::check::types::head_sigil(st, &p_);
    if at_ == &crate::check::types::Ty::TyErr {
        st.clone()
    } else {
        if crate::check::expr::is_time_sigil(&ph) || (&ph == &Text::lit("@")) {
            {
                let shown = if crate::check::types::is_flex_var(st, at_) {
                    crate::check::expr::src_text(env, &a.value.span)
                } else {
                    crate::check::types::show_ty(st, at_)
                };
                crate::check::types::recording::err_fix(st, &Text::lit("plain-for-sigiled"), &a.value.span, &Text::from(format!("a plain `{}` where `{}` takes a `{}`", &shown, fname, &crate::check::types::show_ty(st, &p_))), &Text::from(format!("write `{} {}`", &ph, &crate::check::expr::src_text(env, &a.value.span))))
            }
        } else {
            crate::check::types::unify::unify(st, &p_, at_, &a.value.span)
        }
    }
}

/// The step machine of `PlainArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
/// ```
pub struct PlainArg {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub fname: Text,
    pub param: crate::check::types::Ty,
    pub at_: crate::check::types::Ty,
    pub a: crate::syntax::Arg,
}

impl prism_rtl::Job<crate::check::types::St> for PlainArg {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let fname = &self.fname;
        let param = &self.param;
        let at_ = &self.at_;
        let a = &self.a;
        let a = a.clone();
        let at_ = at_.clone();
        let env = env.clone();
        let fname = fname.clone();
        let param = param.clone();
        let st = st.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), param.clone()), move |walk_17068: crate::check::types::Ty| {
            let p_ = walk_17068;
            call_then(crate::check::types::start_head_sigil(st.clone(), p_.clone()), move |head_sigil_17096: Text| {
                let ph = head_sigil_17096;
                if &at_ == &crate::check::types::Ty::TyErr {
                    prism_rtl::Turn::Finished(st.clone())
                } else {
                    if crate::check::expr::is_time_sigil(&ph) || (&ph == &Text::lit("@")) {
                        call_then(crate::check::types::start_is_flex_var(st.clone(), at_.clone()), move |is_flex_var_17202: bool| {
                            let shown = if is_flex_var_17202 {
                                crate::check::expr::src_text(&env, &a.value.span)
                            } else {
                                crate::check::types::show_ty(&st, &at_)
                            };
                            call_then(crate::check::types::start_show_ty(st.clone(), p_.clone()), move |show_ty_17365: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st, &Text::lit("plain-for-sigiled"), &a.value.span, &Text::from(format!("a plain `{}` where `{}` takes a `{}`", &shown, &fname, &show_ty_17365)), &Text::from(format!("write `{} {}`", &ph, &crate::check::expr::src_text(&env, &a.value.span))))))
                        })
                    } else {
                        prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st.clone(), expected: p_.clone(), found: at_.clone(), span: a.value.span.clone() }))
                    }
                }
            })
        })
    }
}

/// `Start PlainArg, x`: what the function value is when passed to `@Run`.
pub fn start_plain_arg(env: crate::check::expr::Env, st: crate::check::types::St, fname: Text, param: crate::check::types::Ty, at_: crate::check::types::Ty, a: crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(PlainArg { env, st, fname, param, at_, a })
}

/// ```prism
/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub fn layered_arg(env: &crate::check::expr::Env, st: &crate::check::types::St, acc: &Peeled, fname: &Text, cmp: &bool, param: &crate::check::types::Ty, at_: &crate::check::types::Ty, a: &crate::syntax::Arg) -> (Peeled, crate::check::types::St) {
    let p_ = crate::check::types::recording::walk(st, param);
    let span = a.value.span.clone();
    let ph = crate::check::types::head_sigil(st, &p_);
    if crate::check::types::is_free_headed(st, at_) {
        {
            let st2 = if ((crate::check::expr::is_time_sigil(&ph) || (&ph == &Text::lit("@"))) || (&ph == &Text::lit("&"))) || *cmp {
                st.clone()
            } else {
                crate::check::types::unify::ask_layer(st, at_, &span, fname)
            };
            (acc.clone(), crate::check::types::unify::unify(&st2, &p_, at_, &span))
        }
    } else {
        if (crate::check::expr::is_time_sigil(&ph) || (&ph == &Text::lit("@"))) || (&ph == &Text::lit("&")) {
            (acc.clone(), crate::check::types::unify::unify(st, &p_, at_, &span))
        } else {
            if crate::check::expr::is_plain_sigil(&ph) {
                peel_time_only(env, st, acc, fname, &p_, at_, a)
            } else {
                {
                    let head = crate::check::types::head_sigil(st, at_);
                    if &head == &Text::lit("@") {
                        (acc.clone(), crate::check::types::recording::err_fix(st, &Text::lit("blueprint-operand"), &span, &Text::from(format!("`{}` over a blueprint; bind it first", fname)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text(env, &span)))))
                    } else {
                        if crate::check::expr::is_time_sigil(&head) {
                            {
                                let inner = crate::check::expr::inner_of(st, at_);
                                let ih = crate::check::types::head_sigil(st, &inner);
                                let acc2 = {
                                    let mut this: Peeled = acc.clone();
                                    if &head == &Text::lit("!") {
                                        this.events = push(&this.events, &span);
                                    } else {
                                        this.dyns = push(&this.dyns, &span);
                                    }
                                    if &this.lifted == &Text::lit("") {
                                        this.lifted = crate::check::expr::src_text(env, &span);
                                    }
                                    this
                                };
                                if crate::check::expr::is_time_sigil(&ih) {
                                    {
                                        let what = if &ih == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") };
                                        (acc2.clone(), crate::check::types::recording::err_fix(st, &Text::lit("two-layers"), &span, &Text::from(format!("`{}` over a {} of {}s", fname, &(if &head == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &what)), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))
                                    }
                                } else {
                                    if crate::check::expr::is_plain_sigil(&ih) && !*cmp {
                                        {
                                            let inner2 = crate::check::expr::inner_of(st, &inner);
                                            if crate::check::expr::is_time_sigil(&crate::check::types::head_sigil(st, &inner2)) || (&crate::check::types::head_sigil(st, &inner2) == &Text::lit("@")) {
                                                (acc2.clone(), crate::check::types::recording::err(st, &Text::lit("layer-under-optional"), &span, &Text::from(format!("`{}` over an optional {}dynamic", fname, &(if &ih == &Text::lit("?") { Text::lit("") } else { Text::lit("fault ") })))))
                                            } else {
                                                {
                                                    let acc3 = {
                                                        let mut this: Peeled = acc2.clone();
                                                        this.opts = crate::check::types::add_text(&this.opts, &ih);
                                                        this
                                                    };
                                                    (acc3.clone(), crate::check::types::unify::unify(st, &p_, &inner2, &span))
                                                }
                                            }
                                        }
                                    } else {
                                        (acc2.clone(), crate::check::types::unify::unify(st, &p_, &inner, &span))
                                    }
                                }
                            }
                        } else {
                            if crate::check::expr::is_plain_sigil(&head) && !*cmp {
                                {
                                    let inner = crate::check::expr::inner_of(st, at_);
                                    let ih = crate::check::types::head_sigil(st, &inner);
                                    if crate::check::expr::is_time_sigil(&ih) || (&ih == &Text::lit("@")) {
                                        (acc.clone(), crate::check::types::recording::err_fix(st, &Text::lit("layer-under-optional"), &span, &Text::from(format!("`{}` over an optional dynamic", fname)), &Text::lit("match the optional once, at build time, to find out whether there is a dynamic")))
                                    } else {
                                        {
                                            let acc2 = {
                                                let mut this: Peeled = acc.clone();
                                                this.opts = crate::check::types::add_text(&this.opts, &head);
                                                this
                                            };
                                            (acc2.clone(), crate::check::types::unify::unify(st, &p_, &inner, &span))
                                        }
                                    }
                                }
                            } else {
                                if &head == &Text::lit("&") {
                                    (acc.clone(), crate::check::types::unify::unify(st, &p_, &crate::check::expr::inner_of(st, at_), &span))
                                } else {
                                    (acc.clone(), crate::check::types::unify::unify(st, &p_, at_, &span))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `LayeredArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub struct LayeredArg {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub acc: Peeled,
    pub fname: Text,
    pub cmp: bool,
    pub param: crate::check::types::Ty,
    pub at_: crate::check::types::Ty,
    pub a: crate::syntax::Arg,
}

impl prism_rtl::Job<(Peeled, crate::check::types::St)> for LayeredArg {
    fn cycle(&self) -> prism_rtl::Turn<(Peeled, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let acc = &self.acc;
        let fname = &self.fname;
        let cmp = &self.cmp;
        let param = &self.param;
        let at_ = &self.at_;
        let a = &self.a;
        let a = a.clone();
        let acc = acc.clone();
        let at_ = at_.clone();
        let cmp = *cmp;
        let env = env.clone();
        let fname = fname.clone();
        let param = param.clone();
        let st = st.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), param.clone()), move |walk_17677: crate::check::types::Ty| {
            let p_ = walk_17677;
            let span = a.value.span.clone();
            call_then(crate::check::types::start_head_sigil(st.clone(), p_.clone()), move |head_sigil_17733: Text| {
                let ph = head_sigil_17733;
                call_then(crate::check::types::start_is_free_headed(st.clone(), at_.clone()), move |is_free_headed_17756: bool| if is_free_headed_17756 {
                    {
                        let st2 = if ((crate::check::expr::is_time_sigil(&ph) || (&ph == &Text::lit("@"))) || (&ph == &Text::lit("&"))) || cmp {
                            st.clone()
                        } else {
                            crate::check::types::unify::ask_layer(&st, &at_, &span, &fname)
                        };
                        call_then(crate::check::types::unify::start_unify(st2.clone(), p_.clone(), at_.clone(), span.clone()), move |unify_17903: crate::check::types::St| prism_rtl::Turn::Finished((acc.clone(), unify_17903)))
                    }
                } else {
                    if (crate::check::expr::is_time_sigil(&ph) || (&ph == &Text::lit("@"))) || (&ph == &Text::lit("&")) {
                        call_then(crate::check::types::unify::start_unify(st.clone(), p_.clone(), at_.clone(), span.clone()), move |unify_17994: crate::check::types::St| prism_rtl::Turn::Finished((acc.clone(), unify_17994)))
                    } else {
                        if crate::check::expr::is_plain_sigil(&ph) {
                            prism_rtl::Turn::More(Rc::new(PeelTimeOnly { env: env.clone(), st: st.clone(), acc: acc.clone(), fname: fname.clone(), p_: p_.clone(), at_: at_.clone(), a: a.clone() }))
                        } else {
                            call_then(crate::check::types::start_head_sigil(st.clone(), at_.clone()), move |head_sigil_18121: Text| {
                                let head = head_sigil_18121;
                                if &head == &Text::lit("@") {
                                    prism_rtl::Turn::Finished((acc.clone(), crate::check::types::recording::err_fix(&st, &Text::lit("blueprint-operand"), &span, &Text::from(format!("`{}` over a blueprint; bind it first", &fname)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text(&env, &span))))))
                                } else {
                                    if crate::check::expr::is_time_sigil(&head) {
                                        call_then(crate::check::expr::start_inner_of(st.clone(), at_.clone()), move |inner_of_18366: crate::check::types::Ty| {
                                            let inner = inner_of_18366;
                                            call_then(crate::check::types::start_head_sigil(st.clone(), inner.clone()), move |head_sigil_18402: Text| {
                                                let ih = head_sigil_18402;
                                                let acc2 = {
                                                    let mut this: Peeled = acc.clone();
                                                    if &head == &Text::lit("!") {
                                                        this.events = push(&this.events, &span);
                                                    } else {
                                                        this.dyns = push(&this.dyns, &span);
                                                    }
                                                    if &this.lifted == &Text::lit("") {
                                                        this.lifted = crate::check::expr::src_text(&env, &span);
                                                    }
                                                    this
                                                };
                                                if crate::check::expr::is_time_sigil(&ih) {
                                                    {
                                                        let what = if &ih == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") };
                                                        prism_rtl::Turn::Finished((acc2.clone(), crate::check::types::recording::err_fix(&st, &Text::lit("two-layers"), &span, &Text::from(format!("`{}` over a {} of {}s", &fname, &(if &head == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &what)), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))))
                                                    }
                                                } else {
                                                    if crate::check::expr::is_plain_sigil(&ih) && !cmp {
                                                        call_then(crate::check::expr::start_inner_of(st.clone(), inner.clone()), move |inner_of_19078: crate::check::types::Ty| {
                                                            let inner2 = inner_of_19078;
                                                            call_then(crate::check::types::start_head_sigil(st.clone(), inner2.clone()), move |head_sigil_19129: Text| if crate::check::expr::is_time_sigil(&head_sigil_19129) || (&crate::check::types::head_sigil(&st, &inner2) == &Text::lit("@")) {
                                                                prism_rtl::Turn::Finished((acc2.clone(), crate::check::types::recording::err(&st, &Text::lit("layer-under-optional"), &span, &Text::from(format!("`{}` over an optional {}dynamic", &fname, &(if &ih == &Text::lit("?") { Text::lit("") } else { Text::lit("fault ") }))))))
                                                            } else {
                                                                {
                                                                    let acc3 = {
                                                                        let mut this: Peeled = acc2.clone();
                                                                        this.opts = crate::check::types::add_text(&this.opts, &ih);
                                                                        this
                                                                    };
                                                                    call_then(crate::check::types::unify::start_unify(st.clone(), p_.clone(), inner2.clone(), span.clone()), move |unify_19476: crate::check::types::St| prism_rtl::Turn::Finished((acc3.clone(), unify_19476)))
                                                                }
                                                            })
                                                        })
                                                    } else {
                                                        call_then(crate::check::types::unify::start_unify(st.clone(), p_.clone(), inner.clone(), span.clone()), move |unify_19532: crate::check::types::St| prism_rtl::Turn::Finished((acc2.clone(), unify_19532)))
                                                    }
                                                }
                                            })
                                        })
                                    } else {
                                        if crate::check::expr::is_plain_sigil(&head) && !cmp {
                                            call_then(crate::check::expr::start_inner_of(st.clone(), at_.clone()), move |inner_of_19634: crate::check::types::Ty| {
                                                let inner = inner_of_19634;
                                                call_then(crate::check::types::start_head_sigil(st.clone(), inner.clone()), move |head_sigil_19670: Text| {
                                                    let ih = head_sigil_19670;
                                                    if crate::check::expr::is_time_sigil(&ih) || (&ih == &Text::lit("@")) {
                                                        prism_rtl::Turn::Finished((acc.clone(), crate::check::types::recording::err_fix(&st, &Text::lit("layer-under-optional"), &span, &Text::from(format!("`{}` over an optional dynamic", &fname)), &Text::lit("match the optional once, at build time, to find out whether there is a dynamic"))))
                                                    } else {
                                                        {
                                                            let acc2 = {
                                                                let mut this: Peeled = acc.clone();
                                                                this.opts = crate::check::types::add_text(&this.opts, &head);
                                                                this
                                                            };
                                                            call_then(crate::check::types::unify::start_unify(st.clone(), p_.clone(), inner.clone(), span.clone()), move |unify_20058: crate::check::types::St| prism_rtl::Turn::Finished((acc2.clone(), unify_20058)))
                                                        }
                                                    }
                                                })
                                            })
                                        } else {
                                            if &head == &Text::lit("&") {
                                                call_then(crate::check::expr::start_inner_of(st.clone(), at_.clone()), move |inner_of_20138: crate::check::types::Ty| call_then(crate::check::types::unify::start_unify(st.clone(), p_.clone(), inner_of_20138, span.clone()), move |unify_20124: crate::check::types::St| prism_rtl::Turn::Finished((acc.clone(), unify_20124))))
                                            } else {
                                                call_then(crate::check::types::unify::start_unify(st.clone(), p_.clone(), at_.clone(), span.clone()), move |unify_20185: crate::check::types::St| prism_rtl::Turn::Finished((acc.clone(), unify_20185)))
                                            }
                                        }
                                    }
                                }
                            })
                        }
                    }
                })
            })
        })
    }
}

/// `Start LayeredArg, x`: what the function value is when passed to `@Run`.
pub fn start_layered_arg(env: crate::check::expr::Env, st: crate::check::types::St, acc: Peeled, fname: Text, cmp: bool, param: crate::check::types::Ty, at_: crate::check::types::Ty, a: crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check::types::St)>> {
    Rc::new(LayeredArg { env, st, acc, fname, cmp, param, at_, a })
}

/// ```prism
/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub fn peel_time_only(env: &crate::check::expr::Env, st: &crate::check::types::St, acc: &Peeled, fname: &Text, p_: &crate::check::types::Ty, at_: &crate::check::types::Ty, a: &crate::syntax::Arg) -> (Peeled, crate::check::types::St) {
    let span = a.value.span.clone();
    let head = crate::check::types::head_sigil(st, at_);
    if &head == &Text::lit("@") {
        (acc.clone(), crate::check::types::recording::err_fix(st, &Text::lit("blueprint-operand"), &span, &Text::from(format!("`{}` over a blueprint; bind it first", fname)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text(env, &span)))))
    } else {
        if crate::check::expr::is_time_sigil(&head) {
            {
                let inner = crate::check::expr::inner_of(st, at_);
                let acc2 = {
                    let mut this: Peeled = acc.clone();
                    if &head == &Text::lit("!") {
                        this.events = push(&this.events, &span);
                    } else {
                        this.dyns = push(&this.dyns, &span);
                    }
                    if &this.lifted == &Text::lit("") {
                        this.lifted = crate::check::expr::src_text(env, &span);
                    }
                    this
                };
                if crate::check::expr::is_time_sigil(&crate::check::types::head_sigil(st, &inner)) {
                    (acc2.clone(), crate::check::types::recording::err_fix(st, &Text::lit("two-layers"), &span, &Text::from(format!("`{}` over a {} of {}s", fname, &(if &head == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &(if &crate::check::types::head_sigil(st, &inner) == &Text::lit("$") {
                        Text::lit("dynamic")
                    } else {
                        Text::lit("event")
                    }))), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))
                } else {
                    (acc2.clone(), crate::check::types::unify::unify(st, p_, &inner, &span))
                }
            }
        } else {
            (acc.clone(), crate::check::types::unify::unify(st, p_, at_, &span))
        }
    }
}

/// The step machine of `PeelTimeOnly`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub struct PeelTimeOnly {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub acc: Peeled,
    pub fname: Text,
    pub p_: crate::check::types::Ty,
    pub at_: crate::check::types::Ty,
    pub a: crate::syntax::Arg,
}

impl prism_rtl::Job<(Peeled, crate::check::types::St)> for PeelTimeOnly {
    fn cycle(&self) -> prism_rtl::Turn<(Peeled, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let acc = &self.acc;
        let fname = &self.fname;
        let p_ = &self.p_;
        let at_ = &self.at_;
        let a = &self.a;
        let span = a.value.span.clone();
        let a = a.clone();
        let acc = acc.clone();
        let at_ = at_.clone();
        let env = env.clone();
        let fname = fname.clone();
        let p_ = p_.clone();
        let st = st.clone();
        call_then(crate::check::types::start_head_sigil(st.clone(), at_.clone()), move |head_sigil_20471: Text| {
            let head = head_sigil_20471;
            if &head == &Text::lit("@") {
                prism_rtl::Turn::Finished((acc.clone(), crate::check::types::recording::err_fix(&st, &Text::lit("blueprint-operand"), &span, &Text::from(format!("`{}` over a blueprint; bind it first", &fname)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text(&env, &span))))))
            } else {
                if crate::check::expr::is_time_sigil(&head) {
                    call_then(crate::check::expr::start_inner_of(st.clone(), at_.clone()), move |inner_of_20704: crate::check::types::Ty| {
                        let inner = inner_of_20704;
                        let acc2 = {
                            let mut this: Peeled = acc.clone();
                            if &head == &Text::lit("!") {
                                this.events = push(&this.events, &span);
                            } else {
                                this.dyns = push(&this.dyns, &span);
                            }
                            if &this.lifted == &Text::lit("") {
                                this.lifted = crate::check::expr::src_text(&env, &span);
                            }
                            this
                        };
                        call_then(crate::check::types::start_head_sigil(st.clone(), inner.clone()), move |head_sigil_20995: Text| if crate::check::expr::is_time_sigil(&head_sigil_20995) {
                            call_then(crate::check::types::start_head_sigil(st.clone(), inner.clone()), move |head_sigil_21125: Text| prism_rtl::Turn::Finished((acc2.clone(), crate::check::types::recording::err_fix(&st, &Text::lit("two-layers"), &span, &Text::from(format!("`{}` over a {} of {}s", &fname, &(if &head == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &(if &head_sigil_21125 == &Text::lit("$") {
                                Text::lit("dynamic")
                            } else {
                                Text::lit("event")
                            }))), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))))
                        } else {
                            call_then(crate::check::types::unify::start_unify(st.clone(), p_.clone(), inner.clone(), span.clone()), move |unify_21275: crate::check::types::St| prism_rtl::Turn::Finished((acc2.clone(), unify_21275)))
                        })
                    })
                } else {
                    call_then(crate::check::types::unify::start_unify(st.clone(), p_.clone(), at_.clone(), span.clone()), move |unify_21321: crate::check::types::St| prism_rtl::Turn::Finished((acc.clone(), unify_21321)))
                }
            }
        })
    }
}

/// `Start PeelTimeOnly, x`: what the function value is when passed to `@Run`.
pub fn start_peel_time_only(env: crate::check::expr::Env, st: crate::check::types::St, acc: Peeled, fname: Text, p_: crate::check::types::Ty, at_: crate::check::types::Ty, a: crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check::types::St)>> {
    Rc::new(PeelTimeOnly { env, st, acc, fname, p_, at_, a })
}

/// ```prism
/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
/// ```
pub fn ctor_app(env: &crate::check::expr::Env, st: &crate::check::types::St, c: &crate::check::env::CtorInfo, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range, cspan: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (self_, st0, inst) = crate::check::types::schemes::instantiate_with(st, &crate::check::types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c.ty.clone() }, span, &Array::new());
    let field_tys = run_to_end(each_job(c.args.clone(), {
        let inst = inst.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let inst = inst.clone();
            entered(once_job(move || {
                let t = p0;
                prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m: inst.clone(), t: t.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
    }));
    let st1 = crate::check::types::recording::note_ty(&st0, cspan, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys.clone(), Rc::new(self_.clone())));
    let named = filter(args, &(|a: &crate::syntax::Arg| &a.name != &None));
    if (&len(&named) > &Nat::from(0u32)) && (&len(&c.fields) > &Nat::from(0u32)) {
        {
            let st2 = run_to_end(fold_job(named.clone(), st1.clone(), {
                let c = c.clone();
                let env = env.clone();
                let field_tys = field_tys.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arg)| {
                    let c = c.clone();
                    let env = env.clone();
                    let field_tys = field_tys.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let a = p1;
                        match &a.name {
                            Some(id) => match crate::check::expr::operators::index_of(&c.fields, &id.name) {
                                Some(i) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env: env.clone(), st: s.clone(), e: a.value.clone(), expected: or(&index(&field_tys, &i), &crate::check::types::Ty::TyErr) })),
                                None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&c.owner), &id.name)))),
                            },
                            None => prism_rtl::Turn::Finished(s.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }));
            let missing = filter(&c.fields, &(|f: &Text| !fold(&named, &false, &(|seen: &bool, a: &crate::syntax::Arg| *seen || arg_named(a, f)))));
            let st3 = if &len(&missing) > &Nat::from(0u32) {
                crate::check::types::recording::err(&st2, &Text::lit("mismatch"), span, &Text::from(format!("`{}` needs {}", &crate::check::types::bare_name(&c.owner), &crate::syntax::lexer::chars::join(&each(&missing, &(|f: &Text| Text::from(format!("`{}`", f)))), &Text::lit(", ")))))
            } else {
                st2.clone()
            };
            (self_.clone(), st3.clone())
        }
    } else {
        if &len(args) != &len(&field_tys) {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st1, &Text::lit("mismatch"), span, &Text::from(format!("`{}` takes {} argument{}; here it has {}", &crate::check::types::bare_name(&c.name), &crate::check::errors::count_word(&len(&field_tys)), &(if &len(&field_tys) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(args))))))
        } else {
            {
                let st2 = run_to_end(fold_job(crate::check::errors::range0(&len(args)), st1.clone(), {
                    let args = args.clone();
                    let env = env.clone();
                    let field_tys = field_tys.clone();
                    Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                        let args = args.clone();
                        let env = env.clone();
                        let field_tys = field_tys.clone();
                        entered(once_job(move || {
                            let s = p0;
                            let i = p1;
                            match index(&args, &i) {
                                Some(a) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env: env.clone(), st: s.clone(), e: a.value.clone(), expected: or(&index(&field_tys, &i), &crate::check::types::Ty::TyErr) })),
                                None => prism_rtl::Turn::Finished(s.clone()),
                            }
                        }))
                    }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                }));
                (self_.clone(), st2.clone())
            }
        }
    }
}

/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
/// ```
pub struct CtorApp {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub c: crate::check::env::CtorInfo,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
    pub cspan: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for CtorApp {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let args = &self.args;
        let span = &self.span;
        let cspan = &self.cspan;
        let args = args.clone();
        let c = c.clone();
        let cspan = cspan.clone();
        let env = env.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::types::schemes::start_instantiate_with(st.clone(), crate::check::types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c.ty.clone() }, span.clone(), Array::new()), move |instantiate_with_21583: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
            let (self_, st0, inst) = instantiate_with_21583;
            call_value(each_job(c.args.clone(), {
                let inst = inst.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let inst = inst.clone();
                    entered(once_job(move || {
                        let t = p0;
                        prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m: inst.clone(), t: t.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_21725: Array<crate::check::types::Ty>| {
                let field_tys = each_21725;
                let st1 = crate::check::types::recording::note_ty(&st0, &cspan, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys.clone(), Rc::new(self_.clone())));
                let named = filter(&args, &(|a: &crate::syntax::Arg| &a.name != &None));
                if (&len(&named) > &Nat::from(0u32)) && (&len(&c.fields) > &Nat::from(0u32)) {
                    call_value(fold_job(named.clone(), st1.clone(), {
                        let c = c.clone();
                        let env = env.clone();
                        let field_tys = field_tys.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arg)| {
                            let c = c.clone();
                            let env = env.clone();
                            let field_tys = field_tys.clone();
                            entered(once_job(move || {
                                let s = p0;
                                let a = p1;
                                match &a.name {
                                    Some(id) => match crate::check::expr::operators::index_of(&c.fields, &id.name) {
                                        Some(i) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env: env.clone(), st: s.clone(), e: a.value.clone(), expected: or(&index(&field_tys, &i), &crate::check::types::Ty::TyErr) })),
                                        None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&c.owner), &id.name)))),
                                    },
                                    None => prism_rtl::Turn::Finished(s.clone()),
                                }
                            }))
                        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_21935: crate::check::types::St| {
                        let st2 = fold_21935;
                        let missing = filter(&c.fields, &(|f: &Text| !fold(&named, &false, &(|seen: &bool, a: &crate::syntax::Arg| *seen || arg_named(a, f)))));
                        let st3 = if &len(&missing) > &Nat::from(0u32) {
                            crate::check::types::recording::err(&st2, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` needs {}", &crate::check::types::bare_name(&c.owner), &crate::syntax::lexer::chars::join(&each(&missing, &(|f: &Text| Text::from(format!("`{}`", f)))), &Text::lit(", ")))))
                        } else {
                            st2.clone()
                        };
                        prism_rtl::Turn::Finished((self_.clone(), st3.clone()))
                    })
                } else {
                    if &len(&args) != &len(&field_tys) {
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st1, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` takes {} argument{}; here it has {}", &crate::check::types::bare_name(&c.name), &crate::check::errors::count_word(&len(&field_tys)), &(if &len(&field_tys) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(&args)))))))
                    } else {
                        call_value(fold_job(crate::check::errors::range0(&len(&args)), st1.clone(), {
                            let args = args.clone();
                            let env = env.clone();
                            let field_tys = field_tys.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                let args = args.clone();
                                let env = env.clone();
                                let field_tys = field_tys.clone();
                                entered(once_job(move || {
                                    let s = p0;
                                    let i = p1;
                                    match index(&args, &i) {
                                        Some(a) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env: env.clone(), st: s.clone(), e: a.value.clone(), expected: or(&index(&field_tys, &i), &crate::check::types::Ty::TyErr) })),
                                        None => prism_rtl::Turn::Finished(s.clone()),
                                    }
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }), move |fold_22741: crate::check::types::St| {
                            let st2 = fold_22741;
                            prism_rtl::Turn::Finished((self_.clone(), st2.clone()))
                        })
                    }
                }
            })
        })
    }
}

/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_app(env: crate::check::expr::Env, st: crate::check::types::St, c: crate::check::env::CtorInfo, args: Array<crate::syntax::Arg>, span: crate::syntax::Range, cspan: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(CtorApp { env, st, c, args, span, cspan })
}

/// ```prism
/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
/// ```
pub fn tag_app(env: &crate::check::expr::Env, st: &crate::check::types::St, name: &Text, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range, cspan: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match get(&env.g.tags, name) {
        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unknown-name"), span, &Text::from(format!("no tag `{}`", name)))),
        Some(tg) => {
            let (out, st1, inst) = crate::check::types::schemes::instantiate_with(st, &crate::check::types::Scheme { qs: tg.qs.clone(), plain_qs: Array::new(), rqs: tg.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: tg.bounds.clone(), ty: tg.out.clone() }, span, &Array::new());
            let st2 = run_to_end(fold_job(args.clone(), st1.clone(), {
                let tg = tg.clone();
                let env = env.clone();
                let name = name.clone();
                let inst = inst.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arg)| {
                    let tg = tg.clone();
                    let env = env.clone();
                    let name = name.clone();
                    let inst = inst.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let a = p1;
                        match &a.name {
                            Some(id) => match field_of_tag(&tg, &id.name) {
                                Some(ft) => {
                                    let id = id.clone();
                                    call_then(crate::check::types::schemes::start_subst_q(inst.clone(), ft.clone()), move |subst_q_23695: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(TagField { env: env.clone(), st: s.clone(), tag_name: name.clone(), field: id.name.clone(), ft: subst_q_23695, a: a.clone() })))
                                },
                                None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` has no field `{}`", &name, &id.name)))),
                            },
                            None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("a tag's fields are named: `{}(field=...)`", &name)))),
                        }
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }));
            let missing = filter(&tg.fields, &(|(f, _): &(Text, crate::check::types::Ty)| !fold(args, &false, &(|seen: &bool, a: &crate::syntax::Arg| *seen || arg_named(a, f)))));
            let st3 = if (&len(&missing) > &Nat::from(0u32)) && !fold(args, &false, &(|seen: &bool, a: &crate::syntax::Arg| *seen || (&*a.value.kind == &crate::syntax::ExprKind::ERest))) {
                crate::check::types::recording::err(&st2, &Text::lit("mismatch"), span, &Text::from(format!("`{}` needs {}", name, &crate::syntax::lexer::chars::join(&each(&missing, &(|(f, _): &(Text, crate::check::types::Ty)| Text::from(format!("`{}`", f)))), &Text::lit(", ")))))
            } else {
                st2.clone()
            };
            let field_tys = run_to_end(each_job(tg.fields.clone(), {
                let inst = inst.clone();
                Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                    let inst = inst.clone();
                    entered(once_job(move || {
                        let (_, ft) = p0;
                        prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m: inst.clone(), t: ft.clone() }))
                    }))
                }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }));
            if &tg.kind == &Text::lit("Element") {
                {
                    let (rw, st4) = crate::check::types::recording::fresh_row(&st3, &Array::from(vec![tg.family.clone()]));
                    let et = crate::check::types::Ty::TyElem(crate::check::types::Rw { fams: Array::from(vec![tg.family.clone()]), minus: Array::new(), tail: rw.tail.clone() }, Rc::new(out.clone()));
                    (et.clone(), crate::check::types::recording::note_ty(&st4, cspan, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys.clone(), Rc::new(et.clone()))))
                }
            } else {
                (crate::check::types::Ty::TyCon(tg.kind.clone(), Array::new()), crate::check::types::recording::note_ty(&st3, cspan, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys.clone(), Rc::new(crate::check::types::Ty::TyCon(tg.kind.clone(), Array::new())))))
            }
        },
    }
}

/// The step machine of `TagApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
/// ```
pub struct TagApp {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub name: Text,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
    pub cspan: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for TagApp {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let name = &self.name;
        let args = &self.args;
        let span = &self.span;
        let cspan = &self.cspan;
        match get(&env.g.tags, name) {
            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unknown-name"), span, &Text::from(format!("no tag `{}`", name))))),
            Some(tg) => {
                let args = args.clone();
                let cspan = cspan.clone();
                let env = env.clone();
                let name = name.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(crate::check::types::schemes::start_instantiate_with(st.clone(), crate::check::types::Scheme { qs: tg.qs.clone(), plain_qs: Array::new(), rqs: tg.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: tg.bounds.clone(), ty: tg.out.clone() }, span.clone(), Array::new()), move |instantiate_with_23405: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                    let (out, st1, inst) = instantiate_with_23405;
                    call_value(fold_job(args.clone(), st1.clone(), {
                        let tg = tg.clone();
                        let env = env.clone();
                        let name = name.clone();
                        let inst = inst.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arg)| {
                            let tg = tg.clone();
                            let env = env.clone();
                            let name = name.clone();
                            let inst = inst.clone();
                            entered(once_job(move || {
                                let s = p0;
                                let a = p1;
                                match &a.name {
                                    Some(id) => match field_of_tag(&tg, &id.name) {
                                        Some(ft) => {
                                            let id = id.clone();
                                            call_then(crate::check::types::schemes::start_subst_q(inst.clone(), ft.clone()), move |subst_q_23695: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(TagField { env: env.clone(), st: s.clone(), tag_name: name.clone(), field: id.name.clone(), ft: subst_q_23695, a: a.clone() })))
                                        },
                                        None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` has no field `{}`", &name, &id.name)))),
                                    },
                                    None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("a tag's fields are named: `{}(field=...)`", &name)))),
                                }
                            }))
                        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_23552: crate::check::types::St| {
                        let st2 = fold_23552;
                        let missing = filter(&tg.fields, &(|(f, _): &(Text, crate::check::types::Ty)| !fold(&args, &false, &(|seen: &bool, a: &crate::syntax::Arg| *seen || arg_named(a, f)))));
                        let st3 = if (&len(&missing) > &Nat::from(0u32)) && !fold(&args, &false, &(|seen: &bool, a: &crate::syntax::Arg| *seen || (&*a.value.kind == &crate::syntax::ExprKind::ERest))) {
                            crate::check::types::recording::err(&st2, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` needs {}", &name, &crate::syntax::lexer::chars::join(&each(&missing, &(|(f, _): &(Text, crate::check::types::Ty)| Text::from(format!("`{}`", f)))), &Text::lit(", ")))))
                        } else {
                            st2.clone()
                        };
                        call_value(each_job(tg.fields.clone(), {
                            let inst = inst.clone();
                            Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                                let inst = inst.clone();
                                entered(once_job(move || {
                                    let (_, ft) = p0;
                                    prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m: inst.clone(), t: ft.clone() }))
                                }))
                            }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                        }), move |each_24247: Array<crate::check::types::Ty>| {
                            let field_tys = each_24247;
                            if &tg.kind == &Text::lit("Element") {
                                {
                                    let (rw, st4) = crate::check::types::recording::fresh_row(&st3, &Array::from(vec![tg.family.clone()]));
                                    let et = crate::check::types::Ty::TyElem(crate::check::types::Rw { fams: Array::from(vec![tg.family.clone()]), minus: Array::new(), tail: rw.tail.clone() }, Rc::new(out.clone()));
                                    prism_rtl::Turn::Finished((et.clone(), crate::check::types::recording::note_ty(&st4, &cspan, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys.clone(), Rc::new(et.clone())))))
                                }
                            } else {
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(tg.kind.clone(), Array::new()), crate::check::types::recording::note_ty(&st3, &cspan, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys.clone(), Rc::new(crate::check::types::Ty::TyCon(tg.kind.clone(), Array::new()))))))
                            }
                        })
                    })
                })
            },
        }
    }
}

/// `Start TagApp, x`: what the function value is when passed to `@Run`.
pub fn start_tag_app(env: crate::check::expr::Env, st: crate::check::types::St, name: Text, args: Array<crate::syntax::Arg>, span: crate::syntax::Range, cspan: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(TagApp { env, st, name, args, span, cspan })
}

/// ```prism
/// ?FieldOfTag: fn TagInfo, Text -> ?Ty
/// ```
pub fn field_of_tag(tg: &crate::check::env::TagInfo, f: &Text) -> Option<crate::check::types::Ty> {
    fold(&tg.fields, &None, &(|found_opt: &Option<crate::check::types::Ty>, (n, t): &(Text, crate::check::types::Ty)| match found_opt {
        Some(x) => Some(x.clone()),
        None => if n == f { Some(t.clone()) } else { None },
    }))
}

/// ```prism
/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
/// ```
pub fn tag_field(env: &crate::check::expr::Env, st: &crate::check::types::St, tag_name: &Text, field: &Text, ft: &crate::check::types::Ty, a: &crate::syntax::Arg) -> crate::check::types::St {
    if &crate::check::types::head_sigil(st, ft) != &Text::lit("") {
        crate::check::expr::check(env, st, &a.value, ft)
    } else {
        {
            let (at_, st2) = crate::check::expr::infer(env, st, &a.value);
            let head = crate::check::types::head_sigil(&st2, &at_);
            if &head == &Text::lit("$") {
                crate::check::types::recording::err_fix(&st2, &Text::lit("identity-dynamic"), &a.value.span, &Text::from(format!("a dynamic in the identity field `{}`", field)), &Text::from(format!("for a new element per value, write `rebuild {}:` with `{}({}=_, ...)` inside", &crate::check::expr::src_text(env, &a.value.span), tag_name, field)))
            } else {
                if &head == &Text::lit("!") {
                    crate::check::types::recording::err(&st2, &Text::lit("two-events"), &a.value.span, &Text::from(format!("an event in the plain field `{}`", field)))
                } else {
                    crate::check::types::unify::unify(&st2, ft, &at_, &a.value.span)
                }
            }
        }
    }
}

/// The step machine of `TagField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
/// ```
pub struct TagField {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub tag_name: Text,
    pub field: Text,
    pub ft: crate::check::types::Ty,
    pub a: crate::syntax::Arg,
}

impl prism_rtl::Job<crate::check::types::St> for TagField {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let tag_name = &self.tag_name;
        let field = &self.field;
        let ft = &self.ft;
        let a = &self.a;
        let a = a.clone();
        let env = env.clone();
        let field = field.clone();
        let ft = ft.clone();
        let st = st.clone();
        let tag_name = tag_name.clone();
        call_then(crate::check::types::start_head_sigil(st.clone(), ft.clone()), move |head_sigil_25063: Text| if &head_sigil_25063 != &Text::lit("") {
            prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env: env.clone(), st: st.clone(), e: a.value.clone(), expected: ft.clone() }))
        } else {
            call_then(crate::check::expr::start_infer(env.clone(), st.clone(), a.value.clone()), move |infer_25151: (crate::check::types::Ty, crate::check::types::St)| {
                let (at_, st2) = infer_25151;
                call_then(crate::check::types::start_head_sigil(st2.clone(), at_.clone()), move |head_sigil_25193: Text| {
                    let head = head_sigil_25193;
                    if &head == &Text::lit("$") {
                        prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st2, &Text::lit("identity-dynamic"), &a.value.span, &Text::from(format!("a dynamic in the identity field `{}`", &field)), &Text::from(format!("for a new element per value, write `rebuild {}:` with `{}({}=_, ...)` inside", &crate::check::expr::src_text(&env, &a.value.span), &tag_name, &field))))
                    } else {
                        if &head == &Text::lit("!") {
                            prism_rtl::Turn::Finished(crate::check::types::recording::err(&st2, &Text::lit("two-events"), &a.value.span, &Text::from(format!("an event in the plain field `{}`", &field))))
                        } else {
                            prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st2.clone(), expected: ft.clone(), found: at_.clone(), span: a.value.span.clone() }))
                        }
                    }
                })
            })
        })
    }
}

/// `Start TagField, x`: what the function value is when passed to `@Run`.
pub fn start_tag_field(env: crate::check::expr::Env, st: crate::check::types::St, tag_name: Text, field: Text, ft: crate::check::types::Ty, a: crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(TagField { env, st, tag_name, field, ft, a })
}

/// ```prism
/// LambdaArity: fn Expr -> Nat
/// ```
pub fn lambda_arity(e: &crate::syntax::Expr) -> Nat {
    match &*e.kind {
        crate::syntax::ExprKind::ELambda(Some(ps), _) => len(ps),
        crate::syntax::ExprKind::EGroup(x) => lambda_arity(&**x),
        _ => Nat::from(2u32),
    }
}

/// ```prism
/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub fn infer_lambda(env: &crate::check::expr::Env, st: &crate::check::types::St, e: &crate::syntax::Expr, expected_opt: &Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*e.kind {
        crate::syntax::ExprKind::EGroup(x) => {
            let (t, st2) = infer_lambda(env, st, &**x, expected_opt);
            (t.clone(), crate::check::types::recording::note_ty(&st2, &e.span, &t))
        },
        _ => infer_bare_lambda(env, st, e, expected_opt),
    }
}

/// The step machine of `InferLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub struct InferLambda {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub e: crate::syntax::Expr,
    pub expected_opt: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferLambda {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let expected_opt = &self.expected_opt;
        match &*e.kind {
            crate::syntax::ExprKind::EGroup(x) => {
                let expected_opt = expected_opt.clone();
                let e = e.clone();
                let env = env.clone();
                let st = st.clone();
                let x = (**x).clone();
                call_then(start_infer_lambda(env.clone(), st.clone(), x.clone(), expected_opt.clone()), move |infer_lambda_26421: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_lambda_26421;
                    prism_rtl::Turn::Finished((t.clone(), crate::check::types::recording::note_ty(&st2, &e.span, &t)))
                })
            },
            _ => prism_rtl::Turn::More(Rc::new(InferBareLambda { env: env.clone(), st: st.clone(), e: e.clone(), expected_opt: expected_opt.clone() })),
        }
    }
}

/// `Start InferLambda, x`: what the function value is when passed to `@Run`.
pub fn start_infer_lambda(env: crate::check::expr::Env, st: crate::check::types::St, e: crate::syntax::Expr, expected_opt: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferLambda { env, st, e, expected_opt })
}

/// ```prism
/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub fn infer_bare_lambda(env: &crate::check::expr::Env, st: &crate::check::types::St, e: &crate::syntax::Expr, expected_opt: &Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    let (params, body) = match &*e.kind {
        crate::syntax::ExprKind::ELambda(Some(ps), b) => (ps.clone(), (**b).clone()),
        crate::syntax::ExprKind::ELambda(None, b) => (Array::from(vec![topic_pat(&e.span)]), (**b).clone()),
        crate::syntax::ExprKind::ETopicField(f) => (Array::from(vec![topic_pat(&e.span)]), crate::syntax::LambdaBody::LbExpr(Rc::new(topic_field_expr(&e.span, f)))),
        crate::syntax::ExprKind::ETopicIndex(x) => (Array::from(vec![topic_pat(&e.span)]), crate::syntax::LambdaBody::LbExpr(Rc::new(topic_index_expr(&e.span, &**x)))),
        _ => (Array::new(), crate::syntax::LambdaBody::LbExpr(Rc::new(e.clone()))),
    };
    let (exp_params, exp_res_opt, st0) = match expected_opt {
        Some(t) => match crate::check::types::recording::walk(st, t) {
            crate::check::types::Ty::TyFn(_, ps, r) => if &len(&ps) == &len(&params) {
                (ps.clone(), Some((*r).clone()), st.clone())
            } else {
                (Array::new(), None, crate::check::types::recording::err(st, &Text::lit("mismatch"), &e.span, &Text::from(format!("this lambda takes {} parameter{}; here {} {} wanted", &crate::check::errors::count_word(&len(&params)), &(if &len(&params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(&ps)), &(if &len(&ps) == &Nat::from(1u32) { Text::lit("is") } else { Text::lit("are") })))))
            },
            _ => (Array::new(), None, st.clone()),
        },
        None => (Array::new(), None, st.clone()),
    };
    let (env2, ptys, st1) = run_to_end(fold_job(crate::check::errors::range0(&len(&params)), (env.clone(), Array::new(), st0.clone()), {
        let params = params.clone();
        let e = e.clone();
        let exp_params = exp_params.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
            let params = params.clone();
            let e = e.clone();
            let exp_params = exp_params.clone();
            entered(once_job(move || {
                let (en, acc, s) = p0;
                let i = p1;
                {
                    let p_ = or(&index(&params, &i), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: e.span.clone() });
                    let (pt, s2) = match index(&exp_params, &i) {
                        Some(t) => (t.clone(), s.clone()),
                        None => crate::check::types::fresh_var(&s, &true, &Text::lit("")),
                    };
                    call_then(crate::check::expr::patterns::start_bind_pattern(crate::check::expr::lets::unpend(&en), s2.clone(), p_.clone(), pt.clone(), false), move |bind_pattern_27763: (crate::check::expr::Env, crate::check::types::St)| {
                        let (en2, s3) = bind_pattern_27763;
                        prism_rtl::Turn::Finished((en2.clone(), push(&acc, &pt), s3.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }));
    let outer_color = st1.color.clone();
    let outer_why = st1.color_why.clone();
    let outer_flex = st1.color_flex.clone();
    let (lcol, st1b) = crate::check::types::fresh_col(&st1);
    let st2 = {
        let mut this: crate::check::types::St = st1b.clone();
        this.color = crate::check::types::Col::CBound;
        this.color_why = Text::lit("");
        this.color_flex = Array::new();
        this
    };
    let (rt, st3) = match &body {
        crate::syntax::LambdaBody::LbExpr(x) => match &exp_res_opt {
            Some(r) => {
                let s4 = crate::check::expr::check(&env2, &st2, &**x, r);
                (r.clone(), s4.clone())
            },
            None => crate::check::expr::infer(&env2, &st2, &**x),
        },
        crate::syntax::LambdaBody::LbBlock(b) => infer_body_block(&env2, &st2, b, &exp_res_opt),
    };
    let st3b = crate::check::types::colors::settle_body(&st3, &lcol, &Text::lit(""));
    let st3c = crate::check::types::colors::add_leq(&st3b, &st3b.color, &lcol, &e.span, &Text::lit("lambda"), &Text::lit(""), &st3b.color_why);
    let st4 = {
        let mut this: crate::check::types::St = st3c.clone();
        this.color = outer_color.clone();
        this.color_why = outer_why.clone();
        this.color_flex = outer_flex.clone();
        this
    };
    (crate::check::types::Ty::TyFn(lcol.clone(), ptys.clone(), Rc::new(rt.clone())), crate::check::types::recording::note_fn(&st4, &e.span, &Text::lit("lambda"), &lcol, &lcol))
}

/// The step machine of `InferBareLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub struct InferBareLambda {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub e: crate::syntax::Expr,
    pub expected_opt: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferBareLambda {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let expected_opt = &self.expected_opt;
        let (params, body) = match &*e.kind {
            crate::syntax::ExprKind::ELambda(Some(ps), b) => (ps.clone(), (**b).clone()),
            crate::syntax::ExprKind::ELambda(None, b) => (Array::from(vec![topic_pat(&e.span)]), (**b).clone()),
            crate::syntax::ExprKind::ETopicField(f) => (Array::from(vec![topic_pat(&e.span)]), crate::syntax::LambdaBody::LbExpr(Rc::new(topic_field_expr(&e.span, f)))),
            crate::syntax::ExprKind::ETopicIndex(x) => (Array::from(vec![topic_pat(&e.span)]), crate::syntax::LambdaBody::LbExpr(Rc::new(topic_index_expr(&e.span, &**x)))),
            _ => (Array::new(), crate::syntax::LambdaBody::LbExpr(Rc::new(e.clone()))),
        };
        let (exp_params, exp_res_opt, st0) = match expected_opt {
            Some(t) => match crate::check::types::recording::walk(st, t) {
                crate::check::types::Ty::TyFn(_, ps, r) => if &len(&ps) == &len(&params) {
                    (ps.clone(), Some((*r).clone()), st.clone())
                } else {
                    (Array::new(), None, crate::check::types::recording::err(st, &Text::lit("mismatch"), &e.span, &Text::from(format!("this lambda takes {} parameter{}; here {} {} wanted", &crate::check::errors::count_word(&len(&params)), &(if &len(&params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(&ps)), &(if &len(&ps) == &Nat::from(1u32) { Text::lit("is") } else { Text::lit("are") })))))
                },
                _ => (Array::new(), None, st.clone()),
            },
            None => (Array::new(), None, st.clone()),
        };
        let e = e.clone();
        let env = env.clone();
        call_value(fold_job(crate::check::errors::range0(&len(&params)), (env.clone(), Array::new(), st0.clone()), {
            let params = params.clone();
            let e = e.clone();
            let exp_params = exp_params.clone();
            Rc::new(move |(p0, p1): ((crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
                let params = params.clone();
                let e = e.clone();
                let exp_params = exp_params.clone();
                entered(once_job(move || {
                    let (en, acc, s) = p0;
                    let i = p1;
                    {
                        let p_ = or(&index(&params, &i), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: e.span.clone() });
                        let (pt, s2) = match index(&exp_params, &i) {
                            Some(t) => (t.clone(), s.clone()),
                            None => crate::check::types::fresh_var(&s, &true, &Text::lit("")),
                        };
                        call_then(crate::check::expr::patterns::start_bind_pattern(crate::check::expr::lets::unpend(&en), s2.clone(), p_.clone(), pt.clone(), false), move |bind_pattern_27763: (crate::check::expr::Env, crate::check::types::St)| {
                            let (en2, s3) = bind_pattern_27763;
                            prism_rtl::Turn::Finished((en2.clone(), push(&acc, &pt), s3.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }), move |fold_27494: (crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St)| {
            let (env2, ptys, st1) = fold_27494;
            let outer_color = st1.color.clone();
            let outer_why = st1.color_why.clone();
            let outer_flex = st1.color_flex.clone();
            let (lcol, st1b) = crate::check::types::fresh_col(&st1);
            let st2 = {
                let mut this: crate::check::types::St = st1b.clone();
                this.color = crate::check::types::Col::CBound;
                this.color_why = Text::lit("");
                this.color_flex = Array::new();
                this
            };
            let (rt, st3) = match &body {
                crate::syntax::LambdaBody::LbExpr(x) => match &exp_res_opt {
                    Some(r) => {
                        let s4 = crate::check::expr::check(&env2, &st2, &**x, r);
                        (r.clone(), s4.clone())
                    },
                    None => crate::check::expr::infer(&env2, &st2, &**x),
                },
                crate::syntax::LambdaBody::LbBlock(b) => infer_body_block(&env2, &st2, b, &exp_res_opt),
            };
            call_then(crate::check::types::colors::start_settle_body(st3.clone(), lcol.clone(), Text::lit("")), move |settle_body_28349: crate::check::types::St| {
                let st3b = settle_body_28349;
                call_then(crate::check::types::colors::start_add_leq(st3b.clone(), st3b.color.clone(), lcol.clone(), e.span.clone(), Text::lit("lambda"), Text::lit(""), st3b.color_why.clone()), move |add_leq_28389: crate::check::types::St| {
                    let st3c = add_leq_28389;
                    let st4 = {
                        let mut this: crate::check::types::St = st3c.clone();
                        this.color = outer_color.clone();
                        this.color_why = outer_why.clone();
                        this.color_flex = outer_flex.clone();
                        this
                    };
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyFn(lcol.clone(), ptys.clone(), Rc::new(rt.clone())), crate::check::types::recording::note_fn(&st4, &e.span, &Text::lit("lambda"), &lcol, &lcol)))
                })
            })
        })
    }
}

/// `Start InferBareLambda, x`: what the function value is when passed to `@Run`.
pub fn start_infer_bare_lambda(env: crate::check::expr::Env, st: crate::check::types::St, e: crate::syntax::Expr, expected_opt: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferBareLambda { env, st, e, expected_opt })
}

/// ```prism
/// TopicPat: fn Range -> Pattern
/// ```
pub fn topic_pat(span: &crate::syntax::Range) -> crate::syntax::Pattern_ {
    crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PName(topic_sname(span))), span: span.clone() }
}

/// ```prism
/// TopicSName: fn Range -> SName
/// ```
pub fn topic_sname(span: &crate::syntax::Range) -> crate::syntax::SName {
    crate::syntax::SName { sigils: Text::lit(""), path_: Array::from(vec![Text::lit("_")]), span: span.clone() }
}

/// ```prism
/// TopicExpr: fn Range -> Expr
/// ```
pub fn topic_expr(span: &crate::syntax::Range) -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(topic_sname(span))), span: span.clone() }
}

/// ```prism
/// TopicFieldExpr: fn Range, Ident -> Expr
/// ```
pub fn topic_field_expr(span: &crate::syntax::Range, f: &crate::syntax::Ident) -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(topic_expr(span)), Text::lit(""), f.clone())), span: span.clone() }
}

/// ```prism
/// TopicIndexExpr: fn Range, Expr -> Expr
/// ```
pub fn topic_index_expr(span: &crate::syntax::Range, x: &crate::syntax::Expr) -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIndex(Rc::new(topic_expr(span)), Rc::new(x.clone()))), span: span.clone() }
}

/// ```prism
/// ArgNamed: fn Arg, Text -> Bool
/// ```
pub fn arg_named(a: &crate::syntax::Arg, f: &Text) -> bool {
    match &a.name {
        Some(id) => &id.name == f,
        None => false,
    }
}

/// ```prism
/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
/// ```
pub fn infer_body_block(env: &crate::check::expr::Env, st: &crate::check::types::St, b: &crate::syntax::Block, expected_opt: &Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t, st2) = crate::check::expr::lets::infer_expr_block(env, st, b);
    match expected_opt {
        Some(r) => (r.clone(), crate::check::types::unify::unify(&st2, r, &t, &b.span)),
        None => (t.clone(), st2.clone()),
    }
}

/// The step machine of `InferBodyBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
/// ```
pub struct InferBodyBlock {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub b: crate::syntax::Block,
    pub expected_opt: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferBodyBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let expected_opt = &self.expected_opt;
        let expected_opt = expected_opt.clone();
        let b = b.clone();
        let env = env.clone();
        let st = st.clone();
        call_then(crate::check::expr::lets::start_infer_expr_block(env.clone(), st.clone(), b.clone()), move |infer_expr_block_29644: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st2) = infer_expr_block_29644;
            match &expected_opt {
                Some(r) => {
                    let r = r.clone();
                    call_then(crate::check::types::unify::start_unify(st2.clone(), r.clone(), t.clone(), b.span.clone()), move |unify_29710: crate::check::types::St| prism_rtl::Turn::Finished((r.clone(), unify_29710)))
                },
                None => prism_rtl::Turn::Finished((t.clone(), st2.clone())),
            }
        })
    }
}

/// `Start InferBodyBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_body_block(env: crate::check::expr::Env, st: crate::check::types::St, b: crate::syntax::Block, expected_opt: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferBodyBlock { env, st, b, expected_opt })
}
