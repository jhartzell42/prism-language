//! The module `Check.Expr.Calls`, from `target/bootstrap/src/prismc/check/expr/calls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Peeled`:
///
/// ```prism
/// type Peeled = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Peeled {
    pub events_p: Array<crate::syntax::Range>,
    pub dyns_p: Array<crate::syntax::Range>,
    pub opts_p: Array<Text>,
    pub opt_args_p: Array<crate::syntax::Range>,
    pub lifted_p: Text,
    pub broken_p: bool,
}

impl Show for Peeled {
    fn show(&self, p: &mut Printer) {
        p.record("Peeled", &[("events", &self.events_p), ("dyns", &self.dyns_p), ("opts", &self.opts_p), ("optArgs", &self.opt_args_p), ("lifted", &self.lifted_p), ("broken", &self.broken_p)]);
    }
}

impl ToPod for Peeled {
    fn to_pod(&self) -> Pod {
        Pod::record("Peeled", vec![("events", self.events_p.to_pod()), ("dyns", self.dyns_p.to_pod()), ("opts", self.opts_p.to_pod()), ("optArgs", self.opt_args_p.to_pod()), ("lifted", self.lifted_p.to_pod()), ("broken", self.broken_p.to_pod())])
    }
}

impl FromPod for Peeled {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Peeled { events_p: FromPod::from_pod(field(p, "events")?)?, dyns_p: FromPod::from_pod(field(p, "dyns")?)?, opts_p: FromPod::from_pod(field(p, "opts")?)?, opt_args_p: FromPod::from_pod(field(p, "optArgs")?)?, lifted_p: FromPod::from_pod(field(p, "lifted")?)?, broken_p: FromPod::from_pod(field(p, "broken")?)? })
    }
}

/// ```prism
/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
/// ```
pub fn infer_call_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, callee_p2: &crate::syntax::Expr, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*callee_p2.kind_p {
        crate::syntax::ExprKind::EName(n_p5) => {
            let local_p6 = crate::check::env::sname_key_f(n_p5);
            match crate::prelude::get(&env_p0.locals_p, &local_p6) {
                Some(sc_p7) => {
                    let (t_p8, st2_p9) = crate::check::expr::instantiate_local_f(st_p1, &sc_p7, &callee_p2.span_p, &local_p6);
                    apply_fn_f(env_p0, &crate::check::types::recording::note_ty_f(&st2_p9, &callee_p2.span_p, &t_p8), &local_p6, &t_p8, &positional_f(args_p3), span_p4)
                },
                None => call_global_f(env_p0, st_p1, n_p5, args_p3, span_p4, &Array::new(), &callee_p2.span_p),
            }
        },
        crate::syntax::ExprKind::ETypeArgs(target_pa, tys_pb) => match &*target_pa.kind_p {
            crate::syntax::ExprKind::EName(n_pc) => {
                let cx_pd = crate::check::expr::env_cx_f(env_p0);
                let (given2_pe, st2_pf) = crate::check::env::reading::conv_types_f(&cx_pd, st_p1, tys_pb);
                call_global_f(env_p0, &st2_pf, n_pc, args_p3, span_p4, &given2_pe, &callee_p2.span_p)
            },
            _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), &callee_p2.span_p, &Text::lit("`<<T>>` applies to a function\'s name"))),
        },
        crate::syntax::ExprKind::EGroup(x_pg) => infer_call_f(env_p0, st_p1, &**x_pg, args_p3, span_p4),
        _ => {
            let (t_ph, st2_pi) = crate::check::expr::infer_f(env_p0, st_p1, callee_p2);
            apply_fn_f(env_p0, &st2_pi, &crate::check::expr::src_text_f(env_p0, &callee_p2.span_p), &t_ph, &positional_f(args_p3), span_p4)
        },
    }
}

/// The step machine of `InferCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
/// ```
pub struct InferCall {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub callee_p2: crate::syntax::Expr,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferCall {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let callee_p2 = &self.callee_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        match &*callee_p2.kind_p {
            crate::syntax::ExprKind::EName(n_p5) => {
                let local_p6 = crate::check::env::sname_key_f(n_p5);
                match crate::prelude::get(&env_p0.locals_p, &local_p6) {
                    Some(sc_p7) => {
                        let args_p3x = args_p3.clone();
                        let callee_p2x = callee_p2.clone();
                        let env_p0x = env_p0.clone();
                        let span_p4x = span_p4.clone();
                        let st_p1x = st_p1.clone();
                        crate::prelude::call_then(crate::check::expr::start_instantiate_local_f(st_p1x.clone(), sc_p7.clone(), callee_p2x.span_p.clone(), local_p6.clone()), move |instantiate_local_f_1491: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_p8, st2_p9) = instantiate_local_f_1491;
                            prism_rtl::Turn::More(Rc::new(ApplyFn { env_p0: env_p0x.clone(), st_p1: crate::check::types::recording::note_ty_f(&st2_p9, &callee_p2x.span_p, &t_p8), fname_p2: local_p6.clone(), fty_p3: t_p8.clone(), args_p4: positional_f(&args_p3x), span_p5: span_p4x.clone() }))
                        })
                    },
                    None => prism_rtl::Turn::More(Rc::new(CallGlobal { env_p0: env_p0.clone(), st0_p1: st_p1.clone(), n_p2: n_p5.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone(), explicit_p5: Array::new(), cspan_p6: callee_p2.span_p.clone() })),
                }
            },
            crate::syntax::ExprKind::ETypeArgs(target_pa, tys_pb) => match &*target_pa.kind_p {
                crate::syntax::ExprKind::EName(n_pc) => {
                    let cx_pd = crate::check::expr::env_cx_f(env_p0);
                    let args_p3x = args_p3.clone();
                    let callee_p2x = callee_p2.clone();
                    let env_p0x = env_p0.clone();
                    let n_pcx = n_pc.clone();
                    let span_p4x = span_p4.clone();
                    let st_p1x = st_p1.clone();
                    let tys_pbx = tys_pb.clone();
                    crate::prelude::call_then(crate::check::env::reading::start_conv_types_f(cx_pd.clone(), st_p1x.clone(), tys_pbx.clone()), move |conv_types_f_1826: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                        let (given2_pe, st2_pf) = conv_types_f_1826;
                        prism_rtl::Turn::More(Rc::new(CallGlobal { env_p0: env_p0x.clone(), st0_p1: st2_pf.clone(), n_p2: n_pcx.clone(), args_p3: args_p3x.clone(), span_p4: span_p4x.clone(), explicit_p5: given2_pe.clone(), cspan_p6: callee_p2x.span_p.clone() }))
                    })
                },
                _ => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), &callee_p2.span_p, &Text::lit("`<<T>>` applies to a function\'s name")))),
            },
            crate::syntax::ExprKind::EGroup(x_pg) => prism_rtl::Turn::More(Rc::new(InferCall { env_p0: env_p0.clone(), st_p1: st_p1.clone(), callee_p2: (**x_pg).clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone() })),
            _ => {
                let args_p3x = args_p3.clone();
                let callee_p2x = callee_p2.clone();
                let env_p0x = env_p0.clone();
                let span_p4x = span_p4.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), callee_p2x.clone()), move |infer_f_2107: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_ph, st2_pi) = infer_f_2107;
                    prism_rtl::Turn::More(Rc::new(ApplyFn { env_p0: env_p0x.clone(), st_p1: st2_pi.clone(), fname_p2: crate::check::expr::src_text_f(&env_p0x, &callee_p2x.span_p), fty_p3: t_ph.clone(), args_p4: positional_f(&args_p3x), span_p5: span_p4x.clone() }))
                })
            },
        }
    }
}

/// `Start InferCall, x`: what the function value is when passed to `@Run`.
pub fn start_infer_call_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, callee_p2: crate::syntax::Expr, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferCall { env_p0, st_p1, callee_p2, args_p3, span_p4 })
}

/// ```prism
/// Positional: fn [Arg] -> [Arg]
/// ```
pub fn positional_f(args_p0: &Array<crate::syntax::Arg>) -> Array<crate::syntax::Arg> {
    args_p0.clone()
}

/// ```prism
/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
/// ```
pub fn call_global_f(env_p0: &crate::check::expr::Env, st0_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range, explicit_p5: &Array<crate::check::types::Ty>, cspan_p6: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (qk_oa, why_pb) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p2);
    let name_p7 = crate::check::env::sname_key_f(n_p2);
    let st1_p8 = crate::check::expr::collision_at_f(env_p0, st0_p1, &why_pb, &name_p7, &n_p2.span_p);
    let st_p9 = match &qk_oa {
        Some(qk_pc) => crate::check::types::recording::note_global_f(&st1_p8, &n_p2.span_p, qk_pc),
        None => st1_p8.clone(),
    };
    match &qk_oa {
        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p9, &Text::lit("unknown-name"), &n_p2.span_p, &Text::from(format!("nothing declares `{}` here", &name_p7)))),
        Some(qk_pd) => if &why_pb == &Text::lit("tag") {
            tag_app_f(env_p0, &st_p9, qk_pd, args_p3, span_p4, cspan_p6)
        } else {
            if is_local_maker_f(qk_pd) && !env_p0.in_update_p {
                (crate::check::types::Ty::TyErr, local_outside_f(&st_p9, qk_pd, span_p4))
            } else {
                match crate::prelude::get(&env_p0.g_p.vals_p, qk_pd) {
                    Some(v_pe) => {
                        let (t_ph, st2i_pi, inst_pj) = crate::check::types::schemes::instantiate_with_f(&st_p9, &v_pe.scheme_p, span_p4, explicit_p5);
                        let (rigids_pk, st2_pl) = rank_two_f(&st2i_pi, &v_pe.scheme_p, &inst_pj, &crate::prelude::len(explicit_p5), span_p4);
                        let st3a_pf = note_callee_f(&note_method_use_f(&st2_pl, &v_pe, span_p4), &n_p2.span_p, cspan_p6, &t_ph);
                        let st3_pg = if &crate::check::types::bare_name_f(qk_pd) == &Text::lit("Min") {
                            crate::check::types::recording::note_size_ty_f(&st3a_pf, span_p4, &crate::check::types::recording::walk_f(&st3a_pf, &t_ph))
                        } else {
                            st3a_pf.clone()
                        };
                        if (&crate::check::types::bare_name_f(qk_pd) == &Text::lit("Fold")) && (&v_pe.home_p == &Text::lit("Prelude")) {
                            fold_app_f(env_p0, &st3_pg, &t_ph, args_p3, span_p4)
                        } else {
                            {
                                let (rt_pm, st4_pn) = apply_fn_f(env_p0, &st3_pg, &name_p7, &t_ph, args_p3, span_p4);
                                (rt_pm.clone(), escaped_f(env_p0, &st4_pn, &rigids_pk, &rt_pm, &name_p7, span_p4))
                            }
                        }
                    },
                    None => match crate::prelude::get(&env_p0.g_p.ctors_p, qk_pd) {
                        Some(c_po) => ctor_app_f(env_p0, &st_p9, &c_po, args_p3, span_p4, cspan_p6),
                        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p9, &Text::lit("unknown-name"), &n_p2.span_p, &Text::from(format!("`{}` has no signature line", &name_p7)))),
                    },
                }
            }
        },
    }
}

/// The step machine of `CallGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
/// ```
pub struct CallGlobal {
    pub env_p0: crate::check::expr::Env,
    pub st0_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
    pub explicit_p5: Array<crate::check::types::Ty>,
    pub cspan_p6: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for CallGlobal {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st0_p1 = &self.st0_p1;
        let n_p2 = &self.n_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let explicit_p5 = &self.explicit_p5;
        let cspan_p6 = &self.cspan_p6;
        let (qk_oa, why_pb) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p2);
        let name_p7 = crate::check::env::sname_key_f(n_p2);
        let st1_p8 = crate::check::expr::collision_at_f(env_p0, st0_p1, &why_pb, &name_p7, &n_p2.span_p);
        let st_p9 = match &qk_oa {
            Some(qk_pc) => crate::check::types::recording::note_global_f(&st1_p8, &n_p2.span_p, qk_pc),
            None => st1_p8.clone(),
        };
        match &qk_oa {
            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p9, &Text::lit("unknown-name"), &n_p2.span_p, &Text::from(format!("nothing declares `{}` here", &name_p7))))),
            Some(qk_pd) => if &why_pb == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(TagApp { env_p0: env_p0.clone(), st_p1: st_p9.clone(), name_p2: qk_pd.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone(), cspan_p5: cspan_p6.clone() }))
            } else {
                if is_local_maker_f(qk_pd) && !env_p0.in_update_p {
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, local_outside_f(&st_p9, qk_pd, span_p4)))
                } else {
                    match crate::prelude::get(&env_p0.g_p.vals_p, qk_pd) {
                        Some(v_pe) => {
                            let args_p3x = args_p3.clone();
                            let cspan_p6x = cspan_p6.clone();
                            let env_p0x = env_p0.clone();
                            let explicit_p5x = explicit_p5.clone();
                            let n_p2x = n_p2.clone();
                            let qk_pdx = qk_pd.clone();
                            let span_p4x = span_p4.clone();
                            crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p9.clone(), v_pe.scheme_p.clone(), span_p4x.clone(), explicit_p5x.clone()), move |instantiate_with_f_3014: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                                let (t_ph, st2i_pi, inst_pj) = instantiate_with_f_3014;
                                crate::prelude::call_then(start_rank_two_f(st2i_pi.clone(), v_pe.scheme_p.clone(), inst_pj.clone(), crate::prelude::len(&explicit_p5x), span_p4x.clone()), move |rank_two_f_3101: (Array<Text>, crate::check::types::St)| {
                                    let (rigids_pk, st2_pl) = rank_two_f_3101;
                                    let st3a_pf = note_callee_f(&note_method_use_f(&st2_pl, &v_pe, &span_p4x), &n_p2x.span_p, &cspan_p6x, &t_ph);
                                    let st3_pg = if &crate::check::types::bare_name_f(&qk_pdx) == &Text::lit("Min") {
                                        crate::check::types::recording::note_size_ty_f(&st3a_pf, &span_p4x, &crate::check::types::recording::walk_f(&st3a_pf, &t_ph))
                                    } else {
                                        st3a_pf.clone()
                                    };
                                    if (&crate::check::types::bare_name_f(&qk_pdx) == &Text::lit("Fold")) && (&v_pe.home_p == &Text::lit("Prelude")) {
                                        prism_rtl::Turn::More(Rc::new(FoldApp { env_p0: env_p0x.clone(), st_p1: st3_pg.clone(), t_p2: t_ph.clone(), args_p3: args_p3x.clone(), span_p4: span_p4x.clone() }))
                                    } else {
                                        crate::prelude::call_then(start_apply_fn_f(env_p0x.clone(), st3_pg.clone(), name_p7.clone(), t_ph.clone(), args_p3x.clone(), span_p4x.clone()), move |apply_fn_f_3519: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (rt_pm, st4_pn) = apply_fn_f_3519;
                                            crate::prelude::call_then(start_escaped_f(env_p0x.clone(), st4_pn.clone(), rigids_pk.clone(), rt_pm.clone(), name_p7.clone(), span_p4x.clone()), move |escaped_f_3588: crate::check::types::St| prism_rtl::Turn::Finished((rt_pm.clone(), escaped_f_3588)))
                                        })
                                    }
                                })
                            })
                        },
                        None => match crate::prelude::get(&env_p0.g_p.ctors_p, qk_pd) {
                            Some(c_po) => prism_rtl::Turn::More(Rc::new(CtorApp { env_p0: env_p0.clone(), st_p1: st_p9.clone(), c_p2: c_po.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone(), cspan_p5: cspan_p6.clone() })),
                            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p9, &Text::lit("unknown-name"), &n_p2.span_p, &Text::from(format!("`{}` has no signature line", &name_p7))))),
                        },
                    }
                }
            },
        }
    }
}

/// `Start CallGlobal, x`: what the function value is when passed to `@Run`.
pub fn start_call_global_f(env_p0: crate::check::expr::Env, st0_p1: crate::check::types::St, n_p2: crate::syntax::SName, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range, explicit_p5: Array<crate::check::types::Ty>, cspan_p6: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(CallGlobal { env_p0, st0_p1, n_p2, args_p3, span_p4, explicit_p5, cspan_p6 })
}

/// ```prism
/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
/// ```
pub fn rank_two_f(st_p0: &crate::check::types::St, sc_p1: &crate::check::types::Scheme, inst_p2: &crate::check::types::schemes::Inst, n_explicit_p3: &Nat, span_p4: &crate::syntax::Range) -> (Array<Text>, crate::check::types::St) {
    let qs_p5 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(&sc_p1.qs_p)), &(|i_p6: &Nat| (i_p6 >= n_explicit_p3) && is_rank_two_f(&crate::prelude::or(&crate::prelude::index(&sc_p1.qs_p, i_p6), &Text::lit("")), &sc_p1.ty_p)));
    crate::prelude::run_to_end(crate::prelude::fold_job(qs_p5.clone(), (Array::new(), st_p0.clone()), {
        let sc_p1x = sc_p1.clone();
        let inst_p2x = inst_p2.clone();
        let span_p4x = span_p4.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, crate::check::types::St), Nat)| {
            let sc_p1xy = sc_p1x.clone();
            let inst_p2xy = inst_p2x.clone();
            let span_p4xy = span_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p7, s_p8) = p0;
                let i_p9 = p1;
                {
                    let q_pa = crate::prelude::or(&crate::prelude::index(&sc_p1xy.qs_p, &i_p9), &Text::lit(""));
                    let rigid_pb = Text::from(format!("{}\'{}", &q_pa, &s_p8.next_p));
                    let s2_pc = {
                        let mut this: crate::check::types::St = s_p8.clone();
                        this.next_p = &this.next_p + &Nat::from(1u32);
                        this
                    };
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(s2_pc.clone(), crate::prelude::or(&crate::prelude::get(&inst_p2xy.tys_p, &q_pa), &crate::check::types::Ty::TyErr), crate::check::types::Ty::TyRigid(rigid_pb.clone()), span_p4xy.clone()), move |unify_f_4667: crate::check::types::St| prism_rtl::Turn::Finished((crate::prelude::push(&acc_p7, &rigid_pb), unify_f_4667)))
                }
            }))
        }) as Rc<dyn Fn(((Array<Text>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>>>
    }))
}

/// The step machine of `RankTwo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
/// ```
pub struct RankTwo {
    pub st_p0: crate::check::types::St,
    pub sc_p1: crate::check::types::Scheme,
    pub inst_p2: crate::check::types::schemes::Inst,
    pub n_explicit_p3: Nat,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(Array<Text>, crate::check::types::St)> for RankTwo {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let sc_p1 = &self.sc_p1;
        let inst_p2 = &self.inst_p2;
        let n_explicit_p3 = &self.n_explicit_p3;
        let span_p4 = &self.span_p4;
        let qs_p5 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(&sc_p1.qs_p)), &(|i_p6: &Nat| (i_p6 >= n_explicit_p3) && is_rank_two_f(&crate::prelude::or(&crate::prelude::index(&sc_p1.qs_p, i_p6), &Text::lit("")), &sc_p1.ty_p)));
        crate::prelude::fold_job(qs_p5.clone(), (Array::new(), st_p0.clone()), {
            let sc_p1x = sc_p1.clone();
            let inst_p2x = inst_p2.clone();
            let span_p4x = span_p4.clone();
            Rc::new(move |(p0, p1): ((Array<Text>, crate::check::types::St), Nat)| {
                let sc_p1xy = sc_p1x.clone();
                let inst_p2xy = inst_p2x.clone();
                let span_p4xy = span_p4x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p7, s_p8) = p0;
                    let i_p9 = p1;
                    {
                        let q_pa = crate::prelude::or(&crate::prelude::index(&sc_p1xy.qs_p, &i_p9), &Text::lit(""));
                        let rigid_pb = Text::from(format!("{}\'{}", &q_pa, &s_p8.next_p));
                        let s2_pc = {
                            let mut this: crate::check::types::St = s_p8.clone();
                            this.next_p = &this.next_p + &Nat::from(1u32);
                            this
                        };
                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(s2_pc.clone(), crate::prelude::or(&crate::prelude::get(&inst_p2xy.tys_p, &q_pa), &crate::check::types::Ty::TyErr), crate::check::types::Ty::TyRigid(rigid_pb.clone()), span_p4xy.clone()), move |unify_f_4667: crate::check::types::St| prism_rtl::Turn::Finished((crate::prelude::push(&acc_p7, &rigid_pb), unify_f_4667)))
                    }
                }))
            }) as Rc<dyn Fn(((Array<Text>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start RankTwo, x`: what the function value is when passed to `@Run`.
pub fn start_rank_two_f(st_p0: crate::check::types::St, sc_p1: crate::check::types::Scheme, inst_p2: crate::check::types::schemes::Inst, n_explicit_p3: Nat, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>> {
    Rc::new(RankTwo { st_p0, sc_p1, inst_p2, n_explicit_p3, span_p4 })
}

/// ```prism
/// IsRankTwo: fn Text, Ty -> Bool
/// ```
pub fn is_rank_two_f(q_p0: &Text, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyFn(_, ps_p2, res_p3) => {
            let holding_p4 = crate::prelude::filter(ps_p2, &(|p_p5: &crate::check::types::Ty| qoccurs_f(q_p0, p_p5)));
            if (&crate::prelude::len(&holding_p4) != &Nat::from(1u32)) || qoccurs_f(q_p0, &**res_p3) {
                false
            } else {
                match crate::prelude::index(&holding_p4, &Nat::from(0u32)) {
                    Some(crate::check::types::Ty::TyFn(_, _, _)) => elem_out_q_f(q_p0, &crate::prelude::or(&crate::prelude::index(&holding_p4, &Nat::from(0u32)), &crate::check::types::Ty::TyErr)),
                    _ => false,
                }
            }
        },
        _ => false,
    }
}

/// ```prism
/// QOccurs: fn Text, Ty -> Bool
/// ```
pub fn qoccurs_f(q_p0: &Text, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyQ(n_p2) => n_p2 == q_p0,
        crate::check::types::Ty::TyCon(_, args_p3) => crate::prelude::fold(args_p3, &false, &(|seen_p4: &bool, a_p5: &crate::check::types::Ty| *seen_p4 || qoccurs_f(q_p0, a_p5))),
        crate::check::types::Ty::TyFn(_, ps_p6, r_p7) => crate::prelude::fold(ps_p6, &qoccurs_f(q_p0, &**r_p7), &(|seen_p8: &bool, a_p9: &crate::check::types::Ty| *seen_p8 || qoccurs_f(q_p0, a_p9))),
        crate::check::types::Ty::TyTuple(ts_pa) => crate::prelude::fold(ts_pa, &false, &(|seen_pb: &bool, a_pc: &crate::check::types::Ty| *seen_pb || qoccurs_f(q_p0, a_pc))),
        crate::check::types::Ty::TyArray(e_pd) => qoccurs_f(q_p0, &**e_pd),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => qoccurs_f(q_p0, &**k_pe) || qoccurs_f(q_p0, &**v_pf),
        crate::check::types::Ty::TySig(_, i_pg) => qoccurs_f(q_p0, &**i_pg),
        crate::check::types::Ty::TyAt(i_ph, _) => qoccurs_f(q_p0, &**i_ph),
        crate::check::types::Ty::TyElem(_, o_pi) => qoccurs_f(q_p0, &**o_pi),
        crate::check::types::Ty::TyAssoc(_, i_pj) => qoccurs_f(q_p0, &**i_pj),
        _ => false,
    }
}

/// ```prism
/// ElemOutQ: fn Text, Ty -> Bool
/// ```
pub fn elem_out_q_f(q_p0: &Text, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyElem(_, o_p2) => (&**o_p2 == &crate::check::types::Ty::TyQ(q_p0.clone())) || elem_out_q_f(q_p0, &**o_p2),
        crate::check::types::Ty::TyCon(_, args_p3) => crate::prelude::fold(args_p3, &false, &(|seen_p4: &bool, a_p5: &crate::check::types::Ty| *seen_p4 || elem_out_q_f(q_p0, a_p5))),
        crate::check::types::Ty::TyFn(_, ps_p6, r_p7) => crate::prelude::fold(ps_p6, &elem_out_q_f(q_p0, &**r_p7), &(|seen_p8: &bool, a_p9: &crate::check::types::Ty| *seen_p8 || elem_out_q_f(q_p0, a_p9))),
        crate::check::types::Ty::TyTuple(ts_pa) => crate::prelude::fold(ts_pa, &false, &(|seen_pb: &bool, a_pc: &crate::check::types::Ty| *seen_pb || elem_out_q_f(q_p0, a_pc))),
        crate::check::types::Ty::TyArray(e_pd) => elem_out_q_f(q_p0, &**e_pd),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => elem_out_q_f(q_p0, &**k_pe) || elem_out_q_f(q_p0, &**v_pf),
        crate::check::types::Ty::TySig(_, i_pg) => elem_out_q_f(q_p0, &**i_pg),
        crate::check::types::Ty::TyAt(i_ph, _) => elem_out_q_f(q_p0, &**i_ph),
        _ => false,
    }
}

/// ```prism
/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
/// ```
pub fn escaped_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, rigids_p2: &Array<Text>, rt_p3: &crate::check::types::Ty, fname_p4: &Text, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    crate::prelude::run_to_end(crate::prelude::fold_job(rigids_p2.clone(), st_p1.clone(), {
        let env_p0x = env_p0.clone();
        let rt_p3x = rt_p3.clone();
        let span_p5x = span_p5.clone();
        let fname_p4x = fname_p4.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
            let env_p0xy = env_p0x.clone();
            let rt_p3xy = rt_p3x.clone();
            let span_p5xy = span_p5x.clone();
            let fname_p4xy = fname_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p6 = p0;
                let r_p7 = p1;
                crate::prelude::call_value(crate::prelude::filter_job(crate::prelude::keys(&env_p0xy.locals_p), {
                    let s_p6x = s_p6.clone();
                    let r_p7x = r_p7.clone();
                    let env_p0xyx = env_p0xy.clone();
                    Rc::new(move |p0: Text| {
                        let s_p6xy = s_p6x.clone();
                        let r_p7xy = r_p7x.clone();
                        let env_p0xyxy = env_p0xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let k_p9 = p0;
                            prism_rtl::Turn::More(Rc::new(HasRigid { st_p0: s_p6xy.clone(), r_p1: r_p7xy.clone(), t_p2: crate::prelude::or(&crate::prelude::get(&env_p0xyxy.locals_p, &k_p9), &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)).ty_p.clone() }))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |filter_6630: Array<Text>| {
                    let outside_p8 = filter_6630;
                    crate::prelude::call_then(start_has_rigid_f(s_p6.clone(), r_p7.clone(), rt_p3xy.clone()), move |has_rigid_f_6719: bool| if has_rigid_f_6719 {
                        prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_p6, &Text::lit("refinement-escape"), &span_p5xy, &Text::from(format!("the call\'s result takes the output of the element `{}`\'s supplier answers, which is the supplier\'s alone (rank-2)", &fname_p4xy))))
                    } else {
                        match crate::prelude::index(&outside_p8, &Nat::from(0u32)) {
                            Some(k_pa) => prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_p6, &Text::lit("refinement-escape"), &span_p5xy, &Text::from(format!("`{}`, outside the supplier `{}` is given, takes the output of the element the supplier answers, which is the supplier\'s alone (rank-2)", &k_pa, &fname_p4xy)))),
                            None => prism_rtl::Turn::Finished(s_p6.clone()),
                        }
                    })
                })
            }))
        }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `Escaped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
/// ```
pub struct Escaped {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub rigids_p2: Array<Text>,
    pub rt_p3: crate::check::types::Ty,
    pub fname_p4: Text,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for Escaped {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let rigids_p2 = &self.rigids_p2;
        let rt_p3 = &self.rt_p3;
        let fname_p4 = &self.fname_p4;
        let span_p5 = &self.span_p5;
        crate::prelude::fold_job(rigids_p2.clone(), st_p1.clone(), {
            let env_p0x = env_p0.clone();
            let rt_p3x = rt_p3.clone();
            let span_p5x = span_p5.clone();
            let fname_p4x = fname_p4.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
                let env_p0xy = env_p0x.clone();
                let rt_p3xy = rt_p3x.clone();
                let span_p5xy = span_p5x.clone();
                let fname_p4xy = fname_p4x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p6 = p0;
                    let r_p7 = p1;
                    crate::prelude::call_value(crate::prelude::filter_job(crate::prelude::keys(&env_p0xy.locals_p), {
                        let s_p6x = s_p6.clone();
                        let r_p7x = r_p7.clone();
                        let env_p0xyx = env_p0xy.clone();
                        Rc::new(move |p0: Text| {
                            let s_p6xy = s_p6x.clone();
                            let r_p7xy = r_p7x.clone();
                            let env_p0xyxy = env_p0xyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let k_p9 = p0;
                                prism_rtl::Turn::More(Rc::new(HasRigid { st_p0: s_p6xy.clone(), r_p1: r_p7xy.clone(), t_p2: crate::prelude::or(&crate::prelude::get(&env_p0xyxy.locals_p, &k_p9), &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)).ty_p.clone() }))
                            }))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |filter_6630: Array<Text>| {
                        let outside_p8 = filter_6630;
                        crate::prelude::call_then(start_has_rigid_f(s_p6.clone(), r_p7.clone(), rt_p3xy.clone()), move |has_rigid_f_6719: bool| if has_rigid_f_6719 {
                            prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_p6, &Text::lit("refinement-escape"), &span_p5xy, &Text::from(format!("the call\'s result takes the output of the element `{}`\'s supplier answers, which is the supplier\'s alone (rank-2)", &fname_p4xy))))
                        } else {
                            match crate::prelude::index(&outside_p8, &Nat::from(0u32)) {
                                Some(k_pa) => prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_p6, &Text::lit("refinement-escape"), &span_p5xy, &Text::from(format!("`{}`, outside the supplier `{}` is given, takes the output of the element the supplier answers, which is the supplier\'s alone (rank-2)", &k_pa, &fname_p4xy)))),
                                None => prism_rtl::Turn::Finished(s_p6.clone()),
                            }
                        })
                    })
                }))
            }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start Escaped, x`: what the function value is when passed to `@Run`.
pub fn start_escaped_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, rigids_p2: Array<Text>, rt_p3: crate::check::types::Ty, fname_p4: Text, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Escaped { env_p0, st_p1, rigids_p2, rt_p3, fname_p4, span_p5 })
}

/// ```prism
/// HasRigid: unbounded fn St, Text, Ty -> Bool
/// ```
pub fn has_rigid_f(st_p0: &crate::check::types::St, r_p1: &Text, t_p2: &crate::check::types::Ty) -> bool {
    rigid_in_f(r_p1, &crate::check::types::recording::zonk_f(st_p0, t_p2))
}

/// The step machine of `HasRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HasRigid: unbounded fn St, Text, Ty -> Bool
/// ```
pub struct HasRigid {
    pub st_p0: crate::check::types::St,
    pub r_p1: Text,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for HasRigid {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let r_p1 = &self.r_p1;
        let t_p2 = &self.t_p2;
        let r_p1x = r_p1.clone();
        let st_p0x = st_p0.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x.clone(), t_p2x.clone()), move |zonk_f_7206: crate::check::types::Ty| prism_rtl::Turn::Finished(rigid_in_f(&r_p1x, &zonk_f_7206)))
    }
}

/// `Start HasRigid, x`: what the function value is when passed to `@Run`.
pub fn start_has_rigid_f(st_p0: crate::check::types::St, r_p1: Text, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HasRigid { st_p0, r_p1, t_p2 })
}

/// ```prism
/// RigidIn: fn Text, Ty -> Bool
/// ```
pub fn rigid_in_f(r_p0: &Text, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyRigid(n_p2) => n_p2 == r_p0,
        crate::check::types::Ty::TyCon(_, args_p3) => crate::prelude::fold(args_p3, &false, &(|seen_p4: &bool, a_p5: &crate::check::types::Ty| *seen_p4 || rigid_in_f(r_p0, a_p5))),
        crate::check::types::Ty::TyFn(_, ps_p6, res_p7) => crate::prelude::fold(ps_p6, &rigid_in_f(r_p0, &**res_p7), &(|seen_p8: &bool, a_p9: &crate::check::types::Ty| *seen_p8 || rigid_in_f(r_p0, a_p9))),
        crate::check::types::Ty::TyTuple(ts_pa) => crate::prelude::fold(ts_pa, &false, &(|seen_pb: &bool, a_pc: &crate::check::types::Ty| *seen_pb || rigid_in_f(r_p0, a_pc))),
        crate::check::types::Ty::TyArray(e_pd) => rigid_in_f(r_p0, &**e_pd),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => rigid_in_f(r_p0, &**k_pe) || rigid_in_f(r_p0, &**v_pf),
        crate::check::types::Ty::TySig(_, i_pg) => rigid_in_f(r_p0, &**i_pg),
        crate::check::types::Ty::TyAt(i_ph, _) => rigid_in_f(r_p0, &**i_ph),
        crate::check::types::Ty::TyElem(_, o_pi) => rigid_in_f(r_p0, &**o_pi),
        crate::check::types::Ty::TyAssoc(_, i_pj) => rigid_in_f(r_p0, &**i_pj),
        _ => false,
    }
}

/// ```prism
/// IsLocalMaker: fn Text -> Bool
/// ```
pub fn is_local_maker_f(qk_p0: &Text) -> bool {
    crate::check::types::has_text_f(&Array::from(vec![Text::lit("Buffer.Numbered"), Text::lit("Buffer.Empty"), Text::lit("Table.Empty")]), qk_p0)
}

/// ```prism
/// LocalOutside: fn St, Text, Range -> St
/// ```
pub fn local_outside_f(st_p0: &crate::check::types::St, qk_p1: &Text, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    crate::check::types::recording::err_fix_f(st_p0, &Text::lit("local-escapes"), span_p2, &Text::from(format!("a `{}` lives only in an `&` block\'s local", &crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(qk_p1, &Text::lit(".")), &Nat::from(0u32)), qk_p1))), &Text::from(format!("make it inside `update ...:` as `let &b = {} ...`, and `Freeze &b` for the plain value", qk_p1)))
}

/// ```prism
/// NoteCallee: fn St, Range, Range, Ty -> St
/// ```
pub fn note_callee_f(st_p0: &crate::check::types::St, at_p1: &crate::syntax::Range, cspan_p2: &crate::syntax::Range, t_p3: &crate::check::types::Ty) -> crate::check::types::St {
    if at_p1 == cspan_p2 {
        crate::check::types::recording::note_ty_f(st_p0, at_p1, t_p3)
    } else {
        crate::check::types::recording::note_ty_f(&crate::check::types::recording::note_ty_f(st_p0, at_p1, t_p3), cspan_p2, t_p3)
    }
}

/// ```prism
/// NoteMethodUse: fn St, ValInfo, Range -> St
/// ```
pub fn note_method_use_f(st_p0: &crate::check::types::St, v_p1: &crate::check::env::ValInfo, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    if &v_p1.sort_p != &Text::lit("method") {
        st_p0.clone()
    } else {
        {
            let (_, cls_p3) = crate::prelude::or(&crate::prelude::index(&v_p1.scheme_p.bounds_p, &Nat::from(0u32)), &(Text::lit(""), Text::lit("")));
            crate::check::types::recording::note_method_f(st_p0, span_p2, &v_p1.qk_p, &cls_p3)
        }
    }
}

/// ```prism
/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn fold_app_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let lambda_arity_p5 = match crate::prelude::index(args_p3, &Nat::from(2u32)) {
        Some(a_p6) => lambda_arity_f(&a_p6.value_p),
        None => Nat::from(2u32),
    };
    if &lambda_arity_p5 == &Nat::from(3u32) {
        match crate::check::types::recording::walk_f(st_p1, t_p2) {
            crate::check::types::Ty::TyFn(col_p7, params_p8, res_p9) => {
                let (k_pc, st1_pd) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
                let (v_pe, st2_pf) = crate::check::types::fresh_var_f(&st1_pd, &false, &Text::lit(""));
                let (b_pg, st3_ph) = crate::check::types::fresh_var_f(&st2_pf, &false, &Text::lit(""));
                let step_col_pa = match crate::prelude::index(&params_p8, &Nat::from(2u32)) {
                    Some(crate::check::types::Ty::TyFn(c_pi, _, _)) => c_pi,
                    _ => col_p7.clone(),
                };
                let params2_pb = Array::from(vec![crate::check::types::Ty::TyMap(Rc::new(k_pc.clone()), Rc::new(v_pe.clone())), b_pg.clone(), crate::check::types::Ty::TyFn(step_col_pa.clone(), Array::from(vec![b_pg.clone(), k_pc.clone(), v_pe.clone()]), Rc::new(b_pg.clone()))]);
                apply_rule_f(env_p0, &st3_ph, &Text::lit("Fold"), &col_p7, &params2_pb, &b_pg, args_p3, span_p4)
            },
            _ => apply_fn_f(env_p0, st_p1, &Text::lit("Fold"), t_p2, args_p3, span_p4),
        }
    } else {
        apply_fn_f(env_p0, st_p1, &Text::lit("Fold"), t_p2, args_p3, span_p4)
    }
}

/// The step machine of `FoldApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct FoldApp {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for FoldApp {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let lambda_arity_p5 = match crate::prelude::index(args_p3, &Nat::from(2u32)) {
            Some(a_p6) => lambda_arity_f(&a_p6.value_p),
            None => Nat::from(2u32),
        };
        if &lambda_arity_p5 == &Nat::from(3u32) {
            {
                let args_p3x = args_p3.clone();
                let env_p0x = env_p0.clone();
                let span_p4x = span_p4.clone();
                let st_p1x = st_p1.clone();
                let t_p2x = t_p2.clone();
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), t_p2x.clone()), move |walk_f_9146: crate::check::types::Ty| match walk_f_9146 {
                    crate::check::types::Ty::TyFn(col_p7, params_p8, res_p9) => {
                        let (k_pc, st1_pd) = crate::check::types::fresh_var_f(&st_p1x, &false, &Text::lit(""));
                        let (v_pe, st2_pf) = crate::check::types::fresh_var_f(&st1_pd, &false, &Text::lit(""));
                        let (b_pg, st3_ph) = crate::check::types::fresh_var_f(&st2_pf, &false, &Text::lit(""));
                        let step_col_pa = match crate::prelude::index(&params_p8, &Nat::from(2u32)) {
                            Some(crate::check::types::Ty::TyFn(c_pi, _, _)) => c_pi,
                            _ => col_p7.clone(),
                        };
                        let params2_pb = Array::from(vec![crate::check::types::Ty::TyMap(Rc::new(k_pc.clone()), Rc::new(v_pe.clone())), b_pg.clone(), crate::check::types::Ty::TyFn(step_col_pa.clone(), Array::from(vec![b_pg.clone(), k_pc.clone(), v_pe.clone()]), Rc::new(b_pg.clone()))]);
                        prism_rtl::Turn::More(Rc::new(ApplyRule { env_p0: env_p0x.clone(), st_p1: st3_ph.clone(), fname_p2: Text::lit("Fold"), col_p3: col_p7.clone(), params_p4: params2_pb.clone(), res_p5: b_pg.clone(), args_p6: args_p3x.clone(), span_p7: span_p4x.clone() }))
                    },
                    _ => prism_rtl::Turn::More(Rc::new(ApplyFn { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), fname_p2: Text::lit("Fold"), fty_p3: t_p2x.clone(), args_p4: args_p3x.clone(), span_p5: span_p4x.clone() })),
                })
            }
        } else {
            prism_rtl::Turn::More(Rc::new(ApplyFn { env_p0: env_p0.clone(), st_p1: st_p1.clone(), fname_p2: Text::lit("Fold"), fty_p3: t_p2.clone(), args_p4: args_p3.clone(), span_p5: span_p4.clone() }))
        }
    }
}

/// `Start FoldApp, x`: what the function value is when passed to `@Run`.
pub fn start_fold_app_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(FoldApp { env_p0, st_p1, t_p2, args_p3, span_p4 })
}

/// ```prism
/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn apply_fn_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fname_p2: &Text, fty_p3: &crate::check::types::Ty, args_p4: &Array<crate::syntax::Arg>, span_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let named_p6 = crate::prelude::filter(args_p4, &(|a_p8: &crate::syntax::Arg| &a_p8.name_o != &None));
    let st0_p7 = if &crate::prelude::len(&named_p6) > &Nat::from(0u32) {
        crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), span_p5, &Text::from(format!("`{}` takes its arguments by position; named arguments are a record\'s or a tag\'s", fname_p2)))
    } else {
        st_p1.clone()
    };
    match crate::check::types::recording::walk_f(&st0_p7, fty_p3) {
        crate::check::types::Ty::TyFn(col_p9, params_pa, res_pb) => if &crate::prelude::len(&params_pa) != &crate::prelude::len(args_p4) {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st0_p7, &Text::lit("mismatch"), span_p5, &Text::from(format!("`{}` takes {} argument{}; here it has {}", fname_p2, &crate::check::errors::count_word_f(&crate::prelude::len(&params_pa)), &(if &crate::prelude::len(&params_pa) == &Nat::from(1u32) {
                Text::lit("")
            } else {
                Text::lit("s")
            }), &crate::check::errors::count_word_f(&crate::prelude::len(args_p4))))))
        } else {
            apply_rule_f(env_p0, &st0_p7, fname_p2, &col_p9, &params_pa, &*res_pb, args_p4, span_p5)
        },
        crate::check::types::Ty::TyFlex(_) => {
            let (params_ph, st1_pi) = crate::prelude::fold(args_p4, &(Array::new(), st0_p7.clone()), &(|(acc_pd, s_pe): &(Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Arg| {
                let (v_pf, s2_pg) = crate::check::types::fresh_var_f(s_pe, &false, &Text::lit(""));
                (crate::prelude::push(acc_pd, &v_pf), s2_pg.clone())
            }));
            let (res_pj, st2_pk) = crate::check::types::fresh_var_f(&st1_pi, &false, &Text::lit(""));
            let (col_pl, st2b_pm) = crate::check::types::fresh_col_f(&st2_pk);
            let st3_pc = crate::check::types::unify::unify_f(&st2b_pm, fty_p3, &crate::check::types::Ty::TyFn(col_pl.clone(), params_ph.clone(), Rc::new(res_pj.clone())), span_p5);
            apply_rule_f(env_p0, &st3_pc, fname_p2, &col_pl, &params_ph, &res_pj, args_p4, span_p5)
        },
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st0_p7.clone()),
        other_pn => if &crate::prelude::len(args_p4) == &Nat::from(0u32) {
            (other_pn.clone(), st0_p7.clone())
        } else {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st0_p7, &Text::lit("mismatch"), span_p5, &Text::from(format!("`{}` is a `{}`, not a function", fname_p2, &crate::check::types::show_ty_f(&st0_p7, &other_pn)))))
        },
    }
}

/// The step machine of `ApplyFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct ApplyFn {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fname_p2: Text,
    pub fty_p3: crate::check::types::Ty,
    pub args_p4: Array<crate::syntax::Arg>,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ApplyFn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fname_p2 = &self.fname_p2;
        let fty_p3 = &self.fty_p3;
        let args_p4 = &self.args_p4;
        let span_p5 = &self.span_p5;
        let named_p6 = crate::prelude::filter(args_p4, &(|a_p8: &crate::syntax::Arg| &a_p8.name_o != &None));
        let st0_p7 = if &crate::prelude::len(&named_p6) > &Nat::from(0u32) {
            crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), span_p5, &Text::from(format!("`{}` takes its arguments by position; named arguments are a record\'s or a tag\'s", fname_p2)))
        } else {
            st_p1.clone()
        };
        let args_p4x = args_p4.clone();
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        let fty_p3x = fty_p3.clone();
        let span_p5x = span_p5.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st0_p7.clone(), fty_p3x.clone()), move |walk_f_10180: crate::check::types::Ty| match walk_f_10180 {
            crate::check::types::Ty::TyFn(col_p9, params_pa, res_pb) => if &crate::prelude::len(&params_pa) != &crate::prelude::len(&args_p4x) {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st0_p7, &Text::lit("mismatch"), &span_p5x, &Text::from(format!("`{}` takes {} argument{}; here it has {}", &fname_p2x, &crate::check::errors::count_word_f(&crate::prelude::len(&params_pa)), &(if &crate::prelude::len(&params_pa) == &Nat::from(1u32) {
                    Text::lit("")
                } else {
                    Text::lit("s")
                }), &crate::check::errors::count_word_f(&crate::prelude::len(&args_p4x)))))))
            } else {
                prism_rtl::Turn::More(Rc::new(ApplyRule { env_p0: env_p0x.clone(), st_p1: st0_p7.clone(), fname_p2: fname_p2x.clone(), col_p3: col_p9.clone(), params_p4: params_pa.clone(), res_p5: (*res_pb).clone(), args_p6: args_p4x.clone(), span_p7: span_p5x.clone() }))
            },
            crate::check::types::Ty::TyFlex(_) => {
                let (params_ph, st1_pi) = crate::prelude::fold(&args_p4x, &(Array::new(), st0_p7.clone()), &(|(acc_pd, s_pe): &(Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Arg| {
                    let (v_pf, s2_pg) = crate::check::types::fresh_var_f(s_pe, &false, &Text::lit(""));
                    (crate::prelude::push(acc_pd, &v_pf), s2_pg.clone())
                }));
                let (res_pj, st2_pk) = crate::check::types::fresh_var_f(&st1_pi, &false, &Text::lit(""));
                let (col_pl, st2b_pm) = crate::check::types::fresh_col_f(&st2_pk);
                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2b_pm.clone(), fty_p3x.clone(), crate::check::types::Ty::TyFn(col_pl.clone(), params_ph.clone(), Rc::new(res_pj.clone())), span_p5x.clone()), move |unify_f_10842: crate::check::types::St| {
                    let st3_pc = unify_f_10842;
                    prism_rtl::Turn::More(Rc::new(ApplyRule { env_p0: env_p0x.clone(), st_p1: st3_pc.clone(), fname_p2: fname_p2x.clone(), col_p3: col_pl.clone(), params_p4: params_ph.clone(), res_p5: res_pj.clone(), args_p6: args_p4x.clone(), span_p7: span_p5x.clone() }))
                })
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st0_p7.clone())),
            other_pn => if &crate::prelude::len(&args_p4x) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished((other_pn.clone(), st0_p7.clone()))
            } else {
                crate::prelude::call_then(crate::check::types::start_show_ty_f(st0_p7.clone(), other_pn.clone()), move |show_ty_f_11122: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st0_p7, &Text::lit("mismatch"), &span_p5x, &Text::from(format!("`{}` is a `{}`, not a function", &fname_p2x, &show_ty_f_11122))))))
            },
        })
    }
}

/// `Start ApplyFn, x`: what the function value is when passed to `@Run`.
pub fn start_apply_fn_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fname_p2: Text, fty_p3: crate::check::types::Ty, args_p4: Array<crate::syntax::Arg>, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(ApplyFn { env_p0, st_p1, fname_p2, fty_p3, args_p4, span_p5 })
}

/// ```prism
/// Broken: fn Peeled, Bool -> Peeled
/// ```
pub fn broken_f(p_p0: &Peeled, b_p1: &bool) -> Peeled {
    if !*b_p1 {
        p_p0.clone()
    } else {
        {
            let mut this: Peeled = p_p0.clone();
            this.broken_p = true;
            this
        }
    }
}

/// ```prism
/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn apply_rule_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fname_p2: &Text, col_p3: &crate::check::types::Col, params_p4: &Array<crate::check::types::Ty>, res_p5: &crate::check::types::Ty, args_p6: &Array<crate::syntax::Arg>, span_p7: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let n_p8 = crate::prelude::len(args_p6);
    let cmp_p9 = crate::check::expr::is_comparison_f(fname_p2);
    let (arg_tys_p12, st1_p13) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (Array::new(), st_p1.clone()), {
        let args_p6x = args_p6.clone();
        let span_p7x = span_p7.clone();
        let env_p0x = env_p0.clone();
        let params_p4x = params_p4.clone();
        let fname_p2x = fname_p2.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
            let args_p6xy = args_p6x.clone();
            let span_p7xy = span_p7x.clone();
            let env_p0xy = env_p0x.clone();
            let params_p4xy = params_p4x.clone();
            let fname_p2xy = fname_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_po, s_pp) = p0;
                let i_pq = p1;
                {
                    let a_pr = crate::prelude::or(&crate::prelude::index(&args_p6xy, &i_pq), &crate::syntax::Arg { name_o: None, value_p: crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xy.clone() }, span_p: span_p7xy.clone() });
                    if crate::check::expr::is_lambda_f(&a_pr.value_p) {
                        prism_rtl::Turn::Finished((crate::prelude::push(&acc_po, &crate::check::types::Ty::TyErr), s_pp.clone()))
                    } else {
                        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0xy.clone(), s_pp.clone(), a_pr.value_p.clone()), move |infer_f_12583: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_ps, s2_pt) = infer_f_12583;
                            crate::prelude::call_then(crate::check::types::recording::start_walk_f(s2_pt.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xy, &i_pq), &crate::check::types::Ty::TyErr)), move |walk_f_12626: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::recording::start_walk_f(s2_pt.clone(), t_ps.clone()), move |walk_f_12660: crate::check::types::Ty| match (walk_f_12626, walk_f_12660) {
                                (crate::check::types::Ty::TyFn(pc_pu, _, _), crate::check::types::Ty::TyFn(ac_pv, aps_p10, ar_p11)) => crate::prelude::call_then(crate::check::types::colors::start_add_leq_f(s2_pt.clone(), ac_pv.clone(), pc_pu.clone(), a_pr.value_p.span_p.clone(), Text::lit("arg"), fname_p2xy.clone(), Text::lit("")), move |add_leq_f_12777: crate::check::types::St| prism_rtl::Turn::Finished((crate::prelude::push(&acc_po, &crate::check::types::Ty::TyFn(pc_pu.clone(), aps_p10.clone(), Rc::new((*ar_p11).clone()))), add_leq_f_12777))),
                                _ => prism_rtl::Turn::Finished((crate::prelude::push(&acc_po, &t_ps), s2_pt.clone())),
                            }))
                        })
                    }
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }));
    let (st2_p1b, whole_p1c) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (st1_p13.clone(), Array::new()), {
        let args_p6x = args_p6.clone();
        let span_p7x = span_p7.clone();
        let arg_tys_p12x = arg_tys_p12.clone();
        let params_p4x = params_p4.clone();
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        let res_p5x = res_p5.clone();
        Rc::new(move |(p0, p1): ((crate::check::types::St, Array<Nat>), Nat)| {
            let args_p6xy = args_p6x.clone();
            let span_p7xy = span_p7x.clone();
            let arg_tys_p12xy = arg_tys_p12x.clone();
            let params_p4xy = params_p4x.clone();
            let env_p0xy = env_p0x.clone();
            let fname_p2xy = fname_p2x.clone();
            let res_p5xy = res_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (s_p14, done_p15) = p0;
                let i_p16 = p1;
                {
                    let a_p17 = crate::prelude::or(&crate::prelude::index(&args_p6xy, &i_p16), &crate::syntax::Arg { name_o: None, value_p: crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xy.clone() }, span_p: span_p7xy.clone() });
                    let at_p18 = crate::prelude::or(&crate::prelude::index(&arg_tys_p12xy, &i_p16), &crate::check::types::Ty::TyErr);
                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p14.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xy, &i_p16), &crate::check::types::Ty::TyErr)), move |walk_f_13099: crate::check::types::Ty| {
                        let pnow_p19 = walk_f_13099;
                        crate::prelude::call_then(crate::check::types::start_head_sigil_f(s_p14.clone(), pnow_p19.clone()), move |head_sigil_f_13166: Text| {
                            let whole_now_p1a = crate::check::expr::is_time_sigil_f(&head_sigil_f_13166) || (&crate::check::types::head_sigil_f(&s_p14, &pnow_p19) == &Text::lit("@"));
                            if crate::check::expr::is_lambda_f(&a_p17.value_p) {
                                prism_rtl::Turn::Finished((s_p14.clone(), done_p15.clone()))
                            } else {
                                if whole_now_p1a && (&crate::check::types::stack_of_f(&s_p14, &at_p18) != &Text::lit("")) {
                                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(s_p14.clone(), pnow_p19.clone(), at_p18.clone(), a_p17.value_p.span_p.clone()), move |unify_f_13313: crate::check::types::St| prism_rtl::Turn::Finished((unify_f_13313, crate::prelude::push(&done_p15, &i_p16))))
                                } else {
                                    crate::prelude::call_then(crate::check::types::start_stack_of_f(s_p14.clone(), at_p18.clone()), move |stack_of_f_13382: Text| if (&stack_of_f_13382 != &Text::lit("")) || crate::check::types::is_free_headed_f(&s_p14, &at_p18) {
                                        prism_rtl::Turn::Finished((s_p14.clone(), done_p15.clone()))
                                    } else {
                                        crate::prelude::call_then(start_arg_or_unpack_f(env_p0xy.clone(), s_p14.clone(), fname_p2xy.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xy, &i_p16), &crate::check::types::Ty::TyErr), pnow_p19.clone(), at_p18.clone(), a_p17.clone(), res_p5xy.clone(), span_p7xy.clone()), move |arg_or_unpack_f_13457: crate::check::types::St| prism_rtl::Turn::Finished((arg_or_unpack_f_13457, done_p15.clone())))
                                    })
                                }
                            }
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(((crate::check::types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, Array<Nat>)>>>
    }));
    let (_, st3_p1p) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (Map::new(), st2_p1b.clone()), {
        let args_p6x = args_p6.clone();
        let span_p7x = span_p7.clone();
        let params_p4x = params_p4.clone();
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        Rc::new(move |(p0, p1): ((Map<(), ()>, crate::check::types::St), Nat)| {
            let args_p6xy = args_p6x.clone();
            let span_p7xy = span_p7x.clone();
            let params_p4xy = params_p4x.clone();
            let env_p0xy = env_p0x.clone();
            let fname_p2xy = fname_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (m_p1d, s_p1e) = p0;
                let i_p1f = p1;
                {
                    let a_p1g = crate::prelude::or(&crate::prelude::index(&args_p6xy, &i_p1f), &crate::syntax::Arg { name_o: None, value_p: crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xy.clone() }, span_p: span_p7xy.clone() });
                    if crate::check::expr::is_lambda_f(&a_p1g.value_p) {
                        crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p1e.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xy, &i_p1f), &crate::check::types::Ty::TyErr)), move |walk_f_13748: crate::check::types::Ty| {
                            let p_p1h = walk_f_13748;
                            crate::prelude::call_then(start_infer_lambda_f(env_p0xy.clone(), s_p1e.clone(), a_p1g.value_p.clone(), Some(p_p1h.clone())), move |infer_lambda_f_13807: (crate::check::types::Ty, crate::check::types::St)| {
                                let (lt_p1j, s2_p1k) = infer_lambda_f_13807;
                                let s3_p1i = match (p_p1h.clone(), lt_p1j.clone()) {
                                    (crate::check::types::Ty::TyFn(pc_p1l, _, _), crate::check::types::Ty::TyFn(lc_p1m, lps_p1n, lr_p1o)) => crate::check::types::colors::add_leq_f(&crate::check::types::unify::unify_f(&crate::check::types::recording::note_ty_f(&s2_p1k, &a_p1g.value_p.span_p, &lt_p1j), &p_p1h, &crate::check::types::Ty::TyFn(pc_p1l.clone(), lps_p1n, Rc::new((*lr_p1o).clone())), &a_p1g.value_p.span_p), &lc_p1m, &pc_p1l, &a_p1g.value_p.span_p, &Text::lit("arg"), &fname_p2xy, &Text::lit("")),
                                    _ => crate::check::types::unify::unify_f(&crate::check::types::recording::note_ty_f(&s2_p1k, &a_p1g.value_p.span_p, &lt_p1j), &p_p1h, &lt_p1j, &a_p1g.value_p.span_p),
                                };
                                prism_rtl::Turn::Finished((m_p1d.clone(), s3_p1i.clone()))
                            })
                        })
                    } else {
                        prism_rtl::Turn::Finished((m_p1d.clone(), s_p1e.clone()))
                    }
                }
            }))
        }) as Rc<dyn Fn(((Map<(), ()>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Map<(), ()>, crate::check::types::St)>>>
    }));
    let (pl_p25, st4_p26) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (Peeled { events_p: Array::new(), dyns_p: Array::new(), opts_p: Array::new(), opt_args_p: Array::new(), lifted_p: Text::lit(""), broken_p: false }, st3_p1p.clone()), {
        let args_p6x = args_p6.clone();
        let span_p7x = span_p7.clone();
        let arg_tys_p12x = arg_tys_p12.clone();
        let whole_p1cx = whole_p1c.clone();
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        let cmp_p9x = cmp_p9;
        let params_p4x = params_p4.clone();
        Rc::new(move |(p0, p1): ((Peeled, crate::check::types::St), Nat)| {
            let args_p6xy = args_p6x.clone();
            let span_p7xy = span_p7x.clone();
            let arg_tys_p12xy = arg_tys_p12x.clone();
            let whole_p1cxy = whole_p1cx.clone();
            let env_p0xy = env_p0x.clone();
            let fname_p2xy = fname_p2x.clone();
            let cmp_p9xy = cmp_p9x;
            let params_p4xy = params_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p1q, s_p1r) = p0;
                let i_p1s = p1;
                {
                    let a_p1t = crate::prelude::or(&crate::prelude::index(&args_p6xy, &i_p1s), &crate::syntax::Arg { name_o: None, value_p: crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xy.clone() }, span_p: span_p7xy.clone() });
                    let at_p1u = crate::prelude::or(&crate::prelude::index(&arg_tys_p12xy, &i_p1s), &crate::check::types::Ty::TyErr);
                    if (crate::check::expr::is_lambda_f(&a_p1t.value_p) || crate::check::types::has_nat_f(&whole_p1cxy, &i_p1s)) || ((&crate::check::types::stack_of_f(&s_p1r, &at_p1u) == &Text::lit("")) && !crate::check::types::is_free_headed_f(&s_p1r, &at_p1u)) {
                        prism_rtl::Turn::Finished((acc_p1q.clone(), s_p1r.clone()))
                    } else {
                        {
                            let before_p1v = crate::prelude::len(&s_p1r.diags_p);
                            crate::prelude::call_then(start_layered_arg_f(env_p0xy.clone(), s_p1r.clone(), acc_p1q.clone(), fname_p2xy.clone(), cmp_p9xy, crate::prelude::or(&crate::prelude::index(&params_p4xy, &i_p1s), &crate::check::types::Ty::TyErr), at_p1u.clone(), a_p1t.clone()), move |layered_arg_f_14672: (Peeled, crate::check::types::St)| {
                                let (acc2_p21, s2_p22) = layered_arg_f_14672;
                                let broke_p20 = (&crate::prelude::len(&s2_p22.diags_p) > &before_p1v) && crate::prelude::fold(&crate::prelude::drop(&s2_p22.diags_p, &before_p1v), &false, &(|seen_p23: &bool, d_p24: &crate::check::errors::CDiag| *seen_p23 || crate::check::types::has_text_f(&Array::from(vec![Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")]), &d_p24.code_p)));
                                prism_rtl::Turn::Finished((broken_f(&acc2_p21, &broke_p20), s2_p22.clone()))
                            })
                        }
                    }
                }
            }))
        }) as Rc<dyn Fn(((Peeled, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check::types::St)>>>
    }));
    let st5_pa = if &crate::prelude::len(&pl_p25.events_p) > &Nat::from(1u32) {
        crate::check::types::recording::err_fix_f(&st4_p26, &Text::lit("two-events"), &crate::prelude::or(&crate::prelude::index(&pl_p25.events_p, &Nat::from(1u32)), span_p7), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
    } else {
        st4_p26.clone()
    };
    let st6_pb = if &crate::prelude::len(&pl_p25.opts_p) > &Nat::from(1u32) {
        crate::check::types::recording::err_f(&st5_pa, &Text::lit("optional-and-fault"), span_p7, &Text::lit("`?` and `~` in one operation"))
    } else {
        st5_pa.clone()
    };
    let layer_pc = if &crate::prelude::len(&pl_p25.events_p) > &Nat::from(0u32) {
        Text::lit("!")
    } else {
        if &crate::prelude::len(&pl_p25.dyns_p) > &Nat::from(0u32) {
            Text::lit("$")
        } else {
            Text::lit("")
        }
    };
    let with_opt_pd = match crate::prelude::index(&pl_p25.opts_p, &Nat::from(0u32)) {
        Some(o_p27) => crate::check::types::Ty::TySig(o_p27, Rc::new(res_p5.clone())),
        None => res_p5.clone(),
    };
    let result_pe = if pl_p25.broken_p {
        crate::check::types::Ty::TyErr
    } else {
        if &layer_pc == &Text::lit("") {
            with_opt_pd.clone()
        } else {
            crate::check::types::Ty::TySig(layer_pc.clone(), Rc::new(with_opt_pd.clone()))
        }
    };
    let call_col_pf = crate::check::types::colors::walk_col_f(&st6_pb, col_p3);
    let st7_pg = if (&layer_pc != &Text::lit("")) && crate::check::types::colors::is_flex_col_f(&call_col_pf) {
        crate::check::types::colors::add_leq_f(&st6_pb, &call_col_pf, &crate::check::types::Col::CBound, span_p7, &Text::lit("lifted"), fname_p2, &pl_p25.lifted_p)
    } else {
        st6_pb.clone()
    };
    let lifted_bad_ph = ((&layer_pc != &Text::lit("")) && (&call_col_pf != &crate::check::types::Col::CBound)) && !crate::check::types::colors::is_flex_col_f(&call_col_pf);
    let st8_pi = if lifted_bad_ph {
        crate::check::types::recording::err_fix_f(&st7_pg, &Text::lit("lifted-unbounded"), span_p7, &Text::from(format!("{} `{}` lifted over `{}`; use `@Run`", &crate::check::types::colors::col_word_f(&call_col_pf), fname_p2, &pl_p25.lifted_p)), &Text::from(format!("run it through `!done <- @Run {}, ...`", fname_p2)))
    } else {
        st7_pg.clone()
    };
    let st9_pj = crate::check::types::colors::use_color_f(&st8_pi, &call_col_pf, fname_p2, span_p7);
    let kind_pk = if (&layer_pc == &Text::lit("!")) && (&crate::prelude::len(&pl_p25.dyns_p) > &Nat::from(0u32)) {
        Text::lit("sample")
    } else {
        if &layer_pc != &Text::lit("") {
            Text::lit("map")
        } else {
            if fname_p2 == &Text::lit("$") { Text::lit("const") } else { Text::lit("plain") }
        }
    };
    let peeled_pl = crate::prelude::append(&pl_p25.events_p, &pl_p25.dyns_p);
    let lifted_pm = crate::prelude::filter(&crate::check::errors::range0_f(&n_p8), &(|i_p28: &Nat| has_range_f(&peeled_pl, &crate::prelude::or(&crate::prelude::index(args_p6, i_p28), &crate::syntax::Arg { name_o: None, value_p: crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7.clone() }, span_p: span_p7.clone() }).value_p.span_p)));
    let st10_pn = if pl_p25.broken_p || (&crate::prelude::len(&pl_p25.opts_p) != &Nat::from(1u32)) {
        st9_pj.clone()
    } else {
        crate::check::types::recording::note_lift_f(&st9_pj, span_p7, &crate::prelude::or(&crate::prelude::index(&pl_p25.opts_p, &Nat::from(0u32)), &Text::lit("")), &pl_p25.opt_args_p)
    };
    (result_pe.clone(), crate::check::types::recording::note_app_f(&st10_pn, span_p7, fname_p2, &kind_pk, &layer_pc, &lifted_pm, &crate::prelude::or(&crate::prelude::index(&pl_p25.opts_p, &Nat::from(0u32)), &Text::lit("")), &call_col_pf))
}

/// The step machine of `ApplyRule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct ApplyRule {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fname_p2: Text,
    pub col_p3: crate::check::types::Col,
    pub params_p4: Array<crate::check::types::Ty>,
    pub res_p5: crate::check::types::Ty,
    pub args_p6: Array<crate::syntax::Arg>,
    pub span_p7: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ApplyRule {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fname_p2 = &self.fname_p2;
        let col_p3 = &self.col_p3;
        let params_p4 = &self.params_p4;
        let res_p5 = &self.res_p5;
        let args_p6 = &self.args_p6;
        let span_p7 = &self.span_p7;
        let n_p8 = crate::prelude::len(args_p6);
        let cmp_p9 = crate::check::expr::is_comparison_f(fname_p2);
        let args_p6x = args_p6.clone();
        let col_p3x = col_p3.clone();
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        let params_p4x = params_p4.clone();
        let res_p5x = res_p5.clone();
        let span_p7x = span_p7.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (Array::new(), st_p1x.clone()), {
            let args_p6xx = args_p6x.clone();
            let span_p7xx = span_p7x.clone();
            let env_p0xx = env_p0x.clone();
            let params_p4xx = params_p4x.clone();
            let fname_p2xx = fname_p2x.clone();
            Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
                let args_p6xxy = args_p6xx.clone();
                let span_p7xxy = span_p7xx.clone();
                let env_p0xxy = env_p0xx.clone();
                let params_p4xxy = params_p4xx.clone();
                let fname_p2xxy = fname_p2xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_po, s_pp) = p0;
                    let i_pq = p1;
                    {
                        let a_pr = crate::prelude::or(&crate::prelude::index(&args_p6xxy, &i_pq), &crate::syntax::Arg { name_o: None, value_p: crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xxy.clone() }, span_p: span_p7xxy.clone() });
                        if crate::check::expr::is_lambda_f(&a_pr.value_p) {
                            prism_rtl::Turn::Finished((crate::prelude::push(&acc_po, &crate::check::types::Ty::TyErr), s_pp.clone()))
                        } else {
                            crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0xxy.clone(), s_pp.clone(), a_pr.value_p.clone()), move |infer_f_12583: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t_ps, s2_pt) = infer_f_12583;
                                crate::prelude::call_then(crate::check::types::recording::start_walk_f(s2_pt.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xxy, &i_pq), &crate::check::types::Ty::TyErr)), move |walk_f_12626: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::recording::start_walk_f(s2_pt.clone(), t_ps.clone()), move |walk_f_12660: crate::check::types::Ty| match (walk_f_12626, walk_f_12660) {
                                    (crate::check::types::Ty::TyFn(pc_pu, _, _), crate::check::types::Ty::TyFn(ac_pv, aps_p10, ar_p11)) => crate::prelude::call_then(crate::check::types::colors::start_add_leq_f(s2_pt.clone(), ac_pv.clone(), pc_pu.clone(), a_pr.value_p.span_p.clone(), Text::lit("arg"), fname_p2xxy.clone(), Text::lit("")), move |add_leq_f_12777: crate::check::types::St| prism_rtl::Turn::Finished((crate::prelude::push(&acc_po, &crate::check::types::Ty::TyFn(pc_pu.clone(), aps_p10.clone(), Rc::new((*ar_p11).clone()))), add_leq_f_12777))),
                                    _ => prism_rtl::Turn::Finished((crate::prelude::push(&acc_po, &t_ps), s2_pt.clone())),
                                }))
                            })
                        }
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }), move |fold_12350: (Array<crate::check::types::Ty>, crate::check::types::St)| {
            let (arg_tys_p12, st1_p13) = fold_12350;
            crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (st1_p13.clone(), Array::new()), {
                let args_p6xx = args_p6x.clone();
                let span_p7xx = span_p7x.clone();
                let arg_tys_p12x = arg_tys_p12.clone();
                let params_p4xx = params_p4x.clone();
                let env_p0xx = env_p0x.clone();
                let fname_p2xx = fname_p2x.clone();
                let res_p5xx = res_p5x.clone();
                Rc::new(move |(p0, p1): ((crate::check::types::St, Array<Nat>), Nat)| {
                    let args_p6xxy = args_p6xx.clone();
                    let span_p7xxy = span_p7xx.clone();
                    let arg_tys_p12xy = arg_tys_p12x.clone();
                    let params_p4xxy = params_p4xx.clone();
                    let env_p0xxy = env_p0xx.clone();
                    let fname_p2xxy = fname_p2xx.clone();
                    let res_p5xxy = res_p5xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (s_p14, done_p15) = p0;
                        let i_p16 = p1;
                        {
                            let a_p17 = crate::prelude::or(&crate::prelude::index(&args_p6xxy, &i_p16), &crate::syntax::Arg { name_o: None, value_p: crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xxy.clone() }, span_p: span_p7xxy.clone() });
                            let at_p18 = crate::prelude::or(&crate::prelude::index(&arg_tys_p12xy, &i_p16), &crate::check::types::Ty::TyErr);
                            crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p14.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xxy, &i_p16), &crate::check::types::Ty::TyErr)), move |walk_f_13099: crate::check::types::Ty| {
                                let pnow_p19 = walk_f_13099;
                                crate::prelude::call_then(crate::check::types::start_head_sigil_f(s_p14.clone(), pnow_p19.clone()), move |head_sigil_f_13166: Text| {
                                    let whole_now_p1a = crate::check::expr::is_time_sigil_f(&head_sigil_f_13166) || (&crate::check::types::head_sigil_f(&s_p14, &pnow_p19) == &Text::lit("@"));
                                    if crate::check::expr::is_lambda_f(&a_p17.value_p) {
                                        prism_rtl::Turn::Finished((s_p14.clone(), done_p15.clone()))
                                    } else {
                                        if whole_now_p1a && (&crate::check::types::stack_of_f(&s_p14, &at_p18) != &Text::lit("")) {
                                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(s_p14.clone(), pnow_p19.clone(), at_p18.clone(), a_p17.value_p.span_p.clone()), move |unify_f_13313: crate::check::types::St| prism_rtl::Turn::Finished((unify_f_13313, crate::prelude::push(&done_p15, &i_p16))))
                                        } else {
                                            crate::prelude::call_then(crate::check::types::start_stack_of_f(s_p14.clone(), at_p18.clone()), move |stack_of_f_13382: Text| if (&stack_of_f_13382 != &Text::lit("")) || crate::check::types::is_free_headed_f(&s_p14, &at_p18) {
                                                prism_rtl::Turn::Finished((s_p14.clone(), done_p15.clone()))
                                            } else {
                                                crate::prelude::call_then(start_arg_or_unpack_f(env_p0xxy.clone(), s_p14.clone(), fname_p2xxy.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xxy, &i_p16), &crate::check::types::Ty::TyErr), pnow_p19.clone(), at_p18.clone(), a_p17.clone(), res_p5xxy.clone(), span_p7xxy.clone()), move |arg_or_unpack_f_13457: crate::check::types::St| prism_rtl::Turn::Finished((arg_or_unpack_f_13457, done_p15.clone())))
                                            })
                                        }
                                    }
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(((crate::check::types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, Array<Nat>)>>>
            }), move |fold_12904: (crate::check::types::St, Array<Nat>)| {
                let (st2_p1b, whole_p1c) = fold_12904;
                crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (Map::new(), st2_p1b.clone()), {
                    let args_p6xx = args_p6x.clone();
                    let span_p7xx = span_p7x.clone();
                    let params_p4xx = params_p4x.clone();
                    let env_p0xx = env_p0x.clone();
                    let fname_p2xx = fname_p2x.clone();
                    Rc::new(move |(p0, p1): ((Map<(), ()>, crate::check::types::St), Nat)| {
                        let args_p6xxy = args_p6xx.clone();
                        let span_p7xxy = span_p7xx.clone();
                        let params_p4xxy = params_p4xx.clone();
                        let env_p0xxy = env_p0xx.clone();
                        let fname_p2xxy = fname_p2xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (m_p1d, s_p1e) = p0;
                            let i_p1f = p1;
                            {
                                let a_p1g = crate::prelude::or(&crate::prelude::index(&args_p6xxy, &i_p1f), &crate::syntax::Arg { name_o: None, value_p: crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xxy.clone() }, span_p: span_p7xxy.clone() });
                                if crate::check::expr::is_lambda_f(&a_p1g.value_p) {
                                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p1e.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xxy, &i_p1f), &crate::check::types::Ty::TyErr)), move |walk_f_13748: crate::check::types::Ty| {
                                        let p_p1h = walk_f_13748;
                                        crate::prelude::call_then(start_infer_lambda_f(env_p0xxy.clone(), s_p1e.clone(), a_p1g.value_p.clone(), Some(p_p1h.clone())), move |infer_lambda_f_13807: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (lt_p1j, s2_p1k) = infer_lambda_f_13807;
                                            let s3_p1i = match (p_p1h.clone(), lt_p1j.clone()) {
                                                (crate::check::types::Ty::TyFn(pc_p1l, _, _), crate::check::types::Ty::TyFn(lc_p1m, lps_p1n, lr_p1o)) => crate::check::types::colors::add_leq_f(&crate::check::types::unify::unify_f(&crate::check::types::recording::note_ty_f(&s2_p1k, &a_p1g.value_p.span_p, &lt_p1j), &p_p1h, &crate::check::types::Ty::TyFn(pc_p1l.clone(), lps_p1n, Rc::new((*lr_p1o).clone())), &a_p1g.value_p.span_p), &lc_p1m, &pc_p1l, &a_p1g.value_p.span_p, &Text::lit("arg"), &fname_p2xxy, &Text::lit("")),
                                                _ => crate::check::types::unify::unify_f(&crate::check::types::recording::note_ty_f(&s2_p1k, &a_p1g.value_p.span_p, &lt_p1j), &p_p1h, &lt_p1j, &a_p1g.value_p.span_p),
                                            };
                                            prism_rtl::Turn::Finished((m_p1d.clone(), s3_p1i.clone()))
                                        })
                                    })
                                } else {
                                    prism_rtl::Turn::Finished((m_p1d.clone(), s_p1e.clone()))
                                }
                            }
                        }))
                    }) as Rc<dyn Fn(((Map<(), ()>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Map<(), ()>, crate::check::types::St)>>>
                }), move |fold_13565: (Map<(), ()>, crate::check::types::St)| {
                    let (_, st3_p1p) = fold_13565;
                    crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (Peeled { events_p: Array::new(), dyns_p: Array::new(), opts_p: Array::new(), opt_args_p: Array::new(), lifted_p: Text::lit(""), broken_p: false }, st3_p1p.clone()), {
                        let args_p6xx = args_p6x.clone();
                        let span_p7xx = span_p7x.clone();
                        let arg_tys_p12x = arg_tys_p12.clone();
                        let whole_p1cx = whole_p1c.clone();
                        let env_p0xx = env_p0x.clone();
                        let fname_p2xx = fname_p2x.clone();
                        let cmp_p9x = cmp_p9;
                        let params_p4xx = params_p4x.clone();
                        Rc::new(move |(p0, p1): ((Peeled, crate::check::types::St), Nat)| {
                            let args_p6xxy = args_p6xx.clone();
                            let span_p7xxy = span_p7xx.clone();
                            let arg_tys_p12xy = arg_tys_p12x.clone();
                            let whole_p1cxy = whole_p1cx.clone();
                            let env_p0xxy = env_p0xx.clone();
                            let fname_p2xxy = fname_p2xx.clone();
                            let cmp_p9xy = cmp_p9x;
                            let params_p4xxy = params_p4xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (acc_p1q, s_p1r) = p0;
                                let i_p1s = p1;
                                {
                                    let a_p1t = crate::prelude::or(&crate::prelude::index(&args_p6xxy, &i_p1s), &crate::syntax::Arg { name_o: None, value_p: crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xxy.clone() }, span_p: span_p7xxy.clone() });
                                    let at_p1u = crate::prelude::or(&crate::prelude::index(&arg_tys_p12xy, &i_p1s), &crate::check::types::Ty::TyErr);
                                    if (crate::check::expr::is_lambda_f(&a_p1t.value_p) || crate::check::types::has_nat_f(&whole_p1cxy, &i_p1s)) || ((&crate::check::types::stack_of_f(&s_p1r, &at_p1u) == &Text::lit("")) && !crate::check::types::is_free_headed_f(&s_p1r, &at_p1u)) {
                                        prism_rtl::Turn::Finished((acc_p1q.clone(), s_p1r.clone()))
                                    } else {
                                        {
                                            let before_p1v = crate::prelude::len(&s_p1r.diags_p);
                                            crate::prelude::call_then(start_layered_arg_f(env_p0xxy.clone(), s_p1r.clone(), acc_p1q.clone(), fname_p2xxy.clone(), cmp_p9xy, crate::prelude::or(&crate::prelude::index(&params_p4xxy, &i_p1s), &crate::check::types::Ty::TyErr), at_p1u.clone(), a_p1t.clone()), move |layered_arg_f_14672: (Peeled, crate::check::types::St)| {
                                                let (acc2_p21, s2_p22) = layered_arg_f_14672;
                                                let broke_p20 = (&crate::prelude::len(&s2_p22.diags_p) > &before_p1v) && crate::prelude::fold(&crate::prelude::drop(&s2_p22.diags_p, &before_p1v), &false, &(|seen_p23: &bool, d_p24: &crate::check::errors::CDiag| *seen_p23 || crate::check::types::has_text_f(&Array::from(vec![Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")]), &d_p24.code_p)));
                                                prism_rtl::Turn::Finished((broken_f(&acc2_p21, &broke_p20), s2_p22.clone()))
                                            })
                                        }
                                    }
                                }
                            }))
                        }) as Rc<dyn Fn(((Peeled, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check::types::St)>>>
                    }), move |fold_14220: (Peeled, crate::check::types::St)| {
                        let (pl_p25, st4_p26) = fold_14220;
                        let st5_pa = if &crate::prelude::len(&pl_p25.events_p) > &Nat::from(1u32) {
                            crate::check::types::recording::err_fix_f(&st4_p26, &Text::lit("two-events"), &crate::prelude::or(&crate::prelude::index(&pl_p25.events_p, &Nat::from(1u32)), &span_p7x), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
                        } else {
                            st4_p26.clone()
                        };
                        let st6_pb = if &crate::prelude::len(&pl_p25.opts_p) > &Nat::from(1u32) {
                            crate::check::types::recording::err_f(&st5_pa, &Text::lit("optional-and-fault"), &span_p7x, &Text::lit("`?` and `~` in one operation"))
                        } else {
                            st5_pa.clone()
                        };
                        let layer_pc = if &crate::prelude::len(&pl_p25.events_p) > &Nat::from(0u32) {
                            Text::lit("!")
                        } else {
                            if &crate::prelude::len(&pl_p25.dyns_p) > &Nat::from(0u32) {
                                Text::lit("$")
                            } else {
                                Text::lit("")
                            }
                        };
                        let with_opt_pd = match crate::prelude::index(&pl_p25.opts_p, &Nat::from(0u32)) {
                            Some(o_p27) => crate::check::types::Ty::TySig(o_p27, Rc::new(res_p5x.clone())),
                            None => res_p5x.clone(),
                        };
                        let result_pe = if pl_p25.broken_p {
                            crate::check::types::Ty::TyErr
                        } else {
                            if &layer_pc == &Text::lit("") {
                                with_opt_pd.clone()
                            } else {
                                crate::check::types::Ty::TySig(layer_pc.clone(), Rc::new(with_opt_pd.clone()))
                            }
                        };
                        crate::prelude::call_then(crate::check::types::colors::start_walk_col_f(st6_pb.clone(), col_p3x.clone()), move |walk_col_f_15720: crate::check::types::Col| {
                            let call_col_pf = walk_col_f_15720;
                            let st7_pg = if (&layer_pc != &Text::lit("")) && crate::check::types::colors::is_flex_col_f(&call_col_pf) {
                                crate::check::types::colors::add_leq_f(&st6_pb, &call_col_pf, &crate::check::types::Col::CBound, &span_p7x, &Text::lit("lifted"), &fname_p2x, &pl_p25.lifted_p)
                            } else {
                                st6_pb.clone()
                            };
                            let lifted_bad_ph = ((&layer_pc != &Text::lit("")) && (&call_col_pf != &crate::check::types::Col::CBound)) && !crate::check::types::colors::is_flex_col_f(&call_col_pf);
                            let st8_pi = if lifted_bad_ph {
                                crate::check::types::recording::err_fix_f(&st7_pg, &Text::lit("lifted-unbounded"), &span_p7x, &Text::from(format!("{} `{}` lifted over `{}`; use `@Run`", &crate::check::types::colors::col_word_f(&call_col_pf), &fname_p2x, &pl_p25.lifted_p)), &Text::from(format!("run it through `!done <- @Run {}, ...`", &fname_p2x)))
                            } else {
                                st7_pg.clone()
                            };
                            crate::prelude::call_then(crate::check::types::colors::start_use_color_f(st8_pi.clone(), call_col_pf.clone(), fname_p2x.clone(), span_p7x.clone()), move |use_color_f_16150: crate::check::types::St| {
                                let st9_pj = use_color_f_16150;
                                let kind_pk = if (&layer_pc == &Text::lit("!")) && (&crate::prelude::len(&pl_p25.dyns_p) > &Nat::from(0u32)) {
                                    Text::lit("sample")
                                } else {
                                    if &layer_pc != &Text::lit("") {
                                        Text::lit("map")
                                    } else {
                                        if &fname_p2x == &Text::lit("$") { Text::lit("const") } else { Text::lit("plain") }
                                    }
                                };
                                let peeled_pl = crate::prelude::append(&pl_p25.events_p, &pl_p25.dyns_p);
                                let lifted_pm = crate::prelude::filter(&crate::check::errors::range0_f(&n_p8), &(|i_p28: &Nat| has_range_f(&peeled_pl, &crate::prelude::or(&crate::prelude::index(&args_p6x, i_p28), &crate::syntax::Arg { name_o: None, value_p: crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7x.clone() }, span_p: span_p7x.clone() }).value_p.span_p)));
                                let st10_pn = if pl_p25.broken_p || (&crate::prelude::len(&pl_p25.opts_p) != &Nat::from(1u32)) {
                                    st9_pj.clone()
                                } else {
                                    crate::check::types::recording::note_lift_f(&st9_pj, &span_p7x, &crate::prelude::or(&crate::prelude::index(&pl_p25.opts_p, &Nat::from(0u32)), &Text::lit("")), &pl_p25.opt_args_p)
                                };
                                prism_rtl::Turn::Finished((result_pe.clone(), crate::check::types::recording::note_app_f(&st10_pn, &span_p7x, &fname_p2x, &kind_pk, &layer_pc, &lifted_pm, &crate::prelude::or(&crate::prelude::index(&pl_p25.opts_p, &Nat::from(0u32)), &Text::lit("")), &call_col_pf)))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start ApplyRule, x`: what the function value is when passed to `@Run`.
pub fn start_apply_rule_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fname_p2: Text, col_p3: crate::check::types::Col, params_p4: Array<crate::check::types::Ty>, res_p5: crate::check::types::Ty, args_p6: Array<crate::syntax::Arg>, span_p7: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(ApplyRule { env_p0, st_p1, fname_p2, col_p3, params_p4, res_p5, args_p6, span_p7 })
}

/// ```prism
/// ArgOrUnpack: unbounded fn Env, St, Text, Ty, Ty, Ty, Arg, Ty, Range -> St
/// ```
pub fn arg_or_unpack_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fname_p2: &Text, param_p3: &crate::check::types::Ty, pnow_p4: &crate::check::types::Ty, at_p5: &crate::check::types::Ty, a_p6: &crate::syntax::Arg, res_p7: &crate::check::types::Ty, span_p8: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk_f(st_p1, at_p5) {
        crate::check::types::Ty::TyAny(bounds_p9) => match pnow_p4 {
            crate::check::types::Ty::TyFlex(n_pa) => {
                let hidden_pb = Text::from(format!("e\'{}", &st_p1.next_p));
                let st2_pc = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.next_p = &this.next_p + &Nat::from(1u32);
                    this.any_givens_p = crate::prelude::append(&this.any_givens_p, &crate::prelude::each(&bounds_p9, &(|b_pe: &Text| (hidden_pb.clone(), b_pe.clone()))));
                    this
                };
                let st3_pd = crate::check::types::unify::unify_f(&st2_pc, pnow_p4, &crate::check::types::Ty::TyRigid(hidden_pb.clone()), &a_p6.value_p.span_p);
                if crate::check::types::has_nat_f(&crate::check::types::recording::free_vars_f(st_p1, res_p7), n_pa) {
                    crate::check::types::recording::err_f(&st3_pd, &Text::lit("existential-escape"), span_p8, &Text::from(format!("the type hidden in `{}` would leave it here", &crate::check::types::show_ty_f(st_p1, at_p5))))
                } else {
                    st3_pd.clone()
                }
            },
            crate::check::types::Ty::TyRigid(r_pf) if crate::syntax::lexer::chars::has_prefix_f(r_pf, &Text::lit("e\'")) => crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), &a_p6.value_p.span_p, &Text::from(format!("two existentials meet here, each `{}` hiding a type of its own", &crate::check::types::show_ty_f(st_p1, at_p5)))),
            _ => plain_arg_f(env_p0, st_p1, fname_p2, param_p3, at_p5, a_p6),
            _ => unreachable!("no arm matched"),
        },
        _ => plain_arg_f(env_p0, st_p1, fname_p2, param_p3, at_p5, a_p6),
    }
}

/// The step machine of `ArgOrUnpack`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgOrUnpack: unbounded fn Env, St, Text, Ty, Ty, Ty, Arg, Ty, Range -> St
/// ```
pub struct ArgOrUnpack {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fname_p2: Text,
    pub param_p3: crate::check::types::Ty,
    pub pnow_p4: crate::check::types::Ty,
    pub at_p5: crate::check::types::Ty,
    pub a_p6: crate::syntax::Arg,
    pub res_p7: crate::check::types::Ty,
    pub span_p8: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for ArgOrUnpack {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fname_p2 = &self.fname_p2;
        let param_p3 = &self.param_p3;
        let pnow_p4 = &self.pnow_p4;
        let at_p5 = &self.at_p5;
        let a_p6 = &self.a_p6;
        let res_p7 = &self.res_p7;
        let span_p8 = &self.span_p8;
        let a_p6x = a_p6.clone();
        let at_p5x = at_p5.clone();
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        let param_p3x = param_p3.clone();
        let pnow_p4x = pnow_p4.clone();
        let res_p7x = res_p7.clone();
        let span_p8x = span_p8.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), at_p5x.clone()), move |walk_f_17303: crate::check::types::Ty| match walk_f_17303 {
            crate::check::types::Ty::TyAny(bounds_p9) => match &pnow_p4x {
                crate::check::types::Ty::TyFlex(n_pa) => {
                    let hidden_pb = Text::from(format!("e\'{}", &st_p1x.next_p));
                    let st2_pc = {
                        let mut this: crate::check::types::St = st_p1x.clone();
                        this.next_p = &this.next_p + &Nat::from(1u32);
                        this.any_givens_p = crate::prelude::append(&this.any_givens_p, &crate::prelude::each(&bounds_p9, &(|b_pe: &Text| (hidden_pb.clone(), b_pe.clone()))));
                        this
                    };
                    let n_pax = n_pa.clone();
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pc.clone(), pnow_p4x.clone(), crate::check::types::Ty::TyRigid(hidden_pb.clone()), a_p6x.value_p.span_p.clone()), move |unify_f_17574: crate::check::types::St| {
                        let st3_pd = unify_f_17574;
                        crate::prelude::call_then(crate::check::types::recording::start_free_vars_f(st_p1x.clone(), res_p7x.clone()), move |free_vars_f_17645: Array<Nat>| if crate::check::types::has_nat_f(&free_vars_f_17645, &n_pax) {
                            crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), at_p5x.clone()), move |show_ty_f_17726: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&st3_pd, &Text::lit("existential-escape"), &span_p8x, &Text::from(format!("the type hidden in `{}` would leave it here", &show_ty_f_17726)))))
                        } else {
                            prism_rtl::Turn::Finished(st3_pd.clone())
                        })
                    })
                },
                crate::check::types::Ty::TyRigid(r_pf) if crate::syntax::lexer::chars::has_prefix_f(r_pf, &Text::lit("e\'")) => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), at_p5x.clone()), move |show_ty_f_17895: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&st_p1x, &Text::lit("mismatch"), &a_p6x.value_p.span_p, &Text::from(format!("two existentials meet here, each `{}` hiding a type of its own", &show_ty_f_17895))))),
                _ => prism_rtl::Turn::More(Rc::new(PlainArg { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), fname_p2: fname_p2x.clone(), param_p3: param_p3x.clone(), at_p4: at_p5x.clone(), a_p5: a_p6x.clone() })),
                _ => unreachable!("no arm matched"),
            },
            _ => prism_rtl::Turn::More(Rc::new(PlainArg { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), fname_p2: fname_p2x.clone(), param_p3: param_p3x.clone(), at_p4: at_p5x.clone(), a_p5: a_p6x.clone() })),
        })
    }
}

/// `Start ArgOrUnpack, x`: what the function value is when passed to `@Run`.
pub fn start_arg_or_unpack_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fname_p2: Text, param_p3: crate::check::types::Ty, pnow_p4: crate::check::types::Ty, at_p5: crate::check::types::Ty, a_p6: crate::syntax::Arg, res_p7: crate::check::types::Ty, span_p8: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ArgOrUnpack { env_p0, st_p1, fname_p2, param_p3, pnow_p4, at_p5, a_p6, res_p7, span_p8 })
}

/// ```prism
/// HasRange: fn [Range], Range -> Bool
/// ```
pub fn has_range_f(rs_p0: &Array<crate::syntax::Range>, r_p1: &crate::syntax::Range) -> bool {
    crate::prelude::fold(rs_p0, &false, &(|seen_p2: &bool, x_p3: &crate::syntax::Range| *seen_p2 || (x_p3 == r_p1)))
}

/// ```prism
/// Elab: fn St, Range, Text, Text, Text -> St
/// ```
pub fn elab_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, what_p2: &Text, kind_p3: &Text, layer_p4: &Text) -> crate::check::types::St {
    crate::check::types::recording::note_app_f(st_p0, span_p1, what_p2, kind_p3, layer_p4, &Array::new(), &Text::lit(""), &crate::check::types::Col::CBound)
}

/// ```prism
/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
/// ```
pub fn plain_arg_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fname_p2: &Text, param_p3: &crate::check::types::Ty, at_p4: &crate::check::types::Ty, a_p5: &crate::syntax::Arg) -> crate::check::types::St {
    let p_p6 = crate::check::types::recording::walk_f(st_p1, param_p3);
    let ph_p7 = crate::check::types::head_sigil_f(st_p1, &p_p6);
    if at_p4 == &crate::check::types::Ty::TyErr {
        st_p1.clone()
    } else {
        if crate::check::expr::is_time_sigil_f(&ph_p7) || (&ph_p7 == &Text::lit("@")) {
            {
                let shown_p8 = if crate::check::types::is_flex_var_f(st_p1, at_p4) {
                    crate::check::expr::src_text_f(env_p0, &a_p5.value_p.span_p)
                } else {
                    crate::check::types::show_ty_f(st_p1, at_p4)
                };
                crate::check::types::recording::err_fix_f(st_p1, &Text::lit("plain-for-sigiled"), &a_p5.value_p.span_p, &Text::from(format!("a plain `{}` where `{}` takes a `{}`", &shown_p8, fname_p2, &crate::check::types::show_ty_f(st_p1, &p_p6))), &Text::from(format!("write `{} {}`", &ph_p7, &crate::check::expr::src_text_f(env_p0, &a_p5.value_p.span_p))))
            }
        } else {
            crate::check::types::unify::unify_f(st_p1, &p_p6, at_p4, &a_p5.value_p.span_p)
        }
    }
}

/// The step machine of `PlainArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
/// ```
pub struct PlainArg {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fname_p2: Text,
    pub param_p3: crate::check::types::Ty,
    pub at_p4: crate::check::types::Ty,
    pub a_p5: crate::syntax::Arg,
}

impl prism_rtl::Job<crate::check::types::St> for PlainArg {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fname_p2 = &self.fname_p2;
        let param_p3 = &self.param_p3;
        let at_p4 = &self.at_p4;
        let a_p5 = &self.a_p5;
        let a_p5x = a_p5.clone();
        let at_p4x = at_p4.clone();
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        let param_p3x = param_p3.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), param_p3x.clone()), move |walk_f_18708: crate::check::types::Ty| {
            let p_p6 = walk_f_18708;
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), p_p6.clone()), move |head_sigil_f_18736: Text| {
                let ph_p7 = head_sigil_f_18736;
                if &at_p4x == &crate::check::types::Ty::TyErr {
                    prism_rtl::Turn::Finished(st_p1x.clone())
                } else {
                    if crate::check::expr::is_time_sigil_f(&ph_p7) || (&ph_p7 == &Text::lit("@")) {
                        crate::prelude::call_then(crate::check::types::start_is_flex_var_f(st_p1x.clone(), at_p4x.clone()), move |is_flex_var_f_18842: bool| {
                            let shown_p8 = if is_flex_var_f_18842 {
                                crate::check::expr::src_text_f(&env_p0x, &a_p5x.value_p.span_p)
                            } else {
                                crate::check::types::show_ty_f(&st_p1x, &at_p4x)
                            };
                            crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), p_p6.clone()), move |show_ty_f_19005: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &Text::lit("plain-for-sigiled"), &a_p5x.value_p.span_p, &Text::from(format!("a plain `{}` where `{}` takes a `{}`", &shown_p8, &fname_p2x, &show_ty_f_19005)), &Text::from(format!("write `{} {}`", &ph_p7, &crate::check::expr::src_text_f(&env_p0x, &a_p5x.value_p.span_p))))))
                        })
                    } else {
                        prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st_p1x.clone(), expected_p1: p_p6.clone(), found_p2: at_p4x.clone(), span_p3: a_p5x.value_p.span_p.clone() }))
                    }
                }
            })
        })
    }
}

/// `Start PlainArg, x`: what the function value is when passed to `@Run`.
pub fn start_plain_arg_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fname_p2: Text, param_p3: crate::check::types::Ty, at_p4: crate::check::types::Ty, a_p5: crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(PlainArg { env_p0, st_p1, fname_p2, param_p3, at_p4, a_p5 })
}

/// ```prism
/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub fn layered_arg_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, acc_p2: &Peeled, fname_p3: &Text, cmp_p4: &bool, param_p5: &crate::check::types::Ty, at_p6: &crate::check::types::Ty, a_p7: &crate::syntax::Arg) -> (Peeled, crate::check::types::St) {
    let p_p8 = crate::check::types::recording::walk_f(st_p1, param_p5);
    let span_p9 = a_p7.value_p.span_p.clone();
    let ph_pa = crate::check::types::head_sigil_f(st_p1, &p_p8);
    if crate::check::types::is_free_headed_f(st_p1, at_p6) {
        {
            let st2_pb = if ((crate::check::expr::is_time_sigil_f(&ph_pa) || (&ph_pa == &Text::lit("@"))) || (&ph_pa == &Text::lit("&"))) || *cmp_p4 {
                st_p1.clone()
            } else {
                crate::check::types::unify::ask_layer_f(st_p1, at_p6, &span_p9, fname_p3)
            };
            (acc_p2.clone(), crate::check::types::unify::unify_f(&st2_pb, &p_p8, at_p6, &span_p9))
        }
    } else {
        if (crate::check::expr::is_time_sigil_f(&ph_pa) || (&ph_pa == &Text::lit("@"))) || (&ph_pa == &Text::lit("&")) {
            (acc_p2.clone(), crate::check::types::unify::unify_f(st_p1, &p_p8, at_p6, &span_p9))
        } else {
            if crate::check::expr::is_plain_sigil_f(&ph_pa) {
                peel_time_only_f(env_p0, st_p1, acc_p2, fname_p3, &p_p8, at_p6, a_p7)
            } else {
                {
                    let head_pc = crate::check::types::head_sigil_f(st_p1, at_p6);
                    if &head_pc == &Text::lit("@") {
                        (acc_p2.clone(), crate::check::types::recording::err_fix_f(st_p1, &Text::lit("blueprint-operand"), &span_p9, &Text::from(format!("`{}` over a blueprint; bind it first", fname_p3)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text_f(env_p0, &span_p9)))))
                    } else {
                        if crate::check::expr::is_time_sigil_f(&head_pc) {
                            {
                                let inner_pd = crate::check::expr::inner_of_f(st_p1, at_p6);
                                let ih_pe = crate::check::types::head_sigil_f(st_p1, &inner_pd);
                                let acc2_pf = {
                                    let mut this: Peeled = acc_p2.clone();
                                    if &head_pc == &Text::lit("!") {
                                        this.events_p = crate::prelude::push(&this.events_p, &span_p9);
                                    } else {
                                        this.dyns_p = crate::prelude::push(&this.dyns_p, &span_p9);
                                    }
                                    if &this.lifted_p == &Text::lit("") {
                                        this.lifted_p = crate::check::expr::src_text_f(env_p0, &span_p9);
                                    }
                                    this
                                };
                                if crate::check::expr::is_time_sigil_f(&ih_pe) {
                                    {
                                        let what_pg = if &ih_pe == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") };
                                        (acc2_pf.clone(), crate::check::types::recording::err_fix_f(st_p1, &Text::lit("two-layers"), &span_p9, &Text::from(format!("`{}` over a {} of {}s", fname_p3, &(if &head_pc == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &what_pg)), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))
                                    }
                                } else {
                                    if crate::check::expr::is_plain_sigil_f(&ih_pe) && !*cmp_p4 {
                                        {
                                            let inner2_ph = crate::check::expr::inner_of_f(st_p1, &inner_pd);
                                            if crate::check::expr::is_time_sigil_f(&crate::check::types::head_sigil_f(st_p1, &inner2_ph)) || (&crate::check::types::head_sigil_f(st_p1, &inner2_ph) == &Text::lit("@")) {
                                                (acc2_pf.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("layer-under-optional"), &span_p9, &Text::from(format!("`{}` over an optional {}dynamic", fname_p3, &(if &ih_pe == &Text::lit("?") { Text::lit("") } else { Text::lit("fault ") })))))
                                            } else {
                                                {
                                                    let acc3_pi = {
                                                        let mut this: Peeled = acc2_pf.clone();
                                                        this.opts_p = crate::check::types::add_text_f(&this.opts_p, &ih_pe);
                                                        this.opt_args_p = crate::prelude::push(&this.opt_args_p, &span_p9);
                                                        this
                                                    };
                                                    (acc3_pi.clone(), crate::check::types::unify::unify_f(st_p1, &p_p8, &inner2_ph, &span_p9))
                                                }
                                            }
                                        }
                                    } else {
                                        (acc2_pf.clone(), crate::check::types::unify::unify_f(st_p1, &p_p8, &inner_pd, &span_p9))
                                    }
                                }
                            }
                        } else {
                            if crate::check::expr::is_plain_sigil_f(&head_pc) && !*cmp_p4 {
                                {
                                    let inner_pj = crate::check::expr::inner_of_f(st_p1, at_p6);
                                    let ih_pk = crate::check::types::head_sigil_f(st_p1, &inner_pj);
                                    if crate::check::expr::is_time_sigil_f(&ih_pk) || (&ih_pk == &Text::lit("@")) {
                                        (acc_p2.clone(), crate::check::types::recording::err_fix_f(st_p1, &Text::lit("layer-under-optional"), &span_p9, &Text::from(format!("`{}` over an optional dynamic", fname_p3)), &Text::lit("match the optional once, at build time, to find out whether there is a dynamic")))
                                    } else {
                                        {
                                            let acc2_pl = {
                                                let mut this: Peeled = acc_p2.clone();
                                                this.opts_p = crate::check::types::add_text_f(&this.opts_p, &head_pc);
                                                this.opt_args_p = crate::prelude::push(&this.opt_args_p, &span_p9);
                                                this
                                            };
                                            (acc2_pl.clone(), crate::check::types::unify::unify_f(st_p1, &p_p8, &inner_pj, &span_p9))
                                        }
                                    }
                                }
                            } else {
                                if &head_pc == &Text::lit("&") {
                                    (acc_p2.clone(), crate::check::types::unify::unify_f(st_p1, &p_p8, &crate::check::expr::inner_of_f(st_p1, at_p6), &span_p9))
                                } else {
                                    (acc_p2.clone(), crate::check::types::unify::unify_f(st_p1, &p_p8, at_p6, &span_p9))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `LayeredArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub struct LayeredArg {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub acc_p2: Peeled,
    pub fname_p3: Text,
    pub cmp_p4: bool,
    pub param_p5: crate::check::types::Ty,
    pub at_p6: crate::check::types::Ty,
    pub a_p7: crate::syntax::Arg,
}

impl prism_rtl::Job<(Peeled, crate::check::types::St)> for LayeredArg {
    fn cycle(&self) -> prism_rtl::Turn<(Peeled, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let acc_p2 = &self.acc_p2;
        let fname_p3 = &self.fname_p3;
        let cmp_p4 = &self.cmp_p4;
        let param_p5 = &self.param_p5;
        let at_p6 = &self.at_p6;
        let a_p7 = &self.a_p7;
        let a_p7x = a_p7.clone();
        let acc_p2x = acc_p2.clone();
        let at_p6x = at_p6.clone();
        let cmp_p4x = *cmp_p4;
        let env_p0x = env_p0.clone();
        let fname_p3x = fname_p3.clone();
        let param_p5x = param_p5.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), param_p5x.clone()), move |walk_f_19317: crate::check::types::Ty| {
            let p_p8 = walk_f_19317;
            let span_p9 = a_p7x.value_p.span_p.clone();
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), p_p8.clone()), move |head_sigil_f_19373: Text| {
                let ph_pa = head_sigil_f_19373;
                crate::prelude::call_then(crate::check::types::start_is_free_headed_f(st_p1x.clone(), at_p6x.clone()), move |is_free_headed_f_19396: bool| if is_free_headed_f_19396 {
                    {
                        let st2_pb = if ((crate::check::expr::is_time_sigil_f(&ph_pa) || (&ph_pa == &Text::lit("@"))) || (&ph_pa == &Text::lit("&"))) || cmp_p4x {
                            st_p1x.clone()
                        } else {
                            crate::check::types::unify::ask_layer_f(&st_p1x, &at_p6x, &span_p9, &fname_p3x)
                        };
                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pb.clone(), p_p8.clone(), at_p6x.clone(), span_p9.clone()), move |unify_f_19543: crate::check::types::St| prism_rtl::Turn::Finished((acc_p2x.clone(), unify_f_19543)))
                    }
                } else {
                    if (crate::check::expr::is_time_sigil_f(&ph_pa) || (&ph_pa == &Text::lit("@"))) || (&ph_pa == &Text::lit("&")) {
                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p8.clone(), at_p6x.clone(), span_p9.clone()), move |unify_f_19634: crate::check::types::St| prism_rtl::Turn::Finished((acc_p2x.clone(), unify_f_19634)))
                    } else {
                        if crate::check::expr::is_plain_sigil_f(&ph_pa) {
                            prism_rtl::Turn::More(Rc::new(PeelTimeOnly { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), acc_p2: acc_p2x.clone(), fname_p3: fname_p3x.clone(), p_p4: p_p8.clone(), at_p5: at_p6x.clone(), a_p6: a_p7x.clone() }))
                        } else {
                            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), at_p6x.clone()), move |head_sigil_f_19761: Text| {
                                let head_pc = head_sigil_f_19761;
                                if &head_pc == &Text::lit("@") {
                                    prism_rtl::Turn::Finished((acc_p2x.clone(), crate::check::types::recording::err_fix_f(&st_p1x, &Text::lit("blueprint-operand"), &span_p9, &Text::from(format!("`{}` over a blueprint; bind it first", &fname_p3x)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text_f(&env_p0x, &span_p9))))))
                                } else {
                                    if crate::check::expr::is_time_sigil_f(&head_pc) {
                                        crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x.clone(), at_p6x.clone()), move |inner_of_f_20006: crate::check::types::Ty| {
                                            let inner_pd = inner_of_f_20006;
                                            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), inner_pd.clone()), move |head_sigil_f_20042: Text| {
                                                let ih_pe = head_sigil_f_20042;
                                                let acc2_pf = {
                                                    let mut this: Peeled = acc_p2x.clone();
                                                    if &head_pc == &Text::lit("!") {
                                                        this.events_p = crate::prelude::push(&this.events_p, &span_p9);
                                                    } else {
                                                        this.dyns_p = crate::prelude::push(&this.dyns_p, &span_p9);
                                                    }
                                                    if &this.lifted_p == &Text::lit("") {
                                                        this.lifted_p = crate::check::expr::src_text_f(&env_p0x, &span_p9);
                                                    }
                                                    this
                                                };
                                                if crate::check::expr::is_time_sigil_f(&ih_pe) {
                                                    {
                                                        let what_pg = if &ih_pe == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") };
                                                        prism_rtl::Turn::Finished((acc2_pf.clone(), crate::check::types::recording::err_fix_f(&st_p1x, &Text::lit("two-layers"), &span_p9, &Text::from(format!("`{}` over a {} of {}s", &fname_p3x, &(if &head_pc == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &what_pg)), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))))
                                                    }
                                                } else {
                                                    if crate::check::expr::is_plain_sigil_f(&ih_pe) && !cmp_p4x {
                                                        crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x.clone(), inner_pd.clone()), move |inner_of_f_20718: crate::check::types::Ty| {
                                                            let inner2_ph = inner_of_f_20718;
                                                            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), inner2_ph.clone()), move |head_sigil_f_20769: Text| if crate::check::expr::is_time_sigil_f(&head_sigil_f_20769) || (&crate::check::types::head_sigil_f(&st_p1x, &inner2_ph) == &Text::lit("@")) {
                                                                prism_rtl::Turn::Finished((acc2_pf.clone(), crate::check::types::recording::err_f(&st_p1x, &Text::lit("layer-under-optional"), &span_p9, &Text::from(format!("`{}` over an optional {}dynamic", &fname_p3x, &(if &ih_pe == &Text::lit("?") { Text::lit("") } else { Text::lit("fault ") }))))))
                                                            } else {
                                                                {
                                                                    let acc3_pi = {
                                                                        let mut this: Peeled = acc2_pf.clone();
                                                                        this.opts_p = crate::check::types::add_text_f(&this.opts_p, &ih_pe);
                                                                        this.opt_args_p = crate::prelude::push(&this.opt_args_p, &span_p9);
                                                                        this
                                                                    };
                                                                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p8.clone(), inner2_ph.clone(), span_p9.clone()), move |unify_f_21176: crate::check::types::St| prism_rtl::Turn::Finished((acc3_pi.clone(), unify_f_21176)))
                                                                }
                                                            })
                                                        })
                                                    } else {
                                                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p8.clone(), inner_pd.clone(), span_p9.clone()), move |unify_f_21232: crate::check::types::St| prism_rtl::Turn::Finished((acc2_pf.clone(), unify_f_21232)))
                                                    }
                                                }
                                            })
                                        })
                                    } else {
                                        if crate::check::expr::is_plain_sigil_f(&head_pc) && !cmp_p4x {
                                            crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x.clone(), at_p6x.clone()), move |inner_of_f_21334: crate::check::types::Ty| {
                                                let inner_pj = inner_of_f_21334;
                                                crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), inner_pj.clone()), move |head_sigil_f_21370: Text| {
                                                    let ih_pk = head_sigil_f_21370;
                                                    if crate::check::expr::is_time_sigil_f(&ih_pk) || (&ih_pk == &Text::lit("@")) {
                                                        prism_rtl::Turn::Finished((acc_p2x.clone(), crate::check::types::recording::err_fix_f(&st_p1x, &Text::lit("layer-under-optional"), &span_p9, &Text::from(format!("`{}` over an optional dynamic", &fname_p3x)), &Text::lit("match the optional once, at build time, to find out whether there is a dynamic"))))
                                                    } else {
                                                        {
                                                            let acc2_pl = {
                                                                let mut this: Peeled = acc_p2x.clone();
                                                                this.opts_p = crate::check::types::add_text_f(&this.opts_p, &head_pc);
                                                                this.opt_args_p = crate::prelude::push(&this.opt_args_p, &span_p9);
                                                                this
                                                            };
                                                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p8.clone(), inner_pj.clone(), span_p9.clone()), move |unify_f_21814: crate::check::types::St| prism_rtl::Turn::Finished((acc2_pl.clone(), unify_f_21814)))
                                                        }
                                                    }
                                                })
                                            })
                                        } else {
                                            if &head_pc == &Text::lit("&") {
                                                crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x.clone(), at_p6x.clone()), move |inner_of_f_21894: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p8.clone(), inner_of_f_21894, span_p9.clone()), move |unify_f_21880: crate::check::types::St| prism_rtl::Turn::Finished((acc_p2x.clone(), unify_f_21880))))
                                            } else {
                                                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p8.clone(), at_p6x.clone(), span_p9.clone()), move |unify_f_21941: crate::check::types::St| prism_rtl::Turn::Finished((acc_p2x.clone(), unify_f_21941)))
                                            }
                                        }
                                    }
                                }
                            })
                        }
                    }
                })
            })
        })
    }
}

/// `Start LayeredArg, x`: what the function value is when passed to `@Run`.
pub fn start_layered_arg_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, acc_p2: Peeled, fname_p3: Text, cmp_p4: bool, param_p5: crate::check::types::Ty, at_p6: crate::check::types::Ty, a_p7: crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check::types::St)>> {
    Rc::new(LayeredArg { env_p0, st_p1, acc_p2, fname_p3, cmp_p4, param_p5, at_p6, a_p7 })
}

/// ```prism
/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub fn peel_time_only_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, acc_p2: &Peeled, fname_p3: &Text, p_p4: &crate::check::types::Ty, at_p5: &crate::check::types::Ty, a_p6: &crate::syntax::Arg) -> (Peeled, crate::check::types::St) {
    let span_p7 = a_p6.value_p.span_p.clone();
    let head_p8 = crate::check::types::head_sigil_f(st_p1, at_p5);
    if &head_p8 == &Text::lit("@") {
        (acc_p2.clone(), crate::check::types::recording::err_fix_f(st_p1, &Text::lit("blueprint-operand"), &span_p7, &Text::from(format!("`{}` over a blueprint; bind it first", fname_p3)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text_f(env_p0, &span_p7)))))
    } else {
        if crate::check::expr::is_time_sigil_f(&head_p8) {
            {
                let inner_p9 = crate::check::expr::inner_of_f(st_p1, at_p5);
                let acc2_pa = {
                    let mut this: Peeled = acc_p2.clone();
                    if &head_p8 == &Text::lit("!") {
                        this.events_p = crate::prelude::push(&this.events_p, &span_p7);
                    } else {
                        this.dyns_p = crate::prelude::push(&this.dyns_p, &span_p7);
                    }
                    if &this.lifted_p == &Text::lit("") {
                        this.lifted_p = crate::check::expr::src_text_f(env_p0, &span_p7);
                    }
                    this
                };
                if crate::check::expr::is_time_sigil_f(&crate::check::types::head_sigil_f(st_p1, &inner_p9)) {
                    (acc2_pa.clone(), crate::check::types::recording::err_fix_f(st_p1, &Text::lit("two-layers"), &span_p7, &Text::from(format!("`{}` over a {} of {}s", fname_p3, &(if &head_p8 == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &(if &crate::check::types::head_sigil_f(st_p1, &inner_p9) == &Text::lit("$") {
                        Text::lit("dynamic")
                    } else {
                        Text::lit("event")
                    }))), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))
                } else {
                    (acc2_pa.clone(), crate::check::types::unify::unify_f(st_p1, p_p4, &inner_p9, &span_p7))
                }
            }
        } else {
            (acc_p2.clone(), crate::check::types::unify::unify_f(st_p1, p_p4, at_p5, &span_p7))
        }
    }
}

/// The step machine of `PeelTimeOnly`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub struct PeelTimeOnly {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub acc_p2: Peeled,
    pub fname_p3: Text,
    pub p_p4: crate::check::types::Ty,
    pub at_p5: crate::check::types::Ty,
    pub a_p6: crate::syntax::Arg,
}

impl prism_rtl::Job<(Peeled, crate::check::types::St)> for PeelTimeOnly {
    fn cycle(&self) -> prism_rtl::Turn<(Peeled, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let acc_p2 = &self.acc_p2;
        let fname_p3 = &self.fname_p3;
        let p_p4 = &self.p_p4;
        let at_p5 = &self.at_p5;
        let a_p6 = &self.a_p6;
        let span_p7 = a_p6.value_p.span_p.clone();
        let a_p6x = a_p6.clone();
        let acc_p2x = acc_p2.clone();
        let at_p5x = at_p5.clone();
        let env_p0x = env_p0.clone();
        let fname_p3x = fname_p3.clone();
        let p_p4x = p_p4.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), at_p5x.clone()), move |head_sigil_f_22227: Text| {
            let head_p8 = head_sigil_f_22227;
            if &head_p8 == &Text::lit("@") {
                prism_rtl::Turn::Finished((acc_p2x.clone(), crate::check::types::recording::err_fix_f(&st_p1x, &Text::lit("blueprint-operand"), &span_p7, &Text::from(format!("`{}` over a blueprint; bind it first", &fname_p3x)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text_f(&env_p0x, &span_p7))))))
            } else {
                if crate::check::expr::is_time_sigil_f(&head_p8) {
                    crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x.clone(), at_p5x.clone()), move |inner_of_f_22460: crate::check::types::Ty| {
                        let inner_p9 = inner_of_f_22460;
                        let acc2_pa = {
                            let mut this: Peeled = acc_p2x.clone();
                            if &head_p8 == &Text::lit("!") {
                                this.events_p = crate::prelude::push(&this.events_p, &span_p7);
                            } else {
                                this.dyns_p = crate::prelude::push(&this.dyns_p, &span_p7);
                            }
                            if &this.lifted_p == &Text::lit("") {
                                this.lifted_p = crate::check::expr::src_text_f(&env_p0x, &span_p7);
                            }
                            this
                        };
                        crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), inner_p9.clone()), move |head_sigil_f_22751: Text| if crate::check::expr::is_time_sigil_f(&head_sigil_f_22751) {
                            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), inner_p9.clone()), move |head_sigil_f_22881: Text| prism_rtl::Turn::Finished((acc2_pa.clone(), crate::check::types::recording::err_fix_f(&st_p1x, &Text::lit("two-layers"), &span_p7, &Text::from(format!("`{}` over a {} of {}s", &fname_p3x, &(if &head_p8 == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &(if &head_sigil_f_22881 == &Text::lit("$") {
                                Text::lit("dynamic")
                            } else {
                                Text::lit("event")
                            }))), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))))
                        } else {
                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p4x.clone(), inner_p9.clone(), span_p7.clone()), move |unify_f_23031: crate::check::types::St| prism_rtl::Turn::Finished((acc2_pa.clone(), unify_f_23031)))
                        })
                    })
                } else {
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p4x.clone(), at_p5x.clone(), span_p7.clone()), move |unify_f_23077: crate::check::types::St| prism_rtl::Turn::Finished((acc_p2x.clone(), unify_f_23077)))
                }
            }
        })
    }
}

/// `Start PeelTimeOnly, x`: what the function value is when passed to `@Run`.
pub fn start_peel_time_only_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, acc_p2: Peeled, fname_p3: Text, p_p4: crate::check::types::Ty, at_p5: crate::check::types::Ty, a_p6: crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check::types::St)>> {
    Rc::new(PeelTimeOnly { env_p0, st_p1, acc_p2, fname_p3, p_p4, at_p5, a_p6 })
}

/// ```prism
/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
/// ```
pub fn ctor_app_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::check::env::CtorInfo, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range, cspan_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (self_p9, st0_pa, inst_pb) = crate::check::types::schemes::instantiate_with_f(st_p1, &crate::check::types::Scheme { qs_p: c_p2.params_p.clone(), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: c_p2.ty_p.clone() }, span_p4, &Array::new());
    let field_tys_p6 = crate::prelude::run_to_end(crate::prelude::each_job(c_p2.args_p.clone(), {
        let inst_pbx = inst_pb.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let inst_pbxy = inst_pbx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let t_pc = p0;
                prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: inst_pbxy.clone(), t_p1: t_pc.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
    }));
    let st1_p7 = crate::check::types::recording::note_ty_f(&st0_pa, cspan_p5, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_p6.clone(), Rc::new(self_p9.clone())));
    let named_p8 = crate::prelude::filter(args_p3, &(|a_pd: &crate::syntax::Arg| &a_pd.name_o != &None));
    if (&crate::prelude::len(&named_p8) > &Nat::from(0u32)) && (&crate::prelude::len(&c_p2.fields_p) > &Nat::from(0u32)) {
        {
            let st2_pe = crate::prelude::run_to_end(crate::prelude::fold_job(named_p8.clone(), st1_p7.clone(), {
                let c_p2x = c_p2.clone();
                let env_p0x = env_p0.clone();
                let field_tys_p6x = field_tys_p6.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arg)| {
                    let c_p2xy = c_p2x.clone();
                    let env_p0xy = env_p0x.clone();
                    let field_tys_p6xy = field_tys_p6x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_ph = p0;
                        let a_pi = p1;
                        match &a_pi.name_o {
                            Some(id_pj) => match crate::check::expr::operators::index_of_o(&c_p2xy.fields_p, &id_pj.name_p) {
                                Some(i_pk) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env_p0: env_p0xy.clone(), st_p1: s_ph.clone(), e_p2: a_pi.value_p.clone(), expected_p3: crate::prelude::or(&crate::prelude::index(&field_tys_p6xy, &i_pk), &crate::check::types::Ty::TyErr) })),
                                None => prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_ph, &Text::lit("mismatch"), &a_pi.span_p, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name_f(&c_p2xy.owner_p), &id_pj.name_p)))),
                            },
                            None => prism_rtl::Turn::Finished(s_ph.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }));
            let missing_pf = crate::prelude::filter(&c_p2.fields_p, &(|f_pl: &Text| !crate::prelude::fold(&named_p8, &false, &(|seen_pm: &bool, a_pn: &crate::syntax::Arg| *seen_pm || arg_named_f(a_pn, f_pl)))));
            let st3_pg = if &crate::prelude::len(&missing_pf) > &Nat::from(0u32) {
                crate::check::types::recording::err_f(&st2_pe, &Text::lit("mismatch"), span_p4, &Text::from(format!("`{}` needs {}", &crate::check::types::bare_name_f(&c_p2.owner_p), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&missing_pf, &(|f_po: &Text| Text::from(format!("`{}`", f_po)))), &Text::lit(", ")))))
            } else {
                st2_pe.clone()
            };
            (self_p9.clone(), st3_pg.clone())
        }
    } else {
        if &crate::prelude::len(args_p3) != &crate::prelude::len(&field_tys_p6) {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st1_p7, &Text::lit("mismatch"), span_p4, &Text::from(format!("`{}` takes {} argument{}; here it has {}", &crate::check::types::bare_name_f(&c_p2.name_p), &crate::check::errors::count_word_f(&crate::prelude::len(&field_tys_p6)), &(if &crate::prelude::len(&field_tys_p6) == &Nat::from(1u32) {
                Text::lit("")
            } else {
                Text::lit("s")
            }), &crate::check::errors::count_word_f(&crate::prelude::len(args_p3))))))
        } else {
            {
                let st2_pp = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(args_p3)), st1_p7.clone(), {
                    let args_p3x = args_p3.clone();
                    let env_p0x = env_p0.clone();
                    let field_tys_p6x = field_tys_p6.clone();
                    Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                        let args_p3xy = args_p3x.clone();
                        let env_p0xy = env_p0x.clone();
                        let field_tys_p6xy = field_tys_p6x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let s_pq = p0;
                            let i_pr = p1;
                            match crate::prelude::index(&args_p3xy, &i_pr) {
                                Some(a_ps) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env_p0: env_p0xy.clone(), st_p1: s_pq.clone(), e_p2: a_ps.value_p.clone(), expected_p3: crate::prelude::or(&crate::prelude::index(&field_tys_p6xy, &i_pr), &crate::check::types::Ty::TyErr) })),
                                None => prism_rtl::Turn::Finished(s_pq.clone()),
                            }
                        }))
                    }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                }));
                (self_p9.clone(), st2_pp.clone())
            }
        }
    }
}

/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
/// ```
pub struct CtorApp {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::check::env::CtorInfo,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
    pub cspan_p5: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for CtorApp {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let cspan_p5 = &self.cspan_p5;
        let args_p3x = args_p3.clone();
        let c_p2x = c_p2.clone();
        let cspan_p5x = cspan_p5.clone();
        let env_p0x = env_p0.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p1x.clone(), crate::check::types::Scheme { qs_p: c_p2x.params_p.clone(), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: c_p2x.ty_p.clone() }, span_p4x.clone(), Array::new()), move |instantiate_with_f_23339: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
            let (self_p9, st0_pa, inst_pb) = instantiate_with_f_23339;
            crate::prelude::call_value(crate::prelude::each_job(c_p2x.args_p.clone(), {
                let inst_pbx = inst_pb.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let inst_pbxy = inst_pbx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let t_pc = p0;
                        prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: inst_pbxy.clone(), t_p1: t_pc.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_23481: Array<crate::check::types::Ty>| {
                let field_tys_p6 = each_23481;
                let st1_p7 = crate::check::types::recording::note_ty_f(&st0_pa, &cspan_p5x, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_p6.clone(), Rc::new(self_p9.clone())));
                let named_p8 = crate::prelude::filter(&args_p3x, &(|a_pd: &crate::syntax::Arg| &a_pd.name_o != &None));
                if (&crate::prelude::len(&named_p8) > &Nat::from(0u32)) && (&crate::prelude::len(&c_p2x.fields_p) > &Nat::from(0u32)) {
                    crate::prelude::call_value(crate::prelude::fold_job(named_p8.clone(), st1_p7.clone(), {
                        let c_p2xx = c_p2x.clone();
                        let env_p0xx = env_p0x.clone();
                        let field_tys_p6x = field_tys_p6.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arg)| {
                            let c_p2xxy = c_p2xx.clone();
                            let env_p0xxy = env_p0xx.clone();
                            let field_tys_p6xy = field_tys_p6x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let s_ph = p0;
                                let a_pi = p1;
                                match &a_pi.name_o {
                                    Some(id_pj) => match crate::check::expr::operators::index_of_o(&c_p2xxy.fields_p, &id_pj.name_p) {
                                        Some(i_pk) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env_p0: env_p0xxy.clone(), st_p1: s_ph.clone(), e_p2: a_pi.value_p.clone(), expected_p3: crate::prelude::or(&crate::prelude::index(&field_tys_p6xy, &i_pk), &crate::check::types::Ty::TyErr) })),
                                        None => prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_ph, &Text::lit("mismatch"), &a_pi.span_p, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name_f(&c_p2xxy.owner_p), &id_pj.name_p)))),
                                    },
                                    None => prism_rtl::Turn::Finished(s_ph.clone()),
                                }
                            }))
                        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_23691: crate::check::types::St| {
                        let st2_pe = fold_23691;
                        let missing_pf = crate::prelude::filter(&c_p2x.fields_p, &(|f_pl: &Text| !crate::prelude::fold(&named_p8, &false, &(|seen_pm: &bool, a_pn: &crate::syntax::Arg| *seen_pm || arg_named_f(a_pn, f_pl)))));
                        let st3_pg = if &crate::prelude::len(&missing_pf) > &Nat::from(0u32) {
                            crate::check::types::recording::err_f(&st2_pe, &Text::lit("mismatch"), &span_p4x, &Text::from(format!("`{}` needs {}", &crate::check::types::bare_name_f(&c_p2x.owner_p), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&missing_pf, &(|f_po: &Text| Text::from(format!("`{}`", f_po)))), &Text::lit(", ")))))
                        } else {
                            st2_pe.clone()
                        };
                        prism_rtl::Turn::Finished((self_p9.clone(), st3_pg.clone()))
                    })
                } else {
                    if &crate::prelude::len(&args_p3x) != &crate::prelude::len(&field_tys_p6) {
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st1_p7, &Text::lit("mismatch"), &span_p4x, &Text::from(format!("`{}` takes {} argument{}; here it has {}", &crate::check::types::bare_name_f(&c_p2x.name_p), &crate::check::errors::count_word_f(&crate::prelude::len(&field_tys_p6)), &(if &crate::prelude::len(&field_tys_p6) == &Nat::from(1u32) {
                            Text::lit("")
                        } else {
                            Text::lit("s")
                        }), &crate::check::errors::count_word_f(&crate::prelude::len(&args_p3x)))))))
                    } else {
                        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&args_p3x)), st1_p7.clone(), {
                            let args_p3xx = args_p3x.clone();
                            let env_p0xx = env_p0x.clone();
                            let field_tys_p6x = field_tys_p6.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                let args_p3xxy = args_p3xx.clone();
                                let env_p0xxy = env_p0xx.clone();
                                let field_tys_p6xy = field_tys_p6x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s_pq = p0;
                                    let i_pr = p1;
                                    match crate::prelude::index(&args_p3xxy, &i_pr) {
                                        Some(a_ps) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env_p0: env_p0xxy.clone(), st_p1: s_pq.clone(), e_p2: a_ps.value_p.clone(), expected_p3: crate::prelude::or(&crate::prelude::index(&field_tys_p6xy, &i_pr), &crate::check::types::Ty::TyErr) })),
                                        None => prism_rtl::Turn::Finished(s_pq.clone()),
                                    }
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }), move |fold_24497: crate::check::types::St| {
                            let st2_pp = fold_24497;
                            prism_rtl::Turn::Finished((self_p9.clone(), st2_pp.clone()))
                        })
                    }
                }
            })
        })
    }
}

/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_app_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, c_p2: crate::check::env::CtorInfo, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range, cspan_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(CtorApp { env_p0, st_p1, c_p2, args_p3, span_p4, cspan_p5 })
}

/// ```prism
/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
/// ```
pub fn tag_app_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, name_p2: &Text, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range, cspan_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::prelude::get(&env_p0.g_p.tags_p, name_p2) {
        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), span_p4, &Text::from(format!("no tag `{}`", name_p2)))),
        Some(tg_p6) => {
            let (out_pb, st1_pc, inst_pd) = crate::check::types::schemes::instantiate_with_f(st_p1, &crate::check::types::Scheme { qs_p: tg_p6.qs_p.clone(), plain_qs_p: Array::new(), rqs_p: tg_p6.rqs_p.clone(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: tg_p6.bounds_p.clone(), ty_p: tg_p6.out_p.clone() }, span_p4, &Array::new());
            let st2_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(args_p3.clone(), st1_pc.clone(), {
                let tg_p6x = tg_p6.clone();
                let env_p0x = env_p0.clone();
                let name_p2x = name_p2.clone();
                let inst_pdx = inst_pd.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arg)| {
                    let tg_p6xy = tg_p6x.clone();
                    let env_p0xy = env_p0x.clone();
                    let name_p2xy = name_p2x.clone();
                    let inst_pdxy = inst_pdx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_pe = p0;
                        let a_pf = p1;
                        match &a_pf.name_o {
                            Some(id_pg) => match field_of_tag_o(&tg_p6xy, &id_pg.name_p) {
                                Some(ft_ph) => {
                                    let id_pgx = id_pg.clone();
                                    crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pdxy.clone(), ft_ph.clone()), move |subst_q_f_25451: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(TagField { env_p0: env_p0xy.clone(), st_p1: s_pe.clone(), tag_name_p2: name_p2xy.clone(), field_p3: id_pgx.name_p.clone(), ft_p4: subst_q_f_25451, a_p5: a_pf.clone() })))
                                },
                                None => prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_pe, &Text::lit("mismatch"), &a_pf.span_p, &Text::from(format!("`{}` has no field `{}`", &name_p2xy, &id_pg.name_p)))),
                            },
                            None => prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_pe, &Text::lit("mismatch"), &a_pf.span_p, &Text::from(format!("a tag\'s fields are named: `{}(field=...)`", &name_p2xy)))),
                        }
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }));
            let missing_p8 = crate::prelude::filter(&tg_p6.fields_p, &(|(f_pi, _): &(Text, crate::check::types::Ty)| !crate::prelude::fold(args_p3, &false, &(|seen_pj: &bool, a_pk: &crate::syntax::Arg| *seen_pj || arg_named_f(a_pk, f_pi)))));
            let st3_p9 = if (&crate::prelude::len(&missing_p8) > &Nat::from(0u32)) && !crate::prelude::fold(args_p3, &false, &(|seen_pl: &bool, a_pm: &crate::syntax::Arg| *seen_pl || (&*a_pm.value_p.kind_p == &crate::syntax::ExprKind::ERest))) {
                crate::check::types::recording::err_f(&st2_p7, &Text::lit("mismatch"), span_p4, &Text::from(format!("`{}` needs {}", name_p2, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&missing_p8, &(|(f_pn, _): &(Text, crate::check::types::Ty)| Text::from(format!("`{}`", f_pn)))), &Text::lit(", ")))))
            } else {
                st2_p7.clone()
            };
            let field_tys_pa = crate::prelude::run_to_end(crate::prelude::each_job(tg_p6.fields_p.clone(), {
                let inst_pdx = inst_pd.clone();
                Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                    let inst_pdxy = inst_pdx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (_, ft_po) = p0;
                        prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: inst_pdxy.clone(), t_p1: ft_po.clone() }))
                    }))
                }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }));
            if &tg_p6.kind_p == &Text::lit("Element") {
                {
                    let (rw_pq, st4_pr) = crate::check::types::recording::fresh_row_f(&st3_p9, &Array::from(vec![tg_p6.family_p.clone()]));
                    let et_pp = crate::check::types::Ty::TyElem(crate::check::types::Rw { fams_p: Array::from(vec![tg_p6.family_p.clone()]), minus_p: Array::new(), tail_p: rw_pq.tail_p.clone() }, Rc::new(out_pb.clone()));
                    (et_pp.clone(), crate::check::types::recording::note_ty_f(&st4_pr, cspan_p5, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_pa.clone(), Rc::new(et_pp.clone()))))
                }
            } else {
                (crate::check::types::Ty::TyCon(tg_p6.kind_p.clone(), Array::new()), crate::check::types::recording::note_ty_f(&st3_p9, cspan_p5, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_pa.clone(), Rc::new(crate::check::types::Ty::TyCon(tg_p6.kind_p.clone(), Array::new())))))
            }
        },
    }
}

/// The step machine of `TagApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
/// ```
pub struct TagApp {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub name_p2: Text,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
    pub cspan_p5: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for TagApp {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let name_p2 = &self.name_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let cspan_p5 = &self.cspan_p5;
        match crate::prelude::get(&env_p0.g_p.tags_p, name_p2) {
            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), span_p4, &Text::from(format!("no tag `{}`", name_p2))))),
            Some(tg_p6) => {
                let args_p3x = args_p3.clone();
                let cspan_p5x = cspan_p5.clone();
                let env_p0x = env_p0.clone();
                let name_p2x = name_p2.clone();
                let span_p4x = span_p4.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p1x.clone(), crate::check::types::Scheme { qs_p: tg_p6.qs_p.clone(), plain_qs_p: Array::new(), rqs_p: tg_p6.rqs_p.clone(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: tg_p6.bounds_p.clone(), ty_p: tg_p6.out_p.clone() }, span_p4x.clone(), Array::new()), move |instantiate_with_f_25161: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                    let (out_pb, st1_pc, inst_pd) = instantiate_with_f_25161;
                    crate::prelude::call_value(crate::prelude::fold_job(args_p3x.clone(), st1_pc.clone(), {
                        let tg_p6x = tg_p6.clone();
                        let env_p0xx = env_p0x.clone();
                        let name_p2xx = name_p2x.clone();
                        let inst_pdx = inst_pd.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arg)| {
                            let tg_p6xy = tg_p6x.clone();
                            let env_p0xxy = env_p0xx.clone();
                            let name_p2xxy = name_p2xx.clone();
                            let inst_pdxy = inst_pdx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let s_pe = p0;
                                let a_pf = p1;
                                match &a_pf.name_o {
                                    Some(id_pg) => match field_of_tag_o(&tg_p6xy, &id_pg.name_p) {
                                        Some(ft_ph) => {
                                            let id_pgx = id_pg.clone();
                                            crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pdxy.clone(), ft_ph.clone()), move |subst_q_f_25451: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(TagField { env_p0: env_p0xxy.clone(), st_p1: s_pe.clone(), tag_name_p2: name_p2xxy.clone(), field_p3: id_pgx.name_p.clone(), ft_p4: subst_q_f_25451, a_p5: a_pf.clone() })))
                                        },
                                        None => prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_pe, &Text::lit("mismatch"), &a_pf.span_p, &Text::from(format!("`{}` has no field `{}`", &name_p2xxy, &id_pg.name_p)))),
                                    },
                                    None => prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_pe, &Text::lit("mismatch"), &a_pf.span_p, &Text::from(format!("a tag\'s fields are named: `{}(field=...)`", &name_p2xxy)))),
                                }
                            }))
                        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_25308: crate::check::types::St| {
                        let st2_p7 = fold_25308;
                        let missing_p8 = crate::prelude::filter(&tg_p6.fields_p, &(|(f_pi, _): &(Text, crate::check::types::Ty)| !crate::prelude::fold(&args_p3x, &false, &(|seen_pj: &bool, a_pk: &crate::syntax::Arg| *seen_pj || arg_named_f(a_pk, f_pi)))));
                        let st3_p9 = if (&crate::prelude::len(&missing_p8) > &Nat::from(0u32)) && !crate::prelude::fold(&args_p3x, &false, &(|seen_pl: &bool, a_pm: &crate::syntax::Arg| *seen_pl || (&*a_pm.value_p.kind_p == &crate::syntax::ExprKind::ERest))) {
                            crate::check::types::recording::err_f(&st2_p7, &Text::lit("mismatch"), &span_p4x, &Text::from(format!("`{}` needs {}", &name_p2x, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&missing_p8, &(|(f_pn, _): &(Text, crate::check::types::Ty)| Text::from(format!("`{}`", f_pn)))), &Text::lit(", ")))))
                        } else {
                            st2_p7.clone()
                        };
                        crate::prelude::call_value(crate::prelude::each_job(tg_p6.fields_p.clone(), {
                            let inst_pdx = inst_pd.clone();
                            Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                                let inst_pdxy = inst_pdx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (_, ft_po) = p0;
                                    prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: inst_pdxy.clone(), t_p1: ft_po.clone() }))
                                }))
                            }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                        }), move |each_26003: Array<crate::check::types::Ty>| {
                            let field_tys_pa = each_26003;
                            if &tg_p6.kind_p == &Text::lit("Element") {
                                {
                                    let (rw_pq, st4_pr) = crate::check::types::recording::fresh_row_f(&st3_p9, &Array::from(vec![tg_p6.family_p.clone()]));
                                    let et_pp = crate::check::types::Ty::TyElem(crate::check::types::Rw { fams_p: Array::from(vec![tg_p6.family_p.clone()]), minus_p: Array::new(), tail_p: rw_pq.tail_p.clone() }, Rc::new(out_pb.clone()));
                                    prism_rtl::Turn::Finished((et_pp.clone(), crate::check::types::recording::note_ty_f(&st4_pr, &cspan_p5x, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_pa.clone(), Rc::new(et_pp.clone())))))
                                }
                            } else {
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(tg_p6.kind_p.clone(), Array::new()), crate::check::types::recording::note_ty_f(&st3_p9, &cspan_p5x, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_pa.clone(), Rc::new(crate::check::types::Ty::TyCon(tg_p6.kind_p.clone(), Array::new()))))))
                            }
                        })
                    })
                })
            },
        }
    }
}

/// `Start TagApp, x`: what the function value is when passed to `@Run`.
pub fn start_tag_app_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, name_p2: Text, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range, cspan_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(TagApp { env_p0, st_p1, name_p2, args_p3, span_p4, cspan_p5 })
}

/// ```prism
/// ?FieldOfTag: fn TagInfo, Text -> ?Ty
/// ```
pub fn field_of_tag_o(tg_p0: &crate::check::env::TagInfo, f_p1: &Text) -> Option<crate::check::types::Ty> {
    crate::prelude::fold(&tg_p0.fields_p, &None, &(|found_o2: &Option<crate::check::types::Ty>, (n_p3, t_p4): &(Text, crate::check::types::Ty)| match found_o2 {
        Some(x_p5) => Some(x_p5.clone()),
        None => if n_p3 == f_p1 { Some(t_p4.clone()) } else { None },
    }))
}

/// ```prism
/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
/// ```
pub fn tag_field_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, tag_name_p2: &Text, field_p3: &Text, ft_p4: &crate::check::types::Ty, a_p5: &crate::syntax::Arg) -> crate::check::types::St {
    if &crate::check::types::head_sigil_f(st_p1, ft_p4) != &Text::lit("") {
        crate::check::expr::check_f(env_p0, st_p1, &a_p5.value_p, ft_p4)
    } else {
        {
            let (at_p7, st2_p8) = crate::check::expr::infer_f(env_p0, st_p1, &a_p5.value_p);
            let head_p6 = crate::check::types::head_sigil_f(&st2_p8, &at_p7);
            if &head_p6 == &Text::lit("$") {
                crate::check::types::recording::err_fix_f(&st2_p8, &Text::lit("identity-dynamic"), &a_p5.value_p.span_p, &Text::from(format!("a dynamic in the identity field `{}`", field_p3)), &Text::from(format!("for a new element per value, write `rebuild {}:` with `{}({}=_, ...)` inside", &crate::check::expr::src_text_f(env_p0, &a_p5.value_p.span_p), tag_name_p2, field_p3)))
            } else {
                if &head_p6 == &Text::lit("!") {
                    crate::check::types::recording::err_f(&st2_p8, &Text::lit("two-events"), &a_p5.value_p.span_p, &Text::from(format!("an event in the plain field `{}`", field_p3)))
                } else {
                    crate::check::types::unify::unify_f(&st2_p8, ft_p4, &at_p7, &a_p5.value_p.span_p)
                }
            }
        }
    }
}

/// The step machine of `TagField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
/// ```
pub struct TagField {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub tag_name_p2: Text,
    pub field_p3: Text,
    pub ft_p4: crate::check::types::Ty,
    pub a_p5: crate::syntax::Arg,
}

impl prism_rtl::Job<crate::check::types::St> for TagField {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let tag_name_p2 = &self.tag_name_p2;
        let field_p3 = &self.field_p3;
        let ft_p4 = &self.ft_p4;
        let a_p5 = &self.a_p5;
        let a_p5x = a_p5.clone();
        let env_p0x = env_p0.clone();
        let field_p3x = field_p3.clone();
        let ft_p4x = ft_p4.clone();
        let st_p1x = st_p1.clone();
        let tag_name_p2x = tag_name_p2.clone();
        crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), ft_p4x.clone()), move |head_sigil_f_26819: Text| if &head_sigil_f_26819 != &Text::lit("") {
            prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), e_p2: a_p5x.value_p.clone(), expected_p3: ft_p4x.clone() }))
        } else {
            crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), a_p5x.value_p.clone()), move |infer_f_26907: (crate::check::types::Ty, crate::check::types::St)| {
                let (at_p7, st2_p8) = infer_f_26907;
                crate::prelude::call_then(crate::check::types::start_head_sigil_f(st2_p8.clone(), at_p7.clone()), move |head_sigil_f_26949: Text| {
                    let head_p6 = head_sigil_f_26949;
                    if &head_p6 == &Text::lit("$") {
                        prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st2_p8, &Text::lit("identity-dynamic"), &a_p5x.value_p.span_p, &Text::from(format!("a dynamic in the identity field `{}`", &field_p3x)), &Text::from(format!("for a new element per value, write `rebuild {}:` with `{}({}=_, ...)` inside", &crate::check::expr::src_text_f(&env_p0x, &a_p5x.value_p.span_p), &tag_name_p2x, &field_p3x))))
                    } else {
                        if &head_p6 == &Text::lit("!") {
                            prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&st2_p8, &Text::lit("two-events"), &a_p5x.value_p.span_p, &Text::from(format!("an event in the plain field `{}`", &field_p3x))))
                        } else {
                            prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st2_p8.clone(), expected_p1: ft_p4x.clone(), found_p2: at_p7.clone(), span_p3: a_p5x.value_p.span_p.clone() }))
                        }
                    }
                })
            })
        })
    }
}

/// `Start TagField, x`: what the function value is when passed to `@Run`.
pub fn start_tag_field_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, tag_name_p2: Text, field_p3: Text, ft_p4: crate::check::types::Ty, a_p5: crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(TagField { env_p0, st_p1, tag_name_p2, field_p3, ft_p4, a_p5 })
}

/// ```prism
/// LambdaArity: fn Expr -> Nat
/// ```
pub fn lambda_arity_f(e_p0: &crate::syntax::Expr) -> Nat {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ELambda(Some(ps_p1), _) => crate::prelude::len(ps_p1),
        crate::syntax::ExprKind::EGroup(x_p2) => lambda_arity_f(&**x_p2),
        _ => Nat::from(2u32),
    }
}

/// ```prism
/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub fn infer_lambda_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, expected_o3: &Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EGroup(x_p4) => {
            let (t_p5, st2_p6) = infer_lambda_f(env_p0, st_p1, &**x_p4, expected_o3);
            (t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &x_p4.span_p, &t_p5))
        },
        _ => infer_bare_lambda_f(env_p0, st_p1, e_p2, expected_o3),
    }
}

/// The step machine of `InferLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub struct InferLambda {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub expected_o3: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferLambda {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let expected_o3 = &self.expected_o3;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EGroup(x_p4) => {
                let expected_o3x = expected_o3.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let x_p4x = (**x_p4).clone();
                crate::prelude::call_then(start_infer_lambda_f(env_p0x.clone(), st_p1x.clone(), x_p4x.clone(), expected_o3x.clone()), move |infer_lambda_f_28335: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p5, st2_p6) = infer_lambda_f_28335;
                    prism_rtl::Turn::Finished((t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &x_p4x.span_p, &t_p5)))
                })
            },
            _ => prism_rtl::Turn::More(Rc::new(InferBareLambda { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p2.clone(), expected_o3: expected_o3.clone() })),
        }
    }
}

/// `Start InferLambda, x`: what the function value is when passed to `@Run`.
pub fn start_infer_lambda_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, expected_o3: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferLambda { env_p0, st_p1, e_p2, expected_o3 })
}

/// ```prism
/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub fn infer_bare_lambda_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, expected_o3: &Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    let (params_pg, body_ph) = match &*e_p2.kind_p {
        crate::syntax::ExprKind::ELambda(Some(ps_pb), b_pc) => (ps_pb.clone(), (**b_pc).clone()),
        crate::syntax::ExprKind::ELambda(None, b_pd) => (Array::from(vec![topic_pat_f(&e_p2.span_p)]), (**b_pd).clone()),
        crate::syntax::ExprKind::ETopicField(f_pe) => (Array::from(vec![topic_pat_f(&e_p2.span_p)]), crate::syntax::LambdaBody::LbExpr(Rc::new(topic_field_expr_f(&e_p2.span_p, f_pe)))),
        crate::syntax::ExprKind::ETopicIndex(x_pf) => (Array::from(vec![topic_pat_f(&e_p2.span_p)]), crate::syntax::LambdaBody::LbExpr(Rc::new(topic_index_expr_f(&e_p2.span_p, &**x_pf)))),
        _ => (Array::new(), crate::syntax::LambdaBody::LbExpr(Rc::new(e_p2.clone()))),
    };
    let (exp_params_pl, exp_res_om, st0_pn) = match expected_o3 {
        Some(t_pi) => match crate::check::types::recording::walk_f(st_p1, t_pi) {
            crate::check::types::Ty::TyFn(_, ps_pj, r_pk) => if &crate::prelude::len(&ps_pj) == &crate::prelude::len(&params_pg) {
                (ps_pj.clone(), Some((*r_pk).clone()), st_p1.clone())
            } else {
                (Array::new(), None, crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), &e_p2.span_p, &Text::from(format!("this lambda takes {} parameter{}; here {} {} wanted", &crate::check::errors::count_word_f(&crate::prelude::len(&params_pg)), &(if &crate::prelude::len(&params_pg) == &Nat::from(1u32) {
                    Text::lit("")
                } else {
                    Text::lit("s")
                }), &crate::check::errors::count_word_f(&crate::prelude::len(&ps_pj)), &(if &crate::prelude::len(&ps_pj) == &Nat::from(1u32) {
                    Text::lit("is")
                } else {
                    Text::lit("are")
                })))))
            },
            _ => (Array::new(), None, st_p1.clone()),
        },
        None => (Array::new(), None, st_p1.clone()),
    };
    let (env2_p12, ptys_p13, st1_p14) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&params_pg)), (env_p0.clone(), Array::new(), st0_pn.clone()), {
        let params_pgx = params_pg.clone();
        let e_p2x = e_p2.clone();
        let exp_params_plx = exp_params_pl.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
            let params_pgxy = params_pgx.clone();
            let e_p2xy = e_p2x.clone();
            let exp_params_plxy = exp_params_plx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (en_po, acc_pp, s_pq) = p0;
                let i_pr = p1;
                {
                    let p_ps = crate::prelude::or(&crate::prelude::index(&params_pgxy, &i_pr), &crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: e_p2xy.span_p.clone() });
                    let (pt_pu, s2_pv) = match crate::prelude::index(&exp_params_plxy, &i_pr) {
                        Some(t_pt) => (t_pt, s_pq.clone()),
                        None => crate::check::types::fresh_var_f(&s_pq, &true, &Text::lit("")),
                    };
                    crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::expr::lets::unpend_f(&en_po), s2_pv.clone(), p_ps.clone(), pt_pu.clone(), false), move |bind_pattern_f_29677: (crate::check::expr::Env, crate::check::types::St)| {
                        let (en2_p10, s3_p11) = bind_pattern_f_29677;
                        prism_rtl::Turn::Finished((en2_p10.clone(), crate::prelude::push(&acc_pp, &pt_pu), s3_p11.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }));
    let outer_color_p4 = st1_p14.color_p.clone();
    let outer_why_p5 = st1_p14.color_why_p.clone();
    let outer_flex_p6 = st1_p14.color_flex_p.clone();
    let (lcol_p15, st1b_p16) = crate::check::types::fresh_col_f(&st1_p14);
    let st2_p7 = {
        let mut this: crate::check::types::St = st1b_p16.clone();
        this.color_p = crate::check::types::Col::CBound;
        this.color_why_p = Text::lit("");
        this.color_flex_p = Array::new();
        this
    };
    let (rt_p1b, st3_p1c) = match &body_ph {
        crate::syntax::LambdaBody::LbExpr(x_p17) => match &exp_res_om {
            Some(r_p18) => {
                let s4_p19 = crate::check::expr::check_f(&env2_p12, &st2_p7, &**x_p17, r_p18);
                (r_p18.clone(), s4_p19.clone())
            },
            None => crate::check::expr::infer_f(&env2_p12, &st2_p7, &**x_p17),
        },
        crate::syntax::LambdaBody::LbBlock(b_p1a) => infer_body_block_f(&env2_p12, &st2_p7, b_p1a, &exp_res_om),
    };
    let st3b_p8 = crate::check::types::colors::settle_body_f(&st3_p1c, &lcol_p15, &Text::lit(""));
    let st3c_p9 = crate::check::types::colors::add_leq_f(&st3b_p8, &st3b_p8.color_p, &lcol_p15, &e_p2.span_p, &Text::lit("lambda"), &Text::lit(""), &st3b_p8.color_why_p);
    let st4_pa = {
        let mut this: crate::check::types::St = st3c_p9.clone();
        this.color_p = outer_color_p4.clone();
        this.color_why_p = outer_why_p5.clone();
        this.color_flex_p = outer_flex_p6.clone();
        this
    };
    (crate::check::types::Ty::TyFn(lcol_p15.clone(), ptys_p13.clone(), Rc::new(rt_p1b.clone())), crate::check::types::recording::note_fn_f(&st4_pa, &e_p2.span_p, &Text::lit("lambda"), &lcol_p15, &lcol_p15))
}

/// The step machine of `InferBareLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub struct InferBareLambda {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub expected_o3: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferBareLambda {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let expected_o3 = &self.expected_o3;
        let (params_pg, body_ph) = match &*e_p2.kind_p {
            crate::syntax::ExprKind::ELambda(Some(ps_pb), b_pc) => (ps_pb.clone(), (**b_pc).clone()),
            crate::syntax::ExprKind::ELambda(None, b_pd) => (Array::from(vec![topic_pat_f(&e_p2.span_p)]), (**b_pd).clone()),
            crate::syntax::ExprKind::ETopicField(f_pe) => (Array::from(vec![topic_pat_f(&e_p2.span_p)]), crate::syntax::LambdaBody::LbExpr(Rc::new(topic_field_expr_f(&e_p2.span_p, f_pe)))),
            crate::syntax::ExprKind::ETopicIndex(x_pf) => (Array::from(vec![topic_pat_f(&e_p2.span_p)]), crate::syntax::LambdaBody::LbExpr(Rc::new(topic_index_expr_f(&e_p2.span_p, &**x_pf)))),
            _ => (Array::new(), crate::syntax::LambdaBody::LbExpr(Rc::new(e_p2.clone()))),
        };
        let (exp_params_pl, exp_res_om, st0_pn) = match expected_o3 {
            Some(t_pi) => match crate::check::types::recording::walk_f(st_p1, t_pi) {
                crate::check::types::Ty::TyFn(_, ps_pj, r_pk) => if &crate::prelude::len(&ps_pj) == &crate::prelude::len(&params_pg) {
                    (ps_pj.clone(), Some((*r_pk).clone()), st_p1.clone())
                } else {
                    (Array::new(), None, crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), &e_p2.span_p, &Text::from(format!("this lambda takes {} parameter{}; here {} {} wanted", &crate::check::errors::count_word_f(&crate::prelude::len(&params_pg)), &(if &crate::prelude::len(&params_pg) == &Nat::from(1u32) {
                        Text::lit("")
                    } else {
                        Text::lit("s")
                    }), &crate::check::errors::count_word_f(&crate::prelude::len(&ps_pj)), &(if &crate::prelude::len(&ps_pj) == &Nat::from(1u32) {
                        Text::lit("is")
                    } else {
                        Text::lit("are")
                    })))))
                },
                _ => (Array::new(), None, st_p1.clone()),
            },
            None => (Array::new(), None, st_p1.clone()),
        };
        let e_p2x = e_p2.clone();
        let env_p0x = env_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&params_pg)), (env_p0x.clone(), Array::new(), st0_pn.clone()), {
            let params_pgx = params_pg.clone();
            let e_p2xx = e_p2x.clone();
            let exp_params_plx = exp_params_pl.clone();
            Rc::new(move |(p0, p1): ((crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
                let params_pgxy = params_pgx.clone();
                let e_p2xxy = e_p2xx.clone();
                let exp_params_plxy = exp_params_plx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (en_po, acc_pp, s_pq) = p0;
                    let i_pr = p1;
                    {
                        let p_ps = crate::prelude::or(&crate::prelude::index(&params_pgxy, &i_pr), &crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: e_p2xxy.span_p.clone() });
                        let (pt_pu, s2_pv) = match crate::prelude::index(&exp_params_plxy, &i_pr) {
                            Some(t_pt) => (t_pt, s_pq.clone()),
                            None => crate::check::types::fresh_var_f(&s_pq, &true, &Text::lit("")),
                        };
                        crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::expr::lets::unpend_f(&en_po), s2_pv.clone(), p_ps.clone(), pt_pu.clone(), false), move |bind_pattern_f_29677: (crate::check::expr::Env, crate::check::types::St)| {
                            let (en2_p10, s3_p11) = bind_pattern_f_29677;
                            prism_rtl::Turn::Finished((en2_p10.clone(), crate::prelude::push(&acc_pp, &pt_pu), s3_p11.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }), move |fold_29408: (crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St)| {
            let (env2_p12, ptys_p13, st1_p14) = fold_29408;
            let outer_color_p4 = st1_p14.color_p.clone();
            let outer_why_p5 = st1_p14.color_why_p.clone();
            let outer_flex_p6 = st1_p14.color_flex_p.clone();
            let (lcol_p15, st1b_p16) = crate::check::types::fresh_col_f(&st1_p14);
            let st2_p7 = {
                let mut this: crate::check::types::St = st1b_p16.clone();
                this.color_p = crate::check::types::Col::CBound;
                this.color_why_p = Text::lit("");
                this.color_flex_p = Array::new();
                this
            };
            let (rt_p1b, st3_p1c) = match &body_ph {
                crate::syntax::LambdaBody::LbExpr(x_p17) => match &exp_res_om {
                    Some(r_p18) => {
                        let s4_p19 = crate::check::expr::check_f(&env2_p12, &st2_p7, &**x_p17, r_p18);
                        (r_p18.clone(), s4_p19.clone())
                    },
                    None => crate::check::expr::infer_f(&env2_p12, &st2_p7, &**x_p17),
                },
                crate::syntax::LambdaBody::LbBlock(b_p1a) => infer_body_block_f(&env2_p12, &st2_p7, b_p1a, &exp_res_om),
            };
            crate::prelude::call_then(crate::check::types::colors::start_settle_body_f(st3_p1c.clone(), lcol_p15.clone(), Text::lit("")), move |settle_body_f_30263: crate::check::types::St| {
                let st3b_p8 = settle_body_f_30263;
                crate::prelude::call_then(crate::check::types::colors::start_add_leq_f(st3b_p8.clone(), st3b_p8.color_p.clone(), lcol_p15.clone(), e_p2x.span_p.clone(), Text::lit("lambda"), Text::lit(""), st3b_p8.color_why_p.clone()), move |add_leq_f_30303: crate::check::types::St| {
                    let st3c_p9 = add_leq_f_30303;
                    let st4_pa = {
                        let mut this: crate::check::types::St = st3c_p9.clone();
                        this.color_p = outer_color_p4.clone();
                        this.color_why_p = outer_why_p5.clone();
                        this.color_flex_p = outer_flex_p6.clone();
                        this
                    };
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyFn(lcol_p15.clone(), ptys_p13.clone(), Rc::new(rt_p1b.clone())), crate::check::types::recording::note_fn_f(&st4_pa, &e_p2x.span_p, &Text::lit("lambda"), &lcol_p15, &lcol_p15)))
                })
            })
        })
    }
}

/// `Start InferBareLambda, x`: what the function value is when passed to `@Run`.
pub fn start_infer_bare_lambda_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, expected_o3: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferBareLambda { env_p0, st_p1, e_p2, expected_o3 })
}

/// ```prism
/// TopicPat: fn Range -> Pattern
/// ```
pub fn topic_pat_f(span_p0: &crate::syntax::Range) -> crate::syntax::Pattern_ {
    crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PName(topic_sname_f(span_p0))), span_p: span_p0.clone() }
}

/// ```prism
/// TopicSName: fn Range -> SName
/// ```
pub fn topic_sname_f(span_p0: &crate::syntax::Range) -> crate::syntax::SName {
    crate::syntax::SName { sigils_p: Text::lit(""), path_p: Array::from(vec![Text::lit("_")]), span_p: span_p0.clone() }
}

/// ```prism
/// TopicExpr: fn Range -> Expr
/// ```
pub fn topic_expr_f(span_p0: &crate::syntax::Range) -> crate::syntax::Expr {
    crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EName(topic_sname_f(span_p0))), span_p: span_p0.clone() }
}

/// ```prism
/// TopicFieldExpr: fn Range, Ident -> Expr
/// ```
pub fn topic_field_expr_f(span_p0: &crate::syntax::Range, f_p1: &crate::syntax::Ident) -> crate::syntax::Expr {
    crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EField(Rc::new(topic_expr_f(span_p0)), Text::lit(""), f_p1.clone())), span_p: span_p0.clone() }
}

/// ```prism
/// TopicIndexExpr: fn Range, Expr -> Expr
/// ```
pub fn topic_index_expr_f(span_p0: &crate::syntax::Range, x_p1: &crate::syntax::Expr) -> crate::syntax::Expr {
    crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EIndex(Rc::new(topic_expr_f(span_p0)), Rc::new(x_p1.clone()))), span_p: span_p0.clone() }
}

/// ```prism
/// ArgNamed: fn Arg, Text -> Bool
/// ```
pub fn arg_named_f(a_p0: &crate::syntax::Arg, f_p1: &Text) -> bool {
    match &a_p0.name_o {
        Some(id_p2) => &id_p2.name_p == f_p1,
        None => false,
    }
}

/// ```prism
/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
/// ```
pub fn infer_body_block_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block, expected_o3: &Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p4, st2_p5) = crate::check::expr::lets::infer_expr_block_f(env_p0, st_p1, b_p2);
    match expected_o3 {
        Some(r_p6) => (r_p6.clone(), crate::check::types::unify::unify_f(&st2_p5, r_p6, &t_p4, &b_p2.span_p)),
        None => (t_p4.clone(), st2_p5.clone()),
    }
}

/// The step machine of `InferBodyBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
/// ```
pub struct InferBodyBlock {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
    pub expected_o3: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferBodyBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        let expected_o3 = &self.expected_o3;
        let expected_o3x = expected_o3.clone();
        let b_p2x = b_p2.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(env_p0x.clone(), st_p1x.clone(), b_p2x.clone()), move |infer_expr_block_f_31558: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p4, st2_p5) = infer_expr_block_f_31558;
            match &expected_o3x {
                Some(r_p6) => {
                    let r_p6x = r_p6.clone();
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p5.clone(), r_p6x.clone(), t_p4.clone(), b_p2x.span_p.clone()), move |unify_f_31624: crate::check::types::St| prism_rtl::Turn::Finished((r_p6x.clone(), unify_f_31624)))
                },
                None => prism_rtl::Turn::Finished((t_p4.clone(), st2_p5.clone())),
            }
        })
    }
}

/// `Start InferBodyBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_body_block_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block, expected_o3: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferBodyBlock { env_p0, st_p1, b_p2, expected_o3 })
}
