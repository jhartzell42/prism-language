//! The module `Check.Expr.Calls`, from `target/bootstrap/src/prismc/check/expr/calls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `Peeled`:
///
/// ```prism
/// type Peeled = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Peeled {
    pub events_p: crate::prelude::Array<crate::syntax::Range>,
    pub dyns_p: crate::prelude::Array<crate::syntax::Range>,
    pub opts_p: crate::prelude::Array<crate::prelude::Text>,
    pub opt_args_p: crate::prelude::Array<crate::syntax::Range>,
    pub lifted_p: crate::prelude::Text,
    pub broken_p: bool,
}

impl crate::prelude::Show for Peeled {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Peeled", &[("events", &self.events_p), ("dyns", &self.dyns_p), ("opts", &self.opts_p), ("optArgs", &self.opt_args_p), ("lifted", &self.lifted_p), ("broken", &self.broken_p)]);
    }
}

impl crate::prelude::ToPod for Peeled {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Peeled", vec![("events", self.events_p.to_pod()), ("dyns", self.dyns_p.to_pod()), ("opts", self.opts_p.to_pod()), ("optArgs", self.opt_args_p.to_pod()), ("lifted", self.lifted_p.to_pod()), ("broken", self.broken_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Peeled {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Peeled { events_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "events")?)?, dyns_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "dyns")?)?, opts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "opts")?)?, opt_args_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "optArgs")?)?, lifted_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lifted")?)?, broken_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "broken")?)? })
    }
}

/// ```prism
/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
/// ```
pub fn infer_call_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, callee_p2: &crate::syntax::Expr, args_p3: &crate::prelude::Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*callee_p2.kind_p {
        crate::syntax::ExprKind::EName(n_p5) => {
            let local_p6 = crate::check::env::sname_key_f(n_p5);
            match crate::prelude::get(&env_p0.locals_p, &local_p6) {
                ::std::option::Option::Some(sc_p7) => {
                    let st1_p8 = match crate::prelude::get(&env_p0.ids_p, &local_p6) {
                        ::std::option::Option::Some(id_p9) => crate::check::types::recording::note_use_f(st_p1, &callee_p2.span_p, &id_p9, &local_p6),
                        ::std::option::Option::None => st_p1.clone(),
                    };
                    let (t_pa, st2_pb) = crate::check::expr::instantiate_local_f(&st1_p8, &sc_p7, &callee_p2.span_p, &local_p6);
                    apply_fn_f(env_p0, &crate::check::types::recording::note_ty_f(&st2_pb, &callee_p2.span_p, &t_pa), &local_p6, &t_pa, &positional_f(args_p3), span_p4)
                },
                ::std::option::Option::None => call_global_f(env_p0, st_p1, n_p5, args_p3, span_p4, &crate::prelude::Array::new(), &callee_p2.span_p),
            }
        },
        crate::syntax::ExprKind::ETypeArgs(target_pc, tys_pd) => match &*target_pc.kind_p {
            crate::syntax::ExprKind::EName(n_pe) => {
                let cx_pf = crate::check::expr::env_cx_f(env_p0);
                let (given2_pg, st2_ph) = crate::check::env::reading::conv_types_f(&cx_pf, st_p1, tys_pd);
                call_global_f(env_p0, &st2_ph, n_pe, args_p3, span_p4, &given2_pg, &callee_p2.span_p)
            },
            _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &callee_p2.span_p, &crate::prelude::Text::lit("`<<T>>` applies to a function\'s name"))),
        },
        crate::syntax::ExprKind::EGroup(x_pi) => infer_call_f(env_p0, st_p1, &**x_pi, args_p3, span_p4),
        _ => {
            let (t_pj, st2_pk) = crate::check::expr::infer_f(env_p0, st_p1, callee_p2);
            apply_fn_f(env_p0, &st2_pk, &crate::check::expr::src_text_f(env_p0, &callee_p2.span_p), &t_pj, &positional_f(args_p3), span_p4)
        },
    }
}

/// The step machine of `InferCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
/// ```
pub struct InferCall {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub callee_p2: crate::syntax::Expr,
    pub args_p3: crate::prelude::Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferCall {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let callee_p2 = &self.callee_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        match &*callee_p2.kind_p {
            crate::syntax::ExprKind::EName(n_p5) => {
                let local_p6 = crate::check::env::sname_key_f(n_p5);
                match crate::prelude::get(&env_p0.locals_p, &local_p6) {
                    ::std::option::Option::Some(sc_p7) => {
                        let st1_p8 = match crate::prelude::get(&env_p0.ids_p, &local_p6) {
                            ::std::option::Option::Some(id_p9) => crate::check::types::recording::note_use_f(st_p1, &callee_p2.span_p, &id_p9, &local_p6),
                            ::std::option::Option::None => st_p1.clone(),
                        };
                        let args_p3x = args_p3.clone();
                        let callee_p2x = callee_p2.clone();
                        let env_p0x = env_p0.clone();
                        let span_p4x = span_p4.clone();
                        crate::prelude::call_then(crate::check::expr::start_instantiate_local_f(st1_p8.clone(), sc_p7.clone(), callee_p2x.span_p.clone(), local_p6.clone()), move |instantiate_local_f_1628: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_pa, st2_pb) = instantiate_local_f_1628;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ApplyFn { env_p0: env_p0x.clone(), st_p1: crate::check::types::recording::note_ty_f(&st2_pb, &callee_p2x.span_p, &t_pa), fname_p2: local_p6.clone(), fty_p3: t_pa.clone(), args_p4: positional_f(&args_p3x), span_p5: span_p4x.clone() }))
                        })
                    },
                    ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(CallGlobal { env_p0: env_p0.clone(), st0_p1: st_p1.clone(), n_p2: n_p5.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone(), explicit_p5: crate::prelude::Array::new(), cspan_p6: callee_p2.span_p.clone() })),
                }
            },
            crate::syntax::ExprKind::ETypeArgs(target_pc, tys_pd) => match &*target_pc.kind_p {
                crate::syntax::ExprKind::EName(n_pe) => {
                    let cx_pf = crate::check::expr::env_cx_f(env_p0);
                    let args_p3x = args_p3.clone();
                    let callee_p2x = callee_p2.clone();
                    let env_p0x = env_p0.clone();
                    let n_pex = n_pe.clone();
                    let span_p4x = span_p4.clone();
                    let st_p1x = st_p1.clone();
                    let tys_pdx = tys_pd.clone();
                    crate::prelude::call_then(crate::check::env::reading::start_conv_types_f(cx_pf.clone(), st_p1x.clone(), tys_pdx.clone()), move |conv_types_f_1964: (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)| {
                        let (given2_pg, st2_ph) = conv_types_f_1964;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(CallGlobal { env_p0: env_p0x.clone(), st0_p1: st2_ph.clone(), n_p2: n_pex.clone(), args_p3: args_p3x.clone(), span_p4: span_p4x.clone(), explicit_p5: given2_pg.clone(), cspan_p6: callee_p2x.span_p.clone() }))
                    })
                },
                _ => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &callee_p2.span_p, &crate::prelude::Text::lit("`<<T>>` applies to a function\'s name")))),
            },
            crate::syntax::ExprKind::EGroup(x_pi) => ::prism_rtl::Turn::More(::std::rc::Rc::new(InferCall { env_p0: env_p0.clone(), st_p1: st_p1.clone(), callee_p2: (**x_pi).clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone() })),
            _ => {
                let args_p3x = args_p3.clone();
                let callee_p2x = callee_p2.clone();
                let env_p0x = env_p0.clone();
                let span_p4x = span_p4.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), callee_p2x.clone()), move |infer_f_2245: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pj, st2_pk) = infer_f_2245;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ApplyFn { env_p0: env_p0x.clone(), st_p1: st2_pk.clone(), fname_p2: crate::check::expr::src_text_f(&env_p0x, &callee_p2x.span_p), fty_p3: t_pj.clone(), args_p4: positional_f(&args_p3x), span_p5: span_p4x.clone() }))
                })
            },
        }
    }
}

/// `Start InferCall, x`: what the function value is when passed to `@Run`.
pub fn start_infer_call_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, callee_p2: crate::syntax::Expr, args_p3: crate::prelude::Array<crate::syntax::Arg>, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferCall { env_p0, st_p1, callee_p2, args_p3, span_p4 })
}

/// ```prism
/// Positional: fn [Arg] -> [Arg]
/// ```
pub fn positional_f(args_p0: &crate::prelude::Array<crate::syntax::Arg>) -> crate::prelude::Array<crate::syntax::Arg> {
    args_p0.clone()
}

/// ```prism
/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
/// ```
pub fn call_global_f(env_p0: &crate::check::expr::Env, st0_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, args_p3: &crate::prelude::Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range, explicit_p5: &crate::prelude::Array<crate::check::types::Ty>, cspan_p6: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (qk_oa, why_pb) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p2);
    let name_p7 = crate::check::env::sname_key_f(n_p2);
    let st1_p8 = crate::check::expr::collision_at_f(env_p0, st0_p1, &why_pb, &name_p7, &n_p2.span_p);
    let st_p9 = match &qk_oa {
        ::std::option::Option::Some(qk_pc) => crate::check::types::recording::note_global_f(&st1_p8, &n_p2.span_p, &(if &why_pb == &crate::prelude::Text::lit("answer") {
            crate::check::env::names::answer_tag_f(qk_pc)
        } else {
            qk_pc.clone()
        })),
        ::std::option::Option::None => st1_p8.clone(),
    };
    match &qk_oa {
        ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p9, &crate::prelude::Text::lit("unknown-name"), &n_p2.span_p, &crate::prelude::Text::from(format!("nothing declares `{}` here", &name_p7)))),
        ::std::option::Option::Some(qk_pd) => if &why_pb == &crate::prelude::Text::lit("tag") {
            tag_app_f(env_p0, &st_p9, qk_pd, args_p3, span_p4, cspan_p6)
        } else {
            if &why_pb == &crate::prelude::Text::lit("answer") {
                {
                    let (t_pe, st2_pf) = crate::check::expr::answer_constructor_f(env_p0, &st_p9, &crate::check::env::names::answer_tag_f(qk_pd), &n_p2.span_p);
                    apply_fn_f(env_p0, &note_callee_f(&st2_pf, &n_p2.span_p, cspan_p6, &t_pe), &name_p7, &t_pe, args_p3, span_p4)
                }
            } else {
                if is_local_maker_f(qk_pd) && !env_p0.in_update_p {
                    (crate::check::types::Ty::TyErr, local_outside_f(&st_p9, qk_pd, span_p4))
                } else {
                    match crate::prelude::get(&env_p0.g_p.vals_p, qk_pd) {
                        ::std::option::Option::Some(v_pg) => {
                            let (t_pk, st2i_pl, inst_pm) = crate::check::types::schemes::instantiate_with_f(&st_p9, &v_pg.scheme_p, span_p4, explicit_p5);
                            let (rigids_pn, st2_po) = rank_two_f(&st2i_pl, &v_pg.scheme_p, &inst_pm, &crate::prelude::len(explicit_p5), span_p4);
                            let st2u_ph = if crate::check::expr::is_generic_use_f(&v_pg) {
                                crate::check::types::recording::note_generic_use_f(&st2_po, qk_pd, &v_pg.scheme_p.qs_p, &n_p2.span_p, &inst_pm)
                            } else {
                                st2_po.clone()
                            };
                            let st3a_pi = note_callee_f(&note_method_use_f(&st2u_ph, &v_pg, span_p4), &n_p2.span_p, cspan_p6, &t_pk);
                            let st3_pj = if &crate::check::types::bare_name_f(qk_pd) == &crate::prelude::Text::lit("Min") {
                                crate::check::types::recording::note_size_ty_f(&st3a_pi, span_p4, &crate::check::types::recording::walk_f(&st3a_pi, &t_pk))
                            } else {
                                st3a_pi.clone()
                            };
                            if (&crate::check::types::bare_name_f(qk_pd) == &crate::prelude::Text::lit("Fold")) && (&v_pg.home_p == &crate::prelude::Text::lit("Prelude")) {
                                fold_app_f(env_p0, &st3_pj, &t_pk, args_p3, span_p4)
                            } else {
                                {
                                    let (rt_pp, st4_pq) = apply_fn_f(env_p0, &st3_pj, &name_p7, &t_pk, args_p3, span_p4);
                                    (rt_pp.clone(), escaped_f(env_p0, &st4_pq, &rigids_pn, &rt_pp, &name_p7, span_p4))
                                }
                            }
                        },
                        ::std::option::Option::None => match crate::prelude::get(&env_p0.g_p.ctors_p, qk_pd) {
                            ::std::option::Option::Some(c_pr) => ctor_app_f(env_p0, &st_p9, &c_pr, args_p3, span_p4, cspan_p6),
                            ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p9, &crate::prelude::Text::lit("unknown-name"), &n_p2.span_p, &crate::prelude::Text::from(format!("`{}` has no signature line", &name_p7)))),
                        },
                    }
                }
            }
        },
    }
}

/// The step machine of `CallGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
/// ```
pub struct CallGlobal {
    pub env_p0: crate::check::expr::Env,
    pub st0_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub args_p3: crate::prelude::Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
    pub explicit_p5: crate::prelude::Array<crate::check::types::Ty>,
    pub cspan_p6: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for CallGlobal {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st0_p1 = &self.st0_p1;
        let n_p2 = &self.n_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let explicit_p5 = &self.explicit_p5;
        let cspan_p6 = &self.cspan_p6;
        let (qk_oa, why_pb) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p2);
        let name_p7 = crate::check::env::sname_key_f(n_p2);
        let st1_p8 = crate::check::expr::collision_at_f(env_p0, st0_p1, &why_pb, &name_p7, &n_p2.span_p);
        let st_p9 = match &qk_oa {
            ::std::option::Option::Some(qk_pc) => crate::check::types::recording::note_global_f(&st1_p8, &n_p2.span_p, &(if &why_pb == &crate::prelude::Text::lit("answer") {
                crate::check::env::names::answer_tag_f(qk_pc)
            } else {
                qk_pc.clone()
            })),
            ::std::option::Option::None => st1_p8.clone(),
        };
        match &qk_oa {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p9, &crate::prelude::Text::lit("unknown-name"), &n_p2.span_p, &crate::prelude::Text::from(format!("nothing declares `{}` here", &name_p7))))),
            ::std::option::Option::Some(qk_pd) => if &why_pb == &crate::prelude::Text::lit("tag") {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TagApp { env_p0: env_p0.clone(), st_p1: st_p9.clone(), name_p2: qk_pd.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone(), cspan_p5: cspan_p6.clone() }))
            } else {
                if &why_pb == &crate::prelude::Text::lit("answer") {
                    {
                        let args_p3x = args_p3.clone();
                        let cspan_p6x = cspan_p6.clone();
                        let env_p0x = env_p0.clone();
                        let n_p2x = n_p2.clone();
                        let qk_pdx = qk_pd.clone();
                        let span_p4x = span_p4.clone();
                        crate::prelude::call_then(crate::check::expr::start_answer_constructor_f(env_p0x.clone(), st_p9.clone(), crate::check::env::names::answer_tag_f(&qk_pdx), n_p2x.span_p.clone()), move |answer_constructor_f_3059: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_pe, st2_pf) = answer_constructor_f_3059;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ApplyFn { env_p0: env_p0x.clone(), st_p1: note_callee_f(&st2_pf, &n_p2x.span_p, &cspan_p6x, &t_pe), fname_p2: name_p7.clone(), fty_p3: t_pe.clone(), args_p4: args_p3x.clone(), span_p5: span_p4x.clone() }))
                        })
                    }
                } else {
                    if is_local_maker_f(qk_pd) && !env_p0.in_update_p {
                        ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, local_outside_f(&st_p9, qk_pd, span_p4)))
                    } else {
                        match crate::prelude::get(&env_p0.g_p.vals_p, qk_pd) {
                            ::std::option::Option::Some(v_pg) => {
                                let args_p3x = args_p3.clone();
                                let cspan_p6x = cspan_p6.clone();
                                let env_p0x = env_p0.clone();
                                let explicit_p5x = explicit_p5.clone();
                                let n_p2x = n_p2.clone();
                                let qk_pdx = qk_pd.clone();
                                let span_p4x = span_p4.clone();
                                crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p9.clone(), v_pg.scheme_p.clone(), span_p4x.clone(), explicit_p5x.clone()), move |instantiate_with_f_3399: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                                    let (t_pk, st2i_pl, inst_pm) = instantiate_with_f_3399;
                                    crate::prelude::call_then(start_rank_two_f(st2i_pl.clone(), v_pg.scheme_p.clone(), inst_pm.clone(), crate::prelude::len(&explicit_p5x), span_p4x.clone()), move |rank_two_f_3486: (crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)| {
                                        let (rigids_pn, st2_po) = rank_two_f_3486;
                                        let st2u_ph = if crate::check::expr::is_generic_use_f(&v_pg) {
                                            crate::check::types::recording::note_generic_use_f(&st2_po, &qk_pdx, &v_pg.scheme_p.qs_p, &n_p2x.span_p, &inst_pm)
                                        } else {
                                            st2_po.clone()
                                        };
                                        let st3a_pi = note_callee_f(&note_method_use_f(&st2u_ph, &v_pg, &span_p4x), &n_p2x.span_p, &cspan_p6x, &t_pk);
                                        let qk_oaz = qk_oa.clone();
                                        let args_p3xz = args_p3x.clone();
                                        let env_p0xz = env_p0x.clone();
                                        let name_p7z = name_p7.clone();
                                        let qk_pdxz = qk_pdx.clone();
                                        let rigids_pnz = rigids_pn.clone();
                                        let span_p4xz = span_p4x.clone();
                                        let t_pkz = t_pk.clone();
                                        let v_pgz = v_pg.clone();
                                        let k_let3757 = move |v3757: crate::check::types::St| {
                                            let st3_pj = v3757;
                                            if (&crate::check::types::bare_name_f(&qk_pdxz) == &crate::prelude::Text::lit("Fold")) && (&v_pgz.home_p == &crate::prelude::Text::lit("Prelude")) {
                                                ::prism_rtl::Turn::More(::std::rc::Rc::new(FoldApp { env_p0: env_p0xz.clone(), st_p1: st3_pj.clone(), t_p2: t_pkz.clone(), args_p3: args_p3xz.clone(), span_p4: span_p4xz.clone() }))
                                            } else {
                                                crate::prelude::call_then(start_apply_fn_f(env_p0xz.clone(), st3_pj.clone(), name_p7z.clone(), t_pkz.clone(), args_p3xz.clone(), span_p4xz.clone()), move |apply_fn_f_4015: (crate::check::types::Ty, crate::check::types::St)| {
                                                    let (rt_pp, st4_pq) = apply_fn_f_4015;
                                                    crate::prelude::call_then(start_escaped_f(env_p0xz.clone(), st4_pq.clone(), rigids_pnz.clone(), rt_pp.clone(), name_p7z.clone(), span_p4xz.clone()), move |escaped_f_4084: crate::check::types::St| ::prism_rtl::Turn::Finished((rt_pp.clone(), escaped_f_4084)))
                                                })
                                            }
                                        };
                                        if &crate::check::types::bare_name_f(&qk_pdx) == &crate::prelude::Text::lit("Min") {
                                            crate::prelude::call_then(crate::check::types::recording::start_walk_f(st3a_pi.clone(), t_pk.clone()), move |walk_f_3818: crate::check::types::Ty| k_let3757(crate::check::types::recording::note_size_ty_f(&st3a_pi, &span_p4x, &walk_f_3818)))
                                        } else {
                                            k_let3757(st3a_pi.clone())
                                        }
                                    })
                                })
                            },
                            ::std::option::Option::None => match crate::prelude::get(&env_p0.g_p.ctors_p, qk_pd) {
                                ::std::option::Option::Some(c_pr) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CtorApp { env_p0: env_p0.clone(), st_p1: st_p9.clone(), c_p2: c_pr.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone(), cspan_p5: cspan_p6.clone() })),
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p9, &crate::prelude::Text::lit("unknown-name"), &n_p2.span_p, &crate::prelude::Text::from(format!("`{}` has no signature line", &name_p7))))),
                            },
                        }
                    }
                }
            },
        }
    }
}

/// `Start CallGlobal, x`: what the function value is when passed to `@Run`.
pub fn start_call_global_f(env_p0: crate::check::expr::Env, st0_p1: crate::check::types::St, n_p2: crate::syntax::SName, args_p3: crate::prelude::Array<crate::syntax::Arg>, span_p4: crate::syntax::Range, explicit_p5: crate::prelude::Array<crate::check::types::Ty>, cspan_p6: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(CallGlobal { env_p0, st0_p1, n_p2, args_p3, span_p4, explicit_p5, cspan_p6 })
}

/// ```prism
/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
/// ```
pub fn rank_two_f(st_p0: &crate::check::types::St, sc_p1: &crate::check::types::Scheme, inst_p2: &crate::check::types::schemes::Inst, n_explicit_p3: &crate::prelude::Nat, span_p4: &crate::syntax::Range) -> (crate::prelude::Array<crate::prelude::Text>, crate::check::types::St) {
    let qs_p5 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(&sc_p1.qs_p)), &(|i_p6: &crate::prelude::Nat| (i_p6 >= n_explicit_p3) && is_rank_two_f(&crate::prelude::or(&crate::prelude::index(&sc_p1.qs_p, i_p6), &crate::prelude::Text::lit("")), &sc_p1.ty_p)));
    crate::prelude::run_to_end(crate::prelude::fold_job(qs_p5.clone(), (crate::prelude::Array::new(), st_p0.clone()), {
        let sc_p1x = sc_p1.clone();
        let inst_p2x = inst_p2.clone();
        let span_p4x = span_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), crate::prelude::Nat)| {
            let sc_p1xy = sc_p1x.clone();
            let inst_p2xy = inst_p2x.clone();
            let span_p4xy = span_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p7, s_p8) = p0;
                let i_p9 = p1;
                {
                    let q_pa = crate::prelude::or(&crate::prelude::index(&sc_p1xy.qs_p, &i_p9), &crate::prelude::Text::lit(""));
                    let rigid_pb = crate::prelude::Text::from(format!("{}\'{}", &q_pa, &s_p8.next_p));
                    let s2_pc = {
                        let mut this: crate::check::types::St = s_p8.clone();
                        this.next_p = &this.next_p + &crate::prelude::Nat::from(1u32);
                        this
                    };
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(s2_pc.clone(), crate::prelude::or(&crate::prelude::get(&inst_p2xy.tys_p, &q_pa), &crate::check::types::Ty::TyErr), crate::check::types::Ty::TyRigid(rigid_pb.clone()), span_p4xy.clone()), move |unify_f_5163: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p7, &rigid_pb), unify_f_5163)))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)>>>
    }))
}

/// The step machine of `RankTwo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
/// ```
pub struct RankTwo {
    pub st_p0: crate::check::types::St,
    pub sc_p1: crate::check::types::Scheme,
    pub inst_p2: crate::check::types::schemes::Inst,
    pub n_explicit_p3: crate::prelude::Nat,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)> for RankTwo {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let sc_p1 = &self.sc_p1;
        let inst_p2 = &self.inst_p2;
        let n_explicit_p3 = &self.n_explicit_p3;
        let span_p4 = &self.span_p4;
        let qs_p5 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(&sc_p1.qs_p)), &(|i_p6: &crate::prelude::Nat| (i_p6 >= n_explicit_p3) && is_rank_two_f(&crate::prelude::or(&crate::prelude::index(&sc_p1.qs_p, i_p6), &crate::prelude::Text::lit("")), &sc_p1.ty_p)));
        crate::prelude::fold_job(qs_p5.clone(), (crate::prelude::Array::new(), st_p0.clone()), {
            let sc_p1x = sc_p1.clone();
            let inst_p2x = inst_p2.clone();
            let span_p4x = span_p4.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), crate::prelude::Nat)| {
                let sc_p1xy = sc_p1x.clone();
                let inst_p2xy = inst_p2x.clone();
                let span_p4xy = span_p4x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p7, s_p8) = p0;
                    let i_p9 = p1;
                    {
                        let q_pa = crate::prelude::or(&crate::prelude::index(&sc_p1xy.qs_p, &i_p9), &crate::prelude::Text::lit(""));
                        let rigid_pb = crate::prelude::Text::from(format!("{}\'{}", &q_pa, &s_p8.next_p));
                        let s2_pc = {
                            let mut this: crate::check::types::St = s_p8.clone();
                            this.next_p = &this.next_p + &crate::prelude::Nat::from(1u32);
                            this
                        };
                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(s2_pc.clone(), crate::prelude::or(&crate::prelude::get(&inst_p2xy.tys_p, &q_pa), &crate::check::types::Ty::TyErr), crate::check::types::Ty::TyRigid(rigid_pb.clone()), span_p4xy.clone()), move |unify_f_5163: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p7, &rigid_pb), unify_f_5163)))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start RankTwo, x`: what the function value is when passed to `@Run`.
pub fn start_rank_two_f(st_p0: crate::check::types::St, sc_p1: crate::check::types::Scheme, inst_p2: crate::check::types::schemes::Inst, n_explicit_p3: crate::prelude::Nat, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)>> {
    ::std::rc::Rc::new(RankTwo { st_p0, sc_p1, inst_p2, n_explicit_p3, span_p4 })
}

/// ```prism
/// IsRankTwo: fn Text, Ty -> Bool
/// ```
pub fn is_rank_two_f(q_p0: &crate::prelude::Text, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyFn(_, ps_p2, res_p3) => {
            let holding_p4 = crate::prelude::filter(ps_p2, &(|p_p5: &crate::check::types::Ty| qoccurs_f(q_p0, p_p5)));
            if (&crate::prelude::len(&holding_p4) != &crate::prelude::Nat::from(1u32)) || qoccurs_f(q_p0, &**res_p3) {
                false
            } else {
                match crate::prelude::index(&holding_p4, &crate::prelude::Nat::from(0u32)) {
                    ::std::option::Option::Some(crate::check::types::Ty::TyFn(_, _, _)) => elem_out_q_f(q_p0, &crate::prelude::or(&crate::prelude::index(&holding_p4, &crate::prelude::Nat::from(0u32)), &crate::check::types::Ty::TyErr)),
                    _ => false,
                }
            }
        },
        _ => false,
    }
}

/// ```prism
/// QOccurs: fn Text, Ty -> Bool
/// ```
pub fn qoccurs_f(q_p0: &crate::prelude::Text, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyQ(n_p2) => n_p2 == q_p0,
        crate::check::types::Ty::TyCon(_, args_p3) => crate::prelude::fold(args_p3, &false, &(|seen_p4: &bool, a_p5: &crate::check::types::Ty| *seen_p4 || qoccurs_f(q_p0, a_p5))),
        crate::check::types::Ty::TyFn(_, ps_p6, r_p7) => crate::prelude::fold(ps_p6, &qoccurs_f(q_p0, &**r_p7), &(|seen_p8: &bool, a_p9: &crate::check::types::Ty| *seen_p8 || qoccurs_f(q_p0, a_p9))),
        crate::check::types::Ty::TyTuple(ts_pa) => crate::prelude::fold(ts_pa, &false, &(|seen_pb: &bool, a_pc: &crate::check::types::Ty| *seen_pb || qoccurs_f(q_p0, a_pc))),
        crate::check::types::Ty::TyArray(e_pd) => qoccurs_f(q_p0, &**e_pd),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => qoccurs_f(q_p0, &**k_pe) || qoccurs_f(q_p0, &**v_pf),
        crate::check::types::Ty::TySig(_, i_pg) => qoccurs_f(q_p0, &**i_pg),
        crate::check::types::Ty::TyAt(i_ph, _) => qoccurs_f(q_p0, &**i_ph),
        crate::check::types::Ty::TyElem(_, o_pi) => qoccurs_f(q_p0, &**o_pi),
        crate::check::types::Ty::TyAssoc(_, _, i_pj) => qoccurs_f(q_p0, &**i_pj),
        _ => false,
    }
}

/// ```prism
/// ElemOutQ: fn Text, Ty -> Bool
/// ```
pub fn elem_out_q_f(q_p0: &crate::prelude::Text, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyElem(_, o_p2) => (&**o_p2 == &crate::check::types::Ty::TyQ(q_p0.clone())) || elem_out_q_f(q_p0, &**o_p2),
        crate::check::types::Ty::TyCon(_, args_p3) => crate::prelude::fold(args_p3, &false, &(|seen_p4: &bool, a_p5: &crate::check::types::Ty| *seen_p4 || elem_out_q_f(q_p0, a_p5))),
        crate::check::types::Ty::TyFn(_, ps_p6, r_p7) => crate::prelude::fold(ps_p6, &elem_out_q_f(q_p0, &**r_p7), &(|seen_p8: &bool, a_p9: &crate::check::types::Ty| *seen_p8 || elem_out_q_f(q_p0, a_p9))),
        crate::check::types::Ty::TyTuple(ts_pa) => crate::prelude::fold(ts_pa, &false, &(|seen_pb: &bool, a_pc: &crate::check::types::Ty| *seen_pb || elem_out_q_f(q_p0, a_pc))),
        crate::check::types::Ty::TyArray(e_pd) => elem_out_q_f(q_p0, &**e_pd),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => elem_out_q_f(q_p0, &**k_pe) || elem_out_q_f(q_p0, &**v_pf),
        crate::check::types::Ty::TySig(_, i_pg) => elem_out_q_f(q_p0, &**i_pg),
        crate::check::types::Ty::TyAt(i_ph, _) => elem_out_q_f(q_p0, &**i_ph),
        _ => false,
    }
}

/// ```prism
/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
/// ```
pub fn escaped_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, rigids_p2: &crate::prelude::Array<crate::prelude::Text>, rt_p3: &crate::check::types::Ty, fname_p4: &crate::prelude::Text, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    crate::prelude::run_to_end(crate::prelude::fold_job(rigids_p2.clone(), st_p1.clone(), {
        let env_p0x = env_p0.clone();
        let rt_p3x = rt_p3.clone();
        let span_p5x = span_p5.clone();
        let fname_p4x = fname_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
            let env_p0xy = env_p0x.clone();
            let rt_p3xy = rt_p3x.clone();
            let span_p5xy = span_p5x.clone();
            let fname_p4xy = fname_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p6 = p0;
                let r_p7 = p1;
                crate::prelude::call_value(crate::prelude::filter_job(crate::prelude::keys(&env_p0xy.locals_p), {
                    let s_p6x = s_p6.clone();
                    let r_p7x = r_p7.clone();
                    let env_p0xyx = env_p0xy.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                        let s_p6xy = s_p6x.clone();
                        let r_p7xy = r_p7x.clone();
                        let env_p0xyxy = env_p0xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let k_p9 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(HasRigid { st_p0: s_p6xy.clone(), r_p1: r_p7xy.clone(), t_p2: crate::prelude::or(&crate::prelude::get(&env_p0xyxy.locals_p, &k_p9), &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)).ty_p.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }), move |filter_7134: crate::prelude::Array<crate::prelude::Text>| {
                    let outside_p8 = filter_7134;
                    crate::prelude::call_then(start_has_rigid_f(s_p6.clone(), r_p7.clone(), rt_p3xy.clone()), move |has_rigid_f_7223: bool| if has_rigid_f_7223 {
                        ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_p6, &crate::prelude::Text::lit("refinement-escape"), &span_p5xy, &crate::prelude::Text::from(format!("the call\'s result takes the output of the element `{}`\'s supplier answers, which is the supplier\'s alone (rank-2)", &fname_p4xy))))
                    } else {
                        match crate::prelude::index(&outside_p8, &crate::prelude::Nat::from(0u32)) {
                            ::std::option::Option::Some(k_pa) => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_p6, &crate::prelude::Text::lit("refinement-escape"), &span_p5xy, &crate::prelude::Text::from(format!("`{}`, outside the supplier `{}` is given, takes the output of the element the supplier answers, which is the supplier\'s alone (rank-2)", &k_pa, &fname_p4xy)))),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p6.clone()),
                        }
                    })
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `Escaped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
/// ```
pub struct Escaped {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub rigids_p2: crate::prelude::Array<crate::prelude::Text>,
    pub rt_p3: crate::check::types::Ty,
    pub fname_p4: crate::prelude::Text,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for Escaped {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let rigids_p2 = &self.rigids_p2;
        let rt_p3 = &self.rt_p3;
        let fname_p4 = &self.fname_p4;
        let span_p5 = &self.span_p5;
        crate::prelude::fold_job(rigids_p2.clone(), st_p1.clone(), {
            let env_p0x = env_p0.clone();
            let rt_p3x = rt_p3.clone();
            let span_p5x = span_p5.clone();
            let fname_p4x = fname_p4.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Text)| {
                let env_p0xy = env_p0x.clone();
                let rt_p3xy = rt_p3x.clone();
                let span_p5xy = span_p5x.clone();
                let fname_p4xy = fname_p4x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p6 = p0;
                    let r_p7 = p1;
                    crate::prelude::call_value(crate::prelude::filter_job(crate::prelude::keys(&env_p0xy.locals_p), {
                        let s_p6x = s_p6.clone();
                        let r_p7x = r_p7.clone();
                        let env_p0xyx = env_p0xy.clone();
                        ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                            let s_p6xy = s_p6x.clone();
                            let r_p7xy = r_p7x.clone();
                            let env_p0xyxy = env_p0xyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let k_p9 = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(HasRigid { st_p0: s_p6xy.clone(), r_p1: r_p7xy.clone(), t_p2: crate::prelude::or(&crate::prelude::get(&env_p0xyxy.locals_p, &k_p9), &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)).ty_p.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    }), move |filter_7134: crate::prelude::Array<crate::prelude::Text>| {
                        let outside_p8 = filter_7134;
                        crate::prelude::call_then(start_has_rigid_f(s_p6.clone(), r_p7.clone(), rt_p3xy.clone()), move |has_rigid_f_7223: bool| if has_rigid_f_7223 {
                            ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_p6, &crate::prelude::Text::lit("refinement-escape"), &span_p5xy, &crate::prelude::Text::from(format!("the call\'s result takes the output of the element `{}`\'s supplier answers, which is the supplier\'s alone (rank-2)", &fname_p4xy))))
                        } else {
                            match crate::prelude::index(&outside_p8, &crate::prelude::Nat::from(0u32)) {
                                ::std::option::Option::Some(k_pa) => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_p6, &crate::prelude::Text::lit("refinement-escape"), &span_p5xy, &crate::prelude::Text::from(format!("`{}`, outside the supplier `{}` is given, takes the output of the element the supplier answers, which is the supplier\'s alone (rank-2)", &k_pa, &fname_p4xy)))),
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p6.clone()),
                            }
                        })
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start Escaped, x`: what the function value is when passed to `@Run`.
pub fn start_escaped_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, rigids_p2: crate::prelude::Array<crate::prelude::Text>, rt_p3: crate::check::types::Ty, fname_p4: crate::prelude::Text, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(Escaped { env_p0, st_p1, rigids_p2, rt_p3, fname_p4, span_p5 })
}

/// ```prism
/// HasRigid: unbounded fn St, Text, Ty -> Bool
/// ```
pub fn has_rigid_f(st_p0: &crate::check::types::St, r_p1: &crate::prelude::Text, t_p2: &crate::check::types::Ty) -> bool {
    rigid_in_f(r_p1, &crate::check::types::recording::zonk_f(st_p0, t_p2))
}

/// The step machine of `HasRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HasRigid: unbounded fn St, Text, Ty -> Bool
/// ```
pub struct HasRigid {
    pub st_p0: crate::check::types::St,
    pub r_p1: crate::prelude::Text,
    pub t_p2: crate::check::types::Ty,
}

impl ::prism_rtl::Job<bool> for HasRigid {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let r_p1 = &self.r_p1;
        let t_p2 = &self.t_p2;
        let r_p1x = r_p1.clone();
        let st_p0x = st_p0.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x.clone(), t_p2x.clone()), move |zonk_f_7710: crate::check::types::Ty| ::prism_rtl::Turn::Finished(rigid_in_f(&r_p1x, &zonk_f_7710)))
    }
}

/// `Start HasRigid, x`: what the function value is when passed to `@Run`.
pub fn start_has_rigid_f(st_p0: crate::check::types::St, r_p1: crate::prelude::Text, t_p2: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(HasRigid { st_p0, r_p1, t_p2 })
}

/// ```prism
/// RigidIn: fn Text, Ty -> Bool
/// ```
pub fn rigid_in_f(r_p0: &crate::prelude::Text, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyRigid(n_p2) => n_p2 == r_p0,
        crate::check::types::Ty::TyCon(_, args_p3) => crate::prelude::fold(args_p3, &false, &(|seen_p4: &bool, a_p5: &crate::check::types::Ty| *seen_p4 || rigid_in_f(r_p0, a_p5))),
        crate::check::types::Ty::TyFn(_, ps_p6, res_p7) => crate::prelude::fold(ps_p6, &rigid_in_f(r_p0, &**res_p7), &(|seen_p8: &bool, a_p9: &crate::check::types::Ty| *seen_p8 || rigid_in_f(r_p0, a_p9))),
        crate::check::types::Ty::TyTuple(ts_pa) => crate::prelude::fold(ts_pa, &false, &(|seen_pb: &bool, a_pc: &crate::check::types::Ty| *seen_pb || rigid_in_f(r_p0, a_pc))),
        crate::check::types::Ty::TyArray(e_pd) => rigid_in_f(r_p0, &**e_pd),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => rigid_in_f(r_p0, &**k_pe) || rigid_in_f(r_p0, &**v_pf),
        crate::check::types::Ty::TySig(_, i_pg) => rigid_in_f(r_p0, &**i_pg),
        crate::check::types::Ty::TyAt(i_ph, _) => rigid_in_f(r_p0, &**i_ph),
        crate::check::types::Ty::TyElem(_, o_pi) => rigid_in_f(r_p0, &**o_pi),
        crate::check::types::Ty::TyAssoc(_, _, i_pj) => rigid_in_f(r_p0, &**i_pj),
        _ => false,
    }
}

/// ```prism
/// IsLocalMaker: fn Text -> Bool
/// ```
pub fn is_local_maker_f(qk_p0: &crate::prelude::Text) -> bool {
    crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("Buffer.Numbered"), crate::prelude::Text::lit("Buffer.Empty"), crate::prelude::Text::lit("Table.Empty")]), qk_p0)
}

/// ```prism
/// LocalOutside: fn St, Text, Range -> St
/// ```
pub fn local_outside_f(st_p0: &crate::check::types::St, qk_p1: &crate::prelude::Text, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("local-escapes"), span_p2, &crate::prelude::Text::from(format!("a `{}` lives only in an `&` block\'s local", &crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(qk_p1, &crate::prelude::Text::lit(".")), &crate::prelude::Nat::from(0u32)), qk_p1))), &crate::prelude::Text::from(format!("make it inside `update ...:` as `let &b = {} ...`, and `Freeze &b` for the plain value", qk_p1)))
}

/// ```prism
/// NoteCallee: fn St, Range, Range, Ty -> St
/// ```
pub fn note_callee_f(st_p0: &crate::check::types::St, at_p1: &crate::syntax::Range, cspan_p2: &crate::syntax::Range, t_p3: &crate::check::types::Ty) -> crate::check::types::St {
    if at_p1 == cspan_p2 {
        crate::check::types::recording::note_ty_f(st_p0, at_p1, t_p3)
    } else {
        crate::check::types::recording::note_ty_f(&crate::check::types::recording::note_ty_f(st_p0, at_p1, t_p3), cspan_p2, t_p3)
    }
}

/// ```prism
/// NoteMethodUse: fn St, ValInfo, Range -> St
/// ```
pub fn note_method_use_f(st_p0: &crate::check::types::St, v_p1: &crate::check::env::ValInfo, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    if &v_p1.sort_p != &crate::prelude::Text::lit("method") {
        st_p0.clone()
    } else {
        {
            let (_, cls_p4) = crate::prelude::or(&crate::prelude::index(&v_p1.scheme_p.bounds_p, &crate::prelude::Nat::from(0u32)), &(crate::prelude::Text::lit(""), crate::prelude::Text::lit("")));
            let used_p3 = {
                let mut this: crate::check::types::St = st_p0.clone();
                this.method_uses_p = crate::prelude::insert(&this.method_uses_p, &crate::check::types::use_key_f(&this.file_p, span_p2), &v_p1.qk_p);
                this
            };
            crate::check::types::recording::note_method_f(&used_p3, span_p2, &v_p1.qk_p, &cls_p4)
        }
    }
}

/// ```prism
/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn fold_app_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty, args_p3: &crate::prelude::Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let lambda_arity_p5 = match crate::prelude::index(args_p3, &crate::prelude::Nat::from(2u32)) {
        ::std::option::Option::Some(a_p6) => lambda_arity_f(&a_p6.value_p),
        ::std::option::Option::None => crate::prelude::Nat::from(2u32),
    };
    if &lambda_arity_p5 == &crate::prelude::Nat::from(3u32) {
        match crate::check::types::recording::walk_f(st_p1, t_p2) {
            crate::check::types::Ty::TyFn(col_p7, params_p8, res_p9) => {
                let (k_pc, st1_pd) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                let (v_pe, st2_pf) = crate::check::types::fresh_var_f(&st1_pd, &false, &crate::prelude::Text::lit(""));
                let (b_pg, st3_ph) = crate::check::types::fresh_var_f(&st2_pf, &false, &crate::prelude::Text::lit(""));
                let step_col_pa = match crate::prelude::index(&params_p8, &crate::prelude::Nat::from(2u32)) {
                    ::std::option::Option::Some(crate::check::types::Ty::TyFn(c_pi, _, _)) => c_pi,
                    _ => col_p7.clone(),
                };
                let params2_pb = crate::prelude::Array::from(vec![crate::check::types::Ty::TyMap(::std::rc::Rc::new(k_pc.clone()), ::std::rc::Rc::new(v_pe.clone())), b_pg.clone(), crate::check::types::Ty::TyFn(step_col_pa.clone(), crate::prelude::Array::from(vec![b_pg.clone(), k_pc.clone(), v_pe.clone()]), ::std::rc::Rc::new(b_pg.clone()))]);
                apply_rule_f(env_p0, &st3_ph, &crate::prelude::Text::lit("Fold"), &col_p7, &params2_pb, &b_pg, args_p3, span_p4)
            },
            _ => apply_fn_f(env_p0, st_p1, &crate::prelude::Text::lit("Fold"), t_p2, args_p3, span_p4),
        }
    } else {
        apply_fn_f(env_p0, st_p1, &crate::prelude::Text::lit("Fold"), t_p2, args_p3, span_p4)
    }
}

/// The step machine of `FoldApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct FoldApp {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
    pub args_p3: crate::prelude::Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for FoldApp {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let lambda_arity_p5 = match crate::prelude::index(args_p3, &crate::prelude::Nat::from(2u32)) {
            ::std::option::Option::Some(a_p6) => lambda_arity_f(&a_p6.value_p),
            ::std::option::Option::None => crate::prelude::Nat::from(2u32),
        };
        if &lambda_arity_p5 == &crate::prelude::Nat::from(3u32) {
            {
                let args_p3x = args_p3.clone();
                let env_p0x = env_p0.clone();
                let span_p4x = span_p4.clone();
                let st_p1x = st_p1.clone();
                let t_p2x = t_p2.clone();
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), t_p2x.clone()), move |walk_f_9770: crate::check::types::Ty| match walk_f_9770 {
                    crate::check::types::Ty::TyFn(col_p7, params_p8, res_p9) => {
                        let (k_pc, st1_pd) = crate::check::types::fresh_var_f(&st_p1x, &false, &crate::prelude::Text::lit(""));
                        let (v_pe, st2_pf) = crate::check::types::fresh_var_f(&st1_pd, &false, &crate::prelude::Text::lit(""));
                        let (b_pg, st3_ph) = crate::check::types::fresh_var_f(&st2_pf, &false, &crate::prelude::Text::lit(""));
                        let step_col_pa = match crate::prelude::index(&params_p8, &crate::prelude::Nat::from(2u32)) {
                            ::std::option::Option::Some(crate::check::types::Ty::TyFn(c_pi, _, _)) => c_pi,
                            _ => col_p7.clone(),
                        };
                        let params2_pb = crate::prelude::Array::from(vec![crate::check::types::Ty::TyMap(::std::rc::Rc::new(k_pc.clone()), ::std::rc::Rc::new(v_pe.clone())), b_pg.clone(), crate::check::types::Ty::TyFn(step_col_pa.clone(), crate::prelude::Array::from(vec![b_pg.clone(), k_pc.clone(), v_pe.clone()]), ::std::rc::Rc::new(b_pg.clone()))]);
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ApplyRule { env_p0: env_p0x.clone(), st_p1: st3_ph.clone(), fname_p2: crate::prelude::Text::lit("Fold"), col_p3: col_p7.clone(), params_p4: params2_pb.clone(), res_p5: b_pg.clone(), args_p6: args_p3x.clone(), span_p7: span_p4x.clone() }))
                    },
                    _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(ApplyFn { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), fname_p2: crate::prelude::Text::lit("Fold"), fty_p3: t_p2x.clone(), args_p4: args_p3x.clone(), span_p5: span_p4x.clone() })),
                })
            }
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(ApplyFn { env_p0: env_p0.clone(), st_p1: st_p1.clone(), fname_p2: crate::prelude::Text::lit("Fold"), fty_p3: t_p2.clone(), args_p4: args_p3.clone(), span_p5: span_p4.clone() }))
        }
    }
}

/// `Start FoldApp, x`: what the function value is when passed to `@Run`.
pub fn start_fold_app_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty, args_p3: crate::prelude::Array<crate::syntax::Arg>, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(FoldApp { env_p0, st_p1, t_p2, args_p3, span_p4 })
}

/// ```prism
/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn apply_fn_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fname_p2: &crate::prelude::Text, fty_p3: &crate::check::types::Ty, args_p4: &crate::prelude::Array<crate::syntax::Arg>, span_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let named_p6 = crate::prelude::filter(args_p4, &(|a_p8: &crate::syntax::Arg| &a_p8.name_o != &::std::option::Option::None));
    let st0_p7 = if &crate::prelude::len(&named_p6) > &crate::prelude::Nat::from(0u32) {
        crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p5, &crate::prelude::Text::from(format!("`{}` takes its arguments by position; named arguments are a record\'s or a tag\'s", fname_p2)))
    } else {
        st_p1.clone()
    };
    match crate::check::types::recording::walk_f(&st0_p7, fty_p3) {
        crate::check::types::Ty::TyFn(col_p9, params_pa, res_pb) => if &crate::prelude::len(&params_pa) != &crate::prelude::len(args_p4) {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st0_p7, &crate::prelude::Text::lit("mismatch"), span_p5, &crate::prelude::Text::from(format!("`{}` takes {} argument{}; here it has {}", fname_p2, &crate::check::errors::count_word_f(&crate::prelude::len(&params_pa)), &(if &crate::prelude::len(&params_pa) == &crate::prelude::Nat::from(1u32) {
                crate::prelude::Text::lit("")
            } else {
                crate::prelude::Text::lit("s")
            }), &crate::check::errors::count_word_f(&crate::prelude::len(args_p4))))))
        } else {
            apply_rule_f(env_p0, &st0_p7, fname_p2, &col_p9, &params_pa, &*res_pb, args_p4, span_p5)
        },
        crate::check::types::Ty::TyFlex(_) => {
            let (params_ph, st1_pi) = crate::prelude::fold(args_p4, &(crate::prelude::Array::new(), st0_p7.clone()), &(|(acc_pd, s_pe): &(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Arg| {
                let (v_pf, s2_pg) = crate::check::types::fresh_var_f(s_pe, &false, &crate::prelude::Text::lit(""));
                (crate::prelude::push(acc_pd, &v_pf), s2_pg.clone())
            }));
            let (res_pj, st2_pk) = crate::check::types::fresh_var_f(&st1_pi, &false, &crate::prelude::Text::lit(""));
            let (col_pl, st2b_pm) = crate::check::types::fresh_col_f(&st2_pk);
            let st3_pc = crate::check::types::unify::unify_f(&st2b_pm, fty_p3, &crate::check::types::Ty::TyFn(col_pl.clone(), params_ph.clone(), ::std::rc::Rc::new(res_pj.clone())), span_p5);
            apply_rule_f(env_p0, &st3_pc, fname_p2, &col_pl, &params_ph, &res_pj, args_p4, span_p5)
        },
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st0_p7.clone()),
        other_pn => if &crate::prelude::len(args_p4) == &crate::prelude::Nat::from(0u32) {
            (other_pn.clone(), st0_p7.clone())
        } else {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st0_p7, &crate::prelude::Text::lit("mismatch"), span_p5, &crate::prelude::Text::from(format!("`{}` is a `{}`, not a function", fname_p2, &crate::check::types::show_ty_f(&st0_p7, &other_pn)))))
        },
    }
}

/// The step machine of `ApplyFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct ApplyFn {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fname_p2: crate::prelude::Text,
    pub fty_p3: crate::check::types::Ty,
    pub args_p4: crate::prelude::Array<crate::syntax::Arg>,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ApplyFn {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fname_p2 = &self.fname_p2;
        let fty_p3 = &self.fty_p3;
        let args_p4 = &self.args_p4;
        let span_p5 = &self.span_p5;
        let named_p6 = crate::prelude::filter(args_p4, &(|a_p8: &crate::syntax::Arg| &a_p8.name_o != &::std::option::Option::None));
        let st0_p7 = if &crate::prelude::len(&named_p6) > &crate::prelude::Nat::from(0u32) {
            crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p5, &crate::prelude::Text::from(format!("`{}` takes its arguments by position; named arguments are a record\'s or a tag\'s", fname_p2)))
        } else {
            st_p1.clone()
        };
        let args_p4x = args_p4.clone();
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        let fty_p3x = fty_p3.clone();
        let span_p5x = span_p5.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st0_p7.clone(), fty_p3x.clone()), move |walk_f_10804: crate::check::types::Ty| match walk_f_10804 {
            crate::check::types::Ty::TyFn(col_p9, params_pa, res_pb) => if &crate::prelude::len(&params_pa) != &crate::prelude::len(&args_p4x) {
                ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st0_p7, &crate::prelude::Text::lit("mismatch"), &span_p5x, &crate::prelude::Text::from(format!("`{}` takes {} argument{}; here it has {}", &fname_p2x, &crate::check::errors::count_word_f(&crate::prelude::len(&params_pa)), &(if &crate::prelude::len(&params_pa) == &crate::prelude::Nat::from(1u32) {
                    crate::prelude::Text::lit("")
                } else {
                    crate::prelude::Text::lit("s")
                }), &crate::check::errors::count_word_f(&crate::prelude::len(&args_p4x)))))))
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ApplyRule { env_p0: env_p0x.clone(), st_p1: st0_p7.clone(), fname_p2: fname_p2x.clone(), col_p3: col_p9.clone(), params_p4: params_pa.clone(), res_p5: (*res_pb).clone(), args_p6: args_p4x.clone(), span_p7: span_p5x.clone() }))
            },
            crate::check::types::Ty::TyFlex(_) => {
                let (params_ph, st1_pi) = crate::prelude::fold(&args_p4x, &(crate::prelude::Array::new(), st0_p7.clone()), &(|(acc_pd, s_pe): &(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Arg| {
                    let (v_pf, s2_pg) = crate::check::types::fresh_var_f(s_pe, &false, &crate::prelude::Text::lit(""));
                    (crate::prelude::push(acc_pd, &v_pf), s2_pg.clone())
                }));
                let (res_pj, st2_pk) = crate::check::types::fresh_var_f(&st1_pi, &false, &crate::prelude::Text::lit(""));
                let (col_pl, st2b_pm) = crate::check::types::fresh_col_f(&st2_pk);
                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2b_pm.clone(), fty_p3x.clone(), crate::check::types::Ty::TyFn(col_pl.clone(), params_ph.clone(), ::std::rc::Rc::new(res_pj.clone())), span_p5x.clone()), move |unify_f_11466: crate::check::types::St| {
                    let st3_pc = unify_f_11466;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ApplyRule { env_p0: env_p0x.clone(), st_p1: st3_pc.clone(), fname_p2: fname_p2x.clone(), col_p3: col_pl.clone(), params_p4: params_ph.clone(), res_p5: res_pj.clone(), args_p6: args_p4x.clone(), span_p7: span_p5x.clone() }))
                })
            },
            crate::check::types::Ty::TyErr => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st0_p7.clone())),
            other_pn => if &crate::prelude::len(&args_p4x) == &crate::prelude::Nat::from(0u32) {
                ::prism_rtl::Turn::Finished((other_pn.clone(), st0_p7.clone()))
            } else {
                crate::prelude::call_then(crate::check::types::start_show_ty_f(st0_p7.clone(), other_pn.clone()), move |show_ty_f_11746: crate::prelude::Text| ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st0_p7, &crate::prelude::Text::lit("mismatch"), &span_p5x, &crate::prelude::Text::from(format!("`{}` is a `{}`, not a function", &fname_p2x, &show_ty_f_11746))))))
            },
        })
    }
}

/// `Start ApplyFn, x`: what the function value is when passed to `@Run`.
pub fn start_apply_fn_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fname_p2: crate::prelude::Text, fty_p3: crate::check::types::Ty, args_p4: crate::prelude::Array<crate::syntax::Arg>, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(ApplyFn { env_p0, st_p1, fname_p2, fty_p3, args_p4, span_p5 })
}

/// ```prism
/// Broken: fn Peeled, Bool -> Peeled
/// ```
pub fn broken_f(p_p0: &Peeled, b_p1: &bool) -> Peeled {
    if !*b_p1 {
        p_p0.clone()
    } else {
        {
            let mut this: Peeled = p_p0.clone();
            this.broken_p = true;
            this
        }
    }
}

/// ```prism
/// let mapLiteral
/// ```
pub fn map_literal_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("a map literal")
}

/// ```prism
/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn apply_rule_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fname_p2: &crate::prelude::Text, col_p3: &crate::check::types::Col, params_p4: &crate::prelude::Array<crate::check::types::Ty>, res_p5: &crate::check::types::Ty, args_p6: &crate::prelude::Array<crate::syntax::Arg>, span_p7: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let n_p8 = crate::prelude::len(args_p6);
    let cmp_p9 = crate::check::expr::is_comparison_f(fname_p2);
    let holds_pa = fname_p2 == &map_literal_p();
    let (inferred_p15, st1_p16) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (crate::prelude::Array::new(), st_p1.clone()), {
        let args_p6x = args_p6.clone();
        let span_p7x = span_p7.clone();
        let env_p0x = env_p0.clone();
        let params_p4x = params_p4.clone();
        let fname_p2x = fname_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)| {
            let args_p6xy = args_p6x.clone();
            let span_p7xy = span_p7x.clone();
            let env_p0xy = env_p0x.clone();
            let params_p4xy = params_p4x.clone();
            let fname_p2xy = fname_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pr, s_ps) = p0;
                let i_pt = p1;
                {
                    let a_pu = crate::prelude::or(&crate::prelude::index(&args_p6xy, &i_pt), &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xy.clone() }, span_p: span_p7xy.clone() });
                    if crate::check::expr::is_lambda_f(&a_pu.value_p) {
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pr, &crate::check::types::Ty::TyErr), s_ps.clone()))
                    } else {
                        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0xy.clone(), s_ps.clone(), a_pu.value_p.clone()), move |infer_f_13454: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_pv, s2_p10) = infer_f_13454;
                            crate::prelude::call_then(crate::check::types::recording::start_walk_f(s2_p10.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xy, &i_pt), &crate::check::types::Ty::TyErr)), move |walk_f_13497: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::recording::start_walk_f(s2_p10.clone(), t_pv.clone()), move |walk_f_13531: crate::check::types::Ty| match (walk_f_13497, walk_f_13531) {
                                (crate::check::types::Ty::TyFn(pc_p11, _, _), crate::check::types::Ty::TyFn(ac_p12, aps_p13, ar_p14)) => crate::prelude::call_then(crate::check::types::colors::start_add_leq_f(s2_p10.clone(), ac_p12.clone(), pc_p11.clone(), a_pu.value_p.span_p.clone(), crate::prelude::Text::lit("arg"), fname_p2xy.clone(), crate::prelude::Text::lit("")), move |add_leq_f_13648: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pr, &crate::check::types::Ty::TyFn(pc_p11.clone(), aps_p13.clone(), ::std::rc::Rc::new((*ar_p14).clone()))), add_leq_f_13648))),
                                _ => ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pr, &t_pv), s2_p10.clone())),
                            }))
                        })
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }));
    let arg_tys_pb = plain_beside_f(&st1_p16, params_p4, &inferred_p15);
    let st1b_pc = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), st1_p16.clone(), {
        let inferred_p15x = inferred_p15.clone();
        let arg_tys_pbx = arg_tys_pb.clone();
        let args_p6x = args_p6.clone();
        let span_p7x = span_p7.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Nat)| {
            let inferred_p15xy = inferred_p15x.clone();
            let arg_tys_pbxy = arg_tys_pbx.clone();
            let args_p6xy = args_p6x.clone();
            let span_p7xy = span_p7x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p17 = p0;
                let i_p18 = p1;
                crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(s_p17.clone(), crate::prelude::or(&crate::prelude::index(&inferred_p15xy, &i_p18), &crate::check::types::Ty::TyErr)), move |non_empty_coll_o_13974: ::std::option::Option<crate::check::types::Ty>| crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(s_p17.clone(), crate::prelude::or(&crate::prelude::index(&arg_tys_pbxy, &i_p18), &crate::check::types::Ty::TyErr)), move |non_empty_coll_o_14018: ::std::option::Option<crate::check::types::Ty>| match (non_empty_coll_o_13974, non_empty_coll_o_14018) {
                    (::std::option::Option::Some(c_p19), ::std::option::Option::None) => ::prism_rtl::Turn::Finished(crate::check::types::recording::ask_plain_at_f(&s_p17, &crate::prelude::or(&crate::prelude::index(&args_p6xy, &i_p18), &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xy.clone() }, span_p: span_p7xy.clone() }).value_p.span_p, &c_p19)),
                    _ => ::prism_rtl::Turn::Finished(s_p17.clone()),
                }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }));
    let (st2_p1h, whole_p1i) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (st1b_pc.clone(), crate::prelude::Array::new()), {
        let args_p6x = args_p6.clone();
        let span_p7x = span_p7.clone();
        let arg_tys_pbx = arg_tys_pb.clone();
        let params_p4x = params_p4.clone();
        let holds_pax = holds_pa;
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        let res_p5x = res_p5.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>), crate::prelude::Nat)| {
            let args_p6xy = args_p6x.clone();
            let span_p7xy = span_p7x.clone();
            let arg_tys_pbxy = arg_tys_pbx.clone();
            let params_p4xy = params_p4x.clone();
            let holds_paxy = holds_pax;
            let env_p0xy = env_p0x.clone();
            let fname_p2xy = fname_p2x.clone();
            let res_p5xy = res_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (s_p1a, done_p1b) = p0;
                let i_p1c = p1;
                {
                    let a_p1d = crate::prelude::or(&crate::prelude::index(&args_p6xy, &i_p1c), &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xy.clone() }, span_p: span_p7xy.clone() });
                    let at_p1e = crate::prelude::or(&crate::prelude::index(&arg_tys_pbxy, &i_p1c), &crate::check::types::Ty::TyErr);
                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p1a.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xy, &i_p1c), &crate::check::types::Ty::TyErr)), move |walk_f_14464: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::unify::start_norm_assoc_f(s_p1a.clone(), walk_f_14464), move |norm_assoc_f_14450: crate::check::types::Ty| {
                        let pnow_p1f = norm_assoc_f_14450;
                        crate::prelude::call_then(crate::check::types::start_head_sigil_f(s_p1a.clone(), pnow_p1f.clone()), move |head_sigil_f_14715: crate::prelude::Text| {
                            let a_p1dz = a_p1d.clone();
                            let at_p1ez = at_p1e.clone();
                            let done_p1bz = done_p1b.clone();
                            let env_p0xyz = env_p0xy.clone();
                            let fname_p2xyz = fname_p2xy.clone();
                            let i_p1cz = i_p1c.clone();
                            let params_p4xyz = params_p4xy.clone();
                            let pnow_p1fz = pnow_p1f.clone();
                            let res_p5xyz = res_p5xy.clone();
                            let s_p1az = s_p1a.clone();
                            let span_p7xyz = span_p7xy.clone();
                            let k_let14686 = move |v14686: bool| {
                                let whole_now_p1g = v14686;
                                if crate::check::expr::is_lambda_f(&a_p1dz.value_p) {
                                    ::prism_rtl::Turn::Finished((s_p1az.clone(), done_p1bz.clone()))
                                } else {
                                    if whole_now_p1g && (&crate::check::types::stack_of_f(&s_p1az, &at_p1ez) != &crate::prelude::Text::lit("")) {
                                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(s_p1az.clone(), pnow_p1fz.clone(), at_p1ez.clone(), a_p1dz.value_p.span_p.clone()), move |unify_f_14902: crate::check::types::St| ::prism_rtl::Turn::Finished((unify_f_14902, crate::prelude::push(&done_p1bz, &i_p1cz))))
                                    } else {
                                        crate::prelude::call_then(crate::check::types::start_stack_of_f(s_p1az.clone(), at_p1ez.clone()), move |stack_of_f_14971: crate::prelude::Text| if (&stack_of_f_14971 != &crate::prelude::Text::lit("")) || crate::check::types::is_free_headed_f(&s_p1az, &at_p1ez) {
                                            ::prism_rtl::Turn::Finished((s_p1az.clone(), done_p1bz.clone()))
                                        } else {
                                            crate::prelude::call_then(start_arg_or_unpack_f(env_p0xyz.clone(), s_p1az.clone(), fname_p2xyz.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xyz, &i_p1cz), &crate::check::types::Ty::TyErr), pnow_p1fz.clone(), at_p1ez.clone(), a_p1dz.clone(), res_p5xyz.clone(), span_p7xyz.clone()), move |arg_or_unpack_f_15046: crate::check::types::St| ::prism_rtl::Turn::Finished((arg_or_unpack_f_15046, done_p1bz.clone())))
                                        })
                                    }
                                }
                            };
                            if crate::check::expr::is_time_sigil_f(&head_sigil_f_14715) || (&crate::check::types::head_sigil_f(&s_p1a, &pnow_p1f) == &crate::prelude::Text::lit("@")) {
                                k_let14686(true)
                            } else {
                                if holds_paxy {
                                    crate::prelude::call_then(crate::check::types::start_head_sigil_f(s_p1a.clone(), at_p1e.clone()), move |head_sigil_f_14780: crate::prelude::Text| k_let14686(&head_sigil_f_14780 == &crate::prelude::Text::lit("@")))
                                } else {
                                    k_let14686(false)
                                }
                            }
                        })
                    }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>)>>>
    }));
    let (_, st3_p1v) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (crate::prelude::Map::new(), st2_p1h.clone()), {
        let args_p6x = args_p6.clone();
        let span_p7x = span_p7.clone();
        let params_p4x = params_p4.clone();
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<(), ()>, crate::check::types::St), crate::prelude::Nat)| {
            let args_p6xy = args_p6x.clone();
            let span_p7xy = span_p7x.clone();
            let params_p4xy = params_p4x.clone();
            let env_p0xy = env_p0x.clone();
            let fname_p2xy = fname_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (m_p1j, s_p1k) = p0;
                let i_p1l = p1;
                {
                    let a_p1m = crate::prelude::or(&crate::prelude::index(&args_p6xy, &i_p1l), &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xy.clone() }, span_p: span_p7xy.clone() });
                    if crate::check::expr::is_lambda_f(&a_p1m.value_p) {
                        crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p1k.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xy, &i_p1l), &crate::check::types::Ty::TyErr)), move |walk_f_15348: crate::check::types::Ty| {
                            let p_p1n = walk_f_15348;
                            crate::prelude::call_then(start_infer_lambda_f(env_p0xy.clone(), s_p1k.clone(), a_p1m.value_p.clone(), ::std::option::Option::Some(p_p1n.clone())), move |infer_lambda_f_15407: (crate::check::types::Ty, crate::check::types::St)| {
                                let (lt_p1p, s2_p1q) = infer_lambda_f_15407;
                                let m_p1jz = m_p1j.clone();
                                let k_let15454 = move |v15454: crate::check::types::St| {
                                    let s3_p1o = v15454;
                                    ::prism_rtl::Turn::Finished((m_p1jz.clone(), s3_p1o.clone()))
                                };
                                match (p_p1n.clone(), lt_p1p.clone()) {
                                    (crate::check::types::Ty::TyFn(pc_p1r, _, _), crate::check::types::Ty::TyFn(lc_p1s, lps_p1t, lr_p1u)) => crate::prelude::call_then(crate::check::types::unify::start_unify_f(crate::check::types::recording::note_ty_f(&s2_p1q, &a_p1m.value_p.span_p, &lt_p1p), p_p1n.clone(), crate::check::types::Ty::TyFn(pc_p1r.clone(), lps_p1t.clone(), ::std::rc::Rc::new((*lr_p1u).clone())), a_p1m.value_p.span_p.clone()), move |unify_f_15555: crate::check::types::St| crate::prelude::call_then(crate::check::types::colors::start_add_leq_f(unify_f_15555, lc_p1s.clone(), pc_p1r.clone(), a_p1m.value_p.span_p.clone(), crate::prelude::Text::lit("arg"), fname_p2xy.clone(), crate::prelude::Text::lit("")), move |add_leq_f_15547: crate::check::types::St| k_let15454(add_leq_f_15547))),
                                    _ => crate::prelude::call_then(crate::check::types::unify::start_unify_f(crate::check::types::recording::note_ty_f(&s2_p1q, &a_p1m.value_p.span_p, &lt_p1p), p_p1n.clone(), lt_p1p.clone(), a_p1m.value_p.span_p.clone()), move |unify_f_15696: crate::check::types::St| k_let15454(unify_f_15696)),
                                }
                            })
                        })
                    } else {
                        ::prism_rtl::Turn::Finished((m_p1j.clone(), s_p1k.clone()))
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<(), ()>, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<(), ()>, crate::check::types::St)>>>
    }));
    let (pl_p2b, st4_p2c) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (Peeled { events_p: crate::prelude::Array::new(), dyns_p: crate::prelude::Array::new(), opts_p: crate::prelude::Array::new(), opt_args_p: crate::prelude::Array::new(), lifted_p: crate::prelude::Text::lit(""), broken_p: false }, st3_p1v.clone()), {
        let args_p6x = args_p6.clone();
        let span_p7x = span_p7.clone();
        let arg_tys_pbx = arg_tys_pb.clone();
        let whole_p1ix = whole_p1i.clone();
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        let cmp_p9x = cmp_p9;
        let params_p4x = params_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((Peeled, crate::check::types::St), crate::prelude::Nat)| {
            let args_p6xy = args_p6x.clone();
            let span_p7xy = span_p7x.clone();
            let arg_tys_pbxy = arg_tys_pbx.clone();
            let whole_p1ixy = whole_p1ix.clone();
            let env_p0xy = env_p0x.clone();
            let fname_p2xy = fname_p2x.clone();
            let cmp_p9xy = cmp_p9x;
            let params_p4xy = params_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p20, s_p21) = p0;
                let i_p22 = p1;
                {
                    let a_p23 = crate::prelude::or(&crate::prelude::index(&args_p6xy, &i_p22), &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xy.clone() }, span_p: span_p7xy.clone() });
                    let at_p24 = crate::prelude::or(&crate::prelude::index(&arg_tys_pbxy, &i_p22), &crate::check::types::Ty::TyErr);
                    if (crate::check::expr::is_lambda_f(&a_p23.value_p) || crate::check::types::has_nat_f(&whole_p1ixy, &i_p22)) || ((&crate::check::types::stack_of_f(&s_p21, &at_p24) == &crate::prelude::Text::lit("")) && !crate::check::types::is_free_headed_f(&s_p21, &at_p24)) {
                        ::prism_rtl::Turn::Finished((acc_p20.clone(), s_p21.clone()))
                    } else {
                        {
                            let before_p25 = crate::prelude::len(&s_p21.diags_p);
                            crate::prelude::call_then(start_layered_arg_f(env_p0xy.clone(), s_p21.clone(), acc_p20.clone(), fname_p2xy.clone(), cmp_p9xy, crate::prelude::or(&crate::prelude::index(&params_p4xy, &i_p22), &crate::check::types::Ty::TyErr), at_p24.clone(), a_p23.clone()), move |layered_arg_f_16283: (Peeled, crate::check::types::St)| {
                                let (acc2_p27, s2_p28) = layered_arg_f_16283;
                                let broke_p26 = (&crate::prelude::len(&s2_p28.diags_p) > &before_p25) && crate::prelude::fold(&crate::prelude::drop(&s2_p28.diags_p, &before_p25), &false, &(|seen_p29: &bool, d_p2a: &crate::check::errors::CDiag| *seen_p29 || crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("two-layers"), crate::prelude::Text::lit("layer-under-optional"), crate::prelude::Text::lit("blueprint-operand")]), &d_p2a.code_p)));
                                ::prism_rtl::Turn::Finished((broken_f(&acc2_p27, &broke_p26), s2_p28.clone()))
                            })
                        }
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((Peeled, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(Peeled, crate::check::types::St)>>>
    }));
    let st5_pd = if &crate::prelude::len(&pl_p2b.events_p) > &crate::prelude::Nat::from(1u32) {
        crate::check::types::recording::err_fix_f(&st4_p2c, &crate::prelude::Text::lit("two-events"), &crate::prelude::or(&crate::prelude::index(&pl_p2b.events_p, &crate::prelude::Nat::from(1u32)), span_p7), &crate::prelude::Text::lit("two events in one operation"), &crate::prelude::Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
    } else {
        st4_p2c.clone()
    };
    let st6_pe = if &crate::prelude::len(&pl_p2b.opts_p) > &crate::prelude::Nat::from(1u32) {
        crate::check::types::recording::err_f(&st5_pd, &crate::prelude::Text::lit("optional-and-fault"), span_p7, &crate::prelude::Text::lit("`?` and `~` in one operation"))
    } else {
        st5_pd.clone()
    };
    let layer_pf = if &crate::prelude::len(&pl_p2b.events_p) > &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("!")
    } else {
        if &crate::prelude::len(&pl_p2b.dyns_p) > &crate::prelude::Nat::from(0u32) {
            crate::prelude::Text::lit("$")
        } else {
            crate::prelude::Text::lit("")
        }
    };
    let with_opt_pg = match crate::prelude::index(&pl_p2b.opts_p, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(o_p2d) => crate::check::types::Ty::TySig(o_p2d, ::std::rc::Rc::new(res_p5.clone())),
        ::std::option::Option::None => res_p5.clone(),
    };
    let result_ph = if pl_p2b.broken_p {
        crate::check::types::Ty::TyErr
    } else {
        if &layer_pf == &crate::prelude::Text::lit("") {
            with_opt_pg.clone()
        } else {
            crate::check::types::Ty::TySig(layer_pf.clone(), ::std::rc::Rc::new(with_opt_pg.clone()))
        }
    };
    let call_col_pi = crate::check::types::colors::walk_col_f(&st6_pe, col_p3);
    let st7_pj = if (&layer_pf != &crate::prelude::Text::lit("")) && crate::check::types::colors::is_flex_col_f(&call_col_pi) {
        crate::check::types::colors::add_leq_f(&st6_pe, &call_col_pi, &crate::check::types::Col::CBound, span_p7, &crate::prelude::Text::lit("lifted"), fname_p2, &pl_p2b.lifted_p)
    } else {
        st6_pe.clone()
    };
    let lifted_bad_pk = ((&layer_pf != &crate::prelude::Text::lit("")) && (&call_col_pi != &crate::check::types::Col::CBound)) && !crate::check::types::colors::is_flex_col_f(&call_col_pi);
    let st8_pl = if lifted_bad_pk {
        crate::check::types::recording::err_fix_f(&st7_pj, &crate::prelude::Text::lit("lifted-unbounded"), span_p7, &crate::prelude::Text::from(format!("{} `{}` lifted over `{}`; use `@Run`", &crate::check::types::colors::col_word_f(&call_col_pi), fname_p2, &pl_p2b.lifted_p)), &crate::prelude::Text::from(format!("run it through `!done <- @Run {}, ...`", fname_p2)))
    } else {
        st7_pj.clone()
    };
    let st9_pm = crate::check::types::colors::use_color_f(&st8_pl, &call_col_pi, fname_p2, span_p7);
    let kind_pn = if (&layer_pf == &crate::prelude::Text::lit("!")) && (&crate::prelude::len(&pl_p2b.dyns_p) > &crate::prelude::Nat::from(0u32)) {
        crate::prelude::Text::lit("sample")
    } else {
        if &layer_pf != &crate::prelude::Text::lit("") {
            crate::prelude::Text::lit("map")
        } else {
            if fname_p2 == &crate::prelude::Text::lit("$") {
                crate::prelude::Text::lit("const")
            } else {
                crate::prelude::Text::lit("plain")
            }
        }
    };
    let peeled_po = crate::prelude::append(&pl_p2b.events_p, &pl_p2b.dyns_p);
    let lifted_pp = crate::prelude::filter(&crate::check::errors::range0_f(&n_p8), &(|i_p2e: &crate::prelude::Nat| has_range_f(&peeled_po, &crate::prelude::or(&crate::prelude::index(args_p6, i_p2e), &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7.clone() }, span_p: span_p7.clone() }).value_p.span_p)));
    let st10_pq = if pl_p2b.broken_p || (&crate::prelude::len(&pl_p2b.opts_p) != &crate::prelude::Nat::from(1u32)) {
        st9_pm.clone()
    } else {
        crate::check::types::recording::note_lift_f(&st9_pm, span_p7, &crate::prelude::or(&crate::prelude::index(&pl_p2b.opts_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), &pl_p2b.opt_args_p)
    };
    (result_ph.clone(), crate::check::types::recording::note_app_f(&st10_pq, span_p7, fname_p2, &kind_pn, &layer_pf, &lifted_pp, &crate::prelude::or(&crate::prelude::index(&pl_p2b.opts_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), &call_col_pi))
}

/// The step machine of `ApplyRule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct ApplyRule {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fname_p2: crate::prelude::Text,
    pub col_p3: crate::check::types::Col,
    pub params_p4: crate::prelude::Array<crate::check::types::Ty>,
    pub res_p5: crate::check::types::Ty,
    pub args_p6: crate::prelude::Array<crate::syntax::Arg>,
    pub span_p7: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ApplyRule {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fname_p2 = &self.fname_p2;
        let col_p3 = &self.col_p3;
        let params_p4 = &self.params_p4;
        let res_p5 = &self.res_p5;
        let args_p6 = &self.args_p6;
        let span_p7 = &self.span_p7;
        let n_p8 = crate::prelude::len(args_p6);
        let cmp_p9 = crate::check::expr::is_comparison_f(fname_p2);
        let holds_pa = fname_p2 == &map_literal_p();
        let args_p6x = args_p6.clone();
        let col_p3x = col_p3.clone();
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        let params_p4x = params_p4.clone();
        let res_p5x = res_p5.clone();
        let span_p7x = span_p7.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (crate::prelude::Array::new(), st_p1x.clone()), {
            let args_p6xx = args_p6x.clone();
            let span_p7xx = span_p7x.clone();
            let env_p0xx = env_p0x.clone();
            let params_p4xx = params_p4x.clone();
            let fname_p2xx = fname_p2x.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)| {
                let args_p6xxy = args_p6xx.clone();
                let span_p7xxy = span_p7xx.clone();
                let env_p0xxy = env_p0xx.clone();
                let params_p4xxy = params_p4xx.clone();
                let fname_p2xxy = fname_p2xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_pr, s_ps) = p0;
                    let i_pt = p1;
                    {
                        let a_pu = crate::prelude::or(&crate::prelude::index(&args_p6xxy, &i_pt), &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xxy.clone() }, span_p: span_p7xxy.clone() });
                        if crate::check::expr::is_lambda_f(&a_pu.value_p) {
                            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pr, &crate::check::types::Ty::TyErr), s_ps.clone()))
                        } else {
                            crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0xxy.clone(), s_ps.clone(), a_pu.value_p.clone()), move |infer_f_13454: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t_pv, s2_p10) = infer_f_13454;
                                crate::prelude::call_then(crate::check::types::recording::start_walk_f(s2_p10.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xxy, &i_pt), &crate::check::types::Ty::TyErr)), move |walk_f_13497: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::recording::start_walk_f(s2_p10.clone(), t_pv.clone()), move |walk_f_13531: crate::check::types::Ty| match (walk_f_13497, walk_f_13531) {
                                    (crate::check::types::Ty::TyFn(pc_p11, _, _), crate::check::types::Ty::TyFn(ac_p12, aps_p13, ar_p14)) => crate::prelude::call_then(crate::check::types::colors::start_add_leq_f(s2_p10.clone(), ac_p12.clone(), pc_p11.clone(), a_pu.value_p.span_p.clone(), crate::prelude::Text::lit("arg"), fname_p2xxy.clone(), crate::prelude::Text::lit("")), move |add_leq_f_13648: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pr, &crate::check::types::Ty::TyFn(pc_p11.clone(), aps_p13.clone(), ::std::rc::Rc::new((*ar_p14).clone()))), add_leq_f_13648))),
                                    _ => ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pr, &t_pv), s2_p10.clone())),
                                }))
                            })
                        }
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }), move |fold_13210: (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)| {
            let (inferred_p15, st1_p16) = fold_13210;
            crate::prelude::call_then(start_plain_beside_f(st1_p16.clone(), params_p4x.clone(), inferred_p15.clone()), move |plain_beside_f_13767: crate::prelude::Array<crate::check::types::Ty>| {
                let arg_tys_pb = plain_beside_f_13767;
                crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), st1_p16.clone(), {
                    let inferred_p15x = inferred_p15.clone();
                    let arg_tys_pbx = arg_tys_pb.clone();
                    let args_p6xx = args_p6x.clone();
                    let span_p7xx = span_p7x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Nat)| {
                        let inferred_p15xy = inferred_p15x.clone();
                        let arg_tys_pbxy = arg_tys_pbx.clone();
                        let args_p6xxy = args_p6xx.clone();
                        let span_p7xxy = span_p7xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let s_p17 = p0;
                            let i_p18 = p1;
                            crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(s_p17.clone(), crate::prelude::or(&crate::prelude::index(&inferred_p15xy, &i_p18), &crate::check::types::Ty::TyErr)), move |non_empty_coll_o_13974: ::std::option::Option<crate::check::types::Ty>| crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(s_p17.clone(), crate::prelude::or(&crate::prelude::index(&arg_tys_pbxy, &i_p18), &crate::check::types::Ty::TyErr)), move |non_empty_coll_o_14018: ::std::option::Option<crate::check::types::Ty>| match (non_empty_coll_o_13974, non_empty_coll_o_14018) {
                                (::std::option::Option::Some(c_p19), ::std::option::Option::None) => ::prism_rtl::Turn::Finished(crate::check::types::recording::ask_plain_at_f(&s_p17, &crate::prelude::or(&crate::prelude::index(&args_p6xxy, &i_p18), &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xxy.clone() }, span_p: span_p7xxy.clone() }).value_p.span_p, &c_p19)),
                                _ => ::prism_rtl::Turn::Finished(s_p17.clone()),
                            }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                }), move |fold_13935: crate::check::types::St| {
                    let st1b_pc = fold_13935;
                    crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (st1b_pc.clone(), crate::prelude::Array::new()), {
                        let args_p6xx = args_p6x.clone();
                        let span_p7xx = span_p7x.clone();
                        let arg_tys_pbx = arg_tys_pb.clone();
                        let params_p4xx = params_p4x.clone();
                        let holds_pax = holds_pa;
                        let env_p0xx = env_p0x.clone();
                        let fname_p2xx = fname_p2x.clone();
                        let res_p5xx = res_p5x.clone();
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>), crate::prelude::Nat)| {
                            let args_p6xxy = args_p6xx.clone();
                            let span_p7xxy = span_p7xx.clone();
                            let arg_tys_pbxy = arg_tys_pbx.clone();
                            let params_p4xxy = params_p4xx.clone();
                            let holds_paxy = holds_pax;
                            let env_p0xxy = env_p0xx.clone();
                            let fname_p2xxy = fname_p2xx.clone();
                            let res_p5xxy = res_p5xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (s_p1a, done_p1b) = p0;
                                let i_p1c = p1;
                                {
                                    let a_p1d = crate::prelude::or(&crate::prelude::index(&args_p6xxy, &i_p1c), &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xxy.clone() }, span_p: span_p7xxy.clone() });
                                    let at_p1e = crate::prelude::or(&crate::prelude::index(&arg_tys_pbxy, &i_p1c), &crate::check::types::Ty::TyErr);
                                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p1a.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xxy, &i_p1c), &crate::check::types::Ty::TyErr)), move |walk_f_14464: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::unify::start_norm_assoc_f(s_p1a.clone(), walk_f_14464), move |norm_assoc_f_14450: crate::check::types::Ty| {
                                        let pnow_p1f = norm_assoc_f_14450;
                                        crate::prelude::call_then(crate::check::types::start_head_sigil_f(s_p1a.clone(), pnow_p1f.clone()), move |head_sigil_f_14715: crate::prelude::Text| {
                                            let a_p1dz = a_p1d.clone();
                                            let at_p1ez = at_p1e.clone();
                                            let done_p1bz = done_p1b.clone();
                                            let env_p0xxyz = env_p0xxy.clone();
                                            let fname_p2xxyz = fname_p2xxy.clone();
                                            let i_p1cz = i_p1c.clone();
                                            let params_p4xxyz = params_p4xxy.clone();
                                            let pnow_p1fz = pnow_p1f.clone();
                                            let res_p5xxyz = res_p5xxy.clone();
                                            let s_p1az = s_p1a.clone();
                                            let span_p7xxyz = span_p7xxy.clone();
                                            let k_let14686 = move |v14686: bool| {
                                                let whole_now_p1g = v14686;
                                                if crate::check::expr::is_lambda_f(&a_p1dz.value_p) {
                                                    ::prism_rtl::Turn::Finished((s_p1az.clone(), done_p1bz.clone()))
                                                } else {
                                                    if whole_now_p1g && (&crate::check::types::stack_of_f(&s_p1az, &at_p1ez) != &crate::prelude::Text::lit("")) {
                                                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(s_p1az.clone(), pnow_p1fz.clone(), at_p1ez.clone(), a_p1dz.value_p.span_p.clone()), move |unify_f_14902: crate::check::types::St| ::prism_rtl::Turn::Finished((unify_f_14902, crate::prelude::push(&done_p1bz, &i_p1cz))))
                                                    } else {
                                                        crate::prelude::call_then(crate::check::types::start_stack_of_f(s_p1az.clone(), at_p1ez.clone()), move |stack_of_f_14971: crate::prelude::Text| if (&stack_of_f_14971 != &crate::prelude::Text::lit("")) || crate::check::types::is_free_headed_f(&s_p1az, &at_p1ez) {
                                                            ::prism_rtl::Turn::Finished((s_p1az.clone(), done_p1bz.clone()))
                                                        } else {
                                                            crate::prelude::call_then(start_arg_or_unpack_f(env_p0xxyz.clone(), s_p1az.clone(), fname_p2xxyz.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xxyz, &i_p1cz), &crate::check::types::Ty::TyErr), pnow_p1fz.clone(), at_p1ez.clone(), a_p1dz.clone(), res_p5xxyz.clone(), span_p7xxyz.clone()), move |arg_or_unpack_f_15046: crate::check::types::St| ::prism_rtl::Turn::Finished((arg_or_unpack_f_15046, done_p1bz.clone())))
                                                        })
                                                    }
                                                }
                                            };
                                            if crate::check::expr::is_time_sigil_f(&head_sigil_f_14715) || (&crate::check::types::head_sigil_f(&s_p1a, &pnow_p1f) == &crate::prelude::Text::lit("@")) {
                                                k_let14686(true)
                                            } else {
                                                if holds_paxy {
                                                    crate::prelude::call_then(crate::check::types::start_head_sigil_f(s_p1a.clone(), at_p1e.clone()), move |head_sigil_f_14780: crate::prelude::Text| k_let14686(&head_sigil_f_14780 == &crate::prelude::Text::lit("@")))
                                                } else {
                                                    k_let14686(false)
                                                }
                                            }
                                        })
                                    }))
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>)>>>
                    }), move |fold_14243: (crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>)| {
                        let (st2_p1h, whole_p1i) = fold_14243;
                        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (crate::prelude::Map::new(), st2_p1h.clone()), {
                            let args_p6xx = args_p6x.clone();
                            let span_p7xx = span_p7x.clone();
                            let params_p4xx = params_p4x.clone();
                            let env_p0xx = env_p0x.clone();
                            let fname_p2xx = fname_p2x.clone();
                            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<(), ()>, crate::check::types::St), crate::prelude::Nat)| {
                                let args_p6xxy = args_p6xx.clone();
                                let span_p7xxy = span_p7xx.clone();
                                let params_p4xxy = params_p4xx.clone();
                                let env_p0xxy = env_p0xx.clone();
                                let fname_p2xxy = fname_p2xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (m_p1j, s_p1k) = p0;
                                    let i_p1l = p1;
                                    {
                                        let a_p1m = crate::prelude::or(&crate::prelude::index(&args_p6xxy, &i_p1l), &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xxy.clone() }, span_p: span_p7xxy.clone() });
                                        if crate::check::expr::is_lambda_f(&a_p1m.value_p) {
                                            crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p1k.clone(), crate::prelude::or(&crate::prelude::index(&params_p4xxy, &i_p1l), &crate::check::types::Ty::TyErr)), move |walk_f_15348: crate::check::types::Ty| {
                                                let p_p1n = walk_f_15348;
                                                crate::prelude::call_then(start_infer_lambda_f(env_p0xxy.clone(), s_p1k.clone(), a_p1m.value_p.clone(), ::std::option::Option::Some(p_p1n.clone())), move |infer_lambda_f_15407: (crate::check::types::Ty, crate::check::types::St)| {
                                                    let (lt_p1p, s2_p1q) = infer_lambda_f_15407;
                                                    let m_p1jz = m_p1j.clone();
                                                    let k_let15454 = move |v15454: crate::check::types::St| {
                                                        let s3_p1o = v15454;
                                                        ::prism_rtl::Turn::Finished((m_p1jz.clone(), s3_p1o.clone()))
                                                    };
                                                    match (p_p1n.clone(), lt_p1p.clone()) {
                                                        (crate::check::types::Ty::TyFn(pc_p1r, _, _), crate::check::types::Ty::TyFn(lc_p1s, lps_p1t, lr_p1u)) => crate::prelude::call_then(crate::check::types::unify::start_unify_f(crate::check::types::recording::note_ty_f(&s2_p1q, &a_p1m.value_p.span_p, &lt_p1p), p_p1n.clone(), crate::check::types::Ty::TyFn(pc_p1r.clone(), lps_p1t.clone(), ::std::rc::Rc::new((*lr_p1u).clone())), a_p1m.value_p.span_p.clone()), move |unify_f_15555: crate::check::types::St| crate::prelude::call_then(crate::check::types::colors::start_add_leq_f(unify_f_15555, lc_p1s.clone(), pc_p1r.clone(), a_p1m.value_p.span_p.clone(), crate::prelude::Text::lit("arg"), fname_p2xxy.clone(), crate::prelude::Text::lit("")), move |add_leq_f_15547: crate::check::types::St| k_let15454(add_leq_f_15547))),
                                                        _ => crate::prelude::call_then(crate::check::types::unify::start_unify_f(crate::check::types::recording::note_ty_f(&s2_p1q, &a_p1m.value_p.span_p, &lt_p1p), p_p1n.clone(), lt_p1p.clone(), a_p1m.value_p.span_p.clone()), move |unify_f_15696: crate::check::types::St| k_let15454(unify_f_15696)),
                                                    }
                                                })
                                            })
                                        } else {
                                            ::prism_rtl::Turn::Finished((m_p1j.clone(), s_p1k.clone()))
                                        }
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<(), ()>, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<(), ()>, crate::check::types::St)>>>
                        }), move |fold_15154: (crate::prelude::Map<(), ()>, crate::check::types::St)| {
                            let (_, st3_p1v) = fold_15154;
                            crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p8), (Peeled { events_p: crate::prelude::Array::new(), dyns_p: crate::prelude::Array::new(), opts_p: crate::prelude::Array::new(), opt_args_p: crate::prelude::Array::new(), lifted_p: crate::prelude::Text::lit(""), broken_p: false }, st3_p1v.clone()), {
                                let args_p6xx = args_p6x.clone();
                                let span_p7xx = span_p7x.clone();
                                let arg_tys_pbx = arg_tys_pb.clone();
                                let whole_p1ix = whole_p1i.clone();
                                let env_p0xx = env_p0x.clone();
                                let fname_p2xx = fname_p2x.clone();
                                let cmp_p9x = cmp_p9;
                                let params_p4xx = params_p4x.clone();
                                ::std::rc::Rc::new(move |(p0, p1): ((Peeled, crate::check::types::St), crate::prelude::Nat)| {
                                    let args_p6xxy = args_p6xx.clone();
                                    let span_p7xxy = span_p7xx.clone();
                                    let arg_tys_pbxy = arg_tys_pbx.clone();
                                    let whole_p1ixy = whole_p1ix.clone();
                                    let env_p0xxy = env_p0xx.clone();
                                    let fname_p2xxy = fname_p2xx.clone();
                                    let cmp_p9xy = cmp_p9x;
                                    let params_p4xxy = params_p4xx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (acc_p20, s_p21) = p0;
                                        let i_p22 = p1;
                                        {
                                            let a_p23 = crate::prelude::or(&crate::prelude::index(&args_p6xxy, &i_p22), &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xxy.clone() }, span_p: span_p7xxy.clone() });
                                            let at_p24 = crate::prelude::or(&crate::prelude::index(&arg_tys_pbxy, &i_p22), &crate::check::types::Ty::TyErr);
                                            if (crate::check::expr::is_lambda_f(&a_p23.value_p) || crate::check::types::has_nat_f(&whole_p1ixy, &i_p22)) || ((&crate::check::types::stack_of_f(&s_p21, &at_p24) == &crate::prelude::Text::lit("")) && !crate::check::types::is_free_headed_f(&s_p21, &at_p24)) {
                                                ::prism_rtl::Turn::Finished((acc_p20.clone(), s_p21.clone()))
                                            } else {
                                                {
                                                    let before_p25 = crate::prelude::len(&s_p21.diags_p);
                                                    crate::prelude::call_then(start_layered_arg_f(env_p0xxy.clone(), s_p21.clone(), acc_p20.clone(), fname_p2xxy.clone(), cmp_p9xy, crate::prelude::or(&crate::prelude::index(&params_p4xxy, &i_p22), &crate::check::types::Ty::TyErr), at_p24.clone(), a_p23.clone()), move |layered_arg_f_16283: (Peeled, crate::check::types::St)| {
                                                        let (acc2_p27, s2_p28) = layered_arg_f_16283;
                                                        let broke_p26 = (&crate::prelude::len(&s2_p28.diags_p) > &before_p25) && crate::prelude::fold(&crate::prelude::drop(&s2_p28.diags_p, &before_p25), &false, &(|seen_p29: &bool, d_p2a: &crate::check::errors::CDiag| *seen_p29 || crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("two-layers"), crate::prelude::Text::lit("layer-under-optional"), crate::prelude::Text::lit("blueprint-operand")]), &d_p2a.code_p)));
                                                        ::prism_rtl::Turn::Finished((broken_f(&acc2_p27, &broke_p26), s2_p28.clone()))
                                                    })
                                                }
                                            }
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((Peeled, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(Peeled, crate::check::types::St)>>>
                            }), move |fold_15820: (Peeled, crate::check::types::St)| {
                                let (pl_p2b, st4_p2c) = fold_15820;
                                let st5_pd = if &crate::prelude::len(&pl_p2b.events_p) > &crate::prelude::Nat::from(1u32) {
                                    crate::check::types::recording::err_fix_f(&st4_p2c, &crate::prelude::Text::lit("two-events"), &crate::prelude::or(&crate::prelude::index(&pl_p2b.events_p, &crate::prelude::Nat::from(1u32)), &span_p7x), &crate::prelude::Text::lit("two events in one operation"), &crate::prelude::Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
                                } else {
                                    st4_p2c.clone()
                                };
                                let st6_pe = if &crate::prelude::len(&pl_p2b.opts_p) > &crate::prelude::Nat::from(1u32) {
                                    crate::check::types::recording::err_f(&st5_pd, &crate::prelude::Text::lit("optional-and-fault"), &span_p7x, &crate::prelude::Text::lit("`?` and `~` in one operation"))
                                } else {
                                    st5_pd.clone()
                                };
                                let layer_pf = if &crate::prelude::len(&pl_p2b.events_p) > &crate::prelude::Nat::from(0u32) {
                                    crate::prelude::Text::lit("!")
                                } else {
                                    if &crate::prelude::len(&pl_p2b.dyns_p) > &crate::prelude::Nat::from(0u32) {
                                        crate::prelude::Text::lit("$")
                                    } else {
                                        crate::prelude::Text::lit("")
                                    }
                                };
                                let with_opt_pg = match crate::prelude::index(&pl_p2b.opts_p, &crate::prelude::Nat::from(0u32)) {
                                    ::std::option::Option::Some(o_p2d) => crate::check::types::Ty::TySig(o_p2d, ::std::rc::Rc::new(res_p5x.clone())),
                                    ::std::option::Option::None => res_p5x.clone(),
                                };
                                let result_ph = if pl_p2b.broken_p {
                                    crate::check::types::Ty::TyErr
                                } else {
                                    if &layer_pf == &crate::prelude::Text::lit("") {
                                        with_opt_pg.clone()
                                    } else {
                                        crate::check::types::Ty::TySig(layer_pf.clone(), ::std::rc::Rc::new(with_opt_pg.clone()))
                                    }
                                };
                                crate::prelude::call_then(crate::check::types::colors::start_walk_col_f(st6_pe.clone(), col_p3x.clone()), move |walk_col_f_17331: crate::check::types::Col| {
                                    let call_col_pi = walk_col_f_17331;
                                    let args_p6xz = args_p6x.clone();
                                    let call_col_piz = call_col_pi.clone();
                                    let fname_p2xz = fname_p2x.clone();
                                    let layer_pfz = layer_pf.clone();
                                    let n_p8z = n_p8.clone();
                                    let pl_p2bz = pl_p2b.clone();
                                    let result_phz = result_ph.clone();
                                    let span_p7xz = span_p7x.clone();
                                    let k_let17352 = move |v17352: crate::check::types::St| {
                                        let st7_pj = v17352;
                                        let lifted_bad_pk = ((&layer_pfz != &crate::prelude::Text::lit("")) && (&call_col_piz != &crate::check::types::Col::CBound)) && !crate::check::types::colors::is_flex_col_f(&call_col_piz);
                                        let st8_pl = if lifted_bad_pk {
                                            crate::check::types::recording::err_fix_f(&st7_pj, &crate::prelude::Text::lit("lifted-unbounded"), &span_p7xz, &crate::prelude::Text::from(format!("{} `{}` lifted over `{}`; use `@Run`", &crate::check::types::colors::col_word_f(&call_col_piz), &fname_p2xz, &pl_p2bz.lifted_p)), &crate::prelude::Text::from(format!("run it through `!done <- @Run {}, ...`", &fname_p2xz)))
                                        } else {
                                            st7_pj.clone()
                                        };
                                        crate::prelude::call_then(crate::check::types::colors::start_use_color_f(st8_pl.clone(), call_col_piz.clone(), fname_p2xz.clone(), span_p7xz.clone()), move |use_color_f_17761: crate::check::types::St| {
                                            let st9_pm = use_color_f_17761;
                                            let kind_pn = if (&layer_pfz == &crate::prelude::Text::lit("!")) && (&crate::prelude::len(&pl_p2bz.dyns_p) > &crate::prelude::Nat::from(0u32)) {
                                                crate::prelude::Text::lit("sample")
                                            } else {
                                                if &layer_pfz != &crate::prelude::Text::lit("") {
                                                    crate::prelude::Text::lit("map")
                                                } else {
                                                    if &fname_p2xz == &crate::prelude::Text::lit("$") {
                                                        crate::prelude::Text::lit("const")
                                                    } else {
                                                        crate::prelude::Text::lit("plain")
                                                    }
                                                }
                                            };
                                            let peeled_po = crate::prelude::append(&pl_p2bz.events_p, &pl_p2bz.dyns_p);
                                            let lifted_pp = crate::prelude::filter(&crate::check::errors::range0_f(&n_p8z), &(|i_p2e: &crate::prelude::Nat| has_range_f(&peeled_po, &crate::prelude::or(&crate::prelude::index(&args_p6xz, i_p2e), &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p7xz.clone() }, span_p: span_p7xz.clone() }).value_p.span_p)));
                                            let st10_pq = if pl_p2bz.broken_p || (&crate::prelude::len(&pl_p2bz.opts_p) != &crate::prelude::Nat::from(1u32)) {
                                                st9_pm.clone()
                                            } else {
                                                crate::check::types::recording::note_lift_f(&st9_pm, &span_p7xz, &crate::prelude::or(&crate::prelude::index(&pl_p2bz.opts_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), &pl_p2bz.opt_args_p)
                                            };
                                            ::prism_rtl::Turn::Finished((result_phz.clone(), crate::check::types::recording::note_app_f(&st10_pq, &span_p7xz, &fname_p2xz, &kind_pn, &layer_pfz, &lifted_pp, &crate::prelude::or(&crate::prelude::index(&pl_p2bz.opts_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), &call_col_piz)))
                                        })
                                    };
                                    if (&layer_pf != &crate::prelude::Text::lit("")) && crate::check::types::colors::is_flex_col_f(&call_col_pi) {
                                        crate::prelude::call_then(crate::check::types::colors::start_add_leq_f(st6_pe.clone(), call_col_pi.clone(), crate::check::types::Col::CBound, span_p7x.clone(), crate::prelude::Text::lit("lifted"), fname_p2x.clone(), pl_p2b.lifted_p.clone()), move |add_leq_f_17402: crate::check::types::St| k_let17352(add_leq_f_17402))
                                    } else {
                                        k_let17352(st6_pe.clone())
                                    }
                                })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start ApplyRule, x`: what the function value is when passed to `@Run`.
pub fn start_apply_rule_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fname_p2: crate::prelude::Text, col_p3: crate::check::types::Col, params_p4: crate::prelude::Array<crate::check::types::Ty>, res_p5: crate::check::types::Ty, args_p6: crate::prelude::Array<crate::syntax::Arg>, span_p7: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(ApplyRule { env_p0, st_p1, fname_p2, col_p3, params_p4, res_p5, args_p6, span_p7 })
}

/// ```prism
/// PlainBeside: unbounded fn St, [Ty], [Ty] -> [Ty]
/// ```
pub fn plain_beside_f(st_p0: &crate::check::types::St, params_p1: &crate::prelude::Array<crate::check::types::Ty>, arg_tys_p2: &crate::prelude::Array<crate::check::types::Ty>) -> crate::prelude::Array<crate::check::types::Ty> {
    let n_p3 = crate::prelude::len(arg_tys_p2);
    let plain_at_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p3), crate::prelude::Array::new(), {
        let st_p0x = st_p0.clone();
        let params_p1x = params_p1.clone();
        let arg_tys_p2x = arg_tys_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Nat)| {
            let st_p0xy = st_p0x.clone();
            let params_p1xy = params_p1x.clone();
            let arg_tys_p2xy = arg_tys_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let i_p6 = p1;
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0xy.clone(), crate::prelude::or(&crate::prelude::index(&params_p1xy, &i_p6), &crate::check::types::Ty::TyErr)), move |walk_f_18903: crate::check::types::Ty| match walk_f_18903 {
                    crate::check::types::Ty::TyFlex(v_p7) if crate::check::types::is_plain_collection_f(&st_p0xy, &crate::prelude::or(&crate::prelude::index(&arg_tys_p2xy, &i_p6), &crate::check::types::Ty::TyErr)) => ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p5, &v_p7)),
                    _ => ::prism_rtl::Turn::Finished(acc_p5.clone()),
                    _ => unreachable!("no arm matched"),
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    if &crate::prelude::len(&plain_at_p4) == &crate::prelude::Nat::from(0u32) {
        arg_tys_p2.clone()
    } else {
        crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&n_p3), {
            let arg_tys_p2x = arg_tys_p2.clone();
            let st_p0x = st_p0.clone();
            let params_p1x = params_p1.clone();
            let plain_at_p4x = plain_at_p4.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let arg_tys_p2xy = arg_tys_p2x.clone();
                let st_p0xy = st_p0x.clone();
                let params_p1xy = params_p1x.clone();
                let plain_at_p4xy = plain_at_p4x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_p8 = p0;
                    {
                        let at_p9 = crate::prelude::or(&crate::prelude::index(&arg_tys_p2xy, &i_p8), &crate::check::types::Ty::TyErr);
                        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0xy.clone(), crate::prelude::or(&crate::prelude::index(&params_p1xy, &i_p8), &crate::check::types::Ty::TyErr)), move |walk_f_19155: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(st_p0xy.clone(), at_p9.clone()), move |non_empty_coll_o_19189: ::std::option::Option<crate::check::types::Ty>| match (walk_f_19155, non_empty_coll_o_19189) {
                            (crate::check::types::Ty::TyFlex(v_pa), ::std::option::Option::Some(c_pb)) if crate::check::types::has_nat_f(&plain_at_p4xy, &v_pa) => ::prism_rtl::Turn::Finished(c_pb.clone()),
                            _ => ::prism_rtl::Turn::Finished(at_p9.clone()),
                            _ => unreachable!("no arm matched"),
                        }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        }))
    }
}

/// The step machine of `PlainBeside`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainBeside: unbounded fn St, [Ty], [Ty] -> [Ty]
/// ```
pub struct PlainBeside {
    pub st_p0: crate::check::types::St,
    pub params_p1: crate::prelude::Array<crate::check::types::Ty>,
    pub arg_tys_p2: crate::prelude::Array<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::check::types::Ty>> for PlainBeside {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::check::types::Ty>> {
        let st_p0 = &self.st_p0;
        let params_p1 = &self.params_p1;
        let arg_tys_p2 = &self.arg_tys_p2;
        let n_p3 = crate::prelude::len(arg_tys_p2);
        let arg_tys_p2x = arg_tys_p2.clone();
        let params_p1x = params_p1.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p3), crate::prelude::Array::new(), {
            let st_p0xx = st_p0x.clone();
            let params_p1xx = params_p1x.clone();
            let arg_tys_p2xx = arg_tys_p2x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Nat)| {
                let st_p0xxy = st_p0xx.clone();
                let params_p1xxy = params_p1xx.clone();
                let arg_tys_p2xxy = arg_tys_p2xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p5 = p0;
                    let i_p6 = p1;
                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0xxy.clone(), crate::prelude::or(&crate::prelude::index(&params_p1xxy, &i_p6), &crate::check::types::Ty::TyErr)), move |walk_f_18903: crate::check::types::Ty| match walk_f_18903 {
                        crate::check::types::Ty::TyFlex(v_p7) if crate::check::types::is_plain_collection_f(&st_p0xxy, &crate::prelude::or(&crate::prelude::index(&arg_tys_p2xxy, &i_p6), &crate::check::types::Ty::TyErr)) => ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p5, &v_p7)),
                        _ => ::prism_rtl::Turn::Finished(acc_p5.clone()),
                        _ => unreachable!("no arm matched"),
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
        }), move |fold_18864: crate::prelude::Array<crate::prelude::Nat>| {
            let plain_at_p4 = fold_18864;
            if &crate::prelude::len(&plain_at_p4) == &crate::prelude::Nat::from(0u32) {
                ::prism_rtl::Turn::Finished(arg_tys_p2x.clone())
            } else {
                crate::prelude::each_job(crate::check::errors::range0_f(&n_p3), {
                    let arg_tys_p2xx = arg_tys_p2x.clone();
                    let st_p0xx = st_p0x.clone();
                    let params_p1xx = params_p1x.clone();
                    let plain_at_p4x = plain_at_p4.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                        let arg_tys_p2xxy = arg_tys_p2xx.clone();
                        let st_p0xxy = st_p0xx.clone();
                        let params_p1xxy = params_p1xx.clone();
                        let plain_at_p4xy = plain_at_p4x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_p8 = p0;
                            {
                                let at_p9 = crate::prelude::or(&crate::prelude::index(&arg_tys_p2xxy, &i_p8), &crate::check::types::Ty::TyErr);
                                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0xxy.clone(), crate::prelude::or(&crate::prelude::index(&params_p1xxy, &i_p8), &crate::check::types::Ty::TyErr)), move |walk_f_19155: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(st_p0xxy.clone(), at_p9.clone()), move |non_empty_coll_o_19189: ::std::option::Option<crate::check::types::Ty>| match (walk_f_19155, non_empty_coll_o_19189) {
                                    (crate::check::types::Ty::TyFlex(v_pa), ::std::option::Option::Some(c_pb)) if crate::check::types::has_nat_f(&plain_at_p4xy, &v_pa) => ::prism_rtl::Turn::Finished(c_pb.clone()),
                                    _ => ::prism_rtl::Turn::Finished(at_p9.clone()),
                                    _ => unreachable!("no arm matched"),
                                }))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }).cycle()
            }
        })
    }
}

/// `Start PlainBeside, x`: what the function value is when passed to `@Run`.
pub fn start_plain_beside_f(st_p0: crate::check::types::St, params_p1: crate::prelude::Array<crate::check::types::Ty>, arg_tys_p2: crate::prelude::Array<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::check::types::Ty>>> {
    ::std::rc::Rc::new(PlainBeside { st_p0, params_p1, arg_tys_p2 })
}

/// ```prism
/// ArgOrUnpack: unbounded fn Env, St, Text, Ty, Ty, Ty, Arg, Ty, Range -> St
/// ```
pub fn arg_or_unpack_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fname_p2: &crate::prelude::Text, param_p3: &crate::check::types::Ty, pnow_p4: &crate::check::types::Ty, at_p5: &crate::check::types::Ty, a_p6: &crate::syntax::Arg, res_p7: &crate::check::types::Ty, span_p8: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk_f(st_p1, at_p5) {
        crate::check::types::Ty::TyAny(bounds_p9) => match pnow_p4 {
            crate::check::types::Ty::TyFlex(n_pa) => {
                let hidden_pb = crate::prelude::Text::from(format!("e\'{}", &st_p1.next_p));
                let st2_pc = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.next_p = &this.next_p + &crate::prelude::Nat::from(1u32);
                    this.any_givens_p = crate::prelude::append(&this.any_givens_p, &crate::prelude::each(&bounds_p9, &(|b_pe: &crate::prelude::Text| (hidden_pb.clone(), b_pe.clone()))));
                    this
                };
                let st3_pd = crate::check::types::unify::unify_f(&st2_pc, pnow_p4, &crate::check::types::Ty::TyRigid(hidden_pb.clone()), &a_p6.value_p.span_p);
                if crate::check::types::has_nat_f(&crate::check::types::recording::free_vars_f(st_p1, res_p7), n_pa) {
                    crate::check::types::recording::err_f(&st3_pd, &crate::prelude::Text::lit("existential-escape"), span_p8, &crate::prelude::Text::from(format!("the type hidden in `{}` would leave it here", &crate::check::types::show_ty_f(st_p1, at_p5))))
                } else {
                    st3_pd.clone()
                }
            },
            crate::check::types::Ty::TyRigid(r_pf) if crate::syntax::lexer::chars::has_prefix_f(r_pf, &crate::prelude::Text::lit("e\'")) => crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &a_p6.value_p.span_p, &crate::prelude::Text::from(format!("two existentials meet here, each `{}` hiding a type of its own", &crate::check::types::show_ty_f(st_p1, at_p5)))),
            _ => plain_arg_f(env_p0, st_p1, fname_p2, param_p3, at_p5, a_p6),
            _ => unreachable!("no arm matched"),
        },
        _ => plain_arg_f(env_p0, st_p1, fname_p2, param_p3, at_p5, a_p6),
    }
}

/// The step machine of `ArgOrUnpack`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgOrUnpack: unbounded fn Env, St, Text, Ty, Ty, Ty, Arg, Ty, Range -> St
/// ```
pub struct ArgOrUnpack {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fname_p2: crate::prelude::Text,
    pub param_p3: crate::check::types::Ty,
    pub pnow_p4: crate::check::types::Ty,
    pub at_p5: crate::check::types::Ty,
    pub a_p6: crate::syntax::Arg,
    pub res_p7: crate::check::types::Ty,
    pub span_p8: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for ArgOrUnpack {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fname_p2 = &self.fname_p2;
        let param_p3 = &self.param_p3;
        let pnow_p4 = &self.pnow_p4;
        let at_p5 = &self.at_p5;
        let a_p6 = &self.a_p6;
        let res_p7 = &self.res_p7;
        let span_p8 = &self.span_p8;
        let a_p6x = a_p6.clone();
        let at_p5x = at_p5.clone();
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        let param_p3x = param_p3.clone();
        let pnow_p4x = pnow_p4.clone();
        let res_p7x = res_p7.clone();
        let span_p8x = span_p8.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), at_p5x.clone()), move |walk_f_19885: crate::check::types::Ty| match walk_f_19885 {
            crate::check::types::Ty::TyAny(bounds_p9) => match &pnow_p4x {
                crate::check::types::Ty::TyFlex(n_pa) => {
                    let hidden_pb = crate::prelude::Text::from(format!("e\'{}", &st_p1x.next_p));
                    let st2_pc = {
                        let mut this: crate::check::types::St = st_p1x.clone();
                        this.next_p = &this.next_p + &crate::prelude::Nat::from(1u32);
                        this.any_givens_p = crate::prelude::append(&this.any_givens_p, &crate::prelude::each(&bounds_p9, &(|b_pe: &crate::prelude::Text| (hidden_pb.clone(), b_pe.clone()))));
                        this
                    };
                    let n_pax = n_pa.clone();
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pc.clone(), pnow_p4x.clone(), crate::check::types::Ty::TyRigid(hidden_pb.clone()), a_p6x.value_p.span_p.clone()), move |unify_f_20156: crate::check::types::St| {
                        let st3_pd = unify_f_20156;
                        crate::prelude::call_then(crate::check::types::recording::start_free_vars_f(st_p1x.clone(), res_p7x.clone()), move |free_vars_f_20227: crate::prelude::Array<crate::prelude::Nat>| if crate::check::types::has_nat_f(&free_vars_f_20227, &n_pax) {
                            crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), at_p5x.clone()), move |show_ty_f_20308: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&st3_pd, &crate::prelude::Text::lit("existential-escape"), &span_p8x, &crate::prelude::Text::from(format!("the type hidden in `{}` would leave it here", &show_ty_f_20308)))))
                        } else {
                            ::prism_rtl::Turn::Finished(st3_pd.clone())
                        })
                    })
                },
                crate::check::types::Ty::TyRigid(r_pf) if crate::syntax::lexer::chars::has_prefix_f(r_pf, &crate::prelude::Text::lit("e\'")) => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), at_p5x.clone()), move |show_ty_f_20477: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&st_p1x, &crate::prelude::Text::lit("mismatch"), &a_p6x.value_p.span_p, &crate::prelude::Text::from(format!("two existentials meet here, each `{}` hiding a type of its own", &show_ty_f_20477))))),
                _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(PlainArg { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), fname_p2: fname_p2x.clone(), param_p3: param_p3x.clone(), at_p4: at_p5x.clone(), a_p5: a_p6x.clone() })),
                _ => unreachable!("no arm matched"),
            },
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(PlainArg { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), fname_p2: fname_p2x.clone(), param_p3: param_p3x.clone(), at_p4: at_p5x.clone(), a_p5: a_p6x.clone() })),
        })
    }
}

/// `Start ArgOrUnpack, x`: what the function value is when passed to `@Run`.
pub fn start_arg_or_unpack_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fname_p2: crate::prelude::Text, param_p3: crate::check::types::Ty, pnow_p4: crate::check::types::Ty, at_p5: crate::check::types::Ty, a_p6: crate::syntax::Arg, res_p7: crate::check::types::Ty, span_p8: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(ArgOrUnpack { env_p0, st_p1, fname_p2, param_p3, pnow_p4, at_p5, a_p6, res_p7, span_p8 })
}

/// ```prism
/// HasRange: fn [Range], Range -> Bool
/// ```
pub fn has_range_f(rs_p0: &crate::prelude::Array<crate::syntax::Range>, r_p1: &crate::syntax::Range) -> bool {
    crate::prelude::fold(rs_p0, &false, &(|seen_p2: &bool, x_p3: &crate::syntax::Range| *seen_p2 || (x_p3 == r_p1)))
}

/// ```prism
/// Elab: fn St, Range, Text, Text, Text -> St
/// ```
pub fn elab_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, what_p2: &crate::prelude::Text, kind_p3: &crate::prelude::Text, layer_p4: &crate::prelude::Text) -> crate::check::types::St {
    crate::check::types::recording::note_app_f(st_p0, span_p1, what_p2, kind_p3, layer_p4, &crate::prelude::Array::new(), &crate::prelude::Text::lit(""), &crate::check::types::Col::CBound)
}

/// ```prism
/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
/// ```
pub fn plain_arg_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fname_p2: &crate::prelude::Text, param_p3: &crate::check::types::Ty, at_p4: &crate::check::types::Ty, a_p5: &crate::syntax::Arg) -> crate::check::types::St {
    let p_p6 = crate::check::types::recording::walk_f(st_p1, param_p3);
    let ph_p7 = crate::check::types::head_sigil_f(st_p1, &p_p6);
    if at_p4 == &crate::check::types::Ty::TyErr {
        st_p1.clone()
    } else {
        if crate::check::expr::is_time_sigil_f(&ph_p7) || (&ph_p7 == &crate::prelude::Text::lit("@")) {
            {
                let shown_p8 = if crate::check::types::is_flex_var_f(st_p1, at_p4) {
                    crate::check::expr::src_text_f(env_p0, &a_p5.value_p.span_p)
                } else {
                    crate::check::types::show_ty_f(st_p1, at_p4)
                };
                crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("plain-for-sigiled"), &a_p5.value_p.span_p, &crate::prelude::Text::from(format!("a plain `{}` where `{}` takes a `{}`", &shown_p8, fname_p2, &crate::check::types::show_ty_f(st_p1, &p_p6))), &crate::prelude::Text::from(format!("write `{} {}`", &ph_p7, &crate::check::expr::src_text_f(env_p0, &a_p5.value_p.span_p))))
            }
        } else {
            crate::check::types::recording::unify_at_f(st_p1, &p_p6, at_p4, &a_p5.value_p.span_p)
        }
    }
}

/// The step machine of `PlainArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
/// ```
pub struct PlainArg {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fname_p2: crate::prelude::Text,
    pub param_p3: crate::check::types::Ty,
    pub at_p4: crate::check::types::Ty,
    pub a_p5: crate::syntax::Arg,
}

impl ::prism_rtl::Job<crate::check::types::St> for PlainArg {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fname_p2 = &self.fname_p2;
        let param_p3 = &self.param_p3;
        let at_p4 = &self.at_p4;
        let a_p5 = &self.a_p5;
        let a_p5x = a_p5.clone();
        let at_p4x = at_p4.clone();
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        let param_p3x = param_p3.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), param_p3x.clone()), move |walk_f_21290: crate::check::types::Ty| {
            let p_p6 = walk_f_21290;
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), p_p6.clone()), move |head_sigil_f_21318: crate::prelude::Text| {
                let ph_p7 = head_sigil_f_21318;
                if &at_p4x == &crate::check::types::Ty::TyErr {
                    ::prism_rtl::Turn::Finished(st_p1x.clone())
                } else {
                    if crate::check::expr::is_time_sigil_f(&ph_p7) || (&ph_p7 == &crate::prelude::Text::lit("@")) {
                        crate::prelude::call_then(crate::check::types::start_is_flex_var_f(st_p1x.clone(), at_p4x.clone()), move |is_flex_var_f_21424: bool| {
                            let a_p5xz = a_p5x.clone();
                            let env_p0xz = env_p0x.clone();
                            let fname_p2xz = fname_p2x.clone();
                            let p_p6z = p_p6.clone();
                            let ph_p7z = ph_p7.clone();
                            let st_p1xz = st_p1x.clone();
                            let k_let21409 = move |v21409: crate::prelude::Text| {
                                let shown_p8 = v21409;
                                crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1xz.clone(), p_p6z.clone()), move |show_ty_f_21587: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1xz, &crate::prelude::Text::lit("plain-for-sigiled"), &a_p5xz.value_p.span_p, &crate::prelude::Text::from(format!("a plain `{}` where `{}` takes a `{}`", &shown_p8, &fname_p2xz, &show_ty_f_21587)), &crate::prelude::Text::from(format!("write `{} {}`", &ph_p7z, &crate::check::expr::src_text_f(&env_p0xz, &a_p5xz.value_p.span_p))))))
                            };
                            if is_flex_var_f_21424 {
                                k_let21409(crate::check::expr::src_text_f(&env_p0x, &a_p5x.value_p.span_p))
                            } else {
                                crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), at_p4x.clone()), move |show_ty_f_21474: crate::prelude::Text| k_let21409(show_ty_f_21474))
                            }
                        })
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::recording::UnifyAt { st_p0: st_p1x.clone(), expected_p1: p_p6.clone(), found_p2: at_p4x.clone(), span_p3: a_p5x.value_p.span_p.clone() }))
                    }
                }
            })
        })
    }
}

/// `Start PlainArg, x`: what the function value is when passed to `@Run`.
pub fn start_plain_arg_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fname_p2: crate::prelude::Text, param_p3: crate::check::types::Ty, at_p4: crate::check::types::Ty, a_p5: crate::syntax::Arg) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(PlainArg { env_p0, st_p1, fname_p2, param_p3, at_p4, a_p5 })
}

/// ```prism
/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub fn layered_arg_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, acc_p2: &Peeled, fname_p3: &crate::prelude::Text, cmp_p4: &bool, param_p5: &crate::check::types::Ty, at_p6: &crate::check::types::Ty, a_p7: &crate::syntax::Arg) -> (Peeled, crate::check::types::St) {
    let p_p8 = crate::check::types::unify::norm_assoc_f(st_p1, &crate::check::types::recording::walk_f(st_p1, param_p5));
    let span_p9 = a_p7.value_p.span_p.clone();
    let ph_pa = crate::check::types::head_sigil_f(st_p1, &p_p8);
    if crate::check::types::unify::is_waiting_assoc_f(st_p1, &p_p8) && !crate::check::types::is_free_headed_f(st_p1, at_p6) {
        (acc_p2.clone(), crate::check::types::recording::err_fix_f(&crate::check::types::unify::unify_f(st_p1, &p_p8, at_p6, &span_p9), &crate::prelude::Text::lit("ambiguous"), &span_p9, &crate::prelude::Text::from(format!("whether `{}` takes this `{}` whole or lifts over it depends on an associated type nothing has decided here", fname_p3, &crate::check::types::head_sigil_f(st_p1, at_p6))), &crate::prelude::Text::lit("decide the type before the call, by an argument of it or an annotation on one")))
    } else {
        if crate::check::types::is_free_headed_f(st_p1, at_p6) {
            {
                let st2_pb = if ((crate::check::expr::is_time_sigil_f(&ph_pa) || (&ph_pa == &crate::prelude::Text::lit("@"))) || (&ph_pa == &crate::prelude::Text::lit("&"))) || *cmp_p4 {
                    st_p1.clone()
                } else {
                    crate::check::types::unify::ask_layer_f(st_p1, at_p6, &span_p9, fname_p3)
                };
                (acc_p2.clone(), crate::check::types::unify::unify_f(&st2_pb, &p_p8, at_p6, &span_p9))
            }
        } else {
            if (crate::check::expr::is_time_sigil_f(&ph_pa) || (&ph_pa == &crate::prelude::Text::lit("@"))) || (&ph_pa == &crate::prelude::Text::lit("&")) {
                (acc_p2.clone(), crate::check::types::unify::unify_f(st_p1, &p_p8, at_p6, &span_p9))
            } else {
                if crate::check::expr::is_plain_sigil_f(&ph_pa) {
                    peel_time_only_f(env_p0, st_p1, acc_p2, fname_p3, &p_p8, at_p6, a_p7)
                } else {
                    {
                        let head_pc = crate::check::types::head_sigil_f(st_p1, at_p6);
                        if &head_pc == &crate::prelude::Text::lit("@") {
                            (acc_p2.clone(), crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("blueprint-operand"), &span_p9, &crate::prelude::Text::from(format!("`{}` over a blueprint; bind it first", fname_p3)), &crate::prelude::Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text_f(env_p0, &span_p9)))))
                        } else {
                            if crate::check::expr::is_time_sigil_f(&head_pc) {
                                {
                                    let inner_pd = crate::check::expr::inner_of_f(st_p1, at_p6);
                                    let ih_pe = crate::check::types::head_sigil_f(st_p1, &inner_pd);
                                    let acc2_pf = {
                                        let mut this: Peeled = acc_p2.clone();
                                        if &head_pc == &crate::prelude::Text::lit("!") {
                                            this.events_p = crate::prelude::push(&this.events_p, &span_p9);
                                        } else {
                                            this.dyns_p = crate::prelude::push(&this.dyns_p, &span_p9);
                                        }
                                        if &this.lifted_p == &crate::prelude::Text::lit("") {
                                            this.lifted_p = crate::check::expr::src_text_f(env_p0, &span_p9);
                                        }
                                        this
                                    };
                                    if crate::check::expr::is_time_sigil_f(&ih_pe) {
                                        {
                                            let what_pg = if &ih_pe == &crate::prelude::Text::lit("$") {
                                                crate::prelude::Text::lit("dynamic")
                                            } else {
                                                crate::prelude::Text::lit("event")
                                            };
                                            (acc2_pf.clone(), crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("two-layers"), &span_p9, &crate::prelude::Text::from(format!("`{}` over a {} of {}s", fname_p3, &(if &head_pc == &crate::prelude::Text::lit("$") {
                                                crate::prelude::Text::lit("dynamic")
                                            } else {
                                                crate::prelude::Text::lit("event")
                                            }), &what_pg)), &crate::prelude::Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))
                                        }
                                    } else {
                                        if crate::check::expr::is_plain_sigil_f(&ih_pe) && !*cmp_p4 {
                                            {
                                                let inner2_ph = crate::check::expr::inner_of_f(st_p1, &inner_pd);
                                                if crate::check::expr::is_time_sigil_f(&crate::check::types::head_sigil_f(st_p1, &inner2_ph)) || (&crate::check::types::head_sigil_f(st_p1, &inner2_ph) == &crate::prelude::Text::lit("@")) {
                                                    (acc2_pf.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("layer-under-optional"), &span_p9, &crate::prelude::Text::from(format!("`{}` over an optional {}dynamic", fname_p3, &(if &ih_pe == &crate::prelude::Text::lit("?") {
                                                        crate::prelude::Text::lit("")
                                                    } else {
                                                        crate::prelude::Text::lit("fault ")
                                                    })))))
                                                } else {
                                                    {
                                                        let acc3_pi = {
                                                            let mut this: Peeled = acc2_pf.clone();
                                                            this.opts_p = crate::check::types::add_text_f(&this.opts_p, &ih_pe);
                                                            this.opt_args_p = crate::prelude::push(&this.opt_args_p, &span_p9);
                                                            this
                                                        };
                                                        (acc3_pi.clone(), crate::check::types::unify::unify_f(st_p1, &p_p8, &inner2_ph, &span_p9))
                                                    }
                                                }
                                            }
                                        } else {
                                            (acc2_pf.clone(), crate::check::types::unify::unify_f(st_p1, &p_p8, &inner_pd, &span_p9))
                                        }
                                    }
                                }
                            } else {
                                if crate::check::expr::is_plain_sigil_f(&head_pc) && !*cmp_p4 {
                                    {
                                        let inner_pj = crate::check::expr::inner_of_f(st_p1, at_p6);
                                        let ih_pk = crate::check::types::head_sigil_f(st_p1, &inner_pj);
                                        if crate::check::expr::is_time_sigil_f(&ih_pk) || (&ih_pk == &crate::prelude::Text::lit("@")) {
                                            (acc_p2.clone(), crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("layer-under-optional"), &span_p9, &crate::prelude::Text::from(format!("`{}` over an optional dynamic", fname_p3)), &crate::prelude::Text::lit("match the optional once, at build time, to find out whether there is a dynamic")))
                                        } else {
                                            {
                                                let acc2_pl = {
                                                    let mut this: Peeled = acc_p2.clone();
                                                    this.opts_p = crate::check::types::add_text_f(&this.opts_p, &head_pc);
                                                    this.opt_args_p = crate::prelude::push(&this.opt_args_p, &span_p9);
                                                    this
                                                };
                                                (acc2_pl.clone(), crate::check::types::unify::unify_f(st_p1, &p_p8, &inner_pj, &span_p9))
                                            }
                                        }
                                    }
                                } else {
                                    if &head_pc == &crate::prelude::Text::lit("&") {
                                        (acc_p2.clone(), crate::check::types::unify::unify_f(st_p1, &p_p8, &crate::check::expr::inner_of_f(st_p1, at_p6), &span_p9))
                                    } else {
                                        (acc_p2.clone(), crate::check::types::unify::unify_f(st_p1, &p_p8, at_p6, &span_p9))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `LayeredArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub struct LayeredArg {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub acc_p2: Peeled,
    pub fname_p3: crate::prelude::Text,
    pub cmp_p4: bool,
    pub param_p5: crate::check::types::Ty,
    pub at_p6: crate::check::types::Ty,
    pub a_p7: crate::syntax::Arg,
}

impl ::prism_rtl::Job<(Peeled, crate::check::types::St)> for LayeredArg {
    fn cycle(&self) -> ::prism_rtl::Turn<(Peeled, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let acc_p2 = &self.acc_p2;
        let fname_p3 = &self.fname_p3;
        let cmp_p4 = &self.cmp_p4;
        let param_p5 = &self.param_p5;
        let at_p6 = &self.at_p6;
        let a_p7 = &self.a_p7;
        let a_p7x = a_p7.clone();
        let acc_p2x = acc_p2.clone();
        let at_p6x = at_p6.clone();
        let cmp_p4x = *cmp_p4;
        let env_p0x = env_p0.clone();
        let fname_p3x = fname_p3.clone();
        let param_p5x = param_p5.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), param_p5x.clone()), move |walk_f_22061: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::unify::start_norm_assoc_f(st_p1x.clone(), walk_f_22061), move |norm_assoc_f_22046: crate::check::types::Ty| {
            let p_p8 = norm_assoc_f_22046;
            let span_p9 = a_p7x.value_p.span_p.clone();
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), p_p8.clone()), move |head_sigil_f_22118: crate::prelude::Text| {
                let ph_pa = head_sigil_f_22118;
                crate::prelude::call_then(crate::check::types::unify::start_is_waiting_assoc_f(st_p1x.clone(), p_p8.clone()), move |is_waiting_assoc_f_22305: bool| if is_waiting_assoc_f_22305 && !crate::check::types::is_free_headed_f(&st_p1x, &at_p6x) {
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p8.clone(), at_p6x.clone(), span_p9.clone()), move |unify_f_22382: crate::check::types::St| crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), at_p6x.clone()), move |head_sigil_f_22457: crate::prelude::Text| ::prism_rtl::Turn::Finished((acc_p2x.clone(), crate::check::types::recording::err_fix_f(&unify_f_22382, &crate::prelude::Text::lit("ambiguous"), &span_p9, &crate::prelude::Text::from(format!("whether `{}` takes this `{}` whole or lifts over it depends on an associated type nothing has decided here", &fname_p3x, &head_sigil_f_22457)), &crate::prelude::Text::lit("decide the type before the call, by an argument of it or an annotation on one"))))))
                } else {
                    crate::prelude::call_then(crate::check::types::start_is_free_headed_f(st_p1x.clone(), at_p6x.clone()), move |is_free_headed_f_22652: bool| if is_free_headed_f_22652 {
                        {
                            let st2_pb = if ((crate::check::expr::is_time_sigil_f(&ph_pa) || (&ph_pa == &crate::prelude::Text::lit("@"))) || (&ph_pa == &crate::prelude::Text::lit("&"))) || cmp_p4x {
                                st_p1x.clone()
                            } else {
                                crate::check::types::unify::ask_layer_f(&st_p1x, &at_p6x, &span_p9, &fname_p3x)
                            };
                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pb.clone(), p_p8.clone(), at_p6x.clone(), span_p9.clone()), move |unify_f_22799: crate::check::types::St| ::prism_rtl::Turn::Finished((acc_p2x.clone(), unify_f_22799)))
                        }
                    } else {
                        if (crate::check::expr::is_time_sigil_f(&ph_pa) || (&ph_pa == &crate::prelude::Text::lit("@"))) || (&ph_pa == &crate::prelude::Text::lit("&")) {
                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p8.clone(), at_p6x.clone(), span_p9.clone()), move |unify_f_22890: crate::check::types::St| ::prism_rtl::Turn::Finished((acc_p2x.clone(), unify_f_22890)))
                        } else {
                            if crate::check::expr::is_plain_sigil_f(&ph_pa) {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(PeelTimeOnly { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), acc_p2: acc_p2x.clone(), fname_p3: fname_p3x.clone(), p_p4: p_p8.clone(), at_p5: at_p6x.clone(), a_p6: a_p7x.clone() }))
                            } else {
                                crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), at_p6x.clone()), move |head_sigil_f_23017: crate::prelude::Text| {
                                    let head_pc = head_sigil_f_23017;
                                    if &head_pc == &crate::prelude::Text::lit("@") {
                                        ::prism_rtl::Turn::Finished((acc_p2x.clone(), crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("blueprint-operand"), &span_p9, &crate::prelude::Text::from(format!("`{}` over a blueprint; bind it first", &fname_p3x)), &crate::prelude::Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text_f(&env_p0x, &span_p9))))))
                                    } else {
                                        if crate::check::expr::is_time_sigil_f(&head_pc) {
                                            crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x.clone(), at_p6x.clone()), move |inner_of_f_23262: crate::check::types::Ty| {
                                                let inner_pd = inner_of_f_23262;
                                                crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), inner_pd.clone()), move |head_sigil_f_23298: crate::prelude::Text| {
                                                    let ih_pe = head_sigil_f_23298;
                                                    let acc2_pf = {
                                                        let mut this: Peeled = acc_p2x.clone();
                                                        if &head_pc == &crate::prelude::Text::lit("!") {
                                                            this.events_p = crate::prelude::push(&this.events_p, &span_p9);
                                                        } else {
                                                            this.dyns_p = crate::prelude::push(&this.dyns_p, &span_p9);
                                                        }
                                                        if &this.lifted_p == &crate::prelude::Text::lit("") {
                                                            this.lifted_p = crate::check::expr::src_text_f(&env_p0x, &span_p9);
                                                        }
                                                        this
                                                    };
                                                    if crate::check::expr::is_time_sigil_f(&ih_pe) {
                                                        {
                                                            let what_pg = if &ih_pe == &crate::prelude::Text::lit("$") {
                                                                crate::prelude::Text::lit("dynamic")
                                                            } else {
                                                                crate::prelude::Text::lit("event")
                                                            };
                                                            ::prism_rtl::Turn::Finished((acc2_pf.clone(), crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("two-layers"), &span_p9, &crate::prelude::Text::from(format!("`{}` over a {} of {}s", &fname_p3x, &(if &head_pc == &crate::prelude::Text::lit("$") {
                                                                crate::prelude::Text::lit("dynamic")
                                                            } else {
                                                                crate::prelude::Text::lit("event")
                                                            }), &what_pg)), &crate::prelude::Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))))
                                                        }
                                                    } else {
                                                        if crate::check::expr::is_plain_sigil_f(&ih_pe) && !cmp_p4x {
                                                            crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x.clone(), inner_pd.clone()), move |inner_of_f_23974: crate::check::types::Ty| {
                                                                let inner2_ph = inner_of_f_23974;
                                                                crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), inner2_ph.clone()), move |head_sigil_f_24025: crate::prelude::Text| if crate::check::expr::is_time_sigil_f(&head_sigil_f_24025) || (&crate::check::types::head_sigil_f(&st_p1x, &inner2_ph) == &crate::prelude::Text::lit("@")) {
                                                                    ::prism_rtl::Turn::Finished((acc2_pf.clone(), crate::check::types::recording::err_f(&st_p1x, &crate::prelude::Text::lit("layer-under-optional"), &span_p9, &crate::prelude::Text::from(format!("`{}` over an optional {}dynamic", &fname_p3x, &(if &ih_pe == &crate::prelude::Text::lit("?") {
                                                                        crate::prelude::Text::lit("")
                                                                    } else {
                                                                        crate::prelude::Text::lit("fault ")
                                                                    }))))))
                                                                } else {
                                                                    {
                                                                        let acc3_pi = {
                                                                            let mut this: Peeled = acc2_pf.clone();
                                                                            this.opts_p = crate::check::types::add_text_f(&this.opts_p, &ih_pe);
                                                                            this.opt_args_p = crate::prelude::push(&this.opt_args_p, &span_p9);
                                                                            this
                                                                        };
                                                                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p8.clone(), inner2_ph.clone(), span_p9.clone()), move |unify_f_24432: crate::check::types::St| ::prism_rtl::Turn::Finished((acc3_pi.clone(), unify_f_24432)))
                                                                    }
                                                                })
                                                            })
                                                        } else {
                                                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p8.clone(), inner_pd.clone(), span_p9.clone()), move |unify_f_24488: crate::check::types::St| ::prism_rtl::Turn::Finished((acc2_pf.clone(), unify_f_24488)))
                                                        }
                                                    }
                                                })
                                            })
                                        } else {
                                            if crate::check::expr::is_plain_sigil_f(&head_pc) && !cmp_p4x {
                                                crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x.clone(), at_p6x.clone()), move |inner_of_f_24590: crate::check::types::Ty| {
                                                    let inner_pj = inner_of_f_24590;
                                                    crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), inner_pj.clone()), move |head_sigil_f_24626: crate::prelude::Text| {
                                                        let ih_pk = head_sigil_f_24626;
                                                        if crate::check::expr::is_time_sigil_f(&ih_pk) || (&ih_pk == &crate::prelude::Text::lit("@")) {
                                                            ::prism_rtl::Turn::Finished((acc_p2x.clone(), crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("layer-under-optional"), &span_p9, &crate::prelude::Text::from(format!("`{}` over an optional dynamic", &fname_p3x)), &crate::prelude::Text::lit("match the optional once, at build time, to find out whether there is a dynamic"))))
                                                        } else {
                                                            {
                                                                let acc2_pl = {
                                                                    let mut this: Peeled = acc_p2x.clone();
                                                                    this.opts_p = crate::check::types::add_text_f(&this.opts_p, &head_pc);
                                                                    this.opt_args_p = crate::prelude::push(&this.opt_args_p, &span_p9);
                                                                    this
                                                                };
                                                                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p8.clone(), inner_pj.clone(), span_p9.clone()), move |unify_f_25070: crate::check::types::St| ::prism_rtl::Turn::Finished((acc2_pl.clone(), unify_f_25070)))
                                                            }
                                                        }
                                                    })
                                                })
                                            } else {
                                                if &head_pc == &crate::prelude::Text::lit("&") {
                                                    crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x.clone(), at_p6x.clone()), move |inner_of_f_25150: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p8.clone(), inner_of_f_25150, span_p9.clone()), move |unify_f_25136: crate::check::types::St| ::prism_rtl::Turn::Finished((acc_p2x.clone(), unify_f_25136))))
                                                } else {
                                                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p8.clone(), at_p6x.clone(), span_p9.clone()), move |unify_f_25197: crate::check::types::St| ::prism_rtl::Turn::Finished((acc_p2x.clone(), unify_f_25197)))
                                                }
                                            }
                                        }
                                    }
                                })
                            }
                        }
                    })
                })
            })
        }))
    }
}

/// `Start LayeredArg, x`: what the function value is when passed to `@Run`.
pub fn start_layered_arg_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, acc_p2: Peeled, fname_p3: crate::prelude::Text, cmp_p4: bool, param_p5: crate::check::types::Ty, at_p6: crate::check::types::Ty, a_p7: crate::syntax::Arg) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(Peeled, crate::check::types::St)>> {
    ::std::rc::Rc::new(LayeredArg { env_p0, st_p1, acc_p2, fname_p3, cmp_p4, param_p5, at_p6, a_p7 })
}

/// ```prism
/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub fn peel_time_only_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, acc_p2: &Peeled, fname_p3: &crate::prelude::Text, p_p4: &crate::check::types::Ty, at_p5: &crate::check::types::Ty, a_p6: &crate::syntax::Arg) -> (Peeled, crate::check::types::St) {
    let span_p7 = a_p6.value_p.span_p.clone();
    let head_p8 = crate::check::types::head_sigil_f(st_p1, at_p5);
    if &head_p8 == &crate::prelude::Text::lit("@") {
        (acc_p2.clone(), crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("blueprint-operand"), &span_p7, &crate::prelude::Text::from(format!("`{}` over a blueprint; bind it first", fname_p3)), &crate::prelude::Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text_f(env_p0, &span_p7)))))
    } else {
        if crate::check::expr::is_time_sigil_f(&head_p8) {
            {
                let inner_p9 = crate::check::expr::inner_of_f(st_p1, at_p5);
                let acc2_pa = {
                    let mut this: Peeled = acc_p2.clone();
                    if &head_p8 == &crate::prelude::Text::lit("!") {
                        this.events_p = crate::prelude::push(&this.events_p, &span_p7);
                    } else {
                        this.dyns_p = crate::prelude::push(&this.dyns_p, &span_p7);
                    }
                    if &this.lifted_p == &crate::prelude::Text::lit("") {
                        this.lifted_p = crate::check::expr::src_text_f(env_p0, &span_p7);
                    }
                    this
                };
                if crate::check::expr::is_time_sigil_f(&crate::check::types::head_sigil_f(st_p1, &inner_p9)) {
                    (acc2_pa.clone(), crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("two-layers"), &span_p7, &crate::prelude::Text::from(format!("`{}` over a {} of {}s", fname_p3, &(if &head_p8 == &crate::prelude::Text::lit("$") {
                        crate::prelude::Text::lit("dynamic")
                    } else {
                        crate::prelude::Text::lit("event")
                    }), &(if &crate::check::types::head_sigil_f(st_p1, &inner_p9) == &crate::prelude::Text::lit("$") {
                        crate::prelude::Text::lit("dynamic")
                    } else {
                        crate::prelude::Text::lit("event")
                    }))), &crate::prelude::Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))
                } else {
                    (acc2_pa.clone(), crate::check::types::unify::unify_f(st_p1, p_p4, &inner_p9, &span_p7))
                }
            }
        } else {
            (acc_p2.clone(), crate::check::types::unify::unify_f(st_p1, p_p4, at_p5, &span_p7))
        }
    }
}

/// The step machine of `PeelTimeOnly`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub struct PeelTimeOnly {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub acc_p2: Peeled,
    pub fname_p3: crate::prelude::Text,
    pub p_p4: crate::check::types::Ty,
    pub at_p5: crate::check::types::Ty,
    pub a_p6: crate::syntax::Arg,
}

impl ::prism_rtl::Job<(Peeled, crate::check::types::St)> for PeelTimeOnly {
    fn cycle(&self) -> ::prism_rtl::Turn<(Peeled, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let acc_p2 = &self.acc_p2;
        let fname_p3 = &self.fname_p3;
        let p_p4 = &self.p_p4;
        let at_p5 = &self.at_p5;
        let a_p6 = &self.a_p6;
        let span_p7 = a_p6.value_p.span_p.clone();
        let acc_p2x = acc_p2.clone();
        let at_p5x = at_p5.clone();
        let env_p0x = env_p0.clone();
        let fname_p3x = fname_p3.clone();
        let p_p4x = p_p4.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), at_p5x.clone()), move |head_sigil_f_25483: crate::prelude::Text| {
            let head_p8 = head_sigil_f_25483;
            if &head_p8 == &crate::prelude::Text::lit("@") {
                ::prism_rtl::Turn::Finished((acc_p2x.clone(), crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("blueprint-operand"), &span_p7, &crate::prelude::Text::from(format!("`{}` over a blueprint; bind it first", &fname_p3x)), &crate::prelude::Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text_f(&env_p0x, &span_p7))))))
            } else {
                if crate::check::expr::is_time_sigil_f(&head_p8) {
                    crate::prelude::call_then(crate::check::expr::start_inner_of_f(st_p1x.clone(), at_p5x.clone()), move |inner_of_f_25716: crate::check::types::Ty| {
                        let inner_p9 = inner_of_f_25716;
                        let acc2_pa = {
                            let mut this: Peeled = acc_p2x.clone();
                            if &head_p8 == &crate::prelude::Text::lit("!") {
                                this.events_p = crate::prelude::push(&this.events_p, &span_p7);
                            } else {
                                this.dyns_p = crate::prelude::push(&this.dyns_p, &span_p7);
                            }
                            if &this.lifted_p == &crate::prelude::Text::lit("") {
                                this.lifted_p = crate::check::expr::src_text_f(&env_p0x, &span_p7);
                            }
                            this
                        };
                        crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), inner_p9.clone()), move |head_sigil_f_26007: crate::prelude::Text| if crate::check::expr::is_time_sigil_f(&head_sigil_f_26007) {
                            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), inner_p9.clone()), move |head_sigil_f_26137: crate::prelude::Text| ::prism_rtl::Turn::Finished((acc2_pa.clone(), crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("two-layers"), &span_p7, &crate::prelude::Text::from(format!("`{}` over a {} of {}s", &fname_p3x, &(if &head_p8 == &crate::prelude::Text::lit("$") {
                                crate::prelude::Text::lit("dynamic")
                            } else {
                                crate::prelude::Text::lit("event")
                            }), &(if &head_sigil_f_26137 == &crate::prelude::Text::lit("$") {
                                crate::prelude::Text::lit("dynamic")
                            } else {
                                crate::prelude::Text::lit("event")
                            }))), &crate::prelude::Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))))
                        } else {
                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p4x.clone(), inner_p9.clone(), span_p7.clone()), move |unify_f_26287: crate::check::types::St| ::prism_rtl::Turn::Finished((acc2_pa.clone(), unify_f_26287)))
                        })
                    })
                } else {
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), p_p4x.clone(), at_p5x.clone(), span_p7.clone()), move |unify_f_26333: crate::check::types::St| ::prism_rtl::Turn::Finished((acc_p2x.clone(), unify_f_26333)))
                }
            }
        })
    }
}

/// `Start PeelTimeOnly, x`: what the function value is when passed to `@Run`.
pub fn start_peel_time_only_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, acc_p2: Peeled, fname_p3: crate::prelude::Text, p_p4: crate::check::types::Ty, at_p5: crate::check::types::Ty, a_p6: crate::syntax::Arg) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(Peeled, crate::check::types::St)>> {
    ::std::rc::Rc::new(PeelTimeOnly { env_p0, st_p1, acc_p2, fname_p3, p_p4, at_p5, a_p6 })
}

/// ```prism
/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
/// ```
pub fn ctor_app_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::check::env::CtorInfo, args_p3: &crate::prelude::Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range, cspan_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (self_pa, st0_pb, inst_pc) = crate::check::types::schemes::instantiate_with_f(st_p1, &crate::check::types::Scheme { qs_p: c_p2.params_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: c_p2.ty_p.clone() }, span_p4, &crate::prelude::Array::new());
    let field_tys_p6 = crate::prelude::run_to_end(crate::prelude::each_job(c_p2.args_p.clone(), {
        let inst_pcx = inst_pc.clone();
        ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
            let inst_pcxy = inst_pcx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let t_pd = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::schemes::SubstQ { m_p0: inst_pcxy.clone(), t_p1: t_pd.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
    }));
    let st1_p7 = named_twice_f(&crate::check::types::recording::note_ty_f(&st0_pb, cspan_p5, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_p6.clone(), ::std::rc::Rc::new(self_pa.clone()))), args_p3);
    let named_p8 = crate::prelude::filter(args_p3, &(|a_pe: &crate::syntax::Arg| &a_pe.name_o != &::std::option::Option::None));
    let lifts_p9 = (&crate::prelude::len(&c_p2.params_p) == &crate::prelude::Nat::from(0u32)) || !crate::prelude::fold(&c_p2.args_p, &false, &(|bare_pf: &bool, t_pg: &crate::check::types::Ty| *bare_pf || is_bare_parameter_f(t_pg)));
    if (&crate::prelude::len(&named_p8) > &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&c_p2.fields_p) > &crate::prelude::Nat::from(0u32)) {
        {
            let st2_ph = crate::prelude::run_to_end(crate::prelude::fold_job(named_p8.clone(), st1_p7.clone(), {
                let c_p2x = c_p2.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arg)| {
                    let c_p2xy = c_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_pm = p0;
                        let a_pn = p1;
                        match &a_pn.name_o {
                            ::std::option::Option::Some(id_po) => match crate::check::expr::operators::index_of_o(&c_p2xy.fields_p, &id_po.name_p) {
                                ::std::option::Option::Some(i_pp) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ArgMarks { st_p0: s_pm.clone(), owner_p1: crate::check::types::bare_name_f(&c_p2xy.owner_p), field_p2: id_po.name_p.clone(), declared_p3: crate::prelude::or(&crate::prelude::index(&c_p2xy.args_p, &i_pp), &crate::check::types::Ty::TyErr), marks_p4: a_pn.marks_p.clone(), span_p5: a_pn.span_p.clone() })),
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_pm, &crate::prelude::Text::lit("mismatch"), &a_pn.span_p, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name_f(&c_p2xy.owner_p), &id_po.name_p)))),
                            },
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_pm.clone()),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
            }));
            let missing_pi = crate::prelude::filter(&c_p2.fields_p, &(|f_pq: &crate::prelude::Text| !crate::prelude::fold(&named_p8, &false, &(|seen_pr: &bool, a_ps: &crate::syntax::Arg| *seen_pr || arg_named_f(a_ps, f_pq)))));
            let st3_pj = if &crate::prelude::len(&missing_pi) > &crate::prelude::Nat::from(0u32) {
                crate::check::types::recording::err_f(&st2_ph, &crate::prelude::Text::lit("mismatch"), span_p4, &crate::prelude::Text::from(format!("`{}` needs {}", &crate::check::types::bare_name_f(&c_p2.owner_p), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&missing_pi, &(|f_pt: &crate::prelude::Text| crate::prelude::Text::from(format!("`{}`", f_pt)))), &crate::prelude::Text::lit(", ")))))
            } else {
                st2_ph.clone()
            };
            let known_pk = crate::prelude::filter(&named_p8, &(|a_pu: &crate::syntax::Arg| match &a_pu.name_o {
                ::std::option::Option::Some(id_pv) => &crate::check::expr::operators::index_of_o(&c_p2.fields_p, &id_pv.name_p) != &::std::option::Option::None,
                ::std::option::Option::None => false,
            }));
            let ptys_pl = crate::prelude::each(&known_pk, &(|a_p10: &crate::syntax::Arg| match &a_p10.name_o {
                ::std::option::Option::Some(id_p11) => crate::prelude::or(&crate::prelude::index(&field_tys_p6, &crate::prelude::or(&crate::check::expr::operators::index_of_o(&c_p2.fields_p, &id_p11.name_p), &crate::prelude::Nat::from(0u32))), &crate::check::types::Ty::TyErr),
                ::std::option::Option::None => crate::check::types::Ty::TyErr,
            }));
            ctor_args_f(env_p0, &st3_pj, c_p2, &known_pk, &ptys_pl, &self_pa, &lifts_p9, span_p4)
        }
    } else {
        if &crate::prelude::len(args_p3) != &crate::prelude::len(&field_tys_p6) {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st1_p7, &crate::prelude::Text::lit("mismatch"), span_p4, &crate::prelude::Text::from(format!("`{}` takes {} argument{}; here it has {}", &crate::check::types::bare_name_f(&c_p2.name_p), &crate::check::errors::count_word_f(&crate::prelude::len(&field_tys_p6)), &(if &crate::prelude::len(&field_tys_p6) == &crate::prelude::Nat::from(1u32) {
                crate::prelude::Text::lit("")
            } else {
                crate::prelude::Text::lit("s")
            }), &crate::check::errors::count_word_f(&crate::prelude::len(args_p3))))))
        } else {
            ctor_args_f(env_p0, &st1_p7, c_p2, args_p3, &field_tys_p6, &self_pa, &lifts_p9, span_p4)
        }
    }
}

/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
/// ```
pub struct CtorApp {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::check::env::CtorInfo,
    pub args_p3: crate::prelude::Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
    pub cspan_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for CtorApp {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let cspan_p5 = &self.cspan_p5;
        let args_p3x = args_p3.clone();
        let c_p2x = c_p2.clone();
        let cspan_p5x = cspan_p5.clone();
        let env_p0x = env_p0.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p1x.clone(), crate::check::types::Scheme { qs_p: c_p2x.params_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: c_p2x.ty_p.clone() }, span_p4x.clone(), crate::prelude::Array::new()), move |instantiate_with_f_27231: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
            let (self_pa, st0_pb, inst_pc) = instantiate_with_f_27231;
            crate::prelude::call_value(crate::prelude::each_job(c_p2x.args_p.clone(), {
                let inst_pcx = inst_pc.clone();
                ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                    let inst_pcxy = inst_pcx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let t_pd = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::schemes::SubstQ { m_p0: inst_pcxy.clone(), t_p1: t_pd.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_27383: crate::prelude::Array<crate::check::types::Ty>| {
                let field_tys_p6 = each_27383;
                let st1_p7 = named_twice_f(&crate::check::types::recording::note_ty_f(&st0_pb, &cspan_p5x, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_p6.clone(), ::std::rc::Rc::new(self_pa.clone()))), &args_p3x);
                let named_p8 = crate::prelude::filter(&args_p3x, &(|a_pe: &crate::syntax::Arg| &a_pe.name_o != &::std::option::Option::None));
                let lifts_p9 = (&crate::prelude::len(&c_p2x.params_p) == &crate::prelude::Nat::from(0u32)) || !crate::prelude::fold(&c_p2x.args_p, &false, &(|bare_pf: &bool, t_pg: &crate::check::types::Ty| *bare_pf || is_bare_parameter_f(t_pg)));
                if (&crate::prelude::len(&named_p8) > &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&c_p2x.fields_p) > &crate::prelude::Nat::from(0u32)) {
                    crate::prelude::call_value(crate::prelude::fold_job(named_p8.clone(), st1_p7.clone(), {
                        let c_p2xx = c_p2x.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arg)| {
                            let c_p2xxy = c_p2xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let s_pm = p0;
                                let a_pn = p1;
                                match &a_pn.name_o {
                                    ::std::option::Option::Some(id_po) => match crate::check::expr::operators::index_of_o(&c_p2xxy.fields_p, &id_po.name_p) {
                                        ::std::option::Option::Some(i_pp) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ArgMarks { st_p0: s_pm.clone(), owner_p1: crate::check::types::bare_name_f(&c_p2xxy.owner_p), field_p2: id_po.name_p.clone(), declared_p3: crate::prelude::or(&crate::prelude::index(&c_p2xxy.args_p, &i_pp), &crate::check::types::Ty::TyErr), marks_p4: a_pn.marks_p.clone(), span_p5: a_pn.span_p.clone() })),
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&s_pm, &crate::prelude::Text::lit("mismatch"), &a_pn.span_p, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name_f(&c_p2xxy.owner_p), &id_po.name_p)))),
                                    },
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_pm.clone()),
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_27714: crate::check::types::St| {
                        let st2_ph = fold_27714;
                        let missing_pi = crate::prelude::filter(&c_p2x.fields_p, &(|f_pq: &crate::prelude::Text| !crate::prelude::fold(&named_p8, &false, &(|seen_pr: &bool, a_ps: &crate::syntax::Arg| *seen_pr || arg_named_f(a_ps, f_pq)))));
                        let st3_pj = if &crate::prelude::len(&missing_pi) > &crate::prelude::Nat::from(0u32) {
                            crate::check::types::recording::err_f(&st2_ph, &crate::prelude::Text::lit("mismatch"), &span_p4x, &crate::prelude::Text::from(format!("`{}` needs {}", &crate::check::types::bare_name_f(&c_p2x.owner_p), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&missing_pi, &(|f_pt: &crate::prelude::Text| crate::prelude::Text::from(format!("`{}`", f_pt)))), &crate::prelude::Text::lit(", ")))))
                        } else {
                            st2_ph.clone()
                        };
                        let known_pk = crate::prelude::filter(&named_p8, &(|a_pu: &crate::syntax::Arg| match &a_pu.name_o {
                            ::std::option::Option::Some(id_pv) => &crate::check::expr::operators::index_of_o(&c_p2x.fields_p, &id_pv.name_p) != &::std::option::Option::None,
                            ::std::option::Option::None => false,
                        }));
                        let ptys_pl = crate::prelude::each(&known_pk, &(|a_p10: &crate::syntax::Arg| match &a_p10.name_o {
                            ::std::option::Option::Some(id_p11) => crate::prelude::or(&crate::prelude::index(&field_tys_p6, &crate::prelude::or(&crate::check::expr::operators::index_of_o(&c_p2x.fields_p, &id_p11.name_p), &crate::prelude::Nat::from(0u32))), &crate::check::types::Ty::TyErr),
                            ::std::option::Option::None => crate::check::types::Ty::TyErr,
                        }));
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(CtorArgs { env_p0: env_p0x.clone(), st_p1: st3_pj.clone(), c_p2: c_p2x.clone(), args_p3: known_pk.clone(), ptys_p4: ptys_pl.clone(), self_p5: self_pa.clone(), lifts_p6: lifts_p9, span_p7: span_p4x.clone() }))
                    })
                } else {
                    if &crate::prelude::len(&args_p3x) != &crate::prelude::len(&field_tys_p6) {
                        ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st1_p7, &crate::prelude::Text::lit("mismatch"), &span_p4x, &crate::prelude::Text::from(format!("`{}` takes {} argument{}; here it has {}", &crate::check::types::bare_name_f(&c_p2x.name_p), &crate::check::errors::count_word_f(&crate::prelude::len(&field_tys_p6)), &(if &crate::prelude::len(&field_tys_p6) == &crate::prelude::Nat::from(1u32) {
                            crate::prelude::Text::lit("")
                        } else {
                            crate::prelude::Text::lit("s")
                        }), &crate::check::errors::count_word_f(&crate::prelude::len(&args_p3x)))))))
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(CtorArgs { env_p0: env_p0x.clone(), st_p1: st1_p7.clone(), c_p2: c_p2x.clone(), args_p3: args_p3x.clone(), ptys_p4: field_tys_p6.clone(), self_p5: self_pa.clone(), lifts_p6: lifts_p9, span_p7: span_p4x.clone() }))
                    }
                }
            })
        })
    }
}

/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_app_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, c_p2: crate::check::env::CtorInfo, args_p3: crate::prelude::Array<crate::syntax::Arg>, span_p4: crate::syntax::Range, cspan_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(CtorApp { env_p0, st_p1, c_p2, args_p3, span_p4, cspan_p5 })
}

/// ```prism
/// IsBareParameter: fn Ty -> Bool
/// ```
pub fn is_bare_parameter_f(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyQ(_) => true,
        _ => false,
    }
}

/// ```prism
/// CtorArgs: unbounded fn Env, St, CtorInfo, [Arg], [Ty], Ty, Bool, Range -> ((Ty, St))
/// ```
pub fn ctor_args_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::check::env::CtorInfo, args_p3: &crate::prelude::Array<crate::syntax::Arg>, ptys_p4: &crate::prelude::Array<crate::check::types::Ty>, self_p5: &crate::check::types::Ty, lifts_p6: &bool, span_p7: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    if *lifts_p6 {
        apply_rule_f(env_p0, st_p1, &crate::check::types::bare_name_f(&c_p2.name_p), &crate::check::types::Col::CBound, ptys_p4, self_p5, args_p3, span_p7)
    } else {
        {
            let st2_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(args_p3)), st_p1.clone(), {
                let args_p3x = args_p3.clone();
                let env_p0x = env_p0.clone();
                let ptys_p4x = ptys_p4.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Nat)| {
                    let args_p3xy = args_p3x.clone();
                    let env_p0xy = env_p0x.clone();
                    let ptys_p4xy = ptys_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_p9 = p0;
                        let i_pa = p1;
                        match crate::prelude::index(&args_p3xy, &i_pa) {
                            ::std::option::Option::Some(a_pb) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::Check { env_p0: env_p0xy.clone(), st_p1: s_p9.clone(), e_p2: a_pb.value_p.clone(), expected_p3: crate::prelude::or(&crate::prelude::index(&ptys_p4xy, &i_pa), &crate::check::types::Ty::TyErr) })),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p9.clone()),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
            }));
            (self_p5.clone(), st2_p8.clone())
        }
    }
}

/// The step machine of `CtorArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorArgs: unbounded fn Env, St, CtorInfo, [Arg], [Ty], Ty, Bool, Range -> ((Ty, St))
/// ```
pub struct CtorArgs {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::check::env::CtorInfo,
    pub args_p3: crate::prelude::Array<crate::syntax::Arg>,
    pub ptys_p4: crate::prelude::Array<crate::check::types::Ty>,
    pub self_p5: crate::check::types::Ty,
    pub lifts_p6: bool,
    pub span_p7: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for CtorArgs {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let args_p3 = &self.args_p3;
        let ptys_p4 = &self.ptys_p4;
        let self_p5 = &self.self_p5;
        let lifts_p6 = &self.lifts_p6;
        let span_p7 = &self.span_p7;
        if *lifts_p6 {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(ApplyRule { env_p0: env_p0.clone(), st_p1: st_p1.clone(), fname_p2: crate::check::types::bare_name_f(&c_p2.name_p), col_p3: crate::check::types::Col::CBound, params_p4: ptys_p4.clone(), res_p5: self_p5.clone(), args_p6: args_p3.clone(), span_p7: span_p7.clone() }))
        } else {
            {
                let args_p3x = args_p3.clone();
                let env_p0x = env_p0.clone();
                let ptys_p4x = ptys_p4.clone();
                let self_p5x = self_p5.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&args_p3x)), st_p1x.clone(), {
                    let args_p3xx = args_p3x.clone();
                    let env_p0xx = env_p0x.clone();
                    let ptys_p4xx = ptys_p4x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Nat)| {
                        let args_p3xxy = args_p3xx.clone();
                        let env_p0xxy = env_p0xx.clone();
                        let ptys_p4xxy = ptys_p4xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let s_p9 = p0;
                            let i_pa = p1;
                            match crate::prelude::index(&args_p3xxy, &i_pa) {
                                ::std::option::Option::Some(a_pb) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::Check { env_p0: env_p0xxy.clone(), st_p1: s_p9.clone(), e_p2: a_pb.value_p.clone(), expected_p3: crate::prelude::or(&crate::prelude::index(&ptys_p4xxy, &i_pa), &crate::check::types::Ty::TyErr) })),
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(s_p9.clone()),
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                }), move |fold_29490: crate::check::types::St| {
                    let st2_p8 = fold_29490;
                    ::prism_rtl::Turn::Finished((self_p5x.clone(), st2_p8.clone()))
                })
            }
        }
    }
}

/// `Start CtorArgs, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_args_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, c_p2: crate::check::env::CtorInfo, args_p3: crate::prelude::Array<crate::syntax::Arg>, ptys_p4: crate::prelude::Array<crate::check::types::Ty>, self_p5: crate::check::types::Ty, lifts_p6: bool, span_p7: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(CtorArgs { env_p0, st_p1, c_p2, args_p3, ptys_p4, self_p5, lifts_p6, span_p7 })
}

/// ```prism
/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
/// ```
pub fn tag_app_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, name_p2: &crate::prelude::Text, args_p3: &crate::prelude::Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range, cspan_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::prelude::get(&env_p0.g_p.tags_p, name_p2) {
        ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), span_p4, &crate::prelude::Text::from(format!("no tag `{}`", name_p2)))),
        ::std::option::Option::Some(tg_p6) if (((&tg_p6.kind_p == &crate::prelude::Text::lit("Fault")) || (&tg_p6.kind_p == &crate::prelude::Text::lit("Prelude.Fault"))) && (&crate::prelude::len(&tg_p6.fields_p) == &crate::prelude::Nat::from(0u32))) => (crate::check::types::Ty::TyCon(tg_p6.kind_p.clone(), crate::prelude::Array::new()), crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p4, &crate::prelude::Text::from(format!("`{}` is a fault kind and takes no arguments: its value is the tag", name_p2)), &crate::prelude::Text::from(format!("write `{}`", name_p2)))),
        ::std::option::Option::Some(tg_p7) => {
            let (out_pd, st1a_pe, inst_pf) = crate::check::types::schemes::instantiate_with_f(st_p1, &crate::check::types::Scheme { qs_p: tg_p7.qs_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: tg_p7.rqs_p.clone(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: tg_p7.bounds_p.clone(), eqs_p: crate::prelude::Array::new(), ty_p: tg_p7.out_p.clone() }, span_p4, &crate::prelude::Array::new());
            let st1_p8 = named_twice_f(&st1a_pe, args_p3);
            let element_p9 = &tg_p7.kind_p == &crate::prelude::Text::lit("Element");
            let (layer_po, st2_pp) = crate::prelude::run_to_end(crate::prelude::fold_job(args_p3.clone(), (crate::prelude::Text::lit(""), st1_p8.clone()), {
                let tg_p7x = tg_p7.clone();
                let name_p2x = name_p2.clone();
                let element_p9x = element_p9;
                let env_p0x = env_p0.clone();
                let inst_pfx = inst_pf.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Text, crate::check::types::St), crate::syntax::Arg)| {
                    let tg_p7xy = tg_p7x.clone();
                    let name_p2xy = name_p2x.clone();
                    let element_p9xy = element_p9x;
                    let env_p0xy = env_p0x.clone();
                    let inst_pfxy = inst_pfx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (lay_pg, s_ph) = p0;
                        let a_pi = p1;
                        match &a_pi.name_o {
                            ::std::option::Option::Some(id_pj) => match field_of_tag_o(&tg_p7xy, &id_pj.name_p) {
                                ::std::option::Option::Some(ft_pk) => {
                                    let id_pjx = id_pj.clone();
                                    crate::prelude::call_then(start_arg_marks_f(s_ph.clone(), name_p2xy.clone(), id_pjx.name_p.clone(), ft_pk.clone(), a_pi.marks_p.clone(), a_pi.span_p.clone()), move |arg_marks_f_31119: crate::check::types::St| {
                                        let marked_pl = arg_marks_f_31119;
                                        if element_p9xy {
                                            crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pfxy.clone(), ft_pk.clone()), move |subst_q_f_31276: crate::check::types::Ty| crate::prelude::call_then(start_tag_field_f(env_p0xy.clone(), marked_pl.clone(), name_p2xy.clone(), id_pjx.name_p.clone(), subst_q_f_31276, a_pi.clone()), move |tag_field_f_31238: (crate::prelude::Text, crate::check::types::St)| {
                                                let (l_pm, s2_pn) = tag_field_f_31238;
                                                ::prism_rtl::Turn::Finished((if (&lay_pg == &crate::prelude::Text::lit("!")) || (&l_pm == &crate::prelude::Text::lit("")) {
                                                    lay_pg.clone()
                                                } else {
                                                    l_pm.clone()
                                                }, s2_pn.clone()))
                                            }))
                                        } else {
                                            ::prism_rtl::Turn::Finished((lay_pg.clone(), marked_pl.clone()))
                                        }
                                    })
                                },
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished((lay_pg.clone(), crate::check::types::recording::err_f(&s_ph, &crate::prelude::Text::lit("mismatch"), &a_pi.span_p, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &name_p2xy, &id_pj.name_p))))),
                            },
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished((lay_pg.clone(), crate::check::types::recording::err_f(&s_ph, &crate::prelude::Text::lit("mismatch"), &a_pi.span_p, &crate::prelude::Text::from(format!("a tag\'s fields are named: `{}(field=...)`", &name_p2xy))))),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Text, crate::check::types::St), crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)>>>
            }));
            let missing_pa = crate::prelude::filter(&tg_p7.fields_p, &(|(f_pq, _): &(crate::prelude::Text, crate::check::types::Ty)| !crate::prelude::fold(args_p3, &false, &(|seen_pr: &bool, a_ps: &crate::syntax::Arg| *seen_pr || arg_named_f(a_ps, f_pq)))));
            let st3_pb = if (&crate::prelude::len(&missing_pa) > &crate::prelude::Nat::from(0u32)) && !crate::prelude::fold(args_p3, &false, &(|seen_pt: &bool, a_pu: &crate::syntax::Arg| *seen_pt || (&*a_pu.value_p.kind_p == &crate::syntax::ExprKind::ERest))) {
                crate::check::types::recording::err_f(&st2_pp, &crate::prelude::Text::lit("mismatch"), span_p4, &crate::prelude::Text::from(format!("`{}` needs {}", name_p2, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&missing_pa, &(|(f_pv, _): &(crate::prelude::Text, crate::check::types::Ty)| crate::prelude::Text::from(format!("`{}`", f_pv)))), &crate::prelude::Text::lit(", ")))))
            } else {
                st2_pp.clone()
            };
            let field_tys_pc = crate::prelude::run_to_end(crate::prelude::each_job(tg_p7.fields_p.clone(), {
                let inst_pfx = inst_pf.clone();
                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                    let inst_pfxy = inst_pfx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (_, ft_p10) = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::schemes::SubstQ { m_p0: inst_pfxy.clone(), t_p1: ft_p10.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
            }));
            if element_p9 {
                {
                    let (rw_p13, st4_p14) = crate::check::types::recording::fresh_row_f(&st3_pb, &crate::prelude::Array::from(vec![tg_p7.family_p.clone()]));
                    let et_p11 = crate::check::types::Ty::TyElem(crate::check::types::Rw { fams_p: crate::prelude::Array::from(vec![tg_p7.family_p.clone()]), minus_p: crate::prelude::Array::new(), tail_p: rw_p13.tail_p.clone() }, ::std::rc::Rc::new(out_pd.clone()));
                    let lifted_p12 = if &layer_po == &crate::prelude::Text::lit("") {
                        et_p11.clone()
                    } else {
                        crate::check::types::Ty::TySig(layer_po.clone(), ::std::rc::Rc::new(et_p11.clone()))
                    };
                    (lifted_p12.clone(), crate::check::types::recording::note_ty_f(&st4_p14, cspan_p5, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_pc.clone(), ::std::rc::Rc::new(et_p11.clone()))))
                }
            } else {
                {
                    let self_p15 = crate::check::types::Ty::TyCon(tg_p7.kind_p.clone(), crate::prelude::Array::new());
                    let known_p16 = crate::prelude::filter(args_p3, &(|a_p18: &crate::syntax::Arg| match &a_p18.name_o {
                        ::std::option::Option::Some(id_p19) => &field_of_tag_o(&tg_p7, &id_p19.name_p) != &::std::option::Option::None,
                        ::std::option::Option::None => false,
                    }));
                    let ptys_p17 = crate::prelude::run_to_end(crate::prelude::each_job(known_p16.clone(), {
                        let inst_pfx = inst_pf.clone();
                        let tg_p7x = tg_p7.clone();
                        ::std::rc::Rc::new(move |p0: crate::syntax::Arg| {
                            let inst_pfxy = inst_pfx.clone();
                            let tg_p7xy = tg_p7x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_p1a = p0;
                                match &a_p1a.name_o {
                                    ::std::option::Option::Some(id_p1b) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::schemes::SubstQ { m_p0: inst_pfxy.clone(), t_p1: crate::prelude::or(&field_of_tag_o(&tg_p7xy, &id_p1b.name_p), &crate::check::types::Ty::TyErr) })),
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyErr),
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Arg) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                    }));
                    apply_rule_f(env_p0, &crate::check::types::recording::note_ty_f(&st3_pb, cspan_p5, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_pc.clone(), ::std::rc::Rc::new(self_p15.clone()))), name_p2, &crate::check::types::Col::CBound, &ptys_p17, &self_p15, &known_p16, span_p4)
                }
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TagApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
/// ```
pub struct TagApp {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub name_p2: crate::prelude::Text,
    pub args_p3: crate::prelude::Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
    pub cspan_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for TagApp {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let name_p2 = &self.name_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let cspan_p5 = &self.cspan_p5;
        match crate::prelude::get(&env_p0.g_p.tags_p, name_p2) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), span_p4, &crate::prelude::Text::from(format!("no tag `{}`", name_p2))))),
            ::std::option::Option::Some(tg_p6) if (((&tg_p6.kind_p == &crate::prelude::Text::lit("Fault")) || (&tg_p6.kind_p == &crate::prelude::Text::lit("Prelude.Fault"))) && (&crate::prelude::len(&tg_p6.fields_p) == &crate::prelude::Nat::from(0u32))) => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(tg_p6.kind_p.clone(), crate::prelude::Array::new()), crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p4, &crate::prelude::Text::from(format!("`{}` is a fault kind and takes no arguments: its value is the tag", name_p2)), &crate::prelude::Text::from(format!("write `{}`", name_p2))))),
            ::std::option::Option::Some(tg_p7) => {
                let args_p3x = args_p3.clone();
                let cspan_p5x = cspan_p5.clone();
                let env_p0x = env_p0.clone();
                let name_p2x = name_p2.clone();
                let span_p4x = span_p4.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p1x.clone(), crate::check::types::Scheme { qs_p: tg_p7.qs_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: tg_p7.rqs_p.clone(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: tg_p7.bounds_p.clone(), eqs_p: crate::prelude::Array::new(), ty_p: tg_p7.out_p.clone() }, span_p4x.clone(), crate::prelude::Array::new()), move |instantiate_with_f_30708: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                    let (out_pd, st1a_pe, inst_pf) = instantiate_with_f_30708;
                    let st1_p8 = named_twice_f(&st1a_pe, &args_p3x);
                    let element_p9 = &tg_p7.kind_p == &crate::prelude::Text::lit("Element");
                    crate::prelude::call_value(crate::prelude::fold_job(args_p3x.clone(), (crate::prelude::Text::lit(""), st1_p8.clone()), {
                        let tg_p7x = tg_p7.clone();
                        let name_p2xx = name_p2x.clone();
                        let element_p9x = element_p9;
                        let env_p0xx = env_p0x.clone();
                        let inst_pfx = inst_pf.clone();
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Text, crate::check::types::St), crate::syntax::Arg)| {
                            let tg_p7xy = tg_p7x.clone();
                            let name_p2xxy = name_p2xx.clone();
                            let element_p9xy = element_p9x;
                            let env_p0xxy = env_p0xx.clone();
                            let inst_pfxy = inst_pfx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (lay_pg, s_ph) = p0;
                                let a_pi = p1;
                                match &a_pi.name_o {
                                    ::std::option::Option::Some(id_pj) => match field_of_tag_o(&tg_p7xy, &id_pj.name_p) {
                                        ::std::option::Option::Some(ft_pk) => {
                                            let id_pjx = id_pj.clone();
                                            crate::prelude::call_then(start_arg_marks_f(s_ph.clone(), name_p2xxy.clone(), id_pjx.name_p.clone(), ft_pk.clone(), a_pi.marks_p.clone(), a_pi.span_p.clone()), move |arg_marks_f_31119: crate::check::types::St| {
                                                let marked_pl = arg_marks_f_31119;
                                                if element_p9xy {
                                                    crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pfxy.clone(), ft_pk.clone()), move |subst_q_f_31276: crate::check::types::Ty| crate::prelude::call_then(start_tag_field_f(env_p0xxy.clone(), marked_pl.clone(), name_p2xxy.clone(), id_pjx.name_p.clone(), subst_q_f_31276, a_pi.clone()), move |tag_field_f_31238: (crate::prelude::Text, crate::check::types::St)| {
                                                        let (l_pm, s2_pn) = tag_field_f_31238;
                                                        ::prism_rtl::Turn::Finished((if (&lay_pg == &crate::prelude::Text::lit("!")) || (&l_pm == &crate::prelude::Text::lit("")) {
                                                            lay_pg.clone()
                                                        } else {
                                                            l_pm.clone()
                                                        }, s2_pn.clone()))
                                                    }))
                                                } else {
                                                    ::prism_rtl::Turn::Finished((lay_pg.clone(), marked_pl.clone()))
                                                }
                                            })
                                        },
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((lay_pg.clone(), crate::check::types::recording::err_f(&s_ph, &crate::prelude::Text::lit("mismatch"), &a_pi.span_p, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &name_p2xxy, &id_pj.name_p))))),
                                    },
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished((lay_pg.clone(), crate::check::types::recording::err_f(&s_ph, &crate::prelude::Text::lit("mismatch"), &a_pi.span_p, &crate::prelude::Text::from(format!("a tag\'s fields are named: `{}(field=...)`", &name_p2xxy))))),
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Text, crate::check::types::St), crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)>>>
                    }), move |fold_30959: (crate::prelude::Text, crate::check::types::St)| {
                        let (layer_po, st2_pp) = fold_30959;
                        let missing_pa = crate::prelude::filter(&tg_p7.fields_p, &(|(f_pq, _): &(crate::prelude::Text, crate::check::types::Ty)| !crate::prelude::fold(&args_p3x, &false, &(|seen_pr: &bool, a_ps: &crate::syntax::Arg| *seen_pr || arg_named_f(a_ps, f_pq)))));
                        let st3_pb = if (&crate::prelude::len(&missing_pa) > &crate::prelude::Nat::from(0u32)) && !crate::prelude::fold(&args_p3x, &false, &(|seen_pt: &bool, a_pu: &crate::syntax::Arg| *seen_pt || (&*a_pu.value_p.kind_p == &crate::syntax::ExprKind::ERest))) {
                            crate::check::types::recording::err_f(&st2_pp, &crate::prelude::Text::lit("mismatch"), &span_p4x, &crate::prelude::Text::from(format!("`{}` needs {}", &name_p2x, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&missing_pa, &(|(f_pv, _): &(crate::prelude::Text, crate::check::types::Ty)| crate::prelude::Text::from(format!("`{}`", f_pv)))), &crate::prelude::Text::lit(", ")))))
                        } else {
                            st2_pp.clone()
                        };
                        crate::prelude::call_value(crate::prelude::each_job(tg_p7.fields_p.clone(), {
                            let inst_pfx = inst_pf.clone();
                            ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                                let inst_pfxy = inst_pfx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (_, ft_p10) = p0;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::schemes::SubstQ { m_p0: inst_pfxy.clone(), t_p1: ft_p10.clone() }))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                        }), move |each_31964: crate::prelude::Array<crate::check::types::Ty>| {
                            let field_tys_pc = each_31964;
                            if element_p9 {
                                {
                                    let (rw_p13, st4_p14) = crate::check::types::recording::fresh_row_f(&st3_pb, &crate::prelude::Array::from(vec![tg_p7.family_p.clone()]));
                                    let et_p11 = crate::check::types::Ty::TyElem(crate::check::types::Rw { fams_p: crate::prelude::Array::from(vec![tg_p7.family_p.clone()]), minus_p: crate::prelude::Array::new(), tail_p: rw_p13.tail_p.clone() }, ::std::rc::Rc::new(out_pd.clone()));
                                    let lifted_p12 = if &layer_po == &crate::prelude::Text::lit("") {
                                        et_p11.clone()
                                    } else {
                                        crate::check::types::Ty::TySig(layer_po.clone(), ::std::rc::Rc::new(et_p11.clone()))
                                    };
                                    ::prism_rtl::Turn::Finished((lifted_p12.clone(), crate::check::types::recording::note_ty_f(&st4_p14, &cspan_p5x, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_pc.clone(), ::std::rc::Rc::new(et_p11.clone())))))
                                }
                            } else {
                                {
                                    let self_p15 = crate::check::types::Ty::TyCon(tg_p7.kind_p.clone(), crate::prelude::Array::new());
                                    let known_p16 = crate::prelude::filter(&args_p3x, &(|a_p18: &crate::syntax::Arg| match &a_p18.name_o {
                                        ::std::option::Option::Some(id_p19) => &field_of_tag_o(&tg_p7, &id_p19.name_p) != &::std::option::Option::None,
                                        ::std::option::Option::None => false,
                                    }));
                                    crate::prelude::call_value(crate::prelude::each_job(known_p16.clone(), {
                                        let inst_pfx = inst_pf.clone();
                                        let tg_p7x = tg_p7.clone();
                                        ::std::rc::Rc::new(move |p0: crate::syntax::Arg| {
                                            let inst_pfxy = inst_pfx.clone();
                                            let tg_p7xy = tg_p7x.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let a_p1a = p0;
                                                match &a_p1a.name_o {
                                                    ::std::option::Option::Some(id_p1b) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::schemes::SubstQ { m_p0: inst_pfxy.clone(), t_p1: crate::prelude::or(&field_of_tag_o(&tg_p7xy, &id_p1b.name_p), &crate::check::types::Ty::TyErr) })),
                                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyErr),
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Arg) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                                    }), move |each_32534: crate::prelude::Array<crate::check::types::Ty>| {
                                        let ptys_p17 = each_32534;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ApplyRule { env_p0: env_p0x.clone(), st_p1: crate::check::types::recording::note_ty_f(&st3_pb, &cspan_p5x, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_pc.clone(), ::std::rc::Rc::new(self_p15.clone()))), fname_p2: name_p2x.clone(), col_p3: crate::check::types::Col::CBound, params_p4: ptys_p17.clone(), res_p5: self_p15.clone(), args_p6: known_p16.clone(), span_p7: span_p4x.clone() }))
                                    })
                                }
                            }
                        })
                    })
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TagApp, x`: what the function value is when passed to `@Run`.
pub fn start_tag_app_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, name_p2: crate::prelude::Text, args_p3: crate::prelude::Array<crate::syntax::Arg>, span_p4: crate::syntax::Range, cspan_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(TagApp { env_p0, st_p1, name_p2, args_p3, span_p4, cspan_p5 })
}

/// ```prism
/// ArgMarks: unbounded fn St, Text, Text, Ty, Text, Range -> St
/// ```
pub fn arg_marks_f(st_p0: &crate::check::types::St, owner_p1: &crate::prelude::Text, field_p2: &crate::prelude::Text, declared_p3: &crate::check::types::Ty, marks_p4: &crate::prelude::Text, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    let want_p6 = name_sigils_f(declared_p3);
    if marks_p4 == &want_p6 {
        st_p0.clone()
    } else {
        if &want_p6 == &crate::prelude::Text::lit("") {
            crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("unknown-field"), span_p5, &crate::prelude::Text::from(format!("`{}` has no field `{}{}`; its `{}` is plain", owner_p1, marks_p4, field_p2, field_p2)), &crate::prelude::Text::from(format!("write `{}=`", field_p2)))
        } else {
            crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("unknown-field"), span_p5, &crate::prelude::Text::from(format!("`{}` has no plain field `{}`; its field is `{}{}`", owner_p1, field_p2, &want_p6, field_p2)), &crate::prelude::Text::from(format!("write `{}{}=`", &want_p6, field_p2)))
        }
    }
}

/// The step machine of `ArgMarks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgMarks: unbounded fn St, Text, Text, Ty, Text, Range -> St
/// ```
pub struct ArgMarks {
    pub st_p0: crate::check::types::St,
    pub owner_p1: crate::prelude::Text,
    pub field_p2: crate::prelude::Text,
    pub declared_p3: crate::check::types::Ty,
    pub marks_p4: crate::prelude::Text,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for ArgMarks {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let owner_p1 = &self.owner_p1;
        let field_p2 = &self.field_p2;
        let declared_p3 = &self.declared_p3;
        let marks_p4 = &self.marks_p4;
        let span_p5 = &self.span_p5;
        let want_p6 = name_sigils_f(declared_p3);
        if marks_p4 == &want_p6 {
            ::prism_rtl::Turn::Finished(st_p0.clone())
        } else {
            if &want_p6 == &crate::prelude::Text::lit("") {
                ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("unknown-field"), span_p5, &crate::prelude::Text::from(format!("`{}` has no field `{}{}`; its `{}` is plain", owner_p1, marks_p4, field_p2, field_p2)), &crate::prelude::Text::from(format!("write `{}=`", field_p2))))
            } else {
                ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("unknown-field"), span_p5, &crate::prelude::Text::from(format!("`{}` has no plain field `{}`; its field is `{}{}`", owner_p1, field_p2, &want_p6, field_p2)), &crate::prelude::Text::from(format!("write `{}{}=`", &want_p6, field_p2))))
            }
        }
    }
}

/// `Start ArgMarks, x`: what the function value is when passed to `@Run`.
pub fn start_arg_marks_f(st_p0: crate::check::types::St, owner_p1: crate::prelude::Text, field_p2: crate::prelude::Text, declared_p3: crate::check::types::Ty, marks_p4: crate::prelude::Text, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(ArgMarks { st_p0, owner_p1, field_p2, declared_p3, marks_p4, span_p5 })
}

/// ```prism
/// NameSigils: fn Ty -> Text
/// ```
pub fn name_sigils_f(ty0: &crate::check::types::Ty) -> crate::prelude::Text {
    match ty0 {
        crate::check::types::Ty::TySig(s_p0, inner_p1) => crate::prelude::Text::from(format!("{}{}", s_p0, &name_sigils_f(&**inner_p1))),
        crate::check::types::Ty::TyAt(inner_p2, _) => crate::prelude::Text::from(format!("@{}", &name_sigils_f(&**inner_p2))),
        other_p3 => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// ?FieldOfTag: fn TagInfo, Text -> ?Ty
/// ```
pub fn field_of_tag_o(tg_p0: &crate::check::env::TagInfo, f_p1: &crate::prelude::Text) -> ::std::option::Option<crate::check::types::Ty> {
    crate::prelude::fold(&tg_p0.fields_p, &::std::option::Option::None, &(|found_o2: &::std::option::Option<crate::check::types::Ty>, (n_p3, t_p4): &(crate::prelude::Text, crate::check::types::Ty)| match found_o2 {
        ::std::option::Option::Some(x_p5) => ::std::option::Option::Some(x_p5.clone()),
        ::std::option::Option::None => if n_p3 == f_p1 {
            ::std::option::Option::Some(t_p4.clone())
        } else {
            ::std::option::Option::None
        },
    }))
}

/// ```prism
/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> ((Text, St))
/// ```
pub fn tag_field_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, tag_name_p2: &crate::prelude::Text, field_p3: &crate::prelude::Text, ft_p4: &crate::check::types::Ty, a_p5: &crate::syntax::Arg) -> (crate::prelude::Text, crate::check::types::St) {
    if &crate::check::types::head_sigil_f(st_p1, ft_p4) != &crate::prelude::Text::lit("") {
        (crate::prelude::Text::lit(""), crate::check::expr::check_f(env_p0, st_p1, &a_p5.value_p, ft_p4))
    } else {
        {
            let (at_p7, st2_p8) = crate::check::expr::infer_f(env_p0, st_p1, &a_p5.value_p);
            let head_p6 = crate::check::types::head_sigil_f(&st2_p8, &at_p7);
            if (&head_p6 == &crate::prelude::Text::lit("$")) || (&head_p6 == &crate::prelude::Text::lit("!")) {
                {
                    let lift_p9 = crate::check::types::ElemLift { field_p: field_p3.clone(), owner_p: tag_name_p2.clone(), arg_p: a_p5.value_p.span_p.clone(), file_p: st2_p8.file_p.clone(), layer_p: head_p6.clone(), src_p: crate::check::expr::src_text_f(env_p0, &a_p5.value_p.span_p) };
                    let st3_pa = {
                        let mut this: crate::check::types::St = crate::check::types::unify::unify_f(&st2_p8, ft_p4, &crate::check::expr::inner_of_f(&st2_p8, &at_p7), &a_p5.value_p.span_p);
                        this.elem_lifts_p = crate::prelude::push(&this.elem_lifts_p, &lift_p9);
                        this
                    };
                    (head_p6.clone(), st3_pa.clone())
                }
            } else {
                (crate::prelude::Text::lit(""), crate::check::types::unify::unify_f(&st2_p8, ft_p4, &at_p7, &a_p5.value_p.span_p))
            }
        }
    }
}

/// The step machine of `TagField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> ((Text, St))
/// ```
pub struct TagField {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub tag_name_p2: crate::prelude::Text,
    pub field_p3: crate::prelude::Text,
    pub ft_p4: crate::check::types::Ty,
    pub a_p5: crate::syntax::Arg,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)> for TagField {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let tag_name_p2 = &self.tag_name_p2;
        let field_p3 = &self.field_p3;
        let ft_p4 = &self.ft_p4;
        let a_p5 = &self.a_p5;
        let a_p5x = a_p5.clone();
        let env_p0x = env_p0.clone();
        let field_p3x = field_p3.clone();
        let ft_p4x = ft_p4.clone();
        let st_p1x = st_p1.clone();
        let tag_name_p2x = tag_name_p2.clone();
        crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), ft_p4x.clone()), move |head_sigil_f_34593: crate::prelude::Text| if &head_sigil_f_34593 != &crate::prelude::Text::lit("") {
            crate::prelude::call_then(crate::check::expr::start_check_f(env_p0x.clone(), st_p1x.clone(), a_p5x.value_p.clone(), ft_p4x.clone()), move |check_f_34625: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), check_f_34625)))
        } else {
            crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), a_p5x.value_p.clone()), move |infer_f_34691: (crate::check::types::Ty, crate::check::types::St)| {
                let (at_p7, st2_p8) = infer_f_34691;
                crate::prelude::call_then(crate::check::types::start_head_sigil_f(st2_p8.clone(), at_p7.clone()), move |head_sigil_f_34733: crate::prelude::Text| {
                    let head_p6 = head_sigil_f_34733;
                    if (&head_p6 == &crate::prelude::Text::lit("$")) || (&head_p6 == &crate::prelude::Text::lit("!")) {
                        {
                            let lift_p9 = crate::check::types::ElemLift { field_p: field_p3x.clone(), owner_p: tag_name_p2x.clone(), arg_p: a_p5x.value_p.span_p.clone(), file_p: st2_p8.file_p.clone(), layer_p: head_p6.clone(), src_p: crate::check::expr::src_text_f(&env_p0x, &a_p5x.value_p.span_p) };
                            let st3_pa = {
                                let mut this: crate::check::types::St = crate::check::types::unify::unify_f(&st2_p8, &ft_p4x, &crate::check::expr::inner_of_f(&st2_p8, &at_p7), &a_p5x.value_p.span_p);
                                this.elem_lifts_p = crate::prelude::push(&this.elem_lifts_p, &lift_p9);
                                this
                            };
                            ::prism_rtl::Turn::Finished((head_p6.clone(), st3_pa.clone()))
                        }
                    } else {
                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p8.clone(), ft_p4x.clone(), at_p7.clone(), a_p5x.value_p.span_p.clone()), move |unify_f_35110: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), unify_f_35110)))
                    }
                })
            })
        })
    }
}

/// `Start TagField, x`: what the function value is when passed to `@Run`.
pub fn start_tag_field_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, tag_name_p2: crate::prelude::Text, field_p3: crate::prelude::Text, ft_p4: crate::check::types::Ty, a_p5: crate::syntax::Arg) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)>> {
    ::std::rc::Rc::new(TagField { env_p0, st_p1, tag_name_p2, field_p3, ft_p4, a_p5 })
}

/// ```prism
/// LambdaArity: fn Expr -> Nat
/// ```
pub fn lambda_arity_f(e_p0: &crate::syntax::Expr) -> crate::prelude::Nat {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ELambda(::std::option::Option::Some(ps_p1), _) => crate::prelude::len(ps_p1),
        crate::syntax::ExprKind::EGroup(x_p2) => lambda_arity_f(&**x_p2),
        _ => crate::prelude::Nat::from(2u32),
    }
}

/// ```prism
/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub fn infer_lambda_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, expected_o3: &::std::option::Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EGroup(x_p4) => {
            let (t_p5, st2_p6) = infer_lambda_f(env_p0, st_p1, &**x_p4, expected_o3);
            (t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &x_p4.span_p, &t_p5))
        },
        _ => infer_bare_lambda_f(env_p0, st_p1, e_p2, expected_o3),
    }
}

/// The step machine of `InferLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub struct InferLambda {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub expected_o3: ::std::option::Option<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferLambda {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let expected_o3 = &self.expected_o3;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EGroup(x_p4) => {
                let expected_o3x = expected_o3.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let x_p4x = (**x_p4).clone();
                crate::prelude::call_then(start_infer_lambda_f(env_p0x.clone(), st_p1x.clone(), x_p4x.clone(), expected_o3x.clone()), move |infer_lambda_f_36117: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p5, st2_p6) = infer_lambda_f_36117;
                    ::prism_rtl::Turn::Finished((t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &x_p4x.span_p, &t_p5)))
                })
            },
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(InferBareLambda { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p2.clone(), expected_o3: expected_o3.clone() })),
        }
    }
}

/// `Start InferLambda, x`: what the function value is when passed to `@Run`.
pub fn start_infer_lambda_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, expected_o3: ::std::option::Option<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferLambda { env_p0, st_p1, e_p2, expected_o3 })
}

/// ```prism
/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub fn infer_bare_lambda_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, expected_o3: &::std::option::Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    let (params_pg, body_ph) = match &*e_p2.kind_p {
        crate::syntax::ExprKind::ELambda(::std::option::Option::Some(ps_pb), b_pc) => (ps_pb.clone(), (**b_pc).clone()),
        crate::syntax::ExprKind::ELambda(::std::option::Option::None, b_pd) => (crate::prelude::Array::from(vec![topic_pat_f(&e_p2.span_p)]), (**b_pd).clone()),
        crate::syntax::ExprKind::ETopicField(f_pe) => (crate::prelude::Array::from(vec![topic_pat_f(&e_p2.span_p)]), crate::syntax::LambdaBody::LbExpr(::std::rc::Rc::new(topic_field_expr_f(&e_p2.span_p, f_pe)))),
        crate::syntax::ExprKind::ETopicIndex(x_pf) => (crate::prelude::Array::from(vec![topic_pat_f(&e_p2.span_p)]), crate::syntax::LambdaBody::LbExpr(::std::rc::Rc::new(topic_index_expr_f(&e_p2.span_p, &**x_pf)))),
        _ => (crate::prelude::Array::new(), crate::syntax::LambdaBody::LbExpr(::std::rc::Rc::new(e_p2.clone()))),
    };
    let (exp_params_pl, exp_res_om, st0_pn) = match expected_o3 {
        ::std::option::Option::Some(t_pi) => match crate::check::types::recording::walk_f(st_p1, t_pi) {
            crate::check::types::Ty::TyFn(_, ps_pj, r_pk) => if &crate::prelude::len(&ps_pj) == &crate::prelude::len(&params_pg) {
                (ps_pj.clone(), ::std::option::Option::Some((*r_pk).clone()), st_p1.clone())
            } else {
                (crate::prelude::Array::new(), ::std::option::Option::None, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &e_p2.span_p, &crate::prelude::Text::from(format!("this lambda takes {} parameter{}; here {} {} wanted", &crate::check::errors::count_word_f(&crate::prelude::len(&params_pg)), &(if &crate::prelude::len(&params_pg) == &crate::prelude::Nat::from(1u32) {
                    crate::prelude::Text::lit("")
                } else {
                    crate::prelude::Text::lit("s")
                }), &crate::check::errors::count_word_f(&crate::prelude::len(&ps_pj)), &(if &crate::prelude::len(&ps_pj) == &crate::prelude::Nat::from(1u32) {
                    crate::prelude::Text::lit("is")
                } else {
                    crate::prelude::Text::lit("are")
                })))))
            },
            _ => (crate::prelude::Array::new(), ::std::option::Option::None, st_p1.clone()),
        },
        ::std::option::Option::None => (crate::prelude::Array::new(), ::std::option::Option::None, st_p1.clone()),
    };
    let (env2_p12, ptys_p13, st1_p14) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&params_pg)), (env_p0.clone(), crate::prelude::Array::new(), crate::check::expr::patterns::bound_twice_f(env_p0, &st0_pn, &params_pg)), {
        let params_pgx = params_pg.clone();
        let e_p2x = e_p2.clone();
        let exp_params_plx = exp_params_pl.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)| {
            let params_pgxy = params_pgx.clone();
            let e_p2xy = e_p2x.clone();
            let exp_params_plxy = exp_params_plx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (en_po, acc_pp, s_pq) = p0;
                let i_pr = p1;
                {
                    let p_ps = crate::prelude::or(&crate::prelude::index(&params_pgxy, &i_pr), &crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: e_p2xy.span_p.clone() });
                    let (pt_pu, s2_pv) = match crate::prelude::index(&exp_params_plxy, &i_pr) {
                        ::std::option::Option::Some(t_pt) => (t_pt, s_pq.clone()),
                        ::std::option::Option::None => crate::check::types::fresh_var_f(&s_pq, &true, &crate::prelude::Text::lit("")),
                    };
                    crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::expr::lets::unpend_f(&en_po), s2_pv.clone(), p_ps.clone(), pt_pu.clone(), false), move |bind_pattern_f_37485: (crate::check::expr::Env, crate::check::types::St)| {
                        let (en2_p10, s3_p11) = bind_pattern_f_37485;
                        crate::prelude::call_then(crate::check::passes::start_always_matches_f(en_po.clone(), s3_p11.clone(), p_ps.clone(), pt_pu.clone(), crate::prelude::Text::lit("a lambda parameter")), move |always_matches_f_37559: crate::check::types::St| ::prism_rtl::Turn::Finished((en2_p10.clone(), crate::prelude::push(&acc_pp, &pt_pu), always_matches_f_37559)))
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }));
    let outer_color_p4 = st1_p14.color_p.clone();
    let outer_why_p5 = st1_p14.color_why_p.clone();
    let outer_flex_p6 = st1_p14.color_flex_p.clone();
    let (lcol_p15, st1b_p16) = crate::check::types::fresh_col_f(&st1_p14);
    let st2_p7 = {
        let mut this: crate::check::types::St = st1b_p16.clone();
        this.color_p = crate::check::types::Col::CBound;
        this.color_why_p = crate::prelude::Text::lit("");
        this.color_flex_p = crate::prelude::Array::new();
        this
    };
    let (rt_p1f, st3_p1g) = match &body_ph {
        crate::syntax::LambdaBody::LbExpr(x_p17) => match &exp_res_om {
            ::std::option::Option::Some(r_p18) => {
                let s4_p19 = crate::check::expr::check_f(&env2_p12, &st2_p7, &**x_p17, r_p18);
                (r_p18.clone(), s4_p19.clone())
            },
            ::std::option::Option::None => {
                let (t_p1a, s4_p1b) = crate::check::expr::infer_f(&env2_p12, &st2_p7, &**x_p17);
                crate::check::expr::fault_of_f(&s4_p1b, &t_p1a, &x_p17.span_p)
            },
        },
        crate::syntax::LambdaBody::LbBlock(b_p1c) => match &exp_res_om {
            ::std::option::Option::Some(_) => infer_body_block_f(&env2_p12, &st2_p7, b_p1c, &exp_res_om),
            ::std::option::Option::None => {
                let (t_p1d, s4_p1e) = infer_body_block_f(&env2_p12, &st2_p7, b_p1c, &::std::option::Option::None);
                crate::check::expr::fault_of_f(&s4_p1e, &t_p1d, &crate::check::types::recording::tail_span_f(b_p1c))
            },
        },
    };
    let st3b_p8 = crate::check::types::colors::settle_body_f(&st3_p1g, &lcol_p15, &crate::prelude::Text::lit(""));
    let st3c_p9 = crate::check::types::colors::add_leq_f(&st3b_p8, &st3b_p8.color_p, &lcol_p15, &e_p2.span_p, &crate::prelude::Text::lit("lambda"), &crate::prelude::Text::lit(""), &st3b_p8.color_why_p);
    let st4_pa = {
        let mut this: crate::check::types::St = st3c_p9.clone();
        this.color_p = outer_color_p4.clone();
        this.color_why_p = outer_why_p5.clone();
        this.color_flex_p = outer_flex_p6.clone();
        this
    };
    (crate::check::types::Ty::TyFn(lcol_p15.clone(), ptys_p13.clone(), ::std::rc::Rc::new(rt_p1f.clone())), crate::check::types::recording::note_fn_f(&st4_pa, &e_p2.span_p, &crate::prelude::Text::lit("lambda"), &lcol_p15, &lcol_p15))
}

/// The step machine of `InferBareLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub struct InferBareLambda {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub expected_o3: ::std::option::Option<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferBareLambda {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let expected_o3 = &self.expected_o3;
        let (params_pg, body_ph) = match &*e_p2.kind_p {
            crate::syntax::ExprKind::ELambda(::std::option::Option::Some(ps_pb), b_pc) => (ps_pb.clone(), (**b_pc).clone()),
            crate::syntax::ExprKind::ELambda(::std::option::Option::None, b_pd) => (crate::prelude::Array::from(vec![topic_pat_f(&e_p2.span_p)]), (**b_pd).clone()),
            crate::syntax::ExprKind::ETopicField(f_pe) => (crate::prelude::Array::from(vec![topic_pat_f(&e_p2.span_p)]), crate::syntax::LambdaBody::LbExpr(::std::rc::Rc::new(topic_field_expr_f(&e_p2.span_p, f_pe)))),
            crate::syntax::ExprKind::ETopicIndex(x_pf) => (crate::prelude::Array::from(vec![topic_pat_f(&e_p2.span_p)]), crate::syntax::LambdaBody::LbExpr(::std::rc::Rc::new(topic_index_expr_f(&e_p2.span_p, &**x_pf)))),
            _ => (crate::prelude::Array::new(), crate::syntax::LambdaBody::LbExpr(::std::rc::Rc::new(e_p2.clone()))),
        };
        let body_phz = body_ph.clone();
        let e_p2z = e_p2.clone();
        let env_p0z = env_p0.clone();
        let params_pgz = params_pg.clone();
        let k_let36684 = move |v36684: (crate::prelude::Array<crate::check::types::Ty>, ::std::option::Option<crate::check::types::Ty>, crate::check::types::St)| {
            let (exp_params_pl, exp_res_om, st0_pn) = v36684;
            crate::prelude::call_then(crate::check::expr::patterns::start_bound_twice_f(env_p0z.clone(), st0_pn.clone(), params_pgz.clone()), move |bound_twice_f_37232: crate::check::types::St| crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&params_pgz)), (env_p0z.clone(), crate::prelude::Array::new(), bound_twice_f_37232), {
                let params_pgzx = params_pgz.clone();
                let e_p2zx = e_p2z.clone();
                let exp_params_plx = exp_params_pl.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)| {
                    let params_pgzxy = params_pgzx.clone();
                    let e_p2zxy = e_p2zx.clone();
                    let exp_params_plxy = exp_params_plx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (en_po, acc_pp, s_pq) = p0;
                        let i_pr = p1;
                        {
                            let p_ps = crate::prelude::or(&crate::prelude::index(&params_pgzxy, &i_pr), &crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: e_p2zxy.span_p.clone() });
                            let (pt_pu, s2_pv) = match crate::prelude::index(&exp_params_plxy, &i_pr) {
                                ::std::option::Option::Some(t_pt) => (t_pt, s_pq.clone()),
                                ::std::option::Option::None => crate::check::types::fresh_var_f(&s_pq, &true, &crate::prelude::Text::lit("")),
                            };
                            crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::expr::lets::unpend_f(&en_po), s2_pv.clone(), p_ps.clone(), pt_pu.clone(), false), move |bind_pattern_f_37485: (crate::check::expr::Env, crate::check::types::St)| {
                                let (en2_p10, s3_p11) = bind_pattern_f_37485;
                                crate::prelude::call_then(crate::check::passes::start_always_matches_f(en_po.clone(), s3_p11.clone(), p_ps.clone(), pt_pu.clone(), crate::prelude::Text::lit("a lambda parameter")), move |always_matches_f_37559: crate::check::types::St| ::prism_rtl::Turn::Finished((en2_p10.clone(), crate::prelude::push(&acc_pp, &pt_pu), always_matches_f_37559)))
                            })
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>>>
            }), move |fold_37190: (crate::check::expr::Env, crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)| {
                let (env2_p12, ptys_p13, st1_p14) = fold_37190;
                let outer_color_p4 = st1_p14.color_p.clone();
                let outer_why_p5 = st1_p14.color_why_p.clone();
                let outer_flex_p6 = st1_p14.color_flex_p.clone();
                let (lcol_p15, st1b_p16) = crate::check::types::fresh_col_f(&st1_p14);
                let st2_p7 = {
                    let mut this: crate::check::types::St = st1b_p16.clone();
                    this.color_p = crate::check::types::Col::CBound;
                    this.color_why_p = crate::prelude::Text::lit("");
                    this.color_flex_p = crate::prelude::Array::new();
                    this
                };
                let e_p2zz = e_p2z.clone();
                let lcol_p15z = lcol_p15.clone();
                let outer_color_p4z = outer_color_p4.clone();
                let outer_flex_p6z = outer_flex_p6.clone();
                let outer_why_p5z = outer_why_p5.clone();
                let ptys_p13z = ptys_p13.clone();
                let k_let37860 = move |v37860: (crate::check::types::Ty, crate::check::types::St)| {
                    let (rt_p1f, st3_p1g) = v37860;
                    crate::prelude::call_then(crate::check::types::colors::start_settle_body_f(st3_p1g.clone(), lcol_p15z.clone(), crate::prelude::Text::lit("")), move |settle_body_f_38353: crate::check::types::St| {
                        let st3b_p8 = settle_body_f_38353;
                        crate::prelude::call_then(crate::check::types::colors::start_add_leq_f(st3b_p8.clone(), st3b_p8.color_p.clone(), lcol_p15z.clone(), e_p2zz.span_p.clone(), crate::prelude::Text::lit("lambda"), crate::prelude::Text::lit(""), st3b_p8.color_why_p.clone()), move |add_leq_f_38393: crate::check::types::St| {
                            let st3c_p9 = add_leq_f_38393;
                            let st4_pa = {
                                let mut this: crate::check::types::St = st3c_p9.clone();
                                this.color_p = outer_color_p4z.clone();
                                this.color_why_p = outer_why_p5z.clone();
                                this.color_flex_p = outer_flex_p6z.clone();
                                this
                            };
                            ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyFn(lcol_p15z.clone(), ptys_p13z.clone(), ::std::rc::Rc::new(rt_p1f.clone())), crate::check::types::recording::note_fn_f(&st4_pa, &e_p2zz.span_p, &crate::prelude::Text::lit("lambda"), &lcol_p15z, &lcol_p15z)))
                        })
                    })
                };
                match body_phz.clone() {
                    crate::syntax::LambdaBody::LbExpr(x_p17) => match exp_res_om.clone() {
                        ::std::option::Option::Some(r_p18) => crate::prelude::call_then(crate::check::expr::start_check_f(env2_p12.clone(), st2_p7.clone(), (*x_p17).clone(), r_p18.clone()), move |check_f_37965: crate::check::types::St| {
                            let s4_p19 = check_f_37965;
                            k_let37860((r_p18.clone(), s4_p19.clone()))
                        }),
                        ::std::option::Option::None => crate::prelude::call_then(crate::check::expr::start_infer_f(env2_p12.clone(), st2_p7.clone(), (*x_p17).clone()), move |infer_f_38062: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_p1a, s4_p1b) = infer_f_38062;
                            crate::prelude::call_then(crate::check::expr::start_fault_of_f(s4_p1b.clone(), t_p1a.clone(), x_p17.span_p.clone()), move |fault_of_f_38097: (crate::check::types::Ty, crate::check::types::St)| k_let37860(fault_of_f_38097))
                        }),
                    },
                    crate::syntax::LambdaBody::LbBlock(b_p1c) => match exp_res_om.clone() {
                        ::std::option::Option::Some(_) => crate::prelude::call_then(start_infer_body_block_f(env2_p12.clone(), st2_p7.clone(), b_p1c.clone(), exp_res_om.clone()), move |infer_body_block_f_38175: (crate::check::types::Ty, crate::check::types::St)| k_let37860(infer_body_block_f_38175)),
                        ::std::option::Option::None => crate::prelude::call_then(start_infer_body_block_f(env2_p12.clone(), st2_p7.clone(), b_p1c.clone(), ::std::option::Option::None), move |infer_body_block_f_38261: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_p1d, s4_p1e) = infer_body_block_f_38261;
                            crate::prelude::call_then(crate::check::expr::start_fault_of_f(s4_p1e.clone(), t_p1d.clone(), crate::check::types::recording::tail_span_f(&b_p1c)), move |fault_of_f_38310: (crate::check::types::Ty, crate::check::types::St)| k_let37860(fault_of_f_38310))
                        }),
                    },
                }
            }))
        };
        match expected_o3.clone() {
            ::std::option::Option::Some(t_pi) => {
                let e_p2x = e_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), t_pi.clone()), move |walk_f_36754: crate::check::types::Ty| k_let36684(match walk_f_36754 {
                    crate::check::types::Ty::TyFn(_, ps_pj, r_pk) => if &crate::prelude::len(&ps_pj) == &crate::prelude::len(&params_pg) {
                        (ps_pj.clone(), ::std::option::Option::Some((*r_pk).clone()), st_p1x.clone())
                    } else {
                        (crate::prelude::Array::new(), ::std::option::Option::None, crate::check::types::recording::err_f(&st_p1x, &crate::prelude::Text::lit("mismatch"), &e_p2x.span_p, &crate::prelude::Text::from(format!("this lambda takes {} parameter{}; here {} {} wanted", &crate::check::errors::count_word_f(&crate::prelude::len(&params_pg)), &(if &crate::prelude::len(&params_pg) == &crate::prelude::Nat::from(1u32) {
                            crate::prelude::Text::lit("")
                        } else {
                            crate::prelude::Text::lit("s")
                        }), &crate::check::errors::count_word_f(&crate::prelude::len(&ps_pj)), &(if &crate::prelude::len(&ps_pj) == &crate::prelude::Nat::from(1u32) {
                            crate::prelude::Text::lit("is")
                        } else {
                            crate::prelude::Text::lit("are")
                        })))))
                    },
                    _ => (crate::prelude::Array::new(), ::std::option::Option::None, st_p1x.clone()),
                }))
            },
            ::std::option::Option::None => k_let36684((crate::prelude::Array::new(), ::std::option::Option::None, st_p1.clone())),
        }
    }
}

/// `Start InferBareLambda, x`: what the function value is when passed to `@Run`.
pub fn start_infer_bare_lambda_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, expected_o3: ::std::option::Option<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferBareLambda { env_p0, st_p1, e_p2, expected_o3 })
}

/// ```prism
/// TopicPat: fn Range -> Pattern
/// ```
pub fn topic_pat_f(span_p0: &crate::syntax::Range) -> crate::syntax::Pattern {
    crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PName(topic_sname_f(span_p0))), span_p: span_p0.clone() }
}

/// ```prism
/// TopicSName: fn Range -> SName
/// ```
pub fn topic_sname_f(span_p0: &crate::syntax::Range) -> crate::syntax::SName {
    crate::syntax::SName { sigils_p: crate::prelude::Text::lit(""), path_p: crate::prelude::Array::from(vec![crate::prelude::Text::lit("_")]), span_p: span_p0.clone() }
}

/// ```prism
/// TopicExpr: fn Range -> Expr
/// ```
pub fn topic_expr_f(span_p0: &crate::syntax::Range) -> crate::syntax::Expr {
    crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EName(topic_sname_f(span_p0))), span_p: span_p0.clone() }
}

/// ```prism
/// TopicFieldExpr: fn Range, Ident -> Expr
/// ```
pub fn topic_field_expr_f(span_p0: &crate::syntax::Range, f_p1: &crate::syntax::Ident) -> crate::syntax::Expr {
    crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EField(::std::rc::Rc::new(topic_expr_f(span_p0)), crate::prelude::Text::lit(""), f_p1.clone())), span_p: span_p0.clone() }
}

/// ```prism
/// TopicIndexExpr: fn Range, Expr -> Expr
/// ```
pub fn topic_index_expr_f(span_p0: &crate::syntax::Range, x_p1: &crate::syntax::Expr) -> crate::syntax::Expr {
    crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EIndex(::std::rc::Rc::new(topic_expr_f(span_p0)), ::std::rc::Rc::new(x_p1.clone()))), span_p: span_p0.clone() }
}

/// ```prism
/// NamedTwice: fn St, [Arg] -> St
/// ```
pub fn named_twice_f(st_p0: &crate::check::types::St, args_p1: &crate::prelude::Array<crate::syntax::Arg>) -> crate::check::types::St {
    let (_, checked_p6) = crate::prelude::fold(args_p1, &(crate::prelude::Array::new(), st_p0.clone()), &(|(seen_p2, s_p3): &(crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), a_p4: &crate::syntax::Arg| match &a_p4.name_o {
        ::std::option::Option::Some(id_p5) => if crate::check::types::has_text_f(seen_p2, &id_p5.name_p) {
            (seen_p2.clone(), crate::check::types::recording::err_f(s_p3, &crate::prelude::Text::lit("collision"), &a_p4.span_p, &crate::prelude::Text::from(format!("`{}` is given twice", &id_p5.name_p))))
        } else {
            (crate::prelude::push(seen_p2, &id_p5.name_p), s_p3.clone())
        },
        ::std::option::Option::None => (seen_p2.clone(), s_p3.clone()),
    }));
    checked_p6.clone()
}

/// ```prism
/// ArgNamed: fn Arg, Text -> Bool
/// ```
pub fn arg_named_f(a_p0: &crate::syntax::Arg, f_p1: &crate::prelude::Text) -> bool {
    match &a_p0.name_o {
        ::std::option::Option::Some(id_p2) => &id_p2.name_p == f_p1,
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
/// ```
pub fn infer_body_block_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block, expected_o3: &::std::option::Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p4, st2_p5) = crate::check::expr::lets::infer_expr_block_f(env_p0, st_p1, b_p2);
    match expected_o3 {
        ::std::option::Option::Some(r_p6) => (r_p6.clone(), crate::check::types::unify::unify_f(&st2_p5, r_p6, &t_p4, &crate::check::types::recording::result_span_f(b_p2))),
        ::std::option::Option::None => (t_p4.clone(), st2_p5.clone()),
    }
}

/// The step machine of `InferBodyBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
/// ```
pub struct InferBodyBlock {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
    pub expected_o3: ::std::option::Option<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferBodyBlock {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        let expected_o3 = &self.expected_o3;
        let expected_o3x = expected_o3.clone();
        let b_p2x = b_p2.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(env_p0x.clone(), st_p1x.clone(), b_p2x.clone()), move |infer_expr_block_f_40022: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p4, st2_p5) = infer_expr_block_f_40022;
            match &expected_o3x {
                ::std::option::Option::Some(r_p6) => {
                    let r_p6x = r_p6.clone();
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p5.clone(), r_p6x.clone(), t_p4.clone(), crate::check::types::recording::result_span_f(&b_p2x)), move |unify_f_40088: crate::check::types::St| ::prism_rtl::Turn::Finished((r_p6x.clone(), unify_f_40088)))
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished((t_p4.clone(), st2_p5.clone())),
            }
        })
    }
}

/// `Start InferBodyBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_body_block_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block, expected_o3: ::std::option::Option<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferBodyBlock { env_p0, st_p1, b_p2, expected_o3 })
}
