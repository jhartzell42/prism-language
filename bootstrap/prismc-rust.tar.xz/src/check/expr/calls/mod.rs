//! The module `Check.Expr.Calls`, from `target/bootstrap/src/prismc/check/expr/calls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Peeled`:
///
/// ```prism
/// type Peeled = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Peeled {
    pub events: Array<crate::syntax::Range>,
    pub dyns: Array<crate::syntax::Range>,
    pub opts: Array<Text>,
    pub opt_args: Array<crate::syntax::Range>,
    pub lifted: Text,
    pub broken: bool,
}

impl Show for Peeled {
    fn show(&self, p: &mut Printer) {
        p.record("Peeled", &[("events", &self.events), ("dyns", &self.dyns), ("opts", &self.opts), ("opt_args", &self.opt_args), ("lifted", &self.lifted), ("broken", &self.broken)]);
    }
}

impl ToPod for Peeled {
    fn to_pod(&self) -> Pod {
        Pod::record("Peeled", vec![("events", self.events.to_pod()), ("dyns", self.dyns.to_pod()), ("opts", self.opts.to_pod()), ("opt_args", self.opt_args.to_pod()), ("lifted", self.lifted.to_pod()), ("broken", self.broken.to_pod())])
    }
}

impl FromPod for Peeled {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Peeled { events: FromPod::from_pod(field(p, "events")?)?, dyns: FromPod::from_pod(field(p, "dyns")?)?, opts: FromPod::from_pod(field(p, "opts")?)?, opt_args: FromPod::from_pod(field(p, "opt_args")?)?, lifted: FromPod::from_pod(field(p, "lifted")?)?, broken: FromPod::from_pod(field(p, "broken")?)? })
    }
}

/// ```prism
/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
/// ```
pub fn infer_call(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, callee_p2: &crate::syntax::Expr, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*callee_p2.kind {
        crate::syntax::ExprKind::EName(n_p5) => {
            let local_p6 = crate::check::env::sname_key(n_p5);
            match get(&env_p0.locals, &local_p6) {
                Some(sc_p7) => {
                    let (t_p8, st2_p9) = crate::check::expr::instantiate_local(st_p1, &sc_p7, &callee_p2.span, &local_p6);
                    apply_fn(env_p0, &crate::check::types::recording::note_ty(&st2_p9, &callee_p2.span, &t_p8), &local_p6, &t_p8, &positional(args_p3), span_p4)
                },
                None => call_global(env_p0, st_p1, n_p5, args_p3, span_p4, &Array::new(), &callee_p2.span),
            }
        },
        crate::syntax::ExprKind::ETypeArgs(target_pa, tys_pb) => match &*target_pa.kind {
            crate::syntax::ExprKind::EName(n_pc) => {
                let cx_pd = crate::check::expr::env_cx(env_p0);
                let (given2_pe, st2_pf) = crate::check::env::reading::conv_types(&cx_pd, st_p1, tys_pb);
                call_global(env_p0, &st2_pf, n_pc, args_p3, span_p4, &given2_pe, &callee_p2.span)
            },
            _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &callee_p2.span, &Text::lit("`<<T>>` applies to a function\'s name"))),
        },
        crate::syntax::ExprKind::EGroup(x_pg) => infer_call(env_p0, st_p1, &**x_pg, args_p3, span_p4),
        _ => {
            let (t_ph, st2_pi) = crate::check::expr::infer(env_p0, st_p1, callee_p2);
            apply_fn(env_p0, &st2_pi, &crate::check::expr::src_text(env_p0, &callee_p2.span), &t_ph, &positional(args_p3), span_p4)
        },
    }
}

/// The step machine of `InferCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
/// ```
pub struct InferCall {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub callee_p2: crate::syntax::Expr,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferCall {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let callee_p2 = &self.callee_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        match &*callee_p2.kind {
            crate::syntax::ExprKind::EName(n_p5) => {
                let local_p6 = crate::check::env::sname_key(n_p5);
                match get(&env_p0.locals, &local_p6) {
                    Some(sc_p7) => {
                        let args_p3 = args_p3.clone();
                        let callee_p2 = callee_p2.clone();
                        let env_p0 = env_p0.clone();
                        let span_p4 = span_p4.clone();
                        let st_p1 = st_p1.clone();
                        call_then(crate::check::expr::start_instantiate_local(st_p1.clone(), sc_p7.clone(), callee_p2.span.clone(), local_p6.clone()), move |instantiate_local_1491: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_p8, st2_p9) = instantiate_local_1491;
                            prism_rtl::Turn::More(Rc::new(ApplyFn { env_p0: env_p0.clone(), st_p1: crate::check::types::recording::note_ty(&st2_p9, &callee_p2.span, &t_p8), fname_p2: local_p6.clone(), fty_p3: t_p8.clone(), args_p4: positional(&args_p3), span_p5: span_p4.clone() }))
                        })
                    },
                    None => prism_rtl::Turn::More(Rc::new(CallGlobal { env_p0: env_p0.clone(), st0_p1: st_p1.clone(), n_p2: n_p5.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone(), explicit_p5: Array::new(), cspan_p6: callee_p2.span.clone() })),
                }
            },
            crate::syntax::ExprKind::ETypeArgs(target_pa, tys_pb) => match &*target_pa.kind {
                crate::syntax::ExprKind::EName(n_pc) => {
                    let cx_pd = crate::check::expr::env_cx(env_p0);
                    let args_p3 = args_p3.clone();
                    let callee_p2 = callee_p2.clone();
                    let env_p0 = env_p0.clone();
                    let n_pc = n_pc.clone();
                    let span_p4 = span_p4.clone();
                    let st_p1 = st_p1.clone();
                    let tys_pb = tys_pb.clone();
                    call_then(crate::check::env::reading::start_conv_types(cx_pd.clone(), st_p1.clone(), tys_pb.clone()), move |conv_types_1826: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                        let (given2_pe, st2_pf) = conv_types_1826;
                        prism_rtl::Turn::More(Rc::new(CallGlobal { env_p0: env_p0.clone(), st0_p1: st2_pf.clone(), n_p2: n_pc.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone(), explicit_p5: given2_pe.clone(), cspan_p6: callee_p2.span.clone() }))
                    })
                },
                _ => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &callee_p2.span, &Text::lit("`<<T>>` applies to a function\'s name")))),
            },
            crate::syntax::ExprKind::EGroup(x_pg) => prism_rtl::Turn::More(Rc::new(InferCall { env_p0: env_p0.clone(), st_p1: st_p1.clone(), callee_p2: (**x_pg).clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone() })),
            _ => {
                let args_p3 = args_p3.clone();
                let callee_p2 = callee_p2.clone();
                let env_p0 = env_p0.clone();
                let span_p4 = span_p4.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), callee_p2.clone()), move |infer_2107: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_ph, st2_pi) = infer_2107;
                    prism_rtl::Turn::More(Rc::new(ApplyFn { env_p0: env_p0.clone(), st_p1: st2_pi.clone(), fname_p2: crate::check::expr::src_text(&env_p0, &callee_p2.span), fty_p3: t_ph.clone(), args_p4: positional(&args_p3), span_p5: span_p4.clone() }))
                })
            },
        }
    }
}

/// `Start InferCall, x`: what the function value is when passed to `@Run`.
pub fn start_infer_call(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, callee_p2: crate::syntax::Expr, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferCall { env_p0, st_p1, callee_p2, args_p3, span_p4 })
}

/// ```prism
/// Positional: fn [Arg] -> [Arg]
/// ```
pub fn positional(args_p0: &Array<crate::syntax::Arg>) -> Array<crate::syntax::Arg> {
    args_p0.clone()
}

/// ```prism
/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
/// ```
pub fn call_global(env_p0: &crate::check::expr::Env, st0_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range, explicit_p5: &Array<crate::check::types::Ty>, cspan_p6: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (qk_o9, why_pa) = crate::check::env::names::resolve_value(&env_p0.g, &env_p0.home, n_p2);
    let name_p7 = crate::check::env::sname_key(n_p2);
    let st_p8 = crate::check::expr::collision_at(env_p0, st0_p1, &why_pa, &name_p7, &n_p2.span);
    match &qk_o9 {
        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st_p8, &Text::lit("unknown-name"), &n_p2.span, &Text::from(format!("nothing declares `{}` here", &name_p7)))),
        Some(qk_pb) => if &why_pa == &Text::lit("tag") {
            tag_app(env_p0, &st_p8, qk_pb, args_p3, span_p4, cspan_p6)
        } else {
            if is_local_maker(qk_pb) && !env_p0.in_update {
                (crate::check::types::Ty::TyErr, local_outside(&st_p8, qk_pb, span_p4))
            } else {
                match get(&env_p0.g.vals, qk_pb) {
                    Some(v_pc) => {
                        let (t_pf, st2i_pg, inst_ph) = crate::check::types::schemes::instantiate_with(&st_p8, &v_pc.scheme, span_p4, explicit_p5);
                        let (rigids_pi, st2_pj) = rank_two(&st2i_pg, &v_pc.scheme, &inst_ph, &len(explicit_p5), span_p4);
                        let st3a_pd = note_callee(&note_method_use(&st2_pj, &v_pc, span_p4), &n_p2.span, cspan_p6, &t_pf);
                        let st3_pe = if &crate::check::types::bare_name(qk_pb) == &Text::lit("Min") {
                            crate::check::types::recording::note_size_ty(&st3a_pd, span_p4, &crate::check::types::recording::walk(&st3a_pd, &t_pf))
                        } else {
                            st3a_pd.clone()
                        };
                        if (&crate::check::types::bare_name(qk_pb) == &Text::lit("Fold")) && (&v_pc.home == &Text::lit("Prelude")) {
                            fold_app(env_p0, &st3_pe, &t_pf, args_p3, span_p4)
                        } else {
                            {
                                let (rt_pk, st4_pl) = apply_fn(env_p0, &st3_pe, &name_p7, &t_pf, args_p3, span_p4);
                                (rt_pk.clone(), escaped(env_p0, &st4_pl, &rigids_pi, &rt_pk, &name_p7, span_p4))
                            }
                        }
                    },
                    None => match get(&env_p0.g.ctors, qk_pb) {
                        Some(c_pm) => ctor_app(env_p0, &st_p8, &c_pm, args_p3, span_p4, cspan_p6),
                        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st_p8, &Text::lit("unknown-name"), &n_p2.span, &Text::from(format!("`{}` has no signature line", &name_p7)))),
                    },
                }
            }
        },
    }
}

/// The step machine of `CallGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
/// ```
pub struct CallGlobal {
    pub env_p0: crate::check::expr::Env,
    pub st0_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
    pub explicit_p5: Array<crate::check::types::Ty>,
    pub cspan_p6: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for CallGlobal {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st0_p1 = &self.st0_p1;
        let n_p2 = &self.n_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let explicit_p5 = &self.explicit_p5;
        let cspan_p6 = &self.cspan_p6;
        let (qk_o9, why_pa) = crate::check::env::names::resolve_value(&env_p0.g, &env_p0.home, n_p2);
        let name_p7 = crate::check::env::sname_key(n_p2);
        let st_p8 = crate::check::expr::collision_at(env_p0, st0_p1, &why_pa, &name_p7, &n_p2.span);
        match &qk_o9 {
            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st_p8, &Text::lit("unknown-name"), &n_p2.span, &Text::from(format!("nothing declares `{}` here", &name_p7))))),
            Some(qk_pb) => if &why_pa == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(TagApp { env_p0: env_p0.clone(), st_p1: st_p8.clone(), name_p2: qk_pb.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone(), cspan_p5: cspan_p6.clone() }))
            } else {
                if is_local_maker(qk_pb) && !env_p0.in_update {
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, local_outside(&st_p8, qk_pb, span_p4)))
                } else {
                    match get(&env_p0.g.vals, qk_pb) {
                        Some(v_pc) => {
                            let args_p3 = args_p3.clone();
                            let cspan_p6 = cspan_p6.clone();
                            let env_p0 = env_p0.clone();
                            let explicit_p5 = explicit_p5.clone();
                            let n_p2 = n_p2.clone();
                            let qk_pb = qk_pb.clone();
                            let span_p4 = span_p4.clone();
                            call_then(crate::check::types::schemes::start_instantiate_with(st_p8.clone(), v_pc.scheme.clone(), span_p4.clone(), explicit_p5.clone()), move |instantiate_with_2931: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                                let (t_pf, st2i_pg, inst_ph) = instantiate_with_2931;
                                call_then(start_rank_two(st2i_pg.clone(), v_pc.scheme.clone(), inst_ph.clone(), len(&explicit_p5), span_p4.clone()), move |rank_two_3018: (Array<Text>, crate::check::types::St)| {
                                    let (rigids_pi, st2_pj) = rank_two_3018;
                                    let st3a_pd = note_callee(&note_method_use(&st2_pj, &v_pc, &span_p4), &n_p2.span, &cspan_p6, &t_pf);
                                    let st3_pe = if &crate::check::types::bare_name(&qk_pb) == &Text::lit("Min") {
                                        crate::check::types::recording::note_size_ty(&st3a_pd, &span_p4, &crate::check::types::recording::walk(&st3a_pd, &t_pf))
                                    } else {
                                        st3a_pd.clone()
                                    };
                                    if (&crate::check::types::bare_name(&qk_pb) == &Text::lit("Fold")) && (&v_pc.home == &Text::lit("Prelude")) {
                                        prism_rtl::Turn::More(Rc::new(FoldApp { env_p0: env_p0.clone(), st_p1: st3_pe.clone(), t_p2: t_pf.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone() }))
                                    } else {
                                        call_then(start_apply_fn(env_p0.clone(), st3_pe.clone(), name_p7.clone(), t_pf.clone(), args_p3.clone(), span_p4.clone()), move |apply_fn_3436: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (rt_pk, st4_pl) = apply_fn_3436;
                                            call_then(start_escaped(env_p0.clone(), st4_pl.clone(), rigids_pi.clone(), rt_pk.clone(), name_p7.clone(), span_p4.clone()), move |escaped_3505: crate::check::types::St| prism_rtl::Turn::Finished((rt_pk.clone(), escaped_3505)))
                                        })
                                    }
                                })
                            })
                        },
                        None => match get(&env_p0.g.ctors, qk_pb) {
                            Some(c_pm) => prism_rtl::Turn::More(Rc::new(CtorApp { env_p0: env_p0.clone(), st_p1: st_p8.clone(), c_p2: c_pm.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone(), cspan_p5: cspan_p6.clone() })),
                            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st_p8, &Text::lit("unknown-name"), &n_p2.span, &Text::from(format!("`{}` has no signature line", &name_p7))))),
                        },
                    }
                }
            },
        }
    }
}

/// `Start CallGlobal, x`: what the function value is when passed to `@Run`.
pub fn start_call_global(env_p0: crate::check::expr::Env, st0_p1: crate::check::types::St, n_p2: crate::syntax::SName, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range, explicit_p5: Array<crate::check::types::Ty>, cspan_p6: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(CallGlobal { env_p0, st0_p1, n_p2, args_p3, span_p4, explicit_p5, cspan_p6 })
}

/// ```prism
/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
/// ```
pub fn rank_two(st_p0: &crate::check::types::St, sc_p1: &crate::check::types::Scheme, inst_p2: &crate::check::types::schemes::Inst, n_explicit_p3: &Nat, span_p4: &crate::syntax::Range) -> (Array<Text>, crate::check::types::St) {
    let qs_p5 = filter(&crate::check::errors::range0(&len(&sc_p1.qs)), &(|i_p6: &Nat| (i_p6 >= n_explicit_p3) && is_rank_two(&or(&index(&sc_p1.qs, i_p6), &Text::lit("")), &sc_p1.ty)));
    run_to_end(fold_job(qs_p5.clone(), (Array::new(), st_p0.clone()), {
        let sc_p1 = sc_p1.clone();
        let inst_p2 = inst_p2.clone();
        let span_p4 = span_p4.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, crate::check::types::St), Nat)| {
            let sc_p1 = sc_p1.clone();
            let inst_p2 = inst_p2.clone();
            let span_p4 = span_p4.clone();
            entered(once_job(move || {
                let (acc_p7, s_p8) = p0;
                let i_p9 = p1;
                {
                    let q_pa = or(&index(&sc_p1.qs, &i_p9), &Text::lit(""));
                    let rigid_pb = Text::from(format!("{}\'{}", &q_pa, &s_p8.next));
                    let s2_pc = {
                        let mut this: crate::check::types::St = s_p8.clone();
                        this.next = &this.next + &Nat::from(1u32);
                        this
                    };
                    call_then(crate::check::types::unify::start_unify(s2_pc.clone(), or(&get(&inst_p2.tys, &q_pa), &crate::check::types::Ty::TyErr), crate::check::types::Ty::TyRigid(rigid_pb.clone()), span_p4.clone()), move |unify_4584: crate::check::types::St| prism_rtl::Turn::Finished((push(&acc_p7, &rigid_pb), unify_4584)))
                }
            }))
        }) as Rc<dyn Fn(((Array<Text>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>>>
    }))
}

/// The step machine of `RankTwo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
/// ```
pub struct RankTwo {
    pub st_p0: crate::check::types::St,
    pub sc_p1: crate::check::types::Scheme,
    pub inst_p2: crate::check::types::schemes::Inst,
    pub n_explicit_p3: Nat,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(Array<Text>, crate::check::types::St)> for RankTwo {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let sc_p1 = &self.sc_p1;
        let inst_p2 = &self.inst_p2;
        let n_explicit_p3 = &self.n_explicit_p3;
        let span_p4 = &self.span_p4;
        let qs_p5 = filter(&crate::check::errors::range0(&len(&sc_p1.qs)), &(|i_p6: &Nat| (i_p6 >= n_explicit_p3) && is_rank_two(&or(&index(&sc_p1.qs, i_p6), &Text::lit("")), &sc_p1.ty)));
        fold_job(qs_p5.clone(), (Array::new(), st_p0.clone()), {
            let sc_p1 = sc_p1.clone();
            let inst_p2 = inst_p2.clone();
            let span_p4 = span_p4.clone();
            Rc::new(move |(p0, p1): ((Array<Text>, crate::check::types::St), Nat)| {
                let sc_p1 = sc_p1.clone();
                let inst_p2 = inst_p2.clone();
                let span_p4 = span_p4.clone();
                entered(once_job(move || {
                    let (acc_p7, s_p8) = p0;
                    let i_p9 = p1;
                    {
                        let q_pa = or(&index(&sc_p1.qs, &i_p9), &Text::lit(""));
                        let rigid_pb = Text::from(format!("{}\'{}", &q_pa, &s_p8.next));
                        let s2_pc = {
                            let mut this: crate::check::types::St = s_p8.clone();
                            this.next = &this.next + &Nat::from(1u32);
                            this
                        };
                        call_then(crate::check::types::unify::start_unify(s2_pc.clone(), or(&get(&inst_p2.tys, &q_pa), &crate::check::types::Ty::TyErr), crate::check::types::Ty::TyRigid(rigid_pb.clone()), span_p4.clone()), move |unify_4584: crate::check::types::St| prism_rtl::Turn::Finished((push(&acc_p7, &rigid_pb), unify_4584)))
                    }
                }))
            }) as Rc<dyn Fn(((Array<Text>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start RankTwo, x`: what the function value is when passed to `@Run`.
pub fn start_rank_two(st_p0: crate::check::types::St, sc_p1: crate::check::types::Scheme, inst_p2: crate::check::types::schemes::Inst, n_explicit_p3: Nat, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>> {
    Rc::new(RankTwo { st_p0, sc_p1, inst_p2, n_explicit_p3, span_p4 })
}

/// ```prism
/// IsRankTwo: fn Text, Ty -> Bool
/// ```
pub fn is_rank_two(q_p0: &Text, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyFn(_, ps_p2, res_p3) => {
            let holding_p4 = filter(ps_p2, &(|p_p5: &crate::check::types::Ty| qoccurs(q_p0, p_p5)));
            if (&len(&holding_p4) != &Nat::from(1u32)) || qoccurs(q_p0, &**res_p3) {
                false
            } else {
                match index(&holding_p4, &Nat::from(0u32)) {
                    Some(crate::check::types::Ty::TyFn(_, _, _)) => elem_out_q(q_p0, &or(&index(&holding_p4, &Nat::from(0u32)), &crate::check::types::Ty::TyErr)),
                    _ => false,
                }
            }
        },
        _ => false,
    }
}

/// ```prism
/// QOccurs: fn Text, Ty -> Bool
/// ```
pub fn qoccurs(q_p0: &Text, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyQ(n_p2) => n_p2 == q_p0,
        crate::check::types::Ty::TyCon(_, args_p3) => fold(args_p3, &false, &(|seen_p4: &bool, a_p5: &crate::check::types::Ty| *seen_p4 || qoccurs(q_p0, a_p5))),
        crate::check::types::Ty::TyFn(_, ps_p6, r_p7) => fold(ps_p6, &qoccurs(q_p0, &**r_p7), &(|seen_p8: &bool, a_p9: &crate::check::types::Ty| *seen_p8 || qoccurs(q_p0, a_p9))),
        crate::check::types::Ty::TyTuple(ts_pa) => fold(ts_pa, &false, &(|seen_pb: &bool, a_pc: &crate::check::types::Ty| *seen_pb || qoccurs(q_p0, a_pc))),
        crate::check::types::Ty::TyArray(e_pd) => qoccurs(q_p0, &**e_pd),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => qoccurs(q_p0, &**k_pe) || qoccurs(q_p0, &**v_pf),
        crate::check::types::Ty::TySig(_, i_pg) => qoccurs(q_p0, &**i_pg),
        crate::check::types::Ty::TyAt(i_ph, _) => qoccurs(q_p0, &**i_ph),
        crate::check::types::Ty::TyElem(_, o_pi) => qoccurs(q_p0, &**o_pi),
        crate::check::types::Ty::TyAssoc(_, i_pj) => qoccurs(q_p0, &**i_pj),
        _ => false,
    }
}

/// ```prism
/// ElemOutQ: fn Text, Ty -> Bool
/// ```
pub fn elem_out_q(q_p0: &Text, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyElem(_, o_p2) => (&**o_p2 == &crate::check::types::Ty::TyQ(q_p0.clone())) || elem_out_q(q_p0, &**o_p2),
        crate::check::types::Ty::TyCon(_, args_p3) => fold(args_p3, &false, &(|seen_p4: &bool, a_p5: &crate::check::types::Ty| *seen_p4 || elem_out_q(q_p0, a_p5))),
        crate::check::types::Ty::TyFn(_, ps_p6, r_p7) => fold(ps_p6, &elem_out_q(q_p0, &**r_p7), &(|seen_p8: &bool, a_p9: &crate::check::types::Ty| *seen_p8 || elem_out_q(q_p0, a_p9))),
        crate::check::types::Ty::TyTuple(ts_pa) => fold(ts_pa, &false, &(|seen_pb: &bool, a_pc: &crate::check::types::Ty| *seen_pb || elem_out_q(q_p0, a_pc))),
        crate::check::types::Ty::TyArray(e_pd) => elem_out_q(q_p0, &**e_pd),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => elem_out_q(q_p0, &**k_pe) || elem_out_q(q_p0, &**v_pf),
        crate::check::types::Ty::TySig(_, i_pg) => elem_out_q(q_p0, &**i_pg),
        crate::check::types::Ty::TyAt(i_ph, _) => elem_out_q(q_p0, &**i_ph),
        _ => false,
    }
}

/// ```prism
/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
/// ```
pub fn escaped(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, rigids_p2: &Array<Text>, rt_p3: &crate::check::types::Ty, fname_p4: &Text, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    run_to_end(fold_job(rigids_p2.clone(), st_p1.clone(), {
        let env_p0 = env_p0.clone();
        let rt_p3 = rt_p3.clone();
        let span_p5 = span_p5.clone();
        let fname_p4 = fname_p4.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
            let env_p0 = env_p0.clone();
            let rt_p3 = rt_p3.clone();
            let span_p5 = span_p5.clone();
            let fname_p4 = fname_p4.clone();
            entered(once_job(move || {
                let s_p6 = p0;
                let r_p7 = p1;
                call_value(filter_job(keys(&env_p0.locals), {
                    let s_p6 = s_p6.clone();
                    let r_p7 = r_p7.clone();
                    let env_p0 = env_p0.clone();
                    Rc::new(move |p0: Text| {
                        let s_p6 = s_p6.clone();
                        let r_p7 = r_p7.clone();
                        let env_p0 = env_p0.clone();
                        entered(once_job(move || {
                            let k_p9 = p0;
                            prism_rtl::Turn::More(Rc::new(HasRigid { st_p0: s_p6.clone(), r_p1: r_p7.clone(), t_p2: or(&get(&env_p0.locals, &k_p9), &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)).ty.clone() }))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |filter_6547: Array<Text>| {
                    let outside_p8 = filter_6547;
                    call_then(start_has_rigid(s_p6.clone(), r_p7.clone(), rt_p3.clone()), move |has_rigid_6636: bool| if has_rigid_6636 {
                        prism_rtl::Turn::Finished(crate::check::types::recording::err(&s_p6, &Text::lit("refinement-escape"), &span_p5, &Text::from(format!("the call\'s result takes the output of the element `{}`\'s supplier answers, which is the supplier\'s alone (rank-2)", &fname_p4))))
                    } else {
                        match index(&outside_p8, &Nat::from(0u32)) {
                            Some(k_pa) => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s_p6, &Text::lit("refinement-escape"), &span_p5, &Text::from(format!("`{}`, outside the supplier `{}` is given, takes the output of the element the supplier answers, which is the supplier\'s alone (rank-2)", &k_pa, &fname_p4)))),
                            None => prism_rtl::Turn::Finished(s_p6.clone()),
                        }
                    })
                })
            }))
        }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `Escaped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
/// ```
pub struct Escaped {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub rigids_p2: Array<Text>,
    pub rt_p3: crate::check::types::Ty,
    pub fname_p4: Text,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for Escaped {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let rigids_p2 = &self.rigids_p2;
        let rt_p3 = &self.rt_p3;
        let fname_p4 = &self.fname_p4;
        let span_p5 = &self.span_p5;
        fold_job(rigids_p2.clone(), st_p1.clone(), {
            let env_p0 = env_p0.clone();
            let rt_p3 = rt_p3.clone();
            let span_p5 = span_p5.clone();
            let fname_p4 = fname_p4.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, Text)| {
                let env_p0 = env_p0.clone();
                let rt_p3 = rt_p3.clone();
                let span_p5 = span_p5.clone();
                let fname_p4 = fname_p4.clone();
                entered(once_job(move || {
                    let s_p6 = p0;
                    let r_p7 = p1;
                    call_value(filter_job(keys(&env_p0.locals), {
                        let s_p6 = s_p6.clone();
                        let r_p7 = r_p7.clone();
                        let env_p0 = env_p0.clone();
                        Rc::new(move |p0: Text| {
                            let s_p6 = s_p6.clone();
                            let r_p7 = r_p7.clone();
                            let env_p0 = env_p0.clone();
                            entered(once_job(move || {
                                let k_p9 = p0;
                                prism_rtl::Turn::More(Rc::new(HasRigid { st_p0: s_p6.clone(), r_p1: r_p7.clone(), t_p2: or(&get(&env_p0.locals, &k_p9), &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)).ty.clone() }))
                            }))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |filter_6547: Array<Text>| {
                        let outside_p8 = filter_6547;
                        call_then(start_has_rigid(s_p6.clone(), r_p7.clone(), rt_p3.clone()), move |has_rigid_6636: bool| if has_rigid_6636 {
                            prism_rtl::Turn::Finished(crate::check::types::recording::err(&s_p6, &Text::lit("refinement-escape"), &span_p5, &Text::from(format!("the call\'s result takes the output of the element `{}`\'s supplier answers, which is the supplier\'s alone (rank-2)", &fname_p4))))
                        } else {
                            match index(&outside_p8, &Nat::from(0u32)) {
                                Some(k_pa) => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s_p6, &Text::lit("refinement-escape"), &span_p5, &Text::from(format!("`{}`, outside the supplier `{}` is given, takes the output of the element the supplier answers, which is the supplier\'s alone (rank-2)", &k_pa, &fname_p4)))),
                                None => prism_rtl::Turn::Finished(s_p6.clone()),
                            }
                        })
                    })
                }))
            }) as Rc<dyn Fn((crate::check::types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }).cycle()
    }
}

/// `Start Escaped, x`: what the function value is when passed to `@Run`.
pub fn start_escaped(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, rigids_p2: Array<Text>, rt_p3: crate::check::types::Ty, fname_p4: Text, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Escaped { env_p0, st_p1, rigids_p2, rt_p3, fname_p4, span_p5 })
}

/// ```prism
/// HasRigid: unbounded fn St, Text, Ty -> Bool
/// ```
pub fn has_rigid(st_p0: &crate::check::types::St, r_p1: &Text, t_p2: &crate::check::types::Ty) -> bool {
    rigid_in(r_p1, &crate::check::types::recording::zonk(st_p0, t_p2))
}

/// The step machine of `HasRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HasRigid: unbounded fn St, Text, Ty -> Bool
/// ```
pub struct HasRigid {
    pub st_p0: crate::check::types::St,
    pub r_p1: Text,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for HasRigid {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let r_p1 = &self.r_p1;
        let t_p2 = &self.t_p2;
        let r_p1 = r_p1.clone();
        let st_p0 = st_p0.clone();
        let t_p2 = t_p2.clone();
        call_then(crate::check::types::recording::start_zonk(st_p0.clone(), t_p2.clone()), move |zonk_7123: crate::check::types::Ty| prism_rtl::Turn::Finished(rigid_in(&r_p1, &zonk_7123)))
    }
}

/// `Start HasRigid, x`: what the function value is when passed to `@Run`.
pub fn start_has_rigid(st_p0: crate::check::types::St, r_p1: Text, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HasRigid { st_p0, r_p1, t_p2 })
}

/// ```prism
/// RigidIn: fn Text, Ty -> Bool
/// ```
pub fn rigid_in(r_p0: &Text, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyRigid(n_p2) => n_p2 == r_p0,
        crate::check::types::Ty::TyCon(_, args_p3) => fold(args_p3, &false, &(|seen_p4: &bool, a_p5: &crate::check::types::Ty| *seen_p4 || rigid_in(r_p0, a_p5))),
        crate::check::types::Ty::TyFn(_, ps_p6, res_p7) => fold(ps_p6, &rigid_in(r_p0, &**res_p7), &(|seen_p8: &bool, a_p9: &crate::check::types::Ty| *seen_p8 || rigid_in(r_p0, a_p9))),
        crate::check::types::Ty::TyTuple(ts_pa) => fold(ts_pa, &false, &(|seen_pb: &bool, a_pc: &crate::check::types::Ty| *seen_pb || rigid_in(r_p0, a_pc))),
        crate::check::types::Ty::TyArray(e_pd) => rigid_in(r_p0, &**e_pd),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => rigid_in(r_p0, &**k_pe) || rigid_in(r_p0, &**v_pf),
        crate::check::types::Ty::TySig(_, i_pg) => rigid_in(r_p0, &**i_pg),
        crate::check::types::Ty::TyAt(i_ph, _) => rigid_in(r_p0, &**i_ph),
        crate::check::types::Ty::TyElem(_, o_pi) => rigid_in(r_p0, &**o_pi),
        crate::check::types::Ty::TyAssoc(_, i_pj) => rigid_in(r_p0, &**i_pj),
        _ => false,
    }
}

/// ```prism
/// IsLocalMaker: fn Text -> Bool
/// ```
pub fn is_local_maker(qk_p0: &Text) -> bool {
    crate::check::types::has_text(&Array::from(vec![Text::lit("Buffer.Numbered"), Text::lit("Buffer.Empty"), Text::lit("Table.Empty")]), qk_p0)
}

/// ```prism
/// LocalOutside: fn St, Text, Range -> St
/// ```
pub fn local_outside(st_p0: &crate::check::types::St, qk_p1: &Text, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    crate::check::types::recording::err_fix(st_p0, &Text::lit("local-escapes"), span_p2, &Text::from(format!("a `{}` lives only in an `&` block\'s local", &or(&index(&split_on(qk_p1, &Text::lit(".")), &Nat::from(0u32)), qk_p1))), &Text::from(format!("make it inside `update ...:` as `let &b = {} ...`, and `Freeze &b` for the plain value", qk_p1)))
}

/// ```prism
/// NoteCallee: fn St, Range, Range, Ty -> St
/// ```
pub fn note_callee(st_p0: &crate::check::types::St, at_p1: &crate::syntax::Range, cspan_p2: &crate::syntax::Range, t_p3: &crate::check::types::Ty) -> crate::check::types::St {
    if at_p1 == cspan_p2 {
        crate::check::types::recording::note_ty(st_p0, at_p1, t_p3)
    } else {
        crate::check::types::recording::note_ty(&crate::check::types::recording::note_ty(st_p0, at_p1, t_p3), cspan_p2, t_p3)
    }
}

/// ```prism
/// NoteMethodUse: fn St, ValInfo, Range -> St
/// ```
pub fn note_method_use(st_p0: &crate::check::types::St, v_p1: &crate::check::env::ValInfo, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    if &v_p1.sort != &Text::lit("method") {
        st_p0.clone()
    } else {
        {
            let (_, cls_p3) = or(&index(&v_p1.scheme.bounds, &Nat::from(0u32)), &(Text::lit(""), Text::lit("")));
            crate::check::types::recording::note_method(st_p0, span_p2, &v_p1.qk, &cls_p3)
        }
    }
}

/// ```prism
/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn fold_app(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let lambda_arity_p5 = match index(args_p3, &Nat::from(2u32)) {
        Some(a_p6) => lambda_arity(&a_p6.value),
        None => Nat::from(2u32),
    };
    if &lambda_arity_p5 == &Nat::from(3u32) {
        match crate::check::types::recording::walk(st_p1, t_p2) {
            crate::check::types::Ty::TyFn(col_p7, params_p8, res_p9) => {
                let (k_pc, st1_pd) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                let (v_pe, st2_pf) = crate::check::types::fresh_var(&st1_pd, &false, &Text::lit(""));
                let (b_pg, st3_ph) = crate::check::types::fresh_var(&st2_pf, &false, &Text::lit(""));
                let step_col_pa = match index(&params_p8, &Nat::from(2u32)) {
                    Some(crate::check::types::Ty::TyFn(c_pi, _, _)) => c_pi,
                    _ => col_p7.clone(),
                };
                let params2_pb = Array::from(vec![crate::check::types::Ty::TyMap(Rc::new(k_pc.clone()), Rc::new(v_pe.clone())), b_pg.clone(), crate::check::types::Ty::TyFn(step_col_pa.clone(), Array::from(vec![b_pg.clone(), k_pc.clone(), v_pe.clone()]), Rc::new(b_pg.clone()))]);
                apply_rule(env_p0, &st3_ph, &Text::lit("Fold"), &col_p7, &params2_pb, &b_pg, args_p3, span_p4)
            },
            _ => apply_fn(env_p0, st_p1, &Text::lit("Fold"), t_p2, args_p3, span_p4),
        }
    } else {
        apply_fn(env_p0, st_p1, &Text::lit("Fold"), t_p2, args_p3, span_p4)
    }
}

/// The step machine of `FoldApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct FoldApp {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for FoldApp {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let lambda_arity_p5 = match index(args_p3, &Nat::from(2u32)) {
            Some(a_p6) => lambda_arity(&a_p6.value),
            None => Nat::from(2u32),
        };
        if &lambda_arity_p5 == &Nat::from(3u32) {
            {
                let args_p3 = args_p3.clone();
                let env_p0 = env_p0.clone();
                let span_p4 = span_p4.clone();
                let st_p1 = st_p1.clone();
                let t_p2 = t_p2.clone();
                call_then(crate::check::types::recording::start_walk(st_p1.clone(), t_p2.clone()), move |walk_9063: crate::check::types::Ty| match walk_9063 {
                    crate::check::types::Ty::TyFn(col_p7, params_p8, res_p9) => {
                        let (k_pc, st1_pd) = crate::check::types::fresh_var(&st_p1, &false, &Text::lit(""));
                        let (v_pe, st2_pf) = crate::check::types::fresh_var(&st1_pd, &false, &Text::lit(""));
                        let (b_pg, st3_ph) = crate::check::types::fresh_var(&st2_pf, &false, &Text::lit(""));
                        let step_col_pa = match index(&params_p8, &Nat::from(2u32)) {
                            Some(crate::check::types::Ty::TyFn(c_pi, _, _)) => c_pi,
                            _ => col_p7.clone(),
                        };
                        let params2_pb = Array::from(vec![crate::check::types::Ty::TyMap(Rc::new(k_pc.clone()), Rc::new(v_pe.clone())), b_pg.clone(), crate::check::types::Ty::TyFn(step_col_pa.clone(), Array::from(vec![b_pg.clone(), k_pc.clone(), v_pe.clone()]), Rc::new(b_pg.clone()))]);
                        prism_rtl::Turn::More(Rc::new(ApplyRule { env_p0: env_p0.clone(), st_p1: st3_ph.clone(), fname_p2: Text::lit("Fold"), col_p3: col_p7.clone(), params_p4: params2_pb.clone(), res_p5: b_pg.clone(), args_p6: args_p3.clone(), span_p7: span_p4.clone() }))
                    },
                    _ => prism_rtl::Turn::More(Rc::new(ApplyFn { env_p0: env_p0.clone(), st_p1: st_p1.clone(), fname_p2: Text::lit("Fold"), fty_p3: t_p2.clone(), args_p4: args_p3.clone(), span_p5: span_p4.clone() })),
                })
            }
        } else {
            prism_rtl::Turn::More(Rc::new(ApplyFn { env_p0: env_p0.clone(), st_p1: st_p1.clone(), fname_p2: Text::lit("Fold"), fty_p3: t_p2.clone(), args_p4: args_p3.clone(), span_p5: span_p4.clone() }))
        }
    }
}

/// `Start FoldApp, x`: what the function value is when passed to `@Run`.
pub fn start_fold_app(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(FoldApp { env_p0, st_p1, t_p2, args_p3, span_p4 })
}

/// ```prism
/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn apply_fn(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fname_p2: &Text, fty_p3: &crate::check::types::Ty, args_p4: &Array<crate::syntax::Arg>, span_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let named_p6 = filter(args_p4, &(|a_p8: &crate::syntax::Arg| &a_p8.name != &None));
    let st0_p7 = if &len(&named_p6) > &Nat::from(0u32) {
        crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), span_p5, &Text::from(format!("`{}` takes its arguments by position; named arguments are a record\'s or a tag\'s", fname_p2)))
    } else {
        st_p1.clone()
    };
    match crate::check::types::recording::walk(&st0_p7, fty_p3) {
        crate::check::types::Ty::TyFn(col_p9, params_pa, res_pb) => if &len(&params_pa) != &len(args_p4) {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st0_p7, &Text::lit("mismatch"), span_p5, &Text::from(format!("`{}` takes {} argument{}; here it has {}", fname_p2, &crate::check::errors::count_word(&len(&params_pa)), &(if &len(&params_pa) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(args_p4))))))
        } else {
            apply_rule(env_p0, &st0_p7, fname_p2, &col_p9, &params_pa, &*res_pb, args_p4, span_p5)
        },
        crate::check::types::Ty::TyFlex(_) => {
            let (params_ph, st1_pi) = fold(args_p4, &(Array::new(), st0_p7.clone()), &(|(acc_pd, s_pe): &(Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Arg| {
                let (v_pf, s2_pg) = crate::check::types::fresh_var(s_pe, &false, &Text::lit(""));
                (push(acc_pd, &v_pf), s2_pg.clone())
            }));
            let (res_pj, st2_pk) = crate::check::types::fresh_var(&st1_pi, &false, &Text::lit(""));
            let (col_pl, st2b_pm) = crate::check::types::fresh_col(&st2_pk);
            let st3_pc = crate::check::types::unify::unify(&st2b_pm, fty_p3, &crate::check::types::Ty::TyFn(col_pl.clone(), params_ph.clone(), Rc::new(res_pj.clone())), span_p5);
            apply_rule(env_p0, &st3_pc, fname_p2, &col_pl, &params_ph, &res_pj, args_p4, span_p5)
        },
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st0_p7.clone()),
        other_pn => if &len(args_p4) == &Nat::from(0u32) {
            (other_pn.clone(), st0_p7.clone())
        } else {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st0_p7, &Text::lit("mismatch"), span_p5, &Text::from(format!("`{}` is a `{}`, not a function", fname_p2, &crate::check::types::show_ty(&st0_p7, &other_pn)))))
        },
    }
}

/// The step machine of `ApplyFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct ApplyFn {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fname_p2: Text,
    pub fty_p3: crate::check::types::Ty,
    pub args_p4: Array<crate::syntax::Arg>,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ApplyFn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fname_p2 = &self.fname_p2;
        let fty_p3 = &self.fty_p3;
        let args_p4 = &self.args_p4;
        let span_p5 = &self.span_p5;
        let named_p6 = filter(args_p4, &(|a_p8: &crate::syntax::Arg| &a_p8.name != &None));
        let st0_p7 = if &len(&named_p6) > &Nat::from(0u32) {
            crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), span_p5, &Text::from(format!("`{}` takes its arguments by position; named arguments are a record\'s or a tag\'s", fname_p2)))
        } else {
            st_p1.clone()
        };
        let args_p4 = args_p4.clone();
        let env_p0 = env_p0.clone();
        let fname_p2 = fname_p2.clone();
        let fty_p3 = fty_p3.clone();
        let span_p5 = span_p5.clone();
        call_then(crate::check::types::recording::start_walk(st0_p7.clone(), fty_p3.clone()), move |walk_10097: crate::check::types::Ty| match walk_10097 {
            crate::check::types::Ty::TyFn(col_p9, params_pa, res_pb) => if &len(&params_pa) != &len(&args_p4) {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st0_p7, &Text::lit("mismatch"), &span_p5, &Text::from(format!("`{}` takes {} argument{}; here it has {}", &fname_p2, &crate::check::errors::count_word(&len(&params_pa)), &(if &len(&params_pa) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(&args_p4)))))))
            } else {
                prism_rtl::Turn::More(Rc::new(ApplyRule { env_p0: env_p0.clone(), st_p1: st0_p7.clone(), fname_p2: fname_p2.clone(), col_p3: col_p9.clone(), params_p4: params_pa.clone(), res_p5: (*res_pb).clone(), args_p6: args_p4.clone(), span_p7: span_p5.clone() }))
            },
            crate::check::types::Ty::TyFlex(_) => {
                let (params_ph, st1_pi) = fold(&args_p4, &(Array::new(), st0_p7.clone()), &(|(acc_pd, s_pe): &(Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Arg| {
                    let (v_pf, s2_pg) = crate::check::types::fresh_var(s_pe, &false, &Text::lit(""));
                    (push(acc_pd, &v_pf), s2_pg.clone())
                }));
                let (res_pj, st2_pk) = crate::check::types::fresh_var(&st1_pi, &false, &Text::lit(""));
                let (col_pl, st2b_pm) = crate::check::types::fresh_col(&st2_pk);
                call_then(crate::check::types::unify::start_unify(st2b_pm.clone(), fty_p3.clone(), crate::check::types::Ty::TyFn(col_pl.clone(), params_ph.clone(), Rc::new(res_pj.clone())), span_p5.clone()), move |unify_10759: crate::check::types::St| {
                    let st3_pc = unify_10759;
                    prism_rtl::Turn::More(Rc::new(ApplyRule { env_p0: env_p0.clone(), st_p1: st3_pc.clone(), fname_p2: fname_p2.clone(), col_p3: col_pl.clone(), params_p4: params_ph.clone(), res_p5: res_pj.clone(), args_p6: args_p4.clone(), span_p7: span_p5.clone() }))
                })
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st0_p7.clone())),
            other_pn => if &len(&args_p4) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished((other_pn.clone(), st0_p7.clone()))
            } else {
                call_then(crate::check::types::start_show_ty(st0_p7.clone(), other_pn.clone()), move |show_ty_11039: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st0_p7, &Text::lit("mismatch"), &span_p5, &Text::from(format!("`{}` is a `{}`, not a function", &fname_p2, &show_ty_11039))))))
            },
        })
    }
}

/// `Start ApplyFn, x`: what the function value is when passed to `@Run`.
pub fn start_apply_fn(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fname_p2: Text, fty_p3: crate::check::types::Ty, args_p4: Array<crate::syntax::Arg>, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(ApplyFn { env_p0, st_p1, fname_p2, fty_p3, args_p4, span_p5 })
}

/// ```prism
/// Broken: fn Peeled, Bool -> Peeled
/// ```
pub fn broken(p_p0: &Peeled, b_p1: &bool) -> Peeled {
    if !*b_p1 {
        p_p0.clone()
    } else {
        {
            let mut this: Peeled = p_p0.clone();
            this.broken = true;
            this
        }
    }
}

/// ```prism
/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn apply_rule(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fname_p2: &Text, col_p3: &crate::check::types::Col, params_p4: &Array<crate::check::types::Ty>, res_p5: &crate::check::types::Ty, args_p6: &Array<crate::syntax::Arg>, span_p7: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let n_p8 = len(args_p6);
    let cmp_p9 = crate::check::expr::is_comparison(fname_p2);
    let (arg_tys_p12, st1_p13) = run_to_end(fold_job(crate::check::errors::range0(&n_p8), (Array::new(), st_p1.clone()), {
        let args_p6 = args_p6.clone();
        let span_p7 = span_p7.clone();
        let env_p0 = env_p0.clone();
        let params_p4 = params_p4.clone();
        let fname_p2 = fname_p2.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
            let args_p6 = args_p6.clone();
            let span_p7 = span_p7.clone();
            let env_p0 = env_p0.clone();
            let params_p4 = params_p4.clone();
            let fname_p2 = fname_p2.clone();
            entered(once_job(move || {
                let (acc_po, s_pp) = p0;
                let i_pq = p1;
                {
                    let a_pr = or(&index(&args_p6, &i_pq), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p7.clone() }, span: span_p7.clone() });
                    if crate::check::expr::is_lambda(&a_pr.value) {
                        prism_rtl::Turn::Finished((push(&acc_po, &crate::check::types::Ty::TyErr), s_pp.clone()))
                    } else {
                        call_then(crate::check::expr::start_infer(env_p0.clone(), s_pp.clone(), a_pr.value.clone()), move |infer_12500: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_ps, s2_pt) = infer_12500;
                            call_then(crate::check::types::recording::start_walk(s2_pt.clone(), or(&index(&params_p4, &i_pq), &crate::check::types::Ty::TyErr)), move |walk_12543: crate::check::types::Ty| call_then(crate::check::types::recording::start_walk(s2_pt.clone(), t_ps.clone()), move |walk_12577: crate::check::types::Ty| match (walk_12543, walk_12577) {
                                (crate::check::types::Ty::TyFn(pc_pu, _, _), crate::check::types::Ty::TyFn(ac_pv, aps_p10, ar_p11)) => call_then(crate::check::types::colors::start_add_leq(s2_pt.clone(), ac_pv.clone(), pc_pu.clone(), a_pr.value.span.clone(), Text::lit("arg"), fname_p2.clone(), Text::lit("")), move |add_leq_12694: crate::check::types::St| prism_rtl::Turn::Finished((push(&acc_po, &crate::check::types::Ty::TyFn(pc_pu.clone(), aps_p10.clone(), Rc::new((*ar_p11).clone()))), add_leq_12694))),
                                _ => prism_rtl::Turn::Finished((push(&acc_po, &t_ps), s2_pt.clone())),
                            }))
                        })
                    }
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }));
    let (st2_p1b, whole_p1c) = run_to_end(fold_job(crate::check::errors::range0(&n_p8), (st1_p13.clone(), Array::new()), {
        let args_p6 = args_p6.clone();
        let span_p7 = span_p7.clone();
        let arg_tys_p12 = arg_tys_p12.clone();
        let params_p4 = params_p4.clone();
        let env_p0 = env_p0.clone();
        let fname_p2 = fname_p2.clone();
        Rc::new(move |(p0, p1): ((crate::check::types::St, Array<Nat>), Nat)| {
            let args_p6 = args_p6.clone();
            let span_p7 = span_p7.clone();
            let arg_tys_p12 = arg_tys_p12.clone();
            let params_p4 = params_p4.clone();
            let env_p0 = env_p0.clone();
            let fname_p2 = fname_p2.clone();
            entered(once_job(move || {
                let (s_p14, done_p15) = p0;
                let i_p16 = p1;
                {
                    let a_p17 = or(&index(&args_p6, &i_p16), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p7.clone() }, span: span_p7.clone() });
                    let at_p18 = or(&index(&arg_tys_p12, &i_p16), &crate::check::types::Ty::TyErr);
                    call_then(crate::check::types::recording::start_walk(s_p14.clone(), or(&index(&params_p4, &i_p16), &crate::check::types::Ty::TyErr)), move |walk_13016: crate::check::types::Ty| {
                        let pnow_p19 = walk_13016;
                        call_then(crate::check::types::start_head_sigil(s_p14.clone(), pnow_p19.clone()), move |head_sigil_13083: Text| {
                            let whole_now_p1a = crate::check::expr::is_time_sigil(&head_sigil_13083) || (&crate::check::types::head_sigil(&s_p14, &pnow_p19) == &Text::lit("@"));
                            if crate::check::expr::is_lambda(&a_p17.value) {
                                prism_rtl::Turn::Finished((s_p14.clone(), done_p15.clone()))
                            } else {
                                if whole_now_p1a && (&crate::check::types::stack_of(&s_p14, &at_p18) != &Text::lit("")) {
                                    call_then(crate::check::types::unify::start_unify(s_p14.clone(), pnow_p19.clone(), at_p18.clone(), a_p17.value.span.clone()), move |unify_13230: crate::check::types::St| prism_rtl::Turn::Finished((unify_13230, push(&done_p15, &i_p16))))
                                } else {
                                    call_then(crate::check::types::start_stack_of(s_p14.clone(), at_p18.clone()), move |stack_of_13299: Text| if (&stack_of_13299 != &Text::lit("")) || crate::check::types::is_free_headed(&s_p14, &at_p18) {
                                        prism_rtl::Turn::Finished((s_p14.clone(), done_p15.clone()))
                                    } else {
                                        call_then(start_plain_arg(env_p0.clone(), s_p14.clone(), fname_p2.clone(), or(&index(&params_p4, &i_p16), &crate::check::types::Ty::TyErr), at_p18.clone(), a_p17.clone()), move |plain_arg_13374: crate::check::types::St| prism_rtl::Turn::Finished((plain_arg_13374, done_p15.clone())))
                                    })
                                }
                            }
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(((crate::check::types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, Array<Nat>)>>>
    }));
    let (_, st3_p1p) = run_to_end(fold_job(crate::check::errors::range0(&n_p8), (Map::new(), st2_p1b.clone()), {
        let args_p6 = args_p6.clone();
        let span_p7 = span_p7.clone();
        let params_p4 = params_p4.clone();
        let env_p0 = env_p0.clone();
        let fname_p2 = fname_p2.clone();
        Rc::new(move |(p0, p1): ((Map<(), ()>, crate::check::types::St), Nat)| {
            let args_p6 = args_p6.clone();
            let span_p7 = span_p7.clone();
            let params_p4 = params_p4.clone();
            let env_p0 = env_p0.clone();
            let fname_p2 = fname_p2.clone();
            entered(once_job(move || {
                let (m_p1d, s_p1e) = p0;
                let i_p1f = p1;
                {
                    let a_p1g = or(&index(&args_p6, &i_p1f), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p7.clone() }, span: span_p7.clone() });
                    if crate::check::expr::is_lambda(&a_p1g.value) {
                        call_then(crate::check::types::recording::start_walk(s_p1e.clone(), or(&index(&params_p4, &i_p1f), &crate::check::types::Ty::TyErr)), move |walk_13645: crate::check::types::Ty| {
                            let p_p1h = walk_13645;
                            call_then(start_infer_lambda(env_p0.clone(), s_p1e.clone(), a_p1g.value.clone(), Some(p_p1h.clone())), move |infer_lambda_13704: (crate::check::types::Ty, crate::check::types::St)| {
                                let (lt_p1j, s2_p1k) = infer_lambda_13704;
                                let s3_p1i = match (p_p1h.clone(), lt_p1j.clone()) {
                                    (crate::check::types::Ty::TyFn(pc_p1l, _, _), crate::check::types::Ty::TyFn(lc_p1m, lps_p1n, lr_p1o)) => crate::check::types::colors::add_leq(&crate::check::types::unify::unify(&crate::check::types::recording::note_ty(&s2_p1k, &a_p1g.value.span, &lt_p1j), &p_p1h, &crate::check::types::Ty::TyFn(pc_p1l.clone(), lps_p1n, Rc::new((*lr_p1o).clone())), &a_p1g.value.span), &lc_p1m, &pc_p1l, &a_p1g.value.span, &Text::lit("arg"), &fname_p2, &Text::lit("")),
                                    _ => crate::check::types::unify::unify(&crate::check::types::recording::note_ty(&s2_p1k, &a_p1g.value.span, &lt_p1j), &p_p1h, &lt_p1j, &a_p1g.value.span),
                                };
                                prism_rtl::Turn::Finished((m_p1d.clone(), s3_p1i.clone()))
                            })
                        })
                    } else {
                        prism_rtl::Turn::Finished((m_p1d.clone(), s_p1e.clone()))
                    }
                }
            }))
        }) as Rc<dyn Fn(((Map<(), ()>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Map<(), ()>, crate::check::types::St)>>>
    }));
    let (pl_p25, st4_p26) = run_to_end(fold_job(crate::check::errors::range0(&n_p8), (Peeled { events: Array::new(), dyns: Array::new(), opts: Array::new(), opt_args: Array::new(), lifted: Text::lit(""), broken: false }, st3_p1p.clone()), {
        let args_p6 = args_p6.clone();
        let span_p7 = span_p7.clone();
        let arg_tys_p12 = arg_tys_p12.clone();
        let whole_p1c = whole_p1c.clone();
        let env_p0 = env_p0.clone();
        let fname_p2 = fname_p2.clone();
        let cmp_p9 = cmp_p9;
        let params_p4 = params_p4.clone();
        Rc::new(move |(p0, p1): ((Peeled, crate::check::types::St), Nat)| {
            let args_p6 = args_p6.clone();
            let span_p7 = span_p7.clone();
            let arg_tys_p12 = arg_tys_p12.clone();
            let whole_p1c = whole_p1c.clone();
            let env_p0 = env_p0.clone();
            let fname_p2 = fname_p2.clone();
            let cmp_p9 = cmp_p9;
            let params_p4 = params_p4.clone();
            entered(once_job(move || {
                let (acc_p1q, s_p1r) = p0;
                let i_p1s = p1;
                {
                    let a_p1t = or(&index(&args_p6, &i_p1s), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p7.clone() }, span: span_p7.clone() });
                    let at_p1u = or(&index(&arg_tys_p12, &i_p1s), &crate::check::types::Ty::TyErr);
                    if (crate::check::expr::is_lambda(&a_p1t.value) || crate::check::types::has_nat(&whole_p1c, &i_p1s)) || ((&crate::check::types::stack_of(&s_p1r, &at_p1u) == &Text::lit("")) && !crate::check::types::is_free_headed(&s_p1r, &at_p1u)) {
                        prism_rtl::Turn::Finished((acc_p1q.clone(), s_p1r.clone()))
                    } else {
                        {
                            let before_p1v = len(&s_p1r.diags);
                            call_then(start_layered_arg(env_p0.clone(), s_p1r.clone(), acc_p1q.clone(), fname_p2.clone(), cmp_p9, or(&index(&params_p4, &i_p1s), &crate::check::types::Ty::TyErr), at_p1u.clone(), a_p1t.clone()), move |layered_arg_14569: (Peeled, crate::check::types::St)| {
                                let (acc2_p21, s2_p22) = layered_arg_14569;
                                let broke_p20 = (&len(&s2_p22.diags) > &before_p1v) && fold(&drop(&s2_p22.diags, &before_p1v), &false, &(|seen_p23: &bool, d_p24: &crate::check::errors::CDiag| *seen_p23 || crate::check::types::has_text(&Array::from(vec![Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")]), &d_p24.code)));
                                prism_rtl::Turn::Finished((broken(&acc2_p21, &broke_p20), s2_p22.clone()))
                            })
                        }
                    }
                }
            }))
        }) as Rc<dyn Fn(((Peeled, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check::types::St)>>>
    }));
    let st5_pa = if &len(&pl_p25.events) > &Nat::from(1u32) {
        crate::check::types::recording::err_fix(&st4_p26, &Text::lit("two-events"), &or(&index(&pl_p25.events, &Nat::from(1u32)), span_p7), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
    } else {
        st4_p26.clone()
    };
    let st6_pb = if &len(&pl_p25.opts) > &Nat::from(1u32) {
        crate::check::types::recording::err(&st5_pa, &Text::lit("optional-and-fault"), span_p7, &Text::lit("`?` and `~` in one operation"))
    } else {
        st5_pa.clone()
    };
    let layer_pc = if &len(&pl_p25.events) > &Nat::from(0u32) {
        Text::lit("!")
    } else {
        if &len(&pl_p25.dyns) > &Nat::from(0u32) { Text::lit("$") } else { Text::lit("") }
    };
    let with_opt_pd = match index(&pl_p25.opts, &Nat::from(0u32)) {
        Some(o_p27) => crate::check::types::Ty::TySig(o_p27, Rc::new(res_p5.clone())),
        None => res_p5.clone(),
    };
    let result_pe = if pl_p25.broken {
        crate::check::types::Ty::TyErr
    } else {
        if &layer_pc == &Text::lit("") {
            with_opt_pd.clone()
        } else {
            crate::check::types::Ty::TySig(layer_pc.clone(), Rc::new(with_opt_pd.clone()))
        }
    };
    let call_col_pf = crate::check::types::colors::walk_col(&st6_pb, col_p3);
    let st7_pg = if (&layer_pc != &Text::lit("")) && crate::check::types::colors::is_flex_col(&call_col_pf) {
        crate::check::types::colors::add_leq(&st6_pb, &call_col_pf, &crate::check::types::Col::CBound, span_p7, &Text::lit("lifted"), fname_p2, &pl_p25.lifted)
    } else {
        st6_pb.clone()
    };
    let lifted_bad_ph = ((&layer_pc != &Text::lit("")) && (&call_col_pf != &crate::check::types::Col::CBound)) && !crate::check::types::colors::is_flex_col(&call_col_pf);
    let st8_pi = if lifted_bad_ph {
        crate::check::types::recording::err_fix(&st7_pg, &Text::lit("lifted-unbounded"), span_p7, &Text::from(format!("{} `{}` lifted over `{}`; use `@Run`", &crate::check::types::colors::col_word(&call_col_pf), fname_p2, &pl_p25.lifted)), &Text::from(format!("run it through `!done <- @Run {}, ...`", fname_p2)))
    } else {
        st7_pg.clone()
    };
    let st9_pj = crate::check::types::colors::use_color(&st8_pi, &call_col_pf, fname_p2, span_p7);
    let kind_pk = if (&layer_pc == &Text::lit("!")) && (&len(&pl_p25.dyns) > &Nat::from(0u32)) {
        Text::lit("sample")
    } else {
        if &layer_pc != &Text::lit("") {
            Text::lit("map")
        } else {
            if fname_p2 == &Text::lit("$") { Text::lit("const") } else { Text::lit("plain") }
        }
    };
    let peeled_pl = append(&pl_p25.events, &pl_p25.dyns);
    let lifted_pm = filter(&crate::check::errors::range0(&n_p8), &(|i_p28: &Nat| has_range(&peeled_pl, &or(&index(args_p6, i_p28), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p7.clone() }, span: span_p7.clone() }).value.span)));
    let st10_pn = if pl_p25.broken || (&len(&pl_p25.opts) != &Nat::from(1u32)) {
        st9_pj.clone()
    } else {
        crate::check::types::recording::note_lift(&st9_pj, span_p7, &or(&index(&pl_p25.opts, &Nat::from(0u32)), &Text::lit("")), &pl_p25.opt_args)
    };
    (result_pe.clone(), crate::check::types::recording::note_app(&st10_pn, span_p7, fname_p2, &kind_pk, &layer_pc, &lifted_pm, &or(&index(&pl_p25.opts, &Nat::from(0u32)), &Text::lit("")), &call_col_pf))
}

/// The step machine of `ApplyRule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct ApplyRule {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fname_p2: Text,
    pub col_p3: crate::check::types::Col,
    pub params_p4: Array<crate::check::types::Ty>,
    pub res_p5: crate::check::types::Ty,
    pub args_p6: Array<crate::syntax::Arg>,
    pub span_p7: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ApplyRule {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fname_p2 = &self.fname_p2;
        let col_p3 = &self.col_p3;
        let params_p4 = &self.params_p4;
        let res_p5 = &self.res_p5;
        let args_p6 = &self.args_p6;
        let span_p7 = &self.span_p7;
        let n_p8 = len(args_p6);
        let cmp_p9 = crate::check::expr::is_comparison(fname_p2);
        let args_p6 = args_p6.clone();
        let col_p3 = col_p3.clone();
        let env_p0 = env_p0.clone();
        let fname_p2 = fname_p2.clone();
        let params_p4 = params_p4.clone();
        let res_p5 = res_p5.clone();
        let span_p7 = span_p7.clone();
        let st_p1 = st_p1.clone();
        call_value(fold_job(crate::check::errors::range0(&n_p8), (Array::new(), st_p1.clone()), {
            let args_p6 = args_p6.clone();
            let span_p7 = span_p7.clone();
            let env_p0 = env_p0.clone();
            let params_p4 = params_p4.clone();
            let fname_p2 = fname_p2.clone();
            Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
                let args_p6 = args_p6.clone();
                let span_p7 = span_p7.clone();
                let env_p0 = env_p0.clone();
                let params_p4 = params_p4.clone();
                let fname_p2 = fname_p2.clone();
                entered(once_job(move || {
                    let (acc_po, s_pp) = p0;
                    let i_pq = p1;
                    {
                        let a_pr = or(&index(&args_p6, &i_pq), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p7.clone() }, span: span_p7.clone() });
                        if crate::check::expr::is_lambda(&a_pr.value) {
                            prism_rtl::Turn::Finished((push(&acc_po, &crate::check::types::Ty::TyErr), s_pp.clone()))
                        } else {
                            call_then(crate::check::expr::start_infer(env_p0.clone(), s_pp.clone(), a_pr.value.clone()), move |infer_12500: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t_ps, s2_pt) = infer_12500;
                                call_then(crate::check::types::recording::start_walk(s2_pt.clone(), or(&index(&params_p4, &i_pq), &crate::check::types::Ty::TyErr)), move |walk_12543: crate::check::types::Ty| call_then(crate::check::types::recording::start_walk(s2_pt.clone(), t_ps.clone()), move |walk_12577: crate::check::types::Ty| match (walk_12543, walk_12577) {
                                    (crate::check::types::Ty::TyFn(pc_pu, _, _), crate::check::types::Ty::TyFn(ac_pv, aps_p10, ar_p11)) => call_then(crate::check::types::colors::start_add_leq(s2_pt.clone(), ac_pv.clone(), pc_pu.clone(), a_pr.value.span.clone(), Text::lit("arg"), fname_p2.clone(), Text::lit("")), move |add_leq_12694: crate::check::types::St| prism_rtl::Turn::Finished((push(&acc_po, &crate::check::types::Ty::TyFn(pc_pu.clone(), aps_p10.clone(), Rc::new((*ar_p11).clone()))), add_leq_12694))),
                                    _ => prism_rtl::Turn::Finished((push(&acc_po, &t_ps), s2_pt.clone())),
                                }))
                            })
                        }
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }), move |fold_12267: (Array<crate::check::types::Ty>, crate::check::types::St)| {
            let (arg_tys_p12, st1_p13) = fold_12267;
            call_value(fold_job(crate::check::errors::range0(&n_p8), (st1_p13.clone(), Array::new()), {
                let args_p6 = args_p6.clone();
                let span_p7 = span_p7.clone();
                let arg_tys_p12 = arg_tys_p12.clone();
                let params_p4 = params_p4.clone();
                let env_p0 = env_p0.clone();
                let fname_p2 = fname_p2.clone();
                Rc::new(move |(p0, p1): ((crate::check::types::St, Array<Nat>), Nat)| {
                    let args_p6 = args_p6.clone();
                    let span_p7 = span_p7.clone();
                    let arg_tys_p12 = arg_tys_p12.clone();
                    let params_p4 = params_p4.clone();
                    let env_p0 = env_p0.clone();
                    let fname_p2 = fname_p2.clone();
                    entered(once_job(move || {
                        let (s_p14, done_p15) = p0;
                        let i_p16 = p1;
                        {
                            let a_p17 = or(&index(&args_p6, &i_p16), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p7.clone() }, span: span_p7.clone() });
                            let at_p18 = or(&index(&arg_tys_p12, &i_p16), &crate::check::types::Ty::TyErr);
                            call_then(crate::check::types::recording::start_walk(s_p14.clone(), or(&index(&params_p4, &i_p16), &crate::check::types::Ty::TyErr)), move |walk_13016: crate::check::types::Ty| {
                                let pnow_p19 = walk_13016;
                                call_then(crate::check::types::start_head_sigil(s_p14.clone(), pnow_p19.clone()), move |head_sigil_13083: Text| {
                                    let whole_now_p1a = crate::check::expr::is_time_sigil(&head_sigil_13083) || (&crate::check::types::head_sigil(&s_p14, &pnow_p19) == &Text::lit("@"));
                                    if crate::check::expr::is_lambda(&a_p17.value) {
                                        prism_rtl::Turn::Finished((s_p14.clone(), done_p15.clone()))
                                    } else {
                                        if whole_now_p1a && (&crate::check::types::stack_of(&s_p14, &at_p18) != &Text::lit("")) {
                                            call_then(crate::check::types::unify::start_unify(s_p14.clone(), pnow_p19.clone(), at_p18.clone(), a_p17.value.span.clone()), move |unify_13230: crate::check::types::St| prism_rtl::Turn::Finished((unify_13230, push(&done_p15, &i_p16))))
                                        } else {
                                            call_then(crate::check::types::start_stack_of(s_p14.clone(), at_p18.clone()), move |stack_of_13299: Text| if (&stack_of_13299 != &Text::lit("")) || crate::check::types::is_free_headed(&s_p14, &at_p18) {
                                                prism_rtl::Turn::Finished((s_p14.clone(), done_p15.clone()))
                                            } else {
                                                call_then(start_plain_arg(env_p0.clone(), s_p14.clone(), fname_p2.clone(), or(&index(&params_p4, &i_p16), &crate::check::types::Ty::TyErr), at_p18.clone(), a_p17.clone()), move |plain_arg_13374: crate::check::types::St| prism_rtl::Turn::Finished((plain_arg_13374, done_p15.clone())))
                                            })
                                        }
                                    }
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(((crate::check::types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, Array<Nat>)>>>
            }), move |fold_12821: (crate::check::types::St, Array<Nat>)| {
                let (st2_p1b, whole_p1c) = fold_12821;
                call_value(fold_job(crate::check::errors::range0(&n_p8), (Map::new(), st2_p1b.clone()), {
                    let args_p6 = args_p6.clone();
                    let span_p7 = span_p7.clone();
                    let params_p4 = params_p4.clone();
                    let env_p0 = env_p0.clone();
                    let fname_p2 = fname_p2.clone();
                    Rc::new(move |(p0, p1): ((Map<(), ()>, crate::check::types::St), Nat)| {
                        let args_p6 = args_p6.clone();
                        let span_p7 = span_p7.clone();
                        let params_p4 = params_p4.clone();
                        let env_p0 = env_p0.clone();
                        let fname_p2 = fname_p2.clone();
                        entered(once_job(move || {
                            let (m_p1d, s_p1e) = p0;
                            let i_p1f = p1;
                            {
                                let a_p1g = or(&index(&args_p6, &i_p1f), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p7.clone() }, span: span_p7.clone() });
                                if crate::check::expr::is_lambda(&a_p1g.value) {
                                    call_then(crate::check::types::recording::start_walk(s_p1e.clone(), or(&index(&params_p4, &i_p1f), &crate::check::types::Ty::TyErr)), move |walk_13645: crate::check::types::Ty| {
                                        let p_p1h = walk_13645;
                                        call_then(start_infer_lambda(env_p0.clone(), s_p1e.clone(), a_p1g.value.clone(), Some(p_p1h.clone())), move |infer_lambda_13704: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (lt_p1j, s2_p1k) = infer_lambda_13704;
                                            let s3_p1i = match (p_p1h.clone(), lt_p1j.clone()) {
                                                (crate::check::types::Ty::TyFn(pc_p1l, _, _), crate::check::types::Ty::TyFn(lc_p1m, lps_p1n, lr_p1o)) => crate::check::types::colors::add_leq(&crate::check::types::unify::unify(&crate::check::types::recording::note_ty(&s2_p1k, &a_p1g.value.span, &lt_p1j), &p_p1h, &crate::check::types::Ty::TyFn(pc_p1l.clone(), lps_p1n, Rc::new((*lr_p1o).clone())), &a_p1g.value.span), &lc_p1m, &pc_p1l, &a_p1g.value.span, &Text::lit("arg"), &fname_p2, &Text::lit("")),
                                                _ => crate::check::types::unify::unify(&crate::check::types::recording::note_ty(&s2_p1k, &a_p1g.value.span, &lt_p1j), &p_p1h, &lt_p1j, &a_p1g.value.span),
                                            };
                                            prism_rtl::Turn::Finished((m_p1d.clone(), s3_p1i.clone()))
                                        })
                                    })
                                } else {
                                    prism_rtl::Turn::Finished((m_p1d.clone(), s_p1e.clone()))
                                }
                            }
                        }))
                    }) as Rc<dyn Fn(((Map<(), ()>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Map<(), ()>, crate::check::types::St)>>>
                }), move |fold_13462: (Map<(), ()>, crate::check::types::St)| {
                    let (_, st3_p1p) = fold_13462;
                    call_value(fold_job(crate::check::errors::range0(&n_p8), (Peeled { events: Array::new(), dyns: Array::new(), opts: Array::new(), opt_args: Array::new(), lifted: Text::lit(""), broken: false }, st3_p1p.clone()), {
                        let args_p6 = args_p6.clone();
                        let span_p7 = span_p7.clone();
                        let arg_tys_p12 = arg_tys_p12.clone();
                        let whole_p1c = whole_p1c.clone();
                        let env_p0 = env_p0.clone();
                        let fname_p2 = fname_p2.clone();
                        let cmp_p9 = cmp_p9;
                        let params_p4 = params_p4.clone();
                        Rc::new(move |(p0, p1): ((Peeled, crate::check::types::St), Nat)| {
                            let args_p6 = args_p6.clone();
                            let span_p7 = span_p7.clone();
                            let arg_tys_p12 = arg_tys_p12.clone();
                            let whole_p1c = whole_p1c.clone();
                            let env_p0 = env_p0.clone();
                            let fname_p2 = fname_p2.clone();
                            let cmp_p9 = cmp_p9;
                            let params_p4 = params_p4.clone();
                            entered(once_job(move || {
                                let (acc_p1q, s_p1r) = p0;
                                let i_p1s = p1;
                                {
                                    let a_p1t = or(&index(&args_p6, &i_p1s), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p7.clone() }, span: span_p7.clone() });
                                    let at_p1u = or(&index(&arg_tys_p12, &i_p1s), &crate::check::types::Ty::TyErr);
                                    if (crate::check::expr::is_lambda(&a_p1t.value) || crate::check::types::has_nat(&whole_p1c, &i_p1s)) || ((&crate::check::types::stack_of(&s_p1r, &at_p1u) == &Text::lit("")) && !crate::check::types::is_free_headed(&s_p1r, &at_p1u)) {
                                        prism_rtl::Turn::Finished((acc_p1q.clone(), s_p1r.clone()))
                                    } else {
                                        {
                                            let before_p1v = len(&s_p1r.diags);
                                            call_then(start_layered_arg(env_p0.clone(), s_p1r.clone(), acc_p1q.clone(), fname_p2.clone(), cmp_p9, or(&index(&params_p4, &i_p1s), &crate::check::types::Ty::TyErr), at_p1u.clone(), a_p1t.clone()), move |layered_arg_14569: (Peeled, crate::check::types::St)| {
                                                let (acc2_p21, s2_p22) = layered_arg_14569;
                                                let broke_p20 = (&len(&s2_p22.diags) > &before_p1v) && fold(&drop(&s2_p22.diags, &before_p1v), &false, &(|seen_p23: &bool, d_p24: &crate::check::errors::CDiag| *seen_p23 || crate::check::types::has_text(&Array::from(vec![Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")]), &d_p24.code)));
                                                prism_rtl::Turn::Finished((broken(&acc2_p21, &broke_p20), s2_p22.clone()))
                                            })
                                        }
                                    }
                                }
                            }))
                        }) as Rc<dyn Fn(((Peeled, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check::types::St)>>>
                    }), move |fold_14117: (Peeled, crate::check::types::St)| {
                        let (pl_p25, st4_p26) = fold_14117;
                        let st5_pa = if &len(&pl_p25.events) > &Nat::from(1u32) {
                            crate::check::types::recording::err_fix(&st4_p26, &Text::lit("two-events"), &or(&index(&pl_p25.events, &Nat::from(1u32)), &span_p7), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
                        } else {
                            st4_p26.clone()
                        };
                        let st6_pb = if &len(&pl_p25.opts) > &Nat::from(1u32) {
                            crate::check::types::recording::err(&st5_pa, &Text::lit("optional-and-fault"), &span_p7, &Text::lit("`?` and `~` in one operation"))
                        } else {
                            st5_pa.clone()
                        };
                        let layer_pc = if &len(&pl_p25.events) > &Nat::from(0u32) {
                            Text::lit("!")
                        } else {
                            if &len(&pl_p25.dyns) > &Nat::from(0u32) { Text::lit("$") } else { Text::lit("") }
                        };
                        let with_opt_pd = match index(&pl_p25.opts, &Nat::from(0u32)) {
                            Some(o_p27) => crate::check::types::Ty::TySig(o_p27, Rc::new(res_p5.clone())),
                            None => res_p5.clone(),
                        };
                        let result_pe = if pl_p25.broken {
                            crate::check::types::Ty::TyErr
                        } else {
                            if &layer_pc == &Text::lit("") {
                                with_opt_pd.clone()
                            } else {
                                crate::check::types::Ty::TySig(layer_pc.clone(), Rc::new(with_opt_pd.clone()))
                            }
                        };
                        call_then(crate::check::types::colors::start_walk_col(st6_pb.clone(), col_p3.clone()), move |walk_col_15617: crate::check::types::Col| {
                            let call_col_pf = walk_col_15617;
                            let st7_pg = if (&layer_pc != &Text::lit("")) && crate::check::types::colors::is_flex_col(&call_col_pf) {
                                crate::check::types::colors::add_leq(&st6_pb, &call_col_pf, &crate::check::types::Col::CBound, &span_p7, &Text::lit("lifted"), &fname_p2, &pl_p25.lifted)
                            } else {
                                st6_pb.clone()
                            };
                            let lifted_bad_ph = ((&layer_pc != &Text::lit("")) && (&call_col_pf != &crate::check::types::Col::CBound)) && !crate::check::types::colors::is_flex_col(&call_col_pf);
                            let st8_pi = if lifted_bad_ph {
                                crate::check::types::recording::err_fix(&st7_pg, &Text::lit("lifted-unbounded"), &span_p7, &Text::from(format!("{} `{}` lifted over `{}`; use `@Run`", &crate::check::types::colors::col_word(&call_col_pf), &fname_p2, &pl_p25.lifted)), &Text::from(format!("run it through `!done <- @Run {}, ...`", &fname_p2)))
                            } else {
                                st7_pg.clone()
                            };
                            call_then(crate::check::types::colors::start_use_color(st8_pi.clone(), call_col_pf.clone(), fname_p2.clone(), span_p7.clone()), move |use_color_16047: crate::check::types::St| {
                                let st9_pj = use_color_16047;
                                let kind_pk = if (&layer_pc == &Text::lit("!")) && (&len(&pl_p25.dyns) > &Nat::from(0u32)) {
                                    Text::lit("sample")
                                } else {
                                    if &layer_pc != &Text::lit("") {
                                        Text::lit("map")
                                    } else {
                                        if &fname_p2 == &Text::lit("$") { Text::lit("const") } else { Text::lit("plain") }
                                    }
                                };
                                let peeled_pl = append(&pl_p25.events, &pl_p25.dyns);
                                let lifted_pm = filter(&crate::check::errors::range0(&n_p8), &(|i_p28: &Nat| has_range(&peeled_pl, &or(&index(&args_p6, i_p28), &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p7.clone() }, span: span_p7.clone() }).value.span)));
                                let st10_pn = if pl_p25.broken || (&len(&pl_p25.opts) != &Nat::from(1u32)) {
                                    st9_pj.clone()
                                } else {
                                    crate::check::types::recording::note_lift(&st9_pj, &span_p7, &or(&index(&pl_p25.opts, &Nat::from(0u32)), &Text::lit("")), &pl_p25.opt_args)
                                };
                                prism_rtl::Turn::Finished((result_pe.clone(), crate::check::types::recording::note_app(&st10_pn, &span_p7, &fname_p2, &kind_pk, &layer_pc, &lifted_pm, &or(&index(&pl_p25.opts, &Nat::from(0u32)), &Text::lit("")), &call_col_pf)))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start ApplyRule, x`: what the function value is when passed to `@Run`.
pub fn start_apply_rule(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fname_p2: Text, col_p3: crate::check::types::Col, params_p4: Array<crate::check::types::Ty>, res_p5: crate::check::types::Ty, args_p6: Array<crate::syntax::Arg>, span_p7: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(ApplyRule { env_p0, st_p1, fname_p2, col_p3, params_p4, res_p5, args_p6, span_p7 })
}

/// ```prism
/// HasRange: fn [Range], Range -> Bool
/// ```
pub fn has_range(rs_p0: &Array<crate::syntax::Range>, r_p1: &crate::syntax::Range) -> bool {
    fold(rs_p0, &false, &(|seen_p2: &bool, x_p3: &crate::syntax::Range| *seen_p2 || (x_p3 == r_p1)))
}

/// ```prism
/// Elab: fn St, Range, Text, Text, Text -> St
/// ```
pub fn elab(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, what_p2: &Text, kind_p3: &Text, layer_p4: &Text) -> crate::check::types::St {
    crate::check::types::recording::note_app(st_p0, span_p1, what_p2, kind_p3, layer_p4, &Array::new(), &Text::lit(""), &crate::check::types::Col::CBound)
}

/// ```prism
/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
/// ```
pub fn plain_arg(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fname_p2: &Text, param_p3: &crate::check::types::Ty, at_p4: &crate::check::types::Ty, a_p5: &crate::syntax::Arg) -> crate::check::types::St {
    let p_p6 = crate::check::types::recording::walk(st_p1, param_p3);
    let ph_p7 = crate::check::types::head_sigil(st_p1, &p_p6);
    if at_p4 == &crate::check::types::Ty::TyErr {
        st_p1.clone()
    } else {
        if crate::check::expr::is_time_sigil(&ph_p7) || (&ph_p7 == &Text::lit("@")) {
            {
                let shown_p8 = if crate::check::types::is_flex_var(st_p1, at_p4) {
                    crate::check::expr::src_text(env_p0, &a_p5.value.span)
                } else {
                    crate::check::types::show_ty(st_p1, at_p4)
                };
                crate::check::types::recording::err_fix(st_p1, &Text::lit("plain-for-sigiled"), &a_p5.value.span, &Text::from(format!("a plain `{}` where `{}` takes a `{}`", &shown_p8, fname_p2, &crate::check::types::show_ty(st_p1, &p_p6))), &Text::from(format!("write `{} {}`", &ph_p7, &crate::check::expr::src_text(env_p0, &a_p5.value.span))))
            }
        } else {
            crate::check::types::unify::unify(st_p1, &p_p6, at_p4, &a_p5.value.span)
        }
    }
}

/// The step machine of `PlainArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
/// ```
pub struct PlainArg {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fname_p2: Text,
    pub param_p3: crate::check::types::Ty,
    pub at_p4: crate::check::types::Ty,
    pub a_p5: crate::syntax::Arg,
}

impl prism_rtl::Job<crate::check::types::St> for PlainArg {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fname_p2 = &self.fname_p2;
        let param_p3 = &self.param_p3;
        let at_p4 = &self.at_p4;
        let a_p5 = &self.a_p5;
        let a_p5 = a_p5.clone();
        let at_p4 = at_p4.clone();
        let env_p0 = env_p0.clone();
        let fname_p2 = fname_p2.clone();
        let param_p3 = param_p3.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p1.clone(), param_p3.clone()), move |walk_17274: crate::check::types::Ty| {
            let p_p6 = walk_17274;
            call_then(crate::check::types::start_head_sigil(st_p1.clone(), p_p6.clone()), move |head_sigil_17302: Text| {
                let ph_p7 = head_sigil_17302;
                if &at_p4 == &crate::check::types::Ty::TyErr {
                    prism_rtl::Turn::Finished(st_p1.clone())
                } else {
                    if crate::check::expr::is_time_sigil(&ph_p7) || (&ph_p7 == &Text::lit("@")) {
                        call_then(crate::check::types::start_is_flex_var(st_p1.clone(), at_p4.clone()), move |is_flex_var_17408: bool| {
                            let shown_p8 = if is_flex_var_17408 {
                                crate::check::expr::src_text(&env_p0, &a_p5.value.span)
                            } else {
                                crate::check::types::show_ty(&st_p1, &at_p4)
                            };
                            call_then(crate::check::types::start_show_ty(st_p1.clone(), p_p6.clone()), move |show_ty_17571: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st_p1, &Text::lit("plain-for-sigiled"), &a_p5.value.span, &Text::from(format!("a plain `{}` where `{}` takes a `{}`", &shown_p8, &fname_p2, &show_ty_17571)), &Text::from(format!("write `{} {}`", &ph_p7, &crate::check::expr::src_text(&env_p0, &a_p5.value.span))))))
                        })
                    } else {
                        prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st_p1.clone(), expected_p1: p_p6.clone(), found_p2: at_p4.clone(), span_p3: a_p5.value.span.clone() }))
                    }
                }
            })
        })
    }
}

/// `Start PlainArg, x`: what the function value is when passed to `@Run`.
pub fn start_plain_arg(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fname_p2: Text, param_p3: crate::check::types::Ty, at_p4: crate::check::types::Ty, a_p5: crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(PlainArg { env_p0, st_p1, fname_p2, param_p3, at_p4, a_p5 })
}

/// ```prism
/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub fn layered_arg(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, acc_p2: &Peeled, fname_p3: &Text, cmp_p4: &bool, param_p5: &crate::check::types::Ty, at_p6: &crate::check::types::Ty, a_p7: &crate::syntax::Arg) -> (Peeled, crate::check::types::St) {
    let p_p8 = crate::check::types::recording::walk(st_p1, param_p5);
    let span_p9 = a_p7.value.span.clone();
    let ph_pa = crate::check::types::head_sigil(st_p1, &p_p8);
    if crate::check::types::is_free_headed(st_p1, at_p6) {
        {
            let st2_pb = if ((crate::check::expr::is_time_sigil(&ph_pa) || (&ph_pa == &Text::lit("@"))) || (&ph_pa == &Text::lit("&"))) || *cmp_p4 {
                st_p1.clone()
            } else {
                crate::check::types::unify::ask_layer(st_p1, at_p6, &span_p9, fname_p3)
            };
            (acc_p2.clone(), crate::check::types::unify::unify(&st2_pb, &p_p8, at_p6, &span_p9))
        }
    } else {
        if (crate::check::expr::is_time_sigil(&ph_pa) || (&ph_pa == &Text::lit("@"))) || (&ph_pa == &Text::lit("&")) {
            (acc_p2.clone(), crate::check::types::unify::unify(st_p1, &p_p8, at_p6, &span_p9))
        } else {
            if crate::check::expr::is_plain_sigil(&ph_pa) {
                peel_time_only(env_p0, st_p1, acc_p2, fname_p3, &p_p8, at_p6, a_p7)
            } else {
                {
                    let head_pc = crate::check::types::head_sigil(st_p1, at_p6);
                    if &head_pc == &Text::lit("@") {
                        (acc_p2.clone(), crate::check::types::recording::err_fix(st_p1, &Text::lit("blueprint-operand"), &span_p9, &Text::from(format!("`{}` over a blueprint; bind it first", fname_p3)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text(env_p0, &span_p9)))))
                    } else {
                        if crate::check::expr::is_time_sigil(&head_pc) {
                            {
                                let inner_pd = crate::check::expr::inner_of(st_p1, at_p6);
                                let ih_pe = crate::check::types::head_sigil(st_p1, &inner_pd);
                                let acc2_pf = {
                                    let mut this: Peeled = acc_p2.clone();
                                    if &head_pc == &Text::lit("!") {
                                        this.events = push(&this.events, &span_p9);
                                    } else {
                                        this.dyns = push(&this.dyns, &span_p9);
                                    }
                                    if &this.lifted == &Text::lit("") {
                                        this.lifted = crate::check::expr::src_text(env_p0, &span_p9);
                                    }
                                    this
                                };
                                if crate::check::expr::is_time_sigil(&ih_pe) {
                                    {
                                        let what_pg = if &ih_pe == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") };
                                        (acc2_pf.clone(), crate::check::types::recording::err_fix(st_p1, &Text::lit("two-layers"), &span_p9, &Text::from(format!("`{}` over a {} of {}s", fname_p3, &(if &head_pc == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &what_pg)), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))
                                    }
                                } else {
                                    if crate::check::expr::is_plain_sigil(&ih_pe) && !*cmp_p4 {
                                        {
                                            let inner2_ph = crate::check::expr::inner_of(st_p1, &inner_pd);
                                            if crate::check::expr::is_time_sigil(&crate::check::types::head_sigil(st_p1, &inner2_ph)) || (&crate::check::types::head_sigil(st_p1, &inner2_ph) == &Text::lit("@")) {
                                                (acc2_pf.clone(), crate::check::types::recording::err(st_p1, &Text::lit("layer-under-optional"), &span_p9, &Text::from(format!("`{}` over an optional {}dynamic", fname_p3, &(if &ih_pe == &Text::lit("?") { Text::lit("") } else { Text::lit("fault ") })))))
                                            } else {
                                                {
                                                    let acc3_pi = {
                                                        let mut this: Peeled = acc2_pf.clone();
                                                        this.opts = crate::check::types::add_text(&this.opts, &ih_pe);
                                                        this.opt_args = push(&this.opt_args, &span_p9);
                                                        this
                                                    };
                                                    (acc3_pi.clone(), crate::check::types::unify::unify(st_p1, &p_p8, &inner2_ph, &span_p9))
                                                }
                                            }
                                        }
                                    } else {
                                        (acc2_pf.clone(), crate::check::types::unify::unify(st_p1, &p_p8, &inner_pd, &span_p9))
                                    }
                                }
                            }
                        } else {
                            if crate::check::expr::is_plain_sigil(&head_pc) && !*cmp_p4 {
                                {
                                    let inner_pj = crate::check::expr::inner_of(st_p1, at_p6);
                                    let ih_pk = crate::check::types::head_sigil(st_p1, &inner_pj);
                                    if crate::check::expr::is_time_sigil(&ih_pk) || (&ih_pk == &Text::lit("@")) {
                                        (acc_p2.clone(), crate::check::types::recording::err_fix(st_p1, &Text::lit("layer-under-optional"), &span_p9, &Text::from(format!("`{}` over an optional dynamic", fname_p3)), &Text::lit("match the optional once, at build time, to find out whether there is a dynamic")))
                                    } else {
                                        {
                                            let acc2_pl = {
                                                let mut this: Peeled = acc_p2.clone();
                                                this.opts = crate::check::types::add_text(&this.opts, &head_pc);
                                                this.opt_args = push(&this.opt_args, &span_p9);
                                                this
                                            };
                                            (acc2_pl.clone(), crate::check::types::unify::unify(st_p1, &p_p8, &inner_pj, &span_p9))
                                        }
                                    }
                                }
                            } else {
                                if &head_pc == &Text::lit("&") {
                                    (acc_p2.clone(), crate::check::types::unify::unify(st_p1, &p_p8, &crate::check::expr::inner_of(st_p1, at_p6), &span_p9))
                                } else {
                                    (acc_p2.clone(), crate::check::types::unify::unify(st_p1, &p_p8, at_p6, &span_p9))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `LayeredArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub struct LayeredArg {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub acc_p2: Peeled,
    pub fname_p3: Text,
    pub cmp_p4: bool,
    pub param_p5: crate::check::types::Ty,
    pub at_p6: crate::check::types::Ty,
    pub a_p7: crate::syntax::Arg,
}

impl prism_rtl::Job<(Peeled, crate::check::types::St)> for LayeredArg {
    fn cycle(&self) -> prism_rtl::Turn<(Peeled, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let acc_p2 = &self.acc_p2;
        let fname_p3 = &self.fname_p3;
        let cmp_p4 = &self.cmp_p4;
        let param_p5 = &self.param_p5;
        let at_p6 = &self.at_p6;
        let a_p7 = &self.a_p7;
        let a_p7 = a_p7.clone();
        let acc_p2 = acc_p2.clone();
        let at_p6 = at_p6.clone();
        let cmp_p4 = *cmp_p4;
        let env_p0 = env_p0.clone();
        let fname_p3 = fname_p3.clone();
        let param_p5 = param_p5.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p1.clone(), param_p5.clone()), move |walk_17883: crate::check::types::Ty| {
            let p_p8 = walk_17883;
            let span_p9 = a_p7.value.span.clone();
            call_then(crate::check::types::start_head_sigil(st_p1.clone(), p_p8.clone()), move |head_sigil_17939: Text| {
                let ph_pa = head_sigil_17939;
                call_then(crate::check::types::start_is_free_headed(st_p1.clone(), at_p6.clone()), move |is_free_headed_17962: bool| if is_free_headed_17962 {
                    {
                        let st2_pb = if ((crate::check::expr::is_time_sigil(&ph_pa) || (&ph_pa == &Text::lit("@"))) || (&ph_pa == &Text::lit("&"))) || cmp_p4 {
                            st_p1.clone()
                        } else {
                            crate::check::types::unify::ask_layer(&st_p1, &at_p6, &span_p9, &fname_p3)
                        };
                        call_then(crate::check::types::unify::start_unify(st2_pb.clone(), p_p8.clone(), at_p6.clone(), span_p9.clone()), move |unify_18109: crate::check::types::St| prism_rtl::Turn::Finished((acc_p2.clone(), unify_18109)))
                    }
                } else {
                    if (crate::check::expr::is_time_sigil(&ph_pa) || (&ph_pa == &Text::lit("@"))) || (&ph_pa == &Text::lit("&")) {
                        call_then(crate::check::types::unify::start_unify(st_p1.clone(), p_p8.clone(), at_p6.clone(), span_p9.clone()), move |unify_18200: crate::check::types::St| prism_rtl::Turn::Finished((acc_p2.clone(), unify_18200)))
                    } else {
                        if crate::check::expr::is_plain_sigil(&ph_pa) {
                            prism_rtl::Turn::More(Rc::new(PeelTimeOnly { env_p0: env_p0.clone(), st_p1: st_p1.clone(), acc_p2: acc_p2.clone(), fname_p3: fname_p3.clone(), p_p4: p_p8.clone(), at_p5: at_p6.clone(), a_p6: a_p7.clone() }))
                        } else {
                            call_then(crate::check::types::start_head_sigil(st_p1.clone(), at_p6.clone()), move |head_sigil_18327: Text| {
                                let head_pc = head_sigil_18327;
                                if &head_pc == &Text::lit("@") {
                                    prism_rtl::Turn::Finished((acc_p2.clone(), crate::check::types::recording::err_fix(&st_p1, &Text::lit("blueprint-operand"), &span_p9, &Text::from(format!("`{}` over a blueprint; bind it first", &fname_p3)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text(&env_p0, &span_p9))))))
                                } else {
                                    if crate::check::expr::is_time_sigil(&head_pc) {
                                        call_then(crate::check::expr::start_inner_of(st_p1.clone(), at_p6.clone()), move |inner_of_18572: crate::check::types::Ty| {
                                            let inner_pd = inner_of_18572;
                                            call_then(crate::check::types::start_head_sigil(st_p1.clone(), inner_pd.clone()), move |head_sigil_18608: Text| {
                                                let ih_pe = head_sigil_18608;
                                                let acc2_pf = {
                                                    let mut this: Peeled = acc_p2.clone();
                                                    if &head_pc == &Text::lit("!") {
                                                        this.events = push(&this.events, &span_p9);
                                                    } else {
                                                        this.dyns = push(&this.dyns, &span_p9);
                                                    }
                                                    if &this.lifted == &Text::lit("") {
                                                        this.lifted = crate::check::expr::src_text(&env_p0, &span_p9);
                                                    }
                                                    this
                                                };
                                                if crate::check::expr::is_time_sigil(&ih_pe) {
                                                    {
                                                        let what_pg = if &ih_pe == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") };
                                                        prism_rtl::Turn::Finished((acc2_pf.clone(), crate::check::types::recording::err_fix(&st_p1, &Text::lit("two-layers"), &span_p9, &Text::from(format!("`{}` over a {} of {}s", &fname_p3, &(if &head_pc == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &what_pg)), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))))
                                                    }
                                                } else {
                                                    if crate::check::expr::is_plain_sigil(&ih_pe) && !cmp_p4 {
                                                        call_then(crate::check::expr::start_inner_of(st_p1.clone(), inner_pd.clone()), move |inner_of_19284: crate::check::types::Ty| {
                                                            let inner2_ph = inner_of_19284;
                                                            call_then(crate::check::types::start_head_sigil(st_p1.clone(), inner2_ph.clone()), move |head_sigil_19335: Text| if crate::check::expr::is_time_sigil(&head_sigil_19335) || (&crate::check::types::head_sigil(&st_p1, &inner2_ph) == &Text::lit("@")) {
                                                                prism_rtl::Turn::Finished((acc2_pf.clone(), crate::check::types::recording::err(&st_p1, &Text::lit("layer-under-optional"), &span_p9, &Text::from(format!("`{}` over an optional {}dynamic", &fname_p3, &(if &ih_pe == &Text::lit("?") { Text::lit("") } else { Text::lit("fault ") }))))))
                                                            } else {
                                                                {
                                                                    let acc3_pi = {
                                                                        let mut this: Peeled = acc2_pf.clone();
                                                                        this.opts = crate::check::types::add_text(&this.opts, &ih_pe);
                                                                        this.opt_args = push(&this.opt_args, &span_p9);
                                                                        this
                                                                    };
                                                                    call_then(crate::check::types::unify::start_unify(st_p1.clone(), p_p8.clone(), inner2_ph.clone(), span_p9.clone()), move |unify_19742: crate::check::types::St| prism_rtl::Turn::Finished((acc3_pi.clone(), unify_19742)))
                                                                }
                                                            })
                                                        })
                                                    } else {
                                                        call_then(crate::check::types::unify::start_unify(st_p1.clone(), p_p8.clone(), inner_pd.clone(), span_p9.clone()), move |unify_19798: crate::check::types::St| prism_rtl::Turn::Finished((acc2_pf.clone(), unify_19798)))
                                                    }
                                                }
                                            })
                                        })
                                    } else {
                                        if crate::check::expr::is_plain_sigil(&head_pc) && !cmp_p4 {
                                            call_then(crate::check::expr::start_inner_of(st_p1.clone(), at_p6.clone()), move |inner_of_19900: crate::check::types::Ty| {
                                                let inner_pj = inner_of_19900;
                                                call_then(crate::check::types::start_head_sigil(st_p1.clone(), inner_pj.clone()), move |head_sigil_19936: Text| {
                                                    let ih_pk = head_sigil_19936;
                                                    if crate::check::expr::is_time_sigil(&ih_pk) || (&ih_pk == &Text::lit("@")) {
                                                        prism_rtl::Turn::Finished((acc_p2.clone(), crate::check::types::recording::err_fix(&st_p1, &Text::lit("layer-under-optional"), &span_p9, &Text::from(format!("`{}` over an optional dynamic", &fname_p3)), &Text::lit("match the optional once, at build time, to find out whether there is a dynamic"))))
                                                    } else {
                                                        {
                                                            let acc2_pl = {
                                                                let mut this: Peeled = acc_p2.clone();
                                                                this.opts = crate::check::types::add_text(&this.opts, &head_pc);
                                                                this.opt_args = push(&this.opt_args, &span_p9);
                                                                this
                                                            };
                                                            call_then(crate::check::types::unify::start_unify(st_p1.clone(), p_p8.clone(), inner_pj.clone(), span_p9.clone()), move |unify_20380: crate::check::types::St| prism_rtl::Turn::Finished((acc2_pl.clone(), unify_20380)))
                                                        }
                                                    }
                                                })
                                            })
                                        } else {
                                            if &head_pc == &Text::lit("&") {
                                                call_then(crate::check::expr::start_inner_of(st_p1.clone(), at_p6.clone()), move |inner_of_20460: crate::check::types::Ty| call_then(crate::check::types::unify::start_unify(st_p1.clone(), p_p8.clone(), inner_of_20460, span_p9.clone()), move |unify_20446: crate::check::types::St| prism_rtl::Turn::Finished((acc_p2.clone(), unify_20446))))
                                            } else {
                                                call_then(crate::check::types::unify::start_unify(st_p1.clone(), p_p8.clone(), at_p6.clone(), span_p9.clone()), move |unify_20507: crate::check::types::St| prism_rtl::Turn::Finished((acc_p2.clone(), unify_20507)))
                                            }
                                        }
                                    }
                                }
                            })
                        }
                    }
                })
            })
        })
    }
}

/// `Start LayeredArg, x`: what the function value is when passed to `@Run`.
pub fn start_layered_arg(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, acc_p2: Peeled, fname_p3: Text, cmp_p4: bool, param_p5: crate::check::types::Ty, at_p6: crate::check::types::Ty, a_p7: crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check::types::St)>> {
    Rc::new(LayeredArg { env_p0, st_p1, acc_p2, fname_p3, cmp_p4, param_p5, at_p6, a_p7 })
}

/// ```prism
/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub fn peel_time_only(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, acc_p2: &Peeled, fname_p3: &Text, p_p4: &crate::check::types::Ty, at_p5: &crate::check::types::Ty, a_p6: &crate::syntax::Arg) -> (Peeled, crate::check::types::St) {
    let span_p7 = a_p6.value.span.clone();
    let head_p8 = crate::check::types::head_sigil(st_p1, at_p5);
    if &head_p8 == &Text::lit("@") {
        (acc_p2.clone(), crate::check::types::recording::err_fix(st_p1, &Text::lit("blueprint-operand"), &span_p7, &Text::from(format!("`{}` over a blueprint; bind it first", fname_p3)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text(env_p0, &span_p7)))))
    } else {
        if crate::check::expr::is_time_sigil(&head_p8) {
            {
                let inner_p9 = crate::check::expr::inner_of(st_p1, at_p5);
                let acc2_pa = {
                    let mut this: Peeled = acc_p2.clone();
                    if &head_p8 == &Text::lit("!") {
                        this.events = push(&this.events, &span_p7);
                    } else {
                        this.dyns = push(&this.dyns, &span_p7);
                    }
                    if &this.lifted == &Text::lit("") {
                        this.lifted = crate::check::expr::src_text(env_p0, &span_p7);
                    }
                    this
                };
                if crate::check::expr::is_time_sigil(&crate::check::types::head_sigil(st_p1, &inner_p9)) {
                    (acc2_pa.clone(), crate::check::types::recording::err_fix(st_p1, &Text::lit("two-layers"), &span_p7, &Text::from(format!("`{}` over a {} of {}s", fname_p3, &(if &head_p8 == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &(if &crate::check::types::head_sigil(st_p1, &inner_p9) == &Text::lit("$") {
                        Text::lit("dynamic")
                    } else {
                        Text::lit("event")
                    }))), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))
                } else {
                    (acc2_pa.clone(), crate::check::types::unify::unify(st_p1, p_p4, &inner_p9, &span_p7))
                }
            }
        } else {
            (acc_p2.clone(), crate::check::types::unify::unify(st_p1, p_p4, at_p5, &span_p7))
        }
    }
}

/// The step machine of `PeelTimeOnly`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub struct PeelTimeOnly {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub acc_p2: Peeled,
    pub fname_p3: Text,
    pub p_p4: crate::check::types::Ty,
    pub at_p5: crate::check::types::Ty,
    pub a_p6: crate::syntax::Arg,
}

impl prism_rtl::Job<(Peeled, crate::check::types::St)> for PeelTimeOnly {
    fn cycle(&self) -> prism_rtl::Turn<(Peeled, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let acc_p2 = &self.acc_p2;
        let fname_p3 = &self.fname_p3;
        let p_p4 = &self.p_p4;
        let at_p5 = &self.at_p5;
        let a_p6 = &self.a_p6;
        let span_p7 = a_p6.value.span.clone();
        let a_p6 = a_p6.clone();
        let acc_p2 = acc_p2.clone();
        let at_p5 = at_p5.clone();
        let env_p0 = env_p0.clone();
        let fname_p3 = fname_p3.clone();
        let p_p4 = p_p4.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::types::start_head_sigil(st_p1.clone(), at_p5.clone()), move |head_sigil_20793: Text| {
            let head_p8 = head_sigil_20793;
            if &head_p8 == &Text::lit("@") {
                prism_rtl::Turn::Finished((acc_p2.clone(), crate::check::types::recording::err_fix(&st_p1, &Text::lit("blueprint-operand"), &span_p7, &Text::from(format!("`{}` over a blueprint; bind it first", &fname_p3)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &crate::check::expr::src_text(&env_p0, &span_p7))))))
            } else {
                if crate::check::expr::is_time_sigil(&head_p8) {
                    call_then(crate::check::expr::start_inner_of(st_p1.clone(), at_p5.clone()), move |inner_of_21026: crate::check::types::Ty| {
                        let inner_p9 = inner_of_21026;
                        let acc2_pa = {
                            let mut this: Peeled = acc_p2.clone();
                            if &head_p8 == &Text::lit("!") {
                                this.events = push(&this.events, &span_p7);
                            } else {
                                this.dyns = push(&this.dyns, &span_p7);
                            }
                            if &this.lifted == &Text::lit("") {
                                this.lifted = crate::check::expr::src_text(&env_p0, &span_p7);
                            }
                            this
                        };
                        call_then(crate::check::types::start_head_sigil(st_p1.clone(), inner_p9.clone()), move |head_sigil_21317: Text| if crate::check::expr::is_time_sigil(&head_sigil_21317) {
                            call_then(crate::check::types::start_head_sigil(st_p1.clone(), inner_p9.clone()), move |head_sigil_21447: Text| prism_rtl::Turn::Finished((acc2_pa.clone(), crate::check::types::recording::err_fix(&st_p1, &Text::lit("two-layers"), &span_p7, &Text::from(format!("`{}` over a {} of {}s", &fname_p3, &(if &head_p8 == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &(if &head_sigil_21447 == &Text::lit("$") {
                                Text::lit("dynamic")
                            } else {
                                Text::lit("event")
                            }))), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))))
                        } else {
                            call_then(crate::check::types::unify::start_unify(st_p1.clone(), p_p4.clone(), inner_p9.clone(), span_p7.clone()), move |unify_21597: crate::check::types::St| prism_rtl::Turn::Finished((acc2_pa.clone(), unify_21597)))
                        })
                    })
                } else {
                    call_then(crate::check::types::unify::start_unify(st_p1.clone(), p_p4.clone(), at_p5.clone(), span_p7.clone()), move |unify_21643: crate::check::types::St| prism_rtl::Turn::Finished((acc_p2.clone(), unify_21643)))
                }
            }
        })
    }
}

/// `Start PeelTimeOnly, x`: what the function value is when passed to `@Run`.
pub fn start_peel_time_only(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, acc_p2: Peeled, fname_p3: Text, p_p4: crate::check::types::Ty, at_p5: crate::check::types::Ty, a_p6: crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check::types::St)>> {
    Rc::new(PeelTimeOnly { env_p0, st_p1, acc_p2, fname_p3, p_p4, at_p5, a_p6 })
}

/// ```prism
/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
/// ```
pub fn ctor_app(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::check::env::CtorInfo, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range, cspan_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (self_p9, st0_pa, inst_pb) = crate::check::types::schemes::instantiate_with(st_p1, &crate::check::types::Scheme { qs: c_p2.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c_p2.ty.clone() }, span_p4, &Array::new());
    let field_tys_p6 = run_to_end(each_job(c_p2.args.clone(), {
        let inst_pb = inst_pb.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let inst_pb = inst_pb.clone();
            entered(once_job(move || {
                let t_pc = p0;
                prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: inst_pb.clone(), t_p1: t_pc.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
    }));
    let st1_p7 = crate::check::types::recording::note_ty(&st0_pa, cspan_p5, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_p6.clone(), Rc::new(self_p9.clone())));
    let named_p8 = filter(args_p3, &(|a_pd: &crate::syntax::Arg| &a_pd.name != &None));
    if (&len(&named_p8) > &Nat::from(0u32)) && (&len(&c_p2.fields) > &Nat::from(0u32)) {
        {
            let st2_pe = run_to_end(fold_job(named_p8.clone(), st1_p7.clone(), {
                let c_p2 = c_p2.clone();
                let env_p0 = env_p0.clone();
                let field_tys_p6 = field_tys_p6.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arg)| {
                    let c_p2 = c_p2.clone();
                    let env_p0 = env_p0.clone();
                    let field_tys_p6 = field_tys_p6.clone();
                    entered(once_job(move || {
                        let s_ph = p0;
                        let a_pi = p1;
                        match &a_pi.name {
                            Some(id_pj) => match crate::check::expr::operators::index_of(&c_p2.fields, &id_pj.name) {
                                Some(i_pk) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env_p0: env_p0.clone(), st_p1: s_ph.clone(), e_p2: a_pi.value.clone(), expected_p3: or(&index(&field_tys_p6, &i_pk), &crate::check::types::Ty::TyErr) })),
                                None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s_ph, &Text::lit("mismatch"), &a_pi.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&c_p2.owner), &id_pj.name)))),
                            },
                            None => prism_rtl::Turn::Finished(s_ph.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }));
            let missing_pf = filter(&c_p2.fields, &(|f_pl: &Text| !fold(&named_p8, &false, &(|seen_pm: &bool, a_pn: &crate::syntax::Arg| *seen_pm || arg_named(a_pn, f_pl)))));
            let st3_pg = if &len(&missing_pf) > &Nat::from(0u32) {
                crate::check::types::recording::err(&st2_pe, &Text::lit("mismatch"), span_p4, &Text::from(format!("`{}` needs {}", &crate::check::types::bare_name(&c_p2.owner), &crate::syntax::lexer::chars::join(&each(&missing_pf, &(|f_po: &Text| Text::from(format!("`{}`", f_po)))), &Text::lit(", ")))))
            } else {
                st2_pe.clone()
            };
            (self_p9.clone(), st3_pg.clone())
        }
    } else {
        if &len(args_p3) != &len(&field_tys_p6) {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st1_p7, &Text::lit("mismatch"), span_p4, &Text::from(format!("`{}` takes {} argument{}; here it has {}", &crate::check::types::bare_name(&c_p2.name), &crate::check::errors::count_word(&len(&field_tys_p6)), &(if &len(&field_tys_p6) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(args_p3))))))
        } else {
            {
                let st2_pp = run_to_end(fold_job(crate::check::errors::range0(&len(args_p3)), st1_p7.clone(), {
                    let args_p3 = args_p3.clone();
                    let env_p0 = env_p0.clone();
                    let field_tys_p6 = field_tys_p6.clone();
                    Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                        let args_p3 = args_p3.clone();
                        let env_p0 = env_p0.clone();
                        let field_tys_p6 = field_tys_p6.clone();
                        entered(once_job(move || {
                            let s_pq = p0;
                            let i_pr = p1;
                            match index(&args_p3, &i_pr) {
                                Some(a_ps) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env_p0: env_p0.clone(), st_p1: s_pq.clone(), e_p2: a_ps.value.clone(), expected_p3: or(&index(&field_tys_p6, &i_pr), &crate::check::types::Ty::TyErr) })),
                                None => prism_rtl::Turn::Finished(s_pq.clone()),
                            }
                        }))
                    }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                }));
                (self_p9.clone(), st2_pp.clone())
            }
        }
    }
}

/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
/// ```
pub struct CtorApp {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::check::env::CtorInfo,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
    pub cspan_p5: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for CtorApp {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let cspan_p5 = &self.cspan_p5;
        let args_p3 = args_p3.clone();
        let c_p2 = c_p2.clone();
        let cspan_p5 = cspan_p5.clone();
        let env_p0 = env_p0.clone();
        let span_p4 = span_p4.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::types::schemes::start_instantiate_with(st_p1.clone(), crate::check::types::Scheme { qs: c_p2.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c_p2.ty.clone() }, span_p4.clone(), Array::new()), move |instantiate_with_21905: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
            let (self_p9, st0_pa, inst_pb) = instantiate_with_21905;
            call_value(each_job(c_p2.args.clone(), {
                let inst_pb = inst_pb.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let inst_pb = inst_pb.clone();
                    entered(once_job(move || {
                        let t_pc = p0;
                        prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: inst_pb.clone(), t_p1: t_pc.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_22047: Array<crate::check::types::Ty>| {
                let field_tys_p6 = each_22047;
                let st1_p7 = crate::check::types::recording::note_ty(&st0_pa, &cspan_p5, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_p6.clone(), Rc::new(self_p9.clone())));
                let named_p8 = filter(&args_p3, &(|a_pd: &crate::syntax::Arg| &a_pd.name != &None));
                if (&len(&named_p8) > &Nat::from(0u32)) && (&len(&c_p2.fields) > &Nat::from(0u32)) {
                    call_value(fold_job(named_p8.clone(), st1_p7.clone(), {
                        let c_p2 = c_p2.clone();
                        let env_p0 = env_p0.clone();
                        let field_tys_p6 = field_tys_p6.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arg)| {
                            let c_p2 = c_p2.clone();
                            let env_p0 = env_p0.clone();
                            let field_tys_p6 = field_tys_p6.clone();
                            entered(once_job(move || {
                                let s_ph = p0;
                                let a_pi = p1;
                                match &a_pi.name {
                                    Some(id_pj) => match crate::check::expr::operators::index_of(&c_p2.fields, &id_pj.name) {
                                        Some(i_pk) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env_p0: env_p0.clone(), st_p1: s_ph.clone(), e_p2: a_pi.value.clone(), expected_p3: or(&index(&field_tys_p6, &i_pk), &crate::check::types::Ty::TyErr) })),
                                        None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s_ph, &Text::lit("mismatch"), &a_pi.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&c_p2.owner), &id_pj.name)))),
                                    },
                                    None => prism_rtl::Turn::Finished(s_ph.clone()),
                                }
                            }))
                        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_22257: crate::check::types::St| {
                        let st2_pe = fold_22257;
                        let missing_pf = filter(&c_p2.fields, &(|f_pl: &Text| !fold(&named_p8, &false, &(|seen_pm: &bool, a_pn: &crate::syntax::Arg| *seen_pm || arg_named(a_pn, f_pl)))));
                        let st3_pg = if &len(&missing_pf) > &Nat::from(0u32) {
                            crate::check::types::recording::err(&st2_pe, &Text::lit("mismatch"), &span_p4, &Text::from(format!("`{}` needs {}", &crate::check::types::bare_name(&c_p2.owner), &crate::syntax::lexer::chars::join(&each(&missing_pf, &(|f_po: &Text| Text::from(format!("`{}`", f_po)))), &Text::lit(", ")))))
                        } else {
                            st2_pe.clone()
                        };
                        prism_rtl::Turn::Finished((self_p9.clone(), st3_pg.clone()))
                    })
                } else {
                    if &len(&args_p3) != &len(&field_tys_p6) {
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st1_p7, &Text::lit("mismatch"), &span_p4, &Text::from(format!("`{}` takes {} argument{}; here it has {}", &crate::check::types::bare_name(&c_p2.name), &crate::check::errors::count_word(&len(&field_tys_p6)), &(if &len(&field_tys_p6) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(&args_p3)))))))
                    } else {
                        call_value(fold_job(crate::check::errors::range0(&len(&args_p3)), st1_p7.clone(), {
                            let args_p3 = args_p3.clone();
                            let env_p0 = env_p0.clone();
                            let field_tys_p6 = field_tys_p6.clone();
                            Rc::new(move |(p0, p1): (crate::check::types::St, Nat)| {
                                let args_p3 = args_p3.clone();
                                let env_p0 = env_p0.clone();
                                let field_tys_p6 = field_tys_p6.clone();
                                entered(once_job(move || {
                                    let s_pq = p0;
                                    let i_pr = p1;
                                    match index(&args_p3, &i_pr) {
                                        Some(a_ps) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env_p0: env_p0.clone(), st_p1: s_pq.clone(), e_p2: a_ps.value.clone(), expected_p3: or(&index(&field_tys_p6, &i_pr), &crate::check::types::Ty::TyErr) })),
                                        None => prism_rtl::Turn::Finished(s_pq.clone()),
                                    }
                                }))
                            }) as Rc<dyn Fn((crate::check::types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                        }), move |fold_23063: crate::check::types::St| {
                            let st2_pp = fold_23063;
                            prism_rtl::Turn::Finished((self_p9.clone(), st2_pp.clone()))
                        })
                    }
                }
            })
        })
    }
}

/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_app(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, c_p2: crate::check::env::CtorInfo, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range, cspan_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(CtorApp { env_p0, st_p1, c_p2, args_p3, span_p4, cspan_p5 })
}

/// ```prism
/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
/// ```
pub fn tag_app(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, name_p2: &Text, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range, cspan_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match get(&env_p0.g.tags, name_p2) {
        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), span_p4, &Text::from(format!("no tag `{}`", name_p2)))),
        Some(tg_p6) => {
            let (out_pb, st1_pc, inst_pd) = crate::check::types::schemes::instantiate_with(st_p1, &crate::check::types::Scheme { qs: tg_p6.qs.clone(), plain_qs: Array::new(), rqs: tg_p6.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: tg_p6.bounds.clone(), ty: tg_p6.out.clone() }, span_p4, &Array::new());
            let st2_p7 = run_to_end(fold_job(args_p3.clone(), st1_pc.clone(), {
                let tg_p6 = tg_p6.clone();
                let env_p0 = env_p0.clone();
                let name_p2 = name_p2.clone();
                let inst_pd = inst_pd.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arg)| {
                    let tg_p6 = tg_p6.clone();
                    let env_p0 = env_p0.clone();
                    let name_p2 = name_p2.clone();
                    let inst_pd = inst_pd.clone();
                    entered(once_job(move || {
                        let s_pe = p0;
                        let a_pf = p1;
                        match &a_pf.name {
                            Some(id_pg) => match field_of_tag(&tg_p6, &id_pg.name) {
                                Some(ft_ph) => {
                                    let id_pg = id_pg.clone();
                                    call_then(crate::check::types::schemes::start_subst_q(inst_pd.clone(), ft_ph.clone()), move |subst_q_24017: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(TagField { env_p0: env_p0.clone(), st_p1: s_pe.clone(), tag_name_p2: name_p2.clone(), field_p3: id_pg.name.clone(), ft_p4: subst_q_24017, a_p5: a_pf.clone() })))
                                },
                                None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s_pe, &Text::lit("mismatch"), &a_pf.span, &Text::from(format!("`{}` has no field `{}`", &name_p2, &id_pg.name)))),
                            },
                            None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s_pe, &Text::lit("mismatch"), &a_pf.span, &Text::from(format!("a tag\'s fields are named: `{}(field=...)`", &name_p2)))),
                        }
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }));
            let missing_p8 = filter(&tg_p6.fields, &(|(f_pi, _): &(Text, crate::check::types::Ty)| !fold(args_p3, &false, &(|seen_pj: &bool, a_pk: &crate::syntax::Arg| *seen_pj || arg_named(a_pk, f_pi)))));
            let st3_p9 = if (&len(&missing_p8) > &Nat::from(0u32)) && !fold(args_p3, &false, &(|seen_pl: &bool, a_pm: &crate::syntax::Arg| *seen_pl || (&*a_pm.value.kind == &crate::syntax::ExprKind::ERest))) {
                crate::check::types::recording::err(&st2_p7, &Text::lit("mismatch"), span_p4, &Text::from(format!("`{}` needs {}", name_p2, &crate::syntax::lexer::chars::join(&each(&missing_p8, &(|(f_pn, _): &(Text, crate::check::types::Ty)| Text::from(format!("`{}`", f_pn)))), &Text::lit(", ")))))
            } else {
                st2_p7.clone()
            };
            let field_tys_pa = run_to_end(each_job(tg_p6.fields.clone(), {
                let inst_pd = inst_pd.clone();
                Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                    let inst_pd = inst_pd.clone();
                    entered(once_job(move || {
                        let (_, ft_po) = p0;
                        prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: inst_pd.clone(), t_p1: ft_po.clone() }))
                    }))
                }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }));
            if &tg_p6.kind == &Text::lit("Element") {
                {
                    let (rw_pq, st4_pr) = crate::check::types::recording::fresh_row(&st3_p9, &Array::from(vec![tg_p6.family.clone()]));
                    let et_pp = crate::check::types::Ty::TyElem(crate::check::types::Rw { fams: Array::from(vec![tg_p6.family.clone()]), minus: Array::new(), tail: rw_pq.tail.clone() }, Rc::new(out_pb.clone()));
                    (et_pp.clone(), crate::check::types::recording::note_ty(&st4_pr, cspan_p5, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_pa.clone(), Rc::new(et_pp.clone()))))
                }
            } else {
                (crate::check::types::Ty::TyCon(tg_p6.kind.clone(), Array::new()), crate::check::types::recording::note_ty(&st3_p9, cspan_p5, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_pa.clone(), Rc::new(crate::check::types::Ty::TyCon(tg_p6.kind.clone(), Array::new())))))
            }
        },
    }
}

/// The step machine of `TagApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
/// ```
pub struct TagApp {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub name_p2: Text,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
    pub cspan_p5: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for TagApp {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let name_p2 = &self.name_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let cspan_p5 = &self.cspan_p5;
        match get(&env_p0.g.tags, name_p2) {
            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), span_p4, &Text::from(format!("no tag `{}`", name_p2))))),
            Some(tg_p6) => {
                let args_p3 = args_p3.clone();
                let cspan_p5 = cspan_p5.clone();
                let env_p0 = env_p0.clone();
                let name_p2 = name_p2.clone();
                let span_p4 = span_p4.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::types::schemes::start_instantiate_with(st_p1.clone(), crate::check::types::Scheme { qs: tg_p6.qs.clone(), plain_qs: Array::new(), rqs: tg_p6.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: tg_p6.bounds.clone(), ty: tg_p6.out.clone() }, span_p4.clone(), Array::new()), move |instantiate_with_23727: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                    let (out_pb, st1_pc, inst_pd) = instantiate_with_23727;
                    call_value(fold_job(args_p3.clone(), st1_pc.clone(), {
                        let tg_p6 = tg_p6.clone();
                        let env_p0 = env_p0.clone();
                        let name_p2 = name_p2.clone();
                        let inst_pd = inst_pd.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arg)| {
                            let tg_p6 = tg_p6.clone();
                            let env_p0 = env_p0.clone();
                            let name_p2 = name_p2.clone();
                            let inst_pd = inst_pd.clone();
                            entered(once_job(move || {
                                let s_pe = p0;
                                let a_pf = p1;
                                match &a_pf.name {
                                    Some(id_pg) => match field_of_tag(&tg_p6, &id_pg.name) {
                                        Some(ft_ph) => {
                                            let id_pg = id_pg.clone();
                                            call_then(crate::check::types::schemes::start_subst_q(inst_pd.clone(), ft_ph.clone()), move |subst_q_24017: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(TagField { env_p0: env_p0.clone(), st_p1: s_pe.clone(), tag_name_p2: name_p2.clone(), field_p3: id_pg.name.clone(), ft_p4: subst_q_24017, a_p5: a_pf.clone() })))
                                        },
                                        None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s_pe, &Text::lit("mismatch"), &a_pf.span, &Text::from(format!("`{}` has no field `{}`", &name_p2, &id_pg.name)))),
                                    },
                                    None => prism_rtl::Turn::Finished(crate::check::types::recording::err(&s_pe, &Text::lit("mismatch"), &a_pf.span, &Text::from(format!("a tag\'s fields are named: `{}(field=...)`", &name_p2)))),
                                }
                            }))
                        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_23874: crate::check::types::St| {
                        let st2_p7 = fold_23874;
                        let missing_p8 = filter(&tg_p6.fields, &(|(f_pi, _): &(Text, crate::check::types::Ty)| !fold(&args_p3, &false, &(|seen_pj: &bool, a_pk: &crate::syntax::Arg| *seen_pj || arg_named(a_pk, f_pi)))));
                        let st3_p9 = if (&len(&missing_p8) > &Nat::from(0u32)) && !fold(&args_p3, &false, &(|seen_pl: &bool, a_pm: &crate::syntax::Arg| *seen_pl || (&*a_pm.value.kind == &crate::syntax::ExprKind::ERest))) {
                            crate::check::types::recording::err(&st2_p7, &Text::lit("mismatch"), &span_p4, &Text::from(format!("`{}` needs {}", &name_p2, &crate::syntax::lexer::chars::join(&each(&missing_p8, &(|(f_pn, _): &(Text, crate::check::types::Ty)| Text::from(format!("`{}`", f_pn)))), &Text::lit(", ")))))
                        } else {
                            st2_p7.clone()
                        };
                        call_value(each_job(tg_p6.fields.clone(), {
                            let inst_pd = inst_pd.clone();
                            Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                                let inst_pd = inst_pd.clone();
                                entered(once_job(move || {
                                    let (_, ft_po) = p0;
                                    prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::SubstQ { m_p0: inst_pd.clone(), t_p1: ft_po.clone() }))
                                }))
                            }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                        }), move |each_24569: Array<crate::check::types::Ty>| {
                            let field_tys_pa = each_24569;
                            if &tg_p6.kind == &Text::lit("Element") {
                                {
                                    let (rw_pq, st4_pr) = crate::check::types::recording::fresh_row(&st3_p9, &Array::from(vec![tg_p6.family.clone()]));
                                    let et_pp = crate::check::types::Ty::TyElem(crate::check::types::Rw { fams: Array::from(vec![tg_p6.family.clone()]), minus: Array::new(), tail: rw_pq.tail.clone() }, Rc::new(out_pb.clone()));
                                    prism_rtl::Turn::Finished((et_pp.clone(), crate::check::types::recording::note_ty(&st4_pr, &cspan_p5, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_pa.clone(), Rc::new(et_pp.clone())))))
                                }
                            } else {
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(tg_p6.kind.clone(), Array::new()), crate::check::types::recording::note_ty(&st3_p9, &cspan_p5, &crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, field_tys_pa.clone(), Rc::new(crate::check::types::Ty::TyCon(tg_p6.kind.clone(), Array::new()))))))
                            }
                        })
                    })
                })
            },
        }
    }
}

/// `Start TagApp, x`: what the function value is when passed to `@Run`.
pub fn start_tag_app(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, name_p2: Text, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range, cspan_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(TagApp { env_p0, st_p1, name_p2, args_p3, span_p4, cspan_p5 })
}

/// ```prism
/// ?FieldOfTag: fn TagInfo, Text -> ?Ty
/// ```
pub fn field_of_tag(tg_p0: &crate::check::env::TagInfo, f_p1: &Text) -> Option<crate::check::types::Ty> {
    fold(&tg_p0.fields, &None, &(|found_o2: &Option<crate::check::types::Ty>, (n_p3, t_p4): &(Text, crate::check::types::Ty)| match found_o2 {
        Some(x_p5) => Some(x_p5.clone()),
        None => if n_p3 == f_p1 { Some(t_p4.clone()) } else { None },
    }))
}

/// ```prism
/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
/// ```
pub fn tag_field(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, tag_name_p2: &Text, field_p3: &Text, ft_p4: &crate::check::types::Ty, a_p5: &crate::syntax::Arg) -> crate::check::types::St {
    if &crate::check::types::head_sigil(st_p1, ft_p4) != &Text::lit("") {
        crate::check::expr::check(env_p0, st_p1, &a_p5.value, ft_p4)
    } else {
        {
            let (at_p7, st2_p8) = crate::check::expr::infer(env_p0, st_p1, &a_p5.value);
            let head_p6 = crate::check::types::head_sigil(&st2_p8, &at_p7);
            if &head_p6 == &Text::lit("$") {
                crate::check::types::recording::err_fix(&st2_p8, &Text::lit("identity-dynamic"), &a_p5.value.span, &Text::from(format!("a dynamic in the identity field `{}`", field_p3)), &Text::from(format!("for a new element per value, write `rebuild {}:` with `{}({}=_, ...)` inside", &crate::check::expr::src_text(env_p0, &a_p5.value.span), tag_name_p2, field_p3)))
            } else {
                if &head_p6 == &Text::lit("!") {
                    crate::check::types::recording::err(&st2_p8, &Text::lit("two-events"), &a_p5.value.span, &Text::from(format!("an event in the plain field `{}`", field_p3)))
                } else {
                    crate::check::types::unify::unify(&st2_p8, ft_p4, &at_p7, &a_p5.value.span)
                }
            }
        }
    }
}

/// The step machine of `TagField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
/// ```
pub struct TagField {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub tag_name_p2: Text,
    pub field_p3: Text,
    pub ft_p4: crate::check::types::Ty,
    pub a_p5: crate::syntax::Arg,
}

impl prism_rtl::Job<crate::check::types::St> for TagField {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let tag_name_p2 = &self.tag_name_p2;
        let field_p3 = &self.field_p3;
        let ft_p4 = &self.ft_p4;
        let a_p5 = &self.a_p5;
        let a_p5 = a_p5.clone();
        let env_p0 = env_p0.clone();
        let field_p3 = field_p3.clone();
        let ft_p4 = ft_p4.clone();
        let st_p1 = st_p1.clone();
        let tag_name_p2 = tag_name_p2.clone();
        call_then(crate::check::types::start_head_sigil(st_p1.clone(), ft_p4.clone()), move |head_sigil_25385: Text| if &head_sigil_25385 != &Text::lit("") {
            prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: a_p5.value.clone(), expected_p3: ft_p4.clone() }))
        } else {
            call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), a_p5.value.clone()), move |infer_25473: (crate::check::types::Ty, crate::check::types::St)| {
                let (at_p7, st2_p8) = infer_25473;
                call_then(crate::check::types::start_head_sigil(st2_p8.clone(), at_p7.clone()), move |head_sigil_25515: Text| {
                    let head_p6 = head_sigil_25515;
                    if &head_p6 == &Text::lit("$") {
                        prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st2_p8, &Text::lit("identity-dynamic"), &a_p5.value.span, &Text::from(format!("a dynamic in the identity field `{}`", &field_p3)), &Text::from(format!("for a new element per value, write `rebuild {}:` with `{}({}=_, ...)` inside", &crate::check::expr::src_text(&env_p0, &a_p5.value.span), &tag_name_p2, &field_p3))))
                    } else {
                        if &head_p6 == &Text::lit("!") {
                            prism_rtl::Turn::Finished(crate::check::types::recording::err(&st2_p8, &Text::lit("two-events"), &a_p5.value.span, &Text::from(format!("an event in the plain field `{}`", &field_p3))))
                        } else {
                            prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st2_p8.clone(), expected_p1: ft_p4.clone(), found_p2: at_p7.clone(), span_p3: a_p5.value.span.clone() }))
                        }
                    }
                })
            })
        })
    }
}

/// `Start TagField, x`: what the function value is when passed to `@Run`.
pub fn start_tag_field(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, tag_name_p2: Text, field_p3: Text, ft_p4: crate::check::types::Ty, a_p5: crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(TagField { env_p0, st_p1, tag_name_p2, field_p3, ft_p4, a_p5 })
}

/// ```prism
/// LambdaArity: fn Expr -> Nat
/// ```
pub fn lambda_arity(e_p0: &crate::syntax::Expr) -> Nat {
    match &*e_p0.kind {
        crate::syntax::ExprKind::ELambda(Some(ps_p1), _) => len(ps_p1),
        crate::syntax::ExprKind::EGroup(x_p2) => lambda_arity(&**x_p2),
        _ => Nat::from(2u32),
    }
}

/// ```prism
/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub fn infer_lambda(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, expected_o3: &Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*e_p2.kind {
        crate::syntax::ExprKind::EGroup(x_p4) => {
            let (t_p5, st2_p6) = infer_lambda(env_p0, st_p1, &**x_p4, expected_o3);
            (t_p5.clone(), crate::check::types::recording::note_ty(&st2_p6, &x_p4.span, &t_p5))
        },
        _ => infer_bare_lambda(env_p0, st_p1, e_p2, expected_o3),
    }
}

/// The step machine of `InferLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub struct InferLambda {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub expected_o3: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferLambda {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let expected_o3 = &self.expected_o3;
        match &*e_p2.kind {
            crate::syntax::ExprKind::EGroup(x_p4) => {
                let expected_o3 = expected_o3.clone();
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                let x_p4 = (**x_p4).clone();
                call_then(start_infer_lambda(env_p0.clone(), st_p1.clone(), x_p4.clone(), expected_o3.clone()), move |infer_lambda_26901: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p5, st2_p6) = infer_lambda_26901;
                    prism_rtl::Turn::Finished((t_p5.clone(), crate::check::types::recording::note_ty(&st2_p6, &x_p4.span, &t_p5)))
                })
            },
            _ => prism_rtl::Turn::More(Rc::new(InferBareLambda { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p2.clone(), expected_o3: expected_o3.clone() })),
        }
    }
}

/// `Start InferLambda, x`: what the function value is when passed to `@Run`.
pub fn start_infer_lambda(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, expected_o3: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferLambda { env_p0, st_p1, e_p2, expected_o3 })
}

/// ```prism
/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub fn infer_bare_lambda(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, expected_o3: &Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    let (params_pg, body_ph) = match &*e_p2.kind {
        crate::syntax::ExprKind::ELambda(Some(ps_pb), b_pc) => (ps_pb.clone(), (**b_pc).clone()),
        crate::syntax::ExprKind::ELambda(None, b_pd) => (Array::from(vec![topic_pat(&e_p2.span)]), (**b_pd).clone()),
        crate::syntax::ExprKind::ETopicField(f_pe) => (Array::from(vec![topic_pat(&e_p2.span)]), crate::syntax::LambdaBody::LbExpr(Rc::new(topic_field_expr(&e_p2.span, f_pe)))),
        crate::syntax::ExprKind::ETopicIndex(x_pf) => (Array::from(vec![topic_pat(&e_p2.span)]), crate::syntax::LambdaBody::LbExpr(Rc::new(topic_index_expr(&e_p2.span, &**x_pf)))),
        _ => (Array::new(), crate::syntax::LambdaBody::LbExpr(Rc::new(e_p2.clone()))),
    };
    let (exp_params_pl, exp_res_om, st0_pn) = match expected_o3 {
        Some(t_pi) => match crate::check::types::recording::walk(st_p1, t_pi) {
            crate::check::types::Ty::TyFn(_, ps_pj, r_pk) => if &len(&ps_pj) == &len(&params_pg) {
                (ps_pj.clone(), Some((*r_pk).clone()), st_p1.clone())
            } else {
                (Array::new(), None, crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &e_p2.span, &Text::from(format!("this lambda takes {} parameter{}; here {} {} wanted", &crate::check::errors::count_word(&len(&params_pg)), &(if &len(&params_pg) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(&ps_pj)), &(if &len(&ps_pj) == &Nat::from(1u32) { Text::lit("is") } else { Text::lit("are") })))))
            },
            _ => (Array::new(), None, st_p1.clone()),
        },
        None => (Array::new(), None, st_p1.clone()),
    };
    let (env2_p12, ptys_p13, st1_p14) = run_to_end(fold_job(crate::check::errors::range0(&len(&params_pg)), (env_p0.clone(), Array::new(), st0_pn.clone()), {
        let params_pg = params_pg.clone();
        let e_p2 = e_p2.clone();
        let exp_params_pl = exp_params_pl.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
            let params_pg = params_pg.clone();
            let e_p2 = e_p2.clone();
            let exp_params_pl = exp_params_pl.clone();
            entered(once_job(move || {
                let (en_po, acc_pp, s_pq) = p0;
                let i_pr = p1;
                {
                    let p_ps = or(&index(&params_pg, &i_pr), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: e_p2.span.clone() });
                    let (pt_pu, s2_pv) = match index(&exp_params_pl, &i_pr) {
                        Some(t_pt) => (t_pt, s_pq.clone()),
                        None => crate::check::types::fresh_var(&s_pq, &true, &Text::lit("")),
                    };
                    call_then(crate::check::expr::patterns::start_bind_pattern(crate::check::expr::lets::unpend(&en_po), s2_pv.clone(), p_ps.clone(), pt_pu.clone(), false), move |bind_pattern_28243: (crate::check::expr::Env, crate::check::types::St)| {
                        let (en2_p10, s3_p11) = bind_pattern_28243;
                        prism_rtl::Turn::Finished((en2_p10.clone(), push(&acc_pp, &pt_pu), s3_p11.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }));
    let outer_color_p4 = st1_p14.color.clone();
    let outer_why_p5 = st1_p14.color_why.clone();
    let outer_flex_p6 = st1_p14.color_flex.clone();
    let (lcol_p15, st1b_p16) = crate::check::types::fresh_col(&st1_p14);
    let st2_p7 = {
        let mut this: crate::check::types::St = st1b_p16.clone();
        this.color = crate::check::types::Col::CBound;
        this.color_why = Text::lit("");
        this.color_flex = Array::new();
        this
    };
    let (rt_p1b, st3_p1c) = match &body_ph {
        crate::syntax::LambdaBody::LbExpr(x_p17) => match &exp_res_om {
            Some(r_p18) => {
                let s4_p19 = crate::check::expr::check(&env2_p12, &st2_p7, &**x_p17, r_p18);
                (r_p18.clone(), s4_p19.clone())
            },
            None => crate::check::expr::infer(&env2_p12, &st2_p7, &**x_p17),
        },
        crate::syntax::LambdaBody::LbBlock(b_p1a) => infer_body_block(&env2_p12, &st2_p7, b_p1a, &exp_res_om),
    };
    let st3b_p8 = crate::check::types::colors::settle_body(&st3_p1c, &lcol_p15, &Text::lit(""));
    let st3c_p9 = crate::check::types::colors::add_leq(&st3b_p8, &st3b_p8.color, &lcol_p15, &e_p2.span, &Text::lit("lambda"), &Text::lit(""), &st3b_p8.color_why);
    let st4_pa = {
        let mut this: crate::check::types::St = st3c_p9.clone();
        this.color = outer_color_p4.clone();
        this.color_why = outer_why_p5.clone();
        this.color_flex = outer_flex_p6.clone();
        this
    };
    (crate::check::types::Ty::TyFn(lcol_p15.clone(), ptys_p13.clone(), Rc::new(rt_p1b.clone())), crate::check::types::recording::note_fn(&st4_pa, &e_p2.span, &Text::lit("lambda"), &lcol_p15, &lcol_p15))
}

/// The step machine of `InferBareLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub struct InferBareLambda {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub expected_o3: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferBareLambda {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let expected_o3 = &self.expected_o3;
        let (params_pg, body_ph) = match &*e_p2.kind {
            crate::syntax::ExprKind::ELambda(Some(ps_pb), b_pc) => (ps_pb.clone(), (**b_pc).clone()),
            crate::syntax::ExprKind::ELambda(None, b_pd) => (Array::from(vec![topic_pat(&e_p2.span)]), (**b_pd).clone()),
            crate::syntax::ExprKind::ETopicField(f_pe) => (Array::from(vec![topic_pat(&e_p2.span)]), crate::syntax::LambdaBody::LbExpr(Rc::new(topic_field_expr(&e_p2.span, f_pe)))),
            crate::syntax::ExprKind::ETopicIndex(x_pf) => (Array::from(vec![topic_pat(&e_p2.span)]), crate::syntax::LambdaBody::LbExpr(Rc::new(topic_index_expr(&e_p2.span, &**x_pf)))),
            _ => (Array::new(), crate::syntax::LambdaBody::LbExpr(Rc::new(e_p2.clone()))),
        };
        let (exp_params_pl, exp_res_om, st0_pn) = match expected_o3 {
            Some(t_pi) => match crate::check::types::recording::walk(st_p1, t_pi) {
                crate::check::types::Ty::TyFn(_, ps_pj, r_pk) => if &len(&ps_pj) == &len(&params_pg) {
                    (ps_pj.clone(), Some((*r_pk).clone()), st_p1.clone())
                } else {
                    (Array::new(), None, crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &e_p2.span, &Text::from(format!("this lambda takes {} parameter{}; here {} {} wanted", &crate::check::errors::count_word(&len(&params_pg)), &(if &len(&params_pg) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(&ps_pj)), &(if &len(&ps_pj) == &Nat::from(1u32) { Text::lit("is") } else { Text::lit("are") })))))
                },
                _ => (Array::new(), None, st_p1.clone()),
            },
            None => (Array::new(), None, st_p1.clone()),
        };
        let e_p2 = e_p2.clone();
        let env_p0 = env_p0.clone();
        call_value(fold_job(crate::check::errors::range0(&len(&params_pg)), (env_p0.clone(), Array::new(), st0_pn.clone()), {
            let params_pg = params_pg.clone();
            let e_p2 = e_p2.clone();
            let exp_params_pl = exp_params_pl.clone();
            Rc::new(move |(p0, p1): ((crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St), Nat)| {
                let params_pg = params_pg.clone();
                let e_p2 = e_p2.clone();
                let exp_params_pl = exp_params_pl.clone();
                entered(once_job(move || {
                    let (en_po, acc_pp, s_pq) = p0;
                    let i_pr = p1;
                    {
                        let p_ps = or(&index(&params_pg, &i_pr), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: e_p2.span.clone() });
                        let (pt_pu, s2_pv) = match index(&exp_params_pl, &i_pr) {
                            Some(t_pt) => (t_pt, s_pq.clone()),
                            None => crate::check::types::fresh_var(&s_pq, &true, &Text::lit("")),
                        };
                        call_then(crate::check::expr::patterns::start_bind_pattern(crate::check::expr::lets::unpend(&en_po), s2_pv.clone(), p_ps.clone(), pt_pu.clone(), false), move |bind_pattern_28243: (crate::check::expr::Env, crate::check::types::St)| {
                            let (en2_p10, s3_p11) = bind_pattern_28243;
                            prism_rtl::Turn::Finished((en2_p10.clone(), push(&acc_pp, &pt_pu), s3_p11.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }), move |fold_27974: (crate::check::expr::Env, Array<crate::check::types::Ty>, crate::check::types::St)| {
            let (env2_p12, ptys_p13, st1_p14) = fold_27974;
            let outer_color_p4 = st1_p14.color.clone();
            let outer_why_p5 = st1_p14.color_why.clone();
            let outer_flex_p6 = st1_p14.color_flex.clone();
            let (lcol_p15, st1b_p16) = crate::check::types::fresh_col(&st1_p14);
            let st2_p7 = {
                let mut this: crate::check::types::St = st1b_p16.clone();
                this.color = crate::check::types::Col::CBound;
                this.color_why = Text::lit("");
                this.color_flex = Array::new();
                this
            };
            let (rt_p1b, st3_p1c) = match &body_ph {
                crate::syntax::LambdaBody::LbExpr(x_p17) => match &exp_res_om {
                    Some(r_p18) => {
                        let s4_p19 = crate::check::expr::check(&env2_p12, &st2_p7, &**x_p17, r_p18);
                        (r_p18.clone(), s4_p19.clone())
                    },
                    None => crate::check::expr::infer(&env2_p12, &st2_p7, &**x_p17),
                },
                crate::syntax::LambdaBody::LbBlock(b_p1a) => infer_body_block(&env2_p12, &st2_p7, b_p1a, &exp_res_om),
            };
            call_then(crate::check::types::colors::start_settle_body(st3_p1c.clone(), lcol_p15.clone(), Text::lit("")), move |settle_body_28829: crate::check::types::St| {
                let st3b_p8 = settle_body_28829;
                call_then(crate::check::types::colors::start_add_leq(st3b_p8.clone(), st3b_p8.color.clone(), lcol_p15.clone(), e_p2.span.clone(), Text::lit("lambda"), Text::lit(""), st3b_p8.color_why.clone()), move |add_leq_28869: crate::check::types::St| {
                    let st3c_p9 = add_leq_28869;
                    let st4_pa = {
                        let mut this: crate::check::types::St = st3c_p9.clone();
                        this.color = outer_color_p4.clone();
                        this.color_why = outer_why_p5.clone();
                        this.color_flex = outer_flex_p6.clone();
                        this
                    };
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyFn(lcol_p15.clone(), ptys_p13.clone(), Rc::new(rt_p1b.clone())), crate::check::types::recording::note_fn(&st4_pa, &e_p2.span, &Text::lit("lambda"), &lcol_p15, &lcol_p15)))
                })
            })
        })
    }
}

/// `Start InferBareLambda, x`: what the function value is when passed to `@Run`.
pub fn start_infer_bare_lambda(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, expected_o3: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferBareLambda { env_p0, st_p1, e_p2, expected_o3 })
}

/// ```prism
/// TopicPat: fn Range -> Pattern
/// ```
pub fn topic_pat(span_p0: &crate::syntax::Range) -> crate::syntax::Pattern_ {
    crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PName(topic_sname(span_p0))), span: span_p0.clone() }
}

/// ```prism
/// TopicSName: fn Range -> SName
/// ```
pub fn topic_sname(span_p0: &crate::syntax::Range) -> crate::syntax::SName {
    crate::syntax::SName { sigils: Text::lit(""), path_: Array::from(vec![Text::lit("_")]), span: span_p0.clone() }
}

/// ```prism
/// TopicExpr: fn Range -> Expr
/// ```
pub fn topic_expr(span_p0: &crate::syntax::Range) -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(topic_sname(span_p0))), span: span_p0.clone() }
}

/// ```prism
/// TopicFieldExpr: fn Range, Ident -> Expr
/// ```
pub fn topic_field_expr(span_p0: &crate::syntax::Range, f_p1: &crate::syntax::Ident) -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(topic_expr(span_p0)), Text::lit(""), f_p1.clone())), span: span_p0.clone() }
}

/// ```prism
/// TopicIndexExpr: fn Range, Expr -> Expr
/// ```
pub fn topic_index_expr(span_p0: &crate::syntax::Range, x_p1: &crate::syntax::Expr) -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIndex(Rc::new(topic_expr(span_p0)), Rc::new(x_p1.clone()))), span: span_p0.clone() }
}

/// ```prism
/// ArgNamed: fn Arg, Text -> Bool
/// ```
pub fn arg_named(a_p0: &crate::syntax::Arg, f_p1: &Text) -> bool {
    match &a_p0.name {
        Some(id_p2) => &id_p2.name == f_p1,
        None => false,
    }
}

/// ```prism
/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
/// ```
pub fn infer_body_block(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block, expected_o3: &Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p4, st2_p5) = crate::check::expr::lets::infer_expr_block(env_p0, st_p1, b_p2);
    match expected_o3 {
        Some(r_p6) => (r_p6.clone(), crate::check::types::unify::unify(&st2_p5, r_p6, &t_p4, &b_p2.span)),
        None => (t_p4.clone(), st2_p5.clone()),
    }
}

/// The step machine of `InferBodyBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
/// ```
pub struct InferBodyBlock {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
    pub expected_o3: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferBodyBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        let expected_o3 = &self.expected_o3;
        let expected_o3 = expected_o3.clone();
        let b_p2 = b_p2.clone();
        let env_p0 = env_p0.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::expr::lets::start_infer_expr_block(env_p0.clone(), st_p1.clone(), b_p2.clone()), move |infer_expr_block_30124: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p4, st2_p5) = infer_expr_block_30124;
            match &expected_o3 {
                Some(r_p6) => {
                    let r_p6 = r_p6.clone();
                    call_then(crate::check::types::unify::start_unify(st2_p5.clone(), r_p6.clone(), t_p4.clone(), b_p2.span.clone()), move |unify_30190: crate::check::types::St| prism_rtl::Turn::Finished((r_p6.clone(), unify_30190)))
                },
                None => prism_rtl::Turn::Finished((t_p4.clone(), st2_p5.clone())),
            }
        })
    }
}

/// `Start InferBodyBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_body_block(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block, expected_o3: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferBodyBlock { env_p0, st_p1, b_p2, expected_o3 })
}
