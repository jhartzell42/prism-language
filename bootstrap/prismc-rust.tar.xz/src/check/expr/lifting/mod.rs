//! The module `Check.Expr.Lifting`, from `target/bootstrap/src/prismc/check/expr/lifting.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
/// ```
pub fn infer_match_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, scrut_p2: &crate::syntax::Expr, arms_p3: &Array<crate::syntax::Arm>, span_p4: &crate::syntax::Range, expected_o5: &Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    let (st_ty_pd, st1_pe) = crate::check::expr::infer_f(env_p0, st_p1, scrut_p2);
    let sh_p6 = crate::check::types::head_sigil_f(&st1_pe, &st_ty_pd);
    let plain_scrut_p7 = if crate::check::expr::is_time_sigil_f(&sh_p6) {
        crate::check::expr::inner_of_f(&st1_pe, &st_ty_pd)
    } else {
        st_ty_pd.clone()
    };
    let st2_p8 = if &sh_p6 == &Text::lit("@") {
        crate::check::types::recording::err_f(&st1_pe, &Text::lit("blueprint-operand"), &scrut_p2.span_p, &Text::lit("`match` over a blueprint; bind it first"))
    } else {
        st1_pe.clone()
    };
    let rigid_out_o9 = match crate::check::types::recording::walk_f(&st2_p8, &plain_scrut_p7) {
        crate::check::types::Ty::TyElem(_, o_pf) => match crate::check::types::recording::walk_f(&st2_p8, &*o_pf) {
            crate::check::types::Ty::TyRigid(name_pg) => Some(name_pg),
            _ => None,
        },
        _ => None,
    };
    let (res_ph, st3_pi) = crate::check::types::fresh_var_f(&st2_p8, &false, &Text::lit(""));
    let checking_pa = (expected_o5 != &None) && !crate::check::expr::is_time_sigil_f(&sh_p6);
    let scrut_name_pb = crate::check::shrink::locals::expr_name_f(scrut_p2);
    let (layers_pq, st4_pr, _) = crate::prelude::run_to_end(crate::prelude::fold_job(arms_p3.clone(), (Array::new(), st3_pi.clone(), Array::new()), {
        let env_p0x = env_p0.clone();
        let scrut_name_pbx = scrut_name_pb.clone();
        let plain_scrut_p7x = plain_scrut_p7.clone();
        let res_phx = res_ph.clone();
        let checking_pax = checking_pa;
        let expected_o5x = expected_o5.clone();
        let rigid_out_o9x = rigid_out_o9.clone();
        Rc::new(move |(p0, p1): ((Array<(Text, crate::syntax::Range)>, crate::check::types::St, Array<Text>), crate::syntax::Arm)| {
            let env_p0xy = env_p0x.clone();
            let scrut_name_pbxy = scrut_name_pbx.clone();
            let plain_scrut_p7xy = plain_scrut_p7x.clone();
            let res_phxy = res_phx.clone();
            let checking_paxy = checking_pax;
            let expected_o5xy = expected_o5x.clone();
            let rigid_out_o9xy = rigid_out_o9x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pj, s_pk, taken_pl) = p0;
                let arm_pm = p1;
                crate::prelude::call_then(start_narrowed_f(env_p0xy.clone(), s_pk.clone(), arm_pm.clone(), scrut_name_pbxy.clone(), plain_scrut_p7xy.clone(), taken_pl.clone()), move |narrowed_f_2375: crate::check::expr::Env| {
                    let env_arm_pn = narrowed_f_2375;
                    crate::prelude::call_then(start_infer_arm_f(env_arm_pn.clone(), s_pk.clone(), arm_pm.clone(), plain_scrut_p7xy.clone(), res_phxy.clone(), if checking_paxy { expected_o5xy.clone() } else { None }, rigid_out_o9xy.clone(), acc_pj.clone()), move |infer_arm_f_2453: (Array<(Text, crate::syntax::Range)>, crate::check::types::St)| {
                        let (acc2_po, s2_pp) = infer_arm_f_2453;
                        prism_rtl::Turn::Finished((acc2_po.clone(), s2_pp.clone(), taken_by_f(&env_p0xy, &arm_pm, &taken_pl)))
                    })
                })
            }))
        }) as Rc<dyn Fn(((Array<(Text, crate::syntax::Range)>, crate::check::types::St, Array<Text>), crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::syntax::Range)>, crate::check::types::St, Array<Text>)>>>
    }));
    let st5_pc = crate::check::passes::match_coverage_f(env_p0, &st4_pr, &plain_scrut_p7, arms_p3, span_p4);
    match expected_o5 {
        Some(want_ps) => if checking_pa {
            (want_ps.clone(), st5_pc.clone())
        } else {
            match_result_f(env_p0, &st5_pc, &sh_p6, &layers_pq, &res_ph, span_p4)
        },
        None => match_result_f(env_p0, &st5_pc, &sh_p6, &layers_pq, &res_ph, span_p4),
    }
}

/// The step machine of `InferMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
/// ```
pub struct InferMatch {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub scrut_p2: crate::syntax::Expr,
    pub arms_p3: Array<crate::syntax::Arm>,
    pub span_p4: crate::syntax::Range,
    pub expected_o5: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferMatch {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let scrut_p2 = &self.scrut_p2;
        let arms_p3 = &self.arms_p3;
        let span_p4 = &self.span_p4;
        let expected_o5 = &self.expected_o5;
        let expected_o5x = expected_o5.clone();
        let arms_p3x = arms_p3.clone();
        let env_p0x = env_p0.clone();
        let scrut_p2x = scrut_p2.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), scrut_p2x.clone()), move |infer_f_1698: (crate::check::types::Ty, crate::check::types::St)| {
            let (st_ty_pd, st1_pe) = infer_f_1698;
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pe.clone(), st_ty_pd.clone()), move |head_sigil_f_1732: Text| {
                let sh_p6 = head_sigil_f_1732;
                let plain_scrut_p7 = if crate::check::expr::is_time_sigil_f(&sh_p6) {
                    crate::check::expr::inner_of_f(&st1_pe, &st_ty_pd)
                } else {
                    st_ty_pd.clone()
                };
                let st2_p8 = if &sh_p6 == &Text::lit("@") {
                    crate::check::types::recording::err_f(&st1_pe, &Text::lit("blueprint-operand"), &scrut_p2x.span_p, &Text::lit("`match` over a blueprint; bind it first"))
                } else {
                    st1_pe.clone()
                };
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st2_p8.clone(), plain_scrut_p7.clone()), move |walk_f_1969: crate::check::types::Ty| {
                    let rigid_out_o9 = match walk_f_1969 {
                        crate::check::types::Ty::TyElem(_, o_pf) => match crate::check::types::recording::walk_f(&st2_p8, &*o_pf) {
                            crate::check::types::Ty::TyRigid(name_pg) => Some(name_pg),
                            _ => None,
                        },
                        _ => None,
                    };
                    let (res_ph, st3_pi) = crate::check::types::fresh_var_f(&st2_p8, &false, &Text::lit(""));
                    let checking_pa = (&expected_o5x != &None) && !crate::check::expr::is_time_sigil_f(&sh_p6);
                    let scrut_name_pb = crate::check::shrink::locals::expr_name_f(&scrut_p2x);
                    crate::prelude::call_value(crate::prelude::fold_job(arms_p3x.clone(), (Array::new(), st3_pi.clone(), Array::new()), {
                        let env_p0xx = env_p0x.clone();
                        let scrut_name_pbx = scrut_name_pb.clone();
                        let plain_scrut_p7x = plain_scrut_p7.clone();
                        let res_phx = res_ph.clone();
                        let checking_pax = checking_pa;
                        let expected_o5xx = expected_o5x.clone();
                        let rigid_out_o9x = rigid_out_o9.clone();
                        Rc::new(move |(p0, p1): ((Array<(Text, crate::syntax::Range)>, crate::check::types::St, Array<Text>), crate::syntax::Arm)| {
                            let env_p0xxy = env_p0xx.clone();
                            let scrut_name_pbxy = scrut_name_pbx.clone();
                            let plain_scrut_p7xy = plain_scrut_p7x.clone();
                            let res_phxy = res_phx.clone();
                            let checking_paxy = checking_pax;
                            let expected_o5xxy = expected_o5xx.clone();
                            let rigid_out_o9xy = rigid_out_o9x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (acc_pj, s_pk, taken_pl) = p0;
                                let arm_pm = p1;
                                crate::prelude::call_then(start_narrowed_f(env_p0xxy.clone(), s_pk.clone(), arm_pm.clone(), scrut_name_pbxy.clone(), plain_scrut_p7xy.clone(), taken_pl.clone()), move |narrowed_f_2375: crate::check::expr::Env| {
                                    let env_arm_pn = narrowed_f_2375;
                                    crate::prelude::call_then(start_infer_arm_f(env_arm_pn.clone(), s_pk.clone(), arm_pm.clone(), plain_scrut_p7xy.clone(), res_phxy.clone(), if checking_paxy { expected_o5xxy.clone() } else { None }, rigid_out_o9xy.clone(), acc_pj.clone()), move |infer_arm_f_2453: (Array<(Text, crate::syntax::Range)>, crate::check::types::St)| {
                                        let (acc2_po, s2_pp) = infer_arm_f_2453;
                                        prism_rtl::Turn::Finished((acc2_po.clone(), s2_pp.clone(), taken_by_f(&env_p0xxy, &arm_pm, &taken_pl)))
                                    })
                                })
                            }))
                        }) as Rc<dyn Fn(((Array<(Text, crate::syntax::Range)>, crate::check::types::St, Array<Text>), crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::syntax::Range)>, crate::check::types::St, Array<Text>)>>>
                    }), move |fold_2296: (Array<(Text, crate::syntax::Range)>, crate::check::types::St, Array<Text>)| {
                        let (layers_pq, st4_pr, _) = fold_2296;
                        crate::prelude::call_then(crate::check::passes::start_match_coverage_f(env_p0x.clone(), st4_pr.clone(), plain_scrut_p7.clone(), arms_p3x.clone(), span_p4x.clone()), move |match_coverage_f_2608: crate::check::types::St| {
                            let st5_pc = match_coverage_f_2608;
                            match &expected_o5x {
                                Some(want_ps) => if checking_pa {
                                    prism_rtl::Turn::Finished((want_ps.clone(), st5_pc.clone()))
                                } else {
                                    prism_rtl::Turn::More(Rc::new(MatchResult { env_p0: env_p0x.clone(), st_p1: st5_pc.clone(), sh_p2: sh_p6.clone(), layers_p3: layers_pq.clone(), res_p4: res_ph.clone(), span_p5: span_p4x.clone() }))
                                },
                                None => prism_rtl::Turn::More(Rc::new(MatchResult { env_p0: env_p0x.clone(), st_p1: st5_pc.clone(), sh_p2: sh_p6.clone(), layers_p3: layers_pq.clone(), res_p4: res_ph.clone(), span_p5: span_p4x.clone() })),
                            }
                        })
                    })
                })
            })
        })
    }
}

/// `Start InferMatch, x`: what the function value is when passed to `@Run`.
pub fn start_infer_match_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, scrut_p2: crate::syntax::Expr, arms_p3: Array<crate::syntax::Arm>, span_p4: crate::syntax::Range, expected_o5: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferMatch { env_p0, st_p1, scrut_p2, arms_p3, span_p4, expected_o5 })
}

/// ```prism
/// TakenBy: fn Env, Arm, [Text] -> [Text]
/// ```
pub fn taken_by_f(env_p0: &crate::check::expr::Env, arm_p1: &crate::syntax::Arm, taken_p2: &Array<Text>) -> Array<Text> {
    if &arm_p1.guard_o != &None {
        taken_p2.clone()
    } else {
        match &arm_p1.pattern_o {
            Some(p_p3) => match &*p_p3.kind_p {
                crate::syntax::PatternKind::PFamily(q_p4) => crate::check::types::union_texts_f(taken_p2, &crate::prelude::or(&crate::prelude::get(&env_p0.g_p.families_p, &crate::check::env::dotted_f(&q_p4.path_p)), &Array::new())),
                _ => match tag_of_pattern_o(env_p0, p_p3) {
                    Some(tg_p5) => crate::check::types::add_text_f(taken_p2, &tg_p5.name_p),
                    None => taken_p2.clone(),
                },
            },
            None => taken_p2.clone(),
        }
    }
}

/// ```prism
/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
/// ```
pub fn narrowed_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, arm_p2: &crate::syntax::Arm, name_p3: &Text, t_p4: &crate::check::types::Ty, taken_p5: &Array<Text>) -> crate::check::expr::Env {
    let forwards_p6 = match &arm_p2.pattern_o {
        Some(p_p7) => match &*p_p7.kind_p {
            crate::syntax::PatternKind::PFamily(_) => true,
            _ => false,
        },
        None => true,
    };
    if (!forwards_p6 || (name_p3 == &Text::lit(""))) || (&crate::prelude::len(taken_p5) == &Nat::from(0u32)) {
        env_p0.clone()
    } else {
        match crate::check::types::recording::walk_f(st_p1, t_p4) {
            crate::check::types::Ty::TyElem(rw_p8, o_p9) => {
                let w_pa = crate::check::types::recording::walk_row_f(st_p1, &rw_p8);
                crate::check::expr::with_local_f(env_p0, name_p3, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyElem(crate::check::types::Rw { fams_p: w_pa.fams_p.clone(), minus_p: crate::check::types::union_texts_f(&w_pa.minus_p, taken_p5), tail_p: w_pa.tail_p.clone() }, Rc::new((*o_p9).clone()))))
            },
            _ => env_p0.clone(),
        }
    }
}

/// The step machine of `Narrowed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
/// ```
pub struct Narrowed {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub arm_p2: crate::syntax::Arm,
    pub name_p3: Text,
    pub t_p4: crate::check::types::Ty,
    pub taken_p5: Array<Text>,
}

impl prism_rtl::Job<crate::check::expr::Env> for Narrowed {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::expr::Env> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let arm_p2 = &self.arm_p2;
        let name_p3 = &self.name_p3;
        let t_p4 = &self.t_p4;
        let taken_p5 = &self.taken_p5;
        let forwards_p6 = match &arm_p2.pattern_o {
            Some(p_p7) => match &*p_p7.kind_p {
                crate::syntax::PatternKind::PFamily(_) => true,
                _ => false,
            },
            None => true,
        };
        if (!forwards_p6 || (name_p3 == &Text::lit(""))) || (&crate::prelude::len(taken_p5) == &Nat::from(0u32)) {
            prism_rtl::Turn::Finished(env_p0.clone())
        } else {
            {
                let arm_p2x = arm_p2.clone();
                let env_p0x = env_p0.clone();
                let name_p3x = name_p3.clone();
                let st_p1x = st_p1.clone();
                let t_p4x = t_p4.clone();
                let taken_p5x = taken_p5.clone();
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), t_p4x.clone()), move |walk_f_3793: crate::check::types::Ty| match walk_f_3793 {
                    crate::check::types::Ty::TyElem(rw_p8, o_p9) => crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_p8.clone()), move |walk_row_f_3847: crate::check::types::Rw| {
                        let w_pa = walk_row_f_3847;
                        prism_rtl::Turn::Finished(crate::check::expr::with_local_f(&env_p0x, &name_p3x, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyElem(crate::check::types::Rw { fams_p: w_pa.fams_p.clone(), minus_p: crate::check::types::union_texts_f(&w_pa.minus_p, &taken_p5x), tail_p: w_pa.tail_p.clone() }, Rc::new((*o_p9).clone())))))
                    }),
                    _ => prism_rtl::Turn::Finished(env_p0x.clone()),
                })
            }
        }
    }
}

/// `Start Narrowed, x`: what the function value is when passed to `@Run`.
pub fn start_narrowed_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, arm_p2: crate::syntax::Arm, name_p3: Text, t_p4: crate::check::types::Ty, taken_p5: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::check::expr::Env>> {
    Rc::new(Narrowed { env_p0, st_p1, arm_p2, name_p3, t_p4, taken_p5 })
}

/// ```prism
/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
/// ```
pub fn infer_arm_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, arm_p2: &crate::syntax::Arm, scrut_ty_p3: &crate::check::types::Ty, res_p4: &crate::check::types::Ty, expected_o5: &Option<crate::check::types::Ty>, rigid_out_o6: &Option<Text>, acc_p7: &Array<(Text, crate::syntax::Range)>) -> (Array<(Text, crate::syntax::Range)>, crate::check::types::St) {
    let (env2_pb, st1_pc) = match &arm_p2.pattern_o {
        Some(p_pa) => crate::check::expr::patterns::bind_pattern_f(env_p0, st_p1, p_pa, scrut_ty_p3, &true),
        None => (env_p0.clone(), st_p1.clone()),
    };
    let refined_out_o8 = match rigid_out_o6 {
        Some(o_pd) => match &arm_p2.pattern_o {
            Some(p_pe) => match tag_of_pattern_o(env_p0, p_pe) {
                Some(tg_pf) => Some((o_pd.clone(), tg_pf.out_p.clone())),
                None => None,
            },
            None => None,
        },
        None => None,
    };
    let st2_p9 = match &arm_p2.guard_o {
        Some(gd_pg) => check_cond_f(&env2_pb, &st1_pc, gd_pg),
        None => st1_pc.clone(),
    };
    match expected_o5 {
        Some(want_ph) => {
            let refined_pi = match &refined_out_o8 {
                Some((o_pj, out_pk)) => subst_rigid_f(o_pj, out_pk, &crate::check::types::recording::zonk_f(&st2_p9, want_ph)),
                None => want_ph.clone(),
            };
            let (bt_pl, st3_pm) = crate::check::expr::lets::infer_expr_block_f(&env2_pb, &st2_p9, &arm_p2.body_p);
            (acc_p7.clone(), arm_against_f(&st3_pm, &refined_pi, &bt_pl, &arm_p2.body_p.span_p, &((&arm_p2.pattern_o == &None) || is_family_arm_f(arm_p2))))
        },
        None => {
            let (bt_ps, st3_pt) = crate::check::expr::lets::infer_expr_block_f(&env2_pb, &st2_p9, &arm_p2.body_p);
            let head_pn = crate::check::types::head_sigil_f(&st3_pt, &bt_ps);
            let plain_bt_po = if crate::check::expr::is_time_sigil_f(&head_pn) {
                crate::check::expr::inner_of_f(&st3_pt, &bt_ps)
            } else {
                bt_ps.clone()
            };
            let st4_pp = unify_arm_f(&st3_pt, res_p4, &plain_bt_po, &arm_p2.body_p.span_p);
            let acc2_pq = if crate::check::expr::is_time_sigil_f(&head_pn) {
                crate::prelude::push(acc_p7, &(head_pn.clone(), arm_p2.body_p.span_p.clone()))
            } else {
                crate::prelude::push(acc_p7, &(Text::lit(""), arm_p2.body_p.span_p.clone()))
            };
            let acc3_pr = if &head_pn == &Text::lit("@") {
                crate::prelude::push(&acc2_pq, &(Text::lit("@"), arm_p2.body_p.span_p.clone()))
            } else {
                acc2_pq.clone()
            };
            (acc3_pr.clone(), st4_pp.clone())
        },
    }
}

/// The step machine of `InferArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
/// ```
pub struct InferArm {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub arm_p2: crate::syntax::Arm,
    pub scrut_ty_p3: crate::check::types::Ty,
    pub res_p4: crate::check::types::Ty,
    pub expected_o5: Option<crate::check::types::Ty>,
    pub rigid_out_o6: Option<Text>,
    pub acc_p7: Array<(Text, crate::syntax::Range)>,
}

impl prism_rtl::Job<(Array<(Text, crate::syntax::Range)>, crate::check::types::St)> for InferArm {
    fn cycle(&self) -> prism_rtl::Turn<(Array<(Text, crate::syntax::Range)>, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let arm_p2 = &self.arm_p2;
        let scrut_ty_p3 = &self.scrut_ty_p3;
        let res_p4 = &self.res_p4;
        let expected_o5 = &self.expected_o5;
        let rigid_out_o6 = &self.rigid_out_o6;
        let acc_p7 = &self.acc_p7;
        let (env2_pb, st1_pc) = match &arm_p2.pattern_o {
            Some(p_pa) => crate::check::expr::patterns::bind_pattern_f(env_p0, st_p1, p_pa, scrut_ty_p3, &true),
            None => (env_p0.clone(), st_p1.clone()),
        };
        let refined_out_o8 = match rigid_out_o6 {
            Some(o_pd) => match &arm_p2.pattern_o {
                Some(p_pe) => match tag_of_pattern_o(env_p0, p_pe) {
                    Some(tg_pf) => Some((o_pd.clone(), tg_pf.out_p.clone())),
                    None => None,
                },
                None => None,
            },
            None => None,
        };
        let st2_p9 = match &arm_p2.guard_o {
            Some(gd_pg) => check_cond_f(&env2_pb, &st1_pc, gd_pg),
            None => st1_pc.clone(),
        };
        match expected_o5 {
            Some(want_ph) => {
                let refined_pi = match &refined_out_o8 {
                    Some((o_pj, out_pk)) => subst_rigid_f(o_pj, out_pk, &crate::check::types::recording::zonk_f(&st2_p9, want_ph)),
                    None => want_ph.clone(),
                };
                let acc_p7x = acc_p7.clone();
                let arm_p2x = arm_p2.clone();
                crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(env2_pb.clone(), st2_p9.clone(), arm_p2x.body_p.clone()), move |infer_expr_block_f_4943: (crate::check::types::Ty, crate::check::types::St)| {
                    let (bt_pl, st3_pm) = infer_expr_block_f_4943;
                    crate::prelude::call_then(start_arm_against_f(st3_pm.clone(), refined_pi.clone(), bt_pl.clone(), arm_p2x.body_p.span_p.clone(), (&arm_p2x.pattern_o == &None) || is_family_arm_f(&arm_p2x)), move |arm_against_f_4998: crate::check::types::St| prism_rtl::Turn::Finished((acc_p7x.clone(), arm_against_f_4998)))
                })
            },
            None => {
                let acc_p7x = acc_p7.clone();
                let arm_p2x = arm_p2.clone();
                let res_p4x = res_p4.clone();
                crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(env2_pb.clone(), st2_p9.clone(), arm_p2x.body_p.clone()), move |infer_expr_block_f_5131: (crate::check::types::Ty, crate::check::types::St)| {
                    let (bt_ps, st3_pt) = infer_expr_block_f_5131;
                    crate::prelude::call_then(crate::check::types::start_head_sigil_f(st3_pt.clone(), bt_ps.clone()), move |head_sigil_f_5189: Text| {
                        let head_pn = head_sigil_f_5189;
                        let plain_bt_po = if crate::check::expr::is_time_sigil_f(&head_pn) {
                            crate::check::expr::inner_of_f(&st3_pt, &bt_ps)
                        } else {
                            bt_ps.clone()
                        };
                        crate::prelude::call_then(start_unify_arm_f(st3_pt.clone(), res_p4x.clone(), plain_bt_po.clone(), arm_p2x.body_p.span_p.clone()), move |unify_arm_f_5301: crate::check::types::St| {
                            let st4_pp = unify_arm_f_5301;
                            let acc2_pq = if crate::check::expr::is_time_sigil_f(&head_pn) {
                                crate::prelude::push(&acc_p7x, &(head_pn.clone(), arm_p2x.body_p.span_p.clone()))
                            } else {
                                crate::prelude::push(&acc_p7x, &(Text::lit(""), arm_p2x.body_p.span_p.clone()))
                            };
                            let acc3_pr = if &head_pn == &Text::lit("@") {
                                crate::prelude::push(&acc2_pq, &(Text::lit("@"), arm_p2x.body_p.span_p.clone()))
                            } else {
                                acc2_pq.clone()
                            };
                            prism_rtl::Turn::Finished((acc3_pr.clone(), st4_pp.clone()))
                        })
                    })
                })
            },
        }
    }
}

/// `Start InferArm, x`: what the function value is when passed to `@Run`.
pub fn start_infer_arm_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, arm_p2: crate::syntax::Arm, scrut_ty_p3: crate::check::types::Ty, res_p4: crate::check::types::Ty, expected_o5: Option<crate::check::types::Ty>, rigid_out_o6: Option<Text>, acc_p7: Array<(Text, crate::syntax::Range)>) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::syntax::Range)>, crate::check::types::St)>> {
    Rc::new(InferArm { env_p0, st_p1, arm_p2, scrut_ty_p3, res_p4, expected_o5, rigid_out_o6, acc_p7 })
}

/// ```prism
/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
/// ```
pub fn arm_against_f(st_p0: &crate::check::types::St, want_p1: &crate::check::types::Ty, bt_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range, forwards_p4: &bool) -> crate::check::types::St {
    match (crate::check::types::recording::walk_f(st_p0, want_p1), crate::check::types::recording::walk_f(st_p0, bt_p2)) {
        (crate::check::types::Ty::TyAt(w1_p5, r1_p6), crate::check::types::Ty::TyAt(b1_p7, r2_p8)) => {
            let st2_p9 = crate::check::types::unify::unify_f(st_p0, &*w1_p5, &*b1_p7, span_p3);
            {
                let mut this: crate::check::types::St = st2_p9.clone();
                this.incls_p = crate::prelude::push(&this.incls_p, &crate::check::types::Incl { sub_p: r2_p8, sup_p: r1_p6, file_p: this.file_p.clone(), span_p: span_p3.clone(), what_p: Text::lit("arm"), forward_p: *forwards_p4 });
                this
            }
        },
        _ => crate::check::types::unify::unify_f(st_p0, want_p1, bt_p2, span_p3),
    }
}

/// The step machine of `ArmAgainst`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
/// ```
pub struct ArmAgainst {
    pub st_p0: crate::check::types::St,
    pub want_p1: crate::check::types::Ty,
    pub bt_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
    pub forwards_p4: bool,
}

impl prism_rtl::Job<crate::check::types::St> for ArmAgainst {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let want_p1 = &self.want_p1;
        let bt_p2 = &self.bt_p2;
        let span_p3 = &self.span_p3;
        let forwards_p4 = &self.forwards_p4;
        let bt_p2x = bt_p2.clone();
        let forwards_p4x = *forwards_p4;
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        let want_p1x = want_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), want_p1x.clone()), move |walk_f_5855: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), bt_p2x.clone()), move |walk_f_5872: crate::check::types::Ty| match (walk_f_5855, walk_f_5872) {
            (crate::check::types::Ty::TyAt(w1_p5, r1_p6), crate::check::types::Ty::TyAt(b1_p7, r2_p8)) => crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p0x.clone(), (*w1_p5).clone(), (*b1_p7).clone(), span_p3x.clone()), move |unify_f_5944: crate::check::types::St| {
                let st2_p9 = unify_f_5944;
                prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = st2_p9.clone();
                    this.incls_p = crate::prelude::push(&this.incls_p, &crate::check::types::Incl { sub_p: r2_p8.clone(), sup_p: r1_p6.clone(), file_p: this.file_p.clone(), span_p: span_p3x.clone(), what_p: Text::lit("arm"), forward_p: forwards_p4x });
                    this
                })
            }),
            _ => prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st_p0x.clone(), expected_p1: want_p1x.clone(), found_p2: bt_p2x.clone(), span_p3: span_p3x.clone() })),
        }))
    }
}

/// `Start ArmAgainst, x`: what the function value is when passed to `@Run`.
pub fn start_arm_against_f(st_p0: crate::check::types::St, want_p1: crate::check::types::Ty, bt_p2: crate::check::types::Ty, span_p3: crate::syntax::Range, forwards_p4: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ArmAgainst { st_p0, want_p1, bt_p2, span_p3, forwards_p4 })
}

/// ```prism
/// IsFamilyArm: fn Arm -> Bool
/// ```
pub fn is_family_arm_f(arm_p0: &crate::syntax::Arm) -> bool {
    match &arm_p0.pattern_o {
        Some(p_p1) => match &*p_p1.kind_p {
            crate::syntax::PatternKind::PFamily(_) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// CheckCond: unbounded fn Env, St, Expr -> St
/// ```
pub fn check_cond_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> crate::check::types::St {
    let (t_p4, st2_p5) = crate::check::expr::infer_f(env_p0, st_p1, e_p2);
    let inner_p3 = if crate::check::expr::is_time_sigil_f(&crate::check::types::head_sigil_f(&st2_p5, &t_p4)) {
        crate::check::expr::inner_of_f(&st2_p5, &t_p4)
    } else {
        t_p4.clone()
    };
    crate::check::types::unify::unify_f(&st2_p5, &crate::check::types::t_bool_p(), &inner_p3, &e_p2.span_p)
}

/// The step machine of `CheckCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckCond: unbounded fn Env, St, Expr -> St
/// ```
pub struct CheckCond {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::check::types::St> for CheckCond {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let e_p2x = e_p2.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone()), move |infer_f_6481: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p4, st2_p5) = infer_f_6481;
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st2_p5.clone(), t_p4.clone()), move |head_sigil_f_6530: Text| {
                let inner_p3 = if crate::check::expr::is_time_sigil_f(&head_sigil_f_6530) {
                    crate::check::expr::inner_of_f(&st2_p5, &t_p4)
                } else {
                    t_p4.clone()
                };
                prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st2_p5.clone(), expected_p1: crate::check::types::t_bool_p(), found_p2: inner_p3.clone(), span_p3: e_p2x.span_p.clone() }))
            })
        })
    }
}

/// `Start CheckCond, x`: what the function value is when passed to `@Run`.
pub fn start_check_cond_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckCond { env_p0, st_p1, e_p2 })
}

/// ```prism
/// ?TagOfPattern: fn Env, Pattern -> ?TagInfo
/// ```
pub fn tag_of_pattern_o(env_p0: &crate::check::expr::Env, p_p1: &crate::syntax::Pattern_) -> Option<crate::check::env::TagInfo> {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PRecord(n_p2, _, _) => crate::prelude::get(&env_p0.g_p.tags_p, &crate::check::env::dotted_f(&n_p2.path_p)),
        crate::syntax::PatternKind::PCtor(n_p3, _) => crate::prelude::get(&env_p0.g_p.tags_p, &crate::check::env::dotted_f(&n_p3.path_p)),
        crate::syntax::PatternKind::PName(n_p4) => crate::prelude::get(&env_p0.g_p.tags_p, &crate::check::env::dotted_f(&n_p4.path_p)),
        crate::syntax::PatternKind::PGroup(q_p5) => tag_of_pattern_o(env_p0, &**q_p5),
        _ => None,
    }
}

/// ```prism
/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
/// ```
pub fn subst_rigid_f(name_p0: &Text, by_p1: &crate::check::types::Ty, t_p2: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p2 {
        crate::check::types::Ty::TyRigid(n_p3) => if n_p3 == name_p0 { by_p1.clone() } else { t_p2.clone() },
        crate::check::types::Ty::TyCon(n_p4, args_p5) => crate::check::types::Ty::TyCon(n_p4.clone(), crate::prelude::run_to_end(crate::prelude::each_job(args_p5.clone(), {
            let name_p0x = name_p0.clone();
            let by_p1x = by_p1.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let name_p0xy = name_p0x.clone();
                let by_p1xy = by_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p6 = p0;
                    prism_rtl::Turn::More(Rc::new(SubstRigid { name_p0: name_p0xy.clone(), by_p1: by_p1xy.clone(), t_p2: a_p6.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c_p7, ps_p8, r_p9) => crate::check::types::Ty::TyFn(c_p7.clone(), crate::prelude::run_to_end(crate::prelude::each_job(ps_p8.clone(), {
            let name_p0x = name_p0.clone();
            let by_p1x = by_p1.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let name_p0xy = name_p0x.clone();
                let by_p1xy = by_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pa = p0;
                    prism_rtl::Turn::More(Rc::new(SubstRigid { name_p0: name_p0xy.clone(), by_p1: by_p1xy.clone(), t_p2: a_pa.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        })), Rc::new(subst_rigid_f(name_p0, by_p1, &**r_p9))),
        crate::check::types::Ty::TyTuple(ts_pb) => crate::check::types::Ty::TyTuple(crate::prelude::run_to_end(crate::prelude::each_job(ts_pb.clone(), {
            let name_p0x = name_p0.clone();
            let by_p1x = by_p1.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let name_p0xy = name_p0x.clone();
                let by_p1xy = by_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pc = p0;
                    prism_rtl::Turn::More(Rc::new(SubstRigid { name_p0: name_p0xy.clone(), by_p1: by_p1xy.clone(), t_p2: a_pc.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e_pd) => crate::check::types::Ty::TyArray(Rc::new(subst_rigid_f(name_p0, by_p1, &**e_pd))),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => crate::check::types::Ty::TyMap(Rc::new(subst_rigid_f(name_p0, by_p1, &**k_pe)), Rc::new(subst_rigid_f(name_p0, by_p1, &**v_pf))),
        crate::check::types::Ty::TySig(s_pg, i_ph) => crate::check::types::Ty::TySig(s_pg.clone(), Rc::new(subst_rigid_f(name_p0, by_p1, &**i_ph))),
        crate::check::types::Ty::TyAt(i_pi, rw_pj) => crate::check::types::Ty::TyAt(Rc::new(subst_rigid_f(name_p0, by_p1, &**i_pi)), rw_pj.clone()),
        crate::check::types::Ty::TyElem(rw_pk, o_pl) => crate::check::types::Ty::TyElem(rw_pk.clone(), Rc::new(subst_rigid_f(name_p0, by_p1, &**o_pl))),
        other_pm => other_pm.clone(),
    }
}

/// The step machine of `SubstRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
/// ```
pub struct SubstRigid {
    pub name_p0: Text,
    pub by_p1: crate::check::types::Ty,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for SubstRigid {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let name_p0 = &self.name_p0;
        let by_p1 = &self.by_p1;
        let t_p2 = &self.t_p2;
        match t_p2 {
            crate::check::types::Ty::TyRigid(n_p3) => if n_p3 == name_p0 {
                prism_rtl::Turn::Finished(by_p1.clone())
            } else {
                prism_rtl::Turn::Finished(t_p2.clone())
            },
            crate::check::types::Ty::TyCon(n_p4, args_p5) => {
                let args_p5x = args_p5.clone();
                let by_p1x = by_p1.clone();
                let n_p4x = n_p4.clone();
                let name_p0x = name_p0.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p5x.clone(), {
                    let name_p0xx = name_p0x.clone();
                    let by_p1xx = by_p1x.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let name_p0xxy = name_p0xx.clone();
                        let by_p1xxy = by_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p6 = p0;
                            prism_rtl::Turn::More(Rc::new(SubstRigid { name_p0: name_p0xxy.clone(), by_p1: by_p1xxy.clone(), t_p2: a_p6.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_7117: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p4x.clone(), each_7117)))
            },
            crate::check::types::Ty::TyFn(c_p7, ps_p8, r_p9) => {
                let by_p1x = by_p1.clone();
                let c_p7x = c_p7.clone();
                let name_p0x = name_p0.clone();
                let ps_p8x = ps_p8.clone();
                let r_p9x = (**r_p9).clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_p8x.clone(), {
                    let name_p0xx = name_p0x.clone();
                    let by_p1xx = by_p1x.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let name_p0xxy = name_p0xx.clone();
                        let by_p1xxy = by_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pa = p0;
                            prism_rtl::Turn::More(Rc::new(SubstRigid { name_p0: name_p0xxy.clone(), by_p1: by_p1xxy.clone(), t_p2: a_pa.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_7185: Array<crate::check::types::Ty>| crate::prelude::call_then(start_subst_rigid_f(name_p0x.clone(), by_p1x.clone(), r_p9x.clone()), move |subst_rigid_f_7225: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c_p7x.clone(), each_7185, Rc::new(subst_rigid_f_7225)))))
            },
            crate::check::types::Ty::TyTuple(ts_pb) => {
                let by_p1x = by_p1.clone();
                let name_p0x = name_p0.clone();
                let ts_pbx = ts_pb.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_pbx.clone(), {
                    let name_p0xx = name_p0x.clone();
                    let by_p1xx = by_p1x.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let name_p0xxy = name_p0xx.clone();
                        let by_p1xxy = by_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pc = p0;
                            prism_rtl::Turn::More(Rc::new(SubstRigid { name_p0: name_p0xxy.clone(), by_p1: by_p1xxy.clone(), t_p2: a_pc.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_7274: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_7274)))
            },
            crate::check::types::Ty::TyArray(e_pd) => {
                let by_p1x = by_p1.clone();
                let e_pdx = (**e_pd).clone();
                let name_p0x = name_p0.clone();
                crate::prelude::call_then(start_subst_rigid_f(name_p0x.clone(), by_p1x.clone(), e_pdx.clone()), move |subst_rigid_f_7336: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(subst_rigid_f_7336))))
            },
            crate::check::types::Ty::TyMap(k_pe, v_pf) => {
                let by_p1x = by_p1.clone();
                let k_pex = (**k_pe).clone();
                let name_p0x = name_p0.clone();
                let v_pfx = (**v_pf).clone();
                crate::prelude::call_then(start_subst_rigid_f(name_p0x.clone(), by_p1x.clone(), k_pex.clone()), move |subst_rigid_f_7383: crate::check::types::Ty| crate::prelude::call_then(start_subst_rigid_f(name_p0x.clone(), by_p1x.clone(), v_pfx.clone()), move |subst_rigid_f_7409: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(subst_rigid_f_7383), Rc::new(subst_rigid_f_7409)))))
            },
            crate::check::types::Ty::TySig(s_pg, i_ph) => {
                let by_p1x = by_p1.clone();
                let i_phx = (**i_ph).clone();
                let name_p0x = name_p0.clone();
                let s_pgx = s_pg.clone();
                crate::prelude::call_then(start_subst_rigid_f(name_p0x.clone(), by_p1x.clone(), i_phx.clone()), move |subst_rigid_f_7459: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pgx.clone(), Rc::new(subst_rigid_f_7459))))
            },
            crate::check::types::Ty::TyAt(i_pi, rw_pj) => {
                let by_p1x = by_p1.clone();
                let i_pix = (**i_pi).clone();
                let name_p0x = name_p0.clone();
                let rw_pjx = rw_pj.clone();
                crate::prelude::call_then(start_subst_rigid_f(name_p0x.clone(), by_p1x.clone(), i_pix.clone()), move |subst_rigid_f_7505: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(Rc::new(subst_rigid_f_7505), rw_pjx.clone())))
            },
            crate::check::types::Ty::TyElem(rw_pk, o_pl) => {
                let by_p1x = by_p1.clone();
                let name_p0x = name_p0.clone();
                let o_plx = (**o_pl).clone();
                let rw_pkx = rw_pk.clone();
                crate::prelude::call_then(start_subst_rigid_f(name_p0x.clone(), by_p1x.clone(), o_plx.clone()), move |subst_rigid_f_7563: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(rw_pkx.clone(), Rc::new(subst_rigid_f_7563))))
            },
            other_pm => prism_rtl::Turn::Finished(other_pm.clone()),
        }
    }
}

/// `Start SubstRigid, x`: what the function value is when passed to `@Run`.
pub fn start_subst_rigid_f(name_p0: Text, by_p1: crate::check::types::Ty, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(SubstRigid { name_p0, by_p1, t_p2 })
}

/// ```prism
/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
/// ```
pub fn match_result_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, sh_p2: &Text, layers_p3: &Array<(Text, crate::syntax::Range)>, res_p4: &crate::check::types::Ty, span_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let events_p6 = crate::prelude::filter(layers_p3, &(|(h_pb, _): &(Text, crate::syntax::Range)| h_pb == &Text::lit("!")));
    let dyns_p7 = crate::prelude::filter(layers_p3, &(|(h_pc, _): &(Text, crate::syntax::Range)| h_pc == &Text::lit("$")));
    let blue_p8 = crate::prelude::filter(layers_p3, &(|(h_pd, _): &(Text, crate::syntax::Range)| h_pd == &Text::lit("@")));
    let st2_p9 = if (&crate::prelude::len(&blue_p8) > &Nat::from(0u32)) && crate::check::expr::is_time_sigil_f(sh_p2) {
        crate::check::types::recording::err_fix_f(st_p1, &Text::lit("building-match"), span_p5, &Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
    } else {
        st_p1.clone()
    };
    let st3_pa = if (sh_p2 == &Text::lit("!")) && (&crate::prelude::len(&events_p6) > &Nat::from(0u32)) {
        crate::check::types::recording::err_fix_f(&st2_p9, &Text::lit("two-events"), span_p5, &Text::lit("two events in one operation"), &Text::lit("an arm over an event\'s scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
    } else {
        st2_p9.clone()
    };
    if &crate::prelude::len(&events_p6) > &Nat::from(0u32) {
        (crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(res_p4.clone())), crate::check::expr::calls::elab_f(&st3_pa, span_p5, &Text::lit("match"), &Text::lit("gate"), &Text::lit("!")))
    } else {
        if (sh_p2 == &Text::lit("$")) || (&crate::prelude::len(&dyns_p7) > &Nat::from(0u32)) {
            (crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(res_p4.clone())), crate::check::expr::calls::elab_f(&st3_pa, span_p5, &Text::lit("match"), &Text::lit("map"), &Text::lit("$")))
        } else {
            if sh_p2 == &Text::lit("!") {
                (crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(res_p4.clone())), crate::check::expr::calls::elab_f(&st3_pa, span_p5, &Text::lit("match"), &Text::lit("map"), &Text::lit("!")))
            } else {
                (res_p4.clone(), st3_pa.clone())
            }
        }
    }
}

/// The step machine of `MatchResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
/// ```
pub struct MatchResult {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub sh_p2: Text,
    pub layers_p3: Array<(Text, crate::syntax::Range)>,
    pub res_p4: crate::check::types::Ty,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for MatchResult {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let sh_p2 = &self.sh_p2;
        let layers_p3 = &self.layers_p3;
        let res_p4 = &self.res_p4;
        let span_p5 = &self.span_p5;
        let events_p6 = crate::prelude::filter(layers_p3, &(|(h_pb, _): &(Text, crate::syntax::Range)| h_pb == &Text::lit("!")));
        let dyns_p7 = crate::prelude::filter(layers_p3, &(|(h_pc, _): &(Text, crate::syntax::Range)| h_pc == &Text::lit("$")));
        let blue_p8 = crate::prelude::filter(layers_p3, &(|(h_pd, _): &(Text, crate::syntax::Range)| h_pd == &Text::lit("@")));
        let st2_p9 = if (&crate::prelude::len(&blue_p8) > &Nat::from(0u32)) && crate::check::expr::is_time_sigil_f(sh_p2) {
            crate::check::types::recording::err_fix_f(st_p1, &Text::lit("building-match"), span_p5, &Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
        } else {
            st_p1.clone()
        };
        let st3_pa = if (sh_p2 == &Text::lit("!")) && (&crate::prelude::len(&events_p6) > &Nat::from(0u32)) {
            crate::check::types::recording::err_fix_f(&st2_p9, &Text::lit("two-events"), span_p5, &Text::lit("two events in one operation"), &Text::lit("an arm over an event\'s scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
        } else {
            st2_p9.clone()
        };
        if &crate::prelude::len(&events_p6) > &Nat::from(0u32) {
            prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(res_p4.clone())), crate::check::expr::calls::elab_f(&st3_pa, span_p5, &Text::lit("match"), &Text::lit("gate"), &Text::lit("!"))))
        } else {
            if (sh_p2 == &Text::lit("$")) || (&crate::prelude::len(&dyns_p7) > &Nat::from(0u32)) {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(res_p4.clone())), crate::check::expr::calls::elab_f(&st3_pa, span_p5, &Text::lit("match"), &Text::lit("map"), &Text::lit("$"))))
            } else {
                if sh_p2 == &Text::lit("!") {
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(res_p4.clone())), crate::check::expr::calls::elab_f(&st3_pa, span_p5, &Text::lit("match"), &Text::lit("map"), &Text::lit("!"))))
                } else {
                    prism_rtl::Turn::Finished((res_p4.clone(), st3_pa.clone()))
                }
            }
        }
    }
}

/// `Start MatchResult, x`: what the function value is when passed to `@Run`.
pub fn start_match_result_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, sh_p2: Text, layers_p3: Array<(Text, crate::syntax::Range)>, res_p4: crate::check::types::Ty, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(MatchResult { env_p0, st_p1, sh_p2, layers_p3, res_p4, span_p5 })
}

/// ```prism
/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
/// ```
pub fn infer_if_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::syntax::Cond, then_b_p3: &crate::syntax::Block, else_b_o4: &Option<crate::syntax::Block>, span_p5: &crate::syntax::Range, expected_o6: &Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    match c_p2 {
        crate::syntax::Cond::CondExpr(e_p7) => {
            let (ct_pb, st1_pc) = crate::check::expr::infer_f(env_p0, st_p1, &**e_p7);
            let sh_p8 = crate::check::types::head_sigil_f(&st1_pc, &ct_pb);
            let inner_p9 = if crate::check::expr::is_time_sigil_f(&sh_p8) {
                crate::check::expr::inner_of_f(&st1_pc, &ct_pb)
            } else {
                ct_pb.clone()
            };
            let st2_pa = crate::check::types::unify::unify_f(&st1_pc, &crate::check::types::t_bool_p(), &inner_p9, &e_p7.span_p);
            let (res_pd, st3_pe) = crate::check::types::fresh_var_f(&st2_pa, &false, &Text::lit(""));
            let (layers_pf, st4_pg) = if_branches_f(env_p0, &st3_pe, env_p0, then_b_p3, else_b_o4, &res_pd);
            match_result_f(env_p0, &st4_pg, &sh_p8, &layers_pf, &res_pd, span_p5)
        },
        crate::syntax::Cond::CondBind(p_ph, e_pi, gd_oj) => {
            let (et_pl, st1_pm) = crate::check::expr::infer_f(env_p0, st_p1, &**e_pi);
            let (env2_pn, st2_po) = crate::check::expr::patterns::bind_pattern_f(env_p0, &st1_pm, p_ph, &et_pl, &true);
            let st3_pk = match &**gd_oj {
                Some(g_pp) => check_cond_f(&env2_pn, &st2_po, g_pp),
                None => st2_po.clone(),
            };
            let (res_pq, st4_pr) = crate::check::types::fresh_var_f(&st3_pk, &false, &Text::lit(""));
            let (layers_ps, st5_pt) = if_branches_f(&env2_pn, &st4_pr, env_p0, then_b_p3, else_b_o4, &res_pq);
            match_result_f(env_p0, &st5_pt, &Text::lit(""), &layers_ps, &res_pq, span_p5)
        },
    }
}

/// The step machine of `InferIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
/// ```
pub struct InferIf {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::syntax::Cond,
    pub then_b_p3: crate::syntax::Block,
    pub else_b_o4: Option<crate::syntax::Block>,
    pub span_p5: crate::syntax::Range,
    pub expected_o6: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferIf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let then_b_p3 = &self.then_b_p3;
        let else_b_o4 = &self.else_b_o4;
        let span_p5 = &self.span_p5;
        let expected_o6 = &self.expected_o6;
        match c_p2 {
            crate::syntax::Cond::CondExpr(e_p7) => {
                let else_b_o4x = else_b_o4.clone();
                let e_p7x = (**e_p7).clone();
                let env_p0x = env_p0.clone();
                let span_p5x = span_p5.clone();
                let st_p1x = st_p1.clone();
                let then_b_p3x = then_b_p3.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_p7x.clone()), move |infer_f_8896: (crate::check::types::Ty, crate::check::types::St)| {
                    let (ct_pb, st1_pc) = infer_f_8896;
                    crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pc.clone(), ct_pb.clone()), move |head_sigil_f_8930: Text| {
                        let sh_p8 = head_sigil_f_8930;
                        let inner_p9 = if crate::check::expr::is_time_sigil_f(&sh_p8) {
                            crate::check::expr::inner_of_f(&st1_pc, &ct_pb)
                        } else {
                            ct_pb.clone()
                        };
                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(st1_pc.clone(), crate::check::types::t_bool_p(), inner_p9.clone(), e_p7x.span_p.clone()), move |unify_f_9030: crate::check::types::St| {
                            let st2_pa = unify_f_9030;
                            let (res_pd, st3_pe) = crate::check::types::fresh_var_f(&st2_pa, &false, &Text::lit(""));
                            crate::prelude::call_then(start_if_branches_f(env_p0x.clone(), st3_pe.clone(), env_p0x.clone(), then_b_p3x.clone(), else_b_o4x.clone(), res_pd.clone()), move |if_branches_f_9143: (Array<(Text, crate::syntax::Range)>, crate::check::types::St)| {
                                let (layers_pf, st4_pg) = if_branches_f_9143;
                                prism_rtl::Turn::More(Rc::new(MatchResult { env_p0: env_p0x.clone(), st_p1: st4_pg.clone(), sh_p2: sh_p8.clone(), layers_p3: layers_pf.clone(), res_p4: res_pd.clone(), span_p5: span_p5x.clone() }))
                            })
                        })
                    })
                })
            },
            crate::syntax::Cond::CondBind(p_ph, e_pi, gd_oj) => {
                let else_b_o4x = else_b_o4.clone();
                let gd_ojx = (**gd_oj).clone();
                let c_p2x = c_p2.clone();
                let e_pix = (**e_pi).clone();
                let env_p0x = env_p0.clone();
                let p_phx = p_ph.clone();
                let span_p5x = span_p5.clone();
                let st_p1x = st_p1.clone();
                let then_b_p3x = then_b_p3.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_pix.clone()), move |infer_f_9290: (crate::check::types::Ty, crate::check::types::St)| {
                    let (et_pl, st1_pm) = infer_f_9290;
                    crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p0x.clone(), st1_pm.clone(), p_phx.clone(), et_pl.clone(), true), move |bind_pattern_f_9335: (crate::check::expr::Env, crate::check::types::St)| {
                        let (env2_pn, st2_po) = bind_pattern_f_9335;
                        let st3_pk = match &gd_ojx {
                            Some(g_pp) => check_cond_f(&env2_pn, &st2_po, g_pp),
                            None => st2_po.clone(),
                        };
                        let (res_pq, st4_pr) = crate::check::types::fresh_var_f(&st3_pk, &false, &Text::lit(""));
                        crate::prelude::call_then(start_if_branches_f(env2_pn.clone(), st4_pr.clone(), env_p0x.clone(), then_b_p3x.clone(), else_b_o4x.clone(), res_pq.clone()), move |if_branches_f_9540: (Array<(Text, crate::syntax::Range)>, crate::check::types::St)| {
                            let (layers_ps, st5_pt) = if_branches_f_9540;
                            prism_rtl::Turn::More(Rc::new(MatchResult { env_p0: env_p0x.clone(), st_p1: st5_pt.clone(), sh_p2: Text::lit(""), layers_p3: layers_ps.clone(), res_p4: res_pq.clone(), span_p5: span_p5x.clone() }))
                        })
                    })
                })
            },
        }
    }
}

/// `Start InferIf, x`: what the function value is when passed to `@Run`.
pub fn start_infer_if_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, c_p2: crate::syntax::Cond, then_b_p3: crate::syntax::Block, else_b_o4: Option<crate::syntax::Block>, span_p5: crate::syntax::Range, expected_o6: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferIf { env_p0, st_p1, c_p2, then_b_p3, else_b_o4, span_p5, expected_o6 })
}

/// ```prism
/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub fn unify_arm_f(st_p0: &crate::check::types::St, res_p1: &crate::check::types::Ty, t_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    if crate::check::types::is_flex_var_f(st_p0, res_p1) && (&crate::check::types::recording::walk_f(st_p0, t_p2) == &crate::check::types::Ty::TyCon(Text::lit("Prelude.Error"), Array::new())) {
        crate::check::types::unify::defer_f(st_p0, res_p1, t_p2, span_p3)
    } else {
        crate::check::types::unify::unify_f(st_p0, res_p1, t_p2, span_p3)
    }
}

/// The step machine of `UnifyArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub struct UnifyArm {
    pub st_p0: crate::check::types::St,
    pub res_p1: crate::check::types::Ty,
    pub t_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for UnifyArm {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let res_p1 = &self.res_p1;
        let t_p2 = &self.t_p2;
        let span_p3 = &self.span_p3;
        let res_p1x = res_p1.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(crate::check::types::start_is_flex_var_f(st_p0x.clone(), res_p1x.clone()), move |is_flex_var_f_9877: bool| if is_flex_var_f_9877 && (&crate::check::types::recording::walk_f(&st_p0x, &t_p2x) == &crate::check::types::Ty::TyCon(Text::lit("Prelude.Error"), Array::new())) {
            prism_rtl::Turn::Finished(crate::check::types::unify::defer_f(&st_p0x, &res_p1x, &t_p2x, &span_p3x))
        } else {
            prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st_p0x.clone(), expected_p1: res_p1x.clone(), found_p2: t_p2x.clone(), span_p3: span_p3x.clone() }))
        })
    }
}

/// `Start UnifyArm, x`: what the function value is when passed to `@Run`.
pub fn start_unify_arm_f(st_p0: crate::check::types::St, res_p1: crate::check::types::Ty, t_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UnifyArm { st_p0, res_p1, t_p2, span_p3 })
}

/// ```prism
/// LayerHead: fn Text -> Text
/// ```
pub fn layer_head_f(h_p0: &Text) -> Text {
    if crate::check::expr::is_time_sigil_f(h_p0) {
        h_p0.clone()
    } else {
        if h_p0 == &Text::lit("@") { Text::lit("@") } else { Text::lit("") }
    }
}

/// ```prism
/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
/// ```
pub fn if_branches_f(then_env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, else_env_p2: &crate::check::expr::Env, then_b_p3: &crate::syntax::Block, else_b_o4: &Option<crate::syntax::Block>, res_p5: &crate::check::types::Ty) -> (Array<(Text, crate::syntax::Range)>, crate::check::types::St) {
    let (t1_p9, st1_pa) = crate::check::expr::lets::infer_expr_block_f(then_env_p0, st_p1, then_b_p3);
    let h1_p6 = crate::check::types::head_sigil_f(&st1_pa, &t1_p9);
    let st2_p7 = unify_arm_f(&st1_pa, res_p5, &(if crate::check::expr::is_time_sigil_f(&h1_p6) {
        crate::check::expr::inner_of_f(&st1_pa, &t1_p9)
    } else {
        t1_p9.clone()
    }), &then_b_p3.span_p);
    let l1_p8 = Array::from(vec![(layer_head_f(&h1_p6), then_b_p3.span_p.clone())]);
    match else_b_o4 {
        Some(b_pb) => {
            let (t2_pe, st3_pf) = crate::check::expr::lets::infer_expr_block_f(else_env_p2, &st2_p7, b_pb);
            let h2_pc = crate::check::types::head_sigil_f(&st3_pf, &t2_pe);
            let st4_pd = unify_arm_f(&st3_pf, res_p5, &(if crate::check::expr::is_time_sigil_f(&h2_pc) {
                crate::check::expr::inner_of_f(&st3_pf, &t2_pe)
            } else {
                t2_pe.clone()
            }), &b_pb.span_p);
            (crate::prelude::push(&l1_p8, &(layer_head_f(&h2_pc), b_pb.span_p.clone())), st4_pd.clone())
        },
        None => (l1_p8.clone(), crate::check::types::unify::unify_f(&st2_p7, res_p5, &crate::check::types::t_unit_p(), &then_b_p3.span_p)),
    }
}

/// The step machine of `IfBranches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
/// ```
pub struct IfBranches {
    pub then_env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub else_env_p2: crate::check::expr::Env,
    pub then_b_p3: crate::syntax::Block,
    pub else_b_o4: Option<crate::syntax::Block>,
    pub res_p5: crate::check::types::Ty,
}

impl prism_rtl::Job<(Array<(Text, crate::syntax::Range)>, crate::check::types::St)> for IfBranches {
    fn cycle(&self) -> prism_rtl::Turn<(Array<(Text, crate::syntax::Range)>, crate::check::types::St)> {
        let then_env_p0 = &self.then_env_p0;
        let st_p1 = &self.st_p1;
        let else_env_p2 = &self.else_env_p2;
        let then_b_p3 = &self.then_b_p3;
        let else_b_o4 = &self.else_b_o4;
        let res_p5 = &self.res_p5;
        let else_b_o4x = else_b_o4.clone();
        let else_env_p2x = else_env_p2.clone();
        let res_p5x = res_p5.clone();
        let st_p1x = st_p1.clone();
        let then_b_p3x = then_b_p3.clone();
        let then_env_p0x = then_env_p0.clone();
        crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(then_env_p0x.clone(), st_p1x.clone(), then_b_p3x.clone()), move |infer_expr_block_f_10261: (crate::check::types::Ty, crate::check::types::St)| {
            let (t1_p9, st1_pa) = infer_expr_block_f_10261;
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pa.clone(), t1_p9.clone()), move |head_sigil_f_10308: Text| {
                let h1_p6 = head_sigil_f_10308;
                crate::prelude::call_then(start_unify_arm_f(st1_pa.clone(), res_p5x.clone(), if crate::check::expr::is_time_sigil_f(&h1_p6) {
                    crate::check::expr::inner_of_f(&st1_pa, &t1_p9)
                } else {
                    t1_p9.clone()
                }, then_b_p3x.span_p.clone()), move |unify_arm_f_10340: crate::check::types::St| {
                    let st2_p7 = unify_arm_f_10340;
                    let l1_p8 = Array::from(vec![(layer_head_f(&h1_p6), then_b_p3x.span_p.clone())]);
                    match &else_b_o4x {
                        Some(b_pb) => {
                            let b_pbx = b_pb.clone();
                            crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(else_env_p2x.clone(), st2_p7.clone(), b_pbx.clone()), move |infer_expr_block_f_10526: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t2_pe, st3_pf) = infer_expr_block_f_10526;
                                crate::prelude::call_then(crate::check::types::start_head_sigil_f(st3_pf.clone(), t2_pe.clone()), move |head_sigil_f_10578: Text| {
                                    let h2_pc = head_sigil_f_10578;
                                    crate::prelude::call_then(start_unify_arm_f(st3_pf.clone(), res_p5x.clone(), if crate::check::expr::is_time_sigil_f(&h2_pc) {
                                        crate::check::expr::inner_of_f(&st3_pf, &t2_pe)
                                    } else {
                                        t2_pe.clone()
                                    }, b_pbx.span_p.clone()), move |unify_arm_f_10618: crate::check::types::St| {
                                        let st4_pd = unify_arm_f_10618;
                                        prism_rtl::Turn::Finished((crate::prelude::push(&l1_p8, &(layer_head_f(&h2_pc), b_pbx.span_p.clone())), st4_pd.clone()))
                                    })
                                })
                            })
                        },
                        None => crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p7.clone(), res_p5x.clone(), crate::check::types::t_unit_p(), then_b_p3x.span_p.clone()), move |unify_f_10770: crate::check::types::St| prism_rtl::Turn::Finished((l1_p8.clone(), unify_f_10770))),
                    }
                })
            })
        })
    }
}

/// `Start IfBranches, x`: what the function value is when passed to `@Run`.
pub fn start_if_branches_f(then_env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, else_env_p2: crate::check::expr::Env, then_b_p3: crate::syntax::Block, else_b_o4: Option<crate::syntax::Block>, res_p5: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::syntax::Range)>, crate::check::types::St)>> {
    Rc::new(IfBranches { then_env_p0, st_p1, else_env_p2, then_b_p3, else_b_o4, res_p5 })
}
