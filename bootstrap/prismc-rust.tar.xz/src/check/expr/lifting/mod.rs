//! The module `Check.Expr.Lifting`, from `target/bootstrap/src/prismc/check/expr/lifting.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `ArmWait`:
///
/// ```prism
/// type ArmWait = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ArmWait {
    pub o_p: crate::prelude::Text,
    pub out_p: crate::check::types::Ty,
    pub ty_p: crate::check::types::Ty,
    pub span_p: crate::syntax::Range,
    pub against_o: ::std::option::Option<crate::check::types::Ty>,
    pub fwd_p: bool,
}

impl crate::prelude::Show for ArmWait {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ArmWait", &[("o", &self.o_p), ("out", &self.out_p), ("ty", &self.ty_p), ("span", &self.span_p), ("against", &self.against_o), ("fwd", &self.fwd_p)]);
    }
}

impl crate::prelude::ToPod for ArmWait {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ArmWait", vec![("o", self.o_p.to_pod()), ("out", self.out_p.to_pod()), ("ty", self.ty_p.to_pod()), ("span", self.span_p.to_pod()), ("against", self.against_o.to_pod()), ("fwd", self.fwd_p.to_pod())])
    }
}

impl crate::prelude::FromPod for ArmWait {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ArmWait { o_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "o")?)?, out_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "out")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)?, against_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "against")?)?, fwd_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fwd")?)? })
    }
}

/// ```prism
/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
/// ```
pub fn infer_match_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, scrut_p2: &crate::syntax::Expr, arms_p3: &crate::prelude::Array<crate::syntax::Arm>, span_p4: &crate::syntax::Range, expected_o5: &::std::option::Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    let (st_ty_pe, st1_pf) = crate::check::expr::infer_f(env_p0, st_p1, scrut_p2);
    let sh_p6 = crate::check::types::head_sigil_f(&st1_pf, &st_ty_pe);
    let plain_scrut_p7 = if crate::check::expr::is_time_sigil_f(&sh_p6) {
        crate::check::expr::inner_of_f(&st1_pf, &st_ty_pe)
    } else {
        st_ty_pe.clone()
    };
    let st2_p8 = if &sh_p6 == &crate::prelude::Text::lit("@") {
        crate::check::types::recording::err_f(&st1_pf, &crate::prelude::Text::lit("blueprint-operand"), &scrut_p2.span_p, &crate::prelude::Text::lit("`match` over a blueprint; bind it first"))
    } else {
        st1_pf.clone()
    };
    let rigid_out_o9 = match crate::check::types::recording::walk_f(&st2_p8, &plain_scrut_p7) {
        crate::check::types::Ty::TyElem(_, o_pg) => match crate::check::types::recording::walk_f(&st2_p8, &*o_pg) {
            crate::check::types::Ty::TyRigid(name_ph) => ::std::option::Option::Some(name_ph),
            _ => ::std::option::Option::None,
        },
        _ => ::std::option::Option::None,
    };
    let (res_pi, st3_pj) = crate::check::types::fresh_var_f(&st2_p8, &false, &crate::prelude::Text::lit(""));
    let checking_pa = (expected_o5 != &::std::option::Option::None) && !crate::check::expr::is_time_sigil_f(&sh_p6);
    let scrut_name_pb = crate::check::shrink::locals::expr_name_f(scrut_p2);
    let (layers_pv, st4a_p10, _, waits_p11) = crate::prelude::run_to_end(crate::prelude::fold_job(arms_p3.clone(), (crate::prelude::Array::new(), st3_pj.clone(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
        let env_p0x = env_p0.clone();
        let scrut_name_pbx = scrut_name_pb.clone();
        let plain_scrut_p7x = plain_scrut_p7.clone();
        let res_pix = res_pi.clone();
        let checking_pax = checking_pa;
        let expected_o5x = expected_o5.clone();
        let rigid_out_o9x = rigid_out_o9.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<ArmWait>), crate::syntax::Arm)| {
            let env_p0xy = env_p0x.clone();
            let scrut_name_pbxy = scrut_name_pbx.clone();
            let plain_scrut_p7xy = plain_scrut_p7x.clone();
            let res_pixy = res_pix.clone();
            let checking_paxy = checking_pax;
            let expected_o5xy = expected_o5x.clone();
            let rigid_out_o9xy = rigid_out_o9x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pk, s_pl, taken_pm, ws_pn) = p0;
                let arm_po = p1;
                crate::prelude::call_then(start_narrowed_f(env_p0xy.clone(), s_pl.clone(), arm_po.clone(), scrut_name_pbxy.clone(), plain_scrut_p7xy.clone(), taken_pm.clone()), move |narrowed_f_2393: crate::check::expr::Env| {
                    let env_arm_pp = narrowed_f_2393;
                    crate::prelude::call_then(start_infer_arm_f(env_arm_pp.clone(), s_pl.clone(), arm_po.clone(), plain_scrut_p7xy.clone(), res_pixy.clone(), if checking_paxy { expected_o5xy.clone() } else { ::std::option::Option::None }, rigid_out_o9xy.clone(), acc_pk.clone()), move |infer_arm_f_2478: (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St, ::std::option::Option<ArmWait>)| {
                        let (acc2_pr, s2_ps, wait_ot) = infer_arm_f_2478;
                        let ws2_pq = match &wait_ot {
                            ::std::option::Option::Some(w_pu) => crate::prelude::push(&ws_pn, w_pu),
                            ::std::option::Option::None => ws_pn.clone(),
                        };
                        ::prism_rtl::Turn::Finished((acc2_pr.clone(), s2_ps.clone(), taken_by_f(&env_p0xy, &arm_po, &taken_pm), ws2_pq.clone()))
                    })
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<ArmWait>), crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<ArmWait>)>>>
    }));
    let st4_pc = crate::prelude::run_to_end(crate::prelude::fold_job(waits_p11.clone(), st4a_p10.clone(), {
        let res_pix = res_pi.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, ArmWait)| {
            let res_pixy = res_pix.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p12 = p0;
                let w_p13 = p1;
                match &w_p13.against_o {
                    ::std::option::Option::Some(want_p14) => {
                        let want_p14x = want_p14.clone();
                        crate::prelude::call_then(crate::check::types::recording::start_zonk_f(s_p12.clone(), want_p14x.clone()), move |zonk_f_3032: crate::check::types::Ty| crate::prelude::call_then(start_subst_rigid_f(w_p13.o_p.clone(), w_p13.out_p.clone(), zonk_f_3032), move |subst_rigid_f_3008: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(ArmAgainst { st_p0: s_p12.clone(), want_p1: subst_rigid_f_3008, bt_p2: w_p13.ty_p.clone(), span_p3: w_p13.span_p.clone(), forwards_p4: w_p13.fwd_p }))))
                    },
                    ::std::option::Option::None => crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p12.clone(), res_pixy.clone()), move |walk_f_3087: crate::check::types::Ty| match walk_f_3087 {
                        crate::check::types::Ty::TyFlex(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyArm { st_p0: s_p12.clone(), res_p1: res_pixy.clone(), t_p2: w_p13.ty_p.clone(), span_p3: w_p13.span_p.clone() })),
                        _ => crate::prelude::call_then(crate::check::types::recording::start_zonk_f(s_p12.clone(), res_pixy.clone()), move |zonk_f_3217: crate::check::types::Ty| crate::prelude::call_then(start_subst_rigid_f(w_p13.o_p.clone(), w_p13.out_p.clone(), zonk_f_3217), move |subst_rigid_f_3193: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyArm { st_p0: s_p12.clone(), res_p1: subst_rigid_f_3193, t_p2: w_p13.ty_p.clone(), span_p3: w_p13.span_p.clone() })))),
                    }),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, ArmWait)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }));
    let st5_pd = crate::check::passes::match_coverage_f(env_p0, &st4_pc, &plain_scrut_p7, arms_p3, span_p4);
    match expected_o5 {
        ::std::option::Option::Some(want_p15) => if checking_pa {
            (want_p15.clone(), st5_pd.clone())
        } else {
            match_result_f(env_p0, &st5_pd, &sh_p6, &layers_pv, &res_pi, span_p4)
        },
        ::std::option::Option::None => match_result_f(env_p0, &st5_pd, &sh_p6, &layers_pv, &res_pi, span_p4),
    }
}

/// The step machine of `InferMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
/// ```
pub struct InferMatch {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub scrut_p2: crate::syntax::Expr,
    pub arms_p3: crate::prelude::Array<crate::syntax::Arm>,
    pub span_p4: crate::syntax::Range,
    pub expected_o5: ::std::option::Option<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferMatch {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let scrut_p2 = &self.scrut_p2;
        let arms_p3 = &self.arms_p3;
        let span_p4 = &self.span_p4;
        let expected_o5 = &self.expected_o5;
        let expected_o5x = expected_o5.clone();
        let arms_p3x = arms_p3.clone();
        let env_p0x = env_p0.clone();
        let scrut_p2x = scrut_p2.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), scrut_p2x.clone()), move |infer_f_1698: (crate::check::types::Ty, crate::check::types::St)| {
            let (st_ty_pe, st1_pf) = infer_f_1698;
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pf.clone(), st_ty_pe.clone()), move |head_sigil_f_1732: crate::prelude::Text| {
                let sh_p6 = head_sigil_f_1732;
                let expected_o5xz = expected_o5x.clone();
                let arms_p3xz = arms_p3x.clone();
                let env_p0xz = env_p0x.clone();
                let scrut_p2xz = scrut_p2x.clone();
                let sh_p6z = sh_p6.clone();
                let span_p4xz = span_p4x.clone();
                let st1_pfz = st1_pf.clone();
                let k_let1756 = move |v1756: crate::check::types::Ty| {
                    let plain_scrut_p7 = v1756;
                    let st2_p8 = if &sh_p6z == &crate::prelude::Text::lit("@") {
                        crate::check::types::recording::err_f(&st1_pfz, &crate::prelude::Text::lit("blueprint-operand"), &scrut_p2xz.span_p, &crate::prelude::Text::lit("`match` over a blueprint; bind it first"))
                    } else {
                        st1_pfz.clone()
                    };
                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(st2_p8.clone(), plain_scrut_p7.clone()), move |walk_f_1969: crate::check::types::Ty| {
                        let expected_o5xzz = expected_o5xz.clone();
                        let arms_p3xzz = arms_p3xz.clone();
                        let env_p0xzz = env_p0xz.clone();
                        let plain_scrut_p7z = plain_scrut_p7.clone();
                        let scrut_p2xzz = scrut_p2xz.clone();
                        let sh_p6zz = sh_p6z.clone();
                        let span_p4xzz = span_p4xz.clone();
                        let st2_p8z = st2_p8.clone();
                        let k_let1947 = move |v1947: ::std::option::Option<crate::prelude::Text>| {
                            let rigid_out_o9 = v1947;
                            let (res_pi, st3_pj) = crate::check::types::fresh_var_f(&st2_p8z, &false, &crate::prelude::Text::lit(""));
                            let checking_pa = (&expected_o5xzz != &::std::option::Option::None) && !crate::check::expr::is_time_sigil_f(&sh_p6zz);
                            let scrut_name_pb = crate::check::shrink::locals::expr_name_f(&scrut_p2xzz);
                            crate::prelude::call_value(crate::prelude::fold_job(arms_p3xzz.clone(), (crate::prelude::Array::new(), st3_pj.clone(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
                                let env_p0xzzx = env_p0xzz.clone();
                                let scrut_name_pbx = scrut_name_pb.clone();
                                let plain_scrut_p7zx = plain_scrut_p7z.clone();
                                let res_pix = res_pi.clone();
                                let checking_pax = checking_pa;
                                let expected_o5xzzx = expected_o5xzz.clone();
                                let rigid_out_o9x = rigid_out_o9.clone();
                                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<ArmWait>), crate::syntax::Arm)| {
                                    let env_p0xzzxy = env_p0xzzx.clone();
                                    let scrut_name_pbxy = scrut_name_pbx.clone();
                                    let plain_scrut_p7zxy = plain_scrut_p7zx.clone();
                                    let res_pixy = res_pix.clone();
                                    let checking_paxy = checking_pax;
                                    let expected_o5xzzxy = expected_o5xzzx.clone();
                                    let rigid_out_o9xy = rigid_out_o9x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (acc_pk, s_pl, taken_pm, ws_pn) = p0;
                                        let arm_po = p1;
                                        crate::prelude::call_then(start_narrowed_f(env_p0xzzxy.clone(), s_pl.clone(), arm_po.clone(), scrut_name_pbxy.clone(), plain_scrut_p7zxy.clone(), taken_pm.clone()), move |narrowed_f_2393: crate::check::expr::Env| {
                                            let env_arm_pp = narrowed_f_2393;
                                            crate::prelude::call_then(start_infer_arm_f(env_arm_pp.clone(), s_pl.clone(), arm_po.clone(), plain_scrut_p7zxy.clone(), res_pixy.clone(), if checking_paxy { expected_o5xzzxy.clone() } else { ::std::option::Option::None }, rigid_out_o9xy.clone(), acc_pk.clone()), move |infer_arm_f_2478: (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St, ::std::option::Option<ArmWait>)| {
                                                let (acc2_pr, s2_ps, wait_ot) = infer_arm_f_2478;
                                                let ws2_pq = match &wait_ot {
                                                    ::std::option::Option::Some(w_pu) => crate::prelude::push(&ws_pn, w_pu),
                                                    ::std::option::Option::None => ws_pn.clone(),
                                                };
                                                ::prism_rtl::Turn::Finished((acc2_pr.clone(), s2_ps.clone(), taken_by_f(&env_p0xzzxy, &arm_po, &taken_pm), ws2_pq.clone()))
                                            })
                                        })
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<ArmWait>), crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<ArmWait>)>>>
                            }), move |fold_2304: (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<ArmWait>)| {
                                let (layers_pv, st4a_p10, _, waits_p11) = fold_2304;
                                crate::prelude::call_value(crate::prelude::fold_job(waits_p11.clone(), st4a_p10.clone(), {
                                    let res_pix = res_pi.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, ArmWait)| {
                                        let res_pixy = res_pix.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let s_p12 = p0;
                                            let w_p13 = p1;
                                            match &w_p13.against_o {
                                                ::std::option::Option::Some(want_p14) => {
                                                    let want_p14x = want_p14.clone();
                                                    crate::prelude::call_then(crate::check::types::recording::start_zonk_f(s_p12.clone(), want_p14x.clone()), move |zonk_f_3032: crate::check::types::Ty| crate::prelude::call_then(start_subst_rigid_f(w_p13.o_p.clone(), w_p13.out_p.clone(), zonk_f_3032), move |subst_rigid_f_3008: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(ArmAgainst { st_p0: s_p12.clone(), want_p1: subst_rigid_f_3008, bt_p2: w_p13.ty_p.clone(), span_p3: w_p13.span_p.clone(), forwards_p4: w_p13.fwd_p }))))
                                                },
                                                ::std::option::Option::None => crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p12.clone(), res_pixy.clone()), move |walk_f_3087: crate::check::types::Ty| match walk_f_3087 {
                                                    crate::check::types::Ty::TyFlex(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyArm { st_p0: s_p12.clone(), res_p1: res_pixy.clone(), t_p2: w_p13.ty_p.clone(), span_p3: w_p13.span_p.clone() })),
                                                    _ => crate::prelude::call_then(crate::check::types::recording::start_zonk_f(s_p12.clone(), res_pixy.clone()), move |zonk_f_3217: crate::check::types::Ty| crate::prelude::call_then(start_subst_rigid_f(w_p13.o_p.clone(), w_p13.out_p.clone(), zonk_f_3217), move |subst_rigid_f_3193: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyArm { st_p0: s_p12.clone(), res_p1: subst_rigid_f_3193, t_p2: w_p13.ty_p.clone(), span_p3: w_p13.span_p.clone() })))),
                                                }),
                                            }
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, ArmWait)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                                }), move |fold_2933: crate::check::types::St| {
                                    let st4_pc = fold_2933;
                                    crate::prelude::call_then(crate::check::passes::start_match_coverage_f(env_p0xzz.clone(), st4_pc.clone(), plain_scrut_p7z.clone(), arms_p3xzz.clone(), span_p4xzz.clone()), move |match_coverage_f_3259: crate::check::types::St| {
                                        let st5_pd = match_coverage_f_3259;
                                        match &expected_o5xzz {
                                            ::std::option::Option::Some(want_p15) => if checking_pa {
                                                ::prism_rtl::Turn::Finished((want_p15.clone(), st5_pd.clone()))
                                            } else {
                                                ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchResult { env_p0: env_p0xzz.clone(), st_p1: st5_pd.clone(), sh_p2: sh_p6zz.clone(), layers_p3: layers_pv.clone(), joined_p4: res_pi.clone(), span_p5: span_p4xzz.clone() }))
                                            },
                                            ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchResult { env_p0: env_p0xzz.clone(), st_p1: st5_pd.clone(), sh_p2: sh_p6zz.clone(), layers_p3: layers_pv.clone(), joined_p4: res_pi.clone(), span_p5: span_p4xzz.clone() })),
                                        }
                                    })
                                })
                            })
                        };
                        match walk_f_1969 {
                            crate::check::types::Ty::TyElem(_, o_pg) => crate::prelude::call_then(crate::check::types::recording::start_walk_f(st2_p8.clone(), (*o_pg).clone()), move |walk_f_2023: crate::check::types::Ty| k_let1947(match walk_f_2023 {
                                crate::check::types::Ty::TyRigid(name_ph) => ::std::option::Option::Some(name_ph),
                                _ => ::std::option::Option::None,
                            })),
                            _ => k_let1947(::std::option::Option::None),
                        }
                    })
                };
                if crate::check::expr::is_time_sigil_f(&sh_p6) {
                    crate::prelude::call_then(crate::check::expr::start_inner_of_f(st1_pf.clone(), st_ty_pe.clone()), move |inner_of_f_1792: crate::check::types::Ty| k_let1756(inner_of_f_1792))
                } else {
                    k_let1756(st_ty_pe.clone())
                }
            })
        })
    }
}

/// `Start InferMatch, x`: what the function value is when passed to `@Run`.
pub fn start_infer_match_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, scrut_p2: crate::syntax::Expr, arms_p3: crate::prelude::Array<crate::syntax::Arm>, span_p4: crate::syntax::Range, expected_o5: ::std::option::Option<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferMatch { env_p0, st_p1, scrut_p2, arms_p3, span_p4, expected_o5 })
}

/// ```prism
/// TakenBy: fn Env, Arm, [Text] -> [Text]
/// ```
pub fn taken_by_f(env_p0: &crate::check::expr::Env, arm_p1: &crate::syntax::Arm, taken_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    if &arm_p1.guard_o != &::std::option::Option::None {
        taken_p2.clone()
    } else {
        match &arm_p1.pattern_o {
            ::std::option::Option::Some(p_p3) => match &*p_p3.kind_p {
                crate::syntax::PatternKind::PFamily(q_p4) => crate::check::types::union_texts_f(taken_p2, &crate::prelude::or(&crate::prelude::get(&env_p0.g_p.families_p, &crate::check::env::dotted_f(&q_p4.path_p)), &crate::prelude::Array::new())),
                _ => match tag_of_pattern_o(env_p0, p_p3) {
                    ::std::option::Option::Some(tg_p5) => crate::check::types::add_text_f(taken_p2, &tg_p5.name_p),
                    ::std::option::Option::None => taken_p2.clone(),
                },
            },
            ::std::option::Option::None => taken_p2.clone(),
        }
    }
}

/// ```prism
/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
/// ```
pub fn narrowed_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, arm_p2: &crate::syntax::Arm, name_p3: &crate::prelude::Text, t_p4: &crate::check::types::Ty, taken_p5: &crate::prelude::Array<crate::prelude::Text>) -> crate::check::expr::Env {
    let forwards_p6 = match &arm_p2.pattern_o {
        ::std::option::Option::Some(p_p7) => match &*p_p7.kind_p {
            crate::syntax::PatternKind::PFamily(_) => true,
            _ => false,
        },
        ::std::option::Option::None => true,
    };
    if (!forwards_p6 || (name_p3 == &crate::prelude::Text::lit(""))) || (&crate::prelude::len(taken_p5) == &crate::prelude::Nat::from(0u32)) {
        env_p0.clone()
    } else {
        match crate::check::types::recording::walk_f(st_p1, t_p4) {
            crate::check::types::Ty::TyElem(rw_p8, o_p9) => {
                let w_pa = crate::check::types::recording::walk_row_f(st_p1, &rw_p8);
                crate::check::expr::with_local_f(env_p0, name_p3, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyElem(crate::check::types::Rw { fams_p: w_pa.fams_p.clone(), minus_p: crate::check::types::union_texts_f(&w_pa.minus_p, taken_p5), tail_p: w_pa.tail_p.clone() }, ::std::rc::Rc::new((*o_p9).clone()))))
            },
            _ => env_p0.clone(),
        }
    }
}

/// The step machine of `Narrowed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
/// ```
pub struct Narrowed {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub arm_p2: crate::syntax::Arm,
    pub name_p3: crate::prelude::Text,
    pub t_p4: crate::check::types::Ty,
    pub taken_p5: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::check::expr::Env> for Narrowed {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::expr::Env> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let arm_p2 = &self.arm_p2;
        let name_p3 = &self.name_p3;
        let t_p4 = &self.t_p4;
        let taken_p5 = &self.taken_p5;
        let forwards_p6 = match &arm_p2.pattern_o {
            ::std::option::Option::Some(p_p7) => match &*p_p7.kind_p {
                crate::syntax::PatternKind::PFamily(_) => true,
                _ => false,
            },
            ::std::option::Option::None => true,
        };
        if (!forwards_p6 || (name_p3 == &crate::prelude::Text::lit(""))) || (&crate::prelude::len(taken_p5) == &crate::prelude::Nat::from(0u32)) {
            ::prism_rtl::Turn::Finished(env_p0.clone())
        } else {
            {
                let env_p0x = env_p0.clone();
                let name_p3x = name_p3.clone();
                let st_p1x = st_p1.clone();
                let t_p4x = t_p4.clone();
                let taken_p5x = taken_p5.clone();
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), t_p4x.clone()), move |walk_f_4444: crate::check::types::Ty| match walk_f_4444 {
                    crate::check::types::Ty::TyElem(rw_p8, o_p9) => crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_p8.clone()), move |walk_row_f_4498: crate::check::types::Rw| {
                        let w_pa = walk_row_f_4498;
                        ::prism_rtl::Turn::Finished(crate::check::expr::with_local_f(&env_p0x, &name_p3x, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyElem(crate::check::types::Rw { fams_p: w_pa.fams_p.clone(), minus_p: crate::check::types::union_texts_f(&w_pa.minus_p, &taken_p5x), tail_p: w_pa.tail_p.clone() }, ::std::rc::Rc::new((*o_p9).clone())))))
                    }),
                    _ => ::prism_rtl::Turn::Finished(env_p0x.clone()),
                })
            }
        }
    }
}

/// `Start Narrowed, x`: what the function value is when passed to `@Run`.
pub fn start_narrowed_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, arm_p2: crate::syntax::Arm, name_p3: crate::prelude::Text, t_p4: crate::check::types::Ty, taken_p5: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::expr::Env>> {
    ::std::rc::Rc::new(Narrowed { env_p0, st_p1, arm_p2, name_p3, t_p4, taken_p5 })
}

/// ```prism
/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St, ?ArmWait))
/// ```
pub fn infer_arm_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, arm_p2: &crate::syntax::Arm, scrut_ty_p3: &crate::check::types::Ty, res_p4: &crate::check::types::Ty, expected_o5: &::std::option::Option<crate::check::types::Ty>, rigid_out_o6: &::std::option::Option<crate::prelude::Text>, acc_p7: &crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>) -> (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St, ::std::option::Option<ArmWait>) {
    let (env2_pb, st1_pc) = match &arm_p2.pattern_o {
        ::std::option::Option::Some(p_pa) => crate::check::expr::patterns::bind_pattern_f(env_p0, st_p1, p_pa, scrut_ty_p3, &true),
        ::std::option::Option::None => (env_p0.clone(), st_p1.clone()),
    };
    let refined_out_o8 = match rigid_out_o6 {
        ::std::option::Option::Some(o_pd) => match &arm_p2.pattern_o {
            ::std::option::Option::Some(p_pe) => match tag_of_pattern_o(env_p0, p_pe) {
                ::std::option::Option::Some(tg_pf) => ::std::option::Option::Some((o_pd.clone(), tg_pf.out_p.clone())),
                ::std::option::Option::None => ::std::option::Option::None,
            },
            ::std::option::Option::None => ::std::option::Option::None,
        },
        ::std::option::Option::None => ::std::option::Option::None,
    };
    let st2_p9 = match &arm_p2.guard_o {
        ::std::option::Option::Some(gd_pg) => check_cond_f(&env2_pb, &st1_pc, gd_pg),
        ::std::option::Option::None => st1_pc.clone(),
    };
    match expected_o5 {
        ::std::option::Option::Some(want_ph) => {
            let (bt_pk, st3a_pl) = crate::check::expr::lets::infer_expr_block_f(&env2_pb, &st2_p9, &arm_p2.body_p);
            let st3_pi = crate::check::types::recording::note_fault_at_f(&st3a_pl, &crate::check::types::recording::tail_span_f(&arm_p2.body_p), want_ph, &bt_pk);
            let fwd_pj = (&arm_p2.pattern_o == &::std::option::Option::None) || is_family_arm_f(arm_p2);
            match &refined_out_o8 {
                ::std::option::Option::Some((o_pm, out_pn)) => (acc_p7.clone(), st3_pi.clone(), ::std::option::Option::Some(ArmWait { o_p: o_pm.clone(), out_p: out_pn.clone(), ty_p: bt_pk.clone(), span_p: crate::check::types::recording::result_span_f(&arm_p2.body_p), against_o: ::std::option::Option::Some(want_ph.clone()), fwd_p: fwd_pj })),
                ::std::option::Option::None => (acc_p7.clone(), arm_against_f(&st3_pi, want_ph, &bt_pk, &crate::check::types::recording::result_span_f(&arm_p2.body_p), &fwd_pj), ::std::option::Option::None),
            }
        },
        ::std::option::Option::None => {
            let (bt_pt, st3b_pu) = crate::check::expr::lets::infer_expr_block_f(&env2_pb, &st2_p9, &arm_p2.body_p);
            let st3_po = crate::check::types::recording::note_fault_at_f(&st3b_pu, &crate::check::types::recording::tail_span_f(&arm_p2.body_p), res_p4, &bt_pt);
            let head_pp = crate::check::types::head_sigil_f(&st3_po, &bt_pt);
            let plain_bt_pq = if crate::check::expr::is_time_sigil_f(&head_pp) {
                crate::check::expr::inner_of_f(&st3_po, &bt_pt)
            } else {
                bt_pt.clone()
            };
            let acc2_pr = if crate::check::expr::is_time_sigil_f(&head_pp) {
                crate::prelude::push(acc_p7, &(head_pp.clone(), arm_p2.body_p.span_p.clone()))
            } else {
                crate::prelude::push(acc_p7, &(crate::prelude::Text::lit(""), arm_p2.body_p.span_p.clone()))
            };
            let acc3_ps = if &head_pp == &crate::prelude::Text::lit("@") {
                crate::prelude::push(&acc2_pr, &(crate::prelude::Text::lit("@"), arm_p2.body_p.span_p.clone()))
            } else {
                acc2_pr.clone()
            };
            match &refined_out_o8 {
                ::std::option::Option::Some((o_pv, out_p10)) => (acc3_ps.clone(), st3_po.clone(), ::std::option::Option::Some(ArmWait { o_p: o_pv.clone(), out_p: out_p10.clone(), ty_p: plain_bt_pq.clone(), span_p: crate::check::types::recording::result_span_f(&arm_p2.body_p), against_o: ::std::option::Option::None, fwd_p: false })),
                ::std::option::Option::None => (acc3_ps.clone(), unify_arm_f(&st3_po, res_p4, &plain_bt_pq, &crate::check::types::recording::result_span_f(&arm_p2.body_p)), ::std::option::Option::None),
            }
        },
    }
}

/// The step machine of `InferArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St, ?ArmWait))
/// ```
pub struct InferArm {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub arm_p2: crate::syntax::Arm,
    pub scrut_ty_p3: crate::check::types::Ty,
    pub res_p4: crate::check::types::Ty,
    pub expected_o5: ::std::option::Option<crate::check::types::Ty>,
    pub rigid_out_o6: ::std::option::Option<crate::prelude::Text>,
    pub acc_p7: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>,
}

impl ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St, ::std::option::Option<ArmWait>)> for InferArm {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St, ::std::option::Option<ArmWait>)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let arm_p2 = &self.arm_p2;
        let scrut_ty_p3 = &self.scrut_ty_p3;
        let res_p4 = &self.res_p4;
        let expected_o5 = &self.expected_o5;
        let rigid_out_o6 = &self.rigid_out_o6;
        let acc_p7 = &self.acc_p7;
        let expected_o5z = expected_o5.clone();
        let rigid_out_o6z = rigid_out_o6.clone();
        let acc_p7z = acc_p7.clone();
        let arm_p2z = arm_p2.clone();
        let env_p0z = env_p0.clone();
        let res_p4z = res_p4.clone();
        let k_let5289 = move |v5289: (crate::check::expr::Env, crate::check::types::St)| {
            let (env2_pb, st1_pc) = v5289;
            let refined_out_o8 = match &rigid_out_o6z {
                ::std::option::Option::Some(o_pd) => match &arm_p2z.pattern_o {
                    ::std::option::Option::Some(p_pe) => match tag_of_pattern_o(&env_p0z, p_pe) {
                        ::std::option::Option::Some(tg_pf) => ::std::option::Option::Some((o_pd.clone(), tg_pf.out_p.clone())),
                        ::std::option::Option::None => ::std::option::Option::None,
                    },
                    ::std::option::Option::None => ::std::option::Option::None,
                },
                ::std::option::Option::None => ::std::option::Option::None,
            };
            let expected_o5zz = expected_o5z.clone();
            let refined_out_o8z = refined_out_o8.clone();
            let acc_p7zz = acc_p7z.clone();
            let arm_p2zz = arm_p2z.clone();
            let env2_pbz = env2_pb.clone();
            let res_p4zz = res_p4z.clone();
            let k_let5627 = move |v5627: crate::check::types::St| {
                let st2_p9 = v5627;
                match &expected_o5zz {
                    ::std::option::Option::Some(want_ph) => {
                        let want_phx = want_ph.clone();
                        crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(env2_pbz.clone(), st2_p9.clone(), arm_p2zz.body_p.clone()), move |infer_expr_block_f_5778: (crate::check::types::Ty, crate::check::types::St)| {
                            let (bt_pk, st3a_pl) = infer_expr_block_f_5778;
                            crate::prelude::call_then(crate::check::types::recording::start_note_fault_at_f(st3a_pl.clone(), crate::check::types::recording::tail_span_f(&arm_p2zz.body_p), want_phx.clone(), bt_pk.clone()), move |note_fault_at_f_5835: crate::check::types::St| {
                                let st3_pi = note_fault_at_f_5835;
                                let fwd_pj = (&arm_p2zz.pattern_o == &::std::option::Option::None) || is_family_arm_f(&arm_p2zz);
                                match &refined_out_o8z {
                                    ::std::option::Option::Some((o_pm, out_pn)) => ::prism_rtl::Turn::Finished((acc_p7zz.clone(), st3_pi.clone(), ::std::option::Option::Some(ArmWait { o_p: o_pm.clone(), out_p: out_pn.clone(), ty_p: bt_pk.clone(), span_p: crate::check::types::recording::result_span_f(&arm_p2zz.body_p), against_o: ::std::option::Option::Some(want_phx.clone()), fwd_p: fwd_pj }))),
                                    ::std::option::Option::None => crate::prelude::call_then(start_arm_against_f(st3_pi.clone(), want_phx.clone(), bt_pk.clone(), crate::check::types::recording::result_span_f(&arm_p2zz.body_p), fwd_pj), move |arm_against_f_6139: crate::check::types::St| ::prism_rtl::Turn::Finished((acc_p7zz.clone(), arm_against_f_6139, ::std::option::Option::None))),
                                }
                            })
                        })
                    },
                    ::std::option::Option::None => crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(env2_pbz.clone(), st2_p9.clone(), arm_p2zz.body_p.clone()), move |infer_expr_block_f_6244: (crate::check::types::Ty, crate::check::types::St)| {
                        let (bt_pt, st3b_pu) = infer_expr_block_f_6244;
                        crate::prelude::call_then(crate::check::types::recording::start_note_fault_at_f(st3b_pu.clone(), crate::check::types::recording::tail_span_f(&arm_p2zz.body_p), res_p4zz.clone(), bt_pt.clone()), move |note_fault_at_f_6301: crate::check::types::St| {
                            let st3_po = note_fault_at_f_6301;
                            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st3_po.clone(), bt_pt.clone()), move |head_sigil_f_6371: crate::prelude::Text| {
                                let head_pp = head_sigil_f_6371;
                                let refined_out_o8zz = refined_out_o8z.clone();
                                let acc_p7zzz = acc_p7zz.clone();
                                let arm_p2zzz = arm_p2zz.clone();
                                let head_ppz = head_pp.clone();
                                let res_p4zzz = res_p4zz.clone();
                                let st3_poz = st3_po.clone();
                                let k_let6401 = move |v6401: crate::check::types::Ty| {
                                    let plain_bt_pq = v6401;
                                    let acc2_pr = if crate::check::expr::is_time_sigil_f(&head_ppz) {
                                        crate::prelude::push(&acc_p7zzz, &(head_ppz.clone(), arm_p2zzz.body_p.span_p.clone()))
                                    } else {
                                        crate::prelude::push(&acc_p7zzz, &(crate::prelude::Text::lit(""), arm_p2zzz.body_p.span_p.clone()))
                                    };
                                    let acc3_ps = if &head_ppz == &crate::prelude::Text::lit("@") {
                                        crate::prelude::push(&acc2_pr, &(crate::prelude::Text::lit("@"), arm_p2zzz.body_p.span_p.clone()))
                                    } else {
                                        acc2_pr.clone()
                                    };
                                    match &refined_out_o8zz {
                                        ::std::option::Option::Some((o_pv, out_p10)) => ::prism_rtl::Turn::Finished((acc3_ps.clone(), st3_poz.clone(), ::std::option::Option::Some(ArmWait { o_p: o_pv.clone(), out_p: out_p10.clone(), ty_p: plain_bt_pq.clone(), span_p: crate::check::types::recording::result_span_f(&arm_p2zzz.body_p), against_o: ::std::option::Option::None, fwd_p: false }))),
                                        ::std::option::Option::None => crate::prelude::call_then(start_unify_arm_f(st3_poz.clone(), res_p4zzz.clone(), plain_bt_pq.clone(), crate::check::types::recording::result_span_f(&arm_p2zzz.body_p)), move |unify_arm_f_6858: crate::check::types::St| ::prism_rtl::Turn::Finished((acc3_ps.clone(), unify_arm_f_6858, ::std::option::Option::None))),
                                    }
                                };
                                if crate::check::expr::is_time_sigil_f(&head_pp) {
                                    crate::prelude::call_then(crate::check::expr::start_inner_of_f(st3_po.clone(), bt_pt.clone()), move |inner_of_f_6436: crate::check::types::Ty| k_let6401(inner_of_f_6436))
                                } else {
                                    k_let6401(bt_pt.clone())
                                }
                            })
                        })
                    }),
                }
            };
            match arm_p2z.guard_o.clone() {
                ::std::option::Option::Some(gd_pg) => crate::prelude::call_then(start_check_cond_f(env2_pb.clone(), st1_pc.clone(), gd_pg.clone()), move |check_cond_f_5669: crate::check::types::St| k_let5627(check_cond_f_5669)),
                ::std::option::Option::None => k_let5627(st1_pc.clone()),
            }
        };
        match arm_p2.pattern_o.clone() {
            ::std::option::Option::Some(p_pa) => {
                let env_p0x = env_p0.clone();
                let scrut_ty_p3x = scrut_ty_p3.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p0x.clone(), st_p1x.clone(), p_pa.clone(), scrut_ty_p3x.clone(), true), move |bind_pattern_f_5342: (crate::check::expr::Env, crate::check::types::St)| k_let5289(bind_pattern_f_5342))
            },
            ::std::option::Option::None => k_let5289((env_p0.clone(), st_p1.clone())),
        }
    }
}

/// `Start InferArm, x`: what the function value is when passed to `@Run`.
pub fn start_infer_arm_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, arm_p2: crate::syntax::Arm, scrut_ty_p3: crate::check::types::Ty, res_p4: crate::check::types::Ty, expected_o5: ::std::option::Option<crate::check::types::Ty>, rigid_out_o6: ::std::option::Option<crate::prelude::Text>, acc_p7: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St, ::std::option::Option<ArmWait>)>> {
    ::std::rc::Rc::new(InferArm { env_p0, st_p1, arm_p2, scrut_ty_p3, res_p4, expected_o5, rigid_out_o6, acc_p7 })
}

/// ```prism
/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
/// ```
pub fn arm_against_f(st_p0: &crate::check::types::St, want_p1: &crate::check::types::Ty, bt_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range, forwards_p4: &bool) -> crate::check::types::St {
    match (crate::check::types::recording::walk_f(st_p0, want_p1), crate::check::types::recording::walk_f(st_p0, bt_p2)) {
        (crate::check::types::Ty::TyAt(w1_p5, r1_p6), crate::check::types::Ty::TyAt(b1_p7, r2_p8)) => {
            let st2_p9 = crate::check::types::unify::unify_f(st_p0, &*w1_p5, &*b1_p7, span_p3);
            {
                let mut this: crate::check::types::St = st2_p9.clone();
                this.incls_p = crate::prelude::push(&this.incls_p, &crate::check::types::Incl { sub_p: r2_p8, sup_p: r1_p6, file_p: this.file_p.clone(), span_p: span_p3.clone(), what_p: crate::prelude::Text::lit("arm"), forward_p: *forwards_p4 });
                this
            }
        },
        _ => crate::check::types::recording::unify_noted_f(st_p0, want_p1, bt_p2, span_p3),
    }
}

/// The step machine of `ArmAgainst`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
/// ```
pub struct ArmAgainst {
    pub st_p0: crate::check::types::St,
    pub want_p1: crate::check::types::Ty,
    pub bt_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
    pub forwards_p4: bool,
}

impl ::prism_rtl::Job<crate::check::types::St> for ArmAgainst {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let want_p1 = &self.want_p1;
        let bt_p2 = &self.bt_p2;
        let span_p3 = &self.span_p3;
        let forwards_p4 = &self.forwards_p4;
        let bt_p2x = bt_p2.clone();
        let forwards_p4x = *forwards_p4;
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        let want_p1x = want_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), want_p1x.clone()), move |walk_f_7202: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), bt_p2x.clone()), move |walk_f_7219: crate::check::types::Ty| match (walk_f_7202, walk_f_7219) {
            (crate::check::types::Ty::TyAt(w1_p5, r1_p6), crate::check::types::Ty::TyAt(b1_p7, r2_p8)) => crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p0x.clone(), (*w1_p5).clone(), (*b1_p7).clone(), span_p3x.clone()), move |unify_f_7291: crate::check::types::St| {
                let st2_p9 = unify_f_7291;
                ::prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = st2_p9.clone();
                    this.incls_p = crate::prelude::push(&this.incls_p, &crate::check::types::Incl { sub_p: r2_p8.clone(), sup_p: r1_p6.clone(), file_p: this.file_p.clone(), span_p: span_p3x.clone(), what_p: crate::prelude::Text::lit("arm"), forward_p: forwards_p4x });
                    this
                })
            }),
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::recording::UnifyNoted { st_p0: st_p0x.clone(), expected_p1: want_p1x.clone(), found_p2: bt_p2x.clone(), span_p3: span_p3x.clone() })),
        }))
    }
}

/// `Start ArmAgainst, x`: what the function value is when passed to `@Run`.
pub fn start_arm_against_f(st_p0: crate::check::types::St, want_p1: crate::check::types::Ty, bt_p2: crate::check::types::Ty, span_p3: crate::syntax::Range, forwards_p4: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(ArmAgainst { st_p0, want_p1, bt_p2, span_p3, forwards_p4 })
}

/// ```prism
/// IsFamilyArm: fn Arm -> Bool
/// ```
pub fn is_family_arm_f(arm_p0: &crate::syntax::Arm) -> bool {
    match &arm_p0.pattern_o {
        ::std::option::Option::Some(p_p1) => match &*p_p1.kind_p {
            crate::syntax::PatternKind::PFamily(_) => true,
            _ => false,
        },
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// CheckCond: unbounded fn Env, St, Expr -> St
/// ```
pub fn check_cond_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> crate::check::types::St {
    let (t_p4, st2_p5) = crate::check::expr::infer_f(env_p0, st_p1, e_p2);
    let inner_p3 = if crate::check::expr::is_time_sigil_f(&crate::check::types::head_sigil_f(&st2_p5, &t_p4)) {
        crate::check::expr::inner_of_f(&st2_p5, &t_p4)
    } else {
        t_p4.clone()
    };
    crate::check::types::unify::unify_f(&st2_p5, &crate::check::types::t_bool_p(), &inner_p3, &e_p2.span_p)
}

/// The step machine of `CheckCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckCond: unbounded fn Env, St, Expr -> St
/// ```
pub struct CheckCond {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::check::types::St> for CheckCond {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let e_p2x = e_p2.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone()), move |infer_f_7833: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p4, st2_p5) = infer_f_7833;
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st2_p5.clone(), t_p4.clone()), move |head_sigil_f_7882: crate::prelude::Text| {
                let e_p2xz = e_p2x.clone();
                let st2_p5z = st2_p5.clone();
                let k_let7854 = move |v7854: crate::check::types::Ty| {
                    let inner_p3 = v7854;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st2_p5z.clone(), expected_p1: crate::check::types::t_bool_p(), found_p2: inner_p3.clone(), span_p3: e_p2xz.span_p.clone() }))
                };
                if crate::check::expr::is_time_sigil_f(&head_sigil_f_7882) {
                    crate::prelude::call_then(crate::check::expr::start_inner_of_f(st2_p5.clone(), t_p4.clone()), move |inner_of_f_7901: crate::check::types::Ty| k_let7854(inner_of_f_7901))
                } else {
                    k_let7854(t_p4.clone())
                }
            })
        })
    }
}

/// `Start CheckCond, x`: what the function value is when passed to `@Run`.
pub fn start_check_cond_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CheckCond { env_p0, st_p1, e_p2 })
}

/// ```prism
/// ?TagOfPattern: fn Env, Pattern -> ?TagInfo
/// ```
pub fn tag_of_pattern_o(env_p0: &crate::check::expr::Env, p_p1: &crate::syntax::Pattern) -> ::std::option::Option<crate::check::env::TagInfo> {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PRecord(n_p2, _, _) => crate::prelude::get(&env_p0.g_p.tags_p, &crate::check::env::dotted_f(&n_p2.path_p)),
        crate::syntax::PatternKind::PCtor(n_p3, _) => crate::prelude::get(&env_p0.g_p.tags_p, &crate::check::env::dotted_f(&n_p3.path_p)),
        crate::syntax::PatternKind::PName(n_p4) => crate::prelude::get(&env_p0.g_p.tags_p, &crate::check::env::dotted_f(&n_p4.path_p)),
        crate::syntax::PatternKind::PGroup(q_p5) => tag_of_pattern_o(env_p0, &**q_p5),
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
/// ```
pub fn subst_rigid_f(name_p0: &crate::prelude::Text, by_p1: &crate::check::types::Ty, t_p2: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p2 {
        crate::check::types::Ty::TyRigid(n_p3) => if n_p3 == name_p0 { by_p1.clone() } else { t_p2.clone() },
        crate::check::types::Ty::TyCon(n_p4, args_p5) => crate::check::types::Ty::TyCon(n_p4.clone(), crate::prelude::run_to_end(crate::prelude::each_job(args_p5.clone(), {
            let name_p0x = name_p0.clone();
            let by_p1x = by_p1.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let name_p0xy = name_p0x.clone();
                let by_p1xy = by_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p6 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstRigid { name_p0: name_p0xy.clone(), by_p1: by_p1xy.clone(), t_p2: a_p6.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c_p7, ps_p8, r_p9) => crate::check::types::Ty::TyFn(c_p7.clone(), crate::prelude::run_to_end(crate::prelude::each_job(ps_p8.clone(), {
            let name_p0x = name_p0.clone();
            let by_p1x = by_p1.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let name_p0xy = name_p0x.clone();
                let by_p1xy = by_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pa = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstRigid { name_p0: name_p0xy.clone(), by_p1: by_p1xy.clone(), t_p2: a_pa.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        })), ::std::rc::Rc::new(subst_rigid_f(name_p0, by_p1, &**r_p9))),
        crate::check::types::Ty::TyTuple(ts_pb) => crate::check::types::Ty::TyTuple(crate::prelude::run_to_end(crate::prelude::each_job(ts_pb.clone(), {
            let name_p0x = name_p0.clone();
            let by_p1x = by_p1.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let name_p0xy = name_p0x.clone();
                let by_p1xy = by_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pc = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstRigid { name_p0: name_p0xy.clone(), by_p1: by_p1xy.clone(), t_p2: a_pc.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e_pd) => crate::check::types::Ty::TyArray(::std::rc::Rc::new(subst_rigid_f(name_p0, by_p1, &**e_pd))),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => crate::check::types::Ty::TyMap(::std::rc::Rc::new(subst_rigid_f(name_p0, by_p1, &**k_pe)), ::std::rc::Rc::new(subst_rigid_f(name_p0, by_p1, &**v_pf))),
        crate::check::types::Ty::TySig(s_pg, i_ph) => crate::check::types::Ty::TySig(s_pg.clone(), ::std::rc::Rc::new(subst_rigid_f(name_p0, by_p1, &**i_ph))),
        crate::check::types::Ty::TyAt(i_pi, rw_pj) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(subst_rigid_f(name_p0, by_p1, &**i_pi)), rw_pj.clone()),
        crate::check::types::Ty::TyElem(rw_pk, o_pl) => crate::check::types::Ty::TyElem(rw_pk.clone(), ::std::rc::Rc::new(subst_rigid_f(name_p0, by_p1, &**o_pl))),
        other_pm => other_pm.clone(),
    }
}

/// The step machine of `SubstRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
/// ```
pub struct SubstRigid {
    pub name_p0: crate::prelude::Text,
    pub by_p1: crate::check::types::Ty,
    pub t_p2: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for SubstRigid {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let name_p0 = &self.name_p0;
        let by_p1 = &self.by_p1;
        let t_p2 = &self.t_p2;
        match t_p2 {
            crate::check::types::Ty::TyRigid(n_p3) => if n_p3 == name_p0 {
                ::prism_rtl::Turn::Finished(by_p1.clone())
            } else {
                ::prism_rtl::Turn::Finished(t_p2.clone())
            },
            crate::check::types::Ty::TyCon(n_p4, args_p5) => {
                let args_p5x = args_p5.clone();
                let by_p1x = by_p1.clone();
                let n_p4x = n_p4.clone();
                let name_p0x = name_p0.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p5x.clone(), {
                    let name_p0xx = name_p0x.clone();
                    let by_p1xx = by_p1x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let name_p0xxy = name_p0xx.clone();
                        let by_p1xxy = by_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p6 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstRigid { name_p0: name_p0xxy.clone(), by_p1: by_p1xxy.clone(), t_p2: a_p6.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_8469: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p4x.clone(), each_8469)))
            },
            crate::check::types::Ty::TyFn(c_p7, ps_p8, r_p9) => {
                let by_p1x = by_p1.clone();
                let c_p7x = c_p7.clone();
                let name_p0x = name_p0.clone();
                let ps_p8x = ps_p8.clone();
                let r_p9x = (**r_p9).clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_p8x.clone(), {
                    let name_p0xx = name_p0x.clone();
                    let by_p1xx = by_p1x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let name_p0xxy = name_p0xx.clone();
                        let by_p1xxy = by_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pa = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstRigid { name_p0: name_p0xxy.clone(), by_p1: by_p1xxy.clone(), t_p2: a_pa.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_8537: crate::prelude::Array<crate::check::types::Ty>| crate::prelude::call_then(start_subst_rigid_f(name_p0x.clone(), by_p1x.clone(), r_p9x.clone()), move |subst_rigid_f_8577: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c_p7x.clone(), each_8537, ::std::rc::Rc::new(subst_rigid_f_8577)))))
            },
            crate::check::types::Ty::TyTuple(ts_pb) => {
                let by_p1x = by_p1.clone();
                let name_p0x = name_p0.clone();
                let ts_pbx = ts_pb.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_pbx.clone(), {
                    let name_p0xx = name_p0x.clone();
                    let by_p1xx = by_p1x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let name_p0xxy = name_p0xx.clone();
                        let by_p1xxy = by_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pc = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstRigid { name_p0: name_p0xxy.clone(), by_p1: by_p1xxy.clone(), t_p2: a_pc.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_8626: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_8626)))
            },
            crate::check::types::Ty::TyArray(e_pd) => {
                let by_p1x = by_p1.clone();
                let e_pdx = (**e_pd).clone();
                let name_p0x = name_p0.clone();
                crate::prelude::call_then(start_subst_rigid_f(name_p0x.clone(), by_p1x.clone(), e_pdx.clone()), move |subst_rigid_f_8688: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(::std::rc::Rc::new(subst_rigid_f_8688))))
            },
            crate::check::types::Ty::TyMap(k_pe, v_pf) => {
                let by_p1x = by_p1.clone();
                let k_pex = (**k_pe).clone();
                let name_p0x = name_p0.clone();
                let v_pfx = (**v_pf).clone();
                crate::prelude::call_then(start_subst_rigid_f(name_p0x.clone(), by_p1x.clone(), k_pex.clone()), move |subst_rigid_f_8735: crate::check::types::Ty| crate::prelude::call_then(start_subst_rigid_f(name_p0x.clone(), by_p1x.clone(), v_pfx.clone()), move |subst_rigid_f_8761: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(::std::rc::Rc::new(subst_rigid_f_8735), ::std::rc::Rc::new(subst_rigid_f_8761)))))
            },
            crate::check::types::Ty::TySig(s_pg, i_ph) => {
                let by_p1x = by_p1.clone();
                let i_phx = (**i_ph).clone();
                let name_p0x = name_p0.clone();
                let s_pgx = s_pg.clone();
                crate::prelude::call_then(start_subst_rigid_f(name_p0x.clone(), by_p1x.clone(), i_phx.clone()), move |subst_rigid_f_8811: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pgx.clone(), ::std::rc::Rc::new(subst_rigid_f_8811))))
            },
            crate::check::types::Ty::TyAt(i_pi, rw_pj) => {
                let by_p1x = by_p1.clone();
                let i_pix = (**i_pi).clone();
                let name_p0x = name_p0.clone();
                let rw_pjx = rw_pj.clone();
                crate::prelude::call_then(start_subst_rigid_f(name_p0x.clone(), by_p1x.clone(), i_pix.clone()), move |subst_rigid_f_8857: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(::std::rc::Rc::new(subst_rigid_f_8857), rw_pjx.clone())))
            },
            crate::check::types::Ty::TyElem(rw_pk, o_pl) => {
                let by_p1x = by_p1.clone();
                let name_p0x = name_p0.clone();
                let o_plx = (**o_pl).clone();
                let rw_pkx = rw_pk.clone();
                crate::prelude::call_then(start_subst_rigid_f(name_p0x.clone(), by_p1x.clone(), o_plx.clone()), move |subst_rigid_f_8915: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(rw_pkx.clone(), ::std::rc::Rc::new(subst_rigid_f_8915))))
            },
            other_pm => ::prism_rtl::Turn::Finished(other_pm.clone()),
        }
    }
}

/// `Start SubstRigid, x`: what the function value is when passed to `@Run`.
pub fn start_subst_rigid_f(name_p0: crate::prelude::Text, by_p1: crate::check::types::Ty, t_p2: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(SubstRigid { name_p0, by_p1, t_p2 })
}

/// ```prism
/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
/// ```
pub fn match_result_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, sh_p2: &crate::prelude::Text, layers_p3: &crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, joined_p4: &crate::check::types::Ty, span_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let res_p6 = arm_result_f(st_p1, joined_p4);
    let events_p7 = crate::prelude::filter(layers_p3, &(|(h_pc, _): &(crate::prelude::Text, crate::syntax::Range)| h_pc == &crate::prelude::Text::lit("!")));
    let dyns_p8 = crate::prelude::filter(layers_p3, &(|(h_pd, _): &(crate::prelude::Text, crate::syntax::Range)| h_pd == &crate::prelude::Text::lit("$")));
    let blue_p9 = crate::prelude::filter(layers_p3, &(|(h_pe, _): &(crate::prelude::Text, crate::syntax::Range)| h_pe == &crate::prelude::Text::lit("@")));
    let st2_pa = if (&crate::prelude::len(&blue_p9) > &crate::prelude::Nat::from(0u32)) && crate::check::expr::is_time_sigil_f(sh_p2) {
        crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("building-match"), span_p5, &crate::prelude::Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &crate::prelude::Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
    } else {
        st_p1.clone()
    };
    let st3_pb = if (sh_p2 == &crate::prelude::Text::lit("!")) && (&crate::prelude::len(&events_p7) > &crate::prelude::Nat::from(0u32)) {
        crate::check::types::recording::err_fix_f(&st2_pa, &crate::prelude::Text::lit("two-events"), span_p5, &crate::prelude::Text::lit("two events in one operation"), &crate::prelude::Text::lit("an arm over an event\'s scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
    } else {
        st2_pa.clone()
    };
    if &crate::prelude::len(&events_p7) > &crate::prelude::Nat::from(0u32) {
        (crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(res_p6.clone())), crate::check::expr::calls::elab_f(&st3_pb, span_p5, &crate::prelude::Text::lit("match"), &crate::prelude::Text::lit("gate"), &crate::prelude::Text::lit("!")))
    } else {
        if (sh_p2 == &crate::prelude::Text::lit("$")) || (&crate::prelude::len(&dyns_p8) > &crate::prelude::Nat::from(0u32)) {
            (crate::check::types::Ty::TySig(crate::prelude::Text::lit("$"), ::std::rc::Rc::new(res_p6.clone())), crate::check::expr::calls::elab_f(&st3_pb, span_p5, &crate::prelude::Text::lit("match"), &crate::prelude::Text::lit("map"), &crate::prelude::Text::lit("$")))
        } else {
            if sh_p2 == &crate::prelude::Text::lit("!") {
                (crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(res_p6.clone())), crate::check::expr::calls::elab_f(&st3_pb, span_p5, &crate::prelude::Text::lit("match"), &crate::prelude::Text::lit("map"), &crate::prelude::Text::lit("!")))
            } else {
                (res_p6.clone(), st3_pb.clone())
            }
        }
    }
}

/// The step machine of `MatchResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
/// ```
pub struct MatchResult {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub sh_p2: crate::prelude::Text,
    pub layers_p3: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>,
    pub joined_p4: crate::check::types::Ty,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for MatchResult {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let sh_p2 = &self.sh_p2;
        let layers_p3 = &self.layers_p3;
        let joined_p4 = &self.joined_p4;
        let span_p5 = &self.span_p5;
        let joined_p4x = joined_p4.clone();
        let layers_p3x = layers_p3.clone();
        let sh_p2x = sh_p2.clone();
        let span_p5x = span_p5.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_arm_result_f(st_p1x.clone(), joined_p4x.clone()), move |arm_result_f_9105: crate::check::types::Ty| {
            let res_p6 = arm_result_f_9105;
            let events_p7 = crate::prelude::filter(&layers_p3x, &(|(h_pc, _): &(crate::prelude::Text, crate::syntax::Range)| h_pc == &crate::prelude::Text::lit("!")));
            let dyns_p8 = crate::prelude::filter(&layers_p3x, &(|(h_pd, _): &(crate::prelude::Text, crate::syntax::Range)| h_pd == &crate::prelude::Text::lit("$")));
            let blue_p9 = crate::prelude::filter(&layers_p3x, &(|(h_pe, _): &(crate::prelude::Text, crate::syntax::Range)| h_pe == &crate::prelude::Text::lit("@")));
            let st2_pa = if (&crate::prelude::len(&blue_p9) > &crate::prelude::Nat::from(0u32)) && crate::check::expr::is_time_sigil_f(&sh_p2x) {
                crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("building-match"), &span_p5x, &crate::prelude::Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &crate::prelude::Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
            } else {
                st_p1x.clone()
            };
            let st3_pb = if (&sh_p2x == &crate::prelude::Text::lit("!")) && (&crate::prelude::len(&events_p7) > &crate::prelude::Nat::from(0u32)) {
                crate::check::types::recording::err_fix_f(&st2_pa, &crate::prelude::Text::lit("two-events"), &span_p5x, &crate::prelude::Text::lit("two events in one operation"), &crate::prelude::Text::lit("an arm over an event\'s scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
            } else {
                st2_pa.clone()
            };
            if &crate::prelude::len(&events_p7) > &crate::prelude::Nat::from(0u32) {
                ::prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(res_p6.clone())), crate::check::expr::calls::elab_f(&st3_pb, &span_p5x, &crate::prelude::Text::lit("match"), &crate::prelude::Text::lit("gate"), &crate::prelude::Text::lit("!"))))
            } else {
                if (&sh_p2x == &crate::prelude::Text::lit("$")) || (&crate::prelude::len(&dyns_p8) > &crate::prelude::Nat::from(0u32)) {
                    ::prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(crate::prelude::Text::lit("$"), ::std::rc::Rc::new(res_p6.clone())), crate::check::expr::calls::elab_f(&st3_pb, &span_p5x, &crate::prelude::Text::lit("match"), &crate::prelude::Text::lit("map"), &crate::prelude::Text::lit("$"))))
                } else {
                    if &sh_p2x == &crate::prelude::Text::lit("!") {
                        ::prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(res_p6.clone())), crate::check::expr::calls::elab_f(&st3_pb, &span_p5x, &crate::prelude::Text::lit("match"), &crate::prelude::Text::lit("map"), &crate::prelude::Text::lit("!"))))
                    } else {
                        ::prism_rtl::Turn::Finished((res_p6.clone(), st3_pb.clone()))
                    }
                }
            }
        })
    }
}

/// `Start MatchResult, x`: what the function value is when passed to `@Run`.
pub fn start_match_result_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, sh_p2: crate::prelude::Text, layers_p3: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, joined_p4: crate::check::types::Ty, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(MatchResult { env_p0, st_p1, sh_p2, layers_p3, joined_p4, span_p5 })
}

/// ```prism
/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
/// ```
pub fn infer_if_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::syntax::Cond, then_b_p3: &crate::syntax::Block, else_b_o4: &::std::option::Option<crate::syntax::Block>, span_p5: &crate::syntax::Range, expected_o6: &::std::option::Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    match c_p2 {
        crate::syntax::Cond::CondExpr(e_p7) => {
            let (ct_pb, st1_pc) = crate::check::expr::infer_f(env_p0, st_p1, &**e_p7);
            let sh_p8 = crate::check::types::head_sigil_f(&st1_pc, &ct_pb);
            let inner_p9 = if crate::check::expr::is_time_sigil_f(&sh_p8) {
                crate::check::expr::inner_of_f(&st1_pc, &ct_pb)
            } else {
                ct_pb.clone()
            };
            let st2_pa = crate::check::types::unify::unify_f(&st1_pc, &crate::check::types::t_bool_p(), &inner_p9, &e_p7.span_p);
            let (res_pd, st3_pe) = crate::check::types::fresh_var_f(&st2_pa, &false, &crate::prelude::Text::lit(""));
            let (layers_pf, st4_pg) = if_branches_f(env_p0, &st3_pe, env_p0, then_b_p3, else_b_o4, &res_pd);
            match_result_f(env_p0, &no_else_f(&st4_pg, else_b_o4, span_p5), &sh_p8, &layers_pf, &res_pd, span_p5)
        },
        crate::syntax::Cond::CondBind(p_ph, e_pi, gd_oj) => {
            let (et_pl, st1_pm) = crate::check::expr::infer_f(env_p0, st_p1, &**e_pi);
            let (env2_pn, st2_po) = crate::check::expr::patterns::bind_pattern_f(env_p0, &st1_pm, p_ph, &et_pl, &true);
            let st3_pk = match &**gd_oj {
                ::std::option::Option::Some(g_pp) => check_cond_f(&env2_pn, &st2_po, g_pp),
                ::std::option::Option::None => st2_po.clone(),
            };
            let (res_pq, st4_pr) = crate::check::types::fresh_var_f(&st3_pk, &false, &crate::prelude::Text::lit(""));
            let (layers_ps, st5_pt) = if_branches_f(&env2_pn, &st4_pr, env_p0, then_b_p3, else_b_o4, &res_pq);
            match_result_f(env_p0, &no_else_f(&st5_pt, else_b_o4, span_p5), &crate::prelude::Text::lit(""), &layers_ps, &res_pq, span_p5)
        },
    }
}

/// The step machine of `InferIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
/// ```
pub struct InferIf {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::syntax::Cond,
    pub then_b_p3: crate::syntax::Block,
    pub else_b_o4: ::std::option::Option<crate::syntax::Block>,
    pub span_p5: crate::syntax::Range,
    pub expected_o6: ::std::option::Option<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferIf {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let then_b_p3 = &self.then_b_p3;
        let else_b_o4 = &self.else_b_o4;
        let span_p5 = &self.span_p5;
        let expected_o6 = &self.expected_o6;
        match c_p2 {
            crate::syntax::Cond::CondExpr(e_p7) => {
                let else_b_o4x = else_b_o4.clone();
                let e_p7x = (**e_p7).clone();
                let env_p0x = env_p0.clone();
                let span_p5x = span_p5.clone();
                let st_p1x = st_p1.clone();
                let then_b_p3x = then_b_p3.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_p7x.clone()), move |infer_f_10286: (crate::check::types::Ty, crate::check::types::St)| {
                    let (ct_pb, st1_pc) = infer_f_10286;
                    crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pc.clone(), ct_pb.clone()), move |head_sigil_f_10320: crate::prelude::Text| {
                        let sh_p8 = head_sigil_f_10320;
                        let else_b_o4xz = else_b_o4x.clone();
                        let e_p7xz = e_p7x.clone();
                        let env_p0xz = env_p0x.clone();
                        let sh_p8z = sh_p8.clone();
                        let span_p5xz = span_p5x.clone();
                        let st1_pcz = st1_pc.clone();
                        let then_b_p3xz = then_b_p3x.clone();
                        let k_let10346 = move |v10346: crate::check::types::Ty| {
                            let inner_p9 = v10346;
                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(st1_pcz.clone(), crate::check::types::t_bool_p(), inner_p9.clone(), e_p7xz.span_p.clone()), move |unify_f_10420: crate::check::types::St| {
                                let st2_pa = unify_f_10420;
                                let (res_pd, st3_pe) = crate::check::types::fresh_var_f(&st2_pa, &false, &crate::prelude::Text::lit(""));
                                crate::prelude::call_then(start_if_branches_f(env_p0xz.clone(), st3_pe.clone(), env_p0xz.clone(), then_b_p3xz.clone(), else_b_o4xz.clone(), res_pd.clone()), move |if_branches_f_10533: (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St)| {
                                    let (layers_pf, st4_pg) = if_branches_f_10533;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchResult { env_p0: env_p0xz.clone(), st_p1: no_else_f(&st4_pg, &else_b_o4xz, &span_p5xz), sh_p2: sh_p8z.clone(), layers_p3: layers_pf.clone(), joined_p4: res_pd.clone(), span_p5: span_p5xz.clone() }))
                                })
                            })
                        };
                        if crate::check::expr::is_time_sigil_f(&sh_p8) {
                            crate::prelude::call_then(crate::check::expr::start_inner_of_f(st1_pc.clone(), ct_pb.clone()), move |inner_of_f_10377: crate::check::types::Ty| k_let10346(inner_of_f_10377))
                        } else {
                            k_let10346(ct_pb.clone())
                        }
                    })
                })
            },
            crate::syntax::Cond::CondBind(p_ph, e_pi, gd_oj) => {
                let else_b_o4x = else_b_o4.clone();
                let gd_ojx = (**gd_oj).clone();
                let e_pix = (**e_pi).clone();
                let env_p0x = env_p0.clone();
                let p_phx = p_ph.clone();
                let span_p5x = span_p5.clone();
                let st_p1x = st_p1.clone();
                let then_b_p3x = then_b_p3.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_pix.clone()), move |infer_f_10703: (crate::check::types::Ty, crate::check::types::St)| {
                    let (et_pl, st1_pm) = infer_f_10703;
                    crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p0x.clone(), st1_pm.clone(), p_phx.clone(), et_pl.clone(), true), move |bind_pattern_f_10748: (crate::check::expr::Env, crate::check::types::St)| {
                        let (env2_pn, st2_po) = bind_pattern_f_10748;
                        let else_b_o4xz = else_b_o4x.clone();
                        let env_p0xz = env_p0x.clone();
                        let env2_pnz = env2_pn.clone();
                        let span_p5xz = span_p5x.clone();
                        let then_b_p3xz = then_b_p3x.clone();
                        let k_let10790 = move |v10790: crate::check::types::St| {
                            let st3_pk = v10790;
                            let (res_pq, st4_pr) = crate::check::types::fresh_var_f(&st3_pk, &false, &crate::prelude::Text::lit(""));
                            crate::prelude::call_then(start_if_branches_f(env2_pnz.clone(), st4_pr.clone(), env_p0xz.clone(), then_b_p3xz.clone(), else_b_o4xz.clone(), res_pq.clone()), move |if_branches_f_10953: (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St)| {
                                let (layers_ps, st5_pt) = if_branches_f_10953;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchResult { env_p0: env_p0xz.clone(), st_p1: no_else_f(&st5_pt, &else_b_o4xz, &span_p5xz), sh_p2: crate::prelude::Text::lit(""), layers_p3: layers_ps.clone(), joined_p4: res_pq.clone(), span_p5: span_p5xz.clone() }))
                            })
                        };
                        match gd_ojx.clone() {
                            ::std::option::Option::Some(g_pp) => crate::prelude::call_then(start_check_cond_f(env2_pn.clone(), st2_po.clone(), g_pp.clone()), move |check_cond_f_10828: crate::check::types::St| k_let10790(check_cond_f_10828)),
                            ::std::option::Option::None => k_let10790(st2_po.clone()),
                        }
                    })
                })
            },
        }
    }
}

/// `Start InferIf, x`: what the function value is when passed to `@Run`.
pub fn start_infer_if_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, c_p2: crate::syntax::Cond, then_b_p3: crate::syntax::Block, else_b_o4: ::std::option::Option<crate::syntax::Block>, span_p5: crate::syntax::Range, expected_o6: ::std::option::Option<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferIf { env_p0, st_p1, c_p2, then_b_p3, else_b_o4, span_p5, expected_o6 })
}

/// ```prism
/// NoElse: fn St, ?Block, Range -> St
/// ```
pub fn no_else_f(st_p0: &crate::check::types::St, else_b_o1: &::std::option::Option<crate::syntax::Block>, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    match else_b_o1 {
        ::std::option::Option::Some(_) => st_p0.clone(),
        ::std::option::Option::None => crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("no-else"), span_p2, &crate::prelude::Text::lit("this `if` has no `else`: an `if` that is a value chooses between two branches"), &crate::prelude::Text::lit("add `else:` with the other branch\'s value")),
    }
}

/// ```prism
/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub fn unify_arm_f(st_p0: &crate::check::types::St, res_p1: &crate::check::types::Ty, t_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    match (res_p1.clone(), crate::check::types::non_empty_coll_o(st_p0, res_p1), crate::check::types::is_plain_collection_f(st_p0, t_p2)) {
        (crate::check::types::Ty::TyFlex(n_p4), ::std::option::Option::Some(c_p5), true) => {
            let mut this: crate::check::types::St = crate::check::types::unify::unify_f(st_p0, &c_p5, t_p2, span_p3);
            this.plain_arms_p = crate::prelude::push(&this.plain_arms_p, &n_p4);
            this
        },
        _ => crate::check::types::recording::unify_noted_f(st_p0, res_p1, t_p2, span_p3),
    }
}

/// The step machine of `UnifyArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub struct UnifyArm {
    pub st_p0: crate::check::types::St,
    pub res_p1: crate::check::types::Ty,
    pub t_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for UnifyArm {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let res_p1 = &self.res_p1;
        let t_p2 = &self.t_p2;
        let span_p3 = &self.span_p3;
        let res_p1x = res_p1.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(st_p0x.clone(), res_p1x.clone()), move |non_empty_coll_o_12185: ::std::option::Option<crate::check::types::Ty>| crate::prelude::call_then(crate::check::types::start_is_plain_collection_f(st_p0x.clone(), t_p2x.clone()), move |is_plain_collection_f_12210: bool| match (res_p1x.clone(), non_empty_coll_o_12185, is_plain_collection_f_12210) {
            (crate::check::types::Ty::TyFlex(n_p4), ::std::option::Option::Some(c_p5), true) => ::prism_rtl::Turn::Finished({
                let mut this: crate::check::types::St = crate::check::types::unify::unify_f(&st_p0x, &c_p5, &t_p2x, &span_p3x);
                this.plain_arms_p = crate::prelude::push(&this.plain_arms_p, &n_p4);
                this
            }),
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::recording::UnifyNoted { st_p0: st_p0x.clone(), expected_p1: res_p1x.clone(), found_p2: t_p2x.clone(), span_p3: span_p3x.clone() })),
        }))
    }
}

/// `Start UnifyArm, x`: what the function value is when passed to `@Run`.
pub fn start_unify_arm_f(st_p0: crate::check::types::St, res_p1: crate::check::types::Ty, t_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(UnifyArm { st_p0, res_p1, t_p2, span_p3 })
}

/// ```prism
/// ArmResult: unbounded fn St, Ty -> Ty
/// ```
pub fn arm_result_f(st_p0: &crate::check::types::St, joined_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match joined_p1 {
        crate::check::types::Ty::TyFlex(n_p2) if crate::check::types::has_nat_f(&st_p0.plain_arms_p, n_p2) => crate::prelude::or(&crate::check::types::non_empty_coll_o(st_p0, joined_p1), joined_p1),
        _ => joined_p1.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ArmResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmResult: unbounded fn St, Ty -> Ty
/// ```
pub struct ArmResult {
    pub st_p0: crate::check::types::St,
    pub joined_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for ArmResult {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let joined_p1 = &self.joined_p1;
        match joined_p1 {
            crate::check::types::Ty::TyFlex(n_p2) if crate::check::types::has_nat_f(&st_p0.plain_arms_p, n_p2) => {
                let joined_p1x = joined_p1.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(st_p0x.clone(), joined_p1x.clone()), move |non_empty_coll_o_12650: ::std::option::Option<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::prelude::or(&non_empty_coll_o_12650, &joined_p1x)))
            },
            _ => ::prism_rtl::Turn::Finished(joined_p1.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ArmResult, x`: what the function value is when passed to `@Run`.
pub fn start_arm_result_f(st_p0: crate::check::types::St, joined_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(ArmResult { st_p0, joined_p1 })
}

/// ```prism
/// LayerHead: fn Text -> Text
/// ```
pub fn layer_head_f(h_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if crate::check::expr::is_time_sigil_f(h_p0) {
        h_p0.clone()
    } else {
        if h_p0 == &crate::prelude::Text::lit("@") {
            crate::prelude::Text::lit("@")
        } else {
            crate::prelude::Text::lit("")
        }
    }
}

/// ```prism
/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
/// ```
pub fn if_branches_f(then_env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, else_env_p2: &crate::check::expr::Env, then_b_p3: &crate::syntax::Block, else_b_o4: &::std::option::Option<crate::syntax::Block>, res_p5: &crate::check::types::Ty) -> (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St) {
    let (t1_pa, st1a_pb) = crate::check::expr::lets::infer_expr_block_f(then_env_p0, st_p1, then_b_p3);
    let st1_p6 = crate::check::types::recording::note_fault_at_f(&st1a_pb, &crate::check::types::recording::tail_span_f(then_b_p3), res_p5, &t1_pa);
    let h1_p7 = crate::check::types::head_sigil_f(&st1_p6, &t1_pa);
    let st2_p8 = unify_arm_f(&st1_p6, res_p5, &(if crate::check::expr::is_time_sigil_f(&h1_p7) {
        crate::check::expr::inner_of_f(&st1_p6, &t1_pa)
    } else {
        t1_pa.clone()
    }), &crate::check::types::recording::result_span_f(then_b_p3));
    let l1_p9 = crate::prelude::Array::from(vec![(layer_head_f(&h1_p7), then_b_p3.span_p.clone())]);
    match else_b_o4 {
        ::std::option::Option::Some(b_pc) => {
            let (t2_pg, st3a_ph) = crate::check::expr::lets::infer_expr_block_f(else_env_p2, &st2_p8, b_pc);
            let st3_pd = crate::check::types::recording::note_fault_at_f(&st3a_ph, &crate::check::types::recording::tail_span_f(b_pc), res_p5, &t2_pg);
            let h2_pe = crate::check::types::head_sigil_f(&st3_pd, &t2_pg);
            let st4_pf = unify_arm_f(&st3_pd, res_p5, &(if crate::check::expr::is_time_sigil_f(&h2_pe) {
                crate::check::expr::inner_of_f(&st3_pd, &t2_pg)
            } else {
                t2_pg.clone()
            }), &crate::check::types::recording::result_span_f(b_pc));
            (crate::prelude::push(&l1_p9, &(layer_head_f(&h2_pe), b_pc.span_p.clone())), st4_pf.clone())
        },
        ::std::option::Option::None => (l1_p9.clone(), crate::check::types::unify::unify_f(&st2_p8, res_p5, &crate::check::types::t_unit_p(), &crate::check::types::recording::result_span_f(then_b_p3))),
    }
}

/// The step machine of `IfBranches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
/// ```
pub struct IfBranches {
    pub then_env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub else_env_p2: crate::check::expr::Env,
    pub then_b_p3: crate::syntax::Block,
    pub else_b_o4: ::std::option::Option<crate::syntax::Block>,
    pub res_p5: crate::check::types::Ty,
}

impl ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St)> for IfBranches {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St)> {
        let then_env_p0 = &self.then_env_p0;
        let st_p1 = &self.st_p1;
        let else_env_p2 = &self.else_env_p2;
        let then_b_p3 = &self.then_b_p3;
        let else_b_o4 = &self.else_b_o4;
        let res_p5 = &self.res_p5;
        let else_b_o4x = else_b_o4.clone();
        let else_env_p2x = else_env_p2.clone();
        let res_p5x = res_p5.clone();
        let st_p1x = st_p1.clone();
        let then_b_p3x = then_b_p3.clone();
        let then_env_p0x = then_env_p0.clone();
        crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(then_env_p0x.clone(), st_p1x.clone(), then_b_p3x.clone()), move |infer_expr_block_f_12969: (crate::check::types::Ty, crate::check::types::St)| {
            let (t1_pa, st1a_pb) = infer_expr_block_f_12969;
            crate::prelude::call_then(crate::check::types::recording::start_note_fault_at_f(st1a_pb.clone(), crate::check::types::recording::tail_span_f(&then_b_p3x), res_p5x.clone(), t1_pa.clone()), move |note_fault_at_f_13017: crate::check::types::St| {
                let st1_p6 = note_fault_at_f_13017;
                crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_p6.clone(), t1_pa.clone()), move |head_sigil_f_13074: crate::prelude::Text| {
                    let h1_p7 = head_sigil_f_13074;
                    crate::prelude::call_then(start_unify_arm_f(st1_p6.clone(), res_p5x.clone(), if crate::check::expr::is_time_sigil_f(&h1_p7) {
                        crate::check::expr::inner_of_f(&st1_p6, &t1_pa)
                    } else {
                        t1_pa.clone()
                    }, crate::check::types::recording::result_span_f(&then_b_p3x)), move |unify_arm_f_13106: crate::check::types::St| {
                        let st2_p8 = unify_arm_f_13106;
                        let l1_p9 = crate::prelude::Array::from(vec![(layer_head_f(&h1_p7), then_b_p3x.span_p.clone())]);
                        match &else_b_o4x {
                            ::std::option::Option::Some(b_pc) => {
                                let b_pcx = b_pc.clone();
                                crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(else_env_p2x.clone(), st2_p8.clone(), b_pcx.clone()), move |infer_expr_block_f_13301: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (t2_pg, st3a_ph) = infer_expr_block_f_13301;
                                    crate::prelude::call_then(crate::check::types::recording::start_note_fault_at_f(st3a_ph.clone(), crate::check::types::recording::tail_span_f(&b_pcx), res_p5x.clone(), t2_pg.clone()), move |note_fault_at_f_13354: crate::check::types::St| {
                                        let st3_pd = note_fault_at_f_13354;
                                        crate::prelude::call_then(crate::check::types::start_head_sigil_f(st3_pd.clone(), t2_pg.clone()), move |head_sigil_f_13415: crate::prelude::Text| {
                                            let h2_pe = head_sigil_f_13415;
                                            crate::prelude::call_then(start_unify_arm_f(st3_pd.clone(), res_p5x.clone(), if crate::check::expr::is_time_sigil_f(&h2_pe) {
                                                crate::check::expr::inner_of_f(&st3_pd, &t2_pg)
                                            } else {
                                                t2_pg.clone()
                                            }, crate::check::types::recording::result_span_f(&b_pcx)), move |unify_arm_f_13455: crate::check::types::St| {
                                                let st4_pf = unify_arm_f_13455;
                                                ::prism_rtl::Turn::Finished((crate::prelude::push(&l1_p9, &(layer_head_f(&h2_pe), b_pcx.span_p.clone())), st4_pf.clone()))
                                            })
                                        })
                                    })
                                })
                            },
                            ::std::option::Option::None => crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p8.clone(), res_p5x.clone(), crate::check::types::t_unit_p(), crate::check::types::recording::result_span_f(&then_b_p3x)), move |unify_f_13615: crate::check::types::St| ::prism_rtl::Turn::Finished((l1_p9.clone(), unify_f_13615))),
                        }
                    })
                })
            })
        })
    }
}

/// `Start IfBranches, x`: what the function value is when passed to `@Run`.
pub fn start_if_branches_f(then_env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, else_env_p2: crate::check::expr::Env, then_b_p3: crate::syntax::Block, else_b_o4: ::std::option::Option<crate::syntax::Block>, res_p5: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::check::types::St)>> {
    ::std::rc::Rc::new(IfBranches { then_env_p0, st_p1, else_env_p2, then_b_p3, else_b_o4, res_p5 })
}
