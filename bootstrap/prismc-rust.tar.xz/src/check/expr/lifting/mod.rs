//! The module `Check.Expr.Lifting`, from `target/bootstrap/src/prismc/check/expr/lifting.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
/// ```
pub fn infer_match(env: &crate::check::expr::Env, st: &crate::check::types::St, scrut: &crate::syntax::Expr, arms: &Array<crate::syntax::Arm>, span: &crate::syntax::Range, expected_opt: &Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    let (st_ty, st1) = crate::check::expr::infer(env, st, scrut);
    let sh = crate::check::types::head_sigil(&st1, &st_ty);
    let plain_scrut = if crate::check::expr::is_time_sigil(&sh) {
        crate::check::expr::inner_of(&st1, &st_ty)
    } else {
        st_ty.clone()
    };
    let st2 = if &sh == &Text::lit("@") {
        crate::check::types::recording::err(&st1, &Text::lit("blueprint-operand"), &scrut.span, &Text::lit("`match` over a blueprint; bind it first"))
    } else {
        st1.clone()
    };
    let rigid_out_opt = match crate::check::types::recording::walk(&st2, &plain_scrut) {
        crate::check::types::Ty::TyElem(_, o) => match crate::check::types::recording::walk(&st2, &*o) {
            crate::check::types::Ty::TyRigid(name) => Some(name.clone()),
            _ => None,
        },
        _ => None,
    };
    let (res, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
    let checking = (expected_opt != &None) && !crate::check::expr::is_time_sigil(&sh);
    let scrut_name = crate::check::shrink::locals::expr_name(scrut);
    let (layers, st4, _) = run_to_end(fold_job(arms.clone(), (Array::new(), st3.clone(), Array::new()), {
        let env = env.clone();
        let scrut_name = scrut_name.clone();
        let plain_scrut = plain_scrut.clone();
        let res = res.clone();
        let checking = checking;
        let expected_opt = expected_opt.clone();
        let rigid_out_opt = rigid_out_opt.clone();
        Rc::new(move |(p0, p1): ((Array<(Text, crate::syntax::Range)>, crate::check::types::St, Array<Text>), crate::syntax::Arm)| {
            let env = env.clone();
            let scrut_name = scrut_name.clone();
            let plain_scrut = plain_scrut.clone();
            let res = res.clone();
            let checking = checking;
            let expected_opt = expected_opt.clone();
            let rigid_out_opt = rigid_out_opt.clone();
            entered(once_job(move || {
                let (acc, s, taken) = p0;
                let arm = p1;
                call_then(start_narrowed(env.clone(), s.clone(), arm.clone(), scrut_name.clone(), plain_scrut.clone(), taken.clone()), move |narrowed_2375: crate::check::expr::Env| {
                    let env_arm = narrowed_2375;
                    call_then(start_infer_arm(env_arm.clone(), s.clone(), arm.clone(), plain_scrut.clone(), res.clone(), if checking { expected_opt.clone() } else { None }, rigid_out_opt.clone(), acc.clone()), move |infer_arm_2453: (Array<(Text, crate::syntax::Range)>, crate::check::types::St)| {
                        let (acc2, s2) = infer_arm_2453;
                        prism_rtl::Turn::Finished((acc2.clone(), s2.clone(), taken_by(&env, &arm, &taken)))
                    })
                })
            }))
        }) as Rc<dyn Fn(((Array<(Text, crate::syntax::Range)>, crate::check::types::St, Array<Text>), crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::syntax::Range)>, crate::check::types::St, Array<Text>)>>>
    }));
    let st5 = crate::check::passes::match_coverage(env, &st4, &plain_scrut, arms, span);
    match expected_opt {
        Some(want) => if checking {
            (want.clone(), st5.clone())
        } else {
            match_result(env, &st5, &sh, &layers, &res, span)
        },
        None => match_result(env, &st5, &sh, &layers, &res, span),
    }
}

/// The step machine of `InferMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
/// ```
pub struct InferMatch {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub scrut: crate::syntax::Expr,
    pub arms: Array<crate::syntax::Arm>,
    pub span: crate::syntax::Range,
    pub expected_opt: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferMatch {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let scrut = &self.scrut;
        let arms = &self.arms;
        let span = &self.span;
        let expected_opt = &self.expected_opt;
        let expected_opt = expected_opt.clone();
        let arms = arms.clone();
        let env = env.clone();
        let scrut = scrut.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), scrut.clone()), move |infer_1698: (crate::check::types::Ty, crate::check::types::St)| {
            let (st_ty, st1) = infer_1698;
            call_then(crate::check::types::start_head_sigil(st1.clone(), st_ty.clone()), move |head_sigil_1732: Text| {
                let sh = head_sigil_1732;
                let plain_scrut = if crate::check::expr::is_time_sigil(&sh) {
                    crate::check::expr::inner_of(&st1, &st_ty)
                } else {
                    st_ty.clone()
                };
                let st2 = if &sh == &Text::lit("@") {
                    crate::check::types::recording::err(&st1, &Text::lit("blueprint-operand"), &scrut.span, &Text::lit("`match` over a blueprint; bind it first"))
                } else {
                    st1.clone()
                };
                call_then(crate::check::types::recording::start_walk(st2.clone(), plain_scrut.clone()), move |walk_1969: crate::check::types::Ty| {
                    let rigid_out_opt = match walk_1969 {
                        crate::check::types::Ty::TyElem(_, o) => match crate::check::types::recording::walk(&st2, &*o) {
                            crate::check::types::Ty::TyRigid(name) => Some(name.clone()),
                            _ => None,
                        },
                        _ => None,
                    };
                    let (res, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
                    let checking = (&expected_opt != &None) && !crate::check::expr::is_time_sigil(&sh);
                    let scrut_name = crate::check::shrink::locals::expr_name(&scrut);
                    call_value(fold_job(arms.clone(), (Array::new(), st3.clone(), Array::new()), {
                        let env = env.clone();
                        let scrut_name = scrut_name.clone();
                        let plain_scrut = plain_scrut.clone();
                        let res = res.clone();
                        let checking = checking;
                        let expected_opt = expected_opt.clone();
                        let rigid_out_opt = rigid_out_opt.clone();
                        Rc::new(move |(p0, p1): ((Array<(Text, crate::syntax::Range)>, crate::check::types::St, Array<Text>), crate::syntax::Arm)| {
                            let env = env.clone();
                            let scrut_name = scrut_name.clone();
                            let plain_scrut = plain_scrut.clone();
                            let res = res.clone();
                            let checking = checking;
                            let expected_opt = expected_opt.clone();
                            let rigid_out_opt = rigid_out_opt.clone();
                            entered(once_job(move || {
                                let (acc, s, taken) = p0;
                                let arm = p1;
                                call_then(start_narrowed(env.clone(), s.clone(), arm.clone(), scrut_name.clone(), plain_scrut.clone(), taken.clone()), move |narrowed_2375: crate::check::expr::Env| {
                                    let env_arm = narrowed_2375;
                                    call_then(start_infer_arm(env_arm.clone(), s.clone(), arm.clone(), plain_scrut.clone(), res.clone(), if checking { expected_opt.clone() } else { None }, rigid_out_opt.clone(), acc.clone()), move |infer_arm_2453: (Array<(Text, crate::syntax::Range)>, crate::check::types::St)| {
                                        let (acc2, s2) = infer_arm_2453;
                                        prism_rtl::Turn::Finished((acc2.clone(), s2.clone(), taken_by(&env, &arm, &taken)))
                                    })
                                })
                            }))
                        }) as Rc<dyn Fn(((Array<(Text, crate::syntax::Range)>, crate::check::types::St, Array<Text>), crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::syntax::Range)>, crate::check::types::St, Array<Text>)>>>
                    }), move |fold_2296: (Array<(Text, crate::syntax::Range)>, crate::check::types::St, Array<Text>)| {
                        let (layers, st4, _) = fold_2296;
                        call_then(crate::check::passes::start_match_coverage(env.clone(), st4.clone(), plain_scrut.clone(), arms.clone(), span.clone()), move |match_coverage_2608: crate::check::types::St| {
                            let st5 = match_coverage_2608;
                            match &expected_opt {
                                Some(want) => if checking {
                                    prism_rtl::Turn::Finished((want.clone(), st5.clone()))
                                } else {
                                    prism_rtl::Turn::More(Rc::new(MatchResult { env: env.clone(), st: st5.clone(), sh: sh.clone(), layers: layers.clone(), res: res.clone(), span: span.clone() }))
                                },
                                None => prism_rtl::Turn::More(Rc::new(MatchResult { env: env.clone(), st: st5.clone(), sh: sh.clone(), layers: layers.clone(), res: res.clone(), span: span.clone() })),
                            }
                        })
                    })
                })
            })
        })
    }
}

/// `Start InferMatch, x`: what the function value is when passed to `@Run`.
pub fn start_infer_match(env: crate::check::expr::Env, st: crate::check::types::St, scrut: crate::syntax::Expr, arms: Array<crate::syntax::Arm>, span: crate::syntax::Range, expected_opt: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferMatch { env, st, scrut, arms, span, expected_opt })
}

/// ```prism
/// TakenBy: fn Env, Arm, [Text] -> [Text]
/// ```
pub fn taken_by(env: &crate::check::expr::Env, arm: &crate::syntax::Arm, taken: &Array<Text>) -> Array<Text> {
    if &arm.guard != &None {
        taken.clone()
    } else {
        match &arm.pattern {
            Some(p_) => match &*p_.kind {
                crate::syntax::PatternKind::PFamily(q) => crate::check::types::union_texts(taken, &or(&get(&env.g.families, &crate::check::env::dotted(&q.path_)), &Array::new())),
                _ => match tag_of_pattern(env, p_) {
                    Some(tg) => crate::check::types::add_text(taken, &tg.name),
                    None => taken.clone(),
                },
            },
            None => taken.clone(),
        }
    }
}

/// ```prism
/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
/// ```
pub fn narrowed(env: &crate::check::expr::Env, st: &crate::check::types::St, arm: &crate::syntax::Arm, name: &Text, t: &crate::check::types::Ty, taken: &Array<Text>) -> crate::check::expr::Env {
    let forwards = match &arm.pattern {
        Some(p_) => match &*p_.kind {
            crate::syntax::PatternKind::PFamily(_) => true,
            _ => false,
        },
        None => true,
    };
    if (!forwards || (name == &Text::lit(""))) || (&len(taken) == &Nat::from(0u32)) {
        env.clone()
    } else {
        match crate::check::types::recording::walk(st, t) {
            crate::check::types::Ty::TyElem(rw, o) => {
                let w = crate::check::types::recording::walk_row(st, &rw);
                crate::check::expr::with_local(env, name, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyElem(crate::check::types::Rw { fams: w.fams.clone(), minus: crate::check::types::union_texts(&w.minus, taken), tail: w.tail.clone() }, Rc::new((*o).clone()))))
            },
            _ => env.clone(),
        }
    }
}

/// The step machine of `Narrowed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
/// ```
pub struct Narrowed {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub arm: crate::syntax::Arm,
    pub name: Text,
    pub t: crate::check::types::Ty,
    pub taken: Array<Text>,
}

impl prism_rtl::Job<crate::check::expr::Env> for Narrowed {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::expr::Env> {
        let env = &self.env;
        let st = &self.st;
        let arm = &self.arm;
        let name = &self.name;
        let t = &self.t;
        let taken = &self.taken;
        let forwards = match &arm.pattern {
            Some(p_) => match &*p_.kind {
                crate::syntax::PatternKind::PFamily(_) => true,
                _ => false,
            },
            None => true,
        };
        if (!forwards || (name == &Text::lit(""))) || (&len(taken) == &Nat::from(0u32)) {
            prism_rtl::Turn::Finished(env.clone())
        } else {
            {
                let arm = arm.clone();
                let env = env.clone();
                let name = name.clone();
                let st = st.clone();
                let t = t.clone();
                let taken = taken.clone();
                call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_3793: crate::check::types::Ty| match walk_3793 {
                    crate::check::types::Ty::TyElem(rw, o) => call_then(crate::check::types::recording::start_walk_row(st.clone(), rw.clone()), move |walk_row_3847: crate::check::types::Rw| {
                        let w = walk_row_3847;
                        prism_rtl::Turn::Finished(crate::check::expr::with_local(&env, &name, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyElem(crate::check::types::Rw { fams: w.fams.clone(), minus: crate::check::types::union_texts(&w.minus, &taken), tail: w.tail.clone() }, Rc::new((*o).clone())))))
                    }),
                    _ => prism_rtl::Turn::Finished(env.clone()),
                })
            }
        }
    }
}

/// `Start Narrowed, x`: what the function value is when passed to `@Run`.
pub fn start_narrowed(env: crate::check::expr::Env, st: crate::check::types::St, arm: crate::syntax::Arm, name: Text, t: crate::check::types::Ty, taken: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::check::expr::Env>> {
    Rc::new(Narrowed { env, st, arm, name, t, taken })
}

/// ```prism
/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
/// ```
pub fn infer_arm(env: &crate::check::expr::Env, st: &crate::check::types::St, arm: &crate::syntax::Arm, scrut_ty: &crate::check::types::Ty, res: &crate::check::types::Ty, expected_opt: &Option<crate::check::types::Ty>, rigid_out_opt: &Option<Text>, acc: &Array<(Text, crate::syntax::Range)>) -> (Array<(Text, crate::syntax::Range)>, crate::check::types::St) {
    let (env2, st1) = match &arm.pattern {
        Some(p_) => crate::check::expr::patterns::bind_pattern(env, st, p_, scrut_ty, &true),
        None => (env.clone(), st.clone()),
    };
    let refined_out_opt = match rigid_out_opt {
        Some(o) => match &arm.pattern {
            Some(p_) => match tag_of_pattern(env, p_) {
                Some(tg) => Some((o.clone(), tg.out.clone())),
                None => None,
            },
            None => None,
        },
        None => None,
    };
    let st2 = match &arm.guard {
        Some(gd) => check_cond(&env2, &st1, gd),
        None => st1.clone(),
    };
    match expected_opt {
        Some(want) => {
            let refined = match &refined_out_opt {
                Some((o, out)) => subst_rigid(o, out, &crate::check::types::recording::zonk(&st2, want)),
                None => want.clone(),
            };
            let (bt, st3) = crate::check::expr::lets::infer_expr_block(&env2, &st2, &arm.body);
            (acc.clone(), arm_against(&st3, &refined, &bt, &arm.body.span, &((&arm.pattern == &None) || is_family_arm(arm))))
        },
        None => {
            let (bt, st3) = crate::check::expr::lets::infer_expr_block(&env2, &st2, &arm.body);
            let head = crate::check::types::head_sigil(&st3, &bt);
            let plain_bt = if crate::check::expr::is_time_sigil(&head) {
                crate::check::expr::inner_of(&st3, &bt)
            } else {
                bt.clone()
            };
            let st4 = unify_arm(&st3, res, &plain_bt, &arm.body.span);
            let acc2 = if crate::check::expr::is_time_sigil(&head) {
                push(acc, &(head.clone(), arm.body.span.clone()))
            } else {
                push(acc, &(Text::lit(""), arm.body.span.clone()))
            };
            let acc3 = if &head == &Text::lit("@") {
                push(&acc2, &(Text::lit("@"), arm.body.span.clone()))
            } else {
                acc2.clone()
            };
            (acc3.clone(), st4.clone())
        },
    }
}

/// The step machine of `InferArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
/// ```
pub struct InferArm {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub arm: crate::syntax::Arm,
    pub scrut_ty: crate::check::types::Ty,
    pub res: crate::check::types::Ty,
    pub expected_opt: Option<crate::check::types::Ty>,
    pub rigid_out_opt: Option<Text>,
    pub acc: Array<(Text, crate::syntax::Range)>,
}

impl prism_rtl::Job<(Array<(Text, crate::syntax::Range)>, crate::check::types::St)> for InferArm {
    fn cycle(&self) -> prism_rtl::Turn<(Array<(Text, crate::syntax::Range)>, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let arm = &self.arm;
        let scrut_ty = &self.scrut_ty;
        let res = &self.res;
        let expected_opt = &self.expected_opt;
        let rigid_out_opt = &self.rigid_out_opt;
        let acc = &self.acc;
        let (env2, st1) = match &arm.pattern {
            Some(p_) => crate::check::expr::patterns::bind_pattern(env, st, p_, scrut_ty, &true),
            None => (env.clone(), st.clone()),
        };
        let refined_out_opt = match rigid_out_opt {
            Some(o) => match &arm.pattern {
                Some(p_) => match tag_of_pattern(env, p_) {
                    Some(tg) => Some((o.clone(), tg.out.clone())),
                    None => None,
                },
                None => None,
            },
            None => None,
        };
        let st2 = match &arm.guard {
            Some(gd) => check_cond(&env2, &st1, gd),
            None => st1.clone(),
        };
        match expected_opt {
            Some(want) => {
                let refined = match &refined_out_opt {
                    Some((o, out)) => subst_rigid(o, out, &crate::check::types::recording::zonk(&st2, want)),
                    None => want.clone(),
                };
                let acc = acc.clone();
                let arm = arm.clone();
                call_then(crate::check::expr::lets::start_infer_expr_block(env2.clone(), st2.clone(), arm.body.clone()), move |infer_expr_block_4943: (crate::check::types::Ty, crate::check::types::St)| {
                    let (bt, st3) = infer_expr_block_4943;
                    call_then(start_arm_against(st3.clone(), refined.clone(), bt.clone(), arm.body.span.clone(), (&arm.pattern == &None) || is_family_arm(&arm)), move |arm_against_4998: crate::check::types::St| prism_rtl::Turn::Finished((acc.clone(), arm_against_4998)))
                })
            },
            None => {
                let acc = acc.clone();
                let arm = arm.clone();
                let res = res.clone();
                call_then(crate::check::expr::lets::start_infer_expr_block(env2.clone(), st2.clone(), arm.body.clone()), move |infer_expr_block_5131: (crate::check::types::Ty, crate::check::types::St)| {
                    let (bt, st3) = infer_expr_block_5131;
                    call_then(crate::check::types::start_head_sigil(st3.clone(), bt.clone()), move |head_sigil_5189: Text| {
                        let head = head_sigil_5189;
                        let plain_bt = if crate::check::expr::is_time_sigil(&head) {
                            crate::check::expr::inner_of(&st3, &bt)
                        } else {
                            bt.clone()
                        };
                        call_then(start_unify_arm(st3.clone(), res.clone(), plain_bt.clone(), arm.body.span.clone()), move |unify_arm_5301: crate::check::types::St| {
                            let st4 = unify_arm_5301;
                            let acc2 = if crate::check::expr::is_time_sigil(&head) {
                                push(&acc, &(head.clone(), arm.body.span.clone()))
                            } else {
                                push(&acc, &(Text::lit(""), arm.body.span.clone()))
                            };
                            let acc3 = if &head == &Text::lit("@") {
                                push(&acc2, &(Text::lit("@"), arm.body.span.clone()))
                            } else {
                                acc2.clone()
                            };
                            prism_rtl::Turn::Finished((acc3.clone(), st4.clone()))
                        })
                    })
                })
            },
        }
    }
}

/// `Start InferArm, x`: what the function value is when passed to `@Run`.
pub fn start_infer_arm(env: crate::check::expr::Env, st: crate::check::types::St, arm: crate::syntax::Arm, scrut_ty: crate::check::types::Ty, res: crate::check::types::Ty, expected_opt: Option<crate::check::types::Ty>, rigid_out_opt: Option<Text>, acc: Array<(Text, crate::syntax::Range)>) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::syntax::Range)>, crate::check::types::St)>> {
    Rc::new(InferArm { env, st, arm, scrut_ty, res, expected_opt, rigid_out_opt, acc })
}

/// ```prism
/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
/// ```
pub fn arm_against(st: &crate::check::types::St, want: &crate::check::types::Ty, bt: &crate::check::types::Ty, span: &crate::syntax::Range, forwards: &bool) -> crate::check::types::St {
    match (crate::check::types::recording::walk(st, want), crate::check::types::recording::walk(st, bt)) {
        (crate::check::types::Ty::TyAt(w1, r1), crate::check::types::Ty::TyAt(b1, r2)) => {
            let st2 = crate::check::types::unify::unify(st, &*w1, &*b1, span);
            {
                let mut this: crate::check::types::St = st2.clone();
                this.incls = push(&this.incls, &crate::check::types::Incl { sub: r2.clone(), sup: r1.clone(), file: this.file.clone(), span: span.clone(), what: Text::lit("arm"), forward: *forwards });
                this
            }
        },
        _ => crate::check::types::unify::unify(st, want, bt, span),
    }
}

/// The step machine of `ArmAgainst`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
/// ```
pub struct ArmAgainst {
    pub st: crate::check::types::St,
    pub want: crate::check::types::Ty,
    pub bt: crate::check::types::Ty,
    pub span: crate::syntax::Range,
    pub forwards: bool,
}

impl prism_rtl::Job<crate::check::types::St> for ArmAgainst {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let want = &self.want;
        let bt = &self.bt;
        let span = &self.span;
        let forwards = &self.forwards;
        let bt = bt.clone();
        let forwards = *forwards;
        let span = span.clone();
        let st = st.clone();
        let want = want.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), want.clone()), move |walk_5855: crate::check::types::Ty| call_then(crate::check::types::recording::start_walk(st.clone(), bt.clone()), move |walk_5872: crate::check::types::Ty| match (walk_5855, walk_5872) {
            (crate::check::types::Ty::TyAt(w1, r1), crate::check::types::Ty::TyAt(b1, r2)) => call_then(crate::check::types::unify::start_unify(st.clone(), (*w1).clone(), (*b1).clone(), span.clone()), move |unify_5944: crate::check::types::St| {
                let st2 = unify_5944;
                prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = st2.clone();
                    this.incls = push(&this.incls, &crate::check::types::Incl { sub: r2.clone(), sup: r1.clone(), file: this.file.clone(), span: span.clone(), what: Text::lit("arm"), forward: forwards });
                    this
                })
            }),
            _ => prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st.clone(), expected: want.clone(), found: bt.clone(), span: span.clone() })),
        }))
    }
}

/// `Start ArmAgainst, x`: what the function value is when passed to `@Run`.
pub fn start_arm_against(st: crate::check::types::St, want: crate::check::types::Ty, bt: crate::check::types::Ty, span: crate::syntax::Range, forwards: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ArmAgainst { st, want, bt, span, forwards })
}

/// ```prism
/// IsFamilyArm: fn Arm -> Bool
/// ```
pub fn is_family_arm(arm: &crate::syntax::Arm) -> bool {
    match &arm.pattern {
        Some(p_) => match &*p_.kind {
            crate::syntax::PatternKind::PFamily(_) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// CheckCond: unbounded fn Env, St, Expr -> St
/// ```
pub fn check_cond(env: &crate::check::expr::Env, st: &crate::check::types::St, e: &crate::syntax::Expr) -> crate::check::types::St {
    let (t, st2) = crate::check::expr::infer(env, st, e);
    let inner = if crate::check::expr::is_time_sigil(&crate::check::types::head_sigil(&st2, &t)) {
        crate::check::expr::inner_of(&st2, &t)
    } else {
        t.clone()
    };
    crate::check::types::unify::unify(&st2, &crate::check::types::t_bool(), &inner, &e.span)
}

/// The step machine of `CheckCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckCond: unbounded fn Env, St, Expr -> St
/// ```
pub struct CheckCond {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::check::types::St> for CheckCond {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let e = e.clone();
        let env = env.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_6481: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st2) = infer_6481;
            call_then(crate::check::types::start_head_sigil(st2.clone(), t.clone()), move |head_sigil_6530: Text| {
                let inner = if crate::check::expr::is_time_sigil(&head_sigil_6530) {
                    crate::check::expr::inner_of(&st2, &t)
                } else {
                    t.clone()
                };
                prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st2.clone(), expected: crate::check::types::t_bool(), found: inner.clone(), span: e.span.clone() }))
            })
        })
    }
}

/// `Start CheckCond, x`: what the function value is when passed to `@Run`.
pub fn start_check_cond(env: crate::check::expr::Env, st: crate::check::types::St, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckCond { env, st, e })
}

/// ```prism
/// ?TagOfPattern: fn Env, Pattern -> ?TagInfo
/// ```
pub fn tag_of_pattern(env: &crate::check::expr::Env, p_: &crate::syntax::Pattern_) -> Option<crate::check::env::TagInfo> {
    match &*p_.kind {
        crate::syntax::PatternKind::PRecord(n, _, _) => get(&env.g.tags, &crate::check::env::dotted(&n.path_)),
        crate::syntax::PatternKind::PCtor(n, _) => get(&env.g.tags, &crate::check::env::dotted(&n.path_)),
        crate::syntax::PatternKind::PName(n) => get(&env.g.tags, &crate::check::env::dotted(&n.path_)),
        crate::syntax::PatternKind::PGroup(q) => tag_of_pattern(env, &**q),
        _ => None,
    }
}

/// ```prism
/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
/// ```
pub fn subst_rigid(name: &Text, by: &crate::check::types::Ty, t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TyRigid(n) => if n == name { by.clone() } else { t.clone() },
        crate::check::types::Ty::TyCon(n, args) => crate::check::types::Ty::TyCon(n.clone(), run_to_end(each_job(args.clone(), {
            let name = name.clone();
            let by = by.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let name = name.clone();
                let by = by.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(SubstRigid { name: name.clone(), by: by.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c, ps, r) => crate::check::types::Ty::TyFn(c.clone(), run_to_end(each_job(ps.clone(), {
            let name = name.clone();
            let by = by.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let name = name.clone();
                let by = by.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(SubstRigid { name: name.clone(), by: by.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        })), Rc::new(subst_rigid(name, by, &**r))),
        crate::check::types::Ty::TyTuple(ts) => crate::check::types::Ty::TyTuple(run_to_end(each_job(ts.clone(), {
            let name = name.clone();
            let by = by.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let name = name.clone();
                let by = by.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(SubstRigid { name: name.clone(), by: by.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e) => crate::check::types::Ty::TyArray(Rc::new(subst_rigid(name, by, &**e))),
        crate::check::types::Ty::TyMap(k, v_) => crate::check::types::Ty::TyMap(Rc::new(subst_rigid(name, by, &**k)), Rc::new(subst_rigid(name, by, &**v_))),
        crate::check::types::Ty::TySig(s, i) => crate::check::types::Ty::TySig(s.clone(), Rc::new(subst_rigid(name, by, &**i))),
        crate::check::types::Ty::TyAt(i, rw) => crate::check::types::Ty::TyAt(Rc::new(subst_rigid(name, by, &**i)), rw.clone()),
        crate::check::types::Ty::TyElem(rw, o) => crate::check::types::Ty::TyElem(rw.clone(), Rc::new(subst_rigid(name, by, &**o))),
        other => other.clone(),
    }
}

/// The step machine of `SubstRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
/// ```
pub struct SubstRigid {
    pub name: Text,
    pub by: crate::check::types::Ty,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for SubstRigid {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let name = &self.name;
        let by = &self.by;
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyRigid(n) => if n == name {
                prism_rtl::Turn::Finished(by.clone())
            } else {
                prism_rtl::Turn::Finished(t.clone())
            },
            crate::check::types::Ty::TyCon(n, args) => {
                let args = args.clone();
                let by = by.clone();
                let n = n.clone();
                let name = name.clone();
                call_value(each_job(args.clone(), {
                    let name = name.clone();
                    let by = by.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let name = name.clone();
                        let by = by.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(SubstRigid { name: name.clone(), by: by.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_7117: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n.clone(), each_7117)))
            },
            crate::check::types::Ty::TyFn(c, ps, r) => {
                let by = by.clone();
                let c = c.clone();
                let name = name.clone();
                let ps = ps.clone();
                let r = (**r).clone();
                call_value(each_job(ps.clone(), {
                    let name = name.clone();
                    let by = by.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let name = name.clone();
                        let by = by.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(SubstRigid { name: name.clone(), by: by.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_7185: Array<crate::check::types::Ty>| call_then(start_subst_rigid(name.clone(), by.clone(), r.clone()), move |subst_rigid_7225: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c.clone(), each_7185, Rc::new(subst_rigid_7225)))))
            },
            crate::check::types::Ty::TyTuple(ts) => {
                let by = by.clone();
                let name = name.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let name = name.clone();
                    let by = by.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let name = name.clone();
                        let by = by.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(SubstRigid { name: name.clone(), by: by.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_7274: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_7274)))
            },
            crate::check::types::Ty::TyArray(e) => {
                let by = by.clone();
                let e = (**e).clone();
                let name = name.clone();
                call_then(start_subst_rigid(name.clone(), by.clone(), e.clone()), move |subst_rigid_7336: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(subst_rigid_7336))))
            },
            crate::check::types::Ty::TyMap(k, v_) => {
                let by = by.clone();
                let k = (**k).clone();
                let name = name.clone();
                let v_ = (**v_).clone();
                call_then(start_subst_rigid(name.clone(), by.clone(), k.clone()), move |subst_rigid_7383: crate::check::types::Ty| call_then(start_subst_rigid(name.clone(), by.clone(), v_.clone()), move |subst_rigid_7409: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(subst_rigid_7383), Rc::new(subst_rigid_7409)))))
            },
            crate::check::types::Ty::TySig(s, i) => {
                let by = by.clone();
                let i = (**i).clone();
                let name = name.clone();
                let s = s.clone();
                call_then(start_subst_rigid(name.clone(), by.clone(), i.clone()), move |subst_rigid_7459: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s.clone(), Rc::new(subst_rigid_7459))))
            },
            crate::check::types::Ty::TyAt(i, rw) => {
                let by = by.clone();
                let i = (**i).clone();
                let name = name.clone();
                let rw = rw.clone();
                call_then(start_subst_rigid(name.clone(), by.clone(), i.clone()), move |subst_rigid_7505: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(Rc::new(subst_rigid_7505), rw.clone())))
            },
            crate::check::types::Ty::TyElem(rw, o) => {
                let by = by.clone();
                let name = name.clone();
                let o = (**o).clone();
                let rw = rw.clone();
                call_then(start_subst_rigid(name.clone(), by.clone(), o.clone()), move |subst_rigid_7563: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(rw.clone(), Rc::new(subst_rigid_7563))))
            },
            other => prism_rtl::Turn::Finished(other.clone()),
        }
    }
}

/// `Start SubstRigid, x`: what the function value is when passed to `@Run`.
pub fn start_subst_rigid(name: Text, by: crate::check::types::Ty, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(SubstRigid { name, by, t })
}

/// ```prism
/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
/// ```
pub fn match_result(env: &crate::check::expr::Env, st: &crate::check::types::St, sh: &Text, layers: &Array<(Text, crate::syntax::Range)>, res: &crate::check::types::Ty, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let events = filter(layers, &(|(h, _): &(Text, crate::syntax::Range)| h == &Text::lit("!")));
    let dyns = filter(layers, &(|(h, _): &(Text, crate::syntax::Range)| h == &Text::lit("$")));
    let blue = filter(layers, &(|(h, _): &(Text, crate::syntax::Range)| h == &Text::lit("@")));
    let st2 = if (&len(&blue) > &Nat::from(0u32)) && crate::check::expr::is_time_sigil(sh) {
        crate::check::types::recording::err_fix(st, &Text::lit("building-match"), span, &Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
    } else {
        st.clone()
    };
    let st3 = if (sh == &Text::lit("!")) && (&len(&events) > &Nat::from(0u32)) {
        crate::check::types::recording::err_fix(&st2, &Text::lit("two-events"), span, &Text::lit("two events in one operation"), &Text::lit("an arm over an event\'s scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
    } else {
        st2.clone()
    };
    if &len(&events) > &Nat::from(0u32) {
        (crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(res.clone())), crate::check::expr::calls::elab(&st3, span, &Text::lit("match"), &Text::lit("gate"), &Text::lit("!")))
    } else {
        if (sh == &Text::lit("$")) || (&len(&dyns) > &Nat::from(0u32)) {
            (crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(res.clone())), crate::check::expr::calls::elab(&st3, span, &Text::lit("match"), &Text::lit("map"), &Text::lit("$")))
        } else {
            if sh == &Text::lit("!") {
                (crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(res.clone())), crate::check::expr::calls::elab(&st3, span, &Text::lit("match"), &Text::lit("map"), &Text::lit("!")))
            } else {
                (res.clone(), st3.clone())
            }
        }
    }
}

/// The step machine of `MatchResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
/// ```
pub struct MatchResult {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub sh: Text,
    pub layers: Array<(Text, crate::syntax::Range)>,
    pub res: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for MatchResult {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let sh = &self.sh;
        let layers = &self.layers;
        let res = &self.res;
        let span = &self.span;
        let events = filter(layers, &(|(h, _): &(Text, crate::syntax::Range)| h == &Text::lit("!")));
        let dyns = filter(layers, &(|(h, _): &(Text, crate::syntax::Range)| h == &Text::lit("$")));
        let blue = filter(layers, &(|(h, _): &(Text, crate::syntax::Range)| h == &Text::lit("@")));
        let st2 = if (&len(&blue) > &Nat::from(0u32)) && crate::check::expr::is_time_sigil(sh) {
            crate::check::types::recording::err_fix(st, &Text::lit("building-match"), span, &Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
        } else {
            st.clone()
        };
        let st3 = if (sh == &Text::lit("!")) && (&len(&events) > &Nat::from(0u32)) {
            crate::check::types::recording::err_fix(&st2, &Text::lit("two-events"), span, &Text::lit("two events in one operation"), &Text::lit("an arm over an event\'s scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
        } else {
            st2.clone()
        };
        if &len(&events) > &Nat::from(0u32) {
            prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(res.clone())), crate::check::expr::calls::elab(&st3, span, &Text::lit("match"), &Text::lit("gate"), &Text::lit("!"))))
        } else {
            if (sh == &Text::lit("$")) || (&len(&dyns) > &Nat::from(0u32)) {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(res.clone())), crate::check::expr::calls::elab(&st3, span, &Text::lit("match"), &Text::lit("map"), &Text::lit("$"))))
            } else {
                if sh == &Text::lit("!") {
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(res.clone())), crate::check::expr::calls::elab(&st3, span, &Text::lit("match"), &Text::lit("map"), &Text::lit("!"))))
                } else {
                    prism_rtl::Turn::Finished((res.clone(), st3.clone()))
                }
            }
        }
    }
}

/// `Start MatchResult, x`: what the function value is when passed to `@Run`.
pub fn start_match_result(env: crate::check::expr::Env, st: crate::check::types::St, sh: Text, layers: Array<(Text, crate::syntax::Range)>, res: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(MatchResult { env, st, sh, layers, res, span })
}

/// ```prism
/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
/// ```
pub fn infer_if(env: &crate::check::expr::Env, st: &crate::check::types::St, c: &crate::syntax::Cond, then_b: &crate::syntax::Block, else_b_opt: &Option<crate::syntax::Block>, span: &crate::syntax::Range, expected_opt: &Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    match c {
        crate::syntax::Cond::CondExpr(e) => {
            let (ct, st1) = crate::check::expr::infer(env, st, &**e);
            let sh = crate::check::types::head_sigil(&st1, &ct);
            let inner = if crate::check::expr::is_time_sigil(&sh) {
                crate::check::expr::inner_of(&st1, &ct)
            } else {
                ct.clone()
            };
            let st2 = crate::check::types::unify::unify(&st1, &crate::check::types::t_bool(), &inner, &e.span);
            let (res, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
            let (layers, st4) = if_branches(env, &st3, env, then_b, else_b_opt, &res);
            match_result(env, &st4, &sh, &layers, &res, span)
        },
        crate::syntax::Cond::CondBind(p_, e, gd_opt) => {
            let (et, st1) = crate::check::expr::infer(env, st, &**e);
            let (env2, st2) = crate::check::expr::patterns::bind_pattern(env, &st1, p_, &et, &true);
            let st3 = match &**gd_opt {
                Some(g) => check_cond(&env2, &st2, g),
                None => st2.clone(),
            };
            let (res, st4) = crate::check::types::fresh_var(&st3, &false, &Text::lit(""));
            let (layers, st5) = if_branches(&env2, &st4, env, then_b, else_b_opt, &res);
            match_result(env, &st5, &Text::lit(""), &layers, &res, span)
        },
    }
}

/// The step machine of `InferIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
/// ```
pub struct InferIf {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub c: crate::syntax::Cond,
    pub then_b: crate::syntax::Block,
    pub else_b_opt: Option<crate::syntax::Block>,
    pub span: crate::syntax::Range,
    pub expected_opt: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferIf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let span = &self.span;
        let expected_opt = &self.expected_opt;
        match c {
            crate::syntax::Cond::CondExpr(e) => {
                let else_b_opt = else_b_opt.clone();
                let e = (**e).clone();
                let env = env.clone();
                let span = span.clone();
                let st = st.clone();
                let then_b = then_b.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_8896: (crate::check::types::Ty, crate::check::types::St)| {
                    let (ct, st1) = infer_8896;
                    call_then(crate::check::types::start_head_sigil(st1.clone(), ct.clone()), move |head_sigil_8930: Text| {
                        let sh = head_sigil_8930;
                        let inner = if crate::check::expr::is_time_sigil(&sh) {
                            crate::check::expr::inner_of(&st1, &ct)
                        } else {
                            ct.clone()
                        };
                        call_then(crate::check::types::unify::start_unify(st1.clone(), crate::check::types::t_bool(), inner.clone(), e.span.clone()), move |unify_9030: crate::check::types::St| {
                            let st2 = unify_9030;
                            let (res, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
                            call_then(start_if_branches(env.clone(), st3.clone(), env.clone(), then_b.clone(), else_b_opt.clone(), res.clone()), move |if_branches_9143: (Array<(Text, crate::syntax::Range)>, crate::check::types::St)| {
                                let (layers, st4) = if_branches_9143;
                                prism_rtl::Turn::More(Rc::new(MatchResult { env: env.clone(), st: st4.clone(), sh: sh.clone(), layers: layers.clone(), res: res.clone(), span: span.clone() }))
                            })
                        })
                    })
                })
            },
            crate::syntax::Cond::CondBind(p_, e, gd_opt) => {
                let else_b_opt = else_b_opt.clone();
                let gd_opt = (**gd_opt).clone();
                let c = c.clone();
                let e = (**e).clone();
                let env = env.clone();
                let p_ = p_.clone();
                let span = span.clone();
                let st = st.clone();
                let then_b = then_b.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_9290: (crate::check::types::Ty, crate::check::types::St)| {
                    let (et, st1) = infer_9290;
                    call_then(crate::check::expr::patterns::start_bind_pattern(env.clone(), st1.clone(), p_.clone(), et.clone(), true), move |bind_pattern_9335: (crate::check::expr::Env, crate::check::types::St)| {
                        let (env2, st2) = bind_pattern_9335;
                        let st3 = match &gd_opt {
                            Some(g) => check_cond(&env2, &st2, g),
                            None => st2.clone(),
                        };
                        let (res, st4) = crate::check::types::fresh_var(&st3, &false, &Text::lit(""));
                        call_then(start_if_branches(env2.clone(), st4.clone(), env.clone(), then_b.clone(), else_b_opt.clone(), res.clone()), move |if_branches_9540: (Array<(Text, crate::syntax::Range)>, crate::check::types::St)| {
                            let (layers, st5) = if_branches_9540;
                            prism_rtl::Turn::More(Rc::new(MatchResult { env: env.clone(), st: st5.clone(), sh: Text::lit(""), layers: layers.clone(), res: res.clone(), span: span.clone() }))
                        })
                    })
                })
            },
        }
    }
}

/// `Start InferIf, x`: what the function value is when passed to `@Run`.
pub fn start_infer_if(env: crate::check::expr::Env, st: crate::check::types::St, c: crate::syntax::Cond, then_b: crate::syntax::Block, else_b_opt: Option<crate::syntax::Block>, span: crate::syntax::Range, expected_opt: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferIf { env, st, c, then_b, else_b_opt, span, expected_opt })
}

/// ```prism
/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub fn unify_arm(st: &crate::check::types::St, res: &crate::check::types::Ty, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> crate::check::types::St {
    if crate::check::types::is_flex_var(st, res) && (&crate::check::types::recording::walk(st, t) == &crate::check::types::Ty::TyCon(Text::lit("Prelude.Error"), Array::new())) {
        crate::check::types::unify::defer(st, res, t, span)
    } else {
        crate::check::types::unify::unify(st, res, t, span)
    }
}

/// The step machine of `UnifyArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub struct UnifyArm {
    pub st: crate::check::types::St,
    pub res: crate::check::types::Ty,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for UnifyArm {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let res = &self.res;
        let t = &self.t;
        let span = &self.span;
        let res = res.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::start_is_flex_var(st.clone(), res.clone()), move |is_flex_var_9877: bool| if is_flex_var_9877 && (&crate::check::types::recording::walk(&st, &t) == &crate::check::types::Ty::TyCon(Text::lit("Prelude.Error"), Array::new())) {
            prism_rtl::Turn::Finished(crate::check::types::unify::defer(&st, &res, &t, &span))
        } else {
            prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st.clone(), expected: res.clone(), found: t.clone(), span: span.clone() }))
        })
    }
}

/// `Start UnifyArm, x`: what the function value is when passed to `@Run`.
pub fn start_unify_arm(st: crate::check::types::St, res: crate::check::types::Ty, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UnifyArm { st, res, t, span })
}

/// ```prism
/// LayerHead: fn Text -> Text
/// ```
pub fn layer_head(h: &Text) -> Text {
    if crate::check::expr::is_time_sigil(h) {
        h.clone()
    } else {
        if h == &Text::lit("@") { Text::lit("@") } else { Text::lit("") }
    }
}

/// ```prism
/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
/// ```
pub fn if_branches(then_env: &crate::check::expr::Env, st: &crate::check::types::St, else_env: &crate::check::expr::Env, then_b: &crate::syntax::Block, else_b_opt: &Option<crate::syntax::Block>, res: &crate::check::types::Ty) -> (Array<(Text, crate::syntax::Range)>, crate::check::types::St) {
    let (t1, st1) = crate::check::expr::lets::infer_expr_block(then_env, st, then_b);
    let h1 = crate::check::types::head_sigil(&st1, &t1);
    let st2 = unify_arm(&st1, res, &(if crate::check::expr::is_time_sigil(&h1) {
        crate::check::expr::inner_of(&st1, &t1)
    } else {
        t1.clone()
    }), &then_b.span);
    let l1 = Array::from(vec![(layer_head(&h1), then_b.span.clone())]);
    match else_b_opt {
        Some(b) => {
            let (t2, st3) = crate::check::expr::lets::infer_expr_block(else_env, &st2, b);
            let h2 = crate::check::types::head_sigil(&st3, &t2);
            let st4 = unify_arm(&st3, res, &(if crate::check::expr::is_time_sigil(&h2) {
                crate::check::expr::inner_of(&st3, &t2)
            } else {
                t2.clone()
            }), &b.span);
            (push(&l1, &(layer_head(&h2), b.span.clone())), st4.clone())
        },
        None => (l1.clone(), crate::check::types::unify::unify(&st2, res, &crate::check::types::t_unit(), &then_b.span)),
    }
}

/// The step machine of `IfBranches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
/// ```
pub struct IfBranches {
    pub then_env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub else_env: crate::check::expr::Env,
    pub then_b: crate::syntax::Block,
    pub else_b_opt: Option<crate::syntax::Block>,
    pub res: crate::check::types::Ty,
}

impl prism_rtl::Job<(Array<(Text, crate::syntax::Range)>, crate::check::types::St)> for IfBranches {
    fn cycle(&self) -> prism_rtl::Turn<(Array<(Text, crate::syntax::Range)>, crate::check::types::St)> {
        let then_env = &self.then_env;
        let st = &self.st;
        let else_env = &self.else_env;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let res = &self.res;
        let else_b_opt = else_b_opt.clone();
        let else_env = else_env.clone();
        let res = res.clone();
        let st = st.clone();
        let then_b = then_b.clone();
        let then_env = then_env.clone();
        call_then(crate::check::expr::lets::start_infer_expr_block(then_env.clone(), st.clone(), then_b.clone()), move |infer_expr_block_10261: (crate::check::types::Ty, crate::check::types::St)| {
            let (t1, st1) = infer_expr_block_10261;
            call_then(crate::check::types::start_head_sigil(st1.clone(), t1.clone()), move |head_sigil_10308: Text| {
                let h1 = head_sigil_10308;
                call_then(start_unify_arm(st1.clone(), res.clone(), if crate::check::expr::is_time_sigil(&h1) {
                    crate::check::expr::inner_of(&st1, &t1)
                } else {
                    t1.clone()
                }, then_b.span.clone()), move |unify_arm_10340: crate::check::types::St| {
                    let st2 = unify_arm_10340;
                    let l1 = Array::from(vec![(layer_head(&h1), then_b.span.clone())]);
                    match &else_b_opt {
                        Some(b) => {
                            let b = b.clone();
                            call_then(crate::check::expr::lets::start_infer_expr_block(else_env.clone(), st2.clone(), b.clone()), move |infer_expr_block_10526: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t2, st3) = infer_expr_block_10526;
                                call_then(crate::check::types::start_head_sigil(st3.clone(), t2.clone()), move |head_sigil_10578: Text| {
                                    let h2 = head_sigil_10578;
                                    call_then(start_unify_arm(st3.clone(), res.clone(), if crate::check::expr::is_time_sigil(&h2) {
                                        crate::check::expr::inner_of(&st3, &t2)
                                    } else {
                                        t2.clone()
                                    }, b.span.clone()), move |unify_arm_10618: crate::check::types::St| {
                                        let st4 = unify_arm_10618;
                                        prism_rtl::Turn::Finished((push(&l1, &(layer_head(&h2), b.span.clone())), st4.clone()))
                                    })
                                })
                            })
                        },
                        None => call_then(crate::check::types::unify::start_unify(st2.clone(), res.clone(), crate::check::types::t_unit(), then_b.span.clone()), move |unify_10770: crate::check::types::St| prism_rtl::Turn::Finished((l1.clone(), unify_10770))),
                    }
                })
            })
        })
    }
}

/// `Start IfBranches, x`: what the function value is when passed to `@Run`.
pub fn start_if_branches(then_env: crate::check::expr::Env, st: crate::check::types::St, else_env: crate::check::expr::Env, then_b: crate::syntax::Block, else_b_opt: Option<crate::syntax::Block>, res: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::syntax::Range)>, crate::check::types::St)>> {
    Rc::new(IfBranches { then_env, st, else_env, then_b, else_b_opt, res })
}
