//! The module `Check.Expr`, from `target/bootstrap/src/prismc/check/expr/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod calls;
pub mod lets;
pub mod lifting;
pub mod operators;
pub mod patterns;

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Env {
    pub g_p: crate::check::env::G,
    pub home_p: Text,
    pub file_p: Nat,
    pub src_p: crate::check::errors::Src,
    pub locals_p: Map<Text, crate::check::types::Scheme>,
    pub scope_p: crate::check::types::Rw,
    pub givens_p: Array<(Text, Text)>,
    pub mark_p: Text,
    pub in_update_p: bool,
    pub def_name_p: Text,
    pub refine_p: Map<Text, crate::check::types::Ty>,
    pub pending_p: Array<Text>,
    pub ids_p: Map<Text, Nat>,
}

impl Show for Env {
    fn show(&self, p: &mut Printer) {
        p.record("Env", &[("g", &self.g_p), ("home", &self.home_p), ("file", &self.file_p), ("src", &self.src_p), ("locals", &self.locals_p), ("scope", &self.scope_p), ("givens", &self.givens_p), ("mark", &self.mark_p), ("inUpdate", &self.in_update_p), ("defName", &self.def_name_p), ("refine", &self.refine_p), ("pending", &self.pending_p), ("ids", &self.ids_p)]);
    }
}

impl ToPod for Env {
    fn to_pod(&self) -> Pod {
        Pod::record("Env", vec![("g", self.g_p.to_pod()), ("home", self.home_p.to_pod()), ("file", self.file_p.to_pod()), ("src", self.src_p.to_pod()), ("locals", self.locals_p.to_pod()), ("scope", self.scope_p.to_pod()), ("givens", self.givens_p.to_pod()), ("mark", self.mark_p.to_pod()), ("inUpdate", self.in_update_p.to_pod()), ("defName", self.def_name_p.to_pod()), ("refine", self.refine_p.to_pod()), ("pending", self.pending_p.to_pod()), ("ids", self.ids_p.to_pod())])
    }
}

impl FromPod for Env {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Env { g_p: FromPod::from_pod(field(p, "g")?)?, home_p: FromPod::from_pod(field(p, "home")?)?, file_p: FromPod::from_pod(field(p, "file")?)?, src_p: FromPod::from_pod(field(p, "src")?)?, locals_p: FromPod::from_pod(field(p, "locals")?)?, scope_p: FromPod::from_pod(field(p, "scope")?)?, givens_p: FromPod::from_pod(field(p, "givens")?)?, mark_p: FromPod::from_pod(field(p, "mark")?)?, in_update_p: FromPod::from_pod(field(p, "inUpdate")?)?, def_name_p: FromPod::from_pod(field(p, "defName")?)?, refine_p: FromPod::from_pod(field(p, "refine")?)?, pending_p: FromPod::from_pod(field(p, "pending")?)?, ids_p: FromPod::from_pod(field(p, "ids")?)? })
    }
}

/// ```prism
/// WithLocal: fn Env, Text, Scheme -> Env
/// ```
pub fn with_local_f(env_p0: &Env, name_p1: &Text, sc_p2: &crate::check::types::Scheme) -> Env {
    let mut this: Env = env_p0.clone();
    this.locals_p = crate::prelude::insert(&this.locals_p, name_p1, sc_p2);
    this
}

/// ```prism
/// CallId: fn St, Text, Range -> St
/// ```
pub fn call_id_f(st_p0: &crate::check::types::St, qk_p1: &Text, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    if !crate::syntax::lexer::chars::has_prefix_f(&crate::check::types::bare_name_f(qk_p1), &Text::lit("@")) {
        st_p0.clone()
    } else {
        {
            let s2_p3 = {
                let mut this: crate::check::types::St = st_p0.clone();
                this.local_next_p = &this.local_next_p + &Nat::from(1u32);
                this
            };
            crate::check::types::recording::note_call_f(&s2_p3, span_p2, &st_p0.local_next_p)
        }
    }
}

/// ```prism
/// BindLocalId: fn Env, St, Text, Range -> ((Env, St))
/// ```
pub fn bind_local_id_f(env_p0: &Env, st_p1: &crate::check::types::St, name_p2: &Text, span_p3: &crate::syntax::Range) -> (Env, crate::check::types::St) {
    let place_p4 = Text::from(format!("{}:{}:{}", &st_p1.file_p, &span_p3.start_p, &span_p3.end_p));
    let (id_p9, st2_pa) = match crate::prelude::get(&st_p1.local_ids_p, &place_p4) {
        Some(i_p6) => (i_p6, st_p1.clone()),
        None => {
            let fresh_p7 = st_p1.local_next_p.clone();
            let s2_p8 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.local_next_p = &this.local_next_p + &Nat::from(1u32);
                this.local_ids_p = crate::prelude::insert(&this.local_ids_p, &place_p4, &fresh_p7);
                this
            };
            (fresh_p7.clone(), crate::check::types::recording::note_local_f(&s2_p8, span_p3, &fresh_p7))
        },
    };
    let env2_p5 = {
        let mut this: Env = env_p0.clone();
        this.ids_p = crate::prelude::insert(&this.ids_p, name_p2, &id_p9);
        this
    };
    (env2_p5.clone(), st2_pa.clone())
}

/// ```prism
/// SrcText: fn Env, Range -> Text
/// ```
pub fn src_text_f(env_p0: &Env, r_p1: &crate::syntax::Range) -> Text {
    crate::check::errors::span_text_f(&env_p0.src_p, r_p1)
}

/// ```prism
/// IsComparison: fn Text -> Bool
/// ```
pub fn is_comparison_f(n_p0: &Text) -> bool {
    crate::check::types::has_text_f(&Array::from(vec![Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">="), Text::lit("Compare"), Text::lit("?"), Text::lit("~"), Text::lit("$")]), n_p0)
}

/// ```prism
/// HasTimeMark: fn Text -> Bool
/// ```
pub fn has_time_mark_f(marks_p0: &Text) -> bool {
    crate::syntax::lexer::chars::contains_f(marks_p0, &Text::lit("$")) || crate::syntax::lexer::chars::contains_f(marks_p0, &Text::lit("!"))
}

/// ```prism
/// IsTimeSigil: fn Text -> Bool
/// ```
pub fn is_time_sigil_f(s_p0: &Text) -> bool {
    (s_p0 == &Text::lit("$")) || (s_p0 == &Text::lit("!"))
}

/// ```prism
/// IsPlainSigil: fn Text -> Bool
/// ```
pub fn is_plain_sigil_f(s_p0: &Text) -> bool {
    (s_p0 == &Text::lit("?")) || (s_p0 == &Text::lit("~"))
}

/// ```prism
/// InnerOf: unbounded fn St, Ty -> Ty
/// ```
pub fn inner_of_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TySig(_, i_p2) => (*i_p2).clone(),
        crate::check::types::Ty::TyAt(i_p3, _) => (*i_p3).clone(),
        other_p4 => other_p4,
    }
}

/// The step machine of `InnerOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InnerOf: unbounded fn St, Ty -> Ty
/// ```
pub struct InnerOf {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for InnerOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_4169: crate::check::types::Ty| match walk_f_4169 {
            crate::check::types::Ty::TySig(_, i_p2) => prism_rtl::Turn::Finished((*i_p2).clone()),
            crate::check::types::Ty::TyAt(i_p3, _) => prism_rtl::Turn::Finished((*i_p3).clone()),
            other_p4 => prism_rtl::Turn::Finished(other_p4.clone()),
        })
    }
}

/// `Start InnerOf, x`: what the function value is when passed to `@Run`.
pub fn start_inner_of_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(InnerOf { st_p0, t_p1 })
}

/// ```prism
/// IsLambda: fn Expr -> Bool
/// ```
pub fn is_lambda_f(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ELambda(_, _) => true,
        crate::syntax::ExprKind::ETopicField(_) => true,
        crate::syntax::ExprKind::ETopicIndex(_) => true,
        crate::syntax::ExprKind::EGroup(x_p1) => is_lambda_f(&**x_p1),
        _ => false,
    }
}

/// ```prism
/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub fn infer_f(env_p0: &Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p3, st2_p4) = infer_kind_f(env_p0, st_p1, e_p2);
    (t_p3.clone(), crate::check::types::recording::note_ty_f(&st2_p4, &e_p2.span_p, &t_p3))
}

/// The step machine of `Infer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub struct Infer {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for Infer {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let e_p2x = e_p2.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_infer_kind_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone()), move |infer_kind_f_4721: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p3, st2_p4) = infer_kind_f_4721;
            prism_rtl::Turn::Finished((t_p3.clone(), crate::check::types::recording::note_ty_f(&st2_p4, &e_p2x.span_p, &t_p3)))
        })
    }
}

/// `Start Infer, x`: what the function value is when passed to `@Run`.
pub fn start_infer_f(env_p0: Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(Infer { env_p0, st_p1, e_p2 })
}

/// ```prism
/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub fn infer_kind_f(env_p0: &Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EName(n_p3) => infer_name_f(env_p0, st_p1, n_p3, &e_p2.span_p),
        crate::syntax::ExprKind::ELit(l_p4) => infer_lit_f(env_p0, st_p1, l_p4, &false, &e_p2.span_p),
        crate::syntax::ExprKind::EUnit(marks_p5) => (crate::check::types::with_marks_f(marks_p5, &crate::check::types::t_unit_p(), &env_p0.scope_p), st_p1.clone()),
        crate::syntax::ExprKind::ENil(marks_p6) => {
            let (v_p7, st2_p8) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
            (crate::check::types::with_marks_f(marks_p6, &crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_p7.clone())), &env_p0.scope_p), st2_p8.clone())
        },
        crate::syntax::ExprKind::EBound(b_p9) => infer_bound_f(env_p0, st_p1, b_p9, &e_p2.span_p),
        crate::syntax::ExprKind::ETuple(es_pa) => {
            let (ts_pb, st2_pc) = infer_all_f(env_p0, st_p1, es_pa);
            (crate::check::types::Ty::TyTuple(ts_pb.clone()), st2_pc.clone())
        },
        crate::syntax::ExprKind::EArray(es_pd) => crate::check::expr::operators::infer_array_f(env_p0, st_p1, es_pd, &e_p2.span_p),
        crate::syntax::ExprKind::EMap(entries_pe) => crate::check::expr::operators::infer_map_f(env_p0, st_p1, entries_pe, &e_p2.span_p),
        crate::syntax::ExprKind::EGroup(x_pf) => infer_f(env_p0, st_p1, &**x_pf),
        crate::syntax::ExprKind::ECall(callee_pg, args_ph, _, _) => crate::check::expr::calls::infer_call_f(env_p0, st_p1, &**callee_pg, args_ph, &e_p2.span_p),
        crate::syntax::ExprKind::EBinary(op_pi, lhs_pj, rhs_pk) => crate::check::expr::operators::infer_binary_f(env_p0, st_p1, op_pi, &**lhs_pj, &**rhs_pk, &e_p2.span_p),
        crate::syntax::ExprKind::EUnary(op_pl, x_pm) => crate::check::expr::operators::infer_unary_f(env_p0, st_p1, op_pl, &**x_pm, &e_p2.span_p),
        crate::syntax::ExprKind::ESuffixed(_, _, _, _) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &e_p2.span_p, &Text::lit("this checker does not implement suffixed operators"))),
        crate::syntax::ExprKind::EFreeSigil(s_pn, x_po) => crate::check::expr::operators::infer_free_sigil_f(env_p0, st_p1, s_pn, &**x_po, &e_p2.span_p),
        crate::syntax::ExprKind::EField(recv_pp, sigils_pq, name_pr) => crate::check::expr::operators::infer_field_f(env_p0, st_p1, &**recv_pp, sigils_pq, name_pr, &e_p2.span_p),
        crate::syntax::ExprKind::EIndex(recv_ps, idx_pt) => crate::check::expr::operators::infer_index_f(env_p0, st_p1, &**recv_ps, &**idx_pt, &e_p2.span_p),
        crate::syntax::ExprKind::ETopicField(_) => crate::check::expr::calls::infer_lambda_f(env_p0, st_p1, e_p2, &None),
        crate::syntax::ExprKind::ETopicIndex(_) => crate::check::expr::calls::infer_lambda_f(env_p0, st_p1, e_p2, &None),
        crate::syntax::ExprKind::EMethod(recv_pu, m_pv, args_p10) => crate::check::expr::calls::infer_call_f(env_p0, st_p1, &crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EName(m_pv.clone())), span_p: m_pv.span_p.clone() }, &crate::prelude::append(&Array::from(vec![crate::syntax::Arg { name_o: None, value_p: (**recv_pu).clone(), span_p: recv_pu.span_p.clone() }]), args_p10), &e_p2.span_p),
        crate::syntax::ExprKind::ETypeArgs(target_p11, _) => crate::check::expr::calls::infer_call_f(env_p0, st_p1, e_p2, &Array::new(), &e_p2.span_p),
        crate::syntax::ExprKind::ECast(x_p12, ty_p13, checked_p14) => if *checked_p14 {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &e_p2.span_p, &Text::lit("this checker does not implement non-empty arrays")))
        } else {
            {
                let cx_p15 = env_cx_f(env_p0);
                let (t_p17, st2_p18) = crate::check::env::reading::conv_type_f(&cx_p15, st_p1, ty_p13);
                let st3_p16 = check_f(env_p0, &st2_p18, &**x_p12, &t_p17);
                (t_p17.clone(), st3_p16.clone())
            }
        },
        crate::syntax::ExprKind::ENonEmpty(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &e_p2.span_p, &Text::lit("this checker does not implement non-empty arrays"))),
        crate::syntax::ExprKind::EAbsent => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &e_p2.span_p, &Text::lit("this checker does not implement sparse tuples"))),
        crate::syntax::ExprKind::ERest => (crate::check::types::Ty::TyErr, st_p1.clone()),
        crate::syntax::ExprKind::ELambda(_, _) => crate::check::expr::calls::infer_lambda_f(env_p0, st_p1, e_p2, &None),
        crate::syntax::ExprKind::EIf(c_p19, then_b_p1a, else_b_o1b) => crate::check::expr::lifting::infer_if_f(env_p0, st_p1, &**c_p19, then_b_p1a, else_b_o1b, &e_p2.span_p, &None),
        crate::syntax::ExprKind::EMatch(scrut_p1c, arms_p1d) => crate::check::expr::lifting::infer_match_f(env_p0, st_p1, &**scrut_p1c, arms_p1d, &e_p2.span_p, &None),
        crate::syntax::ExprKind::ERebuild(scrut_p1e, body_p1f) => crate::check::blocks::structure::infer_rebuild_f(env_p0, st_p1, &**scrut_p1e, body_p1f, &e_p2.span_p),
        crate::syntax::ExprKind::EFor(binders_o1g, source_p1h, body_p1i) => crate::check::blocks::structure::infer_for_f(env_p0, st_p1, binders_o1g, &**source_p1h, body_p1i, &e_p2.span_p),
        crate::syntax::ExprKind::EGiven(b_p1j) => crate::check::blocks::structure::infer_given_f(env_p0, st_p1, b_p1j, &e_p2.span_p),
        crate::syntax::ExprKind::EUpdate(target_p1k, body_p1l) => crate::check::blocks::borrows::infer_update_f(env_p0, st_p1, &**target_p1k, body_p1l, &e_p2.span_p),
        crate::syntax::ExprKind::EWidgetBlock(b_p1m) => {
            let (t_p1n, st2_p1o) = crate::check::blocks::infer_widget_block_f(env_p0, st_p1, b_p1m);
            (crate::check::types::Ty::TyAt(Rc::new(t_p1n.clone()), env_p0.scope_p.clone()), st2_p1o.clone())
        },
        crate::syntax::ExprKind::EMonad(_, _) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &e_p2.span_p, &Text::lit("this checker does not implement `T monad:` blocks"))),
        crate::syntax::ExprKind::ETemplate(t_p1p) => crate::check::expr::lets::infer_template_f(env_p0, st_p1, t_p1p),
        crate::syntax::ExprKind::EAny(x_p1q) => {
            let (t_p1r, st2_p1s) = infer_f(env_p0, st_p1, &**x_p1q);
            (crate::check::types::Ty::TyAny(Array::new()), st2_p1s.clone())
        },
        crate::syntax::ExprKind::ELens(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &e_p2.span_p, &Text::lit("this checker does not implement named lenses and `Over`"))),
        crate::syntax::ExprKind::EError => (crate::check::types::Ty::TyErr, st_p1.clone()),
    }
}

/// The step machine of `InferKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub struct InferKind {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferKind {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EName(n_p3) => prism_rtl::Turn::More(Rc::new(InferName { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p3.clone(), span_p3: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::ELit(l_p4) => prism_rtl::Turn::More(Rc::new(InferLit { env_p0: env_p0.clone(), st_p1: st_p1.clone(), l_p2: l_p4.clone(), negative_p3: false, span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EUnit(marks_p5) => prism_rtl::Turn::Finished((crate::check::types::with_marks_f(marks_p5, &crate::check::types::t_unit_p(), &env_p0.scope_p), st_p1.clone())),
            crate::syntax::ExprKind::ENil(marks_p6) => {
                let (v_p7, st2_p8) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
                prism_rtl::Turn::Finished((crate::check::types::with_marks_f(marks_p6, &crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_p7.clone())), &env_p0.scope_p), st2_p8.clone()))
            },
            crate::syntax::ExprKind::EBound(b_p9) => prism_rtl::Turn::Finished(infer_bound_f(env_p0, st_p1, b_p9, &e_p2.span_p)),
            crate::syntax::ExprKind::ETuple(es_pa) => {
                let env_p0x = env_p0.clone();
                let es_pax = es_pa.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_infer_all_f(env_p0x.clone(), st_p1x.clone(), es_pax.clone()), move |infer_all_f_5231: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (ts_pb, st2_pc) = infer_all_f_5231;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyTuple(ts_pb.clone()), st2_pc.clone()))
                })
            },
            crate::syntax::ExprKind::EArray(es_pd) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferArray { env_p0: env_p0.clone(), st_p1: st_p1.clone(), es_p2: es_pd.clone(), span_p3: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EMap(entries_pe) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferMap { env_p0: env_p0.clone(), st_p1: st_p1.clone(), entries_p2: entries_pe.clone(), span_p3: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EGroup(x_pf) => prism_rtl::Turn::More(Rc::new(Infer { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: (**x_pf).clone() })),
            crate::syntax::ExprKind::ECall(callee_pg, args_ph, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferCall { env_p0: env_p0.clone(), st_p1: st_p1.clone(), callee_p2: (**callee_pg).clone(), args_p3: args_ph.clone(), span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EBinary(op_pi, lhs_pj, rhs_pk) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferBinary { env_p0: env_p0.clone(), st_p1: st_p1.clone(), op_p2: op_pi.clone(), lhs_p3: (**lhs_pj).clone(), rhs_p4: (**rhs_pk).clone(), span_p5: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EUnary(op_pl, x_pm) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferUnary { env_p0: env_p0.clone(), st_p1: st_p1.clone(), op_p2: op_pl.clone(), x_p3: (**x_pm).clone(), span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::ESuffixed(_, _, _, _) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &e_p2.span_p, &Text::lit("this checker does not implement suffixed operators")))),
            crate::syntax::ExprKind::EFreeSigil(s_pn, x_po) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferFreeSigil { env_p0: env_p0.clone(), st_p1: st_p1.clone(), s_p2: s_pn.clone(), x_p3: (**x_po).clone(), span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EField(recv_pp, sigils_pq, name_pr) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferField { env_p0: env_p0.clone(), st_p1: st_p1.clone(), recv_p2: (**recv_pp).clone(), sigils_p3: sigils_pq.clone(), name_p4: name_pr.clone(), span_p5: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EIndex(recv_ps, idx_pt) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferIndex { env_p0: env_p0.clone(), st_p1: st_p1.clone(), recv_p2: (**recv_ps).clone(), idx_p3: (**idx_pt).clone(), span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::ETopicField(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferLambda { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p2.clone(), expected_o3: None })),
            crate::syntax::ExprKind::ETopicIndex(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferLambda { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p2.clone(), expected_o3: None })),
            crate::syntax::ExprKind::EMethod(recv_pu, m_pv, args_p10) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferCall { env_p0: env_p0.clone(), st_p1: st_p1.clone(), callee_p2: crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EName(m_pv.clone())), span_p: m_pv.span_p.clone() }, args_p3: crate::prelude::append(&Array::from(vec![crate::syntax::Arg { name_o: None, value_p: (**recv_pu).clone(), span_p: recv_pu.span_p.clone() }]), args_p10), span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::ETypeArgs(target_p11, _) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferCall { env_p0: env_p0.clone(), st_p1: st_p1.clone(), callee_p2: e_p2.clone(), args_p3: Array::new(), span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::ECast(x_p12, ty_p13, checked_p14) => if *checked_p14 {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &e_p2.span_p, &Text::lit("this checker does not implement non-empty arrays"))))
            } else {
                {
                    let cx_p15 = env_cx_f(env_p0);
                    let env_p0x = env_p0.clone();
                    let st_p1x = st_p1.clone();
                    let ty_p13x = ty_p13.clone();
                    let x_p12x = (**x_p12).clone();
                    crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p15.clone(), st_p1x.clone(), ty_p13x.clone()), move |conv_type_f_6484: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_p17, st2_p18) = conv_type_f_6484;
                        crate::prelude::call_then(start_check_f(env_p0x.clone(), st2_p18.clone(), x_p12x.clone(), t_p17.clone()), move |check_f_6526: crate::check::types::St| {
                            let st3_p16 = check_f_6526;
                            prism_rtl::Turn::Finished((t_p17.clone(), st3_p16.clone()))
                        })
                    })
                }
            },
            crate::syntax::ExprKind::ENonEmpty(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &e_p2.span_p, &Text::lit("this checker does not implement non-empty arrays")))),
            crate::syntax::ExprKind::EAbsent => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &e_p2.span_p, &Text::lit("this checker does not implement sparse tuples")))),
            crate::syntax::ExprKind::ERest => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st_p1.clone())),
            crate::syntax::ExprKind::ELambda(_, _) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferLambda { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p2.clone(), expected_o3: None })),
            crate::syntax::ExprKind::EIf(c_p19, then_b_p1a, else_b_o1b) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lifting::InferIf { env_p0: env_p0.clone(), st_p1: st_p1.clone(), c_p2: (**c_p19).clone(), then_b_p3: then_b_p1a.clone(), else_b_o4: else_b_o1b.clone(), span_p5: e_p2.span_p.clone(), expected_o6: None })),
            crate::syntax::ExprKind::EMatch(scrut_p1c, arms_p1d) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lifting::InferMatch { env_p0: env_p0.clone(), st_p1: st_p1.clone(), scrut_p2: (**scrut_p1c).clone(), arms_p3: arms_p1d.clone(), span_p4: e_p2.span_p.clone(), expected_o5: None })),
            crate::syntax::ExprKind::ERebuild(scrut_p1e, body_p1f) => prism_rtl::Turn::More(Rc::new(crate::check::blocks::structure::InferRebuild { env_p0: env_p0.clone(), st_p1: st_p1.clone(), scrut_p2: (**scrut_p1e).clone(), body_p3: body_p1f.clone(), span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EFor(binders_o1g, source_p1h, body_p1i) => prism_rtl::Turn::More(Rc::new(crate::check::blocks::structure::InferFor { env_p0: env_p0.clone(), st_p1: st_p1.clone(), binders_o2: binders_o1g.clone(), source_p3: (**source_p1h).clone(), body_p4: body_p1i.clone(), span_p5: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EGiven(b_p1j) => prism_rtl::Turn::More(Rc::new(crate::check::blocks::structure::InferGiven { env_p0: env_p0.clone(), st_p1: st_p1.clone(), b_p2: b_p1j.clone(), span_p3: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EUpdate(target_p1k, body_p1l) => prism_rtl::Turn::More(Rc::new(crate::check::blocks::borrows::InferUpdate { env_p0: env_p0.clone(), st_p1: st_p1.clone(), target_p2: (**target_p1k).clone(), body_p3: body_p1l.clone(), span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EWidgetBlock(b_p1m) => {
                let b_p1mx = b_p1m.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_f(env_p0x.clone(), st_p1x.clone(), b_p1mx.clone()), move |infer_widget_block_f_7322: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p1n, st2_p1o) = infer_widget_block_f_7322;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyAt(Rc::new(t_p1n.clone()), env_p0x.scope_p.clone()), st2_p1o.clone()))
                })
            },
            crate::syntax::ExprKind::EMonad(_, _) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &e_p2.span_p, &Text::lit("this checker does not implement `T monad:` blocks")))),
            crate::syntax::ExprKind::ETemplate(t_p1p) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::InferTemplate { env_p0: env_p0.clone(), st_p1: st_p1.clone(), t_p2: t_p1p.clone() })),
            crate::syntax::ExprKind::EAny(x_p1q) => {
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let x_p1qx = (**x_p1q).clone();
                crate::prelude::call_then(start_infer_f(env_p0x.clone(), st_p1x.clone(), x_p1qx.clone()), move |infer_f_7589: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p1r, st2_p1s) = infer_f_7589;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyAny(Array::new()), st2_p1s.clone()))
                })
            },
            crate::syntax::ExprKind::ELens(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unsupported"), &e_p2.span_p, &Text::lit("this checker does not implement named lenses and `Over`")))),
            crate::syntax::ExprKind::EError => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st_p1.clone())),
        }
    }
}

/// `Start InferKind, x`: what the function value is when passed to `@Run`.
pub fn start_infer_kind_f(env_p0: Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferKind { env_p0, st_p1, e_p2 })
}

/// ```prism
/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
/// ```
pub fn infer_all_f(env_p0: &Env, st_p1: &crate::check::types::St, es_p2: &Array<crate::syntax::Expr>) -> (Array<crate::check::types::Ty>, crate::check::types::St) {
    crate::prelude::run_to_end(crate::prelude::fold_job(es_p2.clone(), (Array::new(), st_p1.clone()), {
        let env_p0x = env_p0.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)| {
            let env_p0xy = env_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p3, s_p4) = p0;
                let x_p5 = p1;
                crate::prelude::call_then(start_infer_f(env_p0xy.clone(), s_p4.clone(), x_p5.clone()), move |infer_f_7922: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p6, s2_p7) = infer_f_7922;
                    prism_rtl::Turn::Finished((crate::prelude::push(&acc_p3, &t_p6), s2_p7.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }))
}

/// The step machine of `InferAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
/// ```
pub struct InferAll {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub es_p2: Array<crate::syntax::Expr>,
}

impl prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)> for InferAll {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Ty>, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let es_p2 = &self.es_p2;
        crate::prelude::fold_job(es_p2.clone(), (Array::new(), st_p1.clone()), {
            let env_p0x = env_p0.clone();
            Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)| {
                let env_p0xy = env_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p3, s_p4) = p0;
                    let x_p5 = p1;
                    crate::prelude::call_then(start_infer_f(env_p0xy.clone(), s_p4.clone(), x_p5.clone()), move |infer_f_7922: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_p6, s2_p7) = infer_f_7922;
                        prism_rtl::Turn::Finished((crate::prelude::push(&acc_p3, &t_p6), s2_p7.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start InferAll, x`: what the function value is when passed to `@Run`.
pub fn start_infer_all_f(env_p0: Env, st_p1: crate::check::types::St, es_p2: Array<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>> {
    Rc::new(InferAll { env_p0, st_p1, es_p2 })
}

/// ```prism
/// Check: unbounded fn Env, St, Expr, Ty -> St
/// ```
pub fn check_f(env_p0: &Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, expected_p3: &crate::check::types::Ty) -> crate::check::types::St {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::ELambda(_, _) => {
            let (t_p4, st2_p5) = crate::check::expr::calls::infer_lambda_f(env_p0, st_p1, e_p2, &Some(expected_p3.clone()));
            crate::check::types::unify::unify_f(&crate::check::types::recording::note_ty_f(&st2_p5, &e_p2.span_p, &t_p4), expected_p3, &t_p4, &e_p2.span_p)
        },
        crate::syntax::ExprKind::EGroup(x_p6) => crate::check::types::recording::note_ty_f(&check_f(env_p0, st_p1, &**x_p6, expected_p3), &e_p2.span_p, expected_p3),
        crate::syntax::ExprKind::EMatch(scrut_p7, arms_p8) => {
            let (t_p9, st2_pa) = crate::check::expr::lifting::infer_match_f(env_p0, st_p1, &**scrut_p7, arms_p8, &e_p2.span_p, &Some(expected_p3.clone()));
            crate::check::types::unify::unify_f(&crate::check::types::recording::note_ty_f(&st2_pa, &e_p2.span_p, &t_p9), expected_p3, &t_p9, &e_p2.span_p)
        },
        crate::syntax::ExprKind::EIf(c_pb, then_b_pc, else_b_od) => {
            let (t_pe, st2_pf) = crate::check::expr::lifting::infer_if_f(env_p0, st_p1, &**c_pb, then_b_pc, else_b_od, &e_p2.span_p, &Some(expected_p3.clone()));
            crate::check::types::unify::unify_f(&crate::check::types::recording::note_ty_f(&st2_pf, &e_p2.span_p, &t_pe), expected_p3, &t_pe, &e_p2.span_p)
        },
        crate::syntax::ExprKind::EAny(x_pg) => crate::check::types::recording::note_ty_f(&check_any_f(env_p0, st_p1, &**x_pg, expected_p3, &e_p2.span_p), &e_p2.span_p, expected_p3),
        _ => {
            let (t_ph, st2_pi) = infer_f(env_p0, st_p1, e_p2);
            crate::check::types::unify::unify_f(&st2_pi, expected_p3, &t_ph, &e_p2.span_p)
        },
    }
}

/// The step machine of `Check`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Check: unbounded fn Env, St, Expr, Ty -> St
/// ```
pub struct Check {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub expected_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for Check {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let expected_p3 = &self.expected_p3;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::ELambda(_, _) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::calls::start_infer_lambda_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone(), Some(expected_p3x.clone())), move |infer_lambda_f_8231: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p4, st2_p5) = infer_lambda_f_8231;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: crate::check::types::recording::note_ty_f(&st2_p5, &e_p2x.span_p, &t_p4), expected_p1: expected_p3x.clone(), found_p2: t_p4.clone(), span_p3: e_p2x.span_p.clone() }))
                })
            },
            crate::syntax::ExprKind::EGroup(x_p6) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                let x_p6x = (**x_p6).clone();
                crate::prelude::call_then(start_check_f(env_p0x.clone(), st_p1x.clone(), x_p6x.clone(), expected_p3x.clone()), move |check_f_8349: crate::check::types::St| prism_rtl::Turn::Finished(crate::check::types::recording::note_ty_f(&check_f_8349, &e_p2x.span_p, &expected_p3x)))
            },
            crate::syntax::ExprKind::EMatch(scrut_p7, arms_p8) => {
                let arms_p8x = arms_p8.clone();
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let scrut_p7x = (**scrut_p7).clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lifting::start_infer_match_f(env_p0x.clone(), st_p1x.clone(), scrut_p7x.clone(), arms_p8x.clone(), e_p2x.span_p.clone(), Some(expected_p3x.clone())), move |infer_match_f_8444: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p9, st2_pa) = infer_match_f_8444;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: crate::check::types::recording::note_ty_f(&st2_pa, &e_p2x.span_p, &t_p9), expected_p1: expected_p3x.clone(), found_p2: t_p9.clone(), span_p3: e_p2x.span_p.clone() }))
                })
            },
            crate::syntax::ExprKind::EIf(c_pb, then_b_pc, else_b_od) => {
                let else_b_odx = else_b_od.clone();
                let c_pbx = (**c_pb).clone();
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                let then_b_pcx = then_b_pc.clone();
                crate::prelude::call_then(crate::check::expr::lifting::start_infer_if_f(env_p0x.clone(), st_p1x.clone(), c_pbx.clone(), then_b_pcx.clone(), else_b_odx.clone(), e_p2x.span_p.clone(), Some(expected_p3x.clone())), move |infer_if_f_8608: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pe, st2_pf) = infer_if_f_8608;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: crate::check::types::recording::note_ty_f(&st2_pf, &e_p2x.span_p, &t_pe), expected_p1: expected_p3x.clone(), found_p2: t_pe.clone(), span_p3: e_p2x.span_p.clone() }))
                })
            },
            crate::syntax::ExprKind::EAny(x_pg) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                let x_pgx = (**x_pg).clone();
                crate::prelude::call_then(start_check_any_f(env_p0x.clone(), st_p1x.clone(), x_pgx.clone(), expected_p3x.clone(), e_p2x.span_p.clone()), move |check_any_f_8743: crate::check::types::St| prism_rtl::Turn::Finished(crate::check::types::recording::note_ty_f(&check_any_f_8743, &e_p2x.span_p, &expected_p3x)))
            },
            _ => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_infer_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone()), move |infer_f_8840: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_ph, st2_pi) = infer_f_8840;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st2_pi.clone(), expected_p1: expected_p3x.clone(), found_p2: t_ph.clone(), span_p3: e_p2x.span_p.clone() }))
                })
            },
        }
    }
}

/// `Start Check, x`: what the function value is when passed to `@Run`.
pub fn start_check_f(env_p0: Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, expected_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Check { env_p0, st_p1, e_p2, expected_p3 })
}

/// ```prism
/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
/// ```
pub fn check_any_f(env_p0: &Env, st_p1: &crate::check::types::St, x_p2: &crate::syntax::Expr, expected_p3: &crate::check::types::Ty, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk_f(st_p1, expected_p3) {
        crate::check::types::Ty::TyAny(trs_p5) => {
            let (t_p6, st2_p7) = infer_f(env_p0, st_p1, x_p2);
            crate::prelude::fold(&trs_p5, &st2_p7, &(|s_p8: &crate::check::types::St, tr_p9: &Text| add_want_f(s_p8, tr_p9, &t_p6, span_p4)))
        },
        other_pa => {
            let (t_pb, st2_pc) = infer_f(env_p0, st_p1, x_p2);
            crate::check::types::unify::unify_f(&st2_pc, &other_pa, &crate::check::types::Ty::TyAny(Array::new()), span_p4)
        },
    }
}

/// The step machine of `CheckAny`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
/// ```
pub struct CheckAny {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub x_p2: crate::syntax::Expr,
    pub expected_p3: crate::check::types::Ty,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for CheckAny {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let x_p2 = &self.x_p2;
        let expected_p3 = &self.expected_p3;
        let span_p4 = &self.span_p4;
        let env_p0x = env_p0.clone();
        let expected_p3x = expected_p3.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        let x_p2x = x_p2.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), expected_p3x.clone()), move |walk_f_9088: crate::check::types::Ty| match walk_f_9088 {
            crate::check::types::Ty::TyAny(trs_p5) => crate::prelude::call_then(start_infer_f(env_p0x.clone(), st_p1x.clone(), x_p2x.clone()), move |infer_f_9147: (crate::check::types::Ty, crate::check::types::St)| {
                let (t_p6, st2_p7) = infer_f_9147;
                prism_rtl::Turn::Finished(crate::prelude::fold(&trs_p5, &st2_p7, &(|s_p8: &crate::check::types::St, tr_p9: &Text| add_want_f(s_p8, tr_p9, &t_p6, &span_p4x))))
            }),
            other_pa => crate::prelude::call_then(start_infer_f(env_p0x.clone(), st_p1x.clone(), x_p2x.clone()), move |infer_f_9255: (crate::check::types::Ty, crate::check::types::St)| {
                let (t_pb, st2_pc) = infer_f_9255;
                prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st2_pc.clone(), expected_p1: other_pa.clone(), found_p2: crate::check::types::Ty::TyAny(Array::new()), span_p3: span_p4x.clone() }))
            }),
        })
    }
}

/// `Start CheckAny, x`: what the function value is when passed to `@Run`.
pub fn start_check_any_f(env_p0: Env, st_p1: crate::check::types::St, x_p2: crate::syntax::Expr, expected_p3: crate::check::types::Ty, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckAny { env_p0, st_p1, x_p2, expected_p3, span_p4 })
}

/// ```prism
/// AddWant: fn St, Text, Ty, Range -> St
/// ```
pub fn add_want_f(st_p0: &crate::check::types::St, cls_p1: &Text, t_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.wants_p = crate::prelude::push(&this.wants_p, &crate::check::types::Want { cls_p: cls_p1.clone(), ty_p: t_p2.clone(), file_p: this.file_p.clone(), span_p: span_p3.clone(), level_p: this.level_p.clone() });
    this
}

/// ```prism
/// EnvCx: fn Env -> Cx
/// ```
pub fn env_cx_f(env_p0: &Env) -> crate::check::env::reading::Cx_ {
    let base_p1 = crate::check::env::reading::cx_of_f(&env_p0.g_p, &env_p0.home_p);
    let mut this: crate::check::env::reading::Cx_ = base_p1.clone();
    this.scope_p = env_p0.scope_p.clone();
    this
}

/// ```prism
/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_name_f(env_p0: &Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let local_p4 = crate::check::env::sname_key_f(n_p2);
    if env_p0.in_update_p && has_time_mark_f(&n_p2.sigils_p) {
        (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(st_p1, &Text::lit("time-in-update"), span_p3, &Text::from(format!("`{}` in an `update` block", &local_p4)), &Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function")))
    } else {
        infer_name_in_f(env_p0, st_p1, n_p2, span_p3)
    }
}

/// The step machine of `InferName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferName {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferName {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let span_p3 = &self.span_p3;
        let local_p4 = crate::check::env::sname_key_f(n_p2);
        if env_p0.in_update_p && has_time_mark_f(&n_p2.sigils_p) {
            prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(st_p1, &Text::lit("time-in-update"), span_p3, &Text::from(format!("`{}` in an `update` block", &local_p4)), &Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function"))))
        } else {
            prism_rtl::Turn::More(Rc::new(InferNameIn { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p2.clone(), span_p3: span_p3.clone() }))
        }
    }
}

/// `Start InferName, x`: what the function value is when passed to `@Run`.
pub fn start_infer_name_f(env_p0: Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferName { env_p0, st_p1, n_p2, span_p3 })
}

/// ```prism
/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_name_in_f(env_p0: &Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let local_p4 = crate::check::env::sname_key_f(n_p2);
    match crate::prelude::get(&env_p0.locals_p, &local_p4) {
        Some(sc_p5) => {
            let st2_p6 = match crate::prelude::get(&env_p0.ids_p, &local_p4) {
                Some(id_p7) => crate::check::types::recording::note_use_f(st_p1, span_p3, &id_p7),
                None => st_p1.clone(),
            };
            instantiate_local_f(&st2_p6, &sc_p5, span_p3, &local_p4)
        },
        None => infer_global_f(env_p0, st_p1, n_p2, span_p3),
    }
}

/// The step machine of `InferNameIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferNameIn {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferNameIn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let span_p3 = &self.span_p3;
        let local_p4 = crate::check::env::sname_key_f(n_p2);
        match crate::prelude::get(&env_p0.locals_p, &local_p4) {
            Some(sc_p5) => {
                let st2_p6 = match crate::prelude::get(&env_p0.ids_p, &local_p4) {
                    Some(id_p7) => crate::check::types::recording::note_use_f(st_p1, span_p3, &id_p7),
                    None => st_p1.clone(),
                };
                prism_rtl::Turn::More(Rc::new(InstantiateLocal { st_p0: st2_p6.clone(), sc_p1: sc_p5.clone(), span_p2: span_p3.clone(), name_p3: local_p4.clone() }))
            },
            None => prism_rtl::Turn::More(Rc::new(InferGlobal { env_p0: env_p0.clone(), st0_p1: st_p1.clone(), n_p2: n_p2.clone(), span_p3: span_p3.clone() })),
        }
    }
}

/// `Start InferNameIn, x`: what the function value is when passed to `@Run`.
pub fn start_infer_name_in_f(env_p0: Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferNameIn { env_p0, st_p1, n_p2, span_p3 })
}

/// ```prism
/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
/// ```
pub fn instantiate_local_f(st_p0: &crate::check::types::St, sc_p1: &crate::check::types::Scheme, span_p2: &crate::syntax::Range, name_p3: &Text) -> (crate::check::types::Ty, crate::check::types::St) {
    if (&crate::prelude::len(&sc_p1.qs_p) == &Nat::from(0u32)) && (&crate::prelude::len(&sc_p1.cqs_p) == &Nat::from(0u32)) {
        crate::check::types::schemes::instantiate_f(st_p0, sc_p1, span_p2)
    } else {
        {
            let (t_p4, st2_p5, inst_p6) = crate::check::types::schemes::instantiate_with_f(st_p0, sc_p1, span_p2, &Array::new());
            (t_p4.clone(), crate::check::types::recording::note_inst_f(&st2_p5, span_p2, name_p3, sc_p1, &inst_p6))
        }
    }
}

/// The step machine of `InstantiateLocal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
/// ```
pub struct InstantiateLocal {
    pub st_p0: crate::check::types::St,
    pub sc_p1: crate::check::types::Scheme,
    pub span_p2: crate::syntax::Range,
    pub name_p3: Text,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InstantiateLocal {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let sc_p1 = &self.sc_p1;
        let span_p2 = &self.span_p2;
        let name_p3 = &self.name_p3;
        if (&crate::prelude::len(&sc_p1.qs_p) == &Nat::from(0u32)) && (&crate::prelude::len(&sc_p1.cqs_p) == &Nat::from(0u32)) {
            prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::Instantiate { st_p0: st_p0.clone(), sc_p1: sc_p1.clone(), span_p2: span_p2.clone() }))
        } else {
            {
                let name_p3x = name_p3.clone();
                let sc_p1x = sc_p1.clone();
                let span_p2x = span_p2.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p0x.clone(), sc_p1x.clone(), span_p2x.clone(), Array::new()), move |instantiate_with_f_10896: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                    let (t_p4, st2_p5, inst_p6) = instantiate_with_f_10896;
                    prism_rtl::Turn::Finished((t_p4.clone(), crate::check::types::recording::note_inst_f(&st2_p5, &span_p2x, &name_p3x, &sc_p1x, &inst_p6)))
                })
            }
        }
    }
}

/// `Start InstantiateLocal, x`: what the function value is when passed to `@Run`.
pub fn start_instantiate_local_f(st_p0: crate::check::types::St, sc_p1: crate::check::types::Scheme, span_p2: crate::syntax::Range, name_p3: Text) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InstantiateLocal { st_p0, sc_p1, span_p2, name_p3 })
}

/// ```prism
/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_global_f(env_p0: &Env, st0_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (qk_o6, why_p7) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p2);
    let st1_p4 = collision_at_f(env_p0, st0_p1, &why_p7, &crate::check::env::sname_key_f(n_p2), span_p3);
    let st_p5 = match &qk_o6 {
        Some(qk_p8) => crate::check::types::recording::note_global_f(&st1_p4, span_p3, qk_p8),
        None => st1_p4.clone(),
    };
    match &qk_o6 {
        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p5, &Text::lit("unknown-name"), span_p3, &Text::from(format!("nothing declares `{}` here", &crate::check::env::sname_key_f(n_p2))))),
        Some(qk_p9) => if &why_p7 == &Text::lit("tag") {
            tag_value_f(env_p0, &st_p5, qk_p9, span_p3)
        } else {
            if crate::check::expr::calls::is_local_maker_f(qk_p9) && !env_p0.in_update_p {
                (crate::check::types::Ty::TyErr, crate::check::expr::calls::local_outside_f(&st_p5, qk_p9, span_p3))
            } else {
                match crate::prelude::get(&env_p0.g_p.vals_p, qk_p9) {
                    Some(v_pa) => crate::check::types::schemes::instantiate_f(&crate::check::expr::calls::note_method_use_f(&call_id_f(&st_p5, qk_p9, span_p3), &v_pa, span_p3), &v_pa.scheme_p, span_p3),
                    None => match crate::prelude::get(&env_p0.g_p.ctors_p, qk_p9) {
                        Some(c_pb) => ctor_value_f(env_p0, &st_p5, &c_pb, span_p3),
                        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p5, &Text::lit("unknown-name"), span_p3, &Text::from(format!("`{}` has no signature line or type", &crate::check::env::sname_key_f(n_p2))))),
                    },
                }
            }
        },
    }
}

/// The step machine of `InferGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferGlobal {
    pub env_p0: Env,
    pub st0_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferGlobal {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st0_p1 = &self.st0_p1;
        let n_p2 = &self.n_p2;
        let span_p3 = &self.span_p3;
        let (qk_o6, why_p7) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p2);
        let st1_p4 = collision_at_f(env_p0, st0_p1, &why_p7, &crate::check::env::sname_key_f(n_p2), span_p3);
        let st_p5 = match &qk_o6 {
            Some(qk_p8) => crate::check::types::recording::note_global_f(&st1_p4, span_p3, qk_p8),
            None => st1_p4.clone(),
        };
        match &qk_o6 {
            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p5, &Text::lit("unknown-name"), span_p3, &Text::from(format!("nothing declares `{}` here", &crate::check::env::sname_key_f(n_p2)))))),
            Some(qk_p9) => if &why_p7 == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(TagValue { env_p0: env_p0.clone(), st_p1: st_p5.clone(), name_p2: qk_p9.clone(), span_p3: span_p3.clone() }))
            } else {
                if crate::check::expr::calls::is_local_maker_f(qk_p9) && !env_p0.in_update_p {
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::expr::calls::local_outside_f(&st_p5, qk_p9, span_p3)))
                } else {
                    match crate::prelude::get(&env_p0.g_p.vals_p, qk_p9) {
                        Some(v_pa) => prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::Instantiate { st_p0: crate::check::expr::calls::note_method_use_f(&call_id_f(&st_p5, qk_p9, span_p3), &v_pa, span_p3), sc_p1: v_pa.scheme_p.clone(), span_p2: span_p3.clone() })),
                        None => match crate::prelude::get(&env_p0.g_p.ctors_p, qk_p9) {
                            Some(c_pb) => prism_rtl::Turn::More(Rc::new(CtorValue { env_p0: env_p0.clone(), st_p1: st_p5.clone(), c_p2: c_pb.clone(), span_p3: span_p3.clone() })),
                            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p5, &Text::lit("unknown-name"), span_p3, &Text::from(format!("`{}` has no signature line or type", &crate::check::env::sname_key_f(n_p2)))))),
                        },
                    }
                }
            },
        }
    }
}

/// `Start InferGlobal, x`: what the function value is when passed to `@Run`.
pub fn start_infer_global_f(env_p0: Env, st0_p1: crate::check::types::St, n_p2: crate::syntax::SName, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferGlobal { env_p0, st0_p1, n_p2, span_p3 })
}

/// ```prism
/// CollisionAt: fn Env, St, Text, Text, Range -> St
/// ```
pub fn collision_at_f(env_p0: &Env, st_p1: &crate::check::types::St, why_p2: &Text, name_p3: &Text, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    if why_p2 != &Text::lit("collision") {
        st_p1.clone()
    } else {
        {
            let keys_p5 = crate::prelude::or(&crate::prelude::get(&crate::prelude::or(&crate::prelude::get(&env_p0.g_p.bare_p, &env_p0.home_p), &Map::new()), name_p3), &Array::new());
            let others_p6 = crate::prelude::filter(&keys_p5, &(|k_p7: &Text| crate::syntax::lexer::chars::contains_f(k_p7, &Text::lit("."))));
            crate::check::types::recording::err_fix_f(st_p1, &Text::lit("collision"), span_p4, &Text::from(format!("`{}` is declared by more than one module this file reaches by a bare name: {}", name_p3, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&keys_p5, &(|k_p8: &Text| Text::from(format!("`{}`", k_p8)))), &Text::lit(", ")))), &Text::from(format!("write the one meant qualified, as `{}`, or rename this file\'s own", &crate::prelude::or(&crate::prelude::index(&others_p6, &Nat::from(0u32)), name_p3))))
        }
    }
}

/// ```prism
/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
/// ```
pub fn ctor_value_f(env_p0: &Env, st_p1: &crate::check::types::St, c_p2: &crate::check::env::CtorInfo, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let sc_p4 = crate::check::types::Scheme { qs_p: c_p2.params_p.clone(), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: if &crate::prelude::len(&c_p2.args_p) == &Nat::from(0u32) {
        c_p2.ty_p.clone()
    } else {
        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, c_p2.args_p.clone(), Rc::new(c_p2.ty_p.clone()))
    } };
    crate::check::types::schemes::instantiate_f(st_p1, &sc_p4, span_p3)
}

/// The step machine of `CtorValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
/// ```
pub struct CtorValue {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::check::env::CtorInfo,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for CtorValue {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let span_p3 = &self.span_p3;
        let sc_p4 = crate::check::types::Scheme { qs_p: c_p2.params_p.clone(), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: if &crate::prelude::len(&c_p2.args_p) == &Nat::from(0u32) {
            c_p2.ty_p.clone()
        } else {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, c_p2.args_p.clone(), Rc::new(c_p2.ty_p.clone()))
        } };
        prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::Instantiate { st_p0: st_p1.clone(), sc_p1: sc_p4.clone(), span_p2: span_p3.clone() }))
    }
}

/// `Start CtorValue, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_value_f(env_p0: Env, st_p1: crate::check::types::St, c_p2: crate::check::env::CtorInfo, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(CtorValue { env_p0, st_p1, c_p2, span_p3 })
}

/// ```prism
/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub fn tag_value_f(env_p0: &Env, st_p1: &crate::check::types::St, name_p2: &Text, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::prelude::get(&env_p0.g_p.tags_p, name_p2) {
        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), span_p3, &Text::from(format!("no tag `{}`", name_p2)))),
        Some(tg_p4) => if &tg_p4.kind_p == &Text::lit("Element") {
            {
                let (rw_p6, st2_p7) = crate::check::types::recording::fresh_row_f(st_p1, &Array::from(vec![tg_p4.family_p.clone()]));
                let erow_p5 = crate::check::types::Rw { fams_p: Array::from(vec![tg_p4.family_p.clone()]), minus_p: Array::new(), tail_p: rw_p6.tail_p.clone() };
                let (out_p8, st3_p9) = crate::check::types::schemes::instantiate_f(&st2_p7, &crate::check::types::Scheme { qs_p: tg_p4.qs_p.clone(), plain_qs_p: Array::new(), rqs_p: tg_p4.rqs_p.clone(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: tg_p4.bounds_p.clone(), ty_p: tg_p4.out_p.clone() }, span_p3);
                (crate::check::types::Ty::TyElem(erow_p5.clone(), Rc::new(out_p8.clone())), st3_p9.clone())
            }
        } else {
            (crate::check::types::Ty::TyCon(tg_p4.kind_p.clone(), Array::new()), st_p1.clone())
        },
    }
}

/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub struct TagValue {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub name_p2: Text,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for TagValue {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let name_p2 = &self.name_p2;
        let span_p3 = &self.span_p3;
        match crate::prelude::get(&env_p0.g_p.tags_p, name_p2) {
            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), span_p3, &Text::from(format!("no tag `{}`", name_p2))))),
            Some(tg_p4) => if &tg_p4.kind_p == &Text::lit("Element") {
                {
                    let (rw_p6, st2_p7) = crate::check::types::recording::fresh_row_f(st_p1, &Array::from(vec![tg_p4.family_p.clone()]));
                    let erow_p5 = crate::check::types::Rw { fams_p: Array::from(vec![tg_p4.family_p.clone()]), minus_p: Array::new(), tail_p: rw_p6.tail_p.clone() };
                    let span_p3x = span_p3.clone();
                    crate::prelude::call_then(crate::check::types::schemes::start_instantiate_f(st2_p7.clone(), crate::check::types::Scheme { qs_p: tg_p4.qs_p.clone(), plain_qs_p: Array::new(), rqs_p: tg_p4.rqs_p.clone(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: tg_p4.bounds_p.clone(), ty_p: tg_p4.out_p.clone() }, span_p3x.clone()), move |instantiate_f_13506: (crate::check::types::Ty, crate::check::types::St)| {
                        let (out_p8, st3_p9) = instantiate_f_13506;
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(erow_p5.clone(), Rc::new(out_p8.clone())), st3_p9.clone()))
                    })
                }
            } else {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(tg_p4.kind_p.clone(), Array::new()), st_p1.clone()))
            },
        }
    }
}

/// `Start TagValue, x`: what the function value is when passed to `@Run`.
pub fn start_tag_value_f(env_p0: Env, st_p1: crate::check::types::St, name_p2: Text, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(TagValue { env_p0, st_p1, name_p2, span_p3 })
}

/// ```prism
/// InferBound: fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub fn infer_bound_f(env_p0: &Env, st_p1: &crate::check::types::St, b_p2: &Text, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::prelude::get(&env_p0.locals_p, b_p2) {
        Some(sc_p4) => (sc_p4.ty_p.clone(), st_p1.clone()),
        None => if b_p2 == &Text::lit("key") {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), span_p3, &Text::lit("`key` is bound only in a loop over a map")))
        } else {
            (crate::check::types::t_nat_p(), st_p1.clone())
        },
    }
}

/// ```prism
/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
/// ```
pub fn infer_lit_f(env_p0: &Env, st_p1: &crate::check::types::St, l_p2: &crate::syntax::Literal, negative_p3: &bool, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let sigils_p5 = crate::syntax::lexer::chars::fold_chars_f(&l_p2.marks_p, &Text::lit(""), &(Rc::new(move |(p0, p1): (Text, Text)| crate::prelude::once_job(move || {
        let acc_p7 = p0;
        let c_p8 = p1;
        if crate::check::types::unify::is_mark_char_f(&c_p8) {
            prism_rtl::Turn::Finished(Text::from(format!("{}{}", &acc_p7, &c_p8)))
        } else {
            prism_rtl::Turn::Finished(acc_p7.clone())
        }
    })) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>));
    let signed_p6 = *negative_p3 || crate::syntax::lexer::chars::contains_f(&l_p2.marks_p, &Text::lit("-"));
    let (base_ph, st2_pi) = match &l_p2.kind_p {
        crate::syntax::LitKind::LInt(digits_p9) => {
            let (v_pd, s1_pe) = crate::check::types::fresh_var_f(st_p1, &true, &Text::lit(""));
            let s2_pa = add_want_f(&s1_pe, &Text::lit("Prelude.Num"), &v_pd, span_p4);
            let s3_pb = if signed_p6 {
                add_want_f(&s2_pa, &Text::lit("Prelude.Signed"), &v_pd, span_p4)
            } else {
                s2_pa.clone()
            };
            let s4_pc = add_range_f(&s3_pb, &v_pd, digits_p9, &signed_p6, span_p4);
            (v_pd.clone(), s4_pc.clone())
        },
        crate::syntax::LitKind::LFloat(_) => (crate::check::types::t_float_p(), st_p1.clone()),
        crate::syntax::LitKind::LDuration(_, _) => (crate::check::types::Ty::TyCon(Text::lit("Duration"), Array::new()), st_p1.clone()),
        crate::syntax::LitKind::LChar(_) => (crate::check::types::t_char_p(), st_p1.clone()),
        crate::syntax::LitKind::LText(segs_pf) => infer_text_f(env_p0, st_p1, segs_pf, &crate::syntax::lexer::chars::contains_f(&sigils_p5, &Text::lit("$")), span_p4),
        crate::syntax::LitKind::LRegex(r_pg) => infer_regex_f(st_p1, r_pg),
    };
    if crate::syntax::lexer::chars::contains_f(&sigils_p5, &Text::lit("$")) && (&crate::check::types::head_sigil_f(&st2_pi, &base_ph) == &Text::lit("$")) {
        (base_ph.clone(), st2_pi.clone())
    } else {
        if crate::syntax::lexer::chars::contains_f(&sigils_p5, &Text::lit("$")) {
            (crate::check::types::with_marks_f(&sigils_p5, &base_ph, &env_p0.scope_p), crate::check::types::recording::note_app_f(&st2_pi, span_p4, &Text::lit("$"), &Text::lit("const"), &Text::lit("$"), &Array::new(), &Text::lit(""), &crate::check::types::Col::CBound))
        } else {
            (crate::check::types::with_marks_f(&sigils_p5, &base_ph, &env_p0.scope_p), st2_pi.clone())
        }
    }
}

/// The step machine of `InferLit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
/// ```
pub struct InferLit {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub l_p2: crate::syntax::Literal,
    pub negative_p3: bool,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferLit {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let l_p2 = &self.l_p2;
        let negative_p3 = &self.negative_p3;
        let span_p4 = &self.span_p4;
        let env_p0x = env_p0.clone();
        let l_p2x = l_p2.clone();
        let negative_p3x = *negative_p3;
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::syntax::lexer::chars::start_fold_chars_f(l_p2x.marks_p.clone(), Text::lit(""), Rc::new(move |(p0, p1): (Text, Text)| crate::prelude::once_job(move || {
            let acc_p7 = p0;
            let c_p8 = p1;
            if crate::check::types::unify::is_mark_char_f(&c_p8) {
                prism_rtl::Turn::Finished(Text::from(format!("{}{}", &acc_p7, &c_p8)))
            } else {
                prism_rtl::Turn::Finished(acc_p7.clone())
            }
        })) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>), move |fold_chars_f_14479: Text| {
            let sigils_p5 = fold_chars_f_14479;
            let signed_p6 = negative_p3x || crate::syntax::lexer::chars::contains_f(&l_p2x.marks_p, &Text::lit("-"));
            let (base_ph, st2_pi) = match &l_p2x.kind_p {
                crate::syntax::LitKind::LInt(digits_p9) => {
                    let (v_pd, s1_pe) = crate::check::types::fresh_var_f(&st_p1x, &true, &Text::lit(""));
                    let s2_pa = add_want_f(&s1_pe, &Text::lit("Prelude.Num"), &v_pd, &span_p4x);
                    let s3_pb = if signed_p6 {
                        add_want_f(&s2_pa, &Text::lit("Prelude.Signed"), &v_pd, &span_p4x)
                    } else {
                        s2_pa.clone()
                    };
                    let s4_pc = add_range_f(&s3_pb, &v_pd, digits_p9, &signed_p6, &span_p4x);
                    (v_pd.clone(), s4_pc.clone())
                },
                crate::syntax::LitKind::LFloat(_) => (crate::check::types::t_float_p(), st_p1x.clone()),
                crate::syntax::LitKind::LDuration(_, _) => (crate::check::types::Ty::TyCon(Text::lit("Duration"), Array::new()), st_p1x.clone()),
                crate::syntax::LitKind::LChar(_) => (crate::check::types::t_char_p(), st_p1x.clone()),
                crate::syntax::LitKind::LText(segs_pf) => infer_text_f(&env_p0x, &st_p1x, segs_pf, &crate::syntax::lexer::chars::contains_f(&sigils_p5, &Text::lit("$")), &span_p4x),
                crate::syntax::LitKind::LRegex(r_pg) => infer_regex_f(&st_p1x, r_pg),
            };
            if crate::syntax::lexer::chars::contains_f(&sigils_p5, &Text::lit("$")) && (&crate::check::types::head_sigil_f(&st2_pi, &base_ph) == &Text::lit("$")) {
                prism_rtl::Turn::Finished((base_ph.clone(), st2_pi.clone()))
            } else {
                if crate::syntax::lexer::chars::contains_f(&sigils_p5, &Text::lit("$")) {
                    prism_rtl::Turn::Finished((crate::check::types::with_marks_f(&sigils_p5, &base_ph, &env_p0x.scope_p), crate::check::types::recording::note_app_f(&st2_pi, &span_p4x, &Text::lit("$"), &Text::lit("const"), &Text::lit("$"), &Array::new(), &Text::lit(""), &crate::check::types::Col::CBound)))
                } else {
                    prism_rtl::Turn::Finished((crate::check::types::with_marks_f(&sigils_p5, &base_ph, &env_p0x.scope_p), st2_pi.clone()))
                }
            }
        })
    }
}

/// `Start InferLit, x`: what the function value is when passed to `@Run`.
pub fn start_infer_lit_f(env_p0: Env, st_p1: crate::check::types::St, l_p2: crate::syntax::Literal, negative_p3: bool, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferLit { env_p0, st_p1, l_p2, negative_p3, span_p4 })
}

/// ```prism
/// InferRegex: unbounded fn St, RegexLit -> ((Ty, St))
/// ```
pub fn infer_regex_f(st_p0: &crate::check::types::St, r_p1: &crate::syntax::RegexLit) -> (crate::check::types::Ty, crate::check::types::St) {
    let t_p2 = crate::check::types::Ty::TyCon(if &r_p1.replacement_o == &None {
        Text::lit("Regex")
    } else {
        Text::lit("RegexReplacement")
    }, Array::new());
    match crate::check::regex::regex_refusal_o(&r_p1.pattern_p, &r_p1.flags_p, &r_p1.replacement_o) {
        None => (t_p2.clone(), st_p0.clone()),
        Some(d_p3) => {
            let (base_p6, text_p7) = if &d_p3.part_p == &Text::lit("flags") {
                (r_p1.flags_at_p.clone(), r_p1.flags_p.clone())
            } else {
                if &d_p3.part_p == &Text::lit("pattern") {
                    (r_p1.pattern_at_p.clone(), r_p1.pattern_p.clone())
                } else {
                    (r_p1.replacement_at_p.clone(), crate::prelude::or(&r_p1.replacement_o, &Text::lit("")))
                }
            };
            let start_p4 = &base_p6 + &d_p3.at_p;
            let span_p5 = crate::syntax::Range { start_p: start_p4.clone(), end_p: &start_p4 + &crate::prelude::max(&crate::prelude::len_text(&crate::check::regex::rx_char_at_f(&text_p7, &d_p3.at_p)), &Nat::from(1u32)) };
            if &d_p3.message_p == &crate::check::regex::rx_unknown_flag_p() {
                (t_p2.clone(), crate::check::types::recording::err_fix_f(st_p0, &Text::lit("regex"), &span_p5, &d_p3.message_p, &Text::lit("a replacement that starts with letters and holds anything but letters is written in the hashed form, `%#/x/#hello world/#`")))
            } else {
                (t_p2.clone(), crate::check::types::recording::err_f(st_p0, &Text::lit("regex"), &span_p5, &d_p3.message_p))
            }
        },
    }
}

/// The step machine of `InferRegex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferRegex: unbounded fn St, RegexLit -> ((Ty, St))
/// ```
pub struct InferRegex {
    pub st_p0: crate::check::types::St,
    pub r_p1: crate::syntax::RegexLit,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferRegex {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let r_p1 = &self.r_p1;
        let t_p2 = crate::check::types::Ty::TyCon(if &r_p1.replacement_o == &None {
            Text::lit("Regex")
        } else {
            Text::lit("RegexReplacement")
        }, Array::new());
        let r_p1x = r_p1.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(crate::check::regex::start_regex_refusal_o(r_p1x.pattern_p.clone(), r_p1x.flags_p.clone(), r_p1x.replacement_o.clone()), move |regex_refusal_o_15951: Option<crate::check::regex::RxDiag>| match regex_refusal_o_15951 {
            None => prism_rtl::Turn::Finished((t_p2.clone(), st_p0x.clone())),
            Some(d_p3) => {
                let (base_p6, text_p7) = if &d_p3.part_p == &Text::lit("flags") {
                    (r_p1x.flags_at_p.clone(), r_p1x.flags_p.clone())
                } else {
                    if &d_p3.part_p == &Text::lit("pattern") {
                        (r_p1x.pattern_at_p.clone(), r_p1x.pattern_p.clone())
                    } else {
                        (r_p1x.replacement_at_p.clone(), crate::prelude::or(&r_p1x.replacement_o, &Text::lit("")))
                    }
                };
                let start_p4 = &base_p6 + &d_p3.at_p;
                let span_p5 = crate::syntax::Range { start_p: start_p4.clone(), end_p: &start_p4 + &crate::prelude::max(&crate::prelude::len_text(&crate::check::regex::rx_char_at_f(&text_p7, &d_p3.at_p)), &Nat::from(1u32)) };
                if &d_p3.message_p == &crate::check::regex::rx_unknown_flag_p() {
                    prism_rtl::Turn::Finished((t_p2.clone(), crate::check::types::recording::err_fix_f(&st_p0x, &Text::lit("regex"), &span_p5, &d_p3.message_p, &Text::lit("a replacement that starts with letters and holds anything but letters is written in the hashed form, `%#/x/#hello world/#`"))))
                } else {
                    prism_rtl::Turn::Finished((t_p2.clone(), crate::check::types::recording::err_f(&st_p0x, &Text::lit("regex"), &span_p5, &d_p3.message_p)))
                }
            },
        })
    }
}

/// `Start InferRegex, x`: what the function value is when passed to `@Run`.
pub fn start_infer_regex_f(st_p0: crate::check::types::St, r_p1: crate::syntax::RegexLit) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferRegex { st_p0, r_p1 })
}

/// ```prism
/// AddRange: fn St, Ty, Text, Bool, Range -> St
/// ```
pub fn add_range_f(st_p0: &crate::check::types::St, v_p1: &crate::check::types::Ty, digits_p2: &Text, signed_p3: &bool, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.wants_p = crate::prelude::push(&this.wants_p, &crate::check::types::Want { cls_p: Text::from(format!("Range {}{}", &(if *signed_p3 { Text::lit("-") } else { Text::lit("") }), digits_p2)), ty_p: v_p1.clone(), file_p: this.file_p.clone(), span_p: span_p4.clone(), level_p: this.level_p.clone() });
    this
}

/// ```prism
/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
/// ```
pub fn infer_text_f(env_p0: &Env, st_p1: &crate::check::types::St, segs_p2: &Array<crate::syntax::TextSeg>, dollar_p3: &bool, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let holes_p5 = crate::prelude::fold(segs_p2, &Array::new(), &(|acc_p6: &Array<crate::syntax::Expr>, sg_p7: &crate::syntax::TextSeg| match sg_p7 {
        crate::syntax::TextSeg::SegPlaceholder(x_p8) => crate::prelude::push(acc_p6, x_p8),
        _ => acc_p6.clone(),
    }));
    if &crate::prelude::len(&holes_p5) == &Nat::from(0u32) {
        (crate::check::types::t_text_p(), st_p1.clone())
    } else {
        {
            let (events_p12, dyns_p13, opts_p14, st2_p15, lifted_p16) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&holes_p5)), (Array::new(), Int::from(0), Array::new(), st_p1.clone(), Array::new()), {
                let holes_p5x = holes_p5.clone();
                let span_p4x = span_p4.clone();
                let env_p0x = env_p0.clone();
                Rc::new(move |(p0, p1): ((Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>), Nat)| {
                    let holes_p5xy = holes_p5x.clone();
                    let span_p4xy = span_p4x.clone();
                    let env_p0xy = env_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (ev_pf, dy_pg, op_ph, s_pi, li_pj) = p0;
                        let hi_pk = p1;
                        {
                            let x_pl = crate::prelude::or(&crate::prelude::index(&holes_p5xy, &hi_pk), &crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: span_p4xy.clone() });
                            crate::prelude::call_then(start_infer_f(env_p0xy.clone(), s_pi.clone(), x_pl.clone()), move |infer_f_17646: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t_p10, s2_p11) = infer_f_17646;
                                crate::prelude::call_then(crate::check::types::start_head_sigil_f(s2_p11.clone(), t_p10.clone()), move |head_sigil_f_17685: Text| {
                                    let head_pm = head_sigil_f_17685;
                                    let inner_pn = if is_time_sigil_f(&head_pm) { inner_of_f(&s2_p11, &t_p10) } else { t_p10.clone() };
                                    crate::prelude::call_then(crate::check::types::start_head_sigil_f(s2_p11.clone(), inner_pn.clone()), move |head_sigil_f_17789: Text| {
                                        let ih_po = head_sigil_f_17789;
                                        let plain_t_pp = if is_plain_sigil_f(&ih_po) {
                                            inner_of_f(&s2_p11, &inner_pn)
                                        } else {
                                            inner_pn.clone()
                                        };
                                        let s3_pq = if &head_pm == &Text::lit("@") {
                                            crate::check::types::recording::err_f(&s2_p11, &Text::lit("blueprint-operand"), &x_pl.span_p, &Text::lit("a text over a blueprint; bind it first"))
                                        } else {
                                            s2_p11.clone()
                                        };
                                        crate::prelude::call_then(start_show_want_f(s3_pq.clone(), plain_t_pp.clone(), x_pl.span_p.clone()), move |show_want_f_18029: crate::check::types::St| {
                                            let s4_pr = show_want_f_18029;
                                            let ev2_ps = if &head_pm == &Text::lit("!") {
                                                crate::prelude::push(&ev_pf, &x_pl.span_p)
                                            } else {
                                                ev_pf.clone()
                                            };
                                            let dy2_pt = if &head_pm == &Text::lit("$") { &dy_pg + &Int::from(1) } else { dy_pg.clone() };
                                            let op2_pu = if is_plain_sigil_f(&ih_po) {
                                                crate::check::types::add_text_f(&op_ph, &ih_po)
                                            } else {
                                                op_ph.clone()
                                            };
                                            let li2_pv = if is_time_sigil_f(&head_pm) {
                                                crate::prelude::push(&li_pj, &hi_pk)
                                            } else {
                                                li_pj.clone()
                                            };
                                            prism_rtl::Turn::Finished((ev2_ps.clone(), dy2_pt.clone(), op2_pu.clone(), s4_pr.clone(), li2_pv.clone()))
                                        })
                                    })
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(((Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>)>>>
            }));
            let st3_p9 = if *dollar_p3 && (&crate::prelude::len(&events_p12) > &Nat::from(0u32)) {
                crate::check::types::recording::err_f(&st2_p15, &Text::lit("event-in-text"), &crate::prelude::or(&crate::prelude::index(&events_p12, &Nat::from(0u32)), span_p4), &Text::lit("an event in a dynamic text"))
            } else {
                if &crate::prelude::len(&events_p12) > &Nat::from(1u32) {
                    crate::check::types::recording::err_fix_f(&st2_p15, &Text::lit("two-events"), &crate::prelude::or(&crate::prelude::index(&events_p12, &Nat::from(1u32)), span_p4), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first"))
                } else {
                    st2_p15.clone()
                }
            };
            let st4_pa = if &crate::prelude::len(&opts_p14) > &Nat::from(1u32) {
                crate::check::types::recording::err_f(&st3_p9, &Text::lit("optional-and-fault"), span_p4, &Text::lit("`?` and `~` in one operation"))
            } else {
                st3_p9.clone()
            };
            let with_opt_pb = match crate::prelude::index(&opts_p14, &Nat::from(0u32)) {
                Some(o_p17) => crate::check::types::Ty::TySig(o_p17, Rc::new(crate::check::types::t_text_p())),
                None => crate::check::types::t_text_p(),
            };
            let layer_pc = if (&crate::prelude::len(&events_p12) > &Nat::from(0u32)) && !*dollar_p3 {
                Text::lit("!")
            } else {
                if (&dyns_p13 > &Int::from(0)) || *dollar_p3 { Text::lit("$") } else { Text::lit("") }
            };
            let res_pd = if &layer_pc == &Text::lit("") {
                with_opt_pb.clone()
            } else {
                crate::check::types::Ty::TySig(layer_pc.clone(), Rc::new(with_opt_pb.clone()))
            };
            let kind_pe = if &layer_pc == &Text::lit("") {
                Text::lit("plain")
            } else {
                if &crate::prelude::len(&lifted_p16) == &Nat::from(0u32) {
                    Text::lit("const")
                } else {
                    Text::lit("map")
                }
            };
            (res_pd.clone(), crate::check::types::recording::note_app_f(&st4_pa, span_p4, &Text::lit("text"), &kind_pe, &layer_pc, &lifted_p16, &crate::prelude::or(&crate::prelude::index(&opts_p14, &Nat::from(0u32)), &Text::lit("")), &crate::check::types::Col::CBound))
        }
    }
}

/// The step machine of `InferText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
/// ```
pub struct InferText {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub segs_p2: Array<crate::syntax::TextSeg>,
    pub dollar_p3: bool,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferText {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let segs_p2 = &self.segs_p2;
        let dollar_p3 = &self.dollar_p3;
        let span_p4 = &self.span_p4;
        let holes_p5 = crate::prelude::fold(segs_p2, &Array::new(), &(|acc_p6: &Array<crate::syntax::Expr>, sg_p7: &crate::syntax::TextSeg| match sg_p7 {
            crate::syntax::TextSeg::SegPlaceholder(x_p8) => crate::prelude::push(acc_p6, x_p8),
            _ => acc_p6.clone(),
        }));
        if &crate::prelude::len(&holes_p5) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished((crate::check::types::t_text_p(), st_p1.clone()))
        } else {
            {
                let dollar_p3x = *dollar_p3;
                let env_p0x = env_p0.clone();
                let span_p4x = span_p4.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&holes_p5)), (Array::new(), Int::from(0), Array::new(), st_p1x.clone(), Array::new()), {
                    let holes_p5x = holes_p5.clone();
                    let span_p4xx = span_p4x.clone();
                    let env_p0xx = env_p0x.clone();
                    Rc::new(move |(p0, p1): ((Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>), Nat)| {
                        let holes_p5xy = holes_p5x.clone();
                        let span_p4xxy = span_p4xx.clone();
                        let env_p0xxy = env_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (ev_pf, dy_pg, op_ph, s_pi, li_pj) = p0;
                            let hi_pk = p1;
                            {
                                let x_pl = crate::prelude::or(&crate::prelude::index(&holes_p5xy, &hi_pk), &crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: span_p4xxy.clone() });
                                crate::prelude::call_then(start_infer_f(env_p0xxy.clone(), s_pi.clone(), x_pl.clone()), move |infer_f_17646: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (t_p10, s2_p11) = infer_f_17646;
                                    crate::prelude::call_then(crate::check::types::start_head_sigil_f(s2_p11.clone(), t_p10.clone()), move |head_sigil_f_17685: Text| {
                                        let head_pm = head_sigil_f_17685;
                                        let inner_pn = if is_time_sigil_f(&head_pm) { inner_of_f(&s2_p11, &t_p10) } else { t_p10.clone() };
                                        crate::prelude::call_then(crate::check::types::start_head_sigil_f(s2_p11.clone(), inner_pn.clone()), move |head_sigil_f_17789: Text| {
                                            let ih_po = head_sigil_f_17789;
                                            let plain_t_pp = if is_plain_sigil_f(&ih_po) {
                                                inner_of_f(&s2_p11, &inner_pn)
                                            } else {
                                                inner_pn.clone()
                                            };
                                            let s3_pq = if &head_pm == &Text::lit("@") {
                                                crate::check::types::recording::err_f(&s2_p11, &Text::lit("blueprint-operand"), &x_pl.span_p, &Text::lit("a text over a blueprint; bind it first"))
                                            } else {
                                                s2_p11.clone()
                                            };
                                            crate::prelude::call_then(start_show_want_f(s3_pq.clone(), plain_t_pp.clone(), x_pl.span_p.clone()), move |show_want_f_18029: crate::check::types::St| {
                                                let s4_pr = show_want_f_18029;
                                                let ev2_ps = if &head_pm == &Text::lit("!") {
                                                    crate::prelude::push(&ev_pf, &x_pl.span_p)
                                                } else {
                                                    ev_pf.clone()
                                                };
                                                let dy2_pt = if &head_pm == &Text::lit("$") { &dy_pg + &Int::from(1) } else { dy_pg.clone() };
                                                let op2_pu = if is_plain_sigil_f(&ih_po) {
                                                    crate::check::types::add_text_f(&op_ph, &ih_po)
                                                } else {
                                                    op_ph.clone()
                                                };
                                                let li2_pv = if is_time_sigil_f(&head_pm) {
                                                    crate::prelude::push(&li_pj, &hi_pk)
                                                } else {
                                                    li_pj.clone()
                                                };
                                                prism_rtl::Turn::Finished((ev2_ps.clone(), dy2_pt.clone(), op2_pu.clone(), s4_pr.clone(), li2_pv.clone()))
                                            })
                                        })
                                    })
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>)>>>
                }), move |fold_17470: (Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>)| {
                    let (events_p12, dyns_p13, opts_p14, st2_p15, lifted_p16) = fold_17470;
                    let st3_p9 = if dollar_p3x && (&crate::prelude::len(&events_p12) > &Nat::from(0u32)) {
                        crate::check::types::recording::err_f(&st2_p15, &Text::lit("event-in-text"), &crate::prelude::or(&crate::prelude::index(&events_p12, &Nat::from(0u32)), &span_p4x), &Text::lit("an event in a dynamic text"))
                    } else {
                        if &crate::prelude::len(&events_p12) > &Nat::from(1u32) {
                            crate::check::types::recording::err_fix_f(&st2_p15, &Text::lit("two-events"), &crate::prelude::or(&crate::prelude::index(&events_p12, &Nat::from(1u32)), &span_p4x), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first"))
                        } else {
                            st2_p15.clone()
                        }
                    };
                    let st4_pa = if &crate::prelude::len(&opts_p14) > &Nat::from(1u32) {
                        crate::check::types::recording::err_f(&st3_p9, &Text::lit("optional-and-fault"), &span_p4x, &Text::lit("`?` and `~` in one operation"))
                    } else {
                        st3_p9.clone()
                    };
                    let with_opt_pb = match crate::prelude::index(&opts_p14, &Nat::from(0u32)) {
                        Some(o_p17) => crate::check::types::Ty::TySig(o_p17, Rc::new(crate::check::types::t_text_p())),
                        None => crate::check::types::t_text_p(),
                    };
                    let layer_pc = if (&crate::prelude::len(&events_p12) > &Nat::from(0u32)) && !dollar_p3x {
                        Text::lit("!")
                    } else {
                        if (&dyns_p13 > &Int::from(0)) || dollar_p3x { Text::lit("$") } else { Text::lit("") }
                    };
                    let res_pd = if &layer_pc == &Text::lit("") {
                        with_opt_pb.clone()
                    } else {
                        crate::check::types::Ty::TySig(layer_pc.clone(), Rc::new(with_opt_pb.clone()))
                    };
                    let kind_pe = if &layer_pc == &Text::lit("") {
                        Text::lit("plain")
                    } else {
                        if &crate::prelude::len(&lifted_p16) == &Nat::from(0u32) {
                            Text::lit("const")
                        } else {
                            Text::lit("map")
                        }
                    };
                    prism_rtl::Turn::Finished((res_pd.clone(), crate::check::types::recording::note_app_f(&st4_pa, &span_p4x, &Text::lit("text"), &kind_pe, &layer_pc, &lifted_p16, &crate::prelude::or(&crate::prelude::index(&opts_p14, &Nat::from(0u32)), &Text::lit("")), &crate::check::types::Col::CBound)))
                })
            }
        }
    }
}

/// `Start InferText, x`: what the function value is when passed to `@Run`.
pub fn start_infer_text_f(env_p0: Env, st_p1: crate::check::types::St, segs_p2: Array<crate::syntax::TextSeg>, dollar_p3: bool, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferText { env_p0, st_p1, segs_p2, dollar_p3, span_p4 })
}

/// ```prism
/// ShowWant: unbounded fn St, Ty, Range -> St
/// ```
pub fn show_want_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TyCon(m19342_0_0, m19342_0_1) if (&m19342_0_0 == &Text::lit("Text")) && ((&m19342_0_1).len() == 0) => st_p0.clone(),
        other_p3 => add_want_f(st_p0, &Text::lit("Prelude.Show"), &other_p3, span_p2),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ShowWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowWant: unbounded fn St, Ty, Range -> St
/// ```
pub struct ShowWant {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub span_p2: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for ShowWant {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let span_p2 = &self.span_p2;
        let span_p2x = span_p2.clone();
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_19348: crate::check::types::Ty| match walk_f_19348 {
            crate::check::types::Ty::TyCon(m19342_0_0, m19342_0_1) if (&m19342_0_0 == &Text::lit("Text")) && ((&m19342_0_1).len() == 0) => prism_rtl::Turn::Finished(st_p0x.clone()),
            other_p3 => prism_rtl::Turn::Finished(add_want_f(&st_p0x, &Text::lit("Prelude.Show"), &other_p3, &span_p2x)),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start ShowWant, x`: what the function value is when passed to `@Run`.
pub fn start_show_want_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty, span_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ShowWant { st_p0, t_p1, span_p2 })
}
