//! The module `Check.Expr`, from `target/bootstrap/src/prismc/check/expr/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod calls;
pub mod lets;
pub mod lifting;
pub mod operators;
pub mod patterns;

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Env {
    pub g: crate::check::env::G,
    pub home: Text,
    pub file: Nat,
    pub src: crate::check::errors::Src,
    pub locals: Map<Text, crate::check::types::Scheme>,
    pub scope: crate::check::types::Rw,
    pub givens: Array<(Text, Text)>,
    pub mark: Text,
    pub in_update: bool,
    pub def_name: Text,
    pub refine: Map<Text, crate::check::types::Ty>,
    pub pending: Array<Text>,
    pub ids: Map<Text, Nat>,
}

impl Show for Env {
    fn show(&self, p: &mut Printer) {
        p.record("Env", &[("g", &self.g), ("home", &self.home), ("file", &self.file), ("src", &self.src), ("locals", &self.locals), ("scope", &self.scope), ("givens", &self.givens), ("mark", &self.mark), ("in_update", &self.in_update), ("def_name", &self.def_name), ("refine", &self.refine), ("pending", &self.pending), ("ids", &self.ids)]);
    }
}

impl ToPod for Env {
    fn to_pod(&self) -> Pod {
        Pod::record("Env", vec![("g", self.g.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("src", self.src.to_pod()), ("locals", self.locals.to_pod()), ("scope", self.scope.to_pod()), ("givens", self.givens.to_pod()), ("mark", self.mark.to_pod()), ("in_update", self.in_update.to_pod()), ("def_name", self.def_name.to_pod()), ("refine", self.refine.to_pod()), ("pending", self.pending.to_pod()), ("ids", self.ids.to_pod())])
    }
}

impl FromPod for Env {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Env { g: FromPod::from_pod(field(p, "g")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, src: FromPod::from_pod(field(p, "src")?)?, locals: FromPod::from_pod(field(p, "locals")?)?, scope: FromPod::from_pod(field(p, "scope")?)?, givens: FromPod::from_pod(field(p, "givens")?)?, mark: FromPod::from_pod(field(p, "mark")?)?, in_update: FromPod::from_pod(field(p, "in_update")?)?, def_name: FromPod::from_pod(field(p, "def_name")?)?, refine: FromPod::from_pod(field(p, "refine")?)?, pending: FromPod::from_pod(field(p, "pending")?)?, ids: FromPod::from_pod(field(p, "ids")?)? })
    }
}

/// ```prism
/// WithLocal: fn Env, Text, Scheme -> Env
/// ```
pub fn with_local(env_p0: &Env, name_p1: &Text, sc_p2: &crate::check::types::Scheme) -> Env {
    let mut this: Env = env_p0.clone();
    this.locals = insert(&this.locals, name_p1, sc_p2);
    this
}

/// ```prism
/// BindLocalId: fn Env, St, Text, Range -> ((Env, St))
/// ```
pub fn bind_local_id(env_p0: &Env, st_p1: &crate::check::types::St, name_p2: &Text, span_p3: &crate::syntax::Range) -> (Env, crate::check::types::St) {
    let place_p4 = Text::from(format!("{}:{}:{}", &st_p1.file, &span_p3.start, &span_p3.end));
    let (id_p9, st2_pa) = match get(&st_p1.local_ids, &place_p4) {
        Some(i_p6) => (i_p6, st_p1.clone()),
        None => {
            let fresh_p7 = st_p1.local_next.clone();
            let s2_p8 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.local_next = &this.local_next + &Nat::from(1u32);
                this.local_ids = insert(&this.local_ids, &place_p4, &fresh_p7);
                this
            };
            (fresh_p7.clone(), crate::check::types::recording::note_local(&s2_p8, span_p3, &fresh_p7))
        },
    };
    let env2_p5 = {
        let mut this: Env = env_p0.clone();
        this.ids = insert(&this.ids, name_p2, &id_p9);
        this
    };
    (env2_p5.clone(), st2_pa.clone())
}

/// ```prism
/// SrcText: fn Env, Range -> Text
/// ```
pub fn src_text(env_p0: &Env, r_p1: &crate::syntax::Range) -> Text {
    crate::check::errors::span_text(&env_p0.src, r_p1)
}

/// ```prism
/// IsComparison: fn Text -> Bool
/// ```
pub fn is_comparison(n_p0: &Text) -> bool {
    crate::check::types::has_text(&Array::from(vec![Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">="), Text::lit("Compare"), Text::lit("?"), Text::lit("~"), Text::lit("$")]), n_p0)
}

/// ```prism
/// HasTimeMark: fn Text -> Bool
/// ```
pub fn has_time_mark(marks_p0: &Text) -> bool {
    crate::syntax::lexer::chars::contains(marks_p0, &Text::lit("$")) || crate::syntax::lexer::chars::contains(marks_p0, &Text::lit("!"))
}

/// ```prism
/// IsTimeSigil: fn Text -> Bool
/// ```
pub fn is_time_sigil(s_p0: &Text) -> bool {
    (s_p0 == &Text::lit("$")) || (s_p0 == &Text::lit("!"))
}

/// ```prism
/// IsPlainSigil: fn Text -> Bool
/// ```
pub fn is_plain_sigil(s_p0: &Text) -> bool {
    (s_p0 == &Text::lit("?")) || (s_p0 == &Text::lit("~"))
}

/// ```prism
/// InnerOf: unbounded fn St, Ty -> Ty
/// ```
pub fn inner_of(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match crate::check::types::recording::walk(st_p0, t_p1) {
        crate::check::types::Ty::TySig(_, i_p2) => (*i_p2).clone(),
        crate::check::types::Ty::TyAt(i_p3, _) => (*i_p3).clone(),
        other_p4 => other_p4,
    }
}

/// The step machine of `InnerOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InnerOf: unbounded fn St, Ty -> Ty
/// ```
pub struct InnerOf {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for InnerOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), t_p1.clone()), move |walk_3844: crate::check::types::Ty| match walk_3844 {
            crate::check::types::Ty::TySig(_, i_p2) => prism_rtl::Turn::Finished((*i_p2).clone()),
            crate::check::types::Ty::TyAt(i_p3, _) => prism_rtl::Turn::Finished((*i_p3).clone()),
            other_p4 => prism_rtl::Turn::Finished(other_p4.clone()),
        })
    }
}

/// `Start InnerOf, x`: what the function value is when passed to `@Run`.
pub fn start_inner_of(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(InnerOf { st_p0, t_p1 })
}

/// ```prism
/// IsLambda: fn Expr -> Bool
/// ```
pub fn is_lambda(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind {
        crate::syntax::ExprKind::ELambda(_, _) => true,
        crate::syntax::ExprKind::ETopicField(_) => true,
        crate::syntax::ExprKind::ETopicIndex(_) => true,
        crate::syntax::ExprKind::EGroup(x_p1) => is_lambda(&**x_p1),
        _ => false,
    }
}

/// ```prism
/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub fn infer(env_p0: &Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p3, st2_p4) = infer_kind(env_p0, st_p1, e_p2);
    (t_p3.clone(), crate::check::types::recording::note_ty(&st2_p4, &e_p2.span, &t_p3))
}

/// The step machine of `Infer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub struct Infer {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for Infer {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let e_p2 = e_p2.clone();
        let env_p0 = env_p0.clone();
        let st_p1 = st_p1.clone();
        call_then(start_infer_kind(env_p0.clone(), st_p1.clone(), e_p2.clone()), move |infer_kind_4396: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p3, st2_p4) = infer_kind_4396;
            prism_rtl::Turn::Finished((t_p3.clone(), crate::check::types::recording::note_ty(&st2_p4, &e_p2.span, &t_p3)))
        })
    }
}

/// `Start Infer, x`: what the function value is when passed to `@Run`.
pub fn start_infer(env_p0: Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(Infer { env_p0, st_p1, e_p2 })
}

/// ```prism
/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub fn infer_kind(env_p0: &Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*e_p2.kind {
        crate::syntax::ExprKind::EName(n_p3) => infer_name(env_p0, st_p1, n_p3, &e_p2.span),
        crate::syntax::ExprKind::ELit(l_p4) => infer_lit(env_p0, st_p1, l_p4, &false, &e_p2.span),
        crate::syntax::ExprKind::EUnit(marks_p5) => (crate::check::types::with_marks(marks_p5, &crate::check::types::t_unit(), &env_p0.scope), st_p1.clone()),
        crate::syntax::ExprKind::ENil(marks_p6) => {
            let (v_p7, st2_p8) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
            (crate::check::types::with_marks(marks_p6, &crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_p7.clone())), &env_p0.scope), st2_p8.clone())
        },
        crate::syntax::ExprKind::EBound(b_p9) => infer_bound(env_p0, st_p1, b_p9, &e_p2.span),
        crate::syntax::ExprKind::ETuple(es_pa) => {
            let (ts_pb, st2_pc) = infer_all(env_p0, st_p1, es_pa);
            (crate::check::types::Ty::TyTuple(ts_pb.clone()), st2_pc.clone())
        },
        crate::syntax::ExprKind::EArray(es_pd) => crate::check::expr::operators::infer_array(env_p0, st_p1, es_pd, &e_p2.span),
        crate::syntax::ExprKind::EMap(entries_pe) => crate::check::expr::operators::infer_map(env_p0, st_p1, entries_pe, &e_p2.span),
        crate::syntax::ExprKind::EGroup(x_pf) => infer(env_p0, st_p1, &**x_pf),
        crate::syntax::ExprKind::ECall(callee_pg, args_ph, _, _) => crate::check::expr::calls::infer_call(env_p0, st_p1, &**callee_pg, args_ph, &e_p2.span),
        crate::syntax::ExprKind::EBinary(op_pi, lhs_pj, rhs_pk) => crate::check::expr::operators::infer_binary(env_p0, st_p1, op_pi, &**lhs_pj, &**rhs_pk, &e_p2.span),
        crate::syntax::ExprKind::EUnary(op_pl, x_pm) => crate::check::expr::operators::infer_unary(env_p0, st_p1, op_pl, &**x_pm, &e_p2.span),
        crate::syntax::ExprKind::ESuffixed(_, _, _, _) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unsupported"), &e_p2.span, &Text::lit("this checker does not implement suffixed operators"))),
        crate::syntax::ExprKind::EFreeSigil(s_pn, x_po) => crate::check::expr::operators::infer_free_sigil(env_p0, st_p1, s_pn, &**x_po, &e_p2.span),
        crate::syntax::ExprKind::EField(recv_pp, sigils_pq, name_pr) => crate::check::expr::operators::infer_field(env_p0, st_p1, &**recv_pp, sigils_pq, name_pr, &e_p2.span),
        crate::syntax::ExprKind::EIndex(recv_ps, idx_pt) => crate::check::expr::operators::infer_index(env_p0, st_p1, &**recv_ps, &**idx_pt, &e_p2.span),
        crate::syntax::ExprKind::ETopicField(_) => crate::check::expr::calls::infer_lambda(env_p0, st_p1, e_p2, &None),
        crate::syntax::ExprKind::ETopicIndex(_) => crate::check::expr::calls::infer_lambda(env_p0, st_p1, e_p2, &None),
        crate::syntax::ExprKind::EMethod(recv_pu, m_pv, args_p10) => crate::check::expr::calls::infer_call(env_p0, st_p1, &crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(m_pv.clone())), span: m_pv.span.clone() }, &append(&Array::from(vec![crate::syntax::Arg { name: None, value: (**recv_pu).clone(), span: recv_pu.span.clone() }]), args_p10), &e_p2.span),
        crate::syntax::ExprKind::ETypeArgs(target_p11, _) => crate::check::expr::calls::infer_call(env_p0, st_p1, e_p2, &Array::new(), &e_p2.span),
        crate::syntax::ExprKind::ECast(x_p12, ty_p13, checked_p14) => if *checked_p14 {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unsupported"), &e_p2.span, &Text::lit("this checker does not implement non-empty arrays")))
        } else {
            {
                let cx_p15 = env_cx(env_p0);
                let (t_p17, st2_p18) = crate::check::env::reading::conv_type(&cx_p15, st_p1, ty_p13);
                let st3_p16 = check(env_p0, &st2_p18, &**x_p12, &t_p17);
                (t_p17.clone(), st3_p16.clone())
            }
        },
        crate::syntax::ExprKind::ENonEmpty(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unsupported"), &e_p2.span, &Text::lit("this checker does not implement non-empty arrays"))),
        crate::syntax::ExprKind::EAbsent => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unsupported"), &e_p2.span, &Text::lit("this checker does not implement sparse tuples"))),
        crate::syntax::ExprKind::ERest => (crate::check::types::Ty::TyErr, st_p1.clone()),
        crate::syntax::ExprKind::ELambda(_, _) => crate::check::expr::calls::infer_lambda(env_p0, st_p1, e_p2, &None),
        crate::syntax::ExprKind::EIf(c_p19, then_b_p1a, else_b_o1b) => crate::check::expr::lifting::infer_if(env_p0, st_p1, &**c_p19, then_b_p1a, else_b_o1b, &e_p2.span, &None),
        crate::syntax::ExprKind::EMatch(scrut_p1c, arms_p1d) => crate::check::expr::lifting::infer_match(env_p0, st_p1, &**scrut_p1c, arms_p1d, &e_p2.span, &None),
        crate::syntax::ExprKind::ERebuild(scrut_p1e, body_p1f) => crate::check::blocks::structure::infer_rebuild(env_p0, st_p1, &**scrut_p1e, body_p1f, &e_p2.span),
        crate::syntax::ExprKind::EFor(binders_o1g, source_p1h, body_p1i) => crate::check::blocks::structure::infer_for(env_p0, st_p1, binders_o1g, &**source_p1h, body_p1i, &e_p2.span),
        crate::syntax::ExprKind::EGiven(b_p1j) => crate::check::blocks::structure::infer_given(env_p0, st_p1, b_p1j, &e_p2.span),
        crate::syntax::ExprKind::EUpdate(target_p1k, body_p1l) => crate::check::blocks::borrows::infer_update(env_p0, st_p1, &**target_p1k, body_p1l, &e_p2.span),
        crate::syntax::ExprKind::EWidgetBlock(b_p1m) => {
            let (t_p1n, st2_p1o) = crate::check::blocks::infer_widget_block(env_p0, st_p1, b_p1m);
            (crate::check::types::Ty::TyAt(Rc::new(t_p1n.clone()), env_p0.scope.clone()), st2_p1o.clone())
        },
        crate::syntax::ExprKind::EMonad(_, _) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unsupported"), &e_p2.span, &Text::lit("this checker does not implement `T monad:` blocks"))),
        crate::syntax::ExprKind::ETemplate(t_p1p) => crate::check::expr::lets::infer_template(env_p0, st_p1, t_p1p),
        crate::syntax::ExprKind::EAny(x_p1q) => {
            let (t_p1r, st2_p1s) = infer(env_p0, st_p1, &**x_p1q);
            (crate::check::types::Ty::TyAny(Array::new()), st2_p1s.clone())
        },
        crate::syntax::ExprKind::ELens(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unsupported"), &e_p2.span, &Text::lit("this checker does not implement named lenses and `Over`"))),
        crate::syntax::ExprKind::EError => (crate::check::types::Ty::TyErr, st_p1.clone()),
    }
}

/// The step machine of `InferKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub struct InferKind {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferKind {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind {
            crate::syntax::ExprKind::EName(n_p3) => prism_rtl::Turn::More(Rc::new(InferName { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p3.clone(), span_p3: e_p2.span.clone() })),
            crate::syntax::ExprKind::ELit(l_p4) => prism_rtl::Turn::More(Rc::new(InferLit { env_p0: env_p0.clone(), st_p1: st_p1.clone(), l_p2: l_p4.clone(), negative_p3: false, span_p4: e_p2.span.clone() })),
            crate::syntax::ExprKind::EUnit(marks_p5) => prism_rtl::Turn::Finished((crate::check::types::with_marks(marks_p5, &crate::check::types::t_unit(), &env_p0.scope), st_p1.clone())),
            crate::syntax::ExprKind::ENil(marks_p6) => {
                let (v_p7, st2_p8) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                prism_rtl::Turn::Finished((crate::check::types::with_marks(marks_p6, &crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_p7.clone())), &env_p0.scope), st2_p8.clone()))
            },
            crate::syntax::ExprKind::EBound(b_p9) => prism_rtl::Turn::Finished(infer_bound(env_p0, st_p1, b_p9, &e_p2.span)),
            crate::syntax::ExprKind::ETuple(es_pa) => {
                let env_p0 = env_p0.clone();
                let es_pa = es_pa.clone();
                let st_p1 = st_p1.clone();
                call_then(start_infer_all(env_p0.clone(), st_p1.clone(), es_pa.clone()), move |infer_all_4906: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (ts_pb, st2_pc) = infer_all_4906;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyTuple(ts_pb.clone()), st2_pc.clone()))
                })
            },
            crate::syntax::ExprKind::EArray(es_pd) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferArray { env_p0: env_p0.clone(), st_p1: st_p1.clone(), es_p2: es_pd.clone(), span_p3: e_p2.span.clone() })),
            crate::syntax::ExprKind::EMap(entries_pe) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferMap { env_p0: env_p0.clone(), st_p1: st_p1.clone(), entries_p2: entries_pe.clone(), span_p3: e_p2.span.clone() })),
            crate::syntax::ExprKind::EGroup(x_pf) => prism_rtl::Turn::More(Rc::new(Infer { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: (**x_pf).clone() })),
            crate::syntax::ExprKind::ECall(callee_pg, args_ph, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferCall { env_p0: env_p0.clone(), st_p1: st_p1.clone(), callee_p2: (**callee_pg).clone(), args_p3: args_ph.clone(), span_p4: e_p2.span.clone() })),
            crate::syntax::ExprKind::EBinary(op_pi, lhs_pj, rhs_pk) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferBinary { env_p0: env_p0.clone(), st_p1: st_p1.clone(), op_p2: op_pi.clone(), lhs_p3: (**lhs_pj).clone(), rhs_p4: (**rhs_pk).clone(), span_p5: e_p2.span.clone() })),
            crate::syntax::ExprKind::EUnary(op_pl, x_pm) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferUnary { env_p0: env_p0.clone(), st_p1: st_p1.clone(), op_p2: op_pl.clone(), x_p3: (**x_pm).clone(), span_p4: e_p2.span.clone() })),
            crate::syntax::ExprKind::ESuffixed(_, _, _, _) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unsupported"), &e_p2.span, &Text::lit("this checker does not implement suffixed operators")))),
            crate::syntax::ExprKind::EFreeSigil(s_pn, x_po) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferFreeSigil { env_p0: env_p0.clone(), st_p1: st_p1.clone(), s_p2: s_pn.clone(), x_p3: (**x_po).clone(), span_p4: e_p2.span.clone() })),
            crate::syntax::ExprKind::EField(recv_pp, sigils_pq, name_pr) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferField { env_p0: env_p0.clone(), st_p1: st_p1.clone(), recv_p2: (**recv_pp).clone(), sigils_p3: sigils_pq.clone(), name_p4: name_pr.clone(), span_p5: e_p2.span.clone() })),
            crate::syntax::ExprKind::EIndex(recv_ps, idx_pt) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferIndex { env_p0: env_p0.clone(), st_p1: st_p1.clone(), recv_p2: (**recv_ps).clone(), idx_p3: (**idx_pt).clone(), span_p4: e_p2.span.clone() })),
            crate::syntax::ExprKind::ETopicField(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferLambda { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p2.clone(), expected_o3: None })),
            crate::syntax::ExprKind::ETopicIndex(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferLambda { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p2.clone(), expected_o3: None })),
            crate::syntax::ExprKind::EMethod(recv_pu, m_pv, args_p10) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferCall { env_p0: env_p0.clone(), st_p1: st_p1.clone(), callee_p2: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(m_pv.clone())), span: m_pv.span.clone() }, args_p3: append(&Array::from(vec![crate::syntax::Arg { name: None, value: (**recv_pu).clone(), span: recv_pu.span.clone() }]), args_p10), span_p4: e_p2.span.clone() })),
            crate::syntax::ExprKind::ETypeArgs(target_p11, _) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferCall { env_p0: env_p0.clone(), st_p1: st_p1.clone(), callee_p2: e_p2.clone(), args_p3: Array::new(), span_p4: e_p2.span.clone() })),
            crate::syntax::ExprKind::ECast(x_p12, ty_p13, checked_p14) => if *checked_p14 {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unsupported"), &e_p2.span, &Text::lit("this checker does not implement non-empty arrays"))))
            } else {
                {
                    let cx_p15 = env_cx(env_p0);
                    let env_p0 = env_p0.clone();
                    let st_p1 = st_p1.clone();
                    let ty_p13 = ty_p13.clone();
                    let x_p12 = (**x_p12).clone();
                    call_then(crate::check::env::reading::start_conv_type(cx_p15.clone(), st_p1.clone(), ty_p13.clone()), move |conv_type_6159: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_p17, st2_p18) = conv_type_6159;
                        call_then(start_check(env_p0.clone(), st2_p18.clone(), x_p12.clone(), t_p17.clone()), move |check_6201: crate::check::types::St| {
                            let st3_p16 = check_6201;
                            prism_rtl::Turn::Finished((t_p17.clone(), st3_p16.clone()))
                        })
                    })
                }
            },
            crate::syntax::ExprKind::ENonEmpty(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unsupported"), &e_p2.span, &Text::lit("this checker does not implement non-empty arrays")))),
            crate::syntax::ExprKind::EAbsent => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unsupported"), &e_p2.span, &Text::lit("this checker does not implement sparse tuples")))),
            crate::syntax::ExprKind::ERest => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st_p1.clone())),
            crate::syntax::ExprKind::ELambda(_, _) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferLambda { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p2.clone(), expected_o3: None })),
            crate::syntax::ExprKind::EIf(c_p19, then_b_p1a, else_b_o1b) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lifting::InferIf { env_p0: env_p0.clone(), st_p1: st_p1.clone(), c_p2: (**c_p19).clone(), then_b_p3: then_b_p1a.clone(), else_b_o4: else_b_o1b.clone(), span_p5: e_p2.span.clone(), expected_o6: None })),
            crate::syntax::ExprKind::EMatch(scrut_p1c, arms_p1d) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lifting::InferMatch { env_p0: env_p0.clone(), st_p1: st_p1.clone(), scrut_p2: (**scrut_p1c).clone(), arms_p3: arms_p1d.clone(), span_p4: e_p2.span.clone(), expected_o5: None })),
            crate::syntax::ExprKind::ERebuild(scrut_p1e, body_p1f) => prism_rtl::Turn::More(Rc::new(crate::check::blocks::structure::InferRebuild { env_p0: env_p0.clone(), st_p1: st_p1.clone(), scrut_p2: (**scrut_p1e).clone(), body_p3: body_p1f.clone(), span_p4: e_p2.span.clone() })),
            crate::syntax::ExprKind::EFor(binders_o1g, source_p1h, body_p1i) => prism_rtl::Turn::More(Rc::new(crate::check::blocks::structure::InferFor { env_p0: env_p0.clone(), st_p1: st_p1.clone(), binders_o2: binders_o1g.clone(), source_p3: (**source_p1h).clone(), body_p4: body_p1i.clone(), span_p5: e_p2.span.clone() })),
            crate::syntax::ExprKind::EGiven(b_p1j) => prism_rtl::Turn::More(Rc::new(crate::check::blocks::structure::InferGiven { env_p0: env_p0.clone(), st_p1: st_p1.clone(), b_p2: b_p1j.clone(), span_p3: e_p2.span.clone() })),
            crate::syntax::ExprKind::EUpdate(target_p1k, body_p1l) => prism_rtl::Turn::More(Rc::new(crate::check::blocks::borrows::InferUpdate { env_p0: env_p0.clone(), st_p1: st_p1.clone(), target_p2: (**target_p1k).clone(), body_p3: body_p1l.clone(), span_p4: e_p2.span.clone() })),
            crate::syntax::ExprKind::EWidgetBlock(b_p1m) => {
                let b_p1m = b_p1m.clone();
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::blocks::start_infer_widget_block(env_p0.clone(), st_p1.clone(), b_p1m.clone()), move |infer_widget_block_6997: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p1n, st2_p1o) = infer_widget_block_6997;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyAt(Rc::new(t_p1n.clone()), env_p0.scope.clone()), st2_p1o.clone()))
                })
            },
            crate::syntax::ExprKind::EMonad(_, _) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unsupported"), &e_p2.span, &Text::lit("this checker does not implement `T monad:` blocks")))),
            crate::syntax::ExprKind::ETemplate(t_p1p) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::InferTemplate { env_p0: env_p0.clone(), st_p1: st_p1.clone(), t_p2: t_p1p.clone() })),
            crate::syntax::ExprKind::EAny(x_p1q) => {
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                let x_p1q = (**x_p1q).clone();
                call_then(start_infer(env_p0.clone(), st_p1.clone(), x_p1q.clone()), move |infer_7264: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p1r, st2_p1s) = infer_7264;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyAny(Array::new()), st2_p1s.clone()))
                })
            },
            crate::syntax::ExprKind::ELens(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unsupported"), &e_p2.span, &Text::lit("this checker does not implement named lenses and `Over`")))),
            crate::syntax::ExprKind::EError => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st_p1.clone())),
        }
    }
}

/// `Start InferKind, x`: what the function value is when passed to `@Run`.
pub fn start_infer_kind(env_p0: Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferKind { env_p0, st_p1, e_p2 })
}

/// ```prism
/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
/// ```
pub fn infer_all(env_p0: &Env, st_p1: &crate::check::types::St, es_p2: &Array<crate::syntax::Expr>) -> (Array<crate::check::types::Ty>, crate::check::types::St) {
    run_to_end(fold_job(es_p2.clone(), (Array::new(), st_p1.clone()), {
        let env_p0 = env_p0.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)| {
            let env_p0 = env_p0.clone();
            entered(once_job(move || {
                let (acc_p3, s_p4) = p0;
                let x_p5 = p1;
                call_then(start_infer(env_p0.clone(), s_p4.clone(), x_p5.clone()), move |infer_7597: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p6, s2_p7) = infer_7597;
                    prism_rtl::Turn::Finished((push(&acc_p3, &t_p6), s2_p7.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }))
}

/// The step machine of `InferAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
/// ```
pub struct InferAll {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub es_p2: Array<crate::syntax::Expr>,
}

impl prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)> for InferAll {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Ty>, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let es_p2 = &self.es_p2;
        fold_job(es_p2.clone(), (Array::new(), st_p1.clone()), {
            let env_p0 = env_p0.clone();
            Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)| {
                let env_p0 = env_p0.clone();
                entered(once_job(move || {
                    let (acc_p3, s_p4) = p0;
                    let x_p5 = p1;
                    call_then(start_infer(env_p0.clone(), s_p4.clone(), x_p5.clone()), move |infer_7597: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_p6, s2_p7) = infer_7597;
                        prism_rtl::Turn::Finished((push(&acc_p3, &t_p6), s2_p7.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start InferAll, x`: what the function value is when passed to `@Run`.
pub fn start_infer_all(env_p0: Env, st_p1: crate::check::types::St, es_p2: Array<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>> {
    Rc::new(InferAll { env_p0, st_p1, es_p2 })
}

/// ```prism
/// Check: unbounded fn Env, St, Expr, Ty -> St
/// ```
pub fn check(env_p0: &Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, expected_p3: &crate::check::types::Ty) -> crate::check::types::St {
    match &*e_p2.kind {
        crate::syntax::ExprKind::ELambda(_, _) => {
            let (t_p4, st2_p5) = crate::check::expr::calls::infer_lambda(env_p0, st_p1, e_p2, &Some(expected_p3.clone()));
            crate::check::types::unify::unify(&crate::check::types::recording::note_ty(&st2_p5, &e_p2.span, &t_p4), expected_p3, &t_p4, &e_p2.span)
        },
        crate::syntax::ExprKind::EGroup(x_p6) => crate::check::types::recording::note_ty(&check(env_p0, st_p1, &**x_p6, expected_p3), &e_p2.span, expected_p3),
        crate::syntax::ExprKind::EMatch(scrut_p7, arms_p8) => {
            let (t_p9, st2_pa) = crate::check::expr::lifting::infer_match(env_p0, st_p1, &**scrut_p7, arms_p8, &e_p2.span, &Some(expected_p3.clone()));
            crate::check::types::unify::unify(&crate::check::types::recording::note_ty(&st2_pa, &e_p2.span, &t_p9), expected_p3, &t_p9, &e_p2.span)
        },
        crate::syntax::ExprKind::EIf(c_pb, then_b_pc, else_b_od) => {
            let (t_pe, st2_pf) = crate::check::expr::lifting::infer_if(env_p0, st_p1, &**c_pb, then_b_pc, else_b_od, &e_p2.span, &Some(expected_p3.clone()));
            crate::check::types::unify::unify(&crate::check::types::recording::note_ty(&st2_pf, &e_p2.span, &t_pe), expected_p3, &t_pe, &e_p2.span)
        },
        crate::syntax::ExprKind::EAny(x_pg) => crate::check::types::recording::note_ty(&check_any(env_p0, st_p1, &**x_pg, expected_p3, &e_p2.span), &e_p2.span, expected_p3),
        _ => {
            let (t_ph, st2_pi) = infer(env_p0, st_p1, e_p2);
            crate::check::types::unify::unify(&st2_pi, expected_p3, &t_ph, &e_p2.span)
        },
    }
}

/// The step machine of `Check`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Check: unbounded fn Env, St, Expr, Ty -> St
/// ```
pub struct Check {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub expected_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for Check {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let expected_p3 = &self.expected_p3;
        match &*e_p2.kind {
            crate::syntax::ExprKind::ELambda(_, _) => {
                let e_p2 = e_p2.clone();
                let env_p0 = env_p0.clone();
                let expected_p3 = expected_p3.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::expr::calls::start_infer_lambda(env_p0.clone(), st_p1.clone(), e_p2.clone(), Some(expected_p3.clone())), move |infer_lambda_7906: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p4, st2_p5) = infer_lambda_7906;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: crate::check::types::recording::note_ty(&st2_p5, &e_p2.span, &t_p4), expected_p1: expected_p3.clone(), found_p2: t_p4.clone(), span_p3: e_p2.span.clone() }))
                })
            },
            crate::syntax::ExprKind::EGroup(x_p6) => {
                let e_p2 = e_p2.clone();
                let env_p0 = env_p0.clone();
                let expected_p3 = expected_p3.clone();
                let st_p1 = st_p1.clone();
                let x_p6 = (**x_p6).clone();
                call_then(start_check(env_p0.clone(), st_p1.clone(), x_p6.clone(), expected_p3.clone()), move |check_8024: crate::check::types::St| prism_rtl::Turn::Finished(crate::check::types::recording::note_ty(&check_8024, &e_p2.span, &expected_p3)))
            },
            crate::syntax::ExprKind::EMatch(scrut_p7, arms_p8) => {
                let arms_p8 = arms_p8.clone();
                let e_p2 = e_p2.clone();
                let env_p0 = env_p0.clone();
                let expected_p3 = expected_p3.clone();
                let scrut_p7 = (**scrut_p7).clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::expr::lifting::start_infer_match(env_p0.clone(), st_p1.clone(), scrut_p7.clone(), arms_p8.clone(), e_p2.span.clone(), Some(expected_p3.clone())), move |infer_match_8119: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p9, st2_pa) = infer_match_8119;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: crate::check::types::recording::note_ty(&st2_pa, &e_p2.span, &t_p9), expected_p1: expected_p3.clone(), found_p2: t_p9.clone(), span_p3: e_p2.span.clone() }))
                })
            },
            crate::syntax::ExprKind::EIf(c_pb, then_b_pc, else_b_od) => {
                let else_b_od = else_b_od.clone();
                let c_pb = (**c_pb).clone();
                let e_p2 = e_p2.clone();
                let env_p0 = env_p0.clone();
                let expected_p3 = expected_p3.clone();
                let st_p1 = st_p1.clone();
                let then_b_pc = then_b_pc.clone();
                call_then(crate::check::expr::lifting::start_infer_if(env_p0.clone(), st_p1.clone(), c_pb.clone(), then_b_pc.clone(), else_b_od.clone(), e_p2.span.clone(), Some(expected_p3.clone())), move |infer_if_8283: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pe, st2_pf) = infer_if_8283;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: crate::check::types::recording::note_ty(&st2_pf, &e_p2.span, &t_pe), expected_p1: expected_p3.clone(), found_p2: t_pe.clone(), span_p3: e_p2.span.clone() }))
                })
            },
            crate::syntax::ExprKind::EAny(x_pg) => {
                let e_p2 = e_p2.clone();
                let env_p0 = env_p0.clone();
                let expected_p3 = expected_p3.clone();
                let st_p1 = st_p1.clone();
                let x_pg = (**x_pg).clone();
                call_then(start_check_any(env_p0.clone(), st_p1.clone(), x_pg.clone(), expected_p3.clone(), e_p2.span.clone()), move |check_any_8418: crate::check::types::St| prism_rtl::Turn::Finished(crate::check::types::recording::note_ty(&check_any_8418, &e_p2.span, &expected_p3)))
            },
            _ => {
                let e_p2 = e_p2.clone();
                let env_p0 = env_p0.clone();
                let expected_p3 = expected_p3.clone();
                let st_p1 = st_p1.clone();
                call_then(start_infer(env_p0.clone(), st_p1.clone(), e_p2.clone()), move |infer_8515: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_ph, st2_pi) = infer_8515;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st2_pi.clone(), expected_p1: expected_p3.clone(), found_p2: t_ph.clone(), span_p3: e_p2.span.clone() }))
                })
            },
        }
    }
}

/// `Start Check, x`: what the function value is when passed to `@Run`.
pub fn start_check(env_p0: Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, expected_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Check { env_p0, st_p1, e_p2, expected_p3 })
}

/// ```prism
/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
/// ```
pub fn check_any(env_p0: &Env, st_p1: &crate::check::types::St, x_p2: &crate::syntax::Expr, expected_p3: &crate::check::types::Ty, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk(st_p1, expected_p3) {
        crate::check::types::Ty::TyAny(trs_p5) => {
            let (t_p6, st2_p7) = infer(env_p0, st_p1, x_p2);
            fold(&trs_p5, &st2_p7, &(|s_p8: &crate::check::types::St, tr_p9: &Text| add_want(s_p8, tr_p9, &t_p6, span_p4)))
        },
        other_pa => {
            let (t_pb, st2_pc) = infer(env_p0, st_p1, x_p2);
            crate::check::types::unify::unify(&st2_pc, &other_pa, &crate::check::types::Ty::TyAny(Array::new()), span_p4)
        },
    }
}

/// The step machine of `CheckAny`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
/// ```
pub struct CheckAny {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub x_p2: crate::syntax::Expr,
    pub expected_p3: crate::check::types::Ty,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for CheckAny {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let x_p2 = &self.x_p2;
        let expected_p3 = &self.expected_p3;
        let span_p4 = &self.span_p4;
        let env_p0 = env_p0.clone();
        let expected_p3 = expected_p3.clone();
        let span_p4 = span_p4.clone();
        let st_p1 = st_p1.clone();
        let x_p2 = x_p2.clone();
        call_then(crate::check::types::recording::start_walk(st_p1.clone(), expected_p3.clone()), move |walk_8763: crate::check::types::Ty| match walk_8763 {
            crate::check::types::Ty::TyAny(trs_p5) => call_then(start_infer(env_p0.clone(), st_p1.clone(), x_p2.clone()), move |infer_8822: (crate::check::types::Ty, crate::check::types::St)| {
                let (t_p6, st2_p7) = infer_8822;
                prism_rtl::Turn::Finished(fold(&trs_p5, &st2_p7, &(|s_p8: &crate::check::types::St, tr_p9: &Text| add_want(s_p8, tr_p9, &t_p6, &span_p4))))
            }),
            other_pa => call_then(start_infer(env_p0.clone(), st_p1.clone(), x_p2.clone()), move |infer_8930: (crate::check::types::Ty, crate::check::types::St)| {
                let (t_pb, st2_pc) = infer_8930;
                prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st2_pc.clone(), expected_p1: other_pa.clone(), found_p2: crate::check::types::Ty::TyAny(Array::new()), span_p3: span_p4.clone() }))
            }),
        })
    }
}

/// `Start CheckAny, x`: what the function value is when passed to `@Run`.
pub fn start_check_any(env_p0: Env, st_p1: crate::check::types::St, x_p2: crate::syntax::Expr, expected_p3: crate::check::types::Ty, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckAny { env_p0, st_p1, x_p2, expected_p3, span_p4 })
}

/// ```prism
/// AddWant: fn St, Text, Ty, Range -> St
/// ```
pub fn add_want(st_p0: &crate::check::types::St, cls_p1: &Text, t_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.wants = push(&this.wants, &crate::check::types::Want { cls: cls_p1.clone(), ty: t_p2.clone(), file: this.file.clone(), span: span_p3.clone(), level: this.level.clone() });
    this
}

/// ```prism
/// EnvCx: fn Env -> Cx
/// ```
pub fn env_cx(env_p0: &Env) -> crate::check::env::reading::Cx_ {
    let base_p1 = crate::check::env::reading::cx_of(&env_p0.g, &env_p0.home);
    let mut this: crate::check::env::reading::Cx_ = base_p1.clone();
    this.scope = env_p0.scope.clone();
    this
}

/// ```prism
/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_name(env_p0: &Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let local_p4 = crate::check::env::sname_key(n_p2);
    if env_p0.in_update && has_time_mark(&n_p2.sigils) {
        (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(st_p1, &Text::lit("time-in-update"), span_p3, &Text::from(format!("`{}` in an `update` block", &local_p4)), &Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function")))
    } else {
        infer_name_in(env_p0, st_p1, n_p2, span_p3)
    }
}

/// The step machine of `InferName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferName {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferName {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let span_p3 = &self.span_p3;
        let local_p4 = crate::check::env::sname_key(n_p2);
        if env_p0.in_update && has_time_mark(&n_p2.sigils) {
            prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(st_p1, &Text::lit("time-in-update"), span_p3, &Text::from(format!("`{}` in an `update` block", &local_p4)), &Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function"))))
        } else {
            prism_rtl::Turn::More(Rc::new(InferNameIn { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p2.clone(), span_p3: span_p3.clone() }))
        }
    }
}

/// `Start InferName, x`: what the function value is when passed to `@Run`.
pub fn start_infer_name(env_p0: Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferName { env_p0, st_p1, n_p2, span_p3 })
}

/// ```prism
/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_name_in(env_p0: &Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let local_p4 = crate::check::env::sname_key(n_p2);
    match get(&env_p0.locals, &local_p4) {
        Some(sc_p5) => {
            let st2_p6 = match get(&env_p0.ids, &local_p4) {
                Some(id_p7) => crate::check::types::recording::note_use(st_p1, span_p3, &id_p7),
                None => st_p1.clone(),
            };
            instantiate_local(&st2_p6, &sc_p5, span_p3, &local_p4)
        },
        None => infer_global(env_p0, st_p1, n_p2, span_p3),
    }
}

/// The step machine of `InferNameIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferNameIn {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferNameIn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let span_p3 = &self.span_p3;
        let local_p4 = crate::check::env::sname_key(n_p2);
        match get(&env_p0.locals, &local_p4) {
            Some(sc_p5) => {
                let st2_p6 = match get(&env_p0.ids, &local_p4) {
                    Some(id_p7) => crate::check::types::recording::note_use(st_p1, span_p3, &id_p7),
                    None => st_p1.clone(),
                };
                prism_rtl::Turn::More(Rc::new(InstantiateLocal { st_p0: st2_p6.clone(), sc_p1: sc_p5.clone(), span_p2: span_p3.clone(), name_p3: local_p4.clone() }))
            },
            None => prism_rtl::Turn::More(Rc::new(InferGlobal { env_p0: env_p0.clone(), st0_p1: st_p1.clone(), n_p2: n_p2.clone(), span_p3: span_p3.clone() })),
        }
    }
}

/// `Start InferNameIn, x`: what the function value is when passed to `@Run`.
pub fn start_infer_name_in(env_p0: Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferNameIn { env_p0, st_p1, n_p2, span_p3 })
}

/// ```prism
/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
/// ```
pub fn instantiate_local(st_p0: &crate::check::types::St, sc_p1: &crate::check::types::Scheme, span_p2: &crate::syntax::Range, name_p3: &Text) -> (crate::check::types::Ty, crate::check::types::St) {
    if (&len(&sc_p1.qs) == &Nat::from(0u32)) && (&len(&sc_p1.cqs) == &Nat::from(0u32)) {
        crate::check::types::schemes::instantiate(st_p0, sc_p1, span_p2)
    } else {
        {
            let (t_p4, st2_p5, inst_p6) = crate::check::types::schemes::instantiate_with(st_p0, sc_p1, span_p2, &Array::new());
            (t_p4.clone(), crate::check::types::recording::note_inst(&st2_p5, span_p2, name_p3, sc_p1, &inst_p6))
        }
    }
}

/// The step machine of `InstantiateLocal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
/// ```
pub struct InstantiateLocal {
    pub st_p0: crate::check::types::St,
    pub sc_p1: crate::check::types::Scheme,
    pub span_p2: crate::syntax::Range,
    pub name_p3: Text,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InstantiateLocal {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let sc_p1 = &self.sc_p1;
        let span_p2 = &self.span_p2;
        let name_p3 = &self.name_p3;
        if (&len(&sc_p1.qs) == &Nat::from(0u32)) && (&len(&sc_p1.cqs) == &Nat::from(0u32)) {
            prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::Instantiate { st_p0: st_p0.clone(), sc_p1: sc_p1.clone(), span_p2: span_p2.clone() }))
        } else {
            {
                let name_p3 = name_p3.clone();
                let sc_p1 = sc_p1.clone();
                let span_p2 = span_p2.clone();
                let st_p0 = st_p0.clone();
                call_then(crate::check::types::schemes::start_instantiate_with(st_p0.clone(), sc_p1.clone(), span_p2.clone(), Array::new()), move |instantiate_with_10571: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                    let (t_p4, st2_p5, inst_p6) = instantiate_with_10571;
                    prism_rtl::Turn::Finished((t_p4.clone(), crate::check::types::recording::note_inst(&st2_p5, &span_p2, &name_p3, &sc_p1, &inst_p6)))
                })
            }
        }
    }
}

/// `Start InstantiateLocal, x`: what the function value is when passed to `@Run`.
pub fn start_instantiate_local(st_p0: crate::check::types::St, sc_p1: crate::check::types::Scheme, span_p2: crate::syntax::Range, name_p3: Text) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InstantiateLocal { st_p0, sc_p1, span_p2, name_p3 })
}

/// ```prism
/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_global(env_p0: &Env, st0_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (qk_o5, why_p6) = crate::check::env::names::resolve_value(&env_p0.g, &env_p0.home, n_p2);
    let st_p4 = collision_at(env_p0, st0_p1, &why_p6, &crate::check::env::sname_key(n_p2), span_p3);
    match &qk_o5 {
        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st_p4, &Text::lit("unknown-name"), span_p3, &Text::from(format!("nothing declares `{}` here", &crate::check::env::sname_key(n_p2))))),
        Some(qk_p7) => if &why_p6 == &Text::lit("tag") {
            tag_value(env_p0, &st_p4, qk_p7, span_p3)
        } else {
            if crate::check::expr::calls::is_local_maker(qk_p7) && !env_p0.in_update {
                (crate::check::types::Ty::TyErr, crate::check::expr::calls::local_outside(&st_p4, qk_p7, span_p3))
            } else {
                match get(&env_p0.g.vals, qk_p7) {
                    Some(v_p8) => crate::check::types::schemes::instantiate(&crate::check::expr::calls::note_method_use(&st_p4, &v_p8, span_p3), &v_p8.scheme, span_p3),
                    None => match get(&env_p0.g.ctors, qk_p7) {
                        Some(c_p9) => ctor_value(env_p0, &st_p4, &c_p9, span_p3),
                        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st_p4, &Text::lit("unknown-name"), span_p3, &Text::from(format!("`{}` has no signature line or type", &crate::check::env::sname_key(n_p2))))),
                    },
                }
            }
        },
    }
}

/// The step machine of `InferGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferGlobal {
    pub env_p0: Env,
    pub st0_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferGlobal {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st0_p1 = &self.st0_p1;
        let n_p2 = &self.n_p2;
        let span_p3 = &self.span_p3;
        let (qk_o5, why_p6) = crate::check::env::names::resolve_value(&env_p0.g, &env_p0.home, n_p2);
        let st_p4 = collision_at(env_p0, st0_p1, &why_p6, &crate::check::env::sname_key(n_p2), span_p3);
        match &qk_o5 {
            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st_p4, &Text::lit("unknown-name"), span_p3, &Text::from(format!("nothing declares `{}` here", &crate::check::env::sname_key(n_p2)))))),
            Some(qk_p7) => if &why_p6 == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(TagValue { env_p0: env_p0.clone(), st_p1: st_p4.clone(), name_p2: qk_p7.clone(), span_p3: span_p3.clone() }))
            } else {
                if crate::check::expr::calls::is_local_maker(qk_p7) && !env_p0.in_update {
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::expr::calls::local_outside(&st_p4, qk_p7, span_p3)))
                } else {
                    match get(&env_p0.g.vals, qk_p7) {
                        Some(v_p8) => prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::Instantiate { st_p0: crate::check::expr::calls::note_method_use(&st_p4, &v_p8, span_p3), sc_p1: v_p8.scheme.clone(), span_p2: span_p3.clone() })),
                        None => match get(&env_p0.g.ctors, qk_p7) {
                            Some(c_p9) => prism_rtl::Turn::More(Rc::new(CtorValue { env_p0: env_p0.clone(), st_p1: st_p4.clone(), c_p2: c_p9.clone(), span_p3: span_p3.clone() })),
                            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st_p4, &Text::lit("unknown-name"), span_p3, &Text::from(format!("`{}` has no signature line or type", &crate::check::env::sname_key(n_p2)))))),
                        },
                    }
                }
            },
        }
    }
}

/// `Start InferGlobal, x`: what the function value is when passed to `@Run`.
pub fn start_infer_global(env_p0: Env, st0_p1: crate::check::types::St, n_p2: crate::syntax::SName, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferGlobal { env_p0, st0_p1, n_p2, span_p3 })
}

/// ```prism
/// CollisionAt: fn Env, St, Text, Text, Range -> St
/// ```
pub fn collision_at(env_p0: &Env, st_p1: &crate::check::types::St, why_p2: &Text, name_p3: &Text, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    if why_p2 != &Text::lit("collision") {
        st_p1.clone()
    } else {
        {
            let keys_p5 = or(&get(&or(&get(&env_p0.g.bare, &env_p0.home), &Map::new()), name_p3), &Array::new());
            let others_p6 = filter(&keys_p5, &(|k_p7: &Text| crate::syntax::lexer::chars::contains(k_p7, &Text::lit("."))));
            crate::check::types::recording::err_fix(st_p1, &Text::lit("collision"), span_p4, &Text::from(format!("`{}` is declared by more than one module this file reaches by a bare name: {}", name_p3, &crate::syntax::lexer::chars::join(&each(&keys_p5, &(|k_p8: &Text| Text::from(format!("`{}`", k_p8)))), &Text::lit(", ")))), &Text::from(format!("write the one meant qualified, as `{}`, or rename this file\'s own", &or(&index(&others_p6, &Nat::from(0u32)), name_p3))))
        }
    }
}

/// ```prism
/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
/// ```
pub fn ctor_value(env_p0: &Env, st_p1: &crate::check::types::St, c_p2: &crate::check::env::CtorInfo, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let sc_p4 = crate::check::types::Scheme { qs: c_p2.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: if &len(&c_p2.args) == &Nat::from(0u32) {
        c_p2.ty.clone()
    } else {
        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, c_p2.args.clone(), Rc::new(c_p2.ty.clone()))
    } };
    crate::check::types::schemes::instantiate(st_p1, &sc_p4, span_p3)
}

/// The step machine of `CtorValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
/// ```
pub struct CtorValue {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::check::env::CtorInfo,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for CtorValue {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let span_p3 = &self.span_p3;
        let sc_p4 = crate::check::types::Scheme { qs: c_p2.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: if &len(&c_p2.args) == &Nat::from(0u32) {
            c_p2.ty.clone()
        } else {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, c_p2.args.clone(), Rc::new(c_p2.ty.clone()))
        } };
        prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::Instantiate { st_p0: st_p1.clone(), sc_p1: sc_p4.clone(), span_p2: span_p3.clone() }))
    }
}

/// `Start CtorValue, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_value(env_p0: Env, st_p1: crate::check::types::St, c_p2: crate::check::env::CtorInfo, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(CtorValue { env_p0, st_p1, c_p2, span_p3 })
}

/// ```prism
/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub fn tag_value(env_p0: &Env, st_p1: &crate::check::types::St, name_p2: &Text, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match get(&env_p0.g.tags, name_p2) {
        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), span_p3, &Text::from(format!("no tag `{}`", name_p2)))),
        Some(tg_p4) => if &tg_p4.kind == &Text::lit("Element") {
            {
                let (rw_p6, st2_p7) = crate::check::types::recording::fresh_row(st_p1, &Array::from(vec![tg_p4.family.clone()]));
                let erow_p5 = crate::check::types::Rw { fams: Array::from(vec![tg_p4.family.clone()]), minus: Array::new(), tail: rw_p6.tail.clone() };
                let (out_p8, st3_p9) = crate::check::types::schemes::instantiate(&st2_p7, &crate::check::types::Scheme { qs: tg_p4.qs.clone(), plain_qs: Array::new(), rqs: tg_p4.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: tg_p4.bounds.clone(), ty: tg_p4.out.clone() }, span_p3);
                (crate::check::types::Ty::TyElem(erow_p5.clone(), Rc::new(out_p8.clone())), st3_p9.clone())
            }
        } else {
            (crate::check::types::Ty::TyCon(tg_p4.kind.clone(), Array::new()), st_p1.clone())
        },
    }
}

/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub struct TagValue {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub name_p2: Text,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for TagValue {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let name_p2 = &self.name_p2;
        let span_p3 = &self.span_p3;
        match get(&env_p0.g.tags, name_p2) {
            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), span_p3, &Text::from(format!("no tag `{}`", name_p2))))),
            Some(tg_p4) => if &tg_p4.kind == &Text::lit("Element") {
                {
                    let (rw_p6, st2_p7) = crate::check::types::recording::fresh_row(st_p1, &Array::from(vec![tg_p4.family.clone()]));
                    let erow_p5 = crate::check::types::Rw { fams: Array::from(vec![tg_p4.family.clone()]), minus: Array::new(), tail: rw_p6.tail.clone() };
                    let span_p3 = span_p3.clone();
                    call_then(crate::check::types::schemes::start_instantiate(st2_p7.clone(), crate::check::types::Scheme { qs: tg_p4.qs.clone(), plain_qs: Array::new(), rqs: tg_p4.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: tg_p4.bounds.clone(), ty: tg_p4.out.clone() }, span_p3.clone()), move |instantiate_13081: (crate::check::types::Ty, crate::check::types::St)| {
                        let (out_p8, st3_p9) = instantiate_13081;
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(erow_p5.clone(), Rc::new(out_p8.clone())), st3_p9.clone()))
                    })
                }
            } else {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(tg_p4.kind.clone(), Array::new()), st_p1.clone()))
            },
        }
    }
}

/// `Start TagValue, x`: what the function value is when passed to `@Run`.
pub fn start_tag_value(env_p0: Env, st_p1: crate::check::types::St, name_p2: Text, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(TagValue { env_p0, st_p1, name_p2, span_p3 })
}

/// ```prism
/// InferBound: fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub fn infer_bound(env_p0: &Env, st_p1: &crate::check::types::St, b_p2: &Text, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match get(&env_p0.locals, b_p2) {
        Some(sc_p4) => (sc_p4.ty.clone(), st_p1.clone()),
        None => if b_p2 == &Text::lit("key") {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), span_p3, &Text::lit("`key` is bound only in a loop over a map")))
        } else {
            (crate::check::types::t_nat(), st_p1.clone())
        },
    }
}

/// ```prism
/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
/// ```
pub fn infer_lit(env_p0: &Env, st_p1: &crate::check::types::St, l_p2: &crate::syntax::Literal, negative_p3: &bool, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let sigils_p5 = crate::syntax::lexer::chars::fold_chars(&l_p2.marks, &Text::lit(""), &(Rc::new(move |(p0, p1): (Text, Text)| once_job(move || {
        let acc_p7 = p0;
        let c_p8 = p1;
        if crate::check::types::unify::is_mark_char(&c_p8) {
            prism_rtl::Turn::Finished(Text::from(format!("{}{}", &acc_p7, &c_p8)))
        } else {
            prism_rtl::Turn::Finished(acc_p7.clone())
        }
    })) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>));
    let signed_p6 = *negative_p3 || crate::syntax::lexer::chars::contains(&l_p2.marks, &Text::lit("-"));
    let (base_ph, st2_pi) = match &l_p2.kind {
        crate::syntax::LitKind::LInt(digits_p9) => {
            let (v_pd, s1_pe) = crate::check::types::fresh_var(st_p1, &true, &Text::lit(""));
            let s2_pa = add_want(&s1_pe, &Text::lit("Prelude.Num"), &v_pd, span_p4);
            let s3_pb = if signed_p6 {
                add_want(&s2_pa, &Text::lit("Prelude.Signed"), &v_pd, span_p4)
            } else {
                s2_pa.clone()
            };
            let s4_pc = add_range(&s3_pb, &v_pd, digits_p9, &signed_p6, span_p4);
            (v_pd.clone(), s4_pc.clone())
        },
        crate::syntax::LitKind::LFloat(_) => (crate::check::types::t_float(), st_p1.clone()),
        crate::syntax::LitKind::LDuration(_, _) => (crate::check::types::Ty::TyCon(Text::lit("Duration"), Array::new()), st_p1.clone()),
        crate::syntax::LitKind::LChar(_) => (crate::check::types::t_char(), st_p1.clone()),
        crate::syntax::LitKind::LText(segs_pf) => infer_text(env_p0, st_p1, segs_pf, &crate::syntax::lexer::chars::contains(&sigils_p5, &Text::lit("$")), span_p4),
        crate::syntax::LitKind::LRegex(r_pg) => infer_regex(st_p1, r_pg),
    };
    if crate::syntax::lexer::chars::contains(&sigils_p5, &Text::lit("$")) && (&crate::check::types::head_sigil(&st2_pi, &base_ph) == &Text::lit("$")) {
        (base_ph.clone(), st2_pi.clone())
    } else {
        if crate::syntax::lexer::chars::contains(&sigils_p5, &Text::lit("$")) {
            (crate::check::types::with_marks(&sigils_p5, &base_ph, &env_p0.scope), crate::check::types::recording::note_app(&st2_pi, span_p4, &Text::lit("$"), &Text::lit("const"), &Text::lit("$"), &Array::new(), &Text::lit(""), &crate::check::types::Col::CBound))
        } else {
            (crate::check::types::with_marks(&sigils_p5, &base_ph, &env_p0.scope), st2_pi.clone())
        }
    }
}

/// The step machine of `InferLit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
/// ```
pub struct InferLit {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub l_p2: crate::syntax::Literal,
    pub negative_p3: bool,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferLit {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let l_p2 = &self.l_p2;
        let negative_p3 = &self.negative_p3;
        let span_p4 = &self.span_p4;
        let env_p0 = env_p0.clone();
        let l_p2 = l_p2.clone();
        let negative_p3 = *negative_p3;
        let span_p4 = span_p4.clone();
        let st_p1 = st_p1.clone();
        call_value(crate::syntax::lexer::chars::start_fold_chars(l_p2.marks.clone(), Text::lit(""), Rc::new(move |(p0, p1): (Text, Text)| once_job(move || {
            let acc_p7 = p0;
            let c_p8 = p1;
            if crate::check::types::unify::is_mark_char(&c_p8) {
                prism_rtl::Turn::Finished(Text::from(format!("{}{}", &acc_p7, &c_p8)))
            } else {
                prism_rtl::Turn::Finished(acc_p7.clone())
            }
        })) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>), move |fold_chars_14054: Text| {
            let sigils_p5 = fold_chars_14054;
            let signed_p6 = negative_p3 || crate::syntax::lexer::chars::contains(&l_p2.marks, &Text::lit("-"));
            let (base_ph, st2_pi) = match &l_p2.kind {
                crate::syntax::LitKind::LInt(digits_p9) => {
                    let (v_pd, s1_pe) = crate::check::types::fresh_var(&st_p1, &true, &Text::lit(""));
                    let s2_pa = add_want(&s1_pe, &Text::lit("Prelude.Num"), &v_pd, &span_p4);
                    let s3_pb = if signed_p6 {
                        add_want(&s2_pa, &Text::lit("Prelude.Signed"), &v_pd, &span_p4)
                    } else {
                        s2_pa.clone()
                    };
                    let s4_pc = add_range(&s3_pb, &v_pd, digits_p9, &signed_p6, &span_p4);
                    (v_pd.clone(), s4_pc.clone())
                },
                crate::syntax::LitKind::LFloat(_) => (crate::check::types::t_float(), st_p1.clone()),
                crate::syntax::LitKind::LDuration(_, _) => (crate::check::types::Ty::TyCon(Text::lit("Duration"), Array::new()), st_p1.clone()),
                crate::syntax::LitKind::LChar(_) => (crate::check::types::t_char(), st_p1.clone()),
                crate::syntax::LitKind::LText(segs_pf) => infer_text(&env_p0, &st_p1, segs_pf, &crate::syntax::lexer::chars::contains(&sigils_p5, &Text::lit("$")), &span_p4),
                crate::syntax::LitKind::LRegex(r_pg) => infer_regex(&st_p1, r_pg),
            };
            if crate::syntax::lexer::chars::contains(&sigils_p5, &Text::lit("$")) && (&crate::check::types::head_sigil(&st2_pi, &base_ph) == &Text::lit("$")) {
                prism_rtl::Turn::Finished((base_ph.clone(), st2_pi.clone()))
            } else {
                if crate::syntax::lexer::chars::contains(&sigils_p5, &Text::lit("$")) {
                    prism_rtl::Turn::Finished((crate::check::types::with_marks(&sigils_p5, &base_ph, &env_p0.scope), crate::check::types::recording::note_app(&st2_pi, &span_p4, &Text::lit("$"), &Text::lit("const"), &Text::lit("$"), &Array::new(), &Text::lit(""), &crate::check::types::Col::CBound)))
                } else {
                    prism_rtl::Turn::Finished((crate::check::types::with_marks(&sigils_p5, &base_ph, &env_p0.scope), st2_pi.clone()))
                }
            }
        })
    }
}

/// `Start InferLit, x`: what the function value is when passed to `@Run`.
pub fn start_infer_lit(env_p0: Env, st_p1: crate::check::types::St, l_p2: crate::syntax::Literal, negative_p3: bool, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferLit { env_p0, st_p1, l_p2, negative_p3, span_p4 })
}

/// ```prism
/// InferRegex: unbounded fn St, RegexLit -> ((Ty, St))
/// ```
pub fn infer_regex(st_p0: &crate::check::types::St, r_p1: &crate::syntax::RegexLit) -> (crate::check::types::Ty, crate::check::types::St) {
    let t_p2 = crate::check::types::Ty::TyCon(if &r_p1.replacement == &None {
        Text::lit("Regex")
    } else {
        Text::lit("RegexReplacement")
    }, Array::new());
    match crate::check::regex::regex_refusal(&r_p1.pattern, &r_p1.flags, &r_p1.replacement) {
        None => (t_p2.clone(), st_p0.clone()),
        Some(d_p3) => {
            let (base_p6, text_p7) = if &d_p3.part == &Text::lit("flags") {
                (r_p1.flags_at.clone(), r_p1.flags.clone())
            } else {
                if &d_p3.part == &Text::lit("pattern") {
                    (r_p1.pattern_at.clone(), r_p1.pattern.clone())
                } else {
                    (r_p1.replacement_at.clone(), or(&r_p1.replacement, &Text::lit("")))
                }
            };
            let start_p4 = &base_p6 + &d_p3.at;
            let span_p5 = crate::syntax::Range { start: start_p4.clone(), end: &start_p4 + &max(&len_text(&crate::check::regex::rx_char_at(&text_p7, &d_p3.at)), &Nat::from(1u32)) };
            if &d_p3.message == &crate::check::regex::rx_unknown_flag() {
                (t_p2.clone(), crate::check::types::recording::err_fix(st_p0, &Text::lit("regex"), &span_p5, &d_p3.message, &Text::lit("a replacement that starts with letters and holds anything but letters is written in the hashed form, `%#/x/#hello world/#`")))
            } else {
                (t_p2.clone(), crate::check::types::recording::err(st_p0, &Text::lit("regex"), &span_p5, &d_p3.message))
            }
        },
    }
}

/// The step machine of `InferRegex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferRegex: unbounded fn St, RegexLit -> ((Ty, St))
/// ```
pub struct InferRegex {
    pub st_p0: crate::check::types::St,
    pub r_p1: crate::syntax::RegexLit,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferRegex {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let r_p1 = &self.r_p1;
        let t_p2 = crate::check::types::Ty::TyCon(if &r_p1.replacement == &None {
            Text::lit("Regex")
        } else {
            Text::lit("RegexReplacement")
        }, Array::new());
        let r_p1 = r_p1.clone();
        let st_p0 = st_p0.clone();
        call_then(crate::check::regex::start_regex_refusal(r_p1.pattern.clone(), r_p1.flags.clone(), r_p1.replacement.clone()), move |regex_refusal_15526: Option<crate::check::regex::RxDiag>| match regex_refusal_15526 {
            None => prism_rtl::Turn::Finished((t_p2.clone(), st_p0.clone())),
            Some(d_p3) => {
                let (base_p6, text_p7) = if &d_p3.part == &Text::lit("flags") {
                    (r_p1.flags_at.clone(), r_p1.flags.clone())
                } else {
                    if &d_p3.part == &Text::lit("pattern") {
                        (r_p1.pattern_at.clone(), r_p1.pattern.clone())
                    } else {
                        (r_p1.replacement_at.clone(), or(&r_p1.replacement, &Text::lit("")))
                    }
                };
                let start_p4 = &base_p6 + &d_p3.at;
                let span_p5 = crate::syntax::Range { start: start_p4.clone(), end: &start_p4 + &max(&len_text(&crate::check::regex::rx_char_at(&text_p7, &d_p3.at)), &Nat::from(1u32)) };
                if &d_p3.message == &crate::check::regex::rx_unknown_flag() {
                    prism_rtl::Turn::Finished((t_p2.clone(), crate::check::types::recording::err_fix(&st_p0, &Text::lit("regex"), &span_p5, &d_p3.message, &Text::lit("a replacement that starts with letters and holds anything but letters is written in the hashed form, `%#/x/#hello world/#`"))))
                } else {
                    prism_rtl::Turn::Finished((t_p2.clone(), crate::check::types::recording::err(&st_p0, &Text::lit("regex"), &span_p5, &d_p3.message)))
                }
            },
        })
    }
}

/// `Start InferRegex, x`: what the function value is when passed to `@Run`.
pub fn start_infer_regex(st_p0: crate::check::types::St, r_p1: crate::syntax::RegexLit) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferRegex { st_p0, r_p1 })
}

/// ```prism
/// AddRange: fn St, Ty, Text, Bool, Range -> St
/// ```
pub fn add_range(st_p0: &crate::check::types::St, v_p1: &crate::check::types::Ty, digits_p2: &Text, signed_p3: &bool, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.wants = push(&this.wants, &crate::check::types::Want { cls: Text::from(format!("Range {}{}", &(if *signed_p3 { Text::lit("-") } else { Text::lit("") }), digits_p2)), ty: v_p1.clone(), file: this.file.clone(), span: span_p4.clone(), level: this.level.clone() });
    this
}

/// ```prism
/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
/// ```
pub fn infer_text(env_p0: &Env, st_p1: &crate::check::types::St, segs_p2: &Array<crate::syntax::TextSeg>, dollar_p3: &bool, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let holes_p5 = fold(segs_p2, &Array::new(), &(|acc_p6: &Array<crate::syntax::Expr>, sg_p7: &crate::syntax::TextSeg| match sg_p7 {
        crate::syntax::TextSeg::SegPlaceholder(x_p8) => push(acc_p6, x_p8),
        _ => acc_p6.clone(),
    }));
    if &len(&holes_p5) == &Nat::from(0u32) {
        (crate::check::types::t_text(), st_p1.clone())
    } else {
        {
            let (events_p12, dyns_p13, opts_p14, st2_p15, lifted_p16) = run_to_end(fold_job(crate::check::errors::range0(&len(&holes_p5)), (Array::new(), Int::from(0), Array::new(), st_p1.clone(), Array::new()), {
                let holes_p5 = holes_p5.clone();
                let span_p4 = span_p4.clone();
                let env_p0 = env_p0.clone();
                Rc::new(move |(p0, p1): ((Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>), Nat)| {
                    let holes_p5 = holes_p5.clone();
                    let span_p4 = span_p4.clone();
                    let env_p0 = env_p0.clone();
                    entered(once_job(move || {
                        let (ev_pf, dy_pg, op_ph, s_pi, li_pj) = p0;
                        let hi_pk = p1;
                        {
                            let x_pl = or(&index(&holes_p5, &hi_pk), &crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p4.clone() });
                            call_then(start_infer(env_p0.clone(), s_pi.clone(), x_pl.clone()), move |infer_17221: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t_p10, s2_p11) = infer_17221;
                                call_then(crate::check::types::start_head_sigil(s2_p11.clone(), t_p10.clone()), move |head_sigil_17260: Text| {
                                    let head_pm = head_sigil_17260;
                                    let inner_pn = if is_time_sigil(&head_pm) { inner_of(&s2_p11, &t_p10) } else { t_p10.clone() };
                                    call_then(crate::check::types::start_head_sigil(s2_p11.clone(), inner_pn.clone()), move |head_sigil_17364: Text| {
                                        let ih_po = head_sigil_17364;
                                        let plain_t_pp = if is_plain_sigil(&ih_po) { inner_of(&s2_p11, &inner_pn) } else { inner_pn.clone() };
                                        let s3_pq = if &head_pm == &Text::lit("@") {
                                            crate::check::types::recording::err(&s2_p11, &Text::lit("blueprint-operand"), &x_pl.span, &Text::lit("a text over a blueprint; bind it first"))
                                        } else {
                                            s2_p11.clone()
                                        };
                                        call_then(start_show_want(s3_pq.clone(), plain_t_pp.clone(), x_pl.span.clone()), move |show_want_17604: crate::check::types::St| {
                                            let s4_pr = show_want_17604;
                                            let ev2_ps = if &head_pm == &Text::lit("!") { push(&ev_pf, &x_pl.span) } else { ev_pf.clone() };
                                            let dy2_pt = if &head_pm == &Text::lit("$") { &dy_pg + &Int::from(1) } else { dy_pg.clone() };
                                            let op2_pu = if is_plain_sigil(&ih_po) {
                                                crate::check::types::add_text(&op_ph, &ih_po)
                                            } else {
                                                op_ph.clone()
                                            };
                                            let li2_pv = if is_time_sigil(&head_pm) { push(&li_pj, &hi_pk) } else { li_pj.clone() };
                                            prism_rtl::Turn::Finished((ev2_ps.clone(), dy2_pt.clone(), op2_pu.clone(), s4_pr.clone(), li2_pv.clone()))
                                        })
                                    })
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(((Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>)>>>
            }));
            let st3_p9 = if *dollar_p3 && (&len(&events_p12) > &Nat::from(0u32)) {
                crate::check::types::recording::err(&st2_p15, &Text::lit("event-in-text"), &or(&index(&events_p12, &Nat::from(0u32)), span_p4), &Text::lit("an event in a dynamic text"))
            } else {
                if &len(&events_p12) > &Nat::from(1u32) {
                    crate::check::types::recording::err_fix(&st2_p15, &Text::lit("two-events"), &or(&index(&events_p12, &Nat::from(1u32)), span_p4), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first"))
                } else {
                    st2_p15.clone()
                }
            };
            let st4_pa = if &len(&opts_p14) > &Nat::from(1u32) {
                crate::check::types::recording::err(&st3_p9, &Text::lit("optional-and-fault"), span_p4, &Text::lit("`?` and `~` in one operation"))
            } else {
                st3_p9.clone()
            };
            let with_opt_pb = match index(&opts_p14, &Nat::from(0u32)) {
                Some(o_p17) => crate::check::types::Ty::TySig(o_p17, Rc::new(crate::check::types::t_text())),
                None => crate::check::types::t_text(),
            };
            let layer_pc = if (&len(&events_p12) > &Nat::from(0u32)) && !*dollar_p3 {
                Text::lit("!")
            } else {
                if (&dyns_p13 > &Int::from(0)) || *dollar_p3 { Text::lit("$") } else { Text::lit("") }
            };
            let res_pd = if &layer_pc == &Text::lit("") {
                with_opt_pb.clone()
            } else {
                crate::check::types::Ty::TySig(layer_pc.clone(), Rc::new(with_opt_pb.clone()))
            };
            let kind_pe = if &layer_pc == &Text::lit("") {
                Text::lit("plain")
            } else {
                if &len(&lifted_p16) == &Nat::from(0u32) {
                    Text::lit("const")
                } else {
                    Text::lit("map")
                }
            };
            (res_pd.clone(), crate::check::types::recording::note_app(&st4_pa, span_p4, &Text::lit("text"), &kind_pe, &layer_pc, &lifted_p16, &or(&index(&opts_p14, &Nat::from(0u32)), &Text::lit("")), &crate::check::types::Col::CBound))
        }
    }
}

/// The step machine of `InferText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
/// ```
pub struct InferText {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub segs_p2: Array<crate::syntax::TextSeg>,
    pub dollar_p3: bool,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferText {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let segs_p2 = &self.segs_p2;
        let dollar_p3 = &self.dollar_p3;
        let span_p4 = &self.span_p4;
        let holes_p5 = fold(segs_p2, &Array::new(), &(|acc_p6: &Array<crate::syntax::Expr>, sg_p7: &crate::syntax::TextSeg| match sg_p7 {
            crate::syntax::TextSeg::SegPlaceholder(x_p8) => push(acc_p6, x_p8),
            _ => acc_p6.clone(),
        }));
        if &len(&holes_p5) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished((crate::check::types::t_text(), st_p1.clone()))
        } else {
            {
                let dollar_p3 = *dollar_p3;
                let env_p0 = env_p0.clone();
                let span_p4 = span_p4.clone();
                let st_p1 = st_p1.clone();
                call_value(fold_job(crate::check::errors::range0(&len(&holes_p5)), (Array::new(), Int::from(0), Array::new(), st_p1.clone(), Array::new()), {
                    let holes_p5 = holes_p5.clone();
                    let span_p4 = span_p4.clone();
                    let env_p0 = env_p0.clone();
                    Rc::new(move |(p0, p1): ((Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>), Nat)| {
                        let holes_p5 = holes_p5.clone();
                        let span_p4 = span_p4.clone();
                        let env_p0 = env_p0.clone();
                        entered(once_job(move || {
                            let (ev_pf, dy_pg, op_ph, s_pi, li_pj) = p0;
                            let hi_pk = p1;
                            {
                                let x_pl = or(&index(&holes_p5, &hi_pk), &crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p4.clone() });
                                call_then(start_infer(env_p0.clone(), s_pi.clone(), x_pl.clone()), move |infer_17221: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (t_p10, s2_p11) = infer_17221;
                                    call_then(crate::check::types::start_head_sigil(s2_p11.clone(), t_p10.clone()), move |head_sigil_17260: Text| {
                                        let head_pm = head_sigil_17260;
                                        let inner_pn = if is_time_sigil(&head_pm) { inner_of(&s2_p11, &t_p10) } else { t_p10.clone() };
                                        call_then(crate::check::types::start_head_sigil(s2_p11.clone(), inner_pn.clone()), move |head_sigil_17364: Text| {
                                            let ih_po = head_sigil_17364;
                                            let plain_t_pp = if is_plain_sigil(&ih_po) { inner_of(&s2_p11, &inner_pn) } else { inner_pn.clone() };
                                            let s3_pq = if &head_pm == &Text::lit("@") {
                                                crate::check::types::recording::err(&s2_p11, &Text::lit("blueprint-operand"), &x_pl.span, &Text::lit("a text over a blueprint; bind it first"))
                                            } else {
                                                s2_p11.clone()
                                            };
                                            call_then(start_show_want(s3_pq.clone(), plain_t_pp.clone(), x_pl.span.clone()), move |show_want_17604: crate::check::types::St| {
                                                let s4_pr = show_want_17604;
                                                let ev2_ps = if &head_pm == &Text::lit("!") { push(&ev_pf, &x_pl.span) } else { ev_pf.clone() };
                                                let dy2_pt = if &head_pm == &Text::lit("$") { &dy_pg + &Int::from(1) } else { dy_pg.clone() };
                                                let op2_pu = if is_plain_sigil(&ih_po) {
                                                    crate::check::types::add_text(&op_ph, &ih_po)
                                                } else {
                                                    op_ph.clone()
                                                };
                                                let li2_pv = if is_time_sigil(&head_pm) { push(&li_pj, &hi_pk) } else { li_pj.clone() };
                                                prism_rtl::Turn::Finished((ev2_ps.clone(), dy2_pt.clone(), op2_pu.clone(), s4_pr.clone(), li2_pv.clone()))
                                            })
                                        })
                                    })
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>)>>>
                }), move |fold_17045: (Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>)| {
                    let (events_p12, dyns_p13, opts_p14, st2_p15, lifted_p16) = fold_17045;
                    let st3_p9 = if dollar_p3 && (&len(&events_p12) > &Nat::from(0u32)) {
                        crate::check::types::recording::err(&st2_p15, &Text::lit("event-in-text"), &or(&index(&events_p12, &Nat::from(0u32)), &span_p4), &Text::lit("an event in a dynamic text"))
                    } else {
                        if &len(&events_p12) > &Nat::from(1u32) {
                            crate::check::types::recording::err_fix(&st2_p15, &Text::lit("two-events"), &or(&index(&events_p12, &Nat::from(1u32)), &span_p4), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first"))
                        } else {
                            st2_p15.clone()
                        }
                    };
                    let st4_pa = if &len(&opts_p14) > &Nat::from(1u32) {
                        crate::check::types::recording::err(&st3_p9, &Text::lit("optional-and-fault"), &span_p4, &Text::lit("`?` and `~` in one operation"))
                    } else {
                        st3_p9.clone()
                    };
                    let with_opt_pb = match index(&opts_p14, &Nat::from(0u32)) {
                        Some(o_p17) => crate::check::types::Ty::TySig(o_p17, Rc::new(crate::check::types::t_text())),
                        None => crate::check::types::t_text(),
                    };
                    let layer_pc = if (&len(&events_p12) > &Nat::from(0u32)) && !dollar_p3 {
                        Text::lit("!")
                    } else {
                        if (&dyns_p13 > &Int::from(0)) || dollar_p3 { Text::lit("$") } else { Text::lit("") }
                    };
                    let res_pd = if &layer_pc == &Text::lit("") {
                        with_opt_pb.clone()
                    } else {
                        crate::check::types::Ty::TySig(layer_pc.clone(), Rc::new(with_opt_pb.clone()))
                    };
                    let kind_pe = if &layer_pc == &Text::lit("") {
                        Text::lit("plain")
                    } else {
                        if &len(&lifted_p16) == &Nat::from(0u32) {
                            Text::lit("const")
                        } else {
                            Text::lit("map")
                        }
                    };
                    prism_rtl::Turn::Finished((res_pd.clone(), crate::check::types::recording::note_app(&st4_pa, &span_p4, &Text::lit("text"), &kind_pe, &layer_pc, &lifted_p16, &or(&index(&opts_p14, &Nat::from(0u32)), &Text::lit("")), &crate::check::types::Col::CBound)))
                })
            }
        }
    }
}

/// `Start InferText, x`: what the function value is when passed to `@Run`.
pub fn start_infer_text(env_p0: Env, st_p1: crate::check::types::St, segs_p2: Array<crate::syntax::TextSeg>, dollar_p3: bool, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferText { env_p0, st_p1, segs_p2, dollar_p3, span_p4 })
}

/// ```prism
/// ShowWant: unbounded fn St, Ty, Range -> St
/// ```
pub fn show_want(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk(st_p0, t_p1) {
        crate::check::types::Ty::TyCon(m18917_0_0, m18917_0_1) if (&m18917_0_0 == &Text::lit("Text")) && ((&m18917_0_1).len() == 0) => st_p0.clone(),
        other_p3 => add_want(st_p0, &Text::lit("Prelude.Show"), &other_p3, span_p2),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ShowWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowWant: unbounded fn St, Ty, Range -> St
/// ```
pub struct ShowWant {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub span_p2: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for ShowWant {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let span_p2 = &self.span_p2;
        let span_p2 = span_p2.clone();
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), t_p1.clone()), move |walk_18923: crate::check::types::Ty| match walk_18923 {
            crate::check::types::Ty::TyCon(m18917_0_0, m18917_0_1) if (&m18917_0_0 == &Text::lit("Text")) && ((&m18917_0_1).len() == 0) => prism_rtl::Turn::Finished(st_p0.clone()),
            other_p3 => prism_rtl::Turn::Finished(add_want(&st_p0, &Text::lit("Prelude.Show"), &other_p3, &span_p2)),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start ShowWant, x`: what the function value is when passed to `@Run`.
pub fn start_show_want(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty, span_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ShowWant { st_p0, t_p1, span_p2 })
}
