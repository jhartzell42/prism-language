//! The module `Check.Expr`, from `target/bootstrap/src/prismc/check/expr/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod calls;
pub mod lets;
pub mod lifting;
pub mod operators;
pub mod patterns;

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Env {
    pub g: crate::check::env::G,
    pub home: Text,
    pub file: Nat,
    pub src: crate::check::errors::Src,
    pub locals: Map<Text, crate::check::types::Scheme>,
    pub scope: crate::check::types::Rw,
    pub givens: Array<(Text, Text)>,
    pub mark: Text,
    pub in_update: bool,
    pub def_name: Text,
    pub refine: Map<Text, crate::check::types::Ty>,
    pub pending: Array<Text>,
}

impl Show for Env {
    fn show(&self, p: &mut Printer) {
        p.record("Env", &[("g", &self.g), ("home", &self.home), ("file", &self.file), ("src", &self.src), ("locals", &self.locals), ("scope", &self.scope), ("givens", &self.givens), ("mark", &self.mark), ("in_update", &self.in_update), ("def_name", &self.def_name), ("refine", &self.refine), ("pending", &self.pending)]);
    }
}

impl ToPod for Env {
    fn to_pod(&self) -> Pod {
        Pod::record("Env", vec![("g", self.g.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("src", self.src.to_pod()), ("locals", self.locals.to_pod()), ("scope", self.scope.to_pod()), ("givens", self.givens.to_pod()), ("mark", self.mark.to_pod()), ("in_update", self.in_update.to_pod()), ("def_name", self.def_name.to_pod()), ("refine", self.refine.to_pod()), ("pending", self.pending.to_pod())])
    }
}

impl FromPod for Env {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Env { g: FromPod::from_pod(field(p, "g")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, src: FromPod::from_pod(field(p, "src")?)?, locals: FromPod::from_pod(field(p, "locals")?)?, scope: FromPod::from_pod(field(p, "scope")?)?, givens: FromPod::from_pod(field(p, "givens")?)?, mark: FromPod::from_pod(field(p, "mark")?)?, in_update: FromPod::from_pod(field(p, "in_update")?)?, def_name: FromPod::from_pod(field(p, "def_name")?)?, refine: FromPod::from_pod(field(p, "refine")?)?, pending: FromPod::from_pod(field(p, "pending")?)? })
    }
}

/// ```prism
/// WithLocal: fn Env, Text, Scheme -> Env
/// ```
pub fn with_local(env: &Env, name: &Text, sc: &crate::check::types::Scheme) -> Env {
    let mut this: Env = env.clone();
    this.locals = insert(&this.locals, name, sc);
    this
}

/// ```prism
/// SrcText: fn Env, Range -> Text
/// ```
pub fn src_text(env: &Env, r: &crate::syntax::Range) -> Text {
    crate::check::errors::span_text(&env.src, r)
}

/// ```prism
/// IsComparison: fn Text -> Bool
/// ```
pub fn is_comparison(n: &Text) -> bool {
    crate::check::types::has_text(&Array::from(vec![Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">="), Text::lit("Compare"), Text::lit("?"), Text::lit("~"), Text::lit("$")]), n)
}

/// ```prism
/// HasTimeMark: fn Text -> Bool
/// ```
pub fn has_time_mark(marks: &Text) -> bool {
    crate::syntax::lexer::chars::contains(marks, &Text::lit("$")) || crate::syntax::lexer::chars::contains(marks, &Text::lit("!"))
}

/// ```prism
/// IsTimeSigil: fn Text -> Bool
/// ```
pub fn is_time_sigil(s: &Text) -> bool {
    (s == &Text::lit("$")) || (s == &Text::lit("!"))
}

/// ```prism
/// IsPlainSigil: fn Text -> Bool
/// ```
pub fn is_plain_sigil(s: &Text) -> bool {
    (s == &Text::lit("?")) || (s == &Text::lit("~"))
}

/// ```prism
/// InnerOf: unbounded fn St, Ty -> Ty
/// ```
pub fn inner_of(st: &crate::check::types::St, t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TySig(_, i) => (*i).clone(),
        crate::check::types::Ty::TyAt(i, _) => (*i).clone(),
        other => other.clone(),
    }
}

/// The step machine of `InnerOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InnerOf: unbounded fn St, Ty -> Ty
/// ```
pub struct InnerOf {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for InnerOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_3031: crate::check::types::Ty| match walk_3031 {
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::Finished((*i).clone()),
            crate::check::types::Ty::TyAt(i, _) => prism_rtl::Turn::Finished((*i).clone()),
            other => prism_rtl::Turn::Finished(other.clone()),
        })
    }
}

/// `Start InnerOf, x`: what the function value is when passed to `@Run`.
pub fn start_inner_of(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(InnerOf { st, t })
}

/// ```prism
/// IsLambda: fn Expr -> Bool
/// ```
pub fn is_lambda(e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::ELambda(_, _) => true,
        crate::syntax::ExprKind::ETopicField(_) => true,
        crate::syntax::ExprKind::ETopicIndex(_) => true,
        crate::syntax::ExprKind::EGroup(x) => is_lambda(&**x),
        _ => false,
    }
}

/// ```prism
/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub fn infer(env: &Env, st: &crate::check::types::St, e: &crate::syntax::Expr) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t, st2) = infer_kind(env, st, e);
    (t.clone(), crate::check::types::recording::note_ty(&st2, &e.span, &t))
}

/// The step machine of `Infer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub struct Infer {
    pub env: Env,
    pub st: crate::check::types::St,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for Infer {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let e = e.clone();
        let env = env.clone();
        let st = st.clone();
        call_then(start_infer_kind(env.clone(), st.clone(), e.clone()), move |infer_kind_3583: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st2) = infer_kind_3583;
            prism_rtl::Turn::Finished((t.clone(), crate::check::types::recording::note_ty(&st2, &e.span, &t)))
        })
    }
}

/// `Start Infer, x`: what the function value is when passed to `@Run`.
pub fn start_infer(env: Env, st: crate::check::types::St, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(Infer { env, st, e })
}

/// ```prism
/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub fn infer_kind(env: &Env, st: &crate::check::types::St, e: &crate::syntax::Expr) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => infer_name(env, st, n, &e.span),
        crate::syntax::ExprKind::ELit(l) => infer_lit(env, st, l, &false, &e.span),
        crate::syntax::ExprKind::EUnit(marks) => (crate::check::types::with_marks(marks, &crate::check::types::t_unit(), &env.scope), st.clone()),
        crate::syntax::ExprKind::ENil(marks) => {
            let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
            (crate::check::types::with_marks(marks, &crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_.clone())), &env.scope), st2.clone())
        },
        crate::syntax::ExprKind::EBound(b) => infer_bound(env, st, b, &e.span),
        crate::syntax::ExprKind::ETuple(es) => {
            let (ts, st2) = infer_all(env, st, es);
            (crate::check::types::Ty::TyTuple(ts.clone()), st2.clone())
        },
        crate::syntax::ExprKind::EArray(es) => crate::check::expr::operators::infer_array(env, st, es, &e.span),
        crate::syntax::ExprKind::EMap(entries) => crate::check::expr::operators::infer_map(env, st, entries, &e.span),
        crate::syntax::ExprKind::EGroup(x) => infer(env, st, &**x),
        crate::syntax::ExprKind::ECall(callee, args, _, _) => crate::check::expr::calls::infer_call(env, st, &**callee, args, &e.span),
        crate::syntax::ExprKind::EBinary(op, lhs, rhs) => crate::check::expr::operators::infer_binary(env, st, op, &**lhs, &**rhs, &e.span),
        crate::syntax::ExprKind::EUnary(op, x) => crate::check::expr::operators::infer_unary(env, st, op, &**x, &e.span),
        crate::syntax::ExprKind::ESuffixed(_, _, _, _) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement suffixed operators"))),
        crate::syntax::ExprKind::EFreeSigil(s, x) => crate::check::expr::operators::infer_free_sigil(env, st, s, &**x, &e.span),
        crate::syntax::ExprKind::EField(recv, sigils, name) => crate::check::expr::operators::infer_field(env, st, &**recv, sigils, name, &e.span),
        crate::syntax::ExprKind::EIndex(recv, idx) => crate::check::expr::operators::infer_index(env, st, &**recv, &**idx, &e.span),
        crate::syntax::ExprKind::ETopicField(_) => crate::check::expr::calls::infer_lambda(env, st, e, &None),
        crate::syntax::ExprKind::ETopicIndex(_) => crate::check::expr::calls::infer_lambda(env, st, e, &None),
        crate::syntax::ExprKind::EMethod(recv, m, args) => crate::check::expr::calls::infer_call(env, st, &crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(m.clone())), span: m.span.clone() }, &append(&Array::from(vec![crate::syntax::Arg { name: None, value: (**recv).clone(), span: recv.span.clone() }]), args), &e.span),
        crate::syntax::ExprKind::ETypeArgs(target, _) => crate::check::expr::calls::infer_call(env, st, e, &Array::new(), &e.span),
        crate::syntax::ExprKind::ECast(x, ty, checked) => if *checked {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement non-empty arrays")))
        } else {
            {
                let cx_ = env_cx(env);
                let (t, st2) = crate::check::env::reading::conv_type(&cx_, st, ty);
                let st3 = check(env, &st2, &**x, &t);
                (t.clone(), st3.clone())
            }
        },
        crate::syntax::ExprKind::ENonEmpty(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement non-empty arrays"))),
        crate::syntax::ExprKind::EAbsent => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement sparse tuples"))),
        crate::syntax::ExprKind::ERest => (crate::check::types::Ty::TyErr, st.clone()),
        crate::syntax::ExprKind::ELambda(_, _) => crate::check::expr::calls::infer_lambda(env, st, e, &None),
        crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => crate::check::expr::lifting::infer_if(env, st, &**c, then_b, else_b_opt, &e.span, &None),
        crate::syntax::ExprKind::EMatch(scrut, arms) => crate::check::expr::lifting::infer_match(env, st, &**scrut, arms, &e.span, &None),
        crate::syntax::ExprKind::ERebuild(scrut, body) => crate::check::blocks::structure::infer_rebuild(env, st, &**scrut, body, &e.span),
        crate::syntax::ExprKind::EFor(binders_opt, source, body) => crate::check::blocks::structure::infer_for(env, st, binders_opt, &**source, body, &e.span),
        crate::syntax::ExprKind::EGiven(b) => crate::check::blocks::structure::infer_given(env, st, b, &e.span),
        crate::syntax::ExprKind::EUpdate(target, body) => crate::check::blocks::borrows::infer_update(env, st, &**target, body, &e.span),
        crate::syntax::ExprKind::EWidgetBlock(b) => {
            let (t, st2) = crate::check::blocks::infer_widget_block(env, st, b);
            (crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()), st2.clone())
        },
        crate::syntax::ExprKind::EMonad(_, _) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement `T monad:` blocks"))),
        crate::syntax::ExprKind::ETemplate(t) => crate::check::expr::lets::infer_template(env, st, t),
        crate::syntax::ExprKind::EAny(x) => {
            let (t, st2) = infer(env, st, &**x);
            (crate::check::types::Ty::TyAny(Array::new()), st2.clone())
        },
        crate::syntax::ExprKind::ELens(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement named lenses and `Over`"))),
        crate::syntax::ExprKind::EError => (crate::check::types::Ty::TyErr, st.clone()),
    }
}

/// The step machine of `InferKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub struct InferKind {
    pub env: Env,
    pub st: crate::check::types::St,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferKind {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EName(n) => prism_rtl::Turn::More(Rc::new(InferName { env: env.clone(), st: st.clone(), n: n.clone(), span: e.span.clone() })),
            crate::syntax::ExprKind::ELit(l) => prism_rtl::Turn::More(Rc::new(InferLit { env: env.clone(), st: st.clone(), l: l.clone(), negative: false, span: e.span.clone() })),
            crate::syntax::ExprKind::EUnit(marks) => prism_rtl::Turn::Finished((crate::check::types::with_marks(marks, &crate::check::types::t_unit(), &env.scope), st.clone())),
            crate::syntax::ExprKind::ENil(marks) => {
                let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                prism_rtl::Turn::Finished((crate::check::types::with_marks(marks, &crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_.clone())), &env.scope), st2.clone()))
            },
            crate::syntax::ExprKind::EBound(b) => prism_rtl::Turn::Finished(infer_bound(env, st, b, &e.span)),
            crate::syntax::ExprKind::ETuple(es) => {
                let env = env.clone();
                let es = es.clone();
                let st = st.clone();
                call_then(start_infer_all(env.clone(), st.clone(), es.clone()), move |infer_all_4093: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (ts, st2) = infer_all_4093;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyTuple(ts.clone()), st2.clone()))
                })
            },
            crate::syntax::ExprKind::EArray(es) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferArray { env: env.clone(), st: st.clone(), es: es.clone(), span: e.span.clone() })),
            crate::syntax::ExprKind::EMap(entries) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferMap { env: env.clone(), st: st.clone(), entries: entries.clone(), span: e.span.clone() })),
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(Infer { env: env.clone(), st: st.clone(), e: (**x).clone() })),
            crate::syntax::ExprKind::ECall(callee, args, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferCall { env: env.clone(), st: st.clone(), callee: (**callee).clone(), args: args.clone(), span: e.span.clone() })),
            crate::syntax::ExprKind::EBinary(op, lhs, rhs) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferBinary { env: env.clone(), st: st.clone(), op: op.clone(), lhs: (**lhs).clone(), rhs: (**rhs).clone(), span: e.span.clone() })),
            crate::syntax::ExprKind::EUnary(op, x) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferUnary { env: env.clone(), st: st.clone(), op: op.clone(), x: (**x).clone(), span: e.span.clone() })),
            crate::syntax::ExprKind::ESuffixed(_, _, _, _) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement suffixed operators")))),
            crate::syntax::ExprKind::EFreeSigil(s, x) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferFreeSigil { env: env.clone(), st: st.clone(), s: s.clone(), x: (**x).clone(), span: e.span.clone() })),
            crate::syntax::ExprKind::EField(recv, sigils, name) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferField { env: env.clone(), st: st.clone(), recv: (**recv).clone(), sigils: sigils.clone(), name: name.clone(), span: e.span.clone() })),
            crate::syntax::ExprKind::EIndex(recv, idx) => prism_rtl::Turn::More(Rc::new(crate::check::expr::operators::InferIndex { env: env.clone(), st: st.clone(), recv: (**recv).clone(), idx: (**idx).clone(), span: e.span.clone() })),
            crate::syntax::ExprKind::ETopicField(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferLambda { env: env.clone(), st: st.clone(), e: e.clone(), expected_opt: None })),
            crate::syntax::ExprKind::ETopicIndex(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferLambda { env: env.clone(), st: st.clone(), e: e.clone(), expected_opt: None })),
            crate::syntax::ExprKind::EMethod(recv, m, args) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferCall { env: env.clone(), st: st.clone(), callee: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(m.clone())), span: m.span.clone() }, args: append(&Array::from(vec![crate::syntax::Arg { name: None, value: (**recv).clone(), span: recv.span.clone() }]), args), span: e.span.clone() })),
            crate::syntax::ExprKind::ETypeArgs(target, _) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferCall { env: env.clone(), st: st.clone(), callee: e.clone(), args: Array::new(), span: e.span.clone() })),
            crate::syntax::ExprKind::ECast(x, ty, checked) => if *checked {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement non-empty arrays"))))
            } else {
                {
                    let cx_ = env_cx(env);
                    let env = env.clone();
                    let st = st.clone();
                    let ty = ty.clone();
                    let x = (**x).clone();
                    call_then(crate::check::env::reading::start_conv_type(cx_.clone(), st.clone(), ty.clone()), move |conv_type_5346: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t, st2) = conv_type_5346;
                        call_then(start_check(env.clone(), st2.clone(), x.clone(), t.clone()), move |check_5388: crate::check::types::St| {
                            let st3 = check_5388;
                            prism_rtl::Turn::Finished((t.clone(), st3.clone()))
                        })
                    })
                }
            },
            crate::syntax::ExprKind::ENonEmpty(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement non-empty arrays")))),
            crate::syntax::ExprKind::EAbsent => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement sparse tuples")))),
            crate::syntax::ExprKind::ERest => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st.clone())),
            crate::syntax::ExprKind::ELambda(_, _) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferLambda { env: env.clone(), st: st.clone(), e: e.clone(), expected_opt: None })),
            crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lifting::InferIf { env: env.clone(), st: st.clone(), c: (**c).clone(), then_b: then_b.clone(), else_b_opt: else_b_opt.clone(), span: e.span.clone(), expected_opt: None })),
            crate::syntax::ExprKind::EMatch(scrut, arms) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lifting::InferMatch { env: env.clone(), st: st.clone(), scrut: (**scrut).clone(), arms: arms.clone(), span: e.span.clone(), expected_opt: None })),
            crate::syntax::ExprKind::ERebuild(scrut, body) => prism_rtl::Turn::More(Rc::new(crate::check::blocks::structure::InferRebuild { env: env.clone(), st: st.clone(), scrut: (**scrut).clone(), body: body.clone(), span: e.span.clone() })),
            crate::syntax::ExprKind::EFor(binders_opt, source, body) => prism_rtl::Turn::More(Rc::new(crate::check::blocks::structure::InferFor { env: env.clone(), st: st.clone(), binders_opt: binders_opt.clone(), source: (**source).clone(), body: body.clone(), span: e.span.clone() })),
            crate::syntax::ExprKind::EGiven(b) => prism_rtl::Turn::More(Rc::new(crate::check::blocks::structure::InferGiven { env: env.clone(), st: st.clone(), b: b.clone(), span: e.span.clone() })),
            crate::syntax::ExprKind::EUpdate(target, body) => prism_rtl::Turn::More(Rc::new(crate::check::blocks::borrows::InferUpdate { env: env.clone(), st: st.clone(), target: (**target).clone(), body: body.clone(), span: e.span.clone() })),
            crate::syntax::ExprKind::EWidgetBlock(b) => {
                let b = b.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(crate::check::blocks::start_infer_widget_block(env.clone(), st.clone(), b.clone()), move |infer_widget_block_6184: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_widget_block_6184;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()), st2.clone()))
                })
            },
            crate::syntax::ExprKind::EMonad(_, _) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement `T monad:` blocks")))),
            crate::syntax::ExprKind::ETemplate(t) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::InferTemplate { env: env.clone(), st: st.clone(), t: t.clone() })),
            crate::syntax::ExprKind::EAny(x) => {
                let env = env.clone();
                let st = st.clone();
                let x = (**x).clone();
                call_then(start_infer(env.clone(), st.clone(), x.clone()), move |infer_6451: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_6451;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyAny(Array::new()), st2.clone()))
                })
            },
            crate::syntax::ExprKind::ELens(_) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement named lenses and `Over`")))),
            crate::syntax::ExprKind::EError => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st.clone())),
        }
    }
}

/// `Start InferKind, x`: what the function value is when passed to `@Run`.
pub fn start_infer_kind(env: Env, st: crate::check::types::St, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferKind { env, st, e })
}

/// ```prism
/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
/// ```
pub fn infer_all(env: &Env, st: &crate::check::types::St, es: &Array<crate::syntax::Expr>) -> (Array<crate::check::types::Ty>, crate::check::types::St) {
    run_to_end(fold_job(es.clone(), (Array::new(), st.clone()), {
        let env = env.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)| {
            let env = env.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let x = p1;
                call_then(start_infer(env.clone(), s.clone(), x.clone()), move |infer_6784: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, s2) = infer_6784;
                    prism_rtl::Turn::Finished((push(&acc, &t), s2.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }))
}

/// The step machine of `InferAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
/// ```
pub struct InferAll {
    pub env: Env,
    pub st: crate::check::types::St,
    pub es: Array<crate::syntax::Expr>,
}

impl prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)> for InferAll {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check::types::Ty>, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let es = &self.es;
        fold_job(es.clone(), (Array::new(), st.clone()), {
            let env = env.clone();
            Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)| {
                let env = env.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let x = p1;
                    call_then(start_infer(env.clone(), s.clone(), x.clone()), move |infer_6784: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t, s2) = infer_6784;
                        prism_rtl::Turn::Finished((push(&acc, &t), s2.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start InferAll, x`: what the function value is when passed to `@Run`.
pub fn start_infer_all(env: Env, st: crate::check::types::St, es: Array<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>> {
    Rc::new(InferAll { env, st, es })
}

/// ```prism
/// Check: unbounded fn Env, St, Expr, Ty -> St
/// ```
pub fn check(env: &Env, st: &crate::check::types::St, e: &crate::syntax::Expr, expected: &crate::check::types::Ty) -> crate::check::types::St {
    match &*e.kind {
        crate::syntax::ExprKind::ELambda(_, _) => {
            let (t, st2) = crate::check::expr::calls::infer_lambda(env, st, e, &Some(expected.clone()));
            crate::check::types::unify::unify(&crate::check::types::recording::note_ty(&st2, &e.span, &t), expected, &t, &e.span)
        },
        crate::syntax::ExprKind::EGroup(x) => crate::check::types::recording::note_ty(&check(env, st, &**x, expected), &e.span, expected),
        crate::syntax::ExprKind::EMatch(scrut, arms) => {
            let (t, st2) = crate::check::expr::lifting::infer_match(env, st, &**scrut, arms, &e.span, &Some(expected.clone()));
            crate::check::types::unify::unify(&crate::check::types::recording::note_ty(&st2, &e.span, &t), expected, &t, &e.span)
        },
        crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => {
            let (t, st2) = crate::check::expr::lifting::infer_if(env, st, &**c, then_b, else_b_opt, &e.span, &Some(expected.clone()));
            crate::check::types::unify::unify(&crate::check::types::recording::note_ty(&st2, &e.span, &t), expected, &t, &e.span)
        },
        crate::syntax::ExprKind::EAny(x) => crate::check::types::recording::note_ty(&check_any(env, st, &**x, expected, &e.span), &e.span, expected),
        _ => {
            let (t, st2) = infer(env, st, e);
            crate::check::types::unify::unify(&st2, expected, &t, &e.span)
        },
    }
}

/// The step machine of `Check`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Check: unbounded fn Env, St, Expr, Ty -> St
/// ```
pub struct Check {
    pub env: Env,
    pub st: crate::check::types::St,
    pub e: crate::syntax::Expr,
    pub expected: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for Check {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let expected = &self.expected;
        match &*e.kind {
            crate::syntax::ExprKind::ELambda(_, _) => {
                let e = e.clone();
                let env = env.clone();
                let expected = expected.clone();
                let st = st.clone();
                call_then(crate::check::expr::calls::start_infer_lambda(env.clone(), st.clone(), e.clone(), Some(expected.clone())), move |infer_lambda_7093: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_lambda_7093;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: crate::check::types::recording::note_ty(&st2, &e.span, &t), expected: expected.clone(), found: t.clone(), span: e.span.clone() }))
                })
            },
            crate::syntax::ExprKind::EGroup(x) => {
                let e = e.clone();
                let env = env.clone();
                let expected = expected.clone();
                let st = st.clone();
                let x = (**x).clone();
                call_then(start_check(env.clone(), st.clone(), x.clone(), expected.clone()), move |check_7211: crate::check::types::St| prism_rtl::Turn::Finished(crate::check::types::recording::note_ty(&check_7211, &e.span, &expected)))
            },
            crate::syntax::ExprKind::EMatch(scrut, arms) => {
                let arms = arms.clone();
                let e = e.clone();
                let env = env.clone();
                let expected = expected.clone();
                let scrut = (**scrut).clone();
                let st = st.clone();
                call_then(crate::check::expr::lifting::start_infer_match(env.clone(), st.clone(), scrut.clone(), arms.clone(), e.span.clone(), Some(expected.clone())), move |infer_match_7306: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_match_7306;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: crate::check::types::recording::note_ty(&st2, &e.span, &t), expected: expected.clone(), found: t.clone(), span: e.span.clone() }))
                })
            },
            crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => {
                let else_b_opt = else_b_opt.clone();
                let c = (**c).clone();
                let e = e.clone();
                let env = env.clone();
                let expected = expected.clone();
                let st = st.clone();
                let then_b = then_b.clone();
                call_then(crate::check::expr::lifting::start_infer_if(env.clone(), st.clone(), c.clone(), then_b.clone(), else_b_opt.clone(), e.span.clone(), Some(expected.clone())), move |infer_if_7470: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_if_7470;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: crate::check::types::recording::note_ty(&st2, &e.span, &t), expected: expected.clone(), found: t.clone(), span: e.span.clone() }))
                })
            },
            crate::syntax::ExprKind::EAny(x) => {
                let e = e.clone();
                let env = env.clone();
                let expected = expected.clone();
                let st = st.clone();
                let x = (**x).clone();
                call_then(start_check_any(env.clone(), st.clone(), x.clone(), expected.clone(), e.span.clone()), move |check_any_7605: crate::check::types::St| prism_rtl::Turn::Finished(crate::check::types::recording::note_ty(&check_any_7605, &e.span, &expected)))
            },
            _ => {
                let e = e.clone();
                let env = env.clone();
                let expected = expected.clone();
                let st = st.clone();
                call_then(start_infer(env.clone(), st.clone(), e.clone()), move |infer_7702: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_7702;
                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st2.clone(), expected: expected.clone(), found: t.clone(), span: e.span.clone() }))
                })
            },
        }
    }
}

/// `Start Check, x`: what the function value is when passed to `@Run`.
pub fn start_check(env: Env, st: crate::check::types::St, e: crate::syntax::Expr, expected: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Check { env, st, e, expected })
}

/// ```prism
/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
/// ```
pub fn check_any(env: &Env, st: &crate::check::types::St, x: &crate::syntax::Expr, expected: &crate::check::types::Ty, span: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk(st, expected) {
        crate::check::types::Ty::TyAny(trs) => {
            let (t, st2) = infer(env, st, x);
            fold(&trs, &st2, &(|s: &crate::check::types::St, tr: &Text| add_want(s, tr, &t, span)))
        },
        other => {
            let (t, st2) = infer(env, st, x);
            crate::check::types::unify::unify(&st2, &other, &crate::check::types::Ty::TyAny(Array::new()), span)
        },
    }
}

/// The step machine of `CheckAny`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
/// ```
pub struct CheckAny {
    pub env: Env,
    pub st: crate::check::types::St,
    pub x: crate::syntax::Expr,
    pub expected: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for CheckAny {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let x = &self.x;
        let expected = &self.expected;
        let span = &self.span;
        let env = env.clone();
        let expected = expected.clone();
        let span = span.clone();
        let st = st.clone();
        let x = x.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), expected.clone()), move |walk_7950: crate::check::types::Ty| match walk_7950 {
            crate::check::types::Ty::TyAny(trs) => call_then(start_infer(env.clone(), st.clone(), x.clone()), move |infer_8009: (crate::check::types::Ty, crate::check::types::St)| {
                let (t, st2) = infer_8009;
                prism_rtl::Turn::Finished(fold(&trs, &st2, &(|s: &crate::check::types::St, tr: &Text| add_want(s, tr, &t, &span))))
            }),
            other => call_then(start_infer(env.clone(), st.clone(), x.clone()), move |infer_8117: (crate::check::types::Ty, crate::check::types::St)| {
                let (t, st2) = infer_8117;
                prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st2.clone(), expected: other.clone(), found: crate::check::types::Ty::TyAny(Array::new()), span: span.clone() }))
            }),
        })
    }
}

/// `Start CheckAny, x`: what the function value is when passed to `@Run`.
pub fn start_check_any(env: Env, st: crate::check::types::St, x: crate::syntax::Expr, expected: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckAny { env, st, x, expected, span })
}

/// ```prism
/// AddWant: fn St, Text, Ty, Range -> St
/// ```
pub fn add_want(st: &crate::check::types::St, cls: &Text, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st.clone();
    this.wants = push(&this.wants, &crate::check::types::Want { cls: cls.clone(), ty: t.clone(), file: this.file.clone(), span: span.clone(), level: this.level.clone() });
    this
}

/// ```prism
/// EnvCx: fn Env -> Cx
/// ```
pub fn env_cx(env: &Env) -> crate::check::env::reading::Cx_ {
    let base = crate::check::env::reading::cx_of(&env.g, &env.home);
    let mut this: crate::check::env::reading::Cx_ = base.clone();
    this.scope = env.scope.clone();
    this
}

/// ```prism
/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_name(env: &Env, st: &crate::check::types::St, n: &crate::syntax::SName, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let local = crate::check::env::sname_key(n);
    if env.in_update && has_time_mark(&n.sigils) {
        (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(st, &Text::lit("time-in-update"), span, &Text::from(format!("`{}` in an `update` block", &local)), &Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function")))
    } else {
        infer_name_in(env, st, n, span)
    }
}

/// The step machine of `InferName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferName {
    pub env: Env,
    pub st: crate::check::types::St,
    pub n: crate::syntax::SName,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferName {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let span = &self.span;
        let local = crate::check::env::sname_key(n);
        if env.in_update && has_time_mark(&n.sigils) {
            prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(st, &Text::lit("time-in-update"), span, &Text::from(format!("`{}` in an `update` block", &local)), &Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function"))))
        } else {
            prism_rtl::Turn::More(Rc::new(InferNameIn { env: env.clone(), st: st.clone(), n: n.clone(), span: span.clone() }))
        }
    }
}

/// `Start InferName, x`: what the function value is when passed to `@Run`.
pub fn start_infer_name(env: Env, st: crate::check::types::St, n: crate::syntax::SName, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferName { env, st, n, span })
}

/// ```prism
/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_name_in(env: &Env, st: &crate::check::types::St, n: &crate::syntax::SName, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let local = crate::check::env::sname_key(n);
    match get(&env.locals, &local) {
        Some(sc) => instantiate_local(st, &sc, span, &local),
        None => infer_global(env, st, n, span),
    }
}

/// The step machine of `InferNameIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferNameIn {
    pub env: Env,
    pub st: crate::check::types::St,
    pub n: crate::syntax::SName,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferNameIn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let span = &self.span;
        let local = crate::check::env::sname_key(n);
        match get(&env.locals, &local) {
            Some(sc) => prism_rtl::Turn::More(Rc::new(InstantiateLocal { st: st.clone(), sc: sc.clone(), span: span.clone(), name: local.clone() })),
            None => prism_rtl::Turn::More(Rc::new(InferGlobal { env: env.clone(), st0: st.clone(), n: n.clone(), span: span.clone() })),
        }
    }
}

/// `Start InferNameIn, x`: what the function value is when passed to `@Run`.
pub fn start_infer_name_in(env: Env, st: crate::check::types::St, n: crate::syntax::SName, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferNameIn { env, st, n, span })
}

/// ```prism
/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
/// ```
pub fn instantiate_local(st: &crate::check::types::St, sc: &crate::check::types::Scheme, span: &crate::syntax::Range, name: &Text) -> (crate::check::types::Ty, crate::check::types::St) {
    if (&len(&sc.qs) == &Nat::from(0u32)) && (&len(&sc.cqs) == &Nat::from(0u32)) {
        crate::check::types::schemes::instantiate(st, sc, span)
    } else {
        {
            let (t, st2, inst) = crate::check::types::schemes::instantiate_with(st, sc, span, &Array::new());
            (t.clone(), crate::check::types::recording::note_inst(&st2, span, name, sc, &inst))
        }
    }
}

/// The step machine of `InstantiateLocal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
/// ```
pub struct InstantiateLocal {
    pub st: crate::check::types::St,
    pub sc: crate::check::types::Scheme,
    pub span: crate::syntax::Range,
    pub name: Text,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InstantiateLocal {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st = &self.st;
        let sc = &self.sc;
        let span = &self.span;
        let name = &self.name;
        if (&len(&sc.qs) == &Nat::from(0u32)) && (&len(&sc.cqs) == &Nat::from(0u32)) {
            prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::Instantiate { st: st.clone(), sc: sc.clone(), span: span.clone() }))
        } else {
            {
                let name = name.clone();
                let sc = sc.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(crate::check::types::schemes::start_instantiate_with(st.clone(), sc.clone(), span.clone(), Array::new()), move |instantiate_with_9634: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                    let (t, st2, inst) = instantiate_with_9634;
                    prism_rtl::Turn::Finished((t.clone(), crate::check::types::recording::note_inst(&st2, &span, &name, &sc, &inst)))
                })
            }
        }
    }
}

/// `Start InstantiateLocal, x`: what the function value is when passed to `@Run`.
pub fn start_instantiate_local(st: crate::check::types::St, sc: crate::check::types::Scheme, span: crate::syntax::Range, name: Text) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InstantiateLocal { st, sc, span, name })
}

/// ```prism
/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_global(env: &Env, st0: &crate::check::types::St, n: &crate::syntax::SName, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (qk_opt, why) = crate::check::env::names::resolve_value(&env.g, &env.home, n);
    let st = collision_at(env, st0, &why, &crate::check::env::sname_key(n), span);
    match &qk_opt {
        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("unknown-name"), span, &Text::from(format!("nothing declares `{}` here", &crate::check::env::sname_key(n))))),
        Some(qk) => if &why == &Text::lit("tag") {
            tag_value(env, &st, qk, span)
        } else {
            if crate::check::expr::calls::is_local_maker(qk) && !env.in_update {
                (crate::check::types::Ty::TyErr, crate::check::expr::calls::local_outside(&st, qk, span))
            } else {
                match get(&env.g.vals, qk) {
                    Some(v_) => crate::check::types::schemes::instantiate(&crate::check::expr::calls::note_method_use(&st, &v_, span), &v_.scheme, span),
                    None => match get(&env.g.ctors, qk) {
                        Some(c) => ctor_value(env, &st, &c, span),
                        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("unknown-name"), span, &Text::from(format!("`{}` has no signature line or type", &crate::check::env::sname_key(n))))),
                    },
                }
            }
        },
    }
}

/// The step machine of `InferGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferGlobal {
    pub env: Env,
    pub st0: crate::check::types::St,
    pub n: crate::syntax::SName,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferGlobal {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st0 = &self.st0;
        let n = &self.n;
        let span = &self.span;
        let (qk_opt, why) = crate::check::env::names::resolve_value(&env.g, &env.home, n);
        let st = collision_at(env, st0, &why, &crate::check::env::sname_key(n), span);
        match &qk_opt {
            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("unknown-name"), span, &Text::from(format!("nothing declares `{}` here", &crate::check::env::sname_key(n)))))),
            Some(qk) => if &why == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(TagValue { env: env.clone(), st: st.clone(), name: qk.clone(), span: span.clone() }))
            } else {
                if crate::check::expr::calls::is_local_maker(qk) && !env.in_update {
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::expr::calls::local_outside(&st, qk, span)))
                } else {
                    match get(&env.g.vals, qk) {
                        Some(v_) => prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::Instantiate { st: crate::check::expr::calls::note_method_use(&st, &v_, span), sc: v_.scheme.clone(), span: span.clone() })),
                        None => match get(&env.g.ctors, qk) {
                            Some(c) => prism_rtl::Turn::More(Rc::new(CtorValue { env: env.clone(), st: st.clone(), c: c.clone(), span: span.clone() })),
                            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("unknown-name"), span, &Text::from(format!("`{}` has no signature line or type", &crate::check::env::sname_key(n)))))),
                        },
                    }
                }
            },
        }
    }
}

/// `Start InferGlobal, x`: what the function value is when passed to `@Run`.
pub fn start_infer_global(env: Env, st0: crate::check::types::St, n: crate::syntax::SName, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferGlobal { env, st0, n, span })
}

/// ```prism
/// CollisionAt: fn Env, St, Text, Text, Range -> St
/// ```
pub fn collision_at(env: &Env, st: &crate::check::types::St, why: &Text, name: &Text, span: &crate::syntax::Range) -> crate::check::types::St {
    if why != &Text::lit("collision") {
        st.clone()
    } else {
        {
            let keys_ = or(&get(&or(&get(&env.g.bare, &env.home), &Map::new()), name), &Array::new());
            let others = filter(&keys_, &(|k: &Text| crate::syntax::lexer::chars::contains(k, &Text::lit("."))));
            crate::check::types::recording::err_fix(st, &Text::lit("collision"), span, &Text::from(format!("`{}` is declared by more than one module this file reaches by a bare name: {}", name, &crate::syntax::lexer::chars::join(&each(&keys_, &(|k: &Text| Text::from(format!("`{}`", k)))), &Text::lit(", ")))), &Text::from(format!("write the one meant qualified, as `{}`, or rename this file's own", &or(&index(&others, &Nat::from(0u32)), name))))
        }
    }
}

/// ```prism
/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
/// ```
pub fn ctor_value(env: &Env, st: &crate::check::types::St, c: &crate::check::env::CtorInfo, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let sc = crate::check::types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: if &len(&c.args) == &Nat::from(0u32) {
        c.ty.clone()
    } else {
        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, c.args.clone(), Rc::new(c.ty.clone()))
    } };
    crate::check::types::schemes::instantiate(st, &sc, span)
}

/// The step machine of `CtorValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
/// ```
pub struct CtorValue {
    pub env: Env,
    pub st: crate::check::types::St,
    pub c: crate::check::env::CtorInfo,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for CtorValue {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let span = &self.span;
        let sc = crate::check::types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: if &len(&c.args) == &Nat::from(0u32) {
            c.ty.clone()
        } else {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, c.args.clone(), Rc::new(c.ty.clone()))
        } };
        prism_rtl::Turn::More(Rc::new(crate::check::types::schemes::Instantiate { st: st.clone(), sc: sc.clone(), span: span.clone() }))
    }
}

/// `Start CtorValue, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_value(env: Env, st: crate::check::types::St, c: crate::check::env::CtorInfo, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(CtorValue { env, st, c, span })
}

/// ```prism
/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub fn tag_value(env: &Env, st: &crate::check::types::St, name: &Text, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match get(&env.g.tags, name) {
        None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unknown-name"), span, &Text::from(format!("no tag `{}`", name)))),
        Some(tg) => if &tg.kind == &Text::lit("Element") {
            {
                let (rw, st2) = crate::check::types::recording::fresh_row(st, &Array::from(vec![tg.family.clone()]));
                let erow = crate::check::types::Rw { fams: Array::from(vec![tg.family.clone()]), minus: Array::new(), tail: rw.tail.clone() };
                let (out, st3) = crate::check::types::schemes::instantiate(&st2, &crate::check::types::Scheme { qs: tg.qs.clone(), plain_qs: Array::new(), rqs: tg.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: tg.bounds.clone(), ty: tg.out.clone() }, span);
                (crate::check::types::Ty::TyElem(erow.clone(), Rc::new(out.clone())), st3.clone())
            }
        } else {
            (crate::check::types::Ty::TyCon(tg.kind.clone(), Array::new()), st.clone())
        },
    }
}

/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub struct TagValue {
    pub env: Env,
    pub st: crate::check::types::St,
    pub name: Text,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for TagValue {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let name = &self.name;
        let span = &self.span;
        match get(&env.g.tags, name) {
            None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unknown-name"), span, &Text::from(format!("no tag `{}`", name))))),
            Some(tg) => if &tg.kind == &Text::lit("Element") {
                {
                    let (rw, st2) = crate::check::types::recording::fresh_row(st, &Array::from(vec![tg.family.clone()]));
                    let erow = crate::check::types::Rw { fams: Array::from(vec![tg.family.clone()]), minus: Array::new(), tail: rw.tail.clone() };
                    let span = span.clone();
                    call_then(crate::check::types::schemes::start_instantiate(st2.clone(), crate::check::types::Scheme { qs: tg.qs.clone(), plain_qs: Array::new(), rqs: tg.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: tg.bounds.clone(), ty: tg.out.clone() }, span.clone()), move |instantiate_12144: (crate::check::types::Ty, crate::check::types::St)| {
                        let (out, st3) = instantiate_12144;
                        prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(erow.clone(), Rc::new(out.clone())), st3.clone()))
                    })
                }
            } else {
                prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(tg.kind.clone(), Array::new()), st.clone()))
            },
        }
    }
}

/// `Start TagValue, x`: what the function value is when passed to `@Run`.
pub fn start_tag_value(env: Env, st: crate::check::types::St, name: Text, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(TagValue { env, st, name, span })
}

/// ```prism
/// InferBound: fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub fn infer_bound(env: &Env, st: &crate::check::types::St, b: &Text, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match get(&env.locals, b) {
        Some(sc) => (sc.ty.clone(), st.clone()),
        None => if b == &Text::lit("key") {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("unknown-name"), span, &Text::lit("`key` is bound only in a loop over a map")))
        } else {
            (crate::check::types::t_nat(), st.clone())
        },
    }
}

/// ```prism
/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
/// ```
pub fn infer_lit(env: &Env, st: &crate::check::types::St, l: &crate::syntax::Literal, negative: &bool, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let sigils = crate::syntax::lexer::chars::fold_chars(&l.marks, &Text::lit(""), &(Rc::new(move |(p0, p1): (Text, Text)| once_job(move || {
        let acc = p0;
        let c = p1;
        if crate::check::types::unify::is_mark_char(&c) {
            prism_rtl::Turn::Finished(Text::from(format!("{}{}", &acc, &c)))
        } else {
            prism_rtl::Turn::Finished(acc.clone())
        }
    })) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>));
    let signed = *negative || crate::syntax::lexer::chars::contains(&l.marks, &Text::lit("-"));
    let (base, st2) = match &l.kind {
        crate::syntax::LitKind::LInt(digits) => {
            let (v_, s1) = crate::check::types::fresh_var(st, &true, &Text::lit(""));
            let s2 = add_want(&s1, &Text::lit("Prelude.Num"), &v_, span);
            let s3 = if signed {
                add_want(&s2, &Text::lit("Prelude.Signed"), &v_, span)
            } else {
                s2.clone()
            };
            let s4 = add_range(&s3, &v_, digits, &signed, span);
            (v_.clone(), s4.clone())
        },
        crate::syntax::LitKind::LFloat(_) => (crate::check::types::t_float(), st.clone()),
        crate::syntax::LitKind::LDuration(_, _) => (crate::check::types::Ty::TyCon(Text::lit("Duration"), Array::new()), st.clone()),
        crate::syntax::LitKind::LChar(_) => (crate::check::types::t_char(), st.clone()),
        crate::syntax::LitKind::LText(segs) => infer_text(env, st, segs, &crate::syntax::lexer::chars::contains(&sigils, &Text::lit("$")), span),
    };
    if crate::syntax::lexer::chars::contains(&sigils, &Text::lit("$")) && (&crate::check::types::head_sigil(&st2, &base) == &Text::lit("$")) {
        (base.clone(), st2.clone())
    } else {
        if crate::syntax::lexer::chars::contains(&sigils, &Text::lit("$")) {
            (crate::check::types::with_marks(&sigils, &base, &env.scope), crate::check::types::recording::note_app(&st2, span, &Text::lit("$"), &Text::lit("const"), &Text::lit("$"), &Array::new(), &Text::lit(""), &crate::check::types::Col::CBound))
        } else {
            (crate::check::types::with_marks(&sigils, &base, &env.scope), st2.clone())
        }
    }
}

/// The step machine of `InferLit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
/// ```
pub struct InferLit {
    pub env: Env,
    pub st: crate::check::types::St,
    pub l: crate::syntax::Literal,
    pub negative: bool,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferLit {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let l = &self.l;
        let negative = &self.negative;
        let span = &self.span;
        let env = env.clone();
        let l = l.clone();
        let negative = *negative;
        let span = span.clone();
        let st = st.clone();
        call_value(crate::syntax::lexer::chars::start_fold_chars(l.marks.clone(), Text::lit(""), Rc::new(move |(p0, p1): (Text, Text)| once_job(move || {
            let acc = p0;
            let c = p1;
            if crate::check::types::unify::is_mark_char(&c) {
                prism_rtl::Turn::Finished(Text::from(format!("{}{}", &acc, &c)))
            } else {
                prism_rtl::Turn::Finished(acc.clone())
            }
        })) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>), move |fold_chars_13117: Text| {
            let sigils = fold_chars_13117;
            let signed = negative || crate::syntax::lexer::chars::contains(&l.marks, &Text::lit("-"));
            let (base, st2) = match &l.kind {
                crate::syntax::LitKind::LInt(digits) => {
                    let (v_, s1) = crate::check::types::fresh_var(&st, &true, &Text::lit(""));
                    let s2 = add_want(&s1, &Text::lit("Prelude.Num"), &v_, &span);
                    let s3 = if signed {
                        add_want(&s2, &Text::lit("Prelude.Signed"), &v_, &span)
                    } else {
                        s2.clone()
                    };
                    let s4 = add_range(&s3, &v_, digits, &signed, &span);
                    (v_.clone(), s4.clone())
                },
                crate::syntax::LitKind::LFloat(_) => (crate::check::types::t_float(), st.clone()),
                crate::syntax::LitKind::LDuration(_, _) => (crate::check::types::Ty::TyCon(Text::lit("Duration"), Array::new()), st.clone()),
                crate::syntax::LitKind::LChar(_) => (crate::check::types::t_char(), st.clone()),
                crate::syntax::LitKind::LText(segs) => infer_text(&env, &st, segs, &crate::syntax::lexer::chars::contains(&sigils, &Text::lit("$")), &span),
            };
            if crate::syntax::lexer::chars::contains(&sigils, &Text::lit("$")) && (&crate::check::types::head_sigil(&st2, &base) == &Text::lit("$")) {
                prism_rtl::Turn::Finished((base.clone(), st2.clone()))
            } else {
                if crate::syntax::lexer::chars::contains(&sigils, &Text::lit("$")) {
                    prism_rtl::Turn::Finished((crate::check::types::with_marks(&sigils, &base, &env.scope), crate::check::types::recording::note_app(&st2, &span, &Text::lit("$"), &Text::lit("const"), &Text::lit("$"), &Array::new(), &Text::lit(""), &crate::check::types::Col::CBound)))
                } else {
                    prism_rtl::Turn::Finished((crate::check::types::with_marks(&sigils, &base, &env.scope), st2.clone()))
                }
            }
        })
    }
}

/// `Start InferLit, x`: what the function value is when passed to `@Run`.
pub fn start_infer_lit(env: Env, st: crate::check::types::St, l: crate::syntax::Literal, negative: bool, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferLit { env, st, l, negative, span })
}

/// ```prism
/// AddRange: fn St, Ty, Text, Bool, Range -> St
/// ```
pub fn add_range(st: &crate::check::types::St, v_: &crate::check::types::Ty, digits: &Text, signed: &bool, span: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st.clone();
    this.wants = push(&this.wants, &crate::check::types::Want { cls: Text::from(format!("Range {}{}", &(if *signed { Text::lit("-") } else { Text::lit("") }), digits)), ty: v_.clone(), file: this.file.clone(), span: span.clone(), level: this.level.clone() });
    this
}

/// ```prism
/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
/// ```
pub fn infer_text(env: &Env, st: &crate::check::types::St, segs: &Array<crate::syntax::TextSeg>, dollar: &bool, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let holes = fold(segs, &Array::new(), &(|acc: &Array<crate::syntax::Expr>, sg: &crate::syntax::TextSeg| match sg {
        crate::syntax::TextSeg::SegPlaceholder(x) => push(acc, x),
        _ => acc.clone(),
    }));
    if &len(&holes) == &Nat::from(0u32) {
        (crate::check::types::t_text(), st.clone())
    } else {
        {
            let (events, dyns, opts, st2, lifted) = run_to_end(fold_job(crate::check::errors::range0(&len(&holes)), (Array::new(), Int::from(0), Array::new(), st.clone(), Array::new()), {
                let holes = holes.clone();
                let span = span.clone();
                let env = env.clone();
                Rc::new(move |(p0, p1): ((Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>), Nat)| {
                    let holes = holes.clone();
                    let span = span.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let (ev, dy, op, s, li) = p0;
                        let hi = p1;
                        {
                            let x = or(&index(&holes, &hi), &crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() });
                            call_then(start_infer(env.clone(), s.clone(), x.clone()), move |infer_15067: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t, s2) = infer_15067;
                                call_then(crate::check::types::start_head_sigil(s2.clone(), t.clone()), move |head_sigil_15106: Text| {
                                    let head = head_sigil_15106;
                                    let inner = if is_time_sigil(&head) { inner_of(&s2, &t) } else { t.clone() };
                                    call_then(crate::check::types::start_head_sigil(s2.clone(), inner.clone()), move |head_sigil_15210: Text| {
                                        let ih = head_sigil_15210;
                                        let plain_t = if is_plain_sigil(&ih) { inner_of(&s2, &inner) } else { inner.clone() };
                                        let s3 = if &head == &Text::lit("@") {
                                            crate::check::types::recording::err(&s2, &Text::lit("blueprint-operand"), &x.span, &Text::lit("a text over a blueprint; bind it first"))
                                        } else {
                                            s2.clone()
                                        };
                                        call_then(start_show_want(s3.clone(), plain_t.clone(), x.span.clone()), move |show_want_15450: crate::check::types::St| {
                                            let s4 = show_want_15450;
                                            let ev2 = if &head == &Text::lit("!") { push(&ev, &x.span) } else { ev.clone() };
                                            let dy2 = if &head == &Text::lit("$") { &dy + &Int::from(1) } else { dy.clone() };
                                            let op2 = if is_plain_sigil(&ih) { crate::check::types::add_text(&op, &ih) } else { op.clone() };
                                            let li2 = if is_time_sigil(&head) { push(&li, &hi) } else { li.clone() };
                                            prism_rtl::Turn::Finished((ev2.clone(), dy2.clone(), op2.clone(), s4.clone(), li2.clone()))
                                        })
                                    })
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(((Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>)>>>
            }));
            let st3 = if *dollar && (&len(&events) > &Nat::from(0u32)) {
                crate::check::types::recording::err(&st2, &Text::lit("event-in-text"), &or(&index(&events, &Nat::from(0u32)), span), &Text::lit("an event in a dynamic text"))
            } else {
                if &len(&events) > &Nat::from(1u32) {
                    crate::check::types::recording::err_fix(&st2, &Text::lit("two-events"), &or(&index(&events, &Nat::from(1u32)), span), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first"))
                } else {
                    st2.clone()
                }
            };
            let st4 = if &len(&opts) > &Nat::from(1u32) {
                crate::check::types::recording::err(&st3, &Text::lit("optional-and-fault"), span, &Text::lit("`?` and `~` in one operation"))
            } else {
                st3.clone()
            };
            let with_opt = match index(&opts, &Nat::from(0u32)) {
                Some(o) => crate::check::types::Ty::TySig(o.clone(), Rc::new(crate::check::types::t_text())),
                None => crate::check::types::t_text(),
            };
            let layer = if (&len(&events) > &Nat::from(0u32)) && !*dollar {
                Text::lit("!")
            } else {
                if (&dyns > &Int::from(0)) || *dollar { Text::lit("$") } else { Text::lit("") }
            };
            let res = if &layer == &Text::lit("") {
                with_opt.clone()
            } else {
                crate::check::types::Ty::TySig(layer.clone(), Rc::new(with_opt.clone()))
            };
            let kind = if &layer == &Text::lit("") {
                Text::lit("plain")
            } else {
                if &len(&lifted) == &Nat::from(0u32) { Text::lit("const") } else { Text::lit("map") }
            };
            (res.clone(), crate::check::types::recording::note_app(&st4, span, &Text::lit("text"), &kind, &layer, &lifted, &or(&index(&opts, &Nat::from(0u32)), &Text::lit("")), &crate::check::types::Col::CBound))
        }
    }
}

/// The step machine of `InferText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
/// ```
pub struct InferText {
    pub env: Env,
    pub st: crate::check::types::St,
    pub segs: Array<crate::syntax::TextSeg>,
    pub dollar: bool,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferText {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let segs = &self.segs;
        let dollar = &self.dollar;
        let span = &self.span;
        let holes = fold(segs, &Array::new(), &(|acc: &Array<crate::syntax::Expr>, sg: &crate::syntax::TextSeg| match sg {
            crate::syntax::TextSeg::SegPlaceholder(x) => push(acc, x),
            _ => acc.clone(),
        }));
        if &len(&holes) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished((crate::check::types::t_text(), st.clone()))
        } else {
            {
                let dollar = *dollar;
                let env = env.clone();
                let span = span.clone();
                let st = st.clone();
                call_value(fold_job(crate::check::errors::range0(&len(&holes)), (Array::new(), Int::from(0), Array::new(), st.clone(), Array::new()), {
                    let holes = holes.clone();
                    let span = span.clone();
                    let env = env.clone();
                    Rc::new(move |(p0, p1): ((Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>), Nat)| {
                        let holes = holes.clone();
                        let span = span.clone();
                        let env = env.clone();
                        entered(once_job(move || {
                            let (ev, dy, op, s, li) = p0;
                            let hi = p1;
                            {
                                let x = or(&index(&holes, &hi), &crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() });
                                call_then(start_infer(env.clone(), s.clone(), x.clone()), move |infer_15067: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (t, s2) = infer_15067;
                                    call_then(crate::check::types::start_head_sigil(s2.clone(), t.clone()), move |head_sigil_15106: Text| {
                                        let head = head_sigil_15106;
                                        let inner = if is_time_sigil(&head) { inner_of(&s2, &t) } else { t.clone() };
                                        call_then(crate::check::types::start_head_sigil(s2.clone(), inner.clone()), move |head_sigil_15210: Text| {
                                            let ih = head_sigil_15210;
                                            let plain_t = if is_plain_sigil(&ih) { inner_of(&s2, &inner) } else { inner.clone() };
                                            let s3 = if &head == &Text::lit("@") {
                                                crate::check::types::recording::err(&s2, &Text::lit("blueprint-operand"), &x.span, &Text::lit("a text over a blueprint; bind it first"))
                                            } else {
                                                s2.clone()
                                            };
                                            call_then(start_show_want(s3.clone(), plain_t.clone(), x.span.clone()), move |show_want_15450: crate::check::types::St| {
                                                let s4 = show_want_15450;
                                                let ev2 = if &head == &Text::lit("!") { push(&ev, &x.span) } else { ev.clone() };
                                                let dy2 = if &head == &Text::lit("$") { &dy + &Int::from(1) } else { dy.clone() };
                                                let op2 = if is_plain_sigil(&ih) { crate::check::types::add_text(&op, &ih) } else { op.clone() };
                                                let li2 = if is_time_sigil(&head) { push(&li, &hi) } else { li.clone() };
                                                prism_rtl::Turn::Finished((ev2.clone(), dy2.clone(), op2.clone(), s4.clone(), li2.clone()))
                                            })
                                        })
                                    })
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>)>>>
                }), move |fold_14891: (Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>)| {
                    let (events, dyns, opts, st2, lifted) = fold_14891;
                    let st3 = if dollar && (&len(&events) > &Nat::from(0u32)) {
                        crate::check::types::recording::err(&st2, &Text::lit("event-in-text"), &or(&index(&events, &Nat::from(0u32)), &span), &Text::lit("an event in a dynamic text"))
                    } else {
                        if &len(&events) > &Nat::from(1u32) {
                            crate::check::types::recording::err_fix(&st2, &Text::lit("two-events"), &or(&index(&events, &Nat::from(1u32)), &span), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first"))
                        } else {
                            st2.clone()
                        }
                    };
                    let st4 = if &len(&opts) > &Nat::from(1u32) {
                        crate::check::types::recording::err(&st3, &Text::lit("optional-and-fault"), &span, &Text::lit("`?` and `~` in one operation"))
                    } else {
                        st3.clone()
                    };
                    let with_opt = match index(&opts, &Nat::from(0u32)) {
                        Some(o) => crate::check::types::Ty::TySig(o.clone(), Rc::new(crate::check::types::t_text())),
                        None => crate::check::types::t_text(),
                    };
                    let layer = if (&len(&events) > &Nat::from(0u32)) && !dollar {
                        Text::lit("!")
                    } else {
                        if (&dyns > &Int::from(0)) || dollar { Text::lit("$") } else { Text::lit("") }
                    };
                    let res = if &layer == &Text::lit("") {
                        with_opt.clone()
                    } else {
                        crate::check::types::Ty::TySig(layer.clone(), Rc::new(with_opt.clone()))
                    };
                    let kind = if &layer == &Text::lit("") {
                        Text::lit("plain")
                    } else {
                        if &len(&lifted) == &Nat::from(0u32) { Text::lit("const") } else { Text::lit("map") }
                    };
                    prism_rtl::Turn::Finished((res.clone(), crate::check::types::recording::note_app(&st4, &span, &Text::lit("text"), &kind, &layer, &lifted, &or(&index(&opts, &Nat::from(0u32)), &Text::lit("")), &crate::check::types::Col::CBound)))
                })
            }
        }
    }
}

/// `Start InferText, x`: what the function value is when passed to `@Run`.
pub fn start_infer_text(env: Env, st: crate::check::types::St, segs: Array<crate::syntax::TextSeg>, dollar: bool, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferText { env, st, segs, dollar, span })
}

/// ```prism
/// ShowWant: unbounded fn St, Ty, Range -> St
/// ```
pub fn show_want(st: &crate::check::types::St, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyCon(m16763_0_0, m16763_0_1) if (&m16763_0_0 == &Text::lit("Text")) && ((&m16763_0_1).len() == 0) => st.clone(),
        other => add_want(st, &Text::lit("Prelude.Show"), &other, span),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ShowWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowWant: unbounded fn St, Ty, Range -> St
/// ```
pub struct ShowWant {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for ShowWant {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let t = &self.t;
        let span = &self.span;
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_16769: crate::check::types::Ty| match walk_16769 {
            crate::check::types::Ty::TyCon(m16763_0_0, m16763_0_1) if (&m16763_0_0 == &Text::lit("Text")) && ((&m16763_0_1).len() == 0) => prism_rtl::Turn::Finished(st.clone()),
            other => prism_rtl::Turn::Finished(add_want(&st, &Text::lit("Prelude.Show"), &other, &span)),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start ShowWant, x`: what the function value is when passed to `@Run`.
pub fn start_show_want(st: crate::check::types::St, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(ShowWant { st, t, span })
}
