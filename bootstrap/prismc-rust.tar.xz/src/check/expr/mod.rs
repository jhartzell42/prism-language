//! The module `Check.Expr`, from `target/bootstrap/src/prismc/check/expr/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod calls;
pub mod lets;
pub mod lifting;
pub mod operators;
pub mod patterns;

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Env {
    pub g_p: crate::check::env::G,
    pub home_p: crate::prelude::Text,
    pub file_p: crate::prelude::Nat,
    pub src_p: crate::check::errors::Src,
    pub locals_p: crate::prelude::Map<crate::prelude::Text, crate::check::types::Scheme>,
    pub scope_p: crate::check::types::Rw,
    pub givens_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    pub mark_p: crate::prelude::Text,
    pub in_update_p: bool,
    pub def_name_p: crate::prelude::Text,
    pub refine_p: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>,
    pub pending_p: crate::prelude::Array<crate::prelude::Text>,
    pub ids_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>,
}

impl crate::prelude::Show for Env {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Env", &[("g", &self.g_p), ("home", &self.home_p), ("file", &self.file_p), ("src", &self.src_p), ("locals", &self.locals_p), ("scope", &self.scope_p), ("givens", &self.givens_p), ("mark", &self.mark_p), ("inUpdate", &self.in_update_p), ("defName", &self.def_name_p), ("refine", &self.refine_p), ("pending", &self.pending_p), ("ids", &self.ids_p)]);
    }
}

impl crate::prelude::ToPod for Env {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Env", vec![("g", self.g_p.to_pod()), ("home", self.home_p.to_pod()), ("file", self.file_p.to_pod()), ("src", self.src_p.to_pod()), ("locals", self.locals_p.to_pod()), ("scope", self.scope_p.to_pod()), ("givens", self.givens_p.to_pod()), ("mark", self.mark_p.to_pod()), ("inUpdate", self.in_update_p.to_pod()), ("defName", self.def_name_p.to_pod()), ("refine", self.refine_p.to_pod()), ("pending", self.pending_p.to_pod()), ("ids", self.ids_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Env {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Env { g_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "g")?)?, home_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "home")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, src_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "src")?)?, locals_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "locals")?)?, scope_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "scope")?)?, givens_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "givens")?)?, mark_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "mark")?)?, in_update_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "inUpdate")?)?, def_name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "defName")?)?, refine_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "refine")?)?, pending_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pending")?)?, ids_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ids")?)? })
    }
}

/// ```prism
/// WithLocal: fn Env, Text, Scheme -> Env
/// ```
pub fn with_local_f(env_p0: &Env, name_p1: &crate::prelude::Text, sc_p2: &crate::check::types::Scheme) -> Env {
    let mut this: Env = env_p0.clone();
    this.locals_p = crate::prelude::insert(&this.locals_p, name_p1, sc_p2);
    this
}

/// ```prism
/// CallId: fn St, Text, Range -> St
/// ```
pub fn call_id_f(st_p0: &crate::check::types::St, qk_p1: &crate::prelude::Text, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    if !crate::syntax::lexer::chars::has_prefix_f(&crate::check::types::bare_name_f(qk_p1), &crate::prelude::Text::lit("@")) {
        st_p0.clone()
    } else {
        {
            let s2_p3 = {
                let mut this: crate::check::types::St = st_p0.clone();
                this.local_next_p = &this.local_next_p + &crate::prelude::Nat::from(1u32);
                this
            };
            crate::check::types::recording::note_call_f(&s2_p3, span_p2, &st_p0.local_next_p)
        }
    }
}

/// ```prism
/// BindLocalId: fn Env, St, Text, Range -> ((Env, St))
/// ```
pub fn bind_local_id_f(env_p0: &Env, st_p1: &crate::check::types::St, name_p2: &crate::prelude::Text, span_p3: &crate::syntax::Range) -> (Env, crate::check::types::St) {
    let place_p4 = crate::prelude::Text::from(format!("{}:{}:{}", &st_p1.file_p, &span_p3.start_p, &span_p3.end_p));
    let (id_p9, st2_pa) = match crate::prelude::get(&st_p1.local_ids_p, &place_p4) {
        ::std::option::Option::Some(i_p6) => (i_p6, st_p1.clone()),
        ::std::option::Option::None => {
            let fresh_p7 = st_p1.local_next_p.clone();
            let s2_p8 = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.local_next_p = &this.local_next_p + &crate::prelude::Nat::from(1u32);
                this.local_ids_p = crate::prelude::insert(&this.local_ids_p, &place_p4, &fresh_p7);
                this
            };
            (fresh_p7.clone(), crate::check::types::recording::note_local_f(&s2_p8, span_p3, &fresh_p7, name_p2))
        },
    };
    let env2_p5 = {
        let mut this: Env = env_p0.clone();
        this.ids_p = crate::prelude::insert(&this.ids_p, name_p2, &id_p9);
        this
    };
    (env2_p5.clone(), st2_pa.clone())
}

/// ```prism
/// SrcText: fn Env, Range -> Text
/// ```
pub fn src_text_f(env_p0: &Env, r_p1: &crate::syntax::Range) -> crate::prelude::Text {
    crate::check::errors::span_text_f(&env_p0.src_p, r_p1)
}

/// ```prism
/// IsComparison: fn Text -> Bool
/// ```
pub fn is_comparison_f(n_p0: &crate::prelude::Text) -> bool {
    crate::check::types::has_text_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("=="), crate::prelude::Text::lit("!="), crate::prelude::Text::lit("<"), crate::prelude::Text::lit("<="), crate::prelude::Text::lit(">"), crate::prelude::Text::lit(">="), crate::prelude::Text::lit("Compare"), crate::prelude::Text::lit("?"), crate::prelude::Text::lit("~"), crate::prelude::Text::lit("$")]), n_p0)
}

/// ```prism
/// HasTimeMark: fn Text -> Bool
/// ```
pub fn has_time_mark_f(marks_p0: &crate::prelude::Text) -> bool {
    crate::syntax::lexer::chars::contains_f(marks_p0, &crate::prelude::Text::lit("$")) || crate::syntax::lexer::chars::contains_f(marks_p0, &crate::prelude::Text::lit("!"))
}

/// ```prism
/// IsTimeSigil: fn Text -> Bool
/// ```
pub fn is_time_sigil_f(s_p0: &crate::prelude::Text) -> bool {
    (s_p0 == &crate::prelude::Text::lit("$")) || (s_p0 == &crate::prelude::Text::lit("!"))
}

/// ```prism
/// IsPlainSigil: fn Text -> Bool
/// ```
pub fn is_plain_sigil_f(s_p0: &crate::prelude::Text) -> bool {
    (s_p0 == &crate::prelude::Text::lit("?")) || (s_p0 == &crate::prelude::Text::lit("~"))
}

/// ```prism
/// InnerOf: unbounded fn St, Ty -> Ty
/// ```
pub fn inner_of_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TySig(_, i_p2) => (*i_p2).clone(),
        crate::check::types::Ty::TyAt(i_p3, _) => (*i_p3).clone(),
        other_p4 => other_p4,
    }
}

/// The step machine of `InnerOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InnerOf: unbounded fn St, Ty -> Ty
/// ```
pub struct InnerOf {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for InnerOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_4175: crate::check::types::Ty| match walk_f_4175 {
            crate::check::types::Ty::TySig(_, i_p2) => ::prism_rtl::Turn::Finished((*i_p2).clone()),
            crate::check::types::Ty::TyAt(i_p3, _) => ::prism_rtl::Turn::Finished((*i_p3).clone()),
            other_p4 => ::prism_rtl::Turn::Finished(other_p4.clone()),
        })
    }
}

/// `Start InnerOf, x`: what the function value is when passed to `@Run`.
pub fn start_inner_of_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(InnerOf { st_p0, t_p1 })
}

/// ```prism
/// IsLambda: fn Expr -> Bool
/// ```
pub fn is_lambda_f(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ELambda(_, _) => true,
        crate::syntax::ExprKind::ETopicField(_) => true,
        crate::syntax::ExprKind::ETopicIndex(_) => true,
        crate::syntax::ExprKind::EGroup(x_p1) => is_lambda_f(&**x_p1),
        _ => false,
    }
}

/// ```prism
/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub fn infer_f(env_p0: &Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p3, st2_p4) = infer_kind_f(env_p0, st_p1, e_p2);
    (t_p3.clone(), crate::check::types::recording::note_ty_f(&st2_p4, &e_p2.span_p, &t_p3))
}

/// The step machine of `Infer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub struct Infer {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for Infer {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let e_p2x = e_p2.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_infer_kind_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone()), move |infer_kind_f_4727: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p3, st2_p4) = infer_kind_f_4727;
            ::prism_rtl::Turn::Finished((t_p3.clone(), crate::check::types::recording::note_ty_f(&st2_p4, &e_p2x.span_p, &t_p3)))
        })
    }
}

/// `Start Infer, x`: what the function value is when passed to `@Run`.
pub fn start_infer_f(env_p0: Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(Infer { env_p0, st_p1, e_p2 })
}

/// ```prism
/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub fn infer_kind_f(env_p0: &Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EName(n_p3) => if crate::check::env::is_lens_name_f(n_p3) && !crate::check::env::has_key_f(&env_p0.locals_p, &crate::check::env::sname_key_f(n_p3)) {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("lens-argument"), &e_p2.span_p, &crate::prelude::Text::from(format!("the lens `{}` is no value: it is applied to a reference", &crate::check::env::sname_key_f(n_p3))), &crate::prelude::Text::from(format!("apply it in an `update` block, `{} &_`", &crate::check::env::sname_key_f(n_p3)))))
        } else {
            infer_name_f(env_p0, st_p1, n_p3, &e_p2.span_p)
        },
        crate::syntax::ExprKind::ELit(l_p4) => infer_lit_f(env_p0, st_p1, l_p4, &false, &e_p2.span_p),
        crate::syntax::ExprKind::EUnit(marks_p5) => (crate::check::types::with_marks_f(marks_p5, &crate::check::types::t_unit_p(), &env_p0.scope_p), st_p1.clone()),
        crate::syntax::ExprKind::ENil(marks_p6) => {
            let (v_p7, st2_p8) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
            (crate::check::types::with_marks_f(marks_p6, &crate::check::types::Ty::TySig(crate::prelude::Text::lit("?"), ::std::rc::Rc::new(v_p7.clone())), &env_p0.scope_p), st2_p8.clone())
        },
        crate::syntax::ExprKind::EBound(b_p9) => infer_bound_f(env_p0, st_p1, b_p9, &e_p2.span_p),
        crate::syntax::ExprKind::ETuple(es_pa) => {
            let (ts_pb, st2_pc) = infer_all_f(env_p0, st_p1, es_pa);
            let (parts_pg, st3_ph) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&ts_pb)), (crate::prelude::Array::new(), st2_pc.clone()), {
                let ts_pbx = ts_pb.clone();
                let es_pax = es_pa.clone();
                let e_p2x = e_p2.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)| {
                    let ts_pbxy = ts_pbx.clone();
                    let es_paxy = es_pax.clone();
                    let e_p2xy = e_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (acc_pd, s_pe) = p0;
                        let i_pf = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(FaultPart { st_p0: s_pe.clone(), acc_p1: acc_pd.clone(), t_p2: crate::prelude::or(&crate::prelude::index(&ts_pbxy, &i_pf), &crate::check::types::Ty::TyErr), span_p3: crate::prelude::or(&crate::prelude::index(&es_paxy, &i_pf), &e_p2xy).span_p.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>>>
            }));
            (crate::check::types::Ty::TyTuple(parts_pg.clone()), st3_ph.clone())
        },
        crate::syntax::ExprKind::EArray(es_pi) => crate::check::expr::operators::infer_array_f(env_p0, st_p1, es_pi, &e_p2.span_p),
        crate::syntax::ExprKind::EMap(entries_pj) => crate::check::expr::operators::infer_map_f(env_p0, st_p1, entries_pj, &e_p2.span_p),
        crate::syntax::ExprKind::EGroup(x_pk) => infer_f(env_p0, st_p1, &**x_pk),
        crate::syntax::ExprKind::ECall(callee_pl, args_pm, _, _) => crate::check::expr::calls::infer_call_f(env_p0, &crate::check::blocks::borrows::lens_argument_f(env_p0, st_p1, e_p2), &**callee_pl, args_pm, &e_p2.span_p),
        crate::syntax::ExprKind::EBinary(op_pn, lhs_po, rhs_pp) => crate::check::expr::operators::infer_binary_f(env_p0, st_p1, op_pn, &**lhs_po, &**rhs_pp, &e_p2.span_p),
        crate::syntax::ExprKind::EUnary(op_pq, x_pr) => crate::check::expr::operators::infer_unary_f(env_p0, st_p1, op_pq, &**x_pr, &e_p2.span_p),
        crate::syntax::ExprKind::ESuffixed(_, _, _, _) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), &e_p2.span_p, &crate::prelude::Text::lit("this checker does not implement suffixed operators"))),
        crate::syntax::ExprKind::EFreeSigil(s_ps, x_pt) => crate::check::expr::operators::infer_free_sigil_f(env_p0, st_p1, s_ps, &**x_pt, &e_p2.span_p),
        crate::syntax::ExprKind::EField(recv_pu, sigils_pv, name_p10) => match qualified_field_at_o(env_p0, &**recv_pu, sigils_pv, name_p10) {
            ::std::option::Option::Some(n_p11) => infer_name_f(env_p0, st_p1, &n_p11, &e_p2.span_p),
            ::std::option::Option::None => crate::check::expr::operators::infer_field_f(env_p0, st_p1, &**recv_pu, sigils_pv, name_p10, &e_p2.span_p),
        },
        crate::syntax::ExprKind::EIndex(recv_p12, idx_p13) => crate::check::expr::operators::infer_index_f(env_p0, st_p1, &**recv_p12, &**idx_p13, &e_p2.span_p),
        crate::syntax::ExprKind::ETopicField(_) => crate::check::expr::calls::infer_lambda_f(env_p0, st_p1, e_p2, &::std::option::Option::None),
        crate::syntax::ExprKind::ETopicIndex(_) => crate::check::expr::calls::infer_lambda_f(env_p0, st_p1, e_p2, &::std::option::Option::None),
        crate::syntax::ExprKind::EMethod(recv_p14, m_p15, args_p16) => crate::check::expr::calls::infer_call_f(env_p0, st_p1, &crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EName(m_p15.clone())), span_p: m_p15.span_p.clone() }, &crate::prelude::append(&crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: (**recv_p14).clone(), span_p: recv_p14.span_p.clone() }]), args_p16), &e_p2.span_p),
        crate::syntax::ExprKind::ETypeArgs(target_p17, _) => crate::check::expr::calls::infer_call_f(env_p0, st_p1, e_p2, &crate::prelude::Array::new(), &e_p2.span_p),
        crate::syntax::ExprKind::ECast(x_p18, ty_p19, checked_p1a) => if *checked_p1a {
            checked_cast_f(env_p0, st_p1, &**x_p18, ty_p19, &e_p2.span_p)
        } else {
            {
                let cx_p1b = env_cx_f(env_p0);
                let (t_p1d, st2_p1e) = crate::check::env::reading::conv_type_f(&cx_p1b, st_p1, ty_p19);
                let st3_p1c = check_f(env_p0, &st2_p1e, &**x_p18, &t_p1d);
                (t_p1d.clone(), st3_p1c.clone())
            }
        },
        crate::syntax::ExprKind::ENonEmpty(x_p1f) => infer_non_empty_f(env_p0, st_p1, &**x_p1f, &e_p2.span_p),
        crate::syntax::ExprKind::EAbsent => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), &e_p2.span_p, &crate::prelude::Text::lit("this checker does not implement sparse tuples"))),
        crate::syntax::ExprKind::ERest => (crate::check::types::Ty::TyErr, st_p1.clone()),
        crate::syntax::ExprKind::ELambda(_, _) => crate::check::expr::calls::infer_lambda_f(env_p0, st_p1, e_p2, &::std::option::Option::None),
        crate::syntax::ExprKind::EIf(c_p1g, then_b_p1h, else_b_o1i) => crate::check::expr::lifting::infer_if_f(env_p0, st_p1, &**c_p1g, then_b_p1h, else_b_o1i, &e_p2.span_p, &::std::option::Option::None),
        crate::syntax::ExprKind::EMatch(scrut_p1j, arms_p1k) => crate::check::expr::lifting::infer_match_f(env_p0, st_p1, &**scrut_p1j, arms_p1k, &e_p2.span_p, &::std::option::Option::None),
        crate::syntax::ExprKind::ERebuild(scrut_p1l, body_p1m) => {
            let (t_p1n, st2_p1o) = crate::check::blocks::structure::infer_rebuild_f(env_p0, st_p1, &**scrut_p1l, body_p1m, &e_p2.span_p);
            (crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_p1n.clone()), env_p0.scope_p.clone()), st2_p1o.clone())
        },
        crate::syntax::ExprKind::EFor(binders_o1p, source_p1q, body_p1r) => {
            let (t_p1s, st2_p1t) = crate::check::blocks::structure::infer_for_f(env_p0, st_p1, binders_o1p, &**source_p1q, body_p1r, &e_p2.span_p);
            if env_p0.in_update_p {
                (t_p1s.clone(), st2_p1t.clone())
            } else {
                (crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_p1s.clone()), env_p0.scope_p.clone()), st2_p1t.clone())
            }
        },
        crate::syntax::ExprKind::EGiven(b_p1u) => crate::check::blocks::structure::infer_given_f(env_p0, st_p1, b_p1u, &e_p2.span_p),
        crate::syntax::ExprKind::EUpdate(target_p1v, body_p20) => crate::check::blocks::borrows::infer_update_f(env_p0, st_p1, &**target_p1v, body_p20, &e_p2.span_p),
        crate::syntax::ExprKind::EWidgetBlock(b_p21) => {
            let (t_p22, st2_p23) = crate::check::blocks::infer_widget_block_f(env_p0, st_p1, b_p21);
            (crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_p22.clone()), env_p0.scope_p.clone()), st2_p23.clone())
        },
        crate::syntax::ExprKind::EMonad(_, _) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), &e_p2.span_p, &crate::prelude::Text::lit("this checker does not implement `T monad:` blocks"))),
        crate::syntax::ExprKind::ETemplate(t_p24) => crate::check::expr::lets::infer_template_f(env_p0, st_p1, t_p24),
        crate::syntax::ExprKind::EAny(x_p25) => {
            let (t_p26, st2_p27) = infer_f(env_p0, st_p1, &**x_p25);
            let (v_p28, st3_p29) = crate::check::types::fresh_var_f(&st2_p27, &true, &crate::prelude::Text::lit(""));
            (v_p28.clone(), waiting_pack_f(&st3_p29, &v_p28, &t_p26, &e_p2.span_p))
        },
        crate::syntax::ExprKind::ELens(_) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), &e_p2.span_p, &crate::prelude::Text::lit("this checker does not implement lens values and `Over`"))),
        crate::syntax::ExprKind::EError => (crate::check::types::Ty::TyErr, st_p1.clone()),
    }
}

/// The step machine of `InferKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub struct InferKind {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferKind {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EName(n_p3) => if crate::check::env::is_lens_name_f(n_p3) && !crate::check::env::has_key_f(&env_p0.locals_p, &crate::check::env::sname_key_f(n_p3)) {
                ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("lens-argument"), &e_p2.span_p, &crate::prelude::Text::from(format!("the lens `{}` is no value: it is applied to a reference", &crate::check::env::sname_key_f(n_p3))), &crate::prelude::Text::from(format!("apply it in an `update` block, `{} &_`", &crate::check::env::sname_key_f(n_p3))))))
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(InferName { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p3.clone(), span_p3: e_p2.span_p.clone() }))
            },
            crate::syntax::ExprKind::ELit(l_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(InferLit { env_p0: env_p0.clone(), st_p1: st_p1.clone(), l_p2: l_p4.clone(), negative_p3: false, span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EUnit(marks_p5) => ::prism_rtl::Turn::Finished((crate::check::types::with_marks_f(marks_p5, &crate::check::types::t_unit_p(), &env_p0.scope_p), st_p1.clone())),
            crate::syntax::ExprKind::ENil(marks_p6) => {
                let (v_p7, st2_p8) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                ::prism_rtl::Turn::Finished((crate::check::types::with_marks_f(marks_p6, &crate::check::types::Ty::TySig(crate::prelude::Text::lit("?"), ::std::rc::Rc::new(v_p7.clone())), &env_p0.scope_p), st2_p8.clone()))
            },
            crate::syntax::ExprKind::EBound(b_p9) => ::prism_rtl::Turn::Finished(infer_bound_f(env_p0, st_p1, b_p9, &e_p2.span_p)),
            crate::syntax::ExprKind::ETuple(es_pa) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let es_pax = es_pa.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_infer_all_f(env_p0x.clone(), st_p1x.clone(), es_pax.clone()), move |infer_all_f_5550: (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (ts_pb, st2_pc) = infer_all_f_5550;
                    crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&ts_pb)), (crate::prelude::Array::new(), st2_pc.clone()), {
                        let ts_pbx = ts_pb.clone();
                        let es_paxx = es_pax.clone();
                        let e_p2xx = e_p2x.clone();
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)| {
                            let ts_pbxy = ts_pbx.clone();
                            let es_paxxy = es_paxx.clone();
                            let e_p2xxy = e_p2xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (acc_pd, s_pe) = p0;
                                let i_pf = p1;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(FaultPart { st_p0: s_pe.clone(), acc_p1: acc_pd.clone(), t_p2: crate::prelude::or(&crate::prelude::index(&ts_pbxy, &i_pf), &crate::check::types::Ty::TyErr), span_p3: crate::prelude::or(&crate::prelude::index(&es_paxxy, &i_pf), &e_p2xxy).span_p.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>>>
                    }), move |fold_5600: (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)| {
                        let (parts_pg, st3_ph) = fold_5600;
                        ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyTuple(parts_pg.clone()), st3_ph.clone()))
                    })
                })
            },
            crate::syntax::ExprKind::EArray(es_pi) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::operators::InferArray { env_p0: env_p0.clone(), st_p1: st_p1.clone(), es_p2: es_pi.clone(), span_p3: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EMap(entries_pj) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::operators::InferMap { env_p0: env_p0.clone(), st_p1: st_p1.clone(), entries_p2: entries_pj.clone(), span_p3: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EGroup(x_pk) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Infer { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: (**x_pk).clone() })),
            crate::syntax::ExprKind::ECall(callee_pl, args_pm, _, _) => {
                let args_pmx = args_pm.clone();
                let callee_plx = (**callee_pl).clone();
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::blocks::borrows::start_lens_argument_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone()), move |lens_argument_f_5928: crate::check::types::St| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::InferCall { env_p0: env_p0x.clone(), st_p1: lens_argument_f_5928, callee_p2: callee_plx.clone(), args_p3: args_pmx.clone(), span_p4: e_p2x.span_p.clone() })))
            },
            crate::syntax::ExprKind::EBinary(op_pn, lhs_po, rhs_pp) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::operators::InferBinary { env_p0: env_p0.clone(), st_p1: st_p1.clone(), op_p2: op_pn.clone(), lhs_p3: (**lhs_po).clone(), rhs_p4: (**rhs_pp).clone(), span_p5: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EUnary(op_pq, x_pr) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::operators::InferUnary { env_p0: env_p0.clone(), st_p1: st_p1.clone(), op_p2: op_pq.clone(), x_p3: (**x_pr).clone(), span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::ESuffixed(_, _, _, _) => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), &e_p2.span_p, &crate::prelude::Text::lit("this checker does not implement suffixed operators")))),
            crate::syntax::ExprKind::EFreeSigil(s_ps, x_pt) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::operators::InferFreeSigil { env_p0: env_p0.clone(), st_p1: st_p1.clone(), s_p2: s_ps.clone(), x_p3: (**x_pt).clone(), span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EField(recv_pu, sigils_pv, name_p10) => match qualified_field_at_o(env_p0, &**recv_pu, sigils_pv, name_p10) {
                ::std::option::Option::Some(n_p11) => ::prism_rtl::Turn::More(::std::rc::Rc::new(InferName { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p11.clone(), span_p3: e_p2.span_p.clone() })),
                ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::operators::InferField { env_p0: env_p0.clone(), st_p1: st_p1.clone(), recv_p2: (**recv_pu).clone(), sigils_p3: sigils_pv.clone(), name_p4: name_p10.clone(), span_p5: e_p2.span_p.clone() })),
            },
            crate::syntax::ExprKind::EIndex(recv_p12, idx_p13) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::operators::InferIndex { env_p0: env_p0.clone(), st_p1: st_p1.clone(), recv_p2: (**recv_p12).clone(), idx_p3: (**idx_p13).clone(), span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::ETopicField(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::InferLambda { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p2.clone(), expected_o3: ::std::option::Option::None })),
            crate::syntax::ExprKind::ETopicIndex(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::InferLambda { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p2.clone(), expected_o3: ::std::option::Option::None })),
            crate::syntax::ExprKind::EMethod(recv_p14, m_p15, args_p16) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::InferCall { env_p0: env_p0.clone(), st_p1: st_p1.clone(), callee_p2: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EName(m_p15.clone())), span_p: m_p15.span_p.clone() }, args_p3: crate::prelude::append(&crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: (**recv_p14).clone(), span_p: recv_p14.span_p.clone() }]), args_p16), span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::ETypeArgs(target_p17, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::InferCall { env_p0: env_p0.clone(), st_p1: st_p1.clone(), callee_p2: e_p2.clone(), args_p3: crate::prelude::Array::new(), span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::ECast(x_p18, ty_p19, checked_p1a) => if *checked_p1a {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckedCast { env_p0: env_p0.clone(), st_p1: st_p1.clone(), x_p2: (**x_p18).clone(), ty_p3: ty_p19.clone(), span_p4: e_p2.span_p.clone() }))
            } else {
                {
                    let cx_p1b = env_cx_f(env_p0);
                    let env_p0x = env_p0.clone();
                    let st_p1x = st_p1.clone();
                    let ty_p19x = ty_p19.clone();
                    let x_p18x = (**x_p18).clone();
                    crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(cx_p1b.clone(), st_p1x.clone(), ty_p19x.clone()), move |conv_type_f_7109: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_p1d, st2_p1e) = conv_type_f_7109;
                        crate::prelude::call_then(start_check_f(env_p0x.clone(), st2_p1e.clone(), x_p18x.clone(), t_p1d.clone()), move |check_f_7151: crate::check::types::St| {
                            let st3_p1c = check_f_7151;
                            ::prism_rtl::Turn::Finished((t_p1d.clone(), st3_p1c.clone()))
                        })
                    })
                }
            },
            crate::syntax::ExprKind::ENonEmpty(x_p1f) => ::prism_rtl::Turn::More(::std::rc::Rc::new(InferNonEmpty { env_p0: env_p0.clone(), st_p1: st_p1.clone(), x_p2: (**x_p1f).clone(), span_p3: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EAbsent => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), &e_p2.span_p, &crate::prelude::Text::lit("this checker does not implement sparse tuples")))),
            crate::syntax::ExprKind::ERest => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st_p1.clone())),
            crate::syntax::ExprKind::ELambda(_, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::InferLambda { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p2.clone(), expected_o3: ::std::option::Option::None })),
            crate::syntax::ExprKind::EIf(c_p1g, then_b_p1h, else_b_o1i) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::lifting::InferIf { env_p0: env_p0.clone(), st_p1: st_p1.clone(), c_p2: (**c_p1g).clone(), then_b_p3: then_b_p1h.clone(), else_b_o4: else_b_o1i.clone(), span_p5: e_p2.span_p.clone(), expected_o6: ::std::option::Option::None })),
            crate::syntax::ExprKind::EMatch(scrut_p1j, arms_p1k) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::lifting::InferMatch { env_p0: env_p0.clone(), st_p1: st_p1.clone(), scrut_p2: (**scrut_p1j).clone(), arms_p3: arms_p1k.clone(), span_p4: e_p2.span_p.clone(), expected_o5: ::std::option::Option::None })),
            crate::syntax::ExprKind::ERebuild(scrut_p1l, body_p1m) => {
                let body_p1mx = body_p1m.clone();
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let scrut_p1lx = (**scrut_p1l).clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::blocks::structure::start_infer_rebuild_f(env_p0x.clone(), st_p1x.clone(), scrut_p1lx.clone(), body_p1mx.clone(), e_p2x.span_p.clone()), move |infer_rebuild_f_7897: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p1n, st2_p1o) = infer_rebuild_f_7897;
                    ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_p1n.clone()), env_p0x.scope_p.clone()), st2_p1o.clone()))
                })
            },
            crate::syntax::ExprKind::EFor(binders_o1p, source_p1q, body_p1r) => {
                let binders_o1px = binders_o1p.clone();
                let body_p1rx = body_p1r.clone();
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let source_p1qx = (**source_p1q).clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::blocks::structure::start_infer_for_f(env_p0x.clone(), st_p1x.clone(), binders_o1px.clone(), source_p1qx.clone(), body_p1rx.clone(), e_p2x.span_p.clone()), move |infer_for_f_8034: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p1s, st2_p1t) = infer_for_f_8034;
                    if env_p0x.in_update_p {
                        ::prism_rtl::Turn::Finished((t_p1s.clone(), st2_p1t.clone()))
                    } else {
                        ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_p1s.clone()), env_p0x.scope_p.clone()), st2_p1t.clone()))
                    }
                })
            },
            crate::syntax::ExprKind::EGiven(b_p1u) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::blocks::structure::InferGiven { env_p0: env_p0.clone(), st_p1: st_p1.clone(), b_p2: b_p1u.clone(), span_p3: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EUpdate(target_p1v, body_p20) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::blocks::borrows::InferUpdate { env_p0: env_p0.clone(), st_p1: st_p1.clone(), target_p2: (**target_p1v).clone(), body_p3: body_p20.clone(), span_p4: e_p2.span_p.clone() })),
            crate::syntax::ExprKind::EWidgetBlock(b_p21) => {
                let b_p21x = b_p21.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_f(env_p0x.clone(), st_p1x.clone(), b_p21x.clone()), move |infer_widget_block_f_8311: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p22, st2_p23) = infer_widget_block_f_8311;
                    ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_p22.clone()), env_p0x.scope_p.clone()), st2_p23.clone()))
                })
            },
            crate::syntax::ExprKind::EMonad(_, _) => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), &e_p2.span_p, &crate::prelude::Text::lit("this checker does not implement `T monad:` blocks")))),
            crate::syntax::ExprKind::ETemplate(t_p24) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::lets::InferTemplate { env_p0: env_p0.clone(), st_p1: st_p1.clone(), t_p2: t_p24.clone() })),
            crate::syntax::ExprKind::EAny(x_p25) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let x_p25x = (**x_p25).clone();
                crate::prelude::call_then(start_infer_f(env_p0x.clone(), st_p1x.clone(), x_p25x.clone()), move |infer_f_8794: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p26, st2_p27) = infer_f_8794;
                    let (v_p28, st3_p29) = crate::check::types::fresh_var_f(&st2_p27, &true, &crate::prelude::Text::lit(""));
                    ::prism_rtl::Turn::Finished((v_p28.clone(), waiting_pack_f(&st3_p29, &v_p28, &t_p26, &e_p2x.span_p)))
                })
            },
            crate::syntax::ExprKind::ELens(_) => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unsupported"), &e_p2.span_p, &crate::prelude::Text::lit("this checker does not implement lens values and `Over`")))),
            crate::syntax::ExprKind::EError => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st_p1.clone())),
        }
    }
}

/// `Start InferKind, x`: what the function value is when passed to `@Run`.
pub fn start_infer_kind_f(env_p0: Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferKind { env_p0, st_p1, e_p2 })
}

/// ```prism
/// InferNonEmpty: unbounded fn Env, St, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_non_empty_f(env_p0: &Env, st_p1: &crate::check::types::St, x_p2: &crate::syntax::Expr, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let count_o4 = match &*x_p2.kind_p {
        crate::syntax::ExprKind::EArray(es_p5) => ::std::option::Option::Some(crate::prelude::len(es_p5)),
        crate::syntax::ExprKind::EMap(kvs_p6) => ::std::option::Option::Some(crate::prelude::len(kvs_p6)),
        _ => ::std::option::Option::None,
    };
    match &count_o4 {
        ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p3, &crate::prelude::Text::lit("only an array or a map literal is non-empty"))),
        ::std::option::Option::Some(m9406_1) if (m9406_1 == &crate::prelude::Nat::from(0u32)) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p3, &crate::prelude::Text::lit("an empty literal is not non-empty"), &crate::prelude::Text::lit("give it an element, or drop the `+`"))),
        _ => {
            let (c_p7, st2_p8) = infer_f(env_p0, st_p1, x_p2);
            (crate::check::types::non_empty_of_f(&c_p7), st2_p8.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InferNonEmpty`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferNonEmpty: unbounded fn Env, St, Expr, Range -> ((Ty, St))
/// ```
pub struct InferNonEmpty {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub x_p2: crate::syntax::Expr,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferNonEmpty {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let x_p2 = &self.x_p2;
        let span_p3 = &self.span_p3;
        let count_o4 = match &*x_p2.kind_p {
            crate::syntax::ExprKind::EArray(es_p5) => ::std::option::Option::Some(crate::prelude::len(es_p5)),
            crate::syntax::ExprKind::EMap(kvs_p6) => ::std::option::Option::Some(crate::prelude::len(kvs_p6)),
            _ => ::std::option::Option::None,
        };
        match &count_o4 {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p3, &crate::prelude::Text::lit("only an array or a map literal is non-empty")))),
            ::std::option::Option::Some(m9406_1) if (m9406_1 == &crate::prelude::Nat::from(0u32)) => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p3, &crate::prelude::Text::lit("an empty literal is not non-empty"), &crate::prelude::Text::lit("give it an element, or drop the `+`")))),
            _ => {
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let x_p2x = x_p2.clone();
                crate::prelude::call_then(start_infer_f(env_p0x.clone(), st_p1x.clone(), x_p2x.clone()), move |infer_f_9696: (crate::check::types::Ty, crate::check::types::St)| {
                    let (c_p7, st2_p8) = infer_f_9696;
                    ::prism_rtl::Turn::Finished((crate::check::types::non_empty_of_f(&c_p7), st2_p8.clone()))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start InferNonEmpty, x`: what the function value is when passed to `@Run`.
pub fn start_infer_non_empty_f(env_p0: Env, st_p1: crate::check::types::St, x_p2: crate::syntax::Expr, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferNonEmpty { env_p0, st_p1, x_p2, span_p3 })
}

/// ```prism
/// CheckedCast: unbounded fn Env, St, Expr, Type, Range -> ((Ty, St))
/// ```
pub fn checked_cast_f(env_p0: &Env, st_p1: &crate::check::types::St, x_p2: &crate::syntax::Expr, ty_p3: &crate::syntax::Type, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p5, st2_p6) = crate::check::env::reading::conv_type_f(&env_cx_f(env_p0), st_p1, ty_p3);
    match crate::check::types::non_empty_coll_o(&st2_p6, &t_p5) {
        ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(&st2_p6, &crate::prelude::Text::lit("mismatch"), span_p4, &crate::prelude::Text::from(format!("a checked cast\'s type is non-empty; this is `{}`", &crate::check::types::show_ty_f(&st2_p6, &t_p5))), &crate::prelude::Text::lit("write `as [a]+?` or `as (K ==> V)+?`, or drop the `?`"))),
        ::std::option::Option::Some(c_p7) => {
            let (xt_p9, st3_pa) = infer_f(env_p0, &st2_p6, x_p2);
            let coll_p8 = crate::prelude::or(&crate::check::types::non_empty_coll_o(&st3_pa, &xt_p9), &xt_p9);
            (crate::check::types::Ty::TySig(crate::prelude::Text::lit("?"), ::std::rc::Rc::new(t_p5.clone())), crate::check::types::unify::unify_f(&crate::check::types::recording::note_fault_at_f(&st3_pa, &x_p2.span_p, &c_p7, &xt_p9), &c_p7, &coll_p8, &x_p2.span_p))
        },
    }
}

/// The step machine of `CheckedCast`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckedCast: unbounded fn Env, St, Expr, Type, Range -> ((Ty, St))
/// ```
pub struct CheckedCast {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub x_p2: crate::syntax::Expr,
    pub ty_p3: crate::syntax::Type,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for CheckedCast {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let x_p2 = &self.x_p2;
        let ty_p3 = &self.ty_p3;
        let span_p4 = &self.span_p4;
        let env_p0x = env_p0.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        let ty_p3x = ty_p3.clone();
        let x_p2x = x_p2.clone();
        crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(env_cx_f(&env_p0x), st_p1x.clone(), ty_p3x.clone()), move |conv_type_f_10057: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p5, st2_p6) = conv_type_f_10057;
            crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(st2_p6.clone(), t_p5.clone()), move |non_empty_coll_o_10096: ::std::option::Option<crate::check::types::Ty>| match non_empty_coll_o_10096 {
                ::std::option::Option::None => crate::prelude::call_then(crate::check::types::start_show_ty_f(st2_p6.clone(), t_p5.clone()), move |show_ty_f_10218: crate::prelude::Text| ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(&st2_p6, &crate::prelude::Text::lit("mismatch"), &span_p4x, &crate::prelude::Text::from(format!("a checked cast\'s type is non-empty; this is `{}`", &show_ty_f_10218)), &crate::prelude::Text::lit("write `as [a]+?` or `as (K ==> V)+?`, or drop the `?`"))))),
                ::std::option::Option::Some(c_p7) => crate::prelude::call_then(start_infer_f(env_p0x.clone(), st2_p6.clone(), x_p2x.clone()), move |infer_f_10338: (crate::check::types::Ty, crate::check::types::St)| {
                    let (xt_p9, st3_pa) = infer_f_10338;
                    crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(st3_pa.clone(), xt_p9.clone()), move |non_empty_coll_o_10383: ::std::option::Option<crate::check::types::Ty>| {
                        let coll_p8 = crate::prelude::or(&non_empty_coll_o_10383, &xt_p9);
                        crate::prelude::call_then(crate::check::types::recording::start_note_fault_at_f(st3_pa.clone(), x_p2x.span_p.clone(), c_p7.clone(), xt_p9.clone()), move |note_fault_at_f_10531: crate::check::types::St| crate::prelude::call_then(crate::check::types::unify::start_unify_f(note_fault_at_f_10531, c_p7.clone(), coll_p8.clone(), x_p2x.span_p.clone()), move |unify_f_10524: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(crate::prelude::Text::lit("?"), ::std::rc::Rc::new(t_p5.clone())), unify_f_10524))))
                    })
                }),
            })
        })
    }
}

/// `Start CheckedCast, x`: what the function value is when passed to `@Run`.
pub fn start_checked_cast_f(env_p0: Env, st_p1: crate::check::types::St, x_p2: crate::syntax::Expr, ty_p3: crate::syntax::Type, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(CheckedCast { env_p0, st_p1, x_p2, ty_p3, span_p4 })
}

/// ```prism
/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
/// ```
pub fn infer_all_f(env_p0: &Env, st_p1: &crate::check::types::St, es_p2: &crate::prelude::Array<crate::syntax::Expr>) -> (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St) {
    crate::prelude::run_to_end(crate::prelude::fold_job(es_p2.clone(), (crate::prelude::Array::new(), st_p1.clone()), {
        let env_p0x = env_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)| {
            let env_p0xy = env_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p3, s_p4) = p0;
                let x_p5 = p1;
                crate::prelude::call_then(start_infer_f(env_p0xy.clone(), s_p4.clone(), x_p5.clone()), move |infer_f_10725: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p6, s2_p7) = infer_f_10725;
                    ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p3, &t_p6), s2_p7.clone()))
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>>>
    }))
}

/// The step machine of `InferAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
/// ```
pub struct InferAll {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub es_p2: crate::prelude::Array<crate::syntax::Expr>,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)> for InferAll {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let es_p2 = &self.es_p2;
        crate::prelude::fold_job(es_p2.clone(), (crate::prelude::Array::new(), st_p1.clone()), {
            let env_p0x = env_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)| {
                let env_p0xy = env_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p3, s_p4) = p0;
                    let x_p5 = p1;
                    crate::prelude::call_then(start_infer_f(env_p0xy.clone(), s_p4.clone(), x_p5.clone()), move |infer_f_10725: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_p6, s2_p7) = infer_f_10725;
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p3, &t_p6), s2_p7.clone()))
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start InferAll, x`: what the function value is when passed to `@Run`.
pub fn start_infer_all_f(env_p0: Env, st_p1: crate::check::types::St, es_p2: crate::prelude::Array<crate::syntax::Expr>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferAll { env_p0, st_p1, es_p2 })
}

/// ```prism
/// Check: unbounded fn Env, St, Expr, Ty -> St
/// ```
pub fn check_f(env_p0: &Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, expected_p3: &crate::check::types::Ty) -> crate::check::types::St {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::ELambda(_, _) => {
            let (t_p4, st2_p5) = crate::check::expr::calls::infer_lambda_f(env_p0, st_p1, e_p2, &::std::option::Option::Some(expected_p3.clone()));
            crate::check::types::unify::unify_f(&crate::check::types::recording::note_ty_f(&st2_p5, &e_p2.span_p, &t_p4), expected_p3, &t_p4, &e_p2.span_p)
        },
        crate::syntax::ExprKind::EGroup(x_p6) => crate::check::types::recording::note_ty_f(&check_f(env_p0, st_p1, &**x_p6, expected_p3), &e_p2.span_p, expected_p3),
        crate::syntax::ExprKind::EMatch(scrut_p7, arms_p8) => {
            let (t_p9, st2_pa) = crate::check::expr::lifting::infer_match_f(env_p0, st_p1, &**scrut_p7, arms_p8, &e_p2.span_p, &::std::option::Option::Some(expected_p3.clone()));
            crate::check::types::unify::unify_f(&crate::check::types::recording::note_ty_f(&st2_pa, &e_p2.span_p, &t_p9), expected_p3, &t_p9, &e_p2.span_p)
        },
        crate::syntax::ExprKind::EIf(c_pb, then_b_pc, else_b_od) => {
            let (t_pe, st2_pf) = crate::check::expr::lifting::infer_if_f(env_p0, st_p1, &**c_pb, then_b_pc, else_b_od, &e_p2.span_p, &::std::option::Option::Some(expected_p3.clone()));
            crate::check::types::unify::unify_f(&crate::check::types::recording::note_ty_f(&st2_pf, &e_p2.span_p, &t_pe), expected_p3, &t_pe, &e_p2.span_p)
        },
        crate::syntax::ExprKind::EAny(x_pg) => crate::check::types::recording::note_ty_f(&check_any_f(env_p0, st_p1, &**x_pg, expected_p3, &e_p2.span_p), &e_p2.span_p, expected_p3),
        _ => {
            let (t_ph, st2_pi) = infer_f(env_p0, st_p1, e_p2);
            crate::check::types::recording::unify_at_f(&st2_pi, expected_p3, &t_ph, &e_p2.span_p)
        },
    }
}

/// The step machine of `Check`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Check: unbounded fn Env, St, Expr, Ty -> St
/// ```
pub struct Check {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub expected_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::St> for Check {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let expected_p3 = &self.expected_p3;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::ELambda(_, _) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::calls::start_infer_lambda_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone(), ::std::option::Option::Some(expected_p3x.clone())), move |infer_lambda_f_11034: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p4, st2_p5) = infer_lambda_f_11034;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: crate::check::types::recording::note_ty_f(&st2_p5, &e_p2x.span_p, &t_p4), expected_p1: expected_p3x.clone(), found_p2: t_p4.clone(), span_p3: e_p2x.span_p.clone() }))
                })
            },
            crate::syntax::ExprKind::EGroup(x_p6) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                let x_p6x = (**x_p6).clone();
                crate::prelude::call_then(start_check_f(env_p0x.clone(), st_p1x.clone(), x_p6x.clone(), expected_p3x.clone()), move |check_f_11152: crate::check::types::St| ::prism_rtl::Turn::Finished(crate::check::types::recording::note_ty_f(&check_f_11152, &e_p2x.span_p, &expected_p3x)))
            },
            crate::syntax::ExprKind::EMatch(scrut_p7, arms_p8) => {
                let arms_p8x = arms_p8.clone();
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let scrut_p7x = (**scrut_p7).clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lifting::start_infer_match_f(env_p0x.clone(), st_p1x.clone(), scrut_p7x.clone(), arms_p8x.clone(), e_p2x.span_p.clone(), ::std::option::Option::Some(expected_p3x.clone())), move |infer_match_f_11247: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p9, st2_pa) = infer_match_f_11247;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: crate::check::types::recording::note_ty_f(&st2_pa, &e_p2x.span_p, &t_p9), expected_p1: expected_p3x.clone(), found_p2: t_p9.clone(), span_p3: e_p2x.span_p.clone() }))
                })
            },
            crate::syntax::ExprKind::EIf(c_pb, then_b_pc, else_b_od) => {
                let else_b_odx = else_b_od.clone();
                let c_pbx = (**c_pb).clone();
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                let then_b_pcx = then_b_pc.clone();
                crate::prelude::call_then(crate::check::expr::lifting::start_infer_if_f(env_p0x.clone(), st_p1x.clone(), c_pbx.clone(), then_b_pcx.clone(), else_b_odx.clone(), e_p2x.span_p.clone(), ::std::option::Option::Some(expected_p3x.clone())), move |infer_if_f_11411: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pe, st2_pf) = infer_if_f_11411;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: crate::check::types::recording::note_ty_f(&st2_pf, &e_p2x.span_p, &t_pe), expected_p1: expected_p3x.clone(), found_p2: t_pe.clone(), span_p3: e_p2x.span_p.clone() }))
                })
            },
            crate::syntax::ExprKind::EAny(x_pg) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                let x_pgx = (**x_pg).clone();
                crate::prelude::call_then(start_check_any_f(env_p0x.clone(), st_p1x.clone(), x_pgx.clone(), expected_p3x.clone(), e_p2x.span_p.clone()), move |check_any_f_11546: crate::check::types::St| ::prism_rtl::Turn::Finished(crate::check::types::recording::note_ty_f(&check_any_f_11546, &e_p2x.span_p, &expected_p3x)))
            },
            _ => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_infer_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone()), move |infer_f_11643: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_ph, st2_pi) = infer_f_11643;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::recording::UnifyAt { st_p0: st2_pi.clone(), expected_p1: expected_p3x.clone(), found_p2: t_ph.clone(), span_p3: e_p2x.span_p.clone() }))
                })
            },
        }
    }
}

/// `Start Check, x`: what the function value is when passed to `@Run`.
pub fn start_check_f(env_p0: Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, expected_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(Check { env_p0, st_p1, e_p2, expected_p3 })
}

/// ```prism
/// FaultPart: unbounded fn St, [Ty], Ty, Range -> (([Ty], St))
/// ```
pub fn fault_part_f(st_p0: &crate::check::types::St, acc_p1: &crate::prelude::Array<crate::check::types::Ty>, t_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St) {
    let (t2_p4, st2_p5) = fault_of_f(st_p0, t_p2, span_p3);
    (crate::prelude::push(acc_p1, &t2_p4), st2_p5.clone())
}

/// The step machine of `FaultPart`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FaultPart: unbounded fn St, [Ty], Ty, Range -> (([Ty], St))
/// ```
pub struct FaultPart {
    pub st_p0: crate::check::types::St,
    pub acc_p1: crate::prelude::Array<crate::check::types::Ty>,
    pub t_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)> for FaultPart {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let acc_p1 = &self.acc_p1;
        let t_p2 = &self.t_p2;
        let span_p3 = &self.span_p3;
        let acc_p1x = acc_p1.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(start_fault_of_f(st_p0x.clone(), t_p2x.clone(), span_p3x.clone()), move |fault_of_f_11928: (crate::check::types::Ty, crate::check::types::St)| {
            let (t2_p4, st2_p5) = fault_of_f_11928;
            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p1x, &t2_p4), st2_p5.clone()))
        })
    }
}

/// `Start FaultPart, x`: what the function value is when passed to `@Run`.
pub fn start_fault_part_f(st_p0: crate::check::types::St, acc_p1: crate::prelude::Array<crate::check::types::Ty>, t_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>> {
    ::std::rc::Rc::new(FaultPart { st_p0, acc_p1, t_p2, span_p3 })
}

/// ```prism
/// FaultOf: unbounded fn St, Ty, Range -> ((Ty, St))
/// ```
pub fn fault_of_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, span_p2: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TyCon(m12267_0_0, m12267_0_1) if (&m12267_0_0 == &crate::prelude::Text::lit("Prelude.Error")) && ((&m12267_0_1).len() == 0) => {
            let (v_p3, st2_p4) = crate::check::types::recording::fault_var_f(st_p0, span_p2);
            (v_p3.clone(), crate::check::types::recording::note_fault_at_f(&st2_p4, span_p2, &v_p3, t_p1))
        },
        _ => (t_p1.clone(), st_p0.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `FaultOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FaultOf: unbounded fn St, Ty, Range -> ((Ty, St))
/// ```
pub struct FaultOf {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub span_p2: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for FaultOf {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let span_p2 = &self.span_p2;
        let span_p2x = span_p2.clone();
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_12273: crate::check::types::Ty| match walk_f_12273 {
            crate::check::types::Ty::TyCon(m12267_0_0, m12267_0_1) if (&m12267_0_0 == &crate::prelude::Text::lit("Prelude.Error")) && ((&m12267_0_1).len() == 0) => {
                let (v_p3, st2_p4) = crate::check::types::recording::fault_var_f(&st_p0x, &span_p2x);
                crate::prelude::call_then(crate::check::types::recording::start_note_fault_at_f(st2_p4.clone(), span_p2x.clone(), v_p3.clone(), t_p1x.clone()), move |note_fault_at_f_12375: crate::check::types::St| ::prism_rtl::Turn::Finished((v_p3.clone(), note_fault_at_f_12375)))
            },
            _ => ::prism_rtl::Turn::Finished((t_p1x.clone(), st_p0x.clone())),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start FaultOf, x`: what the function value is when passed to `@Run`.
pub fn start_fault_of_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty, span_p2: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(FaultOf { st_p0, t_p1, span_p2 })
}

/// ```prism
/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
/// ```
pub fn check_any_f(env_p0: &Env, st_p1: &crate::check::types::St, x_p2: &crate::syntax::Expr, expected_p3: &crate::check::types::Ty, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk_f(st_p1, expected_p3) {
        crate::check::types::Ty::TyAny(trs_p5) => {
            let (t_p6, st2_p7) = infer_f(env_p0, st_p1, x_p2);
            crate::prelude::fold(&trs_p5, &st2_p7, &(|s_p8: &crate::check::types::St, tr_p9: &crate::prelude::Text| add_want_f(s_p8, tr_p9, &t_p6, span_p4)))
        },
        crate::check::types::Ty::TyFlex(_) => {
            let (t_pa, st2_pb) = infer_f(env_p0, st_p1, x_p2);
            waiting_pack_f(&st2_pb, expected_p3, &t_pa, span_p4)
        },
        other_pc => {
            let (t_pd, st2_pe) = infer_f(env_p0, st_p1, x_p2);
            crate::check::types::unify::unify_f(&st2_pe, &other_pc, &crate::check::types::Ty::TyAny(crate::prelude::Array::new()), span_p4)
        },
    }
}

/// The step machine of `CheckAny`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
/// ```
pub struct CheckAny {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub x_p2: crate::syntax::Expr,
    pub expected_p3: crate::check::types::Ty,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for CheckAny {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let x_p2 = &self.x_p2;
        let expected_p3 = &self.expected_p3;
        let span_p4 = &self.span_p4;
        let env_p0x = env_p0.clone();
        let expected_p3x = expected_p3.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        let x_p2x = x_p2.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), expected_p3x.clone()), move |walk_f_12623: crate::check::types::Ty| match walk_f_12623 {
            crate::check::types::Ty::TyAny(trs_p5) => crate::prelude::call_then(start_infer_f(env_p0x.clone(), st_p1x.clone(), x_p2x.clone()), move |infer_f_12682: (crate::check::types::Ty, crate::check::types::St)| {
                let (t_p6, st2_p7) = infer_f_12682;
                ::prism_rtl::Turn::Finished(crate::prelude::fold(&trs_p5, &st2_p7, &(|s_p8: &crate::check::types::St, tr_p9: &crate::prelude::Text| add_want_f(s_p8, tr_p9, &t_p6, &span_p4x))))
            }),
            crate::check::types::Ty::TyFlex(_) => crate::prelude::call_then(start_infer_f(env_p0x.clone(), st_p1x.clone(), x_p2x.clone()), move |infer_f_12798: (crate::check::types::Ty, crate::check::types::St)| {
                let (t_pa, st2_pb) = infer_f_12798;
                ::prism_rtl::Turn::Finished(waiting_pack_f(&st2_pb, &expected_p3x, &t_pa, &span_p4x))
            }),
            other_pc => crate::prelude::call_then(start_infer_f(env_p0x.clone(), st_p1x.clone(), x_p2x.clone()), move |infer_f_12894: (crate::check::types::Ty, crate::check::types::St)| {
                let (t_pd, st2_pe) = infer_f_12894;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st2_pe.clone(), expected_p1: other_pc.clone(), found_p2: crate::check::types::Ty::TyAny(crate::prelude::Array::new()), span_p3: span_p4x.clone() }))
            }),
        })
    }
}

/// `Start CheckAny, x`: what the function value is when passed to `@Run`.
pub fn start_check_any_f(env_p0: Env, st_p1: crate::check::types::St, x_p2: crate::syntax::Expr, expected_p3: crate::check::types::Ty, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CheckAny { env_p0, st_p1, x_p2, expected_p3, span_p4 })
}

/// ```prism
/// WaitingPack: fn St, Ty, Ty, Range -> St
/// ```
pub fn waiting_pack_f(st_p0: &crate::check::types::St, result_p1: &crate::check::types::Ty, inner_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.packs_p = crate::prelude::push(&this.packs_p, &crate::check::types::Pack { result_p: result_p1.clone(), inner_p: inner_p2.clone(), file_p: this.file_p.clone(), span_p: span_p3.clone() });
    this
}

/// ```prism
/// AddWant: fn St, Text, Ty, Range -> St
/// ```
pub fn add_want_f(st_p0: &crate::check::types::St, cls_p1: &crate::prelude::Text, t_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.wants_p = crate::prelude::push(&this.wants_p, &crate::check::types::Want { cls_p: cls_p1.clone(), ty_p: t_p2.clone(), file_p: this.file_p.clone(), span_p: span_p3.clone(), level_p: this.level_p.clone() });
    this
}

/// ```prism
/// EnvCx: fn Env -> Cx
/// ```
pub fn env_cx_f(env_p0: &Env) -> crate::check::env::reading::Cx {
    let base_p1 = crate::check::env::reading::cx_of_f(&env_p0.g_p, &env_p0.home_p);
    let mut this: crate::check::env::reading::Cx = base_p1.clone();
    this.scope_p = env_p0.scope_p.clone();
    this
}

/// ```prism
/// ?QualifiedFieldAt: fn Env, Expr, Text, Ident -> ?SName
/// ```
pub fn qualified_field_at_o(env_p0: &Env, recv_p1: &crate::syntax::Expr, sigils_p2: &crate::prelude::Text, name_p3: &crate::syntax::Ident) -> ::std::option::Option<crate::syntax::SName> {
    match &*recv_p1.kind_p {
        crate::syntax::ExprKind::EName(r_p4) => if crate::check::env::has_key_f(&env_p0.locals_p, &crate::check::env::sname_key_f(r_p4)) {
            ::std::option::Option::None
        } else {
            crate::check::env::names::qualified_field_o(&env_p0.g_p, &env_p0.home_p, recv_p1, sigils_p2, name_p3)
        },
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_name_f(env_p0: &Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let local_p4 = crate::check::env::sname_key_f(n_p2);
    if env_p0.in_update_p && has_time_mark_f(&n_p2.sigils_p) {
        (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("time-in-update"), span_p3, &crate::prelude::Text::from(format!("`{}` in an `update` block", &local_p4)), &crate::prelude::Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function")))
    } else {
        infer_name_in_f(env_p0, st_p1, n_p2, span_p3)
    }
}

/// The step machine of `InferName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferName {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferName {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let span_p3 = &self.span_p3;
        let local_p4 = crate::check::env::sname_key_f(n_p2);
        if env_p0.in_update_p && has_time_mark_f(&n_p2.sigils_p) {
            ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("time-in-update"), span_p3, &crate::prelude::Text::from(format!("`{}` in an `update` block", &local_p4)), &crate::prelude::Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function"))))
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(InferNameIn { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p2.clone(), span_p3: span_p3.clone() }))
        }
    }
}

/// `Start InferName, x`: what the function value is when passed to `@Run`.
pub fn start_infer_name_f(env_p0: Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferName { env_p0, st_p1, n_p2, span_p3 })
}

/// ```prism
/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_name_in_f(env_p0: &Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let local_p4 = crate::check::env::sname_key_f(n_p2);
    match crate::prelude::get(&env_p0.locals_p, &local_p4) {
        ::std::option::Option::Some(sc_p5) => {
            let st2_p6 = match crate::prelude::get(&env_p0.ids_p, &local_p4) {
                ::std::option::Option::Some(id_p7) => crate::check::types::recording::note_use_f(st_p1, span_p3, &id_p7, &local_p4),
                ::std::option::Option::None => st_p1.clone(),
            };
            instantiate_local_f(&st2_p6, &sc_p5, span_p3, &local_p4)
        },
        ::std::option::Option::None => infer_global_f(env_p0, st_p1, n_p2, span_p3),
    }
}

/// The step machine of `InferNameIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferNameIn {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferNameIn {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let span_p3 = &self.span_p3;
        let local_p4 = crate::check::env::sname_key_f(n_p2);
        match crate::prelude::get(&env_p0.locals_p, &local_p4) {
            ::std::option::Option::Some(sc_p5) => {
                let st2_p6 = match crate::prelude::get(&env_p0.ids_p, &local_p4) {
                    ::std::option::Option::Some(id_p7) => crate::check::types::recording::note_use_f(st_p1, span_p3, &id_p7, &local_p4),
                    ::std::option::Option::None => st_p1.clone(),
                };
                ::prism_rtl::Turn::More(::std::rc::Rc::new(InstantiateLocal { st_p0: st2_p6.clone(), sc_p1: sc_p5.clone(), span_p2: span_p3.clone(), name_p3: local_p4.clone() }))
            },
            ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(InferGlobal { env_p0: env_p0.clone(), st0_p1: st_p1.clone(), n_p2: n_p2.clone(), span_p3: span_p3.clone() })),
        }
    }
}

/// `Start InferNameIn, x`: what the function value is when passed to `@Run`.
pub fn start_infer_name_in_f(env_p0: Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferNameIn { env_p0, st_p1, n_p2, span_p3 })
}

/// ```prism
/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
/// ```
pub fn instantiate_local_f(st_p0: &crate::check::types::St, sc_p1: &crate::check::types::Scheme, span_p2: &crate::syntax::Range, name_p3: &crate::prelude::Text) -> (crate::check::types::Ty, crate::check::types::St) {
    if (&crate::prelude::len(&sc_p1.qs_p) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&sc_p1.cqs_p) == &crate::prelude::Nat::from(0u32)) {
        crate::check::types::schemes::instantiate_f(st_p0, sc_p1, span_p2)
    } else {
        {
            let (t_p4, st2_p5, inst_p6) = crate::check::types::schemes::instantiate_with_f(st_p0, sc_p1, span_p2, &crate::prelude::Array::new());
            (t_p4.clone(), crate::check::types::recording::note_inst_f(&st2_p5, span_p2, name_p3, sc_p1, &inst_p6))
        }
    }
}

/// The step machine of `InstantiateLocal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
/// ```
pub struct InstantiateLocal {
    pub st_p0: crate::check::types::St,
    pub sc_p1: crate::check::types::Scheme,
    pub span_p2: crate::syntax::Range,
    pub name_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InstantiateLocal {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let sc_p1 = &self.sc_p1;
        let span_p2 = &self.span_p2;
        let name_p3 = &self.name_p3;
        if (&crate::prelude::len(&sc_p1.qs_p) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&sc_p1.cqs_p) == &crate::prelude::Nat::from(0u32)) {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::schemes::Instantiate { st_p0: st_p0.clone(), sc_p1: sc_p1.clone(), span_p2: span_p2.clone() }))
        } else {
            {
                let name_p3x = name_p3.clone();
                let sc_p1x = sc_p1.clone();
                let span_p2x = span_p2.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p0x.clone(), sc_p1x.clone(), span_p2x.clone(), crate::prelude::Array::new()), move |instantiate_with_f_15036: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                    let (t_p4, st2_p5, inst_p6) = instantiate_with_f_15036;
                    ::prism_rtl::Turn::Finished((t_p4.clone(), crate::check::types::recording::note_inst_f(&st2_p5, &span_p2x, &name_p3x, &sc_p1x, &inst_p6)))
                })
            }
        }
    }
}

/// `Start InstantiateLocal, x`: what the function value is when passed to `@Run`.
pub fn start_instantiate_local_f(st_p0: crate::check::types::St, sc_p1: crate::check::types::Scheme, span_p2: crate::syntax::Range, name_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InstantiateLocal { st_p0, sc_p1, span_p2, name_p3 })
}

/// ```prism
/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_global_f(env_p0: &Env, st0_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (qk_o6, why_p7) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p2);
    let st1_p4 = collision_at_f(env_p0, st0_p1, &why_p7, &crate::check::env::sname_key_f(n_p2), span_p3);
    let st_p5 = match &qk_o6 {
        ::std::option::Option::Some(qk_p8) => crate::check::types::recording::note_global_f(&st1_p4, span_p3, &(if &why_p7 == &crate::prelude::Text::lit("answer") {
            crate::check::env::names::answer_tag_f(qk_p8)
        } else {
            qk_p8.clone()
        })),
        ::std::option::Option::None => st1_p4.clone(),
    };
    match &qk_o6 {
        ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p5, &crate::prelude::Text::lit("unknown-name"), span_p3, &crate::prelude::Text::from(format!("nothing declares `{}` here", &crate::check::env::sname_key_f(n_p2))))),
        ::std::option::Option::Some(qk_p9) => if &why_p7 == &crate::prelude::Text::lit("tag") {
            tag_value_f(env_p0, &st_p5, qk_p9, span_p3)
        } else {
            if &why_p7 == &crate::prelude::Text::lit("answer") {
                answer_constructor_f(env_p0, &st_p5, &crate::check::env::names::answer_tag_f(qk_p9), span_p3)
            } else {
                if crate::check::expr::calls::is_local_maker_f(qk_p9) && !env_p0.in_update_p {
                    (crate::check::types::Ty::TyErr, crate::check::expr::calls::local_outside_f(&st_p5, qk_p9, span_p3))
                } else {
                    match crate::prelude::get(&env_p0.g_p.vals_p, qk_p9) {
                        ::std::option::Option::Some(v_pa) => {
                            let (t_pb, st2_pc, inst_pd) = crate::check::types::schemes::instantiate_with_f(&crate::check::expr::calls::note_method_use_f(&call_id_f(&st_p5, qk_p9, span_p3), &v_pa, span_p3), &v_pa.scheme_p, span_p3, &crate::prelude::Array::new());
                            (t_pb.clone(), if is_generic_use_f(&v_pa) {
                                crate::check::types::recording::note_generic_use_f(&st2_pc, qk_p9, &v_pa.scheme_p.qs_p, span_p3, &inst_pd)
                            } else {
                                st2_pc.clone()
                            })
                        },
                        ::std::option::Option::None => match crate::prelude::get(&env_p0.g_p.ctors_p, qk_p9) {
                            ::std::option::Option::Some(c_pe) => ctor_value_f(env_p0, &st_p5, &c_pe, span_p3),
                            ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p5, &crate::prelude::Text::lit("unknown-name"), span_p3, &crate::prelude::Text::from(format!("`{}` has no signature line or type", &crate::check::env::sname_key_f(n_p2))))),
                        },
                    }
                }
            }
        },
    }
}

/// The step machine of `InferGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferGlobal {
    pub env_p0: Env,
    pub st0_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferGlobal {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st0_p1 = &self.st0_p1;
        let n_p2 = &self.n_p2;
        let span_p3 = &self.span_p3;
        let (qk_o6, why_p7) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p2);
        let st1_p4 = collision_at_f(env_p0, st0_p1, &why_p7, &crate::check::env::sname_key_f(n_p2), span_p3);
        let st_p5 = match &qk_o6 {
            ::std::option::Option::Some(qk_p8) => crate::check::types::recording::note_global_f(&st1_p4, span_p3, &(if &why_p7 == &crate::prelude::Text::lit("answer") {
                crate::check::env::names::answer_tag_f(qk_p8)
            } else {
                qk_p8.clone()
            })),
            ::std::option::Option::None => st1_p4.clone(),
        };
        match &qk_o6 {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p5, &crate::prelude::Text::lit("unknown-name"), span_p3, &crate::prelude::Text::from(format!("nothing declares `{}` here", &crate::check::env::sname_key_f(n_p2)))))),
            ::std::option::Option::Some(qk_p9) => if &why_p7 == &crate::prelude::Text::lit("tag") {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TagValue { env_p0: env_p0.clone(), st_p1: st_p5.clone(), name_p2: qk_p9.clone(), span_p3: span_p3.clone() }))
            } else {
                if &why_p7 == &crate::prelude::Text::lit("answer") {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(AnswerConstructor { env_p0: env_p0.clone(), st_p1: st_p5.clone(), name_p2: crate::check::env::names::answer_tag_f(qk_p9), span_p3: span_p3.clone() }))
                } else {
                    if crate::check::expr::calls::is_local_maker_f(qk_p9) && !env_p0.in_update_p {
                        ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::expr::calls::local_outside_f(&st_p5, qk_p9, span_p3)))
                    } else {
                        match crate::prelude::get(&env_p0.g_p.vals_p, qk_p9) {
                            ::std::option::Option::Some(v_pa) => {
                                let qk_p9x = qk_p9.clone();
                                let span_p3x = span_p3.clone();
                                crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(crate::check::expr::calls::note_method_use_f(&call_id_f(&st_p5, &qk_p9x, &span_p3x), &v_pa, &span_p3x), v_pa.scheme_p.clone(), span_p3x.clone(), crate::prelude::Array::new()), move |instantiate_with_f_15976: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                                    let (t_pb, st2_pc, inst_pd) = instantiate_with_f_15976;
                                    ::prism_rtl::Turn::Finished((t_pb.clone(), if is_generic_use_f(&v_pa) {
                                        crate::check::types::recording::note_generic_use_f(&st2_pc, &qk_p9x, &v_pa.scheme_p.qs_p, &span_p3x, &inst_pd)
                                    } else {
                                        st2_pc.clone()
                                    }))
                                })
                            },
                            ::std::option::Option::None => match crate::prelude::get(&env_p0.g_p.ctors_p, qk_p9) {
                                ::std::option::Option::Some(c_pe) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CtorValue { env_p0: env_p0.clone(), st_p1: st_p5.clone(), c_p2: c_pe.clone(), span_p3: span_p3.clone() })),
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p5, &crate::prelude::Text::lit("unknown-name"), span_p3, &crate::prelude::Text::from(format!("`{}` has no signature line or type", &crate::check::env::sname_key_f(n_p2)))))),
                            },
                        }
                    }
                }
            },
        }
    }
}

/// `Start InferGlobal, x`: what the function value is when passed to `@Run`.
pub fn start_infer_global_f(env_p0: Env, st0_p1: crate::check::types::St, n_p2: crate::syntax::SName, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferGlobal { env_p0, st0_p1, n_p2, span_p3 })
}

/// ```prism
/// IsGenericUse: fn ValInfo -> Bool
/// ```
pub fn is_generic_use_f(v_p0: &crate::check::env::ValInfo) -> bool {
    (&crate::prelude::len(&v_p0.scheme_p.qs_p) > &crate::prelude::Nat::from(0u32)) && (&v_p0.sort_p != &crate::prelude::Text::lit("method"))
}

/// ```prism
/// CollisionAt: fn Env, St, Text, Text, Range -> St
/// ```
pub fn collision_at_f(env_p0: &Env, st_p1: &crate::check::types::St, why_p2: &crate::prelude::Text, name_p3: &crate::prelude::Text, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    if why_p2 != &crate::prelude::Text::lit("collision") {
        st_p1.clone()
    } else {
        {
            let keys_p5 = crate::prelude::or(&crate::prelude::get(&crate::prelude::or(&crate::prelude::get(&env_p0.g_p.bare_p, &env_p0.home_p), &crate::prelude::Map::new()), name_p3), &crate::prelude::Array::new());
            let others_p6 = crate::prelude::filter(&keys_p5, &(|k_p7: &crate::prelude::Text| crate::syntax::lexer::chars::contains_f(k_p7, &crate::prelude::Text::lit("."))));
            crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("collision"), span_p4, &crate::prelude::Text::from(format!("`{}` is declared by more than one module this file reaches by a bare name: {}", name_p3, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&keys_p5, &(|k_p8: &crate::prelude::Text| crate::prelude::Text::from(format!("`{}`", k_p8)))), &crate::prelude::Text::lit(", ")))), &crate::prelude::Text::from(format!("write the one meant qualified, as `{}`, or rename this file\'s own", &crate::prelude::or(&crate::prelude::index(&others_p6, &crate::prelude::Nat::from(0u32)), name_p3))))
        }
    }
}

/// ```prism
/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
/// ```
pub fn ctor_value_f(env_p0: &Env, st_p1: &crate::check::types::St, c_p2: &crate::check::env::CtorInfo, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let sc_p4 = crate::check::types::Scheme { qs_p: c_p2.params_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: if &crate::prelude::len(&c_p2.args_p) == &crate::prelude::Nat::from(0u32) {
        c_p2.ty_p.clone()
    } else {
        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, c_p2.args_p.clone(), ::std::rc::Rc::new(c_p2.ty_p.clone()))
    } };
    crate::check::types::schemes::instantiate_f(st_p1, &sc_p4, span_p3)
}

/// The step machine of `CtorValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
/// ```
pub struct CtorValue {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::check::env::CtorInfo,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for CtorValue {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let span_p3 = &self.span_p3;
        let sc_p4 = crate::check::types::Scheme { qs_p: c_p2.params_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: if &crate::prelude::len(&c_p2.args_p) == &crate::prelude::Nat::from(0u32) {
            c_p2.ty_p.clone()
        } else {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, c_p2.args_p.clone(), ::std::rc::Rc::new(c_p2.ty_p.clone()))
        } };
        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::schemes::Instantiate { st_p0: st_p1.clone(), sc_p1: sc_p4.clone(), span_p2: span_p3.clone() }))
    }
}

/// `Start CtorValue, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_value_f(env_p0: Env, st_p1: crate::check::types::St, c_p2: crate::check::env::CtorInfo, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(CtorValue { env_p0, st_p1, c_p2, span_p3 })
}

/// ```prism
/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub fn tag_value_f(env_p0: &Env, st_p1: &crate::check::types::St, name_p2: &crate::prelude::Text, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::prelude::get(&env_p0.g_p.tags_p, name_p2) {
        ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), span_p3, &crate::prelude::Text::from(format!("no tag `{}`", name_p2)))),
        ::std::option::Option::Some(tg_p4) => if &tg_p4.kind_p == &crate::prelude::Text::lit("Element") {
            {
                let (rw_p6, st2_p7) = crate::check::types::recording::fresh_row_f(st_p1, &crate::prelude::Array::from(vec![tg_p4.family_p.clone()]));
                let erow_p5 = crate::check::types::Rw { fams_p: crate::prelude::Array::from(vec![tg_p4.family_p.clone()]), minus_p: crate::prelude::Array::new(), tail_p: rw_p6.tail_p.clone() };
                let (out_p8, st3_p9) = crate::check::types::schemes::instantiate_f(&st2_p7, &crate::check::types::Scheme { qs_p: tg_p4.qs_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: tg_p4.rqs_p.clone(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: tg_p4.bounds_p.clone(), eqs_p: crate::prelude::Array::new(), ty_p: tg_p4.out_p.clone() }, span_p3);
                (crate::check::types::Ty::TyElem(erow_p5.clone(), ::std::rc::Rc::new(out_p8.clone())), st3_p9.clone())
            }
        } else {
            (crate::check::types::Ty::TyCon(tg_p4.kind_p.clone(), crate::prelude::Array::new()), st_p1.clone())
        },
    }
}

/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub struct TagValue {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub name_p2: crate::prelude::Text,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for TagValue {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let name_p2 = &self.name_p2;
        let span_p3 = &self.span_p3;
        match crate::prelude::get(&env_p0.g_p.tags_p, name_p2) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), span_p3, &crate::prelude::Text::from(format!("no tag `{}`", name_p2))))),
            ::std::option::Option::Some(tg_p4) => if &tg_p4.kind_p == &crate::prelude::Text::lit("Element") {
                {
                    let (rw_p6, st2_p7) = crate::check::types::recording::fresh_row_f(st_p1, &crate::prelude::Array::from(vec![tg_p4.family_p.clone()]));
                    let erow_p5 = crate::check::types::Rw { fams_p: crate::prelude::Array::from(vec![tg_p4.family_p.clone()]), minus_p: crate::prelude::Array::new(), tail_p: rw_p6.tail_p.clone() };
                    let span_p3x = span_p3.clone();
                    crate::prelude::call_then(crate::check::types::schemes::start_instantiate_f(st2_p7.clone(), crate::check::types::Scheme { qs_p: tg_p4.qs_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: tg_p4.rqs_p.clone(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: tg_p4.bounds_p.clone(), eqs_p: crate::prelude::Array::new(), ty_p: tg_p4.out_p.clone() }, span_p3x.clone()), move |instantiate_f_18284: (crate::check::types::Ty, crate::check::types::St)| {
                        let (out_p8, st3_p9) = instantiate_f_18284;
                        ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyElem(erow_p5.clone(), ::std::rc::Rc::new(out_p8.clone())), st3_p9.clone()))
                    })
                }
            } else {
                ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyCon(tg_p4.kind_p.clone(), crate::prelude::Array::new()), st_p1.clone()))
            },
        }
    }
}

/// `Start TagValue, x`: what the function value is when passed to `@Run`.
pub fn start_tag_value_f(env_p0: Env, st_p1: crate::check::types::St, name_p2: crate::prelude::Text, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(TagValue { env_p0, st_p1, name_p2, span_p3 })
}

/// ```prism
/// AnswerConstructor: unbounded fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub fn answer_constructor_f(env_p0: &Env, st_p1: &crate::check::types::St, name_p2: &crate::prelude::Text, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::prelude::get(&env_p0.g_p.tags_p, name_p2) {
        ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), span_p3, &crate::prelude::Text::from(format!("no tag `{}`", name_p2)))),
        ::std::option::Option::Some(tg_p4) => {
            let (rw_p6, st2_p7) = crate::check::types::recording::fresh_row_f(st_p1, &crate::prelude::Array::from(vec![tg_p4.family_p.clone()]));
            let answered_p5 = crate::check::types::Rw { fams_p: crate::prelude::Array::from(vec![tg_p4.family_p.clone()]), minus_p: crate::prelude::Array::new(), tail_p: rw_p6.tail_p.clone() };
            let (out_p8, st3_p9) = crate::check::types::schemes::instantiate_f(&st2_p7, &crate::check::types::Scheme { qs_p: tg_p4.qs_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: tg_p4.rqs_p.clone(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: tg_p4.bounds_p.clone(), eqs_p: crate::prelude::Array::new(), ty_p: tg_p4.out_p.clone() }, span_p3);
            (crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, crate::prelude::Array::from(vec![crate::check::types::answer_of_output_f(&out_p8)]), ::std::rc::Rc::new(crate::check::types::answer_type_f(&answered_p5))), st3_p9.clone())
        },
    }
}

/// The step machine of `AnswerConstructor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerConstructor: unbounded fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub struct AnswerConstructor {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub name_p2: crate::prelude::Text,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for AnswerConstructor {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let name_p2 = &self.name_p2;
        let span_p3 = &self.span_p3;
        match crate::prelude::get(&env_p0.g_p.tags_p, name_p2) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), span_p3, &crate::prelude::Text::from(format!("no tag `{}`", name_p2))))),
            ::std::option::Option::Some(tg_p4) => {
                let (rw_p6, st2_p7) = crate::check::types::recording::fresh_row_f(st_p1, &crate::prelude::Array::from(vec![tg_p4.family_p.clone()]));
                let answered_p5 = crate::check::types::Rw { fams_p: crate::prelude::Array::from(vec![tg_p4.family_p.clone()]), minus_p: crate::prelude::Array::new(), tail_p: rw_p6.tail_p.clone() };
                let span_p3x = span_p3.clone();
                crate::prelude::call_then(crate::check::types::schemes::start_instantiate_f(st2_p7.clone(), crate::check::types::Scheme { qs_p: tg_p4.qs_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: tg_p4.rqs_p.clone(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: tg_p4.bounds_p.clone(), eqs_p: crate::prelude::Array::new(), ty_p: tg_p4.out_p.clone() }, span_p3x.clone()), move |instantiate_f_19230: (crate::check::types::Ty, crate::check::types::St)| {
                    let (out_p8, st3_p9) = instantiate_f_19230;
                    ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, crate::prelude::Array::from(vec![crate::check::types::answer_of_output_f(&out_p8)]), ::std::rc::Rc::new(crate::check::types::answer_type_f(&answered_p5))), st3_p9.clone()))
                })
            },
        }
    }
}

/// `Start AnswerConstructor, x`: what the function value is when passed to `@Run`.
pub fn start_answer_constructor_f(env_p0: Env, st_p1: crate::check::types::St, name_p2: crate::prelude::Text, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(AnswerConstructor { env_p0, st_p1, name_p2, span_p3 })
}

/// ```prism
/// InferBound: fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub fn infer_bound_f(env_p0: &Env, st_p1: &crate::check::types::St, b_p2: &crate::prelude::Text, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::prelude::get(&env_p0.locals_p, b_p2) {
        ::std::option::Option::Some(sc_p4) => (sc_p4.ty_p.clone(), st_p1.clone()),
        ::std::option::Option::None => if b_p2 == &crate::prelude::Text::lit("key") {
            (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), span_p3, &crate::prelude::Text::lit("`key` is bound only in a loop over a map")))
        } else {
            if b_p2 == &crate::prelude::Text::lit("ix") {
                (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), span_p3, &crate::prelude::Text::lit("`ix` outside a loop: it names the index of the `for` it stands in")))
            } else {
                if b_p2 == &crate::prelude::Text::lit("jx") {
                    (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), span_p3, &crate::prelude::Text::lit("`jx` outside two loops: it names the index of the `for` around the one it stands in")))
                } else {
                    (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), span_p3, &crate::prelude::Text::from(format!("`{}` outside three loops: it names the index of the `for` two around the one it stands in", b_p2))))
                }
            }
        },
    }
}

/// ```prism
/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
/// ```
pub fn infer_lit_f(env_p0: &Env, st_p1: &crate::check::types::St, l_p2: &crate::syntax::Literal, negative_p3: &bool, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let sigils_p5 = crate::syntax::lexer::chars::fold_chars_f(&l_p2.marks_p, &crate::prelude::Text::lit(""), &(::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Text, crate::prelude::Text)| crate::prelude::once_job(move || {
        let acc_p7 = p0;
        let c_p8 = p1;
        if crate::check::types::unify::is_mark_char_f(&c_p8) {
            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}", &acc_p7, &c_p8)))
        } else {
            ::prism_rtl::Turn::Finished(acc_p7.clone())
        }
    })) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>));
    let signed_p6 = *negative_p3 || crate::syntax::lexer::chars::contains_f(&l_p2.marks_p, &crate::prelude::Text::lit("-"));
    let (base_ph, st2_pi) = match &l_p2.kind_p {
        crate::syntax::LitKind::LInt(digits_p9) => {
            let (v_pd, s1_pe) = crate::check::types::fresh_var_f(st_p1, &true, &crate::prelude::Text::lit(""));
            let s2_pa = add_want_f(&s1_pe, &crate::prelude::Text::lit("Prelude.Num"), &v_pd, span_p4);
            let s3_pb = if signed_p6 {
                add_want_f(&s2_pa, &crate::prelude::Text::lit("Prelude.Signed"), &v_pd, span_p4)
            } else {
                s2_pa.clone()
            };
            let s4_pc = add_range_f(&s3_pb, &v_pd, digits_p9, &signed_p6, span_p4);
            (v_pd.clone(), s4_pc.clone())
        },
        crate::syntax::LitKind::LFloat(_) => (crate::check::types::t_float_p(), st_p1.clone()),
        crate::syntax::LitKind::LDuration(_, _) => (crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Duration"), crate::prelude::Array::new()), st_p1.clone()),
        crate::syntax::LitKind::LChar(_) => (crate::check::types::t_char_p(), st_p1.clone()),
        crate::syntax::LitKind::LText(segs_pf) => infer_text_f(env_p0, st_p1, segs_pf, &crate::syntax::lexer::chars::contains_f(&sigils_p5, &crate::prelude::Text::lit("$")), span_p4),
        crate::syntax::LitKind::LRegex(r_pg) => infer_regex_f(st_p1, r_pg),
    };
    if crate::syntax::lexer::chars::contains_f(&sigils_p5, &crate::prelude::Text::lit("$")) && (&crate::check::types::head_sigil_f(&st2_pi, &base_ph) == &crate::prelude::Text::lit("$")) {
        (base_ph.clone(), st2_pi.clone())
    } else {
        if crate::syntax::lexer::chars::contains_f(&sigils_p5, &crate::prelude::Text::lit("$")) {
            (crate::check::types::with_marks_f(&sigils_p5, &base_ph, &env_p0.scope_p), crate::check::types::recording::note_app_f(&st2_pi, span_p4, &crate::prelude::Text::lit("$"), &crate::prelude::Text::lit("const"), &crate::prelude::Text::lit("$"), &crate::prelude::Array::new(), &crate::prelude::Text::lit(""), &crate::check::types::Col::CBound))
        } else {
            (crate::check::types::with_marks_f(&sigils_p5, &base_ph, &env_p0.scope_p), st2_pi.clone())
        }
    }
}

/// The step machine of `InferLit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
/// ```
pub struct InferLit {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub l_p2: crate::syntax::Literal,
    pub negative_p3: bool,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferLit {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let l_p2 = &self.l_p2;
        let negative_p3 = &self.negative_p3;
        let span_p4 = &self.span_p4;
        let env_p0x = env_p0.clone();
        let l_p2x = l_p2.clone();
        let negative_p3x = *negative_p3;
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::syntax::lexer::chars::start_fold_chars_f(l_p2x.marks_p.clone(), crate::prelude::Text::lit(""), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Text, crate::prelude::Text)| crate::prelude::once_job(move || {
            let acc_p7 = p0;
            let c_p8 = p1;
            if crate::check::types::unify::is_mark_char_f(&c_p8) {
                ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}", &acc_p7, &c_p8)))
            } else {
                ::prism_rtl::Turn::Finished(acc_p7.clone())
            }
        })) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |fold_chars_f_20789: crate::prelude::Text| {
            let sigils_p5 = fold_chars_f_20789;
            let signed_p6 = negative_p3x || crate::syntax::lexer::chars::contains_f(&l_p2x.marks_p, &crate::prelude::Text::lit("-"));
            let env_p0xz = env_p0x.clone();
            let sigils_p5z = sigils_p5.clone();
            let span_p4xz = span_p4x.clone();
            let k_let20917 = move |v20917: (crate::check::types::Ty, crate::check::types::St)| {
                let (base_ph, st2_pi) = v20917;
                if crate::syntax::lexer::chars::contains_f(&sigils_p5z, &crate::prelude::Text::lit("$")) && (&crate::check::types::head_sigil_f(&st2_pi, &base_ph) == &crate::prelude::Text::lit("$")) {
                    ::prism_rtl::Turn::Finished((base_ph.clone(), st2_pi.clone()))
                } else {
                    if crate::syntax::lexer::chars::contains_f(&sigils_p5z, &crate::prelude::Text::lit("$")) {
                        ::prism_rtl::Turn::Finished((crate::check::types::with_marks_f(&sigils_p5z, &base_ph, &env_p0xz.scope_p), crate::check::types::recording::note_app_f(&st2_pi, &span_p4xz, &crate::prelude::Text::lit("$"), &crate::prelude::Text::lit("const"), &crate::prelude::Text::lit("$"), &crate::prelude::Array::new(), &crate::prelude::Text::lit(""), &crate::check::types::Col::CBound)))
                    } else {
                        ::prism_rtl::Turn::Finished((crate::check::types::with_marks_f(&sigils_p5z, &base_ph, &env_p0xz.scope_p), st2_pi.clone()))
                    }
                }
            };
            match l_p2x.kind_p.clone() {
                crate::syntax::LitKind::LInt(digits_p9) => {
                    let (v_pd, s1_pe) = crate::check::types::fresh_var_f(&st_p1x, &true, &crate::prelude::Text::lit(""));
                    let s2_pa = add_want_f(&s1_pe, &crate::prelude::Text::lit("Prelude.Num"), &v_pd, &span_p4x);
                    let s3_pb = if signed_p6 {
                        add_want_f(&s2_pa, &crate::prelude::Text::lit("Prelude.Signed"), &v_pd, &span_p4x)
                    } else {
                        s2_pa.clone()
                    };
                    let s4_pc = add_range_f(&s3_pb, &v_pd, &digits_p9, &signed_p6, &span_p4x);
                    k_let20917((v_pd.clone(), s4_pc.clone()))
                },
                crate::syntax::LitKind::LFloat(_) => k_let20917((crate::check::types::t_float_p(), st_p1x.clone())),
                crate::syntax::LitKind::LDuration(_, _) => k_let20917((crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Duration"), crate::prelude::Array::new()), st_p1x.clone())),
                crate::syntax::LitKind::LChar(_) => k_let20917((crate::check::types::t_char_p(), st_p1x.clone())),
                crate::syntax::LitKind::LText(segs_pf) => crate::prelude::call_then(start_infer_text_f(env_p0x.clone(), st_p1x.clone(), segs_pf.clone(), crate::syntax::lexer::chars::contains_f(&sigils_p5, &crate::prelude::Text::lit("$")), span_p4x.clone()), move |infer_text_f_21398: (crate::check::types::Ty, crate::check::types::St)| k_let20917(infer_text_f_21398)),
                crate::syntax::LitKind::LRegex(r_pg) => crate::prelude::call_then(start_infer_regex_f(st_p1x.clone(), r_pg.clone()), move |infer_regex_f_21470: (crate::check::types::Ty, crate::check::types::St)| k_let20917(infer_regex_f_21470)),
            }
        })
    }
}

/// `Start InferLit, x`: what the function value is when passed to `@Run`.
pub fn start_infer_lit_f(env_p0: Env, st_p1: crate::check::types::St, l_p2: crate::syntax::Literal, negative_p3: bool, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferLit { env_p0, st_p1, l_p2, negative_p3, span_p4 })
}

/// ```prism
/// InferRegex: unbounded fn St, RegexLit -> ((Ty, St))
/// ```
pub fn infer_regex_f(st_p0: &crate::check::types::St, r_p1: &crate::syntax::RegexLit) -> (crate::check::types::Ty, crate::check::types::St) {
    let t_p2 = crate::check::types::Ty::TyCon(if &r_p1.replacement_o == &::std::option::Option::None {
        crate::prelude::Text::lit("Regex")
    } else {
        crate::prelude::Text::lit("RegexReplacement")
    }, crate::prelude::Array::new());
    match crate::check::regex::regex_refusal_o(&r_p1.pattern_p, &r_p1.flags_p, &r_p1.replacement_o) {
        ::std::option::Option::None => (t_p2.clone(), st_p0.clone()),
        ::std::option::Option::Some(d_p3) => {
            let (base_p6, text_p7) = if &d_p3.part_p == &crate::prelude::Text::lit("flags") {
                (r_p1.flags_at_p.clone(), r_p1.flags_p.clone())
            } else {
                if &d_p3.part_p == &crate::prelude::Text::lit("pattern") {
                    (r_p1.pattern_at_p.clone(), r_p1.pattern_p.clone())
                } else {
                    (r_p1.replacement_at_p.clone(), crate::prelude::or(&r_p1.replacement_o, &crate::prelude::Text::lit("")))
                }
            };
            let start_p4 = &base_p6 + &d_p3.at_p;
            let span_p5 = crate::syntax::Range { start_p: start_p4.clone(), end_p: &start_p4 + &crate::prelude::max(&crate::prelude::len_text(&crate::check::regex::rx_char_at_f(&text_p7, &d_p3.at_p)), &crate::prelude::Nat::from(1u32)) };
            if &d_p3.message_p == &crate::check::regex::rx_unknown_flag_p() {
                (t_p2.clone(), crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("regex"), &span_p5, &d_p3.message_p, &crate::prelude::Text::lit("a replacement that starts with letters and holds anything but letters is written in the hashed form, `%#/x/#hello world/#`")))
            } else {
                (t_p2.clone(), crate::check::types::recording::err_f(st_p0, &crate::prelude::Text::lit("regex"), &span_p5, &d_p3.message_p))
            }
        },
    }
}

/// The step machine of `InferRegex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferRegex: unbounded fn St, RegexLit -> ((Ty, St))
/// ```
pub struct InferRegex {
    pub st_p0: crate::check::types::St,
    pub r_p1: crate::syntax::RegexLit,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferRegex {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let r_p1 = &self.r_p1;
        let t_p2 = crate::check::types::Ty::TyCon(if &r_p1.replacement_o == &::std::option::Option::None {
            crate::prelude::Text::lit("Regex")
        } else {
            crate::prelude::Text::lit("RegexReplacement")
        }, crate::prelude::Array::new());
        let r_p1x = r_p1.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(crate::check::regex::start_regex_refusal_o(r_p1x.pattern_p.clone(), r_p1x.flags_p.clone(), r_p1x.replacement_o.clone()), move |regex_refusal_o_22261: ::std::option::Option<crate::check::regex::RxDiag>| match regex_refusal_o_22261 {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((t_p2.clone(), st_p0x.clone())),
            ::std::option::Option::Some(d_p3) => {
                let (base_p6, text_p7) = if &d_p3.part_p == &crate::prelude::Text::lit("flags") {
                    (r_p1x.flags_at_p.clone(), r_p1x.flags_p.clone())
                } else {
                    if &d_p3.part_p == &crate::prelude::Text::lit("pattern") {
                        (r_p1x.pattern_at_p.clone(), r_p1x.pattern_p.clone())
                    } else {
                        (r_p1x.replacement_at_p.clone(), crate::prelude::or(&r_p1x.replacement_o, &crate::prelude::Text::lit("")))
                    }
                };
                let start_p4 = &base_p6 + &d_p3.at_p;
                let span_p5 = crate::syntax::Range { start_p: start_p4.clone(), end_p: &start_p4 + &crate::prelude::max(&crate::prelude::len_text(&crate::check::regex::rx_char_at_f(&text_p7, &d_p3.at_p)), &crate::prelude::Nat::from(1u32)) };
                if &d_p3.message_p == &crate::check::regex::rx_unknown_flag_p() {
                    ::prism_rtl::Turn::Finished((t_p2.clone(), crate::check::types::recording::err_fix_f(&st_p0x, &crate::prelude::Text::lit("regex"), &span_p5, &d_p3.message_p, &crate::prelude::Text::lit("a replacement that starts with letters and holds anything but letters is written in the hashed form, `%#/x/#hello world/#`"))))
                } else {
                    ::prism_rtl::Turn::Finished((t_p2.clone(), crate::check::types::recording::err_f(&st_p0x, &crate::prelude::Text::lit("regex"), &span_p5, &d_p3.message_p)))
                }
            },
        })
    }
}

/// `Start InferRegex, x`: what the function value is when passed to `@Run`.
pub fn start_infer_regex_f(st_p0: crate::check::types::St, r_p1: crate::syntax::RegexLit) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferRegex { st_p0, r_p1 })
}

/// ```prism
/// AddRange: fn St, Ty, Text, Bool, Range -> St
/// ```
pub fn add_range_f(st_p0: &crate::check::types::St, v_p1: &crate::check::types::Ty, digits_p2: &crate::prelude::Text, signed_p3: &bool, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.wants_p = crate::prelude::push(&this.wants_p, &crate::check::types::Want { cls_p: crate::prelude::Text::from(format!("Range {}{}", &(if *signed_p3 { crate::prelude::Text::lit("-") } else { crate::prelude::Text::lit("") }), digits_p2)), ty_p: v_p1.clone(), file_p: this.file_p.clone(), span_p: span_p4.clone(), level_p: this.level_p.clone() });
    this
}

/// ```prism
/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
/// ```
pub fn infer_text_f(env_p0: &Env, st_p1: &crate::check::types::St, segs_p2: &crate::prelude::Array<crate::syntax::TextSeg>, dollar_p3: &bool, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let holes_p5 = crate::prelude::fold(segs_p2, &crate::prelude::Array::new(), &(|acc_p6: &crate::prelude::Array<crate::syntax::Expr>, sg_p7: &crate::syntax::TextSeg| match sg_p7 {
        crate::syntax::TextSeg::SegPlaceholder(x_p8) => crate::prelude::push(acc_p6, x_p8),
        _ => acc_p6.clone(),
    }));
    if &crate::prelude::len(&holes_p5) == &crate::prelude::Nat::from(0u32) {
        (crate::check::types::t_text_p(), st_p1.clone())
    } else {
        {
            let (events_p15, dyns_p16, opts_p17, st2_p18, lifted_p19, opt_holes_p1a) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&holes_p5)), (crate::prelude::Array::new(), crate::prelude::Int::from(0), crate::prelude::Array::new(), st_p1.clone(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
                let holes_p5x = holes_p5.clone();
                let span_p4x = span_p4.clone();
                let env_p0x = env_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::syntax::Range>, crate::prelude::Int, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<crate::syntax::Range>), crate::prelude::Nat)| {
                    let holes_p5xy = holes_p5x.clone();
                    let span_p4xy = span_p4x.clone();
                    let env_p0xy = env_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (ev_pg, dy_ph, op_pi, s_pj, li_pk, oh_pl) = p0;
                        let hi_pm = p1;
                        {
                            let x_pn = crate::prelude::or(&crate::prelude::index(&holes_p5xy, &hi_pm), &crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p4xy.clone() });
                            crate::prelude::call_then(start_infer_f(env_p0xy.clone(), s_pj.clone(), x_pn.clone()), move |infer_f_23976: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t_p13, s2_p14) = infer_f_23976;
                                crate::prelude::call_then(crate::check::types::start_head_sigil_f(s2_p14.clone(), t_p13.clone()), move |head_sigil_f_24015: crate::prelude::Text| {
                                    let head_po = head_sigil_f_24015;
                                    let dy_phz = dy_ph.clone();
                                    let ev_pgz = ev_pg.clone();
                                    let head_poz = head_po.clone();
                                    let hi_pmz = hi_pm.clone();
                                    let li_pkz = li_pk.clone();
                                    let oh_plz = oh_pl.clone();
                                    let op_piz = op_pi.clone();
                                    let s2_p14z = s2_p14.clone();
                                    let x_pnz = x_pn.clone();
                                    let k_let24043 = move |v24043: crate::check::types::Ty| {
                                        let inner_pp = v24043;
                                        crate::prelude::call_then(crate::check::types::start_head_sigil_f(s2_p14z.clone(), inner_pp.clone()), move |head_sigil_f_24119: crate::prelude::Text| {
                                            let ih_pq = head_sigil_f_24119;
                                            let dy_phzz = dy_phz.clone();
                                            let ev_pgzz = ev_pgz.clone();
                                            let head_pozz = head_poz.clone();
                                            let hi_pmzz = hi_pmz.clone();
                                            let ih_pqz = ih_pq.clone();
                                            let li_pkzz = li_pkz.clone();
                                            let oh_plzz = oh_plz.clone();
                                            let op_pizz = op_piz.clone();
                                            let s2_p14zz = s2_p14z.clone();
                                            let x_pnzz = x_pnz.clone();
                                            let k_let24151 = move |v24151: crate::check::types::Ty| {
                                                let plain_t_pr = v24151;
                                                let s3_ps = if &head_pozz == &crate::prelude::Text::lit("@") {
                                                    crate::check::types::recording::err_f(&s2_p14zz, &crate::prelude::Text::lit("blueprint-operand"), &x_pnzz.span_p, &crate::prelude::Text::lit("a text over a blueprint; bind it first"))
                                                } else {
                                                    s2_p14zz.clone()
                                                };
                                                crate::prelude::call_then(start_show_want_f(s3_ps.clone(), plain_t_pr.clone(), x_pnzz.span_p.clone()), move |show_want_f_24359: crate::check::types::St| {
                                                    let s4_pt = show_want_f_24359;
                                                    let ev2_pu = if &head_pozz == &crate::prelude::Text::lit("!") {
                                                        crate::prelude::push(&ev_pgzz, &x_pnzz.span_p)
                                                    } else {
                                                        ev_pgzz.clone()
                                                    };
                                                    let dy2_pv = if &head_pozz == &crate::prelude::Text::lit("$") {
                                                        &dy_phzz + &crate::prelude::Int::from(1)
                                                    } else {
                                                        dy_phzz.clone()
                                                    };
                                                    let op2_p10 = if is_plain_sigil_f(&ih_pqz) {
                                                        crate::check::types::add_text_f(&op_pizz, &ih_pqz)
                                                    } else {
                                                        op_pizz.clone()
                                                    };
                                                    let li2_p11 = if is_time_sigil_f(&head_pozz) {
                                                        crate::prelude::push(&li_pkzz, &hi_pmzz)
                                                    } else {
                                                        li_pkzz.clone()
                                                    };
                                                    let oh2_p12 = if is_plain_sigil_f(&ih_pqz) {
                                                        crate::prelude::push(&oh_plzz, &x_pnzz.span_p)
                                                    } else {
                                                        oh_plzz.clone()
                                                    };
                                                    ::prism_rtl::Turn::Finished((ev2_pu.clone(), dy2_pv.clone(), op2_p10.clone(), s4_pt.clone(), li2_p11.clone(), oh2_p12.clone()))
                                                })
                                            };
                                            if is_plain_sigil_f(&ih_pq) {
                                                crate::prelude::call_then(start_inner_of_f(s2_p14z.clone(), inner_pp.clone()), move |inner_of_f_24184: crate::check::types::Ty| k_let24151(inner_of_f_24184))
                                            } else {
                                                k_let24151(inner_pp.clone())
                                            }
                                        })
                                    };
                                    if is_time_sigil_f(&head_po) {
                                        crate::prelude::call_then(start_inner_of_f(s2_p14.clone(), t_p13.clone()), move |inner_of_f_24076: crate::check::types::Ty| k_let24043(inner_of_f_24076))
                                    } else {
                                        k_let24043(t_p13.clone())
                                    }
                                })
                            })
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::syntax::Range>, crate::prelude::Int, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<crate::syntax::Range>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Range>, crate::prelude::Int, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<crate::syntax::Range>)>>>
            }));
            let st3_p9 = if *dollar_p3 && (&crate::prelude::len(&events_p15) > &crate::prelude::Nat::from(0u32)) {
                crate::check::types::recording::err_f(&st2_p18, &crate::prelude::Text::lit("event-in-text"), &crate::prelude::or(&crate::prelude::index(&events_p15, &crate::prelude::Nat::from(0u32)), span_p4), &crate::prelude::Text::lit("an event in a dynamic text"))
            } else {
                if &crate::prelude::len(&events_p15) > &crate::prelude::Nat::from(1u32) {
                    crate::check::types::recording::err_fix_f(&st2_p18, &crate::prelude::Text::lit("two-events"), &crate::prelude::or(&crate::prelude::index(&events_p15, &crate::prelude::Nat::from(1u32)), span_p4), &crate::prelude::Text::lit("two events in one operation"), &crate::prelude::Text::lit("merge them with `<|`, or hold one first"))
                } else {
                    st2_p18.clone()
                }
            };
            let st4_pa = if &crate::prelude::len(&opts_p17) > &crate::prelude::Nat::from(1u32) {
                crate::check::types::recording::err_f(&st3_p9, &crate::prelude::Text::lit("optional-and-fault"), span_p4, &crate::prelude::Text::lit("`?` and `~` in one operation"))
            } else {
                st3_p9.clone()
            };
            let with_opt_pb = match crate::prelude::index(&opts_p17, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(o_p1b) => crate::check::types::Ty::TySig(o_p1b, ::std::rc::Rc::new(crate::check::types::t_text_p())),
                ::std::option::Option::None => crate::check::types::t_text_p(),
            };
            let layer_pc = if (&crate::prelude::len(&events_p15) > &crate::prelude::Nat::from(0u32)) && !*dollar_p3 {
                crate::prelude::Text::lit("!")
            } else {
                if (&dyns_p16 > &crate::prelude::Int::from(0)) || *dollar_p3 {
                    crate::prelude::Text::lit("$")
                } else {
                    crate::prelude::Text::lit("")
                }
            };
            let res_pd = if &layer_pc == &crate::prelude::Text::lit("") {
                with_opt_pb.clone()
            } else {
                crate::check::types::Ty::TySig(layer_pc.clone(), ::std::rc::Rc::new(with_opt_pb.clone()))
            };
            let kind_pe = if &layer_pc == &crate::prelude::Text::lit("") {
                crate::prelude::Text::lit("plain")
            } else {
                if &crate::prelude::len(&lifted_p19) == &crate::prelude::Nat::from(0u32) {
                    crate::prelude::Text::lit("const")
                } else {
                    crate::prelude::Text::lit("map")
                }
            };
            let st5_pf = if &crate::prelude::len(&opts_p17) == &crate::prelude::Nat::from(1u32) {
                crate::check::types::recording::note_lift_f(&st4_pa, span_p4, &crate::prelude::or(&crate::prelude::index(&opts_p17, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), &opt_holes_p1a)
            } else {
                st4_pa.clone()
            };
            (res_pd.clone(), crate::check::types::recording::note_app_f(&st5_pf, span_p4, &crate::prelude::Text::lit("text"), &kind_pe, &layer_pc, &lifted_p19, &crate::prelude::or(&crate::prelude::index(&opts_p17, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), &crate::check::types::Col::CBound))
        }
    }
}

/// The step machine of `InferText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
/// ```
pub struct InferText {
    pub env_p0: Env,
    pub st_p1: crate::check::types::St,
    pub segs_p2: crate::prelude::Array<crate::syntax::TextSeg>,
    pub dollar_p3: bool,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferText {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let segs_p2 = &self.segs_p2;
        let dollar_p3 = &self.dollar_p3;
        let span_p4 = &self.span_p4;
        let holes_p5 = crate::prelude::fold(segs_p2, &crate::prelude::Array::new(), &(|acc_p6: &crate::prelude::Array<crate::syntax::Expr>, sg_p7: &crate::syntax::TextSeg| match sg_p7 {
            crate::syntax::TextSeg::SegPlaceholder(x_p8) => crate::prelude::push(acc_p6, x_p8),
            _ => acc_p6.clone(),
        }));
        if &crate::prelude::len(&holes_p5) == &crate::prelude::Nat::from(0u32) {
            ::prism_rtl::Turn::Finished((crate::check::types::t_text_p(), st_p1.clone()))
        } else {
            {
                let dollar_p3x = *dollar_p3;
                let env_p0x = env_p0.clone();
                let span_p4x = span_p4.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&holes_p5)), (crate::prelude::Array::new(), crate::prelude::Int::from(0), crate::prelude::Array::new(), st_p1x.clone(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
                    let holes_p5x = holes_p5.clone();
                    let span_p4xx = span_p4x.clone();
                    let env_p0xx = env_p0x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::syntax::Range>, crate::prelude::Int, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<crate::syntax::Range>), crate::prelude::Nat)| {
                        let holes_p5xy = holes_p5x.clone();
                        let span_p4xxy = span_p4xx.clone();
                        let env_p0xxy = env_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (ev_pg, dy_ph, op_pi, s_pj, li_pk, oh_pl) = p0;
                            let hi_pm = p1;
                            {
                                let x_pn = crate::prelude::or(&crate::prelude::index(&holes_p5xy, &hi_pm), &crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p4xxy.clone() });
                                crate::prelude::call_then(start_infer_f(env_p0xxy.clone(), s_pj.clone(), x_pn.clone()), move |infer_f_23976: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (t_p13, s2_p14) = infer_f_23976;
                                    crate::prelude::call_then(crate::check::types::start_head_sigil_f(s2_p14.clone(), t_p13.clone()), move |head_sigil_f_24015: crate::prelude::Text| {
                                        let head_po = head_sigil_f_24015;
                                        let dy_phz = dy_ph.clone();
                                        let ev_pgz = ev_pg.clone();
                                        let head_poz = head_po.clone();
                                        let hi_pmz = hi_pm.clone();
                                        let li_pkz = li_pk.clone();
                                        let oh_plz = oh_pl.clone();
                                        let op_piz = op_pi.clone();
                                        let s2_p14z = s2_p14.clone();
                                        let x_pnz = x_pn.clone();
                                        let k_let24043 = move |v24043: crate::check::types::Ty| {
                                            let inner_pp = v24043;
                                            crate::prelude::call_then(crate::check::types::start_head_sigil_f(s2_p14z.clone(), inner_pp.clone()), move |head_sigil_f_24119: crate::prelude::Text| {
                                                let ih_pq = head_sigil_f_24119;
                                                let dy_phzz = dy_phz.clone();
                                                let ev_pgzz = ev_pgz.clone();
                                                let head_pozz = head_poz.clone();
                                                let hi_pmzz = hi_pmz.clone();
                                                let ih_pqz = ih_pq.clone();
                                                let li_pkzz = li_pkz.clone();
                                                let oh_plzz = oh_plz.clone();
                                                let op_pizz = op_piz.clone();
                                                let s2_p14zz = s2_p14z.clone();
                                                let x_pnzz = x_pnz.clone();
                                                let k_let24151 = move |v24151: crate::check::types::Ty| {
                                                    let plain_t_pr = v24151;
                                                    let s3_ps = if &head_pozz == &crate::prelude::Text::lit("@") {
                                                        crate::check::types::recording::err_f(&s2_p14zz, &crate::prelude::Text::lit("blueprint-operand"), &x_pnzz.span_p, &crate::prelude::Text::lit("a text over a blueprint; bind it first"))
                                                    } else {
                                                        s2_p14zz.clone()
                                                    };
                                                    crate::prelude::call_then(start_show_want_f(s3_ps.clone(), plain_t_pr.clone(), x_pnzz.span_p.clone()), move |show_want_f_24359: crate::check::types::St| {
                                                        let s4_pt = show_want_f_24359;
                                                        let ev2_pu = if &head_pozz == &crate::prelude::Text::lit("!") {
                                                            crate::prelude::push(&ev_pgzz, &x_pnzz.span_p)
                                                        } else {
                                                            ev_pgzz.clone()
                                                        };
                                                        let dy2_pv = if &head_pozz == &crate::prelude::Text::lit("$") {
                                                            &dy_phzz + &crate::prelude::Int::from(1)
                                                        } else {
                                                            dy_phzz.clone()
                                                        };
                                                        let op2_p10 = if is_plain_sigil_f(&ih_pqz) {
                                                            crate::check::types::add_text_f(&op_pizz, &ih_pqz)
                                                        } else {
                                                            op_pizz.clone()
                                                        };
                                                        let li2_p11 = if is_time_sigil_f(&head_pozz) {
                                                            crate::prelude::push(&li_pkzz, &hi_pmzz)
                                                        } else {
                                                            li_pkzz.clone()
                                                        };
                                                        let oh2_p12 = if is_plain_sigil_f(&ih_pqz) {
                                                            crate::prelude::push(&oh_plzz, &x_pnzz.span_p)
                                                        } else {
                                                            oh_plzz.clone()
                                                        };
                                                        ::prism_rtl::Turn::Finished((ev2_pu.clone(), dy2_pv.clone(), op2_p10.clone(), s4_pt.clone(), li2_p11.clone(), oh2_p12.clone()))
                                                    })
                                                };
                                                if is_plain_sigil_f(&ih_pq) {
                                                    crate::prelude::call_then(start_inner_of_f(s2_p14z.clone(), inner_pp.clone()), move |inner_of_f_24184: crate::check::types::Ty| k_let24151(inner_of_f_24184))
                                                } else {
                                                    k_let24151(inner_pp.clone())
                                                }
                                            })
                                        };
                                        if is_time_sigil_f(&head_po) {
                                            crate::prelude::call_then(start_inner_of_f(s2_p14.clone(), t_p13.clone()), move |inner_of_f_24076: crate::check::types::Ty| k_let24043(inner_of_f_24076))
                                        } else {
                                            k_let24043(t_p13.clone())
                                        }
                                    })
                                })
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::syntax::Range>, crate::prelude::Int, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<crate::syntax::Range>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Range>, crate::prelude::Int, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<crate::syntax::Range>)>>>
                }), move |fold_23790: (crate::prelude::Array<crate::syntax::Range>, crate::prelude::Int, crate::prelude::Array<crate::prelude::Text>, crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<crate::syntax::Range>)| {
                    let (events_p15, dyns_p16, opts_p17, st2_p18, lifted_p19, opt_holes_p1a) = fold_23790;
                    let st3_p9 = if dollar_p3x && (&crate::prelude::len(&events_p15) > &crate::prelude::Nat::from(0u32)) {
                        crate::check::types::recording::err_f(&st2_p18, &crate::prelude::Text::lit("event-in-text"), &crate::prelude::or(&crate::prelude::index(&events_p15, &crate::prelude::Nat::from(0u32)), &span_p4x), &crate::prelude::Text::lit("an event in a dynamic text"))
                    } else {
                        if &crate::prelude::len(&events_p15) > &crate::prelude::Nat::from(1u32) {
                            crate::check::types::recording::err_fix_f(&st2_p18, &crate::prelude::Text::lit("two-events"), &crate::prelude::or(&crate::prelude::index(&events_p15, &crate::prelude::Nat::from(1u32)), &span_p4x), &crate::prelude::Text::lit("two events in one operation"), &crate::prelude::Text::lit("merge them with `<|`, or hold one first"))
                        } else {
                            st2_p18.clone()
                        }
                    };
                    let st4_pa = if &crate::prelude::len(&opts_p17) > &crate::prelude::Nat::from(1u32) {
                        crate::check::types::recording::err_f(&st3_p9, &crate::prelude::Text::lit("optional-and-fault"), &span_p4x, &crate::prelude::Text::lit("`?` and `~` in one operation"))
                    } else {
                        st3_p9.clone()
                    };
                    let with_opt_pb = match crate::prelude::index(&opts_p17, &crate::prelude::Nat::from(0u32)) {
                        ::std::option::Option::Some(o_p1b) => crate::check::types::Ty::TySig(o_p1b, ::std::rc::Rc::new(crate::check::types::t_text_p())),
                        ::std::option::Option::None => crate::check::types::t_text_p(),
                    };
                    let layer_pc = if (&crate::prelude::len(&events_p15) > &crate::prelude::Nat::from(0u32)) && !dollar_p3x {
                        crate::prelude::Text::lit("!")
                    } else {
                        if (&dyns_p16 > &crate::prelude::Int::from(0)) || dollar_p3x {
                            crate::prelude::Text::lit("$")
                        } else {
                            crate::prelude::Text::lit("")
                        }
                    };
                    let res_pd = if &layer_pc == &crate::prelude::Text::lit("") {
                        with_opt_pb.clone()
                    } else {
                        crate::check::types::Ty::TySig(layer_pc.clone(), ::std::rc::Rc::new(with_opt_pb.clone()))
                    };
                    let kind_pe = if &layer_pc == &crate::prelude::Text::lit("") {
                        crate::prelude::Text::lit("plain")
                    } else {
                        if &crate::prelude::len(&lifted_p19) == &crate::prelude::Nat::from(0u32) {
                            crate::prelude::Text::lit("const")
                        } else {
                            crate::prelude::Text::lit("map")
                        }
                    };
                    let st5_pf = if &crate::prelude::len(&opts_p17) == &crate::prelude::Nat::from(1u32) {
                        crate::check::types::recording::note_lift_f(&st4_pa, &span_p4x, &crate::prelude::or(&crate::prelude::index(&opts_p17, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), &opt_holes_p1a)
                    } else {
                        st4_pa.clone()
                    };
                    ::prism_rtl::Turn::Finished((res_pd.clone(), crate::check::types::recording::note_app_f(&st5_pf, &span_p4x, &crate::prelude::Text::lit("text"), &kind_pe, &layer_pc, &lifted_p19, &crate::prelude::or(&crate::prelude::index(&opts_p17, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), &crate::check::types::Col::CBound)))
                })
            }
        }
    }
}

/// `Start InferText, x`: what the function value is when passed to `@Run`.
pub fn start_infer_text_f(env_p0: Env, st_p1: crate::check::types::St, segs_p2: crate::prelude::Array<crate::syntax::TextSeg>, dollar_p3: bool, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferText { env_p0, st_p1, segs_p2, dollar_p3, span_p4 })
}

/// ```prism
/// ShowWant: unbounded fn St, Ty, Range -> St
/// ```
pub fn show_want_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TyCon(m25997_0_0, m25997_0_1) if (&m25997_0_0 == &crate::prelude::Text::lit("Text")) && ((&m25997_0_1).len() == 0) => st_p0.clone(),
        other_p3 => add_want_f(st_p0, &crate::prelude::Text::lit("Prelude.Show"), &other_p3, span_p2),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ShowWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowWant: unbounded fn St, Ty, Range -> St
/// ```
pub struct ShowWant {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub span_p2: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for ShowWant {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let span_p2 = &self.span_p2;
        let span_p2x = span_p2.clone();
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_26003: crate::check::types::Ty| match walk_f_26003 {
            crate::check::types::Ty::TyCon(m25997_0_0, m25997_0_1) if (&m25997_0_0 == &crate::prelude::Text::lit("Text")) && ((&m25997_0_1).len() == 0) => ::prism_rtl::Turn::Finished(st_p0x.clone()),
            other_p3 => ::prism_rtl::Turn::Finished(add_want_f(&st_p0x, &crate::prelude::Text::lit("Prelude.Show"), &other_p3, &span_p2x)),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start ShowWant, x`: what the function value is when passed to `@Run`.
pub fn start_show_want_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty, span_p2: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(ShowWant { st_p0, t_p1, span_p2 })
}
