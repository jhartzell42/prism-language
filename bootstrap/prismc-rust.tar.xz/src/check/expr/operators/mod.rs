//! The module `Check.Expr.Operators`, from `target/bootstrap/src/prismc/check/expr/operators.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
/// ```
pub fn infer_array_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, es_p2: &crate::prelude::Array<crate::syntax::Expr>, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (v_p6, st2_p7) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
    let (st3_pd, plain_pe) = crate::prelude::run_to_end(crate::prelude::fold_job(es_p2.clone(), (st2_p7.clone(), false), {
        let env_p0x = env_p0.clone();
        let v_p6x = v_p6.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::types::St, bool), crate::syntax::Expr)| {
            let env_p0xy = env_p0x.clone();
            let v_p6xy = v_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (s_p8, seen_p9) = p0;
                let x_pa = p1;
                crate::prelude::call_then(start_check_entry_f(env_p0xy.clone(), s_p8.clone(), x_pa.clone(), v_p6xy.clone()), move |check_entry_f_1559: (crate::check::types::St, bool)| {
                    let (s2_pb, beside_pc) = check_entry_f_1559;
                    ::prism_rtl::Turn::Finished((s2_pb.clone(), seen_p9 || beside_pc))
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::types::St, bool), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::St, bool)>>>
    }));
    let entry_p4 = if plain_pe {
        crate::prelude::or(&crate::check::types::non_empty_coll_o(&st3_pd, &v_p6), &v_p6)
    } else {
        v_p6.clone()
    };
    let st4_p5 = if plain_pe {
        crate::prelude::fold(es_p2, &st3_pd, &(|s_pf: &crate::check::types::St, x_pg: &crate::syntax::Expr| crate::check::types::recording::ask_plain_at_f(s_pf, &x_pg.span_p, &entry_p4)))
    } else {
        st3_pd.clone()
    };
    (crate::check::types::Ty::TyArray(::std::rc::Rc::new(entry_p4.clone())), st4_p5.clone())
}

/// The step machine of `InferArray`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
/// ```
pub struct InferArray {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub es_p2: crate::prelude::Array<crate::syntax::Expr>,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferArray {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let es_p2 = &self.es_p2;
        let span_p3 = &self.span_p3;
        let (v_p6, st2_p7) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
        let env_p0x = env_p0.clone();
        let es_p2x = es_p2.clone();
        crate::prelude::call_value(crate::prelude::fold_job(es_p2x.clone(), (st2_p7.clone(), false), {
            let env_p0xx = env_p0x.clone();
            let v_p6x = v_p6.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::check::types::St, bool), crate::syntax::Expr)| {
                let env_p0xxy = env_p0xx.clone();
                let v_p6xy = v_p6x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (s_p8, seen_p9) = p0;
                    let x_pa = p1;
                    crate::prelude::call_then(start_check_entry_f(env_p0xxy.clone(), s_p8.clone(), x_pa.clone(), v_p6xy.clone()), move |check_entry_f_1559: (crate::check::types::St, bool)| {
                        let (s2_pb, beside_pc) = check_entry_f_1559;
                        ::prism_rtl::Turn::Finished((s2_pb.clone(), seen_p9 || beside_pc))
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::types::St, bool), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::St, bool)>>>
        }), move |fold_1487: (crate::check::types::St, bool)| {
            let (st3_pd, plain_pe) = fold_1487;
            let es_p2xz = es_p2x.clone();
            let plain_pez = plain_pe;
            let st3_pdz = st3_pd.clone();
            let k_let1708 = move |v1708: crate::check::types::Ty| {
                let entry_p4 = v1708;
                let st4_p5 = if plain_pez {
                    crate::prelude::fold(&es_p2xz, &st3_pdz, &(|s_pf: &crate::check::types::St, x_pg: &crate::syntax::Expr| crate::check::types::recording::ask_plain_at_f(s_pf, &x_pg.span_p, &entry_p4)))
                } else {
                    st3_pdz.clone()
                };
                ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyArray(::std::rc::Rc::new(entry_p4.clone())), st4_p5.clone()))
            };
            if plain_pe {
                crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(st3_pd.clone(), v_p6.clone()), move |non_empty_coll_o_1734: ::std::option::Option<crate::check::types::Ty>| k_let1708(crate::prelude::or(&non_empty_coll_o_1734, &v_p6)))
            } else {
                k_let1708(v_p6.clone())
            }
        })
    }
}

/// `Start InferArray, x`: what the function value is when passed to `@Run`.
pub fn start_infer_array_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, es_p2: crate::prelude::Array<crate::syntax::Expr>, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferArray { env_p0, st_p1, es_p2, span_p3 })
}

/// ```prism
/// CheckEntry: unbounded fn Env, St, Expr, Ty -> ((St, Bool))
/// ```
pub fn check_entry_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, expected_p3: &crate::check::types::Ty) -> (crate::check::types::St, bool) {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::ELambda(_, _) => (crate::check::expr::check_f(env_p0, st_p1, e_p2, expected_p3), false),
        crate::syntax::ExprKind::EMatch(_, _) => (crate::check::expr::check_f(env_p0, st_p1, e_p2, expected_p3), false),
        crate::syntax::ExprKind::EIf(_, _, _) => (crate::check::expr::check_f(env_p0, st_p1, e_p2, expected_p3), false),
        crate::syntax::ExprKind::EAny(_) => (crate::check::expr::check_f(env_p0, st_p1, e_p2, expected_p3), false),
        crate::syntax::ExprKind::EGroup(x_p4) => {
            let (st2_p5, beside_p6) = check_entry_f(env_p0, st_p1, &**x_p4, expected_p3);
            (crate::check::types::recording::note_ty_f(&st2_p5, &e_p2.span_p, expected_p3), beside_p6)
        },
        _ => {
            let (t_p7, st2_p8) = crate::check::expr::infer_f(env_p0, st_p1, e_p2);
            match crate::check::types::non_empty_coll_o(&st2_p8, expected_p3) {
                ::std::option::Option::Some(c_p9) if crate::check::types::is_plain_collection_f(&st2_p8, &t_p7) => (crate::check::types::recording::unify_at_f(&st2_p8, &c_p9, &t_p7, &e_p2.span_p), true),
                _ => (crate::check::types::recording::unify_at_f(&st2_p8, expected_p3, &t_p7, &e_p2.span_p), false),
                _ => unreachable!("no arm matched"),
            }
        },
    }
}

/// The step machine of `CheckEntry`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckEntry: unbounded fn Env, St, Expr, Ty -> ((St, Bool))
/// ```
pub struct CheckEntry {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub expected_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<(crate::check::types::St, bool)> for CheckEntry {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::St, bool)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let expected_p3 = &self.expected_p3;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::ELambda(_, _) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_check_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone(), expected_p3x.clone()), move |check_f_2357: crate::check::types::St| ::prism_rtl::Turn::Finished((check_f_2357, false)))
            },
            crate::syntax::ExprKind::EMatch(_, _) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_check_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone(), expected_p3x.clone()), move |check_f_2424: crate::check::types::St| ::prism_rtl::Turn::Finished((check_f_2424, false)))
            },
            crate::syntax::ExprKind::EIf(_, _, _) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_check_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone(), expected_p3x.clone()), move |check_f_2496: crate::check::types::St| ::prism_rtl::Turn::Finished((check_f_2496, false)))
            },
            crate::syntax::ExprKind::EAny(_) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_check_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone(), expected_p3x.clone()), move |check_f_2553: crate::check::types::St| ::prism_rtl::Turn::Finished((check_f_2553, false)))
            },
            crate::syntax::ExprKind::EGroup(x_p4) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                let x_p4x = (**x_p4).clone();
                crate::prelude::call_then(start_check_entry_f(env_p0x.clone(), st_p1x.clone(), x_p4x.clone(), expected_p3x.clone()), move |check_entry_f_2634: (crate::check::types::St, bool)| {
                    let (st2_p5, beside_p6) = check_entry_f_2634;
                    ::prism_rtl::Turn::Finished((crate::check::types::recording::note_ty_f(&st2_p5, &e_p2x.span_p, &expected_p3x), beside_p6))
                })
            },
            _ => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let expected_p3x = expected_p3.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone()), move |infer_f_2757: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p7, st2_p8) = infer_f_2757;
                    crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(st2_p8.clone(), expected_p3x.clone()), move |non_empty_coll_o_2788: ::std::option::Option<crate::check::types::Ty>| match non_empty_coll_o_2788 {
                        ::std::option::Option::Some(c_p9) if crate::check::types::is_plain_collection_f(&st2_p8, &t_p7) => crate::prelude::call_then(crate::check::types::recording::start_unify_at_f(st2_p8.clone(), c_p9.clone(), t_p7.clone(), e_p2x.span_p.clone()), move |unify_at_f_2865: crate::check::types::St| ::prism_rtl::Turn::Finished((unify_at_f_2865, true))),
                        _ => crate::prelude::call_then(crate::check::types::recording::start_unify_at_f(st2_p8.clone(), expected_p3x.clone(), t_p7.clone(), e_p2x.span_p.clone()), move |unify_at_f_2926: crate::check::types::St| ::prism_rtl::Turn::Finished((unify_at_f_2926, false))),
                        _ => unreachable!("no arm matched"),
                    })
                })
            },
        }
    }
}

/// `Start CheckEntry, x`: what the function value is when passed to `@Run`.
pub fn start_check_entry_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, expected_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::St, bool)>> {
    ::std::rc::Rc::new(CheckEntry { env_p0, st_p1, e_p2, expected_p3 })
}

/// ```prism
/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
/// ```
pub fn infer_map_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, entries_p2: &crate::prelude::Array<(crate::syntax::Expr, crate::syntax::Expr)>, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (k_p8, st1_p9) = crate::check::types::fresh_var_f(st_p1, &true, &crate::prelude::Text::lit(""));
    let (v_pa, st2_pb) = crate::check::types::fresh_var_f(&st1_p9, &false, &crate::prelude::Text::lit(""));
    let n_p4 = crate::prelude::len(entries_p2);
    let params_p5 = crate::prelude::fold(entries_p2, &crate::prelude::Array::new(), &(|acc_pc: &crate::prelude::Array<crate::check::types::Ty>, _: &(crate::syntax::Expr, crate::syntax::Expr)| crate::prelude::append(acc_pc, &crate::prelude::Array::from(vec![k_p8.clone(), v_pa.clone()]))));
    let args_p6 = crate::prelude::fold(entries_p2, &crate::prelude::Array::new(), &(|acc_pd: &crate::prelude::Array<crate::syntax::Arg>, (ke_pe, ve_pf): &(crate::syntax::Expr, crate::syntax::Expr)| crate::prelude::append(acc_pd, &crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: ke_pe.clone(), span_p: ke_pe.span_p.clone() }, crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: ve_pf.clone(), span_p: ve_pf.span_p.clone() }]))));
    let st3_p7 = if &n_p4 > &crate::prelude::Nat::from(0u32) {
        crate::check::expr::add_want_f(&st2_pb, &crate::prelude::Text::lit("Prelude.Ord"), &k_p8, span_p3)
    } else {
        st2_pb.clone()
    };
    crate::check::expr::calls::apply_rule_f(env_p0, &st3_p7, &crate::check::expr::calls::map_literal_p(), &crate::check::types::Col::CBound, &params_p5, &crate::check::types::Ty::TyMap(::std::rc::Rc::new(k_p8.clone()), ::std::rc::Rc::new(v_pa.clone())), &args_p6, span_p3)
}

/// The step machine of `InferMap`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
/// ```
pub struct InferMap {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub entries_p2: crate::prelude::Array<(crate::syntax::Expr, crate::syntax::Expr)>,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferMap {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let entries_p2 = &self.entries_p2;
        let span_p3 = &self.span_p3;
        let (k_p8, st1_p9) = crate::check::types::fresh_var_f(st_p1, &true, &crate::prelude::Text::lit(""));
        let (v_pa, st2_pb) = crate::check::types::fresh_var_f(&st1_p9, &false, &crate::prelude::Text::lit(""));
        let n_p4 = crate::prelude::len(entries_p2);
        let params_p5 = crate::prelude::fold(entries_p2, &crate::prelude::Array::new(), &(|acc_pc: &crate::prelude::Array<crate::check::types::Ty>, _: &(crate::syntax::Expr, crate::syntax::Expr)| crate::prelude::append(acc_pc, &crate::prelude::Array::from(vec![k_p8.clone(), v_pa.clone()]))));
        let args_p6 = crate::prelude::fold(entries_p2, &crate::prelude::Array::new(), &(|acc_pd: &crate::prelude::Array<crate::syntax::Arg>, (ke_pe, ve_pf): &(crate::syntax::Expr, crate::syntax::Expr)| crate::prelude::append(acc_pd, &crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: ke_pe.clone(), span_p: ke_pe.span_p.clone() }, crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: ve_pf.clone(), span_p: ve_pf.span_p.clone() }]))));
        let st3_p7 = if &n_p4 > &crate::prelude::Nat::from(0u32) {
            crate::check::expr::add_want_f(&st2_pb, &crate::prelude::Text::lit("Prelude.Ord"), &k_p8, span_p3)
        } else {
            st2_pb.clone()
        };
        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st3_p7.clone(), fname_p2: crate::check::expr::calls::map_literal_p(), col_p3: crate::check::types::Col::CBound, params_p4: params_p5.clone(), res_p5: crate::check::types::Ty::TyMap(::std::rc::Rc::new(k_p8.clone()), ::std::rc::Rc::new(v_pa.clone())), args_p6: args_p6.clone(), span_p7: span_p3.clone() }))
    }
}

/// `Start InferMap, x`: what the function value is when passed to `@Run`.
pub fn start_infer_map_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, entries_p2: crate::prelude::Array<(crate::syntax::Expr, crate::syntax::Expr)>, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferMap { env_p0, st_p1, entries_p2, span_p3 })
}

/// ```prism
/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_binary_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, op_p2: &crate::prelude::Text, lhs_p3: &crate::syntax::Expr, rhs_p4: &crate::syntax::Expr, span_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let args_p6 = crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: lhs_p3.clone(), span_p: lhs_p3.span_p.clone() }, crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: rhs_p4.clone(), span_p: rhs_p4.span_p.clone() }]);
    if (op_p2 == &crate::prelude::Text::lit("and")) || (op_p2 == &crate::prelude::Text::lit("or")) {
        crate::check::expr::calls::apply_rule_f(env_p0, st_p1, op_p2, &crate::check::types::Col::CBound, &crate::prelude::Array::from(vec![crate::check::types::t_bool_p(), crate::check::types::t_bool_p()]), &crate::check::types::t_bool_p(), &args_p6, span_p5)
    } else {
        if op_p2 == &crate::prelude::Text::lit("on") {
            infer_on_f(env_p0, st_p1, lhs_p3, rhs_p4, span_p5)
        } else {
            if op_p2 == &crate::prelude::Text::lit("<|") {
                {
                    let (v_p7, st2_p8) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                    crate::check::expr::calls::apply_rule_f(env_p0, &st2_p8, op_p2, &crate::check::types::Col::CBound, &crate::prelude::Array::from(vec![crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(v_p7.clone())), crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(v_p7.clone()))]), &crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(v_p7.clone())), &args_p6, span_p5)
                }
            } else {
                if op_p2 == &crate::prelude::Text::lit("mod") {
                    {
                        let (v_pa, st2_pb) = crate::check::types::fresh_var_f(st_p1, &true, &crate::prelude::Text::lit(""));
                        let st3_p9 = crate::check::expr::add_want_f(&st2_pb, &crate::prelude::Text::lit("Prelude.Num"), &v_pa, span_p5);
                        crate::check::expr::calls::apply_rule_f(env_p0, &st3_p9, op_p2, &crate::check::types::Col::CBound, &crate::prelude::Array::from(vec![v_pa.clone(), v_pa.clone()]), &v_pa, &args_p6, span_p5)
                    }
                } else {
                    {
                        let (t0_pf, st2_pg) = crate::check::expr::infer_name_f(env_p0, st_p1, &crate::syntax::SName { sigils_p: crate::prelude::Text::lit(""), path_p: crate::prelude::Array::from(vec![op_p2.clone()]), span_p: span_p5.clone() }, span_p5);
                        let t_pc = if op_p2 == &crate::prelude::Text::lit("/") {
                            quotient_of_f(&st2_pg, &t0_pf)
                        } else {
                            t0_pf.clone()
                        };
                        let st2b_pd = if op_p2 == &crate::prelude::Text::lit("-?") {
                            crate::check::types::recording::note_size_ty_f(&st2_pg, span_p5, &crate::check::types::recording::walk_f(&st2_pg, &t0_pf))
                        } else {
                            st2_pg.clone()
                        };
                        let st3_pe = if op_p2 == &crate::prelude::Text::lit("-") {
                            sub_want_f(&st2b_pd, &t_pc, span_p5)
                        } else {
                            st2b_pd.clone()
                        };
                        crate::check::expr::calls::apply_fn_f(env_p0, &st3_pe, op_p2, &t_pc, &args_p6, span_p5)
                    }
                }
            }
        }
    }
}

/// The step machine of `InferBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
/// ```
pub struct InferBinary {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub op_p2: crate::prelude::Text,
    pub lhs_p3: crate::syntax::Expr,
    pub rhs_p4: crate::syntax::Expr,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferBinary {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let op_p2 = &self.op_p2;
        let lhs_p3 = &self.lhs_p3;
        let rhs_p4 = &self.rhs_p4;
        let span_p5 = &self.span_p5;
        let args_p6 = crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: lhs_p3.clone(), span_p: lhs_p3.span_p.clone() }, crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: rhs_p4.clone(), span_p: rhs_p4.span_p.clone() }]);
        if (op_p2 == &crate::prelude::Text::lit("and")) || (op_p2 == &crate::prelude::Text::lit("or")) {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st_p1.clone(), fname_p2: op_p2.clone(), col_p3: crate::check::types::Col::CBound, params_p4: crate::prelude::Array::from(vec![crate::check::types::t_bool_p(), crate::check::types::t_bool_p()]), res_p5: crate::check::types::t_bool_p(), args_p6: args_p6.clone(), span_p7: span_p5.clone() }))
        } else {
            if op_p2 == &crate::prelude::Text::lit("on") {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(InferOn { env_p0: env_p0.clone(), st_p1: st_p1.clone(), lhs_p2: lhs_p3.clone(), rhs_p3: rhs_p4.clone(), span_p4: span_p5.clone() }))
            } else {
                if op_p2 == &crate::prelude::Text::lit("<|") {
                    {
                        let (v_p7, st2_p8) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st2_p8.clone(), fname_p2: op_p2.clone(), col_p3: crate::check::types::Col::CBound, params_p4: crate::prelude::Array::from(vec![crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(v_p7.clone())), crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(v_p7.clone()))]), res_p5: crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(v_p7.clone())), args_p6: args_p6.clone(), span_p7: span_p5.clone() }))
                    }
                } else {
                    if op_p2 == &crate::prelude::Text::lit("mod") {
                        {
                            let (v_pa, st2_pb) = crate::check::types::fresh_var_f(st_p1, &true, &crate::prelude::Text::lit(""));
                            let st3_p9 = crate::check::expr::add_want_f(&st2_pb, &crate::prelude::Text::lit("Prelude.Num"), &v_pa, span_p5);
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st3_p9.clone(), fname_p2: op_p2.clone(), col_p3: crate::check::types::Col::CBound, params_p4: crate::prelude::Array::from(vec![v_pa.clone(), v_pa.clone()]), res_p5: v_pa.clone(), args_p6: args_p6.clone(), span_p7: span_p5.clone() }))
                        }
                    } else {
                        {
                            let env_p0x = env_p0.clone();
                            let op_p2x = op_p2.clone();
                            let span_p5x = span_p5.clone();
                            let st_p1x = st_p1.clone();
                            crate::prelude::call_then(crate::check::expr::start_infer_name_f(env_p0x.clone(), st_p1x.clone(), crate::syntax::SName { sigils_p: crate::prelude::Text::lit(""), path_p: crate::prelude::Array::from(vec![op_p2x.clone()]), span_p: span_p5x.clone() }, span_p5x.clone()), move |infer_name_f_4811: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t0_pf, st2_pg) = infer_name_f_4811;
                                let args_p6z = args_p6.clone();
                                let env_p0xz = env_p0x.clone();
                                let op_p2xz = op_p2x.clone();
                                let span_p5xz = span_p5x.clone();
                                let st2_pgz = st2_pg.clone();
                                let t0_pfz = t0_pf.clone();
                                let k_let4887 = move |v4887: crate::check::types::Ty| {
                                    let t_pc = v4887;
                                    let args_p6zz = args_p6z.clone();
                                    let env_p0xzz = env_p0xz.clone();
                                    let op_p2xzz = op_p2xz.clone();
                                    let span_p5xzz = span_p5xz.clone();
                                    let t_pcz = t_pc.clone();
                                    let k_let4945 = move |v4945: crate::check::types::St| {
                                        let st2b_pd = v4945;
                                        let args_p6zzz = args_p6zz.clone();
                                        let env_p0xzzz = env_p0xzz.clone();
                                        let op_p2xzzz = op_p2xzz.clone();
                                        let span_p5xzzz = span_p5xzz.clone();
                                        let t_pczz = t_pcz.clone();
                                        let k_let5026 = move |v5026: crate::check::types::St| {
                                            let st3_pe = v5026;
                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::ApplyFn { env_p0: env_p0xzzz.clone(), st_p1: st3_pe.clone(), fname_p2: op_p2xzzz.clone(), fty_p3: t_pczz.clone(), args_p4: args_p6zzz.clone(), span_p5: span_p5xzzz.clone() }))
                                        };
                                        if &op_p2xzz == &crate::prelude::Text::lit("-") {
                                            crate::prelude::call_then(start_sub_want_f(st2b_pd.clone(), t_pcz.clone(), span_p5xzz.clone()), move |sub_want_f_5050: crate::check::types::St| k_let5026(sub_want_f_5050))
                                        } else {
                                            k_let5026(st2b_pd.clone())
                                        }
                                    };
                                    if &op_p2xz == &crate::prelude::Text::lit("-?") {
                                        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st2_pgz.clone(), t0_pfz.clone()), move |walk_f_4994: crate::check::types::Ty| k_let4945(crate::check::types::recording::note_size_ty_f(&st2_pgz, &span_p5xz, &walk_f_4994)))
                                    } else {
                                        k_let4945(st2_pgz.clone())
                                    }
                                };
                                if &op_p2x == &crate::prelude::Text::lit("/") {
                                    crate::prelude::call_then(start_quotient_of_f(st2_pg.clone(), t0_pf.clone()), move |quotient_of_f_4909: crate::check::types::Ty| k_let4887(quotient_of_f_4909))
                                } else {
                                    k_let4887(t0_pf.clone())
                                }
                            })
                        }
                    }
                }
            }
        }
    }
}

/// `Start InferBinary, x`: what the function value is when passed to `@Run`.
pub fn start_infer_binary_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, op_p2: crate::prelude::Text, lhs_p3: crate::syntax::Expr, rhs_p4: crate::syntax::Expr, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferBinary { env_p0, st_p1, op_p2, lhs_p3, rhs_p4, span_p5 })
}

/// ```prism
/// QuotientOf: unbounded fn St, Ty -> Ty
/// ```
pub fn quotient_of_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TyFn(c_p2, ps_p3, _) => match crate::prelude::index(&ps_p3, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::Some(p_p4) => crate::check::types::Ty::TyFn(c_p2, ps_p3.clone(), ::std::rc::Rc::new(crate::check::types::Ty::TyAssoc(crate::check::types::quotient_trait_p(), crate::prelude::Text::lit("Quotient"), ::std::rc::Rc::new(p_p4)))),
            ::std::option::Option::None => t_p1.clone(),
        },
        other_p5 => other_p5,
    }
}

/// The step machine of `QuotientOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// QuotientOf: unbounded fn St, Ty -> Ty
/// ```
pub struct QuotientOf {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for QuotientOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_5301: crate::check::types::Ty| match walk_f_5301 {
            crate::check::types::Ty::TyFn(c_p2, ps_p3, _) => match crate::prelude::index(&ps_p3, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(p_p4) => ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c_p2.clone(), ps_p3.clone(), ::std::rc::Rc::new(crate::check::types::Ty::TyAssoc(crate::check::types::quotient_trait_p(), crate::prelude::Text::lit("Quotient"), ::std::rc::Rc::new(p_p4.clone()))))),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(t_p1x.clone()),
            },
            other_p5 => ::prism_rtl::Turn::Finished(other_p5.clone()),
        })
    }
}

/// `Start QuotientOf, x`: what the function value is when passed to `@Run`.
pub fn start_quotient_of_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(QuotientOf { st_p0, t_p1 })
}

/// ```prism
/// SubWant: unbounded fn St, Ty, Range -> St
/// ```
pub fn sub_want_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TyFn(_, ps_p3, _) => match crate::prelude::index(&ps_p3, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::Some(p_p4) => crate::check::expr::add_want_f(st_p0, &crate::prelude::Text::lit("Prelude.Sub"), &p_p4, span_p2),
            ::std::option::Option::None => st_p0.clone(),
        },
        _ => st_p0.clone(),
    }
}

/// The step machine of `SubWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubWant: unbounded fn St, Ty, Range -> St
/// ```
pub struct SubWant {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub span_p2: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for SubWant {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let span_p2 = &self.span_p2;
        let span_p2x = span_p2.clone();
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_5644: crate::check::types::Ty| match walk_f_5644 {
            crate::check::types::Ty::TyFn(_, ps_p3, _) => match crate::prelude::index(&ps_p3, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(p_p4) => ::prism_rtl::Turn::Finished(crate::check::expr::add_want_f(&st_p0x, &crate::prelude::Text::lit("Prelude.Sub"), &p_p4, &span_p2x)),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(st_p0x.clone()),
            },
            _ => ::prism_rtl::Turn::Finished(st_p0x.clone()),
        })
    }
}

/// `Start SubWant, x`: what the function value is when passed to `@Run`.
pub fn start_sub_want_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty, span_p2: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(SubWant { st_p0, t_p1, span_p2 })
}

/// ```prism
/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_on_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, lhs_p2: &crate::syntax::Expr, rhs_p3: &crate::syntax::Expr, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (a_p5, st1_p6) = crate::check::types::fresh_var_f(st_p1, &true, &crate::prelude::Text::lit(""));
    let (b_p7, st2_p8) = crate::check::types::fresh_var_f(&st1_p6, &true, &crate::prelude::Text::lit(""));
    let (rt_p9, st3_pa) = crate::check::expr::infer_f(env_p0, &st2_p8, rhs_p3);
    if ((&crate::check::types::head_sigil_f(&st3_pa, &rt_p9) != &crate::prelude::Text::lit("!")) && (&rt_p9 != &crate::check::types::Ty::TyErr)) && !crate::check::types::is_flex_var_f(&st3_pa, &rt_p9) {
        (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st3_pa, &crate::prelude::Text::lit("mismatch"), &rhs_p3.span_p, &crate::prelude::Text::from(format!("`on` fires with an event on its right; this is `{}`", &crate::check::types::show_ty_f(&st3_pa, &rt_p9)))))
    } else {
        {
            let args_pb = crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: lhs_p2.clone(), span_p: lhs_p2.span_p.clone() }, crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: rhs_p3.clone(), span_p: rhs_p3.span_p.clone() }]);
            crate::check::expr::calls::apply_rule_f(env_p0, &st3_pa, &crate::prelude::Text::lit("on"), &crate::check::types::Col::CBound, &crate::prelude::Array::from(vec![a_p5.clone(), b_p7.clone()]), &a_p5, &args_pb, span_p4)
        }
    }
}

/// The step machine of `InferOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub struct InferOn {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub lhs_p2: crate::syntax::Expr,
    pub rhs_p3: crate::syntax::Expr,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferOn {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let lhs_p2 = &self.lhs_p2;
        let rhs_p3 = &self.rhs_p3;
        let span_p4 = &self.span_p4;
        let (a_p5, st1_p6) = crate::check::types::fresh_var_f(st_p1, &true, &crate::prelude::Text::lit(""));
        let (b_p7, st2_p8) = crate::check::types::fresh_var_f(&st1_p6, &true, &crate::prelude::Text::lit(""));
        let env_p0x = env_p0.clone();
        let lhs_p2x = lhs_p2.clone();
        let rhs_p3x = rhs_p3.clone();
        let span_p4x = span_p4.clone();
        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st2_p8.clone(), rhs_p3x.clone()), move |infer_f_6122: (crate::check::types::Ty, crate::check::types::St)| {
            let (rt_p9, st3_pa) = infer_f_6122;
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st3_pa.clone(), rt_p9.clone()), move |head_sigil_f_6150: crate::prelude::Text| if ((&head_sigil_f_6150 != &crate::prelude::Text::lit("!")) && (&rt_p9 != &crate::check::types::Ty::TyErr)) && !crate::check::types::is_flex_var_f(&st3_pa, &rt_p9) {
                crate::prelude::call_then(crate::check::types::start_show_ty_f(st3_pa.clone(), rt_p9.clone()), move |show_ty_f_6320: crate::prelude::Text| ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st3_pa, &crate::prelude::Text::lit("mismatch"), &rhs_p3x.span_p, &crate::prelude::Text::from(format!("`on` fires with an event on its right; this is `{}`", &show_ty_f_6320))))))
            } else {
                {
                    let args_pb = crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: lhs_p2x.clone(), span_p: lhs_p2x.span_p.clone() }, crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: rhs_p3x.clone(), span_p: rhs_p3x.span_p.clone() }]);
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0x.clone(), st_p1: st3_pa.clone(), fname_p2: crate::prelude::Text::lit("on"), col_p3: crate::check::types::Col::CBound, params_p4: crate::prelude::Array::from(vec![a_p5.clone(), b_p7.clone()]), res_p5: a_p5.clone(), args_p6: args_pb.clone(), span_p7: span_p4x.clone() }))
                }
            })
        })
    }
}

/// `Start InferOn, x`: what the function value is when passed to `@Run`.
pub fn start_infer_on_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, lhs_p2: crate::syntax::Expr, rhs_p3: crate::syntax::Expr, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferOn { env_p0, st_p1, lhs_p2, rhs_p3, span_p4 })
}

/// ```prism
/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_unary_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, op_p2: &crate::prelude::Text, x_p3: &crate::syntax::Expr, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let args_p5 = crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: x_p3.clone(), span_p: x_p3.span_p.clone() }]);
    match op_p2 {
        m6716_0 if (m6716_0 == &crate::prelude::Text::lit("not")) => crate::check::expr::calls::apply_rule_f(env_p0, st_p1, &crate::prelude::Text::lit("not"), &crate::check::types::Col::CBound, &crate::prelude::Array::from(vec![crate::check::types::t_bool_p()]), &crate::check::types::t_bool_p(), &args_p5, span_p4),
        m6716_1 if (m6716_1 == &crate::prelude::Text::lit("neg")) => match &*x_p3.kind_p {
            crate::syntax::ExprKind::ELit(l_p6) => {
                let (t_p7, st2_p8) = crate::check::expr::infer_lit_f(env_p0, st_p1, l_p6, &true, span_p4);
                (t_p7.clone(), crate::check::types::recording::note_ty_f(&st2_p8, &x_p3.span_p, &t_p7))
            },
            _ => {
                let (v_pa, st2_pb) = crate::check::types::fresh_var_f(st_p1, &true, &crate::prelude::Text::lit(""));
                let st3_p9 = crate::check::expr::add_want_f(&crate::check::expr::add_want_f(&st2_pb, &crate::prelude::Text::lit("Prelude.Num"), &v_pa, span_p4), &crate::prelude::Text::lit("Prelude.Signed"), &v_pa, span_p4);
                crate::check::expr::calls::apply_rule_f(env_p0, &st3_p9, &crate::prelude::Text::lit("-"), &crate::check::types::Col::CBound, &crate::prelude::Array::from(vec![v_pa.clone()]), &v_pa, &args_p5, span_p4)
            },
        },
        _ => crate::check::expr::infer_f(env_p0, st_p1, x_p3),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InferUnary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub struct InferUnary {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub op_p2: crate::prelude::Text,
    pub x_p3: crate::syntax::Expr,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferUnary {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let op_p2 = &self.op_p2;
        let x_p3 = &self.x_p3;
        let span_p4 = &self.span_p4;
        let args_p5 = crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: x_p3.clone(), span_p: x_p3.span_p.clone() }]);
        match op_p2 {
            m6716_0 if (m6716_0 == &crate::prelude::Text::lit("not")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st_p1.clone(), fname_p2: crate::prelude::Text::lit("not"), col_p3: crate::check::types::Col::CBound, params_p4: crate::prelude::Array::from(vec![crate::check::types::t_bool_p()]), res_p5: crate::check::types::t_bool_p(), args_p6: args_p5.clone(), span_p7: span_p4.clone() })),
            m6716_1 if (m6716_1 == &crate::prelude::Text::lit("neg")) => match &*x_p3.kind_p {
                crate::syntax::ExprKind::ELit(l_p6) => {
                    let env_p0x = env_p0.clone();
                    let l_p6x = l_p6.clone();
                    let span_p4x = span_p4.clone();
                    let st_p1x = st_p1.clone();
                    let x_p3x = x_p3.clone();
                    crate::prelude::call_then(crate::check::expr::start_infer_lit_f(env_p0x.clone(), st_p1x.clone(), l_p6x.clone(), true, span_p4x.clone()), move |infer_lit_f_6886: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_p7, st2_p8) = infer_lit_f_6886;
                        ::prism_rtl::Turn::Finished((t_p7.clone(), crate::check::types::recording::note_ty_f(&st2_p8, &x_p3x.span_p, &t_p7)))
                    })
                },
                _ => {
                    let (v_pa, st2_pb) = crate::check::types::fresh_var_f(st_p1, &true, &crate::prelude::Text::lit(""));
                    let st3_p9 = crate::check::expr::add_want_f(&crate::check::expr::add_want_f(&st2_pb, &crate::prelude::Text::lit("Prelude.Num"), &v_pa, span_p4), &crate::prelude::Text::lit("Prelude.Signed"), &v_pa, span_p4);
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st3_p9.clone(), fname_p2: crate::prelude::Text::lit("-"), col_p3: crate::check::types::Col::CBound, params_p4: crate::prelude::Array::from(vec![v_pa.clone()]), res_p5: v_pa.clone(), args_p6: args_p5.clone(), span_p7: span_p4.clone() }))
                },
            },
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::Infer { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: x_p3.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start InferUnary, x`: what the function value is when passed to `@Run`.
pub fn start_infer_unary_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, op_p2: crate::prelude::Text, x_p3: crate::syntax::Expr, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferUnary { env_p0, st_p1, op_p2, x_p3, span_p4 })
}

/// ```prism
/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_free_sigil_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, s_p2: &crate::prelude::Text, x_p3: &crate::syntax::Expr, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    if s_p2 == &crate::prelude::Text::lit("@") {
        {
            let (t_p5, st2_p6) = crate::check::expr::infer_f(env_p0, st_p1, x_p3);
            (crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_p5.clone()), env_p0.scope_p.clone()), st2_p6.clone())
        }
    } else {
        if ((s_p2 == &crate::prelude::Text::lit("?")) || (s_p2 == &crate::prelude::Text::lit("~"))) || (s_p2 == &crate::prelude::Text::lit("$")) {
            {
                let (v_p7, st2_p8) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                if is_blueprint_expr_f(env_p0, &st2_p8, x_p3) {
                    {
                        let (t_p9, st3_pa) = crate::check::expr::infer_f(env_p0, &st2_p8, x_p3);
                        (crate::check::types::Ty::TySig(s_p2.clone(), ::std::rc::Rc::new(t_p9.clone())), st3_pa.clone())
                    }
                } else {
                    crate::check::expr::calls::apply_rule_f(env_p0, &st2_p8, &crate::prelude::Text::from(format!("{}", s_p2)), &crate::check::types::Col::CBound, &crate::prelude::Array::from(vec![v_p7.clone()]), &crate::check::types::Ty::TySig(s_p2.clone(), ::std::rc::Rc::new(v_p7.clone())), &crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: x_p3.clone(), span_p: x_p3.span_p.clone() }]), span_p4)
                }
            }
        } else {
            {
                let (t_pb, st2_pc) = crate::check::expr::infer_f(env_p0, st_p1, x_p3);
                (crate::check::types::with_marks_f(s_p2, &t_pb, &env_p0.scope_p), st2_pc.clone())
            }
        }
    }
}

/// The step machine of `InferFreeSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub struct InferFreeSigil {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub s_p2: crate::prelude::Text,
    pub x_p3: crate::syntax::Expr,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferFreeSigil {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let s_p2 = &self.s_p2;
        let x_p3 = &self.x_p3;
        let span_p4 = &self.span_p4;
        if s_p2 == &crate::prelude::Text::lit("@") {
            {
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let x_p3x = x_p3.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), x_p3x.clone()), move |infer_f_7532: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p5, st2_p6) = infer_f_7532;
                    ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_p5.clone()), env_p0x.scope_p.clone()), st2_p6.clone()))
                })
            }
        } else {
            if ((s_p2 == &crate::prelude::Text::lit("?")) || (s_p2 == &crate::prelude::Text::lit("~"))) || (s_p2 == &crate::prelude::Text::lit("$")) {
                {
                    let (v_p7, st2_p8) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                    if is_blueprint_expr_f(env_p0, &st2_p8, x_p3) {
                        {
                            let env_p0x = env_p0.clone();
                            let s_p2x = s_p2.clone();
                            let x_p3x = x_p3.clone();
                            crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st2_p8.clone(), x_p3x.clone()), move |infer_f_7750: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t_p9, st3_pa) = infer_f_7750;
                                ::prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(s_p2x.clone(), ::std::rc::Rc::new(t_p9.clone())), st3_pa.clone()))
                            })
                        }
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st2_p8.clone(), fname_p2: crate::prelude::Text::from(format!("{}", s_p2)), col_p3: crate::check::types::Col::CBound, params_p4: crate::prelude::Array::from(vec![v_p7.clone()]), res_p5: crate::check::types::Ty::TySig(s_p2.clone(), ::std::rc::Rc::new(v_p7.clone())), args_p6: crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: x_p3.clone(), span_p: x_p3.span_p.clone() }]), span_p7: span_p4.clone() }))
                    }
                }
            } else {
                {
                    let env_p0x = env_p0.clone();
                    let s_p2x = s_p2.clone();
                    let st_p1x = st_p1.clone();
                    let x_p3x = x_p3.clone();
                    crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), x_p3x.clone()), move |infer_f_7964: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_pb, st2_pc) = infer_f_7964;
                        ::prism_rtl::Turn::Finished((crate::check::types::with_marks_f(&s_p2x, &t_pb, &env_p0x.scope_p), st2_pc.clone()))
                    })
                }
            }
        }
    }
}

/// `Start InferFreeSigil, x`: what the function value is when passed to `@Run`.
pub fn start_infer_free_sigil_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, s_p2: crate::prelude::Text, x_p3: crate::syntax::Expr, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferFreeSigil { env_p0, st_p1, s_p2, x_p3, span_p4 })
}

/// ```prism
/// IsBlueprintExpr: fn Env, St, Expr -> Bool
/// ```
pub fn is_blueprint_expr_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, x_p2: &crate::syntax::Expr) -> bool {
    match &*x_p2.kind_p {
        crate::syntax::ExprKind::EFreeSigil(m8244_0_0, _) if (m8244_0_0 == &crate::prelude::Text::lit("@")) => true,
        crate::syntax::ExprKind::EGroup(y_p3) => is_blueprint_expr_f(env_p0, st_p1, &**y_p3),
        crate::syntax::ExprKind::ECall(c_p4, _, _, _) => match &*c_p4.kind_p {
            crate::syntax::ExprKind::EName(n_p5) => crate::syntax::lexer::chars::has_prefix_f(&n_p5.sigils_p, &crate::prelude::Text::lit("@")),
            _ => false,
        },
        crate::syntax::ExprKind::EName(n_p6) => crate::syntax::lexer::chars::has_prefix_f(&n_p6.sigils_p, &crate::prelude::Text::lit("@")),
        crate::syntax::ExprKind::EWidgetBlock(_) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
/// ```
pub fn infer_field_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, recv_p2: &crate::syntax::Expr, sigils_p3: &crate::prelude::Text, name_p4: &crate::syntax::Ident, span_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (rt_pj, st1_pk) = crate::check::expr::infer_f(env_p0, st_p1, recv_p2);
    let head_p6 = crate::check::types::head_sigil_f(&st1_pk, &rt_pj);
    let inner_p7 = if crate::check::expr::is_time_sigil_f(&head_p6) {
        crate::check::expr::inner_of_f(&st1_pk, &rt_pj)
    } else {
        rt_pj.clone()
    };
    let ih_p8 = if crate::check::blocks::borrows::is_ref_f(recv_p2) {
        crate::prelude::Text::lit("")
    } else {
        crate::check::types::head_sigil_f(&st1_pk, &inner_p7)
    };
    let plain_t_p9 = if crate::check::expr::is_plain_sigil_f(&crate::check::types::head_sigil_f(&st1_pk, &inner_p7)) {
        crate::check::expr::inner_of_f(&st1_pk, &inner_p7)
    } else {
        inner_p7.clone()
    };
    let st2_pa = if &head_p6 == &crate::prelude::Text::lit("@") {
        crate::check::types::recording::err_f(&st1_pk, &crate::prelude::Text::lit("blueprint-operand"), &recv_p2.span_p, &crate::prelude::Text::from(format!("`.{}` over a blueprint; bind it first", &name_p4.name_p)))
    } else {
        st1_pk.clone()
    };
    let (ft_pl, st3_pm) = field_type_f(env_p0, &st2_pa, &plain_t_p9, &name_p4.name_p, span_p5);
    let stack_pb = crate::check::types::stack_of_f(&st3_pm, &ft_pl);
    let bad_pc = (((&stack_pb != sigils_p3) && (&ft_pl != &crate::check::types::Ty::TyErr)) && !crate::check::types::is_flex_var_f(&st3_pm, &ft_pl)) && !crate::check::blocks::borrows::is_ref_f(recv_p2);
    let st3b_pd = if crate::check::types::is_flex_var_f(&st3_pm, &ft_pl) && !crate::check::blocks::borrows::is_ref_f(recv_p2) {
        crate::check::types::unify::mark_last_field_f(&st3_pm, &ft_pl, sigils_p3, &name_p4.span_p)
    } else {
        st3_pm.clone()
    };
    let st4_pe = if bad_pc {
        crate::check::types::recording::err_fix_f(&st3b_pd, &crate::prelude::Text::lit("mark-stack"), &name_p4.span_p, &crate::prelude::Text::from(format!("`.{}{}` has type `{}`, whose stack is `{}`; the access shows `{}`", sigils_p3, &name_p4.name_p, &crate::check::types::show_ty_f(&st3_pm, &ft_pl), &stack_pb, sigils_p3)), &crate::prelude::Text::from(format!("write `.{}{}`", &stack_pb, &name_p4.name_p)))
    } else {
        st3b_pd.clone()
    };
    let with_opt_pf = if crate::check::expr::is_plain_sigil_f(&ih_p8) {
        crate::check::types::Ty::TySig(ih_p8.clone(), ::std::rc::Rc::new(ft_pl.clone()))
    } else {
        ft_pl.clone()
    };
    let res_pg = if crate::check::expr::is_time_sigil_f(&head_p6) {
        crate::check::types::Ty::TySig(head_p6.clone(), ::std::rc::Rc::new(with_opt_pf.clone()))
    } else {
        with_opt_pf.clone()
    };
    let st5_ph = if crate::check::expr::is_time_sigil_f(&head_p6) {
        crate::check::expr::calls::elab_f(&st4_pe, span_p5, &crate::prelude::Text::from(format!(".{}", &name_p4.name_p)), &crate::prelude::Text::lit("map"), &head_p6)
    } else {
        st4_pe.clone()
    };
    let st6_pi = if crate::check::expr::is_plain_sigil_f(&ih_p8) {
        crate::check::types::recording::note_lift_f(&st5_ph, span_p5, &ih_p8, &crate::prelude::Array::from(vec![recv_p2.span_p.clone()]))
    } else {
        st5_ph.clone()
    };
    (res_pg.clone(), st6_pi.clone())
}

/// The step machine of `InferField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
/// ```
pub struct InferField {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub recv_p2: crate::syntax::Expr,
    pub sigils_p3: crate::prelude::Text,
    pub name_p4: crate::syntax::Ident,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferField {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let recv_p2 = &self.recv_p2;
        let sigils_p3 = &self.sigils_p3;
        let name_p4 = &self.name_p4;
        let span_p5 = &self.span_p5;
        let env_p0x = env_p0.clone();
        let name_p4x = name_p4.clone();
        let recv_p2x = recv_p2.clone();
        let sigils_p3x = sigils_p3.clone();
        let span_p5x = span_p5.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), recv_p2x.clone()), move |infer_f_9057: (crate::check::types::Ty, crate::check::types::St)| {
            let (rt_pj, st1_pk) = infer_f_9057;
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pk.clone(), rt_pj.clone()), move |head_sigil_f_9092: crate::prelude::Text| {
                let head_p6 = head_sigil_f_9092;
                let env_p0xz = env_p0x.clone();
                let head_p6z = head_p6.clone();
                let name_p4xz = name_p4x.clone();
                let recv_p2xz = recv_p2x.clone();
                let sigils_p3xz = sigils_p3x.clone();
                let span_p5xz = span_p5x.clone();
                let st1_pkz = st1_pk.clone();
                let k_let9114 = move |v9114: crate::check::types::Ty| {
                    let inner_p7 = v9114;
                    crate::prelude::call_then(crate::check::blocks::borrows::start_is_ref_f(recv_p2xz.clone()), move |is_ref_f_9350: bool| {
                        let env_p0xzz = env_p0xz.clone();
                        let head_p6zz = head_p6z.clone();
                        let inner_p7z = inner_p7.clone();
                        let name_p4xzz = name_p4xz.clone();
                        let recv_p2xzz = recv_p2xz.clone();
                        let sigils_p3xzz = sigils_p3xz.clone();
                        let span_p5xzz = span_p5xz.clone();
                        let st1_pkzz = st1_pkz.clone();
                        let k_let9338 = move |v9338: crate::prelude::Text| {
                            let ih_p8 = v9338;
                            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pkzz.clone(), inner_p7z.clone()), move |head_sigil_f_9426: crate::prelude::Text| {
                                let env_p0xzzz = env_p0xzz.clone();
                                let head_p6zzz = head_p6zz.clone();
                                let ih_p8z = ih_p8.clone();
                                let name_p4xzzz = name_p4xzz.clone();
                                let recv_p2xzzz = recv_p2xzz.clone();
                                let sigils_p3xzzz = sigils_p3xzz.clone();
                                let span_p5xzzz = span_p5xzz.clone();
                                let st1_pkzzz = st1_pkzz.clone();
                                let k_let9396 = move |v9396: crate::check::types::Ty| {
                                    let plain_t_p9 = v9396;
                                    let st2_pa = if &head_p6zzz == &crate::prelude::Text::lit("@") {
                                        crate::check::types::recording::err_f(&st1_pkzzz, &crate::prelude::Text::lit("blueprint-operand"), &recv_p2xzzz.span_p, &crate::prelude::Text::from(format!("`.{}` over a blueprint; bind it first", &name_p4xzzz.name_p)))
                                    } else {
                                        st1_pkzzz.clone()
                                    };
                                    crate::prelude::call_then(start_field_type_f(env_p0xzzz.clone(), st2_pa.clone(), plain_t_p9.clone(), name_p4xzzz.name_p.clone(), span_p5xzzz.clone()), move |field_type_f_9632: (crate::check::types::Ty, crate::check::types::St)| {
                                        let (ft_pl, st3_pm) = field_type_f_9632;
                                        crate::prelude::call_then(crate::check::types::start_stack_of_f(st3_pm.clone(), ft_pl.clone()), move |stack_of_f_9692: crate::prelude::Text| {
                                            let stack_pb = stack_of_f_9692;
                                            let ft_plz = ft_pl.clone();
                                            let head_p6zzzz = head_p6zzz.clone();
                                            let ih_p8zz = ih_p8z.clone();
                                            let name_p4xzzzz = name_p4xzzz.clone();
                                            let recv_p2xzzzz = recv_p2xzzz.clone();
                                            let sigils_p3xzzzz = sigils_p3xzzz.clone();
                                            let span_p5xzzzz = span_p5xzzz.clone();
                                            let st3_pmz = st3_pm.clone();
                                            let stack_pbz = stack_pb.clone();
                                            let k_let9880 = move |v9880: bool| {
                                                let bad_pc = v9880;
                                                crate::prelude::call_then(crate::check::types::start_is_flex_var_f(st3_pmz.clone(), ft_plz.clone()), move |is_flex_var_f_9990: bool| {
                                                    let st3b_pd = if is_flex_var_f_9990 && !crate::check::blocks::borrows::is_ref_f(&recv_p2xzzzz) {
                                                        crate::check::types::unify::mark_last_field_f(&st3_pmz, &ft_plz, &sigils_p3xzzzz, &name_p4xzzzz.span_p)
                                                    } else {
                                                        st3_pmz.clone()
                                                    };
                                                    let ft_plzz = ft_plz.clone();
                                                    let head_p6zzzzz = head_p6zzzz.clone();
                                                    let ih_p8zzz = ih_p8zz.clone();
                                                    let name_p4xzzzzz = name_p4xzzzz.clone();
                                                    let recv_p2xzzzzz = recv_p2xzzzz.clone();
                                                    let span_p5xzzzzz = span_p5xzzzz.clone();
                                                    let k_let10086 = move |v10086: crate::check::types::St| {
                                                        let st4_pe = v10086;
                                                        let with_opt_pf = if crate::check::expr::is_plain_sigil_f(&ih_p8zzz) {
                                                            crate::check::types::Ty::TySig(ih_p8zzz.clone(), ::std::rc::Rc::new(ft_plzz.clone()))
                                                        } else {
                                                            ft_plzz.clone()
                                                        };
                                                        let res_pg = if crate::check::expr::is_time_sigil_f(&head_p6zzzzz) {
                                                            crate::check::types::Ty::TySig(head_p6zzzzz.clone(), ::std::rc::Rc::new(with_opt_pf.clone()))
                                                        } else {
                                                            with_opt_pf.clone()
                                                        };
                                                        let st5_ph = if crate::check::expr::is_time_sigil_f(&head_p6zzzzz) {
                                                            crate::check::expr::calls::elab_f(&st4_pe, &span_p5xzzzzz, &crate::prelude::Text::from(format!(".{}", &name_p4xzzzzz.name_p)), &crate::prelude::Text::lit("map"), &head_p6zzzzz)
                                                        } else {
                                                            st4_pe.clone()
                                                        };
                                                        let st6_pi = if crate::check::expr::is_plain_sigil_f(&ih_p8zzz) {
                                                            crate::check::types::recording::note_lift_f(&st5_ph, &span_p5xzzzzz, &ih_p8zzz, &crate::prelude::Array::from(vec![recv_p2xzzzzz.span_p.clone()]))
                                                        } else {
                                                            st5_ph.clone()
                                                        };
                                                        ::prism_rtl::Turn::Finished((res_pg.clone(), st6_pi.clone()))
                                                    };
                                                    if bad_pc {
                                                        crate::prelude::call_then(crate::check::types::start_show_ty_f(st3_pmz.clone(), ft_plz.clone()), move |show_ty_f_10177: crate::prelude::Text| k_let10086(crate::check::types::recording::err_fix_f(&st3b_pd, &crate::prelude::Text::lit("mark-stack"), &name_p4xzzzz.span_p, &crate::prelude::Text::from(format!("`.{}{}` has type `{}`, whose stack is `{}`; the access shows `{}`", &sigils_p3xzzzz, &name_p4xzzzz.name_p, &show_ty_f_10177, &stack_pbz, &sigils_p3xzzzz)), &crate::prelude::Text::from(format!("write `.{}{}`", &stack_pbz, &name_p4xzzzz.name_p)))))
                                                    } else {
                                                        k_let10086(st3b_pd.clone())
                                                    }
                                                })
                                            };
                                            if ((&stack_pb != &sigils_p3xzzz) && (&ft_pl != &crate::check::types::Ty::TyErr)) && !crate::check::types::is_flex_var_f(&st3_pm, &ft_pl) {
                                                crate::prelude::call_then(crate::check::blocks::borrows::start_is_ref_f(recv_p2xzzz.clone()), move |is_ref_f_9959: bool| k_let9880(!is_ref_f_9959))
                                            } else {
                                                k_let9880(false)
                                            }
                                        })
                                    })
                                };
                                if crate::check::expr::is_plain_sigil_f(&head_sigil_f_9426) {
                                    crate::prelude::call_then(crate::check::expr::start_inner_of_f(st1_pkzz.clone(), inner_p7z.clone()), move |inner_of_f_9449: crate::check::types::Ty| k_let9396(inner_of_f_9449))
                                } else {
                                    k_let9396(inner_p7z.clone())
                                }
                            })
                        };
                        if is_ref_f_9350 {
                            k_let9338(crate::prelude::Text::lit(""))
                        } else {
                            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pkz.clone(), inner_p7.clone()), move |head_sigil_f_9371: crate::prelude::Text| k_let9338(head_sigil_f_9371))
                        }
                    })
                };
                if crate::check::expr::is_time_sigil_f(&head_p6) {
                    crate::prelude::call_then(crate::check::expr::start_inner_of_f(st1_pk.clone(), rt_pj.clone()), move |inner_of_f_9147: crate::check::types::Ty| k_let9114(inner_of_f_9147))
                } else {
                    k_let9114(rt_pj.clone())
                }
            })
        })
    }
}

/// `Start InferField, x`: what the function value is when passed to `@Run`.
pub fn start_infer_field_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, recv_p2: crate::syntax::Expr, sigils_p3: crate::prelude::Text, name_p4: crate::syntax::Ident, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferField { env_p0, st_p1, recv_p2, sigils_p3, name_p4, span_p5 })
}

/// ```prism
/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
/// ```
pub fn field_type_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty, field_p3: &crate::prelude::Text, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::check::types::unify::norm_assoc_f(st_p1, &crate::check::types::recording::walk_f(st_p1, t_p2)) {
        crate::check::types::Ty::TyCon(n_p5, args_p6) => match crate::prelude::get(&env_p0.g_p.ctors_p, &n_p5) {
            ::std::option::Option::Some(c_p7) => match index_of_o(&c_p7.fields_p, field_p3) {
                ::std::option::Option::Some(i_p8) => {
                    let inst_p9 = crate::check::env::reading::param_inst_f(&c_p7.params_p, &args_p6);
                    (crate::check::types::schemes::subst_q_f(&inst_p9, &crate::prelude::or(&crate::prelude::index(&c_p7.args_p, &i_p8), &crate::check::types::Ty::TyErr)), st_p1.clone())
                },
                ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p4, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name_f(&n_p5), field_p3)))),
            },
            ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p4, &crate::prelude::Text::from(format!("`{}` has no fields", &crate::check::types::bare_name_f(&n_p5))))),
        },
        crate::check::types::Ty::TyFlex(_) => {
            let owners_pa = crate::prelude::filter(&crate::prelude::values(&env_p0.g_p.ctors_p), &(|c_pb: &crate::check::env::CtorInfo| crate::check::types::has_text_f(&c_pb.fields_p, field_p3)));
            match crate::prelude::index(&owners_pa, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(c_pc) => if &crate::prelude::len(&owners_pa) > &crate::prelude::Nat::from(1u32) {
                    {
                        let (v_pd, st2_pe) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                        (v_pd.clone(), crate::check::types::unify::ask_field_f(&st2_pe, t_p2, field_p3, &v_pd, span_p4, &crate::prelude::each(&owners_pa, &(|o_pf: &crate::check::env::CtorInfo| crate::check::types::bare_name_f(&o_pf.owner_p)))))
                    }
                } else {
                    {
                        let (self_ph, st2_pi) = crate::check::expr::ctor_value_f(env_p0, st_p1, &{
                            let mut this: crate::check::env::CtorInfo = c_pc.clone();
                            this.args_p = crate::prelude::Array::new();
                            this
                        }, span_p4);
                        let st3_pg = crate::check::types::unify::unify_f(&st2_pi, &self_ph, t_p2, span_p4);
                        field_type_f(env_p0, &st3_pg, &self_ph, field_p3, span_p4)
                    }
                },
                ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p4, &crate::prelude::Text::from(format!("no record has a field `{}`", field_p3)))),
            }
        },
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st_p1.clone()),
        other_pj => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p4, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &crate::check::types::show_ty_f(st_p1, &other_pj), field_p3)))),
    }
}

/// The step machine of `FieldType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
/// ```
pub struct FieldType {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
    pub field_p3: crate::prelude::Text,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for FieldType {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let field_p3 = &self.field_p3;
        let span_p4 = &self.span_p4;
        let env_p0x = env_p0.clone();
        let field_p3x = field_p3.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), t_p2x.clone()), move |walk_f_10972: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::unify::start_norm_assoc_f(st_p1x.clone(), walk_f_10972), move |norm_assoc_f_10957: crate::check::types::Ty| match norm_assoc_f_10957 {
            crate::check::types::Ty::TyCon(n_p5, args_p6) => match crate::prelude::get(&env_p0x.g_p.ctors_p, &n_p5) {
                ::std::option::Option::Some(c_p7) => match index_of_o(&c_p7.fields_p, &field_p3x) {
                    ::std::option::Option::Some(i_p8) => {
                        let inst_p9 = crate::check::env::reading::param_inst_f(&c_p7.params_p, &args_p6);
                        crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_p9.clone(), crate::prelude::or(&crate::prelude::index(&c_p7.args_p, &i_p8), &crate::check::types::Ty::TyErr)), move |subst_q_f_11183: crate::check::types::Ty| ::prism_rtl::Turn::Finished((subst_q_f_11183, st_p1x.clone())))
                    },
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p1x, &crate::prelude::Text::lit("mismatch"), &span_p4x, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name_f(&n_p5), &field_p3x))))),
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p1x, &crate::prelude::Text::lit("mismatch"), &span_p4x, &crate::prelude::Text::from(format!("`{}` has no fields", &crate::check::types::bare_name_f(&n_p5)))))),
            },
            crate::check::types::Ty::TyFlex(_) => {
                let owners_pa = crate::prelude::filter(&crate::prelude::values(&env_p0x.g_p.ctors_p), &(|c_pb: &crate::check::env::CtorInfo| crate::check::types::has_text_f(&c_pb.fields_p, &field_p3x)));
                match crate::prelude::index(&owners_pa, &crate::prelude::Nat::from(0u32)) {
                    ::std::option::Option::Some(c_pc) => if &crate::prelude::len(&owners_pa) > &crate::prelude::Nat::from(1u32) {
                        {
                            let (v_pd, st2_pe) = crate::check::types::fresh_var_f(&st_p1x, &false, &crate::prelude::Text::lit(""));
                            ::prism_rtl::Turn::Finished((v_pd.clone(), crate::check::types::unify::ask_field_f(&st2_pe, &t_p2x, &field_p3x, &v_pd, &span_p4x, &crate::prelude::each(&owners_pa, &(|o_pf: &crate::check::env::CtorInfo| crate::check::types::bare_name_f(&o_pf.owner_p))))))
                        }
                    } else {
                        crate::prelude::call_then(crate::check::expr::start_ctor_value_f(env_p0x.clone(), st_p1x.clone(), {
                            let mut this: crate::check::env::CtorInfo = c_pc.clone();
                            this.args_p = crate::prelude::Array::new();
                            this
                        }, span_p4x.clone()), move |ctor_value_f_12067: (crate::check::types::Ty, crate::check::types::St)| {
                            let (self_ph, st2_pi) = ctor_value_f_12067;
                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pi.clone(), self_ph.clone(), t_p2x.clone(), span_p4x.clone()), move |unify_f_12174: crate::check::types::St| {
                                let st3_pg = unify_f_12174;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(FieldType { env_p0: env_p0x.clone(), st_p1: st3_pg.clone(), t_p2: self_ph.clone(), field_p3: field_p3x.clone(), span_p4: span_p4x.clone() }))
                            })
                        })
                    },
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p1x, &crate::prelude::Text::lit("mismatch"), &span_p4x, &crate::prelude::Text::from(format!("no record has a field `{}`", &field_p3x))))),
                }
            },
            crate::check::types::Ty::TyErr => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st_p1x.clone())),
            other_pj => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), other_pj.clone()), move |show_ty_f_12422: crate::prelude::Text| ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p1x, &crate::prelude::Text::lit("mismatch"), &span_p4x, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &show_ty_f_12422, &field_p3x)))))),
        }))
    }
}

/// `Start FieldType, x`: what the function value is when passed to `@Run`.
pub fn start_field_type_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty, field_p3: crate::prelude::Text, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(FieldType { env_p0, st_p1, t_p2, field_p3, span_p4 })
}

/// ```prism
/// ?IndexOf: fn [Text], Text -> ?Nat
/// ```
pub fn index_of_o(xs_p0: &crate::prelude::Array<crate::prelude::Text>, x_p1: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Nat> {
    crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(xs_p0)), &::std::option::Option::None, &(|found_o2: &::std::option::Option<crate::prelude::Nat>, i_p3: &crate::prelude::Nat| match found_o2 {
        ::std::option::Option::Some(f_p4) => ::std::option::Option::Some(f_p4.clone()),
        ::std::option::Option::None => if &crate::prelude::index(xs_p0, i_p3) == &::std::option::Option::Some(x_p1.clone()) {
            ::std::option::Option::Some(i_p3.clone())
        } else {
            ::std::option::Option::None
        },
    }))
}

/// ```prism
/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_index_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, recv_p2: &crate::syntax::Expr, idx_p3: &crate::syntax::Expr, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (rt_p8, st1_p9) = crate::check::expr::infer_f(env_p0, st_p1, recv_p2);
    let head_p5 = crate::check::types::head_sigil_f(&st1_p9, &rt_p8);
    let inner_p6 = if crate::check::expr::is_time_sigil_f(&head_p5) {
        crate::check::expr::inner_of_f(&st1_p9, &rt_p8)
    } else {
        rt_p8.clone()
    };
    let (v_pa, st2_pb) = crate::check::types::fresh_var_f(&st1_p9, &false, &crate::prelude::Text::lit(""));
    let (k_pc, st3_pd) = crate::check::types::fresh_var_f(&st2_pb, &true, &crate::prelude::Text::lit(""));
    let coll0_p7 = if crate::check::expr::is_plain_sigil_f(&crate::check::types::head_sigil_f(&st3_pd, &inner_p6)) {
        crate::check::expr::inner_of_f(&st3_pd, &inner_p6)
    } else {
        inner_p6.clone()
    };
    match crate::check::types::recording::walk_f(&st3_pd, &coll0_p7) {
        crate::check::types::Ty::TyCon(m13339_0_0, m13339_0_1) if (&m13339_0_0 == &crate::prelude::Text::lit("Text")) && ((&m13339_0_1).len() == 0) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(&st3_pd, &crate::prelude::Text::lit("mismatch"), span_p4, &crate::prelude::Text::lit("a text has no index: a position in a text is a cursor"), &crate::prelude::Text::lit("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`"))),
        _ => {
            let (coll_pf, key_ty_pg) = match crate::check::types::recording::walk_f(&st3_pd, &crate::prelude::or(&crate::check::types::non_empty_coll_o(&st3_pd, &coll0_p7), &coll0_p7)) {
                crate::check::types::Ty::TyMap(_, _) => (crate::check::types::Ty::TyMap(::std::rc::Rc::new(k_pc.clone()), ::std::rc::Rc::new(v_pa.clone())), k_pc.clone()),
                crate::check::types::Ty::TyCon(m13701_1_0, _) if (&m13701_1_0 == &crate::prelude::Text::lit("Table")) => (crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Table"), crate::prelude::Array::from(vec![k_pc.clone(), v_pa.clone()])), k_pc.clone()),
                crate::check::types::Ty::TyCon(m13701_2_0, _) if (&m13701_2_0 == &crate::prelude::Text::lit("Buffer")) => (crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Buffer"), crate::prelude::Array::from(vec![v_pa.clone()])), crate::check::types::t_nat_p()),
                _ => (crate::check::types::Ty::TyArray(::std::rc::Rc::new(v_pa.clone())), crate::check::types::t_nat_p()),
                _ => unreachable!("no arm matched"),
            };
            let args_pe = crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: recv_p2.clone(), span_p: recv_p2.span_p.clone() }, crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: idx_p3.clone(), span_p: idx_p3.span_p.clone() }]);
            crate::check::expr::calls::apply_rule_f(env_p0, &st3_pd, &crate::prelude::Text::lit("[]"), &crate::check::types::Col::CBound, &crate::prelude::Array::from(vec![coll_pf.clone(), key_ty_pg.clone()]), &crate::check::types::Ty::TySig(crate::prelude::Text::lit("?"), ::std::rc::Rc::new(v_pa.clone())), &args_pe, span_p4)
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InferIndex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub struct InferIndex {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub recv_p2: crate::syntax::Expr,
    pub idx_p3: crate::syntax::Expr,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferIndex {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let recv_p2 = &self.recv_p2;
        let idx_p3 = &self.idx_p3;
        let span_p4 = &self.span_p4;
        let env_p0x = env_p0.clone();
        let idx_p3x = idx_p3.clone();
        let recv_p2x = recv_p2.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), recv_p2x.clone()), move |infer_f_12958: (crate::check::types::Ty, crate::check::types::St)| {
            let (rt_p8, st1_p9) = infer_f_12958;
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_p9.clone(), rt_p8.clone()), move |head_sigil_f_12993: crate::prelude::Text| {
                let head_p5 = head_sigil_f_12993;
                let env_p0xz = env_p0x.clone();
                let idx_p3xz = idx_p3x.clone();
                let recv_p2xz = recv_p2x.clone();
                let span_p4xz = span_p4x.clone();
                let st1_p9z = st1_p9.clone();
                let k_let13015 = move |v13015: crate::check::types::Ty| {
                    let inner_p6 = v13015;
                    let (v_pa, st2_pb) = crate::check::types::fresh_var_f(&st1_p9z, &false, &crate::prelude::Text::lit(""));
                    let (k_pc, st3_pd) = crate::check::types::fresh_var_f(&st2_pb, &true, &crate::prelude::Text::lit(""));
                    crate::prelude::call_then(crate::check::types::start_head_sigil_f(st3_pd.clone(), inner_p6.clone()), move |head_sigil_f_13281: crate::prelude::Text| {
                        let env_p0xzz = env_p0xz.clone();
                        let idx_p3xzz = idx_p3xz.clone();
                        let k_pcz = k_pc.clone();
                        let recv_p2xzz = recv_p2xz.clone();
                        let span_p4xzz = span_p4xz.clone();
                        let st3_pdz = st3_pd.clone();
                        let v_paz = v_pa.clone();
                        let k_let13252 = move |v13252: crate::check::types::Ty| {
                            let coll0_p7 = v13252;
                            crate::prelude::call_then(crate::check::types::recording::start_walk_f(st3_pdz.clone(), coll0_p7.clone()), move |walk_f_13345: crate::check::types::Ty| match walk_f_13345 {
                                crate::check::types::Ty::TyCon(m13339_0_0, m13339_0_1) if (&m13339_0_0 == &crate::prelude::Text::lit("Text")) && ((&m13339_0_1).len() == 0) => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(&st3_pdz, &crate::prelude::Text::lit("mismatch"), &span_p4xzz, &crate::prelude::Text::lit("a text has no index: a position in a text is a cursor"), &crate::prelude::Text::lit("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`")))),
                                _ => crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(st3_pdz.clone(), coll0_p7.clone()), move |non_empty_coll_o_13722: ::std::option::Option<crate::check::types::Ty>| crate::prelude::call_then(crate::check::types::recording::start_walk_f(st3_pdz.clone(), crate::prelude::or(&non_empty_coll_o_13722, &coll0_p7)), move |walk_f_13707: crate::check::types::Ty| {
                                    let (coll_pf, key_ty_pg) = match walk_f_13707 {
                                        crate::check::types::Ty::TyMap(_, _) => (crate::check::types::Ty::TyMap(::std::rc::Rc::new(k_pcz.clone()), ::std::rc::Rc::new(v_paz.clone())), k_pcz.clone()),
                                        crate::check::types::Ty::TyCon(m13701_1_0, _) if (&m13701_1_0 == &crate::prelude::Text::lit("Table")) => (crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Table"), crate::prelude::Array::from(vec![k_pcz.clone(), v_paz.clone()])), k_pcz.clone()),
                                        crate::check::types::Ty::TyCon(m13701_2_0, _) if (&m13701_2_0 == &crate::prelude::Text::lit("Buffer")) => (crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Buffer"), crate::prelude::Array::from(vec![v_paz.clone()])), crate::check::types::t_nat_p()),
                                        _ => (crate::check::types::Ty::TyArray(::std::rc::Rc::new(v_paz.clone())), crate::check::types::t_nat_p()),
                                        _ => unreachable!("no arm matched"),
                                    };
                                    let args_pe = crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: recv_p2xzz.clone(), span_p: recv_p2xzz.span_p.clone() }, crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: idx_p3xzz.clone(), span_p: idx_p3xzz.span_p.clone() }]);
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0xzz.clone(), st_p1: st3_pdz.clone(), fname_p2: crate::prelude::Text::lit("[]"), col_p3: crate::check::types::Col::CBound, params_p4: crate::prelude::Array::from(vec![coll_pf.clone(), key_ty_pg.clone()]), res_p5: crate::check::types::Ty::TySig(crate::prelude::Text::lit("?"), ::std::rc::Rc::new(v_paz.clone())), args_p6: args_pe.clone(), span_p7: span_p4xzz.clone() }))
                                })),
                                _ => unreachable!("no arm matched"),
                            })
                        };
                        if crate::check::expr::is_plain_sigil_f(&head_sigil_f_13281) {
                            crate::prelude::call_then(crate::check::expr::start_inner_of_f(st3_pd.clone(), inner_p6.clone()), move |inner_of_f_13304: crate::check::types::Ty| k_let13252(inner_of_f_13304))
                        } else {
                            k_let13252(inner_p6.clone())
                        }
                    })
                };
                if crate::check::expr::is_time_sigil_f(&head_p5) {
                    crate::prelude::call_then(crate::check::expr::start_inner_of_f(st1_p9.clone(), rt_p8.clone()), move |inner_of_f_13048: crate::check::types::Ty| k_let13015(inner_of_f_13048))
                } else {
                    k_let13015(rt_p8.clone())
                }
            })
        })
    }
}

/// `Start InferIndex, x`: what the function value is when passed to `@Run`.
pub fn start_infer_index_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, recv_p2: crate::syntax::Expr, idx_p3: crate::syntax::Expr, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferIndex { env_p0, st_p1, recv_p2, idx_p3, span_p4 })
}
