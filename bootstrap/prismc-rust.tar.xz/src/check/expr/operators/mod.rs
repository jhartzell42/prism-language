//! The module `Check.Expr.Operators`, from `target/bootstrap/src/prismc/check/expr/operators.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
/// ```
pub fn infer_array(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, es_p2: &Array<crate::syntax::Expr>, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (v_p5, st2_p6) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
    let st3_p4 = run_to_end(fold_job(es_p2.clone(), st2_p6.clone(), {
        let env_p0 = env_p0.clone();
        let v_p5 = v_p5.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Expr)| {
            let env_p0 = env_p0.clone();
            let v_p5 = v_p5.clone();
            entered(once_job(move || {
                let s_p7 = p0;
                let x_p8 = p1;
                prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env_p0: env_p0.clone(), st_p1: s_p7.clone(), e_p2: x_p8.clone(), expected_p3: v_p5.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    (crate::check::types::Ty::TyArray(Rc::new(v_p5.clone())), st3_p4.clone())
}

/// The step machine of `InferArray`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
/// ```
pub struct InferArray {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub es_p2: Array<crate::syntax::Expr>,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferArray {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let es_p2 = &self.es_p2;
        let span_p3 = &self.span_p3;
        let (v_p5, st2_p6) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
        let env_p0 = env_p0.clone();
        let es_p2 = es_p2.clone();
        call_value(fold_job(es_p2.clone(), st2_p6.clone(), {
            let env_p0 = env_p0.clone();
            let v_p5 = v_p5.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Expr)| {
                let env_p0 = env_p0.clone();
                let v_p5 = v_p5.clone();
                entered(once_job(move || {
                    let s_p7 = p0;
                    let x_p8 = p1;
                    prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env_p0: env_p0.clone(), st_p1: s_p7.clone(), e_p2: x_p8.clone(), expected_p3: v_p5.clone() }))
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }), move |fold_1476: crate::check::types::St| {
            let st3_p4 = fold_1476;
            prism_rtl::Turn::Finished((crate::check::types::Ty::TyArray(Rc::new(v_p5.clone())), st3_p4.clone()))
        })
    }
}

/// `Start InferArray, x`: what the function value is when passed to `@Run`.
pub fn start_infer_array(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, es_p2: Array<crate::syntax::Expr>, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferArray { env_p0, st_p1, es_p2, span_p3 })
}

/// ```prism
/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
/// ```
pub fn infer_map(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, entries_p2: &Array<(crate::syntax::Expr, crate::syntax::Expr)>, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (k_p8, st1_p9) = crate::check::types::fresh_var(st_p1, &true, &Text::lit(""));
    let (v_pa, st2_pb) = crate::check::types::fresh_var(&st1_p9, &false, &Text::lit(""));
    let n_p4 = len(entries_p2);
    let params_p5 = fold(entries_p2, &Array::new(), &(|acc_pc: &Array<crate::check::types::Ty>, _: &(crate::syntax::Expr, crate::syntax::Expr)| append(acc_pc, &Array::from(vec![k_p8.clone(), v_pa.clone()]))));
    let args_p6 = fold(entries_p2, &Array::new(), &(|acc_pd: &Array<crate::syntax::Arg>, (ke_pe, ve_pf): &(crate::syntax::Expr, crate::syntax::Expr)| append(acc_pd, &Array::from(vec![crate::syntax::Arg { name: None, value: ke_pe.clone(), span: ke_pe.span.clone() }, crate::syntax::Arg { name: None, value: ve_pf.clone(), span: ve_pf.span.clone() }]))));
    let st3_p7 = if &n_p4 > &Nat::from(0u32) {
        crate::check::expr::add_want(&st2_pb, &Text::lit("Prelude.Ord"), &k_p8, span_p3)
    } else {
        st2_pb.clone()
    };
    crate::check::expr::calls::apply_rule(env_p0, &st3_p7, &Text::lit("a map literal"), &crate::check::types::Col::CBound, &params_p5, &crate::check::types::Ty::TyMap(Rc::new(k_p8.clone()), Rc::new(v_pa.clone())), &args_p6, span_p3)
}

/// The step machine of `InferMap`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
/// ```
pub struct InferMap {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub entries_p2: Array<(crate::syntax::Expr, crate::syntax::Expr)>,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferMap {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let entries_p2 = &self.entries_p2;
        let span_p3 = &self.span_p3;
        let (k_p8, st1_p9) = crate::check::types::fresh_var(st_p1, &true, &Text::lit(""));
        let (v_pa, st2_pb) = crate::check::types::fresh_var(&st1_p9, &false, &Text::lit(""));
        let n_p4 = len(entries_p2);
        let params_p5 = fold(entries_p2, &Array::new(), &(|acc_pc: &Array<crate::check::types::Ty>, _: &(crate::syntax::Expr, crate::syntax::Expr)| append(acc_pc, &Array::from(vec![k_p8.clone(), v_pa.clone()]))));
        let args_p6 = fold(entries_p2, &Array::new(), &(|acc_pd: &Array<crate::syntax::Arg>, (ke_pe, ve_pf): &(crate::syntax::Expr, crate::syntax::Expr)| append(acc_pd, &Array::from(vec![crate::syntax::Arg { name: None, value: ke_pe.clone(), span: ke_pe.span.clone() }, crate::syntax::Arg { name: None, value: ve_pf.clone(), span: ve_pf.span.clone() }]))));
        let st3_p7 = if &n_p4 > &Nat::from(0u32) {
            crate::check::expr::add_want(&st2_pb, &Text::lit("Prelude.Ord"), &k_p8, span_p3)
        } else {
            st2_pb.clone()
        };
        prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st3_p7.clone(), fname_p2: Text::lit("a map literal"), col_p3: crate::check::types::Col::CBound, params_p4: params_p5.clone(), res_p5: crate::check::types::Ty::TyMap(Rc::new(k_p8.clone()), Rc::new(v_pa.clone())), args_p6: args_p6.clone(), span_p7: span_p3.clone() }))
    }
}

/// `Start InferMap, x`: what the function value is when passed to `@Run`.
pub fn start_infer_map(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, entries_p2: Array<(crate::syntax::Expr, crate::syntax::Expr)>, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferMap { env_p0, st_p1, entries_p2, span_p3 })
}

/// ```prism
/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_binary(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, op_p2: &Text, lhs_p3: &crate::syntax::Expr, rhs_p4: &crate::syntax::Expr, span_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let args_p6 = Array::from(vec![crate::syntax::Arg { name: None, value: lhs_p3.clone(), span: lhs_p3.span.clone() }, crate::syntax::Arg { name: None, value: rhs_p4.clone(), span: rhs_p4.span.clone() }]);
    if (op_p2 == &Text::lit("and")) || (op_p2 == &Text::lit("or")) {
        crate::check::expr::calls::apply_rule(env_p0, st_p1, op_p2, &crate::check::types::Col::CBound, &Array::from(vec![crate::check::types::t_bool(), crate::check::types::t_bool()]), &crate::check::types::t_bool(), &args_p6, span_p5)
    } else {
        if op_p2 == &Text::lit("on") {
            infer_on(env_p0, st_p1, lhs_p3, rhs_p4, span_p5)
        } else {
            if op_p2 == &Text::lit("<|") {
                {
                    let (v_p7, st2_p8) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                    crate::check::expr::calls::apply_rule(env_p0, &st2_p8, op_p2, &crate::check::types::Col::CBound, &Array::from(vec![crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_p7.clone())), crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_p7.clone()))]), &crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_p7.clone())), &args_p6, span_p5)
                }
            } else {
                if op_p2 == &Text::lit("mod") {
                    {
                        let (v_pa, st2_pb) = crate::check::types::fresh_var(st_p1, &true, &Text::lit(""));
                        let st3_p9 = crate::check::expr::add_want(&st2_pb, &Text::lit("Prelude.Num"), &v_pa, span_p5);
                        crate::check::expr::calls::apply_rule(env_p0, &st3_p9, op_p2, &crate::check::types::Col::CBound, &Array::from(vec![v_pa.clone(), v_pa.clone()]), &v_pa, &args_p6, span_p5)
                    }
                } else {
                    {
                        let (t0_pf, st2_pg) = crate::check::expr::infer_name(env_p0, st_p1, &crate::syntax::SName { sigils: Text::lit(""), path_: Array::from(vec![op_p2.clone()]), span: span_p5.clone() }, span_p5);
                        let t_pc = if op_p2 == &Text::lit("/") { quotient_of(&st2_pg, &t0_pf) } else { t0_pf.clone() };
                        let st2b_pd = if op_p2 == &Text::lit("-?") {
                            crate::check::types::recording::note_size_ty(&st2_pg, span_p5, &crate::check::types::recording::walk(&st2_pg, &t0_pf))
                        } else {
                            st2_pg.clone()
                        };
                        let st3_pe = if op_p2 == &Text::lit("-") {
                            sub_want(&st2b_pd, &t_pc, span_p5)
                        } else {
                            st2b_pd.clone()
                        };
                        crate::check::expr::calls::apply_fn(env_p0, &st3_pe, op_p2, &t_pc, &args_p6, span_p5)
                    }
                }
            }
        }
    }
}

/// The step machine of `InferBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
/// ```
pub struct InferBinary {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub op_p2: Text,
    pub lhs_p3: crate::syntax::Expr,
    pub rhs_p4: crate::syntax::Expr,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferBinary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let op_p2 = &self.op_p2;
        let lhs_p3 = &self.lhs_p3;
        let rhs_p4 = &self.rhs_p4;
        let span_p5 = &self.span_p5;
        let args_p6 = Array::from(vec![crate::syntax::Arg { name: None, value: lhs_p3.clone(), span: lhs_p3.span.clone() }, crate::syntax::Arg { name: None, value: rhs_p4.clone(), span: rhs_p4.span.clone() }]);
        if (op_p2 == &Text::lit("and")) || (op_p2 == &Text::lit("or")) {
            prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st_p1.clone(), fname_p2: op_p2.clone(), col_p3: crate::check::types::Col::CBound, params_p4: Array::from(vec![crate::check::types::t_bool(), crate::check::types::t_bool()]), res_p5: crate::check::types::t_bool(), args_p6: args_p6.clone(), span_p7: span_p5.clone() }))
        } else {
            if op_p2 == &Text::lit("on") {
                prism_rtl::Turn::More(Rc::new(InferOn { env_p0: env_p0.clone(), st_p1: st_p1.clone(), lhs_p2: lhs_p3.clone(), rhs_p3: rhs_p4.clone(), span_p4: span_p5.clone() }))
            } else {
                if op_p2 == &Text::lit("<|") {
                    {
                        let (v_p7, st2_p8) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                        prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st2_p8.clone(), fname_p2: op_p2.clone(), col_p3: crate::check::types::Col::CBound, params_p4: Array::from(vec![crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_p7.clone())), crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_p7.clone()))]), res_p5: crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_p7.clone())), args_p6: args_p6.clone(), span_p7: span_p5.clone() }))
                    }
                } else {
                    if op_p2 == &Text::lit("mod") {
                        {
                            let (v_pa, st2_pb) = crate::check::types::fresh_var(st_p1, &true, &Text::lit(""));
                            let st3_p9 = crate::check::expr::add_want(&st2_pb, &Text::lit("Prelude.Num"), &v_pa, span_p5);
                            prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st3_p9.clone(), fname_p2: op_p2.clone(), col_p3: crate::check::types::Col::CBound, params_p4: Array::from(vec![v_pa.clone(), v_pa.clone()]), res_p5: v_pa.clone(), args_p6: args_p6.clone(), span_p7: span_p5.clone() }))
                        }
                    } else {
                        {
                            let env_p0 = env_p0.clone();
                            let op_p2 = op_p2.clone();
                            let span_p5 = span_p5.clone();
                            let st_p1 = st_p1.clone();
                            call_then(crate::check::expr::start_infer_name(env_p0.clone(), st_p1.clone(), crate::syntax::SName { sigils: Text::lit(""), path_: Array::from(vec![op_p2.clone()]), span: span_p5.clone() }, span_p5.clone()), move |infer_name_3258: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t0_pf, st2_pg) = infer_name_3258;
                                let t_pc = if &op_p2 == &Text::lit("/") { quotient_of(&st2_pg, &t0_pf) } else { t0_pf.clone() };
                                let st2b_pd = if &op_p2 == &Text::lit("-?") {
                                    crate::check::types::recording::note_size_ty(&st2_pg, &span_p5, &crate::check::types::recording::walk(&st2_pg, &t0_pf))
                                } else {
                                    st2_pg.clone()
                                };
                                let st3_pe = if &op_p2 == &Text::lit("-") {
                                    sub_want(&st2b_pd, &t_pc, &span_p5)
                                } else {
                                    st2b_pd.clone()
                                };
                                prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyFn { env_p0: env_p0.clone(), st_p1: st3_pe.clone(), fname_p2: op_p2.clone(), fty_p3: t_pc.clone(), args_p4: args_p6.clone(), span_p5: span_p5.clone() }))
                            })
                        }
                    }
                }
            }
        }
    }
}

/// `Start InferBinary, x`: what the function value is when passed to `@Run`.
pub fn start_infer_binary(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, op_p2: Text, lhs_p3: crate::syntax::Expr, rhs_p4: crate::syntax::Expr, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferBinary { env_p0, st_p1, op_p2, lhs_p3, rhs_p4, span_p5 })
}

/// ```prism
/// QuotientOf: unbounded fn St, Ty -> Ty
/// ```
pub fn quotient_of(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match crate::check::types::recording::walk(st_p0, t_p1) {
        crate::check::types::Ty::TyFn(c_p2, ps_p3, _) => match index(&ps_p3, &Nat::from(0u32)) {
            Some(p_p4) => crate::check::types::Ty::TyFn(c_p2, ps_p3.clone(), Rc::new(crate::check::types::Ty::TyAssoc(Text::lit("Quotient"), Rc::new(p_p4)))),
            None => t_p1.clone(),
        },
        other_p5 => other_p5,
    }
}

/// The step machine of `QuotientOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// QuotientOf: unbounded fn St, Ty -> Ty
/// ```
pub struct QuotientOf {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for QuotientOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), t_p1.clone()), move |walk_3748: crate::check::types::Ty| match walk_3748 {
            crate::check::types::Ty::TyFn(c_p2, ps_p3, _) => match index(&ps_p3, &Nat::from(0u32)) {
                Some(p_p4) => prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c_p2.clone(), ps_p3.clone(), Rc::new(crate::check::types::Ty::TyAssoc(Text::lit("Quotient"), Rc::new(p_p4.clone()))))),
                None => prism_rtl::Turn::Finished(t_p1.clone()),
            },
            other_p5 => prism_rtl::Turn::Finished(other_p5.clone()),
        })
    }
}

/// `Start QuotientOf, x`: what the function value is when passed to `@Run`.
pub fn start_quotient_of(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(QuotientOf { st_p0, t_p1 })
}

/// ```prism
/// SubWant: unbounded fn St, Ty, Range -> St
/// ```
pub fn sub_want(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk(st_p0, t_p1) {
        crate::check::types::Ty::TyFn(_, ps_p3, _) => match index(&ps_p3, &Nat::from(0u32)) {
            Some(p_p4) => crate::check::expr::add_want(st_p0, &Text::lit("Prelude.Sub"), &p_p4, span_p2),
            None => st_p0.clone(),
        },
        _ => st_p0.clone(),
    }
}

/// The step machine of `SubWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubWant: unbounded fn St, Ty, Range -> St
/// ```
pub struct SubWant {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub span_p2: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for SubWant {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let span_p2 = &self.span_p2;
        let span_p2 = span_p2.clone();
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), t_p1.clone()), move |walk_4076: crate::check::types::Ty| match walk_4076 {
            crate::check::types::Ty::TyFn(_, ps_p3, _) => match index(&ps_p3, &Nat::from(0u32)) {
                Some(p_p4) => prism_rtl::Turn::Finished(crate::check::expr::add_want(&st_p0, &Text::lit("Prelude.Sub"), &p_p4, &span_p2)),
                None => prism_rtl::Turn::Finished(st_p0.clone()),
            },
            _ => prism_rtl::Turn::Finished(st_p0.clone()),
        })
    }
}

/// `Start SubWant, x`: what the function value is when passed to `@Run`.
pub fn start_sub_want(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty, span_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SubWant { st_p0, t_p1, span_p2 })
}

/// ```prism
/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_on(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, lhs_p2: &crate::syntax::Expr, rhs_p3: &crate::syntax::Expr, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (a_p5, st1_p6) = crate::check::types::fresh_var(st_p1, &true, &Text::lit(""));
    let (b_p7, st2_p8) = crate::check::types::fresh_var(&st1_p6, &true, &Text::lit(""));
    let (rt_p9, st3_pa) = crate::check::expr::infer(env_p0, &st2_p8, rhs_p3);
    if ((&crate::check::types::head_sigil(&st3_pa, &rt_p9) != &Text::lit("!")) && (&rt_p9 != &crate::check::types::Ty::TyErr)) && !crate::check::types::is_flex_var(&st3_pa, &rt_p9) {
        (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st3_pa, &Text::lit("mismatch"), &rhs_p3.span, &Text::from(format!("`on` fires with an event on its right; this is `{}`", &crate::check::types::show_ty(&st3_pa, &rt_p9)))))
    } else {
        {
            let args_pb = Array::from(vec![crate::syntax::Arg { name: None, value: lhs_p2.clone(), span: lhs_p2.span.clone() }, crate::syntax::Arg { name: None, value: rhs_p3.clone(), span: rhs_p3.span.clone() }]);
            crate::check::expr::calls::apply_rule(env_p0, &st3_pa, &Text::lit("on"), &crate::check::types::Col::CBound, &Array::from(vec![a_p5.clone(), b_p7.clone()]), &a_p5, &args_pb, span_p4)
        }
    }
}

/// The step machine of `InferOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub struct InferOn {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub lhs_p2: crate::syntax::Expr,
    pub rhs_p3: crate::syntax::Expr,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferOn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let lhs_p2 = &self.lhs_p2;
        let rhs_p3 = &self.rhs_p3;
        let span_p4 = &self.span_p4;
        let (a_p5, st1_p6) = crate::check::types::fresh_var(st_p1, &true, &Text::lit(""));
        let (b_p7, st2_p8) = crate::check::types::fresh_var(&st1_p6, &true, &Text::lit(""));
        let env_p0 = env_p0.clone();
        let lhs_p2 = lhs_p2.clone();
        let rhs_p3 = rhs_p3.clone();
        let span_p4 = span_p4.clone();
        call_then(crate::check::expr::start_infer(env_p0.clone(), st2_p8.clone(), rhs_p3.clone()), move |infer_4554: (crate::check::types::Ty, crate::check::types::St)| {
            let (rt_p9, st3_pa) = infer_4554;
            call_then(crate::check::types::start_head_sigil(st3_pa.clone(), rt_p9.clone()), move |head_sigil_4582: Text| if ((&head_sigil_4582 != &Text::lit("!")) && (&rt_p9 != &crate::check::types::Ty::TyErr)) && !crate::check::types::is_flex_var(&st3_pa, &rt_p9) {
                call_then(crate::check::types::start_show_ty(st3_pa.clone(), rt_p9.clone()), move |show_ty_4752: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st3_pa, &Text::lit("mismatch"), &rhs_p3.span, &Text::from(format!("`on` fires with an event on its right; this is `{}`", &show_ty_4752))))))
            } else {
                {
                    let args_pb = Array::from(vec![crate::syntax::Arg { name: None, value: lhs_p2.clone(), span: lhs_p2.span.clone() }, crate::syntax::Arg { name: None, value: rhs_p3.clone(), span: rhs_p3.span.clone() }]);
                    prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st3_pa.clone(), fname_p2: Text::lit("on"), col_p3: crate::check::types::Col::CBound, params_p4: Array::from(vec![a_p5.clone(), b_p7.clone()]), res_p5: a_p5.clone(), args_p6: args_pb.clone(), span_p7: span_p4.clone() }))
                }
            })
        })
    }
}

/// `Start InferOn, x`: what the function value is when passed to `@Run`.
pub fn start_infer_on(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, lhs_p2: crate::syntax::Expr, rhs_p3: crate::syntax::Expr, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferOn { env_p0, st_p1, lhs_p2, rhs_p3, span_p4 })
}

/// ```prism
/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_unary(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, op_p2: &Text, x_p3: &crate::syntax::Expr, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let args_p5 = Array::from(vec![crate::syntax::Arg { name: None, value: x_p3.clone(), span: x_p3.span.clone() }]);
    match op_p2 {
        m5115_0 if (m5115_0 == &Text::lit("not")) => crate::check::expr::calls::apply_rule(env_p0, st_p1, &Text::lit("not"), &crate::check::types::Col::CBound, &Array::from(vec![crate::check::types::t_bool()]), &crate::check::types::t_bool(), &args_p5, span_p4),
        m5115_1 if (m5115_1 == &Text::lit("neg")) => match &*x_p3.kind {
            crate::syntax::ExprKind::ELit(l_p6) => {
                let (t_p7, st2_p8) = crate::check::expr::infer_lit(env_p0, st_p1, l_p6, &true, span_p4);
                (t_p7.clone(), crate::check::types::recording::note_ty(&st2_p8, &x_p3.span, &t_p7))
            },
            _ => {
                let (v_pa, st2_pb) = crate::check::types::fresh_var(st_p1, &true, &Text::lit(""));
                let st3_p9 = crate::check::expr::add_want(&crate::check::expr::add_want(&st2_pb, &Text::lit("Prelude.Num"), &v_pa, span_p4), &Text::lit("Prelude.Signed"), &v_pa, span_p4);
                crate::check::expr::calls::apply_rule(env_p0, &st3_p9, &Text::lit("-"), &crate::check::types::Col::CBound, &Array::from(vec![v_pa.clone()]), &v_pa, &args_p5, span_p4)
            },
        },
        _ => crate::check::expr::infer(env_p0, st_p1, x_p3),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InferUnary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub struct InferUnary {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub op_p2: Text,
    pub x_p3: crate::syntax::Expr,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferUnary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let op_p2 = &self.op_p2;
        let x_p3 = &self.x_p3;
        let span_p4 = &self.span_p4;
        let args_p5 = Array::from(vec![crate::syntax::Arg { name: None, value: x_p3.clone(), span: x_p3.span.clone() }]);
        match op_p2 {
            m5115_0 if (m5115_0 == &Text::lit("not")) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st_p1.clone(), fname_p2: Text::lit("not"), col_p3: crate::check::types::Col::CBound, params_p4: Array::from(vec![crate::check::types::t_bool()]), res_p5: crate::check::types::t_bool(), args_p6: args_p5.clone(), span_p7: span_p4.clone() })),
            m5115_1 if (m5115_1 == &Text::lit("neg")) => match &*x_p3.kind {
                crate::syntax::ExprKind::ELit(l_p6) => {
                    let env_p0 = env_p0.clone();
                    let l_p6 = l_p6.clone();
                    let span_p4 = span_p4.clone();
                    let st_p1 = st_p1.clone();
                    let x_p3 = x_p3.clone();
                    call_then(crate::check::expr::start_infer_lit(env_p0.clone(), st_p1.clone(), l_p6.clone(), true, span_p4.clone()), move |infer_lit_5285: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_p7, st2_p8) = infer_lit_5285;
                        prism_rtl::Turn::Finished((t_p7.clone(), crate::check::types::recording::note_ty(&st2_p8, &x_p3.span, &t_p7)))
                    })
                },
                _ => {
                    let (v_pa, st2_pb) = crate::check::types::fresh_var(st_p1, &true, &Text::lit(""));
                    let st3_p9 = crate::check::expr::add_want(&crate::check::expr::add_want(&st2_pb, &Text::lit("Prelude.Num"), &v_pa, span_p4), &Text::lit("Prelude.Signed"), &v_pa, span_p4);
                    prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st3_p9.clone(), fname_p2: Text::lit("-"), col_p3: crate::check::types::Col::CBound, params_p4: Array::from(vec![v_pa.clone()]), res_p5: v_pa.clone(), args_p6: args_p5.clone(), span_p7: span_p4.clone() }))
                },
            },
            _ => prism_rtl::Turn::More(Rc::new(crate::check::expr::Infer { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: x_p3.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start InferUnary, x`: what the function value is when passed to `@Run`.
pub fn start_infer_unary(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, op_p2: Text, x_p3: crate::syntax::Expr, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferUnary { env_p0, st_p1, op_p2, x_p3, span_p4 })
}

/// ```prism
/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_free_sigil(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, s_p2: &Text, x_p3: &crate::syntax::Expr, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    if s_p2 == &Text::lit("@") {
        {
            let (t_p5, st2_p6) = crate::check::expr::infer(env_p0, st_p1, x_p3);
            (crate::check::types::Ty::TyAt(Rc::new(t_p5.clone()), env_p0.scope.clone()), st2_p6.clone())
        }
    } else {
        if ((s_p2 == &Text::lit("?")) || (s_p2 == &Text::lit("~"))) || (s_p2 == &Text::lit("$")) {
            {
                let (v_p7, st2_p8) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                if is_blueprint_expr(env_p0, &st2_p8, x_p3) {
                    {
                        let (t_p9, st3_pa) = crate::check::expr::infer(env_p0, &st2_p8, x_p3);
                        (crate::check::types::Ty::TySig(s_p2.clone(), Rc::new(t_p9.clone())), st3_pa.clone())
                    }
                } else {
                    crate::check::expr::calls::apply_rule(env_p0, &st2_p8, &Text::from(format!("{}", s_p2)), &crate::check::types::Col::CBound, &Array::from(vec![v_p7.clone()]), &crate::check::types::Ty::TySig(s_p2.clone(), Rc::new(v_p7.clone())), &Array::from(vec![crate::syntax::Arg { name: None, value: x_p3.clone(), span: x_p3.span.clone() }]), span_p4)
                }
            }
        } else {
            {
                let (t_pb, st2_pc) = crate::check::expr::infer(env_p0, st_p1, x_p3);
                (crate::check::types::with_marks(s_p2, &t_pb, &env_p0.scope), st2_pc.clone())
            }
        }
    }
}

/// The step machine of `InferFreeSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub struct InferFreeSigil {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub s_p2: Text,
    pub x_p3: crate::syntax::Expr,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferFreeSigil {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let s_p2 = &self.s_p2;
        let x_p3 = &self.x_p3;
        let span_p4 = &self.span_p4;
        if s_p2 == &Text::lit("@") {
            {
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                let x_p3 = x_p3.clone();
                call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), x_p3.clone()), move |infer_5931: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p5, st2_p6) = infer_5931;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyAt(Rc::new(t_p5.clone()), env_p0.scope.clone()), st2_p6.clone()))
                })
            }
        } else {
            if ((s_p2 == &Text::lit("?")) || (s_p2 == &Text::lit("~"))) || (s_p2 == &Text::lit("$")) {
                {
                    let (v_p7, st2_p8) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                    if is_blueprint_expr(env_p0, &st2_p8, x_p3) {
                        {
                            let env_p0 = env_p0.clone();
                            let s_p2 = s_p2.clone();
                            let x_p3 = x_p3.clone();
                            call_then(crate::check::expr::start_infer(env_p0.clone(), st2_p8.clone(), x_p3.clone()), move |infer_6149: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t_p9, st3_pa) = infer_6149;
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(s_p2.clone(), Rc::new(t_p9.clone())), st3_pa.clone()))
                            })
                        }
                    } else {
                        prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st2_p8.clone(), fname_p2: Text::from(format!("{}", s_p2)), col_p3: crate::check::types::Col::CBound, params_p4: Array::from(vec![v_p7.clone()]), res_p5: crate::check::types::Ty::TySig(s_p2.clone(), Rc::new(v_p7.clone())), args_p6: Array::from(vec![crate::syntax::Arg { name: None, value: x_p3.clone(), span: x_p3.span.clone() }]), span_p7: span_p4.clone() }))
                    }
                }
            } else {
                {
                    let env_p0 = env_p0.clone();
                    let s_p2 = s_p2.clone();
                    let st_p1 = st_p1.clone();
                    let x_p3 = x_p3.clone();
                    call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), x_p3.clone()), move |infer_6352: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_pb, st2_pc) = infer_6352;
                        prism_rtl::Turn::Finished((crate::check::types::with_marks(&s_p2, &t_pb, &env_p0.scope), st2_pc.clone()))
                    })
                }
            }
        }
    }
}

/// `Start InferFreeSigil, x`: what the function value is when passed to `@Run`.
pub fn start_infer_free_sigil(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, s_p2: Text, x_p3: crate::syntax::Expr, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferFreeSigil { env_p0, st_p1, s_p2, x_p3, span_p4 })
}

/// ```prism
/// IsBlueprintExpr: fn Env, St, Expr -> Bool
/// ```
pub fn is_blueprint_expr(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, x_p2: &crate::syntax::Expr) -> bool {
    match &*x_p2.kind {
        crate::syntax::ExprKind::EFreeSigil(m6632_0_0, _) if (m6632_0_0 == &Text::lit("@")) => true,
        crate::syntax::ExprKind::EGroup(y_p3) => is_blueprint_expr(env_p0, st_p1, &**y_p3),
        crate::syntax::ExprKind::ECall(c_p4, _, _, _) => match &*c_p4.kind {
            crate::syntax::ExprKind::EName(n_p5) => crate::syntax::lexer::chars::has_prefix(&n_p5.sigils, &Text::lit("@")),
            _ => false,
        },
        crate::syntax::ExprKind::EName(n_p6) => crate::syntax::lexer::chars::has_prefix(&n_p6.sigils, &Text::lit("@")),
        crate::syntax::ExprKind::EWidgetBlock(_) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
/// ```
pub fn infer_field(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, recv_p2: &crate::syntax::Expr, sigils_p3: &Text, name_p4: &crate::syntax::Ident, span_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (rt_pi, st1_pj) = crate::check::expr::infer(env_p0, st_p1, recv_p2);
    let head_p6 = crate::check::types::head_sigil(&st1_pj, &rt_pi);
    let inner_p7 = if crate::check::expr::is_time_sigil(&head_p6) {
        crate::check::expr::inner_of(&st1_pj, &rt_pi)
    } else {
        rt_pi.clone()
    };
    let ih_p8 = if crate::check::blocks::borrows::is_ref(recv_p2) {
        Text::lit("")
    } else {
        crate::check::types::head_sigil(&st1_pj, &inner_p7)
    };
    let plain_t_p9 = if crate::check::expr::is_plain_sigil(&crate::check::types::head_sigil(&st1_pj, &inner_p7)) {
        crate::check::expr::inner_of(&st1_pj, &inner_p7)
    } else {
        inner_p7.clone()
    };
    let st2_pa = if &head_p6 == &Text::lit("@") {
        crate::check::types::recording::err(&st1_pj, &Text::lit("blueprint-operand"), &recv_p2.span, &Text::from(format!("`.{}` over a blueprint; bind it first", &name_p4.name)))
    } else {
        st1_pj.clone()
    };
    let (ft_pk, st3_pl) = field_type(env_p0, &st2_pa, &plain_t_p9, &name_p4.name, span_p5);
    let stack_pb = crate::check::types::stack_of(&st3_pl, &ft_pk);
    let bad_pc = (((&stack_pb != sigils_p3) && (&ft_pk != &crate::check::types::Ty::TyErr)) && !crate::check::types::is_flex_var(&st3_pl, &ft_pk)) && !crate::check::blocks::borrows::is_ref(recv_p2);
    let st4_pd = if bad_pc {
        crate::check::types::recording::err_fix(&st3_pl, &Text::lit("mark-stack"), &name_p4.span, &Text::from(format!("`.{}{}` has type `{}`, whose stack is `{}`; the access shows `{}`", sigils_p3, &name_p4.name, &crate::check::types::show_ty(&st3_pl, &ft_pk), &stack_pb, sigils_p3)), &Text::from(format!("write `.{}{}`", &stack_pb, &name_p4.name)))
    } else {
        st3_pl.clone()
    };
    let with_opt_pe = if crate::check::expr::is_plain_sigil(&ih_p8) {
        crate::check::types::Ty::TySig(ih_p8.clone(), Rc::new(ft_pk.clone()))
    } else {
        ft_pk.clone()
    };
    let res_pf = if crate::check::expr::is_time_sigil(&head_p6) {
        crate::check::types::Ty::TySig(head_p6.clone(), Rc::new(with_opt_pe.clone()))
    } else {
        with_opt_pe.clone()
    };
    let st5_pg = if crate::check::expr::is_time_sigil(&head_p6) {
        crate::check::expr::calls::elab(&st4_pd, span_p5, &Text::from(format!(".{}", &name_p4.name)), &Text::lit("map"), &head_p6)
    } else {
        st4_pd.clone()
    };
    let st6_ph = if crate::check::expr::is_plain_sigil(&ih_p8) {
        crate::check::types::recording::note_lift(&st5_pg, span_p5, &ih_p8, &Array::from(vec![recv_p2.span.clone()]))
    } else {
        st5_pg.clone()
    };
    (res_pf.clone(), st6_ph.clone())
}

/// The step machine of `InferField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
/// ```
pub struct InferField {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub recv_p2: crate::syntax::Expr,
    pub sigils_p3: Text,
    pub name_p4: crate::syntax::Ident,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferField {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let recv_p2 = &self.recv_p2;
        let sigils_p3 = &self.sigils_p3;
        let name_p4 = &self.name_p4;
        let span_p5 = &self.span_p5;
        let env_p0 = env_p0.clone();
        let name_p4 = name_p4.clone();
        let recv_p2 = recv_p2.clone();
        let sigils_p3 = sigils_p3.clone();
        let span_p5 = span_p5.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), recv_p2.clone()), move |infer_7445: (crate::check::types::Ty, crate::check::types::St)| {
            let (rt_pi, st1_pj) = infer_7445;
            call_then(crate::check::types::start_head_sigil(st1_pj.clone(), rt_pi.clone()), move |head_sigil_7480: Text| {
                let head_p6 = head_sigil_7480;
                let inner_p7 = if crate::check::expr::is_time_sigil(&head_p6) {
                    crate::check::expr::inner_of(&st1_pj, &rt_pi)
                } else {
                    rt_pi.clone()
                };
                let ih_p8 = if crate::check::blocks::borrows::is_ref(&recv_p2) {
                    Text::lit("")
                } else {
                    crate::check::types::head_sigil(&st1_pj, &inner_p7)
                };
                call_then(crate::check::types::start_head_sigil(st1_pj.clone(), inner_p7.clone()), move |head_sigil_7814: Text| {
                    let plain_t_p9 = if crate::check::expr::is_plain_sigil(&head_sigil_7814) {
                        crate::check::expr::inner_of(&st1_pj, &inner_p7)
                    } else {
                        inner_p7.clone()
                    };
                    let st2_pa = if &head_p6 == &Text::lit("@") {
                        crate::check::types::recording::err(&st1_pj, &Text::lit("blueprint-operand"), &recv_p2.span, &Text::from(format!("`.{}` over a blueprint; bind it first", &name_p4.name)))
                    } else {
                        st1_pj.clone()
                    };
                    call_then(start_field_type(env_p0.clone(), st2_pa.clone(), plain_t_p9.clone(), name_p4.name.clone(), span_p5.clone()), move |field_type_8020: (crate::check::types::Ty, crate::check::types::St)| {
                        let (ft_pk, st3_pl) = field_type_8020;
                        call_then(crate::check::types::start_stack_of(st3_pl.clone(), ft_pk.clone()), move |stack_of_8080: Text| {
                            let stack_pb = stack_of_8080;
                            let bad_pc = (((&stack_pb != &sigils_p3) && (&ft_pk != &crate::check::types::Ty::TyErr)) && !crate::check::types::is_flex_var(&st3_pl, &ft_pk)) && !crate::check::blocks::borrows::is_ref(&recv_p2);
                            let st4_pd = if bad_pc {
                                crate::check::types::recording::err_fix(&st3_pl, &Text::lit("mark-stack"), &name_p4.span, &Text::from(format!("`.{}{}` has type `{}`, whose stack is `{}`; the access shows `{}`", &sigils_p3, &name_p4.name, &crate::check::types::show_ty(&st3_pl, &ft_pk), &stack_pb, &sigils_p3)), &Text::from(format!("write `.{}{}`", &stack_pb, &name_p4.name)))
                            } else {
                                st3_pl.clone()
                            };
                            let with_opt_pe = if crate::check::expr::is_plain_sigil(&ih_p8) {
                                crate::check::types::Ty::TySig(ih_p8.clone(), Rc::new(ft_pk.clone()))
                            } else {
                                ft_pk.clone()
                            };
                            let res_pf = if crate::check::expr::is_time_sigil(&head_p6) {
                                crate::check::types::Ty::TySig(head_p6.clone(), Rc::new(with_opt_pe.clone()))
                            } else {
                                with_opt_pe.clone()
                            };
                            let st5_pg = if crate::check::expr::is_time_sigil(&head_p6) {
                                crate::check::expr::calls::elab(&st4_pd, &span_p5, &Text::from(format!(".{}", &name_p4.name)), &Text::lit("map"), &head_p6)
                            } else {
                                st4_pd.clone()
                            };
                            let st6_ph = if crate::check::expr::is_plain_sigil(&ih_p8) {
                                crate::check::types::recording::note_lift(&st5_pg, &span_p5, &ih_p8, &Array::from(vec![recv_p2.span.clone()]))
                            } else {
                                st5_pg.clone()
                            };
                            prism_rtl::Turn::Finished((res_pf.clone(), st6_ph.clone()))
                        })
                    })
                })
            })
        })
    }
}

/// `Start InferField, x`: what the function value is when passed to `@Run`.
pub fn start_infer_field(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, recv_p2: crate::syntax::Expr, sigils_p3: Text, name_p4: crate::syntax::Ident, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferField { env_p0, st_p1, recv_p2, sigils_p3, name_p4, span_p5 })
}

/// ```prism
/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
/// ```
pub fn field_type(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty, field_p3: &Text, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::check::types::recording::walk(st_p1, t_p2) {
        crate::check::types::Ty::TyCon(n_p5, args_p6) => match get(&env_p0.g.ctors, &n_p5) {
            Some(c_p7) => match index_of(&c_p7.fields, field_p3) {
                Some(i_p8) => {
                    let inst_p9 = crate::check::env::reading::param_inst(&c_p7.params, &args_p6);
                    (crate::check::types::schemes::subst_q(&inst_p9, &or(&index(&c_p7.args, &i_p8), &crate::check::types::Ty::TyErr)), st_p1.clone())
                },
                None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), span_p4, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&n_p5), field_p3)))),
            },
            None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), span_p4, &Text::from(format!("`{}` has no fields", &crate::check::types::bare_name(&n_p5))))),
        },
        crate::check::types::Ty::TyFlex(_) => {
            let owners_pa = filter(&values(&env_p0.g.ctors), &(|c_pb: &crate::check::env::CtorInfo| crate::check::types::has_text(&c_pb.fields, field_p3)));
            match index(&owners_pa, &Nat::from(0u32)) {
                Some(c_pc) => if &len(&owners_pa) > &Nat::from(1u32) {
                    {
                        let (v_pd, st2_pe) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                        (v_pd.clone(), crate::check::types::unify::ask_field(&st2_pe, t_p2, field_p3, &v_pd, span_p4, &each(&owners_pa, &(|o_pf: &crate::check::env::CtorInfo| crate::check::types::bare_name(&o_pf.owner)))))
                    }
                } else {
                    {
                        let (self_ph, st2_pi) = crate::check::expr::ctor_value(env_p0, st_p1, &{
                            let mut this: crate::check::env::CtorInfo = c_pc.clone();
                            this.args = Array::new();
                            this
                        }, span_p4);
                        let st3_pg = crate::check::types::unify::unify(&st2_pi, &self_ph, t_p2, span_p4);
                        field_type(env_p0, &st3_pg, &self_ph, field_p3, span_p4)
                    }
                },
                None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), span_p4, &Text::from(format!("no record has a field `{}`", field_p3)))),
            }
        },
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st_p1.clone()),
        other_pj => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), span_p4, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::show_ty(st_p1, &other_pj), field_p3)))),
    }
}

/// The step machine of `FieldType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
/// ```
pub struct FieldType {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
    pub field_p3: Text,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for FieldType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let field_p3 = &self.field_p3;
        let span_p4 = &self.span_p4;
        let env_p0 = env_p0.clone();
        let field_p3 = field_p3.clone();
        let span_p4 = span_p4.clone();
        let st_p1 = st_p1.clone();
        let t_p2 = t_p2.clone();
        call_then(crate::check::types::recording::start_walk(st_p1.clone(), t_p2.clone()), move |walk_9134: crate::check::types::Ty| match walk_9134 {
            crate::check::types::Ty::TyCon(n_p5, args_p6) => match get(&env_p0.g.ctors, &n_p5) {
                Some(c_p7) => match index_of(&c_p7.fields, &field_p3) {
                    Some(i_p8) => {
                        let inst_p9 = crate::check::env::reading::param_inst(&c_p7.params, &args_p6);
                        call_then(crate::check::types::schemes::start_subst_q(inst_p9.clone(), or(&index(&c_p7.args, &i_p8), &crate::check::types::Ty::TyErr)), move |subst_q_9344: crate::check::types::Ty| prism_rtl::Turn::Finished((subst_q_9344, st_p1.clone())))
                    },
                    None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st_p1, &Text::lit("mismatch"), &span_p4, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&n_p5), &field_p3))))),
                },
                None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st_p1, &Text::lit("mismatch"), &span_p4, &Text::from(format!("`{}` has no fields", &crate::check::types::bare_name(&n_p5)))))),
            },
            crate::check::types::Ty::TyFlex(_) => {
                let owners_pa = filter(&values(&env_p0.g.ctors), &(|c_pb: &crate::check::env::CtorInfo| crate::check::types::has_text(&c_pb.fields, &field_p3)));
                match index(&owners_pa, &Nat::from(0u32)) {
                    Some(c_pc) => if &len(&owners_pa) > &Nat::from(1u32) {
                        {
                            let (v_pd, st2_pe) = crate::check::types::fresh_var(&st_p1, &false, &Text::lit(""));
                            prism_rtl::Turn::Finished((v_pd.clone(), crate::check::types::unify::ask_field(&st2_pe, &t_p2, &field_p3, &v_pd, &span_p4, &each(&owners_pa, &(|o_pf: &crate::check::env::CtorInfo| crate::check::types::bare_name(&o_pf.owner))))))
                        }
                    } else {
                        call_then(crate::check::expr::start_ctor_value(env_p0.clone(), st_p1.clone(), {
                            let mut this: crate::check::env::CtorInfo = c_pc.clone();
                            this.args = Array::new();
                            this
                        }, span_p4.clone()), move |ctor_value_10228: (crate::check::types::Ty, crate::check::types::St)| {
                            let (self_ph, st2_pi) = ctor_value_10228;
                            call_then(crate::check::types::unify::start_unify(st2_pi.clone(), self_ph.clone(), t_p2.clone(), span_p4.clone()), move |unify_10335: crate::check::types::St| {
                                let st3_pg = unify_10335;
                                prism_rtl::Turn::More(Rc::new(FieldType { env_p0: env_p0.clone(), st_p1: st3_pg.clone(), t_p2: self_ph.clone(), field_p3: field_p3.clone(), span_p4: span_p4.clone() }))
                            })
                        })
                    },
                    None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st_p1, &Text::lit("mismatch"), &span_p4, &Text::from(format!("no record has a field `{}`", &field_p3))))),
                }
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st_p1.clone())),
            other_pj => call_then(crate::check::types::start_show_ty(st_p1.clone(), other_pj.clone()), move |show_ty_10583: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st_p1, &Text::lit("mismatch"), &span_p4, &Text::from(format!("`{}` has no field `{}`", &show_ty_10583, &field_p3)))))),
        })
    }
}

/// `Start FieldType, x`: what the function value is when passed to `@Run`.
pub fn start_field_type(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty, field_p3: Text, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(FieldType { env_p0, st_p1, t_p2, field_p3, span_p4 })
}

/// ```prism
/// ?IndexOf: fn [Text], Text -> ?Nat
/// ```
pub fn index_of(xs_p0: &Array<Text>, x_p1: &Text) -> Option<Nat> {
    fold(&crate::check::errors::range0(&len(xs_p0)), &None, &(|found_o2: &Option<Nat>, i_p3: &Nat| match found_o2 {
        Some(f_p4) => Some(f_p4.clone()),
        None => if &index(xs_p0, i_p3) == &Some(x_p1.clone()) { Some(i_p3.clone()) } else { None },
    }))
}

/// ```prism
/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_index(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, recv_p2: &crate::syntax::Expr, idx_p3: &crate::syntax::Expr, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (rt_p8, st1_p9) = crate::check::expr::infer(env_p0, st_p1, recv_p2);
    let head_p5 = crate::check::types::head_sigil(&st1_p9, &rt_p8);
    let inner_p6 = if crate::check::expr::is_time_sigil(&head_p5) {
        crate::check::expr::inner_of(&st1_p9, &rt_p8)
    } else {
        rt_p8.clone()
    };
    let (v_pa, st2_pb) = crate::check::types::fresh_var(&st1_p9, &false, &Text::lit(""));
    let (k_pc, st3_pd) = crate::check::types::fresh_var(&st2_pb, &true, &Text::lit(""));
    let coll0_p7 = if crate::check::expr::is_plain_sigil(&crate::check::types::head_sigil(&st3_pd, &inner_p6)) {
        crate::check::expr::inner_of(&st3_pd, &inner_p6)
    } else {
        inner_p6.clone()
    };
    match crate::check::types::recording::walk(&st3_pd, &coll0_p7) {
        crate::check::types::Ty::TyCon(m11500_0_0, m11500_0_1) if (&m11500_0_0 == &Text::lit("Text")) && ((&m11500_0_1).len() == 0) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(&st3_pd, &Text::lit("mismatch"), span_p4, &Text::lit("a text has no index: a position in a text is a cursor"), &Text::lit("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`"))),
        _ => {
            let (coll_pf, key_ty_pg) = match crate::check::types::recording::walk(&st3_pd, &coll0_p7) {
                crate::check::types::Ty::TyMap(_, _) => (crate::check::types::Ty::TyMap(Rc::new(k_pc.clone()), Rc::new(v_pa.clone())), k_pc.clone()),
                crate::check::types::Ty::TyCon(m11793_1_0, _) if (&m11793_1_0 == &Text::lit("Table")) => (crate::check::types::Ty::TyCon(Text::lit("Table"), Array::from(vec![k_pc.clone(), v_pa.clone()])), k_pc.clone()),
                crate::check::types::Ty::TyCon(m11793_2_0, _) if (&m11793_2_0 == &Text::lit("Buffer")) => (crate::check::types::Ty::TyCon(Text::lit("Buffer"), Array::from(vec![v_pa.clone()])), crate::check::types::t_nat()),
                _ => (crate::check::types::Ty::TyArray(Rc::new(v_pa.clone())), crate::check::types::t_nat()),
                _ => unreachable!("no arm matched"),
            };
            let args_pe = Array::from(vec![crate::syntax::Arg { name: None, value: recv_p2.clone(), span: recv_p2.span.clone() }, crate::syntax::Arg { name: None, value: idx_p3.clone(), span: idx_p3.span.clone() }]);
            crate::check::expr::calls::apply_rule(env_p0, &st3_pd, &Text::lit("[]"), &crate::check::types::Col::CBound, &Array::from(vec![coll_pf.clone(), key_ty_pg.clone()]), &crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_pa.clone())), &args_pe, span_p4)
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InferIndex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub struct InferIndex {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub recv_p2: crate::syntax::Expr,
    pub idx_p3: crate::syntax::Expr,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferIndex {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let recv_p2 = &self.recv_p2;
        let idx_p3 = &self.idx_p3;
        let span_p4 = &self.span_p4;
        let env_p0 = env_p0.clone();
        let idx_p3 = idx_p3.clone();
        let recv_p2 = recv_p2.clone();
        let span_p4 = span_p4.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), recv_p2.clone()), move |infer_11119: (crate::check::types::Ty, crate::check::types::St)| {
            let (rt_p8, st1_p9) = infer_11119;
            call_then(crate::check::types::start_head_sigil(st1_p9.clone(), rt_p8.clone()), move |head_sigil_11154: Text| {
                let head_p5 = head_sigil_11154;
                let inner_p6 = if crate::check::expr::is_time_sigil(&head_p5) {
                    crate::check::expr::inner_of(&st1_p9, &rt_p8)
                } else {
                    rt_p8.clone()
                };
                let (v_pa, st2_pb) = crate::check::types::fresh_var(&st1_p9, &false, &Text::lit(""));
                let (k_pc, st3_pd) = crate::check::types::fresh_var(&st2_pb, &true, &Text::lit(""));
                call_then(crate::check::types::start_head_sigil(st3_pd.clone(), inner_p6.clone()), move |head_sigil_11442: Text| {
                    let coll0_p7 = if crate::check::expr::is_plain_sigil(&head_sigil_11442) {
                        crate::check::expr::inner_of(&st3_pd, &inner_p6)
                    } else {
                        inner_p6.clone()
                    };
                    call_then(crate::check::types::recording::start_walk(st3_pd.clone(), coll0_p7.clone()), move |walk_11506: crate::check::types::Ty| match walk_11506 {
                        crate::check::types::Ty::TyCon(m11500_0_0, m11500_0_1) if (&m11500_0_0 == &Text::lit("Text")) && ((&m11500_0_1).len() == 0) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(&st3_pd, &Text::lit("mismatch"), &span_p4, &Text::lit("a text has no index: a position in a text is a cursor"), &Text::lit("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`")))),
                        _ => call_then(crate::check::types::recording::start_walk(st3_pd.clone(), coll0_p7.clone()), move |walk_11799: crate::check::types::Ty| {
                            let (coll_pf, key_ty_pg) = match walk_11799 {
                                crate::check::types::Ty::TyMap(_, _) => (crate::check::types::Ty::TyMap(Rc::new(k_pc.clone()), Rc::new(v_pa.clone())), k_pc.clone()),
                                crate::check::types::Ty::TyCon(m11793_1_0, _) if (&m11793_1_0 == &Text::lit("Table")) => (crate::check::types::Ty::TyCon(Text::lit("Table"), Array::from(vec![k_pc.clone(), v_pa.clone()])), k_pc.clone()),
                                crate::check::types::Ty::TyCon(m11793_2_0, _) if (&m11793_2_0 == &Text::lit("Buffer")) => (crate::check::types::Ty::TyCon(Text::lit("Buffer"), Array::from(vec![v_pa.clone()])), crate::check::types::t_nat()),
                                _ => (crate::check::types::Ty::TyArray(Rc::new(v_pa.clone())), crate::check::types::t_nat()),
                                _ => unreachable!("no arm matched"),
                            };
                            let args_pe = Array::from(vec![crate::syntax::Arg { name: None, value: recv_p2.clone(), span: recv_p2.span.clone() }, crate::syntax::Arg { name: None, value: idx_p3.clone(), span: idx_p3.span.clone() }]);
                            prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env_p0: env_p0.clone(), st_p1: st3_pd.clone(), fname_p2: Text::lit("[]"), col_p3: crate::check::types::Col::CBound, params_p4: Array::from(vec![coll_pf.clone(), key_ty_pg.clone()]), res_p5: crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_pa.clone())), args_p6: args_pe.clone(), span_p7: span_p4.clone() }))
                        }),
                        _ => unreachable!("no arm matched"),
                    })
                })
            })
        })
    }
}

/// `Start InferIndex, x`: what the function value is when passed to `@Run`.
pub fn start_infer_index(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, recv_p2: crate::syntax::Expr, idx_p3: crate::syntax::Expr, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferIndex { env_p0, st_p1, recv_p2, idx_p3, span_p4 })
}
