//! The module `Check.Expr.Operators`, from `target/bootstrap/src/prismc/check/expr/operators.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
/// ```
pub fn infer_array(env: &crate::check::expr::Env, st: &crate::check::types::St, es: &Array<crate::syntax::Expr>, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
    let st3 = run_to_end(fold_job(es.clone(), st2.clone(), {
        let env = env.clone();
        let v_ = v_.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Expr)| {
            let env = env.clone();
            let v_ = v_.clone();
            entered(once_job(move || {
                let s = p0;
                let x = p1;
                prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env: env.clone(), st: s.clone(), e: x.clone(), expected: v_.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    (crate::check::types::Ty::TyArray(Rc::new(v_.clone())), st3.clone())
}

/// The step machine of `InferArray`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
/// ```
pub struct InferArray {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub es: Array<crate::syntax::Expr>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferArray {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let es = &self.es;
        let span = &self.span;
        let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
        let env = env.clone();
        let es = es.clone();
        call_value(fold_job(es.clone(), st2.clone(), {
            let env = env.clone();
            let v_ = v_.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Expr)| {
                let env = env.clone();
                let v_ = v_.clone();
                entered(once_job(move || {
                    let s = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env: env.clone(), st: s.clone(), e: x.clone(), expected: v_.clone() }))
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }), move |fold_1476: crate::check::types::St| {
            let st3 = fold_1476;
            prism_rtl::Turn::Finished((crate::check::types::Ty::TyArray(Rc::new(v_.clone())), st3.clone()))
        })
    }
}

/// `Start InferArray, x`: what the function value is when passed to `@Run`.
pub fn start_infer_array(env: crate::check::expr::Env, st: crate::check::types::St, es: Array<crate::syntax::Expr>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferArray { env, st, es, span })
}

/// ```prism
/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
/// ```
pub fn infer_map(env: &crate::check::expr::Env, st: &crate::check::types::St, entries: &Array<(crate::syntax::Expr, crate::syntax::Expr)>, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (k, st1) = crate::check::types::fresh_var(st, &true, &Text::lit(""));
    let (v_, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
    let n = len(entries);
    let params = fold(entries, &Array::new(), &(|acc: &Array<crate::check::types::Ty>, _: &(crate::syntax::Expr, crate::syntax::Expr)| append(acc, &Array::from(vec![k.clone(), v_.clone()]))));
    let args = fold(entries, &Array::new(), &(|acc: &Array<crate::syntax::Arg>, (ke, ve): &(crate::syntax::Expr, crate::syntax::Expr)| append(acc, &Array::from(vec![crate::syntax::Arg { name: None, value: ke.clone(), span: ke.span.clone() }, crate::syntax::Arg { name: None, value: ve.clone(), span: ve.span.clone() }]))));
    let st3 = if &n > &Nat::from(0u32) {
        crate::check::expr::add_want(&st2, &Text::lit("Prelude.Ord"), &k, span)
    } else {
        st2.clone()
    };
    crate::check::expr::calls::apply_rule(env, &st3, &Text::lit("a map literal"), &crate::check::types::Col::CBound, &params, &crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone())), &args, span)
}

/// The step machine of `InferMap`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
/// ```
pub struct InferMap {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub entries: Array<(crate::syntax::Expr, crate::syntax::Expr)>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferMap {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let entries = &self.entries;
        let span = &self.span;
        let (k, st1) = crate::check::types::fresh_var(st, &true, &Text::lit(""));
        let (v_, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
        let n = len(entries);
        let params = fold(entries, &Array::new(), &(|acc: &Array<crate::check::types::Ty>, _: &(crate::syntax::Expr, crate::syntax::Expr)| append(acc, &Array::from(vec![k.clone(), v_.clone()]))));
        let args = fold(entries, &Array::new(), &(|acc: &Array<crate::syntax::Arg>, (ke, ve): &(crate::syntax::Expr, crate::syntax::Expr)| append(acc, &Array::from(vec![crate::syntax::Arg { name: None, value: ke.clone(), span: ke.span.clone() }, crate::syntax::Arg { name: None, value: ve.clone(), span: ve.span.clone() }]))));
        let st3 = if &n > &Nat::from(0u32) {
            crate::check::expr::add_want(&st2, &Text::lit("Prelude.Ord"), &k, span)
        } else {
            st2.clone()
        };
        prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env: env.clone(), st: st3.clone(), fname: Text::lit("a map literal"), col: crate::check::types::Col::CBound, params: params.clone(), res: crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone())), args: args.clone(), span: span.clone() }))
    }
}

/// `Start InferMap, x`: what the function value is when passed to `@Run`.
pub fn start_infer_map(env: crate::check::expr::Env, st: crate::check::types::St, entries: Array<(crate::syntax::Expr, crate::syntax::Expr)>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferMap { env, st, entries, span })
}

/// ```prism
/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_binary(env: &crate::check::expr::Env, st: &crate::check::types::St, op: &Text, lhs: &crate::syntax::Expr, rhs: &crate::syntax::Expr, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let args = Array::from(vec![crate::syntax::Arg { name: None, value: lhs.clone(), span: lhs.span.clone() }, crate::syntax::Arg { name: None, value: rhs.clone(), span: rhs.span.clone() }]);
    if (op == &Text::lit("and")) || (op == &Text::lit("or")) {
        crate::check::expr::calls::apply_rule(env, st, op, &crate::check::types::Col::CBound, &Array::from(vec![crate::check::types::t_bool(), crate::check::types::t_bool()]), &crate::check::types::t_bool(), &args, span)
    } else {
        if op == &Text::lit("on") {
            infer_on(env, st, lhs, rhs, span)
        } else {
            if op == &Text::lit("<|") {
                {
                    let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                    crate::check::expr::calls::apply_rule(env, &st2, op, &crate::check::types::Col::CBound, &Array::from(vec![crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone())), crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone()))]), &crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone())), &args, span)
                }
            } else {
                if op == &Text::lit("mod") {
                    {
                        let (v_, st2) = crate::check::types::fresh_var(st, &true, &Text::lit(""));
                        let st3 = crate::check::expr::add_want(&st2, &Text::lit("Prelude.Num"), &v_, span);
                        crate::check::expr::calls::apply_rule(env, &st3, op, &crate::check::types::Col::CBound, &Array::from(vec![v_.clone(), v_.clone()]), &v_, &args, span)
                    }
                } else {
                    {
                        let (t0, st2) = crate::check::expr::infer_name(env, st, &crate::syntax::SName { sigils: Text::lit(""), path_: Array::from(vec![op.clone()]), span: span.clone() }, span);
                        let t = if op == &Text::lit("/") { quotient_of(&st2, &t0) } else { t0.clone() };
                        let st2b = if op == &Text::lit("-?") {
                            crate::check::types::recording::note_size_ty(&st2, span, &crate::check::types::recording::walk(&st2, &t0))
                        } else {
                            st2.clone()
                        };
                        let st3 = if op == &Text::lit("-") { sub_want(&st2b, &t, span) } else { st2b.clone() };
                        crate::check::expr::calls::apply_fn(env, &st3, op, &t, &args, span)
                    }
                }
            }
        }
    }
}

/// The step machine of `InferBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
/// ```
pub struct InferBinary {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub op: Text,
    pub lhs: crate::syntax::Expr,
    pub rhs: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferBinary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let op = &self.op;
        let lhs = &self.lhs;
        let rhs = &self.rhs;
        let span = &self.span;
        let args = Array::from(vec![crate::syntax::Arg { name: None, value: lhs.clone(), span: lhs.span.clone() }, crate::syntax::Arg { name: None, value: rhs.clone(), span: rhs.span.clone() }]);
        if (op == &Text::lit("and")) || (op == &Text::lit("or")) {
            prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env: env.clone(), st: st.clone(), fname: op.clone(), col: crate::check::types::Col::CBound, params: Array::from(vec![crate::check::types::t_bool(), crate::check::types::t_bool()]), res: crate::check::types::t_bool(), args: args.clone(), span: span.clone() }))
        } else {
            if op == &Text::lit("on") {
                prism_rtl::Turn::More(Rc::new(InferOn { env: env.clone(), st: st.clone(), lhs: lhs.clone(), rhs: rhs.clone(), span: span.clone() }))
            } else {
                if op == &Text::lit("<|") {
                    {
                        let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                        prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env: env.clone(), st: st2.clone(), fname: op.clone(), col: crate::check::types::Col::CBound, params: Array::from(vec![crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone())), crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone()))]), res: crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone())), args: args.clone(), span: span.clone() }))
                    }
                } else {
                    if op == &Text::lit("mod") {
                        {
                            let (v_, st2) = crate::check::types::fresh_var(st, &true, &Text::lit(""));
                            let st3 = crate::check::expr::add_want(&st2, &Text::lit("Prelude.Num"), &v_, span);
                            prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env: env.clone(), st: st3.clone(), fname: op.clone(), col: crate::check::types::Col::CBound, params: Array::from(vec![v_.clone(), v_.clone()]), res: v_.clone(), args: args.clone(), span: span.clone() }))
                        }
                    } else {
                        {
                            let env = env.clone();
                            let op = op.clone();
                            let span = span.clone();
                            let st = st.clone();
                            call_then(crate::check::expr::start_infer_name(env.clone(), st.clone(), crate::syntax::SName { sigils: Text::lit(""), path_: Array::from(vec![op.clone()]), span: span.clone() }, span.clone()), move |infer_name_3258: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t0, st2) = infer_name_3258;
                                let t = if &op == &Text::lit("/") { quotient_of(&st2, &t0) } else { t0.clone() };
                                let st2b = if &op == &Text::lit("-?") {
                                    crate::check::types::recording::note_size_ty(&st2, &span, &crate::check::types::recording::walk(&st2, &t0))
                                } else {
                                    st2.clone()
                                };
                                let st3 = if &op == &Text::lit("-") { sub_want(&st2b, &t, &span) } else { st2b.clone() };
                                prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyFn { env: env.clone(), st: st3.clone(), fname: op.clone(), fty: t.clone(), args: args.clone(), span: span.clone() }))
                            })
                        }
                    }
                }
            }
        }
    }
}

/// `Start InferBinary, x`: what the function value is when passed to `@Run`.
pub fn start_infer_binary(env: crate::check::expr::Env, st: crate::check::types::St, op: Text, lhs: crate::syntax::Expr, rhs: crate::syntax::Expr, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferBinary { env, st, op, lhs, rhs, span })
}

/// ```prism
/// QuotientOf: unbounded fn St, Ty -> Ty
/// ```
pub fn quotient_of(st: &crate::check::types::St, t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyFn(c, ps, _) => match index(&ps, &Nat::from(0u32)) {
            Some(p_) => crate::check::types::Ty::TyFn(c, ps.clone(), Rc::new(crate::check::types::Ty::TyAssoc(Text::lit("Quotient"), Rc::new(p_)))),
            None => t.clone(),
        },
        other => other,
    }
}

/// The step machine of `QuotientOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// QuotientOf: unbounded fn St, Ty -> Ty
/// ```
pub struct QuotientOf {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for QuotientOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_3748: crate::check::types::Ty| match walk_3748 {
            crate::check::types::Ty::TyFn(c, ps, _) => match index(&ps, &Nat::from(0u32)) {
                Some(p_) => prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c.clone(), ps.clone(), Rc::new(crate::check::types::Ty::TyAssoc(Text::lit("Quotient"), Rc::new(p_.clone()))))),
                None => prism_rtl::Turn::Finished(t.clone()),
            },
            other => prism_rtl::Turn::Finished(other.clone()),
        })
    }
}

/// `Start QuotientOf, x`: what the function value is when passed to `@Run`.
pub fn start_quotient_of(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(QuotientOf { st, t })
}

/// ```prism
/// SubWant: unbounded fn St, Ty, Range -> St
/// ```
pub fn sub_want(st: &crate::check::types::St, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyFn(_, ps, _) => match index(&ps, &Nat::from(0u32)) {
            Some(p_) => crate::check::expr::add_want(st, &Text::lit("Prelude.Sub"), &p_, span),
            None => st.clone(),
        },
        _ => st.clone(),
    }
}

/// The step machine of `SubWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubWant: unbounded fn St, Ty, Range -> St
/// ```
pub struct SubWant {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for SubWant {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let t = &self.t;
        let span = &self.span;
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_4076: crate::check::types::Ty| match walk_4076 {
            crate::check::types::Ty::TyFn(_, ps, _) => match index(&ps, &Nat::from(0u32)) {
                Some(p_) => prism_rtl::Turn::Finished(crate::check::expr::add_want(&st, &Text::lit("Prelude.Sub"), &p_, &span)),
                None => prism_rtl::Turn::Finished(st.clone()),
            },
            _ => prism_rtl::Turn::Finished(st.clone()),
        })
    }
}

/// `Start SubWant, x`: what the function value is when passed to `@Run`.
pub fn start_sub_want(st: crate::check::types::St, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SubWant { st, t, span })
}

/// ```prism
/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_on(env: &crate::check::expr::Env, st: &crate::check::types::St, lhs: &crate::syntax::Expr, rhs: &crate::syntax::Expr, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (a, st1) = crate::check::types::fresh_var(st, &true, &Text::lit(""));
    let (b, st2) = crate::check::types::fresh_var(&st1, &true, &Text::lit(""));
    let (rt, st3) = crate::check::expr::infer(env, &st2, rhs);
    if ((&crate::check::types::head_sigil(&st3, &rt) != &Text::lit("!")) && (&rt != &crate::check::types::Ty::TyErr)) && !crate::check::types::is_flex_var(&st3, &rt) {
        (crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st3, &Text::lit("mismatch"), &rhs.span, &Text::from(format!("`on` fires with an event on its right; this is `{}`", &crate::check::types::show_ty(&st3, &rt)))))
    } else {
        {
            let args = Array::from(vec![crate::syntax::Arg { name: None, value: lhs.clone(), span: lhs.span.clone() }, crate::syntax::Arg { name: None, value: rhs.clone(), span: rhs.span.clone() }]);
            crate::check::expr::calls::apply_rule(env, &st3, &Text::lit("on"), &crate::check::types::Col::CBound, &Array::from(vec![a.clone(), b.clone()]), &a, &args, span)
        }
    }
}

/// The step machine of `InferOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub struct InferOn {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub lhs: crate::syntax::Expr,
    pub rhs: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferOn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let lhs = &self.lhs;
        let rhs = &self.rhs;
        let span = &self.span;
        let (a, st1) = crate::check::types::fresh_var(st, &true, &Text::lit(""));
        let (b, st2) = crate::check::types::fresh_var(&st1, &true, &Text::lit(""));
        let env = env.clone();
        let lhs = lhs.clone();
        let rhs = rhs.clone();
        let span = span.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st2.clone(), rhs.clone()), move |infer_4554: (crate::check::types::Ty, crate::check::types::St)| {
            let (rt, st3) = infer_4554;
            call_then(crate::check::types::start_head_sigil(st3.clone(), rt.clone()), move |head_sigil_4582: Text| if ((&head_sigil_4582 != &Text::lit("!")) && (&rt != &crate::check::types::Ty::TyErr)) && !crate::check::types::is_flex_var(&st3, &rt) {
                call_then(crate::check::types::start_show_ty(st3.clone(), rt.clone()), move |show_ty_4752: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st3, &Text::lit("mismatch"), &rhs.span, &Text::from(format!("`on` fires with an event on its right; this is `{}`", &show_ty_4752))))))
            } else {
                {
                    let args = Array::from(vec![crate::syntax::Arg { name: None, value: lhs.clone(), span: lhs.span.clone() }, crate::syntax::Arg { name: None, value: rhs.clone(), span: rhs.span.clone() }]);
                    prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env: env.clone(), st: st3.clone(), fname: Text::lit("on"), col: crate::check::types::Col::CBound, params: Array::from(vec![a.clone(), b.clone()]), res: a.clone(), args: args.clone(), span: span.clone() }))
                }
            })
        })
    }
}

/// `Start InferOn, x`: what the function value is when passed to `@Run`.
pub fn start_infer_on(env: crate::check::expr::Env, st: crate::check::types::St, lhs: crate::syntax::Expr, rhs: crate::syntax::Expr, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferOn { env, st, lhs, rhs, span })
}

/// ```prism
/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_unary(env: &crate::check::expr::Env, st: &crate::check::types::St, op: &Text, x: &crate::syntax::Expr, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let args = Array::from(vec![crate::syntax::Arg { name: None, value: x.clone(), span: x.span.clone() }]);
    match op {
        m5115_0 if (m5115_0 == &Text::lit("not")) => crate::check::expr::calls::apply_rule(env, st, &Text::lit("not"), &crate::check::types::Col::CBound, &Array::from(vec![crate::check::types::t_bool()]), &crate::check::types::t_bool(), &args, span),
        m5115_1 if (m5115_1 == &Text::lit("neg")) => match &*x.kind {
            crate::syntax::ExprKind::ELit(l) => {
                let (t, st2) = crate::check::expr::infer_lit(env, st, l, &true, span);
                (t.clone(), crate::check::types::recording::note_ty(&st2, &x.span, &t))
            },
            _ => {
                let (v_, st2) = crate::check::types::fresh_var(st, &true, &Text::lit(""));
                let st3 = crate::check::expr::add_want(&crate::check::expr::add_want(&st2, &Text::lit("Prelude.Num"), &v_, span), &Text::lit("Prelude.Signed"), &v_, span);
                crate::check::expr::calls::apply_rule(env, &st3, &Text::lit("-"), &crate::check::types::Col::CBound, &Array::from(vec![v_.clone()]), &v_, &args, span)
            },
        },
        _ => crate::check::expr::infer(env, st, x),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InferUnary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub struct InferUnary {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub op: Text,
    pub x: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferUnary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let op = &self.op;
        let x = &self.x;
        let span = &self.span;
        let args = Array::from(vec![crate::syntax::Arg { name: None, value: x.clone(), span: x.span.clone() }]);
        match op {
            m5115_0 if (m5115_0 == &Text::lit("not")) => prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env: env.clone(), st: st.clone(), fname: Text::lit("not"), col: crate::check::types::Col::CBound, params: Array::from(vec![crate::check::types::t_bool()]), res: crate::check::types::t_bool(), args: args.clone(), span: span.clone() })),
            m5115_1 if (m5115_1 == &Text::lit("neg")) => match &*x.kind {
                crate::syntax::ExprKind::ELit(l) => {
                    let env = env.clone();
                    let l = l.clone();
                    let span = span.clone();
                    let st = st.clone();
                    let x = x.clone();
                    call_then(crate::check::expr::start_infer_lit(env.clone(), st.clone(), l.clone(), true, span.clone()), move |infer_lit_5285: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t, st2) = infer_lit_5285;
                        prism_rtl::Turn::Finished((t.clone(), crate::check::types::recording::note_ty(&st2, &x.span, &t)))
                    })
                },
                _ => {
                    let (v_, st2) = crate::check::types::fresh_var(st, &true, &Text::lit(""));
                    let st3 = crate::check::expr::add_want(&crate::check::expr::add_want(&st2, &Text::lit("Prelude.Num"), &v_, span), &Text::lit("Prelude.Signed"), &v_, span);
                    prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env: env.clone(), st: st3.clone(), fname: Text::lit("-"), col: crate::check::types::Col::CBound, params: Array::from(vec![v_.clone()]), res: v_.clone(), args: args.clone(), span: span.clone() }))
                },
            },
            _ => prism_rtl::Turn::More(Rc::new(crate::check::expr::Infer { env: env.clone(), st: st.clone(), e: x.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start InferUnary, x`: what the function value is when passed to `@Run`.
pub fn start_infer_unary(env: crate::check::expr::Env, st: crate::check::types::St, op: Text, x: crate::syntax::Expr, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferUnary { env, st, op, x, span })
}

/// ```prism
/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_free_sigil(env: &crate::check::expr::Env, st: &crate::check::types::St, s: &Text, x: &crate::syntax::Expr, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    if s == &Text::lit("@") {
        {
            let (t, st2) = crate::check::expr::infer(env, st, x);
            (crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()), st2.clone())
        }
    } else {
        if ((s == &Text::lit("?")) || (s == &Text::lit("~"))) || (s == &Text::lit("$")) {
            {
                let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                if is_blueprint_expr(env, &st2, x) {
                    {
                        let (t, st3) = crate::check::expr::infer(env, &st2, x);
                        (crate::check::types::Ty::TySig(s.clone(), Rc::new(t.clone())), st3.clone())
                    }
                } else {
                    crate::check::expr::calls::apply_rule(env, &st2, &Text::from(format!("{}", s)), &crate::check::types::Col::CBound, &Array::from(vec![v_.clone()]), &crate::check::types::Ty::TySig(s.clone(), Rc::new(v_.clone())), &Array::from(vec![crate::syntax::Arg { name: None, value: x.clone(), span: x.span.clone() }]), span)
                }
            }
        } else {
            {
                let (t, st2) = crate::check::expr::infer(env, st, x);
                (crate::check::types::with_marks(s, &t, &env.scope), st2.clone())
            }
        }
    }
}

/// The step machine of `InferFreeSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub struct InferFreeSigil {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub s: Text,
    pub x: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferFreeSigil {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        let x = &self.x;
        let span = &self.span;
        if s == &Text::lit("@") {
            {
                let env = env.clone();
                let st = st.clone();
                let x = x.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), x.clone()), move |infer_5931: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_5931;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()), st2.clone()))
                })
            }
        } else {
            if ((s == &Text::lit("?")) || (s == &Text::lit("~"))) || (s == &Text::lit("$")) {
                {
                    let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                    if is_blueprint_expr(env, &st2, x) {
                        {
                            let env = env.clone();
                            let s = s.clone();
                            let x = x.clone();
                            call_then(crate::check::expr::start_infer(env.clone(), st2.clone(), x.clone()), move |infer_6149: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t, st3) = infer_6149;
                                prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(s.clone(), Rc::new(t.clone())), st3.clone()))
                            })
                        }
                    } else {
                        prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env: env.clone(), st: st2.clone(), fname: Text::from(format!("{}", s)), col: crate::check::types::Col::CBound, params: Array::from(vec![v_.clone()]), res: crate::check::types::Ty::TySig(s.clone(), Rc::new(v_.clone())), args: Array::from(vec![crate::syntax::Arg { name: None, value: x.clone(), span: x.span.clone() }]), span: span.clone() }))
                    }
                }
            } else {
                {
                    let env = env.clone();
                    let s = s.clone();
                    let st = st.clone();
                    let x = x.clone();
                    call_then(crate::check::expr::start_infer(env.clone(), st.clone(), x.clone()), move |infer_6352: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t, st2) = infer_6352;
                        prism_rtl::Turn::Finished((crate::check::types::with_marks(&s, &t, &env.scope), st2.clone()))
                    })
                }
            }
        }
    }
}

/// `Start InferFreeSigil, x`: what the function value is when passed to `@Run`.
pub fn start_infer_free_sigil(env: crate::check::expr::Env, st: crate::check::types::St, s: Text, x: crate::syntax::Expr, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferFreeSigil { env, st, s, x, span })
}

/// ```prism
/// IsBlueprintExpr: fn Env, St, Expr -> Bool
/// ```
pub fn is_blueprint_expr(env: &crate::check::expr::Env, st: &crate::check::types::St, x: &crate::syntax::Expr) -> bool {
    match &*x.kind {
        crate::syntax::ExprKind::EFreeSigil(m6632_0_0, _) if (m6632_0_0 == &Text::lit("@")) => true,
        crate::syntax::ExprKind::EGroup(y) => is_blueprint_expr(env, st, &**y),
        crate::syntax::ExprKind::ECall(c, _, _, _) => match &*c.kind {
            crate::syntax::ExprKind::EName(n) => crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("@")),
            _ => false,
        },
        crate::syntax::ExprKind::EName(n) => crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("@")),
        crate::syntax::ExprKind::EWidgetBlock(_) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
/// ```
pub fn infer_field(env: &crate::check::expr::Env, st: &crate::check::types::St, recv: &crate::syntax::Expr, sigils: &Text, name: &crate::syntax::Ident, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (rt, st1) = crate::check::expr::infer(env, st, recv);
    let head = crate::check::types::head_sigil(&st1, &rt);
    let inner = if crate::check::expr::is_time_sigil(&head) {
        crate::check::expr::inner_of(&st1, &rt)
    } else {
        rt.clone()
    };
    let ih = if crate::check::blocks::borrows::is_ref(recv) {
        Text::lit("")
    } else {
        crate::check::types::head_sigil(&st1, &inner)
    };
    let plain_t = if crate::check::expr::is_plain_sigil(&crate::check::types::head_sigil(&st1, &inner)) {
        crate::check::expr::inner_of(&st1, &inner)
    } else {
        inner.clone()
    };
    let st2 = if &head == &Text::lit("@") {
        crate::check::types::recording::err(&st1, &Text::lit("blueprint-operand"), &recv.span, &Text::from(format!("`.{}` over a blueprint; bind it first", &name.name)))
    } else {
        st1.clone()
    };
    let (ft, st3) = field_type(env, &st2, &plain_t, &name.name, span);
    let stack = crate::check::types::stack_of(&st3, &ft);
    let bad = (((&stack != sigils) && (&ft != &crate::check::types::Ty::TyErr)) && !crate::check::types::is_flex_var(&st3, &ft)) && !crate::check::blocks::borrows::is_ref(recv);
    let st4 = if bad {
        crate::check::types::recording::err_fix(&st3, &Text::lit("mark-stack"), &name.span, &Text::from(format!("`.{}{}` has type `{}`, whose stack is `{}`; the access shows `{}`", sigils, &name.name, &crate::check::types::show_ty(&st3, &ft), &stack, sigils)), &Text::from(format!("write `.{}{}`", &stack, &name.name)))
    } else {
        st3.clone()
    };
    let with_opt = if crate::check::expr::is_plain_sigil(&ih) {
        crate::check::types::Ty::TySig(ih.clone(), Rc::new(ft.clone()))
    } else {
        ft.clone()
    };
    let res = if crate::check::expr::is_time_sigil(&head) {
        crate::check::types::Ty::TySig(head.clone(), Rc::new(with_opt.clone()))
    } else {
        with_opt.clone()
    };
    let st5 = if crate::check::expr::is_time_sigil(&head) {
        crate::check::expr::calls::elab(&st4, span, &Text::from(format!(".{}", &name.name)), &Text::lit("map"), &head)
    } else {
        st4.clone()
    };
    let st6 = if crate::check::expr::is_plain_sigil(&ih) {
        crate::check::types::recording::note_lift(&st5, span, &ih, &Array::from(vec![recv.span.clone()]))
    } else {
        st5.clone()
    };
    (res.clone(), st6.clone())
}

/// The step machine of `InferField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
/// ```
pub struct InferField {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub recv: crate::syntax::Expr,
    pub sigils: Text,
    pub name: crate::syntax::Ident,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferField {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let recv = &self.recv;
        let sigils = &self.sigils;
        let name = &self.name;
        let span = &self.span;
        let env = env.clone();
        let name = name.clone();
        let recv = recv.clone();
        let sigils = sigils.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), recv.clone()), move |infer_7445: (crate::check::types::Ty, crate::check::types::St)| {
            let (rt, st1) = infer_7445;
            call_then(crate::check::types::start_head_sigil(st1.clone(), rt.clone()), move |head_sigil_7480: Text| {
                let head = head_sigil_7480;
                let inner = if crate::check::expr::is_time_sigil(&head) {
                    crate::check::expr::inner_of(&st1, &rt)
                } else {
                    rt.clone()
                };
                let ih = if crate::check::blocks::borrows::is_ref(&recv) {
                    Text::lit("")
                } else {
                    crate::check::types::head_sigil(&st1, &inner)
                };
                call_then(crate::check::types::start_head_sigil(st1.clone(), inner.clone()), move |head_sigil_7814: Text| {
                    let plain_t = if crate::check::expr::is_plain_sigil(&head_sigil_7814) {
                        crate::check::expr::inner_of(&st1, &inner)
                    } else {
                        inner.clone()
                    };
                    let st2 = if &head == &Text::lit("@") {
                        crate::check::types::recording::err(&st1, &Text::lit("blueprint-operand"), &recv.span, &Text::from(format!("`.{}` over a blueprint; bind it first", &name.name)))
                    } else {
                        st1.clone()
                    };
                    call_then(start_field_type(env.clone(), st2.clone(), plain_t.clone(), name.name.clone(), span.clone()), move |field_type_8020: (crate::check::types::Ty, crate::check::types::St)| {
                        let (ft, st3) = field_type_8020;
                        call_then(crate::check::types::start_stack_of(st3.clone(), ft.clone()), move |stack_of_8080: Text| {
                            let stack = stack_of_8080;
                            let bad = (((&stack != &sigils) && (&ft != &crate::check::types::Ty::TyErr)) && !crate::check::types::is_flex_var(&st3, &ft)) && !crate::check::blocks::borrows::is_ref(&recv);
                            let st4 = if bad {
                                crate::check::types::recording::err_fix(&st3, &Text::lit("mark-stack"), &name.span, &Text::from(format!("`.{}{}` has type `{}`, whose stack is `{}`; the access shows `{}`", &sigils, &name.name, &crate::check::types::show_ty(&st3, &ft), &stack, &sigils)), &Text::from(format!("write `.{}{}`", &stack, &name.name)))
                            } else {
                                st3.clone()
                            };
                            let with_opt = if crate::check::expr::is_plain_sigil(&ih) {
                                crate::check::types::Ty::TySig(ih.clone(), Rc::new(ft.clone()))
                            } else {
                                ft.clone()
                            };
                            let res = if crate::check::expr::is_time_sigil(&head) {
                                crate::check::types::Ty::TySig(head.clone(), Rc::new(with_opt.clone()))
                            } else {
                                with_opt.clone()
                            };
                            let st5 = if crate::check::expr::is_time_sigil(&head) {
                                crate::check::expr::calls::elab(&st4, &span, &Text::from(format!(".{}", &name.name)), &Text::lit("map"), &head)
                            } else {
                                st4.clone()
                            };
                            let st6 = if crate::check::expr::is_plain_sigil(&ih) {
                                crate::check::types::recording::note_lift(&st5, &span, &ih, &Array::from(vec![recv.span.clone()]))
                            } else {
                                st5.clone()
                            };
                            prism_rtl::Turn::Finished((res.clone(), st6.clone()))
                        })
                    })
                })
            })
        })
    }
}

/// `Start InferField, x`: what the function value is when passed to `@Run`.
pub fn start_infer_field(env: crate::check::expr::Env, st: crate::check::types::St, recv: crate::syntax::Expr, sigils: Text, name: crate::syntax::Ident, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferField { env, st, recv, sigils, name, span })
}

/// ```prism
/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
/// ```
pub fn field_type(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::check::types::Ty, field_: &Text, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyCon(n, args) => match get(&env.g.ctors, &n) {
            Some(c) => match index_of(&c.fields, field_) {
                Some(i) => {
                    let inst = crate::check::env::reading::param_inst(&c.params, &args);
                    (crate::check::types::schemes::subst_q(&inst, &or(&index(&c.args, &i), &crate::check::types::Ty::TyErr)), st.clone())
                },
                None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&n), field_)))),
            },
            None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`{}` has no fields", &crate::check::types::bare_name(&n))))),
        },
        crate::check::types::Ty::TyFlex(_) => {
            let owners = filter(&values(&env.g.ctors), &(|c: &crate::check::env::CtorInfo| crate::check::types::has_text(&c.fields, field_)));
            match index(&owners, &Nat::from(0u32)) {
                Some(c) => if &len(&owners) > &Nat::from(1u32) {
                    {
                        let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                        (v_.clone(), crate::check::types::unify::ask_field(&st2, t, field_, &v_, span, &each(&owners, &(|o: &crate::check::env::CtorInfo| crate::check::types::bare_name(&o.owner)))))
                    }
                } else {
                    {
                        let (self_, st2) = crate::check::expr::ctor_value(env, st, &{
                            let mut this: crate::check::env::CtorInfo = c.clone();
                            this.args = Array::new();
                            this
                        }, span);
                        let st3 = crate::check::types::unify::unify(&st2, &self_, t, span);
                        field_type(env, &st3, &self_, field_, span)
                    }
                },
                None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("mismatch"), span, &Text::from(format!("no record has a field `{}`", field_)))),
            }
        },
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st.clone()),
        other => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::show_ty(st, &other), field_)))),
    }
}

/// The step machine of `FieldType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
/// ```
pub struct FieldType {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub field_: Text,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for FieldType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let field_ = &self.field_;
        let span = &self.span;
        let env = env.clone();
        let field_ = field_.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_9134: crate::check::types::Ty| match walk_9134 {
            crate::check::types::Ty::TyCon(n, args) => match get(&env.g.ctors, &n) {
                Some(c) => match index_of(&c.fields, &field_) {
                    Some(i) => {
                        let inst = crate::check::env::reading::param_inst(&c.params, &args);
                        call_then(crate::check::types::schemes::start_subst_q(inst.clone(), or(&index(&c.args, &i), &crate::check::types::Ty::TyErr)), move |subst_q_9344: crate::check::types::Ty| prism_rtl::Turn::Finished((subst_q_9344, st.clone())))
                    },
                    None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&n), &field_))))),
                },
                None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` has no fields", &crate::check::types::bare_name(&n)))))),
            },
            crate::check::types::Ty::TyFlex(_) => {
                let owners = filter(&values(&env.g.ctors), &(|c: &crate::check::env::CtorInfo| crate::check::types::has_text(&c.fields, &field_)));
                match index(&owners, &Nat::from(0u32)) {
                    Some(c) => if &len(&owners) > &Nat::from(1u32) {
                        {
                            let (v_, st2) = crate::check::types::fresh_var(&st, &false, &Text::lit(""));
                            prism_rtl::Turn::Finished((v_.clone(), crate::check::types::unify::ask_field(&st2, &t, &field_, &v_, &span, &each(&owners, &(|o: &crate::check::env::CtorInfo| crate::check::types::bare_name(&o.owner))))))
                        }
                    } else {
                        call_then(crate::check::expr::start_ctor_value(env.clone(), st.clone(), {
                            let mut this: crate::check::env::CtorInfo = c.clone();
                            this.args = Array::new();
                            this
                        }, span.clone()), move |ctor_value_10228: (crate::check::types::Ty, crate::check::types::St)| {
                            let (self_, st2) = ctor_value_10228;
                            call_then(crate::check::types::unify::start_unify(st2.clone(), self_.clone(), t.clone(), span.clone()), move |unify_10335: crate::check::types::St| {
                                let st3 = unify_10335;
                                prism_rtl::Turn::More(Rc::new(FieldType { env: env.clone(), st: st3.clone(), t: self_.clone(), field_: field_.clone(), span: span.clone() }))
                            })
                        })
                    },
                    None => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("no record has a field `{}`", &field_))))),
                }
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st.clone())),
            other => call_then(crate::check::types::start_show_ty(st.clone(), other.clone()), move |show_ty_10583: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` has no field `{}`", &show_ty_10583, &field_)))))),
        })
    }
}

/// `Start FieldType, x`: what the function value is when passed to `@Run`.
pub fn start_field_type(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::check::types::Ty, field_: Text, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(FieldType { env, st, t, field_, span })
}

/// ```prism
/// ?IndexOf: fn [Text], Text -> ?Nat
/// ```
pub fn index_of(xs: &Array<Text>, x: &Text) -> Option<Nat> {
    fold(&crate::check::errors::range0(&len(xs)), &None, &(|found_opt: &Option<Nat>, i: &Nat| match found_opt {
        Some(f) => Some(f.clone()),
        None => if &index(xs, i) == &Some(x.clone()) { Some(i.clone()) } else { None },
    }))
}

/// ```prism
/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_index(env: &crate::check::expr::Env, st: &crate::check::types::St, recv: &crate::syntax::Expr, idx: &crate::syntax::Expr, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (rt, st1) = crate::check::expr::infer(env, st, recv);
    let head = crate::check::types::head_sigil(&st1, &rt);
    let inner = if crate::check::expr::is_time_sigil(&head) {
        crate::check::expr::inner_of(&st1, &rt)
    } else {
        rt.clone()
    };
    let (v_, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
    let (k, st3) = crate::check::types::fresh_var(&st2, &true, &Text::lit(""));
    let coll0 = if crate::check::expr::is_plain_sigil(&crate::check::types::head_sigil(&st3, &inner)) {
        crate::check::expr::inner_of(&st3, &inner)
    } else {
        inner.clone()
    };
    match crate::check::types::recording::walk(&st3, &coll0) {
        crate::check::types::Ty::TyCon(m11500_0_0, m11500_0_1) if (&m11500_0_0 == &Text::lit("Text")) && ((&m11500_0_1).len() == 0) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(&st3, &Text::lit("mismatch"), span, &Text::lit("a text has no index: a position in a text is a cursor"), &Text::lit("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`"))),
        _ => {
            let (coll, key_ty) = match crate::check::types::recording::walk(&st3, &coll0) {
                crate::check::types::Ty::TyMap(_, _) => (crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone())), k.clone()),
                crate::check::types::Ty::TyCon(m11793_1_0, _) if (&m11793_1_0 == &Text::lit("Table")) => (crate::check::types::Ty::TyCon(Text::lit("Table"), Array::from(vec![k.clone(), v_.clone()])), k.clone()),
                crate::check::types::Ty::TyCon(m11793_2_0, _) if (&m11793_2_0 == &Text::lit("Buffer")) => (crate::check::types::Ty::TyCon(Text::lit("Buffer"), Array::from(vec![v_.clone()])), crate::check::types::t_nat()),
                _ => (crate::check::types::Ty::TyArray(Rc::new(v_.clone())), crate::check::types::t_nat()),
                _ => unreachable!("no arm matched"),
            };
            let args = Array::from(vec![crate::syntax::Arg { name: None, value: recv.clone(), span: recv.span.clone() }, crate::syntax::Arg { name: None, value: idx.clone(), span: idx.span.clone() }]);
            crate::check::expr::calls::apply_rule(env, &st3, &Text::lit("[]"), &crate::check::types::Col::CBound, &Array::from(vec![coll.clone(), key_ty.clone()]), &crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_.clone())), &args, span)
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InferIndex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub struct InferIndex {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub recv: crate::syntax::Expr,
    pub idx: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferIndex {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let recv = &self.recv;
        let idx = &self.idx;
        let span = &self.span;
        let env = env.clone();
        let idx = idx.clone();
        let recv = recv.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), recv.clone()), move |infer_11119: (crate::check::types::Ty, crate::check::types::St)| {
            let (rt, st1) = infer_11119;
            call_then(crate::check::types::start_head_sigil(st1.clone(), rt.clone()), move |head_sigil_11154: Text| {
                let head = head_sigil_11154;
                let inner = if crate::check::expr::is_time_sigil(&head) {
                    crate::check::expr::inner_of(&st1, &rt)
                } else {
                    rt.clone()
                };
                let (v_, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
                let (k, st3) = crate::check::types::fresh_var(&st2, &true, &Text::lit(""));
                call_then(crate::check::types::start_head_sigil(st3.clone(), inner.clone()), move |head_sigil_11442: Text| {
                    let coll0 = if crate::check::expr::is_plain_sigil(&head_sigil_11442) {
                        crate::check::expr::inner_of(&st3, &inner)
                    } else {
                        inner.clone()
                    };
                    call_then(crate::check::types::recording::start_walk(st3.clone(), coll0.clone()), move |walk_11506: crate::check::types::Ty| match walk_11506 {
                        crate::check::types::Ty::TyCon(m11500_0_0, m11500_0_1) if (&m11500_0_0 == &Text::lit("Text")) && ((&m11500_0_1).len() == 0) => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(&st3, &Text::lit("mismatch"), &span, &Text::lit("a text has no index: a position in a text is a cursor"), &Text::lit("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`")))),
                        _ => call_then(crate::check::types::recording::start_walk(st3.clone(), coll0.clone()), move |walk_11799: crate::check::types::Ty| {
                            let (coll, key_ty) = match walk_11799 {
                                crate::check::types::Ty::TyMap(_, _) => (crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone())), k.clone()),
                                crate::check::types::Ty::TyCon(m11793_1_0, _) if (&m11793_1_0 == &Text::lit("Table")) => (crate::check::types::Ty::TyCon(Text::lit("Table"), Array::from(vec![k.clone(), v_.clone()])), k.clone()),
                                crate::check::types::Ty::TyCon(m11793_2_0, _) if (&m11793_2_0 == &Text::lit("Buffer")) => (crate::check::types::Ty::TyCon(Text::lit("Buffer"), Array::from(vec![v_.clone()])), crate::check::types::t_nat()),
                                _ => (crate::check::types::Ty::TyArray(Rc::new(v_.clone())), crate::check::types::t_nat()),
                                _ => unreachable!("no arm matched"),
                            };
                            let args = Array::from(vec![crate::syntax::Arg { name: None, value: recv.clone(), span: recv.span.clone() }, crate::syntax::Arg { name: None, value: idx.clone(), span: idx.span.clone() }]);
                            prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::ApplyRule { env: env.clone(), st: st3.clone(), fname: Text::lit("[]"), col: crate::check::types::Col::CBound, params: Array::from(vec![coll.clone(), key_ty.clone()]), res: crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_.clone())), args: args.clone(), span: span.clone() }))
                        }),
                        _ => unreachable!("no arm matched"),
                    })
                })
            })
        })
    }
}

/// `Start InferIndex, x`: what the function value is when passed to `@Run`.
pub fn start_infer_index(env: crate::check::expr::Env, st: crate::check::types::St, recv: crate::syntax::Expr, idx: crate::syntax::Expr, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferIndex { env, st, recv, idx, span })
}
