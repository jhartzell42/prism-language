//! The module `Check.Expr.Patterns`, from `target/bootstrap/src/prismc/check/expr/patterns.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_pattern_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, t_p3: &crate::check::types::Ty, refutable_p4: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    match &*p_p2.kind_p {
        crate::syntax::PatternKind::PName(n_p5) => {
            let bare_p6 = crate::prelude::or(&crate::prelude::index(&n_p5.path_p, &Nat::from(0u32)), &Text::lit(""));
            let is_ctor_p7 = (crate::check::env::is_upper_text_f(&bare_p6) && (&crate::prelude::len_text(&n_p5.sigils_p) == &Nat::from(0u32))) && is_ctor_name_f(env_p0, n_p5);
            if is_ctor_p7 || (&crate::prelude::len(&n_p5.path_p) > &Nat::from(1u32)) {
                bind_ctor_f(env_p0, st_p1, p_p2, n_p5, &Array::new(), t_p3)
            } else {
                bind_name_f(env_p0, st_p1, n_p5, t_p3)
            }
        },
        crate::syntax::PatternKind::PIgnore => (env_p0.clone(), st_p1.clone()),
        crate::syntax::PatternKind::PLit(l_p8) => {
            let (lt_p9, st2_pa) = crate::check::expr::infer_lit_f(env_p0, st_p1, l_p8, &false, &p_p2.span_p);
            (env_p0.clone(), crate::check::types::unify::unify_f(&st2_pa, t_p3, &lt_p9, &p_p2.span_p))
        },
        crate::syntax::PatternKind::PNeg(l_pb) => {
            let (lt_pc, st2_pd) = crate::check::expr::infer_lit_f(env_p0, st_p1, l_pb, &true, &p_p2.span_p);
            (env_p0.clone(), crate::check::types::unify::unify_f(&st2_pd, t_p3, &lt_pc, &p_p2.span_p))
        },
        crate::syntax::PatternKind::PUnit => (env_p0.clone(), crate::check::types::unify::unify_f(st_p1, t_p3, &crate::check::types::t_unit_p(), &p_p2.span_p)),
        crate::syntax::PatternKind::PNil => {
            let (v_pe, st2_pf) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
            (env_p0.clone(), crate::check::types::unify::unify_f(&st2_pf, t_p3, &crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_pe.clone())), &p_p2.span_p))
        },
        crate::syntax::PatternKind::PCtor(n_pg, args_ph) => bind_ctor_f(env_p0, st_p1, p_p2, n_pg, args_ph, t_p3),
        crate::syntax::PatternKind::PRecord(n_pi, fields_pj, rest_pk) => bind_record_f(env_p0, st_p1, p_p2, n_pi, fields_pj, rest_pk, t_p3),
        crate::syntax::PatternKind::PSigil(s_pl, inner_pm) => if (s_pl == &Text::lit("?")) || (s_pl == &Text::lit("~")) {
            {
                let (v_po, st2_pp) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
                let st3_pn = crate::check::types::unify::unify_f(&st2_pp, t_p3, &crate::check::types::Ty::TySig(s_pl.clone(), Rc::new(v_po.clone())), &p_p2.span_p);
                bind_pattern_f(env_p0, &st3_pn, &**inner_pm, &v_po, refutable_p4)
            }
        } else {
            {
                let (v_pr, st2_ps) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
                let st3_pq = crate::check::types::unify::unify_f(&st2_ps, t_p3, &crate::check::types::with_marks_f(s_pl, &v_pr, &env_p0.scope_p), &p_p2.span_p);
                bind_pattern_f(env_p0, &st3_pq, &**inner_pm, &v_pr, refutable_p4)
            }
        },
        crate::syntax::PatternKind::PTuple(ps_pt) => {
            let (vs_p13, st2_p14) = crate::prelude::fold(ps_pt, &(Array::new(), st_p1.clone()), &(|(acc_pv, s_p10): &(Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Pattern_| {
                let (v_p11, s2_p12) = crate::check::types::fresh_var_f(s_p10, &false, &Text::lit(""));
                (crate::prelude::push(acc_pv, &v_p11), s2_p12.clone())
            }));
            let st3_pu = crate::check::types::unify::unify_f(&st2_p14, t_p3, &crate::check::types::Ty::TyTuple(vs_p13.clone()), &p_p2.span_p);
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_pt)), (env_p0.clone(), st3_pu.clone()), {
                let ps_ptx = ps_pt.clone();
                let p_p2x = p_p2.clone();
                let vs_p13x = vs_p13.clone();
                let refutable_p4x = *refutable_p4;
                Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                    let ps_ptxy = ps_ptx.clone();
                    let p_p2xy = p_p2x.clone();
                    let vs_p13xy = vs_p13x.clone();
                    let refutable_p4xy = refutable_p4x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (en_p15, s_p16) = p0;
                        let i_p17 = p1;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_p15.clone(), st_p1: s_p16.clone(), p_p2: crate::prelude::or(&crate::prelude::index(&ps_ptxy, &i_p17), &crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xy.span_p.clone() }), t_p3: crate::prelude::or(&crate::prelude::index(&vs_p13xy, &i_p17), &crate::check::types::Ty::TyErr), refutable_p4: refutable_p4xy }))
                    }))
                }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }))
        },
        crate::syntax::PatternKind::PArray(ps_p18) => {
            let (v_p1a, st2_p1b) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
            let st3_p19 = crate::check::types::unify::unify_f(&st2_p1b, t_p3, &crate::check::types::Ty::TyArray(Rc::new(v_p1a.clone())), &p_p2.span_p);
            crate::prelude::run_to_end(crate::prelude::fold_job(ps_p18.clone(), (env_p0.clone(), st3_p19.clone()), {
                let v_p1ax = v_p1a.clone();
                let refutable_p4x = *refutable_p4;
                Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern_)| {
                    let v_p1axy = v_p1ax.clone();
                    let refutable_p4xy = refutable_p4x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (en_p1c, s_p1d) = p0;
                        let q_p1e = p1;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_p1c.clone(), st_p1: s_p1d.clone(), p_p2: q_p1e.clone(), t_p3: v_p1axy.clone(), refutable_p4: refutable_p4xy }))
                    }))
                }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }))
        },
        crate::syntax::PatternKind::PGroup(q_p1f) => bind_pattern_f(env_p0, st_p1, &**q_p1f, t_p3, refutable_p4),
        crate::syntax::PatternKind::PFamily(q_p1g) => bind_family_f(env_p0, st_p1, &crate::check::env::dotted_f(&q_p1g.path_p), t_p3, &p_p2.span_p),
    }
}

/// The step machine of `BindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub struct BindPattern {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub t_p3: crate::check::types::Ty,
    pub refutable_p4: bool,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let t_p3 = &self.t_p3;
        let refutable_p4 = &self.refutable_p4;
        match &*p_p2.kind_p {
            crate::syntax::PatternKind::PName(n_p5) => {
                let bare_p6 = crate::prelude::or(&crate::prelude::index(&n_p5.path_p, &Nat::from(0u32)), &Text::lit(""));
                let is_ctor_p7 = (crate::check::env::is_upper_text_f(&bare_p6) && (&crate::prelude::len_text(&n_p5.sigils_p) == &Nat::from(0u32))) && is_ctor_name_f(env_p0, n_p5);
                if is_ctor_p7 || (&crate::prelude::len(&n_p5.path_p) > &Nat::from(1u32)) {
                    prism_rtl::Turn::More(Rc::new(BindCtor { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), n_p3: n_p5.clone(), args_p4: Array::new(), t_p5: t_p3.clone() }))
                } else {
                    prism_rtl::Turn::More(Rc::new(BindName { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p5.clone(), t_p3: t_p3.clone() }))
                }
            },
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
            crate::syntax::PatternKind::PLit(l_p8) => {
                let env_p0x = env_p0.clone();
                let l_p8x = l_p8.clone();
                let p_p2x = p_p2.clone();
                let st_p1x = st_p1.clone();
                let t_p3x = t_p3.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_lit_f(env_p0x.clone(), st_p1x.clone(), l_p8x.clone(), false, p_p2x.span_p.clone()), move |infer_lit_f_1841: (crate::check::types::Ty, crate::check::types::St)| {
                    let (lt_p9, st2_pa) = infer_lit_f_1841;
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pa.clone(), t_p3x.clone(), lt_p9.clone(), p_p2x.span_p.clone()), move |unify_f_1892: crate::check::types::St| prism_rtl::Turn::Finished((env_p0x.clone(), unify_f_1892)))
                })
            },
            crate::syntax::PatternKind::PNeg(l_pb) => {
                let env_p0x = env_p0.clone();
                let l_pbx = l_pb.clone();
                let p_p2x = p_p2.clone();
                let st_p1x = st_p1.clone();
                let t_p3x = t_p3.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_lit_f(env_p0x.clone(), st_p1x.clone(), l_pbx.clone(), true, p_p2x.span_p.clone()), move |infer_lit_f_1958: (crate::check::types::Ty, crate::check::types::St)| {
                    let (lt_pc, st2_pd) = infer_lit_f_1958;
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pd.clone(), t_p3x.clone(), lt_pc.clone(), p_p2x.span_p.clone()), move |unify_f_2008: crate::check::types::St| prism_rtl::Turn::Finished((env_p0x.clone(), unify_f_2008)))
                })
            },
            crate::syntax::PatternKind::PUnit => {
                let env_p0x = env_p0.clone();
                let p_p2x = p_p2.clone();
                let st_p1x = st_p1.clone();
                let t_p3x = t_p3.clone();
                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), t_p3x.clone(), crate::check::types::t_unit_p(), p_p2x.span_p.clone()), move |unify_f_2055: crate::check::types::St| prism_rtl::Turn::Finished((env_p0x.clone(), unify_f_2055)))
            },
            crate::syntax::PatternKind::PNil => {
                let (v_pe, st2_pf) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
                let env_p0x = env_p0.clone();
                let p_p2x = p_p2.clone();
                let t_p3x = t_p3.clone();
                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pf.clone(), t_p3x.clone(), crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_pe.clone())), p_p2x.span_p.clone()), move |unify_f_2159: crate::check::types::St| prism_rtl::Turn::Finished((env_p0x.clone(), unify_f_2159)))
            },
            crate::syntax::PatternKind::PCtor(n_pg, args_ph) => prism_rtl::Turn::More(Rc::new(BindCtor { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), n_p3: n_pg.clone(), args_p4: args_ph.clone(), t_p5: t_p3.clone() })),
            crate::syntax::PatternKind::PRecord(n_pi, fields_pj, rest_pk) => prism_rtl::Turn::More(Rc::new(BindRecord { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), n_p3: n_pi.clone(), fields_p4: fields_pj.clone(), rest_p5: *rest_pk, t_p6: t_p3.clone() })),
            crate::syntax::PatternKind::PSigil(s_pl, inner_pm) => if (s_pl == &Text::lit("?")) || (s_pl == &Text::lit("~")) {
                {
                    let (v_po, st2_pp) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
                    let env_p0x = env_p0.clone();
                    let inner_pmx = (**inner_pm).clone();
                    let p_p2x = p_p2.clone();
                    let refutable_p4x = *refutable_p4;
                    let s_plx = s_pl.clone();
                    let t_p3x = t_p3.clone();
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pp.clone(), t_p3x.clone(), crate::check::types::Ty::TySig(s_plx.clone(), Rc::new(v_po.clone())), p_p2x.span_p.clone()), move |unify_f_2449: crate::check::types::St| {
                        let st3_pn = unify_f_2449;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: env_p0x.clone(), st_p1: st3_pn.clone(), p_p2: inner_pmx.clone(), t_p3: v_po.clone(), refutable_p4: refutable_p4x }))
                    })
                }
            } else {
                {
                    let (v_pr, st2_ps) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
                    let env_p0x = env_p0.clone();
                    let inner_pmx = (**inner_pm).clone();
                    let p_p2x = p_p2.clone();
                    let refutable_p4x = *refutable_p4;
                    let s_plx = s_pl.clone();
                    let t_p3x = t_p3.clone();
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_ps.clone(), t_p3x.clone(), crate::check::types::with_marks_f(&s_plx, &v_pr, &env_p0x.scope_p), p_p2x.span_p.clone()), move |unify_f_2626: crate::check::types::St| {
                        let st3_pq = unify_f_2626;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: env_p0x.clone(), st_p1: st3_pq.clone(), p_p2: inner_pmx.clone(), t_p3: v_pr.clone(), refutable_p4: refutable_p4x }))
                    })
                }
            },
            crate::syntax::PatternKind::PTuple(ps_pt) => {
                let (vs_p13, st2_p14) = crate::prelude::fold(ps_pt, &(Array::new(), st_p1.clone()), &(|(acc_pv, s_p10): &(Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Pattern_| {
                    let (v_p11, s2_p12) = crate::check::types::fresh_var_f(s_p10, &false, &Text::lit(""));
                    (crate::prelude::push(acc_pv, &v_p11), s2_p12.clone())
                }));
                let env_p0x = env_p0.clone();
                let p_p2x = p_p2.clone();
                let ps_ptx = ps_pt.clone();
                let refutable_p4x = *refutable_p4;
                let t_p3x = t_p3.clone();
                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p14.clone(), t_p3x.clone(), crate::check::types::Ty::TyTuple(vs_p13.clone()), p_p2x.span_p.clone()), move |unify_f_2918: crate::check::types::St| {
                    let st3_pu = unify_f_2918;
                    crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_ptx)), (env_p0x.clone(), st3_pu.clone()), {
                        let ps_ptxx = ps_ptx.clone();
                        let p_p2xx = p_p2x.clone();
                        let vs_p13x = vs_p13.clone();
                        let refutable_p4xx = refutable_p4x;
                        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                            let ps_ptxxy = ps_ptxx.clone();
                            let p_p2xxy = p_p2xx.clone();
                            let vs_p13xy = vs_p13x.clone();
                            let refutable_p4xxy = refutable_p4xx;
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (en_p15, s_p16) = p0;
                                let i_p17 = p1;
                                prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_p15.clone(), st_p1: s_p16.clone(), p_p2: crate::prelude::or(&crate::prelude::index(&ps_ptxxy, &i_p17), &crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xxy.span_p.clone() }), t_p3: crate::prelude::or(&crate::prelude::index(&vs_p13xy, &i_p17), &crate::check::types::Ty::TyErr), refutable_p4: refutable_p4xxy }))
                            }))
                        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                    }).cycle()
                })
            },
            crate::syntax::PatternKind::PArray(ps_p18) => {
                let (v_p1a, st2_p1b) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
                let env_p0x = env_p0.clone();
                let p_p2x = p_p2.clone();
                let ps_p18x = ps_p18.clone();
                let refutable_p4x = *refutable_p4;
                let t_p3x = t_p3.clone();
                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p1b.clone(), t_p3x.clone(), crate::check::types::Ty::TyArray(Rc::new(v_p1a.clone())), p_p2x.span_p.clone()), move |unify_f_3192: crate::check::types::St| {
                    let st3_p19 = unify_f_3192;
                    crate::prelude::fold_job(ps_p18x.clone(), (env_p0x.clone(), st3_p19.clone()), {
                        let v_p1ax = v_p1a.clone();
                        let refutable_p4xx = refutable_p4x;
                        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern_)| {
                            let v_p1axy = v_p1ax.clone();
                            let refutable_p4xxy = refutable_p4xx;
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (en_p1c, s_p1d) = p0;
                                let q_p1e = p1;
                                prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_p1c.clone(), st_p1: s_p1d.clone(), p_p2: q_p1e.clone(), t_p3: v_p1axy.clone(), refutable_p4: refutable_p4xxy }))
                            }))
                        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                    }).cycle()
                })
            },
            crate::syntax::PatternKind::PGroup(q_p1f) => prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: (**q_p1f).clone(), t_p3: t_p3.clone(), refutable_p4: *refutable_p4 })),
            crate::syntax::PatternKind::PFamily(q_p1g) => prism_rtl::Turn::More(Rc::new(BindFamily { env_p0: env_p0.clone(), st_p1: st_p1.clone(), fam_p2: crate::check::env::dotted_f(&q_p1g.path_p), t_p3: t_p3.clone(), span_p4: p_p2.span_p.clone() })),
        }
    }
}

/// `Start BindPattern, x`: what the function value is when passed to `@Run`.
pub fn start_bind_pattern_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, t_p3: crate::check::types::Ty, refutable_p4: bool) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindPattern { env_p0, st_p1, p_p2, t_p3, refutable_p4 })
}

/// ```prism
/// IsCtorName: fn Env, SName -> Bool
/// ```
pub fn is_ctor_name_f(env_p0: &crate::check::expr::Env, n_p1: &crate::syntax::SName) -> bool {
    let (qk_o2, _) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p1);
    match &qk_o2 {
        Some(qk_p3) => crate::check::env::has_key_f(&env_p0.g_p.ctors_p, qk_p3),
        None => false,
    }
}

/// ```prism
/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub fn bind_name_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, t_p3: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let name_p4 = crate::check::env::sname_key_f(n_p2);
    if crate::check::types::has_text_f(&env_p0.pending_p, &name_p4) {
        match crate::prelude::get(&env_p0.locals_p, &name_p4) {
            Some(sc_p5) => {
                let (ok_p8, st1_p9) = crate::check::types::unify::try_unify_f(st_p1, &sc_p5.ty_p, t_p3, &n_p2.span_p);
                let marks_agree_p6 = (&crate::check::types::stack_of_f(st_p1, t_p3) == &crate::check::expr::lets::type_marks_f(&n_p2.sigils_p)) || crate::check::types::is_flex_var_f(st_p1, t_p3);
                let st_a_p7 = if ok_p8 {
                    st1_p9.clone()
                } else {
                    if marks_agree_p6 {
                        crate::check::types::unify::unify_f(st_p1, &sc_p5.ty_p, t_p3, &n_p2.span_p)
                    } else {
                        crate::check::types::recording::err_fix_f(st_p1, &Text::lit("mark-stack"), &n_p2.span_p, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name_p4, &crate::check::types::show_ty_f(st_p1, t_p3), &crate::check::types::stack_of_f(st_p1, t_p3), &crate::check::expr::lets::type_marks_f(&n_p2.sigils_p))), &Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark_f(&n_p2.sigils_p), &crate::check::types::stack_of_f(st_p1, t_p3), &crate::syntax::lexer::chars::drop_prefix_f(&name_p4, &n_p2.sigils_p))))
                    }
                };
                crate::check::expr::bind_local_id_f(env_p0, &crate::check::types::recording::note_binder_f(&st_a_p7, &n_p2.span_p, &name_p4, t_p3), &name_p4, &n_p2.span_p)
            },
            None => bind_fresh_f(env_p0, st_p1, n_p2, t_p3),
        }
    } else {
        bind_fresh_f(env_p0, st_p1, n_p2, t_p3)
    }
}

/// The step machine of `BindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub struct BindName {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub t_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindName {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let t_p3 = &self.t_p3;
        let name_p4 = crate::check::env::sname_key_f(n_p2);
        if crate::check::types::has_text_f(&env_p0.pending_p, &name_p4) {
            match crate::prelude::get(&env_p0.locals_p, &name_p4) {
                Some(sc_p5) => {
                    let env_p0x = env_p0.clone();
                    let n_p2x = n_p2.clone();
                    let st_p1x = st_p1.clone();
                    let t_p3x = t_p3.clone();
                    crate::prelude::call_then(crate::check::types::unify::start_try_unify_f(st_p1x.clone(), sc_p5.ty_p.clone(), t_p3x.clone(), n_p2x.span_p.clone()), move |try_unify_f_3987: (bool, crate::check::types::St)| {
                        let (ok_p8, st1_p9) = try_unify_f_3987;
                        crate::prelude::call_then(crate::check::types::start_stack_of_f(st_p1x.clone(), t_p3x.clone()), move |stack_of_f_4051: Text| {
                            let marks_agree_p6 = (&stack_of_f_4051 == &crate::check::expr::lets::type_marks_f(&n_p2x.sigils_p)) || crate::check::types::is_flex_var_f(&st_p1x, &t_p3x);
                            let st_a_p7 = if ok_p8 {
                                st1_p9.clone()
                            } else {
                                if marks_agree_p6 {
                                    crate::check::types::unify::unify_f(&st_p1x, &sc_p5.ty_p, &t_p3x, &n_p2x.span_p)
                                } else {
                                    crate::check::types::recording::err_fix_f(&st_p1x, &Text::lit("mark-stack"), &n_p2x.span_p, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name_p4, &crate::check::types::show_ty_f(&st_p1x, &t_p3x), &crate::check::types::stack_of_f(&st_p1x, &t_p3x), &crate::check::expr::lets::type_marks_f(&n_p2x.sigils_p))), &Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark_f(&n_p2x.sigils_p), &crate::check::types::stack_of_f(&st_p1x, &t_p3x), &crate::syntax::lexer::chars::drop_prefix_f(&name_p4, &n_p2x.sigils_p))))
                                }
                            };
                            prism_rtl::Turn::Finished(crate::check::expr::bind_local_id_f(&env_p0x, &crate::check::types::recording::note_binder_f(&st_a_p7, &n_p2x.span_p, &name_p4, &t_p3x), &name_p4, &n_p2x.span_p))
                        })
                    })
                },
                None => prism_rtl::Turn::More(Rc::new(BindFresh { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p2.clone(), t_p3: t_p3.clone() })),
            }
        } else {
            prism_rtl::Turn::More(Rc::new(BindFresh { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p2.clone(), t_p3: t_p3.clone() }))
        }
    }
}

/// `Start BindName, x`: what the function value is when passed to `@Run`.
pub fn start_bind_name_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, t_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindName { env_p0, st_p1, n_p2, t_p3 })
}

/// ```prism
/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub fn bind_fresh_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, t_p3: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    bind_fresh_marked_f(env_p0, st_p1, n_p2, &crate::check::expr::lets::type_marks_f(&n_p2.sigils_p), t_p3)
}

/// The step machine of `BindFresh`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub struct BindFresh {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub t_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindFresh {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let t_p3 = &self.t_p3;
        prism_rtl::Turn::More(Rc::new(BindFreshMarked { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p2.clone(), marks_p3: crate::check::expr::lets::type_marks_f(&n_p2.sigils_p), t_p4: t_p3.clone() }))
    }
}

/// `Start BindFresh, x`: what the function value is when passed to `@Run`.
pub fn start_bind_fresh_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, t_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindFresh { env_p0, st_p1, n_p2, t_p3 })
}

/// ```prism
/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
/// ```
pub fn bind_fresh_marked_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, marks_p3: &Text, t_p4: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let name_p5 = crate::check::env::sname_key_f(n_p2);
    let (v_p8, st2_p9) = crate::check::types::fresh_var_f(st_p1, &true, &name_p5);
    let (rw_pa, st3_pb) = crate::check::types::recording::fresh_row_f(&st2_p9, &Array::new());
    let marked_p6 = crate::check::types::with_marks_f(marks_p3, &v_p8, &rw_pa);
    let (ok_pc, st4_pd) = crate::check::types::unify::try_unify_f(&st3_pb, t_p4, &marked_p6, &n_p2.span_p);
    let st5_p7 = if ok_pc {
        st4_pd.clone()
    } else {
        {
            let stack_pe = crate::check::types::stack_of_f(&st3_pb, t_p4);
            crate::check::types::recording::err_fix_f(&st3_pb, &Text::lit("mark-stack"), &n_p2.span_p, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name_p5, &crate::check::types::show_ty_f(&st3_pb, t_p4), &stack_pe, marks_p3)), &Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark_f(&n_p2.sigils_p), &stack_pe, &crate::syntax::lexer::chars::drop_prefix_f(&name_p5, &n_p2.sigils_p))))
        }
    };
    crate::check::expr::bind_local_id_f(&crate::check::expr::with_local_f(env_p0, &name_p5, &crate::check::types::schemes::mono_f(t_p4)), &crate::check::types::recording::note_binder_f(&st5_p7, &n_p2.span_p, &name_p5, t_p4), &name_p5, &n_p2.span_p)
}

/// The step machine of `BindFreshMarked`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
/// ```
pub struct BindFreshMarked {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub marks_p3: Text,
    pub t_p4: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindFreshMarked {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let marks_p3 = &self.marks_p3;
        let t_p4 = &self.t_p4;
        let name_p5 = crate::check::env::sname_key_f(n_p2);
        let (v_p8, st2_p9) = crate::check::types::fresh_var_f(st_p1, &true, &name_p5);
        let (rw_pa, st3_pb) = crate::check::types::recording::fresh_row_f(&st2_p9, &Array::new());
        let marked_p6 = crate::check::types::with_marks_f(marks_p3, &v_p8, &rw_pa);
        let env_p0x = env_p0.clone();
        let marks_p3x = marks_p3.clone();
        let n_p2x = n_p2.clone();
        let t_p4x = t_p4.clone();
        crate::prelude::call_then(crate::check::types::unify::start_try_unify_f(st3_pb.clone(), t_p4x.clone(), marked_p6.clone(), n_p2x.span_p.clone()), move |try_unify_f_5140: (bool, crate::check::types::St)| {
            let (ok_pc, st4_pd) = try_unify_f_5140;
            let st5_p7 = if ok_pc {
                st4_pd.clone()
            } else {
                {
                    let stack_pe = crate::check::types::stack_of_f(&st3_pb, &t_p4x);
                    crate::check::types::recording::err_fix_f(&st3_pb, &Text::lit("mark-stack"), &n_p2x.span_p, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name_p5, &crate::check::types::show_ty_f(&st3_pb, &t_p4x), &stack_pe, &marks_p3x)), &Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark_f(&n_p2x.sigils_p), &stack_pe, &crate::syntax::lexer::chars::drop_prefix_f(&name_p5, &n_p2x.sigils_p))))
                }
            };
            prism_rtl::Turn::Finished(crate::check::expr::bind_local_id_f(&crate::check::expr::with_local_f(&env_p0x, &name_p5, &crate::check::types::schemes::mono_f(&t_p4x)), &crate::check::types::recording::note_binder_f(&st5_p7, &n_p2x.span_p, &name_p5, &t_p4x), &name_p5, &n_p2x.span_p))
        })
    }
}

/// `Start BindFreshMarked, x`: what the function value is when passed to `@Run`.
pub fn start_bind_fresh_marked_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, marks_p3: Text, t_p4: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindFreshMarked { env_p0, st_p1, n_p2, marks_p3, t_p4 })
}

/// ```prism
/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_field_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, ft_p3: &crate::check::types::Ty, snapshot_p4: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    match crate::check::types::recording::walk_f(st_p1, ft_p3) {
        crate::check::types::Ty::TySig(s_p5, level_p6) if (*snapshot_p4 && (&s_p5 == &Text::lit("$"))) => bind_level_f(env_p0, st_p1, p_p2, &*level_p6),
        _ => bind_pattern_f(env_p0, st_p1, p_p2, ft_p3, &true),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BindField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub struct BindField {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub ft_p3: crate::check::types::Ty,
    pub snapshot_p4: bool,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindField {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let ft_p3 = &self.ft_p3;
        let snapshot_p4 = &self.snapshot_p4;
        let env_p0x = env_p0.clone();
        let ft_p3x = ft_p3.clone();
        let p_p2x = p_p2.clone();
        let snapshot_p4x = *snapshot_p4;
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), ft_p3x.clone()), move |walk_f_6089: crate::check::types::Ty| match walk_f_6089 {
            crate::check::types::Ty::TySig(s_p5, level_p6) if (snapshot_p4x && (&s_p5 == &Text::lit("$"))) => prism_rtl::Turn::More(Rc::new(BindLevel { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), p_p2: p_p2x.clone(), level_p3: (*level_p6).clone() })),
            _ => prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), p_p2: p_p2x.clone(), t_p3: ft_p3x.clone(), refutable_p4: true })),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start BindField, x`: what the function value is when passed to `@Run`.
pub fn start_bind_field_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, ft_p3: crate::check::types::Ty, snapshot_p4: bool) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindField { env_p0, st_p1, p_p2, ft_p3, snapshot_p4 })
}

/// ```prism
/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
/// ```
pub fn bind_level_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, level_p3: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    match &*p_p2.kind_p {
        crate::syntax::PatternKind::PName(n_p4) => if crate::syntax::lexer::chars::has_prefix_f(&n_p4.sigils_p, &Text::lit("$")) && (&crate::prelude::len(&n_p4.path_p) == &Nat::from(1u32)) {
            bind_fresh_marked_f(env_p0, st_p1, n_p4, &crate::syntax::lexer::chars::after_first_f(&n_p4.sigils_p), level_p3)
        } else {
            bind_pattern_f(env_p0, st_p1, p_p2, level_p3, &true)
        },
        crate::syntax::PatternKind::PGroup(q_p5) => bind_level_f(env_p0, st_p1, &**q_p5, level_p3),
        _ => bind_pattern_f(env_p0, st_p1, p_p2, level_p3, &true),
    }
}

/// The step machine of `BindLevel`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
/// ```
pub struct BindLevel {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub level_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindLevel {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let level_p3 = &self.level_p3;
        match &*p_p2.kind_p {
            crate::syntax::PatternKind::PName(n_p4) => if crate::syntax::lexer::chars::has_prefix_f(&n_p4.sigils_p, &Text::lit("$")) && (&crate::prelude::len(&n_p4.path_p) == &Nat::from(1u32)) {
                prism_rtl::Turn::More(Rc::new(BindFreshMarked { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p4.clone(), marks_p3: crate::syntax::lexer::chars::after_first_f(&n_p4.sigils_p), t_p4: level_p3.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), t_p3: level_p3.clone(), refutable_p4: true }))
            },
            crate::syntax::PatternKind::PGroup(q_p5) => prism_rtl::Turn::More(Rc::new(BindLevel { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: (**q_p5).clone(), level_p3: level_p3.clone() })),
            _ => prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), t_p3: level_p3.clone(), refutable_p4: true })),
        }
    }
}

/// `Start BindLevel, x`: what the function value is when passed to `@Run`.
pub fn start_bind_level_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, level_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindLevel { env_p0, st_p1, p_p2, level_p3 })
}

/// ```prism
/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
/// ```
pub fn bind_ctor_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, n_p3: &crate::syntax::SName, args_p4: &Array<crate::syntax::Pattern_>, t_p5: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let (qk_o6, why_p7) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p3);
    match &qk_o6 {
        None => (env_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), &n_p3.span_p, &Text::from(format!("no constructor `{}`", &crate::check::env::sname_key_f(n_p3))))),
        Some(qk_p8) => if &why_p7 == &Text::lit("tag") {
            bind_tag_pattern_f(env_p0, st_p1, p_p2, qk_p8, &Array::new(), &true, t_p5)
        } else {
            match crate::prelude::get(&env_p0.g_p.ctors_p, qk_p8) {
                None => (env_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), &n_p3.span_p, &Text::from(format!("`{}` is not a constructor", &crate::check::env::sname_key_f(n_p3))))),
                Some(c_p9) => {
                    let (self_pb, st1_pc, inst_pd) = crate::check::types::schemes::instantiate_with_f(st_p1, &crate::check::types::Scheme { qs_p: c_p9.params_p.clone(), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: c_p9.ty_p.clone() }, &p_p2.span_p, &Array::new());
                    let st2_pa = crate::check::types::unify::unify_f(&st1_pc, t_p5, &self_pb, &p_p2.span_p);
                    if (&crate::prelude::len(args_p4) != &crate::prelude::len(&c_p9.args_p)) && !((&crate::prelude::len(args_p4) == &Nat::from(1u32)) && (&crate::prelude::len(&c_p9.args_p) > &Nat::from(1u32))) {
                        (env_p0.clone(), crate::check::types::recording::err_f(&st2_pa, &Text::lit("mismatch"), &p_p2.span_p, &Text::from(format!("`{}` takes {} argument{}; this pattern gives {}", &crate::check::types::bare_name_f(&c_p9.name_p), &crate::check::errors::count_word_f(&crate::prelude::len(&c_p9.args_p)), &(if &crate::prelude::len(&c_p9.args_p) == &Nat::from(1u32) {
                            Text::lit("")
                        } else {
                            Text::lit("s")
                        }), &crate::check::errors::count_word_f(&crate::prelude::len(args_p4))))))
                    } else {
                        crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(args_p4)), (env_p0.clone(), st2_pa.clone()), {
                            let args_p4x = args_p4.clone();
                            let p_p2x = p_p2.clone();
                            let inst_pdx = inst_pd.clone();
                            let c_p9x = c_p9.clone();
                            Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                                let args_p4xy = args_p4x.clone();
                                let p_p2xy = p_p2x.clone();
                                let inst_pdxy = inst_pdx.clone();
                                let c_p9xy = c_p9x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (en_pe, s_pf) = p0;
                                    let i_pg = p1;
                                    crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pdxy.clone(), crate::prelude::or(&crate::prelude::index(&c_p9xy.args_p, &i_pg), &crate::check::types::Ty::TyErr)), move |subst_q_f_7811: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_pe.clone(), st_p1: s_pf.clone(), p_p2: crate::prelude::or(&crate::prelude::index(&args_p4xy, &i_pg), &crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xy.span_p.clone() }), t_p3: subst_q_f_7811, refutable_p4: true })))
                                }))
                            }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                        }))
                    }
                },
            }
        },
    }
}

/// The step machine of `BindCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
/// ```
pub struct BindCtor {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub n_p3: crate::syntax::SName,
    pub args_p4: Array<crate::syntax::Pattern_>,
    pub t_p5: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindCtor {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let n_p3 = &self.n_p3;
        let args_p4 = &self.args_p4;
        let t_p5 = &self.t_p5;
        let (qk_o6, why_p7) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p3);
        match &qk_o6 {
            None => prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), &n_p3.span_p, &Text::from(format!("no constructor `{}`", &crate::check::env::sname_key_f(n_p3)))))),
            Some(qk_p8) => if &why_p7 == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(BindTagPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), name_p3: qk_p8.clone(), fields_p4: Array::new(), rest_p5: true, t_p6: t_p5.clone() }))
            } else {
                match crate::prelude::get(&env_p0.g_p.ctors_p, qk_p8) {
                    None => prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), &n_p3.span_p, &Text::from(format!("`{}` is not a constructor", &crate::check::env::sname_key_f(n_p3)))))),
                    Some(c_p9) => {
                        let args_p4x = args_p4.clone();
                        let env_p0x = env_p0.clone();
                        let p_p2x = p_p2.clone();
                        let st_p1x = st_p1.clone();
                        let t_p5x = t_p5.clone();
                        crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p1x.clone(), crate::check::types::Scheme { qs_p: c_p9.params_p.clone(), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: c_p9.ty_p.clone() }, p_p2x.span_p.clone(), Array::new()), move |instantiate_with_f_7174: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                            let (self_pb, st1_pc, inst_pd) = instantiate_with_f_7174;
                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(st1_pc.clone(), t_p5x.clone(), self_pb.clone(), p_p2x.span_p.clone()), move |unify_f_7329: crate::check::types::St| {
                                let st2_pa = unify_f_7329;
                                if (&crate::prelude::len(&args_p4x) != &crate::prelude::len(&c_p9.args_p)) && !((&crate::prelude::len(&args_p4x) == &Nat::from(1u32)) && (&crate::prelude::len(&c_p9.args_p) > &Nat::from(1u32))) {
                                    prism_rtl::Turn::Finished((env_p0x.clone(), crate::check::types::recording::err_f(&st2_pa, &Text::lit("mismatch"), &p_p2x.span_p, &Text::from(format!("`{}` takes {} argument{}; this pattern gives {}", &crate::check::types::bare_name_f(&c_p9.name_p), &crate::check::errors::count_word_f(&crate::prelude::len(&c_p9.args_p)), &(if &crate::prelude::len(&c_p9.args_p) == &Nat::from(1u32) {
                                        Text::lit("")
                                    } else {
                                        Text::lit("s")
                                    }), &crate::check::errors::count_word_f(&crate::prelude::len(&args_p4x)))))))
                                } else {
                                    crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&args_p4x)), (env_p0x.clone(), st2_pa.clone()), {
                                        let args_p4xx = args_p4x.clone();
                                        let p_p2xx = p_p2x.clone();
                                        let inst_pdx = inst_pd.clone();
                                        let c_p9x = c_p9.clone();
                                        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                                            let args_p4xxy = args_p4xx.clone();
                                            let p_p2xxy = p_p2xx.clone();
                                            let inst_pdxy = inst_pdx.clone();
                                            let c_p9xy = c_p9x.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let (en_pe, s_pf) = p0;
                                                let i_pg = p1;
                                                crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pdxy.clone(), crate::prelude::or(&crate::prelude::index(&c_p9xy.args_p, &i_pg), &crate::check::types::Ty::TyErr)), move |subst_q_f_7811: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_pe.clone(), st_p1: s_pf.clone(), p_p2: crate::prelude::or(&crate::prelude::index(&args_p4xxy, &i_pg), &crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xxy.span_p.clone() }), t_p3: subst_q_f_7811, refutable_p4: true })))
                                            }))
                                        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                                    }).cycle()
                                }
                            })
                        })
                    },
                }
            },
        }
    }
}

/// `Start BindCtor, x`: what the function value is when passed to `@Run`.
pub fn start_bind_ctor_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, n_p3: crate::syntax::SName, args_p4: Array<crate::syntax::Pattern_>, t_p5: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindCtor { env_p0, st_p1, p_p2, n_p3, args_p4, t_p5 })
}

/// ```prism
/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub fn bind_record_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, n_p3: &crate::syntax::SName, fields_p4: &Array<crate::syntax::FieldPat>, rest_p5: &bool, t_p6: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let (qk_o7, why_p8) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p3);
    match &qk_o7 {
        None => (env_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), &n_p3.span_p, &Text::from(format!("no record or tag `{}`", &crate::check::env::sname_key_f(n_p3))))),
        Some(qk_p9) => if &why_p8 == &Text::lit("tag") {
            bind_tag_pattern_f(env_p0, st_p1, p_p2, qk_p9, fields_p4, rest_p5, t_p6)
        } else {
            match crate::prelude::get(&env_p0.g_p.ctors_p, qk_p9) {
                None => (env_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), &n_p3.span_p, &Text::from(format!("`{}` is not a record", &crate::check::env::sname_key_f(n_p3))))),
                Some(c_pa) => {
                    let (self_pc, st1_pd, inst_pe) = crate::check::types::schemes::instantiate_with_f(st_p1, &crate::check::types::Scheme { qs_p: c_pa.params_p.clone(), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: c_pa.ty_p.clone() }, &p_p2.span_p, &Array::new());
                    let st2_pb = crate::check::types::unify::unify_f(&st1_pd, t_p6, &self_pc, &p_p2.span_p);
                    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(fields_p4)), (env_p0.clone(), st2_pb.clone()), {
                        let fields_p4x = fields_p4.clone();
                        let p_p2x = p_p2.clone();
                        let c_pax = c_pa.clone();
                        let inst_pex = inst_pe.clone();
                        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                            let fields_p4xy = fields_p4x.clone();
                            let p_p2xy = p_p2x.clone();
                            let c_paxy = c_pax.clone();
                            let inst_pexy = inst_pex.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (en_pf, s_pg) = p0;
                                let i_ph = p1;
                                {
                                    let fp_pi = crate::prelude::or(&crate::prelude::index(&fields_p4xy, &i_ph), &crate::syntax::FieldPat { name_o: None, pattern_p: crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xy.span_p.clone() }, span_p: p_p2xy.span_p.clone() });
                                    let fname_pj = field_pat_name_f(&fp_pi, &c_paxy.fields_p, &i_ph);
                                    match crate::check::expr::operators::index_of_o(&c_paxy.fields_p, &fname_pj) {
                                        Some(j_pk) => crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pexy.clone(), crate::prelude::or(&crate::prelude::index(&c_paxy.args_p, &j_pk), &crate::check::types::Ty::TyErr)), move |subst_q_f_9164: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_pf.clone(), st_p1: s_pg.clone(), p_p2: fp_pi.pattern_p.clone(), t_p3: subst_q_f_9164, refutable_p4: true }))),
                                        None => prism_rtl::Turn::Finished((en_pf.clone(), crate::check::types::recording::err_f(&s_pg, &Text::lit("mismatch"), &fp_pi.span_p, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name_f(&c_paxy.owner_p), &fname_pj))))),
                                    }
                                }
                            }))
                        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                    }))
                },
            }
        },
    }
}

/// The step machine of `BindRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub struct BindRecord {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub n_p3: crate::syntax::SName,
    pub fields_p4: Array<crate::syntax::FieldPat>,
    pub rest_p5: bool,
    pub t_p6: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindRecord {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let n_p3 = &self.n_p3;
        let fields_p4 = &self.fields_p4;
        let rest_p5 = &self.rest_p5;
        let t_p6 = &self.t_p6;
        let (qk_o7, why_p8) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p3);
        match &qk_o7 {
            None => prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), &n_p3.span_p, &Text::from(format!("no record or tag `{}`", &crate::check::env::sname_key_f(n_p3)))))),
            Some(qk_p9) => if &why_p8 == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(BindTagPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), name_p3: qk_p9.clone(), fields_p4: fields_p4.clone(), rest_p5: *rest_p5, t_p6: t_p6.clone() }))
            } else {
                match crate::prelude::get(&env_p0.g_p.ctors_p, qk_p9) {
                    None => prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), &n_p3.span_p, &Text::from(format!("`{}` is not a record", &crate::check::env::sname_key_f(n_p3)))))),
                    Some(c_pa) => {
                        let env_p0x = env_p0.clone();
                        let fields_p4x = fields_p4.clone();
                        let p_p2x = p_p2.clone();
                        let st_p1x = st_p1.clone();
                        let t_p6x = t_p6.clone();
                        crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p1x.clone(), crate::check::types::Scheme { qs_p: c_pa.params_p.clone(), plain_qs_p: Array::new(), rqs_p: Array::new(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: c_pa.ty_p.clone() }, p_p2x.span_p.clone(), Array::new()), move |instantiate_with_f_8595: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                            let (self_pc, st1_pd, inst_pe) = instantiate_with_f_8595;
                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(st1_pd.clone(), t_p6x.clone(), self_pc.clone(), p_p2x.span_p.clone()), move |unify_f_8750: crate::check::types::St| {
                                let st2_pb = unify_f_8750;
                                crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&fields_p4x)), (env_p0x.clone(), st2_pb.clone()), {
                                    let fields_p4xx = fields_p4x.clone();
                                    let p_p2xx = p_p2x.clone();
                                    let c_pax = c_pa.clone();
                                    let inst_pex = inst_pe.clone();
                                    Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                                        let fields_p4xxy = fields_p4xx.clone();
                                        let p_p2xxy = p_p2xx.clone();
                                        let c_paxy = c_pax.clone();
                                        let inst_pexy = inst_pex.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let (en_pf, s_pg) = p0;
                                            let i_ph = p1;
                                            {
                                                let fp_pi = crate::prelude::or(&crate::prelude::index(&fields_p4xxy, &i_ph), &crate::syntax::FieldPat { name_o: None, pattern_p: crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xxy.span_p.clone() }, span_p: p_p2xxy.span_p.clone() });
                                                let fname_pj = field_pat_name_f(&fp_pi, &c_paxy.fields_p, &i_ph);
                                                match crate::check::expr::operators::index_of_o(&c_paxy.fields_p, &fname_pj) {
                                                    Some(j_pk) => crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pexy.clone(), crate::prelude::or(&crate::prelude::index(&c_paxy.args_p, &j_pk), &crate::check::types::Ty::TyErr)), move |subst_q_f_9164: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_pf.clone(), st_p1: s_pg.clone(), p_p2: fp_pi.pattern_p.clone(), t_p3: subst_q_f_9164, refutable_p4: true }))),
                                                    None => prism_rtl::Turn::Finished((en_pf.clone(), crate::check::types::recording::err_f(&s_pg, &Text::lit("mismatch"), &fp_pi.span_p, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name_f(&c_paxy.owner_p), &fname_pj))))),
                                                }
                                            }
                                        }))
                                    }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                                }).cycle()
                            })
                        })
                    },
                }
            },
        }
    }
}

/// `Start BindRecord, x`: what the function value is when passed to `@Run`.
pub fn start_bind_record_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, n_p3: crate::syntax::SName, fields_p4: Array<crate::syntax::FieldPat>, rest_p5: bool, t_p6: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindRecord { env_p0, st_p1, p_p2, n_p3, fields_p4, rest_p5, t_p6 })
}

/// ```prism
/// FieldPatName: fn FieldPat, [Text], Nat -> Text
/// ```
pub fn field_pat_name_f(fp_p0: &crate::syntax::FieldPat, fields_p1: &Array<Text>, i_p2: &Nat) -> Text {
    match &fp_p0.name_o {
        Some(id_p3) => id_p3.name_p.clone(),
        None => match &*fp_p0.pattern_p.kind_p {
            crate::syntax::PatternKind::PName(n_p4) => if crate::check::types::has_text_f(fields_p1, &crate::check::env::sname_key_f(n_p4)) {
                crate::check::env::sname_key_f(n_p4)
            } else {
                crate::prelude::or(&crate::prelude::index(fields_p1, i_p2), &Text::lit(""))
            },
            _ => crate::prelude::or(&crate::prelude::index(fields_p1, i_p2), &Text::lit("")),
        },
    }
}

/// ```prism
/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub fn bind_tag_pattern_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, name_p3: &Text, fields_p4: &Array<crate::syntax::FieldPat>, rest_p5: &bool, t_p6: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    match crate::prelude::get(&env_p0.g_p.tags_p, name_p3) {
        None => (env_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), &p_p2.span_p, &Text::from(format!("no tag `{}`", name_p3)))),
        Some(tg_p7) => {
            let st1_p8 = if &tg_p7.kind_p == &Text::lit("Element") {
                tag_in_row_f(env_p0, st_p1, &tg_p7, t_p6, &p_p2.span_p)
            } else {
                crate::check::types::unify::unify_f(st_p1, t_p6, &crate::check::types::Ty::TyCon(tg_p7.kind_p.clone(), Array::new()), &p_p2.span_p)
            };
            let snapshot_p9 = is_snapshot_f(&st1_p8, t_p6);
            let (_, st2_pb, inst_pc) = crate::check::types::schemes::instantiate_with_f(&st1_p8, &crate::check::types::Scheme { qs_p: tg_p7.qs_p.clone(), plain_qs_p: Array::new(), rqs_p: tg_p7.rqs_p.clone(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: tg_p7.out_p.clone() }, &p_p2.span_p, &Array::new());
            let names_pa = crate::prelude::each(&tg_p7.fields_p, &(|(f_pd, _): &(Text, crate::check::types::Ty)| f_pd.clone()));
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(fields_p4)), (env_p0.clone(), st2_pb.clone()), {
                let fields_p4x = fields_p4.clone();
                let p_p2x = p_p2.clone();
                let names_pax = names_pa.clone();
                let tg_p7x = tg_p7.clone();
                let inst_pcx = inst_pc.clone();
                let snapshot_p9x = snapshot_p9;
                let name_p3x = name_p3.clone();
                Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                    let fields_p4xy = fields_p4x.clone();
                    let p_p2xy = p_p2x.clone();
                    let names_paxy = names_pax.clone();
                    let tg_p7xy = tg_p7x.clone();
                    let inst_pcxy = inst_pcx.clone();
                    let snapshot_p9xy = snapshot_p9x;
                    let name_p3xy = name_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (en_pe, s_pf) = p0;
                        let i_pg = p1;
                        {
                            let fp_ph = crate::prelude::or(&crate::prelude::index(&fields_p4xy, &i_pg), &crate::syntax::FieldPat { name_o: None, pattern_p: crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xy.span_p.clone() }, span_p: p_p2xy.span_p.clone() });
                            let fname_pi = field_pat_name_f(&fp_ph, &names_paxy, &i_pg);
                            match crate::check::expr::calls::field_of_tag_o(&tg_p7xy, &fname_pi) {
                                Some(ft_pj) => crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pcxy.clone(), ft_pj.clone()), move |subst_q_f_10850: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindField { env_p0: en_pe.clone(), st_p1: s_pf.clone(), p_p2: fp_ph.pattern_p.clone(), ft_p3: subst_q_f_10850, snapshot_p4: snapshot_p9xy }))),
                                None => prism_rtl::Turn::Finished((en_pe.clone(), crate::check::types::recording::err_f(&s_pf, &Text::lit("mismatch"), &fp_ph.span_p, &Text::from(format!("`{}` has no field `{}`", &name_p3xy, &fname_pi))))),
                            }
                        }
                    }))
                }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }))
        },
    }
}

/// The step machine of `BindTagPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub struct BindTagPattern {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub name_p3: Text,
    pub fields_p4: Array<crate::syntax::FieldPat>,
    pub rest_p5: bool,
    pub t_p6: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindTagPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let name_p3 = &self.name_p3;
        let fields_p4 = &self.fields_p4;
        let rest_p5 = &self.rest_p5;
        let t_p6 = &self.t_p6;
        match crate::prelude::get(&env_p0.g_p.tags_p, name_p3) {
            None => prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("unknown-name"), &p_p2.span_p, &Text::from(format!("no tag `{}`", name_p3))))),
            Some(tg_p7) => {
                let st1_p8 = if &tg_p7.kind_p == &Text::lit("Element") {
                    tag_in_row_f(env_p0, st_p1, &tg_p7, t_p6, &p_p2.span_p)
                } else {
                    crate::check::types::unify::unify_f(st_p1, t_p6, &crate::check::types::Ty::TyCon(tg_p7.kind_p.clone(), Array::new()), &p_p2.span_p)
                };
                let env_p0x = env_p0.clone();
                let fields_p4x = fields_p4.clone();
                let name_p3x = name_p3.clone();
                let p_p2x = p_p2.clone();
                let t_p6x = t_p6.clone();
                crate::prelude::call_then(start_is_snapshot_f(st1_p8.clone(), t_p6x.clone()), move |is_snapshot_f_10294: bool| {
                    let snapshot_p9 = is_snapshot_f_10294;
                    crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st1_p8.clone(), crate::check::types::Scheme { qs_p: tg_p7.qs_p.clone(), plain_qs_p: Array::new(), rqs_p: tg_p7.rqs_p.clone(), cqs_p: Array::new(), cjoins_p: Array::new(), bounds_p: Array::new(), ty_p: tg_p7.out_p.clone() }, p_p2x.span_p.clone(), Array::new()), move |instantiate_with_f_10348: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                        let (_, st2_pb, inst_pc) = instantiate_with_f_10348;
                        let names_pa = crate::prelude::each(&tg_p7.fields_p, &(|(f_pd, _): &(Text, crate::check::types::Ty)| f_pd.clone()));
                        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&fields_p4x)), (env_p0x.clone(), st2_pb.clone()), {
                            let fields_p4xx = fields_p4x.clone();
                            let p_p2xx = p_p2x.clone();
                            let names_pax = names_pa.clone();
                            let tg_p7x = tg_p7.clone();
                            let inst_pcx = inst_pc.clone();
                            let snapshot_p9x = snapshot_p9;
                            let name_p3xx = name_p3x.clone();
                            Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                                let fields_p4xxy = fields_p4xx.clone();
                                let p_p2xxy = p_p2xx.clone();
                                let names_paxy = names_pax.clone();
                                let tg_p7xy = tg_p7x.clone();
                                let inst_pcxy = inst_pcx.clone();
                                let snapshot_p9xy = snapshot_p9x;
                                let name_p3xxy = name_p3xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (en_pe, s_pf) = p0;
                                    let i_pg = p1;
                                    {
                                        let fp_ph = crate::prelude::or(&crate::prelude::index(&fields_p4xxy, &i_pg), &crate::syntax::FieldPat { name_o: None, pattern_p: crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xxy.span_p.clone() }, span_p: p_p2xxy.span_p.clone() });
                                        let fname_pi = field_pat_name_f(&fp_ph, &names_paxy, &i_pg);
                                        match crate::check::expr::calls::field_of_tag_o(&tg_p7xy, &fname_pi) {
                                            Some(ft_pj) => crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pcxy.clone(), ft_pj.clone()), move |subst_q_f_10850: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindField { env_p0: en_pe.clone(), st_p1: s_pf.clone(), p_p2: fp_ph.pattern_p.clone(), ft_p3: subst_q_f_10850, snapshot_p4: snapshot_p9xy }))),
                                            None => prism_rtl::Turn::Finished((en_pe.clone(), crate::check::types::recording::err_f(&s_pf, &Text::lit("mismatch"), &fp_ph.span_p, &Text::from(format!("`{}` has no field `{}`", &name_p3xxy, &fname_pi))))),
                                        }
                                    }
                                }))
                            }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                        }).cycle()
                    })
                })
            },
        }
    }
}

/// `Start BindTagPattern, x`: what the function value is when passed to `@Run`.
pub fn start_bind_tag_pattern_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, name_p3: Text, fields_p4: Array<crate::syntax::FieldPat>, rest_p5: bool, t_p6: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindTagPattern { env_p0, st_p1, p_p2, name_p3, fields_p4, rest_p5, t_p6 })
}

/// ```prism
/// IsSnapshot: unbounded fn St, Ty -> Bool
/// ```
pub fn is_snapshot_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TyElemAny(_) => true,
        _ => false,
    }
}

/// The step machine of `IsSnapshot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsSnapshot: unbounded fn St, Ty -> Bool
/// ```
pub struct IsSnapshot {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for IsSnapshot {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_11187: crate::check::types::Ty| match walk_f_11187 {
            crate::check::types::Ty::TyElemAny(_) => prism_rtl::Turn::Finished(true),
            _ => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start IsSnapshot, x`: what the function value is when passed to `@Run`.
pub fn start_is_snapshot_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsSnapshot { st_p0, t_p1 })
}

/// ```prism
/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
/// ```
pub fn tag_in_row_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, tg_p2: &crate::check::env::TagInfo, t_p3: &crate::check::types::Ty, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk_f(st_p1, t_p3) {
        crate::check::types::Ty::TyElem(rw_p5, _) => {
            let w_p6 = crate::check::types::recording::walk_row_f(st_p1, &rw_p5);
            if crate::check::types::has_text_f(&w_p6.fams_p, &tg_p2.family_p) {
                st_p1.clone()
            } else {
                crate::check::types::recording::err_fix_f(st_p1, &Text::lit("row-not-here"), span_p4, &Text::from(format!("`{}` is not in this row, `{}`", &tg_p2.name_p, &crate::check::types::show_row_f(&w_p6))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg_p2.family_p)))
            }
        },
        crate::check::types::Ty::TyElemAny(rw_p7) => {
            let w_p8 = crate::check::types::recording::walk_row_f(st_p1, &rw_p7);
            if crate::check::types::has_text_f(&w_p8.fams_p, &tg_p2.family_p) {
                st_p1.clone()
            } else {
                crate::check::types::recording::err_fix_f(st_p1, &Text::lit("row-not-here"), span_p4, &Text::from(format!("`{}` is not in this row, `{}`", &tg_p2.name_p, &crate::check::types::show_row_f(&w_p8))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg_p2.family_p)))
            }
        },
        crate::check::types::Ty::TyFlex(_) => {
            let (rw_p9, st2_pa) = crate::check::types::recording::fresh_row_f(st_p1, &Array::from(vec![tg_p2.family_p.clone()]));
            let (o_pb, st3_pc) = crate::check::types::fresh_var_f(&st2_pa, &false, &Text::lit(""));
            crate::check::types::unify::unify_f(&st3_pc, t_p3, &crate::check::types::Ty::TyElem(crate::check::types::Rw { fams_p: Array::from(vec![tg_p2.family_p.clone()]), minus_p: Array::new(), tail_p: rw_p9.tail_p.clone() }, Rc::new(o_pb.clone())), span_p4)
        },
        crate::check::types::Ty::TyErr => st_p1.clone(),
        other_pd => crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), span_p4, &Text::from(format!("a tag pattern matches an element; this is `{}`", &crate::check::types::show_ty_f(st_p1, &other_pd)))),
    }
}

/// The step machine of `TagInRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
/// ```
pub struct TagInRow {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub tg_p2: crate::check::env::TagInfo,
    pub t_p3: crate::check::types::Ty,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for TagInRow {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let tg_p2 = &self.tg_p2;
        let t_p3 = &self.t_p3;
        let span_p4 = &self.span_p4;
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        let t_p3x = t_p3.clone();
        let tg_p2x = tg_p2.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), t_p3x.clone()), move |walk_f_11346: crate::check::types::Ty| match walk_f_11346 {
            crate::check::types::Ty::TyElem(rw_p5, _) => crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_p5.clone()), move |walk_row_f_11397: crate::check::types::Rw| {
                let w_p6 = walk_row_f_11397;
                if crate::check::types::has_text_f(&w_p6.fams_p, &tg_p2x.family_p) {
                    prism_rtl::Turn::Finished(st_p1x.clone())
                } else {
                    prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &Text::lit("row-not-here"), &span_p4x, &Text::from(format!("`{}` is not in this row, `{}`", &tg_p2x.name_p, &crate::check::types::show_row_f(&w_p6))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg_p2x.family_p))))
                }
            }),
            crate::check::types::Ty::TyElemAny(rw_p7) => crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_p7.clone()), move |walk_row_f_11645: crate::check::types::Rw| {
                let w_p8 = walk_row_f_11645;
                if crate::check::types::has_text_f(&w_p8.fams_p, &tg_p2x.family_p) {
                    prism_rtl::Turn::Finished(st_p1x.clone())
                } else {
                    prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &Text::lit("row-not-here"), &span_p4x, &Text::from(format!("`{}` is not in this row, `{}`", &tg_p2x.name_p, &crate::check::types::show_row_f(&w_p8))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg_p2x.family_p))))
                }
            }),
            crate::check::types::Ty::TyFlex(_) => {
                let (rw_p9, st2_pa) = crate::check::types::recording::fresh_row_f(&st_p1x, &Array::from(vec![tg_p2x.family_p.clone()]));
                let (o_pb, st3_pc) = crate::check::types::fresh_var_f(&st2_pa, &false, &Text::lit(""));
                prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st3_pc.clone(), expected_p1: t_p3x.clone(), found_p2: crate::check::types::Ty::TyElem(crate::check::types::Rw { fams_p: Array::from(vec![tg_p2x.family_p.clone()]), minus_p: Array::new(), tail_p: rw_p9.tail_p.clone() }, Rc::new(o_pb.clone())), span_p3: span_p4x.clone() }))
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished(st_p1x.clone()),
            other_pd => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), other_pd.clone()), move |show_ty_f_12167: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&st_p1x, &Text::lit("mismatch"), &span_p4x, &Text::from(format!("a tag pattern matches an element; this is `{}`", &show_ty_f_12167))))),
        })
    }
}

/// `Start TagInRow, x`: what the function value is when passed to `@Run`.
pub fn start_tag_in_row_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, tg_p2: crate::check::env::TagInfo, t_p3: crate::check::types::Ty, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(TagInRow { env_p0, st_p1, tg_p2, t_p3, span_p4 })
}

/// ```prism
/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
/// ```
pub fn bind_family_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fam_p2: &Text, t_p3: &crate::check::types::Ty, span_p4: &crate::syntax::Range) -> (crate::check::expr::Env, crate::check::types::St) {
    match crate::check::types::recording::walk_f(st_p1, t_p3) {
        crate::check::types::Ty::TyElem(rw_p5, _) => {
            let w_p6 = crate::check::types::recording::walk_row_f(st_p1, &rw_p5);
            if crate::check::types::has_text_f(&w_p6.fams_p, fam_p2) {
                (env_p0.clone(), st_p1.clone())
            } else {
                (env_p0.clone(), crate::check::types::recording::err_fix_f(st_p1, &Text::lit("row-not-here"), span_p4, &Text::from(format!("`{}.*` is not in this row, `{}`", fam_p2, &crate::check::types::show_row_f(&w_p6))), &Text::from(format!("add `{}.*` to the row", fam_p2))))
            }
        },
        _ => (env_p0.clone(), st_p1.clone()),
    }
}

/// The step machine of `BindFamily`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
/// ```
pub struct BindFamily {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fam_p2: Text,
    pub t_p3: crate::check::types::Ty,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindFamily {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fam_p2 = &self.fam_p2;
        let t_p3 = &self.t_p3;
        let span_p4 = &self.span_p4;
        let env_p0x = env_p0.clone();
        let fam_p2x = fam_p2.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        let t_p3x = t_p3.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), t_p3x.clone()), move |walk_f_12297: crate::check::types::Ty| match walk_f_12297 {
            crate::check::types::Ty::TyElem(rw_p5, _) => crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_p5.clone()), move |walk_row_f_12348: crate::check::types::Rw| {
                let w_p6 = walk_row_f_12348;
                if crate::check::types::has_text_f(&w_p6.fams_p, &fam_p2x) {
                    prism_rtl::Turn::Finished((env_p0x.clone(), st_p1x.clone()))
                } else {
                    prism_rtl::Turn::Finished((env_p0x.clone(), crate::check::types::recording::err_fix_f(&st_p1x, &Text::lit("row-not-here"), &span_p4x, &Text::from(format!("`{}.*` is not in this row, `{}`", &fam_p2x, &crate::check::types::show_row_f(&w_p6))), &Text::from(format!("add `{}.*` to the row", &fam_p2x)))))
                }
            }),
            _ => prism_rtl::Turn::Finished((env_p0x.clone(), st_p1x.clone())),
        })
    }
}

/// `Start BindFamily, x`: what the function value is when passed to `@Run`.
pub fn start_bind_family_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fam_p2: Text, t_p3: crate::check::types::Ty, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindFamily { env_p0, st_p1, fam_p2, t_p3, span_p4 })
}
