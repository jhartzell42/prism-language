//! The module `Check.Expr.Patterns`, from `target/bootstrap/src/prismc/check/expr/patterns.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_pattern(env: &crate::check::expr::Env, st: &crate::check::types::St, p_: &crate::syntax::Pattern_, t: &crate::check::types::Ty, refutable: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => {
            let bare = or(&index(&n.path_, &Nat::from(0u32)), &Text::lit(""));
            let is_ctor = (crate::check::env::is_upper_text(&bare) && (&len_text(&n.sigils) == &Nat::from(0u32))) && is_ctor_name(env, n);
            if is_ctor || (&len(&n.path_) > &Nat::from(1u32)) {
                bind_ctor(env, st, p_, n, &Array::new(), t)
            } else {
                bind_name(env, st, n, t)
            }
        },
        crate::syntax::PatternKind::PIgnore => (env.clone(), st.clone()),
        crate::syntax::PatternKind::PLit(l) => {
            let (lt, st2) = crate::check::expr::infer_lit(env, st, l, &false, &p_.span);
            (env.clone(), crate::check::types::unify::unify(&st2, t, &lt, &p_.span))
        },
        crate::syntax::PatternKind::PNeg(l) => {
            let (lt, st2) = crate::check::expr::infer_lit(env, st, l, &true, &p_.span);
            (env.clone(), crate::check::types::unify::unify(&st2, t, &lt, &p_.span))
        },
        crate::syntax::PatternKind::PUnit => (env.clone(), crate::check::types::unify::unify(st, t, &crate::check::types::t_unit(), &p_.span)),
        crate::syntax::PatternKind::PNil => {
            let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
            (env.clone(), crate::check::types::unify::unify(&st2, t, &crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_.clone())), &p_.span))
        },
        crate::syntax::PatternKind::PCtor(n, args) => bind_ctor(env, st, p_, n, args, t),
        crate::syntax::PatternKind::PRecord(n, fields, rest) => bind_record(env, st, p_, n, fields, rest, t),
        crate::syntax::PatternKind::PSigil(s, inner) => if (s == &Text::lit("?")) || (s == &Text::lit("~")) {
            {
                let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                let st3 = crate::check::types::unify::unify(&st2, t, &crate::check::types::Ty::TySig(s.clone(), Rc::new(v_.clone())), &p_.span);
                bind_pattern(env, &st3, &**inner, &v_, refutable)
            }
        } else {
            {
                let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                let st3 = crate::check::types::unify::unify(&st2, t, &crate::check::types::with_marks(s, &v_, &env.scope), &p_.span);
                bind_pattern(env, &st3, &**inner, &v_, refutable)
            }
        },
        crate::syntax::PatternKind::PTuple(ps) => {
            let (vs, st2) = fold(ps, &(Array::new(), st.clone()), &(|(acc, s): &(Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Pattern_| {
                let (v_, s2) = crate::check::types::fresh_var(s, &false, &Text::lit(""));
                (push(acc, &v_), s2.clone())
            }));
            let st3 = crate::check::types::unify::unify(&st2, t, &crate::check::types::Ty::TyTuple(vs.clone()), &p_.span);
            run_to_end(fold_job(crate::check::errors::range0(&len(ps)), (env.clone(), st3.clone()), {
                let ps = ps.clone();
                let p_ = p_.clone();
                let vs = vs.clone();
                let refutable = *refutable;
                Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                    let ps = ps.clone();
                    let p_ = p_.clone();
                    let vs = vs.clone();
                    let refutable = refutable;
                    entered(once_job(move || {
                        let (en, s) = p0;
                        let i = p1;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: or(&index(&ps, &i), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_.span.clone() }), t: or(&index(&vs, &i), &crate::check::types::Ty::TyErr), refutable }))
                    }))
                }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }))
        },
        crate::syntax::PatternKind::PArray(ps) => {
            let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
            let st3 = crate::check::types::unify::unify(&st2, t, &crate::check::types::Ty::TyArray(Rc::new(v_.clone())), &p_.span);
            run_to_end(fold_job(ps.clone(), (env.clone(), st3.clone()), {
                let v_ = v_.clone();
                let refutable = *refutable;
                Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern_)| {
                    let v_ = v_.clone();
                    let refutable = refutable;
                    entered(once_job(move || {
                        let (en, s) = p0;
                        let q = p1;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: q.clone(), t: v_.clone(), refutable }))
                    }))
                }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }))
        },
        crate::syntax::PatternKind::PGroup(q) => bind_pattern(env, st, &**q, t, refutable),
        crate::syntax::PatternKind::PFamily(q) => bind_family(env, st, &crate::check::env::dotted(&q.path_), t, &p_.span),
    }
}

/// The step machine of `BindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub struct BindPattern {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub p_: crate::syntax::Pattern_,
    pub t: crate::check::types::Ty,
    pub refutable: bool,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let t = &self.t;
        let refutable = &self.refutable;
        match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => {
                let bare = or(&index(&n.path_, &Nat::from(0u32)), &Text::lit(""));
                let is_ctor = (crate::check::env::is_upper_text(&bare) && (&len_text(&n.sigils) == &Nat::from(0u32))) && is_ctor_name(env, n);
                if is_ctor || (&len(&n.path_) > &Nat::from(1u32)) {
                    prism_rtl::Turn::More(Rc::new(BindCtor { env: env.clone(), st: st.clone(), p_: p_.clone(), n: n.clone(), args: Array::new(), t: t.clone() }))
                } else {
                    prism_rtl::Turn::More(Rc::new(BindName { env: env.clone(), st: st.clone(), n: n.clone(), t: t.clone() }))
                }
            },
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished((env.clone(), st.clone())),
            crate::syntax::PatternKind::PLit(l) => {
                let env = env.clone();
                let l = l.clone();
                let p_ = p_.clone();
                let st = st.clone();
                let t = t.clone();
                call_then(crate::check::expr::start_infer_lit(env.clone(), st.clone(), l.clone(), false, p_.span.clone()), move |infer_lit_1841: (crate::check::types::Ty, crate::check::types::St)| {
                    let (lt, st2) = infer_lit_1841;
                    call_then(crate::check::types::unify::start_unify(st2.clone(), t.clone(), lt.clone(), p_.span.clone()), move |unify_1892: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), unify_1892)))
                })
            },
            crate::syntax::PatternKind::PNeg(l) => {
                let env = env.clone();
                let l = l.clone();
                let p_ = p_.clone();
                let st = st.clone();
                let t = t.clone();
                call_then(crate::check::expr::start_infer_lit(env.clone(), st.clone(), l.clone(), true, p_.span.clone()), move |infer_lit_1958: (crate::check::types::Ty, crate::check::types::St)| {
                    let (lt, st2) = infer_lit_1958;
                    call_then(crate::check::types::unify::start_unify(st2.clone(), t.clone(), lt.clone(), p_.span.clone()), move |unify_2008: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), unify_2008)))
                })
            },
            crate::syntax::PatternKind::PUnit => {
                let env = env.clone();
                let p_ = p_.clone();
                let st = st.clone();
                let t = t.clone();
                call_then(crate::check::types::unify::start_unify(st.clone(), t.clone(), crate::check::types::t_unit(), p_.span.clone()), move |unify_2055: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), unify_2055)))
            },
            crate::syntax::PatternKind::PNil => {
                let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                let env = env.clone();
                let p_ = p_.clone();
                let t = t.clone();
                call_then(crate::check::types::unify::start_unify(st2.clone(), t.clone(), crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_.clone())), p_.span.clone()), move |unify_2159: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), unify_2159)))
            },
            crate::syntax::PatternKind::PCtor(n, args) => prism_rtl::Turn::More(Rc::new(BindCtor { env: env.clone(), st: st.clone(), p_: p_.clone(), n: n.clone(), args: args.clone(), t: t.clone() })),
            crate::syntax::PatternKind::PRecord(n, fields, rest) => prism_rtl::Turn::More(Rc::new(BindRecord { env: env.clone(), st: st.clone(), p_: p_.clone(), n: n.clone(), fields: fields.clone(), rest: *rest, t: t.clone() })),
            crate::syntax::PatternKind::PSigil(s, inner) => if (s == &Text::lit("?")) || (s == &Text::lit("~")) {
                {
                    let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                    let env = env.clone();
                    let inner = (**inner).clone();
                    let p_ = p_.clone();
                    let refutable = *refutable;
                    let s = s.clone();
                    let t = t.clone();
                    call_then(crate::check::types::unify::start_unify(st2.clone(), t.clone(), crate::check::types::Ty::TySig(s.clone(), Rc::new(v_.clone())), p_.span.clone()), move |unify_2449: crate::check::types::St| {
                        let st3 = unify_2449;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env: env.clone(), st: st3.clone(), p_: inner.clone(), t: v_.clone(), refutable }))
                    })
                }
            } else {
                {
                    let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                    let env = env.clone();
                    let inner = (**inner).clone();
                    let p_ = p_.clone();
                    let refutable = *refutable;
                    let s = s.clone();
                    let t = t.clone();
                    call_then(crate::check::types::unify::start_unify(st2.clone(), t.clone(), crate::check::types::with_marks(&s, &v_, &env.scope), p_.span.clone()), move |unify_2626: crate::check::types::St| {
                        let st3 = unify_2626;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env: env.clone(), st: st3.clone(), p_: inner.clone(), t: v_.clone(), refutable }))
                    })
                }
            },
            crate::syntax::PatternKind::PTuple(ps) => {
                let (vs, st2) = fold(ps, &(Array::new(), st.clone()), &(|(acc, s): &(Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Pattern_| {
                    let (v_, s2) = crate::check::types::fresh_var(s, &false, &Text::lit(""));
                    (push(acc, &v_), s2.clone())
                }));
                let env = env.clone();
                let p_ = p_.clone();
                let ps = ps.clone();
                let refutable = *refutable;
                let t = t.clone();
                call_then(crate::check::types::unify::start_unify(st2.clone(), t.clone(), crate::check::types::Ty::TyTuple(vs.clone()), p_.span.clone()), move |unify_2918: crate::check::types::St| {
                    let st3 = unify_2918;
                    fold_job(crate::check::errors::range0(&len(&ps)), (env.clone(), st3.clone()), {
                        let ps = ps.clone();
                        let p_ = p_.clone();
                        let vs = vs.clone();
                        let refutable = refutable;
                        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                            let ps = ps.clone();
                            let p_ = p_.clone();
                            let vs = vs.clone();
                            let refutable = refutable;
                            entered(once_job(move || {
                                let (en, s) = p0;
                                let i = p1;
                                prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: or(&index(&ps, &i), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_.span.clone() }), t: or(&index(&vs, &i), &crate::check::types::Ty::TyErr), refutable }))
                            }))
                        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                    }).cycle()
                })
            },
            crate::syntax::PatternKind::PArray(ps) => {
                let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                let env = env.clone();
                let p_ = p_.clone();
                let ps = ps.clone();
                let refutable = *refutable;
                let t = t.clone();
                call_then(crate::check::types::unify::start_unify(st2.clone(), t.clone(), crate::check::types::Ty::TyArray(Rc::new(v_.clone())), p_.span.clone()), move |unify_3192: crate::check::types::St| {
                    let st3 = unify_3192;
                    fold_job(ps.clone(), (env.clone(), st3.clone()), {
                        let v_ = v_.clone();
                        let refutable = refutable;
                        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern_)| {
                            let v_ = v_.clone();
                            let refutable = refutable;
                            entered(once_job(move || {
                                let (en, s) = p0;
                                let q = p1;
                                prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: q.clone(), t: v_.clone(), refutable }))
                            }))
                        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                    }).cycle()
                })
            },
            crate::syntax::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(BindPattern { env: env.clone(), st: st.clone(), p_: (**q).clone(), t: t.clone(), refutable: *refutable })),
            crate::syntax::PatternKind::PFamily(q) => prism_rtl::Turn::More(Rc::new(BindFamily { env: env.clone(), st: st.clone(), fam: crate::check::env::dotted(&q.path_), t: t.clone(), span: p_.span.clone() })),
        }
    }
}

/// `Start BindPattern, x`: what the function value is when passed to `@Run`.
pub fn start_bind_pattern(env: crate::check::expr::Env, st: crate::check::types::St, p_: crate::syntax::Pattern_, t: crate::check::types::Ty, refutable: bool) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindPattern { env, st, p_, t, refutable })
}

/// ```prism
/// IsCtorName: fn Env, SName -> Bool
/// ```
pub fn is_ctor_name(env: &crate::check::expr::Env, n: &crate::syntax::SName) -> bool {
    let (qk_opt, _) = crate::check::env::names::resolve_value(&env.g, &env.home, n);
    match &qk_opt {
        Some(qk) => crate::check::env::has_key(&env.g.ctors, qk),
        None => false,
    }
}

/// ```prism
/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub fn bind_name(env: &crate::check::expr::Env, st: &crate::check::types::St, n: &crate::syntax::SName, t: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let name = crate::check::env::sname_key(n);
    if crate::check::types::has_text(&env.pending, &name) {
        match get(&env.locals, &name) {
            Some(sc) => {
                let (ok_, st1) = crate::check::types::unify::try_unify(st, &sc.ty, t, &n.span);
                let marks_agree = (&crate::check::types::stack_of(st, t) == &crate::check::expr::lets::type_marks(&n.sigils)) || crate::check::types::is_flex_var(st, t);
                let st_a = if ok_ {
                    st1.clone()
                } else {
                    if marks_agree {
                        crate::check::types::unify::unify(st, &sc.ty, t, &n.span)
                    } else {
                        crate::check::types::recording::err_fix(st, &Text::lit("mark-stack"), &n.span, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name, &crate::check::types::show_ty(st, t), &crate::check::types::stack_of(st, t), &crate::check::expr::lets::type_marks(&n.sigils))), &Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark(&n.sigils), &crate::check::types::stack_of(st, t), &crate::syntax::lexer::chars::drop_prefix(&name, &n.sigils))))
                    }
                };
                (env.clone(), crate::check::types::recording::note_binder(&st_a, &n.span, &name, t))
            },
            None => bind_fresh(env, st, n, t),
        }
    } else {
        bind_fresh(env, st, n, t)
    }
}

/// The step machine of `BindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub struct BindName {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub n: crate::syntax::SName,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindName {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let t = &self.t;
        let name = crate::check::env::sname_key(n);
        if crate::check::types::has_text(&env.pending, &name) {
            match get(&env.locals, &name) {
                Some(sc) => {
                    let env = env.clone();
                    let n = n.clone();
                    let st = st.clone();
                    let t = t.clone();
                    call_then(crate::check::types::unify::start_try_unify(st.clone(), sc.ty.clone(), t.clone(), n.span.clone()), move |try_unify_3987: (bool, crate::check::types::St)| {
                        let (ok_, st1) = try_unify_3987;
                        call_then(crate::check::types::start_stack_of(st.clone(), t.clone()), move |stack_of_4051: Text| {
                            let marks_agree = (&stack_of_4051 == &crate::check::expr::lets::type_marks(&n.sigils)) || crate::check::types::is_flex_var(&st, &t);
                            let st_a = if ok_ {
                                st1.clone()
                            } else {
                                if marks_agree {
                                    crate::check::types::unify::unify(&st, &sc.ty, &t, &n.span)
                                } else {
                                    crate::check::types::recording::err_fix(&st, &Text::lit("mark-stack"), &n.span, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name, &crate::check::types::show_ty(&st, &t), &crate::check::types::stack_of(&st, &t), &crate::check::expr::lets::type_marks(&n.sigils))), &Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark(&n.sigils), &crate::check::types::stack_of(&st, &t), &crate::syntax::lexer::chars::drop_prefix(&name, &n.sigils))))
                                }
                            };
                            prism_rtl::Turn::Finished((env.clone(), crate::check::types::recording::note_binder(&st_a, &n.span, &name, &t)))
                        })
                    })
                },
                None => prism_rtl::Turn::More(Rc::new(BindFresh { env: env.clone(), st: st.clone(), n: n.clone(), t: t.clone() })),
            }
        } else {
            prism_rtl::Turn::More(Rc::new(BindFresh { env: env.clone(), st: st.clone(), n: n.clone(), t: t.clone() }))
        }
    }
}

/// `Start BindName, x`: what the function value is when passed to `@Run`.
pub fn start_bind_name(env: crate::check::expr::Env, st: crate::check::types::St, n: crate::syntax::SName, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindName { env, st, n, t })
}

/// ```prism
/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub fn bind_fresh(env: &crate::check::expr::Env, st: &crate::check::types::St, n: &crate::syntax::SName, t: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    bind_fresh_marked(env, st, n, &crate::check::expr::lets::type_marks(&n.sigils), t)
}

/// The step machine of `BindFresh`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub struct BindFresh {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub n: crate::syntax::SName,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindFresh {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let t = &self.t;
        prism_rtl::Turn::More(Rc::new(BindFreshMarked { env: env.clone(), st: st.clone(), n: n.clone(), marks: crate::check::expr::lets::type_marks(&n.sigils), t: t.clone() }))
    }
}

/// `Start BindFresh, x`: what the function value is when passed to `@Run`.
pub fn start_bind_fresh(env: crate::check::expr::Env, st: crate::check::types::St, n: crate::syntax::SName, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindFresh { env, st, n, t })
}

/// ```prism
/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
/// ```
pub fn bind_fresh_marked(env: &crate::check::expr::Env, st: &crate::check::types::St, n: &crate::syntax::SName, marks: &Text, t: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let name = crate::check::env::sname_key(n);
    let (v_, st2) = crate::check::types::fresh_var(st, &true, &name);
    let (rw, st3) = crate::check::types::recording::fresh_row(&st2, &Array::new());
    let marked = crate::check::types::with_marks(marks, &v_, &rw);
    let (ok_, st4) = crate::check::types::unify::try_unify(&st3, t, &marked, &n.span);
    let st5 = if ok_ {
        st4.clone()
    } else {
        {
            let stack = crate::check::types::stack_of(&st3, t);
            crate::check::types::recording::err_fix(&st3, &Text::lit("mark-stack"), &n.span, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name, &crate::check::types::show_ty(&st3, t), &stack, marks)), &Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark(&n.sigils), &stack, &crate::syntax::lexer::chars::drop_prefix(&name, &n.sigils))))
        }
    };
    (crate::check::expr::with_local(env, &name, &crate::check::types::schemes::mono(t)), crate::check::types::recording::note_binder(&st5, &n.span, &name, t))
}

/// The step machine of `BindFreshMarked`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
/// ```
pub struct BindFreshMarked {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub n: crate::syntax::SName,
    pub marks: Text,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindFreshMarked {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let marks = &self.marks;
        let t = &self.t;
        let name = crate::check::env::sname_key(n);
        let (v_, st2) = crate::check::types::fresh_var(st, &true, &name);
        let (rw, st3) = crate::check::types::recording::fresh_row(&st2, &Array::new());
        let marked = crate::check::types::with_marks(marks, &v_, &rw);
        let env = env.clone();
        let marks = marks.clone();
        let n = n.clone();
        let t = t.clone();
        call_then(crate::check::types::unify::start_try_unify(st3.clone(), t.clone(), marked.clone(), n.span.clone()), move |try_unify_5118: (bool, crate::check::types::St)| {
            let (ok_, st4) = try_unify_5118;
            let st5 = if ok_ {
                st4.clone()
            } else {
                {
                    let stack = crate::check::types::stack_of(&st3, &t);
                    crate::check::types::recording::err_fix(&st3, &Text::lit("mark-stack"), &n.span, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name, &crate::check::types::show_ty(&st3, &t), &stack, &marks)), &Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark(&n.sigils), &stack, &crate::syntax::lexer::chars::drop_prefix(&name, &n.sigils))))
                }
            };
            prism_rtl::Turn::Finished((crate::check::expr::with_local(&env, &name, &crate::check::types::schemes::mono(&t)), crate::check::types::recording::note_binder(&st5, &n.span, &name, &t)))
        })
    }
}

/// `Start BindFreshMarked, x`: what the function value is when passed to `@Run`.
pub fn start_bind_fresh_marked(env: crate::check::expr::Env, st: crate::check::types::St, n: crate::syntax::SName, marks: Text, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindFreshMarked { env, st, n, marks, t })
}

/// ```prism
/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_field(env: &crate::check::expr::Env, st: &crate::check::types::St, p_: &crate::syntax::Pattern_, ft: &crate::check::types::Ty, snapshot_: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    match crate::check::types::recording::walk(st, ft) {
        crate::check::types::Ty::TySig(s, level) if (*snapshot_ && (&s == &Text::lit("$"))) => bind_level(env, st, p_, &*level),
        _ => bind_pattern(env, st, p_, ft, &true),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BindField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub struct BindField {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub p_: crate::syntax::Pattern_,
    pub ft: crate::check::types::Ty,
    pub snapshot_: bool,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindField {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let ft = &self.ft;
        let snapshot_ = &self.snapshot_;
        let env = env.clone();
        let ft = ft.clone();
        let p_ = p_.clone();
        let snapshot_ = *snapshot_;
        let st = st.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), ft.clone()), move |walk_6045: crate::check::types::Ty| match walk_6045 {
            crate::check::types::Ty::TySig(s, level) if (snapshot_ && (&s == &Text::lit("$"))) => prism_rtl::Turn::More(Rc::new(BindLevel { env: env.clone(), st: st.clone(), p_: p_.clone(), level: (*level).clone() })),
            _ => prism_rtl::Turn::More(Rc::new(BindPattern { env: env.clone(), st: st.clone(), p_: p_.clone(), t: ft.clone(), refutable: true })),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start BindField, x`: what the function value is when passed to `@Run`.
pub fn start_bind_field(env: crate::check::expr::Env, st: crate::check::types::St, p_: crate::syntax::Pattern_, ft: crate::check::types::Ty, snapshot_: bool) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindField { env, st, p_, ft, snapshot_ })
}

/// ```prism
/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
/// ```
pub fn bind_level(env: &crate::check::expr::Env, st: &crate::check::types::St, p_: &crate::syntax::Pattern_, level: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => if crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("$")) && (&len(&n.path_) == &Nat::from(1u32)) {
            bind_fresh_marked(env, st, n, &crate::syntax::lexer::chars::after_first(&n.sigils), level)
        } else {
            bind_pattern(env, st, p_, level, &true)
        },
        crate::syntax::PatternKind::PGroup(q) => bind_level(env, st, &**q, level),
        _ => bind_pattern(env, st, p_, level, &true),
    }
}

/// The step machine of `BindLevel`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
/// ```
pub struct BindLevel {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub p_: crate::syntax::Pattern_,
    pub level: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindLevel {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let level = &self.level;
        match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => if crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("$")) && (&len(&n.path_) == &Nat::from(1u32)) {
                prism_rtl::Turn::More(Rc::new(BindFreshMarked { env: env.clone(), st: st.clone(), n: n.clone(), marks: crate::syntax::lexer::chars::after_first(&n.sigils), t: level.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(BindPattern { env: env.clone(), st: st.clone(), p_: p_.clone(), t: level.clone(), refutable: true }))
            },
            crate::syntax::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(BindLevel { env: env.clone(), st: st.clone(), p_: (**q).clone(), level: level.clone() })),
            _ => prism_rtl::Turn::More(Rc::new(BindPattern { env: env.clone(), st: st.clone(), p_: p_.clone(), t: level.clone(), refutable: true })),
        }
    }
}

/// `Start BindLevel, x`: what the function value is when passed to `@Run`.
pub fn start_bind_level(env: crate::check::expr::Env, st: crate::check::types::St, p_: crate::syntax::Pattern_, level: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindLevel { env, st, p_, level })
}

/// ```prism
/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
/// ```
pub fn bind_ctor(env: &crate::check::expr::Env, st: &crate::check::types::St, p_: &crate::syntax::Pattern_, n: &crate::syntax::SName, args: &Array<crate::syntax::Pattern_>, t: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let (qk_opt, why) = crate::check::env::names::resolve_value(&env.g, &env.home, n);
    match &qk_opt {
        None => (env.clone(), crate::check::types::recording::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("no constructor `{}`", &crate::check::env::sname_key(n))))),
        Some(qk) => if &why == &Text::lit("tag") {
            bind_tag_pattern(env, st, p_, qk, &Array::new(), &true, t)
        } else {
            match get(&env.g.ctors, qk) {
                None => (env.clone(), crate::check::types::recording::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("`{}` is not a constructor", &crate::check::env::sname_key(n))))),
                Some(c) => {
                    let (self_, st1, inst) = crate::check::types::schemes::instantiate_with(st, &crate::check::types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c.ty.clone() }, &p_.span, &Array::new());
                    let st2 = crate::check::types::unify::unify(&st1, t, &self_, &p_.span);
                    if (&len(args) != &len(&c.args)) && !((&len(args) == &Nat::from(1u32)) && (&len(&c.args) > &Nat::from(1u32))) {
                        (env.clone(), crate::check::types::recording::err(&st2, &Text::lit("mismatch"), &p_.span, &Text::from(format!("`{}` takes {} argument{}; this pattern gives {}", &crate::check::types::bare_name(&c.name), &crate::check::errors::count_word(&len(&c.args)), &(if &len(&c.args) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(args))))))
                    } else {
                        run_to_end(fold_job(crate::check::errors::range0(&len(args)), (env.clone(), st2.clone()), {
                            let args = args.clone();
                            let p_ = p_.clone();
                            let inst = inst.clone();
                            let c = c.clone();
                            Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                                let args = args.clone();
                                let p_ = p_.clone();
                                let inst = inst.clone();
                                let c = c.clone();
                                entered(once_job(move || {
                                    let (en, s) = p0;
                                    let i = p1;
                                    call_then(crate::check::types::schemes::start_subst_q(inst.clone(), or(&index(&c.args, &i), &crate::check::types::Ty::TyErr)), move |subst_q_7767: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: or(&index(&args, &i), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_.span.clone() }), t: subst_q_7767, refutable: true })))
                                }))
                            }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                        }))
                    }
                },
            }
        },
    }
}

/// The step machine of `BindCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
/// ```
pub struct BindCtor {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub p_: crate::syntax::Pattern_,
    pub n: crate::syntax::SName,
    pub args: Array<crate::syntax::Pattern_>,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindCtor {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let n = &self.n;
        let args = &self.args;
        let t = &self.t;
        let (qk_opt, why) = crate::check::env::names::resolve_value(&env.g, &env.home, n);
        match &qk_opt {
            None => prism_rtl::Turn::Finished((env.clone(), crate::check::types::recording::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("no constructor `{}`", &crate::check::env::sname_key(n)))))),
            Some(qk) => if &why == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(BindTagPattern { env: env.clone(), st: st.clone(), p_: p_.clone(), name: qk.clone(), fields: Array::new(), rest: true, t: t.clone() }))
            } else {
                match get(&env.g.ctors, qk) {
                    None => prism_rtl::Turn::Finished((env.clone(), crate::check::types::recording::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("`{}` is not a constructor", &crate::check::env::sname_key(n)))))),
                    Some(c) => {
                        let args = args.clone();
                        let env = env.clone();
                        let p_ = p_.clone();
                        let st = st.clone();
                        let t = t.clone();
                        call_then(crate::check::types::schemes::start_instantiate_with(st.clone(), crate::check::types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c.ty.clone() }, p_.span.clone(), Array::new()), move |instantiate_with_7130: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                            let (self_, st1, inst) = instantiate_with_7130;
                            call_then(crate::check::types::unify::start_unify(st1.clone(), t.clone(), self_.clone(), p_.span.clone()), move |unify_7285: crate::check::types::St| {
                                let st2 = unify_7285;
                                if (&len(&args) != &len(&c.args)) && !((&len(&args) == &Nat::from(1u32)) && (&len(&c.args) > &Nat::from(1u32))) {
                                    prism_rtl::Turn::Finished((env.clone(), crate::check::types::recording::err(&st2, &Text::lit("mismatch"), &p_.span, &Text::from(format!("`{}` takes {} argument{}; this pattern gives {}", &crate::check::types::bare_name(&c.name), &crate::check::errors::count_word(&len(&c.args)), &(if &len(&c.args) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(&args)))))))
                                } else {
                                    fold_job(crate::check::errors::range0(&len(&args)), (env.clone(), st2.clone()), {
                                        let args = args.clone();
                                        let p_ = p_.clone();
                                        let inst = inst.clone();
                                        let c = c.clone();
                                        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                                            let args = args.clone();
                                            let p_ = p_.clone();
                                            let inst = inst.clone();
                                            let c = c.clone();
                                            entered(once_job(move || {
                                                let (en, s) = p0;
                                                let i = p1;
                                                call_then(crate::check::types::schemes::start_subst_q(inst.clone(), or(&index(&c.args, &i), &crate::check::types::Ty::TyErr)), move |subst_q_7767: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: or(&index(&args, &i), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_.span.clone() }), t: subst_q_7767, refutable: true })))
                                            }))
                                        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                                    }).cycle()
                                }
                            })
                        })
                    },
                }
            },
        }
    }
}

/// `Start BindCtor, x`: what the function value is when passed to `@Run`.
pub fn start_bind_ctor(env: crate::check::expr::Env, st: crate::check::types::St, p_: crate::syntax::Pattern_, n: crate::syntax::SName, args: Array<crate::syntax::Pattern_>, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindCtor { env, st, p_, n, args, t })
}

/// ```prism
/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub fn bind_record(env: &crate::check::expr::Env, st: &crate::check::types::St, p_: &crate::syntax::Pattern_, n: &crate::syntax::SName, fields: &Array<crate::syntax::FieldPat>, rest: &bool, t: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let (qk_opt, why) = crate::check::env::names::resolve_value(&env.g, &env.home, n);
    match &qk_opt {
        None => (env.clone(), crate::check::types::recording::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("no record or tag `{}`", &crate::check::env::sname_key(n))))),
        Some(qk) => if &why == &Text::lit("tag") {
            bind_tag_pattern(env, st, p_, qk, fields, rest, t)
        } else {
            match get(&env.g.ctors, qk) {
                None => (env.clone(), crate::check::types::recording::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("`{}` is not a record", &crate::check::env::sname_key(n))))),
                Some(c) => {
                    let (self_, st1, inst) = crate::check::types::schemes::instantiate_with(st, &crate::check::types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c.ty.clone() }, &p_.span, &Array::new());
                    let st2 = crate::check::types::unify::unify(&st1, t, &self_, &p_.span);
                    run_to_end(fold_job(crate::check::errors::range0(&len(fields)), (env.clone(), st2.clone()), {
                        let fields = fields.clone();
                        let p_ = p_.clone();
                        let c = c.clone();
                        let inst = inst.clone();
                        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                            let fields = fields.clone();
                            let p_ = p_.clone();
                            let c = c.clone();
                            let inst = inst.clone();
                            entered(once_job(move || {
                                let (en, s) = p0;
                                let i = p1;
                                {
                                    let fp = or(&index(&fields, &i), &crate::syntax::FieldPat { name: None, pattern: crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_.span.clone() }, span: p_.span.clone() });
                                    let fname = field_pat_name(&fp, &c.fields, &i);
                                    match crate::check::expr::operators::index_of(&c.fields, &fname) {
                                        Some(j) => call_then(crate::check::types::schemes::start_subst_q(inst.clone(), or(&index(&c.args, &j), &crate::check::types::Ty::TyErr)), move |subst_q_9120: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: fp.pattern.clone(), t: subst_q_9120, refutable: true }))),
                                        None => prism_rtl::Turn::Finished((en.clone(), crate::check::types::recording::err(&s, &Text::lit("mismatch"), &fp.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&c.owner), &fname))))),
                                    }
                                }
                            }))
                        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                    }))
                },
            }
        },
    }
}

/// The step machine of `BindRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub struct BindRecord {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub p_: crate::syntax::Pattern_,
    pub n: crate::syntax::SName,
    pub fields: Array<crate::syntax::FieldPat>,
    pub rest: bool,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindRecord {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let n = &self.n;
        let fields = &self.fields;
        let rest = &self.rest;
        let t = &self.t;
        let (qk_opt, why) = crate::check::env::names::resolve_value(&env.g, &env.home, n);
        match &qk_opt {
            None => prism_rtl::Turn::Finished((env.clone(), crate::check::types::recording::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("no record or tag `{}`", &crate::check::env::sname_key(n)))))),
            Some(qk) => if &why == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(BindTagPattern { env: env.clone(), st: st.clone(), p_: p_.clone(), name: qk.clone(), fields: fields.clone(), rest: *rest, t: t.clone() }))
            } else {
                match get(&env.g.ctors, qk) {
                    None => prism_rtl::Turn::Finished((env.clone(), crate::check::types::recording::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("`{}` is not a record", &crate::check::env::sname_key(n)))))),
                    Some(c) => {
                        let env = env.clone();
                        let fields = fields.clone();
                        let p_ = p_.clone();
                        let st = st.clone();
                        let t = t.clone();
                        call_then(crate::check::types::schemes::start_instantiate_with(st.clone(), crate::check::types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c.ty.clone() }, p_.span.clone(), Array::new()), move |instantiate_with_8551: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                            let (self_, st1, inst) = instantiate_with_8551;
                            call_then(crate::check::types::unify::start_unify(st1.clone(), t.clone(), self_.clone(), p_.span.clone()), move |unify_8706: crate::check::types::St| {
                                let st2 = unify_8706;
                                fold_job(crate::check::errors::range0(&len(&fields)), (env.clone(), st2.clone()), {
                                    let fields = fields.clone();
                                    let p_ = p_.clone();
                                    let c = c.clone();
                                    let inst = inst.clone();
                                    Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                                        let fields = fields.clone();
                                        let p_ = p_.clone();
                                        let c = c.clone();
                                        let inst = inst.clone();
                                        entered(once_job(move || {
                                            let (en, s) = p0;
                                            let i = p1;
                                            {
                                                let fp = or(&index(&fields, &i), &crate::syntax::FieldPat { name: None, pattern: crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_.span.clone() }, span: p_.span.clone() });
                                                let fname = field_pat_name(&fp, &c.fields, &i);
                                                match crate::check::expr::operators::index_of(&c.fields, &fname) {
                                                    Some(j) => call_then(crate::check::types::schemes::start_subst_q(inst.clone(), or(&index(&c.args, &j), &crate::check::types::Ty::TyErr)), move |subst_q_9120: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: fp.pattern.clone(), t: subst_q_9120, refutable: true }))),
                                                    None => prism_rtl::Turn::Finished((en.clone(), crate::check::types::recording::err(&s, &Text::lit("mismatch"), &fp.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&c.owner), &fname))))),
                                                }
                                            }
                                        }))
                                    }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                                }).cycle()
                            })
                        })
                    },
                }
            },
        }
    }
}

/// `Start BindRecord, x`: what the function value is when passed to `@Run`.
pub fn start_bind_record(env: crate::check::expr::Env, st: crate::check::types::St, p_: crate::syntax::Pattern_, n: crate::syntax::SName, fields: Array<crate::syntax::FieldPat>, rest: bool, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindRecord { env, st, p_, n, fields, rest, t })
}

/// ```prism
/// FieldPatName: fn FieldPat, [Text], Nat -> Text
/// ```
pub fn field_pat_name(fp: &crate::syntax::FieldPat, fields: &Array<Text>, i: &Nat) -> Text {
    match &fp.name {
        Some(id) => id.name.clone(),
        None => match &*fp.pattern.kind {
            crate::syntax::PatternKind::PName(n) => if crate::check::types::has_text(fields, &crate::check::env::sname_key(n)) {
                crate::check::env::sname_key(n)
            } else {
                or(&index(fields, i), &Text::lit(""))
            },
            _ => or(&index(fields, i), &Text::lit("")),
        },
    }
}

/// ```prism
/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub fn bind_tag_pattern(env: &crate::check::expr::Env, st: &crate::check::types::St, p_: &crate::syntax::Pattern_, name: &Text, fields: &Array<crate::syntax::FieldPat>, rest: &bool, t: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    match get(&env.g.tags, name) {
        None => (env.clone(), crate::check::types::recording::err(st, &Text::lit("unknown-name"), &p_.span, &Text::from(format!("no tag `{}`", name)))),
        Some(tg) => {
            let st1 = if &tg.kind == &Text::lit("Element") {
                tag_in_row(env, st, &tg, t, &p_.span)
            } else {
                crate::check::types::unify::unify(st, t, &crate::check::types::Ty::TyCon(tg.kind.clone(), Array::new()), &p_.span)
            };
            let snapshot_ = is_snapshot(&st1, t);
            let (_, st2, inst) = crate::check::types::schemes::instantiate_with(&st1, &crate::check::types::Scheme { qs: tg.qs.clone(), plain_qs: Array::new(), rqs: tg.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: tg.out.clone() }, &p_.span, &Array::new());
            let names = each(&tg.fields, &(|(f, _): &(Text, crate::check::types::Ty)| f.clone()));
            run_to_end(fold_job(crate::check::errors::range0(&len(fields)), (env.clone(), st2.clone()), {
                let fields = fields.clone();
                let p_ = p_.clone();
                let names = names.clone();
                let tg = tg.clone();
                let inst = inst.clone();
                let snapshot_ = snapshot_;
                let name = name.clone();
                Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                    let fields = fields.clone();
                    let p_ = p_.clone();
                    let names = names.clone();
                    let tg = tg.clone();
                    let inst = inst.clone();
                    let snapshot_ = snapshot_;
                    let name = name.clone();
                    entered(once_job(move || {
                        let (en, s) = p0;
                        let i = p1;
                        {
                            let fp = or(&index(&fields, &i), &crate::syntax::FieldPat { name: None, pattern: crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_.span.clone() }, span: p_.span.clone() });
                            let fname = field_pat_name(&fp, &names, &i);
                            match crate::check::expr::calls::field_of_tag(&tg, &fname) {
                                Some(ft) => call_then(crate::check::types::schemes::start_subst_q(inst.clone(), ft.clone()), move |subst_q_10806: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindField { env: en.clone(), st: s.clone(), p_: fp.pattern.clone(), ft: subst_q_10806, snapshot_ }))),
                                None => prism_rtl::Turn::Finished((en.clone(), crate::check::types::recording::err(&s, &Text::lit("mismatch"), &fp.span, &Text::from(format!("`{}` has no field `{}`", &name, &fname))))),
                            }
                        }
                    }))
                }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }))
        },
    }
}

/// The step machine of `BindTagPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub struct BindTagPattern {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub p_: crate::syntax::Pattern_,
    pub name: Text,
    pub fields: Array<crate::syntax::FieldPat>,
    pub rest: bool,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindTagPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let name = &self.name;
        let fields = &self.fields;
        let rest = &self.rest;
        let t = &self.t;
        match get(&env.g.tags, name) {
            None => prism_rtl::Turn::Finished((env.clone(), crate::check::types::recording::err(st, &Text::lit("unknown-name"), &p_.span, &Text::from(format!("no tag `{}`", name))))),
            Some(tg) => {
                let st1 = if &tg.kind == &Text::lit("Element") {
                    tag_in_row(env, st, &tg, t, &p_.span)
                } else {
                    crate::check::types::unify::unify(st, t, &crate::check::types::Ty::TyCon(tg.kind.clone(), Array::new()), &p_.span)
                };
                let env = env.clone();
                let fields = fields.clone();
                let name = name.clone();
                let p_ = p_.clone();
                let t = t.clone();
                call_then(start_is_snapshot(st1.clone(), t.clone()), move |is_snapshot_10250: bool| {
                    let snapshot_ = is_snapshot_10250;
                    call_then(crate::check::types::schemes::start_instantiate_with(st1.clone(), crate::check::types::Scheme { qs: tg.qs.clone(), plain_qs: Array::new(), rqs: tg.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: tg.out.clone() }, p_.span.clone(), Array::new()), move |instantiate_with_10304: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                        let (_, st2, inst) = instantiate_with_10304;
                        let names = each(&tg.fields, &(|(f, _): &(Text, crate::check::types::Ty)| f.clone()));
                        fold_job(crate::check::errors::range0(&len(&fields)), (env.clone(), st2.clone()), {
                            let fields = fields.clone();
                            let p_ = p_.clone();
                            let names = names.clone();
                            let tg = tg.clone();
                            let inst = inst.clone();
                            let snapshot_ = snapshot_;
                            let name = name.clone();
                            Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                                let fields = fields.clone();
                                let p_ = p_.clone();
                                let names = names.clone();
                                let tg = tg.clone();
                                let inst = inst.clone();
                                let snapshot_ = snapshot_;
                                let name = name.clone();
                                entered(once_job(move || {
                                    let (en, s) = p0;
                                    let i = p1;
                                    {
                                        let fp = or(&index(&fields, &i), &crate::syntax::FieldPat { name: None, pattern: crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_.span.clone() }, span: p_.span.clone() });
                                        let fname = field_pat_name(&fp, &names, &i);
                                        match crate::check::expr::calls::field_of_tag(&tg, &fname) {
                                            Some(ft) => call_then(crate::check::types::schemes::start_subst_q(inst.clone(), ft.clone()), move |subst_q_10806: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindField { env: en.clone(), st: s.clone(), p_: fp.pattern.clone(), ft: subst_q_10806, snapshot_ }))),
                                            None => prism_rtl::Turn::Finished((en.clone(), crate::check::types::recording::err(&s, &Text::lit("mismatch"), &fp.span, &Text::from(format!("`{}` has no field `{}`", &name, &fname))))),
                                        }
                                    }
                                }))
                            }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                        }).cycle()
                    })
                })
            },
        }
    }
}

/// `Start BindTagPattern, x`: what the function value is when passed to `@Run`.
pub fn start_bind_tag_pattern(env: crate::check::expr::Env, st: crate::check::types::St, p_: crate::syntax::Pattern_, name: Text, fields: Array<crate::syntax::FieldPat>, rest: bool, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindTagPattern { env, st, p_, name, fields, rest, t })
}

/// ```prism
/// IsSnapshot: unbounded fn St, Ty -> Bool
/// ```
pub fn is_snapshot(st: &crate::check::types::St, t: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyElemAny(_) => true,
        _ => false,
    }
}

/// The step machine of `IsSnapshot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsSnapshot: unbounded fn St, Ty -> Bool
/// ```
pub struct IsSnapshot {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for IsSnapshot {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_11143: crate::check::types::Ty| match walk_11143 {
            crate::check::types::Ty::TyElemAny(_) => prism_rtl::Turn::Finished(true),
            _ => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start IsSnapshot, x`: what the function value is when passed to `@Run`.
pub fn start_is_snapshot(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsSnapshot { st, t })
}

/// ```prism
/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
/// ```
pub fn tag_in_row(env: &crate::check::expr::Env, st: &crate::check::types::St, tg: &crate::check::env::TagInfo, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyElem(rw, _) => {
            let w = crate::check::types::recording::walk_row(st, &rw);
            if crate::check::types::has_text(&w.fams, &tg.family) {
                st.clone()
            } else {
                crate::check::types::recording::err_fix(st, &Text::lit("row-not-here"), span, &Text::from(format!("`{}` is not in this row, `{}`", &tg.name, &crate::check::types::show_row(&w))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg.family)))
            }
        },
        crate::check::types::Ty::TyElemAny(rw) => {
            let w = crate::check::types::recording::walk_row(st, &rw);
            if crate::check::types::has_text(&w.fams, &tg.family) {
                st.clone()
            } else {
                crate::check::types::recording::err_fix(st, &Text::lit("row-not-here"), span, &Text::from(format!("`{}` is not in this row, `{}`", &tg.name, &crate::check::types::show_row(&w))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg.family)))
            }
        },
        crate::check::types::Ty::TyFlex(_) => {
            let (rw, st2) = crate::check::types::recording::fresh_row(st, &Array::from(vec![tg.family.clone()]));
            let (o, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
            crate::check::types::unify::unify(&st3, t, &crate::check::types::Ty::TyElem(crate::check::types::Rw { fams: Array::from(vec![tg.family.clone()]), minus: Array::new(), tail: rw.tail.clone() }, Rc::new(o.clone())), span)
        },
        crate::check::types::Ty::TyErr => st.clone(),
        other => crate::check::types::recording::err(st, &Text::lit("mismatch"), span, &Text::from(format!("a tag pattern matches an element; this is `{}`", &crate::check::types::show_ty(st, &other)))),
    }
}

/// The step machine of `TagInRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
/// ```
pub struct TagInRow {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub tg: crate::check::env::TagInfo,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for TagInRow {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let tg = &self.tg;
        let t = &self.t;
        let span = &self.span;
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        let tg = tg.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_11302: crate::check::types::Ty| match walk_11302 {
            crate::check::types::Ty::TyElem(rw, _) => call_then(crate::check::types::recording::start_walk_row(st.clone(), rw.clone()), move |walk_row_11353: crate::check::types::Rw| {
                let w = walk_row_11353;
                if crate::check::types::has_text(&w.fams, &tg.family) {
                    prism_rtl::Turn::Finished(st.clone())
                } else {
                    prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st, &Text::lit("row-not-here"), &span, &Text::from(format!("`{}` is not in this row, `{}`", &tg.name, &crate::check::types::show_row(&w))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg.family))))
                }
            }),
            crate::check::types::Ty::TyElemAny(rw) => call_then(crate::check::types::recording::start_walk_row(st.clone(), rw.clone()), move |walk_row_11601: crate::check::types::Rw| {
                let w = walk_row_11601;
                if crate::check::types::has_text(&w.fams, &tg.family) {
                    prism_rtl::Turn::Finished(st.clone())
                } else {
                    prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st, &Text::lit("row-not-here"), &span, &Text::from(format!("`{}` is not in this row, `{}`", &tg.name, &crate::check::types::show_row(&w))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg.family))))
                }
            }),
            crate::check::types::Ty::TyFlex(_) => {
                let (rw, st2) = crate::check::types::recording::fresh_row(&st, &Array::from(vec![tg.family.clone()]));
                let (o, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
                prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st3.clone(), expected: t.clone(), found: crate::check::types::Ty::TyElem(crate::check::types::Rw { fams: Array::from(vec![tg.family.clone()]), minus: Array::new(), tail: rw.tail.clone() }, Rc::new(o.clone())), span: span.clone() }))
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished(st.clone()),
            other => call_then(crate::check::types::start_show_ty(st.clone(), other.clone()), move |show_ty_12123: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("a tag pattern matches an element; this is `{}`", &show_ty_12123))))),
        })
    }
}

/// `Start TagInRow, x`: what the function value is when passed to `@Run`.
pub fn start_tag_in_row(env: crate::check::expr::Env, st: crate::check::types::St, tg: crate::check::env::TagInfo, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(TagInRow { env, st, tg, t, span })
}

/// ```prism
/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
/// ```
pub fn bind_family(env: &crate::check::expr::Env, st: &crate::check::types::St, fam: &Text, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> (crate::check::expr::Env, crate::check::types::St) {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyElem(rw, _) => {
            let w = crate::check::types::recording::walk_row(st, &rw);
            if crate::check::types::has_text(&w.fams, fam) {
                (env.clone(), st.clone())
            } else {
                (env.clone(), crate::check::types::recording::err_fix(st, &Text::lit("row-not-here"), span, &Text::from(format!("`{}.*` is not in this row, `{}`", fam, &crate::check::types::show_row(&w))), &Text::from(format!("add `{}.*` to the row", fam))))
            }
        },
        _ => (env.clone(), st.clone()),
    }
}

/// The step machine of `BindFamily`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
/// ```
pub struct BindFamily {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub fam: Text,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindFamily {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let fam = &self.fam;
        let t = &self.t;
        let span = &self.span;
        let env = env.clone();
        let fam = fam.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_12253: crate::check::types::Ty| match walk_12253 {
            crate::check::types::Ty::TyElem(rw, _) => call_then(crate::check::types::recording::start_walk_row(st.clone(), rw.clone()), move |walk_row_12304: crate::check::types::Rw| {
                let w = walk_row_12304;
                if crate::check::types::has_text(&w.fams, &fam) {
                    prism_rtl::Turn::Finished((env.clone(), st.clone()))
                } else {
                    prism_rtl::Turn::Finished((env.clone(), crate::check::types::recording::err_fix(&st, &Text::lit("row-not-here"), &span, &Text::from(format!("`{}.*` is not in this row, `{}`", &fam, &crate::check::types::show_row(&w))), &Text::from(format!("add `{}.*` to the row", &fam)))))
                }
            }),
            _ => prism_rtl::Turn::Finished((env.clone(), st.clone())),
        })
    }
}

/// `Start BindFamily, x`: what the function value is when passed to `@Run`.
pub fn start_bind_family(env: crate::check::expr::Env, st: crate::check::types::St, fam: Text, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindFamily { env, st, fam, t, span })
}
