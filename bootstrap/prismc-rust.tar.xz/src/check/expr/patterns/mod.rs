//! The module `Check.Expr.Patterns`, from `target/bootstrap/src/prismc/check/expr/patterns.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_pattern_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern, t_p3: &crate::check::types::Ty, refutable_p4: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    match &*p_p2.kind_p {
        crate::syntax::PatternKind::PName(n_p5) => {
            let bare_p6 = crate::prelude::or(&crate::prelude::index(&n_p5.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""));
            let is_ctor_p7 = (crate::check::env::is_upper_text_f(&bare_p6) && (&crate::prelude::len_text(&n_p5.sigils_p) == &crate::prelude::Nat::from(0u32))) && is_ctor_name_f(env_p0, n_p5);
            if is_ctor_p7 || (&crate::prelude::len(&n_p5.path_p) > &crate::prelude::Nat::from(1u32)) {
                bind_ctor_f(env_p0, st_p1, p_p2, n_p5, &crate::prelude::Array::new(), t_p3)
            } else {
                bind_name_f(env_p0, st_p1, n_p5, t_p3)
            }
        },
        crate::syntax::PatternKind::PIgnore => (env_p0.clone(), st_p1.clone()),
        crate::syntax::PatternKind::PLit(l_p8) => {
            let (lt_p9, st2_pa) = crate::check::expr::infer_lit_f(env_p0, st_p1, l_p8, &false, &p_p2.span_p);
            (env_p0.clone(), crate::check::types::unify::unify_f(&st2_pa, t_p3, &lt_p9, &p_p2.span_p))
        },
        crate::syntax::PatternKind::PNeg(l_pb) => {
            let (lt_pc, st2_pd) = crate::check::expr::infer_lit_f(env_p0, st_p1, l_pb, &true, &p_p2.span_p);
            (env_p0.clone(), crate::check::types::unify::unify_f(&st2_pd, t_p3, &lt_pc, &p_p2.span_p))
        },
        crate::syntax::PatternKind::PUnit => (env_p0.clone(), crate::check::types::unify::unify_f(st_p1, t_p3, &crate::check::types::t_unit_p(), &p_p2.span_p)),
        crate::syntax::PatternKind::PNil => {
            let (v_pe, st2_pf) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
            (env_p0.clone(), crate::check::types::unify::unify_f(&st2_pf, t_p3, &crate::check::types::Ty::TySig(crate::prelude::Text::lit("?"), ::std::rc::Rc::new(v_pe.clone())), &p_p2.span_p))
        },
        crate::syntax::PatternKind::PCtor(n_pg, args_ph) => bind_ctor_f(env_p0, st_p1, p_p2, n_pg, args_ph, t_p3),
        crate::syntax::PatternKind::PRecord(n_pi, fields_pj, rest_pk) => bind_record_f(env_p0, st_p1, p_p2, n_pi, fields_pj, rest_pk, t_p3),
        crate::syntax::PatternKind::PSigil(s_pl, inner_pm) => if (s_pl == &crate::prelude::Text::lit("?")) || (s_pl == &crate::prelude::Text::lit("~")) {
            {
                let (v_po, st2_pp) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                let st3_pn = crate::check::types::unify::unify_f(&st2_pp, t_p3, &crate::check::types::Ty::TySig(s_pl.clone(), ::std::rc::Rc::new(v_po.clone())), &p_p2.span_p);
                bind_pattern_f(env_p0, &st3_pn, &**inner_pm, &v_po, refutable_p4)
            }
        } else {
            {
                let (v_pr, st2_ps) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                let st3_pq = crate::check::types::unify::unify_f(&st2_ps, t_p3, &crate::check::types::with_marks_f(s_pl, &v_pr, &env_p0.scope_p), &p_p2.span_p);
                bind_pattern_f(env_p0, &st3_pq, &**inner_pm, &v_pr, refutable_p4)
            }
        },
        crate::syntax::PatternKind::PTuple(ps_pt) => {
            let (vs_p13, st2_p14) = crate::prelude::fold(ps_pt, &(crate::prelude::Array::new(), st_p1.clone()), &(|(acc_pv, s_p10): &(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Pattern| {
                let (v_p11, s2_p12) = crate::check::types::fresh_var_f(s_p10, &false, &crate::prelude::Text::lit(""));
                (crate::prelude::push(acc_pv, &v_p11), s2_p12.clone())
            }));
            let st3_pu = crate::check::types::unify::unify_f(&st2_p14, t_p3, &crate::check::types::Ty::TyTuple(vs_p13.clone()), &p_p2.span_p);
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_pt)), (env_p0.clone(), st3_pu.clone()), {
                let ps_ptx = ps_pt.clone();
                let p_p2x = p_p2.clone();
                let vs_p13x = vs_p13.clone();
                let refutable_p4x = *refutable_p4;
                ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)| {
                    let ps_ptxy = ps_ptx.clone();
                    let p_p2xy = p_p2x.clone();
                    let vs_p13xy = vs_p13x.clone();
                    let refutable_p4xy = refutable_p4x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (en_p15, s_p16) = p0;
                        let i_p17 = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: en_p15.clone(), st_p1: s_p16.clone(), p_p2: crate::prelude::or(&crate::prelude::index(&ps_ptxy, &i_p17), &crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xy.span_p.clone() }), t_p3: crate::prelude::or(&crate::prelude::index(&vs_p13xy, &i_p17), &crate::check::types::Ty::TyErr), refutable_p4: refutable_p4xy }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }))
        },
        crate::syntax::PatternKind::PArray(ps_p18) => {
            let (v_p1a, st2_p1b) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
            let st3_p19 = match crate::check::types::non_empty_coll_o(&st2_p1b, t_p3) {
                ::std::option::Option::Some(c_p1c) => {
                    let s_p1d = crate::check::types::unify::unify_f(&st2_p1b, &c_p1c, &crate::check::types::Ty::TyArray(::std::rc::Rc::new(v_p1a.clone())), &p_p2.span_p);
                    if &crate::prelude::len(ps_p18) == &crate::prelude::Nat::from(0u32) {
                        crate::check::types::recording::err_fix_f(&s_p1d, &crate::prelude::Text::lit("unreachable"), &p_p2.span_p, &crate::prelude::Text::lit("a non-empty array has no length zero"), &crate::prelude::Text::lit("remove the arm"))
                    } else {
                        s_p1d.clone()
                    }
                },
                ::std::option::Option::None => crate::check::types::unify::unify_f(&st2_p1b, t_p3, &crate::check::types::Ty::TyArray(::std::rc::Rc::new(v_p1a.clone())), &p_p2.span_p),
            };
            crate::prelude::run_to_end(crate::prelude::fold_job(ps_p18.clone(), (env_p0.clone(), st3_p19.clone()), {
                let v_p1ax = v_p1a.clone();
                let refutable_p4x = *refutable_p4;
                ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern)| {
                    let v_p1axy = v_p1ax.clone();
                    let refutable_p4xy = refutable_p4x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (en_p1e, s_p1f) = p0;
                        let q_p1g = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: en_p1e.clone(), st_p1: s_p1f.clone(), p_p2: q_p1g.clone(), t_p3: v_p1axy.clone(), refutable_p4: refutable_p4xy }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }))
        },
        crate::syntax::PatternKind::PGroup(q_p1h) => bind_pattern_f(env_p0, st_p1, &**q_p1h, t_p3, refutable_p4),
        crate::syntax::PatternKind::PFamily(q_p1i) => bind_family_f(env_p0, st_p1, &crate::check::env::dotted_f(&q_p1i.path_p), t_p3, &p_p2.span_p),
    }
}

/// The step machine of `BindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub struct BindPattern {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern,
    pub t_p3: crate::check::types::Ty,
    pub refutable_p4: bool,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindPattern {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let t_p3 = &self.t_p3;
        let refutable_p4 = &self.refutable_p4;
        match &*p_p2.kind_p {
            crate::syntax::PatternKind::PName(n_p5) => {
                let bare_p6 = crate::prelude::or(&crate::prelude::index(&n_p5.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""));
                let is_ctor_p7 = (crate::check::env::is_upper_text_f(&bare_p6) && (&crate::prelude::len_text(&n_p5.sigils_p) == &crate::prelude::Nat::from(0u32))) && is_ctor_name_f(env_p0, n_p5);
                if is_ctor_p7 || (&crate::prelude::len(&n_p5.path_p) > &crate::prelude::Nat::from(1u32)) {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(BindCtor { env_p0: env_p0.clone(), st0_p1: st_p1.clone(), p_p2: p_p2.clone(), n_p3: n_p5.clone(), args_p4: crate::prelude::Array::new(), t_p5: t_p3.clone() }))
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(BindName { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p5.clone(), t_p3: t_p3.clone() }))
                }
            },
            crate::syntax::PatternKind::PIgnore => ::prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
            crate::syntax::PatternKind::PLit(l_p8) => {
                let env_p0x = env_p0.clone();
                let l_p8x = l_p8.clone();
                let p_p2x = p_p2.clone();
                let st_p1x = st_p1.clone();
                let t_p3x = t_p3.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_lit_f(env_p0x.clone(), st_p1x.clone(), l_p8x.clone(), false, p_p2x.span_p.clone()), move |infer_lit_f_1841: (crate::check::types::Ty, crate::check::types::St)| {
                    let (lt_p9, st2_pa) = infer_lit_f_1841;
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pa.clone(), t_p3x.clone(), lt_p9.clone(), p_p2x.span_p.clone()), move |unify_f_1892: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), unify_f_1892)))
                })
            },
            crate::syntax::PatternKind::PNeg(l_pb) => {
                let env_p0x = env_p0.clone();
                let l_pbx = l_pb.clone();
                let p_p2x = p_p2.clone();
                let st_p1x = st_p1.clone();
                let t_p3x = t_p3.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_lit_f(env_p0x.clone(), st_p1x.clone(), l_pbx.clone(), true, p_p2x.span_p.clone()), move |infer_lit_f_1958: (crate::check::types::Ty, crate::check::types::St)| {
                    let (lt_pc, st2_pd) = infer_lit_f_1958;
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pd.clone(), t_p3x.clone(), lt_pc.clone(), p_p2x.span_p.clone()), move |unify_f_2008: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), unify_f_2008)))
                })
            },
            crate::syntax::PatternKind::PUnit => {
                let env_p0x = env_p0.clone();
                let p_p2x = p_p2.clone();
                let st_p1x = st_p1.clone();
                let t_p3x = t_p3.clone();
                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), t_p3x.clone(), crate::check::types::t_unit_p(), p_p2x.span_p.clone()), move |unify_f_2055: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), unify_f_2055)))
            },
            crate::syntax::PatternKind::PNil => {
                let (v_pe, st2_pf) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                let env_p0x = env_p0.clone();
                let p_p2x = p_p2.clone();
                let t_p3x = t_p3.clone();
                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pf.clone(), t_p3x.clone(), crate::check::types::Ty::TySig(crate::prelude::Text::lit("?"), ::std::rc::Rc::new(v_pe.clone())), p_p2x.span_p.clone()), move |unify_f_2159: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), unify_f_2159)))
            },
            crate::syntax::PatternKind::PCtor(n_pg, args_ph) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindCtor { env_p0: env_p0.clone(), st0_p1: st_p1.clone(), p_p2: p_p2.clone(), n_p3: n_pg.clone(), args_p4: args_ph.clone(), t_p5: t_p3.clone() })),
            crate::syntax::PatternKind::PRecord(n_pi, fields_pj, rest_pk) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindRecord { env_p0: env_p0.clone(), st0_p1: st_p1.clone(), p_p2: p_p2.clone(), n_p3: n_pi.clone(), fields_p4: fields_pj.clone(), rest_p5: *rest_pk, t_p6: t_p3.clone() })),
            crate::syntax::PatternKind::PSigil(s_pl, inner_pm) => if (s_pl == &crate::prelude::Text::lit("?")) || (s_pl == &crate::prelude::Text::lit("~")) {
                {
                    let (v_po, st2_pp) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                    let env_p0x = env_p0.clone();
                    let inner_pmx = (**inner_pm).clone();
                    let p_p2x = p_p2.clone();
                    let refutable_p4x = *refutable_p4;
                    let s_plx = s_pl.clone();
                    let t_p3x = t_p3.clone();
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pp.clone(), t_p3x.clone(), crate::check::types::Ty::TySig(s_plx.clone(), ::std::rc::Rc::new(v_po.clone())), p_p2x.span_p.clone()), move |unify_f_2449: crate::check::types::St| {
                        let st3_pn = unify_f_2449;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: env_p0x.clone(), st_p1: st3_pn.clone(), p_p2: inner_pmx.clone(), t_p3: v_po.clone(), refutable_p4: refutable_p4x }))
                    })
                }
            } else {
                {
                    let (v_pr, st2_ps) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                    let env_p0x = env_p0.clone();
                    let inner_pmx = (**inner_pm).clone();
                    let p_p2x = p_p2.clone();
                    let refutable_p4x = *refutable_p4;
                    let s_plx = s_pl.clone();
                    let t_p3x = t_p3.clone();
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_ps.clone(), t_p3x.clone(), crate::check::types::with_marks_f(&s_plx, &v_pr, &env_p0x.scope_p), p_p2x.span_p.clone()), move |unify_f_2626: crate::check::types::St| {
                        let st3_pq = unify_f_2626;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: env_p0x.clone(), st_p1: st3_pq.clone(), p_p2: inner_pmx.clone(), t_p3: v_pr.clone(), refutable_p4: refutable_p4x }))
                    })
                }
            },
            crate::syntax::PatternKind::PTuple(ps_pt) => {
                let (vs_p13, st2_p14) = crate::prelude::fold(ps_pt, &(crate::prelude::Array::new(), st_p1.clone()), &(|(acc_pv, s_p10): &(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Pattern| {
                    let (v_p11, s2_p12) = crate::check::types::fresh_var_f(s_p10, &false, &crate::prelude::Text::lit(""));
                    (crate::prelude::push(acc_pv, &v_p11), s2_p12.clone())
                }));
                let env_p0x = env_p0.clone();
                let p_p2x = p_p2.clone();
                let ps_ptx = ps_pt.clone();
                let refutable_p4x = *refutable_p4;
                let t_p3x = t_p3.clone();
                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p14.clone(), t_p3x.clone(), crate::check::types::Ty::TyTuple(vs_p13.clone()), p_p2x.span_p.clone()), move |unify_f_2918: crate::check::types::St| {
                    let st3_pu = unify_f_2918;
                    crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_ptx)), (env_p0x.clone(), st3_pu.clone()), {
                        let ps_ptxx = ps_ptx.clone();
                        let p_p2xx = p_p2x.clone();
                        let vs_p13x = vs_p13.clone();
                        let refutable_p4xx = refutable_p4x;
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)| {
                            let ps_ptxxy = ps_ptxx.clone();
                            let p_p2xxy = p_p2xx.clone();
                            let vs_p13xy = vs_p13x.clone();
                            let refutable_p4xxy = refutable_p4xx;
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (en_p15, s_p16) = p0;
                                let i_p17 = p1;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: en_p15.clone(), st_p1: s_p16.clone(), p_p2: crate::prelude::or(&crate::prelude::index(&ps_ptxxy, &i_p17), &crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xxy.span_p.clone() }), t_p3: crate::prelude::or(&crate::prelude::index(&vs_p13xy, &i_p17), &crate::check::types::Ty::TyErr), refutable_p4: refutable_p4xxy }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                    }).cycle()
                })
            },
            crate::syntax::PatternKind::PArray(ps_p18) => {
                let (v_p1a, st2_p1b) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                let env_p0x = env_p0.clone();
                let p_p2x = p_p2.clone();
                let ps_p18x = ps_p18.clone();
                let refutable_p4x = *refutable_p4;
                let t_p3x = t_p3.clone();
                crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(st2_p1b.clone(), t_p3x.clone()), move |non_empty_coll_o_3339: ::std::option::Option<crate::check::types::Ty>| {
                    let env_p0xz = env_p0x.clone();
                    let ps_p18xz = ps_p18x.clone();
                    let refutable_p4xz = refutable_p4x;
                    let v_p1az = v_p1a.clone();
                    let k_let3323 = move |v3323: crate::check::types::St| {
                        let st3_p19 = v3323;
                        crate::prelude::fold_job(ps_p18xz.clone(), (env_p0xz.clone(), st3_p19.clone()), {
                            let v_p1azx = v_p1az.clone();
                            let refutable_p4xzx = refutable_p4xz;
                            ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern)| {
                                let v_p1azxy = v_p1azx.clone();
                                let refutable_p4xzxy = refutable_p4xzx;
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (en_p1e, s_p1f) = p0;
                                    let q_p1g = p1;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: en_p1e.clone(), st_p1: s_p1f.clone(), p_p2: q_p1g.clone(), t_p3: v_p1azxy.clone(), refutable_p4: refutable_p4xzxy }))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                        }).cycle()
                    };
                    match non_empty_coll_o_3339 {
                        ::std::option::Option::Some(c_p1c) => crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p1b.clone(), c_p1c.clone(), crate::check::types::Ty::TyArray(::std::rc::Rc::new(v_p1a.clone())), p_p2x.span_p.clone()), move |unify_f_3402: crate::check::types::St| {
                            let s_p1d = unify_f_3402;
                            k_let3323(if &crate::prelude::len(&ps_p18x) == &crate::prelude::Nat::from(0u32) {
                                crate::check::types::recording::err_fix_f(&s_p1d, &crate::prelude::Text::lit("unreachable"), &p_p2x.span_p, &crate::prelude::Text::lit("a non-empty array has no length zero"), &crate::prelude::Text::lit("remove the arm"))
                            } else {
                                s_p1d.clone()
                            })
                        }),
                        ::std::option::Option::None => crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p1b.clone(), t_p3x.clone(), crate::check::types::Ty::TyArray(::std::rc::Rc::new(v_p1a.clone())), p_p2x.span_p.clone()), move |unify_f_3585: crate::check::types::St| k_let3323(unify_f_3585)),
                    }
                })
            },
            crate::syntax::PatternKind::PGroup(q_p1h) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: (**q_p1h).clone(), t_p3: t_p3.clone(), refutable_p4: *refutable_p4 })),
            crate::syntax::PatternKind::PFamily(q_p1i) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindFamily { env_p0: env_p0.clone(), st_p1: st_p1.clone(), fam_p2: crate::check::env::dotted_f(&q_p1i.path_p), t_p3: t_p3.clone(), span_p4: p_p2.span_p.clone() })),
        }
    }
}

/// `Start BindPattern, x`: what the function value is when passed to `@Run`.
pub fn start_bind_pattern_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern, t_p3: crate::check::types::Ty, refutable_p4: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(BindPattern { env_p0, st_p1, p_p2, t_p3, refutable_p4 })
}

/// ```prism
/// BoundTwice: unbounded fn Env, St, [Pattern] -> St
/// ```
pub fn bound_twice_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, patterns_p2: &crate::prelude::Array<crate::syntax::Pattern>) -> crate::check::types::St {
    let binders_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(patterns_p2.clone(), crate::prelude::Array::new(), {
        let env_p0x = env_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| {
            let env_p0xy = env_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p4 = p0;
                let p_p5 = p1;
                crate::prelude::call_then(start_binders_of_f(env_p0xy.clone(), p_p5.clone()), move |binders_of_f_4092: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &binders_of_f_4092)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
    }));
    let (_, checked_pa) = crate::prelude::fold(&binders_p3, &(crate::prelude::Array::new(), st_p1.clone()), &(|(seen_p6, s_p7): &(crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), (name_p8, at_p9): &(crate::prelude::Text, crate::syntax::Range)| if crate::check::types::has_text_f(seen_p6, name_p8) {
        (seen_p6.clone(), crate::check::types::recording::err_f(s_p7, &crate::prelude::Text::lit("collision"), at_p9, &crate::prelude::Text::from(format!("`{}` is bound twice here", name_p8))))
    } else {
        (crate::prelude::push(seen_p6, name_p8), s_p7.clone())
    }));
    checked_pa.clone()
}

/// The step machine of `BoundTwice`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BoundTwice: unbounded fn Env, St, [Pattern] -> St
/// ```
pub struct BoundTwice {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub patterns_p2: crate::prelude::Array<crate::syntax::Pattern>,
}

impl ::prism_rtl::Job<crate::check::types::St> for BoundTwice {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let patterns_p2 = &self.patterns_p2;
        let env_p0x = env_p0.clone();
        let patterns_p2x = patterns_p2.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(patterns_p2x.clone(), crate::prelude::Array::new(), {
            let env_p0xx = env_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| {
                let env_p0xxy = env_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p4 = p0;
                    let p_p5 = p1;
                    crate::prelude::call_then(start_binders_of_f(env_p0xxy.clone(), p_p5.clone()), move |binders_of_f_4092: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &binders_of_f_4092)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
        }), move |fold_4048: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| {
            let binders_p3 = fold_4048;
            let (_, checked_pa) = crate::prelude::fold(&binders_p3, &(crate::prelude::Array::new(), st_p1x.clone()), &(|(seen_p6, s_p7): &(crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), (name_p8, at_p9): &(crate::prelude::Text, crate::syntax::Range)| if crate::check::types::has_text_f(seen_p6, name_p8) {
                (seen_p6.clone(), crate::check::types::recording::err_f(s_p7, &crate::prelude::Text::lit("collision"), at_p9, &crate::prelude::Text::from(format!("`{}` is bound twice here", name_p8))))
            } else {
                (crate::prelude::push(seen_p6, name_p8), s_p7.clone())
            }));
            ::prism_rtl::Turn::Finished(checked_pa.clone())
        })
    }
}

/// `Start BoundTwice, x`: what the function value is when passed to `@Run`.
pub fn start_bound_twice_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, patterns_p2: crate::prelude::Array<crate::syntax::Pattern>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(BoundTwice { env_p0, st_p1, patterns_p2 })
}

/// ```prism
/// BindersOf: unbounded fn Env, Pattern -> [((Text, Range))]
/// ```
pub fn binders_of_f(env_p0: &crate::check::expr::Env, p_p1: &crate::syntax::Pattern) -> crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)> {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => if (&crate::prelude::len(&n_p2.path_p) > &crate::prelude::Nat::from(1u32)) || (((&crate::prelude::len_text(&n_p2.sigils_p) == &crate::prelude::Nat::from(0u32)) && crate::check::env::is_upper_text_f(&crate::prelude::or(&crate::prelude::index(&n_p2.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")))) && is_ctor_name_f(env_p0, n_p2)) {
            crate::prelude::Array::new()
        } else {
            crate::prelude::Array::from(vec![(crate::check::env::sname_key_f(n_p2), n_p2.span_p.clone())])
        },
        crate::syntax::PatternKind::PCtor(_, ps_p3) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p3.clone(), crate::prelude::Array::new(), {
            let env_p0x = env_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| {
                let env_p0xy = env_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p4 = p0;
                    let q_p5 = p1;
                    crate::prelude::call_then(start_binders_of_f(env_p0xy.clone(), q_p5.clone()), move |binders_of_f_4786: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &binders_of_f_4786)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
        })),
        crate::syntax::PatternKind::PRecord(_, fs_p6, _) => crate::prelude::run_to_end(crate::prelude::fold_job(fs_p6.clone(), crate::prelude::Array::new(), {
            let env_p0x = env_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::FieldPat)| {
                let env_p0xy = env_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p7 = p0;
                    let f_p8 = p1;
                    crate::prelude::call_then(start_binders_of_f(env_p0xy.clone(), f_p8.pattern_p.clone()), move |binders_of_f_4874: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p7, &binders_of_f_4874)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::FieldPat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
        })),
        crate::syntax::PatternKind::PSigil(_, q_p9) => binders_of_f(env_p0, &**q_p9),
        crate::syntax::PatternKind::PTuple(ps_pa) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pa.clone(), crate::prelude::Array::new(), {
            let env_p0x = env_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| {
                let env_p0xy = env_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pb = p0;
                    let q_pc = p1;
                    crate::prelude::call_then(start_binders_of_f(env_p0xy.clone(), q_pc.clone()), move |binders_of_f_4992: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pb, &binders_of_f_4992)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
        })),
        crate::syntax::PatternKind::PArray(ps_pd) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pd.clone(), crate::prelude::Array::new(), {
            let env_p0x = env_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| {
                let env_p0xy = env_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pe = p0;
                    let q_pf = p1;
                    crate::prelude::call_then(start_binders_of_f(env_p0xy.clone(), q_pf.clone()), move |binders_of_f_5063: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pe, &binders_of_f_5063)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
        })),
        crate::syntax::PatternKind::PGroup(q_pg) => binders_of_f(env_p0, &**q_pg),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `BindersOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindersOf: unbounded fn Env, Pattern -> [((Text, Range))]
/// ```
pub struct BindersOf {
    pub env_p0: crate::check::expr::Env,
    pub p_p1: crate::syntax::Pattern,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>> for BindersOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>> {
        let env_p0 = &self.env_p0;
        let p_p1 = &self.p_p1;
        match &*p_p1.kind_p {
            crate::syntax::PatternKind::PName(n_p2) => if (&crate::prelude::len(&n_p2.path_p) > &crate::prelude::Nat::from(1u32)) || (((&crate::prelude::len_text(&n_p2.sigils_p) == &crate::prelude::Nat::from(0u32)) && crate::check::env::is_upper_text_f(&crate::prelude::or(&crate::prelude::index(&n_p2.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")))) && is_ctor_name_f(env_p0, n_p2)) {
                ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
            } else {
                ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![(crate::check::env::sname_key_f(n_p2), n_p2.span_p.clone())]))
            },
            crate::syntax::PatternKind::PCtor(_, ps_p3) => crate::prelude::fold_job(ps_p3.clone(), crate::prelude::Array::new(), {
                let env_p0x = env_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| {
                    let env_p0xy = env_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p4 = p0;
                        let q_p5 = p1;
                        crate::prelude::call_then(start_binders_of_f(env_p0xy.clone(), q_p5.clone()), move |binders_of_f_4786: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &binders_of_f_4786)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
            }).cycle(),
            crate::syntax::PatternKind::PRecord(_, fs_p6, _) => crate::prelude::fold_job(fs_p6.clone(), crate::prelude::Array::new(), {
                let env_p0x = env_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::FieldPat)| {
                    let env_p0xy = env_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p7 = p0;
                        let f_p8 = p1;
                        crate::prelude::call_then(start_binders_of_f(env_p0xy.clone(), f_p8.pattern_p.clone()), move |binders_of_f_4874: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p7, &binders_of_f_4874)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::FieldPat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
            }).cycle(),
            crate::syntax::PatternKind::PSigil(_, q_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindersOf { env_p0: env_p0.clone(), p_p1: (**q_p9).clone() })),
            crate::syntax::PatternKind::PTuple(ps_pa) => crate::prelude::fold_job(ps_pa.clone(), crate::prelude::Array::new(), {
                let env_p0x = env_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| {
                    let env_p0xy = env_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pb = p0;
                        let q_pc = p1;
                        crate::prelude::call_then(start_binders_of_f(env_p0xy.clone(), q_pc.clone()), move |binders_of_f_4992: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pb, &binders_of_f_4992)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
            }).cycle(),
            crate::syntax::PatternKind::PArray(ps_pd) => crate::prelude::fold_job(ps_pd.clone(), crate::prelude::Array::new(), {
                let env_p0x = env_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| {
                    let env_p0xy = env_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pe = p0;
                        let q_pf = p1;
                        crate::prelude::call_then(start_binders_of_f(env_p0xy.clone(), q_pf.clone()), move |binders_of_f_5063: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pe, &binders_of_f_5063)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
            }).cycle(),
            crate::syntax::PatternKind::PGroup(q_pg) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindersOf { env_p0: env_p0.clone(), p_p1: (**q_pg).clone() })),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start BindersOf, x`: what the function value is when passed to `@Run`.
pub fn start_binders_of_f(env_p0: crate::check::expr::Env, p_p1: crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>> {
    ::std::rc::Rc::new(BindersOf { env_p0, p_p1 })
}

/// ```prism
/// BlockBoundOnce: unbounded fn Env, St, [Stmt] -> St
/// ```
pub fn block_bound_once_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, stmts_p2: &crate::prelude::Array<crate::syntax::Stmt>) -> crate::check::types::St {
    let binders_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p2.clone(), crate::prelude::Array::new(), {
        let env_p0x = env_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Stmt)| {
            let env_p0xy = env_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p4 = p0;
                let s_p5 = p1;
                match &s_p5.kind_p {
                    crate::syntax::StmtKind::SBind(p_p6, _, _) => {
                        let p_p6x = p_p6.clone();
                        crate::prelude::call_then(start_binders_of_f(env_p0xy.clone(), p_p6x.clone()), move |binders_of_f_5486: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &binders_of_f_5486)))
                    },
                    crate::syntax::StmtKind::SLet(p_p7, _, _) => {
                        let p_p7x = p_p7.clone();
                        crate::prelude::call_then(start_binders_of_f(env_p0xy.clone(), p_p7x.clone()), move |binders_of_f_5549: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &binders_of_f_5549)))
                    },
                    _ => ::prism_rtl::Turn::Finished(acc_p4.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
    }));
    let (_, checked_pc) = crate::prelude::fold(&binders_p3, &(crate::prelude::Array::new(), st_p1.clone()), &(|(seen_p8, s_p9): &(crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), (name_pa, at_pb): &(crate::prelude::Text, crate::syntax::Range)| if (name_pa == &crate::prelude::Text::lit("_")) || (name_pa == &crate::prelude::Text::lit("$_")) {
        (seen_p8.clone(), s_p9.clone())
    } else {
        if crate::check::types::has_text_f(seen_p8, name_pa) {
            (seen_p8.clone(), crate::check::types::recording::err_fix_f(s_p9, &crate::prelude::Text::lit("collision"), at_pb, &crate::prelude::Text::from(format!("`{}` is bound twice in this block", name_pa)), &crate::prelude::Text::lit("a written name is bound once per block: give the second another name")))
        } else {
            (crate::prelude::push(seen_p8, name_pa), s_p9.clone())
        }
    }));
    checked_pc.clone()
}

/// The step machine of `BlockBoundOnce`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockBoundOnce: unbounded fn Env, St, [Stmt] -> St
/// ```
pub struct BlockBoundOnce {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub stmts_p2: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<crate::check::types::St> for BlockBoundOnce {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let stmts_p2 = &self.stmts_p2;
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        let stmts_p2x = stmts_p2.clone();
        crate::prelude::call_value(crate::prelude::fold_job(stmts_p2x.clone(), crate::prelude::Array::new(), {
            let env_p0xx = env_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Stmt)| {
                let env_p0xxy = env_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p4 = p0;
                    let s_p5 = p1;
                    match &s_p5.kind_p {
                        crate::syntax::StmtKind::SBind(p_p6, _, _) => {
                            let p_p6x = p_p6.clone();
                            crate::prelude::call_then(start_binders_of_f(env_p0xxy.clone(), p_p6x.clone()), move |binders_of_f_5486: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &binders_of_f_5486)))
                        },
                        crate::syntax::StmtKind::SLet(p_p7, _, _) => {
                            let p_p7x = p_p7.clone();
                            crate::prelude::call_then(start_binders_of_f(env_p0xxy.clone(), p_p7x.clone()), move |binders_of_f_5549: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &binders_of_f_5549)))
                        },
                        _ => ::prism_rtl::Turn::Finished(acc_p4.clone()),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
        }), move |fold_5398: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| {
            let binders_p3 = fold_5398;
            let (_, checked_pc) = crate::prelude::fold(&binders_p3, &(crate::prelude::Array::new(), st_p1x.clone()), &(|(seen_p8, s_p9): &(crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), (name_pa, at_pb): &(crate::prelude::Text, crate::syntax::Range)| if (name_pa == &crate::prelude::Text::lit("_")) || (name_pa == &crate::prelude::Text::lit("$_")) {
                (seen_p8.clone(), s_p9.clone())
            } else {
                if crate::check::types::has_text_f(seen_p8, name_pa) {
                    (seen_p8.clone(), crate::check::types::recording::err_fix_f(s_p9, &crate::prelude::Text::lit("collision"), at_pb, &crate::prelude::Text::from(format!("`{}` is bound twice in this block", name_pa)), &crate::prelude::Text::lit("a written name is bound once per block: give the second another name")))
                } else {
                    (crate::prelude::push(seen_p8, name_pa), s_p9.clone())
                }
            }));
            ::prism_rtl::Turn::Finished(checked_pc.clone())
        })
    }
}

/// `Start BlockBoundOnce, x`: what the function value is when passed to `@Run`.
pub fn start_block_bound_once_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, stmts_p2: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(BlockBoundOnce { env_p0, st_p1, stmts_p2 })
}

/// ```prism
/// LetNamesConstructor: fn Env, Pattern -> Bool
/// ```
pub fn let_names_constructor_f(env_p0: &crate::check::expr::Env, p_p1: &crate::syntax::Pattern) -> bool {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => (((&crate::prelude::len(&n_p2.path_p) == &crate::prelude::Nat::from(1u32)) && (&crate::prelude::len_text(&n_p2.sigils_p) == &crate::prelude::Nat::from(0u32))) && crate::check::env::is_upper_text_f(&crate::prelude::or(&crate::prelude::index(&n_p2.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")))) && is_ctor_name_f(env_p0, n_p2),
        _ => false,
    }
}

/// ```prism
/// IsCtorName: fn Env, SName -> Bool
/// ```
pub fn is_ctor_name_f(env_p0: &crate::check::expr::Env, n_p1: &crate::syntax::SName) -> bool {
    let (qk_o2, _) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p1);
    match &qk_o2 {
        ::std::option::Option::Some(qk_p3) => crate::check::env::has_key_f(&env_p0.g_p.ctors_p, qk_p3),
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub fn bind_name_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, t_p3: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let name_p4 = crate::check::env::sname_key_f(n_p2);
    if crate::check::types::has_text_f(&env_p0.pending_p, &name_p4) {
        match crate::prelude::get(&env_p0.locals_p, &name_p4) {
            ::std::option::Option::Some(sc_p5) => {
                let (ok_p8, st1_p9) = crate::check::types::unify::try_unify_f(st_p1, &sc_p5.ty_p, t_p3, &n_p2.span_p);
                let marks_agree_p6 = (&crate::check::types::stack_of_f(st_p1, t_p3) == &crate::check::expr::lets::type_marks_f(&n_p2.sigils_p)) || crate::check::types::is_flex_var_f(st_p1, t_p3);
                let st_a_p7 = if ok_p8 {
                    st1_p9.clone()
                } else {
                    if marks_agree_p6 {
                        crate::check::types::unify::unify_f(st_p1, &sc_p5.ty_p, t_p3, &n_p2.span_p)
                    } else {
                        crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("mark-stack"), &n_p2.span_p, &crate::prelude::Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name_p4, &crate::check::types::show_ty_f(st_p1, t_p3), &crate::check::types::stack_of_f(st_p1, t_p3), &crate::check::expr::lets::type_marks_f(&n_p2.sigils_p))), &crate::prelude::Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark_f(&n_p2.sigils_p), &crate::check::types::stack_of_f(st_p1, t_p3), &crate::syntax::lexer::chars::drop_prefix_f(&name_p4, &n_p2.sigils_p))))
                    }
                };
                crate::check::expr::bind_local_id_f(env_p0, &crate::check::types::recording::note_binder_f(&st_a_p7, &n_p2.span_p, &name_p4, t_p3), &name_p4, &n_p2.span_p)
            },
            ::std::option::Option::None => bind_fresh_f(env_p0, st_p1, n_p2, t_p3),
        }
    } else {
        bind_fresh_f(env_p0, st_p1, n_p2, t_p3)
    }
}

/// The step machine of `BindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub struct BindName {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub t_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindName {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let t_p3 = &self.t_p3;
        let name_p4 = crate::check::env::sname_key_f(n_p2);
        if crate::check::types::has_text_f(&env_p0.pending_p, &name_p4) {
            match crate::prelude::get(&env_p0.locals_p, &name_p4) {
                ::std::option::Option::Some(sc_p5) => {
                    let env_p0x = env_p0.clone();
                    let n_p2x = n_p2.clone();
                    let st_p1x = st_p1.clone();
                    let t_p3x = t_p3.clone();
                    crate::prelude::call_then(crate::check::types::unify::start_try_unify_f(st_p1x.clone(), sc_p5.ty_p.clone(), t_p3x.clone(), n_p2x.span_p.clone()), move |try_unify_f_6922: (bool, crate::check::types::St)| {
                        let (ok_p8, st1_p9) = try_unify_f_6922;
                        crate::prelude::call_then(crate::check::types::start_stack_of_f(st_p1x.clone(), t_p3x.clone()), move |stack_of_f_6986: crate::prelude::Text| {
                            let env_p0xz = env_p0x.clone();
                            let n_p2xz = n_p2x.clone();
                            let name_p4z = name_p4.clone();
                            let ok_p8z = ok_p8;
                            let sc_p5z = sc_p5.clone();
                            let st_p1xz = st_p1x.clone();
                            let st1_p9z = st1_p9.clone();
                            let t_p3xz = t_p3x.clone();
                            let k_let6968 = move |v6968: bool| {
                                let marks_agree_p6 = v6968;
                                let env_p0xzz = env_p0xz.clone();
                                let n_p2xzz = n_p2xz.clone();
                                let name_p4zz = name_p4z.clone();
                                let t_p3xzz = t_p3xz.clone();
                                let k_let7062 = move |v7062: crate::check::types::St| {
                                    let st_a_p7 = v7062;
                                    ::prism_rtl::Turn::Finished(crate::check::expr::bind_local_id_f(&env_p0xzz, &crate::check::types::recording::note_binder_f(&st_a_p7, &n_p2xzz.span_p, &name_p4zz, &t_p3xzz), &name_p4zz, &n_p2xzz.span_p))
                                };
                                if ok_p8z {
                                    k_let7062(st1_p9z.clone())
                                } else {
                                    if marks_agree_p6 {
                                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1xz.clone(), sc_p5z.ty_p.clone(), t_p3xz.clone(), n_p2xz.span_p.clone()), move |unify_f_7104: crate::check::types::St| k_let7062(unify_f_7104))
                                    } else {
                                        crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1xz.clone(), t_p3xz.clone()), move |show_ty_f_7191: crate::prelude::Text| crate::prelude::call_then(crate::check::types::start_stack_of_f(st_p1xz.clone(), t_p3xz.clone()), move |stack_of_f_7224: crate::prelude::Text| crate::prelude::call_then(crate::check::types::start_stack_of_f(st_p1xz.clone(), t_p3xz.clone()), move |stack_of_f_7312: crate::prelude::Text| k_let7062(crate::check::types::recording::err_fix_f(&st_p1xz, &crate::prelude::Text::lit("mark-stack"), &n_p2xz.span_p, &crate::prelude::Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name_p4z, &show_ty_f_7191, &stack_of_f_7224, &crate::check::expr::lets::type_marks_f(&n_p2xz.sigils_p))), &crate::prelude::Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark_f(&n_p2xz.sigils_p), &stack_of_f_7312, &crate::syntax::lexer::chars::drop_prefix_f(&name_p4z, &n_p2xz.sigils_p))))))))
                                    }
                                }
                            };
                            if &stack_of_f_6986 == &crate::check::expr::lets::type_marks_f(&n_p2x.sigils_p) {
                                k_let6968(true)
                            } else {
                                crate::prelude::call_then(crate::check::types::start_is_flex_var_f(st_p1x.clone(), t_p3x.clone()), move |is_flex_var_f_7029: bool| k_let6968(is_flex_var_f_7029))
                            }
                        })
                    })
                },
                ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindFresh { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p2.clone(), t_p3: t_p3.clone() })),
            }
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(BindFresh { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p2.clone(), t_p3: t_p3.clone() }))
        }
    }
}

/// `Start BindName, x`: what the function value is when passed to `@Run`.
pub fn start_bind_name_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, t_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(BindName { env_p0, st_p1, n_p2, t_p3 })
}

/// ```prism
/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub fn bind_fresh_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, t_p3: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    bind_fresh_marked_f(env_p0, st_p1, n_p2, &crate::check::expr::lets::type_marks_f(&n_p2.sigils_p), t_p3)
}

/// The step machine of `BindFresh`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub struct BindFresh {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub t_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindFresh {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let t_p3 = &self.t_p3;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(BindFreshMarked { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p2.clone(), marks_p3: crate::check::expr::lets::type_marks_f(&n_p2.sigils_p), t_p4: t_p3.clone() }))
    }
}

/// `Start BindFresh, x`: what the function value is when passed to `@Run`.
pub fn start_bind_fresh_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, t_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(BindFresh { env_p0, st_p1, n_p2, t_p3 })
}

/// ```prism
/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
/// ```
pub fn bind_fresh_marked_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, marks_p3: &crate::prelude::Text, t_p4: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let name_p5 = crate::check::env::sname_key_f(n_p2);
    let (v_p8, st2_p9) = crate::check::types::fresh_var_f(st_p1, &true, &name_p5);
    let (rw_pa, st3_pb) = crate::check::types::recording::fresh_row_f(&st2_p9, &crate::prelude::Array::new());
    let marked_p6 = crate::check::types::with_marks_f(marks_p3, &v_p8, &rw_pa);
    let (ok_pc, st4_pd) = crate::check::types::unify::try_unify_f(&st3_pb, t_p4, &marked_p6, &n_p2.span_p);
    let st5_p7 = if ok_pc {
        st4_pd.clone()
    } else {
        {
            let stack_pe = crate::check::types::stack_of_f(&st3_pb, t_p4);
            crate::check::types::recording::err_fix_f(&st3_pb, &crate::prelude::Text::lit("mark-stack"), &n_p2.span_p, &crate::prelude::Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name_p5, &crate::check::types::show_ty_f(&st3_pb, t_p4), &stack_pe, marks_p3)), &crate::prelude::Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark_f(&n_p2.sigils_p), &stack_pe, &crate::syntax::lexer::chars::drop_prefix_f(&name_p5, &n_p2.sigils_p))))
        }
    };
    crate::check::expr::bind_local_id_f(&crate::check::expr::with_local_f(env_p0, &name_p5, &crate::check::types::schemes::mono_f(t_p4)), &crate::check::types::recording::note_binder_f(&st5_p7, &n_p2.span_p, &name_p5, t_p4), &name_p5, &n_p2.span_p)
}

/// The step machine of `BindFreshMarked`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
/// ```
pub struct BindFreshMarked {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub marks_p3: crate::prelude::Text,
    pub t_p4: crate::check::types::Ty,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindFreshMarked {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let marks_p3 = &self.marks_p3;
        let t_p4 = &self.t_p4;
        let name_p5 = crate::check::env::sname_key_f(n_p2);
        let (v_p8, st2_p9) = crate::check::types::fresh_var_f(st_p1, &true, &name_p5);
        let (rw_pa, st3_pb) = crate::check::types::recording::fresh_row_f(&st2_p9, &crate::prelude::Array::new());
        let marked_p6 = crate::check::types::with_marks_f(marks_p3, &v_p8, &rw_pa);
        let env_p0x = env_p0.clone();
        let marks_p3x = marks_p3.clone();
        let n_p2x = n_p2.clone();
        let t_p4x = t_p4.clone();
        crate::prelude::call_then(crate::check::types::unify::start_try_unify_f(st3_pb.clone(), t_p4x.clone(), marked_p6.clone(), n_p2x.span_p.clone()), move |try_unify_f_8075: (bool, crate::check::types::St)| {
            let (ok_pc, st4_pd) = try_unify_f_8075;
            let env_p0xz = env_p0x.clone();
            let n_p2xz = n_p2x.clone();
            let name_p5z = name_p5.clone();
            let t_p4xz = t_p4x.clone();
            let k_let8111 = move |v8111: crate::check::types::St| {
                let st5_p7 = v8111;
                ::prism_rtl::Turn::Finished(crate::check::expr::bind_local_id_f(&crate::check::expr::with_local_f(&env_p0xz, &name_p5z, &crate::check::types::schemes::mono_f(&t_p4xz)), &crate::check::types::recording::note_binder_f(&st5_p7, &n_p2xz.span_p, &name_p5z, &t_p4xz), &name_p5z, &n_p2xz.span_p))
            };
            if ok_pc {
                k_let8111(st4_pd.clone())
            } else {
                crate::prelude::call_then(crate::check::types::start_stack_of_f(st3_pb.clone(), t_p4x.clone()), move |stack_of_f_8170: crate::prelude::Text| {
                    let stack_pe = stack_of_f_8170;
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(st3_pb.clone(), t_p4x.clone()), move |show_ty_f_8252: crate::prelude::Text| k_let8111(crate::check::types::recording::err_fix_f(&st3_pb, &crate::prelude::Text::lit("mark-stack"), &n_p2x.span_p, &crate::prelude::Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name_p5, &show_ty_f_8252, &stack_pe, &marks_p3x)), &crate::prelude::Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark_f(&n_p2x.sigils_p), &stack_pe, &crate::syntax::lexer::chars::drop_prefix_f(&name_p5, &n_p2x.sigils_p))))))
                })
            }
        })
    }
}

/// `Start BindFreshMarked, x`: what the function value is when passed to `@Run`.
pub fn start_bind_fresh_marked_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, marks_p3: crate::prelude::Text, t_p4: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(BindFreshMarked { env_p0, st_p1, n_p2, marks_p3, t_p4 })
}

/// ```prism
/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_field_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern, ft_p3: &crate::check::types::Ty, snapshot_p4: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    match crate::check::types::recording::walk_f(st_p1, ft_p3) {
        crate::check::types::Ty::TySig(s_p5, level_p6) if (*snapshot_p4 && (&s_p5 == &crate::prelude::Text::lit("$"))) => bind_level_f(env_p0, st_p1, p_p2, &*level_p6),
        _ => bind_pattern_f(env_p0, st_p1, p_p2, ft_p3, &true),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BindField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub struct BindField {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern,
    pub ft_p3: crate::check::types::Ty,
    pub snapshot_p4: bool,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindField {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let ft_p3 = &self.ft_p3;
        let snapshot_p4 = &self.snapshot_p4;
        let env_p0x = env_p0.clone();
        let ft_p3x = ft_p3.clone();
        let p_p2x = p_p2.clone();
        let snapshot_p4x = *snapshot_p4;
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), ft_p3x.clone()), move |walk_f_9024: crate::check::types::Ty| match walk_f_9024 {
            crate::check::types::Ty::TySig(s_p5, level_p6) if (snapshot_p4x && (&s_p5 == &crate::prelude::Text::lit("$"))) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindLevel { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), p_p2: p_p2x.clone(), level_p3: (*level_p6).clone() })),
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), p_p2: p_p2x.clone(), t_p3: ft_p3x.clone(), refutable_p4: true })),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start BindField, x`: what the function value is when passed to `@Run`.
pub fn start_bind_field_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern, ft_p3: crate::check::types::Ty, snapshot_p4: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(BindField { env_p0, st_p1, p_p2, ft_p3, snapshot_p4 })
}

/// ```prism
/// LiveFieldTested: unbounded fn Env, St, Text, Pattern, Ty -> St
/// ```
pub fn live_field_tested_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fname_p2: &crate::prelude::Text, p_p3: &crate::syntax::Pattern, ft_p4: &crate::check::types::Ty) -> crate::check::types::St {
    let stack_p5 = crate::check::types::stack_of_f(st_p1, ft_p4);
    let binder_p6 = crate::prelude::Text::from(format!("{}{}", &stack_p5, &crate::syntax::lexer::chars::head_f(fname_p2)));
    crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("live-field-pattern"), &p_p3.span_p, &crate::prelude::Text::from(format!("an element\'s `{}{}` binds its {}; `{}` would test a value the field has only in a tick", &stack_p5, fname_p2, &(if crate::syntax::lexer::chars::has_prefix_f(&stack_p5, &crate::prelude::Text::lit("$")) {
        crate::prelude::Text::lit("dynamic")
    } else {
        crate::prelude::Text::lit("event")
    }), &crate::check::expr::src_text_f(env_p0, &p_p3.span_p))), &crate::prelude::Text::from(format!("bind it, `{}{}={}`, and read `{}` where a tick reads it", &stack_p5, fname_p2, &binder_p6, &binder_p6)))
}

/// The step machine of `LiveFieldTested`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiveFieldTested: unbounded fn Env, St, Text, Pattern, Ty -> St
/// ```
pub struct LiveFieldTested {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fname_p2: crate::prelude::Text,
    pub p_p3: crate::syntax::Pattern,
    pub ft_p4: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::St> for LiveFieldTested {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fname_p2 = &self.fname_p2;
        let p_p3 = &self.p_p3;
        let ft_p4 = &self.ft_p4;
        let env_p0x = env_p0.clone();
        let fname_p2x = fname_p2.clone();
        let ft_p4x = ft_p4.clone();
        let p_p3x = p_p3.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::start_stack_of_f(st_p1x.clone(), ft_p4x.clone()), move |stack_of_f_9608: crate::prelude::Text| {
            let stack_p5 = stack_of_f_9608;
            let binder_p6 = crate::prelude::Text::from(format!("{}{}", &stack_p5, &crate::syntax::lexer::chars::head_f(&fname_p2x)));
            ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("live-field-pattern"), &p_p3x.span_p, &crate::prelude::Text::from(format!("an element\'s `{}{}` binds its {}; `{}` would test a value the field has only in a tick", &stack_p5, &fname_p2x, &(if crate::syntax::lexer::chars::has_prefix_f(&stack_p5, &crate::prelude::Text::lit("$")) {
                crate::prelude::Text::lit("dynamic")
            } else {
                crate::prelude::Text::lit("event")
            }), &crate::check::expr::src_text_f(&env_p0x, &p_p3x.span_p))), &crate::prelude::Text::from(format!("bind it, `{}{}={}`, and read `{}` where a tick reads it", &stack_p5, &fname_p2x, &binder_p6, &binder_p6))))
        })
    }
}

/// `Start LiveFieldTested, x`: what the function value is when passed to `@Run`.
pub fn start_live_field_tested_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fname_p2: crate::prelude::Text, p_p3: crate::syntax::Pattern, ft_p4: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(LiveFieldTested { env_p0, st_p1, fname_p2, p_p3, ft_p4 })
}

/// ```prism
/// TestsLiveField: unbounded fn Env, St, Pattern, Ty, Bool -> Bool
/// ```
pub fn tests_live_field_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern, ft_p3: &crate::check::types::Ty, snapshot_p4: &bool) -> bool {
    match crate::check::types::recording::walk_f(st_p1, ft_p3) {
        crate::check::types::Ty::TySig(s_p5, _) => (((&s_p5 == &crate::prelude::Text::lit("$")) || (&s_p5 == &crate::prelude::Text::lit("!"))) && !*snapshot_p4) && tests_value_f(env_p0, p_p2),
        _ => false,
    }
}

/// The step machine of `TestsLiveField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TestsLiveField: unbounded fn Env, St, Pattern, Ty, Bool -> Bool
/// ```
pub struct TestsLiveField {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern,
    pub ft_p3: crate::check::types::Ty,
    pub snapshot_p4: bool,
}

impl ::prism_rtl::Job<bool> for TestsLiveField {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let ft_p3 = &self.ft_p3;
        let snapshot_p4 = &self.snapshot_p4;
        let env_p0x = env_p0.clone();
        let ft_p3x = ft_p3.clone();
        let p_p2x = p_p2.clone();
        let snapshot_p4x = *snapshot_p4;
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), ft_p3x.clone()), move |walk_f_10198: crate::check::types::Ty| match walk_f_10198 {
            crate::check::types::Ty::TySig(s_p5, _) => if ((&s_p5 == &crate::prelude::Text::lit("$")) || (&s_p5 == &crate::prelude::Text::lit("!"))) && !snapshot_p4x {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TestsValue { env_p0: env_p0x.clone(), p_p1: p_p2x.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(false)
            },
            _ => ::prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start TestsLiveField, x`: what the function value is when passed to `@Run`.
pub fn start_tests_live_field_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern, ft_p3: crate::check::types::Ty, snapshot_p4: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(TestsLiveField { env_p0, st_p1, p_p2, ft_p3, snapshot_p4 })
}

/// ```prism
/// TestsValue: unbounded fn Env, Pattern -> Bool
/// ```
pub fn tests_value_f(env_p0: &crate::check::expr::Env, p_p1: &crate::syntax::Pattern) -> bool {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => names_constructor_f(env_p0, n_p2),
        crate::syntax::PatternKind::PLit(_) => true,
        crate::syntax::PatternKind::PNeg(_) => true,
        crate::syntax::PatternKind::PNil => true,
        crate::syntax::PatternKind::PCtor(_, _) => true,
        crate::syntax::PatternKind::PRecord(_, _, _) => true,
        crate::syntax::PatternKind::PArray(_) => true,
        crate::syntax::PatternKind::PFamily(_) => true,
        crate::syntax::PatternKind::PSigil(s_p3, q_p4) => (crate::syntax::lexer::chars::contains_f(s_p3, &crate::prelude::Text::lit("?")) || crate::syntax::lexer::chars::contains_f(s_p3, &crate::prelude::Text::lit("~"))) || tests_value_f(env_p0, &**q_p4),
        crate::syntax::PatternKind::PTuple(parts_p5) => crate::prelude::run_to_end(crate::prelude::fold_job(parts_p5.clone(), false, {
            let env_p0x = env_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Pattern)| {
                let env_p0xy = env_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_p6 = p0;
                    let q_p7 = p1;
                    if seen_p6 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(TestsValue { env_p0: env_p0xy.clone(), p_p1: q_p7.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        crate::syntax::PatternKind::PGroup(q_p8) => tests_value_f(env_p0, &**q_p8),
        _ => false,
    }
}

/// The step machine of `TestsValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TestsValue: unbounded fn Env, Pattern -> Bool
/// ```
pub struct TestsValue {
    pub env_p0: crate::check::expr::Env,
    pub p_p1: crate::syntax::Pattern,
}

impl ::prism_rtl::Job<bool> for TestsValue {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let p_p1 = &self.p_p1;
        match &*p_p1.kind_p {
            crate::syntax::PatternKind::PName(n_p2) => ::prism_rtl::Turn::Finished(names_constructor_f(env_p0, n_p2)),
            crate::syntax::PatternKind::PLit(_) => ::prism_rtl::Turn::Finished(true),
            crate::syntax::PatternKind::PNeg(_) => ::prism_rtl::Turn::Finished(true),
            crate::syntax::PatternKind::PNil => ::prism_rtl::Turn::Finished(true),
            crate::syntax::PatternKind::PCtor(_, _) => ::prism_rtl::Turn::Finished(true),
            crate::syntax::PatternKind::PRecord(_, _, _) => ::prism_rtl::Turn::Finished(true),
            crate::syntax::PatternKind::PArray(_) => ::prism_rtl::Turn::Finished(true),
            crate::syntax::PatternKind::PFamily(_) => ::prism_rtl::Turn::Finished(true),
            crate::syntax::PatternKind::PSigil(s_p3, q_p4) => if crate::syntax::lexer::chars::contains_f(s_p3, &crate::prelude::Text::lit("?")) || crate::syntax::lexer::chars::contains_f(s_p3, &crate::prelude::Text::lit("~")) {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TestsValue { env_p0: env_p0.clone(), p_p1: (**q_p4).clone() }))
            },
            crate::syntax::PatternKind::PTuple(parts_p5) => crate::prelude::fold_job(parts_p5.clone(), false, {
                let env_p0x = env_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Pattern)| {
                    let env_p0xy = env_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let seen_p6 = p0;
                        let q_p7 = p1;
                        if seen_p6 {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(TestsValue { env_p0: env_p0xy.clone(), p_p1: q_p7.clone() }))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle(),
            crate::syntax::PatternKind::PGroup(q_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TestsValue { env_p0: env_p0.clone(), p_p1: (**q_p8).clone() })),
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start TestsValue, x`: what the function value is when passed to `@Run`.
pub fn start_tests_value_f(env_p0: crate::check::expr::Env, p_p1: crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(TestsValue { env_p0, p_p1 })
}

/// ```prism
/// NamesConstructor: fn Env, SName -> Bool
/// ```
pub fn names_constructor_f(env_p0: &crate::check::expr::Env, n_p1: &crate::syntax::SName) -> bool {
    (&crate::prelude::len(&n_p1.path_p) > &crate::prelude::Nat::from(1u32)) || (crate::check::env::is_upper_text_f(&crate::prelude::or(&crate::prelude::index(&n_p1.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""))) && is_ctor_name_f(env_p0, &unmarked_f(n_p1)))
}

/// ```prism
/// Unmarked: fn SName -> SName
/// ```
pub fn unmarked_f(n_p0: &crate::syntax::SName) -> crate::syntax::SName {
    crate::syntax::SName { sigils_p: crate::prelude::Text::lit(""), path_p: n_p0.path_p.clone(), span_p: n_p0.span_p.clone() }
}

/// ```prism
/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
/// ```
pub fn bind_level_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern, level_p3: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    match &*p_p2.kind_p {
        crate::syntax::PatternKind::PName(n_p4) => if (crate::syntax::lexer::chars::has_prefix_f(&n_p4.sigils_p, &crate::prelude::Text::lit("$")) && (&crate::prelude::len(&n_p4.path_p) == &crate::prelude::Nat::from(1u32))) && names_constructor_f(env_p0, n_p4) {
            bind_pattern_f(env_p0, st_p1, &crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PName(unmarked_f(n_p4))), span_p: p_p2.span_p.clone() }, level_p3, &true)
        } else {
            if crate::syntax::lexer::chars::has_prefix_f(&n_p4.sigils_p, &crate::prelude::Text::lit("$")) && (&crate::prelude::len(&n_p4.path_p) == &crate::prelude::Nat::from(1u32)) {
                bind_fresh_marked_f(env_p0, st_p1, n_p4, &crate::syntax::lexer::chars::after_first_f(&n_p4.sigils_p), level_p3)
            } else {
                bind_pattern_f(env_p0, st_p1, p_p2, level_p3, &true)
            }
        },
        crate::syntax::PatternKind::PGroup(q_p5) => bind_level_f(env_p0, st_p1, &**q_p5, level_p3),
        _ => bind_pattern_f(env_p0, st_p1, p_p2, level_p3, &true),
    }
}

/// The step machine of `BindLevel`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
/// ```
pub struct BindLevel {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern,
    pub level_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindLevel {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let level_p3 = &self.level_p3;
        match &*p_p2.kind_p {
            crate::syntax::PatternKind::PName(n_p4) => if (crate::syntax::lexer::chars::has_prefix_f(&n_p4.sigils_p, &crate::prelude::Text::lit("$")) && (&crate::prelude::len(&n_p4.path_p) == &crate::prelude::Nat::from(1u32))) && names_constructor_f(env_p0, n_p4) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PName(unmarked_f(n_p4))), span_p: p_p2.span_p.clone() }, t_p3: level_p3.clone(), refutable_p4: true }))
            } else {
                if crate::syntax::lexer::chars::has_prefix_f(&n_p4.sigils_p, &crate::prelude::Text::lit("$")) && (&crate::prelude::len(&n_p4.path_p) == &crate::prelude::Nat::from(1u32)) {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(BindFreshMarked { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p4.clone(), marks_p3: crate::syntax::lexer::chars::after_first_f(&n_p4.sigils_p), t_p4: level_p3.clone() }))
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), t_p3: level_p3.clone(), refutable_p4: true }))
                }
            },
            crate::syntax::PatternKind::PGroup(q_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindLevel { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: (**q_p5).clone(), level_p3: level_p3.clone() })),
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), t_p3: level_p3.clone(), refutable_p4: true })),
        }
    }
}

/// `Start BindLevel, x`: what the function value is when passed to `@Run`.
pub fn start_bind_level_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern, level_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(BindLevel { env_p0, st_p1, p_p2, level_p3 })
}

/// ```prism
/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
/// ```
pub fn bind_ctor_f(env_p0: &crate::check::expr::Env, st0_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern, n_p3: &crate::syntax::SName, args_p4: &crate::prelude::Array<crate::syntax::Pattern>, t_p5: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let (qk_o7, why_p8) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p3);
    let st_p6 = crate::check::expr::collision_at_f(env_p0, st0_p1, &why_p8, &crate::check::env::sname_key_f(n_p3), &n_p3.span_p);
    match &qk_o7 {
        ::std::option::Option::None => (env_p0.clone(), crate::check::types::recording::err_f(&st_p6, &crate::prelude::Text::lit("unknown-name"), &n_p3.span_p, &crate::prelude::Text::from(format!("no constructor `{}`", &crate::check::env::sname_key_f(n_p3))))),
        ::std::option::Option::Some(qk_p9) => if &why_p8 == &crate::prelude::Text::lit("tag") {
            bind_tag_pattern_f(env_p0, &st_p6, p_p2, qk_p9, &crate::prelude::Array::new(), &true, t_p5)
        } else {
            match crate::prelude::get(&env_p0.g_p.ctors_p, qk_p9) {
                ::std::option::Option::None => (env_p0.clone(), crate::check::types::recording::err_f(&st_p6, &crate::prelude::Text::lit("unknown-name"), &n_p3.span_p, &crate::prelude::Text::from(format!("`{}` is not a constructor", &crate::check::env::sname_key_f(n_p3))))),
                ::std::option::Option::Some(c_pa) => {
                    let (self_pc, st1_pd, inst_pe) = crate::check::types::schemes::instantiate_with_f(&st_p6, &crate::check::types::Scheme { qs_p: c_pa.params_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: c_pa.ty_p.clone() }, &p_p2.span_p, &crate::prelude::Array::new());
                    let st2_pb = if crate::check::types::recording::is_failure_pattern_f(&st1_pd, t_p5, &self_pc) {
                        st1_pd.clone()
                    } else {
                        crate::check::types::unify::unify_f(&st1_pd, t_p5, &self_pc, &p_p2.span_p)
                    };
                    if (&crate::prelude::len(args_p4) != &crate::prelude::len(&c_pa.args_p)) && !((&crate::prelude::len(args_p4) == &crate::prelude::Nat::from(1u32)) && (&crate::prelude::len(&c_pa.args_p) > &crate::prelude::Nat::from(1u32))) {
                        (env_p0.clone(), crate::check::types::recording::err_f(&st2_pb, &crate::prelude::Text::lit("mismatch"), &p_p2.span_p, &crate::prelude::Text::from(format!("`{}` takes {} argument{}; this pattern gives {}", &crate::check::types::bare_name_f(&c_pa.name_p), &crate::check::errors::count_word_f(&crate::prelude::len(&c_pa.args_p)), &(if &crate::prelude::len(&c_pa.args_p) == &crate::prelude::Nat::from(1u32) {
                            crate::prelude::Text::lit("")
                        } else {
                            crate::prelude::Text::lit("s")
                        }), &crate::check::errors::count_word_f(&crate::prelude::len(args_p4))))))
                    } else {
                        crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(args_p4)), (env_p0.clone(), st2_pb.clone()), {
                            let args_p4x = args_p4.clone();
                            let p_p2x = p_p2.clone();
                            let inst_pex = inst_pe.clone();
                            let c_pax = c_pa.clone();
                            ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)| {
                                let args_p4xy = args_p4x.clone();
                                let p_p2xy = p_p2x.clone();
                                let inst_pexy = inst_pex.clone();
                                let c_paxy = c_pax.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (en_pf, s_pg) = p0;
                                    let i_ph = p1;
                                    crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pexy.clone(), crate::prelude::or(&crate::prelude::index(&c_paxy.args_p, &i_ph), &crate::check::types::Ty::TyErr)), move |subst_q_f_13682: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: en_pf.clone(), st_p1: s_pg.clone(), p_p2: crate::prelude::or(&crate::prelude::index(&args_p4xy, &i_ph), &crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xy.span_p.clone() }), t_p3: subst_q_f_13682, refutable_p4: true })))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                        }))
                    }
                },
            }
        },
    }
}

/// The step machine of `BindCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
/// ```
pub struct BindCtor {
    pub env_p0: crate::check::expr::Env,
    pub st0_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern,
    pub n_p3: crate::syntax::SName,
    pub args_p4: crate::prelude::Array<crate::syntax::Pattern>,
    pub t_p5: crate::check::types::Ty,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindCtor {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st0_p1 = &self.st0_p1;
        let p_p2 = &self.p_p2;
        let n_p3 = &self.n_p3;
        let args_p4 = &self.args_p4;
        let t_p5 = &self.t_p5;
        let (qk_o7, why_p8) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p3);
        let st_p6 = crate::check::expr::collision_at_f(env_p0, st0_p1, &why_p8, &crate::check::env::sname_key_f(n_p3), &n_p3.span_p);
        match &qk_o7 {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(&st_p6, &crate::prelude::Text::lit("unknown-name"), &n_p3.span_p, &crate::prelude::Text::from(format!("no constructor `{}`", &crate::check::env::sname_key_f(n_p3)))))),
            ::std::option::Option::Some(qk_p9) => if &why_p8 == &crate::prelude::Text::lit("tag") {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(BindTagPattern { env_p0: env_p0.clone(), st_p1: st_p6.clone(), p_p2: p_p2.clone(), name_p3: qk_p9.clone(), fields_p4: crate::prelude::Array::new(), rest_p5: true, t_p6: t_p5.clone() }))
            } else {
                match crate::prelude::get(&env_p0.g_p.ctors_p, qk_p9) {
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(&st_p6, &crate::prelude::Text::lit("unknown-name"), &n_p3.span_p, &crate::prelude::Text::from(format!("`{}` is not a constructor", &crate::check::env::sname_key_f(n_p3)))))),
                    ::std::option::Option::Some(c_pa) => {
                        let args_p4x = args_p4.clone();
                        let env_p0x = env_p0.clone();
                        let p_p2x = p_p2.clone();
                        let t_p5x = t_p5.clone();
                        crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p6.clone(), crate::check::types::Scheme { qs_p: c_pa.params_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: c_pa.ty_p.clone() }, p_p2x.span_p.clone(), crate::prelude::Array::new()), move |instantiate_with_f_12991: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                            let (self_pc, st1_pd, inst_pe) = instantiate_with_f_12991;
                            crate::prelude::call_then(crate::check::types::recording::start_is_failure_pattern_f(st1_pd.clone(), t_p5x.clone(), self_pc.clone()), move |is_failure_pattern_f_13159: bool| {
                                let args_p4xz = args_p4x.clone();
                                let c_paz = c_pa.clone();
                                let env_p0xz = env_p0x.clone();
                                let inst_pez = inst_pe.clone();
                                let p_p2xz = p_p2x.clone();
                                let k_let13146 = move |v13146: crate::check::types::St| {
                                    let st2_pb = v13146;
                                    if (&crate::prelude::len(&args_p4xz) != &crate::prelude::len(&c_paz.args_p)) && !((&crate::prelude::len(&args_p4xz) == &crate::prelude::Nat::from(1u32)) && (&crate::prelude::len(&c_paz.args_p) > &crate::prelude::Nat::from(1u32))) {
                                        ::prism_rtl::Turn::Finished((env_p0xz.clone(), crate::check::types::recording::err_f(&st2_pb, &crate::prelude::Text::lit("mismatch"), &p_p2xz.span_p, &crate::prelude::Text::from(format!("`{}` takes {} argument{}; this pattern gives {}", &crate::check::types::bare_name_f(&c_paz.name_p), &crate::check::errors::count_word_f(&crate::prelude::len(&c_paz.args_p)), &(if &crate::prelude::len(&c_paz.args_p) == &crate::prelude::Nat::from(1u32) {
                                            crate::prelude::Text::lit("")
                                        } else {
                                            crate::prelude::Text::lit("s")
                                        }), &crate::check::errors::count_word_f(&crate::prelude::len(&args_p4xz)))))))
                                    } else {
                                        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&args_p4xz)), (env_p0xz.clone(), st2_pb.clone()), {
                                            let args_p4xzx = args_p4xz.clone();
                                            let p_p2xzx = p_p2xz.clone();
                                            let inst_pezx = inst_pez.clone();
                                            let c_pazx = c_paz.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)| {
                                                let args_p4xzxy = args_p4xzx.clone();
                                                let p_p2xzxy = p_p2xzx.clone();
                                                let inst_pezxy = inst_pezx.clone();
                                                let c_pazxy = c_pazx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let (en_pf, s_pg) = p0;
                                                    let i_ph = p1;
                                                    crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pezxy.clone(), crate::prelude::or(&crate::prelude::index(&c_pazxy.args_p, &i_ph), &crate::check::types::Ty::TyErr)), move |subst_q_f_13682: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: en_pf.clone(), st_p1: s_pg.clone(), p_p2: crate::prelude::or(&crate::prelude::index(&args_p4xzxy, &i_ph), &crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xzxy.span_p.clone() }), t_p3: subst_q_f_13682, refutable_p4: true })))
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                                        }).cycle()
                                    }
                                };
                                if is_failure_pattern_f_13159 {
                                    k_let13146(st1_pd.clone())
                                } else {
                                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st1_pd.clone(), t_p5x.clone(), self_pc.clone(), p_p2x.span_p.clone()), move |unify_f_13200: crate::check::types::St| k_let13146(unify_f_13200))
                                }
                            })
                        })
                    },
                }
            },
        }
    }
}

/// `Start BindCtor, x`: what the function value is when passed to `@Run`.
pub fn start_bind_ctor_f(env_p0: crate::check::expr::Env, st0_p1: crate::check::types::St, p_p2: crate::syntax::Pattern, n_p3: crate::syntax::SName, args_p4: crate::prelude::Array<crate::syntax::Pattern>, t_p5: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(BindCtor { env_p0, st0_p1, p_p2, n_p3, args_p4, t_p5 })
}

/// ```prism
/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub fn bind_record_f(env_p0: &crate::check::expr::Env, st0_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern, n_p3: &crate::syntax::SName, fields_p4: &crate::prelude::Array<crate::syntax::FieldPat>, rest_p5: &bool, t_p6: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let (qk_o8, why_p9) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p3);
    let st_p7 = crate::check::expr::collision_at_f(env_p0, st0_p1, &why_p9, &crate::check::env::sname_key_f(n_p3), &n_p3.span_p);
    match &qk_o8 {
        ::std::option::Option::None => (env_p0.clone(), crate::check::types::recording::err_f(&st_p7, &crate::prelude::Text::lit("unknown-name"), &n_p3.span_p, &crate::prelude::Text::from(format!("no record or tag `{}`", &crate::check::env::sname_key_f(n_p3))))),
        ::std::option::Option::Some(qk_pa) => if &why_p9 == &crate::prelude::Text::lit("tag") {
            bind_tag_pattern_f(env_p0, &st_p7, p_p2, qk_pa, fields_p4, rest_p5, t_p6)
        } else {
            match crate::prelude::get(&env_p0.g_p.ctors_p, qk_pa) {
                ::std::option::Option::None => (env_p0.clone(), crate::check::types::recording::err_f(&st_p7, &crate::prelude::Text::lit("unknown-name"), &n_p3.span_p, &crate::prelude::Text::from(format!("`{}` is not a record", &crate::check::env::sname_key_f(n_p3))))),
                ::std::option::Option::Some(c_pb) => {
                    let (self_pd, st1_pe, inst_pf) = crate::check::types::schemes::instantiate_with_f(&st_p7, &crate::check::types::Scheme { qs_p: c_pb.params_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: c_pb.ty_p.clone() }, &p_p2.span_p, &crate::prelude::Array::new());
                    let st2_pc = if crate::check::types::recording::is_failure_pattern_f(&st1_pe, t_p6, &self_pd) {
                        st1_pe.clone()
                    } else {
                        crate::check::types::unify::unify_f(&st1_pe, t_p6, &self_pd, &p_p2.span_p)
                    };
                    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(fields_p4)), (env_p0.clone(), st2_pc.clone()), {
                        let fields_p4x = fields_p4.clone();
                        let p_p2x = p_p2.clone();
                        let c_pbx = c_pb.clone();
                        let inst_pfx = inst_pf.clone();
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)| {
                            let fields_p4xy = fields_p4x.clone();
                            let p_p2xy = p_p2x.clone();
                            let c_pbxy = c_pbx.clone();
                            let inst_pfxy = inst_pfx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (en_pg, s_ph) = p0;
                                let i_pi = p1;
                                {
                                    let fp_pj = crate::prelude::or(&crate::prelude::index(&fields_p4xy, &i_pi), &crate::syntax::FieldPat { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, pattern_p: crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xy.span_p.clone() }, span_p: p_p2xy.span_p.clone() });
                                    let fname_pk = field_pat_name_f(&fp_pj, &c_pbxy.fields_p, &i_pi);
                                    let before_pl = crate::prelude::fold(&crate::check::errors::range0_f(&i_pi), &false, &(|seen_pn: &bool, k_po: &crate::prelude::Nat| *seen_pn || (&field_pat_name_f(&crate::prelude::or(&crate::prelude::index(&fields_p4xy, k_po), &fp_pj), &c_pbxy.fields_p, k_po) == &fname_pk)));
                                    let s0_pm = if before_pl {
                                        crate::check::types::recording::err_f(&s_ph, &crate::prelude::Text::lit("collision"), &fp_pj.span_p, &crate::prelude::Text::from(format!("`{}` is matched twice", &fname_pk)))
                                    } else {
                                        s_ph.clone()
                                    };
                                    match crate::check::expr::operators::index_of_o(&c_pbxy.fields_p, &fname_pk) {
                                        ::std::option::Option::Some(j_pp) => crate::prelude::call_then(start_pat_marks_f(s0_pm.clone(), crate::check::types::bare_name_f(&c_pbxy.owner_p), fname_pk.clone(), crate::prelude::or(&crate::prelude::index(&c_pbxy.args_p, &j_pp), &crate::check::types::Ty::TyErr), fp_pj.clone()), move |pat_marks_f_15577: crate::check::types::St| crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pfxy.clone(), crate::prelude::or(&crate::prelude::index(&c_pbxy.args_p, &j_pp), &crate::check::types::Ty::TyErr)), move |subst_q_f_15658: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: en_pg.clone(), st_p1: pat_marks_f_15577, p_p2: fp_pj.pattern_p.clone(), t_p3: subst_q_f_15658, refutable_p4: true })))),
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((en_pg.clone(), crate::check::types::recording::err_f(&s0_pm, &crate::prelude::Text::lit("mismatch"), &fp_pj.span_p, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name_f(&c_pbxy.owner_p), &fname_pk))))),
                                    }
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                    }))
                },
            }
        },
    }
}

/// The step machine of `BindRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub struct BindRecord {
    pub env_p0: crate::check::expr::Env,
    pub st0_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern,
    pub n_p3: crate::syntax::SName,
    pub fields_p4: crate::prelude::Array<crate::syntax::FieldPat>,
    pub rest_p5: bool,
    pub t_p6: crate::check::types::Ty,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindRecord {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st0_p1 = &self.st0_p1;
        let p_p2 = &self.p_p2;
        let n_p3 = &self.n_p3;
        let fields_p4 = &self.fields_p4;
        let rest_p5 = &self.rest_p5;
        let t_p6 = &self.t_p6;
        let (qk_o8, why_p9) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p3);
        let st_p7 = crate::check::expr::collision_at_f(env_p0, st0_p1, &why_p9, &crate::check::env::sname_key_f(n_p3), &n_p3.span_p);
        match &qk_o8 {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(&st_p7, &crate::prelude::Text::lit("unknown-name"), &n_p3.span_p, &crate::prelude::Text::from(format!("no record or tag `{}`", &crate::check::env::sname_key_f(n_p3)))))),
            ::std::option::Option::Some(qk_pa) => if &why_p9 == &crate::prelude::Text::lit("tag") {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(BindTagPattern { env_p0: env_p0.clone(), st_p1: st_p7.clone(), p_p2: p_p2.clone(), name_p3: qk_pa.clone(), fields_p4: fields_p4.clone(), rest_p5: *rest_p5, t_p6: t_p6.clone() }))
            } else {
                match crate::prelude::get(&env_p0.g_p.ctors_p, qk_pa) {
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(&st_p7, &crate::prelude::Text::lit("unknown-name"), &n_p3.span_p, &crate::prelude::Text::from(format!("`{}` is not a record", &crate::check::env::sname_key_f(n_p3)))))),
                    ::std::option::Option::Some(c_pb) => {
                        let env_p0x = env_p0.clone();
                        let fields_p4x = fields_p4.clone();
                        let p_p2x = p_p2.clone();
                        let t_p6x = t_p6.clone();
                        crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p7.clone(), crate::check::types::Scheme { qs_p: c_pb.params_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: c_pb.ty_p.clone() }, p_p2x.span_p.clone(), crate::prelude::Array::new()), move |instantiate_with_f_14528: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                            let (self_pd, st1_pe, inst_pf) = instantiate_with_f_14528;
                            crate::prelude::call_then(crate::check::types::recording::start_is_failure_pattern_f(st1_pe.clone(), t_p6x.clone(), self_pd.clone()), move |is_failure_pattern_f_14696: bool| {
                                let c_pbz = c_pb.clone();
                                let env_p0xz = env_p0x.clone();
                                let fields_p4xz = fields_p4x.clone();
                                let inst_pfz = inst_pf.clone();
                                let p_p2xz = p_p2x.clone();
                                let k_let14683 = move |v14683: crate::check::types::St| {
                                    let st2_pc = v14683;
                                    crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&fields_p4xz)), (env_p0xz.clone(), st2_pc.clone()), {
                                        let fields_p4xzx = fields_p4xz.clone();
                                        let p_p2xzx = p_p2xz.clone();
                                        let c_pbzx = c_pbz.clone();
                                        let inst_pfzx = inst_pfz.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)| {
                                            let fields_p4xzxy = fields_p4xzx.clone();
                                            let p_p2xzxy = p_p2xzx.clone();
                                            let c_pbzxy = c_pbzx.clone();
                                            let inst_pfzxy = inst_pfzx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let (en_pg, s_ph) = p0;
                                                let i_pi = p1;
                                                {
                                                    let fp_pj = crate::prelude::or(&crate::prelude::index(&fields_p4xzxy, &i_pi), &crate::syntax::FieldPat { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, pattern_p: crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xzxy.span_p.clone() }, span_p: p_p2xzxy.span_p.clone() });
                                                    let fname_pk = field_pat_name_f(&fp_pj, &c_pbzxy.fields_p, &i_pi);
                                                    let before_pl = crate::prelude::fold(&crate::check::errors::range0_f(&i_pi), &false, &(|seen_pn: &bool, k_po: &crate::prelude::Nat| *seen_pn || (&field_pat_name_f(&crate::prelude::or(&crate::prelude::index(&fields_p4xzxy, k_po), &fp_pj), &c_pbzxy.fields_p, k_po) == &fname_pk)));
                                                    let s0_pm = if before_pl {
                                                        crate::check::types::recording::err_f(&s_ph, &crate::prelude::Text::lit("collision"), &fp_pj.span_p, &crate::prelude::Text::from(format!("`{}` is matched twice", &fname_pk)))
                                                    } else {
                                                        s_ph.clone()
                                                    };
                                                    match crate::check::expr::operators::index_of_o(&c_pbzxy.fields_p, &fname_pk) {
                                                        ::std::option::Option::Some(j_pp) => crate::prelude::call_then(start_pat_marks_f(s0_pm.clone(), crate::check::types::bare_name_f(&c_pbzxy.owner_p), fname_pk.clone(), crate::prelude::or(&crate::prelude::index(&c_pbzxy.args_p, &j_pp), &crate::check::types::Ty::TyErr), fp_pj.clone()), move |pat_marks_f_15577: crate::check::types::St| crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pfzxy.clone(), crate::prelude::or(&crate::prelude::index(&c_pbzxy.args_p, &j_pp), &crate::check::types::Ty::TyErr)), move |subst_q_f_15658: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: en_pg.clone(), st_p1: pat_marks_f_15577, p_p2: fp_pj.pattern_p.clone(), t_p3: subst_q_f_15658, refutable_p4: true })))),
                                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((en_pg.clone(), crate::check::types::recording::err_f(&s0_pm, &crate::prelude::Text::lit("mismatch"), &fp_pj.span_p, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name_f(&c_pbzxy.owner_p), &fname_pk))))),
                                                    }
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                                    }).cycle()
                                };
                                if is_failure_pattern_f_14696 {
                                    k_let14683(st1_pe.clone())
                                } else {
                                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st1_pe.clone(), t_p6x.clone(), self_pd.clone(), p_p2x.span_p.clone()), move |unify_f_14737: crate::check::types::St| k_let14683(unify_f_14737))
                                }
                            })
                        })
                    },
                }
            },
        }
    }
}

/// `Start BindRecord, x`: what the function value is when passed to `@Run`.
pub fn start_bind_record_f(env_p0: crate::check::expr::Env, st0_p1: crate::check::types::St, p_p2: crate::syntax::Pattern, n_p3: crate::syntax::SName, fields_p4: crate::prelude::Array<crate::syntax::FieldPat>, rest_p5: bool, t_p6: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(BindRecord { env_p0, st0_p1, p_p2, n_p3, fields_p4, rest_p5, t_p6 })
}

/// ```prism
/// PatMarks: unbounded fn St, Text, Text, Ty, FieldPat -> St
/// ```
pub fn pat_marks_f(st_p0: &crate::check::types::St, owner_p1: &crate::prelude::Text, field_p2: &crate::prelude::Text, declared_p3: &crate::check::types::Ty, fp_p4: &crate::syntax::FieldPat) -> crate::check::types::St {
    if &fp_p4.marks_p == &crate::prelude::Text::lit("") {
        st_p0.clone()
    } else {
        crate::check::expr::calls::arg_marks_f(st_p0, owner_p1, field_p2, declared_p3, &fp_p4.marks_p, &fp_p4.span_p)
    }
}

/// The step machine of `PatMarks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatMarks: unbounded fn St, Text, Text, Ty, FieldPat -> St
/// ```
pub struct PatMarks {
    pub st_p0: crate::check::types::St,
    pub owner_p1: crate::prelude::Text,
    pub field_p2: crate::prelude::Text,
    pub declared_p3: crate::check::types::Ty,
    pub fp_p4: crate::syntax::FieldPat,
}

impl ::prism_rtl::Job<crate::check::types::St> for PatMarks {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let owner_p1 = &self.owner_p1;
        let field_p2 = &self.field_p2;
        let declared_p3 = &self.declared_p3;
        let fp_p4 = &self.fp_p4;
        if &fp_p4.marks_p == &crate::prelude::Text::lit("") {
            ::prism_rtl::Turn::Finished(st_p0.clone())
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::calls::ArgMarks { st_p0: st_p0.clone(), owner_p1: owner_p1.clone(), field_p2: field_p2.clone(), declared_p3: declared_p3.clone(), marks_p4: fp_p4.marks_p.clone(), span_p5: fp_p4.span_p.clone() }))
        }
    }
}

/// `Start PatMarks, x`: what the function value is when passed to `@Run`.
pub fn start_pat_marks_f(st_p0: crate::check::types::St, owner_p1: crate::prelude::Text, field_p2: crate::prelude::Text, declared_p3: crate::check::types::Ty, fp_p4: crate::syntax::FieldPat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(PatMarks { st_p0, owner_p1, field_p2, declared_p3, fp_p4 })
}

/// ```prism
/// FieldPatName: fn FieldPat, [Text], Nat -> Text
/// ```
pub fn field_pat_name_f(fp_p0: &crate::syntax::FieldPat, fields_p1: &crate::prelude::Array<crate::prelude::Text>, i_p2: &crate::prelude::Nat) -> crate::prelude::Text {
    match &fp_p0.name_o {
        ::std::option::Option::Some(id_p3) => id_p3.name_p.clone(),
        ::std::option::Option::None => match &*fp_p0.pattern_p.kind_p {
            crate::syntax::PatternKind::PName(n_p4) => if crate::check::types::has_text_f(fields_p1, &crate::check::env::sname_key_f(n_p4)) {
                crate::check::env::sname_key_f(n_p4)
            } else {
                crate::prelude::or(&crate::prelude::index(fields_p1, i_p2), &crate::prelude::Text::lit(""))
            },
            _ => crate::prelude::or(&crate::prelude::index(fields_p1, i_p2), &crate::prelude::Text::lit("")),
        },
    }
}

/// ```prism
/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub fn bind_tag_pattern_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern, name_p3: &crate::prelude::Text, fields_p4: &crate::prelude::Array<crate::syntax::FieldPat>, rest_p5: &bool, t_p6: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    match crate::prelude::get(&env_p0.g_p.tags_p, name_p3) {
        ::std::option::Option::None => (env_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), &p_p2.span_p, &crate::prelude::Text::from(format!("no tag `{}`", name_p3)))),
        ::std::option::Option::Some(tg_p7) => {
            let st1_p8 = if &tg_p7.kind_p == &crate::prelude::Text::lit("Element") {
                tag_in_row_f(env_p0, st_p1, &tg_p7, t_p6, &p_p2.span_p)
            } else {
                crate::check::types::unify::unify_f(st_p1, t_p6, &crate::check::types::Ty::TyCon(tg_p7.kind_p.clone(), crate::prelude::Array::new()), &p_p2.span_p)
            };
            let snapshot_p9 = is_snapshot_f(&st1_p8, t_p6);
            let (_, st2_pb, inst_pc) = crate::check::types::schemes::instantiate_with_f(&st1_p8, &crate::check::types::Scheme { qs_p: tg_p7.qs_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: tg_p7.rqs_p.clone(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: tg_p7.out_p.clone() }, &p_p2.span_p, &crate::prelude::Array::new());
            let names_pa = crate::prelude::each(&tg_p7.fields_p, &(|(f_pd, _): &(crate::prelude::Text, crate::check::types::Ty)| f_pd.clone()));
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(fields_p4)), (env_p0.clone(), st2_pb.clone()), {
                let fields_p4x = fields_p4.clone();
                let p_p2x = p_p2.clone();
                let names_pax = names_pa.clone();
                let tg_p7x = tg_p7.clone();
                let name_p3x = name_p3.clone();
                let env_p0x = env_p0.clone();
                let snapshot_p9x = snapshot_p9;
                let inst_pcx = inst_pc.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)| {
                    let fields_p4xy = fields_p4x.clone();
                    let p_p2xy = p_p2x.clone();
                    let names_paxy = names_pax.clone();
                    let tg_p7xy = tg_p7x.clone();
                    let name_p3xy = name_p3x.clone();
                    let env_p0xy = env_p0x.clone();
                    let snapshot_p9xy = snapshot_p9x;
                    let inst_pcxy = inst_pcx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (en_pe, s_pf) = p0;
                        let i_pg = p1;
                        {
                            let fp_ph = crate::prelude::or(&crate::prelude::index(&fields_p4xy, &i_pg), &crate::syntax::FieldPat { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, pattern_p: crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2xy.span_p.clone() }, span_p: p_p2xy.span_p.clone() });
                            let fname_pi = field_pat_name_f(&fp_ph, &names_paxy, &i_pg);
                            let before_pj = crate::prelude::fold(&crate::check::errors::range0_f(&i_pg), &false, &(|seen_pl: &bool, k_pm: &crate::prelude::Nat| *seen_pl || (&field_pat_name_f(&crate::prelude::or(&crate::prelude::index(&fields_p4xy, k_pm), &fp_ph), &names_paxy, k_pm) == &fname_pi)));
                            let s0_pk = if before_pj {
                                crate::check::types::recording::err_f(&s_pf, &crate::prelude::Text::lit("collision"), &fp_ph.span_p, &crate::prelude::Text::from(format!("`{}` is matched twice", &fname_pi)))
                            } else {
                                s_pf.clone()
                            };
                            match crate::check::expr::calls::field_of_tag_o(&tg_p7xy, &fname_pi) {
                                ::std::option::Option::Some(ft_pn) => crate::prelude::call_then(start_pat_marks_f(s0_pk.clone(), name_p3xy.clone(), fname_pi.clone(), ft_pn.clone(), fp_ph.clone()), move |pat_marks_f_18121: crate::check::types::St| {
                                    let marked_po = pat_marks_f_18121;
                                    crate::prelude::call_then(start_tests_live_field_f(env_p0xy.clone(), marked_po.clone(), fp_ph.pattern_p.clone(), ft_pn.clone(), snapshot_p9xy), move |tests_live_field_f_18177: bool| if tests_live_field_f_18177 {
                                        crate::prelude::call_then(start_live_field_tested_f(env_p0xy.clone(), marked_po.clone(), fname_pi.clone(), fp_ph.pattern_p.clone(), ft_pn.clone()), move |live_field_tested_f_18458: crate::check::types::St| {
                                            let (anything_pp, s1_pq) = crate::check::types::fresh_var_f(&live_field_tested_f_18458, &false, &crate::prelude::Text::lit(""));
                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: en_pe.clone(), st_p1: s1_pq.clone(), p_p2: fp_ph.pattern_p.clone(), t_p3: anything_pp.clone(), refutable_p4: true }))
                                        })
                                    } else {
                                        crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pcxy.clone(), ft_pn.clone()), move |subst_q_f_18653: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(BindField { env_p0: en_pe.clone(), st_p1: marked_po.clone(), p_p2: fp_ph.pattern_p.clone(), ft_p3: subst_q_f_18653, snapshot_p4: snapshot_p9xy })))
                                    })
                                }),
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished((en_pe.clone(), crate::check::types::recording::err_f(&s0_pk, &crate::prelude::Text::lit("mismatch"), &fp_ph.span_p, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &name_p3xy, &fname_pi))))),
                            }
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }))
        },
    }
}

/// The step machine of `BindTagPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub struct BindTagPattern {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern,
    pub name_p3: crate::prelude::Text,
    pub fields_p4: crate::prelude::Array<crate::syntax::FieldPat>,
    pub rest_p5: bool,
    pub t_p6: crate::check::types::Ty,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindTagPattern {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let name_p3 = &self.name_p3;
        let fields_p4 = &self.fields_p4;
        let rest_p5 = &self.rest_p5;
        let t_p6 = &self.t_p6;
        match crate::prelude::get(&env_p0.g_p.tags_p, name_p3) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("unknown-name"), &p_p2.span_p, &crate::prelude::Text::from(format!("no tag `{}`", name_p3))))),
            ::std::option::Option::Some(tg_p7) => {
                let env_p0z = env_p0.clone();
                let fields_p4z = fields_p4.clone();
                let name_p3z = name_p3.clone();
                let p_p2z = p_p2.clone();
                let t_p6z = t_p6.clone();
                let tg_p7z = tg_p7.clone();
                let k_let17023 = move |v17023: crate::check::types::St| {
                    let st1_p8 = v17023;
                    crate::prelude::call_then(start_is_snapshot_f(st1_p8.clone(), t_p6z.clone()), move |is_snapshot_f_17162: bool| {
                        let snapshot_p9 = is_snapshot_f_17162;
                        crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st1_p8.clone(), crate::check::types::Scheme { qs_p: tg_p7z.qs_p.clone(), plain_qs_p: crate::prelude::Array::new(), rqs_p: tg_p7z.rqs_p.clone(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: tg_p7z.out_p.clone() }, p_p2z.span_p.clone(), crate::prelude::Array::new()), move |instantiate_with_f_17216: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                            let (_, st2_pb, inst_pc) = instantiate_with_f_17216;
                            let names_pa = crate::prelude::each(&tg_p7z.fields_p, &(|(f_pd, _): &(crate::prelude::Text, crate::check::types::Ty)| f_pd.clone()));
                            crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&fields_p4z)), (env_p0z.clone(), st2_pb.clone()), {
                                let fields_p4zx = fields_p4z.clone();
                                let p_p2zx = p_p2z.clone();
                                let names_pax = names_pa.clone();
                                let tg_p7zx = tg_p7z.clone();
                                let name_p3zx = name_p3z.clone();
                                let env_p0zx = env_p0z.clone();
                                let snapshot_p9x = snapshot_p9;
                                let inst_pcx = inst_pc.clone();
                                ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)| {
                                    let fields_p4zxy = fields_p4zx.clone();
                                    let p_p2zxy = p_p2zx.clone();
                                    let names_paxy = names_pax.clone();
                                    let tg_p7zxy = tg_p7zx.clone();
                                    let name_p3zxy = name_p3zx.clone();
                                    let env_p0zxy = env_p0zx.clone();
                                    let snapshot_p9xy = snapshot_p9x;
                                    let inst_pcxy = inst_pcx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (en_pe, s_pf) = p0;
                                        let i_pg = p1;
                                        {
                                            let fp_ph = crate::prelude::or(&crate::prelude::index(&fields_p4zxy, &i_pg), &crate::syntax::FieldPat { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, pattern_p: crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: p_p2zxy.span_p.clone() }, span_p: p_p2zxy.span_p.clone() });
                                            let fname_pi = field_pat_name_f(&fp_ph, &names_paxy, &i_pg);
                                            let before_pj = crate::prelude::fold(&crate::check::errors::range0_f(&i_pg), &false, &(|seen_pl: &bool, k_pm: &crate::prelude::Nat| *seen_pl || (&field_pat_name_f(&crate::prelude::or(&crate::prelude::index(&fields_p4zxy, k_pm), &fp_ph), &names_paxy, k_pm) == &fname_pi)));
                                            let s0_pk = if before_pj {
                                                crate::check::types::recording::err_f(&s_pf, &crate::prelude::Text::lit("collision"), &fp_ph.span_p, &crate::prelude::Text::from(format!("`{}` is matched twice", &fname_pi)))
                                            } else {
                                                s_pf.clone()
                                            };
                                            match crate::check::expr::calls::field_of_tag_o(&tg_p7zxy, &fname_pi) {
                                                ::std::option::Option::Some(ft_pn) => crate::prelude::call_then(start_pat_marks_f(s0_pk.clone(), name_p3zxy.clone(), fname_pi.clone(), ft_pn.clone(), fp_ph.clone()), move |pat_marks_f_18121: crate::check::types::St| {
                                                    let marked_po = pat_marks_f_18121;
                                                    crate::prelude::call_then(start_tests_live_field_f(env_p0zxy.clone(), marked_po.clone(), fp_ph.pattern_p.clone(), ft_pn.clone(), snapshot_p9xy), move |tests_live_field_f_18177: bool| if tests_live_field_f_18177 {
                                                        crate::prelude::call_then(start_live_field_tested_f(env_p0zxy.clone(), marked_po.clone(), fname_pi.clone(), fp_ph.pattern_p.clone(), ft_pn.clone()), move |live_field_tested_f_18458: crate::check::types::St| {
                                                            let (anything_pp, s1_pq) = crate::check::types::fresh_var_f(&live_field_tested_f_18458, &false, &crate::prelude::Text::lit(""));
                                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPattern { env_p0: en_pe.clone(), st_p1: s1_pq.clone(), p_p2: fp_ph.pattern_p.clone(), t_p3: anything_pp.clone(), refutable_p4: true }))
                                                        })
                                                    } else {
                                                        crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pcxy.clone(), ft_pn.clone()), move |subst_q_f_18653: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(BindField { env_p0: en_pe.clone(), st_p1: marked_po.clone(), p_p2: fp_ph.pattern_p.clone(), ft_p3: subst_q_f_18653, snapshot_p4: snapshot_p9xy })))
                                                    })
                                                }),
                                                ::std::option::Option::None => ::prism_rtl::Turn::Finished((en_pe.clone(), crate::check::types::recording::err_f(&s0_pk, &crate::prelude::Text::lit("mismatch"), &fp_ph.span_p, &crate::prelude::Text::from(format!("`{}` has no field `{}`", &name_p3zxy, &fname_pi))))),
                                            }
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                            }).cycle()
                        })
                    })
                };
                if &tg_p7.kind_p == &crate::prelude::Text::lit("Element") {
                    {
                        let env_p0x = env_p0.clone();
                        let p_p2x = p_p2.clone();
                        let st_p1x = st_p1.clone();
                        let t_p6x = t_p6.clone();
                        crate::prelude::call_then(start_tag_in_row_f(env_p0x.clone(), st_p1x.clone(), tg_p7.clone(), t_p6x.clone(), p_p2x.span_p.clone()), move |tag_in_row_f_17058: crate::check::types::St| k_let17023(tag_in_row_f_17058))
                    }
                } else {
                    {
                        let p_p2x = p_p2.clone();
                        let st_p1x = st_p1.clone();
                        let t_p6x = t_p6.clone();
                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x.clone(), t_p6x.clone(), crate::check::types::Ty::TyCon(tg_p7.kind_p.clone(), crate::prelude::Array::new()), p_p2x.span_p.clone()), move |unify_f_17096: crate::check::types::St| k_let17023(unify_f_17096))
                    }
                }
            },
        }
    }
}

/// `Start BindTagPattern, x`: what the function value is when passed to `@Run`.
pub fn start_bind_tag_pattern_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern, name_p3: crate::prelude::Text, fields_p4: crate::prelude::Array<crate::syntax::FieldPat>, rest_p5: bool, t_p6: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(BindTagPattern { env_p0, st_p1, p_p2, name_p3, fields_p4, rest_p5, t_p6 })
}

/// ```prism
/// IsSnapshot: unbounded fn St, Ty -> Bool
/// ```
pub fn is_snapshot_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TyElemAny(_) => true,
        _ => false,
    }
}

/// The step machine of `IsSnapshot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsSnapshot: unbounded fn St, Ty -> Bool
/// ```
pub struct IsSnapshot {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<bool> for IsSnapshot {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_18991: crate::check::types::Ty| match walk_f_18991 {
            crate::check::types::Ty::TyElemAny(_) => ::prism_rtl::Turn::Finished(true),
            _ => ::prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start IsSnapshot, x`: what the function value is when passed to `@Run`.
pub fn start_is_snapshot_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsSnapshot { st_p0, t_p1 })
}

/// ```prism
/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
/// ```
pub fn tag_in_row_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, tg_p2: &crate::check::env::TagInfo, t_p3: &crate::check::types::Ty, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk_f(st_p1, t_p3) {
        crate::check::types::Ty::TyElem(rw_p5, _) => {
            let w_p6 = crate::check::types::recording::walk_row_f(st_p1, &rw_p5);
            if crate::check::types::has_text_f(&w_p6.fams_p, &tg_p2.family_p) {
                st_p1.clone()
            } else {
                crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("row-not-here"), span_p4, &crate::prelude::Text::from(format!("`{}` is not in this row, `{}`", &tg_p2.name_p, &crate::check::types::show_row_f(&w_p6))), &crate::prelude::Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg_p2.family_p)))
            }
        },
        crate::check::types::Ty::TyElemAny(rw_p7) => {
            let w_p8 = crate::check::types::recording::walk_row_f(st_p1, &rw_p7);
            if crate::check::types::has_text_f(&w_p8.fams_p, &tg_p2.family_p) {
                st_p1.clone()
            } else {
                crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("row-not-here"), span_p4, &crate::prelude::Text::from(format!("`{}` is not in this row, `{}`", &tg_p2.name_p, &crate::check::types::show_row_f(&w_p8))), &crate::prelude::Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg_p2.family_p)))
            }
        },
        crate::check::types::Ty::TyFlex(_) => {
            let (rw_p9, st2_pa) = crate::check::types::recording::fresh_row_f(st_p1, &crate::prelude::Array::from(vec![tg_p2.family_p.clone()]));
            let (o_pb, st3_pc) = crate::check::types::fresh_var_f(&st2_pa, &false, &crate::prelude::Text::lit(""));
            crate::check::types::unify::unify_f(&st3_pc, t_p3, &crate::check::types::Ty::TyElem(crate::check::types::Rw { fams_p: crate::prelude::Array::from(vec![tg_p2.family_p.clone()]), minus_p: crate::prelude::Array::new(), tail_p: rw_p9.tail_p.clone() }, ::std::rc::Rc::new(o_pb.clone())), span_p4)
        },
        crate::check::types::Ty::TyErr => st_p1.clone(),
        other_pd => crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p4, &crate::prelude::Text::from(format!("a tag pattern matches an element; this is `{}`", &crate::check::types::show_ty_f(st_p1, &other_pd)))),
    }
}

/// The step machine of `TagInRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
/// ```
pub struct TagInRow {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub tg_p2: crate::check::env::TagInfo,
    pub t_p3: crate::check::types::Ty,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for TagInRow {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let tg_p2 = &self.tg_p2;
        let t_p3 = &self.t_p3;
        let span_p4 = &self.span_p4;
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        let t_p3x = t_p3.clone();
        let tg_p2x = tg_p2.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), t_p3x.clone()), move |walk_f_19150: crate::check::types::Ty| match walk_f_19150 {
            crate::check::types::Ty::TyElem(rw_p5, _) => crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_p5.clone()), move |walk_row_f_19201: crate::check::types::Rw| {
                let w_p6 = walk_row_f_19201;
                if crate::check::types::has_text_f(&w_p6.fams_p, &tg_p2x.family_p) {
                    ::prism_rtl::Turn::Finished(st_p1x.clone())
                } else {
                    ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("row-not-here"), &span_p4x, &crate::prelude::Text::from(format!("`{}` is not in this row, `{}`", &tg_p2x.name_p, &crate::check::types::show_row_f(&w_p6))), &crate::prelude::Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg_p2x.family_p))))
                }
            }),
            crate::check::types::Ty::TyElemAny(rw_p7) => crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_p7.clone()), move |walk_row_f_19449: crate::check::types::Rw| {
                let w_p8 = walk_row_f_19449;
                if crate::check::types::has_text_f(&w_p8.fams_p, &tg_p2x.family_p) {
                    ::prism_rtl::Turn::Finished(st_p1x.clone())
                } else {
                    ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("row-not-here"), &span_p4x, &crate::prelude::Text::from(format!("`{}` is not in this row, `{}`", &tg_p2x.name_p, &crate::check::types::show_row_f(&w_p8))), &crate::prelude::Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg_p2x.family_p))))
                }
            }),
            crate::check::types::Ty::TyFlex(_) => {
                let (rw_p9, st2_pa) = crate::check::types::recording::fresh_row_f(&st_p1x, &crate::prelude::Array::from(vec![tg_p2x.family_p.clone()]));
                let (o_pb, st3_pc) = crate::check::types::fresh_var_f(&st2_pa, &false, &crate::prelude::Text::lit(""));
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st3_pc.clone(), expected_p1: t_p3x.clone(), found_p2: crate::check::types::Ty::TyElem(crate::check::types::Rw { fams_p: crate::prelude::Array::from(vec![tg_p2x.family_p.clone()]), minus_p: crate::prelude::Array::new(), tail_p: rw_p9.tail_p.clone() }, ::std::rc::Rc::new(o_pb.clone())), span_p3: span_p4x.clone() }))
            },
            crate::check::types::Ty::TyErr => ::prism_rtl::Turn::Finished(st_p1x.clone()),
            other_pd => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), other_pd.clone()), move |show_ty_f_19971: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&st_p1x, &crate::prelude::Text::lit("mismatch"), &span_p4x, &crate::prelude::Text::from(format!("a tag pattern matches an element; this is `{}`", &show_ty_f_19971))))),
        })
    }
}

/// `Start TagInRow, x`: what the function value is when passed to `@Run`.
pub fn start_tag_in_row_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, tg_p2: crate::check::env::TagInfo, t_p3: crate::check::types::Ty, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(TagInRow { env_p0, st_p1, tg_p2, t_p3, span_p4 })
}

/// ```prism
/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
/// ```
pub fn bind_family_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fam_p2: &crate::prelude::Text, t_p3: &crate::check::types::Ty, span_p4: &crate::syntax::Range) -> (crate::check::expr::Env, crate::check::types::St) {
    match crate::check::types::recording::walk_f(st_p1, t_p3) {
        crate::check::types::Ty::TyElem(rw_p5, _) => {
            let w_p6 = crate::check::types::recording::walk_row_f(st_p1, &rw_p5);
            if crate::check::types::has_text_f(&w_p6.fams_p, fam_p2) {
                (env_p0.clone(), st_p1.clone())
            } else {
                (env_p0.clone(), crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("row-not-here"), span_p4, &crate::prelude::Text::from(format!("`{}.*` is not in this row, `{}`", fam_p2, &crate::check::types::show_row_f(&w_p6))), &crate::prelude::Text::from(format!("add `{}.*` to the row", fam_p2))))
            }
        },
        _ => (env_p0.clone(), st_p1.clone()),
    }
}

/// The step machine of `BindFamily`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
/// ```
pub struct BindFamily {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fam_p2: crate::prelude::Text,
    pub t_p3: crate::check::types::Ty,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindFamily {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fam_p2 = &self.fam_p2;
        let t_p3 = &self.t_p3;
        let span_p4 = &self.span_p4;
        let env_p0x = env_p0.clone();
        let fam_p2x = fam_p2.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        let t_p3x = t_p3.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), t_p3x.clone()), move |walk_f_20101: crate::check::types::Ty| match walk_f_20101 {
            crate::check::types::Ty::TyElem(rw_p5, _) => crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x.clone(), rw_p5.clone()), move |walk_row_f_20152: crate::check::types::Rw| {
                let w_p6 = walk_row_f_20152;
                if crate::check::types::has_text_f(&w_p6.fams_p, &fam_p2x) {
                    ::prism_rtl::Turn::Finished((env_p0x.clone(), st_p1x.clone()))
                } else {
                    ::prism_rtl::Turn::Finished((env_p0x.clone(), crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("row-not-here"), &span_p4x, &crate::prelude::Text::from(format!("`{}.*` is not in this row, `{}`", &fam_p2x, &crate::check::types::show_row_f(&w_p6))), &crate::prelude::Text::from(format!("add `{}.*` to the row", &fam_p2x)))))
                }
            }),
            _ => ::prism_rtl::Turn::Finished((env_p0x.clone(), st_p1x.clone())),
        })
    }
}

/// `Start BindFamily, x`: what the function value is when passed to `@Run`.
pub fn start_bind_family_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fam_p2: crate::prelude::Text, t_p3: crate::check::types::Ty, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(BindFamily { env_p0, st_p1, fam_p2, t_p3, span_p4 })
}
