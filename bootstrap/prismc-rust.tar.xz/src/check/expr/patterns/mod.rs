//! The module `Check.Expr.Patterns`, from `target/bootstrap/src/prismc/check/expr/patterns.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_pattern(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, t_p3: &crate::check::types::Ty, refutable_p4: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    match &*p_p2.kind {
        crate::syntax::PatternKind::PName(n_p5) => {
            let bare_p6 = or(&index(&n_p5.path_, &Nat::from(0u32)), &Text::lit(""));
            let is_ctor_p7 = (crate::check::env::is_upper_text(&bare_p6) && (&len_text(&n_p5.sigils) == &Nat::from(0u32))) && is_ctor_name(env_p0, n_p5);
            if is_ctor_p7 || (&len(&n_p5.path_) > &Nat::from(1u32)) {
                bind_ctor(env_p0, st_p1, p_p2, n_p5, &Array::new(), t_p3)
            } else {
                bind_name(env_p0, st_p1, n_p5, t_p3)
            }
        },
        crate::syntax::PatternKind::PIgnore => (env_p0.clone(), st_p1.clone()),
        crate::syntax::PatternKind::PLit(l_p8) => {
            let (lt_p9, st2_pa) = crate::check::expr::infer_lit(env_p0, st_p1, l_p8, &false, &p_p2.span);
            (env_p0.clone(), crate::check::types::unify::unify(&st2_pa, t_p3, &lt_p9, &p_p2.span))
        },
        crate::syntax::PatternKind::PNeg(l_pb) => {
            let (lt_pc, st2_pd) = crate::check::expr::infer_lit(env_p0, st_p1, l_pb, &true, &p_p2.span);
            (env_p0.clone(), crate::check::types::unify::unify(&st2_pd, t_p3, &lt_pc, &p_p2.span))
        },
        crate::syntax::PatternKind::PUnit => (env_p0.clone(), crate::check::types::unify::unify(st_p1, t_p3, &crate::check::types::t_unit(), &p_p2.span)),
        crate::syntax::PatternKind::PNil => {
            let (v_pe, st2_pf) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
            (env_p0.clone(), crate::check::types::unify::unify(&st2_pf, t_p3, &crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_pe.clone())), &p_p2.span))
        },
        crate::syntax::PatternKind::PCtor(n_pg, args_ph) => bind_ctor(env_p0, st_p1, p_p2, n_pg, args_ph, t_p3),
        crate::syntax::PatternKind::PRecord(n_pi, fields_pj, rest_pk) => bind_record(env_p0, st_p1, p_p2, n_pi, fields_pj, rest_pk, t_p3),
        crate::syntax::PatternKind::PSigil(s_pl, inner_pm) => if (s_pl == &Text::lit("?")) || (s_pl == &Text::lit("~")) {
            {
                let (v_po, st2_pp) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                let st3_pn = crate::check::types::unify::unify(&st2_pp, t_p3, &crate::check::types::Ty::TySig(s_pl.clone(), Rc::new(v_po.clone())), &p_p2.span);
                bind_pattern(env_p0, &st3_pn, &**inner_pm, &v_po, refutable_p4)
            }
        } else {
            {
                let (v_pr, st2_ps) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                let st3_pq = crate::check::types::unify::unify(&st2_ps, t_p3, &crate::check::types::with_marks(s_pl, &v_pr, &env_p0.scope), &p_p2.span);
                bind_pattern(env_p0, &st3_pq, &**inner_pm, &v_pr, refutable_p4)
            }
        },
        crate::syntax::PatternKind::PTuple(ps_pt) => {
            let (vs_p13, st2_p14) = fold(ps_pt, &(Array::new(), st_p1.clone()), &(|(acc_pv, s_p10): &(Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Pattern_| {
                let (v_p11, s2_p12) = crate::check::types::fresh_var(s_p10, &false, &Text::lit(""));
                (push(acc_pv, &v_p11), s2_p12.clone())
            }));
            let st3_pu = crate::check::types::unify::unify(&st2_p14, t_p3, &crate::check::types::Ty::TyTuple(vs_p13.clone()), &p_p2.span);
            run_to_end(fold_job(crate::check::errors::range0(&len(ps_pt)), (env_p0.clone(), st3_pu.clone()), {
                let ps_pt = ps_pt.clone();
                let p_p2 = p_p2.clone();
                let vs_p13 = vs_p13.clone();
                let refutable_p4 = *refutable_p4;
                Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                    let ps_pt = ps_pt.clone();
                    let p_p2 = p_p2.clone();
                    let vs_p13 = vs_p13.clone();
                    let refutable_p4 = refutable_p4;
                    entered(once_job(move || {
                        let (en_p15, s_p16) = p0;
                        let i_p17 = p1;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_p15.clone(), st_p1: s_p16.clone(), p_p2: or(&index(&ps_pt, &i_p17), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_p2.span.clone() }), t_p3: or(&index(&vs_p13, &i_p17), &crate::check::types::Ty::TyErr), refutable_p4 }))
                    }))
                }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }))
        },
        crate::syntax::PatternKind::PArray(ps_p18) => {
            let (v_p1a, st2_p1b) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
            let st3_p19 = crate::check::types::unify::unify(&st2_p1b, t_p3, &crate::check::types::Ty::TyArray(Rc::new(v_p1a.clone())), &p_p2.span);
            run_to_end(fold_job(ps_p18.clone(), (env_p0.clone(), st3_p19.clone()), {
                let v_p1a = v_p1a.clone();
                let refutable_p4 = *refutable_p4;
                Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern_)| {
                    let v_p1a = v_p1a.clone();
                    let refutable_p4 = refutable_p4;
                    entered(once_job(move || {
                        let (en_p1c, s_p1d) = p0;
                        let q_p1e = p1;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_p1c.clone(), st_p1: s_p1d.clone(), p_p2: q_p1e.clone(), t_p3: v_p1a.clone(), refutable_p4 }))
                    }))
                }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }))
        },
        crate::syntax::PatternKind::PGroup(q_p1f) => bind_pattern(env_p0, st_p1, &**q_p1f, t_p3, refutable_p4),
        crate::syntax::PatternKind::PFamily(q_p1g) => bind_family(env_p0, st_p1, &crate::check::env::dotted(&q_p1g.path_), t_p3, &p_p2.span),
    }
}

/// The step machine of `BindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub struct BindPattern {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub t_p3: crate::check::types::Ty,
    pub refutable_p4: bool,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let t_p3 = &self.t_p3;
        let refutable_p4 = &self.refutable_p4;
        match &*p_p2.kind {
            crate::syntax::PatternKind::PName(n_p5) => {
                let bare_p6 = or(&index(&n_p5.path_, &Nat::from(0u32)), &Text::lit(""));
                let is_ctor_p7 = (crate::check::env::is_upper_text(&bare_p6) && (&len_text(&n_p5.sigils) == &Nat::from(0u32))) && is_ctor_name(env_p0, n_p5);
                if is_ctor_p7 || (&len(&n_p5.path_) > &Nat::from(1u32)) {
                    prism_rtl::Turn::More(Rc::new(BindCtor { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), n_p3: n_p5.clone(), args_p4: Array::new(), t_p5: t_p3.clone() }))
                } else {
                    prism_rtl::Turn::More(Rc::new(BindName { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p5.clone(), t_p3: t_p3.clone() }))
                }
            },
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
            crate::syntax::PatternKind::PLit(l_p8) => {
                let env_p0 = env_p0.clone();
                let l_p8 = l_p8.clone();
                let p_p2 = p_p2.clone();
                let st_p1 = st_p1.clone();
                let t_p3 = t_p3.clone();
                call_then(crate::check::expr::start_infer_lit(env_p0.clone(), st_p1.clone(), l_p8.clone(), false, p_p2.span.clone()), move |infer_lit_1841: (crate::check::types::Ty, crate::check::types::St)| {
                    let (lt_p9, st2_pa) = infer_lit_1841;
                    call_then(crate::check::types::unify::start_unify(st2_pa.clone(), t_p3.clone(), lt_p9.clone(), p_p2.span.clone()), move |unify_1892: crate::check::types::St| prism_rtl::Turn::Finished((env_p0.clone(), unify_1892)))
                })
            },
            crate::syntax::PatternKind::PNeg(l_pb) => {
                let env_p0 = env_p0.clone();
                let l_pb = l_pb.clone();
                let p_p2 = p_p2.clone();
                let st_p1 = st_p1.clone();
                let t_p3 = t_p3.clone();
                call_then(crate::check::expr::start_infer_lit(env_p0.clone(), st_p1.clone(), l_pb.clone(), true, p_p2.span.clone()), move |infer_lit_1958: (crate::check::types::Ty, crate::check::types::St)| {
                    let (lt_pc, st2_pd) = infer_lit_1958;
                    call_then(crate::check::types::unify::start_unify(st2_pd.clone(), t_p3.clone(), lt_pc.clone(), p_p2.span.clone()), move |unify_2008: crate::check::types::St| prism_rtl::Turn::Finished((env_p0.clone(), unify_2008)))
                })
            },
            crate::syntax::PatternKind::PUnit => {
                let env_p0 = env_p0.clone();
                let p_p2 = p_p2.clone();
                let st_p1 = st_p1.clone();
                let t_p3 = t_p3.clone();
                call_then(crate::check::types::unify::start_unify(st_p1.clone(), t_p3.clone(), crate::check::types::t_unit(), p_p2.span.clone()), move |unify_2055: crate::check::types::St| prism_rtl::Turn::Finished((env_p0.clone(), unify_2055)))
            },
            crate::syntax::PatternKind::PNil => {
                let (v_pe, st2_pf) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                let env_p0 = env_p0.clone();
                let p_p2 = p_p2.clone();
                let t_p3 = t_p3.clone();
                call_then(crate::check::types::unify::start_unify(st2_pf.clone(), t_p3.clone(), crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(v_pe.clone())), p_p2.span.clone()), move |unify_2159: crate::check::types::St| prism_rtl::Turn::Finished((env_p0.clone(), unify_2159)))
            },
            crate::syntax::PatternKind::PCtor(n_pg, args_ph) => prism_rtl::Turn::More(Rc::new(BindCtor { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), n_p3: n_pg.clone(), args_p4: args_ph.clone(), t_p5: t_p3.clone() })),
            crate::syntax::PatternKind::PRecord(n_pi, fields_pj, rest_pk) => prism_rtl::Turn::More(Rc::new(BindRecord { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), n_p3: n_pi.clone(), fields_p4: fields_pj.clone(), rest_p5: *rest_pk, t_p6: t_p3.clone() })),
            crate::syntax::PatternKind::PSigil(s_pl, inner_pm) => if (s_pl == &Text::lit("?")) || (s_pl == &Text::lit("~")) {
                {
                    let (v_po, st2_pp) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                    let env_p0 = env_p0.clone();
                    let inner_pm = (**inner_pm).clone();
                    let p_p2 = p_p2.clone();
                    let refutable_p4 = *refutable_p4;
                    let s_pl = s_pl.clone();
                    let t_p3 = t_p3.clone();
                    call_then(crate::check::types::unify::start_unify(st2_pp.clone(), t_p3.clone(), crate::check::types::Ty::TySig(s_pl.clone(), Rc::new(v_po.clone())), p_p2.span.clone()), move |unify_2449: crate::check::types::St| {
                        let st3_pn = unify_2449;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: env_p0.clone(), st_p1: st3_pn.clone(), p_p2: inner_pm.clone(), t_p3: v_po.clone(), refutable_p4 }))
                    })
                }
            } else {
                {
                    let (v_pr, st2_ps) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                    let env_p0 = env_p0.clone();
                    let inner_pm = (**inner_pm).clone();
                    let p_p2 = p_p2.clone();
                    let refutable_p4 = *refutable_p4;
                    let s_pl = s_pl.clone();
                    let t_p3 = t_p3.clone();
                    call_then(crate::check::types::unify::start_unify(st2_ps.clone(), t_p3.clone(), crate::check::types::with_marks(&s_pl, &v_pr, &env_p0.scope), p_p2.span.clone()), move |unify_2626: crate::check::types::St| {
                        let st3_pq = unify_2626;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: env_p0.clone(), st_p1: st3_pq.clone(), p_p2: inner_pm.clone(), t_p3: v_pr.clone(), refutable_p4 }))
                    })
                }
            },
            crate::syntax::PatternKind::PTuple(ps_pt) => {
                let (vs_p13, st2_p14) = fold(ps_pt, &(Array::new(), st_p1.clone()), &(|(acc_pv, s_p10): &(Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::syntax::Pattern_| {
                    let (v_p11, s2_p12) = crate::check::types::fresh_var(s_p10, &false, &Text::lit(""));
                    (push(acc_pv, &v_p11), s2_p12.clone())
                }));
                let env_p0 = env_p0.clone();
                let p_p2 = p_p2.clone();
                let ps_pt = ps_pt.clone();
                let refutable_p4 = *refutable_p4;
                let t_p3 = t_p3.clone();
                call_then(crate::check::types::unify::start_unify(st2_p14.clone(), t_p3.clone(), crate::check::types::Ty::TyTuple(vs_p13.clone()), p_p2.span.clone()), move |unify_2918: crate::check::types::St| {
                    let st3_pu = unify_2918;
                    fold_job(crate::check::errors::range0(&len(&ps_pt)), (env_p0.clone(), st3_pu.clone()), {
                        let ps_pt = ps_pt.clone();
                        let p_p2 = p_p2.clone();
                        let vs_p13 = vs_p13.clone();
                        let refutable_p4 = refutable_p4;
                        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                            let ps_pt = ps_pt.clone();
                            let p_p2 = p_p2.clone();
                            let vs_p13 = vs_p13.clone();
                            let refutable_p4 = refutable_p4;
                            entered(once_job(move || {
                                let (en_p15, s_p16) = p0;
                                let i_p17 = p1;
                                prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_p15.clone(), st_p1: s_p16.clone(), p_p2: or(&index(&ps_pt, &i_p17), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_p2.span.clone() }), t_p3: or(&index(&vs_p13, &i_p17), &crate::check::types::Ty::TyErr), refutable_p4 }))
                            }))
                        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                    }).cycle()
                })
            },
            crate::syntax::PatternKind::PArray(ps_p18) => {
                let (v_p1a, st2_p1b) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                let env_p0 = env_p0.clone();
                let p_p2 = p_p2.clone();
                let ps_p18 = ps_p18.clone();
                let refutable_p4 = *refutable_p4;
                let t_p3 = t_p3.clone();
                call_then(crate::check::types::unify::start_unify(st2_p1b.clone(), t_p3.clone(), crate::check::types::Ty::TyArray(Rc::new(v_p1a.clone())), p_p2.span.clone()), move |unify_3192: crate::check::types::St| {
                    let st3_p19 = unify_3192;
                    fold_job(ps_p18.clone(), (env_p0.clone(), st3_p19.clone()), {
                        let v_p1a = v_p1a.clone();
                        let refutable_p4 = refutable_p4;
                        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern_)| {
                            let v_p1a = v_p1a.clone();
                            let refutable_p4 = refutable_p4;
                            entered(once_job(move || {
                                let (en_p1c, s_p1d) = p0;
                                let q_p1e = p1;
                                prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_p1c.clone(), st_p1: s_p1d.clone(), p_p2: q_p1e.clone(), t_p3: v_p1a.clone(), refutable_p4 }))
                            }))
                        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                    }).cycle()
                })
            },
            crate::syntax::PatternKind::PGroup(q_p1f) => prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: (**q_p1f).clone(), t_p3: t_p3.clone(), refutable_p4: *refutable_p4 })),
            crate::syntax::PatternKind::PFamily(q_p1g) => prism_rtl::Turn::More(Rc::new(BindFamily { env_p0: env_p0.clone(), st_p1: st_p1.clone(), fam_p2: crate::check::env::dotted(&q_p1g.path_), t_p3: t_p3.clone(), span_p4: p_p2.span.clone() })),
        }
    }
}

/// `Start BindPattern, x`: what the function value is when passed to `@Run`.
pub fn start_bind_pattern(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, t_p3: crate::check::types::Ty, refutable_p4: bool) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindPattern { env_p0, st_p1, p_p2, t_p3, refutable_p4 })
}

/// ```prism
/// IsCtorName: fn Env, SName -> Bool
/// ```
pub fn is_ctor_name(env_p0: &crate::check::expr::Env, n_p1: &crate::syntax::SName) -> bool {
    let (qk_o2, _) = crate::check::env::names::resolve_value(&env_p0.g, &env_p0.home, n_p1);
    match &qk_o2 {
        Some(qk_p3) => crate::check::env::has_key(&env_p0.g.ctors, qk_p3),
        None => false,
    }
}

/// ```prism
/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub fn bind_name(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, t_p3: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let name_p4 = crate::check::env::sname_key(n_p2);
    if crate::check::types::has_text(&env_p0.pending, &name_p4) {
        match get(&env_p0.locals, &name_p4) {
            Some(sc_p5) => {
                let (ok_p8, st1_p9) = crate::check::types::unify::try_unify(st_p1, &sc_p5.ty, t_p3, &n_p2.span);
                let marks_agree_p6 = (&crate::check::types::stack_of(st_p1, t_p3) == &crate::check::expr::lets::type_marks(&n_p2.sigils)) || crate::check::types::is_flex_var(st_p1, t_p3);
                let st_a_p7 = if ok_p8 {
                    st1_p9.clone()
                } else {
                    if marks_agree_p6 {
                        crate::check::types::unify::unify(st_p1, &sc_p5.ty, t_p3, &n_p2.span)
                    } else {
                        crate::check::types::recording::err_fix(st_p1, &Text::lit("mark-stack"), &n_p2.span, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name_p4, &crate::check::types::show_ty(st_p1, t_p3), &crate::check::types::stack_of(st_p1, t_p3), &crate::check::expr::lets::type_marks(&n_p2.sigils))), &Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark(&n_p2.sigils), &crate::check::types::stack_of(st_p1, t_p3), &crate::syntax::lexer::chars::drop_prefix(&name_p4, &n_p2.sigils))))
                    }
                };
                crate::check::expr::bind_local_id(env_p0, &crate::check::types::recording::note_binder(&st_a_p7, &n_p2.span, &name_p4, t_p3), &name_p4, &n_p2.span)
            },
            None => bind_fresh(env_p0, st_p1, n_p2, t_p3),
        }
    } else {
        bind_fresh(env_p0, st_p1, n_p2, t_p3)
    }
}

/// The step machine of `BindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub struct BindName {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub t_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindName {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let t_p3 = &self.t_p3;
        let name_p4 = crate::check::env::sname_key(n_p2);
        if crate::check::types::has_text(&env_p0.pending, &name_p4) {
            match get(&env_p0.locals, &name_p4) {
                Some(sc_p5) => {
                    let env_p0 = env_p0.clone();
                    let n_p2 = n_p2.clone();
                    let st_p1 = st_p1.clone();
                    let t_p3 = t_p3.clone();
                    call_then(crate::check::types::unify::start_try_unify(st_p1.clone(), sc_p5.ty.clone(), t_p3.clone(), n_p2.span.clone()), move |try_unify_3987: (bool, crate::check::types::St)| {
                        let (ok_p8, st1_p9) = try_unify_3987;
                        call_then(crate::check::types::start_stack_of(st_p1.clone(), t_p3.clone()), move |stack_of_4051: Text| {
                            let marks_agree_p6 = (&stack_of_4051 == &crate::check::expr::lets::type_marks(&n_p2.sigils)) || crate::check::types::is_flex_var(&st_p1, &t_p3);
                            let st_a_p7 = if ok_p8 {
                                st1_p9.clone()
                            } else {
                                if marks_agree_p6 {
                                    crate::check::types::unify::unify(&st_p1, &sc_p5.ty, &t_p3, &n_p2.span)
                                } else {
                                    crate::check::types::recording::err_fix(&st_p1, &Text::lit("mark-stack"), &n_p2.span, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name_p4, &crate::check::types::show_ty(&st_p1, &t_p3), &crate::check::types::stack_of(&st_p1, &t_p3), &crate::check::expr::lets::type_marks(&n_p2.sigils))), &Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark(&n_p2.sigils), &crate::check::types::stack_of(&st_p1, &t_p3), &crate::syntax::lexer::chars::drop_prefix(&name_p4, &n_p2.sigils))))
                                }
                            };
                            prism_rtl::Turn::Finished(crate::check::expr::bind_local_id(&env_p0, &crate::check::types::recording::note_binder(&st_a_p7, &n_p2.span, &name_p4, &t_p3), &name_p4, &n_p2.span))
                        })
                    })
                },
                None => prism_rtl::Turn::More(Rc::new(BindFresh { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p2.clone(), t_p3: t_p3.clone() })),
            }
        } else {
            prism_rtl::Turn::More(Rc::new(BindFresh { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p2.clone(), t_p3: t_p3.clone() }))
        }
    }
}

/// `Start BindName, x`: what the function value is when passed to `@Run`.
pub fn start_bind_name(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, t_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindName { env_p0, st_p1, n_p2, t_p3 })
}

/// ```prism
/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub fn bind_fresh(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, t_p3: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    bind_fresh_marked(env_p0, st_p1, n_p2, &crate::check::expr::lets::type_marks(&n_p2.sigils), t_p3)
}

/// The step machine of `BindFresh`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub struct BindFresh {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub t_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindFresh {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let t_p3 = &self.t_p3;
        prism_rtl::Turn::More(Rc::new(BindFreshMarked { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p2.clone(), marks_p3: crate::check::expr::lets::type_marks(&n_p2.sigils), t_p4: t_p3.clone() }))
    }
}

/// `Start BindFresh, x`: what the function value is when passed to `@Run`.
pub fn start_bind_fresh(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, t_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindFresh { env_p0, st_p1, n_p2, t_p3 })
}

/// ```prism
/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
/// ```
pub fn bind_fresh_marked(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, marks_p3: &Text, t_p4: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let name_p5 = crate::check::env::sname_key(n_p2);
    let (v_p8, st2_p9) = crate::check::types::fresh_var(st_p1, &true, &name_p5);
    let (rw_pa, st3_pb) = crate::check::types::recording::fresh_row(&st2_p9, &Array::new());
    let marked_p6 = crate::check::types::with_marks(marks_p3, &v_p8, &rw_pa);
    let (ok_pc, st4_pd) = crate::check::types::unify::try_unify(&st3_pb, t_p4, &marked_p6, &n_p2.span);
    let st5_p7 = if ok_pc {
        st4_pd.clone()
    } else {
        {
            let stack_pe = crate::check::types::stack_of(&st3_pb, t_p4);
            crate::check::types::recording::err_fix(&st3_pb, &Text::lit("mark-stack"), &n_p2.span, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name_p5, &crate::check::types::show_ty(&st3_pb, t_p4), &stack_pe, marks_p3)), &Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark(&n_p2.sigils), &stack_pe, &crate::syntax::lexer::chars::drop_prefix(&name_p5, &n_p2.sigils))))
        }
    };
    crate::check::expr::bind_local_id(&crate::check::expr::with_local(env_p0, &name_p5, &crate::check::types::schemes::mono(t_p4)), &crate::check::types::recording::note_binder(&st5_p7, &n_p2.span, &name_p5, t_p4), &name_p5, &n_p2.span)
}

/// The step machine of `BindFreshMarked`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
/// ```
pub struct BindFreshMarked {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub marks_p3: Text,
    pub t_p4: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindFreshMarked {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let marks_p3 = &self.marks_p3;
        let t_p4 = &self.t_p4;
        let name_p5 = crate::check::env::sname_key(n_p2);
        let (v_p8, st2_p9) = crate::check::types::fresh_var(st_p1, &true, &name_p5);
        let (rw_pa, st3_pb) = crate::check::types::recording::fresh_row(&st2_p9, &Array::new());
        let marked_p6 = crate::check::types::with_marks(marks_p3, &v_p8, &rw_pa);
        let env_p0 = env_p0.clone();
        let marks_p3 = marks_p3.clone();
        let n_p2 = n_p2.clone();
        let t_p4 = t_p4.clone();
        call_then(crate::check::types::unify::start_try_unify(st3_pb.clone(), t_p4.clone(), marked_p6.clone(), n_p2.span.clone()), move |try_unify_5140: (bool, crate::check::types::St)| {
            let (ok_pc, st4_pd) = try_unify_5140;
            let st5_p7 = if ok_pc {
                st4_pd.clone()
            } else {
                {
                    let stack_pe = crate::check::types::stack_of(&st3_pb, &t_p4);
                    crate::check::types::recording::err_fix(&st3_pb, &Text::lit("mark-stack"), &n_p2.span, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name_p5, &crate::check::types::show_ty(&st3_pb, &t_p4), &stack_pe, &marks_p3)), &Text::from(format!("rename to `{}{}{}`", &crate::check::expr::lets::ref_mark(&n_p2.sigils), &stack_pe, &crate::syntax::lexer::chars::drop_prefix(&name_p5, &n_p2.sigils))))
                }
            };
            prism_rtl::Turn::Finished(crate::check::expr::bind_local_id(&crate::check::expr::with_local(&env_p0, &name_p5, &crate::check::types::schemes::mono(&t_p4)), &crate::check::types::recording::note_binder(&st5_p7, &n_p2.span, &name_p5, &t_p4), &name_p5, &n_p2.span))
        })
    }
}

/// `Start BindFreshMarked, x`: what the function value is when passed to `@Run`.
pub fn start_bind_fresh_marked(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, marks_p3: Text, t_p4: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindFreshMarked { env_p0, st_p1, n_p2, marks_p3, t_p4 })
}

/// ```prism
/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_field(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, ft_p3: &crate::check::types::Ty, snapshot_p4: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    match crate::check::types::recording::walk(st_p1, ft_p3) {
        crate::check::types::Ty::TySig(s_p5, level_p6) if (*snapshot_p4 && (&s_p5 == &Text::lit("$"))) => bind_level(env_p0, st_p1, p_p2, &*level_p6),
        _ => bind_pattern(env_p0, st_p1, p_p2, ft_p3, &true),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BindField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub struct BindField {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub ft_p3: crate::check::types::Ty,
    pub snapshot_p4: bool,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindField {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let ft_p3 = &self.ft_p3;
        let snapshot_p4 = &self.snapshot_p4;
        let env_p0 = env_p0.clone();
        let ft_p3 = ft_p3.clone();
        let p_p2 = p_p2.clone();
        let snapshot_p4 = *snapshot_p4;
        let st_p1 = st_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p1.clone(), ft_p3.clone()), move |walk_6089: crate::check::types::Ty| match walk_6089 {
            crate::check::types::Ty::TySig(s_p5, level_p6) if (snapshot_p4 && (&s_p5 == &Text::lit("$"))) => prism_rtl::Turn::More(Rc::new(BindLevel { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), level_p3: (*level_p6).clone() })),
            _ => prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), t_p3: ft_p3.clone(), refutable_p4: true })),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start BindField, x`: what the function value is when passed to `@Run`.
pub fn start_bind_field(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, ft_p3: crate::check::types::Ty, snapshot_p4: bool) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindField { env_p0, st_p1, p_p2, ft_p3, snapshot_p4 })
}

/// ```prism
/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
/// ```
pub fn bind_level(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, level_p3: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    match &*p_p2.kind {
        crate::syntax::PatternKind::PName(n_p4) => if crate::syntax::lexer::chars::has_prefix(&n_p4.sigils, &Text::lit("$")) && (&len(&n_p4.path_) == &Nat::from(1u32)) {
            bind_fresh_marked(env_p0, st_p1, n_p4, &crate::syntax::lexer::chars::after_first(&n_p4.sigils), level_p3)
        } else {
            bind_pattern(env_p0, st_p1, p_p2, level_p3, &true)
        },
        crate::syntax::PatternKind::PGroup(q_p5) => bind_level(env_p0, st_p1, &**q_p5, level_p3),
        _ => bind_pattern(env_p0, st_p1, p_p2, level_p3, &true),
    }
}

/// The step machine of `BindLevel`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
/// ```
pub struct BindLevel {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub level_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindLevel {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let level_p3 = &self.level_p3;
        match &*p_p2.kind {
            crate::syntax::PatternKind::PName(n_p4) => if crate::syntax::lexer::chars::has_prefix(&n_p4.sigils, &Text::lit("$")) && (&len(&n_p4.path_) == &Nat::from(1u32)) {
                prism_rtl::Turn::More(Rc::new(BindFreshMarked { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p4.clone(), marks_p3: crate::syntax::lexer::chars::after_first(&n_p4.sigils), t_p4: level_p3.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), t_p3: level_p3.clone(), refutable_p4: true }))
            },
            crate::syntax::PatternKind::PGroup(q_p5) => prism_rtl::Turn::More(Rc::new(BindLevel { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: (**q_p5).clone(), level_p3: level_p3.clone() })),
            _ => prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), t_p3: level_p3.clone(), refutable_p4: true })),
        }
    }
}

/// `Start BindLevel, x`: what the function value is when passed to `@Run`.
pub fn start_bind_level(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, level_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindLevel { env_p0, st_p1, p_p2, level_p3 })
}

/// ```prism
/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
/// ```
pub fn bind_ctor(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, n_p3: &crate::syntax::SName, args_p4: &Array<crate::syntax::Pattern_>, t_p5: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let (qk_o6, why_p7) = crate::check::env::names::resolve_value(&env_p0.g, &env_p0.home, n_p3);
    match &qk_o6 {
        None => (env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), &n_p3.span, &Text::from(format!("no constructor `{}`", &crate::check::env::sname_key(n_p3))))),
        Some(qk_p8) => if &why_p7 == &Text::lit("tag") {
            bind_tag_pattern(env_p0, st_p1, p_p2, qk_p8, &Array::new(), &true, t_p5)
        } else {
            match get(&env_p0.g.ctors, qk_p8) {
                None => (env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), &n_p3.span, &Text::from(format!("`{}` is not a constructor", &crate::check::env::sname_key(n_p3))))),
                Some(c_p9) => {
                    let (self_pb, st1_pc, inst_pd) = crate::check::types::schemes::instantiate_with(st_p1, &crate::check::types::Scheme { qs: c_p9.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c_p9.ty.clone() }, &p_p2.span, &Array::new());
                    let st2_pa = crate::check::types::unify::unify(&st1_pc, t_p5, &self_pb, &p_p2.span);
                    if (&len(args_p4) != &len(&c_p9.args)) && !((&len(args_p4) == &Nat::from(1u32)) && (&len(&c_p9.args) > &Nat::from(1u32))) {
                        (env_p0.clone(), crate::check::types::recording::err(&st2_pa, &Text::lit("mismatch"), &p_p2.span, &Text::from(format!("`{}` takes {} argument{}; this pattern gives {}", &crate::check::types::bare_name(&c_p9.name), &crate::check::errors::count_word(&len(&c_p9.args)), &(if &len(&c_p9.args) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(args_p4))))))
                    } else {
                        run_to_end(fold_job(crate::check::errors::range0(&len(args_p4)), (env_p0.clone(), st2_pa.clone()), {
                            let args_p4 = args_p4.clone();
                            let p_p2 = p_p2.clone();
                            let inst_pd = inst_pd.clone();
                            let c_p9 = c_p9.clone();
                            Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                                let args_p4 = args_p4.clone();
                                let p_p2 = p_p2.clone();
                                let inst_pd = inst_pd.clone();
                                let c_p9 = c_p9.clone();
                                entered(once_job(move || {
                                    let (en_pe, s_pf) = p0;
                                    let i_pg = p1;
                                    call_then(crate::check::types::schemes::start_subst_q(inst_pd.clone(), or(&index(&c_p9.args, &i_pg), &crate::check::types::Ty::TyErr)), move |subst_q_7811: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_pe.clone(), st_p1: s_pf.clone(), p_p2: or(&index(&args_p4, &i_pg), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_p2.span.clone() }), t_p3: subst_q_7811, refutable_p4: true })))
                                }))
                            }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                        }))
                    }
                },
            }
        },
    }
}

/// The step machine of `BindCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
/// ```
pub struct BindCtor {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub n_p3: crate::syntax::SName,
    pub args_p4: Array<crate::syntax::Pattern_>,
    pub t_p5: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindCtor {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let n_p3 = &self.n_p3;
        let args_p4 = &self.args_p4;
        let t_p5 = &self.t_p5;
        let (qk_o6, why_p7) = crate::check::env::names::resolve_value(&env_p0.g, &env_p0.home, n_p3);
        match &qk_o6 {
            None => prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), &n_p3.span, &Text::from(format!("no constructor `{}`", &crate::check::env::sname_key(n_p3)))))),
            Some(qk_p8) => if &why_p7 == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(BindTagPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), name_p3: qk_p8.clone(), fields_p4: Array::new(), rest_p5: true, t_p6: t_p5.clone() }))
            } else {
                match get(&env_p0.g.ctors, qk_p8) {
                    None => prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), &n_p3.span, &Text::from(format!("`{}` is not a constructor", &crate::check::env::sname_key(n_p3)))))),
                    Some(c_p9) => {
                        let args_p4 = args_p4.clone();
                        let env_p0 = env_p0.clone();
                        let p_p2 = p_p2.clone();
                        let st_p1 = st_p1.clone();
                        let t_p5 = t_p5.clone();
                        call_then(crate::check::types::schemes::start_instantiate_with(st_p1.clone(), crate::check::types::Scheme { qs: c_p9.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c_p9.ty.clone() }, p_p2.span.clone(), Array::new()), move |instantiate_with_7174: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                            let (self_pb, st1_pc, inst_pd) = instantiate_with_7174;
                            call_then(crate::check::types::unify::start_unify(st1_pc.clone(), t_p5.clone(), self_pb.clone(), p_p2.span.clone()), move |unify_7329: crate::check::types::St| {
                                let st2_pa = unify_7329;
                                if (&len(&args_p4) != &len(&c_p9.args)) && !((&len(&args_p4) == &Nat::from(1u32)) && (&len(&c_p9.args) > &Nat::from(1u32))) {
                                    prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err(&st2_pa, &Text::lit("mismatch"), &p_p2.span, &Text::from(format!("`{}` takes {} argument{}; this pattern gives {}", &crate::check::types::bare_name(&c_p9.name), &crate::check::errors::count_word(&len(&c_p9.args)), &(if &len(&c_p9.args) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(&args_p4)))))))
                                } else {
                                    fold_job(crate::check::errors::range0(&len(&args_p4)), (env_p0.clone(), st2_pa.clone()), {
                                        let args_p4 = args_p4.clone();
                                        let p_p2 = p_p2.clone();
                                        let inst_pd = inst_pd.clone();
                                        let c_p9 = c_p9.clone();
                                        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                                            let args_p4 = args_p4.clone();
                                            let p_p2 = p_p2.clone();
                                            let inst_pd = inst_pd.clone();
                                            let c_p9 = c_p9.clone();
                                            entered(once_job(move || {
                                                let (en_pe, s_pf) = p0;
                                                let i_pg = p1;
                                                call_then(crate::check::types::schemes::start_subst_q(inst_pd.clone(), or(&index(&c_p9.args, &i_pg), &crate::check::types::Ty::TyErr)), move |subst_q_7811: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_pe.clone(), st_p1: s_pf.clone(), p_p2: or(&index(&args_p4, &i_pg), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_p2.span.clone() }), t_p3: subst_q_7811, refutable_p4: true })))
                                            }))
                                        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                                    }).cycle()
                                }
                            })
                        })
                    },
                }
            },
        }
    }
}

/// `Start BindCtor, x`: what the function value is when passed to `@Run`.
pub fn start_bind_ctor(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, n_p3: crate::syntax::SName, args_p4: Array<crate::syntax::Pattern_>, t_p5: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindCtor { env_p0, st_p1, p_p2, n_p3, args_p4, t_p5 })
}

/// ```prism
/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub fn bind_record(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, n_p3: &crate::syntax::SName, fields_p4: &Array<crate::syntax::FieldPat>, rest_p5: &bool, t_p6: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    let (qk_o7, why_p8) = crate::check::env::names::resolve_value(&env_p0.g, &env_p0.home, n_p3);
    match &qk_o7 {
        None => (env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), &n_p3.span, &Text::from(format!("no record or tag `{}`", &crate::check::env::sname_key(n_p3))))),
        Some(qk_p9) => if &why_p8 == &Text::lit("tag") {
            bind_tag_pattern(env_p0, st_p1, p_p2, qk_p9, fields_p4, rest_p5, t_p6)
        } else {
            match get(&env_p0.g.ctors, qk_p9) {
                None => (env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), &n_p3.span, &Text::from(format!("`{}` is not a record", &crate::check::env::sname_key(n_p3))))),
                Some(c_pa) => {
                    let (self_pc, st1_pd, inst_pe) = crate::check::types::schemes::instantiate_with(st_p1, &crate::check::types::Scheme { qs: c_pa.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c_pa.ty.clone() }, &p_p2.span, &Array::new());
                    let st2_pb = crate::check::types::unify::unify(&st1_pd, t_p6, &self_pc, &p_p2.span);
                    run_to_end(fold_job(crate::check::errors::range0(&len(fields_p4)), (env_p0.clone(), st2_pb.clone()), {
                        let fields_p4 = fields_p4.clone();
                        let p_p2 = p_p2.clone();
                        let c_pa = c_pa.clone();
                        let inst_pe = inst_pe.clone();
                        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                            let fields_p4 = fields_p4.clone();
                            let p_p2 = p_p2.clone();
                            let c_pa = c_pa.clone();
                            let inst_pe = inst_pe.clone();
                            entered(once_job(move || {
                                let (en_pf, s_pg) = p0;
                                let i_ph = p1;
                                {
                                    let fp_pi = or(&index(&fields_p4, &i_ph), &crate::syntax::FieldPat { name: None, pattern: crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_p2.span.clone() }, span: p_p2.span.clone() });
                                    let fname_pj = field_pat_name(&fp_pi, &c_pa.fields, &i_ph);
                                    match crate::check::expr::operators::index_of(&c_pa.fields, &fname_pj) {
                                        Some(j_pk) => call_then(crate::check::types::schemes::start_subst_q(inst_pe.clone(), or(&index(&c_pa.args, &j_pk), &crate::check::types::Ty::TyErr)), move |subst_q_9164: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_pf.clone(), st_p1: s_pg.clone(), p_p2: fp_pi.pattern.clone(), t_p3: subst_q_9164, refutable_p4: true }))),
                                        None => prism_rtl::Turn::Finished((en_pf.clone(), crate::check::types::recording::err(&s_pg, &Text::lit("mismatch"), &fp_pi.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&c_pa.owner), &fname_pj))))),
                                    }
                                }
                            }))
                        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                    }))
                },
            }
        },
    }
}

/// The step machine of `BindRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub struct BindRecord {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub n_p3: crate::syntax::SName,
    pub fields_p4: Array<crate::syntax::FieldPat>,
    pub rest_p5: bool,
    pub t_p6: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindRecord {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let n_p3 = &self.n_p3;
        let fields_p4 = &self.fields_p4;
        let rest_p5 = &self.rest_p5;
        let t_p6 = &self.t_p6;
        let (qk_o7, why_p8) = crate::check::env::names::resolve_value(&env_p0.g, &env_p0.home, n_p3);
        match &qk_o7 {
            None => prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), &n_p3.span, &Text::from(format!("no record or tag `{}`", &crate::check::env::sname_key(n_p3)))))),
            Some(qk_p9) => if &why_p8 == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(BindTagPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), name_p3: qk_p9.clone(), fields_p4: fields_p4.clone(), rest_p5: *rest_p5, t_p6: t_p6.clone() }))
            } else {
                match get(&env_p0.g.ctors, qk_p9) {
                    None => prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), &n_p3.span, &Text::from(format!("`{}` is not a record", &crate::check::env::sname_key(n_p3)))))),
                    Some(c_pa) => {
                        let env_p0 = env_p0.clone();
                        let fields_p4 = fields_p4.clone();
                        let p_p2 = p_p2.clone();
                        let st_p1 = st_p1.clone();
                        let t_p6 = t_p6.clone();
                        call_then(crate::check::types::schemes::start_instantiate_with(st_p1.clone(), crate::check::types::Scheme { qs: c_pa.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c_pa.ty.clone() }, p_p2.span.clone(), Array::new()), move |instantiate_with_8595: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                            let (self_pc, st1_pd, inst_pe) = instantiate_with_8595;
                            call_then(crate::check::types::unify::start_unify(st1_pd.clone(), t_p6.clone(), self_pc.clone(), p_p2.span.clone()), move |unify_8750: crate::check::types::St| {
                                let st2_pb = unify_8750;
                                fold_job(crate::check::errors::range0(&len(&fields_p4)), (env_p0.clone(), st2_pb.clone()), {
                                    let fields_p4 = fields_p4.clone();
                                    let p_p2 = p_p2.clone();
                                    let c_pa = c_pa.clone();
                                    let inst_pe = inst_pe.clone();
                                    Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                                        let fields_p4 = fields_p4.clone();
                                        let p_p2 = p_p2.clone();
                                        let c_pa = c_pa.clone();
                                        let inst_pe = inst_pe.clone();
                                        entered(once_job(move || {
                                            let (en_pf, s_pg) = p0;
                                            let i_ph = p1;
                                            {
                                                let fp_pi = or(&index(&fields_p4, &i_ph), &crate::syntax::FieldPat { name: None, pattern: crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_p2.span.clone() }, span: p_p2.span.clone() });
                                                let fname_pj = field_pat_name(&fp_pi, &c_pa.fields, &i_ph);
                                                match crate::check::expr::operators::index_of(&c_pa.fields, &fname_pj) {
                                                    Some(j_pk) => call_then(crate::check::types::schemes::start_subst_q(inst_pe.clone(), or(&index(&c_pa.args, &j_pk), &crate::check::types::Ty::TyErr)), move |subst_q_9164: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env_p0: en_pf.clone(), st_p1: s_pg.clone(), p_p2: fp_pi.pattern.clone(), t_p3: subst_q_9164, refutable_p4: true }))),
                                                    None => prism_rtl::Turn::Finished((en_pf.clone(), crate::check::types::recording::err(&s_pg, &Text::lit("mismatch"), &fp_pi.span, &Text::from(format!("`{}` has no field `{}`", &crate::check::types::bare_name(&c_pa.owner), &fname_pj))))),
                                                }
                                            }
                                        }))
                                    }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                                }).cycle()
                            })
                        })
                    },
                }
            },
        }
    }
}

/// `Start BindRecord, x`: what the function value is when passed to `@Run`.
pub fn start_bind_record(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, n_p3: crate::syntax::SName, fields_p4: Array<crate::syntax::FieldPat>, rest_p5: bool, t_p6: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindRecord { env_p0, st_p1, p_p2, n_p3, fields_p4, rest_p5, t_p6 })
}

/// ```prism
/// FieldPatName: fn FieldPat, [Text], Nat -> Text
/// ```
pub fn field_pat_name(fp_p0: &crate::syntax::FieldPat, fields_p1: &Array<Text>, i_p2: &Nat) -> Text {
    match &fp_p0.name {
        Some(id_p3) => id_p3.name.clone(),
        None => match &*fp_p0.pattern.kind {
            crate::syntax::PatternKind::PName(n_p4) => if crate::check::types::has_text(fields_p1, &crate::check::env::sname_key(n_p4)) {
                crate::check::env::sname_key(n_p4)
            } else {
                or(&index(fields_p1, i_p2), &Text::lit(""))
            },
            _ => or(&index(fields_p1, i_p2), &Text::lit("")),
        },
    }
}

/// ```prism
/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub fn bind_tag_pattern(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, name_p3: &Text, fields_p4: &Array<crate::syntax::FieldPat>, rest_p5: &bool, t_p6: &crate::check::types::Ty) -> (crate::check::expr::Env, crate::check::types::St) {
    match get(&env_p0.g.tags, name_p3) {
        None => (env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), &p_p2.span, &Text::from(format!("no tag `{}`", name_p3)))),
        Some(tg_p7) => {
            let st1_p8 = if &tg_p7.kind == &Text::lit("Element") {
                tag_in_row(env_p0, st_p1, &tg_p7, t_p6, &p_p2.span)
            } else {
                crate::check::types::unify::unify(st_p1, t_p6, &crate::check::types::Ty::TyCon(tg_p7.kind.clone(), Array::new()), &p_p2.span)
            };
            let snapshot_p9 = is_snapshot(&st1_p8, t_p6);
            let (_, st2_pb, inst_pc) = crate::check::types::schemes::instantiate_with(&st1_p8, &crate::check::types::Scheme { qs: tg_p7.qs.clone(), plain_qs: Array::new(), rqs: tg_p7.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: tg_p7.out.clone() }, &p_p2.span, &Array::new());
            let names_pa = each(&tg_p7.fields, &(|(f_pd, _): &(Text, crate::check::types::Ty)| f_pd.clone()));
            run_to_end(fold_job(crate::check::errors::range0(&len(fields_p4)), (env_p0.clone(), st2_pb.clone()), {
                let fields_p4 = fields_p4.clone();
                let p_p2 = p_p2.clone();
                let names_pa = names_pa.clone();
                let tg_p7 = tg_p7.clone();
                let inst_pc = inst_pc.clone();
                let snapshot_p9 = snapshot_p9;
                let name_p3 = name_p3.clone();
                Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                    let fields_p4 = fields_p4.clone();
                    let p_p2 = p_p2.clone();
                    let names_pa = names_pa.clone();
                    let tg_p7 = tg_p7.clone();
                    let inst_pc = inst_pc.clone();
                    let snapshot_p9 = snapshot_p9;
                    let name_p3 = name_p3.clone();
                    entered(once_job(move || {
                        let (en_pe, s_pf) = p0;
                        let i_pg = p1;
                        {
                            let fp_ph = or(&index(&fields_p4, &i_pg), &crate::syntax::FieldPat { name: None, pattern: crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_p2.span.clone() }, span: p_p2.span.clone() });
                            let fname_pi = field_pat_name(&fp_ph, &names_pa, &i_pg);
                            match crate::check::expr::calls::field_of_tag(&tg_p7, &fname_pi) {
                                Some(ft_pj) => call_then(crate::check::types::schemes::start_subst_q(inst_pc.clone(), ft_pj.clone()), move |subst_q_10850: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindField { env_p0: en_pe.clone(), st_p1: s_pf.clone(), p_p2: fp_ph.pattern.clone(), ft_p3: subst_q_10850, snapshot_p4: snapshot_p9 }))),
                                None => prism_rtl::Turn::Finished((en_pe.clone(), crate::check::types::recording::err(&s_pf, &Text::lit("mismatch"), &fp_ph.span, &Text::from(format!("`{}` has no field `{}`", &name_p3, &fname_pi))))),
                            }
                        }
                    }))
                }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }))
        },
    }
}

/// The step machine of `BindTagPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub struct BindTagPattern {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub name_p3: Text,
    pub fields_p4: Array<crate::syntax::FieldPat>,
    pub rest_p5: bool,
    pub t_p6: crate::check::types::Ty,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindTagPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let name_p3 = &self.name_p3;
        let fields_p4 = &self.fields_p4;
        let rest_p5 = &self.rest_p5;
        let t_p6 = &self.t_p6;
        match get(&env_p0.g.tags, name_p3) {
            None => prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("unknown-name"), &p_p2.span, &Text::from(format!("no tag `{}`", name_p3))))),
            Some(tg_p7) => {
                let st1_p8 = if &tg_p7.kind == &Text::lit("Element") {
                    tag_in_row(env_p0, st_p1, &tg_p7, t_p6, &p_p2.span)
                } else {
                    crate::check::types::unify::unify(st_p1, t_p6, &crate::check::types::Ty::TyCon(tg_p7.kind.clone(), Array::new()), &p_p2.span)
                };
                let env_p0 = env_p0.clone();
                let fields_p4 = fields_p4.clone();
                let name_p3 = name_p3.clone();
                let p_p2 = p_p2.clone();
                let t_p6 = t_p6.clone();
                call_then(start_is_snapshot(st1_p8.clone(), t_p6.clone()), move |is_snapshot_10294: bool| {
                    let snapshot_p9 = is_snapshot_10294;
                    call_then(crate::check::types::schemes::start_instantiate_with(st1_p8.clone(), crate::check::types::Scheme { qs: tg_p7.qs.clone(), plain_qs: Array::new(), rqs: tg_p7.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: tg_p7.out.clone() }, p_p2.span.clone(), Array::new()), move |instantiate_with_10348: (crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst)| {
                        let (_, st2_pb, inst_pc) = instantiate_with_10348;
                        let names_pa = each(&tg_p7.fields, &(|(f_pd, _): &(Text, crate::check::types::Ty)| f_pd.clone()));
                        fold_job(crate::check::errors::range0(&len(&fields_p4)), (env_p0.clone(), st2_pb.clone()), {
                            let fields_p4 = fields_p4.clone();
                            let p_p2 = p_p2.clone();
                            let names_pa = names_pa.clone();
                            let tg_p7 = tg_p7.clone();
                            let inst_pc = inst_pc.clone();
                            let snapshot_p9 = snapshot_p9;
                            let name_p3 = name_p3.clone();
                            Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                                let fields_p4 = fields_p4.clone();
                                let p_p2 = p_p2.clone();
                                let names_pa = names_pa.clone();
                                let tg_p7 = tg_p7.clone();
                                let inst_pc = inst_pc.clone();
                                let snapshot_p9 = snapshot_p9;
                                let name_p3 = name_p3.clone();
                                entered(once_job(move || {
                                    let (en_pe, s_pf) = p0;
                                    let i_pg = p1;
                                    {
                                        let fp_ph = or(&index(&fields_p4, &i_pg), &crate::syntax::FieldPat { name: None, pattern: crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: p_p2.span.clone() }, span: p_p2.span.clone() });
                                        let fname_pi = field_pat_name(&fp_ph, &names_pa, &i_pg);
                                        match crate::check::expr::calls::field_of_tag(&tg_p7, &fname_pi) {
                                            Some(ft_pj) => call_then(crate::check::types::schemes::start_subst_q(inst_pc.clone(), ft_pj.clone()), move |subst_q_10850: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(BindField { env_p0: en_pe.clone(), st_p1: s_pf.clone(), p_p2: fp_ph.pattern.clone(), ft_p3: subst_q_10850, snapshot_p4: snapshot_p9 }))),
                                            None => prism_rtl::Turn::Finished((en_pe.clone(), crate::check::types::recording::err(&s_pf, &Text::lit("mismatch"), &fp_ph.span, &Text::from(format!("`{}` has no field `{}`", &name_p3, &fname_pi))))),
                                        }
                                    }
                                }))
                            }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                        }).cycle()
                    })
                })
            },
        }
    }
}

/// `Start BindTagPattern, x`: what the function value is when passed to `@Run`.
pub fn start_bind_tag_pattern(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, name_p3: Text, fields_p4: Array<crate::syntax::FieldPat>, rest_p5: bool, t_p6: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindTagPattern { env_p0, st_p1, p_p2, name_p3, fields_p4, rest_p5, t_p6 })
}

/// ```prism
/// IsSnapshot: unbounded fn St, Ty -> Bool
/// ```
pub fn is_snapshot(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk(st_p0, t_p1) {
        crate::check::types::Ty::TyElemAny(_) => true,
        _ => false,
    }
}

/// The step machine of `IsSnapshot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsSnapshot: unbounded fn St, Ty -> Bool
/// ```
pub struct IsSnapshot {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for IsSnapshot {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), t_p1.clone()), move |walk_11187: crate::check::types::Ty| match walk_11187 {
            crate::check::types::Ty::TyElemAny(_) => prism_rtl::Turn::Finished(true),
            _ => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start IsSnapshot, x`: what the function value is when passed to `@Run`.
pub fn start_is_snapshot(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsSnapshot { st_p0, t_p1 })
}

/// ```prism
/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
/// ```
pub fn tag_in_row(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, tg_p2: &crate::check::env::TagInfo, t_p3: &crate::check::types::Ty, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk(st_p1, t_p3) {
        crate::check::types::Ty::TyElem(rw_p5, _) => {
            let w_p6 = crate::check::types::recording::walk_row(st_p1, &rw_p5);
            if crate::check::types::has_text(&w_p6.fams, &tg_p2.family) {
                st_p1.clone()
            } else {
                crate::check::types::recording::err_fix(st_p1, &Text::lit("row-not-here"), span_p4, &Text::from(format!("`{}` is not in this row, `{}`", &tg_p2.name, &crate::check::types::show_row(&w_p6))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg_p2.family)))
            }
        },
        crate::check::types::Ty::TyElemAny(rw_p7) => {
            let w_p8 = crate::check::types::recording::walk_row(st_p1, &rw_p7);
            if crate::check::types::has_text(&w_p8.fams, &tg_p2.family) {
                st_p1.clone()
            } else {
                crate::check::types::recording::err_fix(st_p1, &Text::lit("row-not-here"), span_p4, &Text::from(format!("`{}` is not in this row, `{}`", &tg_p2.name, &crate::check::types::show_row(&w_p8))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg_p2.family)))
            }
        },
        crate::check::types::Ty::TyFlex(_) => {
            let (rw_p9, st2_pa) = crate::check::types::recording::fresh_row(st_p1, &Array::from(vec![tg_p2.family.clone()]));
            let (o_pb, st3_pc) = crate::check::types::fresh_var(&st2_pa, &false, &Text::lit(""));
            crate::check::types::unify::unify(&st3_pc, t_p3, &crate::check::types::Ty::TyElem(crate::check::types::Rw { fams: Array::from(vec![tg_p2.family.clone()]), minus: Array::new(), tail: rw_p9.tail.clone() }, Rc::new(o_pb.clone())), span_p4)
        },
        crate::check::types::Ty::TyErr => st_p1.clone(),
        other_pd => crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), span_p4, &Text::from(format!("a tag pattern matches an element; this is `{}`", &crate::check::types::show_ty(st_p1, &other_pd)))),
    }
}

/// The step machine of `TagInRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
/// ```
pub struct TagInRow {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub tg_p2: crate::check::env::TagInfo,
    pub t_p3: crate::check::types::Ty,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for TagInRow {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let tg_p2 = &self.tg_p2;
        let t_p3 = &self.t_p3;
        let span_p4 = &self.span_p4;
        let span_p4 = span_p4.clone();
        let st_p1 = st_p1.clone();
        let t_p3 = t_p3.clone();
        let tg_p2 = tg_p2.clone();
        call_then(crate::check::types::recording::start_walk(st_p1.clone(), t_p3.clone()), move |walk_11346: crate::check::types::Ty| match walk_11346 {
            crate::check::types::Ty::TyElem(rw_p5, _) => call_then(crate::check::types::recording::start_walk_row(st_p1.clone(), rw_p5.clone()), move |walk_row_11397: crate::check::types::Rw| {
                let w_p6 = walk_row_11397;
                if crate::check::types::has_text(&w_p6.fams, &tg_p2.family) {
                    prism_rtl::Turn::Finished(st_p1.clone())
                } else {
                    prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st_p1, &Text::lit("row-not-here"), &span_p4, &Text::from(format!("`{}` is not in this row, `{}`", &tg_p2.name, &crate::check::types::show_row(&w_p6))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg_p2.family))))
                }
            }),
            crate::check::types::Ty::TyElemAny(rw_p7) => call_then(crate::check::types::recording::start_walk_row(st_p1.clone(), rw_p7.clone()), move |walk_row_11645: crate::check::types::Rw| {
                let w_p8 = walk_row_11645;
                if crate::check::types::has_text(&w_p8.fams, &tg_p2.family) {
                    prism_rtl::Turn::Finished(st_p1.clone())
                } else {
                    prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st_p1, &Text::lit("row-not-here"), &span_p4, &Text::from(format!("`{}` is not in this row, `{}`", &tg_p2.name, &crate::check::types::show_row(&w_p8))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg_p2.family))))
                }
            }),
            crate::check::types::Ty::TyFlex(_) => {
                let (rw_p9, st2_pa) = crate::check::types::recording::fresh_row(&st_p1, &Array::from(vec![tg_p2.family.clone()]));
                let (o_pb, st3_pc) = crate::check::types::fresh_var(&st2_pa, &false, &Text::lit(""));
                prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st3_pc.clone(), expected_p1: t_p3.clone(), found_p2: crate::check::types::Ty::TyElem(crate::check::types::Rw { fams: Array::from(vec![tg_p2.family.clone()]), minus: Array::new(), tail: rw_p9.tail.clone() }, Rc::new(o_pb.clone())), span_p3: span_p4.clone() }))
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished(st_p1.clone()),
            other_pd => call_then(crate::check::types::start_show_ty(st_p1.clone(), other_pd.clone()), move |show_ty_12167: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err(&st_p1, &Text::lit("mismatch"), &span_p4, &Text::from(format!("a tag pattern matches an element; this is `{}`", &show_ty_12167))))),
        })
    }
}

/// `Start TagInRow, x`: what the function value is when passed to `@Run`.
pub fn start_tag_in_row(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, tg_p2: crate::check::env::TagInfo, t_p3: crate::check::types::Ty, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(TagInRow { env_p0, st_p1, tg_p2, t_p3, span_p4 })
}

/// ```prism
/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
/// ```
pub fn bind_family(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, fam_p2: &Text, t_p3: &crate::check::types::Ty, span_p4: &crate::syntax::Range) -> (crate::check::expr::Env, crate::check::types::St) {
    match crate::check::types::recording::walk(st_p1, t_p3) {
        crate::check::types::Ty::TyElem(rw_p5, _) => {
            let w_p6 = crate::check::types::recording::walk_row(st_p1, &rw_p5);
            if crate::check::types::has_text(&w_p6.fams, fam_p2) {
                (env_p0.clone(), st_p1.clone())
            } else {
                (env_p0.clone(), crate::check::types::recording::err_fix(st_p1, &Text::lit("row-not-here"), span_p4, &Text::from(format!("`{}.*` is not in this row, `{}`", fam_p2, &crate::check::types::show_row(&w_p6))), &Text::from(format!("add `{}.*` to the row", fam_p2))))
            }
        },
        _ => (env_p0.clone(), st_p1.clone()),
    }
}

/// The step machine of `BindFamily`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
/// ```
pub struct BindFamily {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub fam_p2: Text,
    pub t_p3: crate::check::types::Ty,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindFamily {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let fam_p2 = &self.fam_p2;
        let t_p3 = &self.t_p3;
        let span_p4 = &self.span_p4;
        let env_p0 = env_p0.clone();
        let fam_p2 = fam_p2.clone();
        let span_p4 = span_p4.clone();
        let st_p1 = st_p1.clone();
        let t_p3 = t_p3.clone();
        call_then(crate::check::types::recording::start_walk(st_p1.clone(), t_p3.clone()), move |walk_12297: crate::check::types::Ty| match walk_12297 {
            crate::check::types::Ty::TyElem(rw_p5, _) => call_then(crate::check::types::recording::start_walk_row(st_p1.clone(), rw_p5.clone()), move |walk_row_12348: crate::check::types::Rw| {
                let w_p6 = walk_row_12348;
                if crate::check::types::has_text(&w_p6.fams, &fam_p2) {
                    prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone()))
                } else {
                    prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_fix(&st_p1, &Text::lit("row-not-here"), &span_p4, &Text::from(format!("`{}.*` is not in this row, `{}`", &fam_p2, &crate::check::types::show_row(&w_p6))), &Text::from(format!("add `{}.*` to the row", &fam_p2)))))
                }
            }),
            _ => prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
        })
    }
}

/// `Start BindFamily, x`: what the function value is when passed to `@Run`.
pub fn start_bind_family(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, fam_p2: Text, t_p3: crate::check::types::Ty, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindFamily { env_p0, st_p1, fam_p2, t_p3, span_p4 })
}
