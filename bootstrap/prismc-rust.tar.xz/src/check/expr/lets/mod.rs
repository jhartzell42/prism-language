//! The module `Check.Expr.Lets`, from `target/bootstrap/src/prismc/check/expr/lets.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub fn infer_expr_block(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block) -> (crate::check::types::Ty, crate::check::types::St) {
    if is_widgetish(&b_p2.stmts) {
        crate::check::blocks::infer_widget_block(env_p0, st_p1, b_p2)
    } else {
        {
            let (env2_p3, st2_p4) = bind_group(env_p0, st_p1, &b_p2.stmts);
            match crate::syntax::lexer::chars::last(&b_p2.stmts) {
                Some(s_p5) => match &s_p5.kind {
                    crate::syntax::StmtKind::SExpr(e_p6) => crate::check::expr::infer(&env2_p3, &st2_p4, e_p6),
                    _ => (crate::check::types::t_unit(), st2_p4.clone()),
                },
                None => (crate::check::types::t_unit(), st2_p4.clone()),
            }
        }
    }
}

/// The step machine of `InferExprBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub struct InferExprBlock {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferExprBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        if is_widgetish(&b_p2.stmts) {
            prism_rtl::Turn::More(Rc::new(crate::check::blocks::InferWidgetBlock { env_p0: env_p0.clone(), st_p1: st_p1.clone(), b_p2: b_p2.clone() }))
        } else {
            {
                let b_p2 = b_p2.clone();
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                call_then(start_bind_group(env_p0.clone(), st_p1.clone(), b_p2.stmts.clone()), move |bind_group_1662: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2_p3, st2_p4) = bind_group_1662;
                    match crate::syntax::lexer::chars::last(&b_p2.stmts) {
                        Some(s_p5) => match &s_p5.kind {
                            crate::syntax::StmtKind::SExpr(e_p6) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Infer { env_p0: env2_p3.clone(), st_p1: st2_p4.clone(), e_p2: e_p6.clone() })),
                            _ => prism_rtl::Turn::Finished((crate::check::types::t_unit(), st2_p4.clone())),
                        },
                        None => prism_rtl::Turn::Finished((crate::check::types::t_unit(), st2_p4.clone())),
                    }
                })
            }
        }
    }
}

/// `Start InferExprBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_expr_block(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferExprBlock { env_p0, st_p1, b_p2 })
}

/// ```prism
/// IsWidgetish: fn [Stmt] -> Bool
/// ```
pub fn is_widgetish(stmts_p0: &Array<crate::syntax::Stmt>) -> bool {
    fold(stmts_p0, &false, &(|seen_p1: &bool, s_p2: &crate::syntax::Stmt| *seen_p1 || builds(s_p2)))
}

/// ```prism
/// Builds: fn Stmt -> Bool
/// ```
pub fn builds(s_p0: &crate::syntax::Stmt) -> bool {
    match &s_p0.kind {
        crate::syntax::StmtKind::SBind(_, _, _) => true,
        crate::syntax::StmtKind::SIgnore(_) => true,
        crate::syntax::StmtKind::SEmit(_) => true,
        crate::syntax::StmtKind::SWidget(_) => true,
        _ => false,
    }
}

/// ```prism
/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub fn bind_group(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, stmts_p2: &Array<crate::syntax::Stmt>) -> (crate::check::expr::Env, crate::check::types::St) {
    let order_p3 = crate::check::blocks::group_order(stmts_p2);
    let (env1_p8, st1_p9) = run_to_end(fold_job(order_p3.clone(), (env_p0.clone(), st_p1.clone()), {
        let stmts_p2 = stmts_p2.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
            let stmts_p2 = stmts_p2.clone();
            entered(once_job(move || {
                let (en_p5, s_p6) = p0;
                let i_p7 = p1;
                prism_rtl::Turn::More(Rc::new(PreBind { env_p0: en_p5.clone(), st_p1: s_p6.clone(), s_p2: or(&index(&stmts_p2, &i_p7), &dummy_stmt()) }))
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
    }));
    let st2_p4 = if st1_p9.recording && (&len(stmts_p2) > &Nat::from(1u32)) {
        crate::check::types::recording::note_group(&st1_p9, &stmts_span(stmts_p2), &Text::lit("expr"), &crate::check::blocks::dep_order(stmts_p2))
    } else {
        st1_p9.clone()
    };
    run_to_end(fold_job(order_p3.clone(), (env1_p8.clone(), st2_p4.clone()), {
        let stmts_p2 = stmts_p2.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
            let stmts_p2 = stmts_p2.clone();
            entered(once_job(move || {
                let (en_pa, s_pb) = p0;
                let i_pc = p1;
                prism_rtl::Turn::More(Rc::new(CheckGroupStmt { env_p0: en_pa.clone(), st_p1: s_pb.clone(), s_p2: or(&index(&stmts_p2, &i_pc), &dummy_stmt()), last_p3: is_last(&stmts_p2, &i_pc) }))
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
    }))
}

/// The step machine of `BindGroup`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub struct BindGroup {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub stmts_p2: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindGroup {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let stmts_p2 = &self.stmts_p2;
        let env_p0 = env_p0.clone();
        let st_p1 = st_p1.clone();
        let stmts_p2 = stmts_p2.clone();
        call_then(crate::check::blocks::start_group_order(stmts_p2.clone()), move |group_order_2649: Array<Nat>| {
            let order_p3 = group_order_2649;
            call_value(fold_job(order_p3.clone(), (env_p0.clone(), st_p1.clone()), {
                let stmts_p2 = stmts_p2.clone();
                Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                    let stmts_p2 = stmts_p2.clone();
                    entered(once_job(move || {
                        let (en_p5, s_p6) = p0;
                        let i_p7 = p1;
                        prism_rtl::Turn::More(Rc::new(PreBind { env_p0: en_p5.clone(), st_p1: s_p6.clone(), s_p2: or(&index(&stmts_p2, &i_p7), &dummy_stmt()) }))
                    }))
                }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }), move |fold_2690: (crate::check::expr::Env, crate::check::types::St)| {
                let (env1_p8, st1_p9) = fold_2690;
                let st2_p4 = if st1_p9.recording && (&len(&stmts_p2) > &Nat::from(1u32)) {
                    crate::check::types::recording::note_group(&st1_p9, &stmts_span(&stmts_p2), &Text::lit("expr"), &crate::check::blocks::dep_order(&stmts_p2))
                } else {
                    st1_p9.clone()
                };
                fold_job(order_p3.clone(), (env1_p8.clone(), st2_p4.clone()), {
                    let stmts_p2 = stmts_p2.clone();
                    Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                        let stmts_p2 = stmts_p2.clone();
                        entered(once_job(move || {
                            let (en_pa, s_pb) = p0;
                            let i_pc = p1;
                            prism_rtl::Turn::More(Rc::new(CheckGroupStmt { env_p0: en_pa.clone(), st_p1: s_pb.clone(), s_p2: or(&index(&stmts_p2, &i_pc), &dummy_stmt()), last_p3: is_last(&stmts_p2, &i_pc) }))
                        }))
                    }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                }).cycle()
            })
        })
    }
}

/// `Start BindGroup, x`: what the function value is when passed to `@Run`.
pub fn start_bind_group(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, stmts_p2: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindGroup { env_p0, st_p1, stmts_p2 })
}

/// ```prism
/// StmtsSpan: fn [Stmt] -> Range
/// ```
pub fn stmts_span(stmts_p0: &Array<crate::syntax::Stmt>) -> crate::syntax::Range {
    crate::syntax::Range { start: or(&index(stmts_p0, &Nat::from(0u32)), &dummy_stmt()).span.start.clone(), end: or(&crate::syntax::lexer::chars::last(stmts_p0), &dummy_stmt()).span.end.clone() }
}

/// ```prism
/// let dummyStmt
/// ```
pub fn dummy_stmt() -> crate::syntax::Stmt {
    crate::syntax::Stmt { kind: crate::syntax::StmtKind::SExpr(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// IsLast: fn [Stmt], Nat -> Bool
/// ```
pub fn is_last(stmts_p0: &Array<crate::syntax::Stmt>, i_p1: &Nat) -> bool {
    &(i_p1 + &Nat::from(1u32)) == &len(stmts_p0)
}

/// ```prism
/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub fn pre_bind(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, s_p2: &crate::syntax::Stmt) -> (crate::check::expr::Env, crate::check::types::St) {
    match &s_p2.kind {
        crate::syntax::StmtKind::SSignature(sg_p3) => {
            let (sc_p4, st2_p5) = crate::check::env::reading::sig_scheme(&crate::check::expr::env_cx(env_p0), st_p1, &sg_p3.ty, &sg_p3.bounds);
            crate::check::expr::bind_local_id(&crate::check::expr::with_local(env_p0, &crate::check::env::def_name_text(&sg_p3.name), &sc_p4), &st2_p5, &crate::check::env::def_name_text(&sg_p3.name), &crate::check::env::def_name_span(&sg_p3.name))
        },
        crate::syntax::StmtKind::SFn(f_p6) => {
            let name_p7 = crate::check::env::def_name_text(&f_p6.name);
            match get(&env_p0.locals, &name_p7) {
                Some(_) => (env_p0.clone(), st_p1.clone()),
                None => {
                    let (v_p8, st2_p9) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                    crate::check::expr::bind_local_id(&crate::check::expr::with_local(env_p0, &name_p7, &crate::check::types::schemes::mono(&v_p8)), &st2_p9, &name_p7, &crate::check::env::def_name_span(&f_p6.name))
                },
            }
        },
        crate::syntax::StmtKind::SLet(p_pa, _, _) => match &*p_pa.kind {
            crate::syntax::PatternKind::PName(n_pb) => {
                let (v_pd, st1_pe) = crate::check::types::fresh_var(st_p1, &true, &crate::check::env::sname_key(n_pb));
                let st2_pc = crate::check::types::recording::at_binder(&st1_pe, &v_pd, &n_pb.span);
                let (rw_pf, st3_pg) = crate::check::types::recording::fresh_row(&st2_pc, &Array::new());
                crate::check::expr::bind_local_id(&crate::check::expr::with_local(env_p0, &crate::check::env::sname_key(n_pb), &crate::check::types::schemes::mono(&crate::check::types::with_marks(&type_marks(&n_pb.sigils), &v_pd, &rw_pf))), &st3_pg, &crate::check::env::sname_key(n_pb), &n_pb.span)
            },
            _ => (env_p0.clone(), st_p1.clone()),
        },
        _ => (env_p0.clone(), st_p1.clone()),
    }
}

/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub struct PreBind {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub s_p2: crate::syntax::Stmt,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for PreBind {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let s_p2 = &self.s_p2;
        match &s_p2.kind {
            crate::syntax::StmtKind::SSignature(sg_p3) => {
                let env_p0 = env_p0.clone();
                let sg_p3 = sg_p3.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::env::reading::start_sig_scheme(crate::check::expr::env_cx(&env_p0), st_p1.clone(), sg_p3.ty.clone(), sg_p3.bounds.clone()), move |sig_scheme_3595: (crate::check::types::Scheme, crate::check::types::St)| {
                    let (sc_p4, st2_p5) = sig_scheme_3595;
                    prism_rtl::Turn::Finished(crate::check::expr::bind_local_id(&crate::check::expr::with_local(&env_p0, &crate::check::env::def_name_text(&sg_p3.name), &sc_p4), &st2_p5, &crate::check::env::def_name_text(&sg_p3.name), &crate::check::env::def_name_span(&sg_p3.name)))
                })
            },
            crate::syntax::StmtKind::SFn(f_p6) => {
                let name_p7 = crate::check::env::def_name_text(&f_p6.name);
                match get(&env_p0.locals, &name_p7) {
                    Some(_) => prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
                    None => {
                        let (v_p8, st2_p9) = crate::check::types::fresh_var(st_p1, &false, &Text::lit(""));
                        prism_rtl::Turn::Finished(crate::check::expr::bind_local_id(&crate::check::expr::with_local(env_p0, &name_p7, &crate::check::types::schemes::mono(&v_p8)), &st2_p9, &name_p7, &crate::check::env::def_name_span(&f_p6.name)))
                    },
                }
            },
            crate::syntax::StmtKind::SLet(p_pa, _, _) => match &*p_pa.kind {
                crate::syntax::PatternKind::PName(n_pb) => {
                    let (v_pd, st1_pe) = crate::check::types::fresh_var(st_p1, &true, &crate::check::env::sname_key(n_pb));
                    let st2_pc = crate::check::types::recording::at_binder(&st1_pe, &v_pd, &n_pb.span);
                    let (rw_pf, st3_pg) = crate::check::types::recording::fresh_row(&st2_pc, &Array::new());
                    prism_rtl::Turn::Finished(crate::check::expr::bind_local_id(&crate::check::expr::with_local(env_p0, &crate::check::env::sname_key(n_pb), &crate::check::types::schemes::mono(&crate::check::types::with_marks(&type_marks(&n_pb.sigils), &v_pd, &rw_pf))), &st3_pg, &crate::check::env::sname_key(n_pb), &n_pb.span))
                },
                _ => prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
            },
            _ => prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
        }
    }
}

/// `Start PreBind, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, s_p2: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(PreBind { env_p0, st_p1, s_p2 })
}

/// ```prism
/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
/// ```
pub fn check_group_stmt(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, s_p2: &crate::syntax::Stmt, last_p3: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    match &s_p2.kind {
        crate::syntax::StmtKind::SLet(p_p4, ty_o5, e_p6) => check_let(env_p0, st_p1, p_p4, ty_o5, e_p6, &s_p2.span),
        crate::syntax::StmtKind::SFn(f_p7) => check_local_fn(env_p0, st_p1, f_p7, &s_p2.span),
        crate::syntax::StmtKind::SSignature(_) => (env_p0.clone(), st_p1.clone()),
        crate::syntax::StmtKind::SExpr(e_p8) => if *last_p3 {
            (env_p0.clone(), st_p1.clone())
        } else {
            {
                let (t_p9, st2_pa) = crate::check::expr::infer(env_p0, st_p1, e_p8);
                (env_p0.clone(), st2_pa.clone())
            }
        },
        _ => (env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &s_p2.span, &Text::lit("this statement belongs in a widget, `given:` or `update` block"))),
    }
}

/// The step machine of `CheckGroupStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
/// ```
pub struct CheckGroupStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub s_p2: crate::syntax::Stmt,
    pub last_p3: bool,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for CheckGroupStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let s_p2 = &self.s_p2;
        let last_p3 = &self.last_p3;
        match &s_p2.kind {
            crate::syntax::StmtKind::SLet(p_p4, ty_o5, e_p6) => prism_rtl::Turn::More(Rc::new(CheckLet { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p4.clone(), ty_o3: ty_o5.clone(), e_p4: e_p6.clone(), span_p5: s_p2.span.clone() })),
            crate::syntax::StmtKind::SFn(f_p7) => prism_rtl::Turn::More(Rc::new(CheckLocalFn { env_p0: env_p0.clone(), st_p1: st_p1.clone(), f_p2: f_p7.clone(), span_p3: s_p2.span.clone() })),
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
            crate::syntax::StmtKind::SExpr(e_p8) => if *last_p3 {
                prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone()))
            } else {
                {
                    let e_p8 = e_p8.clone();
                    let env_p0 = env_p0.clone();
                    let st_p1 = st_p1.clone();
                    call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), e_p8.clone()), move |infer_4771: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_p9, st2_pa) = infer_4771;
                        prism_rtl::Turn::Finished((env_p0.clone(), st2_pa.clone()))
                    })
                }
            },
            _ => prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &s_p2.span, &Text::lit("this statement belongs in a widget, `given:` or `update` block")))),
        }
    }
}

/// `Start CheckGroupStmt, x`: what the function value is when passed to `@Run`.
pub fn start_check_group_stmt(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, s_p2: crate::syntax::Stmt, last_p3: bool) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(CheckGroupStmt { env_p0, st_p1, s_p2, last_p3 })
}

/// ```prism
/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
/// ```
pub fn check_let(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, ty_o3: &Option<crate::syntax::Type>, e_p4: &crate::syntax::Expr, span_p5: &crate::syntax::Range) -> (crate::check::expr::Env, crate::check::types::St) {
    let st0_p6 = crate::check::types::schemes::enter_level(st_p1);
    let (annot_od, st1_pe) = match ty_o3 {
        Some(t_pa) => {
            let (at_pb, s2_pc) = crate::check::env::reading::conv_type(&crate::check::expr::env_cx(env_p0), &st0_p6, t_pa);
            (Some(at_pb.clone()), s2_pc.clone())
        },
        None => (None, st0_p6.clone()),
    };
    let (pre_pj, st2_pk) = match &*p_p2.kind {
        crate::syntax::PatternKind::PName(n_pf) => match get(&env_p0.locals, &crate::check::env::sname_key(n_pf)) {
            Some(sc_pg) => if (&n_pf.sigils == &Text::lit("")) && crate::check::types::is_flex_var(&st1_pe, &sc_pg.ty) {
                {
                    let (v_ph, s2_pi) = crate::check::types::fresh_var(&st1_pe, &true, &crate::check::env::sname_key(n_pf));
                    (v_ph.clone(), crate::check::types::recording::at_binder(&s2_pi, &v_ph, &n_pf.span))
                }
            } else {
                (sc_pg.ty.clone(), st1_pe.clone())
            },
            None => crate::check::types::fresh_var(&st1_pe, &true, &crate::check::env::sname_key(n_pf)),
        },
        _ => crate::check::types::fresh_var(&st1_pe, &false, &Text::lit("")),
    };
    let st3_p7 = match &annot_od {
        Some(at_pl) => crate::check::expr::check(env_p0, &st2_pk, e_p4, at_pl),
        None => crate::check::expr::check(env_p0, &st2_pk, e_p4, &pre_pj),
    };
    let st4_p8 = match &annot_od {
        Some(at_pm) => crate::check::types::unify::unify(&st3_p7, &pre_pj, at_pm, span_p5),
        None => st3_p7.clone(),
    };
    let st5_p9 = crate::check::env::traits::solve_wants(&env_p0.g, &st4_p8, &env_p0.givens, &false);
    match &*p_p2.kind {
        crate::syntax::PatternKind::PName(n_pn) => {
            let name_po = crate::check::env::sname_key(n_pn);
            let t_pp = crate::check::types::recording::zonk(&st5_p9, &pre_pj);
            let (env2_ps, st7a_pt) = crate::check::expr::patterns::bind_name(env_p0, &st5_p9, n_pn, &t_pp);
            let st7_pq = crate::check::types::schemes::leave_level(&st7a_pt);
            let ahead_fr = {
                let env_p0 = env_p0.clone();
                let name_po = name_po.clone();
                let pre_pj = pre_pj.clone();
                let t_pp = t_pp.clone();
                let span_p5 = span_p5.clone();
                Rc::new(move |p0: crate::check::types::St| {
                    let env_p0 = env_p0.clone();
                    let name_po = name_po.clone();
                    let pre_pj = pre_pj.clone();
                    let t_pp = t_pp.clone();
                    let span_p5 = span_p5.clone();
                    entered(once_job(move || {
                        let s_pu = p0;
                        prism_rtl::Turn::More(Rc::new(AheadUnify { env_p0: env_p0.clone(), st_p1: s_pu.clone(), name_p2: name_po.clone(), pre_p3: pre_pj.clone(), t_p4: t_pp.clone(), span_p5: span_p5.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            };
            if crate::check::types::schemes::holds_node(&st7_pq, &t_pp) || is_topic_name(&name_po) {
                (env2_ps.clone(), run_to_end((&ahead_fr)(st7_pq.clone())))
            } else {
                {
                    let lambda_pv = crate::check::expr::is_lambda(e_p4);
                    let (keep_p10, bounds_p11, st8_p12) = wants_above(&st7_pq, &t_pp, &lambda_pv);
                    let (sc_p13, st9_p14) = crate::check::types::schemes::generalize(&st8_p12, &t_pp, &keep_p10, &bounds_p11);
                    (crate::check::expr::with_local(&env2_ps, &name_po, &sc_p13), run_to_end((&ahead_fr)(crate::check::types::recording::note_gen(&st9_p14, &n_pn.span, &name_po, &sc_p13))))
                }
            }
        },
        _ => {
            let st6_p15 = crate::check::types::schemes::leave_level(&st5_p9);
            crate::check::expr::patterns::bind_pattern(env_p0, &st6_p15, p_p2, &crate::check::types::recording::zonk(&st6_p15, &pre_pj), &false)
        },
    }
}

/// The step machine of `CheckLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
/// ```
pub struct CheckLet {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub ty_o3: Option<crate::syntax::Type>,
    pub e_p4: crate::syntax::Expr,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for CheckLet {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let ty_o3 = &self.ty_o3;
        let e_p4 = &self.e_p4;
        let span_p5 = &self.span_p5;
        let st0_p6 = crate::check::types::schemes::enter_level(st_p1);
        let (annot_od, st1_pe) = match ty_o3 {
            Some(t_pa) => {
                let (at_pb, s2_pc) = crate::check::env::reading::conv_type(&crate::check::expr::env_cx(env_p0), &st0_p6, t_pa);
                (Some(at_pb.clone()), s2_pc.clone())
            },
            None => (None, st0_p6.clone()),
        };
        let (pre_pj, st2_pk) = match &*p_p2.kind {
            crate::syntax::PatternKind::PName(n_pf) => match get(&env_p0.locals, &crate::check::env::sname_key(n_pf)) {
                Some(sc_pg) => if (&n_pf.sigils == &Text::lit("")) && crate::check::types::is_flex_var(&st1_pe, &sc_pg.ty) {
                    {
                        let (v_ph, s2_pi) = crate::check::types::fresh_var(&st1_pe, &true, &crate::check::env::sname_key(n_pf));
                        (v_ph.clone(), crate::check::types::recording::at_binder(&s2_pi, &v_ph, &n_pf.span))
                    }
                } else {
                    (sc_pg.ty.clone(), st1_pe.clone())
                },
                None => crate::check::types::fresh_var(&st1_pe, &true, &crate::check::env::sname_key(n_pf)),
            },
            _ => crate::check::types::fresh_var(&st1_pe, &false, &Text::lit("")),
        };
        let st3_p7 = match &annot_od {
            Some(at_pl) => crate::check::expr::check(env_p0, &st2_pk, e_p4, at_pl),
            None => crate::check::expr::check(env_p0, &st2_pk, e_p4, &pre_pj),
        };
        let st4_p8 = match &annot_od {
            Some(at_pm) => crate::check::types::unify::unify(&st3_p7, &pre_pj, at_pm, span_p5),
            None => st3_p7.clone(),
        };
        let e_p4 = e_p4.clone();
        let env_p0 = env_p0.clone();
        let p_p2 = p_p2.clone();
        let span_p5 = span_p5.clone();
        call_then(crate::check::env::traits::start_solve_wants(env_p0.g.clone(), st4_p8.clone(), env_p0.givens.clone(), false), move |solve_wants_6282: crate::check::types::St| {
            let st5_p9 = solve_wants_6282;
            match &*p_p2.kind {
                crate::syntax::PatternKind::PName(n_pn) => {
                    let name_po = crate::check::env::sname_key(n_pn);
                    let n_pn = n_pn.clone();
                    call_then(crate::check::types::recording::start_zonk(st5_p9.clone(), pre_pj.clone()), move |zonk_6573: crate::check::types::Ty| {
                        let t_pp = zonk_6573;
                        call_then(crate::check::expr::patterns::start_bind_name(env_p0.clone(), st5_p9.clone(), n_pn.clone(), t_pp.clone()), move |bind_name_6620: (crate::check::expr::Env, crate::check::types::St)| {
                            let (env2_ps, st7a_pt) = bind_name_6620;
                            let st7_pq = crate::check::types::schemes::leave_level(&st7a_pt);
                            let ahead_fr = {
                                let env_p0 = env_p0.clone();
                                let name_po = name_po.clone();
                                let pre_pj = pre_pj.clone();
                                let t_pp = t_pp.clone();
                                let span_p5 = span_p5.clone();
                                Rc::new(move |p0: crate::check::types::St| {
                                    let env_p0 = env_p0.clone();
                                    let name_po = name_po.clone();
                                    let pre_pj = pre_pj.clone();
                                    let t_pp = t_pp.clone();
                                    let span_p5 = span_p5.clone();
                                    entered(once_job(move || {
                                        let s_pu = p0;
                                        prism_rtl::Turn::More(Rc::new(AheadUnify { env_p0: env_p0.clone(), st_p1: s_pu.clone(), name_p2: name_po.clone(), pre_p3: pre_pj.clone(), t_p4: t_pp.clone(), span_p5: span_p5.clone() }))
                                    }))
                                }) as Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            };
                            call_then(crate::check::types::schemes::start_holds_node(st7_pq.clone(), t_pp.clone()), move |holds_node_6893: bool| if holds_node_6893 || is_topic_name(&name_po) {
                                call_value((&ahead_fr)(st7_pq.clone()), move |ahead_6943: crate::check::types::St| prism_rtl::Turn::Finished((env2_ps.clone(), ahead_6943)))
                            } else {
                                {
                                    let lambda_pv = crate::check::expr::is_lambda(&e_p4);
                                    call_then(start_wants_above(st7_pq.clone(), t_pp.clone(), lambda_pv), move |wants_above_7058: (Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)| {
                                        let (keep_p10, bounds_p11, st8_p12) = wants_above_7058;
                                        call_then(crate::check::types::schemes::start_generalize(st8_p12.clone(), t_pp.clone(), keep_p10.clone(), bounds_p11.clone()), move |generalize_7118: (crate::check::types::Scheme, crate::check::types::St)| {
                                            let (sc_p13, st9_p14) = generalize_7118;
                                            call_value((&ahead_fr)(crate::check::types::recording::note_gen(&st9_p14, &n_pn.span, &name_po, &sc_p13)), move |ahead_7197: crate::check::types::St| prism_rtl::Turn::Finished((crate::check::expr::with_local(&env2_ps, &name_po, &sc_p13), ahead_7197)))
                                        })
                                    })
                                }
                            })
                        })
                    })
                },
                _ => {
                    let st6_p15 = crate::check::types::schemes::leave_level(&st5_p9);
                    call_then(crate::check::types::recording::start_zonk(st6_p15.clone(), pre_pj.clone()), move |zonk_7332: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(crate::check::expr::patterns::BindPattern { env_p0: env_p0.clone(), st_p1: st6_p15.clone(), p_p2: p_p2.clone(), t_p3: zonk_7332, refutable_p4: false })))
                },
            }
        })
    }
}

/// `Start CheckLet, x`: what the function value is when passed to `@Run`.
pub fn start_check_let(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, ty_o3: Option<crate::syntax::Type>, e_p4: crate::syntax::Expr, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(CheckLet { env_p0, st_p1, p_p2, ty_o3, e_p4, span_p5 })
}

/// ```prism
/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
/// ```
pub fn ahead_unify(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, name_p2: &Text, pre_p3: &crate::check::types::Ty, t_p4: &crate::check::types::Ty, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    match get(&env_p0.locals, name_p2) {
        Some(sc0_p6) => if &sc0_p6.ty != pre_p3 {
            crate::check::types::unify::unify(st_p1, &sc0_p6.ty, t_p4, span_p5)
        } else {
            st_p1.clone()
        },
        None => st_p1.clone(),
    }
}

/// The step machine of `AheadUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
/// ```
pub struct AheadUnify {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub name_p2: Text,
    pub pre_p3: crate::check::types::Ty,
    pub t_p4: crate::check::types::Ty,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for AheadUnify {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let name_p2 = &self.name_p2;
        let pre_p3 = &self.pre_p3;
        let t_p4 = &self.t_p4;
        let span_p5 = &self.span_p5;
        match get(&env_p0.locals, name_p2) {
            Some(sc0_p6) => if &sc0_p6.ty != pre_p3 {
                prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st_p1.clone(), expected_p1: sc0_p6.ty.clone(), found_p2: t_p4.clone(), span_p3: span_p5.clone() }))
            } else {
                prism_rtl::Turn::Finished(st_p1.clone())
            },
            None => prism_rtl::Turn::Finished(st_p1.clone()),
        }
    }
}

/// `Start AheadUnify, x`: what the function value is when passed to `@Run`.
pub fn start_ahead_unify(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, name_p2: Text, pre_p3: crate::check::types::Ty, t_p4: crate::check::types::Ty, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(AheadUnify { env_p0, st_p1, name_p2, pre_p3, t_p4, span_p5 })
}

/// ```prism
/// TypeMarks: fn Text -> Text
/// ```
pub fn type_marks(marks_p0: &Text) -> Text {
    if crate::syntax::lexer::chars::has_prefix(marks_p0, &Text::lit("&")) {
        crate::syntax::lexer::chars::after_first(marks_p0)
    } else {
        marks_p0.clone()
    }
}

/// ```prism
/// RefMark: fn Text -> Text
/// ```
pub fn ref_mark(marks_p0: &Text) -> Text {
    if crate::syntax::lexer::chars::has_prefix(marks_p0, &Text::lit("&")) {
        Text::lit("&")
    } else {
        Text::lit("")
    }
}

/// ```prism
/// Unpend: fn Env -> Env
/// ```
pub fn unpend(env_p0: &crate::check::expr::Env) -> crate::check::expr::Env {
    let mut this: crate::check::expr::Env = env_p0.clone();
    this.pending = Array::new();
    this
}

/// ```prism
/// IsTopicName: fn Text -> Bool
/// ```
pub fn is_topic_name(n_p0: &Text) -> bool {
    (n_p0 == &Text::lit("_")) || (&crate::syntax::lexer::chars::drop_prefix(n_p0, &crate::check::types::unify::marks_of(n_p0)) == &Text::lit("_"))
}

/// ```prism
/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
/// ```
pub fn wants_above(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, lambda_p2: &bool) -> (Array<Nat>, Array<(Nat, Text)>, crate::check::types::St) {
    let vs_p3 = filter(&crate::check::types::recording::free_vars(st_p0, t_p1), &(|v_p7: &Nat| &crate::check::types::recording::info_of(st_p0, v_p7).level > &st_p0.level));
    let mine_p4 = run_to_end(filter_job(st_p0.wants.clone(), {
        let st_p0 = st_p0.clone();
        let vs_p3 = vs_p3.clone();
        Rc::new(move |p0: crate::check::types::Want| {
            let st_p0 = st_p0.clone();
            let vs_p3 = vs_p3.clone();
            entered(once_job(move || {
                let w_p8 = p0;
                call_then(crate::check::types::recording::start_walk(st_p0.clone(), w_p8.ty.clone()), move |walk_8433: crate::check::types::Ty| match walk_8433 {
                    crate::check::types::Ty::TyFlex(n_p9) => prism_rtl::Turn::Finished(crate::check::types::has_nat(&vs_p3, &n_p9)),
                    _ => prism_rtl::Turn::Finished(false),
                })
            }))
        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let others_p5 = filter(&st_p0.wants, &(|w_pa: &crate::check::types::Want| !crate::check::types::has_text(&each(&mine_p4, &(|m_pb: &crate::check::types::Want| show_text(m_pb))), &show_text(w_pa))));
    let constrained_p6 = run_to_end(fold_job(mine_p4.clone(), Array::new(), {
        let st_p0 = st_p0.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Want)| {
            let st_p0 = st_p0.clone();
            entered(once_job(move || {
                let acc_pc = p0;
                let w_pd = p1;
                call_then(crate::check::types::recording::start_walk(st_p0.clone(), w_pd.ty.clone()), move |walk_8647: crate::check::types::Ty| match walk_8647 {
                    crate::check::types::Ty::TyFlex(n_pe) => prism_rtl::Turn::Finished(crate::check::types::add_nat(&acc_pc, &n_pe)),
                    _ => prism_rtl::Turn::Finished(acc_pc.clone()),
                })
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    if *lambda_p2 {
        {
            let bounds_pf = run_to_end(fold_job(mine_p4.clone(), Array::new(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |(p0, p1): (Array<(Nat, Text)>, crate::check::types::Want)| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let acc_pi = p0;
                        let w_pj = p1;
                        call_then(crate::check::types::recording::start_walk(st_p0.clone(), w_pj.ty.clone()), move |walk_8786: crate::check::types::Ty| match walk_8786 {
                            crate::check::types::Ty::TyFlex(n_pk) => if crate::syntax::lexer::chars::has_prefix(&w_pj.cls, &Text::lit("Range ")) {
                                prism_rtl::Turn::Finished(acc_pi.clone())
                            } else {
                                prism_rtl::Turn::Finished(push(&acc_pi, &(n_pk.clone(), w_pj.cls.clone())))
                            },
                            _ => prism_rtl::Turn::Finished(acc_pi.clone()),
                        })
                    }))
                }) as Rc<dyn Fn((Array<(Nat, Text)>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<(Nat, Text)>>>>
            }));
            let st1_pg = fold(&mine_p4, st_p0, &(|s_pl: &crate::check::types::St, w_pm: &crate::check::types::Want| crate::check::types::recording::note_choice(&crate::check::types::recording::note_impl(s_pl, &w_pm.file, &w_pm.span, &w_pm.cls, &w_pm.ty, &Text::lit("quantified")), &w_pm.file, &w_pm.span, &w_pm.cls, &Text::lit("any"))));
            let st2_ph = {
                let mut this: crate::check::types::St = st1_pg.clone();
                this.wants = others_p5.clone();
                this
            };
            (Array::new(), bounds_pf.clone(), st2_ph.clone())
        }
    } else {
        {
            let st2_pn = crate::check::types::unify::lower_levels(st_p0, &constrained_p6, &st_p0.level);
            (constrained_p6.clone(), Array::new(), st2_pn.clone())
        }
    }
}

/// The step machine of `WantsAbove`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
/// ```
pub struct WantsAbove {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub lambda_p2: bool,
}

impl prism_rtl::Job<(Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)> for WantsAbove {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let lambda_p2 = &self.lambda_p2;
        let lambda_p2 = *lambda_p2;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_free_vars(st_p0.clone(), t_p1.clone()), move |free_vars_8336: Array<Nat>| {
            let vs_p3 = filter(&free_vars_8336, &(|v_p7: &Nat| &crate::check::types::recording::info_of(&st_p0, v_p7).level > &st_p0.level));
            call_value(filter_job(st_p0.wants.clone(), {
                let st_p0 = st_p0.clone();
                let vs_p3 = vs_p3.clone();
                Rc::new(move |p0: crate::check::types::Want| {
                    let st_p0 = st_p0.clone();
                    let vs_p3 = vs_p3.clone();
                    entered(once_job(move || {
                        let w_p8 = p0;
                        call_then(crate::check::types::recording::start_walk(st_p0.clone(), w_p8.ty.clone()), move |walk_8433: crate::check::types::Ty| match walk_8433 {
                            crate::check::types::Ty::TyFlex(n_p9) => prism_rtl::Turn::Finished(crate::check::types::has_nat(&vs_p3, &n_p9)),
                            _ => prism_rtl::Turn::Finished(false),
                        })
                    }))
                }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |filter_8405: Array<crate::check::types::Want>| {
                let mine_p4 = filter_8405;
                let others_p5 = filter(&st_p0.wants, &(|w_pa: &crate::check::types::Want| !crate::check::types::has_text(&each(&mine_p4, &(|m_pb: &crate::check::types::Want| show_text(m_pb))), &show_text(w_pa))));
                call_value(fold_job(mine_p4.clone(), Array::new(), {
                    let st_p0 = st_p0.clone();
                    Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Want)| {
                        let st_p0 = st_p0.clone();
                        entered(once_job(move || {
                            let acc_pc = p0;
                            let w_pd = p1;
                            call_then(crate::check::types::recording::start_walk(st_p0.clone(), w_pd.ty.clone()), move |walk_8647: crate::check::types::Ty| match walk_8647 {
                                crate::check::types::Ty::TyFlex(n_pe) => prism_rtl::Turn::Finished(crate::check::types::add_nat(&acc_pc, &n_pe)),
                                _ => prism_rtl::Turn::Finished(acc_pc.clone()),
                            })
                        }))
                    }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }), move |fold_8614: Array<Nat>| {
                    let constrained_p6 = fold_8614;
                    if lambda_p2 {
                        call_value(fold_job(mine_p4.clone(), Array::new(), {
                            let st_p0 = st_p0.clone();
                            Rc::new(move |(p0, p1): (Array<(Nat, Text)>, crate::check::types::Want)| {
                                let st_p0 = st_p0.clone();
                                entered(once_job(move || {
                                    let acc_pi = p0;
                                    let w_pj = p1;
                                    call_then(crate::check::types::recording::start_walk(st_p0.clone(), w_pj.ty.clone()), move |walk_8786: crate::check::types::Ty| match walk_8786 {
                                        crate::check::types::Ty::TyFlex(n_pk) => if crate::syntax::lexer::chars::has_prefix(&w_pj.cls, &Text::lit("Range ")) {
                                            prism_rtl::Turn::Finished(acc_pi.clone())
                                        } else {
                                            prism_rtl::Turn::Finished(push(&acc_pi, &(n_pk.clone(), w_pj.cls.clone())))
                                        },
                                        _ => prism_rtl::Turn::Finished(acc_pi.clone()),
                                    })
                                }))
                            }) as Rc<dyn Fn((Array<(Nat, Text)>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<(Nat, Text)>>>>
                        }), move |fold_8753: Array<(Nat, Text)>| {
                            let bounds_pf = fold_8753;
                            let st1_pg = fold(&mine_p4, &st_p0, &(|s_pl: &crate::check::types::St, w_pm: &crate::check::types::Want| crate::check::types::recording::note_choice(&crate::check::types::recording::note_impl(s_pl, &w_pm.file, &w_pm.span, &w_pm.cls, &w_pm.ty, &Text::lit("quantified")), &w_pm.file, &w_pm.span, &w_pm.cls, &Text::lit("any"))));
                            let st2_ph = {
                                let mut this: crate::check::types::St = st1_pg.clone();
                                this.wants = others_p5.clone();
                                this
                            };
                            prism_rtl::Turn::Finished((Array::new(), bounds_pf.clone(), st2_ph.clone()))
                        })
                    } else {
                        {
                            let st2_pn = crate::check::types::unify::lower_levels(&st_p0, &constrained_p6, &st_p0.level);
                            prism_rtl::Turn::Finished((constrained_p6.clone(), Array::new(), st2_pn.clone()))
                        }
                    }
                })
            })
        })
    }
}

/// `Start WantsAbove, x`: what the function value is when passed to `@Run`.
pub fn start_wants_above(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty, lambda_p2: bool) -> Rc<dyn prism_rtl::Job<(Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)>> {
    Rc::new(WantsAbove { st_p0, t_p1, lambda_p2 })
}

/// ```prism
/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
/// ```
pub fn check_local_fn(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, f_p2: &crate::syntax::decls::FnClause, span_p3: &crate::syntax::Range) -> (crate::check::expr::Env, crate::check::types::St) {
    let name_p4 = crate::check::env::def_name_text(&f_p2.name);
    match get(&env_p0.locals, &name_p4) {
        Some(sc_p5) => if ((&len(&sc_p5.qs) > &Nat::from(0u32)) || (&len(&sc_p5.cqs) > &Nat::from(0u32))) || !crate::check::types::is_flex_var(st_p1, &sc_p5.ty) {
            {
                let st2_p6 = check_clauses(env_p0, st_p1, &name_p4, &Array::from(vec![f_p2.clone()]), &sc_p5, span_p3);
                (env_p0.clone(), st2_p6.clone())
            }
        } else {
            {
                let st0_p7 = crate::check::types::schemes::enter_level(st_p1);
                let (lt_pc, st1_pd) = clause_lambda(env_p0, &st0_p7, f_p2);
                let st2_p8 = crate::check::types::unify::unify(&st1_pd, &sc_p5.ty, &lt_pc, span_p3);
                let st3_p9 = crate::check::env::traits::solve_wants(&env_p0.g, &st2_p8, &env_p0.givens, &false);
                let st4_pa = crate::check::types::schemes::leave_level(&st3_p9);
                let t_pb = crate::check::types::recording::zonk(&st4_pa, &sc_p5.ty);
                if crate::check::types::schemes::holds_node(&st4_pa, &t_pb) {
                    (env_p0.clone(), st4_pa.clone())
                } else {
                    {
                        let (keep_pe, bounds_pf, st5_pg) = wants_above(&st4_pa, &t_pb, &true);
                        let (sc2_ph, st6_pi) = crate::check::types::schemes::generalize(&st5_pg, &t_pb, &keep_pe, &bounds_pf);
                        (crate::check::expr::with_local(env_p0, &name_p4, &sc2_ph), st6_pi.clone())
                    }
                }
            }
        },
        None => (env_p0.clone(), st_p1.clone()),
    }
}

/// The step machine of `CheckLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
/// ```
pub struct CheckLocalFn {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub f_p2: crate::syntax::decls::FnClause,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for CheckLocalFn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let f_p2 = &self.f_p2;
        let span_p3 = &self.span_p3;
        let name_p4 = crate::check::env::def_name_text(&f_p2.name);
        match get(&env_p0.locals, &name_p4) {
            Some(sc_p5) => if ((&len(&sc_p5.qs) > &Nat::from(0u32)) || (&len(&sc_p5.cqs) > &Nat::from(0u32))) || !crate::check::types::is_flex_var(st_p1, &sc_p5.ty) {
                {
                    let env_p0 = env_p0.clone();
                    let f_p2 = f_p2.clone();
                    let span_p3 = span_p3.clone();
                    let st_p1 = st_p1.clone();
                    call_then(start_check_clauses(env_p0.clone(), st_p1.clone(), name_p4.clone(), Array::from(vec![f_p2.clone()]), sc_p5.clone(), span_p3.clone()), move |check_clauses_9674: crate::check::types::St| {
                        let st2_p6 = check_clauses_9674;
                        prism_rtl::Turn::Finished((env_p0.clone(), st2_p6.clone()))
                    })
                }
            } else {
                {
                    let st0_p7 = crate::check::types::schemes::enter_level(st_p1);
                    let env_p0 = env_p0.clone();
                    let f_p2 = f_p2.clone();
                    let span_p3 = span_p3.clone();
                    call_then(start_clause_lambda(env_p0.clone(), st0_p7.clone(), f_p2.clone()), move |clause_lambda_9839: (crate::check::types::Ty, crate::check::types::St)| {
                        let (lt_pc, st1_pd) = clause_lambda_9839;
                        call_then(crate::check::types::unify::start_unify(st1_pd.clone(), sc_p5.ty.clone(), lt_pc.clone(), span_p3.clone()), move |unify_9890: crate::check::types::St| {
                            let st2_p8 = unify_9890;
                            call_then(crate::check::env::traits::start_solve_wants(env_p0.g.clone(), st2_p8.clone(), env_p0.givens.clone(), false), move |solve_wants_9943: crate::check::types::St| {
                                let st3_p9 = solve_wants_9943;
                                let st4_pa = crate::check::types::schemes::leave_level(&st3_p9);
                                call_then(crate::check::types::recording::start_zonk(st4_pa.clone(), sc_p5.ty.clone()), move |zonk_10049: crate::check::types::Ty| {
                                    let t_pb = zonk_10049;
                                    call_then(crate::check::types::schemes::start_holds_node(st4_pa.clone(), t_pb.clone()), move |holds_node_10084: bool| if holds_node_10084 {
                                        prism_rtl::Turn::Finished((env_p0.clone(), st4_pa.clone()))
                                    } else {
                                        call_then(start_wants_above(st4_pa.clone(), t_pb.clone(), true), move |wants_above_10185: (Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)| {
                                            let (keep_pe, bounds_pf, st5_pg) = wants_above_10185;
                                            call_then(crate::check::types::schemes::start_generalize(st5_pg.clone(), t_pb.clone(), keep_pe.clone(), bounds_pf.clone()), move |generalize_10248: (crate::check::types::Scheme, crate::check::types::St)| {
                                                let (sc2_ph, st6_pi) = generalize_10248;
                                                prism_rtl::Turn::Finished((crate::check::expr::with_local(&env_p0, &name_p4, &sc2_ph), st6_pi.clone()))
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    })
                }
            },
            None => prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
        }
    }
}

/// `Start CheckLocalFn, x`: what the function value is when passed to `@Run`.
pub fn start_check_local_fn(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, f_p2: crate::syntax::decls::FnClause, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(CheckLocalFn { env_p0, st_p1, f_p2, span_p3 })
}

/// ```prism
/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
/// ```
pub fn clause_lambda(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, f_p2: &crate::syntax::decls::FnClause) -> (crate::check::types::Ty, crate::check::types::St) {
    let body_p3 = match &f_p2.body {
        crate::syntax::decls::FnBody::BodyExpr(e_p4) => crate::syntax::LambdaBody::LbExpr(Rc::new(e_p4.clone())),
        crate::syntax::decls::FnBody::BodyBlock(b_p5) => crate::syntax::LambdaBody::LbBlock(b_p5.clone()),
    };
    crate::check::expr::calls::infer_lambda(env_p0, st_p1, &crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(Some(f_p2.params.clone()), Rc::new(body_p3.clone()))), span: f_p2.span.clone() }, &None)
}

/// The step machine of `ClauseLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
/// ```
pub struct ClauseLambda {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub f_p2: crate::syntax::decls::FnClause,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ClauseLambda {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let f_p2 = &self.f_p2;
        let body_p3 = match &f_p2.body {
            crate::syntax::decls::FnBody::BodyExpr(e_p4) => crate::syntax::LambdaBody::LbExpr(Rc::new(e_p4.clone())),
            crate::syntax::decls::FnBody::BodyBlock(b_p5) => crate::syntax::LambdaBody::LbBlock(b_p5.clone()),
        };
        prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferLambda { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(Some(f_p2.params.clone()), Rc::new(body_p3.clone()))), span: f_p2.span.clone() }, expected_o3: None }))
    }
}

/// `Start ClauseLambda, x`: what the function value is when passed to `@Run`.
pub fn start_clause_lambda(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, f_p2: crate::syntax::decls::FnClause) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(ClauseLambda { env_p0, st_p1, f_p2 })
}

/// ```prism
/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
/// ```
pub fn check_clauses(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, name_p2: &Text, clauses_p3: &Array<crate::syntax::decls::FnClause>, sc_p4: &crate::check::types::Scheme, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    let t_p6 = crate::check::types::schemes::skolemize(sc_p4);
    let givens_p7 = append(&env_p0.givens, &sc_p4.bounds);
    let env2_p8 = {
        let mut this: crate::check::expr::Env = env_p0.clone();
        this.givens = givens_p7.clone();
        this.mark = crate::syntax::lexer::chars::head(&crate::check::types::unify::marks_of(name_p2));
        this.def_name = name_p2.clone();
        this
    };
    match &t_p6 {
        crate::check::types::Ty::TyFn(col_p9, params_pa, res_pb) => {
            let outer_color_pc = st_p1.color.clone();
            let outer_flex_pd = st_p1.color_flex.clone();
            let st0_pe = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.color = crate::check::types::Col::CBound;
                this.color_why = Text::lit("");
                this.color_flex = Array::new();
                this.col_up = fold(&sc_p4.cjoins, &this.col_up, &(|m_pk: &Map<Text, Text>, (lo_pl, hi_pm): &(Text, Text)| insert(m_pk, lo_pl, hi_pm)));
                this
            };
            let st1_pf = run_to_end(fold_job(clauses_p3.clone(), st0_pe.clone(), {
                let env2_p8 = env2_p8.clone();
                let params_pa = params_pa.clone();
                let res_pb = (**res_pb).clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                    let env2_p8 = env2_p8.clone();
                    let params_pa = params_pa.clone();
                    let res_pb = res_pb.clone();
                    entered(once_job(move || {
                        let s_pn = p0;
                        let c_po = p1;
                        prism_rtl::Turn::More(Rc::new(CheckClause { env_p0: env2_p8.clone(), st_p1: s_pn.clone(), c_p2: c_po.clone(), params_p3: params_pa.clone(), res_p4: res_pb.clone() }))
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }));
            let st1b_pg = crate::check::types::colors::settle_body(&crate::check::env::traits::solve_wants(&env_p0.g, &st1_pf, &givens_p7, &false), col_p9, name_p2);
            let st2_ph = crate::check::passes::clause_coverage(&env2_p8, &st1b_pg, clauses_p3, params_pa, span_p5);
            let st3_pi = if crate::check::types::colors::col_leq(&st2_ph.color, col_p9) {
                st2_ph.clone()
            } else {
                crate::check::types::recording::err_fix(&st2_ph, &Text::lit("calls-unbounded"), span_p5, &Text::from(format!("{} `{}` calls {} `{}`", &crate::check::types::colors::col_word(col_p9), name_p2, &crate::check::types::colors::col_word(&st2_ph.color), &st2_ph.color_why)), &Text::from(format!("mark `{}` `unbounded fn`, or run the call through `@Run`", name_p2)))
            };
            let st4_pj = crate::check::types::recording::note_fn(&st3_pi, span_p5, name_p2, col_p9, &st2_ph.color);
            {
                let mut this: crate::check::types::St = st4_pj.clone();
                this.color = outer_color_pc.clone();
                this.color_flex = outer_flex_pd.clone();
                this
            }
        },
        other_pp => {
            let st1_pq = run_to_end(fold_job(clauses_p3.clone(), st_p1.clone(), {
                let env2_p8 = env2_p8.clone();
                let other_pp = other_pp.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                    let env2_p8 = env2_p8.clone();
                    let other_pp = other_pp.clone();
                    entered(once_job(move || {
                        let s_pr = p0;
                        let c_ps = p1;
                        prism_rtl::Turn::More(Rc::new(CheckClause { env_p0: env2_p8.clone(), st_p1: s_pr.clone(), c_p2: c_ps.clone(), params_p3: Array::new(), res_p4: other_pp.clone() }))
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }));
            st1_pq.clone()
        },
    }
}

/// The step machine of `CheckClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
/// ```
pub struct CheckClauses {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub name_p2: Text,
    pub clauses_p3: Array<crate::syntax::decls::FnClause>,
    pub sc_p4: crate::check::types::Scheme,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for CheckClauses {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let name_p2 = &self.name_p2;
        let clauses_p3 = &self.clauses_p3;
        let sc_p4 = &self.sc_p4;
        let span_p5 = &self.span_p5;
        let clauses_p3 = clauses_p3.clone();
        let env_p0 = env_p0.clone();
        let name_p2 = name_p2.clone();
        let sc_p4 = sc_p4.clone();
        let span_p5 = span_p5.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::types::schemes::start_skolemize(sc_p4.clone()), move |skolemize_11216: crate::check::types::Ty| {
            let t_p6 = skolemize_11216;
            let givens_p7 = append(&env_p0.givens, &sc_p4.bounds);
            let env2_p8 = {
                let mut this: crate::check::expr::Env = env_p0.clone();
                this.givens = givens_p7.clone();
                this.mark = crate::syntax::lexer::chars::head(&crate::check::types::unify::marks_of(&name_p2));
                this.def_name = name_p2.clone();
                this
            };
            match &t_p6 {
                crate::check::types::Ty::TyFn(col_p9, params_pa, res_pb) => {
                    let outer_color_pc = st_p1.color.clone();
                    let outer_flex_pd = st_p1.color_flex.clone();
                    let st0_pe = {
                        let mut this: crate::check::types::St = st_p1.clone();
                        this.color = crate::check::types::Col::CBound;
                        this.color_why = Text::lit("");
                        this.color_flex = Array::new();
                        this.col_up = fold(&sc_p4.cjoins, &this.col_up, &(|m_pk: &Map<Text, Text>, (lo_pl, hi_pm): &(Text, Text)| insert(m_pk, lo_pl, hi_pm)));
                        this
                    };
                    let col_p9 = col_p9.clone();
                    let params_pa = params_pa.clone();
                    let res_pb = (**res_pb).clone();
                    call_value(fold_job(clauses_p3.clone(), st0_pe.clone(), {
                        let env2_p8 = env2_p8.clone();
                        let params_pa = params_pa.clone();
                        let res_pb = res_pb.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                            let env2_p8 = env2_p8.clone();
                            let params_pa = params_pa.clone();
                            let res_pb = res_pb.clone();
                            entered(once_job(move || {
                                let s_pn = p0;
                                let c_po = p1;
                                prism_rtl::Turn::More(Rc::new(CheckClause { env_p0: env2_p8.clone(), st_p1: s_pn.clone(), c_p2: c_po.clone(), params_p3: params_pa.clone(), res_p4: res_pb.clone() }))
                            }))
                        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_11768: crate::check::types::St| {
                        let st1_pf = fold_11768;
                        call_then(crate::check::env::traits::start_solve_wants(env_p0.g.clone(), st1_pf.clone(), givens_p7.clone(), false), move |solve_wants_11866: crate::check::types::St| call_then(crate::check::types::colors::start_settle_body(solve_wants_11866, col_p9.clone(), name_p2.clone()), move |settle_body_11854: crate::check::types::St| {
                            let st1b_pg = settle_body_11854;
                            call_then(crate::check::passes::start_clause_coverage(env2_p8.clone(), st1b_pg.clone(), clauses_p3.clone(), params_pa.clone(), span_p5.clone()), move |clause_coverage_11937: crate::check::types::St| {
                                let st2_ph = clause_coverage_11937;
                                let st3_pi = if crate::check::types::colors::col_leq(&st2_ph.color, &col_p9) {
                                    st2_ph.clone()
                                } else {
                                    crate::check::types::recording::err_fix(&st2_ph, &Text::lit("calls-unbounded"), &span_p5, &Text::from(format!("{} `{}` calls {} `{}`", &crate::check::types::colors::col_word(&col_p9), &name_p2, &crate::check::types::colors::col_word(&st2_ph.color), &st2_ph.color_why)), &Text::from(format!("mark `{}` `unbounded fn`, or run the call through `@Run`", &name_p2)))
                                };
                                let st4_pj = crate::check::types::recording::note_fn(&st3_pi, &span_p5, &name_p2, &col_p9, &st2_ph.color);
                                prism_rtl::Turn::Finished({
                                    let mut this: crate::check::types::St = st4_pj.clone();
                                    this.color = outer_color_pc.clone();
                                    this.color_flex = outer_flex_pd.clone();
                                    this
                                })
                            })
                        }))
                    })
                },
                other_pp => {
                    let other_pp = other_pp.clone();
                    call_value(fold_job(clauses_p3.clone(), st_p1.clone(), {
                        let env2_p8 = env2_p8.clone();
                        let other_pp = other_pp.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                            let env2_p8 = env2_p8.clone();
                            let other_pp = other_pp.clone();
                            entered(once_job(move || {
                                let s_pr = p0;
                                let c_ps = p1;
                                prism_rtl::Turn::More(Rc::new(CheckClause { env_p0: env2_p8.clone(), st_p1: s_pr.clone(), c_p2: c_ps.clone(), params_p3: Array::new(), res_p4: other_pp.clone() }))
                            }))
                        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_12432: crate::check::types::St| {
                        let st1_pq = fold_12432;
                        prism_rtl::Turn::Finished(st1_pq.clone())
                    })
                },
            }
        })
    }
}

/// `Start CheckClauses, x`: what the function value is when passed to `@Run`.
pub fn start_check_clauses(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, name_p2: Text, clauses_p3: Array<crate::syntax::decls::FnClause>, sc_p4: crate::check::types::Scheme, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckClauses { env_p0, st_p1, name_p2, clauses_p3, sc_p4, span_p5 })
}

/// ```prism
/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
/// ```
pub fn check_clause(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::syntax::decls::FnClause, params_p3: &Array<crate::check::types::Ty>, res_p4: &crate::check::types::Ty) -> crate::check::types::St {
    if &len(&c_p2.params) != &len(params_p3) {
        crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &c_p2.span, &Text::from(format!("this clause takes {} parameter{}; the signature has {}", &crate::check::errors::count_word(&len(&c_p2.params)), &(if &len(&c_p2.params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(params_p3)))))
    } else {
        {
            let (env2_p8, st1_p9) = run_to_end(fold_job(crate::check::errors::range0(&len(params_p3)), (env_p0.clone(), st_p1.clone()), {
                let c_p2 = c_p2.clone();
                let params_p3 = params_p3.clone();
                Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                    let c_p2 = c_p2.clone();
                    let params_p3 = params_p3.clone();
                    entered(once_job(move || {
                        let (en_p5, s_p6) = p0;
                        let i_p7 = p1;
                        prism_rtl::Turn::More(Rc::new(crate::check::expr::patterns::BindPattern { env_p0: en_p5.clone(), st_p1: s_p6.clone(), p_p2: or(&index(&c_p2.params, &i_p7), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: c_p2.span.clone() }), t_p3: or(&index(&params_p3, &i_p7), &crate::check::types::Ty::TyErr), refutable_p4: true }))
                    }))
                }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }));
            check_body(&env2_p8, &st1_p9, &c_p2.body, res_p4)
        }
    }
}

/// The step machine of `CheckClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
/// ```
pub struct CheckClause {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::syntax::decls::FnClause,
    pub params_p3: Array<crate::check::types::Ty>,
    pub res_p4: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for CheckClause {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let params_p3 = &self.params_p3;
        let res_p4 = &self.res_p4;
        if &len(&c_p2.params) != &len(params_p3) {
            prism_rtl::Turn::Finished(crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &c_p2.span, &Text::from(format!("this clause takes {} parameter{}; the signature has {}", &crate::check::errors::count_word(&len(&c_p2.params)), &(if &len(&c_p2.params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(params_p3))))))
        } else {
            {
                let c_p2 = c_p2.clone();
                let env_p0 = env_p0.clone();
                let params_p3 = params_p3.clone();
                let res_p4 = res_p4.clone();
                let st_p1 = st_p1.clone();
                call_value(fold_job(crate::check::errors::range0(&len(&params_p3)), (env_p0.clone(), st_p1.clone()), {
                    let c_p2 = c_p2.clone();
                    let params_p3 = params_p3.clone();
                    Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                        let c_p2 = c_p2.clone();
                        let params_p3 = params_p3.clone();
                        entered(once_job(move || {
                            let (en_p5, s_p6) = p0;
                            let i_p7 = p1;
                            prism_rtl::Turn::More(Rc::new(crate::check::expr::patterns::BindPattern { env_p0: en_p5.clone(), st_p1: s_p6.clone(), p_p2: or(&index(&c_p2.params, &i_p7), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: c_p2.span.clone() }), t_p3: or(&index(&params_p3, &i_p7), &crate::check::types::Ty::TyErr), refutable_p4: true }))
                        }))
                    }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                }), move |fold_12863: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2_p8, st1_p9) = fold_12863;
                    prism_rtl::Turn::More(Rc::new(CheckBody { env_p0: env2_p8.clone(), st_p1: st1_p9.clone(), body_p2: c_p2.body.clone(), res_p3: res_p4.clone() }))
                })
            }
        }
    }
}

/// `Start CheckClause, x`: what the function value is when passed to `@Run`.
pub fn start_check_clause(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, c_p2: crate::syntax::decls::FnClause, params_p3: Array<crate::check::types::Ty>, res_p4: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckClause { env_p0, st_p1, c_p2, params_p3, res_p4 })
}

/// ```prism
/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
/// ```
pub fn check_body(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, body_p2: &crate::syntax::decls::FnBody, res_p3: &crate::check::types::Ty) -> crate::check::types::St {
    match body_p2 {
        crate::syntax::decls::FnBody::BodyExpr(e_p4) => crate::check::expr::check(env_p0, st_p1, e_p4, res_p3),
        crate::syntax::decls::FnBody::BodyBlock(b_p5) => if &env_p0.mark == &Text::lit("@") {
            match crate::check::types::recording::walk(st_p1, res_p3) {
                crate::check::types::Ty::TyAt(inner_p6, rw_p7) => {
                    let env2_p8 = {
                        let mut this: crate::check::expr::Env = env_p0.clone();
                        this.scope = rw_p7;
                        this
                    };
                    let (t_p9, st2_pa) = crate::check::blocks::infer_widget_block(&env2_p8, st_p1, b_p5);
                    crate::check::types::unify::unify(&st2_pa, &*inner_p6, &t_p9, &b_p5.span)
                },
                other_pb => crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &b_p5.span, &Text::from(format!("a widget block builds a blueprint; the signature says `{}`", &crate::check::types::show_ty(st_p1, &other_pb)))),
            }
        } else {
            if (&env_p0.mark == &Text::lit("?")) || (&env_p0.mark == &Text::lit("~")) {
                {
                    let (t_pc, st2_pd) = crate::check::blocks::structure::infer_given_block(env_p0, st_p1, b_p5, &env_p0.mark);
                    crate::check::types::unify::unify(&st2_pd, res_p3, &t_pc, &b_p5.span)
                }
            } else {
                {
                    let (t_pe, st2_pf) = infer_expr_block(env_p0, st_p1, b_p5);
                    crate::check::types::unify::unify(&st2_pf, res_p3, &t_pe, &b_p5.span)
                }
            }
        },
    }
}

/// The step machine of `CheckBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
/// ```
pub struct CheckBody {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub body_p2: crate::syntax::decls::FnBody,
    pub res_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for CheckBody {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let body_p2 = &self.body_p2;
        let res_p3 = &self.res_p3;
        match body_p2 {
            crate::syntax::decls::FnBody::BodyExpr(e_p4) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p4.clone(), expected_p3: res_p3.clone() })),
            crate::syntax::decls::FnBody::BodyBlock(b_p5) => if &env_p0.mark == &Text::lit("@") {
                {
                    let b_p5 = b_p5.clone();
                    let env_p0 = env_p0.clone();
                    let res_p3 = res_p3.clone();
                    let st_p1 = st_p1.clone();
                    call_then(crate::check::types::recording::start_walk(st_p1.clone(), res_p3.clone()), move |walk_13433: crate::check::types::Ty| match walk_13433 {
                        crate::check::types::Ty::TyAt(inner_p6, rw_p7) => {
                            let env2_p8 = {
                                let mut this: crate::check::expr::Env = env_p0.clone();
                                this.scope = rw_p7.clone();
                                this
                            };
                            call_then(crate::check::blocks::start_infer_widget_block(env2_p8.clone(), st_p1.clone(), b_p5.clone()), move |infer_widget_block_13598: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t_p9, st2_pa) = infer_widget_block_13598;
                                prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st2_pa.clone(), expected_p1: (*inner_p6).clone(), found_p2: t_p9.clone(), span_p3: b_p5.span.clone() }))
                            })
                        },
                        other_pb => call_then(crate::check::types::start_show_ty(st_p1.clone(), other_pb.clone()), move |show_ty_13783: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err(&st_p1, &Text::lit("mismatch"), &b_p5.span, &Text::from(format!("a widget block builds a blueprint; the signature says `{}`", &show_ty_13783))))),
                    })
                }
            } else {
                if (&env_p0.mark == &Text::lit("?")) || (&env_p0.mark == &Text::lit("~")) {
                    {
                        let b_p5 = b_p5.clone();
                        let env_p0 = env_p0.clone();
                        let res_p3 = res_p3.clone();
                        let st_p1 = st_p1.clone();
                        call_then(crate::check::blocks::structure::start_infer_given_block(env_p0.clone(), st_p1.clone(), b_p5.clone(), env_p0.mark.clone()), move |infer_given_block_13885: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_pc, st2_pd) = infer_given_block_13885;
                            prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st2_pd.clone(), expected_p1: res_p3.clone(), found_p2: t_pc.clone(), span_p3: b_p5.span.clone() }))
                        })
                    }
                } else {
                    {
                        let b_p5 = b_p5.clone();
                        let env_p0 = env_p0.clone();
                        let res_p3 = res_p3.clone();
                        let st_p1 = st_p1.clone();
                        call_then(start_infer_expr_block(env_p0.clone(), st_p1.clone(), b_p5.clone()), move |infer_expr_block_14003: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_pe, st2_pf) = infer_expr_block_14003;
                            prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st2_pf.clone(), expected_p1: res_p3.clone(), found_p2: t_pe.clone(), span_p3: b_p5.span.clone() }))
                        })
                    }
                }
            },
        }
    }
}

/// `Start CheckBody, x`: what the function value is when passed to `@Run`.
pub fn start_check_body(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, body_p2: crate::syntax::decls::FnBody, res_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckBody { env_p0, st_p1, body_p2, res_p3 })
}

/// ```prism
/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
/// ```
pub fn infer_template(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Template) -> (crate::check::types::Ty, crate::check::types::St) {
    let st2_p3 = run_to_end(fold_job(t_p2.parts.clone(), st_p1.clone(), {
        let env_p0 = env_p0.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::TemplatePart)| {
            let env_p0 = env_p0.clone();
            entered(once_job(move || {
                let s_p4 = p0;
                let part_p5 = p1;
                prism_rtl::Turn::More(Rc::new(TemplatePartCheck { env_p0: env_p0.clone(), st_p1: s_p4.clone(), part_p2: part_p5.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    (crate::check::types::t_text(), st2_p3.clone())
}

/// The step machine of `InferTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
/// ```
pub struct InferTemplate {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Template,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferTemplate {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let env_p0 = env_p0.clone();
        let st_p1 = st_p1.clone();
        let t_p2 = t_p2.clone();
        call_value(fold_job(t_p2.parts.clone(), st_p1.clone(), {
            let env_p0 = env_p0.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::TemplatePart)| {
                let env_p0 = env_p0.clone();
                entered(once_job(move || {
                    let s_p4 = p0;
                    let part_p5 = p1;
                    prism_rtl::Turn::More(Rc::new(TemplatePartCheck { env_p0: env_p0.clone(), st_p1: s_p4.clone(), part_p2: part_p5.clone() }))
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }), move |fold_14441: crate::check::types::St| {
            let st2_p3 = fold_14441;
            prism_rtl::Turn::Finished((crate::check::types::t_text(), st2_p3.clone()))
        })
    }
}

/// `Start InferTemplate, x`: what the function value is when passed to `@Run`.
pub fn start_infer_template(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::syntax::Template) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferTemplate { env_p0, st_p1, t_p2 })
}

/// ```prism
/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
/// ```
pub fn template_part_check(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, part_p2: &crate::syntax::TemplatePart) -> crate::check::types::St {
    match part_p2 {
        crate::syntax::TemplatePart::TpText(_) => st_p1.clone(),
        crate::syntax::TemplatePart::TpPlaceholder(x_p3, _) => {
            let (t_p4, st2_p5) = crate::check::expr::infer(env_p0, st_p1, x_p3);
            crate::check::expr::show_want(&st2_p5, &(if crate::check::expr::is_time_sigil(&crate::check::types::head_sigil(&st2_p5, &t_p4)) {
                crate::check::expr::inner_of(&st2_p5, &t_p4)
            } else {
                t_p4.clone()
            }), &x_p3.span)
        },
        crate::syntax::TemplatePart::TpBlock(b_p6) => {
            let (t_p7, st2_p8) = infer_expr_block(env_p0, st_p1, b_p6);
            st2_p8.clone()
        },
        crate::syntax::TemplatePart::TpCall(n_p9, args_pa, parts_ob, span_pc) => template_call_check(env_p0, st_p1, n_p9, args_pa, parts_ob, span_pc),
    }
}

/// The step machine of `TemplatePartCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
/// ```
pub struct TemplatePartCheck {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub part_p2: crate::syntax::TemplatePart,
}

impl prism_rtl::Job<crate::check::types::St> for TemplatePartCheck {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let part_p2 = &self.part_p2;
        match part_p2 {
            crate::syntax::TemplatePart::TpText(_) => prism_rtl::Turn::Finished(st_p1.clone()),
            crate::syntax::TemplatePart::TpPlaceholder(x_p3, _) => {
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                let x_p3 = x_p3.clone();
                call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), x_p3.clone()), move |infer_14706: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p4, st2_p5) = infer_14706;
                    call_then(crate::check::types::start_head_sigil(st2_p5.clone(), t_p4.clone()), move |head_sigil_14762: Text| prism_rtl::Turn::More(Rc::new(crate::check::expr::ShowWant { st_p0: st2_p5.clone(), t_p1: if crate::check::expr::is_time_sigil(&head_sigil_14762) {
                        crate::check::expr::inner_of(&st2_p5, &t_p4)
                    } else {
                        t_p4.clone()
                    }, span_p2: x_p3.span.clone() })))
                })
            },
            crate::syntax::TemplatePart::TpBlock(b_p6) => {
                let b_p6 = b_p6.clone();
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                call_then(start_infer_expr_block(env_p0.clone(), st_p1.clone(), b_p6.clone()), move |infer_expr_block_14853: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p7, st2_p8) = infer_expr_block_14853;
                    prism_rtl::Turn::Finished(st2_p8.clone())
                })
            },
            crate::syntax::TemplatePart::TpCall(n_p9, args_pa, parts_ob, span_pc) => prism_rtl::Turn::More(Rc::new(TemplateCallCheck { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p9.clone(), args_p3: args_pa.clone(), parts_o4: parts_ob.clone(), span_p5: span_pc.clone() })),
        }
    }
}

/// `Start TemplatePartCheck, x`: what the function value is when passed to `@Run`.
pub fn start_template_part_check(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, part_p2: crate::syntax::TemplatePart) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(TemplatePartCheck { env_p0, st_p1, part_p2 })
}

/// ```prism
/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
/// ```
pub fn template_call_check(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, args_p3: &Array<crate::syntax::Arg>, parts_o4: &Option<Array<crate::syntax::TemplatePart>>, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    let plain_p6 = crate::syntax::SName { sigils: crate::syntax::lexer::chars::after_first(&n_p2.sigils), path_: n_p2.path_.clone(), span: n_p2.span.clone() };
    let (qk1_o9, _) = crate::check::env::names::resolve_value(&env_p0.g, &env_p0.home, n_p2);
    let callee_p7 = if &qk1_o9 != &None { n_p2.clone() } else { plain_p6.clone() };
    let (qk_oa, ignore2_pb) = crate::check::env::names::resolve_value(&env_p0.g, &env_p0.home, &callee_p7);
    let cname_p8 = crate::check::env::sname_key(&plain_p6);
    match &qk_oa {
        None => {
            let (ignore3_pc, st2_pd) = crate::check::expr::calls::call_global(env_p0, st_p1, &callee_p7, &Array::new(), span_p5, &Array::new(), &callee_p7.span);
            st2_pd.clone()
        },
        Some(qk_pe) => {
            let clauses_pf = match get(&env_p0.g.fn_at, qk_pe) {
                Some(i_ph) => match index(&env_p0.g.defs, &i_ph) {
                    Some(d_pi) => match &d_pi.body {
                        crate::check::env::DefBody::DbFn(cs_pj) => cs_pj.clone(),
                        _ => Array::new(),
                    },
                    None => Array::new(),
                },
                None => Array::new(),
            };
            let arity_pg = match index(&clauses_pf, &Nat::from(0u32)) {
                Some(c_pk) => len(&c_pk.params),
                None => Nat::from(0u32),
            };
            if &len(&clauses_pf) == &Nat::from(0u32) {
                crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), span_p5, &Text::from(format!("`<@{}>` calls a function without clauses, which name no parameters for its attributes", &cname_p8)))
            } else {
                {
                    let (slots_pu, st1_pv) = run_to_end(fold_job(args_p3.clone(), (Map::new(), st_p1.clone()), {
                        let clauses_pf = clauses_pf.clone();
                        let cname_p8 = cname_p8.clone();
                        Rc::new(move |(p0, p1): ((Map<Text, crate::syntax::Expr>, crate::check::types::St), crate::syntax::Arg)| {
                            let clauses_pf = clauses_pf.clone();
                            let cname_p8 = cname_p8.clone();
                            entered(once_job(move || {
                                let (m_pp, s_pq) = p0;
                                let a_pr = p1;
                                match &a_pr.name {
                                    Some(id_ps) => {
                                        let id_ps = id_ps.clone();
                                        call_then(start_template_slot(clauses_pf.clone(), id_ps.name.clone()), move |template_slot_16652: Option<Nat>| match template_slot_16652 {
                                            Some(j_pt) => if crate::check::env::has_key(&m_pp, &Text::from(format!("{}", &j_pt))) {
                                                prism_rtl::Turn::Finished((m_pp.clone(), crate::check::types::recording::err(&s_pq, &Text::lit("mismatch"), &a_pr.span, &Text::from(format!("`{}` is given twice", &id_ps.name)))))
                                            } else {
                                                prism_rtl::Turn::Finished((insert(&m_pp, &Text::from(format!("{}", &j_pt)), &a_pr.value), s_pq.clone()))
                                            },
                                            None => prism_rtl::Turn::Finished((m_pp.clone(), crate::check::types::recording::err(&s_pq, &Text::lit("mismatch"), &a_pr.span, &Text::from(format!("`{}` has no parameter `{}`", &cname_p8, &id_ps.name))))),
                                        })
                                    },
                                    None => prism_rtl::Turn::Finished((m_pp.clone(), crate::check::types::recording::err(&s_pq, &Text::lit("mismatch"), &a_pr.span, &Text::lit("a template call names each argument: `name={{value}}`")))),
                                }
                            }))
                        }) as Rc<dyn Fn(((Map<Text, crate::syntax::Expr>, crate::check::types::St), crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<(Map<Text, crate::syntax::Expr>, crate::check::types::St)>>>
                    }));
                    let body_ol = match parts_o4 {
                        Some(ps_p10) => Some(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(crate::syntax::Template { keyword: Text::lit("InlineText"), lang: Text::lit(""), delims: Text::lit("double"), parts: ps_p10.clone(), span: span_p5.clone() })), span: span_p5.clone() }),
                        None => None,
                    };
                    let last_pm = crate::syntax::lexer::chars::dec(&arity_pg);
                    let st2_pn = match &body_ol {
                        Some(ignore4_p11) => if (&arity_pg == &Nat::from(0u32)) || crate::check::env::has_key(&slots_pu, &Text::from(format!("{}", &last_pm))) {
                            crate::check::types::recording::err(&st1_pv, &Text::lit("mismatch"), span_p5, &Text::from(format!("`{}` has no parameter left for the call\'s body", &cname_p8)))
                        } else {
                            st1_pv.clone()
                        },
                        None => st1_pv.clone(),
                    };
                    let quiet_po = &len(&st1_pv.diags) > &len(&st_p1.diags);
                    let (positional_p17, st3_p18) = run_to_end(fold_job(crate::check::errors::range0(&arity_pg), (Array::new(), st2_pn.clone()), {
                        let slots_pu = slots_pu.clone();
                        let body_ol = body_ol.clone();
                        let last_pm = last_pm.clone();
                        let span_p5 = span_p5.clone();
                        let clauses_pf = clauses_pf.clone();
                        let cname_p8 = cname_p8.clone();
                        let quiet_po = quiet_po;
                        Rc::new(move |(p0, p1): ((Array<crate::syntax::Arg>, crate::check::types::St), Nat)| {
                            let slots_pu = slots_pu.clone();
                            let body_ol = body_ol.clone();
                            let last_pm = last_pm.clone();
                            let span_p5 = span_p5.clone();
                            let clauses_pf = clauses_pf.clone();
                            let cname_p8 = cname_p8.clone();
                            let quiet_po = quiet_po;
                            entered(once_job(move || {
                                let (acc_p12, s_p13) = p0;
                                let j_p14 = p1;
                                match get(&slots_pu, &Text::from(format!("{}", &j_p14))) {
                                    Some(v_p15) => prism_rtl::Turn::Finished((push(&acc_p12, &crate::syntax::Arg { name: None, value: v_p15.clone(), span: v_p15.span.clone() }), s_p13.clone())),
                                    None => match &body_ol {
                                        Some(b_p16) => if &j_p14 == &last_pm {
                                            prism_rtl::Turn::Finished((push(&acc_p12, &crate::syntax::Arg { name: None, value: b_p16.clone(), span: span_p5.clone() }), s_p13.clone()))
                                        } else {
                                            prism_rtl::Turn::More(Rc::new(TemplateMissing { acc_p0: acc_p12.clone(), st_p1: s_p13.clone(), clauses_p2: clauses_pf.clone(), j_p3: j_p14.clone(), cname_p4: cname_p8.clone(), span_p5: span_p5.clone(), quiet_p6: quiet_po }))
                                        },
                                        None => prism_rtl::Turn::More(Rc::new(TemplateMissing { acc_p0: acc_p12.clone(), st_p1: s_p13.clone(), clauses_p2: clauses_pf.clone(), j_p3: j_p14.clone(), cname_p4: cname_p8.clone(), span_p5: span_p5.clone(), quiet_p6: quiet_po })),
                                    },
                                }
                            }))
                        }) as Rc<dyn Fn(((Array<crate::syntax::Arg>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::check::types::St)>>>
                    }));
                    let (t_p19, st4_p1a) = crate::check::expr::calls::call_global(env_p0, &st3_p18, &callee_p7, &positional_p17, span_p5, &Array::new(), &callee_p7.span);
                    crate::check::types::unify::unify(&st4_p1a, &crate::check::types::t_text(), &t_p19, span_p5)
                }
            }
        },
    }
}

/// The step machine of `TemplateCallCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
/// ```
pub struct TemplateCallCheck {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub args_p3: Array<crate::syntax::Arg>,
    pub parts_o4: Option<Array<crate::syntax::TemplatePart>>,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for TemplateCallCheck {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let args_p3 = &self.args_p3;
        let parts_o4 = &self.parts_o4;
        let span_p5 = &self.span_p5;
        let plain_p6 = crate::syntax::SName { sigils: crate::syntax::lexer::chars::after_first(&n_p2.sigils), path_: n_p2.path_.clone(), span: n_p2.span.clone() };
        let (qk1_o9, _) = crate::check::env::names::resolve_value(&env_p0.g, &env_p0.home, n_p2);
        let callee_p7 = if &qk1_o9 != &None { n_p2.clone() } else { plain_p6.clone() };
        let (qk_oa, ignore2_pb) = crate::check::env::names::resolve_value(&env_p0.g, &env_p0.home, &callee_p7);
        let cname_p8 = crate::check::env::sname_key(&plain_p6);
        match &qk_oa {
            None => {
                let env_p0 = env_p0.clone();
                let span_p5 = span_p5.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::expr::calls::start_call_global(env_p0.clone(), st_p1.clone(), callee_p7.clone(), Array::new(), span_p5.clone(), Array::new(), callee_p7.span.clone()), move |call_global_15910: (crate::check::types::Ty, crate::check::types::St)| {
                    let (ignore3_pc, st2_pd) = call_global_15910;
                    prism_rtl::Turn::Finished(st2_pd.clone())
                })
            },
            Some(qk_pe) => {
                let clauses_pf = match get(&env_p0.g.fn_at, qk_pe) {
                    Some(i_ph) => match index(&env_p0.g.defs, &i_ph) {
                        Some(d_pi) => match &d_pi.body {
                            crate::check::env::DefBody::DbFn(cs_pj) => cs_pj.clone(),
                            _ => Array::new(),
                        },
                        None => Array::new(),
                    },
                    None => Array::new(),
                };
                let arity_pg = match index(&clauses_pf, &Nat::from(0u32)) {
                    Some(c_pk) => len(&c_pk.params),
                    None => Nat::from(0u32),
                };
                if &len(&clauses_pf) == &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), span_p5, &Text::from(format!("`<@{}>` calls a function without clauses, which name no parameters for its attributes", &cname_p8))))
                } else {
                    {
                        let parts_o4 = parts_o4.clone();
                        let args_p3 = args_p3.clone();
                        let env_p0 = env_p0.clone();
                        let span_p5 = span_p5.clone();
                        let st_p1 = st_p1.clone();
                        call_value(fold_job(args_p3.clone(), (Map::new(), st_p1.clone()), {
                            let clauses_pf = clauses_pf.clone();
                            let cname_p8 = cname_p8.clone();
                            Rc::new(move |(p0, p1): ((Map<Text, crate::syntax::Expr>, crate::check::types::St), crate::syntax::Arg)| {
                                let clauses_pf = clauses_pf.clone();
                                let cname_p8 = cname_p8.clone();
                                entered(once_job(move || {
                                    let (m_pp, s_pq) = p0;
                                    let a_pr = p1;
                                    match &a_pr.name {
                                        Some(id_ps) => {
                                            let id_ps = id_ps.clone();
                                            call_then(start_template_slot(clauses_pf.clone(), id_ps.name.clone()), move |template_slot_16652: Option<Nat>| match template_slot_16652 {
                                                Some(j_pt) => if crate::check::env::has_key(&m_pp, &Text::from(format!("{}", &j_pt))) {
                                                    prism_rtl::Turn::Finished((m_pp.clone(), crate::check::types::recording::err(&s_pq, &Text::lit("mismatch"), &a_pr.span, &Text::from(format!("`{}` is given twice", &id_ps.name)))))
                                                } else {
                                                    prism_rtl::Turn::Finished((insert(&m_pp, &Text::from(format!("{}", &j_pt)), &a_pr.value), s_pq.clone()))
                                                },
                                                None => prism_rtl::Turn::Finished((m_pp.clone(), crate::check::types::recording::err(&s_pq, &Text::lit("mismatch"), &a_pr.span, &Text::from(format!("`{}` has no parameter `{}`", &cname_p8, &id_ps.name))))),
                                            })
                                        },
                                        None => prism_rtl::Turn::Finished((m_pp.clone(), crate::check::types::recording::err(&s_pq, &Text::lit("mismatch"), &a_pr.span, &Text::lit("a template call names each argument: `name={{value}}`")))),
                                    }
                                }))
                            }) as Rc<dyn Fn(((Map<Text, crate::syntax::Expr>, crate::check::types::St), crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<(Map<Text, crate::syntax::Expr>, crate::check::types::St)>>>
                        }), move |fold_16567: (Map<Text, crate::syntax::Expr>, crate::check::types::St)| {
                            let (slots_pu, st1_pv) = fold_16567;
                            let body_ol = match &parts_o4 {
                                Some(ps_p10) => Some(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(crate::syntax::Template { keyword: Text::lit("InlineText"), lang: Text::lit(""), delims: Text::lit("double"), parts: ps_p10.clone(), span: span_p5.clone() })), span: span_p5.clone() }),
                                None => None,
                            };
                            let last_pm = crate::syntax::lexer::chars::dec(&arity_pg);
                            let st2_pn = match &body_ol {
                                Some(ignore4_p11) => if (&arity_pg == &Nat::from(0u32)) || crate::check::env::has_key(&slots_pu, &Text::from(format!("{}", &last_pm))) {
                                    crate::check::types::recording::err(&st1_pv, &Text::lit("mismatch"), &span_p5, &Text::from(format!("`{}` has no parameter left for the call\'s body", &cname_p8)))
                                } else {
                                    st1_pv.clone()
                                },
                                None => st1_pv.clone(),
                            };
                            let quiet_po = &len(&st1_pv.diags) > &len(&st_p1.diags);
                            call_value(fold_job(crate::check::errors::range0(&arity_pg), (Array::new(), st2_pn.clone()), {
                                let slots_pu = slots_pu.clone();
                                let body_ol = body_ol.clone();
                                let last_pm = last_pm.clone();
                                let span_p5 = span_p5.clone();
                                let clauses_pf = clauses_pf.clone();
                                let cname_p8 = cname_p8.clone();
                                let quiet_po = quiet_po;
                                Rc::new(move |(p0, p1): ((Array<crate::syntax::Arg>, crate::check::types::St), Nat)| {
                                    let slots_pu = slots_pu.clone();
                                    let body_ol = body_ol.clone();
                                    let last_pm = last_pm.clone();
                                    let span_p5 = span_p5.clone();
                                    let clauses_pf = clauses_pf.clone();
                                    let cname_p8 = cname_p8.clone();
                                    let quiet_po = quiet_po;
                                    entered(once_job(move || {
                                        let (acc_p12, s_p13) = p0;
                                        let j_p14 = p1;
                                        match get(&slots_pu, &Text::from(format!("{}", &j_p14))) {
                                            Some(v_p15) => prism_rtl::Turn::Finished((push(&acc_p12, &crate::syntax::Arg { name: None, value: v_p15.clone(), span: v_p15.span.clone() }), s_p13.clone())),
                                            None => match &body_ol {
                                                Some(b_p16) => if &j_p14 == &last_pm {
                                                    prism_rtl::Turn::Finished((push(&acc_p12, &crate::syntax::Arg { name: None, value: b_p16.clone(), span: span_p5.clone() }), s_p13.clone()))
                                                } else {
                                                    prism_rtl::Turn::More(Rc::new(TemplateMissing { acc_p0: acc_p12.clone(), st_p1: s_p13.clone(), clauses_p2: clauses_pf.clone(), j_p3: j_p14.clone(), cname_p4: cname_p8.clone(), span_p5: span_p5.clone(), quiet_p6: quiet_po }))
                                                },
                                                None => prism_rtl::Turn::More(Rc::new(TemplateMissing { acc_p0: acc_p12.clone(), st_p1: s_p13.clone(), clauses_p2: clauses_pf.clone(), j_p3: j_p14.clone(), cname_p4: cname_p8.clone(), span_p5: span_p5.clone(), quiet_p6: quiet_po })),
                                            },
                                        }
                                    }))
                                }) as Rc<dyn Fn(((Array<crate::syntax::Arg>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::check::types::St)>>>
                            }), move |fold_17651: (Array<crate::syntax::Arg>, crate::check::types::St)| {
                                let (positional_p17, st3_p18) = fold_17651;
                                call_then(crate::check::expr::calls::start_call_global(env_p0.clone(), st3_p18.clone(), callee_p7.clone(), positional_p17.clone(), span_p5.clone(), Array::new(), callee_p7.span.clone()), move |call_global_18116: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (t_p19, st4_p1a) = call_global_18116;
                                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st4_p1a.clone(), expected_p1: crate::check::types::t_text(), found_p2: t_p19.clone(), span_p3: span_p5.clone() }))
                                })
                            })
                        })
                    }
                }
            },
        }
    }
}

/// `Start TemplateCallCheck, x`: what the function value is when passed to `@Run`.
pub fn start_template_call_check(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, args_p3: Array<crate::syntax::Arg>, parts_o4: Option<Array<crate::syntax::TemplatePart>>, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(TemplateCallCheck { env_p0, st_p1, n_p2, args_p3, parts_o4, span_p5 })
}

/// ```prism
/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
/// ```
pub fn template_missing(acc_p0: &Array<crate::syntax::Arg>, st_p1: &crate::check::types::St, clauses_p2: &Array<crate::syntax::decls::FnClause>, j_p3: &Nat, cname_p4: &Text, span_p5: &crate::syntax::Range, quiet_p6: &bool) -> (Array<crate::syntax::Arg>, crate::check::types::St) {
    let pname_p7 = match index(clauses_p2, &Nat::from(0u32)) {
        Some(c_p9) => match index(&c_p9.params, j_p3) {
            Some(p_pa) => crate::check::shrink::locals::param_name_of(&p_pa),
            None => Text::lit(""),
        },
        None => Text::lit(""),
    };
    let st2_p8 = if *quiet_p6 {
        st_p1.clone()
    } else {
        crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), span_p5, &Text::from(format!("`<@{}>` needs `{}=`", cname_p4, &pname_p7)))
    };
    (push(acc_p0, &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p5.clone() }, span: span_p5.clone() }), st2_p8.clone())
}

/// The step machine of `TemplateMissing`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
/// ```
pub struct TemplateMissing {
    pub acc_p0: Array<crate::syntax::Arg>,
    pub st_p1: crate::check::types::St,
    pub clauses_p2: Array<crate::syntax::decls::FnClause>,
    pub j_p3: Nat,
    pub cname_p4: Text,
    pub span_p5: crate::syntax::Range,
    pub quiet_p6: bool,
}

impl prism_rtl::Job<(Array<crate::syntax::Arg>, crate::check::types::St)> for TemplateMissing {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arg>, crate::check::types::St)> {
        let acc_p0 = &self.acc_p0;
        let st_p1 = &self.st_p1;
        let clauses_p2 = &self.clauses_p2;
        let j_p3 = &self.j_p3;
        let cname_p4 = &self.cname_p4;
        let span_p5 = &self.span_p5;
        let quiet_p6 = &self.quiet_p6;
        let pname_p7 = match index(clauses_p2, &Nat::from(0u32)) {
            Some(c_p9) => match index(&c_p9.params, j_p3) {
                Some(p_pa) => crate::check::shrink::locals::param_name_of(&p_pa),
                None => Text::lit(""),
            },
            None => Text::lit(""),
        };
        let st2_p8 = if *quiet_p6 {
            st_p1.clone()
        } else {
            crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), span_p5, &Text::from(format!("`<@{}>` needs `{}=`", cname_p4, &pname_p7)))
        };
        prism_rtl::Turn::Finished((push(acc_p0, &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p5.clone() }, span: span_p5.clone() }), st2_p8.clone()))
    }
}

/// `Start TemplateMissing, x`: what the function value is when passed to `@Run`.
pub fn start_template_missing(acc_p0: Array<crate::syntax::Arg>, st_p1: crate::check::types::St, clauses_p2: Array<crate::syntax::decls::FnClause>, j_p3: Nat, cname_p4: Text, span_p5: crate::syntax::Range, quiet_p6: bool) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::check::types::St)>> {
    Rc::new(TemplateMissing { acc_p0, st_p1, clauses_p2, j_p3, cname_p4, span_p5, quiet_p6 })
}

/// ```prism
/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
/// ```
pub fn template_slot(clauses_p0: &Array<crate::syntax::decls::FnClause>, name_p1: &Text) -> Option<Nat> {
    let found_p7 = run_to_end(fold_job(clauses_p0.clone(), Array::new(), {
        let name_p1 = name_p1.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::syntax::decls::FnClause)| {
            let name_p1 = name_p1.clone();
            entered(once_job(move || {
                let acc_p2 = p0;
                let c_p3 = p1;
                fold_job(crate::check::errors::range0(&len(&c_p3.params)), acc_p2.clone(), {
                    let c_p3 = c_p3.clone();
                    let name_p1 = name_p1.clone();
                    Rc::new(move |(p0, p1): (Array<Nat>, Nat)| {
                        let c_p3 = c_p3.clone();
                        let name_p1 = name_p1.clone();
                        entered(once_job(move || {
                            let a2_p4 = p0;
                            let i_p5 = p1;
                            match index(&c_p3.params, &i_p5) {
                                Some(p_p6) => if &crate::check::shrink::locals::param_name_of(&p_p6) == &name_p1 {
                                    prism_rtl::Turn::Finished(crate::check::types::add_nat(&a2_p4, &i_p5))
                                } else {
                                    prism_rtl::Turn::Finished(a2_p4.clone())
                                },
                                None => prism_rtl::Turn::Finished(a2_p4.clone()),
                            }
                        }))
                    }) as Rc<dyn Fn((Array<Nat>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    if &len(&found_p7) == &Nat::from(1u32) {
        index(&found_p7, &Nat::from(0u32))
    } else {
        None
    }
}

/// The step machine of `TemplateSlot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
/// ```
pub struct TemplateSlot {
    pub clauses_p0: Array<crate::syntax::decls::FnClause>,
    pub name_p1: Text,
}

impl prism_rtl::Job<Option<Nat>> for TemplateSlot {
    fn cycle(&self) -> prism_rtl::Turn<Option<Nat>> {
        let clauses_p0 = &self.clauses_p0;
        let name_p1 = &self.name_p1;
        let clauses_p0 = clauses_p0.clone();
        let name_p1 = name_p1.clone();
        call_value(fold_job(clauses_p0.clone(), Array::new(), {
            let name_p1 = name_p1.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::syntax::decls::FnClause)| {
                let name_p1 = name_p1.clone();
                entered(once_job(move || {
                    let acc_p2 = p0;
                    let c_p3 = p1;
                    fold_job(crate::check::errors::range0(&len(&c_p3.params)), acc_p2.clone(), {
                        let c_p3 = c_p3.clone();
                        let name_p1 = name_p1.clone();
                        Rc::new(move |(p0, p1): (Array<Nat>, Nat)| {
                            let c_p3 = c_p3.clone();
                            let name_p1 = name_p1.clone();
                            entered(once_job(move || {
                                let a2_p4 = p0;
                                let i_p5 = p1;
                                match index(&c_p3.params, &i_p5) {
                                    Some(p_p6) => if &crate::check::shrink::locals::param_name_of(&p_p6) == &name_p1 {
                                        prism_rtl::Turn::Finished(crate::check::types::add_nat(&a2_p4, &i_p5))
                                    } else {
                                        prism_rtl::Turn::Finished(a2_p4.clone())
                                    },
                                    None => prism_rtl::Turn::Finished(a2_p4.clone()),
                                }
                            }))
                        }) as Rc<dyn Fn((Array<Nat>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                    }).cycle()
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        }), move |fold_19010: Array<Nat>| {
            let found_p7 = fold_19010;
            if &len(&found_p7) == &Nat::from(1u32) {
                prism_rtl::Turn::Finished(index(&found_p7, &Nat::from(0u32)))
            } else {
                prism_rtl::Turn::Finished(None)
            }
        })
    }
}

/// `Start TemplateSlot, x`: what the function value is when passed to `@Run`.
pub fn start_template_slot(clauses_p0: Array<crate::syntax::decls::FnClause>, name_p1: Text) -> Rc<dyn prism_rtl::Job<Option<Nat>>> {
    Rc::new(TemplateSlot { clauses_p0, name_p1 })
}
