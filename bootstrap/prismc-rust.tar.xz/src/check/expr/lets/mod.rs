//! The module `Check.Expr.Lets`, from `target/bootstrap/src/prismc/check/expr/lets.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub fn infer_expr_block_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block) -> (crate::check::types::Ty, crate::check::types::St) {
    if is_widgetish_f(&b_p2.stmts_p) {
        crate::check::blocks::infer_widget_block_f(env_p0, st_p1, b_p2)
    } else {
        {
            let (env2_p3, st2_p4) = bind_group_f(env_p0, &crate::check::expr::patterns::block_bound_once_f(env_p0, st_p1, &b_p2.stmts_p), &b_p2.stmts_p);
            match crate::syntax::lexer::chars::last_o(&b_p2.stmts_p) {
                ::std::option::Option::Some(s_p5) => match &s_p5.kind_p {
                    crate::syntax::StmtKind::SExpr(e_p6) => crate::check::expr::infer_f(&env2_p3, &st2_p4, e_p6),
                    _ => (crate::check::types::t_unit_p(), st2_p4.clone()),
                },
                ::std::option::Option::None => (crate::check::types::t_unit_p(), st2_p4.clone()),
            }
        }
    }
}

/// The step machine of `InferExprBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub struct InferExprBlock {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferExprBlock {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        if is_widgetish_f(&b_p2.stmts_p) {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::blocks::InferWidgetBlock { env_p0: env_p0.clone(), st_p1: st_p1.clone(), b_p2: b_p2.clone() }))
        } else {
            {
                let b_p2x = b_p2.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::patterns::start_block_bound_once_f(env_p0x.clone(), st_p1x.clone(), b_p2x.stmts_p.clone()), move |block_bound_once_f_1678: crate::check::types::St| crate::prelude::call_then(start_bind_group_f(env_p0x.clone(), block_bound_once_f_1678, b_p2x.stmts_p.clone()), move |bind_group_f_1662: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2_p3, st2_p4) = bind_group_f_1662;
                    match crate::syntax::lexer::chars::last_o(&b_p2x.stmts_p) {
                        ::std::option::Option::Some(s_p5) => match &s_p5.kind_p {
                            crate::syntax::StmtKind::SExpr(e_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::Infer { env_p0: env2_p3.clone(), st_p1: st2_p4.clone(), e_p2: e_p6.clone() })),
                            _ => ::prism_rtl::Turn::Finished((crate::check::types::t_unit_p(), st2_p4.clone())),
                        },
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::check::types::t_unit_p(), st2_p4.clone())),
                    }
                }))
            }
        }
    }
}

/// `Start InferExprBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_expr_block_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferExprBlock { env_p0, st_p1, b_p2 })
}

/// ```prism
/// IsWidgetish: fn [Stmt] -> Bool
/// ```
pub fn is_widgetish_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>) -> bool {
    crate::prelude::fold(stmts_p0, &false, &(|seen_p1: &bool, s_p2: &crate::syntax::Stmt| *seen_p1 || builds_f(s_p2)))
}

/// ```prism
/// Builds: fn Stmt -> Bool
/// ```
pub fn builds_f(s_p0: &crate::syntax::Stmt) -> bool {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SBind(_, _, _) => true,
        crate::syntax::StmtKind::SIgnore(_) => true,
        crate::syntax::StmtKind::SEmit(_) => true,
        crate::syntax::StmtKind::SWidget(_) => true,
        _ => false,
    }
}

/// ```prism
/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub fn bind_group_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, stmts_p2: &crate::prelude::Array<crate::syntax::Stmt>) -> (crate::check::expr::Env, crate::check::types::St) {
    let order_p3 = crate::check::blocks::group_order_f(stmts_p2);
    let signed_p4 = signed_names_f(stmts_p2);
    let (env1_pb, st0_pc) = crate::prelude::run_to_end(crate::prelude::fold_job(order_p3.clone(), (env_p0.clone(), st_p1.clone()), {
        let stmts_p2x = stmts_p2.clone();
        let signed_p4x = signed_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)| {
            let stmts_p2xy = stmts_p2x.clone();
            let signed_p4xy = signed_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (en_p7, s_p8) = p0;
                let i_p9 = p1;
                {
                    let stmt_pa = crate::prelude::or(&crate::prelude::index(&stmts_p2xy, &i_p9), &dummy_stmt_p());
                    if crate::check::types::has_text_f(&signed_p4xy, &let_name_f(&stmt_pa)) {
                        ::prism_rtl::Turn::Finished((en_p7.clone(), s_p8.clone()))
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBind { env_p0: en_p7.clone(), st_p1: s_p8.clone(), s_p2: stmt_pa.clone() }))
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
    }));
    let st1_p5 = crate::prelude::fold(stmts_p2, &st0_pc, &(|s_pd: &crate::check::types::St, stmt_pe: &crate::syntax::Stmt| undefined_signature_f(s_pd, stmts_p2, stmt_pe)));
    let st2_p6 = if st1_p5.recording_p && (&crate::prelude::len(stmts_p2) > &crate::prelude::Nat::from(1u32)) {
        crate::check::types::recording::note_group_f(&st1_p5, &stmts_span_f(stmts_p2), &crate::prelude::Text::lit("expr"), &crate::check::blocks::dep_order_f(stmts_p2))
    } else {
        st1_p5.clone()
    };
    let (env_n_pm, st_n_pn, uses_po) = crate::prelude::run_to_end(crate::prelude::fold_job(order_p3.clone(), (env1_pb.clone(), st2_p6.clone(), crate::prelude::Map::new()), {
        let stmts_p2x = stmts_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Nat>>), crate::prelude::Nat)| {
            let stmts_p2xy = stmts_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (en_pf, s_pg, m_ph) = p0;
                let i_pi = p1;
                {
                    let before_pj = crate::prelude::len(&s_pg.use_ids_p);
                    crate::prelude::call_then(start_check_group_stmt_f(en_pf.clone(), s_pg.clone(), stmts_p2xy.clone(), i_pi.clone(), is_last_f(&stmts_p2xy, &i_pi)), move |check_group_stmt_f_3441: (crate::check::expr::Env, crate::check::types::St)| {
                        let (en2_pk, s2_pl) = check_group_stmt_f_3441;
                        ::prism_rtl::Turn::Finished((en2_pk.clone(), s2_pl.clone(), crate::prelude::insert(&m_ph, &i_pi, &crate::prelude::drop(&s2_pl.use_ids_p, &before_pj))))
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St, crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Nat>>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Nat>>)>>>
    }));
    (env_n_pm.clone(), value_cycles_f(&st_n_pn, stmts_p2, &uses_po))
}

/// The step machine of `BindGroup`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub struct BindGroup {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub stmts_p2: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindGroup {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let stmts_p2 = &self.stmts_p2;
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        let stmts_p2x = stmts_p2.clone();
        crate::prelude::call_then(crate::check::blocks::start_group_order_f(stmts_p2x.clone()), move |group_order_f_2680: crate::prelude::Array<crate::prelude::Nat>| {
            let order_p3 = group_order_f_2680;
            let signed_p4 = signed_names_f(&stmts_p2x);
            crate::prelude::call_value(crate::prelude::fold_job(order_p3.clone(), (env_p0x.clone(), st_p1x.clone()), {
                let stmts_p2xx = stmts_p2x.clone();
                let signed_p4x = signed_p4.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)| {
                    let stmts_p2xxy = stmts_p2xx.clone();
                    let signed_p4xy = signed_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (en_p7, s_p8) = p0;
                        let i_p9 = p1;
                        {
                            let stmt_pa = crate::prelude::or(&crate::prelude::index(&stmts_p2xxy, &i_p9), &dummy_stmt_p());
                            if crate::check::types::has_text_f(&signed_p4xy, &let_name_f(&stmt_pa)) {
                                ::prism_rtl::Turn::Finished((en_p7.clone(), s_p8.clone()))
                            } else {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBind { env_p0: en_p7.clone(), st_p1: s_p8.clone(), s_p2: stmt_pa.clone() }))
                            }
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }), move |fold_2878: (crate::check::expr::Env, crate::check::types::St)| {
                let (env1_pb, st0_pc) = fold_2878;
                let st1_p5 = crate::prelude::fold(&stmts_p2x, &st0_pc, &(|s_pd: &crate::check::types::St, stmt_pe: &crate::syntax::Stmt| undefined_signature_f(s_pd, &stmts_p2x, stmt_pe)));
                let env1_pbz = env1_pb.clone();
                let order_p3z = order_p3.clone();
                let stmts_p2xz = stmts_p2x.clone();
                let k_let3120 = move |v3120: crate::check::types::St| {
                    let st2_p6 = v3120;
                    crate::prelude::call_value(crate::prelude::fold_job(order_p3z.clone(), (env1_pbz.clone(), st2_p6.clone(), crate::prelude::Map::new()), {
                        let stmts_p2xzx = stmts_p2xz.clone();
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Nat>>), crate::prelude::Nat)| {
                            let stmts_p2xzxy = stmts_p2xzx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (en_pf, s_pg, m_ph) = p0;
                                let i_pi = p1;
                                {
                                    let before_pj = crate::prelude::len(&s_pg.use_ids_p);
                                    crate::prelude::call_then(start_check_group_stmt_f(en_pf.clone(), s_pg.clone(), stmts_p2xzxy.clone(), i_pi.clone(), is_last_f(&stmts_p2xzxy, &i_pi)), move |check_group_stmt_f_3441: (crate::check::expr::Env, crate::check::types::St)| {
                                        let (en2_pk, s2_pl) = check_group_stmt_f_3441;
                                        ::prism_rtl::Turn::Finished((en2_pk.clone(), s2_pl.clone(), crate::prelude::insert(&m_ph, &i_pi, &crate::prelude::drop(&s2_pl.use_ids_p, &before_pj))))
                                    })
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St, crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Nat>>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Nat>>)>>>
                    }), move |fold_3331: (crate::check::expr::Env, crate::check::types::St, crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Nat>>)| {
                        let (env_n_pm, st_n_pn, uses_po) = fold_3331;
                        crate::prelude::call_then(start_value_cycles_f(st_n_pn.clone(), stmts_p2xz.clone(), uses_po.clone()), move |value_cycles_f_3565: crate::check::types::St| ::prism_rtl::Turn::Finished((env_n_pm.clone(), value_cycles_f_3565)))
                    })
                };
                if st1_p5.recording_p && (&crate::prelude::len(&stmts_p2x) > &crate::prelude::Nat::from(1u32)) {
                    crate::prelude::call_then(crate::check::blocks::start_dep_order_f(stmts_p2x.clone()), move |dep_order_f_3211: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>| k_let3120(crate::check::types::recording::note_group_f(&st1_p5, &stmts_span_f(&stmts_p2x), &crate::prelude::Text::lit("expr"), &dep_order_f_3211)))
                } else {
                    k_let3120(st1_p5.clone())
                }
            })
        })
    }
}

/// `Start BindGroup, x`: what the function value is when passed to `@Run`.
pub fn start_bind_group_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, stmts_p2: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(BindGroup { env_p0, st_p1, stmts_p2 })
}

/// ```prism
/// ValueCycles: unbounded fn St, [Stmt], (Nat ==> [Nat]) -> St
/// ```
pub fn value_cycles_f(st_p0: &crate::check::types::St, stmts_p1: &crate::prelude::Array<crate::syntax::Stmt>, uses_p2: &crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Nat>>) -> crate::check::types::St {
    let n_p3 = crate::prelude::len(stmts_p1);
    let ids_p4 = crate::prelude::each(&crate::check::errors::range0_f(&n_p3), &(|j_p8: &crate::prelude::Nat| binder_ids_of_f(st_p0, &crate::prelude::or(&crate::prelude::index(stmts_p1, j_p8), &dummy_stmt_p()))));
    let deps_p5 = crate::prelude::each(&crate::check::errors::range0_f(&n_p3), &(|i_p9: &crate::prelude::Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p3), &(|j_pa: &crate::prelude::Nat| crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(&ids_p4, j_pa), &crate::prelude::Array::new()), &false, &(|seen_pb: &bool, d_pc: &crate::prelude::Nat| *seen_pb || crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::get(uses_p2, i_p9), &crate::prelude::Array::new()), d_pc)))))));
    let reach_p6 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&n_p3), {
        let deps_p5x = deps_p5.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let deps_p5xy = deps_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pd = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::blocks::ReachIdx { deps_p0: deps_p5xy.clone(), frontier_p1: crate::prelude::or(&crate::prelude::index(&deps_p5xy, &i_pd), &crate::prelude::Array::new()), seen_p2: crate::prelude::Array::new() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    let comps_p7 = crate::prelude::each(&crate::check::errors::range0_f(&n_p3), &(|i_pe: &crate::prelude::Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p3), &(|j_pf: &crate::prelude::Nat| (j_pf == i_pe) || (crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p6, i_pe), &crate::prelude::Array::new()), j_pf) && crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p6, j_pf), &crate::prelude::Array::new()), i_pe))))));
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::blocks::emit_groups_f(&comps_p7, &deps_p5, &crate::prelude::Array::new(), &crate::prelude::Array::new()), st_p0.clone(), {
        let stmts_p1x = stmts_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>)| {
            let stmts_p1xy = stmts_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_pg = p0;
                let comp_ph = p1;
                ::prism_rtl::Turn::Finished(cycle_of_f(&s_pg, &stmts_p1xy, &comp_ph))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `ValueCycles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueCycles: unbounded fn St, [Stmt], (Nat ==> [Nat]) -> St
/// ```
pub struct ValueCycles {
    pub st_p0: crate::check::types::St,
    pub stmts_p1: crate::prelude::Array<crate::syntax::Stmt>,
    pub uses_p2: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Nat>>,
}

impl ::prism_rtl::Job<crate::check::types::St> for ValueCycles {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let stmts_p1 = &self.stmts_p1;
        let uses_p2 = &self.uses_p2;
        let n_p3 = crate::prelude::len(stmts_p1);
        let ids_p4 = crate::prelude::each(&crate::check::errors::range0_f(&n_p3), &(|j_p8: &crate::prelude::Nat| binder_ids_of_f(st_p0, &crate::prelude::or(&crate::prelude::index(stmts_p1, j_p8), &dummy_stmt_p()))));
        let deps_p5 = crate::prelude::each(&crate::check::errors::range0_f(&n_p3), &(|i_p9: &crate::prelude::Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p3), &(|j_pa: &crate::prelude::Nat| crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(&ids_p4, j_pa), &crate::prelude::Array::new()), &false, &(|seen_pb: &bool, d_pc: &crate::prelude::Nat| *seen_pb || crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::get(uses_p2, i_p9), &crate::prelude::Array::new()), d_pc)))))));
        let st_p0x = st_p0.clone();
        let stmts_p1x = stmts_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&n_p3), {
            let deps_p5x = deps_p5.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let deps_p5xy = deps_p5x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_pd = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::blocks::ReachIdx { deps_p0: deps_p5xy.clone(), frontier_p1: crate::prelude::or(&crate::prelude::index(&deps_p5xy, &i_pd), &crate::prelude::Array::new()), seen_p2: crate::prelude::Array::new() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
        }), move |each_4359: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>| {
            let reach_p6 = each_4359;
            let comps_p7 = crate::prelude::each(&crate::check::errors::range0_f(&n_p3), &(|i_pe: &crate::prelude::Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p3), &(|j_pf: &crate::prelude::Nat| (j_pf == i_pe) || (crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p6, i_pe), &crate::prelude::Array::new()), j_pf) && crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p6, j_pf), &crate::prelude::Array::new()), i_pe))))));
            crate::prelude::call_then(crate::check::blocks::start_emit_groups_f(comps_p7.clone(), deps_p5.clone(), crate::prelude::Array::new(), crate::prelude::Array::new()), move |emit_groups_f_4573: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>| crate::prelude::fold_job(emit_groups_f_4573, st_p0x.clone(), {
                let stmts_p1xx = stmts_p1x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>)| {
                    let stmts_p1xxy = stmts_p1xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_pg = p0;
                        let comp_ph = p1;
                        ::prism_rtl::Turn::Finished(cycle_of_f(&s_pg, &stmts_p1xxy, &comp_ph))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::prelude::Array<crate::prelude::Nat>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
            }).cycle())
        })
    }
}

/// `Start ValueCycles, x`: what the function value is when passed to `@Run`.
pub fn start_value_cycles_f(st_p0: crate::check::types::St, stmts_p1: crate::prelude::Array<crate::syntax::Stmt>, uses_p2: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Nat>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(ValueCycles { st_p0, stmts_p1, uses_p2 })
}

/// ```prism
/// CycleOf: unbounded fn St, [Stmt], [Nat] -> St
/// ```
pub fn cycle_of_f(s_p0: &crate::check::types::St, stmts_p1: &crate::prelude::Array<crate::syntax::Stmt>, comp_p2: &crate::prelude::Array<crate::prelude::Nat>) -> crate::check::types::St {
    let values_p3 = crate::prelude::filter(comp_p2, &(|i_p4: &crate::prelude::Nat| is_plain_let_f(&crate::prelude::or(&crate::prelude::index(stmts_p1, i_p4), &dummy_stmt_p()))));
    if (&crate::prelude::len(comp_p2) < &crate::prelude::Nat::from(2u32)) || (&crate::prelude::len(&values_p3) == &crate::prelude::Nat::from(0u32)) {
        s_p0.clone()
    } else {
        {
            let first_p5 = crate::prelude::fold(comp_p2, &crate::prelude::or(&crate::prelude::index(comp_p2, &crate::prelude::Nat::from(0u32)), &crate::prelude::Nat::from(0u32)), &(|m_p7: &crate::prelude::Nat, i_p8: &crate::prelude::Nat| crate::prelude::min(m_p7, i_p8)));
            let names_p6 = crate::prelude::fold(&crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(stmts_p1)), &(|i_p9: &crate::prelude::Nat| crate::check::types::has_nat_f(comp_p2, i_p9))), {
                let stmts_p1x = stmts_p1.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let stmts_p1xy = stmts_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pa = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::blocks::GroupDefs { s_p0: crate::prelude::or(&crate::prelude::index(&stmts_p1xy, &i_pa), &dummy_stmt_p()) }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            })), &crate::prelude::Array::new(), &(|acc_pb: &crate::prelude::Array<crate::prelude::Text>, ns_pc: &crate::prelude::Array<crate::prelude::Text>| crate::prelude::append(acc_pb, ns_pc)));
            crate::check::types::recording::err_fix_f(s_p0, &crate::prelude::Text::lit("value-cycle"), &crate::prelude::or(&crate::prelude::index(stmts_p1, &first_p5), &dummy_stmt_p()).span_p, &crate::prelude::Text::from(format!("a cycle among plain values: {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&names_p6, &(|n_pd: &crate::prelude::Text| crate::prelude::Text::from(format!("`{}`", n_pd)))), &crate::prelude::Text::lit(", ")))), &crate::prelude::Text::lit("compute them in order: a value cannot read itself, through other values or directly"))
        }
    }
}

/// ```prism
/// BinderIdsOf: fn St, Stmt -> [Nat]
/// ```
pub fn binder_ids_of_f(st_p0: &crate::check::types::St, s_p1: &crate::syntax::Stmt) -> crate::prelude::Array<crate::prelude::Nat> {
    let spans_p2 = match &s_p1.kind_p {
        crate::syntax::StmtKind::SLet(p_p3, _, _) => pattern_name_spans_f(p_p3),
        crate::syntax::StmtKind::SFn(f_p4) => crate::prelude::Array::from(vec![crate::check::env::def_name_span_f(&f_p4.name_p)]),
        _ => crate::prelude::Array::new(),
    };
    crate::prelude::fold(&spans_p2, &crate::prelude::Array::new(), &(|acc_p5: &crate::prelude::Array<crate::prelude::Nat>, sp_p6: &crate::syntax::Range| match crate::prelude::get(&st_p0.local_ids_p, &crate::prelude::Text::from(format!("{}:{}:{}", &st_p0.file_p, &sp_p6.start_p, &sp_p6.end_p))) {
        ::std::option::Option::Some(id_p7) => crate::prelude::push(acc_p5, &id_p7),
        ::std::option::Option::None => acc_p5.clone(),
    }))
}

/// ```prism
/// PatternNameSpans: fn Pattern -> [Range]
/// ```
pub fn pattern_name_spans_f(p_p0: &crate::syntax::Pattern) -> crate::prelude::Array<crate::syntax::Range> {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p1) => crate::prelude::Array::from(vec![n_p1.span_p.clone()]),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// IsPlainLet: fn Stmt -> Bool
/// ```
pub fn is_plain_let_f(s_p0: &crate::syntax::Stmt) -> bool {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SLet(_, _, e_p1) => !crate::check::expr::is_lambda_f(e_p1),
        _ => false,
    }
}

/// ```prism
/// SignedNames: fn [Stmt] -> [Text]
/// ```
pub fn signed_names_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::fold(stmts_p0, &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<crate::prelude::Text>, s_p2: &crate::syntax::Stmt| match &s_p2.kind_p {
        crate::syntax::StmtKind::SSignature(sg_p3) => crate::prelude::push(acc_p1, &crate::check::env::def_name_text_f(&sg_p3.name_p)),
        _ => acc_p1.clone(),
    }))
}

/// ```prism
/// LetName: fn Stmt -> Text
/// ```
pub fn let_name_f(s_p0: &crate::syntax::Stmt) -> crate::prelude::Text {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SLet(p_p1, _, _) => match &*p_p1.kind_p {
            crate::syntax::PatternKind::PName(n_p2) => crate::check::env::sname_key_f(n_p2),
            _ => crate::prelude::Text::lit(""),
        },
        _ => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// DefinedName: fn Stmt -> Text
/// ```
pub fn defined_name_f(s_p0: &crate::syntax::Stmt) -> crate::prelude::Text {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SFn(f_p1) => crate::check::env::def_name_text_f(&f_p1.name_p),
        _ => let_name_f(s_p0),
    }
}

/// ```prism
/// UndefinedSignature: fn St, [Stmt], Stmt -> St
/// ```
pub fn undefined_signature_f(st_p0: &crate::check::types::St, stmts_p1: &crate::prelude::Array<crate::syntax::Stmt>, s_p2: &crate::syntax::Stmt) -> crate::check::types::St {
    match &s_p2.kind_p {
        crate::syntax::StmtKind::SSignature(sg_p3) => {
            let name_p4 = crate::check::env::def_name_text_f(&sg_p3.name_p);
            if crate::prelude::fold(stmts_p1, &false, &(|seen_p5: &bool, x_p6: &crate::syntax::Stmt| *seen_p5 || (&defined_name_f(x_p6) == &name_p4))) {
                st_p0.clone()
            } else {
                crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("no-definition"), &s_p2.span_p, &crate::prelude::Text::from(format!("`{}` has a signature line and no definition", &name_p4)), &crate::prelude::Text::from(format!("define it under its signature, `let {} = ...`, or delete the line", &name_p4)))
            }
        },
        _ => st_p0.clone(),
    }
}

/// ```prism
/// StmtsSpan: fn [Stmt] -> Range
/// ```
pub fn stmts_span_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>) -> crate::syntax::Range {
    crate::syntax::Range { start_p: crate::prelude::or(&crate::prelude::index(stmts_p0, &crate::prelude::Nat::from(0u32)), &dummy_stmt_p()).span_p.start_p.clone(), end_p: crate::prelude::or(&crate::syntax::lexer::chars::last_o(stmts_p0), &dummy_stmt_p()).span_p.end_p.clone() }
}

/// ```prism
/// let dummyStmt
/// ```
pub fn dummy_stmt_p() -> crate::syntax::Stmt {
    crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// IsLast: fn [Stmt], Nat -> Bool
/// ```
pub fn is_last_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>, i_p1: &crate::prelude::Nat) -> bool {
    &(i_p1 + &crate::prelude::Nat::from(1u32)) == &crate::prelude::len(stmts_p0)
}

/// ```prism
/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub fn pre_bind_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, s_p2: &crate::syntax::Stmt) -> (crate::check::expr::Env, crate::check::types::St) {
    match &s_p2.kind_p {
        crate::syntax::StmtKind::SSignature(sg_p3) => {
            let (sc_p4, st2_p5) = crate::check::env::reading::sig_scheme_f(&crate::check::expr::env_cx_f(env_p0), st_p1, &sg_p3.ty_p, &sg_p3.bounds_p);
            crate::check::expr::bind_local_id_f(&crate::check::expr::with_local_f(env_p0, &crate::check::env::def_name_text_f(&sg_p3.name_p), &sc_p4), &st2_p5, &crate::check::env::def_name_text_f(&sg_p3.name_p), &crate::check::env::def_name_span_f(&sg_p3.name_p))
        },
        crate::syntax::StmtKind::SFn(f_p6) => {
            let name_p7 = crate::check::env::def_name_text_f(&f_p6.name_p);
            match crate::prelude::get(&env_p0.locals_p, &name_p7) {
                ::std::option::Option::Some(_) => (env_p0.clone(), st_p1.clone()),
                ::std::option::Option::None => {
                    let (v_p8, st2_p9) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                    crate::check::expr::bind_local_id_f(&crate::check::expr::with_local_f(env_p0, &name_p7, &crate::check::types::schemes::mono_f(&v_p8)), &st2_p9, &name_p7, &crate::check::env::def_name_span_f(&f_p6.name_p))
                },
            }
        },
        crate::syntax::StmtKind::SLet(p_pa, _, e_pb) => match &*p_pa.kind_p {
            crate::syntax::PatternKind::PName(_) if (crate::check::expr::patterns::let_names_constructor_f(env_p0, p_pa) && !crate::check::expr::is_lambda_f(e_pb)) => (env_p0.clone(), st_p1.clone()),
            crate::syntax::PatternKind::PName(n_pc) => {
                let (v_pe, st1_pf) = crate::check::types::fresh_var_f(st_p1, &true, &crate::check::env::sname_key_f(n_pc));
                let st2_pd = crate::check::types::recording::at_binder_f(&st1_pf, &v_pe, &n_pc.span_p);
                let (rw_pg, st3_ph) = crate::check::types::recording::fresh_row_f(&st2_pd, &crate::prelude::Array::new());
                crate::check::expr::bind_local_id_f(&crate::check::expr::with_local_f(env_p0, &crate::check::env::sname_key_f(n_pc), &crate::check::types::schemes::mono_f(&crate::check::types::with_marks_f(&type_marks_f(&n_pc.sigils_p), &v_pe, &rw_pg))), &st3_ph, &crate::check::env::sname_key_f(n_pc), &n_pc.span_p)
            },
            _ => (env_p0.clone(), st_p1.clone()),
            _ => unreachable!("no arm matched"),
        },
        _ => (env_p0.clone(), st_p1.clone()),
    }
}

/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub struct PreBind {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub s_p2: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for PreBind {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let s_p2 = &self.s_p2;
        match &s_p2.kind_p {
            crate::syntax::StmtKind::SSignature(sg_p3) => {
                let env_p0x = env_p0.clone();
                let sg_p3x = sg_p3.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::env::reading::start_sig_scheme_f(crate::check::expr::env_cx_f(&env_p0x), st_p1x.clone(), sg_p3x.ty_p.clone(), sg_p3x.bounds_p.clone()), move |sig_scheme_f_7686: (crate::check::types::Scheme, crate::check::types::St)| {
                    let (sc_p4, st2_p5) = sig_scheme_f_7686;
                    ::prism_rtl::Turn::Finished(crate::check::expr::bind_local_id_f(&crate::check::expr::with_local_f(&env_p0x, &crate::check::env::def_name_text_f(&sg_p3x.name_p), &sc_p4), &st2_p5, &crate::check::env::def_name_text_f(&sg_p3x.name_p), &crate::check::env::def_name_span_f(&sg_p3x.name_p)))
                })
            },
            crate::syntax::StmtKind::SFn(f_p6) => {
                let name_p7 = crate::check::env::def_name_text_f(&f_p6.name_p);
                match crate::prelude::get(&env_p0.locals_p, &name_p7) {
                    ::std::option::Option::Some(_) => ::prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
                    ::std::option::Option::None => {
                        let (v_p8, st2_p9) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                        ::prism_rtl::Turn::Finished(crate::check::expr::bind_local_id_f(&crate::check::expr::with_local_f(env_p0, &name_p7, &crate::check::types::schemes::mono_f(&v_p8)), &st2_p9, &name_p7, &crate::check::env::def_name_span_f(&f_p6.name_p)))
                    },
                }
            },
            crate::syntax::StmtKind::SLet(p_pa, _, e_pb) => match &*p_pa.kind_p {
                crate::syntax::PatternKind::PName(_) if (crate::check::expr::patterns::let_names_constructor_f(env_p0, p_pa) && !crate::check::expr::is_lambda_f(e_pb)) => ::prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
                crate::syntax::PatternKind::PName(n_pc) => {
                    let (v_pe, st1_pf) = crate::check::types::fresh_var_f(st_p1, &true, &crate::check::env::sname_key_f(n_pc));
                    let st2_pd = crate::check::types::recording::at_binder_f(&st1_pf, &v_pe, &n_pc.span_p);
                    let (rw_pg, st3_ph) = crate::check::types::recording::fresh_row_f(&st2_pd, &crate::prelude::Array::new());
                    ::prism_rtl::Turn::Finished(crate::check::expr::bind_local_id_f(&crate::check::expr::with_local_f(env_p0, &crate::check::env::sname_key_f(n_pc), &crate::check::types::schemes::mono_f(&crate::check::types::with_marks_f(&type_marks_f(&n_pc.sigils_p), &v_pe, &rw_pg))), &st3_ph, &crate::check::env::sname_key_f(n_pc), &n_pc.span_p))
                },
                _ => ::prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
                _ => unreachable!("no arm matched"),
            },
            _ => ::prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
        }
    }
}

/// `Start PreBind, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, s_p2: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(PreBind { env_p0, st_p1, s_p2 })
}

/// ```prism
/// CheckGroupStmt: unbounded fn Env, St, [Stmt], Nat, Bool -> ((Env, St))
/// ```
pub fn check_group_stmt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, stmts_p2: &crate::prelude::Array<crate::syntax::Stmt>, i_p3: &crate::prelude::Nat, last_p4: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    match &crate::prelude::or(&crate::prelude::index(stmts_p2, i_p3), &dummy_stmt_p()).kind_p {
        crate::syntax::StmtKind::SLet(p_p5, ty_o6, e_p7) => check_let_f(env_p0, st_p1, p_p5, ty_o6, e_p7, &crate::prelude::or(&crate::prelude::index(stmts_p2, i_p3), &dummy_stmt_p()).span_p),
        crate::syntax::StmtKind::SFn(f_p8) => check_local_fn_f(env_p0, st_p1, &local_clauses_f(stmts_p2, i_p3), &crate::prelude::or(&crate::prelude::index(stmts_p2, i_p3), &dummy_stmt_p()).span_p),
        crate::syntax::StmtKind::SSignature(_) => (env_p0.clone(), st_p1.clone()),
        crate::syntax::StmtKind::SExpr(e_p9) => if *last_p4 {
            (env_p0.clone(), st_p1.clone())
        } else {
            {
                let (t_pa, st2_pb) = crate::check::expr::infer_f(env_p0, st_p1, e_p9);
                (env_p0.clone(), st2_pb.clone())
            }
        },
        _ => (env_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &crate::prelude::or(&crate::prelude::index(stmts_p2, i_p3), &dummy_stmt_p()).span_p, &crate::prelude::Text::lit("this statement belongs in a widget, `given:` or `update` block"))),
    }
}

/// The step machine of `CheckGroupStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckGroupStmt: unbounded fn Env, St, [Stmt], Nat, Bool -> ((Env, St))
/// ```
pub struct CheckGroupStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub stmts_p2: crate::prelude::Array<crate::syntax::Stmt>,
    pub i_p3: crate::prelude::Nat,
    pub last_p4: bool,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for CheckGroupStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let stmts_p2 = &self.stmts_p2;
        let i_p3 = &self.i_p3;
        let last_p4 = &self.last_p4;
        match &crate::prelude::or(&crate::prelude::index(stmts_p2, i_p3), &dummy_stmt_p()).kind_p {
            crate::syntax::StmtKind::SLet(p_p5, ty_o6, e_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckLet { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p5.clone(), ty_o3: ty_o6.clone(), e_p4: e_p7.clone(), span_p5: crate::prelude::or(&crate::prelude::index(stmts_p2, i_p3), &dummy_stmt_p()).span_p.clone() })),
            crate::syntax::StmtKind::SFn(f_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckLocalFn { env_p0: env_p0.clone(), st_p1: st_p1.clone(), clauses_p2: local_clauses_f(stmts_p2, i_p3), span_p3: crate::prelude::or(&crate::prelude::index(stmts_p2, i_p3), &dummy_stmt_p()).span_p.clone() })),
            crate::syntax::StmtKind::SSignature(_) => ::prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
            crate::syntax::StmtKind::SExpr(e_p9) => if *last_p4 {
                ::prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone()))
            } else {
                {
                    let e_p9x = e_p9.clone();
                    let env_p0x = env_p0.clone();
                    let st_p1x = st_p1.clone();
                    crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_p9x.clone()), move |infer_f_9218: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_pa, st2_pb) = infer_f_9218;
                        ::prism_rtl::Turn::Finished((env_p0x.clone(), st2_pb.clone()))
                    })
                }
            },
            _ => ::prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &crate::prelude::or(&crate::prelude::index(stmts_p2, i_p3), &dummy_stmt_p()).span_p, &crate::prelude::Text::lit("this statement belongs in a widget, `given:` or `update` block")))),
        }
    }
}

/// `Start CheckGroupStmt, x`: what the function value is when passed to `@Run`.
pub fn start_check_group_stmt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, stmts_p2: crate::prelude::Array<crate::syntax::Stmt>, i_p3: crate::prelude::Nat, last_p4: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(CheckGroupStmt { env_p0, st_p1, stmts_p2, i_p3, last_p4 })
}

/// ```prism
/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
/// ```
pub fn check_let_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern, ty_o3: &::std::option::Option<crate::syntax::Type>, e_p4: &crate::syntax::Expr, span_p5: &crate::syntax::Range) -> (crate::check::expr::Env, crate::check::types::St) {
    match builder_head_o(env_p0, e_p4) {
        ::std::option::Option::Some((word_p6, built_p7, head_p8)) if !env_p0.in_update_p => {
            let (_, st1_pa) = crate::check::expr::infer_f(env_p0, st_p1, e_p4);
            let st2_p9 = crate::check::types::recording::err_fix_f(&st1_pa, &crate::prelude::Text::lit("mismatch"), &e_p4.span_p, &crate::prelude::Text::from(format!("a `{}` builds its {} and `let` builds nothing", &word_p6, &built_p7)), &crate::prelude::Text::from(format!("bind its result with `<-`: `{} <- {} ..`", &crate::check::expr::src_text_f(env_p0, &p_p2.span_p), &head_p8)));
            crate::check::expr::patterns::bind_pattern_f(env_p0, &st2_p9, p_p2, &crate::check::types::Ty::TyErr, &false)
        },
        _ => check_let_value_f(env_p0, st_p1, p_p2, ty_o3, e_p4, span_p5),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CheckLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
/// ```
pub struct CheckLet {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern,
    pub ty_o3: ::std::option::Option<crate::syntax::Type>,
    pub e_p4: crate::syntax::Expr,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for CheckLet {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let ty_o3 = &self.ty_o3;
        let e_p4 = &self.e_p4;
        let span_p5 = &self.span_p5;
        match builder_head_o(env_p0, e_p4) {
            ::std::option::Option::Some((word_p6, built_p7, head_p8)) if !env_p0.in_update_p => {
                let e_p4x = e_p4.clone();
                let env_p0x = env_p0.clone();
                let p_p2x = p_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_p4x.clone()), move |infer_f_10032: (crate::check::types::Ty, crate::check::types::St)| {
                    let (_, st1_pa) = infer_f_10032;
                    let st2_p9 = crate::check::types::recording::err_fix_f(&st1_pa, &crate::prelude::Text::lit("mismatch"), &e_p4x.span_p, &crate::prelude::Text::from(format!("a `{}` builds its {} and `let` builds nothing", &word_p6, &built_p7)), &crate::prelude::Text::from(format!("bind its result with `<-`: `{} <- {} ..`", &crate::check::expr::src_text_f(&env_p0x, &p_p2x.span_p), &head_p8)));
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::patterns::BindPattern { env_p0: env_p0x.clone(), st_p1: st2_p9.clone(), p_p2: p_p2x.clone(), t_p3: crate::check::types::Ty::TyErr, refutable_p4: false }))
                })
            },
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckLetValue { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), ty_o3: ty_o3.clone(), e_p4: e_p4.clone(), span_p5: span_p5.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CheckLet, x`: what the function value is when passed to `@Run`.
pub fn start_check_let_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern, ty_o3: ::std::option::Option<crate::syntax::Type>, e_p4: crate::syntax::Expr, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(CheckLet { env_p0, st_p1, p_p2, ty_o3, e_p4, span_p5 })
}

/// ```prism
/// ?BuilderHead: fn Env, Expr -> ?((Text, Text, Text))
/// ```
pub fn builder_head_o(env_p0: &crate::check::expr::Env, e_p1: &crate::syntax::Expr) -> ::std::option::Option<(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)> {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::EFor(_, _, body_p2) => ::std::option::Option::Some((crate::prelude::Text::lit("for"), crate::prelude::Text::lit("rows"), crate::syntax::lexer::chars::trim_trailing_f(&crate::check::expr::src_text_f(env_p0, &crate::syntax::Range { start_p: e_p1.span_p.start_p.clone(), end_p: body_p2.span_p.start_p.clone() }), &crate::prelude::Text::lit(" \n\t")))),
        crate::syntax::ExprKind::ERebuild(_, body_p3) => ::std::option::Option::Some((crate::prelude::Text::lit("rebuild"), crate::prelude::Text::lit("block"), crate::syntax::lexer::chars::trim_trailing_f(&crate::check::expr::src_text_f(env_p0, &crate::syntax::Range { start_p: e_p1.span_p.start_p.clone(), end_p: body_p3.span_p.start_p.clone() }), &crate::prelude::Text::lit(" \n\t")))),
        crate::syntax::ExprKind::EGroup(x_p4) => builder_head_o(env_p0, &**x_p4),
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// CheckLetValue: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
/// ```
pub fn check_let_value_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern, ty_o3: &::std::option::Option<crate::syntax::Type>, e_p4: &crate::syntax::Expr, span_p5: &crate::syntax::Range) -> (crate::check::expr::Env, crate::check::types::St) {
    let named_p6 = crate::check::expr::patterns::let_names_constructor_f(env_p0, p_p2);
    let name_p7 = crate::check::expr::src_text_f(env_p0, &p_p2.span_p);
    let st1_p8 = if named_p6 && crate::check::expr::is_lambda_f(e_p4) {
        crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("collision"), &p_p2.span_p, &crate::prelude::Text::from(format!("`{}` is a constructor here, and a pattern\'s `{}` is the constructor: this `let` names no function", &name_p7, &name_p7)), &crate::prelude::Text::lit("give the function another name"))
    } else {
        st_p1.clone()
    };
    let q_p9 = if named_p6 && !crate::check::expr::is_lambda_f(e_p4) {
        crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PGroup(::std::rc::Rc::new(p_p2.clone()))), span_p: p_p2.span_p.clone() }
    } else {
        p_p2.clone()
    };
    check_let_binding_f(env_p0, &st1_p8, &q_p9, ty_o3, e_p4, span_p5)
}

/// The step machine of `CheckLetValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLetValue: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
/// ```
pub struct CheckLetValue {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern,
    pub ty_o3: ::std::option::Option<crate::syntax::Type>,
    pub e_p4: crate::syntax::Expr,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for CheckLetValue {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let ty_o3 = &self.ty_o3;
        let e_p4 = &self.e_p4;
        let span_p5 = &self.span_p5;
        let named_p6 = crate::check::expr::patterns::let_names_constructor_f(env_p0, p_p2);
        let name_p7 = crate::check::expr::src_text_f(env_p0, &p_p2.span_p);
        let st1_p8 = if named_p6 && crate::check::expr::is_lambda_f(e_p4) {
            crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("collision"), &p_p2.span_p, &crate::prelude::Text::from(format!("`{}` is a constructor here, and a pattern\'s `{}` is the constructor: this `let` names no function", &name_p7, &name_p7)), &crate::prelude::Text::lit("give the function another name"))
        } else {
            st_p1.clone()
        };
        let q_p9 = if named_p6 && !crate::check::expr::is_lambda_f(e_p4) {
            crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PGroup(::std::rc::Rc::new(p_p2.clone()))), span_p: p_p2.span_p.clone() }
        } else {
            p_p2.clone()
        };
        ::prism_rtl::Turn::Finished(check_let_binding_f(env_p0, &st1_p8, &q_p9, ty_o3, e_p4, span_p5))
    }
}

/// `Start CheckLetValue, x`: what the function value is when passed to `@Run`.
pub fn start_check_let_value_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern, ty_o3: ::std::option::Option<crate::syntax::Type>, e_p4: crate::syntax::Expr, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(CheckLetValue { env_p0, st_p1, p_p2, ty_o3, e_p4, span_p5 })
}

/// ```prism
/// CheckLetBinding: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
/// ```
pub fn check_let_binding_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern, ty_o3: &::std::option::Option<crate::syntax::Type>, e_p4: &crate::syntax::Expr, span_p5: &crate::syntax::Range) -> (crate::check::expr::Env, crate::check::types::St) {
    let st0_p6 = crate::check::types::schemes::enter_level_f(st_p1);
    let (annot_od, st1_pe) = match ty_o3 {
        ::std::option::Option::Some(t_pa) => {
            let (at_pb, s2_pc) = crate::check::env::reading::conv_type_f(&crate::check::expr::env_cx_f(env_p0), &st0_p6, t_pa);
            (::std::option::Option::Some(at_pb.clone()), s2_pc.clone())
        },
        ::std::option::Option::None => (::std::option::Option::None, st0_p6.clone()),
    };
    let (pre_pn, st2_po) = match &*p_p2.kind_p {
        crate::syntax::PatternKind::PName(n_pf) => match crate::prelude::get(&env_p0.locals_p, &crate::check::env::sname_key_f(n_pf)) {
            ::std::option::Option::Some(sc_pg) => if (&n_pf.sigils_p == &crate::prelude::Text::lit("")) && crate::check::types::is_flex_var_f(&st1_pe, &sc_pg.ty_p) {
                {
                    let (v_ph, s2_pi) = crate::check::types::fresh_var_f(&st1_pe, &true, &crate::check::env::sname_key_f(n_pf));
                    (v_ph.clone(), crate::check::types::recording::at_binder_f(&s2_pi, &v_ph, &n_pf.span_p))
                }
            } else {
                (sc_pg.ty_p.clone(), st1_pe.clone())
            },
            ::std::option::Option::None => {
                let (v_pj, s2_pk) = crate::check::types::fresh_var_f(&st1_pe, &true, &crate::check::env::sname_key_f(n_pf));
                let (rw_pl, s3_pm) = crate::check::types::recording::fresh_row_f(&s2_pk, &crate::prelude::Array::new());
                (crate::check::types::with_marks_f(&type_marks_f(&n_pf.sigils_p), &v_pj, &rw_pl), crate::check::types::recording::at_binder_f(&s3_pm, &v_pj, &n_pf.span_p))
            },
        },
        _ => crate::check::types::fresh_var_f(&st1_pe, &false, &crate::prelude::Text::lit("")),
    };
    let st3_p7 = match &annot_od {
        ::std::option::Option::Some(at_pp) => crate::check::expr::check_f(env_p0, &st2_po, e_p4, at_pp),
        ::std::option::Option::None => crate::check::expr::check_f(env_p0, &st2_po, e_p4, &pre_pn),
    };
    let st4_p8 = match &annot_od {
        ::std::option::Option::Some(at_pq) => crate::check::types::unify::unify_f(&st3_p7, &pre_pn, at_pq, span_p5),
        ::std::option::Option::None => st3_p7.clone(),
    };
    let st5_p9 = crate::check::env::traits::solve_wants_f(&env_p0.g_p, &st4_p8, &env_p0.givens_p, &false);
    match &*p_p2.kind_p {
        crate::syntax::PatternKind::PName(n_pr) => {
            let name_ps = crate::check::env::sname_key_f(n_pr);
            let t_pt = crate::check::types::recording::zonk_f(&st5_p9, &pre_pn);
            let (env2_p10, st7a_p11) = crate::check::expr::patterns::bind_name_f(env_p0, &st5_p9, n_pr, &t_pt);
            let st7_pu = crate::check::types::schemes::leave_level_f(&st7a_p11);
            let ahead_fv = {
                let env_p0x = env_p0.clone();
                let name_psx = name_ps.clone();
                let pre_pnx = pre_pn.clone();
                let t_ptx = t_pt.clone();
                let span_p5x = span_p5.clone();
                ::std::rc::Rc::new(move |p0: crate::check::types::St| {
                    let env_p0xy = env_p0x.clone();
                    let name_psxy = name_psx.clone();
                    let pre_pnxy = pre_pnx.clone();
                    let t_ptxy = t_ptx.clone();
                    let span_p5xy = span_p5x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_p12 = p0;
                        ::prism_rtl::Turn::Finished(ahead_unify_f(&env_p0xy, &s_p12, &name_psxy, &pre_pnxy, &t_ptxy, &span_p5xy))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
            };
            if crate::check::types::schemes::holds_node_f(&st7_pu, &t_pt) || is_topic_name_f(&name_ps) {
                (env2_p10.clone(), crate::prelude::run_to_end((&ahead_fv)(st7_pu.clone())))
            } else {
                {
                    let lambda_p13 = crate::check::expr::is_lambda_f(e_p4);
                    let own_p14 = if lambda_p13 && crate::check::types::recording::is_closed_f(&st2_po, &st5_p9) {
                        crate::check::types::schemes::own_equations_f(&st7_pu, &t_pt, &crate::prelude::Array::new())
                    } else {
                        crate::prelude::Array::new()
                    };
                    let (keep_p15, bounds_p16, st8_p17) = wants_above_but_f(&st7_pu, &t_pt, &lambda_p13, &own_p14);
                    let (sc_p18, st9_p19) = crate::check::types::schemes::generalize_in_f(&st8_p17, &t_pt, &keep_p15, &bounds_p16, &own_p14);
                    (crate::check::expr::with_local_f(&env2_p10, &name_ps, &sc_p18), crate::prelude::run_to_end((&ahead_fv)(crate::check::types::recording::note_gen_f(&st9_p19, &n_pr.span_p, &name_ps, &sc_p18))))
                }
            }
        },
        _ => {
            let st6_p1a = crate::check::types::schemes::leave_level_f(&st5_p9);
            let (env2_p1b, st7_p1c) = crate::check::expr::patterns::bind_pattern_f(env_p0, &st6_p1a, p_p2, &crate::check::types::recording::zonk_f(&st6_p1a, &pre_pn), &false);
            (env2_p1b.clone(), crate::check::passes::always_matches_f(env_p0, &st7_p1c, p_p2, &pre_pn, &crate::prelude::Text::lit("a `let`")))
        },
    }
}

/// ```prism
/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
/// ```
pub fn ahead_unify_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, name_p2: &crate::prelude::Text, pre_p3: &crate::check::types::Ty, t_p4: &crate::check::types::Ty, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    match crate::prelude::get(&env_p0.locals_p, name_p2) {
        ::std::option::Option::Some(sc0_p6) => if &sc0_p6.ty_p != pre_p3 {
            crate::check::types::unify::unify_f(st_p1, &sc0_p6.ty_p, t_p4, span_p5)
        } else {
            st_p1.clone()
        },
        ::std::option::Option::None => st_p1.clone(),
    }
}

/// ```prism
/// TypeMarks: fn Text -> Text
/// ```
pub fn type_marks_f(marks_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if crate::syntax::lexer::chars::has_prefix_f(marks_p0, &crate::prelude::Text::lit("&")) {
        crate::syntax::lexer::chars::after_first_f(marks_p0)
    } else {
        marks_p0.clone()
    }
}

/// ```prism
/// RefMark: fn Text -> Text
/// ```
pub fn ref_mark_f(marks_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if crate::syntax::lexer::chars::has_prefix_f(marks_p0, &crate::prelude::Text::lit("&")) {
        crate::prelude::Text::lit("&")
    } else {
        crate::prelude::Text::lit("")
    }
}

/// ```prism
/// Unpend: fn Env -> Env
/// ```
pub fn unpend_f(env_p0: &crate::check::expr::Env) -> crate::check::expr::Env {
    let mut this: crate::check::expr::Env = env_p0.clone();
    this.pending_p = crate::prelude::Array::new();
    this
}

/// ```prism
/// IsTopicName: fn Text -> Bool
/// ```
pub fn is_topic_name_f(n_p0: &crate::prelude::Text) -> bool {
    (n_p0 == &crate::prelude::Text::lit("_")) || (&crate::syntax::lexer::chars::drop_prefix_f(n_p0, &crate::check::types::unify::marks_of_f(n_p0)) == &crate::prelude::Text::lit("_"))
}

/// ```prism
/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
/// ```
pub fn wants_above_f(st0_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, lambda_p2: &bool) -> (crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::St) {
    wants_above_but_f(st0_p0, t_p1, lambda_p2, &crate::prelude::Array::new())
}

/// The step machine of `WantsAbove`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
/// ```
pub struct WantsAbove {
    pub st0_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub lambda_p2: bool,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::St)> for WantsAbove {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::St)> {
        let st0_p0 = &self.st0_p0;
        let t_p1 = &self.t_p1;
        let lambda_p2 = &self.lambda_p2;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(WantsAboveBut { st0_p0: st0_p0.clone(), t_p1: t_p1.clone(), lambda_p2: *lambda_p2, own_p3: crate::prelude::Array::new() }))
    }
}

/// `Start WantsAbove, x`: what the function value is when passed to `@Run`.
pub fn start_wants_above_f(st0_p0: crate::check::types::St, t_p1: crate::check::types::Ty, lambda_p2: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::St)>> {
    ::std::rc::Rc::new(WantsAbove { st0_p0, t_p1, lambda_p2 })
}

/// ```prism
/// WantsAboveBut: unbounded fn St, Ty, Bool, [Waiting] -> (([Nat], [((Nat, Text))], St))
/// ```
pub fn wants_above_but_f(st0_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, lambda_p2: &bool, own_p3: &crate::prelude::Array<crate::check::types::Waiting>) -> (crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::St) {
    let st_p4 = crate::check::types::schemes::keep_waiting_but_f(st0_p0, own_p3);
    let vs_p5 = crate::prelude::filter(&crate::check::types::recording::free_vars_f(&st_p4, t_p1), &(|v_p9: &crate::prelude::Nat| &crate::check::types::recording::info_of_f(&st_p4, v_p9).level_p > &st_p4.level_p));
    let mine_p6 = crate::prelude::run_to_end(crate::prelude::filter_job(st_p4.wants_p.clone(), {
        let st_p4x = st_p4.clone();
        let vs_p5x = vs_p5.clone();
        ::std::rc::Rc::new(move |p0: crate::check::types::Want| {
            let st_p4xy = st_p4x.clone();
            let vs_p5xy = vs_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_pa = p0;
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p4xy.clone(), w_pa.ty_p.clone()), move |walk_f_16040: crate::check::types::Ty| match walk_f_16040 {
                    crate::check::types::Ty::TyFlex(n_pb) => ::prism_rtl::Turn::Finished(crate::check::types::has_nat_f(&vs_p5xy, &n_pb)),
                    _ => ::prism_rtl::Turn::Finished(false),
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Want) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    let others_p7 = crate::prelude::filter(&st_p4.wants_p, &(|w_pc: &crate::check::types::Want| !crate::check::types::has_text_f(&crate::prelude::each(&mine_p6, &(|m_pd: &crate::check::types::Want| crate::prelude::show_text(m_pd))), &crate::prelude::show_text(w_pc))));
    let constrained_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(mine_p6.clone(), crate::prelude::Array::new(), {
        let st_p4x = st_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Want)| {
            let st_p4xy = st_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pe = p0;
                let w_pf = p1;
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p4xy.clone(), w_pf.ty_p.clone()), move |walk_f_16254: crate::check::types::Ty| match walk_f_16254 {
                    crate::check::types::Ty::TyFlex(n_pg) => ::prism_rtl::Turn::Finished(crate::check::types::add_nat_f(&acc_pe, &n_pg)),
                    _ => ::prism_rtl::Turn::Finished(acc_pe.clone()),
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Want)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    if *lambda_p2 {
        {
            let bounds_ph = crate::prelude::run_to_end(crate::prelude::fold_job(mine_p6.clone(), crate::prelude::Array::new(), {
                let st_p4x = st_p4.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::Want)| {
                    let st_p4xy = st_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pk = p0;
                        let w_pl = p1;
                        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p4xy.clone(), w_pl.ty_p.clone()), move |walk_f_16393: crate::check::types::Ty| match walk_f_16393 {
                            crate::check::types::Ty::TyFlex(n_pm) => if crate::syntax::lexer::chars::has_prefix_f(&w_pl.cls_p, &crate::prelude::Text::lit("Range ")) {
                                ::prism_rtl::Turn::Finished(acc_pk.clone())
                            } else {
                                ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pk, &(n_pm.clone(), w_pl.cls_p.clone())))
                            },
                            _ => ::prism_rtl::Turn::Finished(acc_pk.clone()),
                        })
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::Want)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>>>>
            }));
            let st1_pi = crate::prelude::fold(&mine_p6, &st_p4, &(|s_pn: &crate::check::types::St, w_po: &crate::check::types::Want| crate::check::types::recording::note_choice_f(&crate::check::types::recording::note_impl_f(s_pn, &w_po.file_p, &w_po.span_p, &w_po.cls_p, &w_po.ty_p, &crate::prelude::Text::lit("quantified")), &w_po.file_p, &w_po.span_p, &w_po.cls_p, &crate::prelude::Text::lit("any"))));
            let st2_pj = {
                let mut this: crate::check::types::St = st1_pi.clone();
                this.wants_p = others_p7.clone();
                this
            };
            (crate::prelude::Array::new(), bounds_ph.clone(), st2_pj.clone())
        }
    } else {
        {
            let st2_pp = crate::check::types::unify::lower_levels_f(&st_p4, &constrained_p8, &st_p4.level_p);
            (constrained_p8.clone(), crate::prelude::Array::new(), st2_pp.clone())
        }
    }
}

/// The step machine of `WantsAboveBut`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WantsAboveBut: unbounded fn St, Ty, Bool, [Waiting] -> (([Nat], [((Nat, Text))], St))
/// ```
pub struct WantsAboveBut {
    pub st0_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub lambda_p2: bool,
    pub own_p3: crate::prelude::Array<crate::check::types::Waiting>,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::St)> for WantsAboveBut {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::St)> {
        let st0_p0 = &self.st0_p0;
        let t_p1 = &self.t_p1;
        let lambda_p2 = &self.lambda_p2;
        let own_p3 = &self.own_p3;
        let lambda_p2x = *lambda_p2;
        let own_p3x = own_p3.clone();
        let st0_p0x = st0_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::schemes::start_keep_waiting_but_f(st0_p0x.clone(), own_p3x.clone()), move |keep_waiting_but_f_15898: crate::check::types::St| {
            let st_p4 = keep_waiting_but_f_15898;
            crate::prelude::call_then(crate::check::types::recording::start_free_vars_f(st_p4.clone(), t_p1x.clone()), move |free_vars_f_15943: crate::prelude::Array<crate::prelude::Nat>| {
                let vs_p5 = crate::prelude::filter(&free_vars_f_15943, &(|v_p9: &crate::prelude::Nat| &crate::check::types::recording::info_of_f(&st_p4, v_p9).level_p > &st_p4.level_p));
                crate::prelude::call_value(crate::prelude::filter_job(st_p4.wants_p.clone(), {
                    let st_p4x = st_p4.clone();
                    let vs_p5x = vs_p5.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Want| {
                        let st_p4xy = st_p4x.clone();
                        let vs_p5xy = vs_p5x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let w_pa = p0;
                            crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p4xy.clone(), w_pa.ty_p.clone()), move |walk_f_16040: crate::check::types::Ty| match walk_f_16040 {
                                crate::check::types::Ty::TyFlex(n_pb) => ::prism_rtl::Turn::Finished(crate::check::types::has_nat_f(&vs_p5xy, &n_pb)),
                                _ => ::prism_rtl::Turn::Finished(false),
                            })
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Want) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }), move |filter_16012: crate::prelude::Array<crate::check::types::Want>| {
                    let mine_p6 = filter_16012;
                    let others_p7 = crate::prelude::filter(&st_p4.wants_p, &(|w_pc: &crate::check::types::Want| !crate::check::types::has_text_f(&crate::prelude::each(&mine_p6, &(|m_pd: &crate::check::types::Want| crate::prelude::show_text(m_pd))), &crate::prelude::show_text(w_pc))));
                    crate::prelude::call_value(crate::prelude::fold_job(mine_p6.clone(), crate::prelude::Array::new(), {
                        let st_p4x = st_p4.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Want)| {
                            let st_p4xy = st_p4x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_pe = p0;
                                let w_pf = p1;
                                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p4xy.clone(), w_pf.ty_p.clone()), move |walk_f_16254: crate::check::types::Ty| match walk_f_16254 {
                                    crate::check::types::Ty::TyFlex(n_pg) => ::prism_rtl::Turn::Finished(crate::check::types::add_nat_f(&acc_pe, &n_pg)),
                                    _ => ::prism_rtl::Turn::Finished(acc_pe.clone()),
                                })
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Want)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
                    }), move |fold_16221: crate::prelude::Array<crate::prelude::Nat>| {
                        let constrained_p8 = fold_16221;
                        if lambda_p2x {
                            crate::prelude::call_value(crate::prelude::fold_job(mine_p6.clone(), crate::prelude::Array::new(), {
                                let st_p4x = st_p4.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::Want)| {
                                    let st_p4xy = st_p4x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let acc_pk = p0;
                                        let w_pl = p1;
                                        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p4xy.clone(), w_pl.ty_p.clone()), move |walk_f_16393: crate::check::types::Ty| match walk_f_16393 {
                                            crate::check::types::Ty::TyFlex(n_pm) => if crate::syntax::lexer::chars::has_prefix_f(&w_pl.cls_p, &crate::prelude::Text::lit("Range ")) {
                                                ::prism_rtl::Turn::Finished(acc_pk.clone())
                                            } else {
                                                ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pk, &(n_pm.clone(), w_pl.cls_p.clone())))
                                            },
                                            _ => ::prism_rtl::Turn::Finished(acc_pk.clone()),
                                        })
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::Want)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>>>>
                            }), move |fold_16360: crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>| {
                                let bounds_ph = fold_16360;
                                let st1_pi = crate::prelude::fold(&mine_p6, &st_p4, &(|s_pn: &crate::check::types::St, w_po: &crate::check::types::Want| crate::check::types::recording::note_choice_f(&crate::check::types::recording::note_impl_f(s_pn, &w_po.file_p, &w_po.span_p, &w_po.cls_p, &w_po.ty_p, &crate::prelude::Text::lit("quantified")), &w_po.file_p, &w_po.span_p, &w_po.cls_p, &crate::prelude::Text::lit("any"))));
                                let st2_pj = {
                                    let mut this: crate::check::types::St = st1_pi.clone();
                                    this.wants_p = others_p7.clone();
                                    this
                                };
                                ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), bounds_ph.clone(), st2_pj.clone()))
                            })
                        } else {
                            {
                                let st2_pp = crate::check::types::unify::lower_levels_f(&st_p4, &constrained_p8, &st_p4.level_p);
                                ::prism_rtl::Turn::Finished((constrained_p8.clone(), crate::prelude::Array::new(), st2_pp.clone()))
                            }
                        }
                    })
                })
            })
        })
    }
}

/// `Start WantsAboveBut, x`: what the function value is when passed to `@Run`.
pub fn start_wants_above_but_f(st0_p0: crate::check::types::St, t_p1: crate::check::types::Ty, lambda_p2: bool, own_p3: crate::prelude::Array<crate::check::types::Waiting>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::St)>> {
    ::std::rc::Rc::new(WantsAboveBut { st0_p0, t_p1, lambda_p2, own_p3 })
}

/// ```prism
/// CheckLocalFn: unbounded fn Env, St, [FnClause], Range -> ((Env, St))
/// ```
pub fn check_local_fn_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, clauses_p2: &crate::prelude::Array<crate::syntax::decls::FnClause>, span_p3: &crate::syntax::Range) -> (crate::check::expr::Env, crate::check::types::St) {
    match crate::prelude::index(clauses_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::None => (env_p0.clone(), st_p1.clone()),
        ::std::option::Option::Some(f_p4) => check_local_clauses_f(env_p0, st_p1, &f_p4, clauses_p2, span_p3),
    }
}

/// The step machine of `CheckLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLocalFn: unbounded fn Env, St, [FnClause], Range -> ((Env, St))
/// ```
pub struct CheckLocalFn {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub clauses_p2: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for CheckLocalFn {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let clauses_p2 = &self.clauses_p2;
        let span_p3 = &self.span_p3;
        match crate::prelude::index(clauses_p2, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
            ::std::option::Option::Some(f_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckLocalClauses { env_p0: env_p0.clone(), st_p1: st_p1.clone(), f_p2: f_p4.clone(), clauses_p3: clauses_p2.clone(), span_p4: span_p3.clone() })),
        }
    }
}

/// `Start CheckLocalFn, x`: what the function value is when passed to `@Run`.
pub fn start_check_local_fn_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, clauses_p2: crate::prelude::Array<crate::syntax::decls::FnClause>, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(CheckLocalFn { env_p0, st_p1, clauses_p2, span_p3 })
}

/// ```prism
/// LocalClauses: fn [Stmt], Nat -> [FnClause]
/// ```
pub fn local_clauses_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>, i_p1: &crate::prelude::Nat) -> crate::prelude::Array<crate::syntax::decls::FnClause> {
    let name_p2 = local_fn_name_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p1), &dummy_stmt_p()));
    let before_p3 = if i_p1 == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("")
    } else {
        local_fn_name_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, &crate::syntax::lexer::chars::dec_f(i_p1)), &dummy_stmt_p()))
    };
    if (&name_p2 == &crate::prelude::Text::lit("")) || (&before_p3 == &name_p2) {
        crate::prelude::Array::new()
    } else {
        {
            let (run_p8, _) = crate::prelude::fold(&crate::prelude::drop(stmts_p0, i_p1), &(crate::prelude::Array::new(), true), &(|(acc_p4, going_p5): &(crate::prelude::Array<crate::syntax::decls::FnClause>, bool), s_p6: &crate::syntax::Stmt| match &s_p6.kind_p {
                crate::syntax::StmtKind::SFn(f_p7) if (*going_p5 && (&crate::check::env::def_name_text_f(&f_p7.name_p) == &name_p2)) => (crate::prelude::push(acc_p4, f_p7), true),
                _ => (acc_p4.clone(), false),
                _ => unreachable!("no arm matched"),
            }));
            run_p8.clone()
        }
    }
}

/// ```prism
/// LocalFnName: fn Stmt -> Text
/// ```
pub fn local_fn_name_f(s_p0: &crate::syntax::Stmt) -> crate::prelude::Text {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SFn(f_p1) => crate::check::env::def_name_text_f(&f_p1.name_p),
        _ => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// IsBoundAhead: fn Ty -> Bool
/// ```
pub fn is_bound_ahead_f(ty0: &crate::check::types::Ty) -> bool {
    match ty0 {
        crate::check::types::Ty::TyFlex(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// CheckLocalClauses: unbounded fn Env, St, FnClause, [FnClause], Range -> ((Env, St))
/// ```
pub fn check_local_clauses_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, f_p2: &crate::syntax::decls::FnClause, clauses_p3: &crate::prelude::Array<crate::syntax::decls::FnClause>, span_p4: &crate::syntax::Range) -> (crate::check::expr::Env, crate::check::types::St) {
    let name_p5 = crate::check::env::def_name_text_f(&f_p2.name_p);
    match crate::prelude::get(&env_p0.locals_p, &name_p5) {
        ::std::option::Option::Some(sc_p6) => if ((&crate::prelude::len(&sc_p6.qs_p) > &crate::prelude::Nat::from(0u32)) || (&crate::prelude::len(&sc_p6.cqs_p) > &crate::prelude::Nat::from(0u32))) || !is_bound_ahead_f(&sc_p6.ty_p) {
            {
                let st2_p7 = check_clauses_f(env_p0, st_p1, &name_p5, clauses_p3, &sc_p6, span_p4);
                (env_p0.clone(), st2_p7.clone())
            }
        } else {
            {
                let unsigned_p8 = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.unsigned_fns_p = crate::prelude::push(&this.unsigned_fns_p, &crate::prelude::Text::from(format!("{}.{}", &st_p1.file_p, &f_p2.span_p.start_p)));
                    this
                };
                let st0_p9 = crate::check::types::schemes::enter_level_f(&unsigned_p8);
                let (own_pf, st0b_pg) = crate::check::types::fresh_var_f(&st0_p9, &false, &crate::prelude::Text::lit(""));
                let inside_pa = crate::check::expr::with_local_f(env_p0, &name_p5, &crate::check::types::schemes::mono_f(&own_pf));
                let (lt_ph, st1_pi) = if &crate::prelude::len(clauses_p3) == &crate::prelude::Nat::from(1u32) {
                    clause_lambda_f(&inside_pa, &st0b_pg, f_p2)
                } else {
                    clauses_lambda_f(&inside_pa, &st0b_pg, &name_p5, clauses_p3, span_p4)
                };
                let st2_pb = crate::check::types::unify::unify_f(&st1_pi, &own_pf, &lt_ph, span_p4);
                let st3_pc = crate::check::env::traits::solve_wants_f(&env_p0.g_p, &st2_pb, &env_p0.givens_p, &false);
                let st4_pd = crate::check::types::schemes::leave_level_f(&st3_pc);
                let t_pe = crate::check::types::recording::zonk_f(&st4_pd, &own_pf);
                if crate::check::types::schemes::holds_node_f(&st4_pd, &t_pe) {
                    (env_p0.clone(), crate::check::types::unify::unify_f(&st4_pd, &sc_p6.ty_p, &t_pe, span_p4))
                } else {
                    {
                        let (keep_pj, bounds_pk, st5_pl) = wants_above_f(&st4_pd, &t_pe, &true);
                        let (sc2_pm, st6_pn) = crate::check::types::schemes::generalize_f(&st5_pl, &t_pe, &keep_pj, &bounds_pk);
                        (crate::check::expr::with_local_f(env_p0, &name_p5, &sc2_pm), crate::check::types::unify::unify_f(&crate::check::types::recording::note_gen_f(&st6_pn, &crate::check::env::def_name_span_f(&f_p2.name_p), &name_p5, &sc2_pm), &sc_p6.ty_p, &t_pe, span_p4))
                    }
                }
            }
        },
        ::std::option::Option::None => (env_p0.clone(), st_p1.clone()),
    }
}

/// The step machine of `CheckLocalClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLocalClauses: unbounded fn Env, St, FnClause, [FnClause], Range -> ((Env, St))
/// ```
pub struct CheckLocalClauses {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub f_p2: crate::syntax::decls::FnClause,
    pub clauses_p3: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for CheckLocalClauses {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let f_p2 = &self.f_p2;
        let clauses_p3 = &self.clauses_p3;
        let span_p4 = &self.span_p4;
        let name_p5 = crate::check::env::def_name_text_f(&f_p2.name_p);
        match crate::prelude::get(&env_p0.locals_p, &name_p5) {
            ::std::option::Option::Some(sc_p6) => if ((&crate::prelude::len(&sc_p6.qs_p) > &crate::prelude::Nat::from(0u32)) || (&crate::prelude::len(&sc_p6.cqs_p) > &crate::prelude::Nat::from(0u32))) || !is_bound_ahead_f(&sc_p6.ty_p) {
                {
                    let clauses_p3x = clauses_p3.clone();
                    let env_p0x = env_p0.clone();
                    let span_p4x = span_p4.clone();
                    let st_p1x = st_p1.clone();
                    crate::prelude::call_then(start_check_clauses_f(env_p0x.clone(), st_p1x.clone(), name_p5.clone(), clauses_p3x.clone(), sc_p6.clone(), span_p4x.clone()), move |check_clauses_f_18885: crate::check::types::St| {
                        let st2_p7 = check_clauses_f_18885;
                        ::prism_rtl::Turn::Finished((env_p0x.clone(), st2_p7.clone()))
                    })
                }
            } else {
                {
                    let unsigned_p8 = {
                        let mut this: crate::check::types::St = st_p1.clone();
                        this.unsigned_fns_p = crate::prelude::push(&this.unsigned_fns_p, &crate::prelude::Text::from(format!("{}.{}", &st_p1.file_p, &f_p2.span_p.start_p)));
                        this
                    };
                    let st0_p9 = crate::check::types::schemes::enter_level_f(&unsigned_p8);
                    let (own_pf, st0b_pg) = crate::check::types::fresh_var_f(&st0_p9, &false, &crate::prelude::Text::lit(""));
                    let inside_pa = crate::check::expr::with_local_f(env_p0, &name_p5, &crate::check::types::schemes::mono_f(&own_pf));
                    let (lt_ph, st1_pi) = if &crate::prelude::len(clauses_p3) == &crate::prelude::Nat::from(1u32) {
                        clause_lambda_f(&inside_pa, &st0b_pg, f_p2)
                    } else {
                        clauses_lambda_f(&inside_pa, &st0b_pg, &name_p5, clauses_p3, span_p4)
                    };
                    let env_p0x = env_p0.clone();
                    let f_p2x = f_p2.clone();
                    let span_p4x = span_p4.clone();
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st1_pi.clone(), own_pf.clone(), lt_ph.clone(), span_p4x.clone()), move |unify_f_19784: crate::check::types::St| {
                        let st2_pb = unify_f_19784;
                        crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(env_p0x.g_p.clone(), st2_pb.clone(), env_p0x.givens_p.clone(), false), move |solve_wants_f_19835: crate::check::types::St| {
                            let st3_pc = solve_wants_f_19835;
                            let st4_pd = crate::check::types::schemes::leave_level_f(&st3_pc);
                            crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st4_pd.clone(), own_pf.clone()), move |zonk_f_19941: crate::check::types::Ty| {
                                let t_pe = zonk_f_19941;
                                crate::prelude::call_then(crate::check::types::schemes::start_holds_node_f(st4_pd.clone(), t_pe.clone()), move |holds_node_f_19974: bool| if holds_node_f_19974 {
                                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st4_pd.clone(), sc_p6.ty_p.clone(), t_pe.clone(), span_p4x.clone()), move |unify_f_20000: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), unify_f_20000)))
                                } else {
                                    crate::prelude::call_then(start_wants_above_f(st4_pd.clone(), t_pe.clone(), true), move |wants_above_f_20099: (crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::St)| {
                                        let (keep_pj, bounds_pk, st5_pl) = wants_above_f_20099;
                                        crate::prelude::call_then(crate::check::types::schemes::start_generalize_f(st5_pl.clone(), t_pe.clone(), keep_pj.clone(), bounds_pk.clone()), move |generalize_f_20162: (crate::check::types::Scheme, crate::check::types::St)| {
                                            let (sc2_pm, st6_pn) = generalize_f_20162;
                                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(crate::check::types::recording::note_gen_f(&st6_pn, &crate::check::env::def_name_span_f(&f_p2x.name_p), &name_p5, &sc2_pm), sc_p6.ty_p.clone(), t_pe.clone(), span_p4x.clone()), move |unify_f_20338: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::check::expr::with_local_f(&env_p0x, &name_p5, &sc2_pm), unify_f_20338)))
                                        })
                                    })
                                })
                            })
                        })
                    })
                }
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
        }
    }
}

/// `Start CheckLocalClauses, x`: what the function value is when passed to `@Run`.
pub fn start_check_local_clauses_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, f_p2: crate::syntax::decls::FnClause, clauses_p3: crate::prelude::Array<crate::syntax::decls::FnClause>, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(CheckLocalClauses { env_p0, st_p1, f_p2, clauses_p3, span_p4 })
}

/// ```prism
/// ClausesLambda: unbounded fn Env, St, Text, [FnClause], Range -> ((Ty, St))
/// ```
pub fn clauses_lambda_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, name_p2: &crate::prelude::Text, clauses_p3: &crate::prelude::Array<crate::syntax::decls::FnClause>, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let arity_p5 = match crate::prelude::index(clauses_p3, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(c_ph) => crate::prelude::len(&c_ph.params_p),
        ::std::option::Option::None => crate::prelude::Nat::from(0u32),
    };
    let (params_pm, st1_pn) = crate::prelude::fold(&crate::check::errors::range0_f(&arity_p5), &(crate::prelude::Array::new(), st_p1.clone()), &(|(acc_pi, s_pj): &(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), _: &crate::prelude::Nat| {
        let (v_pk, s2_pl) = crate::check::types::fresh_var_f(s_pj, &true, &crate::prelude::Text::lit(""));
        (crate::prelude::push(acc_pi, &v_pk), s2_pl.clone())
    }));
    let (res_po, st2_pp) = crate::check::types::fresh_var_f(&st1_pn, &false, &crate::prelude::Text::lit(""));
    let (lcol_pq, st3_pr) = crate::check::types::fresh_col_f(&st2_pp);
    let outer_color_p6 = st3_pr.color_p.clone();
    let outer_why_p7 = st3_pr.color_why_p.clone();
    let outer_flex_p8 = st3_pr.color_flex_p.clone();
    let st4_p9 = {
        let mut this: crate::check::types::St = st3_pr.clone();
        this.color_p = crate::check::types::Col::CBound;
        this.color_why_p = crate::prelude::Text::lit("");
        this.color_flex_p = crate::prelude::Array::new();
        this
    };
    let env2_pa = {
        let mut this: crate::check::expr::Env = env_p0.clone();
        this.mark_p = crate::syntax::lexer::chars::head_f(&crate::check::types::unify::marks_of_f(name_p2));
        this
    };
    let st5_pb = crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p3.clone(), st4_p9.clone(), {
        let env2_pax = env2_pa.clone();
        let params_pmx = params_pm.clone();
        let res_pox = res_po.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
            let env2_paxy = env2_pax.clone();
            let params_pmxy = params_pmx.clone();
            let res_poxy = res_pox.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_ps = p0;
                let c_pt = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckClause { env_p0: env2_paxy.clone(), st_p1: s_ps.clone(), c_p2: c_pt.clone(), params_p3: params_pmxy.clone(), res_p4: res_poxy.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }));
    let st6_pc = crate::check::passes::clause_coverage_f(&env2_pa, &st5_pb, clauses_p3, &params_pm, span_p4);
    let st7_pd = crate::check::types::colors::settle_body_f(&st6_pc, &lcol_pq, &crate::prelude::Text::lit(""));
    let st8_pe = crate::check::types::colors::add_leq_f(&st7_pd, &st7_pd.color_p, &lcol_pq, span_p4, &crate::prelude::Text::lit("lambda"), &crate::prelude::Text::lit(""), &st7_pd.color_why_p);
    let st9_pf = {
        let mut this: crate::check::types::St = st8_pe.clone();
        this.color_p = outer_color_p6.clone();
        this.color_why_p = outer_why_p7.clone();
        this.color_flex_p = outer_flex_p8.clone();
        this
    };
    let t_pg = crate::check::types::Ty::TyFn(lcol_pq.clone(), params_pm.clone(), ::std::rc::Rc::new(res_po.clone()));
    (t_pg.clone(), crate::check::types::recording::note_ty_f(&crate::check::types::recording::note_fn_f(&st9_pf, span_p4, &crate::prelude::Text::lit("lambda"), &lcol_pq, &lcol_pq), span_p4, &t_pg))
}

/// ```prism
/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
/// ```
pub fn clause_lambda_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, f_p2: &crate::syntax::decls::FnClause) -> (crate::check::types::Ty, crate::check::types::St) {
    let body_p3 = match &f_p2.body_p {
        crate::syntax::decls::FnBody::BodyExpr(e_p4) => crate::syntax::LambdaBody::LbExpr(::std::rc::Rc::new(e_p4.clone())),
        crate::syntax::decls::FnBody::BodyBlock(b_p5) => crate::syntax::LambdaBody::LbBlock(b_p5.clone()),
    };
    crate::check::expr::calls::infer_lambda_f(env_p0, st_p1, &crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ELambda(::std::option::Option::Some(f_p2.params_p.clone()), ::std::rc::Rc::new(body_p3.clone()))), span_p: f_p2.span_p.clone() }, &::std::option::Option::None)
}

/// ```prism
/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
/// ```
pub fn check_clauses_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, name_p2: &crate::prelude::Text, clauses_p3: &crate::prelude::Array<crate::syntax::decls::FnClause>, sc_p4: &crate::check::types::Scheme, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    let t_p6 = crate::check::types::schemes::skolemize_f(sc_p4);
    let givens_p7 = crate::prelude::append(&env_p0.givens_p, &sc_p4.bounds_p);
    let env2_p8 = {
        let mut this: crate::check::expr::Env = env_p0.clone();
        this.givens_p = givens_p7.clone();
        this.mark_p = crate::syntax::lexer::chars::head_f(&crate::check::types::unify::marks_of_f(name_p2));
        this.def_name_p = name_p2.clone();
        this
    };
    match &t_p6 {
        crate::check::types::Ty::TyFn(col_p9, params_pa, res_pb) => {
            let outer_color_pc = st_p1.color_p.clone();
            let outer_flex_pd = st_p1.color_flex_p.clone();
            let st0_pe = {
                let mut this: crate::check::types::St = st_p1.clone();
                this.color_p = crate::check::types::Col::CBound;
                this.color_why_p = crate::prelude::Text::lit("");
                this.color_flex_p = crate::prelude::Array::new();
                this.col_up_p = crate::prelude::fold(&sc_p4.cjoins_p, &this.col_up_p, &(|m_pk: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, (lo_pl, hi_pm): &(crate::prelude::Text, crate::prelude::Text)| crate::prelude::insert(m_pk, lo_pl, hi_pm)));
                this
            };
            let st1_pf = crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p3.clone(), st0_pe.clone(), {
                let env2_p8x = env2_p8.clone();
                let params_pax = params_pa.clone();
                let res_pbx = (**res_pb).clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                    let env2_p8xy = env2_p8x.clone();
                    let params_paxy = params_pax.clone();
                    let res_pbxy = res_pbx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_pn = p0;
                        let c_po = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckClause { env_p0: env2_p8xy.clone(), st_p1: s_pn.clone(), c_p2: c_po.clone(), params_p3: params_paxy.clone(), res_p4: res_pbxy.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
            }));
            let st1b_pg = crate::check::types::colors::settle_body_f(&crate::check::env::traits::solve_wants_f(&env_p0.g_p, &st1_pf, &givens_p7, &false), col_p9, name_p2);
            let st2_ph = crate::check::passes::clause_coverage_f(&env2_p8, &st1b_pg, clauses_p3, params_pa, span_p5);
            let st3_pi = if crate::check::types::colors::col_leq_f(&st2_ph.color_p, col_p9) {
                st2_ph.clone()
            } else {
                crate::check::types::recording::err_fix_f(&st2_ph, &crate::prelude::Text::lit("calls-unbounded"), span_p5, &crate::prelude::Text::from(format!("{} `{}` calls {} `{}`", &crate::check::types::colors::col_word_f(col_p9), name_p2, &crate::check::types::colors::col_word_f(&st2_ph.color_p), &st2_ph.color_why_p)), &crate::prelude::Text::from(format!("mark `{}` `unbounded fn`, or run the call through `@Run`", name_p2)))
            };
            let st4_pj = crate::check::types::recording::note_fn_f(&st3_pi, span_p5, name_p2, col_p9, &st2_ph.color_p);
            {
                let mut this: crate::check::types::St = st4_pj.clone();
                this.color_p = outer_color_pc.clone();
                this.color_flex_p = outer_flex_pd.clone();
                this
            }
        },
        other_pp => {
            let st1_pq = crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p3.clone(), st_p1.clone(), {
                let env2_p8x = env2_p8.clone();
                let other_ppx = other_pp.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                    let env2_p8xy = env2_p8x.clone();
                    let other_ppxy = other_ppx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_pr = p0;
                        let c_ps = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckClause { env_p0: env2_p8xy.clone(), st_p1: s_pr.clone(), c_p2: c_ps.clone(), params_p3: crate::prelude::Array::new(), res_p4: other_ppxy.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
            }));
            crate::prelude::fold(&crate::prelude::drop(clauses_p3, &crate::prelude::Nat::from(1u32)), &st1_pq, &(|s_pt: &crate::check::types::St, c_pu: &crate::syntax::decls::FnClause| if &crate::prelude::len(&c_pu.params_p) == &crate::prelude::Nat::from(0u32) {
                crate::check::types::recording::err_f(s_pt, &crate::prelude::Text::lit("collision"), &c_pu.span_p, &crate::prelude::Text::from(format!("`{}` is defined twice", name_p2)))
            } else {
                s_pt.clone()
            }))
        },
    }
}

/// The step machine of `CheckClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
/// ```
pub struct CheckClauses {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub name_p2: crate::prelude::Text,
    pub clauses_p3: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub sc_p4: crate::check::types::Scheme,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for CheckClauses {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let name_p2 = &self.name_p2;
        let clauses_p3 = &self.clauses_p3;
        let sc_p4 = &self.sc_p4;
        let span_p5 = &self.span_p5;
        let clauses_p3x = clauses_p3.clone();
        let env_p0x = env_p0.clone();
        let name_p2x = name_p2.clone();
        let sc_p4x = sc_p4.clone();
        let span_p5x = span_p5.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::schemes::start_skolemize_f(sc_p4x.clone()), move |skolemize_f_22731: crate::check::types::Ty| {
            let t_p6 = skolemize_f_22731;
            let givens_p7 = crate::prelude::append(&env_p0x.givens_p, &sc_p4x.bounds_p);
            let env2_p8 = {
                let mut this: crate::check::expr::Env = env_p0x.clone();
                this.givens_p = givens_p7.clone();
                this.mark_p = crate::syntax::lexer::chars::head_f(&crate::check::types::unify::marks_of_f(&name_p2x));
                this.def_name_p = name_p2x.clone();
                this
            };
            match &t_p6 {
                crate::check::types::Ty::TyFn(col_p9, params_pa, res_pb) => {
                    let outer_color_pc = st_p1x.color_p.clone();
                    let outer_flex_pd = st_p1x.color_flex_p.clone();
                    let st0_pe = {
                        let mut this: crate::check::types::St = st_p1x.clone();
                        this.color_p = crate::check::types::Col::CBound;
                        this.color_why_p = crate::prelude::Text::lit("");
                        this.color_flex_p = crate::prelude::Array::new();
                        this.col_up_p = crate::prelude::fold(&sc_p4x.cjoins_p, &this.col_up_p, &(|m_pk: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, (lo_pl, hi_pm): &(crate::prelude::Text, crate::prelude::Text)| crate::prelude::insert(m_pk, lo_pl, hi_pm)));
                        this
                    };
                    let col_p9x = col_p9.clone();
                    let params_pax = params_pa.clone();
                    let res_pbx = (**res_pb).clone();
                    crate::prelude::call_value(crate::prelude::fold_job(clauses_p3x.clone(), st0_pe.clone(), {
                        let env2_p8x = env2_p8.clone();
                        let params_paxx = params_pax.clone();
                        let res_pbxx = res_pbx.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                            let env2_p8xy = env2_p8x.clone();
                            let params_paxxy = params_paxx.clone();
                            let res_pbxxy = res_pbxx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let s_pn = p0;
                                let c_po = p1;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckClause { env_p0: env2_p8xy.clone(), st_p1: s_pn.clone(), c_p2: c_po.clone(), params_p3: params_paxxy.clone(), res_p4: res_pbxxy.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_23283: crate::check::types::St| {
                        let st1_pf = fold_23283;
                        crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(env_p0x.g_p.clone(), st1_pf.clone(), givens_p7.clone(), false), move |solve_wants_f_23381: crate::check::types::St| crate::prelude::call_then(crate::check::types::colors::start_settle_body_f(solve_wants_f_23381, col_p9x.clone(), name_p2x.clone()), move |settle_body_f_23369: crate::check::types::St| {
                            let st1b_pg = settle_body_f_23369;
                            crate::prelude::call_then(crate::check::passes::start_clause_coverage_f(env2_p8.clone(), st1b_pg.clone(), clauses_p3x.clone(), params_pax.clone(), span_p5x.clone()), move |clause_coverage_f_23452: crate::check::types::St| {
                                let st2_ph = clause_coverage_f_23452;
                                let st3_pi = if crate::check::types::colors::col_leq_f(&st2_ph.color_p, &col_p9x) {
                                    st2_ph.clone()
                                } else {
                                    crate::check::types::recording::err_fix_f(&st2_ph, &crate::prelude::Text::lit("calls-unbounded"), &span_p5x, &crate::prelude::Text::from(format!("{} `{}` calls {} `{}`", &crate::check::types::colors::col_word_f(&col_p9x), &name_p2x, &crate::check::types::colors::col_word_f(&st2_ph.color_p), &st2_ph.color_why_p)), &crate::prelude::Text::from(format!("mark `{}` `unbounded fn`, or run the call through `@Run`", &name_p2x)))
                                };
                                let st4_pj = crate::check::types::recording::note_fn_f(&st3_pi, &span_p5x, &name_p2x, &col_p9x, &st2_ph.color_p);
                                ::prism_rtl::Turn::Finished({
                                    let mut this: crate::check::types::St = st4_pj.clone();
                                    this.color_p = outer_color_pc.clone();
                                    this.color_flex_p = outer_flex_pd.clone();
                                    this
                                })
                            })
                        }))
                    })
                },
                other_pp => {
                    let other_ppx = other_pp.clone();
                    crate::prelude::call_value(crate::prelude::fold_job(clauses_p3x.clone(), st_p1x.clone(), {
                        let env2_p8x = env2_p8.clone();
                        let other_ppxx = other_ppx.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                            let env2_p8xy = env2_p8x.clone();
                            let other_ppxxy = other_ppxx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let s_pr = p0;
                                let c_ps = p1;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckClause { env_p0: env2_p8xy.clone(), st_p1: s_pr.clone(), c_p2: c_ps.clone(), params_p3: crate::prelude::Array::new(), res_p4: other_ppxxy.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_24113: crate::check::types::St| {
                        let st1_pq = fold_24113;
                        ::prism_rtl::Turn::Finished(crate::prelude::fold(&crate::prelude::drop(&clauses_p3x, &crate::prelude::Nat::from(1u32)), &st1_pq, &(|s_pt: &crate::check::types::St, c_pu: &crate::syntax::decls::FnClause| if &crate::prelude::len(&c_pu.params_p) == &crate::prelude::Nat::from(0u32) {
                            crate::check::types::recording::err_f(s_pt, &crate::prelude::Text::lit("collision"), &c_pu.span_p, &crate::prelude::Text::from(format!("`{}` is defined twice", &name_p2x)))
                        } else {
                            s_pt.clone()
                        })))
                    })
                },
            }
        })
    }
}

/// `Start CheckClauses, x`: what the function value is when passed to `@Run`.
pub fn start_check_clauses_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, name_p2: crate::prelude::Text, clauses_p3: crate::prelude::Array<crate::syntax::decls::FnClause>, sc_p4: crate::check::types::Scheme, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CheckClauses { env_p0, st_p1, name_p2, clauses_p3, sc_p4, span_p5 })
}

/// ```prism
/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
/// ```
pub fn check_clause_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::syntax::decls::FnClause, params_p3: &crate::prelude::Array<crate::check::types::Ty>, res_p4: &crate::check::types::Ty) -> crate::check::types::St {
    if &crate::prelude::len(&c_p2.params_p) != &crate::prelude::len(params_p3) {
        crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &c_p2.span_p, &crate::prelude::Text::from(format!("this clause takes {} parameter{}; the signature has {}", &crate::check::errors::count_word_f(&crate::prelude::len(&c_p2.params_p)), &(if &crate::prelude::len(&c_p2.params_p) == &crate::prelude::Nat::from(1u32) {
            crate::prelude::Text::lit("")
        } else {
            crate::prelude::Text::lit("s")
        }), &crate::check::errors::count_word_f(&crate::prelude::len(params_p3)))))
    } else {
        {
            let (env2_p8, st1_p9) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(params_p3)), (env_p0.clone(), crate::check::expr::patterns::bound_twice_f(env_p0, st_p1, &c_p2.params_p)), {
                let c_p2x = c_p2.clone();
                let params_p3x = params_p3.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)| {
                    let c_p2xy = c_p2x.clone();
                    let params_p3xy = params_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (en_p5, s_p6) = p0;
                        let i_p7 = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::patterns::BindPattern { env_p0: en_p5.clone(), st_p1: s_p6.clone(), p_p2: crate::prelude::or(&crate::prelude::index(&c_p2xy.params_p, &i_p7), &crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: c_p2xy.span_p.clone() }), t_p3: crate::prelude::or(&crate::prelude::index(&params_p3xy, &i_p7), &crate::check::types::Ty::TyErr), refutable_p4: true }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }));
            check_body_f(&env2_p8, &st1_p9, &c_p2.body_p, &refined_result_f(env_p0, &st1_p9, &c_p2.params_p, params_p3, res_p4))
        }
    }
}

/// The step machine of `CheckClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
/// ```
pub struct CheckClause {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::syntax::decls::FnClause,
    pub params_p3: crate::prelude::Array<crate::check::types::Ty>,
    pub res_p4: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::St> for CheckClause {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let params_p3 = &self.params_p3;
        let res_p4 = &self.res_p4;
        if &crate::prelude::len(&c_p2.params_p) != &crate::prelude::len(params_p3) {
            ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &c_p2.span_p, &crate::prelude::Text::from(format!("this clause takes {} parameter{}; the signature has {}", &crate::check::errors::count_word_f(&crate::prelude::len(&c_p2.params_p)), &(if &crate::prelude::len(&c_p2.params_p) == &crate::prelude::Nat::from(1u32) {
                crate::prelude::Text::lit("")
            } else {
                crate::prelude::Text::lit("s")
            }), &crate::check::errors::count_word_f(&crate::prelude::len(params_p3))))))
        } else {
            {
                let c_p2x = c_p2.clone();
                let env_p0x = env_p0.clone();
                let params_p3x = params_p3.clone();
                let res_p4x = res_p4.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::patterns::start_bound_twice_f(env_p0x.clone(), st_p1x.clone(), c_p2x.params_p.clone()), move |bound_twice_f_24701: crate::check::types::St| crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&params_p3x)), (env_p0x.clone(), bound_twice_f_24701), {
                    let c_p2xx = c_p2x.clone();
                    let params_p3xx = params_p3x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)| {
                        let c_p2xxy = c_p2xx.clone();
                        let params_p3xxy = params_p3xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (en_p5, s_p6) = p0;
                            let i_p7 = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::patterns::BindPattern { env_p0: en_p5.clone(), st_p1: s_p6.clone(), p_p2: crate::prelude::or(&crate::prelude::index(&c_p2xxy.params_p, &i_p7), &crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: c_p2xxy.span_p.clone() }), t_p3: crate::prelude::or(&crate::prelude::index(&params_p3xxy, &i_p7), &crate::check::types::Ty::TyErr), refutable_p4: true }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                }), move |fold_24665: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2_p8, st1_p9) = fold_24665;
                    crate::prelude::call_then(start_refined_result_f(env_p0x.clone(), st1_p9.clone(), c_p2x.params_p.clone(), params_p3x.clone(), res_p4x.clone()), move |refined_result_f_24889: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(CheckBody { env_p0: env2_p8.clone(), st_p1: st1_p9.clone(), body_p2: c_p2x.body_p.clone(), res_p3: refined_result_f_24889 })))
                }))
            }
        }
    }
}

/// `Start CheckClause, x`: what the function value is when passed to `@Run`.
pub fn start_check_clause_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, c_p2: crate::syntax::decls::FnClause, params_p3: crate::prelude::Array<crate::check::types::Ty>, res_p4: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CheckClause { env_p0, st_p1, c_p2, params_p3, res_p4 })
}

/// ```prism
/// RefinedResult: unbounded fn Env, St, [Pattern], [Ty], Ty -> Ty
/// ```
pub fn refined_result_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, patterns_p2: &crate::prelude::Array<crate::syntax::Pattern>, params_p3: &crate::prelude::Array<crate::check::types::Ty>, res_p4: &crate::check::types::Ty) -> crate::check::types::Ty {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(params_p3)), res_p4.clone(), {
        let patterns_p2x = patterns_p2.clone();
        let st_p1x = st_p1.clone();
        let params_p3x = params_p3.clone();
        let env_p0x = env_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::Ty, crate::prelude::Nat)| {
            let patterns_p2xy = patterns_p2x.clone();
            let st_p1xy = st_p1x.clone();
            let params_p3xy = params_p3x.clone();
            let env_p0xy = env_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let r_p5 = p0;
                let i_p6 = p1;
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xy.clone(), crate::prelude::or(&crate::prelude::index(&params_p3xy, &i_p6), &crate::check::types::Ty::TyErr)), move |walk_f_25559: crate::check::types::Ty| match (crate::prelude::index(&patterns_p2xy, &i_p6), walk_f_25559) {
                    (::std::option::Option::Some(p_p7), crate::check::types::Ty::TyElem(_, o_p8)) => crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xy.clone(), (*o_p8).clone()), move |walk_f_25638: crate::check::types::Ty| match (walk_f_25638, crate::check::expr::lifting::tag_of_pattern_o(&env_p0xy, &p_p7)) {
                        (crate::check::types::Ty::TyRigid(name_p9), ::std::option::Option::Some(tg_pa)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::lifting::SubstRigid { name_p0: name_p9.clone(), by_p1: tg_pa.out_p.clone(), t_p2: r_p5.clone() })),
                        _ => ::prism_rtl::Turn::Finished(r_p5.clone()),
                    }),
                    _ => ::prism_rtl::Turn::Finished(r_p5.clone()),
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::Ty, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
    }))
}

/// The step machine of `RefinedResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RefinedResult: unbounded fn Env, St, [Pattern], [Ty], Ty -> Ty
/// ```
pub struct RefinedResult {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub patterns_p2: crate::prelude::Array<crate::syntax::Pattern>,
    pub params_p3: crate::prelude::Array<crate::check::types::Ty>,
    pub res_p4: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for RefinedResult {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let patterns_p2 = &self.patterns_p2;
        let params_p3 = &self.params_p3;
        let res_p4 = &self.res_p4;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(params_p3)), res_p4.clone(), {
            let patterns_p2x = patterns_p2.clone();
            let st_p1x = st_p1.clone();
            let params_p3x = params_p3.clone();
            let env_p0x = env_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::Ty, crate::prelude::Nat)| {
                let patterns_p2xy = patterns_p2x.clone();
                let st_p1xy = st_p1x.clone();
                let params_p3xy = params_p3x.clone();
                let env_p0xy = env_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let r_p5 = p0;
                    let i_p6 = p1;
                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xy.clone(), crate::prelude::or(&crate::prelude::index(&params_p3xy, &i_p6), &crate::check::types::Ty::TyErr)), move |walk_f_25559: crate::check::types::Ty| match (crate::prelude::index(&patterns_p2xy, &i_p6), walk_f_25559) {
                        (::std::option::Option::Some(p_p7), crate::check::types::Ty::TyElem(_, o_p8)) => crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xy.clone(), (*o_p8).clone()), move |walk_f_25638: crate::check::types::Ty| match (walk_f_25638, crate::check::expr::lifting::tag_of_pattern_o(&env_p0xy, &p_p7)) {
                            (crate::check::types::Ty::TyRigid(name_p9), ::std::option::Option::Some(tg_pa)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::lifting::SubstRigid { name_p0: name_p9.clone(), by_p1: tg_pa.out_p.clone(), t_p2: r_p5.clone() })),
                            _ => ::prism_rtl::Turn::Finished(r_p5.clone()),
                        }),
                        _ => ::prism_rtl::Turn::Finished(r_p5.clone()),
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::Ty, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        }).cycle()
    }
}

/// `Start RefinedResult, x`: what the function value is when passed to `@Run`.
pub fn start_refined_result_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, patterns_p2: crate::prelude::Array<crate::syntax::Pattern>, params_p3: crate::prelude::Array<crate::check::types::Ty>, res_p4: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(RefinedResult { env_p0, st_p1, patterns_p2, params_p3, res_p4 })
}

/// ```prism
/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
/// ```
pub fn check_body_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, body_p2: &crate::syntax::decls::FnBody, res_p3: &crate::check::types::Ty) -> crate::check::types::St {
    match body_p2 {
        crate::syntax::decls::FnBody::BodyExpr(e_p4) => crate::check::expr::check_f(env_p0, st_p1, e_p4, res_p3),
        crate::syntax::decls::FnBody::BodyBlock(b_p5) => if &env_p0.mark_p == &crate::prelude::Text::lit("@") {
            match crate::check::types::recording::walk_f(st_p1, res_p3) {
                crate::check::types::Ty::TyAt(inner_p6, rw_p7) => {
                    let env2_p8 = {
                        let mut this: crate::check::expr::Env = env_p0.clone();
                        this.scope_p = rw_p7;
                        this
                    };
                    let (t_p9, st2_pa) = crate::check::blocks::infer_widget_block_at_f(&env2_p8, st_p1, b_p5, &::std::option::Option::Some((*inner_p6).clone()));
                    crate::check::types::unify::unify_f(&st2_pa, &*inner_p6, &t_p9, &crate::check::types::recording::result_span_f(b_p5))
                },
                other_pb => crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &b_p5.span_p, &crate::prelude::Text::from(format!("a widget block builds a blueprint; the signature says `{}`", &crate::check::types::show_ty_f(st_p1, &other_pb)))),
            }
        } else {
            if (&env_p0.mark_p == &crate::prelude::Text::lit("?")) || (&env_p0.mark_p == &crate::prelude::Text::lit("~")) {
                {
                    let (t_pc, st2_pd) = crate::check::blocks::structure::infer_given_block_f(env_p0, st_p1, b_p5, &env_p0.mark_p);
                    crate::check::types::unify::unify_f(&st2_pd, res_p3, &t_pc, &crate::check::types::recording::result_span_f(b_p5))
                }
            } else {
                {
                    let (t_pe, st2_pf) = infer_expr_block_f(env_p0, st_p1, b_p5);
                    crate::check::types::unify::unify_f(&st2_pf, res_p3, &t_pe, &crate::check::types::recording::result_span_f(b_p5))
                }
            }
        },
    }
}

/// The step machine of `CheckBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
/// ```
pub struct CheckBody {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub body_p2: crate::syntax::decls::FnBody,
    pub res_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::St> for CheckBody {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let body_p2 = &self.body_p2;
        let res_p3 = &self.res_p3;
        match body_p2 {
            crate::syntax::decls::FnBody::BodyExpr(e_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::Check { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p4.clone(), expected_p3: res_p3.clone() })),
            crate::syntax::decls::FnBody::BodyBlock(b_p5) => if &env_p0.mark_p == &crate::prelude::Text::lit("@") {
                {
                    let b_p5x = b_p5.clone();
                    let env_p0x = env_p0.clone();
                    let res_p3x = res_p3.clone();
                    let st_p1x = st_p1.clone();
                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), res_p3x.clone()), move |walk_f_26149: crate::check::types::Ty| match walk_f_26149 {
                        crate::check::types::Ty::TyAt(inner_p6, rw_p7) => {
                            let env2_p8 = {
                                let mut this: crate::check::expr::Env = env_p0x.clone();
                                this.scope_p = rw_p7.clone();
                                this
                            };
                            crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_at_f(env2_p8.clone(), st_p1x.clone(), b_p5x.clone(), ::std::option::Option::Some((*inner_p6).clone())), move |infer_widget_block_at_f_26314: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t_p9, st2_pa) = infer_widget_block_at_f_26314;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st2_pa.clone(), expected_p1: (*inner_p6).clone(), found_p2: t_p9.clone(), span_p3: crate::check::types::recording::result_span_f(&b_p5x) }))
                            })
                        },
                        other_pb => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), other_pb.clone()), move |show_ty_f_26520: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&st_p1x, &crate::prelude::Text::lit("mismatch"), &b_p5x.span_p, &crate::prelude::Text::from(format!("a widget block builds a blueprint; the signature says `{}`", &show_ty_f_26520))))),
                    })
                }
            } else {
                if (&env_p0.mark_p == &crate::prelude::Text::lit("?")) || (&env_p0.mark_p == &crate::prelude::Text::lit("~")) {
                    {
                        let b_p5x = b_p5.clone();
                        let env_p0x = env_p0.clone();
                        let res_p3x = res_p3.clone();
                        let st_p1x = st_p1.clone();
                        crate::prelude::call_then(crate::check::blocks::structure::start_infer_given_block_f(env_p0x.clone(), st_p1x.clone(), b_p5x.clone(), env_p0x.mark_p.clone()), move |infer_given_block_f_26622: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_pc, st2_pd) = infer_given_block_f_26622;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st2_pd.clone(), expected_p1: res_p3x.clone(), found_p2: t_pc.clone(), span_p3: crate::check::types::recording::result_span_f(&b_p5x) }))
                        })
                    }
                } else {
                    {
                        let b_p5x = b_p5.clone();
                        let env_p0x = env_p0.clone();
                        let res_p3x = res_p3.clone();
                        let st_p1x = st_p1.clone();
                        crate::prelude::call_then(start_infer_expr_block_f(env_p0x.clone(), st_p1x.clone(), b_p5x.clone()), move |infer_expr_block_f_26748: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_pe, st2_pf) = infer_expr_block_f_26748;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st2_pf.clone(), expected_p1: res_p3x.clone(), found_p2: t_pe.clone(), span_p3: crate::check::types::recording::result_span_f(&b_p5x) }))
                        })
                    }
                }
            },
        }
    }
}

/// `Start CheckBody, x`: what the function value is when passed to `@Run`.
pub fn start_check_body_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, body_p2: crate::syntax::decls::FnBody, res_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CheckBody { env_p0, st_p1, body_p2, res_p3 })
}

/// ```prism
/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
/// ```
pub fn infer_template_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::syntax::Template) -> (crate::check::types::Ty, crate::check::types::St) {
    let st2_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(t_p2.parts_p.clone(), st_p1.clone(), {
        let env_p0x = env_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::TemplatePart)| {
            let env_p0xy = env_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p4 = p0;
                let part_p5 = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TemplatePartCheck { env_p0: env_p0xy.clone(), st_p1: s_p4.clone(), part_p2: part_p5.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::TemplatePart)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }));
    (crate::check::types::t_text_p(), st2_p3.clone())
}

/// The step machine of `InferTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
/// ```
pub struct InferTemplate {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::syntax::Template,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferTemplate {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_value(crate::prelude::fold_job(t_p2x.parts_p.clone(), st_p1x.clone(), {
            let env_p0xx = env_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::TemplatePart)| {
                let env_p0xxy = env_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p4 = p0;
                    let part_p5 = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(TemplatePartCheck { env_p0: env_p0xxy.clone(), st_p1: s_p4.clone(), part_p2: part_p5.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::TemplatePart)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        }), move |fold_27171: crate::check::types::St| {
            let st2_p3 = fold_27171;
            ::prism_rtl::Turn::Finished((crate::check::types::t_text_p(), st2_p3.clone()))
        })
    }
}

/// `Start InferTemplate, x`: what the function value is when passed to `@Run`.
pub fn start_infer_template_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::syntax::Template) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferTemplate { env_p0, st_p1, t_p2 })
}

/// ```prism
/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
/// ```
pub fn template_part_check_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, part_p2: &crate::syntax::TemplatePart) -> crate::check::types::St {
    match part_p2 {
        crate::syntax::TemplatePart::TpText(_) => st_p1.clone(),
        crate::syntax::TemplatePart::TpPlaceholder(x_p3, _) => {
            let (t_p4, st2_p5) = crate::check::expr::infer_f(env_p0, st_p1, x_p3);
            crate::check::expr::show_want_f(&st2_p5, &(if crate::check::expr::is_time_sigil_f(&crate::check::types::head_sigil_f(&st2_p5, &t_p4)) {
                crate::check::expr::inner_of_f(&st2_p5, &t_p4)
            } else {
                t_p4.clone()
            }), &x_p3.span_p)
        },
        crate::syntax::TemplatePart::TpBlock(b_p6) => {
            let (t_p7, st2_p8) = infer_expr_block_f(env_p0, st_p1, b_p6);
            st2_p8.clone()
        },
        crate::syntax::TemplatePart::TpCall(n_p9, args_pa, parts_ob, span_pc) => template_call_check_f(env_p0, st_p1, n_p9, args_pa, parts_ob, span_pc),
    }
}

/// The step machine of `TemplatePartCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
/// ```
pub struct TemplatePartCheck {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub part_p2: crate::syntax::TemplatePart,
}

impl ::prism_rtl::Job<crate::check::types::St> for TemplatePartCheck {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let part_p2 = &self.part_p2;
        match part_p2 {
            crate::syntax::TemplatePart::TpText(_) => ::prism_rtl::Turn::Finished(st_p1.clone()),
            crate::syntax::TemplatePart::TpPlaceholder(x_p3, _) => {
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let x_p3x = x_p3.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), x_p3x.clone()), move |infer_f_27436: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p4, st2_p5) = infer_f_27436;
                    crate::prelude::call_then(crate::check::types::start_head_sigil_f(st2_p5.clone(), t_p4.clone()), move |head_sigil_f_27492: crate::prelude::Text| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::ShowWant { st_p0: st2_p5.clone(), t_p1: if crate::check::expr::is_time_sigil_f(&head_sigil_f_27492) {
                        crate::check::expr::inner_of_f(&st2_p5, &t_p4)
                    } else {
                        t_p4.clone()
                    }, span_p2: x_p3x.span_p.clone() })))
                })
            },
            crate::syntax::TemplatePart::TpBlock(b_p6) => {
                let b_p6x = b_p6.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_infer_expr_block_f(env_p0x.clone(), st_p1x.clone(), b_p6x.clone()), move |infer_expr_block_f_27583: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p7, st2_p8) = infer_expr_block_f_27583;
                    ::prism_rtl::Turn::Finished(st2_p8.clone())
                })
            },
            crate::syntax::TemplatePart::TpCall(n_p9, args_pa, parts_ob, span_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TemplateCallCheck { env_p0: env_p0.clone(), st_p1: st_p1.clone(), n_p2: n_p9.clone(), args_p3: args_pa.clone(), parts_o4: parts_ob.clone(), span_p5: span_pc.clone() })),
        }
    }
}

/// `Start TemplatePartCheck, x`: what the function value is when passed to `@Run`.
pub fn start_template_part_check_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, part_p2: crate::syntax::TemplatePart) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(TemplatePartCheck { env_p0, st_p1, part_p2 })
}

/// ```prism
/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
/// ```
pub fn template_call_check_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, n_p2: &crate::syntax::SName, args_p3: &crate::prelude::Array<crate::syntax::Arg>, parts_o4: &::std::option::Option<crate::prelude::Array<crate::syntax::TemplatePart>>, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    let plain_p6 = crate::syntax::SName { sigils_p: crate::syntax::lexer::chars::after_first_f(&n_p2.sigils_p), path_p: n_p2.path_p.clone(), span_p: n_p2.span_p.clone() };
    let (qk1_o9, _) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p2);
    let callee_p7 = if &qk1_o9 != &::std::option::Option::None { n_p2.clone() } else { plain_p6.clone() };
    let (qk_oa, ignore2_pb) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, &callee_p7);
    let cname_p8 = crate::check::env::sname_key_f(&plain_p6);
    match &qk_oa {
        ::std::option::Option::None => {
            let (ignore3_pc, st2_pd) = crate::check::expr::calls::call_global_f(env_p0, st_p1, &callee_p7, &crate::prelude::Array::new(), span_p5, &crate::prelude::Array::new(), &callee_p7.span_p);
            st2_pd.clone()
        },
        ::std::option::Option::Some(qk_pe) => {
            let clauses_pf = match crate::prelude::get(&env_p0.g_p.fn_at_p, qk_pe) {
                ::std::option::Option::Some(i_ph) => match crate::prelude::index(&env_p0.g_p.defs_p, &i_ph) {
                    ::std::option::Option::Some(d_pi) => match &d_pi.body_p {
                        crate::check::env::DefBody::DbFn(cs_pj) => cs_pj.clone(),
                        _ => crate::prelude::Array::new(),
                    },
                    ::std::option::Option::None => crate::prelude::Array::new(),
                },
                ::std::option::Option::None => crate::prelude::Array::new(),
            };
            let arity_pg = match crate::prelude::index(&clauses_pf, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(c_pk) => crate::prelude::len(&c_pk.params_p),
                ::std::option::Option::None => crate::prelude::Nat::from(0u32),
            };
            if &crate::prelude::len(&clauses_pf) == &crate::prelude::Nat::from(0u32) {
                crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p5, &crate::prelude::Text::from(format!("`<@{}>` calls a function without clauses, which name no parameters for its attributes", &cname_p8)))
            } else {
                {
                    let (slots_pu, st1_pv) = crate::prelude::run_to_end(crate::prelude::fold_job(args_p3.clone(), (crate::prelude::Map::new(), st_p1.clone()), {
                        let clauses_pfx = clauses_pf.clone();
                        let cname_p8x = cname_p8.clone();
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, crate::syntax::Expr>, crate::check::types::St), crate::syntax::Arg)| {
                            let clauses_pfxy = clauses_pfx.clone();
                            let cname_p8xy = cname_p8x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (m_pp, s_pq) = p0;
                                let a_pr = p1;
                                match &a_pr.name_o {
                                    ::std::option::Option::Some(id_ps) => {
                                        let id_psx = id_ps.clone();
                                        crate::prelude::call_then(start_template_slot_o(clauses_pfxy.clone(), id_psx.name_p.clone()), move |template_slot_o_29382: ::std::option::Option<crate::prelude::Nat>| match template_slot_o_29382 {
                                            ::std::option::Option::Some(j_pt) => if crate::check::env::has_key_f(&m_pp, &crate::prelude::Text::from(format!("{}", &j_pt))) {
                                                ::prism_rtl::Turn::Finished((m_pp.clone(), crate::check::types::recording::err_f(&s_pq, &crate::prelude::Text::lit("mismatch"), &a_pr.span_p, &crate::prelude::Text::from(format!("`{}` is given twice", &id_psx.name_p)))))
                                            } else {
                                                ::prism_rtl::Turn::Finished((crate::prelude::insert(&m_pp, &crate::prelude::Text::from(format!("{}", &j_pt)), &a_pr.value_p), s_pq.clone()))
                                            },
                                            ::std::option::Option::None => ::prism_rtl::Turn::Finished((m_pp.clone(), crate::check::types::recording::err_f(&s_pq, &crate::prelude::Text::lit("mismatch"), &a_pr.span_p, &crate::prelude::Text::from(format!("`{}` has no parameter `{}`", &cname_p8xy, &id_psx.name_p))))),
                                        })
                                    },
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished((m_pp.clone(), crate::check::types::recording::err_f(&s_pq, &crate::prelude::Text::lit("mismatch"), &a_pr.span_p, &crate::prelude::Text::lit("a template call names each argument: `name={{value}}`")))),
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, crate::syntax::Expr>, crate::check::types::St), crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, crate::syntax::Expr>, crate::check::types::St)>>>
                    }));
                    let body_ol = match parts_o4 {
                        ::std::option::Option::Some(ps_p10) => ::std::option::Option::Some(crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETemplate(crate::syntax::Template { keyword_p: crate::prelude::Text::lit("InlineText"), lang_p: crate::prelude::Text::lit(""), delims_p: crate::prelude::Text::lit("double"), parts_p: ps_p10.clone(), span_p: span_p5.clone() })), span_p: span_p5.clone() }),
                        ::std::option::Option::None => ::std::option::Option::None,
                    };
                    let last_pm = crate::syntax::lexer::chars::dec_f(&arity_pg);
                    let st2_pn = match &body_ol {
                        ::std::option::Option::Some(ignore4_p11) => if (&arity_pg == &crate::prelude::Nat::from(0u32)) || crate::check::env::has_key_f(&slots_pu, &crate::prelude::Text::from(format!("{}", &last_pm))) {
                            crate::check::types::recording::err_f(&st1_pv, &crate::prelude::Text::lit("mismatch"), span_p5, &crate::prelude::Text::from(format!("`{}` has no parameter left for the call\'s body", &cname_p8)))
                        } else {
                            st1_pv.clone()
                        },
                        ::std::option::Option::None => st1_pv.clone(),
                    };
                    let quiet_po = &crate::prelude::len(&st1_pv.diags_p) > &crate::prelude::len(&st_p1.diags_p);
                    let (positional_p17, st3_p18) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&arity_pg), (crate::prelude::Array::new(), st2_pn.clone()), {
                        let slots_pux = slots_pu.clone();
                        let body_olx = body_ol.clone();
                        let last_pmx = last_pm.clone();
                        let span_p5x = span_p5.clone();
                        let clauses_pfx = clauses_pf.clone();
                        let cname_p8x = cname_p8.clone();
                        let quiet_pox = quiet_po;
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::syntax::Arg>, crate::check::types::St), crate::prelude::Nat)| {
                            let slots_puxy = slots_pux.clone();
                            let body_olxy = body_olx.clone();
                            let last_pmxy = last_pmx.clone();
                            let span_p5xy = span_p5x.clone();
                            let clauses_pfxy = clauses_pfx.clone();
                            let cname_p8xy = cname_p8x.clone();
                            let quiet_poxy = quiet_pox;
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (acc_p12, s_p13) = p0;
                                let j_p14 = p1;
                                match crate::prelude::get(&slots_puxy, &crate::prelude::Text::from(format!("{}", &j_p14))) {
                                    ::std::option::Option::Some(v_p15) => ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p12, &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: v_p15.clone(), span_p: v_p15.span_p.clone() }), s_p13.clone())),
                                    ::std::option::Option::None => match &body_olxy {
                                        ::std::option::Option::Some(b_p16) => if &j_p14 == &last_pmxy {
                                            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p12, &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: b_p16.clone(), span_p: span_p5xy.clone() }), s_p13.clone()))
                                        } else {
                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(TemplateMissing { acc_p0: acc_p12.clone(), st_p1: s_p13.clone(), clauses_p2: clauses_pfxy.clone(), j_p3: j_p14.clone(), cname_p4: cname_p8xy.clone(), span_p5: span_p5xy.clone(), quiet_p6: quiet_poxy }))
                                        },
                                        ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(TemplateMissing { acc_p0: acc_p12.clone(), st_p1: s_p13.clone(), clauses_p2: clauses_pfxy.clone(), j_p3: j_p14.clone(), cname_p4: cname_p8xy.clone(), span_p5: span_p5xy.clone(), quiet_p6: quiet_poxy })),
                                    },
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::syntax::Arg>, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arg>, crate::check::types::St)>>>
                    }));
                    let (t_p19, st4_p1a) = crate::check::expr::calls::call_global_f(env_p0, &st3_p18, &callee_p7, &positional_p17, span_p5, &crate::prelude::Array::new(), &callee_p7.span_p);
                    crate::check::types::unify::unify_f(&st4_p1a, &crate::check::types::t_text_p(), &t_p19, span_p5)
                }
            }
        },
    }
}

/// The step machine of `TemplateCallCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
/// ```
pub struct TemplateCallCheck {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub n_p2: crate::syntax::SName,
    pub args_p3: crate::prelude::Array<crate::syntax::Arg>,
    pub parts_o4: ::std::option::Option<crate::prelude::Array<crate::syntax::TemplatePart>>,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for TemplateCallCheck {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let n_p2 = &self.n_p2;
        let args_p3 = &self.args_p3;
        let parts_o4 = &self.parts_o4;
        let span_p5 = &self.span_p5;
        let plain_p6 = crate::syntax::SName { sigils_p: crate::syntax::lexer::chars::after_first_f(&n_p2.sigils_p), path_p: n_p2.path_p.clone(), span_p: n_p2.span_p.clone() };
        let (qk1_o9, _) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, n_p2);
        let callee_p7 = if &qk1_o9 != &::std::option::Option::None { n_p2.clone() } else { plain_p6.clone() };
        let (qk_oa, ignore2_pb) = crate::check::env::names::resolve_value_f(&env_p0.g_p, &env_p0.home_p, &callee_p7);
        let cname_p8 = crate::check::env::sname_key_f(&plain_p6);
        match &qk_oa {
            ::std::option::Option::None => {
                let env_p0x = env_p0.clone();
                let span_p5x = span_p5.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::calls::start_call_global_f(env_p0x.clone(), st_p1x.clone(), callee_p7.clone(), crate::prelude::Array::new(), span_p5x.clone(), crate::prelude::Array::new(), callee_p7.span_p.clone()), move |call_global_f_28640: (crate::check::types::Ty, crate::check::types::St)| {
                    let (ignore3_pc, st2_pd) = call_global_f_28640;
                    ::prism_rtl::Turn::Finished(st2_pd.clone())
                })
            },
            ::std::option::Option::Some(qk_pe) => {
                let clauses_pf = match crate::prelude::get(&env_p0.g_p.fn_at_p, qk_pe) {
                    ::std::option::Option::Some(i_ph) => match crate::prelude::index(&env_p0.g_p.defs_p, &i_ph) {
                        ::std::option::Option::Some(d_pi) => match &d_pi.body_p {
                            crate::check::env::DefBody::DbFn(cs_pj) => cs_pj.clone(),
                            _ => crate::prelude::Array::new(),
                        },
                        ::std::option::Option::None => crate::prelude::Array::new(),
                    },
                    ::std::option::Option::None => crate::prelude::Array::new(),
                };
                let arity_pg = match crate::prelude::index(&clauses_pf, &crate::prelude::Nat::from(0u32)) {
                    ::std::option::Option::Some(c_pk) => crate::prelude::len(&c_pk.params_p),
                    ::std::option::Option::None => crate::prelude::Nat::from(0u32),
                };
                if &crate::prelude::len(&clauses_pf) == &crate::prelude::Nat::from(0u32) {
                    ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p5, &crate::prelude::Text::from(format!("`<@{}>` calls a function without clauses, which name no parameters for its attributes", &cname_p8))))
                } else {
                    {
                        let parts_o4x = parts_o4.clone();
                        let args_p3x = args_p3.clone();
                        let env_p0x = env_p0.clone();
                        let span_p5x = span_p5.clone();
                        let st_p1x = st_p1.clone();
                        crate::prelude::call_value(crate::prelude::fold_job(args_p3x.clone(), (crate::prelude::Map::new(), st_p1x.clone()), {
                            let clauses_pfx = clauses_pf.clone();
                            let cname_p8x = cname_p8.clone();
                            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, crate::syntax::Expr>, crate::check::types::St), crate::syntax::Arg)| {
                                let clauses_pfxy = clauses_pfx.clone();
                                let cname_p8xy = cname_p8x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (m_pp, s_pq) = p0;
                                    let a_pr = p1;
                                    match &a_pr.name_o {
                                        ::std::option::Option::Some(id_ps) => {
                                            let id_psx = id_ps.clone();
                                            crate::prelude::call_then(start_template_slot_o(clauses_pfxy.clone(), id_psx.name_p.clone()), move |template_slot_o_29382: ::std::option::Option<crate::prelude::Nat>| match template_slot_o_29382 {
                                                ::std::option::Option::Some(j_pt) => if crate::check::env::has_key_f(&m_pp, &crate::prelude::Text::from(format!("{}", &j_pt))) {
                                                    ::prism_rtl::Turn::Finished((m_pp.clone(), crate::check::types::recording::err_f(&s_pq, &crate::prelude::Text::lit("mismatch"), &a_pr.span_p, &crate::prelude::Text::from(format!("`{}` is given twice", &id_psx.name_p)))))
                                                } else {
                                                    ::prism_rtl::Turn::Finished((crate::prelude::insert(&m_pp, &crate::prelude::Text::from(format!("{}", &j_pt)), &a_pr.value_p), s_pq.clone()))
                                                },
                                                ::std::option::Option::None => ::prism_rtl::Turn::Finished((m_pp.clone(), crate::check::types::recording::err_f(&s_pq, &crate::prelude::Text::lit("mismatch"), &a_pr.span_p, &crate::prelude::Text::from(format!("`{}` has no parameter `{}`", &cname_p8xy, &id_psx.name_p))))),
                                            })
                                        },
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((m_pp.clone(), crate::check::types::recording::err_f(&s_pq, &crate::prelude::Text::lit("mismatch"), &a_pr.span_p, &crate::prelude::Text::lit("a template call names each argument: `name={{value}}`")))),
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, crate::syntax::Expr>, crate::check::types::St), crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, crate::syntax::Expr>, crate::check::types::St)>>>
                        }), move |fold_29297: (crate::prelude::Map<crate::prelude::Text, crate::syntax::Expr>, crate::check::types::St)| {
                            let (slots_pu, st1_pv) = fold_29297;
                            let body_ol = match &parts_o4x {
                                ::std::option::Option::Some(ps_p10) => ::std::option::Option::Some(crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETemplate(crate::syntax::Template { keyword_p: crate::prelude::Text::lit("InlineText"), lang_p: crate::prelude::Text::lit(""), delims_p: crate::prelude::Text::lit("double"), parts_p: ps_p10.clone(), span_p: span_p5x.clone() })), span_p: span_p5x.clone() }),
                                ::std::option::Option::None => ::std::option::Option::None,
                            };
                            let last_pm = crate::syntax::lexer::chars::dec_f(&arity_pg);
                            let st2_pn = match &body_ol {
                                ::std::option::Option::Some(ignore4_p11) => if (&arity_pg == &crate::prelude::Nat::from(0u32)) || crate::check::env::has_key_f(&slots_pu, &crate::prelude::Text::from(format!("{}", &last_pm))) {
                                    crate::check::types::recording::err_f(&st1_pv, &crate::prelude::Text::lit("mismatch"), &span_p5x, &crate::prelude::Text::from(format!("`{}` has no parameter left for the call\'s body", &cname_p8)))
                                } else {
                                    st1_pv.clone()
                                },
                                ::std::option::Option::None => st1_pv.clone(),
                            };
                            let quiet_po = &crate::prelude::len(&st1_pv.diags_p) > &crate::prelude::len(&st_p1x.diags_p);
                            crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&arity_pg), (crate::prelude::Array::new(), st2_pn.clone()), {
                                let slots_pux = slots_pu.clone();
                                let body_olx = body_ol.clone();
                                let last_pmx = last_pm.clone();
                                let span_p5xx = span_p5x.clone();
                                let clauses_pfx = clauses_pf.clone();
                                let cname_p8x = cname_p8.clone();
                                let quiet_pox = quiet_po;
                                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::syntax::Arg>, crate::check::types::St), crate::prelude::Nat)| {
                                    let slots_puxy = slots_pux.clone();
                                    let body_olxy = body_olx.clone();
                                    let last_pmxy = last_pmx.clone();
                                    let span_p5xxy = span_p5xx.clone();
                                    let clauses_pfxy = clauses_pfx.clone();
                                    let cname_p8xy = cname_p8x.clone();
                                    let quiet_poxy = quiet_pox;
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (acc_p12, s_p13) = p0;
                                        let j_p14 = p1;
                                        match crate::prelude::get(&slots_puxy, &crate::prelude::Text::from(format!("{}", &j_p14))) {
                                            ::std::option::Option::Some(v_p15) => ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p12, &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: v_p15.clone(), span_p: v_p15.span_p.clone() }), s_p13.clone())),
                                            ::std::option::Option::None => match &body_olxy {
                                                ::std::option::Option::Some(b_p16) => if &j_p14 == &last_pmxy {
                                                    ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p12, &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: b_p16.clone(), span_p: span_p5xxy.clone() }), s_p13.clone()))
                                                } else {
                                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(TemplateMissing { acc_p0: acc_p12.clone(), st_p1: s_p13.clone(), clauses_p2: clauses_pfxy.clone(), j_p3: j_p14.clone(), cname_p4: cname_p8xy.clone(), span_p5: span_p5xxy.clone(), quiet_p6: quiet_poxy }))
                                                },
                                                ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(TemplateMissing { acc_p0: acc_p12.clone(), st_p1: s_p13.clone(), clauses_p2: clauses_pfxy.clone(), j_p3: j_p14.clone(), cname_p4: cname_p8xy.clone(), span_p5: span_p5xxy.clone(), quiet_p6: quiet_poxy })),
                                            },
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::syntax::Arg>, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arg>, crate::check::types::St)>>>
                            }), move |fold_30381: (crate::prelude::Array<crate::syntax::Arg>, crate::check::types::St)| {
                                let (positional_p17, st3_p18) = fold_30381;
                                crate::prelude::call_then(crate::check::expr::calls::start_call_global_f(env_p0x.clone(), st3_p18.clone(), callee_p7.clone(), positional_p17.clone(), span_p5x.clone(), crate::prelude::Array::new(), callee_p7.span_p.clone()), move |call_global_f_30868: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (t_p19, st4_p1a) = call_global_f_30868;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st4_p1a.clone(), expected_p1: crate::check::types::t_text_p(), found_p2: t_p19.clone(), span_p3: span_p5x.clone() }))
                                })
                            })
                        })
                    }
                }
            },
        }
    }
}

/// `Start TemplateCallCheck, x`: what the function value is when passed to `@Run`.
pub fn start_template_call_check_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, n_p2: crate::syntax::SName, args_p3: crate::prelude::Array<crate::syntax::Arg>, parts_o4: ::std::option::Option<crate::prelude::Array<crate::syntax::TemplatePart>>, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(TemplateCallCheck { env_p0, st_p1, n_p2, args_p3, parts_o4, span_p5 })
}

/// ```prism
/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
/// ```
pub fn template_missing_f(acc_p0: &crate::prelude::Array<crate::syntax::Arg>, st_p1: &crate::check::types::St, clauses_p2: &crate::prelude::Array<crate::syntax::decls::FnClause>, j_p3: &crate::prelude::Nat, cname_p4: &crate::prelude::Text, span_p5: &crate::syntax::Range, quiet_p6: &bool) -> (crate::prelude::Array<crate::syntax::Arg>, crate::check::types::St) {
    let pname_p7 = match crate::prelude::index(clauses_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(c_p9) => match crate::prelude::index(&c_p9.params_p, j_p3) {
            ::std::option::Option::Some(p_pa) => crate::check::shrink::locals::param_name_of_f(&p_pa),
            ::std::option::Option::None => crate::prelude::Text::lit(""),
        },
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    };
    let st2_p8 = if *quiet_p6 {
        st_p1.clone()
    } else {
        crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p5, &crate::prelude::Text::from(format!("`<@{}>` needs `{}=`", cname_p4, &pname_p7)))
    };
    (crate::prelude::push(acc_p0, &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p5.clone() }, span_p: span_p5.clone() }), st2_p8.clone())
}

/// The step machine of `TemplateMissing`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
/// ```
pub struct TemplateMissing {
    pub acc_p0: crate::prelude::Array<crate::syntax::Arg>,
    pub st_p1: crate::check::types::St,
    pub clauses_p2: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub j_p3: crate::prelude::Nat,
    pub cname_p4: crate::prelude::Text,
    pub span_p5: crate::syntax::Range,
    pub quiet_p6: bool,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arg>, crate::check::types::St)> for TemplateMissing {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::Arg>, crate::check::types::St)> {
        let acc_p0 = &self.acc_p0;
        let st_p1 = &self.st_p1;
        let clauses_p2 = &self.clauses_p2;
        let j_p3 = &self.j_p3;
        let cname_p4 = &self.cname_p4;
        let span_p5 = &self.span_p5;
        let quiet_p6 = &self.quiet_p6;
        let pname_p7 = match crate::prelude::index(clauses_p2, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::Some(c_p9) => match crate::prelude::index(&c_p9.params_p, j_p3) {
                ::std::option::Option::Some(p_pa) => crate::check::shrink::locals::param_name_of_f(&p_pa),
                ::std::option::Option::None => crate::prelude::Text::lit(""),
            },
            ::std::option::Option::None => crate::prelude::Text::lit(""),
        };
        let st2_p8 = if *quiet_p6 {
            st_p1.clone()
        } else {
            crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p5, &crate::prelude::Text::from(format!("`<@{}>` needs `{}=`", cname_p4, &pname_p7)))
        };
        ::prism_rtl::Turn::Finished((crate::prelude::push(acc_p0, &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p5.clone() }, span_p: span_p5.clone() }), st2_p8.clone()))
    }
}

/// `Start TemplateMissing, x`: what the function value is when passed to `@Run`.
pub fn start_template_missing_f(acc_p0: crate::prelude::Array<crate::syntax::Arg>, st_p1: crate::check::types::St, clauses_p2: crate::prelude::Array<crate::syntax::decls::FnClause>, j_p3: crate::prelude::Nat, cname_p4: crate::prelude::Text, span_p5: crate::syntax::Range, quiet_p6: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arg>, crate::check::types::St)>> {
    ::std::rc::Rc::new(TemplateMissing { acc_p0, st_p1, clauses_p2, j_p3, cname_p4, span_p5, quiet_p6 })
}

/// ```prism
/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
/// ```
pub fn template_slot_o(clauses_p0: &crate::prelude::Array<crate::syntax::decls::FnClause>, name_p1: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Nat> {
    let found_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p0.clone(), crate::prelude::Array::new(), {
        let name_p1x = name_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::syntax::decls::FnClause)| {
            let name_p1xy = name_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p2 = p0;
                let c_p3 = p1;
                crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&c_p3.params_p)), acc_p2.clone(), {
                    let c_p3x = c_p3.clone();
                    let name_p1xyx = name_p1xy.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Nat)| {
                        let c_p3xy = c_p3x.clone();
                        let name_p1xyxy = name_p1xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a2_p4 = p0;
                            let i_p5 = p1;
                            match crate::prelude::index(&c_p3xy.params_p, &i_p5) {
                                ::std::option::Option::Some(p_p6) => if &crate::check::shrink::locals::param_name_of_f(&p_p6) == &name_p1xyxy {
                                    ::prism_rtl::Turn::Finished(crate::check::types::add_nat_f(&a2_p4, &i_p5))
                                } else {
                                    ::prism_rtl::Turn::Finished(a2_p4.clone())
                                },
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(a2_p4.clone()),
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
                }).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    if &crate::prelude::len(&found_p7) == &crate::prelude::Nat::from(1u32) {
        crate::prelude::index(&found_p7, &crate::prelude::Nat::from(0u32))
    } else {
        ::std::option::Option::None
    }
}

/// The step machine of `TemplateSlot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
/// ```
pub struct TemplateSlot {
    pub clauses_p0: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub name_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Nat>> for TemplateSlot {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Nat>> {
        let clauses_p0 = &self.clauses_p0;
        let name_p1 = &self.name_p1;
        let clauses_p0x = clauses_p0.clone();
        let name_p1x = name_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(clauses_p0x.clone(), crate::prelude::Array::new(), {
            let name_p1xx = name_p1x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::syntax::decls::FnClause)| {
                let name_p1xxy = name_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p2 = p0;
                    let c_p3 = p1;
                    crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&c_p3.params_p)), acc_p2.clone(), {
                        let c_p3x = c_p3.clone();
                        let name_p1xxyx = name_p1xxy.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Nat)| {
                            let c_p3xy = c_p3x.clone();
                            let name_p1xxyxy = name_p1xxyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a2_p4 = p0;
                                let i_p5 = p1;
                                match crate::prelude::index(&c_p3xy.params_p, &i_p5) {
                                    ::std::option::Option::Some(p_p6) => if &crate::check::shrink::locals::param_name_of_f(&p_p6) == &name_p1xxyxy {
                                        ::prism_rtl::Turn::Finished(crate::check::types::add_nat_f(&a2_p4, &i_p5))
                                    } else {
                                        ::prism_rtl::Turn::Finished(a2_p4.clone())
                                    },
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(a2_p4.clone()),
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
                    }).cycle()
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
        }), move |fold_31773: crate::prelude::Array<crate::prelude::Nat>| {
            let found_p7 = fold_31773;
            if &crate::prelude::len(&found_p7) == &crate::prelude::Nat::from(1u32) {
                ::prism_rtl::Turn::Finished(crate::prelude::index(&found_p7, &crate::prelude::Nat::from(0u32)))
            } else {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            }
        })
    }
}

/// `Start TemplateSlot, x`: what the function value is when passed to `@Run`.
pub fn start_template_slot_o(clauses_p0: crate::prelude::Array<crate::syntax::decls::FnClause>, name_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Nat>>> {
    ::std::rc::Rc::new(TemplateSlot { clauses_p0, name_p1 })
}
