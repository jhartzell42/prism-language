//! The module `Check.Expr.Lets`, from `target/bootstrap/src/prismc/check/expr/lets.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub fn infer_expr_block(env: &crate::check::expr::Env, st: &crate::check::types::St, b: &crate::syntax::Block) -> (crate::check::types::Ty, crate::check::types::St) {
    if is_widgetish(&b.stmts) {
        crate::check::blocks::infer_widget_block(env, st, b)
    } else {
        {
            let (env2, st2) = bind_group(env, st, &b.stmts);
            match crate::syntax::lexer::chars::last(&b.stmts) {
                Some(s) => match &s.kind {
                    crate::syntax::StmtKind::SExpr(e) => crate::check::expr::infer(&env2, &st2, e),
                    _ => (crate::check::types::t_unit(), st2.clone()),
                },
                None => (crate::check::types::t_unit(), st2.clone()),
            }
        }
    }
}

/// The step machine of `InferExprBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub struct InferExprBlock {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferExprBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        if is_widgetish(&b.stmts) {
            prism_rtl::Turn::More(Rc::new(crate::check::blocks::InferWidgetBlock { env: env.clone(), st: st.clone(), b: b.clone() }))
        } else {
            {
                let b = b.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(start_bind_group(env.clone(), st.clone(), b.stmts.clone()), move |bind_group_1662: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2, st2) = bind_group_1662;
                    match crate::syntax::lexer::chars::last(&b.stmts) {
                        Some(s) => match &s.kind {
                            crate::syntax::StmtKind::SExpr(e) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Infer { env: env2.clone(), st: st2.clone(), e: e.clone() })),
                            _ => prism_rtl::Turn::Finished((crate::check::types::t_unit(), st2.clone())),
                        },
                        None => prism_rtl::Turn::Finished((crate::check::types::t_unit(), st2.clone())),
                    }
                })
            }
        }
    }
}

/// `Start InferExprBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_expr_block(env: crate::check::expr::Env, st: crate::check::types::St, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferExprBlock { env, st, b })
}

/// ```prism
/// IsWidgetish: fn [Stmt] -> Bool
/// ```
pub fn is_widgetish(stmts: &Array<crate::syntax::Stmt>) -> bool {
    fold(stmts, &false, &(|seen: &bool, s: &crate::syntax::Stmt| *seen || builds(s)))
}

/// ```prism
/// Builds: fn Stmt -> Bool
/// ```
pub fn builds(s: &crate::syntax::Stmt) -> bool {
    match &s.kind {
        crate::syntax::StmtKind::SBind(_, _, _) => true,
        crate::syntax::StmtKind::SIgnore(_) => true,
        crate::syntax::StmtKind::SEmit(_) => true,
        crate::syntax::StmtKind::SWidget(_) => true,
        _ => false,
    }
}

/// ```prism
/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub fn bind_group(env: &crate::check::expr::Env, st: &crate::check::types::St, stmts: &Array<crate::syntax::Stmt>) -> (crate::check::expr::Env, crate::check::types::St) {
    let order = crate::check::blocks::group_order(stmts);
    let (env1, st1) = run_to_end(fold_job(order.clone(), (env.clone(), st.clone()), {
        let stmts = stmts.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
            let stmts = stmts.clone();
            entered(once_job(move || {
                let (en, s) = p0;
                let i = p1;
                prism_rtl::Turn::More(Rc::new(PreBind { env: en.clone(), st: s.clone(), s: or(&index(&stmts, &i), &dummy_stmt()) }))
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
    }));
    let st2 = if st1.recording && (&len(stmts) > &Nat::from(1u32)) {
        crate::check::types::recording::note_group(&st1, &stmts_span(stmts), &Text::lit("expr"), &crate::check::blocks::dep_order(stmts))
    } else {
        st1.clone()
    };
    run_to_end(fold_job(order.clone(), (env1.clone(), st2.clone()), {
        let stmts = stmts.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
            let stmts = stmts.clone();
            entered(once_job(move || {
                let (en, s) = p0;
                let i = p1;
                prism_rtl::Turn::More(Rc::new(CheckGroupStmt { env: en.clone(), st: s.clone(), s: or(&index(&stmts, &i), &dummy_stmt()), last: is_last(&stmts, &i) }))
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
    }))
}

/// The step machine of `BindGroup`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub struct BindGroup {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindGroup {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        let env = env.clone();
        let st = st.clone();
        let stmts = stmts.clone();
        call_then(crate::check::blocks::start_group_order(stmts.clone()), move |group_order_2649: Array<Nat>| {
            let order = group_order_2649;
            call_value(fold_job(order.clone(), (env.clone(), st.clone()), {
                let stmts = stmts.clone();
                Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                    let stmts = stmts.clone();
                    entered(once_job(move || {
                        let (en, s) = p0;
                        let i = p1;
                        prism_rtl::Turn::More(Rc::new(PreBind { env: en.clone(), st: s.clone(), s: or(&index(&stmts, &i), &dummy_stmt()) }))
                    }))
                }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }), move |fold_2690: (crate::check::expr::Env, crate::check::types::St)| {
                let (env1, st1) = fold_2690;
                let st2 = if st1.recording && (&len(&stmts) > &Nat::from(1u32)) {
                    crate::check::types::recording::note_group(&st1, &stmts_span(&stmts), &Text::lit("expr"), &crate::check::blocks::dep_order(&stmts))
                } else {
                    st1.clone()
                };
                fold_job(order.clone(), (env1.clone(), st2.clone()), {
                    let stmts = stmts.clone();
                    Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                        let stmts = stmts.clone();
                        entered(once_job(move || {
                            let (en, s) = p0;
                            let i = p1;
                            prism_rtl::Turn::More(Rc::new(CheckGroupStmt { env: en.clone(), st: s.clone(), s: or(&index(&stmts, &i), &dummy_stmt()), last: is_last(&stmts, &i) }))
                        }))
                    }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                }).cycle()
            })
        })
    }
}

/// `Start BindGroup, x`: what the function value is when passed to `@Run`.
pub fn start_bind_group(env: crate::check::expr::Env, st: crate::check::types::St, stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindGroup { env, st, stmts })
}

/// ```prism
/// StmtsSpan: fn [Stmt] -> Range
/// ```
pub fn stmts_span(stmts: &Array<crate::syntax::Stmt>) -> crate::syntax::Range {
    crate::syntax::Range { start: or(&index(stmts, &Nat::from(0u32)), &dummy_stmt()).span.start.clone(), end: or(&crate::syntax::lexer::chars::last(stmts), &dummy_stmt()).span.end.clone() }
}

/// ```prism
/// let dummyStmt
/// ```
pub fn dummy_stmt() -> crate::syntax::Stmt {
    crate::syntax::Stmt { kind: crate::syntax::StmtKind::SExpr(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// IsLast: fn [Stmt], Nat -> Bool
/// ```
pub fn is_last(stmts: &Array<crate::syntax::Stmt>, i: &Nat) -> bool {
    &(i + &Nat::from(1u32)) == &len(stmts)
}

/// ```prism
/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub fn pre_bind(env: &crate::check::expr::Env, st: &crate::check::types::St, s: &crate::syntax::Stmt) -> (crate::check::expr::Env, crate::check::types::St) {
    match &s.kind {
        crate::syntax::StmtKind::SSignature(sg) => {
            let (sc, st2) = crate::check::env::reading::sig_scheme(&crate::check::expr::env_cx(env), st, &sg.ty, &sg.bounds);
            (crate::check::expr::with_local(env, &crate::check::env::def_name_text(&sg.name), &sc), st2.clone())
        },
        crate::syntax::StmtKind::SFn(f) => {
            let name = crate::check::env::def_name_text(&f.name);
            match get(&env.locals, &name) {
                Some(_) => (env.clone(), st.clone()),
                None => {
                    let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                    (crate::check::expr::with_local(env, &name, &crate::check::types::schemes::mono(&v_)), st2.clone())
                },
            }
        },
        crate::syntax::StmtKind::SLet(p_, _, _) => match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => {
                let (v_, st1) = crate::check::types::fresh_var(st, &true, &crate::check::env::sname_key(n));
                let st2 = crate::check::types::recording::at_binder(&st1, &v_, &n.span);
                let (rw, st3) = crate::check::types::recording::fresh_row(&st2, &Array::new());
                (crate::check::expr::with_local(env, &crate::check::env::sname_key(n), &crate::check::types::schemes::mono(&crate::check::types::with_marks(&type_marks(&n.sigils), &v_, &rw))), st3.clone())
            },
            _ => (env.clone(), st.clone()),
        },
        _ => (env.clone(), st.clone()),
    }
}

/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub struct PreBind {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for PreBind {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SSignature(sg) => {
                let env = env.clone();
                let sg = sg.clone();
                let st = st.clone();
                call_then(crate::check::env::reading::start_sig_scheme(crate::check::expr::env_cx(&env), st.clone(), sg.ty.clone(), sg.bounds.clone()), move |sig_scheme_3595: (crate::check::types::Scheme, crate::check::types::St)| {
                    let (sc, st2) = sig_scheme_3595;
                    prism_rtl::Turn::Finished((crate::check::expr::with_local(&env, &crate::check::env::def_name_text(&sg.name), &sc), st2.clone()))
                })
            },
            crate::syntax::StmtKind::SFn(f) => {
                let name = crate::check::env::def_name_text(&f.name);
                match get(&env.locals, &name) {
                    Some(_) => prism_rtl::Turn::Finished((env.clone(), st.clone())),
                    None => {
                        let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                        prism_rtl::Turn::Finished((crate::check::expr::with_local(env, &name, &crate::check::types::schemes::mono(&v_)), st2.clone()))
                    },
                }
            },
            crate::syntax::StmtKind::SLet(p_, _, _) => match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => {
                    let (v_, st1) = crate::check::types::fresh_var(st, &true, &crate::check::env::sname_key(n));
                    let st2 = crate::check::types::recording::at_binder(&st1, &v_, &n.span);
                    let (rw, st3) = crate::check::types::recording::fresh_row(&st2, &Array::new());
                    prism_rtl::Turn::Finished((crate::check::expr::with_local(env, &crate::check::env::sname_key(n), &crate::check::types::schemes::mono(&crate::check::types::with_marks(&type_marks(&n.sigils), &v_, &rw))), st3.clone()))
                },
                _ => prism_rtl::Turn::Finished((env.clone(), st.clone())),
            },
            _ => prism_rtl::Turn::Finished((env.clone(), st.clone())),
        }
    }
}

/// `Start PreBind, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind(env: crate::check::expr::Env, st: crate::check::types::St, s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(PreBind { env, st, s })
}

/// ```prism
/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
/// ```
pub fn check_group_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, s: &crate::syntax::Stmt, last: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    match &s.kind {
        crate::syntax::StmtKind::SLet(p_, ty_opt, e) => check_let(env, st, p_, ty_opt, e, &s.span),
        crate::syntax::StmtKind::SFn(f) => check_local_fn(env, st, f, &s.span),
        crate::syntax::StmtKind::SSignature(_) => (env.clone(), st.clone()),
        crate::syntax::StmtKind::SExpr(e) => if *last {
            (env.clone(), st.clone())
        } else {
            {
                let (t, st2) = crate::check::expr::infer(env, st, e);
                (env.clone(), st2.clone())
            }
        },
        _ => (env.clone(), crate::check::types::recording::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a widget, `given:` or `update` block"))),
    }
}

/// The step machine of `CheckGroupStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
/// ```
pub struct CheckGroupStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub s: crate::syntax::Stmt,
    pub last: bool,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for CheckGroupStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        let last = &self.last;
        match &s.kind {
            crate::syntax::StmtKind::SLet(p_, ty_opt, e) => prism_rtl::Turn::More(Rc::new(CheckLet { env: env.clone(), st: st.clone(), p_: p_.clone(), ty_opt: ty_opt.clone(), e: e.clone(), span: s.span.clone() })),
            crate::syntax::StmtKind::SFn(f) => prism_rtl::Turn::More(Rc::new(CheckLocalFn { env: env.clone(), st: st.clone(), f: f.clone(), span: s.span.clone() })),
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((env.clone(), st.clone())),
            crate::syntax::StmtKind::SExpr(e) => if *last {
                prism_rtl::Turn::Finished((env.clone(), st.clone()))
            } else {
                {
                    let e = e.clone();
                    let env = env.clone();
                    let st = st.clone();
                    call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_4651: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t, st2) = infer_4651;
                        prism_rtl::Turn::Finished((env.clone(), st2.clone()))
                    })
                }
            },
            _ => prism_rtl::Turn::Finished((env.clone(), crate::check::types::recording::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a widget, `given:` or `update` block")))),
        }
    }
}

/// `Start CheckGroupStmt, x`: what the function value is when passed to `@Run`.
pub fn start_check_group_stmt(env: crate::check::expr::Env, st: crate::check::types::St, s: crate::syntax::Stmt, last: bool) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(CheckGroupStmt { env, st, s, last })
}

/// ```prism
/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
/// ```
pub fn check_let(env: &crate::check::expr::Env, st: &crate::check::types::St, p_: &crate::syntax::Pattern_, ty_opt: &Option<crate::syntax::Type>, e: &crate::syntax::Expr, span: &crate::syntax::Range) -> (crate::check::expr::Env, crate::check::types::St) {
    let st0 = crate::check::types::schemes::enter_level(st);
    let (annot_opt, st1) = match ty_opt {
        Some(t) => {
            let (at_, s2) = crate::check::env::reading::conv_type(&crate::check::expr::env_cx(env), &st0, t);
            (Some(at_.clone()), s2.clone())
        },
        None => (None, st0.clone()),
    };
    let (pre, st2) = match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => match get(&env.locals, &crate::check::env::sname_key(n)) {
            Some(sc) => if (&n.sigils == &Text::lit("")) && crate::check::types::is_flex_var(&st1, &sc.ty) {
                {
                    let (v_, s2) = crate::check::types::fresh_var(&st1, &true, &crate::check::env::sname_key(n));
                    (v_.clone(), crate::check::types::recording::at_binder(&s2, &v_, &n.span))
                }
            } else {
                (sc.ty.clone(), st1.clone())
            },
            None => crate::check::types::fresh_var(&st1, &true, &crate::check::env::sname_key(n)),
        },
        _ => crate::check::types::fresh_var(&st1, &false, &Text::lit("")),
    };
    let st3 = match &annot_opt {
        Some(at_) => crate::check::expr::check(env, &st2, e, at_),
        None => crate::check::expr::check(env, &st2, e, &pre),
    };
    let st4 = match &annot_opt {
        Some(at_) => crate::check::types::unify::unify(&st3, &pre, at_, span),
        None => st3.clone(),
    };
    let st5 = crate::check::env::traits::solve_wants(&env.g, &st4, &env.givens, &false);
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => {
            let name = crate::check::env::sname_key(n);
            let t = crate::check::types::recording::zonk(&st5, &pre);
            let (env2, st7a) = crate::check::expr::patterns::bind_name(env, &st5, n, &t);
            let st7 = crate::check::types::schemes::leave_level(&st7a);
            let ahead_fn = {
                let env = env.clone();
                let name = name.clone();
                let pre = pre.clone();
                let t = t.clone();
                let span = span.clone();
                Rc::new(move |p0: crate::check::types::St| {
                    let env = env.clone();
                    let name = name.clone();
                    let pre = pre.clone();
                    let t = t.clone();
                    let span = span.clone();
                    entered(once_job(move || {
                        let s = p0;
                        prism_rtl::Turn::More(Rc::new(AheadUnify { env: env.clone(), st: s.clone(), name: name.clone(), pre: pre.clone(), t: t.clone(), span: span.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            };
            if crate::check::types::schemes::holds_node(&st7, &t) || is_topic_name(&name) {
                (env2.clone(), run_to_end((&ahead_fn)(st7.clone())))
            } else {
                {
                    let lambda = crate::check::expr::is_lambda(e);
                    let (keep, bounds, st8) = wants_above(&st7, &t, &lambda);
                    let (sc, st9) = crate::check::types::schemes::generalize(&st8, &t, &keep, &bounds);
                    (crate::check::expr::with_local(&env2, &name, &sc), run_to_end((&ahead_fn)(crate::check::types::recording::note_gen(&st9, &n.span, &name, &sc))))
                }
            }
        },
        _ => {
            let st6 = crate::check::types::schemes::leave_level(&st5);
            crate::check::expr::patterns::bind_pattern(env, &st6, p_, &crate::check::types::recording::zonk(&st6, &pre), &false)
        },
    }
}

/// The step machine of `CheckLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
/// ```
pub struct CheckLet {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub p_: crate::syntax::Pattern_,
    pub ty_opt: Option<crate::syntax::Type>,
    pub e: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for CheckLet {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let ty_opt = &self.ty_opt;
        let e = &self.e;
        let span = &self.span;
        let st0 = crate::check::types::schemes::enter_level(st);
        let (annot_opt, st1) = match ty_opt {
            Some(t) => {
                let (at_, s2) = crate::check::env::reading::conv_type(&crate::check::expr::env_cx(env), &st0, t);
                (Some(at_.clone()), s2.clone())
            },
            None => (None, st0.clone()),
        };
        let (pre, st2) = match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => match get(&env.locals, &crate::check::env::sname_key(n)) {
                Some(sc) => if (&n.sigils == &Text::lit("")) && crate::check::types::is_flex_var(&st1, &sc.ty) {
                    {
                        let (v_, s2) = crate::check::types::fresh_var(&st1, &true, &crate::check::env::sname_key(n));
                        (v_.clone(), crate::check::types::recording::at_binder(&s2, &v_, &n.span))
                    }
                } else {
                    (sc.ty.clone(), st1.clone())
                },
                None => crate::check::types::fresh_var(&st1, &true, &crate::check::env::sname_key(n)),
            },
            _ => crate::check::types::fresh_var(&st1, &false, &Text::lit("")),
        };
        let st3 = match &annot_opt {
            Some(at_) => crate::check::expr::check(env, &st2, e, at_),
            None => crate::check::expr::check(env, &st2, e, &pre),
        };
        let st4 = match &annot_opt {
            Some(at_) => crate::check::types::unify::unify(&st3, &pre, at_, span),
            None => st3.clone(),
        };
        let e = e.clone();
        let env = env.clone();
        let p_ = p_.clone();
        let span = span.clone();
        call_then(crate::check::env::traits::start_solve_wants(env.g.clone(), st4.clone(), env.givens.clone(), false), move |solve_wants_6162: crate::check::types::St| {
            let st5 = solve_wants_6162;
            match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => {
                    let name = crate::check::env::sname_key(n);
                    let n = n.clone();
                    call_then(crate::check::types::recording::start_zonk(st5.clone(), pre.clone()), move |zonk_6453: crate::check::types::Ty| {
                        let t = zonk_6453;
                        call_then(crate::check::expr::patterns::start_bind_name(env.clone(), st5.clone(), n.clone(), t.clone()), move |bind_name_6500: (crate::check::expr::Env, crate::check::types::St)| {
                            let (env2, st7a) = bind_name_6500;
                            let st7 = crate::check::types::schemes::leave_level(&st7a);
                            let ahead_fn = {
                                let env = env.clone();
                                let name = name.clone();
                                let pre = pre.clone();
                                let t = t.clone();
                                let span = span.clone();
                                Rc::new(move |p0: crate::check::types::St| {
                                    let env = env.clone();
                                    let name = name.clone();
                                    let pre = pre.clone();
                                    let t = t.clone();
                                    let span = span.clone();
                                    entered(once_job(move || {
                                        let s = p0;
                                        prism_rtl::Turn::More(Rc::new(AheadUnify { env: env.clone(), st: s.clone(), name: name.clone(), pre: pre.clone(), t: t.clone(), span: span.clone() }))
                                    }))
                                }) as Rc<dyn Fn(crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                            };
                            call_then(crate::check::types::schemes::start_holds_node(st7.clone(), t.clone()), move |holds_node_6773: bool| if holds_node_6773 || is_topic_name(&name) {
                                call_value((&ahead_fn)(st7.clone()), move |ahead_6823: crate::check::types::St| prism_rtl::Turn::Finished((env2.clone(), ahead_6823)))
                            } else {
                                {
                                    let lambda = crate::check::expr::is_lambda(&e);
                                    call_then(start_wants_above(st7.clone(), t.clone(), lambda), move |wants_above_6938: (Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)| {
                                        let (keep, bounds, st8) = wants_above_6938;
                                        call_then(crate::check::types::schemes::start_generalize(st8.clone(), t.clone(), keep.clone(), bounds.clone()), move |generalize_6998: (crate::check::types::Scheme, crate::check::types::St)| {
                                            let (sc, st9) = generalize_6998;
                                            call_value((&ahead_fn)(crate::check::types::recording::note_gen(&st9, &n.span, &name, &sc)), move |ahead_7077: crate::check::types::St| prism_rtl::Turn::Finished((crate::check::expr::with_local(&env2, &name, &sc), ahead_7077)))
                                        })
                                    })
                                }
                            })
                        })
                    })
                },
                _ => {
                    let st6 = crate::check::types::schemes::leave_level(&st5);
                    call_then(crate::check::types::recording::start_zonk(st6.clone(), pre.clone()), move |zonk_7212: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(crate::check::expr::patterns::BindPattern { env: env.clone(), st: st6.clone(), p_: p_.clone(), t: zonk_7212, refutable: false })))
                },
            }
        })
    }
}

/// `Start CheckLet, x`: what the function value is when passed to `@Run`.
pub fn start_check_let(env: crate::check::expr::Env, st: crate::check::types::St, p_: crate::syntax::Pattern_, ty_opt: Option<crate::syntax::Type>, e: crate::syntax::Expr, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(CheckLet { env, st, p_, ty_opt, e, span })
}

/// ```prism
/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
/// ```
pub fn ahead_unify(env: &crate::check::expr::Env, st: &crate::check::types::St, name: &Text, pre: &crate::check::types::Ty, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> crate::check::types::St {
    match get(&env.locals, name) {
        Some(sc0) => if &sc0.ty != pre {
            crate::check::types::unify::unify(st, &sc0.ty, t, span)
        } else {
            st.clone()
        },
        None => st.clone(),
    }
}

/// The step machine of `AheadUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
/// ```
pub struct AheadUnify {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub name: Text,
    pub pre: crate::check::types::Ty,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for AheadUnify {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let name = &self.name;
        let pre = &self.pre;
        let t = &self.t;
        let span = &self.span;
        match get(&env.locals, name) {
            Some(sc0) => if &sc0.ty != pre {
                prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st.clone(), expected: sc0.ty.clone(), found: t.clone(), span: span.clone() }))
            } else {
                prism_rtl::Turn::Finished(st.clone())
            },
            None => prism_rtl::Turn::Finished(st.clone()),
        }
    }
}

/// `Start AheadUnify, x`: what the function value is when passed to `@Run`.
pub fn start_ahead_unify(env: crate::check::expr::Env, st: crate::check::types::St, name: Text, pre: crate::check::types::Ty, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(AheadUnify { env, st, name, pre, t, span })
}

/// ```prism
/// TypeMarks: fn Text -> Text
/// ```
pub fn type_marks(marks: &Text) -> Text {
    if crate::syntax::lexer::chars::has_prefix(marks, &Text::lit("&")) {
        crate::syntax::lexer::chars::after_first(marks)
    } else {
        marks.clone()
    }
}

/// ```prism
/// RefMark: fn Text -> Text
/// ```
pub fn ref_mark(marks: &Text) -> Text {
    if crate::syntax::lexer::chars::has_prefix(marks, &Text::lit("&")) {
        Text::lit("&")
    } else {
        Text::lit("")
    }
}

/// ```prism
/// Unpend: fn Env -> Env
/// ```
pub fn unpend(env: &crate::check::expr::Env) -> crate::check::expr::Env {
    let mut this: crate::check::expr::Env = env.clone();
    this.pending = Array::new();
    this
}

/// ```prism
/// IsTopicName: fn Text -> Bool
/// ```
pub fn is_topic_name(n: &Text) -> bool {
    (n == &Text::lit("_")) || (&crate::syntax::lexer::chars::drop_prefix(n, &crate::check::types::unify::marks_of(n)) == &Text::lit("_"))
}

/// ```prism
/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
/// ```
pub fn wants_above(st: &crate::check::types::St, t: &crate::check::types::Ty, lambda: &bool) -> (Array<Nat>, Array<(Nat, Text)>, crate::check::types::St) {
    let vs = filter(&crate::check::types::recording::free_vars(st, t), &(|v_: &Nat| &crate::check::types::recording::info_of(st, v_).level > &st.level));
    let mine = run_to_end(filter_job(st.wants.clone(), {
        let st = st.clone();
        let vs = vs.clone();
        Rc::new(move |p0: crate::check::types::Want| {
            let st = st.clone();
            let vs = vs.clone();
            entered(once_job(move || {
                let w = p0;
                call_then(crate::check::types::recording::start_walk(st.clone(), w.ty.clone()), move |walk_8313: crate::check::types::Ty| match walk_8313 {
                    crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(crate::check::types::has_nat(&vs, &n)),
                    _ => prism_rtl::Turn::Finished(false),
                })
            }))
        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let others = filter(&st.wants, &(|w: &crate::check::types::Want| !crate::check::types::has_text(&each(&mine, &(|m: &crate::check::types::Want| show_text(m))), &show_text(w))));
    let constrained = run_to_end(fold_job(mine.clone(), Array::new(), {
        let st = st.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Want)| {
            let st = st.clone();
            entered(once_job(move || {
                let acc = p0;
                let w = p1;
                call_then(crate::check::types::recording::start_walk(st.clone(), w.ty.clone()), move |walk_8527: crate::check::types::Ty| match walk_8527 {
                    crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(crate::check::types::add_nat(&acc, &n)),
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                })
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    if *lambda {
        {
            let bounds = run_to_end(fold_job(mine.clone(), Array::new(), {
                let st = st.clone();
                Rc::new(move |(p0, p1): (Array<(Nat, Text)>, crate::check::types::Want)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let w = p1;
                        call_then(crate::check::types::recording::start_walk(st.clone(), w.ty.clone()), move |walk_8666: crate::check::types::Ty| match walk_8666 {
                            crate::check::types::Ty::TyFlex(n) => if crate::syntax::lexer::chars::has_prefix(&w.cls, &Text::lit("Range ")) {
                                prism_rtl::Turn::Finished(acc.clone())
                            } else {
                                prism_rtl::Turn::Finished(push(&acc, &(n.clone(), w.cls.clone())))
                            },
                            _ => prism_rtl::Turn::Finished(acc.clone()),
                        })
                    }))
                }) as Rc<dyn Fn((Array<(Nat, Text)>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<(Nat, Text)>>>>
            }));
            let st1 = fold(&mine, st, &(|s: &crate::check::types::St, w: &crate::check::types::Want| crate::check::types::recording::note_choice(&crate::check::types::recording::note_impl(s, &w.file, &w.span, &w.cls, &w.ty, &Text::lit("quantified")), &w.file, &w.span, &w.cls, &Text::lit("any"))));
            let st2 = {
                let mut this: crate::check::types::St = st1.clone();
                this.wants = others.clone();
                this
            };
            (Array::new(), bounds.clone(), st2.clone())
        }
    } else {
        {
            let st2 = crate::check::types::unify::lower_levels(st, &constrained, &st.level);
            (constrained.clone(), Array::new(), st2.clone())
        }
    }
}

/// The step machine of `WantsAbove`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
/// ```
pub struct WantsAbove {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub lambda: bool,
}

impl prism_rtl::Job<(Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)> for WantsAbove {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)> {
        let st = &self.st;
        let t = &self.t;
        let lambda = &self.lambda;
        let lambda = *lambda;
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_free_vars(st.clone(), t.clone()), move |free_vars_8216: Array<Nat>| {
            let vs = filter(&free_vars_8216, &(|v_: &Nat| &crate::check::types::recording::info_of(&st, v_).level > &st.level));
            call_value(filter_job(st.wants.clone(), {
                let st = st.clone();
                let vs = vs.clone();
                Rc::new(move |p0: crate::check::types::Want| {
                    let st = st.clone();
                    let vs = vs.clone();
                    entered(once_job(move || {
                        let w = p0;
                        call_then(crate::check::types::recording::start_walk(st.clone(), w.ty.clone()), move |walk_8313: crate::check::types::Ty| match walk_8313 {
                            crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(crate::check::types::has_nat(&vs, &n)),
                            _ => prism_rtl::Turn::Finished(false),
                        })
                    }))
                }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |filter_8285: Array<crate::check::types::Want>| {
                let mine = filter_8285;
                let others = filter(&st.wants, &(|w: &crate::check::types::Want| !crate::check::types::has_text(&each(&mine, &(|m: &crate::check::types::Want| show_text(m))), &show_text(w))));
                call_value(fold_job(mine.clone(), Array::new(), {
                    let st = st.clone();
                    Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Want)| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let w = p1;
                            call_then(crate::check::types::recording::start_walk(st.clone(), w.ty.clone()), move |walk_8527: crate::check::types::Ty| match walk_8527 {
                                crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(crate::check::types::add_nat(&acc, &n)),
                                _ => prism_rtl::Turn::Finished(acc.clone()),
                            })
                        }))
                    }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }), move |fold_8494: Array<Nat>| {
                    let constrained = fold_8494;
                    if lambda {
                        call_value(fold_job(mine.clone(), Array::new(), {
                            let st = st.clone();
                            Rc::new(move |(p0, p1): (Array<(Nat, Text)>, crate::check::types::Want)| {
                                let st = st.clone();
                                entered(once_job(move || {
                                    let acc = p0;
                                    let w = p1;
                                    call_then(crate::check::types::recording::start_walk(st.clone(), w.ty.clone()), move |walk_8666: crate::check::types::Ty| match walk_8666 {
                                        crate::check::types::Ty::TyFlex(n) => if crate::syntax::lexer::chars::has_prefix(&w.cls, &Text::lit("Range ")) {
                                            prism_rtl::Turn::Finished(acc.clone())
                                        } else {
                                            prism_rtl::Turn::Finished(push(&acc, &(n.clone(), w.cls.clone())))
                                        },
                                        _ => prism_rtl::Turn::Finished(acc.clone()),
                                    })
                                }))
                            }) as Rc<dyn Fn((Array<(Nat, Text)>, crate::check::types::Want)) -> Rc<dyn prism_rtl::Job<Array<(Nat, Text)>>>>
                        }), move |fold_8633: Array<(Nat, Text)>| {
                            let bounds = fold_8633;
                            let st1 = fold(&mine, &st, &(|s: &crate::check::types::St, w: &crate::check::types::Want| crate::check::types::recording::note_choice(&crate::check::types::recording::note_impl(s, &w.file, &w.span, &w.cls, &w.ty, &Text::lit("quantified")), &w.file, &w.span, &w.cls, &Text::lit("any"))));
                            let st2 = {
                                let mut this: crate::check::types::St = st1.clone();
                                this.wants = others.clone();
                                this
                            };
                            prism_rtl::Turn::Finished((Array::new(), bounds.clone(), st2.clone()))
                        })
                    } else {
                        {
                            let st2 = crate::check::types::unify::lower_levels(&st, &constrained, &st.level);
                            prism_rtl::Turn::Finished((constrained.clone(), Array::new(), st2.clone()))
                        }
                    }
                })
            })
        })
    }
}

/// `Start WantsAbove, x`: what the function value is when passed to `@Run`.
pub fn start_wants_above(st: crate::check::types::St, t: crate::check::types::Ty, lambda: bool) -> Rc<dyn prism_rtl::Job<(Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)>> {
    Rc::new(WantsAbove { st, t, lambda })
}

/// ```prism
/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
/// ```
pub fn check_local_fn(env: &crate::check::expr::Env, st: &crate::check::types::St, f: &crate::syntax::decls::FnClause, span: &crate::syntax::Range) -> (crate::check::expr::Env, crate::check::types::St) {
    let name = crate::check::env::def_name_text(&f.name);
    match get(&env.locals, &name) {
        Some(sc) => if ((&len(&sc.qs) > &Nat::from(0u32)) || (&len(&sc.cqs) > &Nat::from(0u32))) || !crate::check::types::is_flex_var(st, &sc.ty) {
            {
                let st2 = check_clauses(env, st, &name, &Array::from(vec![f.clone()]), &sc, span);
                (env.clone(), st2.clone())
            }
        } else {
            {
                let st0 = crate::check::types::schemes::enter_level(st);
                let (lt, st1) = clause_lambda(env, &st0, f);
                let st2 = crate::check::types::unify::unify(&st1, &sc.ty, &lt, span);
                let st3 = crate::check::env::traits::solve_wants(&env.g, &st2, &env.givens, &false);
                let st4 = crate::check::types::schemes::leave_level(&st3);
                let t = crate::check::types::recording::zonk(&st4, &sc.ty);
                if crate::check::types::schemes::holds_node(&st4, &t) {
                    (env.clone(), st4.clone())
                } else {
                    {
                        let (keep, bounds, st5) = wants_above(&st4, &t, &true);
                        let (sc2, st6) = crate::check::types::schemes::generalize(&st5, &t, &keep, &bounds);
                        (crate::check::expr::with_local(env, &name, &sc2), st6.clone())
                    }
                }
            }
        },
        None => (env.clone(), st.clone()),
    }
}

/// The step machine of `CheckLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
/// ```
pub struct CheckLocalFn {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub f: crate::syntax::decls::FnClause,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for CheckLocalFn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let f = &self.f;
        let span = &self.span;
        let name = crate::check::env::def_name_text(&f.name);
        match get(&env.locals, &name) {
            Some(sc) => if ((&len(&sc.qs) > &Nat::from(0u32)) || (&len(&sc.cqs) > &Nat::from(0u32))) || !crate::check::types::is_flex_var(st, &sc.ty) {
                {
                    let env = env.clone();
                    let f = f.clone();
                    let span = span.clone();
                    let st = st.clone();
                    call_then(start_check_clauses(env.clone(), st.clone(), name.clone(), Array::from(vec![f.clone()]), sc.clone(), span.clone()), move |check_clauses_9554: crate::check::types::St| {
                        let st2 = check_clauses_9554;
                        prism_rtl::Turn::Finished((env.clone(), st2.clone()))
                    })
                }
            } else {
                {
                    let st0 = crate::check::types::schemes::enter_level(st);
                    let env = env.clone();
                    let f = f.clone();
                    let span = span.clone();
                    call_then(start_clause_lambda(env.clone(), st0.clone(), f.clone()), move |clause_lambda_9719: (crate::check::types::Ty, crate::check::types::St)| {
                        let (lt, st1) = clause_lambda_9719;
                        call_then(crate::check::types::unify::start_unify(st1.clone(), sc.ty.clone(), lt.clone(), span.clone()), move |unify_9770: crate::check::types::St| {
                            let st2 = unify_9770;
                            call_then(crate::check::env::traits::start_solve_wants(env.g.clone(), st2.clone(), env.givens.clone(), false), move |solve_wants_9823: crate::check::types::St| {
                                let st3 = solve_wants_9823;
                                let st4 = crate::check::types::schemes::leave_level(&st3);
                                call_then(crate::check::types::recording::start_zonk(st4.clone(), sc.ty.clone()), move |zonk_9929: crate::check::types::Ty| {
                                    let t = zonk_9929;
                                    call_then(crate::check::types::schemes::start_holds_node(st4.clone(), t.clone()), move |holds_node_9964: bool| if holds_node_9964 {
                                        prism_rtl::Turn::Finished((env.clone(), st4.clone()))
                                    } else {
                                        call_then(start_wants_above(st4.clone(), t.clone(), true), move |wants_above_10065: (Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)| {
                                            let (keep, bounds, st5) = wants_above_10065;
                                            call_then(crate::check::types::schemes::start_generalize(st5.clone(), t.clone(), keep.clone(), bounds.clone()), move |generalize_10128: (crate::check::types::Scheme, crate::check::types::St)| {
                                                let (sc2, st6) = generalize_10128;
                                                prism_rtl::Turn::Finished((crate::check::expr::with_local(&env, &name, &sc2), st6.clone()))
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    })
                }
            },
            None => prism_rtl::Turn::Finished((env.clone(), st.clone())),
        }
    }
}

/// `Start CheckLocalFn, x`: what the function value is when passed to `@Run`.
pub fn start_check_local_fn(env: crate::check::expr::Env, st: crate::check::types::St, f: crate::syntax::decls::FnClause, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(CheckLocalFn { env, st, f, span })
}

/// ```prism
/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
/// ```
pub fn clause_lambda(env: &crate::check::expr::Env, st: &crate::check::types::St, f: &crate::syntax::decls::FnClause) -> (crate::check::types::Ty, crate::check::types::St) {
    let body = match &f.body {
        crate::syntax::decls::FnBody::BodyExpr(e) => crate::syntax::LambdaBody::LbExpr(Rc::new(e.clone())),
        crate::syntax::decls::FnBody::BodyBlock(b) => crate::syntax::LambdaBody::LbBlock(b.clone()),
    };
    crate::check::expr::calls::infer_lambda(env, st, &crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(Some(f.params.clone()), Rc::new(body.clone()))), span: f.span.clone() }, &None)
}

/// The step machine of `ClauseLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
/// ```
pub struct ClauseLambda {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub f: crate::syntax::decls::FnClause,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for ClauseLambda {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let f = &self.f;
        let body = match &f.body {
            crate::syntax::decls::FnBody::BodyExpr(e) => crate::syntax::LambdaBody::LbExpr(Rc::new(e.clone())),
            crate::syntax::decls::FnBody::BodyBlock(b) => crate::syntax::LambdaBody::LbBlock(b.clone()),
        };
        prism_rtl::Turn::More(Rc::new(crate::check::expr::calls::InferLambda { env: env.clone(), st: st.clone(), e: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(Some(f.params.clone()), Rc::new(body.clone()))), span: f.span.clone() }, expected_opt: None }))
    }
}

/// `Start ClauseLambda, x`: what the function value is when passed to `@Run`.
pub fn start_clause_lambda(env: crate::check::expr::Env, st: crate::check::types::St, f: crate::syntax::decls::FnClause) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(ClauseLambda { env, st, f })
}

/// ```prism
/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
/// ```
pub fn check_clauses(env: &crate::check::expr::Env, st: &crate::check::types::St, name: &Text, clauses: &Array<crate::syntax::decls::FnClause>, sc: &crate::check::types::Scheme, span: &crate::syntax::Range) -> crate::check::types::St {
    let t = crate::check::types::schemes::skolemize(sc);
    let givens = append(&env.givens, &sc.bounds);
    let env2 = {
        let mut this: crate::check::expr::Env = env.clone();
        this.givens = givens.clone();
        this.mark = crate::syntax::lexer::chars::head(&crate::check::types::unify::marks_of(name));
        this.def_name = name.clone();
        this
    };
    match &t {
        crate::check::types::Ty::TyFn(col, params, res) => {
            let outer_color = st.color.clone();
            let outer_flex = st.color_flex.clone();
            let st0 = {
                let mut this: crate::check::types::St = st.clone();
                this.color = crate::check::types::Col::CBound;
                this.color_why = Text::lit("");
                this.color_flex = Array::new();
                this.col_up = fold(&sc.cjoins, &this.col_up, &(|m: &Map<Text, Text>, (lo, hi): &(Text, Text)| insert(m, lo, hi)));
                this
            };
            let st1 = run_to_end(fold_job(clauses.clone(), st0.clone(), {
                let env2 = env2.clone();
                let params = params.clone();
                let res = (**res).clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                    let env2 = env2.clone();
                    let params = params.clone();
                    let res = res.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let c = p1;
                        prism_rtl::Turn::More(Rc::new(CheckClause { env: env2.clone(), st: s.clone(), c: c.clone(), params: params.clone(), res: res.clone() }))
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }));
            let st1b = crate::check::types::colors::settle_body(&crate::check::env::traits::solve_wants(&env.g, &st1, &givens, &false), col, name);
            let st2 = crate::check::passes::clause_coverage(&env2, &st1b, clauses, params, span);
            let st3 = if crate::check::types::colors::col_leq(&st2.color, col) {
                st2.clone()
            } else {
                crate::check::types::recording::err_fix(&st2, &Text::lit("calls-unbounded"), span, &Text::from(format!("{} `{}` calls {} `{}`", &crate::check::types::colors::col_word(col), name, &crate::check::types::colors::col_word(&st2.color), &st2.color_why)), &Text::from(format!("mark `{}` `unbounded fn`, or run the call through `@Run`", name)))
            };
            let st4 = crate::check::types::recording::note_fn(&st3, span, name, col, &st2.color);
            {
                let mut this: crate::check::types::St = st4.clone();
                this.color = outer_color.clone();
                this.color_flex = outer_flex.clone();
                this
            }
        },
        other => {
            let st1 = run_to_end(fold_job(clauses.clone(), st.clone(), {
                let env2 = env2.clone();
                let other = other.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                    let env2 = env2.clone();
                    let other = other.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let c = p1;
                        prism_rtl::Turn::More(Rc::new(CheckClause { env: env2.clone(), st: s.clone(), c: c.clone(), params: Array::new(), res: other.clone() }))
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }));
            st1.clone()
        },
    }
}

/// The step machine of `CheckClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
/// ```
pub struct CheckClauses {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub name: Text,
    pub clauses: Array<crate::syntax::decls::FnClause>,
    pub sc: crate::check::types::Scheme,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for CheckClauses {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let name = &self.name;
        let clauses = &self.clauses;
        let sc = &self.sc;
        let span = &self.span;
        let clauses = clauses.clone();
        let env = env.clone();
        let name = name.clone();
        let sc = sc.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::types::schemes::start_skolemize(sc.clone()), move |skolemize_11096: crate::check::types::Ty| {
            let t = skolemize_11096;
            let givens = append(&env.givens, &sc.bounds);
            let env2 = {
                let mut this: crate::check::expr::Env = env.clone();
                this.givens = givens.clone();
                this.mark = crate::syntax::lexer::chars::head(&crate::check::types::unify::marks_of(&name));
                this.def_name = name.clone();
                this
            };
            match &t {
                crate::check::types::Ty::TyFn(col, params, res) => {
                    let outer_color = st.color.clone();
                    let outer_flex = st.color_flex.clone();
                    let st0 = {
                        let mut this: crate::check::types::St = st.clone();
                        this.color = crate::check::types::Col::CBound;
                        this.color_why = Text::lit("");
                        this.color_flex = Array::new();
                        this.col_up = fold(&sc.cjoins, &this.col_up, &(|m: &Map<Text, Text>, (lo, hi): &(Text, Text)| insert(m, lo, hi)));
                        this
                    };
                    let col = col.clone();
                    let params = params.clone();
                    let res = (**res).clone();
                    call_value(fold_job(clauses.clone(), st0.clone(), {
                        let env2 = env2.clone();
                        let params = params.clone();
                        let res = res.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                            let env2 = env2.clone();
                            let params = params.clone();
                            let res = res.clone();
                            entered(once_job(move || {
                                let s = p0;
                                let c = p1;
                                prism_rtl::Turn::More(Rc::new(CheckClause { env: env2.clone(), st: s.clone(), c: c.clone(), params: params.clone(), res: res.clone() }))
                            }))
                        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_11648: crate::check::types::St| {
                        let st1 = fold_11648;
                        call_then(crate::check::env::traits::start_solve_wants(env.g.clone(), st1.clone(), givens.clone(), false), move |solve_wants_11746: crate::check::types::St| call_then(crate::check::types::colors::start_settle_body(solve_wants_11746, col.clone(), name.clone()), move |settle_body_11734: crate::check::types::St| {
                            let st1b = settle_body_11734;
                            call_then(crate::check::passes::start_clause_coverage(env2.clone(), st1b.clone(), clauses.clone(), params.clone(), span.clone()), move |clause_coverage_11817: crate::check::types::St| {
                                let st2 = clause_coverage_11817;
                                let st3 = if crate::check::types::colors::col_leq(&st2.color, &col) {
                                    st2.clone()
                                } else {
                                    crate::check::types::recording::err_fix(&st2, &Text::lit("calls-unbounded"), &span, &Text::from(format!("{} `{}` calls {} `{}`", &crate::check::types::colors::col_word(&col), &name, &crate::check::types::colors::col_word(&st2.color), &st2.color_why)), &Text::from(format!("mark `{}` `unbounded fn`, or run the call through `@Run`", &name)))
                                };
                                let st4 = crate::check::types::recording::note_fn(&st3, &span, &name, &col, &st2.color);
                                prism_rtl::Turn::Finished({
                                    let mut this: crate::check::types::St = st4.clone();
                                    this.color = outer_color.clone();
                                    this.color_flex = outer_flex.clone();
                                    this
                                })
                            })
                        }))
                    })
                },
                other => {
                    let other = other.clone();
                    call_value(fold_job(clauses.clone(), st.clone(), {
                        let env2 = env2.clone();
                        let other = other.clone();
                        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::FnClause)| {
                            let env2 = env2.clone();
                            let other = other.clone();
                            entered(once_job(move || {
                                let s = p0;
                                let c = p1;
                                prism_rtl::Turn::More(Rc::new(CheckClause { env: env2.clone(), st: s.clone(), c: c.clone(), params: Array::new(), res: other.clone() }))
                            }))
                        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                    }), move |fold_12312: crate::check::types::St| {
                        let st1 = fold_12312;
                        prism_rtl::Turn::Finished(st1.clone())
                    })
                },
            }
        })
    }
}

/// `Start CheckClauses, x`: what the function value is when passed to `@Run`.
pub fn start_check_clauses(env: crate::check::expr::Env, st: crate::check::types::St, name: Text, clauses: Array<crate::syntax::decls::FnClause>, sc: crate::check::types::Scheme, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckClauses { env, st, name, clauses, sc, span })
}

/// ```prism
/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
/// ```
pub fn check_clause(env: &crate::check::expr::Env, st: &crate::check::types::St, c: &crate::syntax::decls::FnClause, params: &Array<crate::check::types::Ty>, res: &crate::check::types::Ty) -> crate::check::types::St {
    if &len(&c.params) != &len(params) {
        crate::check::types::recording::err(st, &Text::lit("mismatch"), &c.span, &Text::from(format!("this clause takes {} parameter{}; the signature has {}", &crate::check::errors::count_word(&len(&c.params)), &(if &len(&c.params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(params)))))
    } else {
        {
            let (env2, st1) = run_to_end(fold_job(crate::check::errors::range0(&len(params)), (env.clone(), st.clone()), {
                let c = c.clone();
                let params = params.clone();
                Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                    let c = c.clone();
                    let params = params.clone();
                    entered(once_job(move || {
                        let (en, s) = p0;
                        let i = p1;
                        prism_rtl::Turn::More(Rc::new(crate::check::expr::patterns::BindPattern { env: en.clone(), st: s.clone(), p_: or(&index(&c.params, &i), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: c.span.clone() }), t: or(&index(&params, &i), &crate::check::types::Ty::TyErr), refutable: true }))
                    }))
                }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
            }));
            check_body(&env2, &st1, &c.body, res)
        }
    }
}

/// The step machine of `CheckClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
/// ```
pub struct CheckClause {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub c: crate::syntax::decls::FnClause,
    pub params: Array<crate::check::types::Ty>,
    pub res: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for CheckClause {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let params = &self.params;
        let res = &self.res;
        if &len(&c.params) != &len(params) {
            prism_rtl::Turn::Finished(crate::check::types::recording::err(st, &Text::lit("mismatch"), &c.span, &Text::from(format!("this clause takes {} parameter{}; the signature has {}", &crate::check::errors::count_word(&len(&c.params)), &(if &len(&c.params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check::errors::count_word(&len(params))))))
        } else {
            {
                let c = c.clone();
                let env = env.clone();
                let params = params.clone();
                let res = res.clone();
                let st = st.clone();
                call_value(fold_job(crate::check::errors::range0(&len(&params)), (env.clone(), st.clone()), {
                    let c = c.clone();
                    let params = params.clone();
                    Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                        let c = c.clone();
                        let params = params.clone();
                        entered(once_job(move || {
                            let (en, s) = p0;
                            let i = p1;
                            prism_rtl::Turn::More(Rc::new(crate::check::expr::patterns::BindPattern { env: en.clone(), st: s.clone(), p_: or(&index(&c.params, &i), &crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: c.span.clone() }), t: or(&index(&params, &i), &crate::check::types::Ty::TyErr), refutable: true }))
                        }))
                    }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
                }), move |fold_12743: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2, st1) = fold_12743;
                    prism_rtl::Turn::More(Rc::new(CheckBody { env: env2.clone(), st: st1.clone(), body: c.body.clone(), res: res.clone() }))
                })
            }
        }
    }
}

/// `Start CheckClause, x`: what the function value is when passed to `@Run`.
pub fn start_check_clause(env: crate::check::expr::Env, st: crate::check::types::St, c: crate::syntax::decls::FnClause, params: Array<crate::check::types::Ty>, res: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckClause { env, st, c, params, res })
}

/// ```prism
/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
/// ```
pub fn check_body(env: &crate::check::expr::Env, st: &crate::check::types::St, body: &crate::syntax::decls::FnBody, res: &crate::check::types::Ty) -> crate::check::types::St {
    match body {
        crate::syntax::decls::FnBody::BodyExpr(e) => crate::check::expr::check(env, st, e, res),
        crate::syntax::decls::FnBody::BodyBlock(b) => if &env.mark == &Text::lit("@") {
            match crate::check::types::recording::walk(st, res) {
                crate::check::types::Ty::TyAt(inner, rw) => {
                    let env2 = {
                        let mut this: crate::check::expr::Env = env.clone();
                        this.scope = rw;
                        this
                    };
                    let (t, st2) = crate::check::blocks::infer_widget_block(&env2, st, b);
                    crate::check::types::unify::unify(&st2, &*inner, &t, &b.span)
                },
                other => crate::check::types::recording::err(st, &Text::lit("mismatch"), &b.span, &Text::from(format!("a widget block builds a blueprint; the signature says `{}`", &crate::check::types::show_ty(st, &other)))),
            }
        } else {
            if (&env.mark == &Text::lit("?")) || (&env.mark == &Text::lit("~")) {
                {
                    let (t, st2) = crate::check::blocks::structure::infer_given_block(env, st, b, &env.mark);
                    crate::check::types::unify::unify(&st2, res, &t, &b.span)
                }
            } else {
                {
                    let (t, st2) = infer_expr_block(env, st, b);
                    crate::check::types::unify::unify(&st2, res, &t, &b.span)
                }
            }
        },
    }
}

/// The step machine of `CheckBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
/// ```
pub struct CheckBody {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub body: crate::syntax::decls::FnBody,
    pub res: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::St> for CheckBody {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let body = &self.body;
        let res = &self.res;
        match body {
            crate::syntax::decls::FnBody::BodyExpr(e) => prism_rtl::Turn::More(Rc::new(crate::check::expr::Check { env: env.clone(), st: st.clone(), e: e.clone(), expected: res.clone() })),
            crate::syntax::decls::FnBody::BodyBlock(b) => if &env.mark == &Text::lit("@") {
                {
                    let b = b.clone();
                    let env = env.clone();
                    let res = res.clone();
                    let st = st.clone();
                    call_then(crate::check::types::recording::start_walk(st.clone(), res.clone()), move |walk_13313: crate::check::types::Ty| match walk_13313 {
                        crate::check::types::Ty::TyAt(inner, rw) => {
                            let env2 = {
                                let mut this: crate::check::expr::Env = env.clone();
                                this.scope = rw.clone();
                                this
                            };
                            call_then(crate::check::blocks::start_infer_widget_block(env2.clone(), st.clone(), b.clone()), move |infer_widget_block_13478: (crate::check::types::Ty, crate::check::types::St)| {
                                let (t, st2) = infer_widget_block_13478;
                                prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st2.clone(), expected: (*inner).clone(), found: t.clone(), span: b.span.clone() }))
                            })
                        },
                        other => call_then(crate::check::types::start_show_ty(st.clone(), other.clone()), move |show_ty_13663: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err(&st, &Text::lit("mismatch"), &b.span, &Text::from(format!("a widget block builds a blueprint; the signature says `{}`", &show_ty_13663))))),
                    })
                }
            } else {
                if (&env.mark == &Text::lit("?")) || (&env.mark == &Text::lit("~")) {
                    {
                        let b = b.clone();
                        let env = env.clone();
                        let res = res.clone();
                        let st = st.clone();
                        call_then(crate::check::blocks::structure::start_infer_given_block(env.clone(), st.clone(), b.clone(), env.mark.clone()), move |infer_given_block_13765: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t, st2) = infer_given_block_13765;
                            prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st2.clone(), expected: res.clone(), found: t.clone(), span: b.span.clone() }))
                        })
                    }
                } else {
                    {
                        let b = b.clone();
                        let env = env.clone();
                        let res = res.clone();
                        let st = st.clone();
                        call_then(start_infer_expr_block(env.clone(), st.clone(), b.clone()), move |infer_expr_block_13883: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t, st2) = infer_expr_block_13883;
                            prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st2.clone(), expected: res.clone(), found: t.clone(), span: b.span.clone() }))
                        })
                    }
                }
            },
        }
    }
}

/// `Start CheckBody, x`: what the function value is when passed to `@Run`.
pub fn start_check_body(env: crate::check::expr::Env, st: crate::check::types::St, body: crate::syntax::decls::FnBody, res: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckBody { env, st, body, res })
}

/// ```prism
/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
/// ```
pub fn infer_template(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::syntax::Template) -> (crate::check::types::Ty, crate::check::types::St) {
    let st2 = run_to_end(fold_job(t.parts.clone(), st.clone(), {
        let env = env.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::TemplatePart)| {
            let env = env.clone();
            entered(once_job(move || {
                let s = p0;
                let part = p1;
                prism_rtl::Turn::More(Rc::new(TemplatePartCheck { env: env.clone(), st: s.clone(), part: part.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    (crate::check::types::t_text(), st2.clone())
}

/// The step machine of `InferTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
/// ```
pub struct InferTemplate {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::syntax::Template,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferTemplate {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_value(fold_job(t.parts.clone(), st.clone(), {
            let env = env.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::TemplatePart)| {
                let env = env.clone();
                entered(once_job(move || {
                    let s = p0;
                    let part = p1;
                    prism_rtl::Turn::More(Rc::new(TemplatePartCheck { env: env.clone(), st: s.clone(), part: part.clone() }))
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        }), move |fold_14321: crate::check::types::St| {
            let st2 = fold_14321;
            prism_rtl::Turn::Finished((crate::check::types::t_text(), st2.clone()))
        })
    }
}

/// `Start InferTemplate, x`: what the function value is when passed to `@Run`.
pub fn start_infer_template(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::syntax::Template) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferTemplate { env, st, t })
}

/// ```prism
/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
/// ```
pub fn template_part_check(env: &crate::check::expr::Env, st: &crate::check::types::St, part: &crate::syntax::TemplatePart) -> crate::check::types::St {
    match part {
        crate::syntax::TemplatePart::TpText(_) => st.clone(),
        crate::syntax::TemplatePart::TpPlaceholder(x, _) => {
            let (t, st2) = crate::check::expr::infer(env, st, x);
            crate::check::expr::show_want(&st2, &(if crate::check::expr::is_time_sigil(&crate::check::types::head_sigil(&st2, &t)) {
                crate::check::expr::inner_of(&st2, &t)
            } else {
                t.clone()
            }), &x.span)
        },
        crate::syntax::TemplatePart::TpBlock(b) => {
            let (t, st2) = infer_expr_block(env, st, b);
            st2.clone()
        },
        crate::syntax::TemplatePart::TpCall(n, args, parts_opt, span) => template_call_check(env, st, n, args, parts_opt, span),
    }
}

/// The step machine of `TemplatePartCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
/// ```
pub struct TemplatePartCheck {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub part: crate::syntax::TemplatePart,
}

impl prism_rtl::Job<crate::check::types::St> for TemplatePartCheck {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let part = &self.part;
        match part {
            crate::syntax::TemplatePart::TpText(_) => prism_rtl::Turn::Finished(st.clone()),
            crate::syntax::TemplatePart::TpPlaceholder(x, _) => {
                let env = env.clone();
                let st = st.clone();
                let x = x.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), x.clone()), move |infer_14586: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_14586;
                    call_then(crate::check::types::start_head_sigil(st2.clone(), t.clone()), move |head_sigil_14642: Text| prism_rtl::Turn::More(Rc::new(crate::check::expr::ShowWant { st: st2.clone(), t: if crate::check::expr::is_time_sigil(&head_sigil_14642) {
                        crate::check::expr::inner_of(&st2, &t)
                    } else {
                        t.clone()
                    }, span: x.span.clone() })))
                })
            },
            crate::syntax::TemplatePart::TpBlock(b) => {
                let b = b.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(start_infer_expr_block(env.clone(), st.clone(), b.clone()), move |infer_expr_block_14733: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_expr_block_14733;
                    prism_rtl::Turn::Finished(st2.clone())
                })
            },
            crate::syntax::TemplatePart::TpCall(n, args, parts_opt, span) => prism_rtl::Turn::More(Rc::new(TemplateCallCheck { env: env.clone(), st: st.clone(), n: n.clone(), args: args.clone(), parts_opt: parts_opt.clone(), span: span.clone() })),
        }
    }
}

/// `Start TemplatePartCheck, x`: what the function value is when passed to `@Run`.
pub fn start_template_part_check(env: crate::check::expr::Env, st: crate::check::types::St, part: crate::syntax::TemplatePart) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(TemplatePartCheck { env, st, part })
}

/// ```prism
/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
/// ```
pub fn template_call_check(env: &crate::check::expr::Env, st: &crate::check::types::St, n: &crate::syntax::SName, args: &Array<crate::syntax::Arg>, parts_opt: &Option<Array<crate::syntax::TemplatePart>>, span: &crate::syntax::Range) -> crate::check::types::St {
    let plain = crate::syntax::SName { sigils: crate::syntax::lexer::chars::after_first(&n.sigils), path_: n.path_.clone(), span: n.span.clone() };
    let (qk1_opt, _) = crate::check::env::names::resolve_value(&env.g, &env.home, n);
    let callee = if &qk1_opt != &None { n.clone() } else { plain.clone() };
    let (qk_opt, ignore2) = crate::check::env::names::resolve_value(&env.g, &env.home, &callee);
    let cname = crate::check::env::sname_key(&plain);
    match &qk_opt {
        None => {
            let (ignore3, st2) = crate::check::expr::calls::call_global(env, st, &callee, &Array::new(), span, &Array::new(), &callee.span);
            st2.clone()
        },
        Some(qk) => {
            let clauses = match get(&env.g.fn_at, qk) {
                Some(i) => match index(&env.g.defs, &i) {
                    Some(d) => match &d.body {
                        crate::check::env::DefBody::DbFn(cs) => cs.clone(),
                        _ => Array::new(),
                    },
                    None => Array::new(),
                },
                None => Array::new(),
            };
            let arity = match index(&clauses, &Nat::from(0u32)) {
                Some(c) => len(&c.params),
                None => Nat::from(0u32),
            };
            if &len(&clauses) == &Nat::from(0u32) {
                crate::check::types::recording::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`<@{}>` calls a function without clauses, which name no parameters for its attributes", &cname)))
            } else {
                {
                    let (slots, st1) = run_to_end(fold_job(args.clone(), (Map::new(), st.clone()), {
                        let clauses = clauses.clone();
                        let cname = cname.clone();
                        Rc::new(move |(p0, p1): ((Map<Text, crate::syntax::Expr>, crate::check::types::St), crate::syntax::Arg)| {
                            let clauses = clauses.clone();
                            let cname = cname.clone();
                            entered(once_job(move || {
                                let (m, s) = p0;
                                let a = p1;
                                match &a.name {
                                    Some(id) => {
                                        let id = id.clone();
                                        call_then(start_template_slot(clauses.clone(), id.name.clone()), move |template_slot_16532: Option<Nat>| match template_slot_16532 {
                                            Some(j) => if crate::check::env::has_key(&m, &Text::from(format!("{}", &j))) {
                                                prism_rtl::Turn::Finished((m.clone(), crate::check::types::recording::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` is given twice", &id.name)))))
                                            } else {
                                                prism_rtl::Turn::Finished((insert(&m, &Text::from(format!("{}", &j)), &a.value), s.clone()))
                                            },
                                            None => prism_rtl::Turn::Finished((m.clone(), crate::check::types::recording::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` has no parameter `{}`", &cname, &id.name))))),
                                        })
                                    },
                                    None => prism_rtl::Turn::Finished((m.clone(), crate::check::types::recording::err(&s, &Text::lit("mismatch"), &a.span, &Text::lit("a template call names each argument: `name={{value}}`")))),
                                }
                            }))
                        }) as Rc<dyn Fn(((Map<Text, crate::syntax::Expr>, crate::check::types::St), crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<(Map<Text, crate::syntax::Expr>, crate::check::types::St)>>>
                    }));
                    let body_opt = match parts_opt {
                        Some(ps) => Some(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(crate::syntax::Template { keyword: Text::lit("InlineText"), lang: Text::lit(""), delims: Text::lit("double"), parts: ps.clone(), span: span.clone() })), span: span.clone() }),
                        None => None,
                    };
                    let last = crate::syntax::lexer::chars::dec(&arity);
                    let st2 = match &body_opt {
                        Some(ignore4) => if (&arity == &Nat::from(0u32)) || crate::check::env::has_key(&slots, &Text::from(format!("{}", &last))) {
                            crate::check::types::recording::err(&st1, &Text::lit("mismatch"), span, &Text::from(format!("`{}` has no parameter left for the call\'s body", &cname)))
                        } else {
                            st1.clone()
                        },
                        None => st1.clone(),
                    };
                    let quiet = &len(&st1.diags) > &len(&st.diags);
                    let (positional, st3) = run_to_end(fold_job(crate::check::errors::range0(&arity), (Array::new(), st2.clone()), {
                        let slots = slots.clone();
                        let body_opt = body_opt.clone();
                        let last = last.clone();
                        let span = span.clone();
                        let clauses = clauses.clone();
                        let cname = cname.clone();
                        let quiet = quiet;
                        Rc::new(move |(p0, p1): ((Array<crate::syntax::Arg>, crate::check::types::St), Nat)| {
                            let slots = slots.clone();
                            let body_opt = body_opt.clone();
                            let last = last.clone();
                            let span = span.clone();
                            let clauses = clauses.clone();
                            let cname = cname.clone();
                            let quiet = quiet;
                            entered(once_job(move || {
                                let (acc, s) = p0;
                                let j = p1;
                                match get(&slots, &Text::from(format!("{}", &j))) {
                                    Some(v_) => prism_rtl::Turn::Finished((push(&acc, &crate::syntax::Arg { name: None, value: v_.clone(), span: v_.span.clone() }), s.clone())),
                                    None => match &body_opt {
                                        Some(b) => if &j == &last {
                                            prism_rtl::Turn::Finished((push(&acc, &crate::syntax::Arg { name: None, value: b.clone(), span: span.clone() }), s.clone()))
                                        } else {
                                            prism_rtl::Turn::More(Rc::new(TemplateMissing { acc: acc.clone(), st: s.clone(), clauses: clauses.clone(), j: j.clone(), cname: cname.clone(), span: span.clone(), quiet }))
                                        },
                                        None => prism_rtl::Turn::More(Rc::new(TemplateMissing { acc: acc.clone(), st: s.clone(), clauses: clauses.clone(), j: j.clone(), cname: cname.clone(), span: span.clone(), quiet })),
                                    },
                                }
                            }))
                        }) as Rc<dyn Fn(((Array<crate::syntax::Arg>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::check::types::St)>>>
                    }));
                    let (t, st4) = crate::check::expr::calls::call_global(env, &st3, &callee, &positional, span, &Array::new(), &callee.span);
                    crate::check::types::unify::unify(&st4, &crate::check::types::t_text(), &t, span)
                }
            }
        },
    }
}

/// The step machine of `TemplateCallCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
/// ```
pub struct TemplateCallCheck {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub n: crate::syntax::SName,
    pub args: Array<crate::syntax::Arg>,
    pub parts_opt: Option<Array<crate::syntax::TemplatePart>>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for TemplateCallCheck {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let args = &self.args;
        let parts_opt = &self.parts_opt;
        let span = &self.span;
        let plain = crate::syntax::SName { sigils: crate::syntax::lexer::chars::after_first(&n.sigils), path_: n.path_.clone(), span: n.span.clone() };
        let (qk1_opt, _) = crate::check::env::names::resolve_value(&env.g, &env.home, n);
        let callee = if &qk1_opt != &None { n.clone() } else { plain.clone() };
        let (qk_opt, ignore2) = crate::check::env::names::resolve_value(&env.g, &env.home, &callee);
        let cname = crate::check::env::sname_key(&plain);
        match &qk_opt {
            None => {
                let env = env.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(crate::check::expr::calls::start_call_global(env.clone(), st.clone(), callee.clone(), Array::new(), span.clone(), Array::new(), callee.span.clone()), move |call_global_15790: (crate::check::types::Ty, crate::check::types::St)| {
                    let (ignore3, st2) = call_global_15790;
                    prism_rtl::Turn::Finished(st2.clone())
                })
            },
            Some(qk) => {
                let clauses = match get(&env.g.fn_at, qk) {
                    Some(i) => match index(&env.g.defs, &i) {
                        Some(d) => match &d.body {
                            crate::check::env::DefBody::DbFn(cs) => cs.clone(),
                            _ => Array::new(),
                        },
                        None => Array::new(),
                    },
                    None => Array::new(),
                };
                let arity = match index(&clauses, &Nat::from(0u32)) {
                    Some(c) => len(&c.params),
                    None => Nat::from(0u32),
                };
                if &len(&clauses) == &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(crate::check::types::recording::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`<@{}>` calls a function without clauses, which name no parameters for its attributes", &cname))))
                } else {
                    {
                        let parts_opt = parts_opt.clone();
                        let args = args.clone();
                        let env = env.clone();
                        let span = span.clone();
                        let st = st.clone();
                        call_value(fold_job(args.clone(), (Map::new(), st.clone()), {
                            let clauses = clauses.clone();
                            let cname = cname.clone();
                            Rc::new(move |(p0, p1): ((Map<Text, crate::syntax::Expr>, crate::check::types::St), crate::syntax::Arg)| {
                                let clauses = clauses.clone();
                                let cname = cname.clone();
                                entered(once_job(move || {
                                    let (m, s) = p0;
                                    let a = p1;
                                    match &a.name {
                                        Some(id) => {
                                            let id = id.clone();
                                            call_then(start_template_slot(clauses.clone(), id.name.clone()), move |template_slot_16532: Option<Nat>| match template_slot_16532 {
                                                Some(j) => if crate::check::env::has_key(&m, &Text::from(format!("{}", &j))) {
                                                    prism_rtl::Turn::Finished((m.clone(), crate::check::types::recording::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` is given twice", &id.name)))))
                                                } else {
                                                    prism_rtl::Turn::Finished((insert(&m, &Text::from(format!("{}", &j)), &a.value), s.clone()))
                                                },
                                                None => prism_rtl::Turn::Finished((m.clone(), crate::check::types::recording::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` has no parameter `{}`", &cname, &id.name))))),
                                            })
                                        },
                                        None => prism_rtl::Turn::Finished((m.clone(), crate::check::types::recording::err(&s, &Text::lit("mismatch"), &a.span, &Text::lit("a template call names each argument: `name={{value}}`")))),
                                    }
                                }))
                            }) as Rc<dyn Fn(((Map<Text, crate::syntax::Expr>, crate::check::types::St), crate::syntax::Arg)) -> Rc<dyn prism_rtl::Job<(Map<Text, crate::syntax::Expr>, crate::check::types::St)>>>
                        }), move |fold_16447: (Map<Text, crate::syntax::Expr>, crate::check::types::St)| {
                            let (slots, st1) = fold_16447;
                            let body_opt = match &parts_opt {
                                Some(ps) => Some(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(crate::syntax::Template { keyword: Text::lit("InlineText"), lang: Text::lit(""), delims: Text::lit("double"), parts: ps.clone(), span: span.clone() })), span: span.clone() }),
                                None => None,
                            };
                            let last = crate::syntax::lexer::chars::dec(&arity);
                            let st2 = match &body_opt {
                                Some(ignore4) => if (&arity == &Nat::from(0u32)) || crate::check::env::has_key(&slots, &Text::from(format!("{}", &last))) {
                                    crate::check::types::recording::err(&st1, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` has no parameter left for the call\'s body", &cname)))
                                } else {
                                    st1.clone()
                                },
                                None => st1.clone(),
                            };
                            let quiet = &len(&st1.diags) > &len(&st.diags);
                            call_value(fold_job(crate::check::errors::range0(&arity), (Array::new(), st2.clone()), {
                                let slots = slots.clone();
                                let body_opt = body_opt.clone();
                                let last = last.clone();
                                let span = span.clone();
                                let clauses = clauses.clone();
                                let cname = cname.clone();
                                let quiet = quiet;
                                Rc::new(move |(p0, p1): ((Array<crate::syntax::Arg>, crate::check::types::St), Nat)| {
                                    let slots = slots.clone();
                                    let body_opt = body_opt.clone();
                                    let last = last.clone();
                                    let span = span.clone();
                                    let clauses = clauses.clone();
                                    let cname = cname.clone();
                                    let quiet = quiet;
                                    entered(once_job(move || {
                                        let (acc, s) = p0;
                                        let j = p1;
                                        match get(&slots, &Text::from(format!("{}", &j))) {
                                            Some(v_) => prism_rtl::Turn::Finished((push(&acc, &crate::syntax::Arg { name: None, value: v_.clone(), span: v_.span.clone() }), s.clone())),
                                            None => match &body_opt {
                                                Some(b) => if &j == &last {
                                                    prism_rtl::Turn::Finished((push(&acc, &crate::syntax::Arg { name: None, value: b.clone(), span: span.clone() }), s.clone()))
                                                } else {
                                                    prism_rtl::Turn::More(Rc::new(TemplateMissing { acc: acc.clone(), st: s.clone(), clauses: clauses.clone(), j: j.clone(), cname: cname.clone(), span: span.clone(), quiet }))
                                                },
                                                None => prism_rtl::Turn::More(Rc::new(TemplateMissing { acc: acc.clone(), st: s.clone(), clauses: clauses.clone(), j: j.clone(), cname: cname.clone(), span: span.clone(), quiet })),
                                            },
                                        }
                                    }))
                                }) as Rc<dyn Fn(((Array<crate::syntax::Arg>, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::check::types::St)>>>
                            }), move |fold_17531: (Array<crate::syntax::Arg>, crate::check::types::St)| {
                                let (positional, st3) = fold_17531;
                                call_then(crate::check::expr::calls::start_call_global(env.clone(), st3.clone(), callee.clone(), positional.clone(), span.clone(), Array::new(), callee.span.clone()), move |call_global_17996: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (t, st4) = call_global_17996;
                                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st4.clone(), expected: crate::check::types::t_text(), found: t.clone(), span: span.clone() }))
                                })
                            })
                        })
                    }
                }
            },
        }
    }
}

/// `Start TemplateCallCheck, x`: what the function value is when passed to `@Run`.
pub fn start_template_call_check(env: crate::check::expr::Env, st: crate::check::types::St, n: crate::syntax::SName, args: Array<crate::syntax::Arg>, parts_opt: Option<Array<crate::syntax::TemplatePart>>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(TemplateCallCheck { env, st, n, args, parts_opt, span })
}

/// ```prism
/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
/// ```
pub fn template_missing(acc: &Array<crate::syntax::Arg>, st: &crate::check::types::St, clauses: &Array<crate::syntax::decls::FnClause>, j: &Nat, cname: &Text, span: &crate::syntax::Range, quiet: &bool) -> (Array<crate::syntax::Arg>, crate::check::types::St) {
    let pname = match index(clauses, &Nat::from(0u32)) {
        Some(c) => match index(&c.params, j) {
            Some(p_) => crate::check::shrink::locals::param_name_of(&p_),
            None => Text::lit(""),
        },
        None => Text::lit(""),
    };
    let st2 = if *quiet {
        st.clone()
    } else {
        crate::check::types::recording::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`<@{}>` needs `{}=`", cname, &pname)))
    };
    (push(acc, &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, span: span.clone() }), st2.clone())
}

/// The step machine of `TemplateMissing`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
/// ```
pub struct TemplateMissing {
    pub acc: Array<crate::syntax::Arg>,
    pub st: crate::check::types::St,
    pub clauses: Array<crate::syntax::decls::FnClause>,
    pub j: Nat,
    pub cname: Text,
    pub span: crate::syntax::Range,
    pub quiet: bool,
}

impl prism_rtl::Job<(Array<crate::syntax::Arg>, crate::check::types::St)> for TemplateMissing {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arg>, crate::check::types::St)> {
        let acc = &self.acc;
        let st = &self.st;
        let clauses = &self.clauses;
        let j = &self.j;
        let cname = &self.cname;
        let span = &self.span;
        let quiet = &self.quiet;
        let pname = match index(clauses, &Nat::from(0u32)) {
            Some(c) => match index(&c.params, j) {
                Some(p_) => crate::check::shrink::locals::param_name_of(&p_),
                None => Text::lit(""),
            },
            None => Text::lit(""),
        };
        let st2 = if *quiet {
            st.clone()
        } else {
            crate::check::types::recording::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`<@{}>` needs `{}=`", cname, &pname)))
        };
        prism_rtl::Turn::Finished((push(acc, &crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, span: span.clone() }), st2.clone()))
    }
}

/// `Start TemplateMissing, x`: what the function value is when passed to `@Run`.
pub fn start_template_missing(acc: Array<crate::syntax::Arg>, st: crate::check::types::St, clauses: Array<crate::syntax::decls::FnClause>, j: Nat, cname: Text, span: crate::syntax::Range, quiet: bool) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::check::types::St)>> {
    Rc::new(TemplateMissing { acc, st, clauses, j, cname, span, quiet })
}

/// ```prism
/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
/// ```
pub fn template_slot(clauses: &Array<crate::syntax::decls::FnClause>, name: &Text) -> Option<Nat> {
    let found = run_to_end(fold_job(clauses.clone(), Array::new(), {
        let name = name.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::syntax::decls::FnClause)| {
            let name = name.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                fold_job(crate::check::errors::range0(&len(&c.params)), acc.clone(), {
                    let c = c.clone();
                    let name = name.clone();
                    Rc::new(move |(p0, p1): (Array<Nat>, Nat)| {
                        let c = c.clone();
                        let name = name.clone();
                        entered(once_job(move || {
                            let a2 = p0;
                            let i = p1;
                            match index(&c.params, &i) {
                                Some(p_) => if &crate::check::shrink::locals::param_name_of(&p_) == &name {
                                    prism_rtl::Turn::Finished(crate::check::types::add_nat(&a2, &i))
                                } else {
                                    prism_rtl::Turn::Finished(a2.clone())
                                },
                                None => prism_rtl::Turn::Finished(a2.clone()),
                            }
                        }))
                    }) as Rc<dyn Fn((Array<Nat>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    if &len(&found) == &Nat::from(1u32) { index(&found, &Nat::from(0u32)) } else { None }
}

/// The step machine of `TemplateSlot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
/// ```
pub struct TemplateSlot {
    pub clauses: Array<crate::syntax::decls::FnClause>,
    pub name: Text,
}

impl prism_rtl::Job<Option<Nat>> for TemplateSlot {
    fn cycle(&self) -> prism_rtl::Turn<Option<Nat>> {
        let clauses = &self.clauses;
        let name = &self.name;
        let clauses = clauses.clone();
        let name = name.clone();
        call_value(fold_job(clauses.clone(), Array::new(), {
            let name = name.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::syntax::decls::FnClause)| {
                let name = name.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let c = p1;
                    fold_job(crate::check::errors::range0(&len(&c.params)), acc.clone(), {
                        let c = c.clone();
                        let name = name.clone();
                        Rc::new(move |(p0, p1): (Array<Nat>, Nat)| {
                            let c = c.clone();
                            let name = name.clone();
                            entered(once_job(move || {
                                let a2 = p0;
                                let i = p1;
                                match index(&c.params, &i) {
                                    Some(p_) => if &crate::check::shrink::locals::param_name_of(&p_) == &name {
                                        prism_rtl::Turn::Finished(crate::check::types::add_nat(&a2, &i))
                                    } else {
                                        prism_rtl::Turn::Finished(a2.clone())
                                    },
                                    None => prism_rtl::Turn::Finished(a2.clone()),
                                }
                            }))
                        }) as Rc<dyn Fn((Array<Nat>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                    }).cycle()
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        }), move |fold_18890: Array<Nat>| {
            let found = fold_18890;
            if &len(&found) == &Nat::from(1u32) {
                prism_rtl::Turn::Finished(index(&found, &Nat::from(0u32)))
            } else {
                prism_rtl::Turn::Finished(None)
            }
        })
    }
}

/// `Start TemplateSlot, x`: what the function value is when passed to `@Run`.
pub fn start_template_slot(clauses: Array<crate::syntax::decls::FnClause>, name: Text) -> Rc<dyn prism_rtl::Job<Option<Nat>>> {
    Rc::new(TemplateSlot { clauses, name })
}
