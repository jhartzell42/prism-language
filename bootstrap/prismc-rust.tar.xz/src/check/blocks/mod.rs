//! The module `Check.Blocks`, from `target/bootstrap/src/prismc/check/blocks/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod borrows;
pub mod structure;

/// ```prism
/// GroupOrder: unbounded fn [Stmt] -> [Nat]
/// ```
pub fn group_order_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>) -> crate::prelude::Array<crate::prelude::Nat> {
    let all_p1 = crate::check::errors::range0_f(&crate::prelude::len(stmts_p0));
    let holds_p2 = crate::prelude::filter(&all_p1, &(|i_p6: &crate::prelude::Nat| is_hold_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p6), &dummy_stmt2_p()))));
    let lets_p3 = crate::prelude::filter(&all_p1, &(|i_p7: &crate::prelude::Nat| is_let_like_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p7), &dummy_stmt2_p()))));
    let rest_p4 = crate::prelude::filter(&all_p1, &(|i_p8: &crate::prelude::Nat| !is_hold_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p8), &dummy_stmt2_p())) && !is_let_like_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p8), &dummy_stmt2_p()))));
    let ordered_p5 = crate::prelude::fold(&dep_order_f(&crate::prelude::each(&rest_p4, &(|i_p9: &crate::prelude::Nat| crate::prelude::or(&crate::prelude::index(stmts_p0, i_p9), &dummy_stmt2_p())))), &crate::prelude::Array::new(), &(|acc_pa: &crate::prelude::Array<crate::prelude::Nat>, comp_pb: &crate::prelude::Array<crate::prelude::Nat>| crate::prelude::append(acc_pa, &crate::prelude::each(comp_pb, &(|j_pc: &crate::prelude::Nat| crate::prelude::or(&crate::prelude::index(&rest_p4, j_pc), &crate::prelude::Nat::from(0u32)))))));
    crate::prelude::append(&crate::prelude::append(&holds_p2, &lets_p3), &ordered_p5)
}

/// The step machine of `GroupOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GroupOrder: unbounded fn [Stmt] -> [Nat]
/// ```
pub struct GroupOrder {
    pub stmts_p0: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>> for GroupOrder {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Nat>> {
        let stmts_p0 = &self.stmts_p0;
        let all_p1 = crate::check::errors::range0_f(&crate::prelude::len(stmts_p0));
        let holds_p2 = crate::prelude::filter(&all_p1, &(|i_p6: &crate::prelude::Nat| is_hold_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p6), &dummy_stmt2_p()))));
        let lets_p3 = crate::prelude::filter(&all_p1, &(|i_p7: &crate::prelude::Nat| is_let_like_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p7), &dummy_stmt2_p()))));
        let rest_p4 = crate::prelude::filter(&all_p1, &(|i_p8: &crate::prelude::Nat| !is_hold_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p8), &dummy_stmt2_p())) && !is_let_like_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p8), &dummy_stmt2_p()))));
        let stmts_p0x = stmts_p0.clone();
        crate::prelude::call_then(start_dep_order_f(crate::prelude::each(&rest_p4, &(|i_p9: &crate::prelude::Nat| crate::prelude::or(&crate::prelude::index(&stmts_p0x, i_p9), &dummy_stmt2_p())))), move |dep_order_f_2397: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>| {
            let ordered_p5 = crate::prelude::fold(&dep_order_f_2397, &crate::prelude::Array::new(), &(|acc_pa: &crate::prelude::Array<crate::prelude::Nat>, comp_pb: &crate::prelude::Array<crate::prelude::Nat>| crate::prelude::append(acc_pa, &crate::prelude::each(comp_pb, &(|j_pc: &crate::prelude::Nat| crate::prelude::or(&crate::prelude::index(&rest_p4, j_pc), &crate::prelude::Nat::from(0u32)))))));
            ::prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::append(&holds_p2, &lets_p3), &ordered_p5))
        })
    }
}

/// `Start GroupOrder, x`: what the function value is when passed to `@Run`.
pub fn start_group_order_f(stmts_p0: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>> {
    ::std::rc::Rc::new(GroupOrder { stmts_p0 })
}

/// ```prism
/// WidgetGroupOrder: unbounded fn [Stmt] -> [Nat]
/// ```
pub fn widget_group_order_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>) -> crate::prelude::Array<crate::prelude::Nat> {
    crate::prelude::fold(&dep_order_f(stmts_p0), &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<crate::prelude::Nat>, comp_p2: &crate::prelude::Array<crate::prelude::Nat>| {
        let holds_p3 = crate::prelude::filter(comp_p2, &(|i_p6: &crate::prelude::Nat| is_hold_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p6), &dummy_stmt2_p()))));
        let lets_p4 = crate::prelude::filter(comp_p2, &(|i_p7: &crate::prelude::Nat| is_let_like_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p7), &dummy_stmt2_p()))));
        let rest_p5 = crate::prelude::filter(comp_p2, &(|i_p8: &crate::prelude::Nat| !is_hold_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p8), &dummy_stmt2_p())) && !is_let_like_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p8), &dummy_stmt2_p()))));
        crate::prelude::append(acc_p1, &crate::prelude::append(&crate::prelude::append(&holds_p3, &lets_p4), &rest_p5))
    }))
}

/// The step machine of `WidgetGroupOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetGroupOrder: unbounded fn [Stmt] -> [Nat]
/// ```
pub struct WidgetGroupOrder {
    pub stmts_p0: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>> for WidgetGroupOrder {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Nat>> {
        let stmts_p0 = &self.stmts_p0;
        let stmts_p0x = stmts_p0.clone();
        crate::prelude::call_then(start_dep_order_f(stmts_p0x.clone()), move |dep_order_f_3154: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&dep_order_f_3154, &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<crate::prelude::Nat>, comp_p2: &crate::prelude::Array<crate::prelude::Nat>| {
            let holds_p3 = crate::prelude::filter(comp_p2, &(|i_p6: &crate::prelude::Nat| is_hold_f(&crate::prelude::or(&crate::prelude::index(&stmts_p0x, i_p6), &dummy_stmt2_p()))));
            let lets_p4 = crate::prelude::filter(comp_p2, &(|i_p7: &crate::prelude::Nat| is_let_like_f(&crate::prelude::or(&crate::prelude::index(&stmts_p0x, i_p7), &dummy_stmt2_p()))));
            let rest_p5 = crate::prelude::filter(comp_p2, &(|i_p8: &crate::prelude::Nat| !is_hold_f(&crate::prelude::or(&crate::prelude::index(&stmts_p0x, i_p8), &dummy_stmt2_p())) && !is_let_like_f(&crate::prelude::or(&crate::prelude::index(&stmts_p0x, i_p8), &dummy_stmt2_p()))));
            crate::prelude::append(acc_p1, &crate::prelude::append(&crate::prelude::append(&holds_p3, &lets_p4), &rest_p5))
        }))))
    }
}

/// `Start WidgetGroupOrder, x`: what the function value is when passed to `@Run`.
pub fn start_widget_group_order_f(stmts_p0: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>> {
    ::std::rc::Rc::new(WidgetGroupOrder { stmts_p0 })
}

/// ```prism
/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub fn dep_order_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>) -> crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>> {
    let n_p1 = crate::prelude::len(stmts_p0);
    let defs_p2 = crate::prelude::run_to_end(crate::prelude::each_job(stmts_p0.clone(), ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p7 = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(GroupDefs { s_p0: s_p7.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
    let uses_p3 = crate::prelude::run_to_end(crate::prelude::each_job(stmts_p0.clone(), ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p8 = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::shrink::locals::NamesInStmt { s_p0: s_p8.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
    let deps_p4 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_p9: &crate::prelude::Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pa: &crate::prelude::Nat| crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(&defs_p2, j_pa), &crate::prelude::Array::new()), &false, &(|seen_pb: &bool, d_pc: &crate::prelude::Text| *seen_pb || crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::index(&uses_p3, i_p9), &crate::prelude::Array::new()), d_pc)))))));
    let reach_p5 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&n_p1), {
        let deps_p4x = deps_p4.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let deps_p4xy = deps_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pd = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ReachIdx { deps_p0: deps_p4xy.clone(), frontier_p1: crate::prelude::or(&crate::prelude::index(&deps_p4xy, &i_pd), &crate::prelude::Array::new()), seen_p2: crate::prelude::Array::new() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    let comps_p6 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_pe: &crate::prelude::Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pf: &crate::prelude::Nat| (j_pf == i_pe) || (crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, i_pe), &crate::prelude::Array::new()), j_pf) && crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, j_pf), &crate::prelude::Array::new()), i_pe))))));
    emit_groups_f(&comps_p6, &deps_p4, &crate::prelude::Array::new(), &crate::prelude::Array::new())
}

/// The step machine of `DepOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub struct DepOrder {
    pub stmts_p0: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>> for DepOrder {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>> {
        let stmts_p0 = &self.stmts_p0;
        let n_p1 = crate::prelude::len(stmts_p0);
        let stmts_p0x = stmts_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(stmts_p0x.clone(), ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
            let s_p7 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(GroupDefs { s_p0: s_p7.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |each_4014: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| {
            let defs_p2 = each_4014;
            crate::prelude::call_value(crate::prelude::each_job(stmts_p0x.clone(), ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p8 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::shrink::locals::NamesInStmt { s_p0: s_p8.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |each_4058: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| {
                let uses_p3 = each_4058;
                let deps_p4 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_p9: &crate::prelude::Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pa: &crate::prelude::Nat| crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(&defs_p2, j_pa), &crate::prelude::Array::new()), &false, &(|seen_pb: &bool, d_pc: &crate::prelude::Text| *seen_pb || crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::index(&uses_p3, i_p9), &crate::prelude::Array::new()), d_pc)))))));
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&n_p1), {
                    let deps_p4x = deps_p4.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                        let deps_p4xy = deps_p4x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_pd = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ReachIdx { deps_p0: deps_p4xy.clone(), frontier_p1: crate::prelude::or(&crate::prelude::index(&deps_p4xy, &i_pd), &crate::prelude::Array::new()), seen_p2: crate::prelude::Array::new() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
                }), move |each_4247: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>| {
                    let reach_p5 = each_4247;
                    let comps_p6 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_pe: &crate::prelude::Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pf: &crate::prelude::Nat| (j_pf == i_pe) || (crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, i_pe), &crate::prelude::Array::new()), j_pf) && crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, j_pf), &crate::prelude::Array::new()), i_pe))))));
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(EmitGroups { comps_p0: comps_p6.clone(), deps_p1: deps_p4.clone(), done_p2: crate::prelude::Array::new(), acc_p3: crate::prelude::Array::new() }))
                })
            })
        })
    }
}

/// `Start DepOrder, x`: what the function value is when passed to `@Run`.
pub fn start_dep_order_f(stmts_p0: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>>> {
    ::std::rc::Rc::new(DepOrder { stmts_p0 })
}

/// ```prism
/// GroupDefs: unbounded fn Stmt -> [Text]
/// ```
pub fn group_defs_f(s_p0: &crate::syntax::Stmt) -> crate::prelude::Array<crate::prelude::Text> {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SBind(p_p1, _, _) => crate::check::env::names::pattern_names_f(p_p1),
        crate::syntax::StmtKind::SLet(p_p2, _, _) => crate::check::env::names::pattern_names_f(p_p2),
        crate::syntax::StmtKind::SFn(f_p3) => crate::prelude::Array::from(vec![crate::check::env::def_name_text_f(&f_p3.name_p)]),
        crate::syntax::StmtKind::SWidget(w_p4) => crate::prelude::Array::from(vec![crate::check::env::sname_key_f(&w_p4.name_p)]),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `GroupDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GroupDefs: unbounded fn Stmt -> [Text]
/// ```
pub struct GroupDefs {
    pub s_p0: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for GroupDefs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let s_p0 = &self.s_p0;
        match &s_p0.kind_p {
            crate::syntax::StmtKind::SBind(p_p1, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::names::PatternNames { p_p0: p_p1.clone() })),
            crate::syntax::StmtKind::SLet(p_p2, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::names::PatternNames { p_p0: p_p2.clone() })),
            crate::syntax::StmtKind::SFn(f_p3) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::check::env::def_name_text_f(&f_p3.name_p)])),
            crate::syntax::StmtKind::SWidget(w_p4) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::check::env::sname_key_f(&w_p4.name_p)])),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start GroupDefs, x`: what the function value is when passed to `@Run`.
pub fn start_group_defs_f(s_p0: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(GroupDefs { s_p0 })
}

/// ```prism
/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
/// ```
pub fn reach_idx_f(deps_p0: &crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>, frontier_p1: &crate::prelude::Array<crate::prelude::Nat>, seen_p2: &crate::prelude::Array<crate::prelude::Nat>) -> crate::prelude::Array<crate::prelude::Nat> {
    match crate::prelude::index(frontier_p1, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::None => seen_p2.clone(),
        ::std::option::Option::Some(x_p3) => if crate::check::types::has_nat_f(seen_p2, &x_p3) {
            reach_idx_f(deps_p0, &crate::prelude::drop(frontier_p1, &crate::prelude::Nat::from(1u32)), seen_p2)
        } else {
            reach_idx_f(deps_p0, &crate::prelude::append(&crate::prelude::drop(frontier_p1, &crate::prelude::Nat::from(1u32)), &crate::prelude::or(&crate::prelude::index(deps_p0, &x_p3), &crate::prelude::Array::new())), &crate::prelude::push(seen_p2, &x_p3))
        },
    }
}

/// The step machine of `ReachIdx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
/// ```
pub struct ReachIdx {
    pub deps_p0: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>,
    pub frontier_p1: crate::prelude::Array<crate::prelude::Nat>,
    pub seen_p2: crate::prelude::Array<crate::prelude::Nat>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>> for ReachIdx {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Nat>> {
        let deps_p0 = &self.deps_p0;
        let frontier_p1 = &self.frontier_p1;
        let seen_p2 = &self.seen_p2;
        match crate::prelude::index(frontier_p1, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(seen_p2.clone()),
            ::std::option::Option::Some(x_p3) => if crate::check::types::has_nat_f(seen_p2, &x_p3) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ReachIdx { deps_p0: deps_p0.clone(), frontier_p1: crate::prelude::drop(frontier_p1, &crate::prelude::Nat::from(1u32)), seen_p2: seen_p2.clone() }))
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ReachIdx { deps_p0: deps_p0.clone(), frontier_p1: crate::prelude::append(&crate::prelude::drop(frontier_p1, &crate::prelude::Nat::from(1u32)), &crate::prelude::or(&crate::prelude::index(deps_p0, &x_p3), &crate::prelude::Array::new())), seen_p2: crate::prelude::push(seen_p2, &x_p3) }))
            },
        }
    }
}

/// `Start ReachIdx, x`: what the function value is when passed to `@Run`.
pub fn start_reach_idx_f(deps_p0: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>, frontier_p1: crate::prelude::Array<crate::prelude::Nat>, seen_p2: crate::prelude::Array<crate::prelude::Nat>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>> {
    ::std::rc::Rc::new(ReachIdx { deps_p0, frontier_p1, seen_p2 })
}

/// ```prism
/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
/// ```
pub fn emit_groups_f(comps_p0: &crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>, deps_p1: &crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>, done_p2: &crate::prelude::Array<crate::prelude::Nat>, acc_p3: &crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>) -> crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>> {
    let ready_p4 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(comps_p0)), &(|i_p5: &crate::prelude::Nat| !crate::check::types::has_nat_f(done_p2, i_p5) && crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(deps_p1, i_p5), &crate::prelude::Array::new()), &true, &(|ok_p6: &bool, d_p7: &crate::prelude::Nat| *ok_p6 && (crate::check::types::has_nat_f(done_p2, d_p7) || crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(comps_p0, i_p5), &crate::prelude::Array::new()), d_p7))))));
    match crate::prelude::index(&ready_p4, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::None => acc_p3.clone(),
        ::std::option::Option::Some(i_p8) => {
            let c_p9 = crate::prelude::or(&crate::prelude::index(comps_p0, &i_p8), &crate::prelude::Array::from(vec![i_p8.clone()]));
            emit_groups_f(comps_p0, deps_p1, &crate::prelude::append(done_p2, &c_p9), &crate::prelude::push(acc_p3, &c_p9))
        },
    }
}

/// The step machine of `EmitGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
/// ```
pub struct EmitGroups {
    pub comps_p0: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>,
    pub deps_p1: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>,
    pub done_p2: crate::prelude::Array<crate::prelude::Nat>,
    pub acc_p3: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>> for EmitGroups {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>> {
        let comps_p0 = &self.comps_p0;
        let deps_p1 = &self.deps_p1;
        let done_p2 = &self.done_p2;
        let acc_p3 = &self.acc_p3;
        let ready_p4 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(comps_p0)), &(|i_p5: &crate::prelude::Nat| !crate::check::types::has_nat_f(done_p2, i_p5) && crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(deps_p1, i_p5), &crate::prelude::Array::new()), &true, &(|ok_p6: &bool, d_p7: &crate::prelude::Nat| *ok_p6 && (crate::check::types::has_nat_f(done_p2, d_p7) || crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(comps_p0, i_p5), &crate::prelude::Array::new()), d_p7))))));
        match crate::prelude::index(&ready_p4, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_p3.clone()),
            ::std::option::Option::Some(i_p8) => {
                let c_p9 = crate::prelude::or(&crate::prelude::index(comps_p0, &i_p8), &crate::prelude::Array::from(vec![i_p8.clone()]));
                ::prism_rtl::Turn::More(::std::rc::Rc::new(EmitGroups { comps_p0: comps_p0.clone(), deps_p1: deps_p1.clone(), done_p2: crate::prelude::append(done_p2, &c_p9), acc_p3: crate::prelude::push(acc_p3, &c_p9) }))
            },
        }
    }
}

/// `Start EmitGroups, x`: what the function value is when passed to `@Run`.
pub fn start_emit_groups_f(comps_p0: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>, deps_p1: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>, done_p2: crate::prelude::Array<crate::prelude::Nat>, acc_p3: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>>> {
    ::std::rc::Rc::new(EmitGroups { comps_p0, deps_p1, done_p2, acc_p3 })
}

/// ```prism
/// IsHold: fn Stmt -> Bool
/// ```
pub fn is_hold_f(s_p0: &crate::syntax::Stmt) -> bool {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SBind(_, _, ::std::option::Option::Some(_)) => true,
        _ => false,
    }
}

/// ```prism
/// IsLetLike: fn Stmt -> Bool
/// ```
pub fn is_let_like_f(s_p0: &crate::syntax::Stmt) -> bool {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SLet(_, _, _) => true,
        crate::syntax::StmtKind::SFn(_) => true,
        crate::syntax::StmtKind::SSignature(_) => true,
        _ => false,
    }
}

/// ```prism
/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub fn infer_widget_block_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block) -> (crate::check::types::Ty, crate::check::types::St) {
    infer_widget_block_at_f(env_p0, st_p1, b_p2, &::std::option::Option::None)
}

/// The step machine of `InferWidgetBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub struct InferWidgetBlock {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferWidgetBlock {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(InferWidgetBlockAt { env_p0: env_p0.clone(), st_p1: st_p1.clone(), b_p2: b_p2.clone(), expected_o3: ::std::option::Option::None }))
    }
}

/// `Start InferWidgetBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_widget_block_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferWidgetBlock { env_p0, st_p1, b_p2 })
}

/// ```prism
/// InferWidgetBlockAt: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
/// ```
pub fn infer_widget_block_at_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block, expected_o3: &::std::option::Option<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St) {
    let (env1_p7, st1_p8) = block_row_f(env_p0, &crate::check::expr::patterns::block_bound_once_f(env_p0, st_p1, &b_p2.stmts_p), &b_p2.stmts_p);
    let (env2_pc, st2_pd) = crate::prelude::run_to_end(crate::prelude::fold_job(b_p2.stmts_p.clone(), (env1_p7.clone(), st1_p8.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (en_p9, s_pa) = p0;
        let stmt_pb = p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindStmt { env_p0: en_p9.clone(), st_p1: s_pa.clone(), s_p2: stmt_pb.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>));
    let n_p4 = crate::prelude::len(&b_p2.stmts_p);
    let (env3_pp, st3_pq, res_or) = crate::prelude::run_to_end(crate::prelude::fold_job(widget_group_order_f(&b_p2.stmts_p), (env2_pc.clone(), st2_pd.clone(), ::std::option::Option::None), {
        let b_p2x = b_p2.clone();
        let expected_o3x = expected_o3.clone();
        let n_p4x = n_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>), crate::prelude::Nat)| {
            let b_p2xy = b_p2x.clone();
            let expected_o3xy = expected_o3x.clone();
            let n_p4xy = n_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (en_pe, s_pf, r_og) = p0;
                let i_ph = p1;
                {
                    let stmt_pi = crate::prelude::or(&crate::prelude::index(&b_p2xy.stmts_p, &i_ph), &dummy_stmt2_p());
                    let r_ogz = r_og.clone();
                    let k_let7122 = move |v7122: (crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)| {
                        let (en2_pl, s2_pm, r2_on) = v7122;
                        match &r2_on {
                            ::std::option::Option::Some(t_po) => ::prism_rtl::Turn::Finished((en2_pl.clone(), s2_pm.clone(), ::std::option::Option::Some(t_po.clone()))),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished((en2_pl.clone(), s2_pm.clone(), r_ogz.clone())),
                        }
                    };
                    match (expected_o3xy.clone(), stmt_pi.kind_p.clone()) {
                        (::std::option::Option::Some(want_pj), crate::syntax::StmtKind::SExpr(e_pk)) if ((&(&i_ph + &crate::prelude::Nat::from(1u32)) == &n_p4xy) && is_element_match_f(&en_pe, &s_pf, &e_pk)) => crate::prelude::call_then(crate::check::expr::start_check_f(en_pe.clone(), s_pf.clone(), e_pk.clone(), crate::check::types::Ty::TyAt(::std::rc::Rc::new(want_pj.clone()), en_pe.scope_p.clone())), move |check_f_7259: crate::check::types::St| k_let7122((en_pe.clone(), check_f_7259, ::std::option::Option::Some(want_pj.clone())))),
                        _ => crate::prelude::call_then(start_widget_stmt_f(en_pe.clone(), s_pf.clone(), stmt_pi.clone(), crate::check::expr::lets::local_clauses_f(&b_p2xy.stmts_p, &i_ph), &(&i_ph + &crate::prelude::Nat::from(1u32)) == &n_p4xy), move |widget_stmt_f_7333: (crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)| k_let7122(widget_stmt_f_7333)),
                        _ => unreachable!("no arm matched"),
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)>>>
    }));
    let st4_p5 = crate::check::passes::cycles::block_prompt_cycles_f(&env3_pp, &st3_pq, b_p2);
    let st5_p6 = if st4_p5.recording_p {
        crate::check::types::recording::note_group_f(&st4_p5, &b_p2.span_p, &crate::prelude::Text::lit("widget"), &dep_order_f(&b_p2.stmts_p))
    } else {
        st4_p5.clone()
    };
    (crate::prelude::or(&res_or, &crate::check::types::t_unit_p()), st5_p6.clone())
}

/// The step machine of `InferWidgetBlockAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferWidgetBlockAt: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
/// ```
pub struct InferWidgetBlockAt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
    pub expected_o3: ::std::option::Option<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferWidgetBlockAt {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        let expected_o3 = &self.expected_o3;
        let expected_o3x = expected_o3.clone();
        let b_p2x = b_p2.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::patterns::start_block_bound_once_f(env_p0x.clone(), st_p1x.clone(), b_p2x.stmts_p.clone()), move |block_bound_once_f_6804: crate::check::types::St| crate::prelude::call_then(start_block_row_f(env_p0x.clone(), block_bound_once_f_6804, b_p2x.stmts_p.clone()), move |block_row_f_6789: (crate::check::expr::Env, crate::check::types::St)| {
            let (env1_p7, st1_p8) = block_row_f_6789;
            crate::prelude::call_value(crate::prelude::fold_job(b_p2x.stmts_p.clone(), (env1_p7.clone(), st1_p8.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (en_p9, s_pa) = p0;
                let stmt_pb = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindStmt { env_p0: en_p9.clone(), st_p1: s_pa.clone(), s_p2: stmt_pb.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>), move |fold_6870: (crate::check::expr::Env, crate::check::types::St)| {
                let (env2_pc, st2_pd) = fold_6870;
                let n_p4 = crate::prelude::len(&b_p2x.stmts_p);
                crate::prelude::call_then(start_widget_group_order_f(b_p2x.stmts_p.clone()), move |widget_group_order_f_7002: crate::prelude::Array<crate::prelude::Nat>| crate::prelude::call_value(crate::prelude::fold_job(widget_group_order_f_7002, (env2_pc.clone(), st2_pd.clone(), ::std::option::Option::None), {
                    let b_p2xx = b_p2x.clone();
                    let expected_o3xx = expected_o3x.clone();
                    let n_p4x = n_p4.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>), crate::prelude::Nat)| {
                        let b_p2xxy = b_p2xx.clone();
                        let expected_o3xxy = expected_o3xx.clone();
                        let n_p4xy = n_p4x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (en_pe, s_pf, r_og) = p0;
                            let i_ph = p1;
                            {
                                let stmt_pi = crate::prelude::or(&crate::prelude::index(&b_p2xxy.stmts_p, &i_ph), &dummy_stmt2_p());
                                let r_ogz = r_og.clone();
                                let k_let7122 = move |v7122: (crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)| {
                                    let (en2_pl, s2_pm, r2_on) = v7122;
                                    match &r2_on {
                                        ::std::option::Option::Some(t_po) => ::prism_rtl::Turn::Finished((en2_pl.clone(), s2_pm.clone(), ::std::option::Option::Some(t_po.clone()))),
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((en2_pl.clone(), s2_pm.clone(), r_ogz.clone())),
                                    }
                                };
                                match (expected_o3xxy.clone(), stmt_pi.kind_p.clone()) {
                                    (::std::option::Option::Some(want_pj), crate::syntax::StmtKind::SExpr(e_pk)) if ((&(&i_ph + &crate::prelude::Nat::from(1u32)) == &n_p4xy) && is_element_match_f(&en_pe, &s_pf, &e_pk)) => crate::prelude::call_then(crate::check::expr::start_check_f(en_pe.clone(), s_pf.clone(), e_pk.clone(), crate::check::types::Ty::TyAt(::std::rc::Rc::new(want_pj.clone()), en_pe.scope_p.clone())), move |check_f_7259: crate::check::types::St| k_let7122((en_pe.clone(), check_f_7259, ::std::option::Option::Some(want_pj.clone())))),
                                    _ => crate::prelude::call_then(start_widget_stmt_f(en_pe.clone(), s_pf.clone(), stmt_pi.clone(), crate::check::expr::lets::local_clauses_f(&b_p2xxy.stmts_p, &i_ph), &(&i_ph + &crate::prelude::Nat::from(1u32)) == &n_p4xy), move |widget_stmt_f_7333: (crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)| k_let7122(widget_stmt_f_7333)),
                                    _ => unreachable!("no arm matched"),
                                }
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)>>>
                }), move |fold_6996: (crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)| {
                    let (env3_pp, st3_pq, res_or) = fold_6996;
                    crate::prelude::call_then(crate::check::passes::cycles::start_block_prompt_cycles_f(env3_pp.clone(), st3_pq.clone(), b_p2x.clone()), move |block_prompt_cycles_f_7495: crate::check::types::St| {
                        let st4_p5 = block_prompt_cycles_f_7495;
                        let res_orz = res_or.clone();
                        let k_let7530 = move |v7530: crate::check::types::St| {
                            let st5_p6 = v7530;
                            ::prism_rtl::Turn::Finished((crate::prelude::or(&res_orz, &crate::check::types::t_unit_p()), st5_p6.clone()))
                        };
                        if st4_p5.recording_p {
                            crate::prelude::call_then(start_dep_order_f(b_p2x.stmts_p.clone()), move |dep_order_f_7592: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>| k_let7530(crate::check::types::recording::note_group_f(&st4_p5, &b_p2x.span_p, &crate::prelude::Text::lit("widget"), &dep_order_f_7592)))
                        } else {
                            k_let7530(st4_p5.clone())
                        }
                    })
                }))
            })
        }))
    }
}

/// `Start InferWidgetBlockAt, x`: what the function value is when passed to `@Run`.
pub fn start_infer_widget_block_at_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block, expected_o3: ::std::option::Option<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferWidgetBlockAt { env_p0, st_p1, b_p2, expected_o3 })
}

/// ```prism
/// IsElementMatch: unbounded fn Env, St, Expr -> Bool
/// ```
pub fn is_element_match_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> bool {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EMatch(scrutinee_p3, _) => {
            let (t_p4, inferred_p5) = crate::check::expr::infer_f(env_p0, st_p1, &**scrutinee_p3);
            match crate::check::types::recording::walk_f(&inferred_p5, &t_p4) {
                crate::check::types::Ty::TyElem(_, _) => true,
                _ => false,
            }
        },
        _ => false,
    }
}

/// The step machine of `IsElementMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsElementMatch: unbounded fn Env, St, Expr -> Bool
/// ```
pub struct IsElementMatch {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for IsElementMatch {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EMatch(scrutinee_p3, _) => {
                let env_p0x = env_p0.clone();
                let scrutinee_p3x = (**scrutinee_p3).clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), scrutinee_p3x.clone()), move |infer_f_8004: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p4, inferred_p5) = infer_f_8004;
                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(inferred_p5.clone(), t_p4.clone()), move |walk_f_8043: crate::check::types::Ty| match walk_f_8043 {
                        crate::check::types::Ty::TyElem(_, _) => ::prism_rtl::Turn::Finished(true),
                        _ => ::prism_rtl::Turn::Finished(false),
                    })
                })
            },
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsElementMatch, x`: what the function value is when passed to `@Run`.
pub fn start_is_element_match_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsElementMatch { env_p0, st_p1, e_p2 })
}

/// ```prism
/// let dummyStmt2
/// ```
pub fn dummy_stmt2_p() -> crate::syntax::Stmt {
    crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub fn block_row_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, stmts_p2: &crate::prelude::Array<crate::syntax::Stmt>) -> (crate::check::expr::Env, crate::check::types::St) {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(stmts_p2)), (env_p0.clone(), st_p1.clone()), {
        let stmts_p2x = stmts_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)| {
            let stmts_p2xy = stmts_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (en_p3, s_p4) = p0;
                let i_p5 = p1;
                match crate::prelude::index(&stmts_p2xy, &i_p5) {
                    ::std::option::Option::Some(stmt_p6) => match &stmt_p6.kind_p {
                        crate::syntax::StmtKind::SEmit(row_decl_p7) => if &i_p5 > &crate::prelude::Nat::from(0u32) {
                            ::prism_rtl::Turn::Finished((en_p3.clone(), crate::check::types::recording::err_fix_f(&s_p4, &crate::prelude::Text::lit("emit-element"), &stmt_p6.span_p, &crate::prelude::Text::lit("`emit` comes first in its block"), &crate::prelude::Text::lit("move this line to the top of the block"))))
                        } else {
                            {
                                let row_decl_p7x = row_decl_p7.clone();
                                crate::prelude::call_then(crate::check::env::reading::start_conv_row_f(crate::check::expr::env_cx_f(&en_p3), s_p4.clone(), row_as_type_f(&row_decl_p7x)), move |conv_row_f_8758: (crate::check::types::Rw, crate::check::types::St)| {
                                    let (rw_p9, s2_pa) = conv_row_f_8758;
                                    let en2_p8 = {
                                        let mut this: crate::check::expr::Env = en_p3.clone();
                                        this.scope_p = resolve_scope_row_f(&en_p3, &rw_p9);
                                        this
                                    };
                                    ::prism_rtl::Turn::Finished((en2_p8.clone(), s2_pa.clone()))
                                })
                            }
                        },
                        _ => ::prism_rtl::Turn::Finished((en_p3.clone(), s_p4.clone())),
                    },
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished((en_p3.clone(), s_p4.clone())),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
    }))
}

/// The step machine of `BlockRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub struct BlockRow {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub stmts_p2: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BlockRow {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let stmts_p2 = &self.stmts_p2;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(stmts_p2)), (env_p0.clone(), st_p1.clone()), {
            let stmts_p2x = stmts_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)| {
                let stmts_p2xy = stmts_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (en_p3, s_p4) = p0;
                    let i_p5 = p1;
                    match crate::prelude::index(&stmts_p2xy, &i_p5) {
                        ::std::option::Option::Some(stmt_p6) => match &stmt_p6.kind_p {
                            crate::syntax::StmtKind::SEmit(row_decl_p7) => if &i_p5 > &crate::prelude::Nat::from(0u32) {
                                ::prism_rtl::Turn::Finished((en_p3.clone(), crate::check::types::recording::err_fix_f(&s_p4, &crate::prelude::Text::lit("emit-element"), &stmt_p6.span_p, &crate::prelude::Text::lit("`emit` comes first in its block"), &crate::prelude::Text::lit("move this line to the top of the block"))))
                            } else {
                                {
                                    let row_decl_p7x = row_decl_p7.clone();
                                    crate::prelude::call_then(crate::check::env::reading::start_conv_row_f(crate::check::expr::env_cx_f(&en_p3), s_p4.clone(), row_as_type_f(&row_decl_p7x)), move |conv_row_f_8758: (crate::check::types::Rw, crate::check::types::St)| {
                                        let (rw_p9, s2_pa) = conv_row_f_8758;
                                        let en2_p8 = {
                                            let mut this: crate::check::expr::Env = en_p3.clone();
                                            this.scope_p = resolve_scope_row_f(&en_p3, &rw_p9);
                                            this
                                        };
                                        ::prism_rtl::Turn::Finished((en2_p8.clone(), s2_pa.clone()))
                                    })
                                }
                            },
                            _ => ::prism_rtl::Turn::Finished((en_p3.clone(), s_p4.clone())),
                        },
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((en_p3.clone(), s_p4.clone())),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start BlockRow, x`: what the function value is when passed to `@Run`.
pub fn start_block_row_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, stmts_p2: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(BlockRow { env_p0, st_p1, stmts_p2 })
}

/// ```prism
/// RowAsType: fn Row -> Type
/// ```
pub fn row_as_type_f(row_decl_p0: &crate::syntax::Row) -> crate::syntax::Type {
    crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TRowUnion(crate::prelude::each(&row_decl_p0.terms_p, &row_term_type_f))), span_p: row_decl_p0.span_p.clone() }
}

/// ```prism
/// RowTermType: fn RowTerm -> Type
/// ```
pub fn row_term_type_f(row_term0: &crate::syntax::RowTerm) -> crate::syntax::Type {
    match row_term0 {
        crate::syntax::RowTerm::RFamily(q_p0) => crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TFamily(q_p0.clone())), span_p: q_p0.span_p.clone() },
        crate::syntax::RowTerm::RVar(v_p1) => crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TName(crate::syntax::SName { sigils_p: crate::prelude::Text::lit(""), path_p: crate::prelude::Array::from(vec![v_p1.name_p.clone()]), span_p: v_p1.span_p.clone() }, crate::prelude::Array::new())), span_p: v_p1.span_p.clone() },
        crate::syntax::RowTerm::RType(t_p2) => t_p2.clone(),
    }
}

/// ```prism
/// ResolveScopeRow: fn Env, Rw -> Rw
/// ```
pub fn resolve_scope_row_f(env_p0: &crate::check::expr::Env, rw_p1: &crate::check::types::Rw) -> crate::check::types::Rw {
    match &rw_p1.tail_p {
        crate::check::types::Tail::TlQ(v_p2) => crate::check::types::Rw { fams_p: rw_p1.fams_p.clone(), minus_p: rw_p1.minus_p.clone(), tail_p: env_p0.scope_p.tail_p.clone() },
        _ => rw_p1.clone(),
    }
}

/// ```prism
/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub fn pre_bind_stmt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, s_p2: &crate::syntax::Stmt) -> (crate::check::expr::Env, crate::check::types::St) {
    match &s_p2.kind_p {
        crate::syntax::StmtKind::SBind(p_p3, _, _) => pre_bind_pattern_f(env_p0, st_p1, p_p3),
        crate::syntax::StmtKind::SLet(_, _, _) => crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2),
        crate::syntax::StmtKind::SFn(_) => crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2),
        crate::syntax::StmtKind::SSignature(_) => crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2),
        crate::syntax::StmtKind::SWidget(w_p4) => {
            let (v_p5, st2_p6) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
            crate::check::expr::bind_local_id_f(&crate::check::expr::with_local_f(env_p0, &crate::check::env::sname_key_f(&w_p4.name_p), &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyAt(::std::rc::Rc::new(v_p5.clone()), env_p0.scope_p.clone()))), &st2_p6, &crate::check::env::sname_key_f(&w_p4.name_p), &w_p4.name_p.span_p)
        },
        _ => (env_p0.clone(), st_p1.clone()),
    }
}

/// The step machine of `PreBindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub struct PreBindStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub s_p2: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for PreBindStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let s_p2 = &self.s_p2;
        match &s_p2.kind_p {
            crate::syntax::StmtKind::SBind(p_p3, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p3.clone() })),
            crate::syntax::StmtKind::SLet(_, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::lets::PreBind { env_p0: env_p0.clone(), st_p1: st_p1.clone(), s_p2: s_p2.clone() })),
            crate::syntax::StmtKind::SFn(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::lets::PreBind { env_p0: env_p0.clone(), st_p1: st_p1.clone(), s_p2: s_p2.clone() })),
            crate::syntax::StmtKind::SSignature(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::lets::PreBind { env_p0: env_p0.clone(), st_p1: st_p1.clone(), s_p2: s_p2.clone() })),
            crate::syntax::StmtKind::SWidget(w_p4) => {
                let (v_p5, st2_p6) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
                ::prism_rtl::Turn::Finished(crate::check::expr::bind_local_id_f(&crate::check::expr::with_local_f(env_p0, &crate::check::env::sname_key_f(&w_p4.name_p), &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyAt(::std::rc::Rc::new(v_p5.clone()), env_p0.scope_p.clone()))), &st2_p6, &crate::check::env::sname_key_f(&w_p4.name_p), &w_p4.name_p.span_p))
            },
            _ => ::prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
        }
    }
}

/// `Start PreBindStmt, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_stmt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, s_p2: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(PreBindStmt { env_p0, st_p1, s_p2 })
}

/// ```prism
/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
/// ```
pub fn pre_bind_pattern_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern) -> (crate::check::expr::Env, crate::check::types::St) {
    crate::prelude::fold(&crate::check::env::names::pattern_binders_f(p_p2), &(env_p0.clone(), st_p1.clone()), &(|(en_p3, s_p4): &(crate::check::expr::Env, crate::check::types::St), (name_p5, at_p6): &(crate::prelude::Text, crate::syntax::Range)| {
        let (v_pa, s1_pb) = crate::check::types::fresh_var_f(s_p4, &true, name_p5);
        let s2_p7 = crate::check::types::recording::at_binder_f(&s1_pb, &v_pa, at_p6);
        let (rw_pc, s3_pd) = crate::check::types::recording::fresh_row_f(&s2_p7, &crate::prelude::Array::new());
        let t_p8 = crate::check::types::with_marks_f(&crate::check::expr::lets::type_marks_f(&crate::check::types::unify::marks_of_f(name_p5)), &v_pa, &rw_pc);
        let en2_p9 = {
            let mut this: crate::check::expr::Env = crate::check::expr::with_local_f(en_p3, name_p5, &crate::check::types::schemes::mono_f(&t_p8));
            this.pending_p = crate::check::types::add_text_f(&this.pending_p, name_p5);
            this
        };
        crate::check::expr::bind_local_id_f(&en2_p9, &s3_pd, name_p5, at_p6)
    }))
}

/// The step machine of `PreBindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
/// ```
pub struct PreBindPattern {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for PreBindPattern {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let env_p0x = env_p0.clone();
        let p_p2x = p_p2.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::env::names::start_pattern_binders_f(p_p2x.clone()), move |pattern_binders_f_10319: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&pattern_binders_f_10319, &(env_p0x.clone(), st_p1x.clone()), &(|(en_p3, s_p4): &(crate::check::expr::Env, crate::check::types::St), (name_p5, at_p6): &(crate::prelude::Text, crate::syntax::Range)| {
            let (v_pa, s1_pb) = crate::check::types::fresh_var_f(s_p4, &true, name_p5);
            let s2_p7 = crate::check::types::recording::at_binder_f(&s1_pb, &v_pa, at_p6);
            let (rw_pc, s3_pd) = crate::check::types::recording::fresh_row_f(&s2_p7, &crate::prelude::Array::new());
            let t_p8 = crate::check::types::with_marks_f(&crate::check::expr::lets::type_marks_f(&crate::check::types::unify::marks_of_f(name_p5)), &v_pa, &rw_pc);
            let en2_p9 = {
                let mut this: crate::check::expr::Env = crate::check::expr::with_local_f(en_p3, name_p5, &crate::check::types::schemes::mono_f(&t_p8));
                this.pending_p = crate::check::types::add_text_f(&this.pending_p, name_p5);
                this
            };
            crate::check::expr::bind_local_id_f(&en2_p9, &s3_pd, name_p5, at_p6)
        }))))
    }
}

/// `Start PreBindPattern, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_pattern_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(PreBindPattern { env_p0, st_p1, p_p2 })
}

/// ```prism
/// WidgetStmt: unbounded fn Env, St, Stmt, [FnClause], Bool -> ((Env, St, ?Ty))
/// ```
pub fn widget_stmt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, s_p2: &crate::syntax::Stmt, clauses_p3: &crate::prelude::Array<crate::syntax::decls::FnClause>, last_p4: &bool) -> (crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>) {
    match &s_p2.kind_p {
        crate::syntax::StmtKind::SEmit(_) => (env_p0.clone(), st_p1.clone(), if *last_p4 {
            ::std::option::Option::Some(crate::check::types::t_unit_p())
        } else {
            ::std::option::Option::None
        }),
        crate::syntax::StmtKind::SBind(p_p5, e_p6, ::std::option::Option::None) => {
            let st2_p7 = bind_stmt_f(env_p0, st_p1, p_p5, e_p6, &s_p2.span_p);
            (env_p0.clone(), st2_p7.clone(), if *last_p4 {
                ::std::option::Option::Some(crate::check::types::t_unit_p())
            } else {
                ::std::option::Option::None
            })
        },
        crate::syntax::StmtKind::SBind(p_p8, init_p9, ::std::option::Option::Some(step_pa)) => {
            let st2_pb = hold_stmt_f(env_p0, st_p1, p_p8, init_p9, step_pa, &s_p2.span_p);
            (env_p0.clone(), st2_pb.clone(), if *last_p4 {
                ::std::option::Option::Some(crate::check::types::t_unit_p())
            } else {
                ::std::option::Option::None
            })
        },
        crate::syntax::StmtKind::SIgnore(e_pc) => {
            let st2_pd = ignore_stmt_f(env_p0, st_p1, e_pc, &s_p2.span_p);
            (env_p0.clone(), st2_pd.clone(), if *last_p4 {
                ::std::option::Option::Some(crate::check::types::t_unit_p())
            } else {
                ::std::option::Option::None
            })
        },
        crate::syntax::StmtKind::SLet(p_pe, ty_of, e_pg) => {
            let (env2_ph, st2_pi) = crate::check::expr::lets::check_let_f(env_p0, st_p1, p_pe, ty_of, e_pg, &s_p2.span_p);
            (env2_ph.clone(), st2_pi.clone(), if *last_p4 {
                ::std::option::Option::Some(crate::check::types::t_unit_p())
            } else {
                ::std::option::Option::None
            })
        },
        crate::syntax::StmtKind::SFn(f_pj) => {
            let (env2_pk, st2_pl) = crate::check::expr::lets::check_local_fn_f(env_p0, st_p1, clauses_p3, &s_p2.span_p);
            (env2_pk.clone(), st2_pl.clone(), if *last_p4 {
                ::std::option::Option::Some(crate::check::types::t_unit_p())
            } else {
                ::std::option::Option::None
            })
        },
        crate::syntax::StmtKind::SSignature(_) => (env_p0.clone(), st_p1.clone(), if *last_p4 {
            ::std::option::Option::Some(crate::check::types::t_unit_p())
        } else {
            ::std::option::Option::None
        }),
        crate::syntax::StmtKind::SWidget(w_pm) => {
            let (t_po, st2_pp) = infer_widget_block_f(env_p0, st_p1, &w_pm.body_p);
            let st3_pn = match crate::prelude::get(&env_p0.locals_p, &crate::check::env::sname_key_f(&w_pm.name_p)) {
                ::std::option::Option::Some(sc_pq) => crate::check::types::unify::unify_f(&st2_pp, &sc_pq.ty_p, &crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_po.clone()), env_p0.scope_p.clone()), &w_pm.span_p),
                ::std::option::Option::None => st2_pp.clone(),
            };
            (env_p0.clone(), st3_pn.clone(), if *last_p4 {
                ::std::option::Option::Some(crate::check::types::t_unit_p())
            } else {
                ::std::option::Option::None
            })
        },
        crate::syntax::StmtKind::SExpr(e_pr) => {
            let (t_ps, st2_pt) = bare_line_f(env_p0, st_p1, e_pr, last_p4);
            if *last_p4 {
                (env_p0.clone(), st2_pt.clone(), ::std::option::Option::Some(t_ps.clone()))
            } else {
                (env_p0.clone(), st2_pt.clone(), ::std::option::Option::None)
            }
        },
        _ => (env_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &s_p2.span_p, &crate::prelude::Text::lit("this statement belongs in a `given:` or `update` block")), if *last_p4 {
            ::std::option::Option::Some(crate::check::types::t_unit_p())
        } else {
            ::std::option::Option::None
        }),
    }
}

/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetStmt: unbounded fn Env, St, Stmt, [FnClause], Bool -> ((Env, St, ?Ty))
/// ```
pub struct WidgetStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub s_p2: crate::syntax::Stmt,
    pub clauses_p3: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub last_p4: bool,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)> for WidgetStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let s_p2 = &self.s_p2;
        let clauses_p3 = &self.clauses_p3;
        let last_p4 = &self.last_p4;
        match &s_p2.kind_p {
            crate::syntax::StmtKind::SEmit(_) => ::prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone(), if *last_p4 {
                ::std::option::Option::Some(crate::check::types::t_unit_p())
            } else {
                ::std::option::Option::None
            })),
            crate::syntax::StmtKind::SBind(p_p5, e_p6, ::std::option::Option::None) => {
                let e_p6x = e_p6.clone();
                let env_p0x = env_p0.clone();
                let last_p4x = *last_p4;
                let p_p5x = p_p5.clone();
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_bind_stmt_f(env_p0x.clone(), st_p1x.clone(), p_p5x.clone(), e_p6x.clone(), s_p2x.span_p.clone()), move |bind_stmt_f_10983: crate::check::types::St| {
                    let st2_p7 = bind_stmt_f_10983;
                    ::prism_rtl::Turn::Finished((env_p0x.clone(), st2_p7.clone(), if last_p4x {
                        ::std::option::Option::Some(crate::check::types::t_unit_p())
                    } else {
                        ::std::option::Option::None
                    }))
                })
            },
            crate::syntax::StmtKind::SBind(p_p8, init_p9, ::std::option::Option::Some(step_pa)) => {
                let env_p0x = env_p0.clone();
                let init_p9x = init_p9.clone();
                let last_p4x = *last_p4;
                let p_p8x = p_p8.clone();
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                let step_pax = step_pa.clone();
                crate::prelude::call_then(start_hold_stmt_f(env_p0x.clone(), st_p1x.clone(), p_p8x.clone(), init_p9x.clone(), step_pax.clone(), s_p2x.span_p.clone()), move |hold_stmt_f_11110: crate::check::types::St| {
                    let st2_pb = hold_stmt_f_11110;
                    ::prism_rtl::Turn::Finished((env_p0x.clone(), st2_pb.clone(), if last_p4x {
                        ::std::option::Option::Some(crate::check::types::t_unit_p())
                    } else {
                        ::std::option::Option::None
                    }))
                })
            },
            crate::syntax::StmtKind::SIgnore(e_pc) => {
                let e_pcx = e_pc.clone();
                let env_p0x = env_p0.clone();
                let last_p4x = *last_p4;
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_ignore_stmt_f(env_p0x.clone(), st_p1x.clone(), e_pcx.clone(), s_p2x.span_p.clone()), move |ignore_stmt_f_11232: crate::check::types::St| {
                    let st2_pd = ignore_stmt_f_11232;
                    ::prism_rtl::Turn::Finished((env_p0x.clone(), st2_pd.clone(), if last_p4x {
                        ::std::option::Option::Some(crate::check::types::t_unit_p())
                    } else {
                        ::std::option::Option::None
                    }))
                })
            },
            crate::syntax::StmtKind::SLet(p_pe, ty_of, e_pg) => {
                let ty_ofx = ty_of.clone();
                let e_pgx = e_pg.clone();
                let env_p0x = env_p0.clone();
                let last_p4x = *last_p4;
                let p_pex = p_pe.clone();
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lets::start_check_let_f(env_p0x.clone(), st_p1x.clone(), p_pex.clone(), ty_ofx.clone(), e_pgx.clone(), s_p2x.span_p.clone()), move |check_let_f_11359: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2_ph, st2_pi) = check_let_f_11359;
                    ::prism_rtl::Turn::Finished((env2_ph.clone(), st2_pi.clone(), if last_p4x {
                        ::std::option::Option::Some(crate::check::types::t_unit_p())
                    } else {
                        ::std::option::Option::None
                    }))
                })
            },
            crate::syntax::StmtKind::SFn(f_pj) => {
                let clauses_p3x = clauses_p3.clone();
                let env_p0x = env_p0.clone();
                let last_p4x = *last_p4;
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lets::start_check_local_fn_f(env_p0x.clone(), st_p1x.clone(), clauses_p3x.clone(), s_p2x.span_p.clone()), move |check_local_fn_f_11484: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2_pk, st2_pl) = check_local_fn_f_11484;
                    ::prism_rtl::Turn::Finished((env2_pk.clone(), st2_pl.clone(), if last_p4x {
                        ::std::option::Option::Some(crate::check::types::t_unit_p())
                    } else {
                        ::std::option::Option::None
                    }))
                })
            },
            crate::syntax::StmtKind::SSignature(_) => ::prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone(), if *last_p4 {
                ::std::option::Option::Some(crate::check::types::t_unit_p())
            } else {
                ::std::option::Option::None
            })),
            crate::syntax::StmtKind::SWidget(w_pm) => {
                let env_p0x = env_p0.clone();
                let last_p4x = *last_p4;
                let st_p1x = st_p1.clone();
                let w_pmx = w_pm.clone();
                crate::prelude::call_then(start_infer_widget_block_f(env_p0x.clone(), st_p1x.clone(), w_pmx.body_p.clone()), move |infer_widget_block_f_11675: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_po, st2_pp) = infer_widget_block_f_11675;
                    let env_p0xz = env_p0x.clone();
                    let last_p4xz = last_p4x;
                    let k_let11716 = move |v11716: crate::check::types::St| {
                        let st3_pn = v11716;
                        ::prism_rtl::Turn::Finished((env_p0xz.clone(), st3_pn.clone(), if last_p4xz {
                            ::std::option::Option::Some(crate::check::types::t_unit_p())
                        } else {
                            ::std::option::Option::None
                        }))
                    };
                    match crate::prelude::get(&env_p0x.locals_p, &crate::check::env::sname_key_f(&w_pmx.name_p)) {
                        ::std::option::Option::Some(sc_pq) => crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pp.clone(), sc_pq.ty_p.clone(), crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_po.clone()), env_p0x.scope_p.clone()), w_pmx.span_p.clone()), move |unify_f_11779: crate::check::types::St| k_let11716(unify_f_11779)),
                        ::std::option::Option::None => k_let11716(st2_pp.clone()),
                    }
                })
            },
            crate::syntax::StmtKind::SExpr(e_pr) => {
                let e_prx = e_pr.clone();
                let env_p0x = env_p0.clone();
                let last_p4x = *last_p4;
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_bare_line_f(env_p0x.clone(), st_p1x.clone(), e_prx.clone(), last_p4x), move |bare_line_f_11933: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_ps, st2_pt) = bare_line_f_11933;
                    if last_p4x {
                        ::prism_rtl::Turn::Finished((env_p0x.clone(), st2_pt.clone(), ::std::option::Option::Some(t_ps.clone())))
                    } else {
                        ::prism_rtl::Turn::Finished((env_p0x.clone(), st2_pt.clone(), ::std::option::Option::None))
                    }
                })
            },
            _ => ::prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &s_p2.span_p, &crate::prelude::Text::lit("this statement belongs in a `given:` or `update` block")), if *last_p4 {
                ::std::option::Option::Some(crate::check::types::t_unit_p())
            } else {
                ::std::option::Option::None
            })),
        }
    }
}

/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
pub fn start_widget_stmt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, s_p2: crate::syntax::Stmt, clauses_p3: crate::prelude::Array<crate::syntax::decls::FnClause>, last_p4: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)>> {
    ::std::rc::Rc::new(WidgetStmt { env_p0, st_p1, s_p2, clauses_p3, last_p4 })
}

/// ```prism
/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
/// ```
pub fn bind_stmt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern, e_p3: &crate::syntax::Expr, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    let (out_p5, st2_p6) = bound_value_f(env_p0, st_p1, e_p3);
    let (_, st3_p7) = crate::check::expr::patterns::bind_pattern_f(env_p0, &st2_p6, p_p2, &out_p5, &false);
    crate::check::passes::always_matches_f(env_p0, &st3_p7, p_p2, &out_p5, &crate::prelude::Text::lit("`<-`"))
}

/// The step machine of `BindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
/// ```
pub struct BindStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern,
    pub e_p3: crate::syntax::Expr,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for BindStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let e_p3 = &self.e_p3;
        let span_p4 = &self.span_p4;
        let e_p3x = e_p3.clone();
        let env_p0x = env_p0.clone();
        let p_p2x = p_p2.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_bound_value_f(env_p0x.clone(), st_p1x.clone(), e_p3x.clone()), move |bound_value_f_12550: (crate::check::types::Ty, crate::check::types::St)| {
            let (out_p5, st2_p6) = bound_value_f_12550;
            crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p0x.clone(), st2_p6.clone(), p_p2x.clone(), out_p5.clone(), false), move |bind_pattern_f_12598: (crate::check::expr::Env, crate::check::types::St)| {
                let (_, st3_p7) = bind_pattern_f_12598;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::passes::AlwaysMatches { env_p0: env_p0x.clone(), st_p1: st3_p7.clone(), p_p2: p_p2x.clone(), t_p3: out_p5.clone(), what_p4: crate::prelude::Text::lit("`<-`") }))
            })
        })
    }
}

/// `Start BindStmt, x`: what the function value is when passed to `@Run`.
pub fn start_bind_stmt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern, e_p3: crate::syntax::Expr, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(BindStmt { env_p0, st_p1, p_p2, e_p3, span_p4 })
}

/// ```prism
/// BoundValue: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub fn bound_value_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> (crate::check::types::Ty, crate::check::types::St) {
    if is_building_choice_f(env_p0, st_p1, e_p2) {
        bare_line_f(env_p0, st_p1, e_p2, &true)
    } else {
        {
            let (t_p3, st1_p4) = infer_built_f(env_p0, st_p1, e_p2);
            if is_builder_f(e_p2) {
                (t_p3.clone(), st1_p4.clone())
            } else {
                bind_output_f(env_p0, &st1_p4, &t_p3, &e_p2.span_p)
            }
        }
    }
}

/// The step machine of `BoundValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BoundValue: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub struct BoundValue {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BoundValue {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        if is_building_choice_f(env_p0, st_p1, e_p2) {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(BareLine { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: e_p2.clone(), last_p3: true }))
        } else {
            {
                let (t_p3, st1_p4) = infer_built_f(env_p0, st_p1, e_p2);
                if is_builder_f(e_p2) {
                    ::prism_rtl::Turn::Finished((t_p3.clone(), st1_p4.clone()))
                } else {
                    ::prism_rtl::Turn::Finished(bind_output_f(env_p0, &st1_p4, &t_p3, &e_p2.span_p))
                }
            }
        }
    }
}

/// `Start BoundValue, x`: what the function value is when passed to `@Run`.
pub fn start_bound_value_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(BoundValue { env_p0, st_p1, e_p2 })
}

/// ```prism
/// IsBuildingChoice: unbounded fn Env, St, Expr -> Bool
/// ```
pub fn is_building_choice_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> bool {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EMatch(_, _) => !is_element_match_f(env_p0, st_p1, e_p2),
        crate::syntax::ExprKind::EIf(_, _, _) => true,
        crate::syntax::ExprKind::EGroup(x_p3) => is_building_choice_f(env_p0, st_p1, &**x_p3),
        _ => false,
    }
}

/// ```prism
/// InferBuilt: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub fn infer_built_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::ERebuild(scrut_p3, body_p4) => {
            let (t_p5, st2_p6) = crate::check::blocks::structure::infer_rebuild_f(env_p0, st_p1, &**scrut_p3, body_p4, &e_p2.span_p);
            (t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &e_p2.span_p, &t_p5))
        },
        crate::syntax::ExprKind::EFor(binders_o7, source_p8, body_p9) => {
            let (t_pa, st2_pb) = crate::check::blocks::structure::infer_for_f(env_p0, st_p1, binders_o7, &**source_p8, body_p9, &e_p2.span_p);
            (t_pa.clone(), crate::check::types::recording::note_ty_f(&st2_pb, &e_p2.span_p, &t_pa))
        },
        crate::syntax::ExprKind::EGroup(x_pc) => {
            let (t_pd, st2_pe) = infer_built_f(env_p0, st_p1, &**x_pc);
            (t_pd.clone(), crate::check::types::recording::note_ty_f(&st2_pe, &e_p2.span_p, &t_pd))
        },
        _ => crate::check::expr::infer_f(env_p0, st_p1, e_p2),
    }
}

/// ```prism
/// IsBuilder: fn Expr -> Bool
/// ```
pub fn is_builder_f(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ERebuild(_, _) => true,
        crate::syntax::ExprKind::EFor(_, _, _) => true,
        crate::syntax::ExprKind::EGroup(x_p1) => is_builder_f(&**x_p1),
        _ => false,
    }
}

/// ```prism
/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
/// ```
pub fn bind_output_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::check::types::recording::walk_f(st_p1, t_p2) {
        crate::check::types::Ty::TyAt(inner_p4, rw_p5) => ((*inner_p4).clone(), add_incl_f(st_p1, &rw_p5, &env_p0.scope_p, span_p3, &crate::prelude::Text::lit("child"))),
        crate::check::types::Ty::TyElem(rw_p6, o_p7) => ((*o_p7).clone(), add_incl_f(st_p1, &rw_p6, &env_p0.scope_p, span_p3, &crate::prelude::Text::lit("element"))),
        crate::check::types::Ty::TySig(s_p8, inner_p9) => match crate::check::types::recording::walk_f(st_p1, &*inner_p9) {
            crate::check::types::Ty::TyAt(_, _) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("bind-dynamic"), span_p3, &crate::prelude::Text::from(format!("binding a `{}`; say what happens to the old widgets with `rebuild`", &crate::check::types::show_ty_f(st_p1, t_p2))), &crate::prelude::Text::lit("write `rebuild` over the dynamic, with the blueprint inside"))),
            crate::check::types::Ty::TyElem(_, _) => match lifted_element_o(st_p1, span_p3) {
                ::std::option::Option::Some(lift_pa) => (crate::check::types::Ty::TyErr, refuse_lifted_f(st_p1, &lift_pa)),
                ::std::option::Option::None => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("bind-dynamic"), span_p3, &crate::prelude::Text::from(format!("binding a `{}`, a {} of elements; say what happens to the old element with `rebuild`", &crate::check::types::show_ty_f(st_p1, t_p2), &(if &s_p8 == &crate::prelude::Text::lit("$") {
                    crate::prelude::Text::lit("dynamic")
                } else {
                    crate::prelude::Text::lit("event")
                }))), &crate::prelude::Text::lit("write `rebuild` over the dynamic field\'s value, with the element inside"))),
            },
            _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p3, &crate::prelude::Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &crate::check::types::show_ty_f(st_p1, t_p2))))),
        },
        crate::check::types::Ty::TyFlex(_) => {
            let (v_pb, st2_pc) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
            (v_pb.clone(), crate::check::types::unify::unify_f(&st2_pc, t_p2, &crate::check::types::Ty::TyAt(::std::rc::Rc::new(v_pb.clone()), env_p0.scope_p.clone()), span_p3))
        },
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st_p1.clone()),
        other_pd => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), span_p3, &crate::prelude::Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &crate::check::types::show_ty_f(st_p1, &other_pd))))),
    }
}

/// ```prism
/// ?LiftedElement: fn St, Range -> ?ElemLift
/// ```
pub fn lifted_element_o(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range) -> ::std::option::Option<crate::check::types::ElemLift> {
    crate::prelude::fold(&st_p0.elem_lifts_p, &::std::option::Option::None, &(|found_o2: &::std::option::Option<crate::check::types::ElemLift>, l_p3: &crate::check::types::ElemLift| match found_o2 {
        ::std::option::Option::Some(x_p4) => ::std::option::Option::Some(x_p4.clone()),
        ::std::option::Option::None => if ((&l_p3.file_p == &st_p0.file_p) && (&l_p3.arg_p.start_p >= &span_p1.start_p)) && (&l_p3.arg_p.end_p <= &span_p1.end_p) {
            ::std::option::Option::Some(l_p3.clone())
        } else {
            ::std::option::Option::None
        },
    }))
}

/// ```prism
/// RefuseLifted: fn St, ElemLift -> St
/// ```
pub fn refuse_lifted_f(st_p0: &crate::check::types::St, l_p1: &crate::check::types::ElemLift) -> crate::check::types::St {
    if &l_p1.layer_p == &crate::prelude::Text::lit("$") {
        crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("identity-dynamic"), &l_p1.arg_p, &crate::prelude::Text::from(format!("a dynamic in the identity field `{}`", &l_p1.field_p)), &crate::prelude::Text::from(format!("for a new element per value, write `rebuild {}:` with `{}({}=_, ...)` inside", &l_p1.src_p, &l_p1.owner_p, &l_p1.field_p)))
    } else {
        crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("identity-dynamic"), &l_p1.arg_p, &crate::prelude::Text::from(format!("an event in the identity field `{}`", &l_p1.field_p)), &crate::prelude::Text::from(format!("hold it first, `$x <- ... then {}`, and give the field the `$x`", &l_p1.src_p)))
    }
}

/// ```prism
/// AddIncl: fn St, Rw, Rw, Range, Text -> St
/// ```
pub fn add_incl_f(st_p0: &crate::check::types::St, sub_p1: &crate::check::types::Rw, sup_p2: &crate::check::types::Rw, span_p3: &crate::syntax::Range, what_p4: &crate::prelude::Text) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.incls_p = crate::prelude::push(&this.incls_p, &crate::check::types::Incl { sub_p: sub_p1.clone(), sup_p: sup_p2.clone(), file_p: this.file_p.clone(), span_p: span_p3.clone(), what_p: what_p4.clone(), forward_p: false });
    this
}

/// ```prism
/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
/// ```
pub fn hold_stmt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern, init_p3: &crate::syntax::Expr, step_p4: &crate::syntax::Expr, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    let (v_p8, st1_p9) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
    let held_p6 = crate::check::types::Ty::TySig(crate::prelude::Text::lit("$"), ::std::rc::Rc::new(v_p8.clone()));
    let (_, st2_pa) = crate::check::expr::patterns::bind_pattern_f(env_p0, &st1_p9, p_p2, &held_p6, &false);
    let st3_p7 = crate::check::expr::check_f(env_p0, &st2_pa, init_p3, &v_p8);
    let (step_ty_pb, st4_pc) = crate::check::expr::infer_f(env_p0, &st3_p7, step_p4);
    if (&crate::check::types::head_sigil_f(&st4_pc, &step_ty_pb) == &crate::prelude::Text::lit("!")) || (&step_ty_pb == &crate::check::types::Ty::TyErr) {
        crate::check::types::unify::unify_f(&st4_pc, &crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(v_p8.clone())), &step_ty_pb, &step_p4.span_p)
    } else {
        crate::check::types::recording::err_fix_f(&st4_pc, &crate::prelude::Text::lit("mismatch"), &step_p4.span_p, &crate::prelude::Text::from(format!("a hold\'s step is an event; this is `{}`", &crate::check::types::show_ty_f(&st4_pc, &step_ty_pb))), &crate::prelude::Text::lit("fire it with an event: `... on !e`"))
    }
}

/// The step machine of `HoldStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
/// ```
pub struct HoldStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern,
    pub init_p3: crate::syntax::Expr,
    pub step_p4: crate::syntax::Expr,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for HoldStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let init_p3 = &self.init_p3;
        let step_p4 = &self.step_p4;
        let span_p5 = &self.span_p5;
        let (v_p8, st1_p9) = crate::check::types::fresh_var_f(st_p1, &false, &crate::prelude::Text::lit(""));
        let held_p6 = crate::check::types::Ty::TySig(crate::prelude::Text::lit("$"), ::std::rc::Rc::new(v_p8.clone()));
        let env_p0x = env_p0.clone();
        let init_p3x = init_p3.clone();
        let p_p2x = p_p2.clone();
        let step_p4x = step_p4.clone();
        crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p0x.clone(), st1_p9.clone(), p_p2x.clone(), held_p6.clone(), false), move |bind_pattern_f_17579: (crate::check::expr::Env, crate::check::types::St)| {
            let (_, st2_pa) = bind_pattern_f_17579;
            crate::prelude::call_then(crate::check::expr::start_check_f(env_p0x.clone(), st2_pa.clone(), init_p3x.clone(), v_p8.clone()), move |check_f_17630: crate::check::types::St| {
                let st3_p7 = check_f_17630;
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st3_p7.clone(), step_p4x.clone()), move |infer_f_17680: (crate::check::types::Ty, crate::check::types::St)| {
                    let (step_ty_pb, st4_pc) = infer_f_17680;
                    crate::prelude::call_then(crate::check::types::start_head_sigil_f(st4_pc.clone(), step_ty_pb.clone()), move |head_sigil_f_17709: crate::prelude::Text| if (&head_sigil_f_17709 == &crate::prelude::Text::lit("!")) || (&step_ty_pb == &crate::check::types::Ty::TyErr) {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st4_pc.clone(), expected_p1: crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(v_p8.clone())), found_p2: step_ty_pb.clone(), span_p3: step_p4x.span_p.clone() }))
                    } else {
                        crate::prelude::call_then(crate::check::types::start_show_ty_f(st4_pc.clone(), step_ty_pb.clone()), move |show_ty_f_17887: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st4_pc, &crate::prelude::Text::lit("mismatch"), &step_p4x.span_p, &crate::prelude::Text::from(format!("a hold\'s step is an event; this is `{}`", &show_ty_f_17887)), &crate::prelude::Text::lit("fire it with an event: `... on !e`"))))
                    })
                })
            })
        })
    }
}

/// `Start HoldStmt, x`: what the function value is when passed to `@Run`.
pub fn start_hold_stmt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern, init_p3: crate::syntax::Expr, step_p4: crate::syntax::Expr, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(HoldStmt { env_p0, st_p1, p_p2, init_p3, step_p4, span_p5 })
}

/// ```prism
/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
/// ```
pub fn ignore_stmt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    let (_, st2_p4) = bound_value_f(env_p0, st_p1, e_p2);
    st2_p4.clone()
}

/// The step machine of `IgnoreStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
/// ```
pub struct IgnoreStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for IgnoreStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let span_p3 = &self.span_p3;
        let e_p2x = e_p2.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_bound_value_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone()), move |bound_value_f_18323: (crate::check::types::Ty, crate::check::types::St)| {
            let (_, st2_p4) = bound_value_f_18323;
            ::prism_rtl::Turn::Finished(st2_p4.clone())
        })
    }
}

/// `Start IgnoreStmt, x`: what the function value is when passed to `@Run`.
pub fn start_ignore_stmt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(IgnoreStmt { env_p0, st_p1, e_p2, span_p3 })
}

/// ```prism
/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub fn bare_line_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, last_p3: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p5, st2_p6) = bare_line_kind_f(env_p0, st_p1, e_p2, last_p3);
    let shown_p4 = match &*e_p2.kind_p {
        crate::syntax::ExprKind::EFreeSigil(m18711_0_0, _) if (m18711_0_0 == &crate::prelude::Text::lit("@")) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_p5.clone()), env_p0.scope_p.clone()),
        crate::syntax::ExprKind::EMatch(_, _) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_p5.clone()), env_p0.scope_p.clone()),
        crate::syntax::ExprKind::EIf(_, _, _) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_p5.clone()), env_p0.scope_p.clone()),
        _ => t_p5.clone(),
        _ => unreachable!("no arm matched"),
    };
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EFreeSigil(m18903_0_0, _) if (m18903_0_0 == &crate::prelude::Text::lit("@")) => (t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &e_p2.span_p, &shown_p4)),
        crate::syntax::ExprKind::EMatch(_, _) => (t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &e_p2.span_p, &shown_p4)),
        crate::syntax::ExprKind::EIf(_, _, _) => (t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &e_p2.span_p, &shown_p4)),
        crate::syntax::ExprKind::EGroup(_) => (t_p5.clone(), note_as_last_f(&st2_p6, &e_p2.span_p)),
        _ => (t_p5.clone(), st2_p6.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BareLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub struct BareLine {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub last_p3: bool,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BareLine {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let last_p3 = &self.last_p3;
        let e_p2x = e_p2.clone();
        let env_p0x = env_p0.clone();
        let last_p3x = *last_p3;
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_bare_line_kind_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone(), last_p3x), move |bare_line_kind_f_18665: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p5, st2_p6) = bare_line_kind_f_18665;
            let shown_p4 = match &*e_p2x.kind_p {
                crate::syntax::ExprKind::EFreeSigil(m18711_0_0, _) if (m18711_0_0 == &crate::prelude::Text::lit("@")) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_p5.clone()), env_p0x.scope_p.clone()),
                crate::syntax::ExprKind::EMatch(_, _) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_p5.clone()), env_p0x.scope_p.clone()),
                crate::syntax::ExprKind::EIf(_, _, _) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(t_p5.clone()), env_p0x.scope_p.clone()),
                _ => t_p5.clone(),
                _ => unreachable!("no arm matched"),
            };
            match &*e_p2x.kind_p {
                crate::syntax::ExprKind::EFreeSigil(m18903_0_0, _) if (m18903_0_0 == &crate::prelude::Text::lit("@")) => ::prism_rtl::Turn::Finished((t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &e_p2x.span_p, &shown_p4))),
                crate::syntax::ExprKind::EMatch(_, _) => ::prism_rtl::Turn::Finished((t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &e_p2x.span_p, &shown_p4))),
                crate::syntax::ExprKind::EIf(_, _, _) => ::prism_rtl::Turn::Finished((t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &e_p2x.span_p, &shown_p4))),
                crate::syntax::ExprKind::EGroup(_) => ::prism_rtl::Turn::Finished((t_p5.clone(), note_as_last_f(&st2_p6, &e_p2x.span_p))),
                _ => ::prism_rtl::Turn::Finished((t_p5.clone(), st2_p6.clone())),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start BareLine, x`: what the function value is when passed to `@Run`.
pub fn start_bare_line_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, last_p3: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(BareLine { env_p0, st_p1, e_p2, last_p3 })
}

/// ```prism
/// NoteAsLast: fn St, Range -> St
/// ```
pub fn note_as_last_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range) -> crate::check::types::St {
    match crate::syntax::lexer::chars::last_o(&st_p0.typed_p.exprs_p) {
        ::std::option::Option::Some(n_p2) => crate::check::types::recording::note_ty_f(st_p0, span_p1, &n_p2.ty_p),
        ::std::option::Option::None => st_p0.clone(),
    }
}

/// ```prism
/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub fn bare_line_kind_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, last_p3: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EMatch(scrut_p4, arms_p5) => building_match_f(env_p0, st_p1, &**scrut_p4, arms_p5, &e_p2.span_p, last_p3),
        crate::syntax::ExprKind::EIf(c_p6, then_b_p7, else_b_o8) => building_if_f(env_p0, st_p1, &**c_p6, then_b_p7, else_b_o8, &e_p2.span_p, last_p3),
        crate::syntax::ExprKind::EFreeSigil(m19485_2_0, x_p9) if (m19485_2_0 == &crate::prelude::Text::lit("@")) => {
            let (t_pa, st2_pb) = crate::check::expr::infer_f(env_p0, st_p1, &**x_p9);
            if *last_p3 {
                (t_pa.clone(), st2_pb.clone())
            } else {
                (t_pa.clone(), discarded_f(&st2_pb, &t_pa, &e_p2.span_p))
            }
        },
        crate::syntax::ExprKind::EGroup(x_pc) => bare_line_f(env_p0, st_p1, &**x_pc, last_p3),
        _ => {
            let (t_pd, st1_pe) = infer_built_f(env_p0, st_p1, e_p2);
            let (res_ph, st2_pi) = match crate::check::types::recording::walk_f(&st1_pe, &t_pd) {
                crate::check::types::Ty::TyAt(_, _) => bind_output_f(env_p0, &st1_pe, &t_pd, &e_p2.span_p),
                crate::check::types::Ty::TyElem(_, _) => bind_output_f(env_p0, &st1_pe, &t_pd, &e_p2.span_p),
                crate::check::types::Ty::TySig(_, inner_pf) if is_elem_type_f(&st1_pe, &*inner_pf) => bind_output_f(env_p0, &st1_pe, &t_pd, &e_p2.span_p),
                crate::check::types::Ty::TyErr => (crate::check::types::t_unit_p(), st1_pe.clone()),
                other_pg => if is_builder_f(e_p2) {
                    (other_pg.clone(), st1_pe.clone())
                } else {
                    if &crate::check::types::recording::walk_f(&st1_pe, &other_pg) == &crate::check::types::t_unit_p() {
                        (crate::check::types::t_unit_p(), st1_pe.clone())
                    } else {
                        (other_pg.clone(), crate::check::types::recording::err_fix_f(&st1_pe, &crate::prelude::Text::lit("mismatch"), &e_p2.span_p, &crate::prelude::Text::from(format!("a bare line emits an element or builds a blueprint; this is `{}`", &crate::check::types::show_ty_f(&st1_pe, &other_pg))), &crate::prelude::Text::from(format!("end the block on a value with `@ {}`", &crate::check::expr::src_text_f(env_p0, &e_p2.span_p)))))
                    }
                },
                _ => unreachable!("no arm matched"),
            };
            if *last_p3 {
                (res_ph.clone(), st2_pi.clone())
            } else {
                (res_ph.clone(), discarded_f(&st2_pi, &res_ph, &e_p2.span_p))
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BareLineKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub struct BareLineKind {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub last_p3: bool,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BareLineKind {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let last_p3 = &self.last_p3;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EMatch(scrut_p4, arms_p5) => ::prism_rtl::Turn::Finished(building_match_f(env_p0, st_p1, &**scrut_p4, arms_p5, &e_p2.span_p, last_p3)),
            crate::syntax::ExprKind::EIf(c_p6, then_b_p7, else_b_o8) => ::prism_rtl::Turn::Finished(building_if_f(env_p0, st_p1, &**c_p6, then_b_p7, else_b_o8, &e_p2.span_p, last_p3)),
            crate::syntax::ExprKind::EFreeSigil(m19485_2_0, x_p9) if (m19485_2_0 == &crate::prelude::Text::lit("@")) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let last_p3x = *last_p3;
                let st_p1x = st_p1.clone();
                let x_p9x = (**x_p9).clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), x_p9x.clone()), move |infer_f_19697: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pa, st2_pb) = infer_f_19697;
                    if last_p3x {
                        ::prism_rtl::Turn::Finished((t_pa.clone(), st2_pb.clone()))
                    } else {
                        crate::prelude::call_then(start_discarded_f(st2_pb.clone(), t_pa.clone(), e_p2x.span_p.clone()), move |discarded_f_19754: crate::check::types::St| ::prism_rtl::Turn::Finished((t_pa.clone(), discarded_f_19754)))
                    }
                })
            },
            crate::syntax::ExprKind::EGroup(x_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BareLine { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: (**x_pc).clone(), last_p3: *last_p3 })),
            _ => {
                let (t_pd, st1_pe) = infer_built_f(env_p0, st_p1, e_p2);
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let last_p3x = *last_p3;
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st1_pe.clone(), t_pd.clone()), move |walk_f_19917: crate::check::types::Ty| {
                    let e_p2xz = e_p2x.clone();
                    let last_p3xz = last_p3x;
                    let k_let19892 = move |v19892: (crate::check::types::Ty, crate::check::types::St)| {
                        let (res_ph, st2_pi) = v19892;
                        if last_p3xz {
                            ::prism_rtl::Turn::Finished((res_ph.clone(), st2_pi.clone()))
                        } else {
                            crate::prelude::call_then(start_discarded_f(st2_pi.clone(), res_ph.clone(), e_p2xz.span_p.clone()), move |discarded_f_20571: crate::check::types::St| ::prism_rtl::Turn::Finished((res_ph.clone(), discarded_f_20571)))
                        }
                    };
                    match walk_f_19917 {
                        crate::check::types::Ty::TyAt(_, _) => k_let19892(bind_output_f(&env_p0x, &st1_pe, &t_pd, &e_p2x.span_p)),
                        crate::check::types::Ty::TyElem(_, _) => k_let19892(bind_output_f(&env_p0x, &st1_pe, &t_pd, &e_p2x.span_p)),
                        crate::check::types::Ty::TySig(_, inner_pf) if is_elem_type_f(&st1_pe, &*inner_pf) => k_let19892(bind_output_f(&env_p0x, &st1_pe, &t_pd, &e_p2x.span_p)),
                        crate::check::types::Ty::TyErr => k_let19892((crate::check::types::t_unit_p(), st1_pe.clone())),
                        other_pg => if is_builder_f(&e_p2x) {
                            k_let19892((other_pg.clone(), st1_pe.clone()))
                        } else {
                            crate::prelude::call_then(crate::check::types::recording::start_walk_f(st1_pe.clone(), other_pg.clone()), move |walk_f_20275: crate::check::types::Ty| if &walk_f_20275 == &crate::check::types::t_unit_p() {
                                k_let19892((crate::check::types::t_unit_p(), st1_pe.clone()))
                            } else {
                                crate::prelude::call_then(crate::check::types::start_show_ty_f(st1_pe.clone(), other_pg.clone()), move |show_ty_f_20444: crate::prelude::Text| k_let19892((other_pg.clone(), crate::check::types::recording::err_fix_f(&st1_pe, &crate::prelude::Text::lit("mismatch"), &e_p2x.span_p, &crate::prelude::Text::from(format!("a bare line emits an element or builds a blueprint; this is `{}`", &show_ty_f_20444)), &crate::prelude::Text::from(format!("end the block on a value with `@ {}`", &crate::check::expr::src_text_f(&env_p0x, &e_p2x.span_p)))))))
                            })
                        },
                        _ => unreachable!("no arm matched"),
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start BareLineKind, x`: what the function value is when passed to `@Run`.
pub fn start_bare_line_kind_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, last_p3: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(BareLineKind { env_p0, st_p1, e_p2, last_p3 })
}

/// ```prism
/// IsElemType: unbounded fn St, Ty -> Bool
/// ```
pub fn is_elem_type_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TyElem(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// Discarded: unbounded fn St, Ty, Range -> St
/// ```
pub fn discarded_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TyCon(m20869_0_0, m20869_0_1) if (&m20869_0_0 == &crate::prelude::Text::lit("unit")) && ((&m20869_0_1).len() == 0) => st_p0.clone(),
        crate::check::types::Ty::TyErr => st_p0.clone(),
        crate::check::types::Ty::TyFlex(_) => crate::check::types::unify::unify_f(st_p0, &crate::check::types::t_unit_p(), t_p1, span_p2),
        other_p3 => crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("discarded"), span_p2, &crate::prelude::Text::from(format!("this line\'s result is `{}`; drop it with `ignore <-`", &crate::check::types::show_ty_f(st_p0, &other_p3))), &crate::prelude::Text::lit("write `ignore <-` in front of it, or bind it")),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Discarded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Discarded: unbounded fn St, Ty, Range -> St
/// ```
pub struct Discarded {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub span_p2: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for Discarded {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let span_p2 = &self.span_p2;
        let span_p2x = span_p2.clone();
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_20875: crate::check::types::Ty| match walk_f_20875 {
            crate::check::types::Ty::TyCon(m20869_0_0, m20869_0_1) if (&m20869_0_0 == &crate::prelude::Text::lit("unit")) && ((&m20869_0_1).len() == 0) => ::prism_rtl::Turn::Finished(st_p0x.clone()),
            crate::check::types::Ty::TyErr => ::prism_rtl::Turn::Finished(st_p0x.clone()),
            crate::check::types::Ty::TyFlex(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: st_p0x.clone(), expected_p1: crate::check::types::t_unit_p(), found_p2: t_p1x.clone(), span_p3: span_p2x.clone() })),
            other_p3 => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p0x.clone(), other_p3.clone()), move |show_ty_f_21038: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p0x, &crate::prelude::Text::lit("discarded"), &span_p2x, &crate::prelude::Text::from(format!("this line\'s result is `{}`; drop it with `ignore <-`", &show_ty_f_21038)), &crate::prelude::Text::lit("write `ignore <-` in front of it, or bind it")))),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start Discarded, x`: what the function value is when passed to `@Run`.
pub fn start_discarded_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty, span_p2: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(Discarded { st_p0, t_p1, span_p2 })
}

/// ```prism
/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
/// ```
pub fn building_match_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, scrut_p2: &crate::syntax::Expr, arms_p3: &crate::prelude::Array<crate::syntax::Arm>, span_p4: &crate::syntax::Range, last_p5: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    let (st_ty_pb, st1_pc) = crate::check::expr::infer_f(env_p0, st_p1, scrut_p2);
    let sh_p6 = crate::check::types::head_sigil_f(&st1_pc, &st_ty_pb);
    let st2_p7 = if crate::check::expr::is_time_sigil_f(&sh_p6) {
        crate::check::types::recording::err_fix_f(&st1_pc, &crate::prelude::Text::lit("building-match"), &scrut_p2.span_p, &crate::prelude::Text::from(format!("a blueprint in a match over a {}; use `rebuild`", &(if &sh_p6 == &crate::prelude::Text::lit("$") {
            crate::prelude::Text::lit("dynamic")
        } else {
            crate::prelude::Text::lit("event")
        }))), &crate::prelude::Text::from(format!("write `rebuild {}:` with `match _:` inside", &crate::check::expr::src_text_f(env_p0, &scrut_p2.span_p))))
    } else {
        st1_pc.clone()
    };
    let plain_scrut_p8 = if crate::check::expr::is_time_sigil_f(&sh_p6) {
        crate::check::expr::inner_of_f(&st2_p7, &st_ty_pb)
    } else {
        st_ty_pb.clone()
    };
    let (res_pd, st3_pe) = crate::check::types::fresh_var_f(&st2_p7, &false, &crate::prelude::Text::lit(""));
    let st4_p9 = crate::prelude::run_to_end(crate::prelude::fold_job(arms_p3.clone(), st3_pe.clone(), {
        let env_p0x = env_p0.clone();
        let plain_scrut_p8x = plain_scrut_p8.clone();
        let res_pdx = res_pd.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
            let env_p0xy = env_p0x.clone();
            let plain_scrut_p8xy = plain_scrut_p8x.clone();
            let res_pdxy = res_pdx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_pf = p0;
                let arm_pg = p1;
                {
                    let arm_pgz = arm_pg.clone();
                    let res_pdxyz = res_pdxy.clone();
                    let k_let21901 = move |v21901: (crate::check::expr::Env, crate::check::types::St)| {
                        let (env2_pj, s1_pk) = v21901;
                        let arm_pgzz = arm_pgz.clone();
                        let env2_pjz = env2_pj.clone();
                        let res_pdxyzz = res_pdxyz.clone();
                        let k_let22033 = move |v22033: crate::check::types::St| {
                            let s2_ph = v22033;
                            let (bt_pm, s3_pn) = arm_widget_block_f(&env2_pjz, &s2_ph, &arm_pgzz.body_p);
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: s3_pn.clone(), expected_p1: res_pdxyzz.clone(), found_p2: bt_pm.clone(), span_p3: crate::check::types::recording::result_span_f(&arm_pgzz.body_p) }))
                        };
                        match arm_pgz.guard_o.clone() {
                            ::std::option::Option::Some(gd_pl) => crate::prelude::call_then(crate::check::expr::lifting::start_check_cond_f(env2_pj.clone(), s1_pk.clone(), gd_pl.clone()), move |check_cond_f_22078: crate::check::types::St| k_let22033(check_cond_f_22078)),
                            ::std::option::Option::None => k_let22033(s1_pk.clone()),
                        }
                    };
                    match arm_pg.pattern_o.clone() {
                        ::std::option::Option::Some(p_pi) => crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p0xy.clone(), s_pf.clone(), p_pi.clone(), plain_scrut_p8xy.clone(), true), move |bind_pattern_f_21957: (crate::check::expr::Env, crate::check::types::St)| k_let21901(bind_pattern_f_21957)),
                        ::std::option::Option::None => k_let21901((env_p0xy.clone(), s_pf.clone())),
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }));
    let st5_pa = crate::check::passes::match_coverage_f(env_p0, &st4_p9, &plain_scrut_p8, arms_p3, span_p4);
    if *last_p5 {
        (res_pd.clone(), st5_pa.clone())
    } else {
        (res_pd.clone(), discarded_f(&st5_pa, &res_pd, span_p4))
    }
}

/// ```prism
/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
/// ```
pub fn building_if_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::syntax::Cond, then_b_p3: &crate::syntax::Block, else_b_o4: &::std::option::Option<crate::syntax::Block>, span_p5: &crate::syntax::Range, last_p6: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    let (env2_pk, st1_pl) = match c_p2 {
        crate::syntax::Cond::CondExpr(e_p7) => {
            let (ct_pa, s1_pb) = crate::check::expr::infer_f(env_p0, st_p1, &**e_p7);
            let sh_p8 = crate::check::types::head_sigil_f(&s1_pb, &ct_pa);
            let s2_p9 = if crate::check::expr::is_time_sigil_f(&sh_p8) {
                crate::check::types::recording::err_fix_f(&s1_pb, &crate::prelude::Text::lit("building-match"), &e_p7.span_p, &crate::prelude::Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &crate::prelude::Text::lit("write `rebuild` over the condition, with `if _:` inside"))
            } else {
                s1_pb.clone()
            };
            (env_p0.clone(), crate::check::types::unify::unify_f(&s2_p9, &crate::check::types::t_bool_p(), &(if crate::check::expr::is_time_sigil_f(&sh_p8) {
                crate::check::expr::inner_of_f(&s2_p9, &ct_pa)
            } else {
                ct_pa.clone()
            }), &e_p7.span_p))
        },
        crate::syntax::Cond::CondBind(p_pc, e_pd, gd_oe) => {
            let (et_pf, s1_pg) = crate::check::expr::infer_f(env_p0, st_p1, &**e_pd);
            let (en_ph, s2_pi) = crate::check::expr::patterns::bind_pattern_f(env_p0, &s1_pg, p_pc, &et_pf, &true);
            match &**gd_oe {
                ::std::option::Option::Some(g_pj) => (en_ph.clone(), crate::check::expr::lifting::check_cond_f(&en_ph, &s2_pi, g_pj)),
                ::std::option::Option::None => (en_ph.clone(), s2_pi.clone()),
            }
        },
    };
    let (t1_pm, st2_pn) = arm_widget_block_f(&env2_pk, &st1_pl, then_b_p3);
    match else_b_o4 {
        ::std::option::Option::Some(b_po) => {
            let (t2_pq, st3_pr) = arm_widget_block_f(env_p0, &st2_pn, b_po);
            let st4_pp = crate::check::types::unify::unify_f(&st3_pr, &t1_pm, &t2_pq, &crate::check::types::recording::result_span_f(b_po));
            if *last_p6 {
                (t1_pm.clone(), st4_pp.clone())
            } else {
                (t1_pm.clone(), discarded_f(&st4_pp, &t1_pm, span_p5))
            }
        },
        ::std::option::Option::None => {
            let st3_ps = crate::check::types::unify::unify_f(&st2_pn, &crate::check::types::t_unit_p(), &t1_pm, &crate::check::types::recording::result_span_f(then_b_p3));
            (crate::check::types::t_unit_p(), st3_ps.clone())
        },
    }
}

/// ```prism
/// ArmWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub fn arm_widget_block_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block) -> (crate::check::types::Ty, crate::check::types::St) {
    infer_widget_block_f(env_p0, st_p1, b_p2)
}
