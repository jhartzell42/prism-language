//! The module `Check.Blocks`, from `target/bootstrap/src/prismc/check/blocks/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// GroupOrder: fn [Stmt] -> [Nat]
/// ```
pub fn group_order(stmts: &Array<crate::syntax::Stmt>) -> Array<Nat> {
    let all = crate::check::errors::range0(&len(stmts));
    let holds = filter(&all, &(|i: &Nat| is_hold(&or(&index(stmts, i), &dummy_stmt2()))));
    let lets = filter(&all, &(|i: &Nat| is_let_like(&or(&index(stmts, i), &dummy_stmt2()))));
    let rest = filter(&all, &(|i: &Nat| !is_hold(&or(&index(stmts, i), &dummy_stmt2())) && !is_let_like(&or(&index(stmts, i), &dummy_stmt2()))));
    append(&append(&holds, &lets), &rest)
}

/// ```prism
/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub fn dep_order(stmts: &Array<crate::syntax::Stmt>) -> Array<Array<Nat>> {
    let n = len(stmts);
    let defs = run_to_end(each_job(stmts.clone(), Rc::new(move |p0: crate::syntax::Stmt| entered(once_job(move || {
        let s = p0;
        prism_rtl::Turn::More(Rc::new(GroupDefs { s: s.clone() }))
    }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let uses = run_to_end(each_job(stmts.clone(), Rc::new(move |p0: crate::syntax::Stmt| entered(once_job(move || {
        let s = p0;
        prism_rtl::Turn::More(Rc::new(crate::check::shrink::NamesInStmt { s: s.clone() }))
    }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let deps = each(&crate::check::errors::range0(&n), &(|i: &Nat| filter(&crate::check::errors::range0(&n), &(|j: &Nat| fold(&or(&index(&defs, j), &Array::new()), &false, &(|seen: &bool, d: &Text| *seen || crate::check::types::has_text(&or(&index(&uses, i), &Array::new()), d)))))));
    let reach = run_to_end(each_job(crate::check::errors::range0(&n), {
        let deps = deps.clone();
        Rc::new(move |p0: Nat| {
            let deps = deps.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ReachIdx { deps: deps.clone(), frontier: or(&index(&deps, &i), &Array::new()), seen: Array::new() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    let comps = each(&crate::check::errors::range0(&n), &(|i: &Nat| filter(&crate::check::errors::range0(&n), &(|j: &Nat| (j == i) || (crate::check::types::has_nat(&or(&index(&reach, i), &Array::new()), j) && crate::check::types::has_nat(&or(&index(&reach, j), &Array::new()), i))))));
    emit_groups(&comps, &deps, &Array::new(), &Array::new())
}

/// The step machine of `DepOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub struct DepOrder {
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<Array<Nat>>> for DepOrder {
    fn cycle(&self) -> prism_rtl::Turn<Array<Array<Nat>>> {
        let stmts = &self.stmts;
        let n = len(stmts);
        let stmts = stmts.clone();
        call_value(each_job(stmts.clone(), Rc::new(move |p0: crate::syntax::Stmt| entered(once_job(move || {
            let s = p0;
            prism_rtl::Turn::More(Rc::new(GroupDefs { s: s.clone() }))
        }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_1925: Array<Array<Text>>| {
            let defs = each_1925;
            call_value(each_job(stmts.clone(), Rc::new(move |p0: crate::syntax::Stmt| entered(once_job(move || {
                let s = p0;
                prism_rtl::Turn::More(Rc::new(crate::check::shrink::NamesInStmt { s: s.clone() }))
            }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_1969: Array<Array<Text>>| {
                let uses = each_1969;
                let deps = each(&crate::check::errors::range0(&n), &(|i: &Nat| filter(&crate::check::errors::range0(&n), &(|j: &Nat| fold(&or(&index(&defs, j), &Array::new()), &false, &(|seen: &bool, d: &Text| *seen || crate::check::types::has_text(&or(&index(&uses, i), &Array::new()), d)))))));
                call_value(each_job(crate::check::errors::range0(&n), {
                    let deps = deps.clone();
                    Rc::new(move |p0: Nat| {
                        let deps = deps.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(ReachIdx { deps: deps.clone(), frontier: or(&index(&deps, &i), &Array::new()), seen: Array::new() }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }), move |each_2158: Array<Array<Nat>>| {
                    let reach = each_2158;
                    let comps = each(&crate::check::errors::range0(&n), &(|i: &Nat| filter(&crate::check::errors::range0(&n), &(|j: &Nat| (j == i) || (crate::check::types::has_nat(&or(&index(&reach, i), &Array::new()), j) && crate::check::types::has_nat(&or(&index(&reach, j), &Array::new()), i))))));
                    prism_rtl::Turn::More(Rc::new(EmitGroups { comps: comps.clone(), deps: deps.clone(), done: Array::new(), acc: Array::new() }))
                })
            })
        })
    }
}

/// `Start DepOrder, x`: what the function value is when passed to `@Run`.
pub fn start_dep_order(stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Array<Nat>>>> {
    Rc::new(DepOrder { stmts })
}

/// ```prism
/// GroupDefs: unbounded fn Stmt -> [Text]
/// ```
pub fn group_defs(s: &crate::syntax::Stmt) -> Array<Text> {
    match &s.kind {
        crate::syntax::StmtKind::SBind(p_, _, _) => crate::check::env::pattern_names(p_),
        crate::syntax::StmtKind::SLet(p_, _, _) => crate::check::env::pattern_names(p_),
        crate::syntax::StmtKind::SFn(f) => Array::from(vec![crate::check::env::def_name_text(&f.name)]),
        crate::syntax::StmtKind::SWidget(w) => Array::from(vec![crate::check::env::sname_key(&w.name)]),
        _ => Array::new(),
    }
}

/// The step machine of `GroupDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GroupDefs: unbounded fn Stmt -> [Text]
/// ```
pub struct GroupDefs {
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<Text>> for GroupDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SBind(p_, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::PatternNames { p_: p_.clone() })),
            crate::syntax::StmtKind::SLet(p_, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::PatternNames { p_: p_.clone() })),
            crate::syntax::StmtKind::SFn(f) => prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::def_name_text(&f.name)])),
            crate::syntax::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::sname_key(&w.name)])),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start GroupDefs, x`: what the function value is when passed to `@Run`.
pub fn start_group_defs(s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(GroupDefs { s })
}

/// ```prism
/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
/// ```
pub fn reach_idx(deps: &Array<Array<Nat>>, frontier: &Array<Nat>, seen: &Array<Nat>) -> Array<Nat> {
    match index(frontier, &Nat::from(0u32)) {
        None => seen.clone(),
        Some(x) => if crate::check::types::has_nat(seen, &x) {
            reach_idx(deps, &drop(frontier, &Nat::from(1u32)), seen)
        } else {
            reach_idx(deps, &append(&drop(frontier, &Nat::from(1u32)), &or(&index(deps, &x), &Array::new())), &push(seen, &x))
        },
    }
}

/// The step machine of `ReachIdx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
/// ```
pub struct ReachIdx {
    pub deps: Array<Array<Nat>>,
    pub frontier: Array<Nat>,
    pub seen: Array<Nat>,
}

impl prism_rtl::Job<Array<Nat>> for ReachIdx {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let deps = &self.deps;
        let frontier = &self.frontier;
        let seen = &self.seen;
        match index(frontier, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(seen.clone()),
            Some(x) => if crate::check::types::has_nat(seen, &x) {
                prism_rtl::Turn::More(Rc::new(ReachIdx { deps: deps.clone(), frontier: drop(frontier, &Nat::from(1u32)), seen: seen.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(ReachIdx { deps: deps.clone(), frontier: append(&drop(frontier, &Nat::from(1u32)), &or(&index(deps, &x), &Array::new())), seen: push(seen, &x) }))
            },
        }
    }
}

/// `Start ReachIdx, x`: what the function value is when passed to `@Run`.
pub fn start_reach_idx(deps: Array<Array<Nat>>, frontier: Array<Nat>, seen: Array<Nat>) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(ReachIdx { deps, frontier, seen })
}

/// ```prism
/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
/// ```
pub fn emit_groups(comps: &Array<Array<Nat>>, deps: &Array<Array<Nat>>, done: &Array<Nat>, acc: &Array<Array<Nat>>) -> Array<Array<Nat>> {
    let ready = filter(&crate::check::errors::range0(&len(comps)), &(|i: &Nat| !crate::check::types::has_nat(done, i) && fold(&or(&index(deps, i), &Array::new()), &true, &(|ok: &bool, d: &Nat| *ok && (crate::check::types::has_nat(done, d) || crate::check::types::has_nat(&or(&index(comps, i), &Array::new()), d))))));
    match index(&ready, &Nat::from(0u32)) {
        None => acc.clone(),
        Some(i) => {
            let c = or(&index(comps, &i), &Array::from(vec![i.clone()]));
            emit_groups(comps, deps, &append(done, &c), &push(acc, &c))
        },
    }
}

/// The step machine of `EmitGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
/// ```
pub struct EmitGroups {
    pub comps: Array<Array<Nat>>,
    pub deps: Array<Array<Nat>>,
    pub done: Array<Nat>,
    pub acc: Array<Array<Nat>>,
}

impl prism_rtl::Job<Array<Array<Nat>>> for EmitGroups {
    fn cycle(&self) -> prism_rtl::Turn<Array<Array<Nat>>> {
        let comps = &self.comps;
        let deps = &self.deps;
        let done = &self.done;
        let acc = &self.acc;
        let ready = filter(&crate::check::errors::range0(&len(comps)), &(|i: &Nat| !crate::check::types::has_nat(done, i) && fold(&or(&index(deps, i), &Array::new()), &true, &(|ok: &bool, d: &Nat| *ok && (crate::check::types::has_nat(done, d) || crate::check::types::has_nat(&or(&index(comps, i), &Array::new()), d))))));
        match index(&ready, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(acc.clone()),
            Some(i) => {
                let c = or(&index(comps, &i), &Array::from(vec![i.clone()]));
                prism_rtl::Turn::More(Rc::new(EmitGroups { comps: comps.clone(), deps: deps.clone(), done: append(done, &c), acc: push(acc, &c) }))
            },
        }
    }
}

/// `Start EmitGroups, x`: what the function value is when passed to `@Run`.
pub fn start_emit_groups(comps: Array<Array<Nat>>, deps: Array<Array<Nat>>, done: Array<Nat>, acc: Array<Array<Nat>>) -> Rc<dyn prism_rtl::Job<Array<Array<Nat>>>> {
    Rc::new(EmitGroups { comps, deps, done, acc })
}

/// ```prism
/// IsHold: fn Stmt -> Bool
/// ```
pub fn is_hold(s: &crate::syntax::Stmt) -> bool {
    match &s.kind {
        crate::syntax::StmtKind::SBind(_, _, Some(_)) => true,
        _ => false,
    }
}

/// ```prism
/// IsLetLike: fn Stmt -> Bool
/// ```
pub fn is_let_like(s: &crate::syntax::Stmt) -> bool {
    match &s.kind {
        crate::syntax::StmtKind::SLet(_, _, _) => true,
        crate::syntax::StmtKind::SFn(_) => true,
        crate::syntax::StmtKind::SSignature(_) => true,
        _ => false,
    }
}

/// ```prism
/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub fn infer_widget_block(env: &crate::check::expr::Env, st: &crate::check::types::St, b: &crate::syntax::Block) -> (crate::check::types::Ty, crate::check::types::St) {
    let (env1, st1) = block_row(env, st, &b.stmts);
    let (env2, st2) = run_to_end(fold_job(b.stmts.clone(), (env1.clone(), st1.clone()), Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| entered(once_job(move || {
        let (en, s) = p0;
        let stmt = p1;
        prism_rtl::Turn::More(Rc::new(PreBindStmt { env: en.clone(), st: s.clone(), s: stmt.clone() }))
    }))) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>));
    let n = len(&b.stmts);
    let (env3, st3, res_opt) = run_to_end(fold_job(group_order(&b.stmts), (env2.clone(), st2.clone(), None), {
        let b = b.clone();
        let n = n.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)| {
            let b = b.clone();
            let n = n.clone();
            entered(once_job(move || {
                let (en, s, r_opt) = p0;
                let i = p1;
                {
                    let stmt = or(&index(&b.stmts, &i), &dummy_stmt2());
                    call_then(start_widget_stmt(en.clone(), s.clone(), stmt.clone(), &(&i + &Nat::from(1u32)) == &n), move |widget_stmt_4550: (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)| {
                        let (en2, s2, r2_opt) = widget_stmt_4550;
                        match &r2_opt {
                            Some(t) => prism_rtl::Turn::Finished((en2.clone(), s2.clone(), Some(t.clone()))),
                            None => prism_rtl::Turn::Finished((en2.clone(), s2.clone(), r_opt.clone())),
                        }
                    })
                }
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>>>
    }));
    let st4 = crate::check::passes::block_prompt_cycles(&env3, &st3, b);
    let st5 = if st4.recording {
        crate::check::types::note_group(&st4, &b.span, &Text::lit("widget"), &dep_order(&b.stmts))
    } else {
        st4.clone()
    };
    (or(&res_opt, &crate::check::types::t_unit()), st5.clone())
}

/// The step machine of `InferWidgetBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub struct InferWidgetBlock {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferWidgetBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let b = b.clone();
        let env = env.clone();
        let st = st.clone();
        call_then(start_block_row(env.clone(), st.clone(), b.stmts.clone()), move |block_row_4231: (crate::check::expr::Env, crate::check::types::St)| {
            let (env1, st1) = block_row_4231;
            call_value(fold_job(b.stmts.clone(), (env1.clone(), st1.clone()), Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| entered(once_job(move || {
                let (en, s) = p0;
                let stmt = p1;
                prism_rtl::Turn::More(Rc::new(PreBindStmt { env: en.clone(), st: s.clone(), s: stmt.clone() }))
            }))) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>), move |fold_4281: (crate::check::expr::Env, crate::check::types::St)| {
                let (env2, st2) = fold_4281;
                let n = len(&b.stmts);
                call_value(fold_job(group_order(&b.stmts), (env2.clone(), st2.clone(), None), {
                    let b = b.clone();
                    let n = n.clone();
                    Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)| {
                        let b = b.clone();
                        let n = n.clone();
                        entered(once_job(move || {
                            let (en, s, r_opt) = p0;
                            let i = p1;
                            {
                                let stmt = or(&index(&b.stmts, &i), &dummy_stmt2());
                                call_then(start_widget_stmt(en.clone(), s.clone(), stmt.clone(), &(&i + &Nat::from(1u32)) == &n), move |widget_stmt_4550: (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)| {
                                    let (en2, s2, r2_opt) = widget_stmt_4550;
                                    match &r2_opt {
                                        Some(t) => prism_rtl::Turn::Finished((en2.clone(), s2.clone(), Some(t.clone()))),
                                        None => prism_rtl::Turn::Finished((en2.clone(), s2.clone(), r_opt.clone())),
                                    }
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>>>
                }), move |fold_4407: (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)| {
                    let (env3, st3, res_opt) = fold_4407;
                    call_then(crate::check::passes::start_block_prompt_cycles(env3.clone(), st3.clone(), b.clone()), move |block_prompt_cycles_4685: crate::check::types::St| {
                        let st4 = block_prompt_cycles_4685;
                        let st5 = if st4.recording {
                            crate::check::types::note_group(&st4, &b.span, &Text::lit("widget"), &dep_order(&b.stmts))
                        } else {
                            st4.clone()
                        };
                        prism_rtl::Turn::Finished((or(&res_opt, &crate::check::types::t_unit()), st5.clone()))
                    })
                })
            })
        })
    }
}

/// `Start InferWidgetBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_widget_block(env: crate::check::expr::Env, st: crate::check::types::St, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferWidgetBlock { env, st, b })
}

/// ```prism
/// let dummyStmt2
/// ```
pub fn dummy_stmt2() -> crate::syntax::Stmt {
    crate::syntax::Stmt { kind: crate::syntax::StmtKind::SExpr(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub fn block_row(env: &crate::check::expr::Env, st: &crate::check::types::St, stmts: &Array<crate::syntax::Stmt>) -> (crate::check::expr::Env, crate::check::types::St) {
    run_to_end(fold_job(crate::check::errors::range0(&len(stmts)), (env.clone(), st.clone()), {
        let stmts = stmts.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
            let stmts = stmts.clone();
            entered(once_job(move || {
                let (en, s) = p0;
                let i = p1;
                match index(&stmts, &i) {
                    Some(stmt) => match &stmt.kind {
                        crate::syntax::StmtKind::SEmit(row_decl) => if &i > &Nat::from(0u32) {
                            prism_rtl::Turn::Finished((en.clone(), crate::check::types::err_fix(&s, &Text::lit("emit-element"), &stmt.span, &Text::lit("`emit` comes first in its block"), &Text::lit("move this line to the top of the block"))))
                        } else {
                            {
                                let row_decl = row_decl.clone();
                                call_then(crate::check::env::start_conv_row(crate::check::expr::env_cx(&en), s.clone(), row_as_type(&row_decl)), move |conv_row_5447: (crate::check::types::Rw, crate::check::types::St)| {
                                    let (rw, s2) = conv_row_5447;
                                    let en2 = {
                                        let mut this: crate::check::expr::Env = en.clone();
                                        this.scope = resolve_scope_row(&en, &rw);
                                        this
                                    };
                                    prism_rtl::Turn::Finished((en2.clone(), s2.clone()))
                                })
                            }
                        },
                        _ => prism_rtl::Turn::Finished((en.clone(), s.clone())),
                    },
                    None => prism_rtl::Turn::Finished((en.clone(), s.clone())),
                }
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
    }))
}

/// The step machine of `BlockRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub struct BlockRow {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BlockRow {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        fold_job(crate::check::errors::range0(&len(stmts)), (env.clone(), st.clone()), {
            let stmts = stmts.clone();
            Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                let stmts = stmts.clone();
                entered(once_job(move || {
                    let (en, s) = p0;
                    let i = p1;
                    match index(&stmts, &i) {
                        Some(stmt) => match &stmt.kind {
                            crate::syntax::StmtKind::SEmit(row_decl) => if &i > &Nat::from(0u32) {
                                prism_rtl::Turn::Finished((en.clone(), crate::check::types::err_fix(&s, &Text::lit("emit-element"), &stmt.span, &Text::lit("`emit` comes first in its block"), &Text::lit("move this line to the top of the block"))))
                            } else {
                                {
                                    let row_decl = row_decl.clone();
                                    call_then(crate::check::env::start_conv_row(crate::check::expr::env_cx(&en), s.clone(), row_as_type(&row_decl)), move |conv_row_5447: (crate::check::types::Rw, crate::check::types::St)| {
                                        let (rw, s2) = conv_row_5447;
                                        let en2 = {
                                            let mut this: crate::check::expr::Env = en.clone();
                                            this.scope = resolve_scope_row(&en, &rw);
                                            this
                                        };
                                        prism_rtl::Turn::Finished((en2.clone(), s2.clone()))
                                    })
                                }
                            },
                            _ => prism_rtl::Turn::Finished((en.clone(), s.clone())),
                        },
                        None => prism_rtl::Turn::Finished((en.clone(), s.clone())),
                    }
                }))
            }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start BlockRow, x`: what the function value is when passed to `@Run`.
pub fn start_block_row(env: crate::check::expr::Env, st: crate::check::types::St, stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BlockRow { env, st, stmts })
}

/// ```prism
/// RowAsType: fn Row -> Type
/// ```
pub fn row_as_type(row_decl: &crate::syntax::Row_) -> crate::syntax::Type {
    crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TRowUnion(each(&row_decl.terms, &row_term_type))), span: row_decl.span.clone() }
}

/// ```prism
/// RowTermType: fn RowTerm -> Type
/// ```
pub fn row_term_type(row_term0: &crate::syntax::RowTerm) -> crate::syntax::Type {
    match row_term0 {
        crate::syntax::RowTerm::RFamily(q) => crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TFamily(q.clone())), span: q.span.clone() },
        crate::syntax::RowTerm::RVar(v_) => crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TName(crate::syntax::SName { sigils: Text::lit(""), path_: Array::from(vec![v_.name.clone()]), span: v_.span.clone() }, Array::new())), span: v_.span.clone() },
        crate::syntax::RowTerm::RType(t) => t.clone(),
    }
}

/// ```prism
/// ResolveScopeRow: fn Env, Rw -> Rw
/// ```
pub fn resolve_scope_row(env: &crate::check::expr::Env, rw: &crate::check::types::Rw) -> crate::check::types::Rw {
    match &rw.tail {
        crate::check::types::Tail::TlQ(v_) => crate::check::types::Rw { fams: rw.fams.clone(), minus: rw.minus.clone(), tail: env.scope.tail.clone() },
        _ => rw.clone(),
    }
}

/// ```prism
/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub fn pre_bind_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, s: &crate::syntax::Stmt) -> (crate::check::expr::Env, crate::check::types::St) {
    match &s.kind {
        crate::syntax::StmtKind::SBind(p_, _, _) => pre_bind_pattern(env, st, p_),
        crate::syntax::StmtKind::SLet(_, _, _) => crate::check::expr::pre_bind(env, st, s),
        crate::syntax::StmtKind::SFn(_) => crate::check::expr::pre_bind(env, st, s),
        crate::syntax::StmtKind::SSignature(_) => crate::check::expr::pre_bind(env, st, s),
        crate::syntax::StmtKind::SWidget(w) => {
            let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
            (crate::check::expr::with_local(env, &crate::check::env::sname_key(&w.name), &crate::check::types::mono(&crate::check::types::Ty::TyAt(Rc::new(v_.clone()), env.scope.clone()))), st2.clone())
        },
        _ => (env.clone(), st.clone()),
    }
}

/// The step machine of `PreBindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub struct PreBindStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for PreBindStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SBind(p_, _, _) => prism_rtl::Turn::More(Rc::new(PreBindPattern { env: env.clone(), st: st.clone(), p_: p_.clone() })),
            crate::syntax::StmtKind::SLet(_, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::expr::PreBind { env: env.clone(), st: st.clone(), s: s.clone() })),
            crate::syntax::StmtKind::SFn(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::PreBind { env: env.clone(), st: st.clone(), s: s.clone() })),
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::PreBind { env: env.clone(), st: st.clone(), s: s.clone() })),
            crate::syntax::StmtKind::SWidget(w) => {
                let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                prism_rtl::Turn::Finished((crate::check::expr::with_local(env, &crate::check::env::sname_key(&w.name), &crate::check::types::mono(&crate::check::types::Ty::TyAt(Rc::new(v_.clone()), env.scope.clone()))), st2.clone()))
            },
            _ => prism_rtl::Turn::Finished((env.clone(), st.clone())),
        }
    }
}

/// `Start PreBindStmt, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_stmt(env: crate::check::expr::Env, st: crate::check::types::St, s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(PreBindStmt { env, st, s })
}

/// ```prism
/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
/// ```
pub fn pre_bind_pattern(env: &crate::check::expr::Env, st: &crate::check::types::St, p_: &crate::syntax::Pattern_) -> (crate::check::expr::Env, crate::check::types::St) {
    fold(&crate::check::env::pattern_binders(p_), &(env.clone(), st.clone()), &(|(en, s): &(crate::check::expr::Env, crate::check::types::St), (name, at_): &(Text, crate::syntax::Range)| {
        let (v_, s1) = crate::check::types::fresh_var(s, &true, name);
        let s2 = crate::check::types::at_binder(&s1, &v_, at_);
        let (rw, s3) = crate::check::types::fresh_row(&s2, &Array::new());
        let t = crate::check::types::with_marks(&crate::check::expr::type_marks(&crate::check::types::marks_of(name)), &v_, &rw);
        let en2 = {
            let mut this: crate::check::expr::Env = crate::check::expr::with_local(en, name, &crate::check::types::mono(&t));
            this.pending = crate::check::types::add_text(&this.pending, name);
            this
        };
        (en2.clone(), s3.clone())
    }))
}

/// The step machine of `PreBindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
/// ```
pub struct PreBindPattern {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub p_: crate::syntax::Pattern_,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for PreBindPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let env = env.clone();
        let p_ = p_.clone();
        let st = st.clone();
        call_then(crate::check::env::start_pattern_binders(p_.clone()), move |pattern_binders_6968: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(fold(&pattern_binders_6968, &(env.clone(), st.clone()), &(|(en, s): &(crate::check::expr::Env, crate::check::types::St), (name, at_): &(Text, crate::syntax::Range)| {
            let (v_, s1) = crate::check::types::fresh_var(s, &true, name);
            let s2 = crate::check::types::at_binder(&s1, &v_, at_);
            let (rw, s3) = crate::check::types::fresh_row(&s2, &Array::new());
            let t = crate::check::types::with_marks(&crate::check::expr::type_marks(&crate::check::types::marks_of(name)), &v_, &rw);
            let en2 = {
                let mut this: crate::check::expr::Env = crate::check::expr::with_local(en, name, &crate::check::types::mono(&t));
                this.pending = crate::check::types::add_text(&this.pending, name);
                this
            };
            (en2.clone(), s3.clone())
        }))))
    }
}

/// `Start PreBindPattern, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_pattern(env: crate::check::expr::Env, st: crate::check::types::St, p_: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(PreBindPattern { env, st, p_ })
}

/// ```prism
/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
/// ```
pub fn widget_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, s: &crate::syntax::Stmt, last: &bool) -> (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>) {
    match &s.kind {
        crate::syntax::StmtKind::SEmit(_) => (env.clone(), st.clone(), if *last { Some(crate::check::types::t_unit()) } else { None }),
        crate::syntax::StmtKind::SBind(p_, e, None) => {
            let st2 = bind_stmt(env, st, p_, e, &s.span);
            (env.clone(), st2.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })
        },
        crate::syntax::StmtKind::SBind(p_, init, Some(step_)) => {
            let st2 = hold_stmt(env, st, p_, init, step_, &s.span);
            (env.clone(), st2.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })
        },
        crate::syntax::StmtKind::SIgnore(e) => {
            let st2 = ignore_stmt(env, st, e, &s.span);
            (env.clone(), st2.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })
        },
        crate::syntax::StmtKind::SLet(p_, ty_opt, e) => {
            let (env2, st2) = crate::check::expr::check_let(env, st, p_, ty_opt, e, &s.span);
            (env2.clone(), st2.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })
        },
        crate::syntax::StmtKind::SFn(f) => {
            let (env2, st2) = crate::check::expr::check_local_fn(env, st, f, &s.span);
            (env2.clone(), st2.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })
        },
        crate::syntax::StmtKind::SSignature(_) => (env.clone(), st.clone(), if *last { Some(crate::check::types::t_unit()) } else { None }),
        crate::syntax::StmtKind::SWidget(w) => {
            let (t, st2) = infer_widget_block(env, st, &w.body);
            let st3 = match get(&env.locals, &crate::check::env::sname_key(&w.name)) {
                Some(sc) => crate::check::types::unify(&st2, &sc.ty, &crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()), &w.span),
                None => st2.clone(),
            };
            (env.clone(), st3.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })
        },
        crate::syntax::StmtKind::SExpr(e) => {
            let (t, st2) = bare_line(env, st, e, last);
            if *last {
                (env.clone(), st2.clone(), Some(t.clone()))
            } else {
                (env.clone(), st2.clone(), None)
            }
        },
        _ => (env.clone(), crate::check::types::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a `given:` or `update` block")), if *last { Some(crate::check::types::t_unit()) } else { None }),
    }
}

/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
/// ```
pub struct WidgetStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub s: crate::syntax::Stmt,
    pub last: bool,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)> for WidgetStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        let last = &self.last;
        match &s.kind {
            crate::syntax::StmtKind::SEmit(_) => prism_rtl::Turn::Finished((env.clone(), st.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })),
            crate::syntax::StmtKind::SBind(p_, e, None) => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let p_ = p_.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(start_bind_stmt(env.clone(), st.clone(), p_.clone(), e.clone(), s.span.clone()), move |bind_stmt_7593: crate::check::types::St| {
                    let st2 = bind_stmt_7593;
                    prism_rtl::Turn::Finished((env.clone(), st2.clone(), if last { Some(crate::check::types::t_unit()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SBind(p_, init, Some(step_)) => {
                let env = env.clone();
                let init = init.clone();
                let last = *last;
                let p_ = p_.clone();
                let s = s.clone();
                let st = st.clone();
                let step_ = step_.clone();
                call_then(start_hold_stmt(env.clone(), st.clone(), p_.clone(), init.clone(), step_.clone(), s.span.clone()), move |hold_stmt_7720: crate::check::types::St| {
                    let st2 = hold_stmt_7720;
                    prism_rtl::Turn::Finished((env.clone(), st2.clone(), if last { Some(crate::check::types::t_unit()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SIgnore(e) => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let s = s.clone();
                let st = st.clone();
                call_then(start_ignore_stmt(env.clone(), st.clone(), e.clone(), s.span.clone()), move |ignore_stmt_7842: crate::check::types::St| {
                    let st2 = ignore_stmt_7842;
                    prism_rtl::Turn::Finished((env.clone(), st2.clone(), if last { Some(crate::check::types::t_unit()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SLet(p_, ty_opt, e) => {
                let ty_opt = ty_opt.clone();
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let p_ = p_.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_check_let(env.clone(), st.clone(), p_.clone(), ty_opt.clone(), e.clone(), s.span.clone()), move |check_let_7969: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2, st2) = check_let_7969;
                    prism_rtl::Turn::Finished((env2.clone(), st2.clone(), if last { Some(crate::check::types::t_unit()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SFn(f) => {
                let env = env.clone();
                let f = f.clone();
                let last = *last;
                let s = s.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_check_local_fn(env.clone(), st.clone(), f.clone(), s.span.clone()), move |check_local_fn_8094: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2, st2) = check_local_fn_8094;
                    prism_rtl::Turn::Finished((env2.clone(), st2.clone(), if last { Some(crate::check::types::t_unit()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((env.clone(), st.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })),
            crate::syntax::StmtKind::SWidget(w) => {
                let env = env.clone();
                let last = *last;
                let st = st.clone();
                let w = w.clone();
                call_then(start_infer_widget_block(env.clone(), st.clone(), w.body.clone()), move |infer_widget_block_8279: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_widget_block_8279;
                    let st3 = match get(&env.locals, &crate::check::env::sname_key(&w.name)) {
                        Some(sc) => crate::check::types::unify(&st2, &sc.ty, &crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()), &w.span),
                        None => st2.clone(),
                    };
                    prism_rtl::Turn::Finished((env.clone(), st3.clone(), if last { Some(crate::check::types::t_unit()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SExpr(e) => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let st = st.clone();
                call_then(start_bare_line(env.clone(), st.clone(), e.clone(), last), move |bare_line_8537: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = bare_line_8537;
                    if last {
                        prism_rtl::Turn::Finished((env.clone(), st2.clone(), Some(t.clone())))
                    } else {
                        prism_rtl::Turn::Finished((env.clone(), st2.clone(), None))
                    }
                })
            },
            _ => prism_rtl::Turn::Finished((env.clone(), crate::check::types::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a `given:` or `update` block")), if *last { Some(crate::check::types::t_unit()) } else { None })),
        }
    }
}

/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
pub fn start_widget_stmt(env: crate::check::expr::Env, st: crate::check::types::St, s: crate::syntax::Stmt, last: bool) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>> {
    Rc::new(WidgetStmt { env, st, s, last })
}

/// ```prism
/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
/// ```
pub fn bind_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, p_: &crate::syntax::Pattern_, e: &crate::syntax::Expr, span: &crate::syntax::Range) -> crate::check::types::St {
    let (t, st1) = crate::check::expr::infer(env, st, e);
    let (out, st2) = if is_builder(e) {
        (t.clone(), st1.clone())
    } else {
        bind_output(env, &st1, &t, &e.span)
    };
    let (_, st3) = crate::check::expr::bind_pattern(env, &st2, p_, &out, &false);
    st3.clone()
}

/// The step machine of `BindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
/// ```
pub struct BindStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub p_: crate::syntax::Pattern_,
    pub e: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for BindStmt {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let e = &self.e;
        let span = &self.span;
        let e = e.clone();
        let env = env.clone();
        let p_ = p_.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_9152: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st1) = infer_9152;
            let (out, st2) = if is_builder(&e) {
                (t.clone(), st1.clone())
            } else {
                bind_output(&env, &st1, &t, &e.span)
            };
            call_then(crate::check::expr::start_bind_pattern(env.clone(), st2.clone(), p_.clone(), out.clone(), false), move |bind_pattern_9282: (crate::check::expr::Env, crate::check::types::St)| {
                let (_, st3) = bind_pattern_9282;
                prism_rtl::Turn::Finished(st3.clone())
            })
        })
    }
}

/// `Start BindStmt, x`: what the function value is when passed to `@Run`.
pub fn start_bind_stmt(env: crate::check::expr::Env, st: crate::check::types::St, p_: crate::syntax::Pattern_, e: crate::syntax::Expr, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(BindStmt { env, st, p_, e, span })
}

/// ```prism
/// IsBuilder: fn Expr -> Bool
/// ```
pub fn is_builder(e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::ERebuild(_, _) => true,
        crate::syntax::ExprKind::EFor(_, _, _) => true,
        crate::syntax::ExprKind::EGroup(x) => is_builder(&**x),
        _ => false,
    }
}

/// ```prism
/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
/// ```
pub fn bind_output(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::check::types::walk(st, t) {
        crate::check::types::Ty::TyAt(inner, rw) => ((*inner).clone(), add_incl(st, &rw, &env.scope, span, &Text::lit("child"))),
        crate::check::types::Ty::TyElem(rw, o) => ((*o).clone(), add_incl(st, &rw, &env.scope, span, &Text::lit("element"))),
        crate::check::types::Ty::TySig(s, inner) => match crate::check::types::walk(st, &*inner) {
            crate::check::types::Ty::TyAt(_, _) => (crate::check::types::Ty::TyErr, crate::check::types::err_fix(st, &Text::lit("bind-dynamic"), span, &Text::from(format!("binding a `{}`; say what happens to the old widgets with `rebuild`", &crate::check::types::show_ty(st, t))), &Text::lit("write `rebuild` over the dynamic, with the blueprint inside"))),
            crate::check::types::Ty::TyElem(_, _) => (crate::check::types::Ty::TyErr, crate::check::types::err_fix(st, &Text::lit("bind-dynamic"), span, &Text::from(format!("binding a `{}`, a {} of elements; say what happens to the old element with `rebuild`", &crate::check::types::show_ty(st, t), &(if &s == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }))), &Text::lit("write `rebuild` over the dynamic field's value, with the element inside"))),
            _ => (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &crate::check::types::show_ty(st, t))))),
        },
        crate::check::types::Ty::TyFlex(_) => {
            let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
            (v_.clone(), crate::check::types::unify(&st2, t, &crate::check::types::Ty::TyAt(Rc::new(v_.clone()), env.scope.clone()), span))
        },
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st.clone()),
        other => (crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &crate::check::types::show_ty(st, &other))))),
    }
}

/// The step machine of `BindOutput`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
/// ```
pub struct BindOutput {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BindOutput {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let span = &self.span;
        let env = env.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::start_walk(st.clone(), t.clone()), move |walk_9677: crate::check::types::Ty| match walk_9677 {
            crate::check::types::Ty::TyAt(inner, rw) => prism_rtl::Turn::Finished(((*inner).clone(), add_incl(&st, &rw, &env.scope, &span, &Text::lit("child")))),
            crate::check::types::Ty::TyElem(rw, o) => prism_rtl::Turn::Finished(((*o).clone(), add_incl(&st, &rw, &env.scope, &span, &Text::lit("element")))),
            crate::check::types::Ty::TySig(s, inner) => call_then(crate::check::types::start_walk(st.clone(), (*inner).clone()), move |walk_9867: crate::check::types::Ty| match walk_9867 {
                crate::check::types::Ty::TyAt(_, _) => call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_9972: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err_fix(&st, &Text::lit("bind-dynamic"), &span, &Text::from(format!("binding a `{}`; say what happens to the old widgets with `rebuild`", &show_ty_9972)), &Text::lit("write `rebuild` over the dynamic, with the blueprint inside"))))),
                crate::check::types::Ty::TyElem(_, _) => call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_10197: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err_fix(&st, &Text::lit("bind-dynamic"), &span, &Text::from(format!("binding a `{}`, a {} of elements; say what happens to the old element with `rebuild`", &show_ty_10197, &(if &s == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }))), &Text::lit("write `rebuild` over the dynamic field's value, with the element inside"))))),
                _ => call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_10505: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &show_ty_10505)))))),
            }),
            crate::check::types::Ty::TyFlex(_) => {
                let (v_, st2) = crate::check::types::fresh_var(&st, &false, &Text::lit(""));
                call_then(crate::check::types::start_unify(st2.clone(), t.clone(), crate::check::types::Ty::TyAt(Rc::new(v_.clone()), env.scope.clone()), span.clone()), move |unify_10605: crate::check::types::St| prism_rtl::Turn::Finished((v_.clone(), unify_10605)))
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st.clone())),
            other => call_then(crate::check::types::start_show_ty(st.clone(), other.clone()), move |show_ty_10769: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &show_ty_10769)))))),
        })
    }
}

/// `Start BindOutput, x`: what the function value is when passed to `@Run`.
pub fn start_bind_output(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BindOutput { env, st, t, span })
}

/// ```prism
/// AddIncl: fn St, Rw, Rw, Range, Text -> St
/// ```
pub fn add_incl(st: &crate::check::types::St, sub: &crate::check::types::Rw, sup: &crate::check::types::Rw, span: &crate::syntax::Range, what: &Text) -> crate::check::types::St {
    let mut this: crate::check::types::St = st.clone();
    this.incls = push(&this.incls, &crate::check::types::Incl { sub: sub.clone(), sup: sup.clone(), file: this.file.clone(), span: span.clone(), what: what.clone(), forward: false });
    this
}

/// ```prism
/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
/// ```
pub fn hold_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, p_: &crate::syntax::Pattern_, init: &crate::syntax::Expr, step_: &crate::syntax::Expr, span: &crate::syntax::Range) -> crate::check::types::St {
    let (v_, st1) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
    let held = crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_.clone()));
    let (_, st2) = crate::check::expr::bind_pattern(env, &st1, p_, &held, &false);
    let st3 = crate::check::expr::check(env, &st2, init, &v_);
    let (step_ty, st4) = crate::check::expr::infer(env, &st3, step_);
    if (&crate::check::types::head_sigil(&st4, &step_ty) == &Text::lit("!")) || (&step_ty == &crate::check::types::Ty::TyErr) {
        crate::check::types::unify(&st4, &crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone())), &step_ty, &step_.span)
    } else {
        crate::check::types::err_fix(&st4, &Text::lit("mismatch"), &step_.span, &Text::from(format!("a hold's step is an event; this is `{}`", &crate::check::types::show_ty(&st4, &step_ty))), &Text::lit("fire it with an event: `... on !e`"))
    }
}

/// The step machine of `HoldStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
/// ```
pub struct HoldStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub p_: crate::syntax::Pattern_,
    pub init: crate::syntax::Expr,
    pub step_: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for HoldStmt {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let init = &self.init;
        let step_ = &self.step_;
        let span = &self.span;
        let (v_, st1) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
        let held = crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_.clone()));
        let env = env.clone();
        let init = init.clone();
        let p_ = p_.clone();
        let span = span.clone();
        let step_ = step_.clone();
        call_then(crate::check::expr::start_bind_pattern(env.clone(), st1.clone(), p_.clone(), held.clone(), false), move |bind_pattern_11312: (crate::check::expr::Env, crate::check::types::St)| {
            let (_, st2) = bind_pattern_11312;
            call_then(crate::check::expr::start_check(env.clone(), st2.clone(), init.clone(), v_.clone()), move |check_11363: crate::check::types::St| {
                let st3 = check_11363;
                call_then(crate::check::expr::start_infer(env.clone(), st3.clone(), step_.clone()), move |infer_11413: (crate::check::types::Ty, crate::check::types::St)| {
                    let (step_ty, st4) = infer_11413;
                    call_then(crate::check::types::start_head_sigil(st4.clone(), step_ty.clone()), move |head_sigil_11442: Text| if (&head_sigil_11442 == &Text::lit("!")) || (&step_ty == &crate::check::types::Ty::TyErr) {
                        prism_rtl::Turn::More(Rc::new(crate::check::types::Unify { st: st4.clone(), expected: crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone())), found: step_ty.clone(), span: step_.span.clone() }))
                    } else {
                        call_then(crate::check::types::start_show_ty(st4.clone(), step_ty.clone()), move |show_ty_11620: Text| prism_rtl::Turn::Finished(crate::check::types::err_fix(&st4, &Text::lit("mismatch"), &step_.span, &Text::from(format!("a hold's step is an event; this is `{}`", &show_ty_11620)), &Text::lit("fire it with an event: `... on !e`"))))
                    })
                })
            })
        })
    }
}

/// `Start HoldStmt, x`: what the function value is when passed to `@Run`.
pub fn start_hold_stmt(env: crate::check::expr::Env, st: crate::check::types::St, p_: crate::syntax::Pattern_, init: crate::syntax::Expr, step_: crate::syntax::Expr, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(HoldStmt { env, st, p_, init, step_, span })
}

/// ```prism
/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
/// ```
pub fn ignore_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, e: &crate::syntax::Expr, span: &crate::syntax::Range) -> crate::check::types::St {
    let (t, st1) = crate::check::expr::infer(env, st, e);
    match crate::check::types::walk(&st1, &t) {
        crate::check::types::Ty::TyAt(_, _) => {
            let (_, st2) = bind_output(env, &st1, &t, &e.span);
            st2.clone()
        },
        crate::check::types::Ty::TyElem(_, _) => {
            let (_, st2) = bind_output(env, &st1, &t, &e.span);
            st2.clone()
        },
        crate::check::types::Ty::TySig(_, inner) => match crate::check::types::walk(&st1, &*inner) {
            crate::check::types::Ty::TyAt(_, _) => {
                let (_, st2) = bind_output(env, &st1, &t, &e.span);
                st2.clone()
            },
            crate::check::types::Ty::TyElem(_, _) => {
                let (_, st2) = bind_output(env, &st1, &t, &e.span);
                st2.clone()
            },
            _ => st1.clone(),
        },
        _ => st1.clone(),
    }
}

/// The step machine of `IgnoreStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
/// ```
pub struct IgnoreStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub e: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for IgnoreStmt {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let span = &self.span;
        let e = e.clone();
        let env = env.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_11853: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st1) = infer_11853;
            call_then(crate::check::types::start_walk(st1.clone(), t.clone()), move |walk_11880: crate::check::types::Ty| match walk_11880 {
                crate::check::types::Ty::TyAt(_, _) => call_then(start_bind_output(env.clone(), st1.clone(), t.clone(), e.span.clone()), move |bind_output_11956: (crate::check::types::Ty, crate::check::types::St)| {
                    let (_, st2) = bind_output_11956;
                    prism_rtl::Turn::Finished(st2.clone())
                }),
                crate::check::types::Ty::TyElem(_, _) => call_then(start_bind_output(env.clone(), st1.clone(), t.clone(), e.span.clone()), move |bind_output_12068: (crate::check::types::Ty, crate::check::types::St)| {
                    let (_, st2) = bind_output_12068;
                    prism_rtl::Turn::Finished(st2.clone())
                }),
                crate::check::types::Ty::TySig(_, inner) => call_then(crate::check::types::start_walk(st1.clone(), (*inner).clone()), move |walk_12150: crate::check::types::Ty| match walk_12150 {
                    crate::check::types::Ty::TyAt(_, _) => call_then(start_bind_output(env.clone(), st1.clone(), t.clone(), e.span.clone()), move |bind_output_12238: (crate::check::types::Ty, crate::check::types::St)| {
                        let (_, st2) = bind_output_12238;
                        prism_rtl::Turn::Finished(st2.clone())
                    }),
                    crate::check::types::Ty::TyElem(_, _) => call_then(start_bind_output(env.clone(), st1.clone(), t.clone(), e.span.clone()), move |bind_output_12362: (crate::check::types::Ty, crate::check::types::St)| {
                        let (_, st2) = bind_output_12362;
                        prism_rtl::Turn::Finished(st2.clone())
                    }),
                    _ => prism_rtl::Turn::Finished(st1.clone()),
                }),
                _ => prism_rtl::Turn::Finished(st1.clone()),
            })
        })
    }
}

/// `Start IgnoreStmt, x`: what the function value is when passed to `@Run`.
pub fn start_ignore_stmt(env: crate::check::expr::Env, st: crate::check::types::St, e: crate::syntax::Expr, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(IgnoreStmt { env, st, e, span })
}

/// ```prism
/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub fn bare_line(env: &crate::check::expr::Env, st: &crate::check::types::St, e: &crate::syntax::Expr, last: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t, st2) = bare_line_kind(env, st, e, last);
    let shown = match &*e.kind {
        crate::syntax::ExprKind::EFreeSigil(m12821_0_0, _) if (m12821_0_0 == &Text::lit("@")) => crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
        crate::syntax::ExprKind::EMatch(_, _) => crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
        crate::syntax::ExprKind::EIf(_, _, _) => crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
        _ => t.clone(),
        _ => unreachable!("no arm matched"),
    };
    match &*e.kind {
        crate::syntax::ExprKind::EFreeSigil(m13013_0_0, _) if (m13013_0_0 == &Text::lit("@")) => (t.clone(), crate::check::types::note_ty(&st2, &e.span, &shown)),
        crate::syntax::ExprKind::EMatch(_, _) => (t.clone(), crate::check::types::note_ty(&st2, &e.span, &shown)),
        crate::syntax::ExprKind::EIf(_, _, _) => (t.clone(), crate::check::types::note_ty(&st2, &e.span, &shown)),
        crate::syntax::ExprKind::EGroup(_) => (t.clone(), note_as_last(&st2, &e.span)),
        _ => (t.clone(), st2.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BareLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub struct BareLine {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub e: crate::syntax::Expr,
    pub last: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BareLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let last = &self.last;
        let e = e.clone();
        let env = env.clone();
        let last = *last;
        let st = st.clone();
        call_then(start_bare_line_kind(env.clone(), st.clone(), e.clone(), last), move |bare_line_kind_12775: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st2) = bare_line_kind_12775;
            let shown = match &*e.kind {
                crate::syntax::ExprKind::EFreeSigil(m12821_0_0, _) if (m12821_0_0 == &Text::lit("@")) => crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
                crate::syntax::ExprKind::EMatch(_, _) => crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
                crate::syntax::ExprKind::EIf(_, _, _) => crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
                _ => t.clone(),
                _ => unreachable!("no arm matched"),
            };
            match &*e.kind {
                crate::syntax::ExprKind::EFreeSigil(m13013_0_0, _) if (m13013_0_0 == &Text::lit("@")) => prism_rtl::Turn::Finished((t.clone(), crate::check::types::note_ty(&st2, &e.span, &shown))),
                crate::syntax::ExprKind::EMatch(_, _) => prism_rtl::Turn::Finished((t.clone(), crate::check::types::note_ty(&st2, &e.span, &shown))),
                crate::syntax::ExprKind::EIf(_, _, _) => prism_rtl::Turn::Finished((t.clone(), crate::check::types::note_ty(&st2, &e.span, &shown))),
                crate::syntax::ExprKind::EGroup(_) => prism_rtl::Turn::Finished((t.clone(), note_as_last(&st2, &e.span))),
                _ => prism_rtl::Turn::Finished((t.clone(), st2.clone())),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start BareLine, x`: what the function value is when passed to `@Run`.
pub fn start_bare_line(env: crate::check::expr::Env, st: crate::check::types::St, e: crate::syntax::Expr, last: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BareLine { env, st, e, last })
}

/// ```prism
/// NoteAsLast: fn St, Range -> St
/// ```
pub fn note_as_last(st: &crate::check::types::St, span: &crate::syntax::Range) -> crate::check::types::St {
    match crate::syntax::lexer::last(&st.typed.exprs) {
        Some(n) => crate::check::types::note_ty(st, span, &n.ty),
        None => st.clone(),
    }
}

/// ```prism
/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub fn bare_line_kind(env: &crate::check::expr::Env, st: &crate::check::types::St, e: &crate::syntax::Expr, last: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*e.kind {
        crate::syntax::ExprKind::EMatch(scrut, arms) => building_match(env, st, &**scrut, arms, &e.span, last),
        crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => building_if(env, st, &**c, then_b, else_b_opt, &e.span, last),
        crate::syntax::ExprKind::EFreeSigil(m13595_2_0, x) if (m13595_2_0 == &Text::lit("@")) => {
            let (t, st2) = crate::check::expr::infer(env, st, &**x);
            if *last {
                (t.clone(), st2.clone())
            } else {
                (t.clone(), discarded(&st2, &t, &e.span))
            }
        },
        crate::syntax::ExprKind::EGroup(x) => bare_line(env, st, &**x, last),
        _ => {
            let (t, st1) = crate::check::expr::infer(env, st, e);
            let (res, st2) = match crate::check::types::walk(&st1, &t) {
                crate::check::types::Ty::TyAt(_, _) => bind_output(env, &st1, &t, &e.span),
                crate::check::types::Ty::TyElem(_, _) => bind_output(env, &st1, &t, &e.span),
                crate::check::types::Ty::TyErr => (crate::check::types::t_unit(), st1.clone()),
                other => if is_builder(e) {
                    (other.clone(), st1.clone())
                } else {
                    if &crate::check::types::walk(&st1, &other) == &crate::check::types::t_unit() {
                        (crate::check::types::t_unit(), st1.clone())
                    } else {
                        (other.clone(), crate::check::types::err_fix(&st1, &Text::lit("mismatch"), &e.span, &Text::from(format!("a bare line emits an element or builds a blueprint; this is `{}`", &crate::check::types::show_ty(&st1, &other))), &Text::from(format!("end the block on a value with `@ {}`", &crate::check::expr::src_text(env, &e.span)))))
                    }
                },
            };
            if *last {
                (res.clone(), st2.clone())
            } else {
                (res.clone(), discarded(&st2, &res, &e.span))
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BareLineKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub struct BareLineKind {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub e: crate::syntax::Expr,
    pub last: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BareLineKind {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let last = &self.last;
        match &*e.kind {
            crate::syntax::ExprKind::EMatch(scrut, arms) => prism_rtl::Turn::More(Rc::new(BuildingMatch { env: env.clone(), st: st.clone(), scrut: (**scrut).clone(), arms: arms.clone(), span: e.span.clone(), last: *last })),
            crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => prism_rtl::Turn::More(Rc::new(BuildingIf { env: env.clone(), st: st.clone(), c: (**c).clone(), then_b: then_b.clone(), else_b_opt: else_b_opt.clone(), span: e.span.clone(), last: *last })),
            crate::syntax::ExprKind::EFreeSigil(m13595_2_0, x) if (m13595_2_0 == &Text::lit("@")) => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let st = st.clone();
                let x = (**x).clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), x.clone()), move |infer_13807: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_13807;
                    if last {
                        prism_rtl::Turn::Finished((t.clone(), st2.clone()))
                    } else {
                        call_then(start_discarded(st2.clone(), t.clone(), e.span.clone()), move |discarded_13864: crate::check::types::St| prism_rtl::Turn::Finished((t.clone(), discarded_13864)))
                    }
                })
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(BareLine { env: env.clone(), st: st.clone(), e: (**x).clone(), last: *last })),
            _ => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let st = st.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_13972: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st1) = infer_13972;
                    call_then(crate::check::types::start_walk(st1.clone(), t.clone()), move |walk_14022: crate::check::types::Ty| {
                        let (res, st2) = match walk_14022 {
                            crate::check::types::Ty::TyAt(_, _) => bind_output(&env, &st1, &t, &e.span),
                            crate::check::types::Ty::TyElem(_, _) => bind_output(&env, &st1, &t, &e.span),
                            crate::check::types::Ty::TyErr => (crate::check::types::t_unit(), st1.clone()),
                            other => if is_builder(&e) {
                                (other.clone(), st1.clone())
                            } else {
                                if &crate::check::types::walk(&st1, &other) == &crate::check::types::t_unit() {
                                    (crate::check::types::t_unit(), st1.clone())
                                } else {
                                    (other.clone(), crate::check::types::err_fix(&st1, &Text::lit("mismatch"), &e.span, &Text::from(format!("a bare line emits an element or builds a blueprint; this is `{}`", &crate::check::types::show_ty(&st1, &other))), &Text::from(format!("end the block on a value with `@ {}`", &crate::check::expr::src_text(&env, &e.span)))))
                                }
                            },
                        };
                        if last {
                            prism_rtl::Turn::Finished((res.clone(), st2.clone()))
                        } else {
                            call_then(start_discarded(st2.clone(), res.clone(), e.span.clone()), move |discarded_14587: crate::check::types::St| prism_rtl::Turn::Finished((res.clone(), discarded_14587)))
                        }
                    })
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start BareLineKind, x`: what the function value is when passed to `@Run`.
pub fn start_bare_line_kind(env: crate::check::expr::Env, st: crate::check::types::St, e: crate::syntax::Expr, last: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BareLineKind { env, st, e, last })
}

/// ```prism
/// Discarded: unbounded fn St, Ty, Range -> St
/// ```
pub fn discarded(st: &crate::check::types::St, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::walk(st, t) {
        crate::check::types::Ty::TyCon(m14751_0_0, m14751_0_1) if (&m14751_0_0 == &Text::lit("unit")) && ((&m14751_0_1).len() == 0) => st.clone(),
        crate::check::types::Ty::TyErr => st.clone(),
        crate::check::types::Ty::TyFlex(_) => crate::check::types::unify(st, &crate::check::types::t_unit(), t, span),
        other => crate::check::types::err_fix(st, &Text::lit("discarded"), span, &Text::from(format!("this line's result is `{}`; drop it with `ignore <-`", &crate::check::types::show_ty(st, &other))), &Text::lit("write `ignore <-` in front of it, or bind it")),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Discarded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Discarded: unbounded fn St, Ty, Range -> St
/// ```
pub struct Discarded {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for Discarded {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let t = &self.t;
        let span = &self.span;
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::start_walk(st.clone(), t.clone()), move |walk_14757: crate::check::types::Ty| match walk_14757 {
            crate::check::types::Ty::TyCon(m14751_0_0, m14751_0_1) if (&m14751_0_0 == &Text::lit("unit")) && ((&m14751_0_1).len() == 0) => prism_rtl::Turn::Finished(st.clone()),
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished(st.clone()),
            crate::check::types::Ty::TyFlex(_) => prism_rtl::Turn::More(Rc::new(crate::check::types::Unify { st: st.clone(), expected: crate::check::types::t_unit(), found: t.clone(), span: span.clone() })),
            other => call_then(crate::check::types::start_show_ty(st.clone(), other.clone()), move |show_ty_14920: Text| prism_rtl::Turn::Finished(crate::check::types::err_fix(&st, &Text::lit("discarded"), &span, &Text::from(format!("this line's result is `{}`; drop it with `ignore <-`", &show_ty_14920)), &Text::lit("write `ignore <-` in front of it, or bind it")))),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start Discarded, x`: what the function value is when passed to `@Run`.
pub fn start_discarded(st: crate::check::types::St, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Discarded { st, t, span })
}

/// ```prism
/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
/// ```
pub fn building_match(env: &crate::check::expr::Env, st: &crate::check::types::St, scrut: &crate::syntax::Expr, arms: &Array<crate::syntax::Arm>, span: &crate::syntax::Range, last: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    let (st_ty, st1) = crate::check::expr::infer(env, st, scrut);
    let sh = crate::check::types::head_sigil(&st1, &st_ty);
    let st2 = if crate::check::expr::is_time_sigil(&sh) {
        crate::check::types::err_fix(&st1, &Text::lit("building-match"), &scrut.span, &Text::from(format!("a blueprint in a match over a {}; use `rebuild`", &(if &sh == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }))), &Text::from(format!("write `rebuild {}:` with `match _:` inside", &crate::check::expr::src_text(env, &scrut.span))))
    } else {
        st1.clone()
    };
    let plain_scrut = if crate::check::expr::is_time_sigil(&sh) {
        crate::check::expr::inner_of(&st2, &st_ty)
    } else {
        st_ty.clone()
    };
    let (res, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
    let st4 = run_to_end(fold_job(arms.clone(), st3.clone(), {
        let env = env.clone();
        let plain_scrut = plain_scrut.clone();
        let res = res.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
            let env = env.clone();
            let plain_scrut = plain_scrut.clone();
            let res = res.clone();
            entered(once_job(move || {
                let s = p0;
                let arm = p1;
                {
                    let (env2, s1) = match &arm.pattern {
                        Some(p_) => crate::check::expr::bind_pattern(&env, &s, p_, &plain_scrut, &true),
                        None => (env.clone(), s.clone()),
                    };
                    let s2 = match &arm.guard {
                        Some(gd) => crate::check::expr::check_cond(&env2, &s1, gd),
                        None => s1.clone(),
                    };
                    let (bt, s3) = arm_widget_block(&env2, &s2, &arm.body);
                    prism_rtl::Turn::More(Rc::new(crate::check::types::Unify { st: s3.clone(), expected: res.clone(), found: bt.clone(), span: arm.body.span.clone() }))
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    let st5 = crate::check::passes::match_coverage(env, &st4, &plain_scrut, arms, span);
    if *last {
        (res.clone(), st5.clone())
    } else {
        (res.clone(), discarded(&st5, &res, span))
    }
}

/// The step machine of `BuildingMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
/// ```
pub struct BuildingMatch {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub scrut: crate::syntax::Expr,
    pub arms: Array<crate::syntax::Arm>,
    pub span: crate::syntax::Range,
    pub last: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BuildingMatch {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let scrut = &self.scrut;
        let arms = &self.arms;
        let span = &self.span;
        let last = &self.last;
        let arms = arms.clone();
        let env = env.clone();
        let last = *last;
        let scrut = scrut.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), scrut.clone()), move |infer_15324: (crate::check::types::Ty, crate::check::types::St)| {
            let (st_ty, st1) = infer_15324;
            call_then(crate::check::types::start_head_sigil(st1.clone(), st_ty.clone()), move |head_sigil_15358: Text| {
                let sh = head_sigil_15358;
                let st2 = if crate::check::expr::is_time_sigil(&sh) {
                    crate::check::types::err_fix(&st1, &Text::lit("building-match"), &scrut.span, &Text::from(format!("a blueprint in a match over a {}; use `rebuild`", &(if &sh == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }))), &Text::from(format!("write `rebuild {}:` with `match _:` inside", &crate::check::expr::src_text(&env, &scrut.span))))
                } else {
                    st1.clone()
                };
                let plain_scrut = if crate::check::expr::is_time_sigil(&sh) {
                    crate::check::expr::inner_of(&st2, &st_ty)
                } else {
                    st_ty.clone()
                };
                let (res, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
                call_value(fold_job(arms.clone(), st3.clone(), {
                    let env = env.clone();
                    let plain_scrut = plain_scrut.clone();
                    let res = res.clone();
                    Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                        let env = env.clone();
                        let plain_scrut = plain_scrut.clone();
                        let res = res.clone();
                        entered(once_job(move || {
                            let s = p0;
                            let arm = p1;
                            {
                                let (env2, s1) = match &arm.pattern {
                                    Some(p_) => crate::check::expr::bind_pattern(&env, &s, p_, &plain_scrut, &true),
                                    None => (env.clone(), s.clone()),
                                };
                                let s2 = match &arm.guard {
                                    Some(gd) => crate::check::expr::check_cond(&env2, &s1, gd),
                                    None => s1.clone(),
                                };
                                let (bt, s3) = arm_widget_block(&env2, &s2, &arm.body);
                                prism_rtl::Turn::More(Rc::new(crate::check::types::Unify { st: s3.clone(), expected: res.clone(), found: bt.clone(), span: arm.body.span.clone() }))
                            }
                        }))
                    }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                }), move |fold_15749: crate::check::types::St| {
                    let st4 = fold_15749;
                    call_then(crate::check::passes::start_match_coverage(env.clone(), st4.clone(), plain_scrut.clone(), arms.clone(), span.clone()), move |match_coverage_16117: crate::check::types::St| {
                        let st5 = match_coverage_16117;
                        if last {
                            prism_rtl::Turn::Finished((res.clone(), st5.clone()))
                        } else {
                            call_then(start_discarded(st5.clone(), res.clone(), span.clone()), move |discarded_16204: crate::check::types::St| prism_rtl::Turn::Finished((res.clone(), discarded_16204)))
                        }
                    })
                })
            })
        })
    }
}

/// `Start BuildingMatch, x`: what the function value is when passed to `@Run`.
pub fn start_building_match(env: crate::check::expr::Env, st: crate::check::types::St, scrut: crate::syntax::Expr, arms: Array<crate::syntax::Arm>, span: crate::syntax::Range, last: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BuildingMatch { env, st, scrut, arms, span, last })
}

/// ```prism
/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
/// ```
pub fn building_if(env: &crate::check::expr::Env, st: &crate::check::types::St, c: &crate::syntax::Cond, then_b: &crate::syntax::Block, else_b_opt: &Option<crate::syntax::Block>, span: &crate::syntax::Range, last: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    let (env2, st1) = match c {
        crate::syntax::Cond::CondExpr(e) => {
            let (ct, s1) = crate::check::expr::infer(env, st, &**e);
            let sh = crate::check::types::head_sigil(&s1, &ct);
            let s2 = if crate::check::expr::is_time_sigil(&sh) {
                crate::check::types::err_fix(&s1, &Text::lit("building-match"), &e.span, &Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &Text::lit("write `rebuild` over the condition, with `if _:` inside"))
            } else {
                s1.clone()
            };
            (env.clone(), crate::check::types::unify(&s2, &crate::check::types::t_bool(), &(if crate::check::expr::is_time_sigil(&sh) {
                crate::check::expr::inner_of(&s2, &ct)
            } else {
                ct.clone()
            }), &e.span))
        },
        crate::syntax::Cond::CondBind(p_, e, gd_opt) => {
            let (et, s1) = crate::check::expr::infer(env, st, &**e);
            let (en, s2) = crate::check::expr::bind_pattern(env, &s1, p_, &et, &true);
            match &**gd_opt {
                Some(g) => (en.clone(), crate::check::expr::check_cond(&en, &s2, g)),
                None => (en.clone(), s2.clone()),
            }
        },
    };
    let (t1, st2) = arm_widget_block(&env2, &st1, then_b);
    match else_b_opt {
        Some(b) => {
            let (t2, st3) = arm_widget_block(env, &st2, b);
            let st4 = crate::check::types::unify(&st3, &t1, &t2, &b.span);
            if *last {
                (t1.clone(), st4.clone())
            } else {
                (t1.clone(), discarded(&st4, &t1, span))
            }
        },
        None => {
            let st3 = crate::check::types::unify(&st2, &crate::check::types::t_unit(), &t1, &then_b.span);
            (crate::check::types::t_unit(), st3.clone())
        },
    }
}

/// The step machine of `BuildingIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
/// ```
pub struct BuildingIf {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub c: crate::syntax::Cond,
    pub then_b: crate::syntax::Block,
    pub else_b_opt: Option<crate::syntax::Block>,
    pub span: crate::syntax::Range,
    pub last: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BuildingIf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let span = &self.span;
        let last = &self.last;
        let (env2, st1) = match c {
            crate::syntax::Cond::CondExpr(e) => {
                let (ct, s1) = crate::check::expr::infer(env, st, &**e);
                let sh = crate::check::types::head_sigil(&s1, &ct);
                let s2 = if crate::check::expr::is_time_sigil(&sh) {
                    crate::check::types::err_fix(&s1, &Text::lit("building-match"), &e.span, &Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &Text::lit("write `rebuild` over the condition, with `if _:` inside"))
                } else {
                    s1.clone()
                };
                (env.clone(), crate::check::types::unify(&s2, &crate::check::types::t_bool(), &(if crate::check::expr::is_time_sigil(&sh) {
                    crate::check::expr::inner_of(&s2, &ct)
                } else {
                    ct.clone()
                }), &e.span))
            },
            crate::syntax::Cond::CondBind(p_, e, gd_opt) => {
                let (et, s1) = crate::check::expr::infer(env, st, &**e);
                let (en, s2) = crate::check::expr::bind_pattern(env, &s1, p_, &et, &true);
                match &**gd_opt {
                    Some(g) => (en.clone(), crate::check::expr::check_cond(&en, &s2, g)),
                    None => (en.clone(), s2.clone()),
                }
            },
        };
        let (t1, st2) = arm_widget_block(&env2, &st1, then_b);
        match else_b_opt {
            Some(b) => {
                let (t2, st3) = arm_widget_block(env, &st2, b);
                let b = b.clone();
                let last = *last;
                let span = span.clone();
                call_then(crate::check::types::start_unify(st3.clone(), t1.clone(), t2.clone(), b.span.clone()), move |unify_17203: crate::check::types::St| {
                    let st4 = unify_17203;
                    if last {
                        prism_rtl::Turn::Finished((t1.clone(), st4.clone()))
                    } else {
                        call_then(start_discarded(st4.clone(), t1.clone(), span.clone()), move |discarded_17275: crate::check::types::St| prism_rtl::Turn::Finished((t1.clone(), discarded_17275)))
                    }
                })
            },
            None => {
                let span = span.clone();
                let then_b = then_b.clone();
                call_then(crate::check::types::start_unify(st2.clone(), crate::check::types::t_unit(), t1.clone(), then_b.span.clone()), move |unify_17337: crate::check::types::St| {
                    let st3 = unify_17337;
                    prism_rtl::Turn::Finished((crate::check::types::t_unit(), st3.clone()))
                })
            },
        }
    }
}

/// `Start BuildingIf, x`: what the function value is when passed to `@Run`.
pub fn start_building_if(env: crate::check::expr::Env, st: crate::check::types::St, c: crate::syntax::Cond, then_b: crate::syntax::Block, else_b_opt: Option<crate::syntax::Block>, span: crate::syntax::Range, last: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BuildingIf { env, st, c, then_b, else_b_opt, span, last })
}

/// ```prism
/// ArmWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub fn arm_widget_block(env: &crate::check::expr::Env, st: &crate::check::types::St, b: &crate::syntax::Block) -> (crate::check::types::Ty, crate::check::types::St) {
    infer_widget_block(env, st, b)
}

/// ```prism
/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_rebuild(env: &crate::check::expr::Env, st: &crate::check::types::St, scrut: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t, st1) = crate::check::expr::infer(env, st, scrut);
    let (inner, st2) = match crate::check::types::walk(&st1, &t) {
        crate::check::types::Ty::TySig(m18319_0_0, i) if (&m18319_0_0 == &Text::lit("$")) => ((*i).clone(), st1.clone()),
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st1.clone()),
        crate::check::types::Ty::TyFlex(_) => {
            let (v_, s2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
            (v_.clone(), crate::check::types::unify(&s2, &crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_.clone())), &t, &scrut.span))
        },
        other => (crate::check::types::Ty::TyErr, crate::check::types::err_fix(&st1, &Text::lit("mismatch"), &scrut.span, &Text::from(format!("`rebuild` builds over a dynamic; this is `{}`", &crate::check::types::show_ty(&st1, &other))), &Text::lit("a plain value is built once: write the block's lines in place"))),
        _ => unreachable!("no arm matched"),
    };
    let env2 = with_topic(env, &Text::lit("_"), &inner);
    let (res, st3) = infer_widget_block(&env2, &st2, body);
    match crate::check::types::walk(&st3, &res) {
        crate::check::types::Ty::TyCon(m18832_0_0, m18832_0_1) if (&m18832_0_0 == &Text::lit("unit")) && ((&m18832_0_1).len() == 0) => (crate::check::types::t_unit(), st3.clone()),
        other => (crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(other.clone())), st3.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InferRebuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferRebuild {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub scrut: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferRebuild {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let scrut = &self.scrut;
        let body = &self.body;
        let span = &self.span;
        let body = body.clone();
        let env = env.clone();
        let scrut = scrut.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), scrut.clone()), move |infer_18273: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st1) = infer_18273;
            call_then(crate::check::types::start_walk(st1.clone(), t.clone()), move |walk_18325: crate::check::types::Ty| {
                let (inner, st2) = match walk_18325 {
                    crate::check::types::Ty::TySig(m18319_0_0, i) if (&m18319_0_0 == &Text::lit("$")) => ((*i).clone(), st1.clone()),
                    crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st1.clone()),
                    crate::check::types::Ty::TyFlex(_) => {
                        let (v_, s2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
                        (v_.clone(), crate::check::types::unify(&s2, &crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_.clone())), &t, &scrut.span))
                    },
                    other => (crate::check::types::Ty::TyErr, crate::check::types::err_fix(&st1, &Text::lit("mismatch"), &scrut.span, &Text::from(format!("`rebuild` builds over a dynamic; this is `{}`", &crate::check::types::show_ty(&st1, &other))), &Text::lit("a plain value is built once: write the block's lines in place"))),
                    _ => unreachable!("no arm matched"),
                };
                let env2 = with_topic(&env, &Text::lit("_"), &inner);
                call_then(start_infer_widget_block(env2.clone(), st2.clone(), body.clone()), move |infer_widget_block_18795: (crate::check::types::Ty, crate::check::types::St)| {
                    let (res, st3) = infer_widget_block_18795;
                    call_then(crate::check::types::start_walk(st3.clone(), res.clone()), move |walk_18838: crate::check::types::Ty| match walk_18838 {
                        crate::check::types::Ty::TyCon(m18832_0_0, m18832_0_1) if (&m18832_0_0 == &Text::lit("unit")) && ((&m18832_0_1).len() == 0) => prism_rtl::Turn::Finished((crate::check::types::t_unit(), st3.clone())),
                        other => prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(other.clone())), st3.clone())),
                        _ => unreachable!("no arm matched"),
                    })
                })
            })
        })
    }
}

/// `Start InferRebuild, x`: what the function value is when passed to `@Run`.
pub fn start_infer_rebuild(env: crate::check::expr::Env, st: crate::check::types::St, scrut: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferRebuild { env, st, scrut, body, span })
}

/// ```prism
/// WithTopic: fn Env, Text, Ty -> Env
/// ```
pub fn with_topic(env: &crate::check::expr::Env, name: &Text, t: &crate::check::types::Ty) -> crate::check::expr::Env {
    let mut this: crate::check::expr::Env = crate::check::expr::with_local(env, name, &crate::check::types::mono(t));
    this.pending = filter(&this.pending, &(|x: &Text| x != name));
    this
}

/// ```prism
/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_for(env: &crate::check::expr::Env, st: &crate::check::types::St, binders_opt: &Option<crate::syntax::ForBinders>, source: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    if env.in_update {
        (crate::check::types::t_unit(), update_for(env, st, binders_opt, source, body, span))
    } else {
        {
            let (t, st1) = crate::check::expr::infer(env, st, source);
            let sh = crate::check::types::head_sigil(&st1, &t);
            let coll = if &sh == &Text::lit("$") { crate::check::expr::inner_of(&st1, &t) } else { t.clone() };
            let st2 = if (&sh == &Text::lit("!")) || (&sh == &Text::lit("@")) {
                crate::check::types::err(&st1, &Text::lit("mismatch"), &source.span, &Text::from(format!("`for` runs over a map or an array, plain or dynamic; this is `{}`", &crate::check::types::show_ty(&st1, &t))))
            } else {
                st1.clone()
            };
            let (k, v_, st3) = coll_parts(&st2, &coll, &source.span);
            let live = &sh == &Text::lit("$");
            let env1 = loop_indices(env);
            let (env2, st4) = bind_for_binders(&env1, &st3, binders_opt, &k, &v_, &live);
            let (res, st5) = infer_widget_block(&env2, &st4, body);
            gather(&st5, &res, &k, &live)
        }
    }
}

/// The step machine of `InferFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferFor {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub binders_opt: Option<crate::syntax::ForBinders>,
    pub source: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferFor {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let binders_opt = &self.binders_opt;
        let source = &self.source;
        let body = &self.body;
        let span = &self.span;
        if env.in_update {
            {
                let binders_opt = binders_opt.clone();
                let body = body.clone();
                let env = env.clone();
                let source = source.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(start_update_for(env.clone(), st.clone(), binders_opt.clone(), source.clone(), body.clone(), span.clone()), move |update_for_19423: crate::check::types::St| prism_rtl::Turn::Finished((crate::check::types::t_unit(), update_for_19423)))
            }
        } else {
            {
                let binders_opt = binders_opt.clone();
                let body = body.clone();
                let env = env.clone();
                let source = source.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), source.clone()), move |infer_19509: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st1) = infer_19509;
                    call_then(crate::check::types::start_head_sigil(st1.clone(), t.clone()), move |head_sigil_19548: Text| {
                        let sh = head_sigil_19548;
                        let coll = if &sh == &Text::lit("$") { crate::check::expr::inner_of(&st1, &t) } else { t.clone() };
                        let st2 = if (&sh == &Text::lit("!")) || (&sh == &Text::lit("@")) {
                            crate::check::types::err(&st1, &Text::lit("mismatch"), &source.span, &Text::from(format!("`for` runs over a map or an array, plain or dynamic; this is `{}`", &crate::check::types::show_ty(&st1, &t))))
                        } else {
                            st1.clone()
                        };
                        call_then(start_coll_parts(st2.clone(), coll.clone(), source.span.clone()), move |coll_parts_19819: (crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)| {
                            let (k, v_, st3) = coll_parts_19819;
                            let live = &sh == &Text::lit("$");
                            let env1 = loop_indices(&env);
                            call_then(start_bind_for_binders(env1.clone(), st3.clone(), binders_opt.clone(), k.clone(), v_.clone(), live), move |bind_for_binders_19944: (crate::check::expr::Env, crate::check::types::St)| {
                                let (env2, st4) = bind_for_binders_19944;
                                call_then(start_infer_widget_block(env2.clone(), st4.clone(), body.clone()), move |infer_widget_block_20018: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (res, st5) = infer_widget_block_20018;
                                    prism_rtl::Turn::More(Rc::new(Gather { st: st5.clone(), res: res.clone(), k: k.clone(), live }))
                                })
                            })
                        })
                    })
                })
            }
        }
    }
}

/// `Start InferFor, x`: what the function value is when passed to `@Run`.
pub fn start_infer_for(env: crate::check::expr::Env, st: crate::check::types::St, binders_opt: Option<crate::syntax::ForBinders>, source: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferFor { env, st, binders_opt, source, body, span })
}

/// ```prism
/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
/// ```
pub fn coll_parts(st: &crate::check::types::St, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St) {
    'm20211: {
        let scrutinee = &crate::check::types::walk(st, t);
        if let crate::check::types::Ty::TyMap(k, v_) = scrutinee {
            break 'm20211 ((**k).clone(), (**v_).clone(), st.clone());
        }
        if let crate::check::types::Ty::TyArray(v_) = scrutinee {
            break 'm20211 (crate::check::types::t_nat(), (**v_).clone(), st.clone());
        }
        if let crate::check::types::Ty::TyCon(m20211_2_0, m20211_2_1) = scrutinee && (m20211_2_0 == &Text::lit("Buffer")) && (m20211_2_1.len() == 1) && let Some(v_) = index(m20211_2_1, &Nat::from(0u32)) {
            break 'm20211 (crate::check::types::t_nat(), v_.clone(), st.clone());
        }
        if let crate::check::types::Ty::TyErr = scrutinee {
            break 'm20211 (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, st.clone());
        }
        if let crate::check::types::Ty::TyFlex(_) = scrutinee {
            break 'm20211 {
                let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                (crate::check::types::t_nat(), v_.clone(), crate::check::types::unify(&st2, &crate::check::types::Ty::TyArray(Rc::new(v_.clone())), t, span))
            };
        }
        if let other = scrutinee {
            break 'm20211 (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, crate::check::types::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`for` runs over a map or an array; this is `{}`", &crate::check::types::show_ty(st, other)))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CollParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
/// ```
pub struct CollParts {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)> for CollParts {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)> {
        let st = &self.st;
        let t = &self.t;
        let span = &self.span;
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::start_walk(st.clone(), t.clone()), move |walk_20217: crate::check::types::Ty| 'm20211: {
            if let crate::check::types::Ty::TyMap(k, v_) = &walk_20217 {
                break 'm20211 prism_rtl::Turn::Finished(((**k).clone(), (**v_).clone(), st.clone()));
            }
            if let crate::check::types::Ty::TyArray(v_) = &walk_20217 {
                break 'm20211 prism_rtl::Turn::Finished((crate::check::types::t_nat(), (**v_).clone(), st.clone()));
            }
            if let crate::check::types::Ty::TyCon(m20211_2_0, m20211_2_1) = &walk_20217 && (m20211_2_0 == &Text::lit("Buffer")) && (m20211_2_1.len() == 1) && let Some(v_) = index(m20211_2_1, &Nat::from(0u32)) {
                break 'm20211 prism_rtl::Turn::Finished((crate::check::types::t_nat(), v_.clone(), st.clone()));
            }
            if let crate::check::types::Ty::TyErr = &walk_20217 {
                break 'm20211 prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, st.clone()));
            }
            if let crate::check::types::Ty::TyFlex(_) = &walk_20217 {
                break 'm20211 {
                    let (v_, st2) = crate::check::types::fresh_var(&st, &false, &Text::lit(""));
                    call_then(crate::check::types::start_unify(st2.clone(), crate::check::types::Ty::TyArray(Rc::new(v_.clone())), t.clone(), span.clone()), move |unify_20451: crate::check::types::St| prism_rtl::Turn::Finished((crate::check::types::t_nat(), v_.clone(), unify_20451)))
                };
            }
            if let other = &walk_20217 {
                break 'm20211 {
                    let other = other.clone();
                    call_then(crate::check::types::start_show_ty(st.clone(), other.clone()), move |show_ty_20586: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, crate::check::types::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("`for` runs over a map or an array; this is `{}`", &show_ty_20586))))))
                };
            }
            unreachable!("no clause matched")
        })
    }
}

/// `Start CollParts, x`: what the function value is when passed to `@Run`.
pub fn start_coll_parts(st: crate::check::types::St, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(CollParts { st, t, span })
}

/// ```prism
/// LoopIndices: fn Env -> Env
/// ```
pub fn loop_indices(env: &crate::check::expr::Env) -> crate::check::expr::Env {
    let outer1_opt = get(&env.locals, &Text::lit("ix"));
    let outer2_opt = get(&env.locals, &Text::lit("jx"));
    let e1 = crate::check::expr::with_local(env, &Text::lit("ix"), &crate::check::types::mono(&crate::check::types::t_nat()));
    let e2 = match &outer1_opt {
        Some(sc) => crate::check::expr::with_local(&e1, &Text::lit("jx"), sc),
        None => e1.clone(),
    };
    match &outer2_opt {
        Some(sc) => crate::check::expr::with_local(&e2, &Text::lit("kx"), sc),
        None => e2.clone(),
    }
}

/// ```prism
/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_for_binders(env: &crate::check::expr::Env, st: &crate::check::types::St, binders_opt: &Option<crate::syntax::ForBinders>, k: &crate::check::types::Ty, v_: &crate::check::types::Ty, live: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    let vt = if *live {
        crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_.clone()))
    } else {
        v_.clone()
    };
    match binders_opt {
        None => {
            let e1 = with_topic(env, &(if *live { Text::lit("$_") } else { Text::lit("_") }), &vt);
            (with_topic(&e1, &Text::lit("key"), k), st.clone())
        },
        Some(bs) => match &bs.second {
            Some(second) => {
                let (e1, st1) = crate::check::expr::bind_pattern(&unpending(env), st, &bs.first, k, &false);
                crate::check::expr::bind_pattern(&e1, &st1, second, &vt, &false)
            },
            None => {
                let e1 = with_topic(env, &Text::lit("key"), k);
                crate::check::expr::bind_pattern(&unpending(&e1), st, &bs.first, &vt, &false)
            },
        },
    }
}

/// The step machine of `BindForBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
/// ```
pub struct BindForBinders {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub binders_opt: Option<crate::syntax::ForBinders>,
    pub k: crate::check::types::Ty,
    pub v_: crate::check::types::Ty,
    pub live: bool,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindForBinders {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let binders_opt = &self.binders_opt;
        let k = &self.k;
        let v_ = &self.v_;
        let live = &self.live;
        let vt = if *live {
            crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_.clone()))
        } else {
            v_.clone()
        };
        match binders_opt {
            None => {
                let e1 = with_topic(env, &(if *live { Text::lit("$_") } else { Text::lit("_") }), &vt);
                prism_rtl::Turn::Finished((with_topic(&e1, &Text::lit("key"), k), st.clone()))
            },
            Some(bs) => match &bs.second {
                Some(second) => {
                    let bs = bs.clone();
                    let env = env.clone();
                    let k = k.clone();
                    let second = second.clone();
                    let st = st.clone();
                    call_then(crate::check::expr::start_bind_pattern(unpending(&env), st.clone(), bs.first.clone(), k.clone(), false), move |bind_pattern_21582: (crate::check::expr::Env, crate::check::types::St)| {
                        let (e1, st1) = bind_pattern_21582;
                        prism_rtl::Turn::More(Rc::new(crate::check::expr::BindPattern { env: e1.clone(), st: st1.clone(), p_: second.clone(), t: vt.clone(), refutable: false }))
                    })
                },
                None => {
                    let e1 = with_topic(env, &Text::lit("key"), k);
                    prism_rtl::Turn::More(Rc::new(crate::check::expr::BindPattern { env: unpending(&e1), st: st.clone(), p_: bs.first.clone(), t: vt.clone(), refutable: false }))
                },
            },
        }
    }
}

/// `Start BindForBinders, x`: what the function value is when passed to `@Run`.
pub fn start_bind_for_binders(env: crate::check::expr::Env, st: crate::check::types::St, binders_opt: Option<crate::syntax::ForBinders>, k: crate::check::types::Ty, v_: crate::check::types::Ty, live: bool) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindForBinders { env, st, binders_opt, k, v_, live })
}

/// ```prism
/// Unpending: fn Env -> Env
/// ```
pub fn unpending(env: &crate::check::expr::Env) -> crate::check::expr::Env {
    let mut this: crate::check::expr::Env = env.clone();
    this.pending = Array::new();
    this
}

/// ```prism
/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
/// ```
pub fn gather(st: &crate::check::types::St, res: &crate::check::types::Ty, k: &crate::check::types::Ty, live: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::check::types::walk(st, res) {
        crate::check::types::Ty::TyCon(m22248_0_0, m22248_0_1) if (&m22248_0_0 == &Text::lit("unit")) && ((&m22248_0_1).len() == 0) => (crate::check::types::t_unit(), st.clone()),
        crate::check::types::Ty::TySig(m22248_1_0, t) if (&m22248_1_0 == &Text::lit("!")) => (crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new((*t).clone())))), st.clone()),
        crate::check::types::Ty::TySig(m22248_2_0, t) if (&m22248_2_0 == &Text::lit("$")) => (crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new((*t).clone())))), st.clone()),
        crate::check::types::Ty::TyTuple(ts) => if run_to_end(fold_job(ts.clone(), false, {
            let st = st.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(seen || crate::check::expr::is_time_sigil(&crate::check::types::head_sigil(&st, &x)))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })) {
            {
                let (parts, st2) = run_to_end(fold_job(ts.clone(), (Array::new(), st.clone()), {
                    let k = k.clone();
                    let live = *live;
                    Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)| {
                        let k = k.clone();
                        let live = live;
                        entered(once_job(move || {
                            let (acc, s) = p0;
                            let x = p1;
                            call_then(start_gather(s.clone(), x.clone(), k.clone(), live), move |gather_22608: (crate::check::types::Ty, crate::check::types::St)| {
                                let (g, s2) = gather_22608;
                                prism_rtl::Turn::Finished((push(&acc, &g), s2.clone()))
                            })
                        }))
                    }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
                }));
                (crate::check::types::Ty::TyTuple(parts.clone()), st2.clone())
            }
        } else {
            (live_map(live, k, &crate::check::types::Ty::TyTuple(ts.clone())), st.clone())
        },
        other => (live_map(live, k, &other), st.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Gather`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
/// ```
pub struct Gather {
    pub st: crate::check::types::St,
    pub res: crate::check::types::Ty,
    pub k: crate::check::types::Ty,
    pub live: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for Gather {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st = &self.st;
        let res = &self.res;
        let k = &self.k;
        let live = &self.live;
        let k = k.clone();
        let live = *live;
        let res = res.clone();
        let st = st.clone();
        call_then(crate::check::types::start_walk(st.clone(), res.clone()), move |walk_22254: crate::check::types::Ty| match walk_22254 {
            crate::check::types::Ty::TyCon(m22248_0_0, m22248_0_1) if (&m22248_0_0 == &Text::lit("unit")) && ((&m22248_0_1).len() == 0) => prism_rtl::Turn::Finished((crate::check::types::t_unit(), st.clone())),
            crate::check::types::Ty::TySig(m22248_1_0, t) if (&m22248_1_0 == &Text::lit("!")) => prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new((*t).clone())))), st.clone())),
            crate::check::types::Ty::TySig(m22248_2_0, t) if (&m22248_2_0 == &Text::lit("$")) => prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new((*t).clone())))), st.clone())),
            crate::check::types::Ty::TyTuple(ts) => call_value(fold_job(ts.clone(), false, {
                let st = st.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(seen || crate::check::expr::is_time_sigil(&crate::check::types::head_sigil(&st, &x)))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |fold_22437: bool| if fold_22437 {
                call_value(fold_job(ts.clone(), (Array::new(), st.clone()), {
                    let k = k.clone();
                    let live = live;
                    Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)| {
                        let k = k.clone();
                        let live = live;
                        entered(once_job(move || {
                            let (acc, s) = p0;
                            let x = p1;
                            call_then(start_gather(s.clone(), x.clone(), k.clone(), live), move |gather_22608: (crate::check::types::Ty, crate::check::types::St)| {
                                let (g, s2) = gather_22608;
                                prism_rtl::Turn::Finished((push(&acc, &g), s2.clone()))
                            })
                        }))
                    }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
                }), move |fold_22536: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (parts, st2) = fold_22536;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyTuple(parts.clone()), st2.clone()))
                })
            } else {
                prism_rtl::Turn::Finished((live_map(&live, &k, &crate::check::types::Ty::TyTuple(ts.clone())), st.clone()))
            }),
            other => prism_rtl::Turn::Finished((live_map(&live, &k, &other), st.clone())),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start Gather, x`: what the function value is when passed to `@Run`.
pub fn start_gather(st: crate::check::types::St, res: crate::check::types::Ty, k: crate::check::types::Ty, live: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(Gather { st, res, k, live })
}

/// ```prism
/// LiveMap: fn Bool, Ty, Ty -> Ty
/// ```
pub fn live_map(live: &bool, k: &crate::check::types::Ty, v_: &crate::check::types::Ty) -> crate::check::types::Ty {
    if *live {
        crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone()))))
    } else {
        crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone()))
    }
}

/// ```prism
/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
/// ```
pub fn infer_given(env: &crate::check::expr::Env, st: &crate::check::types::St, b: &crate::syntax::Block, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let mark = if (&env.mark == &Text::lit("?")) || (&env.mark == &Text::lit("~")) {
        env.mark.clone()
    } else {
        given_mark_of(&b.stmts)
    };
    infer_given_block(env, st, b, &mark)
}

/// The step machine of `InferGiven`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
/// ```
pub struct InferGiven {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub b: crate::syntax::Block,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferGiven {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let span = &self.span;
        let mark = if (&env.mark == &Text::lit("?")) || (&env.mark == &Text::lit("~")) {
            env.mark.clone()
        } else {
            given_mark_of(&b.stmts)
        };
        prism_rtl::Turn::More(Rc::new(InferGivenBlock { env: env.clone(), st: st.clone(), b: b.clone(), mark: mark.clone() }))
    }
}

/// `Start InferGiven, x`: what the function value is when passed to `@Run`.
pub fn start_infer_given(env: crate::check::expr::Env, st: crate::check::types::St, b: crate::syntax::Block, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferGiven { env, st, b, span })
}

/// ```prism
/// GivenMarkOf: fn [Stmt] -> Text
/// ```
pub fn given_mark_of(stmts: &Array<crate::syntax::Stmt>) -> Text {
    fold(stmts, &Text::lit("?"), &(|m: &Text, s: &crate::syntax::Stmt| m.clone()))
}

/// ```prism
/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
/// ```
pub fn infer_given_block(env: &crate::check::expr::Env, st: &crate::check::types::St, b: &crate::syntax::Block, mark: &Text) -> (crate::check::types::Ty, crate::check::types::St) {
    let n = len(&b.stmts);
    let (env2, st2, res_opt) = run_to_end(fold_job(crate::check::errors::range0(&n), (env.clone(), st.clone(), None), {
        let b = b.clone();
        let mark = mark.clone();
        let n = n.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)| {
            let b = b.clone();
            let mark = mark.clone();
            let n = n.clone();
            entered(once_job(move || {
                let (en, s, r_opt) = p0;
                let i = p1;
                {
                    let stmt = or(&index(&b.stmts, &i), &dummy_stmt2());
                    prism_rtl::Turn::More(Rc::new(GivenStmt { env: en.clone(), st: s.clone(), s: stmt.clone(), mark: mark.clone(), last: &(&i + &Nat::from(1u32)) == &n, res_opt: r_opt.clone() }))
                }
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>>>
    }));
    match &res_opt {
        Some(t) => (t.clone(), st2.clone()),
        None => {
            let (v_, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
            (crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), st3.clone())
        },
    }
}

/// The step machine of `InferGivenBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
/// ```
pub struct InferGivenBlock {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub b: crate::syntax::Block,
    pub mark: Text,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferGivenBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let mark = &self.mark;
        let n = len(&b.stmts);
        let b = b.clone();
        let env = env.clone();
        let mark = mark.clone();
        let st = st.clone();
        call_value(fold_job(crate::check::errors::range0(&n), (env.clone(), st.clone(), None), {
            let b = b.clone();
            let mark = mark.clone();
            let n = n.clone();
            Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)| {
                let b = b.clone();
                let mark = mark.clone();
                let n = n.clone();
                entered(once_job(move || {
                    let (en, s, r_opt) = p0;
                    let i = p1;
                    {
                        let stmt = or(&index(&b.stmts, &i), &dummy_stmt2());
                        prism_rtl::Turn::More(Rc::new(GivenStmt { env: en.clone(), st: s.clone(), s: stmt.clone(), mark: mark.clone(), last: &(&i + &Nat::from(1u32)) == &n, res_opt: r_opt.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>>>
        }), move |fold_23805: (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)| {
            let (env2, st2, res_opt) = fold_23805;
            match &res_opt {
                Some(t) => prism_rtl::Turn::Finished((t.clone(), st2.clone())),
                None => {
                    let (v_, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), st3.clone()))
                },
            }
        })
    }
}

/// `Start InferGivenBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_given_block(env: crate::check::expr::Env, st: crate::check::types::St, b: crate::syntax::Block, mark: Text) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferGivenBlock { env, st, b, mark })
}

/// ```prism
/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
/// ```
pub fn given_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, s: &crate::syntax::Stmt, mark: &Text, last: &bool, res_opt: &Option<crate::check::types::Ty>) -> (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>) {
    match &s.kind {
        crate::syntax::StmtKind::SBind(p_, e, None) => {
            let (t, st1) = crate::check::expr::infer(env, st, e);
            let (v_, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
            let st3 = crate::check::types::unify(&st2, &crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), &t, &e.span);
            let (env2, st4) = crate::check::expr::bind_pattern(&unpending(env), &st3, p_, &v_, &true);
            (env2.clone(), st4.clone(), res_opt.clone())
        },
        crate::syntax::StmtKind::SRequire(c) => (env.clone(), crate::check::expr::check_cond(env, st, c), res_opt.clone()),
        crate::syntax::StmtKind::SForbid(c) => (env.clone(), crate::check::expr::check_cond(env, st, c), res_opt.clone()),
        crate::syntax::StmtKind::SLet(p_, ty_opt, e) => {
            let (env2, st2) = crate::check::expr::check_let(env, st, p_, ty_opt, e, &s.span);
            (env2.clone(), st2.clone(), res_opt.clone())
        },
        crate::syntax::StmtKind::SFn(f) => {
            let (env1, st1) = crate::check::expr::pre_bind(env, st, s);
            let (env2, st2) = crate::check::expr::check_local_fn(&env1, &st1, f, &s.span);
            (env2.clone(), st2.clone(), res_opt.clone())
        },
        crate::syntax::StmtKind::SSignature(_) => {
            let (env2, st2) = crate::check::expr::pre_bind(env, st, s);
            (env2.clone(), st2.clone(), res_opt.clone())
        },
        crate::syntax::StmtKind::SExpr(e) => if *last {
            {
                let (t, st1) = crate::check::expr::infer(env, st, e);
                let (v_, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
                let st3 = crate::check::types::unify(&st2, &crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), &t, &e.span);
                (env.clone(), st3.clone(), Some(crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone()))))
            }
        } else {
            {
                let (t, st1) = crate::check::expr::infer(env, st, e);
                (env.clone(), discarded(&st1, &t, &e.span), res_opt.clone())
            }
        },
        _ => (env.clone(), crate::check::types::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a widget or `update` block")), res_opt.clone()),
    }
}

/// The step machine of `GivenStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
/// ```
pub struct GivenStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub s: crate::syntax::Stmt,
    pub mark: Text,
    pub last: bool,
    pub res_opt: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)> for GivenStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        let mark = &self.mark;
        let last = &self.last;
        let res_opt = &self.res_opt;
        match &s.kind {
            crate::syntax::StmtKind::SBind(p_, e, None) => {
                let res_opt = res_opt.clone();
                let e = e.clone();
                let env = env.clone();
                let mark = mark.clone();
                let p_ = p_.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_24280: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st1) = infer_24280;
                    let (v_, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
                    call_then(crate::check::types::start_unify(st2.clone(), crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), t.clone(), e.span.clone()), move |unify_24364: crate::check::types::St| {
                        let st3 = unify_24364;
                        call_then(crate::check::expr::start_bind_pattern(unpending(&env), st3.clone(), p_.clone(), v_.clone(), true), move |bind_pattern_24430: (crate::check::expr::Env, crate::check::types::St)| {
                            let (env2, st4) = bind_pattern_24430;
                            prism_rtl::Turn::Finished((env2.clone(), st4.clone(), res_opt.clone()))
                        })
                    })
                })
            },
            crate::syntax::StmtKind::SRequire(c) => {
                let res_opt = res_opt.clone();
                let c = c.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_check_cond(env.clone(), st.clone(), c.clone()), move |check_cond_24527: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), check_cond_24527, res_opt.clone())))
            },
            crate::syntax::StmtKind::SForbid(c) => {
                let res_opt = res_opt.clone();
                let c = c.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_check_cond(env.clone(), st.clone(), c.clone()), move |check_cond_24580: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), check_cond_24580, res_opt.clone())))
            },
            crate::syntax::StmtKind::SLet(p_, ty_opt, e) => {
                let res_opt = res_opt.clone();
                let ty_opt = ty_opt.clone();
                let e = e.clone();
                let env = env.clone();
                let p_ = p_.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_check_let(env.clone(), st.clone(), p_.clone(), ty_opt.clone(), e.clone(), s.span.clone()), move |check_let_24658: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2, st2) = check_let_24658;
                    prism_rtl::Turn::Finished((env2.clone(), st2.clone(), res_opt.clone()))
                })
            },
            crate::syntax::StmtKind::SFn(f) => {
                let res_opt = res_opt.clone();
                let env = env.clone();
                let f = f.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_pre_bind(env.clone(), st.clone(), s.clone()), move |pre_bind_24761: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env1, st1) = pre_bind_24761;
                    call_then(crate::check::expr::start_check_local_fn(env1.clone(), st1.clone(), f.clone(), s.span.clone()), move |check_local_fn_24808: (crate::check::expr::Env, crate::check::types::St)| {
                        let (env2, st2) = check_local_fn_24808;
                        prism_rtl::Turn::Finished((env2.clone(), st2.clone(), res_opt.clone()))
                    })
                })
            },
            crate::syntax::StmtKind::SSignature(_) => {
                let res_opt = res_opt.clone();
                let env = env.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_pre_bind(env.clone(), st.clone(), s.clone()), move |pre_bind_24921: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2, st2) = pre_bind_24921;
                    prism_rtl::Turn::Finished((env2.clone(), st2.clone(), res_opt.clone()))
                })
            },
            crate::syntax::StmtKind::SExpr(e) => if *last {
                {
                    let e = e.clone();
                    let env = env.clone();
                    let last = *last;
                    let mark = mark.clone();
                    let st = st.clone();
                    call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_25027: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t, st1) = infer_25027;
                        let (v_, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
                        call_then(crate::check::types::start_unify(st2.clone(), crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), t.clone(), e.span.clone()), move |unify_25119: crate::check::types::St| {
                            let st3 = unify_25119;
                            prism_rtl::Turn::Finished((env.clone(), st3.clone(), Some(crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone())))))
                        })
                    })
                }
            } else {
                {
                    let res_opt = res_opt.clone();
                    let e = e.clone();
                    let env = env.clone();
                    let st = st.clone();
                    call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_25386: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t, st1) = infer_25386;
                        call_then(start_discarded(st1.clone(), t.clone(), e.span.clone()), move |discarded_25423: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), discarded_25423, res_opt.clone())))
                    })
                }
            },
            _ => prism_rtl::Turn::Finished((env.clone(), crate::check::types::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a widget or `update` block")), res_opt.clone())),
        }
    }
}

/// `Start GivenStmt, x`: what the function value is when passed to `@Run`.
pub fn start_given_stmt(env: crate::check::expr::Env, st: crate::check::types::St, s: crate::syntax::Stmt, mark: Text, last: bool, res_opt: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>> {
    Rc::new(GivenStmt { env, st, s, mark, last, res_opt })
}

/// ```prism
/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_update(env: &crate::check::expr::Env, st: &crate::check::types::St, target: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t, st1) = crate::check::expr::infer(env, st, target);
    let sh = crate::check::types::head_sigil(&st1, &t);
    let st2 = if crate::check::expr::is_time_sigil(&sh) || (&sh == &Text::lit("@")) {
        crate::check::types::err_fix(&st1, &Text::lit("time-in-update"), &target.span, &Text::from(format!("`update` over a `{}`", &crate::check::types::show_ty(&st1, &t))), &Text::lit("update the plain value, and lift the function that does it"))
    } else {
        st1.clone()
    };
    let env2 = {
        let mut this: crate::check::expr::Env = with_topic(env, &Text::lit("&_"), &t);
        this.in_update = true;
        this
    };
    let (_, st3) = update_stmts(&env2, &st2, &body.stmts);
    let st4 = crate::check::passes::and_block_checks(&env2, &st3, body, &t);
    (t.clone(), st4.clone())
}

/// The step machine of `InferUpdate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferUpdate {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub target: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferUpdate {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let target = &self.target;
        let body = &self.body;
        let span = &self.span;
        let body = body.clone();
        let env = env.clone();
        let span = span.clone();
        let st = st.clone();
        let target = target.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), target.clone()), move |infer_26215: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st1) = infer_26215;
            call_then(crate::check::types::start_head_sigil(st1.clone(), t.clone()), move |head_sigil_26250: Text| {
                let sh = head_sigil_26250;
                let st2 = if crate::check::expr::is_time_sigil(&sh) || (&sh == &Text::lit("@")) {
                    crate::check::types::err_fix(&st1, &Text::lit("time-in-update"), &target.span, &Text::from(format!("`update` over a `{}`", &crate::check::types::show_ty(&st1, &t))), &Text::lit("update the plain value, and lift the function that does it"))
                } else {
                    st1.clone()
                };
                let env2 = {
                    let mut this: crate::check::expr::Env = with_topic(&env, &Text::lit("&_"), &t);
                    this.in_update = true;
                    this
                };
                call_then(start_update_stmts(env2.clone(), st2.clone(), body.stmts.clone()), move |update_stmts_26568: (crate::check::expr::Env, crate::check::types::St)| {
                    let (_, st3) = update_stmts_26568;
                    call_then(crate::check::passes::start_and_block_checks(env2.clone(), st3.clone(), body.clone(), t.clone()), move |and_block_checks_26616: crate::check::types::St| {
                        let st4 = and_block_checks_26616;
                        prism_rtl::Turn::Finished((t.clone(), st4.clone()))
                    })
                })
            })
        })
    }
}

/// `Start InferUpdate, x`: what the function value is when passed to `@Run`.
pub fn start_infer_update(env: crate::check::expr::Env, st: crate::check::types::St, target: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferUpdate { env, st, target, body, span })
}

/// ```prism
/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub fn update_stmts(env: &crate::check::expr::Env, st: &crate::check::types::St, stmts: &Array<crate::syntax::Stmt>) -> (crate::check::expr::Env, crate::check::types::St) {
    run_to_end(fold_job(stmts.clone(), (env.clone(), st.clone()), Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| entered(once_job(move || {
        let (en, s) = p0;
        let stmt = p1;
        prism_rtl::Turn::More(Rc::new(UpdateStmt { env: en.clone(), st: s.clone(), s: stmt.clone() }))
    }))) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>))
}

/// The step machine of `UpdateStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub struct UpdateStmts {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for UpdateStmts {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        fold_job(stmts.clone(), (env.clone(), st.clone()), Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| entered(once_job(move || {
            let (en, s) = p0;
            let stmt = p1;
            prism_rtl::Turn::More(Rc::new(UpdateStmt { env: en.clone(), st: s.clone(), s: stmt.clone() }))
        }))) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>).cycle()
    }
}

/// `Start UpdateStmts, x`: what the function value is when passed to `@Run`.
pub fn start_update_stmts(env: crate::check::expr::Env, st: crate::check::types::St, stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(UpdateStmts { env, st, stmts })
}

/// ```prism
/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub fn update_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, s: &crate::syntax::Stmt) -> (crate::check::expr::Env, crate::check::types::St) {
    match &s.kind {
        crate::syntax::StmtKind::SSet(target, value) => {
            let (tt, st1) = crate::check::expr::infer(env, st, target);
            let st2 = ref_target(env, &st1, target);
            (env.clone(), crate::check::expr::check(env, &st2, value, &tt))
        },
        crate::syntax::StmtKind::SAccum(target, op, value) => {
            let (tt, st1) = crate::check::expr::infer(env, st, target);
            let st2 = ref_target(env, &st1, target);
            let st3 = crate::check::expr::check(env, &st2, value, &tt);
            let st4 = crate::check::expr::add_want(&st3, &Text::lit("Prelude.Num"), &tt, &s.span);
            let st5 = if op == &Text::lit("-=") {
                crate::check::expr::add_want(&st4, &Text::lit("Prelude.Sub"), &tt, &s.span)
            } else {
                st4.clone()
            };
            (env.clone(), st5.clone())
        },
        crate::syntax::StmtKind::SLet(p_, ty_opt, e) => {
            let (t, st1) = crate::check::expr::infer(env, st, e);
            let st2 = match ty_opt {
                Some(ty) => {
                    let (at_, s2) = crate::check::env::conv_type(&crate::check::expr::env_cx(env), &st1, ty);
                    crate::check::types::unify(&s2, &at_, &t, &e.span)
                },
                None => st1.clone(),
            };
            let (env2, st3) = crate::check::expr::bind_pattern(&unpending(env), &st2, p_, &t, &false);
            (env2.clone(), st3.clone())
        },
        crate::syntax::StmtKind::SWhile(c, body) => (env.clone(), update_while(env, st, c, body)),
        crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
            crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => (env.clone(), update_if(env, st, &**c, then_b, else_b_opt)),
            crate::syntax::ExprKind::EMatch(scrut, arms) => (env.clone(), update_match(env, st, &**scrut, arms, &e.span)),
            crate::syntax::ExprKind::EFor(binders_opt, source, body) => (env.clone(), update_for(env, st, binders_opt, &**source, body, &e.span)),
            _ => {
                let (t, st1) = crate::check::expr::infer(env, st, e);
                (env.clone(), discarded(&st1, &t, &e.span))
            },
        },
        crate::syntax::StmtKind::SFn(f) => {
            let (env1, st1) = crate::check::expr::pre_bind(env, st, s);
            crate::check::expr::check_local_fn(&env1, &st1, f, &s.span)
        },
        crate::syntax::StmtKind::SSignature(_) => crate::check::expr::pre_bind(env, st, s),
        _ => (env.clone(), crate::check::types::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a widget or `given:` block"))),
    }
}

/// The step machine of `UpdateStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub struct UpdateStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for UpdateStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SSet(target, value) => {
                let env = env.clone();
                let st = st.clone();
                let target = target.clone();
                let value = value.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), target.clone()), move |infer_26968: (crate::check::types::Ty, crate::check::types::St)| {
                    let (tt, st1) = infer_26968;
                    let st2 = ref_target(&env, &st1, &target);
                    call_then(crate::check::expr::start_check(env.clone(), st2.clone(), value.clone(), tt.clone()), move |check_27051: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), check_27051)))
                })
            },
            crate::syntax::StmtKind::SAccum(target, op, value) => {
                let env = env.clone();
                let op = op.clone();
                let s = s.clone();
                let st = st.clone();
                let target = target.clone();
                let value = value.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), target.clone()), move |infer_27136: (crate::check::types::Ty, crate::check::types::St)| {
                    let (tt, st1) = infer_27136;
                    let st2 = ref_target(&env, &st1, &target);
                    call_then(crate::check::expr::start_check(env.clone(), st2.clone(), value.clone(), tt.clone()), move |check_27221: crate::check::types::St| {
                        let st3 = check_27221;
                        let st4 = crate::check::expr::add_want(&st3, &Text::lit("Prelude.Num"), &tt, &s.span);
                        let st5 = if &op == &Text::lit("-=") {
                            crate::check::expr::add_want(&st4, &Text::lit("Prelude.Sub"), &tt, &s.span)
                        } else {
                            st4.clone()
                        };
                        prism_rtl::Turn::Finished((env.clone(), st5.clone()))
                    })
                })
            },
            crate::syntax::StmtKind::SLet(p_, ty_opt, e) => {
                let ty_opt = ty_opt.clone();
                let e = e.clone();
                let env = env.clone();
                let p_ = p_.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_27452: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st1) = infer_27452;
                    let st2 = match &ty_opt {
                        Some(ty) => {
                            let (at_, s2) = crate::check::env::conv_type(&crate::check::expr::env_cx(&env), &st1, ty);
                            crate::check::types::unify(&s2, &at_, &t, &e.span)
                        },
                        None => st1.clone(),
                    };
                    call_then(crate::check::expr::start_bind_pattern(unpending(&env), st2.clone(), p_.clone(), t.clone(), false), move |bind_pattern_27668: (crate::check::expr::Env, crate::check::types::St)| {
                        let (env2, st3) = bind_pattern_27668;
                        prism_rtl::Turn::Finished((env2.clone(), st3.clone()))
                    })
                })
            },
            crate::syntax::StmtKind::SWhile(c, body) => {
                let body = body.clone();
                let c = c.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(start_update_while(env.clone(), st.clone(), c.clone(), body.clone()), move |update_while_27764: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), update_while_27764)))
            },
            crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => {
                    let else_b_opt = else_b_opt.clone();
                    let c = (**c).clone();
                    let env = env.clone();
                    let st = st.clone();
                    let then_b = then_b.clone();
                    call_then(start_update_if(env.clone(), st.clone(), c.clone(), then_b.clone(), else_b_opt.clone()), move |update_if_27861: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), update_if_27861)))
                },
                crate::syntax::ExprKind::EMatch(scrut, arms) => {
                    let arms = arms.clone();
                    let e = e.clone();
                    let env = env.clone();
                    let scrut = (**scrut).clone();
                    let st = st.clone();
                    call_then(start_update_match(env.clone(), st.clone(), scrut.clone(), arms.clone(), e.span.clone()), move |update_match_27935: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), update_match_27935)))
                },
                crate::syntax::ExprKind::EFor(binders_opt, source, body) => {
                    let binders_opt = binders_opt.clone();
                    let body = body.clone();
                    let e = e.clone();
                    let env = env.clone();
                    let source = (**source).clone();
                    let st = st.clone();
                    call_then(start_update_for(env.clone(), st.clone(), binders_opt.clone(), source.clone(), body.clone(), e.span.clone()), move |update_for_28024: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), update_for_28024)))
                },
                _ => {
                    let e = e.clone();
                    let env = env.clone();
                    let st = st.clone();
                    call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_28125: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t, st1) = infer_28125;
                        call_then(start_discarded(st1.clone(), t.clone(), e.span.clone()), move |discarded_28162: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), discarded_28162)))
                    })
                },
            },
            crate::syntax::StmtKind::SFn(f) => {
                let env = env.clone();
                let f = f.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_pre_bind(env.clone(), st.clone(), s.clone()), move |pre_bind_28229: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env1, st1) = pre_bind_28229;
                    prism_rtl::Turn::More(Rc::new(crate::check::expr::CheckLocalFn { env: env1.clone(), st: st1.clone(), f: f.clone(), span: s.span.clone() }))
                })
            },
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::PreBind { env: env.clone(), st: st.clone(), s: s.clone() })),
            _ => prism_rtl::Turn::Finished((env.clone(), crate::check::types::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a widget or `given:` block")))),
        }
    }
}

/// `Start UpdateStmt, x`: what the function value is when passed to `@Run`.
pub fn start_update_stmt(env: crate::check::expr::Env, st: crate::check::types::St, s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(UpdateStmt { env, st, s })
}

/// ```prism
/// RefTarget: fn Env, St, Expr -> St
/// ```
pub fn ref_target(env: &crate::check::expr::Env, st: &crate::check::types::St, e: &crate::syntax::Expr) -> crate::check::types::St {
    if is_ref(e) {
        st.clone()
    } else {
        crate::check::types::err_fix(st, &Text::lit("mismatch"), &e.span, &Text::lit("the left of `<=` is a reference: `&_`, a local `&x`, or a path from one"), &Text::from(format!("write `&_.{}`, or make a local with `let &x = ...`", &crate::check::expr::src_text(env, &e.span))))
    }
}

/// ```prism
/// IsRef: fn Expr -> Bool
/// ```
pub fn is_ref(e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")),
        crate::syntax::ExprKind::EField(r, _, _) => is_ref(&**r),
        crate::syntax::ExprKind::EIndex(r, _) => is_ref(&**r),
        crate::syntax::ExprKind::EGroup(x) => is_ref(&**x),
        _ => false,
    }
}

/// ```prism
/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
/// ```
pub fn update_if(env: &crate::check::expr::Env, st: &crate::check::types::St, c: &crate::syntax::Cond, then_b: &crate::syntax::Block, else_b_opt: &Option<crate::syntax::Block>) -> crate::check::types::St {
    let (env2, st1) = match c {
        crate::syntax::Cond::CondExpr(e) => (env.clone(), crate::check::expr::check_cond(env, st, &**e)),
        crate::syntax::Cond::CondBind(p_, e, gd_opt) => {
            let (et, s1) = crate::check::expr::infer(env, st, &**e);
            let (en, s2) = crate::check::expr::bind_pattern(&unpending(env), &s1, p_, &et, &true);
            match &**gd_opt {
                Some(g) => (en.clone(), crate::check::expr::check_cond(&en, &s2, g)),
                None => (en.clone(), s2.clone()),
            }
        },
    };
    let (_, st2) = update_stmts(&env2, &st1, &then_b.stmts);
    match else_b_opt {
        Some(b) => {
            let (_, st3) = update_stmts(env, &st2, &b.stmts);
            st3.clone()
        },
        None => st2.clone(),
    }
}

/// The step machine of `UpdateIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
/// ```
pub struct UpdateIf {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub c: crate::syntax::Cond,
    pub then_b: crate::syntax::Block,
    pub else_b_opt: Option<crate::syntax::Block>,
}

impl prism_rtl::Job<crate::check::types::St> for UpdateIf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let (env2, st1) = match c {
            crate::syntax::Cond::CondExpr(e) => (env.clone(), crate::check::expr::check_cond(env, st, &**e)),
            crate::syntax::Cond::CondBind(p_, e, gd_opt) => {
                let (et, s1) = crate::check::expr::infer(env, st, &**e);
                let (en, s2) = crate::check::expr::bind_pattern(&unpending(env), &s1, p_, &et, &true);
                match &**gd_opt {
                    Some(g) => (en.clone(), crate::check::expr::check_cond(&en, &s2, g)),
                    None => (en.clone(), s2.clone()),
                }
            },
        };
        let else_b_opt = else_b_opt.clone();
        let env = env.clone();
        let then_b = then_b.clone();
        call_then(start_update_stmts(env2.clone(), st1.clone(), then_b.stmts.clone()), move |update_stmts_29446: (crate::check::expr::Env, crate::check::types::St)| {
            let (_, st2) = update_stmts_29446;
            match &else_b_opt {
                Some(b) => {
                    let b = b.clone();
                    call_then(start_update_stmts(env.clone(), st2.clone(), b.stmts.clone()), move |update_stmts_29546: (crate::check::expr::Env, crate::check::types::St)| {
                        let (_, st3) = update_stmts_29546;
                        prism_rtl::Turn::Finished(st3.clone())
                    })
                },
                None => prism_rtl::Turn::Finished(st2.clone()),
            }
        })
    }
}

/// `Start UpdateIf, x`: what the function value is when passed to `@Run`.
pub fn start_update_if(env: crate::check::expr::Env, st: crate::check::types::St, c: crate::syntax::Cond, then_b: crate::syntax::Block, else_b_opt: Option<crate::syntax::Block>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UpdateIf { env, st, c, then_b, else_b_opt })
}

/// ```prism
/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
/// ```
pub fn update_match(env: &crate::check::expr::Env, st: &crate::check::types::St, scrut: &crate::syntax::Expr, arms: &Array<crate::syntax::Arm>, span: &crate::syntax::Range) -> crate::check::types::St {
    let (t, st1) = crate::check::expr::infer(env, st, scrut);
    let st2 = run_to_end(fold_job(arms.clone(), st1.clone(), {
        let env = env.clone();
        let t = t.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
            let env = env.clone();
            let t = t.clone();
            entered(once_job(move || {
                let s = p0;
                let arm = p1;
                {
                    let (env2, s1) = match &arm.pattern {
                        Some(p_) => crate::check::expr::bind_pattern(&unpending(&env), &s, p_, &t, &true),
                        None => (env.clone(), s.clone()),
                    };
                    let s2 = match &arm.guard {
                        Some(gd) => crate::check::expr::check_cond(&env2, &s1, gd),
                        None => s1.clone(),
                    };
                    call_then(start_update_stmts(env2.clone(), s2.clone(), arm.body.stmts.clone()), move |update_stmts_30055: (crate::check::expr::Env, crate::check::types::St)| {
                        let (_, s3) = update_stmts_30055;
                        prism_rtl::Turn::Finished(s3.clone())
                    })
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    crate::check::passes::match_coverage(env, &st2, &t, arms, span)
}

/// The step machine of `UpdateMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
/// ```
pub struct UpdateMatch {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub scrut: crate::syntax::Expr,
    pub arms: Array<crate::syntax::Arm>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for UpdateMatch {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let scrut = &self.scrut;
        let arms = &self.arms;
        let span = &self.span;
        let arms = arms.clone();
        let env = env.clone();
        let scrut = scrut.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), scrut.clone()), move |infer_29734: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st1) = infer_29734;
            call_value(fold_job(arms.clone(), st1.clone(), {
                let env = env.clone();
                let t = t.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                    let env = env.clone();
                    let t = t.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let arm = p1;
                        {
                            let (env2, s1) = match &arm.pattern {
                                Some(p_) => crate::check::expr::bind_pattern(&unpending(&env), &s, p_, &t, &true),
                                None => (env.clone(), s.clone()),
                            };
                            let s2 = match &arm.guard {
                                Some(gd) => crate::check::expr::check_cond(&env2, &s1, gd),
                                None => s1.clone(),
                            };
                            call_then(start_update_stmts(env2.clone(), s2.clone(), arm.body.stmts.clone()), move |update_stmts_30055: (crate::check::expr::Env, crate::check::types::St)| {
                                let (_, s3) = update_stmts_30055;
                                prism_rtl::Turn::Finished(s3.clone())
                            })
                        }
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }), move |fold_29769: crate::check::types::St| {
                let st2 = fold_29769;
                prism_rtl::Turn::More(Rc::new(crate::check::passes::MatchCoverage { env: env.clone(), st: st2.clone(), t: t.clone(), arms: arms.clone(), span: span.clone() }))
            })
        })
    }
}

/// `Start UpdateMatch, x`: what the function value is when passed to `@Run`.
pub fn start_update_match(env: crate::check::expr::Env, st: crate::check::types::St, scrut: crate::syntax::Expr, arms: Array<crate::syntax::Arm>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UpdateMatch { env, st, scrut, arms, span })
}

/// ```prism
/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
/// ```
pub fn update_while(env: &crate::check::expr::Env, st: &crate::check::types::St, c: &crate::syntax::Cond, body: &crate::syntax::Block) -> crate::check::types::St {
    let (env2, st1) = match c {
        crate::syntax::Cond::CondExpr(e) => (env.clone(), crate::check::expr::check_cond(env, st, &**e)),
        crate::syntax::Cond::CondBind(p_, e, gd_opt) => {
            let (et, s1) = crate::check::expr::infer(env, st, &**e);
            let (en, s2) = crate::check::expr::bind_pattern(&unpending(env), &s1, p_, &et, &true);
            match &**gd_opt {
                Some(g) => (en.clone(), crate::check::expr::check_cond(&en, &s2, g)),
                None => (en.clone(), s2.clone()),
            }
        },
    };
    let (_, st2) = update_stmts(&env2, &st1, &body.stmts);
    st2.clone()
}

/// The step machine of `UpdateWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
/// ```
pub struct UpdateWhile {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub c: crate::syntax::Cond,
    pub body: crate::syntax::Block,
}

impl prism_rtl::Job<crate::check::types::St> for UpdateWhile {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let body = &self.body;
        let (env2, st1) = match c {
            crate::syntax::Cond::CondExpr(e) => (env.clone(), crate::check::expr::check_cond(env, st, &**e)),
            crate::syntax::Cond::CondBind(p_, e, gd_opt) => {
                let (et, s1) = crate::check::expr::infer(env, st, &**e);
                let (en, s2) = crate::check::expr::bind_pattern(&unpending(env), &s1, p_, &et, &true);
                match &**gd_opt {
                    Some(g) => (en.clone(), crate::check::expr::check_cond(&en, &s2, g)),
                    None => (en.clone(), s2.clone()),
                }
            },
        };
        let body = body.clone();
        call_then(start_update_stmts(env2.clone(), st1.clone(), body.stmts.clone()), move |update_stmts_30690: (crate::check::expr::Env, crate::check::types::St)| {
            let (_, st2) = update_stmts_30690;
            prism_rtl::Turn::Finished(st2.clone())
        })
    }
}

/// `Start UpdateWhile, x`: what the function value is when passed to `@Run`.
pub fn start_update_while(env: crate::check::expr::Env, st: crate::check::types::St, c: crate::syntax::Cond, body: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UpdateWhile { env, st, c, body })
}

/// ```prism
/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
/// ```
pub fn update_for(env: &crate::check::expr::Env, st: &crate::check::types::St, binders_opt: &Option<crate::syntax::ForBinders>, source: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range) -> crate::check::types::St {
    let (t, st1) = crate::check::expr::infer(env, st, source);
    let (k, v_, st2) = coll_parts(&st1, &t, &source.span);
    let env1 = loop_indices(env);
    let (env2, st3) = match binders_opt {
        None => (with_topic(&env1, &Text::lit("&_"), &v_), st2.clone()),
        Some(bs) => match &bs.second {
            Some(second) => {
                let (e1, s1) = crate::check::expr::bind_pattern(&unpending(&env1), &st2, &bs.first, &k, &false);
                crate::check::expr::bind_pattern(&e1, &s1, second, &v_, &false)
            },
            None => crate::check::expr::bind_pattern(&unpending(&env1), &st2, &bs.first, &v_, &false),
        },
    };
    let (_, st4) = update_stmts(&env2, &st3, &body.stmts);
    st4.clone()
}

/// The step machine of `UpdateFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
/// ```
pub struct UpdateFor {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub binders_opt: Option<crate::syntax::ForBinders>,
    pub source: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for UpdateFor {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let binders_opt = &self.binders_opt;
        let source = &self.source;
        let body = &self.body;
        let span = &self.span;
        let binders_opt = binders_opt.clone();
        let body = body.clone();
        let env = env.clone();
        let source = source.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), source.clone()), move |infer_30998: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st1) = infer_30998;
            call_then(start_coll_parts(st1.clone(), t.clone(), source.span.clone()), move |coll_parts_31044: (crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)| {
                let (k, v_, st2) = coll_parts_31044;
                let env1 = loop_indices(&env);
                let (env2, st3) = match &binders_opt {
                    None => (with_topic(&env1, &Text::lit("&_"), &v_), st2.clone()),
                    Some(bs) => match &bs.second {
                        Some(second) => {
                            let (e1, s1) = crate::check::expr::bind_pattern(&unpending(&env1), &st2, &bs.first, &k, &false);
                            crate::check::expr::bind_pattern(&e1, &s1, second, &v_, &false)
                        },
                        None => crate::check::expr::bind_pattern(&unpending(&env1), &st2, &bs.first, &v_, &false),
                    },
                };
                call_then(start_update_stmts(env2.clone(), st3.clone(), body.stmts.clone()), move |update_stmts_31484: (crate::check::expr::Env, crate::check::types::St)| {
                    let (_, st4) = update_stmts_31484;
                    prism_rtl::Turn::Finished(st4.clone())
                })
            })
        })
    }
}

/// `Start UpdateFor, x`: what the function value is when passed to `@Run`.
pub fn start_update_for(env: crate::check::expr::Env, st: crate::check::types::St, binders_opt: Option<crate::syntax::ForBinders>, source: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UpdateFor { env, st, binders_opt, source, body, span })
}
