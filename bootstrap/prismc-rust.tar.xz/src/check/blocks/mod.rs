//! The module `Check.Blocks`, from `target/bootstrap/src/prismc/check/blocks/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod borrows;
pub mod structure;

/// ```prism
/// GroupOrder: fn [Stmt] -> [Nat]
/// ```
pub fn group_order(stmts: &Array<crate::syntax::Stmt>) -> Array<Nat> {
    let all = crate::check::errors::range0(&len(stmts));
    let holds = filter(&all, &(|i: &Nat| is_hold(&or(&index(stmts, i), &dummy_stmt2()))));
    let lets = filter(&all, &(|i: &Nat| is_let_like(&or(&index(stmts, i), &dummy_stmt2()))));
    let rest = filter(&all, &(|i: &Nat| !is_hold(&or(&index(stmts, i), &dummy_stmt2())) && !is_let_like(&or(&index(stmts, i), &dummy_stmt2()))));
    append(&append(&holds, &lets), &rest)
}

/// ```prism
/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub fn dep_order(stmts: &Array<crate::syntax::Stmt>) -> Array<Array<Nat>> {
    let n = len(stmts);
    let defs = run_to_end(each_job(stmts.clone(), Rc::new(move |p0: crate::syntax::Stmt| entered(once_job(move || {
        let s = p0;
        prism_rtl::Turn::More(Rc::new(GroupDefs { s: s.clone() }))
    }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let uses = run_to_end(each_job(stmts.clone(), Rc::new(move |p0: crate::syntax::Stmt| entered(once_job(move || {
        let s = p0;
        prism_rtl::Turn::More(Rc::new(crate::check::shrink::locals::NamesInStmt { s: s.clone() }))
    }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let deps = each(&crate::check::errors::range0(&n), &(|i: &Nat| filter(&crate::check::errors::range0(&n), &(|j: &Nat| fold(&or(&index(&defs, j), &Array::new()), &false, &(|seen: &bool, d: &Text| *seen || crate::check::types::has_text(&or(&index(&uses, i), &Array::new()), d)))))));
    let reach = run_to_end(each_job(crate::check::errors::range0(&n), {
        let deps = deps.clone();
        Rc::new(move |p0: Nat| {
            let deps = deps.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ReachIdx { deps: deps.clone(), frontier: or(&index(&deps, &i), &Array::new()), seen: Array::new() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    let comps = each(&crate::check::errors::range0(&n), &(|i: &Nat| filter(&crate::check::errors::range0(&n), &(|j: &Nat| (j == i) || (crate::check::types::has_nat(&or(&index(&reach, i), &Array::new()), j) && crate::check::types::has_nat(&or(&index(&reach, j), &Array::new()), i))))));
    emit_groups(&comps, &deps, &Array::new(), &Array::new())
}

/// The step machine of `DepOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub struct DepOrder {
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<Array<Nat>>> for DepOrder {
    fn cycle(&self) -> prism_rtl::Turn<Array<Array<Nat>>> {
        let stmts = &self.stmts;
        let n = len(stmts);
        let stmts = stmts.clone();
        call_value(each_job(stmts.clone(), Rc::new(move |p0: crate::syntax::Stmt| entered(once_job(move || {
            let s = p0;
            prism_rtl::Turn::More(Rc::new(GroupDefs { s: s.clone() }))
        }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_2687: Array<Array<Text>>| {
            let defs = each_2687;
            call_value(each_job(stmts.clone(), Rc::new(move |p0: crate::syntax::Stmt| entered(once_job(move || {
                let s = p0;
                prism_rtl::Turn::More(Rc::new(crate::check::shrink::locals::NamesInStmt { s: s.clone() }))
            }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_2731: Array<Array<Text>>| {
                let uses = each_2731;
                let deps = each(&crate::check::errors::range0(&n), &(|i: &Nat| filter(&crate::check::errors::range0(&n), &(|j: &Nat| fold(&or(&index(&defs, j), &Array::new()), &false, &(|seen: &bool, d: &Text| *seen || crate::check::types::has_text(&or(&index(&uses, i), &Array::new()), d)))))));
                call_value(each_job(crate::check::errors::range0(&n), {
                    let deps = deps.clone();
                    Rc::new(move |p0: Nat| {
                        let deps = deps.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(ReachIdx { deps: deps.clone(), frontier: or(&index(&deps, &i), &Array::new()), seen: Array::new() }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }), move |each_2920: Array<Array<Nat>>| {
                    let reach = each_2920;
                    let comps = each(&crate::check::errors::range0(&n), &(|i: &Nat| filter(&crate::check::errors::range0(&n), &(|j: &Nat| (j == i) || (crate::check::types::has_nat(&or(&index(&reach, i), &Array::new()), j) && crate::check::types::has_nat(&or(&index(&reach, j), &Array::new()), i))))));
                    prism_rtl::Turn::More(Rc::new(EmitGroups { comps: comps.clone(), deps: deps.clone(), done: Array::new(), acc: Array::new() }))
                })
            })
        })
    }
}

/// `Start DepOrder, x`: what the function value is when passed to `@Run`.
pub fn start_dep_order(stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Array<Nat>>>> {
    Rc::new(DepOrder { stmts })
}

/// ```prism
/// GroupDefs: unbounded fn Stmt -> [Text]
/// ```
pub fn group_defs(s: &crate::syntax::Stmt) -> Array<Text> {
    match &s.kind {
        crate::syntax::StmtKind::SBind(p_, _, _) => crate::check::env::names::pattern_names(p_),
        crate::syntax::StmtKind::SLet(p_, _, _) => crate::check::env::names::pattern_names(p_),
        crate::syntax::StmtKind::SFn(f) => Array::from(vec![crate::check::env::def_name_text(&f.name)]),
        crate::syntax::StmtKind::SWidget(w) => Array::from(vec![crate::check::env::sname_key(&w.name)]),
        _ => Array::new(),
    }
}

/// The step machine of `GroupDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GroupDefs: unbounded fn Stmt -> [Text]
/// ```
pub struct GroupDefs {
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<Text>> for GroupDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SBind(p_, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::names::PatternNames { p_: p_.clone() })),
            crate::syntax::StmtKind::SLet(p_, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::names::PatternNames { p_: p_.clone() })),
            crate::syntax::StmtKind::SFn(f) => prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::def_name_text(&f.name)])),
            crate::syntax::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::sname_key(&w.name)])),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start GroupDefs, x`: what the function value is when passed to `@Run`.
pub fn start_group_defs(s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(GroupDefs { s })
}

/// ```prism
/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
/// ```
pub fn reach_idx(deps: &Array<Array<Nat>>, frontier: &Array<Nat>, seen: &Array<Nat>) -> Array<Nat> {
    match index(frontier, &Nat::from(0u32)) {
        None => seen.clone(),
        Some(x) => if crate::check::types::has_nat(seen, &x) {
            reach_idx(deps, &drop(frontier, &Nat::from(1u32)), seen)
        } else {
            reach_idx(deps, &append(&drop(frontier, &Nat::from(1u32)), &or(&index(deps, &x), &Array::new())), &push(seen, &x))
        },
    }
}

/// The step machine of `ReachIdx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
/// ```
pub struct ReachIdx {
    pub deps: Array<Array<Nat>>,
    pub frontier: Array<Nat>,
    pub seen: Array<Nat>,
}

impl prism_rtl::Job<Array<Nat>> for ReachIdx {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let deps = &self.deps;
        let frontier = &self.frontier;
        let seen = &self.seen;
        match index(frontier, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(seen.clone()),
            Some(x) => if crate::check::types::has_nat(seen, &x) {
                prism_rtl::Turn::More(Rc::new(ReachIdx { deps: deps.clone(), frontier: drop(frontier, &Nat::from(1u32)), seen: seen.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(ReachIdx { deps: deps.clone(), frontier: append(&drop(frontier, &Nat::from(1u32)), &or(&index(deps, &x), &Array::new())), seen: push(seen, &x) }))
            },
        }
    }
}

/// `Start ReachIdx, x`: what the function value is when passed to `@Run`.
pub fn start_reach_idx(deps: Array<Array<Nat>>, frontier: Array<Nat>, seen: Array<Nat>) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(ReachIdx { deps, frontier, seen })
}

/// ```prism
/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
/// ```
pub fn emit_groups(comps: &Array<Array<Nat>>, deps: &Array<Array<Nat>>, done: &Array<Nat>, acc: &Array<Array<Nat>>) -> Array<Array<Nat>> {
    let ready = filter(&crate::check::errors::range0(&len(comps)), &(|i: &Nat| !crate::check::types::has_nat(done, i) && fold(&or(&index(deps, i), &Array::new()), &true, &(|ok_: &bool, d: &Nat| *ok_ && (crate::check::types::has_nat(done, d) || crate::check::types::has_nat(&or(&index(comps, i), &Array::new()), d))))));
    match index(&ready, &Nat::from(0u32)) {
        None => acc.clone(),
        Some(i) => {
            let c = or(&index(comps, &i), &Array::from(vec![i.clone()]));
            emit_groups(comps, deps, &append(done, &c), &push(acc, &c))
        },
    }
}

/// The step machine of `EmitGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
/// ```
pub struct EmitGroups {
    pub comps: Array<Array<Nat>>,
    pub deps: Array<Array<Nat>>,
    pub done: Array<Nat>,
    pub acc: Array<Array<Nat>>,
}

impl prism_rtl::Job<Array<Array<Nat>>> for EmitGroups {
    fn cycle(&self) -> prism_rtl::Turn<Array<Array<Nat>>> {
        let comps = &self.comps;
        let deps = &self.deps;
        let done = &self.done;
        let acc = &self.acc;
        let ready = filter(&crate::check::errors::range0(&len(comps)), &(|i: &Nat| !crate::check::types::has_nat(done, i) && fold(&or(&index(deps, i), &Array::new()), &true, &(|ok_: &bool, d: &Nat| *ok_ && (crate::check::types::has_nat(done, d) || crate::check::types::has_nat(&or(&index(comps, i), &Array::new()), d))))));
        match index(&ready, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(acc.clone()),
            Some(i) => {
                let c = or(&index(comps, &i), &Array::from(vec![i.clone()]));
                prism_rtl::Turn::More(Rc::new(EmitGroups { comps: comps.clone(), deps: deps.clone(), done: append(done, &c), acc: push(acc, &c) }))
            },
        }
    }
}

/// `Start EmitGroups, x`: what the function value is when passed to `@Run`.
pub fn start_emit_groups(comps: Array<Array<Nat>>, deps: Array<Array<Nat>>, done: Array<Nat>, acc: Array<Array<Nat>>) -> Rc<dyn prism_rtl::Job<Array<Array<Nat>>>> {
    Rc::new(EmitGroups { comps, deps, done, acc })
}

/// ```prism
/// IsHold: fn Stmt -> Bool
/// ```
pub fn is_hold(s: &crate::syntax::Stmt) -> bool {
    match &s.kind {
        crate::syntax::StmtKind::SBind(_, _, Some(_)) => true,
        _ => false,
    }
}

/// ```prism
/// IsLetLike: fn Stmt -> Bool
/// ```
pub fn is_let_like(s: &crate::syntax::Stmt) -> bool {
    match &s.kind {
        crate::syntax::StmtKind::SLet(_, _, _) => true,
        crate::syntax::StmtKind::SFn(_) => true,
        crate::syntax::StmtKind::SSignature(_) => true,
        _ => false,
    }
}

/// ```prism
/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub fn infer_widget_block(env: &crate::check::expr::Env, st: &crate::check::types::St, b: &crate::syntax::Block) -> (crate::check::types::Ty, crate::check::types::St) {
    let (env1, st1) = block_row(env, st, &b.stmts);
    let (env2, st2) = run_to_end(fold_job(b.stmts.clone(), (env1.clone(), st1.clone()), Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| entered(once_job(move || {
        let (en, s) = p0;
        let stmt = p1;
        prism_rtl::Turn::More(Rc::new(PreBindStmt { env: en.clone(), st: s.clone(), s: stmt.clone() }))
    }))) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>));
    let n = len(&b.stmts);
    let (env3, st3, res_opt) = run_to_end(fold_job(group_order(&b.stmts), (env2.clone(), st2.clone(), None), {
        let b = b.clone();
        let n = n.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)| {
            let b = b.clone();
            let n = n.clone();
            entered(once_job(move || {
                let (en, s, r_opt) = p0;
                let i = p1;
                {
                    let stmt = or(&index(&b.stmts, &i), &dummy_stmt2());
                    call_then(start_widget_stmt(en.clone(), s.clone(), stmt.clone(), &(&i + &Nat::from(1u32)) == &n), move |widget_stmt_5312: (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)| {
                        let (en2, s2, r2_opt) = widget_stmt_5312;
                        match &r2_opt {
                            Some(t) => prism_rtl::Turn::Finished((en2.clone(), s2.clone(), Some(t.clone()))),
                            None => prism_rtl::Turn::Finished((en2.clone(), s2.clone(), r_opt.clone())),
                        }
                    })
                }
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>>>
    }));
    let st4 = crate::check::passes::cycles::block_prompt_cycles(&env3, &st3, b);
    let st5 = if st4.recording {
        crate::check::types::recording::note_group(&st4, &b.span, &Text::lit("widget"), &dep_order(&b.stmts))
    } else {
        st4.clone()
    };
    (or(&res_opt, &crate::check::types::t_unit()), st5.clone())
}

/// The step machine of `InferWidgetBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub struct InferWidgetBlock {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferWidgetBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let b = b.clone();
        let env = env.clone();
        let st = st.clone();
        call_then(start_block_row(env.clone(), st.clone(), b.stmts.clone()), move |block_row_4993: (crate::check::expr::Env, crate::check::types::St)| {
            let (env1, st1) = block_row_4993;
            call_value(fold_job(b.stmts.clone(), (env1.clone(), st1.clone()), Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| entered(once_job(move || {
                let (en, s) = p0;
                let stmt = p1;
                prism_rtl::Turn::More(Rc::new(PreBindStmt { env: en.clone(), st: s.clone(), s: stmt.clone() }))
            }))) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>), move |fold_5043: (crate::check::expr::Env, crate::check::types::St)| {
                let (env2, st2) = fold_5043;
                let n = len(&b.stmts);
                call_value(fold_job(group_order(&b.stmts), (env2.clone(), st2.clone(), None), {
                    let b = b.clone();
                    let n = n.clone();
                    Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)| {
                        let b = b.clone();
                        let n = n.clone();
                        entered(once_job(move || {
                            let (en, s, r_opt) = p0;
                            let i = p1;
                            {
                                let stmt = or(&index(&b.stmts, &i), &dummy_stmt2());
                                call_then(start_widget_stmt(en.clone(), s.clone(), stmt.clone(), &(&i + &Nat::from(1u32)) == &n), move |widget_stmt_5312: (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)| {
                                    let (en2, s2, r2_opt) = widget_stmt_5312;
                                    match &r2_opt {
                                        Some(t) => prism_rtl::Turn::Finished((en2.clone(), s2.clone(), Some(t.clone()))),
                                        None => prism_rtl::Turn::Finished((en2.clone(), s2.clone(), r_opt.clone())),
                                    }
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>>>
                }), move |fold_5169: (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)| {
                    let (env3, st3, res_opt) = fold_5169;
                    call_then(crate::check::passes::cycles::start_block_prompt_cycles(env3.clone(), st3.clone(), b.clone()), move |block_prompt_cycles_5447: crate::check::types::St| {
                        let st4 = block_prompt_cycles_5447;
                        let st5 = if st4.recording {
                            crate::check::types::recording::note_group(&st4, &b.span, &Text::lit("widget"), &dep_order(&b.stmts))
                        } else {
                            st4.clone()
                        };
                        prism_rtl::Turn::Finished((or(&res_opt, &crate::check::types::t_unit()), st5.clone()))
                    })
                })
            })
        })
    }
}

/// `Start InferWidgetBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_widget_block(env: crate::check::expr::Env, st: crate::check::types::St, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferWidgetBlock { env, st, b })
}

/// ```prism
/// let dummyStmt2
/// ```
pub fn dummy_stmt2() -> crate::syntax::Stmt {
    crate::syntax::Stmt { kind: crate::syntax::StmtKind::SExpr(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub fn block_row(env: &crate::check::expr::Env, st: &crate::check::types::St, stmts: &Array<crate::syntax::Stmt>) -> (crate::check::expr::Env, crate::check::types::St) {
    run_to_end(fold_job(crate::check::errors::range0(&len(stmts)), (env.clone(), st.clone()), {
        let stmts = stmts.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
            let stmts = stmts.clone();
            entered(once_job(move || {
                let (en, s) = p0;
                let i = p1;
                match index(&stmts, &i) {
                    Some(stmt) => match &stmt.kind {
                        crate::syntax::StmtKind::SEmit(row_decl) => if &i > &Nat::from(0u32) {
                            prism_rtl::Turn::Finished((en.clone(), crate::check::types::recording::err_fix(&s, &Text::lit("emit-element"), &stmt.span, &Text::lit("`emit` comes first in its block"), &Text::lit("move this line to the top of the block"))))
                        } else {
                            {
                                let row_decl = row_decl.clone();
                                call_then(crate::check::env::reading::start_conv_row(crate::check::expr::env_cx(&en), s.clone(), row_as_type(&row_decl)), move |conv_row_6209: (crate::check::types::Rw, crate::check::types::St)| {
                                    let (rw, s2) = conv_row_6209;
                                    let en2 = {
                                        let mut this: crate::check::expr::Env = en.clone();
                                        this.scope = resolve_scope_row(&en, &rw);
                                        this
                                    };
                                    prism_rtl::Turn::Finished((en2.clone(), s2.clone()))
                                })
                            }
                        },
                        _ => prism_rtl::Turn::Finished((en.clone(), s.clone())),
                    },
                    None => prism_rtl::Turn::Finished((en.clone(), s.clone())),
                }
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
    }))
}

/// The step machine of `BlockRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub struct BlockRow {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BlockRow {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        fold_job(crate::check::errors::range0(&len(stmts)), (env.clone(), st.clone()), {
            let stmts = stmts.clone();
            Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                let stmts = stmts.clone();
                entered(once_job(move || {
                    let (en, s) = p0;
                    let i = p1;
                    match index(&stmts, &i) {
                        Some(stmt) => match &stmt.kind {
                            crate::syntax::StmtKind::SEmit(row_decl) => if &i > &Nat::from(0u32) {
                                prism_rtl::Turn::Finished((en.clone(), crate::check::types::recording::err_fix(&s, &Text::lit("emit-element"), &stmt.span, &Text::lit("`emit` comes first in its block"), &Text::lit("move this line to the top of the block"))))
                            } else {
                                {
                                    let row_decl = row_decl.clone();
                                    call_then(crate::check::env::reading::start_conv_row(crate::check::expr::env_cx(&en), s.clone(), row_as_type(&row_decl)), move |conv_row_6209: (crate::check::types::Rw, crate::check::types::St)| {
                                        let (rw, s2) = conv_row_6209;
                                        let en2 = {
                                            let mut this: crate::check::expr::Env = en.clone();
                                            this.scope = resolve_scope_row(&en, &rw);
                                            this
                                        };
                                        prism_rtl::Turn::Finished((en2.clone(), s2.clone()))
                                    })
                                }
                            },
                            _ => prism_rtl::Turn::Finished((en.clone(), s.clone())),
                        },
                        None => prism_rtl::Turn::Finished((en.clone(), s.clone())),
                    }
                }))
            }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start BlockRow, x`: what the function value is when passed to `@Run`.
pub fn start_block_row(env: crate::check::expr::Env, st: crate::check::types::St, stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BlockRow { env, st, stmts })
}

/// ```prism
/// RowAsType: fn Row -> Type
/// ```
pub fn row_as_type(row_decl: &crate::syntax::Row_) -> crate::syntax::Type {
    crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TRowUnion(each(&row_decl.terms, &row_term_type))), span: row_decl.span.clone() }
}

/// ```prism
/// RowTermType: fn RowTerm -> Type
/// ```
pub fn row_term_type(row_term0: &crate::syntax::RowTerm) -> crate::syntax::Type {
    match row_term0 {
        crate::syntax::RowTerm::RFamily(q) => crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TFamily(q.clone())), span: q.span.clone() },
        crate::syntax::RowTerm::RVar(v_) => crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TName(crate::syntax::SName { sigils: Text::lit(""), path_: Array::from(vec![v_.name.clone()]), span: v_.span.clone() }, Array::new())), span: v_.span.clone() },
        crate::syntax::RowTerm::RType(t) => t.clone(),
    }
}

/// ```prism
/// ResolveScopeRow: fn Env, Rw -> Rw
/// ```
pub fn resolve_scope_row(env: &crate::check::expr::Env, rw: &crate::check::types::Rw) -> crate::check::types::Rw {
    match &rw.tail {
        crate::check::types::Tail::TlQ(v_) => crate::check::types::Rw { fams: rw.fams.clone(), minus: rw.minus.clone(), tail: env.scope.tail.clone() },
        _ => rw.clone(),
    }
}

/// ```prism
/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub fn pre_bind_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, s: &crate::syntax::Stmt) -> (crate::check::expr::Env, crate::check::types::St) {
    match &s.kind {
        crate::syntax::StmtKind::SBind(p_, _, _) => pre_bind_pattern(env, st, p_),
        crate::syntax::StmtKind::SLet(_, _, _) => crate::check::expr::lets::pre_bind(env, st, s),
        crate::syntax::StmtKind::SFn(_) => crate::check::expr::lets::pre_bind(env, st, s),
        crate::syntax::StmtKind::SSignature(_) => crate::check::expr::lets::pre_bind(env, st, s),
        crate::syntax::StmtKind::SWidget(w) => {
            let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
            (crate::check::expr::with_local(env, &crate::check::env::sname_key(&w.name), &crate::check::types::schemes::mono(&crate::check::types::Ty::TyAt(Rc::new(v_.clone()), env.scope.clone()))), st2.clone())
        },
        _ => (env.clone(), st.clone()),
    }
}

/// The step machine of `PreBindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub struct PreBindStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for PreBindStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SBind(p_, _, _) => prism_rtl::Turn::More(Rc::new(PreBindPattern { env: env.clone(), st: st.clone(), p_: p_.clone() })),
            crate::syntax::StmtKind::SLet(_, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::PreBind { env: env.clone(), st: st.clone(), s: s.clone() })),
            crate::syntax::StmtKind::SFn(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::PreBind { env: env.clone(), st: st.clone(), s: s.clone() })),
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::PreBind { env: env.clone(), st: st.clone(), s: s.clone() })),
            crate::syntax::StmtKind::SWidget(w) => {
                let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                prism_rtl::Turn::Finished((crate::check::expr::with_local(env, &crate::check::env::sname_key(&w.name), &crate::check::types::schemes::mono(&crate::check::types::Ty::TyAt(Rc::new(v_.clone()), env.scope.clone()))), st2.clone()))
            },
            _ => prism_rtl::Turn::Finished((env.clone(), st.clone())),
        }
    }
}

/// `Start PreBindStmt, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_stmt(env: crate::check::expr::Env, st: crate::check::types::St, s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(PreBindStmt { env, st, s })
}

/// ```prism
/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
/// ```
pub fn pre_bind_pattern(env: &crate::check::expr::Env, st: &crate::check::types::St, p_: &crate::syntax::Pattern_) -> (crate::check::expr::Env, crate::check::types::St) {
    fold(&crate::check::env::names::pattern_binders(p_), &(env.clone(), st.clone()), &(|(en, s): &(crate::check::expr::Env, crate::check::types::St), (name, at_): &(Text, crate::syntax::Range)| {
        let (v_, s1) = crate::check::types::fresh_var(s, &true, name);
        let s2 = crate::check::types::recording::at_binder(&s1, &v_, at_);
        let (rw, s3) = crate::check::types::recording::fresh_row(&s2, &Array::new());
        let t = crate::check::types::with_marks(&crate::check::expr::lets::type_marks(&crate::check::types::unify::marks_of(name)), &v_, &rw);
        let en2 = {
            let mut this: crate::check::expr::Env = crate::check::expr::with_local(en, name, &crate::check::types::schemes::mono(&t));
            this.pending = crate::check::types::add_text(&this.pending, name);
            this
        };
        (en2.clone(), s3.clone())
    }))
}

/// The step machine of `PreBindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
/// ```
pub struct PreBindPattern {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub p_: crate::syntax::Pattern_,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for PreBindPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let env = env.clone();
        let p_ = p_.clone();
        let st = st.clone();
        call_then(crate::check::env::names::start_pattern_binders(p_.clone()), move |pattern_binders_7730: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(fold(&pattern_binders_7730, &(env.clone(), st.clone()), &(|(en, s): &(crate::check::expr::Env, crate::check::types::St), (name, at_): &(Text, crate::syntax::Range)| {
            let (v_, s1) = crate::check::types::fresh_var(s, &true, name);
            let s2 = crate::check::types::recording::at_binder(&s1, &v_, at_);
            let (rw, s3) = crate::check::types::recording::fresh_row(&s2, &Array::new());
            let t = crate::check::types::with_marks(&crate::check::expr::lets::type_marks(&crate::check::types::unify::marks_of(name)), &v_, &rw);
            let en2 = {
                let mut this: crate::check::expr::Env = crate::check::expr::with_local(en, name, &crate::check::types::schemes::mono(&t));
                this.pending = crate::check::types::add_text(&this.pending, name);
                this
            };
            (en2.clone(), s3.clone())
        }))))
    }
}

/// `Start PreBindPattern, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_pattern(env: crate::check::expr::Env, st: crate::check::types::St, p_: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(PreBindPattern { env, st, p_ })
}

/// ```prism
/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
/// ```
pub fn widget_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, s: &crate::syntax::Stmt, last: &bool) -> (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>) {
    match &s.kind {
        crate::syntax::StmtKind::SEmit(_) => (env.clone(), st.clone(), if *last { Some(crate::check::types::t_unit()) } else { None }),
        crate::syntax::StmtKind::SBind(p_, e, None) => {
            let st2 = bind_stmt(env, st, p_, e, &s.span);
            (env.clone(), st2.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })
        },
        crate::syntax::StmtKind::SBind(p_, init, Some(step_)) => {
            let st2 = hold_stmt(env, st, p_, init, step_, &s.span);
            (env.clone(), st2.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })
        },
        crate::syntax::StmtKind::SIgnore(e) => {
            let st2 = ignore_stmt(env, st, e, &s.span);
            (env.clone(), st2.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })
        },
        crate::syntax::StmtKind::SLet(p_, ty_opt, e) => {
            let (env2, st2) = crate::check::expr::lets::check_let(env, st, p_, ty_opt, e, &s.span);
            (env2.clone(), st2.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })
        },
        crate::syntax::StmtKind::SFn(f) => {
            let (env2, st2) = crate::check::expr::lets::check_local_fn(env, st, f, &s.span);
            (env2.clone(), st2.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })
        },
        crate::syntax::StmtKind::SSignature(_) => (env.clone(), st.clone(), if *last { Some(crate::check::types::t_unit()) } else { None }),
        crate::syntax::StmtKind::SWidget(w) => {
            let (t, st2) = infer_widget_block(env, st, &w.body);
            let st3 = match get(&env.locals, &crate::check::env::sname_key(&w.name)) {
                Some(sc) => crate::check::types::unify::unify(&st2, &sc.ty, &crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()), &w.span),
                None => st2.clone(),
            };
            (env.clone(), st3.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })
        },
        crate::syntax::StmtKind::SExpr(e) => {
            let (t, st2) = bare_line(env, st, e, last);
            if *last {
                (env.clone(), st2.clone(), Some(t.clone()))
            } else {
                (env.clone(), st2.clone(), None)
            }
        },
        _ => (env.clone(), crate::check::types::recording::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a `given:` or `update` block")), if *last { Some(crate::check::types::t_unit()) } else { None }),
    }
}

/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
/// ```
pub struct WidgetStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub s: crate::syntax::Stmt,
    pub last: bool,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)> for WidgetStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        let last = &self.last;
        match &s.kind {
            crate::syntax::StmtKind::SEmit(_) => prism_rtl::Turn::Finished((env.clone(), st.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })),
            crate::syntax::StmtKind::SBind(p_, e, None) => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let p_ = p_.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(start_bind_stmt(env.clone(), st.clone(), p_.clone(), e.clone(), s.span.clone()), move |bind_stmt_8355: crate::check::types::St| {
                    let st2 = bind_stmt_8355;
                    prism_rtl::Turn::Finished((env.clone(), st2.clone(), if last { Some(crate::check::types::t_unit()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SBind(p_, init, Some(step_)) => {
                let env = env.clone();
                let init = init.clone();
                let last = *last;
                let p_ = p_.clone();
                let s = s.clone();
                let st = st.clone();
                let step_ = step_.clone();
                call_then(start_hold_stmt(env.clone(), st.clone(), p_.clone(), init.clone(), step_.clone(), s.span.clone()), move |hold_stmt_8482: crate::check::types::St| {
                    let st2 = hold_stmt_8482;
                    prism_rtl::Turn::Finished((env.clone(), st2.clone(), if last { Some(crate::check::types::t_unit()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SIgnore(e) => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let s = s.clone();
                let st = st.clone();
                call_then(start_ignore_stmt(env.clone(), st.clone(), e.clone(), s.span.clone()), move |ignore_stmt_8604: crate::check::types::St| {
                    let st2 = ignore_stmt_8604;
                    prism_rtl::Turn::Finished((env.clone(), st2.clone(), if last { Some(crate::check::types::t_unit()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SLet(p_, ty_opt, e) => {
                let ty_opt = ty_opt.clone();
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let p_ = p_.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(crate::check::expr::lets::start_check_let(env.clone(), st.clone(), p_.clone(), ty_opt.clone(), e.clone(), s.span.clone()), move |check_let_8731: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2, st2) = check_let_8731;
                    prism_rtl::Turn::Finished((env2.clone(), st2.clone(), if last { Some(crate::check::types::t_unit()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SFn(f) => {
                let env = env.clone();
                let f = f.clone();
                let last = *last;
                let s = s.clone();
                let st = st.clone();
                call_then(crate::check::expr::lets::start_check_local_fn(env.clone(), st.clone(), f.clone(), s.span.clone()), move |check_local_fn_8856: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2, st2) = check_local_fn_8856;
                    prism_rtl::Turn::Finished((env2.clone(), st2.clone(), if last { Some(crate::check::types::t_unit()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((env.clone(), st.clone(), if *last { Some(crate::check::types::t_unit()) } else { None })),
            crate::syntax::StmtKind::SWidget(w) => {
                let env = env.clone();
                let last = *last;
                let st = st.clone();
                let w = w.clone();
                call_then(start_infer_widget_block(env.clone(), st.clone(), w.body.clone()), move |infer_widget_block_9041: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_widget_block_9041;
                    let st3 = match get(&env.locals, &crate::check::env::sname_key(&w.name)) {
                        Some(sc) => crate::check::types::unify::unify(&st2, &sc.ty, &crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()), &w.span),
                        None => st2.clone(),
                    };
                    prism_rtl::Turn::Finished((env.clone(), st3.clone(), if last { Some(crate::check::types::t_unit()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SExpr(e) => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let st = st.clone();
                call_then(start_bare_line(env.clone(), st.clone(), e.clone(), last), move |bare_line_9299: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = bare_line_9299;
                    if last {
                        prism_rtl::Turn::Finished((env.clone(), st2.clone(), Some(t.clone())))
                    } else {
                        prism_rtl::Turn::Finished((env.clone(), st2.clone(), None))
                    }
                })
            },
            _ => prism_rtl::Turn::Finished((env.clone(), crate::check::types::recording::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a `given:` or `update` block")), if *last { Some(crate::check::types::t_unit()) } else { None })),
        }
    }
}

/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
pub fn start_widget_stmt(env: crate::check::expr::Env, st: crate::check::types::St, s: crate::syntax::Stmt, last: bool) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>> {
    Rc::new(WidgetStmt { env, st, s, last })
}

/// ```prism
/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
/// ```
pub fn bind_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, p_: &crate::syntax::Pattern_, e: &crate::syntax::Expr, span: &crate::syntax::Range) -> crate::check::types::St {
    let (t, st1) = crate::check::expr::infer(env, st, e);
    let (out, st2) = if is_builder(e) {
        (t.clone(), st1.clone())
    } else {
        bind_output(env, &st1, &t, &e.span)
    };
    let (_, st3) = crate::check::expr::patterns::bind_pattern(env, &st2, p_, &out, &false);
    st3.clone()
}

/// The step machine of `BindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
/// ```
pub struct BindStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub p_: crate::syntax::Pattern_,
    pub e: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for BindStmt {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let e = &self.e;
        let span = &self.span;
        let e = e.clone();
        let env = env.clone();
        let p_ = p_.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_9914: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st1) = infer_9914;
            let (out, st2) = if is_builder(&e) {
                (t.clone(), st1.clone())
            } else {
                bind_output(&env, &st1, &t, &e.span)
            };
            call_then(crate::check::expr::patterns::start_bind_pattern(env.clone(), st2.clone(), p_.clone(), out.clone(), false), move |bind_pattern_10044: (crate::check::expr::Env, crate::check::types::St)| {
                let (_, st3) = bind_pattern_10044;
                prism_rtl::Turn::Finished(st3.clone())
            })
        })
    }
}

/// `Start BindStmt, x`: what the function value is when passed to `@Run`.
pub fn start_bind_stmt(env: crate::check::expr::Env, st: crate::check::types::St, p_: crate::syntax::Pattern_, e: crate::syntax::Expr, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(BindStmt { env, st, p_, e, span })
}

/// ```prism
/// IsBuilder: fn Expr -> Bool
/// ```
pub fn is_builder(e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::ERebuild(_, _) => true,
        crate::syntax::ExprKind::EFor(_, _, _) => true,
        crate::syntax::ExprKind::EGroup(x) => is_builder(&**x),
        _ => false,
    }
}

/// ```prism
/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
/// ```
pub fn bind_output(env: &crate::check::expr::Env, st: &crate::check::types::St, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyAt(inner, rw) => ((*inner).clone(), add_incl(st, &rw, &env.scope, span, &Text::lit("child"))),
        crate::check::types::Ty::TyElem(rw, o) => ((*o).clone(), add_incl(st, &rw, &env.scope, span, &Text::lit("element"))),
        crate::check::types::Ty::TySig(s, inner) => match crate::check::types::recording::walk(st, &*inner) {
            crate::check::types::Ty::TyAt(_, _) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(st, &Text::lit("bind-dynamic"), span, &Text::from(format!("binding a `{}`; say what happens to the old widgets with `rebuild`", &crate::check::types::show_ty(st, t))), &Text::lit("write `rebuild` over the dynamic, with the blueprint inside"))),
            crate::check::types::Ty::TyElem(_, _) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(st, &Text::lit("bind-dynamic"), span, &Text::from(format!("binding a `{}`, a {} of elements; say what happens to the old element with `rebuild`", &crate::check::types::show_ty(st, t), &(if &s == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }))), &Text::lit("write `rebuild` over the dynamic field\'s value, with the element inside"))),
            _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &crate::check::types::show_ty(st, t))))),
        },
        crate::check::types::Ty::TyFlex(_) => {
            let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
            (v_.clone(), crate::check::types::unify::unify(&st2, t, &crate::check::types::Ty::TyAt(Rc::new(v_.clone()), env.scope.clone()), span))
        },
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st.clone()),
        other => (crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &crate::check::types::show_ty(st, &other))))),
    }
}

/// The step machine of `BindOutput`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
/// ```
pub struct BindOutput {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BindOutput {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let span = &self.span;
        let env = env.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_10439: crate::check::types::Ty| match walk_10439 {
            crate::check::types::Ty::TyAt(inner, rw) => prism_rtl::Turn::Finished(((*inner).clone(), add_incl(&st, &rw, &env.scope, &span, &Text::lit("child")))),
            crate::check::types::Ty::TyElem(rw, o) => prism_rtl::Turn::Finished(((*o).clone(), add_incl(&st, &rw, &env.scope, &span, &Text::lit("element")))),
            crate::check::types::Ty::TySig(s, inner) => call_then(crate::check::types::recording::start_walk(st.clone(), (*inner).clone()), move |walk_10629: crate::check::types::Ty| match walk_10629 {
                crate::check::types::Ty::TyAt(_, _) => call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_10734: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(&st, &Text::lit("bind-dynamic"), &span, &Text::from(format!("binding a `{}`; say what happens to the old widgets with `rebuild`", &show_ty_10734)), &Text::lit("write `rebuild` over the dynamic, with the blueprint inside"))))),
                crate::check::types::Ty::TyElem(_, _) => call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_10959: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(&st, &Text::lit("bind-dynamic"), &span, &Text::from(format!("binding a `{}`, a {} of elements; say what happens to the old element with `rebuild`", &show_ty_10959, &(if &s == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }))), &Text::lit("write `rebuild` over the dynamic field\'s value, with the element inside"))))),
                _ => call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_11267: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &show_ty_11267)))))),
            }),
            crate::check::types::Ty::TyFlex(_) => {
                let (v_, st2) = crate::check::types::fresh_var(&st, &false, &Text::lit(""));
                call_then(crate::check::types::unify::start_unify(st2.clone(), t.clone(), crate::check::types::Ty::TyAt(Rc::new(v_.clone()), env.scope.clone()), span.clone()), move |unify_11367: crate::check::types::St| prism_rtl::Turn::Finished((v_.clone(), unify_11367)))
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st.clone())),
            other => call_then(crate::check::types::start_show_ty(st.clone(), other.clone()), move |show_ty_11531: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &show_ty_11531)))))),
        })
    }
}

/// `Start BindOutput, x`: what the function value is when passed to `@Run`.
pub fn start_bind_output(env: crate::check::expr::Env, st: crate::check::types::St, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BindOutput { env, st, t, span })
}

/// ```prism
/// AddIncl: fn St, Rw, Rw, Range, Text -> St
/// ```
pub fn add_incl(st: &crate::check::types::St, sub: &crate::check::types::Rw, sup: &crate::check::types::Rw, span: &crate::syntax::Range, what: &Text) -> crate::check::types::St {
    let mut this: crate::check::types::St = st.clone();
    this.incls = push(&this.incls, &crate::check::types::Incl { sub: sub.clone(), sup: sup.clone(), file: this.file.clone(), span: span.clone(), what: what.clone(), forward: false });
    this
}

/// ```prism
/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
/// ```
pub fn hold_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, p_: &crate::syntax::Pattern_, init: &crate::syntax::Expr, step_: &crate::syntax::Expr, span: &crate::syntax::Range) -> crate::check::types::St {
    let (v_, st1) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
    let held = crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_.clone()));
    let (_, st2) = crate::check::expr::patterns::bind_pattern(env, &st1, p_, &held, &false);
    let st3 = crate::check::expr::check(env, &st2, init, &v_);
    let (step_ty, st4) = crate::check::expr::infer(env, &st3, step_);
    if (&crate::check::types::head_sigil(&st4, &step_ty) == &Text::lit("!")) || (&step_ty == &crate::check::types::Ty::TyErr) {
        crate::check::types::unify::unify(&st4, &crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone())), &step_ty, &step_.span)
    } else {
        crate::check::types::recording::err_fix(&st4, &Text::lit("mismatch"), &step_.span, &Text::from(format!("a hold\'s step is an event; this is `{}`", &crate::check::types::show_ty(&st4, &step_ty))), &Text::lit("fire it with an event: `... on !e`"))
    }
}

/// The step machine of `HoldStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
/// ```
pub struct HoldStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub p_: crate::syntax::Pattern_,
    pub init: crate::syntax::Expr,
    pub step_: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for HoldStmt {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let init = &self.init;
        let step_ = &self.step_;
        let span = &self.span;
        let (v_, st1) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
        let held = crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_.clone()));
        let env = env.clone();
        let init = init.clone();
        let p_ = p_.clone();
        let span = span.clone();
        let step_ = step_.clone();
        call_then(crate::check::expr::patterns::start_bind_pattern(env.clone(), st1.clone(), p_.clone(), held.clone(), false), move |bind_pattern_12074: (crate::check::expr::Env, crate::check::types::St)| {
            let (_, st2) = bind_pattern_12074;
            call_then(crate::check::expr::start_check(env.clone(), st2.clone(), init.clone(), v_.clone()), move |check_12125: crate::check::types::St| {
                let st3 = check_12125;
                call_then(crate::check::expr::start_infer(env.clone(), st3.clone(), step_.clone()), move |infer_12175: (crate::check::types::Ty, crate::check::types::St)| {
                    let (step_ty, st4) = infer_12175;
                    call_then(crate::check::types::start_head_sigil(st4.clone(), step_ty.clone()), move |head_sigil_12204: Text| if (&head_sigil_12204 == &Text::lit("!")) || (&step_ty == &crate::check::types::Ty::TyErr) {
                        prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st4.clone(), expected: crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone())), found: step_ty.clone(), span: step_.span.clone() }))
                    } else {
                        call_then(crate::check::types::start_show_ty(st4.clone(), step_ty.clone()), move |show_ty_12382: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st4, &Text::lit("mismatch"), &step_.span, &Text::from(format!("a hold\'s step is an event; this is `{}`", &show_ty_12382)), &Text::lit("fire it with an event: `... on !e`"))))
                    })
                })
            })
        })
    }
}

/// `Start HoldStmt, x`: what the function value is when passed to `@Run`.
pub fn start_hold_stmt(env: crate::check::expr::Env, st: crate::check::types::St, p_: crate::syntax::Pattern_, init: crate::syntax::Expr, step_: crate::syntax::Expr, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(HoldStmt { env, st, p_, init, step_, span })
}

/// ```prism
/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
/// ```
pub fn ignore_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, e: &crate::syntax::Expr, span: &crate::syntax::Range) -> crate::check::types::St {
    let (t, st1) = crate::check::expr::infer(env, st, e);
    match crate::check::types::recording::walk(&st1, &t) {
        crate::check::types::Ty::TyAt(_, _) => {
            let (_, st2) = bind_output(env, &st1, &t, &e.span);
            st2.clone()
        },
        crate::check::types::Ty::TyElem(_, _) => {
            let (_, st2) = bind_output(env, &st1, &t, &e.span);
            st2.clone()
        },
        crate::check::types::Ty::TySig(_, inner) => match crate::check::types::recording::walk(&st1, &*inner) {
            crate::check::types::Ty::TyAt(_, _) => {
                let (_, st2) = bind_output(env, &st1, &t, &e.span);
                st2.clone()
            },
            crate::check::types::Ty::TyElem(_, _) => {
                let (_, st2) = bind_output(env, &st1, &t, &e.span);
                st2.clone()
            },
            _ => st1.clone(),
        },
        _ => st1.clone(),
    }
}

/// The step machine of `IgnoreStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
/// ```
pub struct IgnoreStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub e: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for IgnoreStmt {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let span = &self.span;
        let e = e.clone();
        let env = env.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_12615: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st1) = infer_12615;
            call_then(crate::check::types::recording::start_walk(st1.clone(), t.clone()), move |walk_12642: crate::check::types::Ty| match walk_12642 {
                crate::check::types::Ty::TyAt(_, _) => call_then(start_bind_output(env.clone(), st1.clone(), t.clone(), e.span.clone()), move |bind_output_12718: (crate::check::types::Ty, crate::check::types::St)| {
                    let (_, st2) = bind_output_12718;
                    prism_rtl::Turn::Finished(st2.clone())
                }),
                crate::check::types::Ty::TyElem(_, _) => call_then(start_bind_output(env.clone(), st1.clone(), t.clone(), e.span.clone()), move |bind_output_12830: (crate::check::types::Ty, crate::check::types::St)| {
                    let (_, st2) = bind_output_12830;
                    prism_rtl::Turn::Finished(st2.clone())
                }),
                crate::check::types::Ty::TySig(_, inner) => call_then(crate::check::types::recording::start_walk(st1.clone(), (*inner).clone()), move |walk_12912: crate::check::types::Ty| match walk_12912 {
                    crate::check::types::Ty::TyAt(_, _) => call_then(start_bind_output(env.clone(), st1.clone(), t.clone(), e.span.clone()), move |bind_output_13000: (crate::check::types::Ty, crate::check::types::St)| {
                        let (_, st2) = bind_output_13000;
                        prism_rtl::Turn::Finished(st2.clone())
                    }),
                    crate::check::types::Ty::TyElem(_, _) => call_then(start_bind_output(env.clone(), st1.clone(), t.clone(), e.span.clone()), move |bind_output_13124: (crate::check::types::Ty, crate::check::types::St)| {
                        let (_, st2) = bind_output_13124;
                        prism_rtl::Turn::Finished(st2.clone())
                    }),
                    _ => prism_rtl::Turn::Finished(st1.clone()),
                }),
                _ => prism_rtl::Turn::Finished(st1.clone()),
            })
        })
    }
}

/// `Start IgnoreStmt, x`: what the function value is when passed to `@Run`.
pub fn start_ignore_stmt(env: crate::check::expr::Env, st: crate::check::types::St, e: crate::syntax::Expr, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(IgnoreStmt { env, st, e, span })
}

/// ```prism
/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub fn bare_line(env: &crate::check::expr::Env, st: &crate::check::types::St, e: &crate::syntax::Expr, last: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t, st2) = bare_line_kind(env, st, e, last);
    let shown = match &*e.kind {
        crate::syntax::ExprKind::EFreeSigil(m13583_0_0, _) if (m13583_0_0 == &Text::lit("@")) => crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
        crate::syntax::ExprKind::EMatch(_, _) => crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
        crate::syntax::ExprKind::EIf(_, _, _) => crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
        _ => t.clone(),
        _ => unreachable!("no arm matched"),
    };
    match &*e.kind {
        crate::syntax::ExprKind::EFreeSigil(m13775_0_0, _) if (m13775_0_0 == &Text::lit("@")) => (t.clone(), crate::check::types::recording::note_ty(&st2, &e.span, &shown)),
        crate::syntax::ExprKind::EMatch(_, _) => (t.clone(), crate::check::types::recording::note_ty(&st2, &e.span, &shown)),
        crate::syntax::ExprKind::EIf(_, _, _) => (t.clone(), crate::check::types::recording::note_ty(&st2, &e.span, &shown)),
        crate::syntax::ExprKind::EGroup(_) => (t.clone(), note_as_last(&st2, &e.span)),
        _ => (t.clone(), st2.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BareLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub struct BareLine {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub e: crate::syntax::Expr,
    pub last: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BareLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let last = &self.last;
        let e = e.clone();
        let env = env.clone();
        let last = *last;
        let st = st.clone();
        call_then(start_bare_line_kind(env.clone(), st.clone(), e.clone(), last), move |bare_line_kind_13537: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st2) = bare_line_kind_13537;
            let shown = match &*e.kind {
                crate::syntax::ExprKind::EFreeSigil(m13583_0_0, _) if (m13583_0_0 == &Text::lit("@")) => crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
                crate::syntax::ExprKind::EMatch(_, _) => crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
                crate::syntax::ExprKind::EIf(_, _, _) => crate::check::types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
                _ => t.clone(),
                _ => unreachable!("no arm matched"),
            };
            match &*e.kind {
                crate::syntax::ExprKind::EFreeSigil(m13775_0_0, _) if (m13775_0_0 == &Text::lit("@")) => prism_rtl::Turn::Finished((t.clone(), crate::check::types::recording::note_ty(&st2, &e.span, &shown))),
                crate::syntax::ExprKind::EMatch(_, _) => prism_rtl::Turn::Finished((t.clone(), crate::check::types::recording::note_ty(&st2, &e.span, &shown))),
                crate::syntax::ExprKind::EIf(_, _, _) => prism_rtl::Turn::Finished((t.clone(), crate::check::types::recording::note_ty(&st2, &e.span, &shown))),
                crate::syntax::ExprKind::EGroup(_) => prism_rtl::Turn::Finished((t.clone(), note_as_last(&st2, &e.span))),
                _ => prism_rtl::Turn::Finished((t.clone(), st2.clone())),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start BareLine, x`: what the function value is when passed to `@Run`.
pub fn start_bare_line(env: crate::check::expr::Env, st: crate::check::types::St, e: crate::syntax::Expr, last: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BareLine { env, st, e, last })
}

/// ```prism
/// NoteAsLast: fn St, Range -> St
/// ```
pub fn note_as_last(st: &crate::check::types::St, span: &crate::syntax::Range) -> crate::check::types::St {
    match crate::syntax::lexer::chars::last(&st.typed.exprs) {
        Some(n) => crate::check::types::recording::note_ty(st, span, &n.ty),
        None => st.clone(),
    }
}

/// ```prism
/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub fn bare_line_kind(env: &crate::check::expr::Env, st: &crate::check::types::St, e: &crate::syntax::Expr, last: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*e.kind {
        crate::syntax::ExprKind::EMatch(scrut, arms) => building_match(env, st, &**scrut, arms, &e.span, last),
        crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => building_if(env, st, &**c, then_b, else_b_opt, &e.span, last),
        crate::syntax::ExprKind::EFreeSigil(m14357_2_0, x) if (m14357_2_0 == &Text::lit("@")) => {
            let (t, st2) = crate::check::expr::infer(env, st, &**x);
            if *last {
                (t.clone(), st2.clone())
            } else {
                (t.clone(), discarded(&st2, &t, &e.span))
            }
        },
        crate::syntax::ExprKind::EGroup(x) => bare_line(env, st, &**x, last),
        _ => {
            let (t, st1) = crate::check::expr::infer(env, st, e);
            let (res, st2) = match crate::check::types::recording::walk(&st1, &t) {
                crate::check::types::Ty::TyAt(_, _) => bind_output(env, &st1, &t, &e.span),
                crate::check::types::Ty::TyElem(_, _) => bind_output(env, &st1, &t, &e.span),
                crate::check::types::Ty::TyErr => (crate::check::types::t_unit(), st1.clone()),
                other => if is_builder(e) {
                    (other.clone(), st1.clone())
                } else {
                    if &crate::check::types::recording::walk(&st1, &other) == &crate::check::types::t_unit() {
                        (crate::check::types::t_unit(), st1.clone())
                    } else {
                        (other.clone(), crate::check::types::recording::err_fix(&st1, &Text::lit("mismatch"), &e.span, &Text::from(format!("a bare line emits an element or builds a blueprint; this is `{}`", &crate::check::types::show_ty(&st1, &other))), &Text::from(format!("end the block on a value with `@ {}`", &crate::check::expr::src_text(env, &e.span)))))
                    }
                },
            };
            if *last {
                (res.clone(), st2.clone())
            } else {
                (res.clone(), discarded(&st2, &res, &e.span))
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BareLineKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub struct BareLineKind {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub e: crate::syntax::Expr,
    pub last: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BareLineKind {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let last = &self.last;
        match &*e.kind {
            crate::syntax::ExprKind::EMatch(scrut, arms) => prism_rtl::Turn::More(Rc::new(BuildingMatch { env: env.clone(), st: st.clone(), scrut: (**scrut).clone(), arms: arms.clone(), span: e.span.clone(), last: *last })),
            crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => prism_rtl::Turn::More(Rc::new(BuildingIf { env: env.clone(), st: st.clone(), c: (**c).clone(), then_b: then_b.clone(), else_b_opt: else_b_opt.clone(), span: e.span.clone(), last: *last })),
            crate::syntax::ExprKind::EFreeSigil(m14357_2_0, x) if (m14357_2_0 == &Text::lit("@")) => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let st = st.clone();
                let x = (**x).clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), x.clone()), move |infer_14569: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_14569;
                    if last {
                        prism_rtl::Turn::Finished((t.clone(), st2.clone()))
                    } else {
                        call_then(start_discarded(st2.clone(), t.clone(), e.span.clone()), move |discarded_14626: crate::check::types::St| prism_rtl::Turn::Finished((t.clone(), discarded_14626)))
                    }
                })
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(BareLine { env: env.clone(), st: st.clone(), e: (**x).clone(), last: *last })),
            _ => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let st = st.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_14734: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st1) = infer_14734;
                    call_then(crate::check::types::recording::start_walk(st1.clone(), t.clone()), move |walk_14784: crate::check::types::Ty| {
                        let (res, st2) = match walk_14784 {
                            crate::check::types::Ty::TyAt(_, _) => bind_output(&env, &st1, &t, &e.span),
                            crate::check::types::Ty::TyElem(_, _) => bind_output(&env, &st1, &t, &e.span),
                            crate::check::types::Ty::TyErr => (crate::check::types::t_unit(), st1.clone()),
                            other => if is_builder(&e) {
                                (other.clone(), st1.clone())
                            } else {
                                if &crate::check::types::recording::walk(&st1, &other) == &crate::check::types::t_unit() {
                                    (crate::check::types::t_unit(), st1.clone())
                                } else {
                                    (other.clone(), crate::check::types::recording::err_fix(&st1, &Text::lit("mismatch"), &e.span, &Text::from(format!("a bare line emits an element or builds a blueprint; this is `{}`", &crate::check::types::show_ty(&st1, &other))), &Text::from(format!("end the block on a value with `@ {}`", &crate::check::expr::src_text(&env, &e.span)))))
                                }
                            },
                        };
                        if last {
                            prism_rtl::Turn::Finished((res.clone(), st2.clone()))
                        } else {
                            call_then(start_discarded(st2.clone(), res.clone(), e.span.clone()), move |discarded_15349: crate::check::types::St| prism_rtl::Turn::Finished((res.clone(), discarded_15349)))
                        }
                    })
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start BareLineKind, x`: what the function value is when passed to `@Run`.
pub fn start_bare_line_kind(env: crate::check::expr::Env, st: crate::check::types::St, e: crate::syntax::Expr, last: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BareLineKind { env, st, e, last })
}

/// ```prism
/// Discarded: unbounded fn St, Ty, Range -> St
/// ```
pub fn discarded(st: &crate::check::types::St, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyCon(m15513_0_0, m15513_0_1) if (&m15513_0_0 == &Text::lit("unit")) && ((&m15513_0_1).len() == 0) => st.clone(),
        crate::check::types::Ty::TyErr => st.clone(),
        crate::check::types::Ty::TyFlex(_) => crate::check::types::unify::unify(st, &crate::check::types::t_unit(), t, span),
        other => crate::check::types::recording::err_fix(st, &Text::lit("discarded"), span, &Text::from(format!("this line\'s result is `{}`; drop it with `ignore <-`", &crate::check::types::show_ty(st, &other))), &Text::lit("write `ignore <-` in front of it, or bind it")),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Discarded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Discarded: unbounded fn St, Ty, Range -> St
/// ```
pub struct Discarded {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for Discarded {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let t = &self.t;
        let span = &self.span;
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_15519: crate::check::types::Ty| match walk_15519 {
            crate::check::types::Ty::TyCon(m15513_0_0, m15513_0_1) if (&m15513_0_0 == &Text::lit("unit")) && ((&m15513_0_1).len() == 0) => prism_rtl::Turn::Finished(st.clone()),
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished(st.clone()),
            crate::check::types::Ty::TyFlex(_) => prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: st.clone(), expected: crate::check::types::t_unit(), found: t.clone(), span: span.clone() })),
            other => call_then(crate::check::types::start_show_ty(st.clone(), other.clone()), move |show_ty_15682: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&st, &Text::lit("discarded"), &span, &Text::from(format!("this line\'s result is `{}`; drop it with `ignore <-`", &show_ty_15682)), &Text::lit("write `ignore <-` in front of it, or bind it")))),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start Discarded, x`: what the function value is when passed to `@Run`.
pub fn start_discarded(st: crate::check::types::St, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Discarded { st, t, span })
}

/// ```prism
/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
/// ```
pub fn building_match(env: &crate::check::expr::Env, st: &crate::check::types::St, scrut: &crate::syntax::Expr, arms: &Array<crate::syntax::Arm>, span: &crate::syntax::Range, last: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    let (st_ty, st1) = crate::check::expr::infer(env, st, scrut);
    let sh = crate::check::types::head_sigil(&st1, &st_ty);
    let st2 = if crate::check::expr::is_time_sigil(&sh) {
        crate::check::types::recording::err_fix(&st1, &Text::lit("building-match"), &scrut.span, &Text::from(format!("a blueprint in a match over a {}; use `rebuild`", &(if &sh == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }))), &Text::from(format!("write `rebuild {}:` with `match _:` inside", &crate::check::expr::src_text(env, &scrut.span))))
    } else {
        st1.clone()
    };
    let plain_scrut = if crate::check::expr::is_time_sigil(&sh) {
        crate::check::expr::inner_of(&st2, &st_ty)
    } else {
        st_ty.clone()
    };
    let (res, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
    let st4 = run_to_end(fold_job(arms.clone(), st3.clone(), {
        let env = env.clone();
        let plain_scrut = plain_scrut.clone();
        let res = res.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
            let env = env.clone();
            let plain_scrut = plain_scrut.clone();
            let res = res.clone();
            entered(once_job(move || {
                let s = p0;
                let arm = p1;
                {
                    let (env2, s1) = match &arm.pattern {
                        Some(p_) => crate::check::expr::patterns::bind_pattern(&env, &s, p_, &plain_scrut, &true),
                        None => (env.clone(), s.clone()),
                    };
                    let s2 = match &arm.guard {
                        Some(gd) => crate::check::expr::lifting::check_cond(&env2, &s1, gd),
                        None => s1.clone(),
                    };
                    let (bt, s3) = arm_widget_block(&env2, &s2, &arm.body);
                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: s3.clone(), expected: res.clone(), found: bt.clone(), span: arm.body.span.clone() }))
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    let st5 = crate::check::passes::match_coverage(env, &st4, &plain_scrut, arms, span);
    if *last {
        (res.clone(), st5.clone())
    } else {
        (res.clone(), discarded(&st5, &res, span))
    }
}

/// The step machine of `BuildingMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
/// ```
pub struct BuildingMatch {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub scrut: crate::syntax::Expr,
    pub arms: Array<crate::syntax::Arm>,
    pub span: crate::syntax::Range,
    pub last: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BuildingMatch {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let scrut = &self.scrut;
        let arms = &self.arms;
        let span = &self.span;
        let last = &self.last;
        let arms = arms.clone();
        let env = env.clone();
        let last = *last;
        let scrut = scrut.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), scrut.clone()), move |infer_16086: (crate::check::types::Ty, crate::check::types::St)| {
            let (st_ty, st1) = infer_16086;
            call_then(crate::check::types::start_head_sigil(st1.clone(), st_ty.clone()), move |head_sigil_16120: Text| {
                let sh = head_sigil_16120;
                let st2 = if crate::check::expr::is_time_sigil(&sh) {
                    crate::check::types::recording::err_fix(&st1, &Text::lit("building-match"), &scrut.span, &Text::from(format!("a blueprint in a match over a {}; use `rebuild`", &(if &sh == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }))), &Text::from(format!("write `rebuild {}:` with `match _:` inside", &crate::check::expr::src_text(&env, &scrut.span))))
                } else {
                    st1.clone()
                };
                let plain_scrut = if crate::check::expr::is_time_sigil(&sh) {
                    crate::check::expr::inner_of(&st2, &st_ty)
                } else {
                    st_ty.clone()
                };
                let (res, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
                call_value(fold_job(arms.clone(), st3.clone(), {
                    let env = env.clone();
                    let plain_scrut = plain_scrut.clone();
                    let res = res.clone();
                    Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                        let env = env.clone();
                        let plain_scrut = plain_scrut.clone();
                        let res = res.clone();
                        entered(once_job(move || {
                            let s = p0;
                            let arm = p1;
                            {
                                let (env2, s1) = match &arm.pattern {
                                    Some(p_) => crate::check::expr::patterns::bind_pattern(&env, &s, p_, &plain_scrut, &true),
                                    None => (env.clone(), s.clone()),
                                };
                                let s2 = match &arm.guard {
                                    Some(gd) => crate::check::expr::lifting::check_cond(&env2, &s1, gd),
                                    None => s1.clone(),
                                };
                                let (bt, s3) = arm_widget_block(&env2, &s2, &arm.body);
                                prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st: s3.clone(), expected: res.clone(), found: bt.clone(), span: arm.body.span.clone() }))
                            }
                        }))
                    }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                }), move |fold_16511: crate::check::types::St| {
                    let st4 = fold_16511;
                    call_then(crate::check::passes::start_match_coverage(env.clone(), st4.clone(), plain_scrut.clone(), arms.clone(), span.clone()), move |match_coverage_16879: crate::check::types::St| {
                        let st5 = match_coverage_16879;
                        if last {
                            prism_rtl::Turn::Finished((res.clone(), st5.clone()))
                        } else {
                            call_then(start_discarded(st5.clone(), res.clone(), span.clone()), move |discarded_16966: crate::check::types::St| prism_rtl::Turn::Finished((res.clone(), discarded_16966)))
                        }
                    })
                })
            })
        })
    }
}

/// `Start BuildingMatch, x`: what the function value is when passed to `@Run`.
pub fn start_building_match(env: crate::check::expr::Env, st: crate::check::types::St, scrut: crate::syntax::Expr, arms: Array<crate::syntax::Arm>, span: crate::syntax::Range, last: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BuildingMatch { env, st, scrut, arms, span, last })
}

/// ```prism
/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
/// ```
pub fn building_if(env: &crate::check::expr::Env, st: &crate::check::types::St, c: &crate::syntax::Cond, then_b: &crate::syntax::Block, else_b_opt: &Option<crate::syntax::Block>, span: &crate::syntax::Range, last: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    let (env2, st1) = match c {
        crate::syntax::Cond::CondExpr(e) => {
            let (ct, s1) = crate::check::expr::infer(env, st, &**e);
            let sh = crate::check::types::head_sigil(&s1, &ct);
            let s2 = if crate::check::expr::is_time_sigil(&sh) {
                crate::check::types::recording::err_fix(&s1, &Text::lit("building-match"), &e.span, &Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &Text::lit("write `rebuild` over the condition, with `if _:` inside"))
            } else {
                s1.clone()
            };
            (env.clone(), crate::check::types::unify::unify(&s2, &crate::check::types::t_bool(), &(if crate::check::expr::is_time_sigil(&sh) {
                crate::check::expr::inner_of(&s2, &ct)
            } else {
                ct.clone()
            }), &e.span))
        },
        crate::syntax::Cond::CondBind(p_, e, gd_opt) => {
            let (et, s1) = crate::check::expr::infer(env, st, &**e);
            let (en, s2) = crate::check::expr::patterns::bind_pattern(env, &s1, p_, &et, &true);
            match &**gd_opt {
                Some(g) => (en.clone(), crate::check::expr::lifting::check_cond(&en, &s2, g)),
                None => (en.clone(), s2.clone()),
            }
        },
    };
    let (t1, st2) = arm_widget_block(&env2, &st1, then_b);
    match else_b_opt {
        Some(b) => {
            let (t2, st3) = arm_widget_block(env, &st2, b);
            let st4 = crate::check::types::unify::unify(&st3, &t1, &t2, &b.span);
            if *last {
                (t1.clone(), st4.clone())
            } else {
                (t1.clone(), discarded(&st4, &t1, span))
            }
        },
        None => {
            let st3 = crate::check::types::unify::unify(&st2, &crate::check::types::t_unit(), &t1, &then_b.span);
            (crate::check::types::t_unit(), st3.clone())
        },
    }
}

/// The step machine of `BuildingIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
/// ```
pub struct BuildingIf {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub c: crate::syntax::Cond,
    pub then_b: crate::syntax::Block,
    pub else_b_opt: Option<crate::syntax::Block>,
    pub span: crate::syntax::Range,
    pub last: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BuildingIf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let span = &self.span;
        let last = &self.last;
        let (env2, st1) = match c {
            crate::syntax::Cond::CondExpr(e) => {
                let (ct, s1) = crate::check::expr::infer(env, st, &**e);
                let sh = crate::check::types::head_sigil(&s1, &ct);
                let s2 = if crate::check::expr::is_time_sigil(&sh) {
                    crate::check::types::recording::err_fix(&s1, &Text::lit("building-match"), &e.span, &Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &Text::lit("write `rebuild` over the condition, with `if _:` inside"))
                } else {
                    s1.clone()
                };
                (env.clone(), crate::check::types::unify::unify(&s2, &crate::check::types::t_bool(), &(if crate::check::expr::is_time_sigil(&sh) {
                    crate::check::expr::inner_of(&s2, &ct)
                } else {
                    ct.clone()
                }), &e.span))
            },
            crate::syntax::Cond::CondBind(p_, e, gd_opt) => {
                let (et, s1) = crate::check::expr::infer(env, st, &**e);
                let (en, s2) = crate::check::expr::patterns::bind_pattern(env, &s1, p_, &et, &true);
                match &**gd_opt {
                    Some(g) => (en.clone(), crate::check::expr::lifting::check_cond(&en, &s2, g)),
                    None => (en.clone(), s2.clone()),
                }
            },
        };
        let (t1, st2) = arm_widget_block(&env2, &st1, then_b);
        match else_b_opt {
            Some(b) => {
                let (t2, st3) = arm_widget_block(env, &st2, b);
                let b = b.clone();
                let last = *last;
                let span = span.clone();
                call_then(crate::check::types::unify::start_unify(st3.clone(), t1.clone(), t2.clone(), b.span.clone()), move |unify_17965: crate::check::types::St| {
                    let st4 = unify_17965;
                    if last {
                        prism_rtl::Turn::Finished((t1.clone(), st4.clone()))
                    } else {
                        call_then(start_discarded(st4.clone(), t1.clone(), span.clone()), move |discarded_18037: crate::check::types::St| prism_rtl::Turn::Finished((t1.clone(), discarded_18037)))
                    }
                })
            },
            None => {
                let span = span.clone();
                let then_b = then_b.clone();
                call_then(crate::check::types::unify::start_unify(st2.clone(), crate::check::types::t_unit(), t1.clone(), then_b.span.clone()), move |unify_18099: crate::check::types::St| {
                    let st3 = unify_18099;
                    prism_rtl::Turn::Finished((crate::check::types::t_unit(), st3.clone()))
                })
            },
        }
    }
}

/// `Start BuildingIf, x`: what the function value is when passed to `@Run`.
pub fn start_building_if(env: crate::check::expr::Env, st: crate::check::types::St, c: crate::syntax::Cond, then_b: crate::syntax::Block, else_b_opt: Option<crate::syntax::Block>, span: crate::syntax::Range, last: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BuildingIf { env, st, c, then_b, else_b_opt, span, last })
}

/// ```prism
/// ArmWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub fn arm_widget_block(env: &crate::check::expr::Env, st: &crate::check::types::St, b: &crate::syntax::Block) -> (crate::check::types::Ty, crate::check::types::St) {
    infer_widget_block(env, st, b)
}
