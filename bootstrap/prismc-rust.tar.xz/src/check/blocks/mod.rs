//! The module `Check.Blocks`, from `target/bootstrap/src/prismc/check/blocks/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod borrows;
pub mod structure;

/// ```prism
/// GroupOrder: unbounded fn [Stmt] -> [Nat]
/// ```
pub fn group_order_f(stmts_p0: &Array<crate::syntax::Stmt>) -> Array<Nat> {
    let all_p1 = crate::check::errors::range0_f(&crate::prelude::len(stmts_p0));
    let holds_p2 = crate::prelude::filter(&all_p1, &(|i_p6: &Nat| is_hold_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p6), &dummy_stmt2_p()))));
    let lets_p3 = crate::prelude::filter(&all_p1, &(|i_p7: &Nat| is_let_like_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p7), &dummy_stmt2_p()))));
    let rest_p4 = crate::prelude::filter(&all_p1, &(|i_p8: &Nat| !is_hold_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p8), &dummy_stmt2_p())) && !is_let_like_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p8), &dummy_stmt2_p()))));
    let ordered_p5 = crate::prelude::fold(&dep_order_f(&crate::prelude::each(&rest_p4, &(|i_p9: &Nat| crate::prelude::or(&crate::prelude::index(stmts_p0, i_p9), &dummy_stmt2_p())))), &Array::new(), &(|acc_pa: &Array<Nat>, comp_pb: &Array<Nat>| crate::prelude::append(acc_pa, &crate::prelude::each(comp_pb, &(|j_pc: &Nat| crate::prelude::or(&crate::prelude::index(&rest_p4, j_pc), &Nat::from(0u32)))))));
    crate::prelude::append(&crate::prelude::append(&holds_p2, &lets_p3), &ordered_p5)
}

/// The step machine of `GroupOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GroupOrder: unbounded fn [Stmt] -> [Nat]
/// ```
pub struct GroupOrder {
    pub stmts_p0: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<Nat>> for GroupOrder {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let stmts_p0 = &self.stmts_p0;
        let all_p1 = crate::check::errors::range0_f(&crate::prelude::len(stmts_p0));
        let holds_p2 = crate::prelude::filter(&all_p1, &(|i_p6: &Nat| is_hold_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p6), &dummy_stmt2_p()))));
        let lets_p3 = crate::prelude::filter(&all_p1, &(|i_p7: &Nat| is_let_like_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p7), &dummy_stmt2_p()))));
        let rest_p4 = crate::prelude::filter(&all_p1, &(|i_p8: &Nat| !is_hold_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p8), &dummy_stmt2_p())) && !is_let_like_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p8), &dummy_stmt2_p()))));
        let stmts_p0x = stmts_p0.clone();
        crate::prelude::call_then(start_dep_order_f(crate::prelude::each(&rest_p4, &(|i_p9: &Nat| crate::prelude::or(&crate::prelude::index(&stmts_p0x, i_p9), &dummy_stmt2_p())))), move |dep_order_f_2397: Array<Array<Nat>>| {
            let ordered_p5 = crate::prelude::fold(&dep_order_f_2397, &Array::new(), &(|acc_pa: &Array<Nat>, comp_pb: &Array<Nat>| crate::prelude::append(acc_pa, &crate::prelude::each(comp_pb, &(|j_pc: &Nat| crate::prelude::or(&crate::prelude::index(&rest_p4, j_pc), &Nat::from(0u32)))))));
            prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::append(&holds_p2, &lets_p3), &ordered_p5))
        })
    }
}

/// `Start GroupOrder, x`: what the function value is when passed to `@Run`.
pub fn start_group_order_f(stmts_p0: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(GroupOrder { stmts_p0 })
}

/// ```prism
/// WidgetGroupOrder: unbounded fn [Stmt] -> [Nat]
/// ```
pub fn widget_group_order_f(stmts_p0: &Array<crate::syntax::Stmt>) -> Array<Nat> {
    crate::prelude::fold(&dep_order_f(stmts_p0), &Array::new(), &(|acc_p1: &Array<Nat>, comp_p2: &Array<Nat>| {
        let holds_p3 = crate::prelude::filter(comp_p2, &(|i_p6: &Nat| is_hold_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p6), &dummy_stmt2_p()))));
        let lets_p4 = crate::prelude::filter(comp_p2, &(|i_p7: &Nat| is_let_like_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p7), &dummy_stmt2_p()))));
        let rest_p5 = crate::prelude::filter(comp_p2, &(|i_p8: &Nat| !is_hold_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p8), &dummy_stmt2_p())) && !is_let_like_f(&crate::prelude::or(&crate::prelude::index(stmts_p0, i_p8), &dummy_stmt2_p()))));
        crate::prelude::append(acc_p1, &crate::prelude::append(&crate::prelude::append(&holds_p3, &lets_p4), &rest_p5))
    }))
}

/// The step machine of `WidgetGroupOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetGroupOrder: unbounded fn [Stmt] -> [Nat]
/// ```
pub struct WidgetGroupOrder {
    pub stmts_p0: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<Nat>> for WidgetGroupOrder {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let stmts_p0 = &self.stmts_p0;
        let stmts_p0x = stmts_p0.clone();
        crate::prelude::call_then(start_dep_order_f(stmts_p0x.clone()), move |dep_order_f_3154: Array<Array<Nat>>| prism_rtl::Turn::Finished(crate::prelude::fold(&dep_order_f_3154, &Array::new(), &(|acc_p1: &Array<Nat>, comp_p2: &Array<Nat>| {
            let holds_p3 = crate::prelude::filter(comp_p2, &(|i_p6: &Nat| is_hold_f(&crate::prelude::or(&crate::prelude::index(&stmts_p0x, i_p6), &dummy_stmt2_p()))));
            let lets_p4 = crate::prelude::filter(comp_p2, &(|i_p7: &Nat| is_let_like_f(&crate::prelude::or(&crate::prelude::index(&stmts_p0x, i_p7), &dummy_stmt2_p()))));
            let rest_p5 = crate::prelude::filter(comp_p2, &(|i_p8: &Nat| !is_hold_f(&crate::prelude::or(&crate::prelude::index(&stmts_p0x, i_p8), &dummy_stmt2_p())) && !is_let_like_f(&crate::prelude::or(&crate::prelude::index(&stmts_p0x, i_p8), &dummy_stmt2_p()))));
            crate::prelude::append(acc_p1, &crate::prelude::append(&crate::prelude::append(&holds_p3, &lets_p4), &rest_p5))
        }))))
    }
}

/// `Start WidgetGroupOrder, x`: what the function value is when passed to `@Run`.
pub fn start_widget_group_order_f(stmts_p0: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(WidgetGroupOrder { stmts_p0 })
}

/// ```prism
/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub fn dep_order_f(stmts_p0: &Array<crate::syntax::Stmt>) -> Array<Array<Nat>> {
    let n_p1 = crate::prelude::len(stmts_p0);
    let defs_p2 = crate::prelude::run_to_end(crate::prelude::each_job(stmts_p0.clone(), Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p7 = p0;
        prism_rtl::Turn::More(Rc::new(GroupDefs { s_p0: s_p7.clone() }))
    }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let uses_p3 = crate::prelude::run_to_end(crate::prelude::each_job(stmts_p0.clone(), Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p8 = p0;
        prism_rtl::Turn::More(Rc::new(crate::check::shrink::locals::NamesInStmt { s_p0: s_p8.clone() }))
    }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let deps_p4 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_p9: &Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pa: &Nat| crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(&defs_p2, j_pa), &Array::new()), &false, &(|seen_pb: &bool, d_pc: &Text| *seen_pb || crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::index(&uses_p3, i_p9), &Array::new()), d_pc)))))));
    let reach_p5 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&n_p1), {
        let deps_p4x = deps_p4.clone();
        Rc::new(move |p0: Nat| {
            let deps_p4xy = deps_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pd = p0;
                prism_rtl::Turn::More(Rc::new(ReachIdx { deps_p0: deps_p4xy.clone(), frontier_p1: crate::prelude::or(&crate::prelude::index(&deps_p4xy, &i_pd), &Array::new()), seen_p2: Array::new() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    let comps_p6 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_pe: &Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pf: &Nat| (j_pf == i_pe) || (crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, i_pe), &Array::new()), j_pf) && crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, j_pf), &Array::new()), i_pe))))));
    emit_groups_f(&comps_p6, &deps_p4, &Array::new(), &Array::new())
}

/// The step machine of `DepOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub struct DepOrder {
    pub stmts_p0: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<Array<Nat>>> for DepOrder {
    fn cycle(&self) -> prism_rtl::Turn<Array<Array<Nat>>> {
        let stmts_p0 = &self.stmts_p0;
        let n_p1 = crate::prelude::len(stmts_p0);
        let stmts_p0x = stmts_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(stmts_p0x.clone(), Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
            let s_p7 = p0;
            prism_rtl::Turn::More(Rc::new(GroupDefs { s_p0: s_p7.clone() }))
        }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_4014: Array<Array<Text>>| {
            let defs_p2 = each_4014;
            crate::prelude::call_value(crate::prelude::each_job(stmts_p0x.clone(), Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p8 = p0;
                prism_rtl::Turn::More(Rc::new(crate::check::shrink::locals::NamesInStmt { s_p0: s_p8.clone() }))
            }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_4058: Array<Array<Text>>| {
                let uses_p3 = each_4058;
                let deps_p4 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_p9: &Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pa: &Nat| crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(&defs_p2, j_pa), &Array::new()), &false, &(|seen_pb: &bool, d_pc: &Text| *seen_pb || crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::index(&uses_p3, i_p9), &Array::new()), d_pc)))))));
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&n_p1), {
                    let deps_p4x = deps_p4.clone();
                    Rc::new(move |p0: Nat| {
                        let deps_p4xy = deps_p4x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_pd = p0;
                            prism_rtl::Turn::More(Rc::new(ReachIdx { deps_p0: deps_p4xy.clone(), frontier_p1: crate::prelude::or(&crate::prelude::index(&deps_p4xy, &i_pd), &Array::new()), seen_p2: Array::new() }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }), move |each_4247: Array<Array<Nat>>| {
                    let reach_p5 = each_4247;
                    let comps_p6 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_pe: &Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pf: &Nat| (j_pf == i_pe) || (crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, i_pe), &Array::new()), j_pf) && crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, j_pf), &Array::new()), i_pe))))));
                    prism_rtl::Turn::More(Rc::new(EmitGroups { comps_p0: comps_p6.clone(), deps_p1: deps_p4.clone(), done_p2: Array::new(), acc_p3: Array::new() }))
                })
            })
        })
    }
}

/// `Start DepOrder, x`: what the function value is when passed to `@Run`.
pub fn start_dep_order_f(stmts_p0: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Array<Nat>>>> {
    Rc::new(DepOrder { stmts_p0 })
}

/// ```prism
/// GroupDefs: unbounded fn Stmt -> [Text]
/// ```
pub fn group_defs_f(s_p0: &crate::syntax::Stmt) -> Array<Text> {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SBind(p_p1, _, _) => crate::check::env::names::pattern_names_f(p_p1),
        crate::syntax::StmtKind::SLet(p_p2, _, _) => crate::check::env::names::pattern_names_f(p_p2),
        crate::syntax::StmtKind::SFn(f_p3) => Array::from(vec![crate::check::env::def_name_text_f(&f_p3.name_p)]),
        crate::syntax::StmtKind::SWidget(w_p4) => Array::from(vec![crate::check::env::sname_key_f(&w_p4.name_p)]),
        _ => Array::new(),
    }
}

/// The step machine of `GroupDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GroupDefs: unbounded fn Stmt -> [Text]
/// ```
pub struct GroupDefs {
    pub s_p0: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<Text>> for GroupDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s_p0 = &self.s_p0;
        match &s_p0.kind_p {
            crate::syntax::StmtKind::SBind(p_p1, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::names::PatternNames { p_p0: p_p1.clone() })),
            crate::syntax::StmtKind::SLet(p_p2, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::env::names::PatternNames { p_p0: p_p2.clone() })),
            crate::syntax::StmtKind::SFn(f_p3) => prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::def_name_text_f(&f_p3.name_p)])),
            crate::syntax::StmtKind::SWidget(w_p4) => prism_rtl::Turn::Finished(Array::from(vec![crate::check::env::sname_key_f(&w_p4.name_p)])),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start GroupDefs, x`: what the function value is when passed to `@Run`.
pub fn start_group_defs_f(s_p0: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(GroupDefs { s_p0 })
}

/// ```prism
/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
/// ```
pub fn reach_idx_f(deps_p0: &Array<Array<Nat>>, frontier_p1: &Array<Nat>, seen_p2: &Array<Nat>) -> Array<Nat> {
    match crate::prelude::index(frontier_p1, &Nat::from(0u32)) {
        None => seen_p2.clone(),
        Some(x_p3) => if crate::check::types::has_nat_f(seen_p2, &x_p3) {
            reach_idx_f(deps_p0, &crate::prelude::drop(frontier_p1, &Nat::from(1u32)), seen_p2)
        } else {
            reach_idx_f(deps_p0, &crate::prelude::append(&crate::prelude::drop(frontier_p1, &Nat::from(1u32)), &crate::prelude::or(&crate::prelude::index(deps_p0, &x_p3), &Array::new())), &crate::prelude::push(seen_p2, &x_p3))
        },
    }
}

/// The step machine of `ReachIdx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
/// ```
pub struct ReachIdx {
    pub deps_p0: Array<Array<Nat>>,
    pub frontier_p1: Array<Nat>,
    pub seen_p2: Array<Nat>,
}

impl prism_rtl::Job<Array<Nat>> for ReachIdx {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let deps_p0 = &self.deps_p0;
        let frontier_p1 = &self.frontier_p1;
        let seen_p2 = &self.seen_p2;
        match crate::prelude::index(frontier_p1, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(seen_p2.clone()),
            Some(x_p3) => if crate::check::types::has_nat_f(seen_p2, &x_p3) {
                prism_rtl::Turn::More(Rc::new(ReachIdx { deps_p0: deps_p0.clone(), frontier_p1: crate::prelude::drop(frontier_p1, &Nat::from(1u32)), seen_p2: seen_p2.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(ReachIdx { deps_p0: deps_p0.clone(), frontier_p1: crate::prelude::append(&crate::prelude::drop(frontier_p1, &Nat::from(1u32)), &crate::prelude::or(&crate::prelude::index(deps_p0, &x_p3), &Array::new())), seen_p2: crate::prelude::push(seen_p2, &x_p3) }))
            },
        }
    }
}

/// `Start ReachIdx, x`: what the function value is when passed to `@Run`.
pub fn start_reach_idx_f(deps_p0: Array<Array<Nat>>, frontier_p1: Array<Nat>, seen_p2: Array<Nat>) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(ReachIdx { deps_p0, frontier_p1, seen_p2 })
}

/// ```prism
/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
/// ```
pub fn emit_groups_f(comps_p0: &Array<Array<Nat>>, deps_p1: &Array<Array<Nat>>, done_p2: &Array<Nat>, acc_p3: &Array<Array<Nat>>) -> Array<Array<Nat>> {
    let ready_p4 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(comps_p0)), &(|i_p5: &Nat| !crate::check::types::has_nat_f(done_p2, i_p5) && crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(deps_p1, i_p5), &Array::new()), &true, &(|ok_p6: &bool, d_p7: &Nat| *ok_p6 && (crate::check::types::has_nat_f(done_p2, d_p7) || crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(comps_p0, i_p5), &Array::new()), d_p7))))));
    match crate::prelude::index(&ready_p4, &Nat::from(0u32)) {
        None => acc_p3.clone(),
        Some(i_p8) => {
            let c_p9 = crate::prelude::or(&crate::prelude::index(comps_p0, &i_p8), &Array::from(vec![i_p8.clone()]));
            emit_groups_f(comps_p0, deps_p1, &crate::prelude::append(done_p2, &c_p9), &crate::prelude::push(acc_p3, &c_p9))
        },
    }
}

/// The step machine of `EmitGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
/// ```
pub struct EmitGroups {
    pub comps_p0: Array<Array<Nat>>,
    pub deps_p1: Array<Array<Nat>>,
    pub done_p2: Array<Nat>,
    pub acc_p3: Array<Array<Nat>>,
}

impl prism_rtl::Job<Array<Array<Nat>>> for EmitGroups {
    fn cycle(&self) -> prism_rtl::Turn<Array<Array<Nat>>> {
        let comps_p0 = &self.comps_p0;
        let deps_p1 = &self.deps_p1;
        let done_p2 = &self.done_p2;
        let acc_p3 = &self.acc_p3;
        let ready_p4 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(comps_p0)), &(|i_p5: &Nat| !crate::check::types::has_nat_f(done_p2, i_p5) && crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(deps_p1, i_p5), &Array::new()), &true, &(|ok_p6: &bool, d_p7: &Nat| *ok_p6 && (crate::check::types::has_nat_f(done_p2, d_p7) || crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(comps_p0, i_p5), &Array::new()), d_p7))))));
        match crate::prelude::index(&ready_p4, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(acc_p3.clone()),
            Some(i_p8) => {
                let c_p9 = crate::prelude::or(&crate::prelude::index(comps_p0, &i_p8), &Array::from(vec![i_p8.clone()]));
                prism_rtl::Turn::More(Rc::new(EmitGroups { comps_p0: comps_p0.clone(), deps_p1: deps_p1.clone(), done_p2: crate::prelude::append(done_p2, &c_p9), acc_p3: crate::prelude::push(acc_p3, &c_p9) }))
            },
        }
    }
}

/// `Start EmitGroups, x`: what the function value is when passed to `@Run`.
pub fn start_emit_groups_f(comps_p0: Array<Array<Nat>>, deps_p1: Array<Array<Nat>>, done_p2: Array<Nat>, acc_p3: Array<Array<Nat>>) -> Rc<dyn prism_rtl::Job<Array<Array<Nat>>>> {
    Rc::new(EmitGroups { comps_p0, deps_p1, done_p2, acc_p3 })
}

/// ```prism
/// IsHold: fn Stmt -> Bool
/// ```
pub fn is_hold_f(s_p0: &crate::syntax::Stmt) -> bool {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SBind(_, _, Some(_)) => true,
        _ => false,
    }
}

/// ```prism
/// IsLetLike: fn Stmt -> Bool
/// ```
pub fn is_let_like_f(s_p0: &crate::syntax::Stmt) -> bool {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SLet(_, _, _) => true,
        crate::syntax::StmtKind::SFn(_) => true,
        crate::syntax::StmtKind::SSignature(_) => true,
        _ => false,
    }
}

/// ```prism
/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub fn infer_widget_block_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block) -> (crate::check::types::Ty, crate::check::types::St) {
    let (env1_p6, st1_p7) = block_row_f(env_p0, st_p1, &b_p2.stmts_p);
    let (env2_pb, st2_pc) = crate::prelude::run_to_end(crate::prelude::fold_job(b_p2.stmts_p.clone(), (env1_p6.clone(), st1_p7.clone()), Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (en_p8, s_p9) = p0;
        let stmt_pa = p1;
        prism_rtl::Turn::More(Rc::new(PreBindStmt { env_p0: en_p8.clone(), st_p1: s_p9.clone(), s_p2: stmt_pa.clone() }))
    }))) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>));
    let n_p3 = crate::prelude::len(&b_p2.stmts_p);
    let (env3_pm, st3_pn, res_oo) = crate::prelude::run_to_end(crate::prelude::fold_job(widget_group_order_f(&b_p2.stmts_p), (env2_pb.clone(), st2_pc.clone(), None), {
        let b_p2x = b_p2.clone();
        let n_p3x = n_p3.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)| {
            let b_p2xy = b_p2x.clone();
            let n_p3xy = n_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (en_pd, s_pe, r_of) = p0;
                let i_pg = p1;
                {
                    let stmt_ph = crate::prelude::or(&crate::prelude::index(&b_p2xy.stmts_p, &i_pg), &dummy_stmt2_p());
                    crate::prelude::call_then(start_widget_stmt_f(en_pd.clone(), s_pe.clone(), stmt_ph.clone(), &(&i_pg + &Nat::from(1u32)) == &n_p3xy), move |widget_stmt_f_6645: (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)| {
                        let (en2_pi, s2_pj, r2_ok) = widget_stmt_f_6645;
                        match &r2_ok {
                            Some(t_pl) => prism_rtl::Turn::Finished((en2_pi.clone(), s2_pj.clone(), Some(t_pl.clone()))),
                            None => prism_rtl::Turn::Finished((en2_pi.clone(), s2_pj.clone(), r_of.clone())),
                        }
                    })
                }
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>>>
    }));
    let st4_p4 = crate::check::passes::cycles::block_prompt_cycles_f(&env3_pm, &st3_pn, b_p2);
    let st5_p5 = if st4_p4.recording_p {
        crate::check::types::recording::note_group_f(&st4_p4, &b_p2.span_p, &Text::lit("widget"), &dep_order_f(&b_p2.stmts_p))
    } else {
        st4_p4.clone()
    };
    (crate::prelude::or(&res_oo, &crate::check::types::t_unit_p()), st5_p5.clone())
}

/// The step machine of `InferWidgetBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub struct InferWidgetBlock {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferWidgetBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        let b_p2x = b_p2.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_block_row_f(env_p0x.clone(), st_p1x.clone(), b_p2x.stmts_p.clone()), move |block_row_f_6320: (crate::check::expr::Env, crate::check::types::St)| {
            let (env1_p6, st1_p7) = block_row_f_6320;
            crate::prelude::call_value(crate::prelude::fold_job(b_p2x.stmts_p.clone(), (env1_p6.clone(), st1_p7.clone()), Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (en_p8, s_p9) = p0;
                let stmt_pa = p1;
                prism_rtl::Turn::More(Rc::new(PreBindStmt { env_p0: en_p8.clone(), st_p1: s_p9.clone(), s_p2: stmt_pa.clone() }))
            }))) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>), move |fold_6370: (crate::check::expr::Env, crate::check::types::St)| {
                let (env2_pb, st2_pc) = fold_6370;
                let n_p3 = crate::prelude::len(&b_p2x.stmts_p);
                crate::prelude::call_then(start_widget_group_order_f(b_p2x.stmts_p.clone()), move |widget_group_order_f_6502: Array<Nat>| crate::prelude::call_value(crate::prelude::fold_job(widget_group_order_f_6502, (env2_pb.clone(), st2_pc.clone(), None), {
                    let b_p2xx = b_p2x.clone();
                    let n_p3x = n_p3.clone();
                    Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)| {
                        let b_p2xxy = b_p2xx.clone();
                        let n_p3xy = n_p3x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (en_pd, s_pe, r_of) = p0;
                            let i_pg = p1;
                            {
                                let stmt_ph = crate::prelude::or(&crate::prelude::index(&b_p2xxy.stmts_p, &i_pg), &dummy_stmt2_p());
                                crate::prelude::call_then(start_widget_stmt_f(en_pd.clone(), s_pe.clone(), stmt_ph.clone(), &(&i_pg + &Nat::from(1u32)) == &n_p3xy), move |widget_stmt_f_6645: (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)| {
                                    let (en2_pi, s2_pj, r2_ok) = widget_stmt_f_6645;
                                    match &r2_ok {
                                        Some(t_pl) => prism_rtl::Turn::Finished((en2_pi.clone(), s2_pj.clone(), Some(t_pl.clone()))),
                                        None => prism_rtl::Turn::Finished((en2_pi.clone(), s2_pj.clone(), r_of.clone())),
                                    }
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>>>
                }), move |fold_6496: (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)| {
                    let (env3_pm, st3_pn, res_oo) = fold_6496;
                    crate::prelude::call_then(crate::check::passes::cycles::start_block_prompt_cycles_f(env3_pm.clone(), st3_pn.clone(), b_p2x.clone()), move |block_prompt_cycles_f_6780: crate::check::types::St| {
                        let st4_p4 = block_prompt_cycles_f_6780;
                        let st5_p5 = if st4_p4.recording_p {
                            crate::check::types::recording::note_group_f(&st4_p4, &b_p2x.span_p, &Text::lit("widget"), &dep_order_f(&b_p2x.stmts_p))
                        } else {
                            st4_p4.clone()
                        };
                        prism_rtl::Turn::Finished((crate::prelude::or(&res_oo, &crate::check::types::t_unit_p()), st5_p5.clone()))
                    })
                }))
            })
        })
    }
}

/// `Start InferWidgetBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_widget_block_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferWidgetBlock { env_p0, st_p1, b_p2 })
}

/// ```prism
/// let dummyStmt2
/// ```
pub fn dummy_stmt2_p() -> crate::syntax::Stmt {
    crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }
}

/// ```prism
/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub fn block_row_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, stmts_p2: &Array<crate::syntax::Stmt>) -> (crate::check::expr::Env, crate::check::types::St) {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(stmts_p2)), (env_p0.clone(), st_p1.clone()), {
        let stmts_p2x = stmts_p2.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
            let stmts_p2xy = stmts_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (en_p3, s_p4) = p0;
                let i_p5 = p1;
                match crate::prelude::index(&stmts_p2xy, &i_p5) {
                    Some(stmt_p6) => match &stmt_p6.kind_p {
                        crate::syntax::StmtKind::SEmit(row_decl_p7) => if &i_p5 > &Nat::from(0u32) {
                            prism_rtl::Turn::Finished((en_p3.clone(), crate::check::types::recording::err_fix_f(&s_p4, &Text::lit("emit-element"), &stmt_p6.span_p, &Text::lit("`emit` comes first in its block"), &Text::lit("move this line to the top of the block"))))
                        } else {
                            {
                                let row_decl_p7x = row_decl_p7.clone();
                                crate::prelude::call_then(crate::check::env::reading::start_conv_row_f(crate::check::expr::env_cx_f(&en_p3), s_p4.clone(), row_as_type_f(&row_decl_p7x)), move |conv_row_f_7542: (crate::check::types::Rw, crate::check::types::St)| {
                                    let (rw_p9, s2_pa) = conv_row_f_7542;
                                    let en2_p8 = {
                                        let mut this: crate::check::expr::Env = en_p3.clone();
                                        this.scope_p = resolve_scope_row_f(&en_p3, &rw_p9);
                                        this
                                    };
                                    prism_rtl::Turn::Finished((en2_p8.clone(), s2_pa.clone()))
                                })
                            }
                        },
                        _ => prism_rtl::Turn::Finished((en_p3.clone(), s_p4.clone())),
                    },
                    None => prism_rtl::Turn::Finished((en_p3.clone(), s_p4.clone())),
                }
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
    }))
}

/// The step machine of `BlockRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub struct BlockRow {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub stmts_p2: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BlockRow {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let stmts_p2 = &self.stmts_p2;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(stmts_p2)), (env_p0.clone(), st_p1.clone()), {
            let stmts_p2x = stmts_p2.clone();
            Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), Nat)| {
                let stmts_p2xy = stmts_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (en_p3, s_p4) = p0;
                    let i_p5 = p1;
                    match crate::prelude::index(&stmts_p2xy, &i_p5) {
                        Some(stmt_p6) => match &stmt_p6.kind_p {
                            crate::syntax::StmtKind::SEmit(row_decl_p7) => if &i_p5 > &Nat::from(0u32) {
                                prism_rtl::Turn::Finished((en_p3.clone(), crate::check::types::recording::err_fix_f(&s_p4, &Text::lit("emit-element"), &stmt_p6.span_p, &Text::lit("`emit` comes first in its block"), &Text::lit("move this line to the top of the block"))))
                            } else {
                                {
                                    let row_decl_p7x = row_decl_p7.clone();
                                    crate::prelude::call_then(crate::check::env::reading::start_conv_row_f(crate::check::expr::env_cx_f(&en_p3), s_p4.clone(), row_as_type_f(&row_decl_p7x)), move |conv_row_f_7542: (crate::check::types::Rw, crate::check::types::St)| {
                                        let (rw_p9, s2_pa) = conv_row_f_7542;
                                        let en2_p8 = {
                                            let mut this: crate::check::expr::Env = en_p3.clone();
                                            this.scope_p = resolve_scope_row_f(&en_p3, &rw_p9);
                                            this
                                        };
                                        prism_rtl::Turn::Finished((en2_p8.clone(), s2_pa.clone()))
                                    })
                                }
                            },
                            _ => prism_rtl::Turn::Finished((en_p3.clone(), s_p4.clone())),
                        },
                        None => prism_rtl::Turn::Finished((en_p3.clone(), s_p4.clone())),
                    }
                }))
            }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start BlockRow, x`: what the function value is when passed to `@Run`.
pub fn start_block_row_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, stmts_p2: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BlockRow { env_p0, st_p1, stmts_p2 })
}

/// ```prism
/// RowAsType: fn Row -> Type
/// ```
pub fn row_as_type_f(row_decl_p0: &crate::syntax::Row_) -> crate::syntax::Type {
    crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TRowUnion(crate::prelude::each(&row_decl_p0.terms_p, &row_term_type_f))), span_p: row_decl_p0.span_p.clone() }
}

/// ```prism
/// RowTermType: fn RowTerm -> Type
/// ```
pub fn row_term_type_f(row_term0: &crate::syntax::RowTerm) -> crate::syntax::Type {
    match row_term0 {
        crate::syntax::RowTerm::RFamily(q_p0) => crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TFamily(q_p0.clone())), span_p: q_p0.span_p.clone() },
        crate::syntax::RowTerm::RVar(v_p1) => crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TName(crate::syntax::SName { sigils_p: Text::lit(""), path_p: Array::from(vec![v_p1.name_p.clone()]), span_p: v_p1.span_p.clone() }, Array::new())), span_p: v_p1.span_p.clone() },
        crate::syntax::RowTerm::RType(t_p2) => t_p2.clone(),
    }
}

/// ```prism
/// ResolveScopeRow: fn Env, Rw -> Rw
/// ```
pub fn resolve_scope_row_f(env_p0: &crate::check::expr::Env, rw_p1: &crate::check::types::Rw) -> crate::check::types::Rw {
    match &rw_p1.tail_p {
        crate::check::types::Tail::TlQ(v_p2) => crate::check::types::Rw { fams_p: rw_p1.fams_p.clone(), minus_p: rw_p1.minus_p.clone(), tail_p: env_p0.scope_p.tail_p.clone() },
        _ => rw_p1.clone(),
    }
}

/// ```prism
/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub fn pre_bind_stmt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, s_p2: &crate::syntax::Stmt) -> (crate::check::expr::Env, crate::check::types::St) {
    match &s_p2.kind_p {
        crate::syntax::StmtKind::SBind(p_p3, _, _) => pre_bind_pattern_f(env_p0, st_p1, p_p3),
        crate::syntax::StmtKind::SLet(_, _, _) => crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2),
        crate::syntax::StmtKind::SFn(_) => crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2),
        crate::syntax::StmtKind::SSignature(_) => crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2),
        crate::syntax::StmtKind::SWidget(w_p4) => {
            let (v_p5, st2_p6) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
            crate::check::expr::bind_local_id_f(&crate::check::expr::with_local_f(env_p0, &crate::check::env::sname_key_f(&w_p4.name_p), &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyAt(Rc::new(v_p5.clone()), env_p0.scope_p.clone()))), &st2_p6, &crate::check::env::sname_key_f(&w_p4.name_p), &w_p4.name_p.span_p)
        },
        _ => (env_p0.clone(), st_p1.clone()),
    }
}

/// The step machine of `PreBindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub struct PreBindStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub s_p2: crate::syntax::Stmt,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for PreBindStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let s_p2 = &self.s_p2;
        match &s_p2.kind_p {
            crate::syntax::StmtKind::SBind(p_p3, _, _) => prism_rtl::Turn::More(Rc::new(PreBindPattern { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p3.clone() })),
            crate::syntax::StmtKind::SLet(_, _, _) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::PreBind { env_p0: env_p0.clone(), st_p1: st_p1.clone(), s_p2: s_p2.clone() })),
            crate::syntax::StmtKind::SFn(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::PreBind { env_p0: env_p0.clone(), st_p1: st_p1.clone(), s_p2: s_p2.clone() })),
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::PreBind { env_p0: env_p0.clone(), st_p1: st_p1.clone(), s_p2: s_p2.clone() })),
            crate::syntax::StmtKind::SWidget(w_p4) => {
                let (v_p5, st2_p6) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
                prism_rtl::Turn::Finished(crate::check::expr::bind_local_id_f(&crate::check::expr::with_local_f(env_p0, &crate::check::env::sname_key_f(&w_p4.name_p), &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyAt(Rc::new(v_p5.clone()), env_p0.scope_p.clone()))), &st2_p6, &crate::check::env::sname_key_f(&w_p4.name_p), &w_p4.name_p.span_p))
            },
            _ => prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone())),
        }
    }
}

/// `Start PreBindStmt, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_stmt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, s_p2: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(PreBindStmt { env_p0, st_p1, s_p2 })
}

/// ```prism
/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
/// ```
pub fn pre_bind_pattern_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_) -> (crate::check::expr::Env, crate::check::types::St) {
    crate::prelude::fold(&crate::check::env::names::pattern_binders_f(p_p2), &(env_p0.clone(), st_p1.clone()), &(|(en_p3, s_p4): &(crate::check::expr::Env, crate::check::types::St), (name_p5, at_p6): &(Text, crate::syntax::Range)| {
        let (v_pa, s1_pb) = crate::check::types::fresh_var_f(s_p4, &true, name_p5);
        let s2_p7 = crate::check::types::recording::at_binder_f(&s1_pb, &v_pa, at_p6);
        let (rw_pc, s3_pd) = crate::check::types::recording::fresh_row_f(&s2_p7, &Array::new());
        let t_p8 = crate::check::types::with_marks_f(&crate::check::expr::lets::type_marks_f(&crate::check::types::unify::marks_of_f(name_p5)), &v_pa, &rw_pc);
        let en2_p9 = {
            let mut this: crate::check::expr::Env = crate::check::expr::with_local_f(en_p3, name_p5, &crate::check::types::schemes::mono_f(&t_p8));
            this.pending_p = crate::check::types::add_text_f(&this.pending_p, name_p5);
            this
        };
        crate::check::expr::bind_local_id_f(&en2_p9, &s3_pd, name_p5, at_p6)
    }))
}

/// The step machine of `PreBindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
/// ```
pub struct PreBindPattern {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for PreBindPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let env_p0x = env_p0.clone();
        let p_p2x = p_p2.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::env::names::start_pattern_binders_f(p_p2x.clone()), move |pattern_binders_f_9103: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(crate::prelude::fold(&pattern_binders_f_9103, &(env_p0x.clone(), st_p1x.clone()), &(|(en_p3, s_p4): &(crate::check::expr::Env, crate::check::types::St), (name_p5, at_p6): &(Text, crate::syntax::Range)| {
            let (v_pa, s1_pb) = crate::check::types::fresh_var_f(s_p4, &true, name_p5);
            let s2_p7 = crate::check::types::recording::at_binder_f(&s1_pb, &v_pa, at_p6);
            let (rw_pc, s3_pd) = crate::check::types::recording::fresh_row_f(&s2_p7, &Array::new());
            let t_p8 = crate::check::types::with_marks_f(&crate::check::expr::lets::type_marks_f(&crate::check::types::unify::marks_of_f(name_p5)), &v_pa, &rw_pc);
            let en2_p9 = {
                let mut this: crate::check::expr::Env = crate::check::expr::with_local_f(en_p3, name_p5, &crate::check::types::schemes::mono_f(&t_p8));
                this.pending_p = crate::check::types::add_text_f(&this.pending_p, name_p5);
                this
            };
            crate::check::expr::bind_local_id_f(&en2_p9, &s3_pd, name_p5, at_p6)
        }))))
    }
}

/// `Start PreBindPattern, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_pattern_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(PreBindPattern { env_p0, st_p1, p_p2 })
}

/// ```prism
/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
/// ```
pub fn widget_stmt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, s_p2: &crate::syntax::Stmt, last_p3: &bool) -> (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>) {
    match &s_p2.kind_p {
        crate::syntax::StmtKind::SEmit(_) => (env_p0.clone(), st_p1.clone(), if *last_p3 { Some(crate::check::types::t_unit_p()) } else { None }),
        crate::syntax::StmtKind::SBind(p_p4, e_p5, None) => {
            let st2_p6 = bind_stmt_f(env_p0, st_p1, p_p4, e_p5, &s_p2.span_p);
            (env_p0.clone(), st2_p6.clone(), if *last_p3 { Some(crate::check::types::t_unit_p()) } else { None })
        },
        crate::syntax::StmtKind::SBind(p_p7, init_p8, Some(step_p9)) => {
            let st2_pa = hold_stmt_f(env_p0, st_p1, p_p7, init_p8, step_p9, &s_p2.span_p);
            (env_p0.clone(), st2_pa.clone(), if *last_p3 { Some(crate::check::types::t_unit_p()) } else { None })
        },
        crate::syntax::StmtKind::SIgnore(e_pb) => {
            let st2_pc = ignore_stmt_f(env_p0, st_p1, e_pb, &s_p2.span_p);
            (env_p0.clone(), st2_pc.clone(), if *last_p3 { Some(crate::check::types::t_unit_p()) } else { None })
        },
        crate::syntax::StmtKind::SLet(p_pd, ty_oe, e_pf) => {
            let (env2_pg, st2_ph) = crate::check::expr::lets::check_let_f(env_p0, st_p1, p_pd, ty_oe, e_pf, &s_p2.span_p);
            (env2_pg.clone(), st2_ph.clone(), if *last_p3 { Some(crate::check::types::t_unit_p()) } else { None })
        },
        crate::syntax::StmtKind::SFn(f_pi) => {
            let (env2_pj, st2_pk) = crate::check::expr::lets::check_local_fn_f(env_p0, st_p1, f_pi, &s_p2.span_p);
            (env2_pj.clone(), st2_pk.clone(), if *last_p3 { Some(crate::check::types::t_unit_p()) } else { None })
        },
        crate::syntax::StmtKind::SSignature(_) => (env_p0.clone(), st_p1.clone(), if *last_p3 { Some(crate::check::types::t_unit_p()) } else { None }),
        crate::syntax::StmtKind::SWidget(w_pl) => {
            let (t_pn, st2_po) = infer_widget_block_f(env_p0, st_p1, &w_pl.body_p);
            let st3_pm = match crate::prelude::get(&env_p0.locals_p, &crate::check::env::sname_key_f(&w_pl.name_p)) {
                Some(sc_pp) => crate::check::types::unify::unify_f(&st2_po, &sc_pp.ty_p, &crate::check::types::Ty::TyAt(Rc::new(t_pn.clone()), env_p0.scope_p.clone()), &w_pl.span_p),
                None => st2_po.clone(),
            };
            (env_p0.clone(), st3_pm.clone(), if *last_p3 { Some(crate::check::types::t_unit_p()) } else { None })
        },
        crate::syntax::StmtKind::SExpr(e_pq) => {
            let (t_pr, st2_ps) = bare_line_f(env_p0, st_p1, e_pq, last_p3);
            if *last_p3 {
                (env_p0.clone(), st2_ps.clone(), Some(t_pr.clone()))
            } else {
                (env_p0.clone(), st2_ps.clone(), None)
            }
        },
        _ => (env_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), &s_p2.span_p, &Text::lit("this statement belongs in a `given:` or `update` block")), if *last_p3 { Some(crate::check::types::t_unit_p()) } else { None }),
    }
}

/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
/// ```
pub struct WidgetStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub s_p2: crate::syntax::Stmt,
    pub last_p3: bool,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)> for WidgetStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let s_p2 = &self.s_p2;
        let last_p3 = &self.last_p3;
        match &s_p2.kind_p {
            crate::syntax::StmtKind::SEmit(_) => prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone(), if *last_p3 { Some(crate::check::types::t_unit_p()) } else { None })),
            crate::syntax::StmtKind::SBind(p_p4, e_p5, None) => {
                let e_p5x = e_p5.clone();
                let env_p0x = env_p0.clone();
                let last_p3x = *last_p3;
                let p_p4x = p_p4.clone();
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_bind_stmt_f(env_p0x.clone(), st_p1x.clone(), p_p4x.clone(), e_p5x.clone(), s_p2x.span_p.clone()), move |bind_stmt_f_9746: crate::check::types::St| {
                    let st2_p6 = bind_stmt_f_9746;
                    prism_rtl::Turn::Finished((env_p0x.clone(), st2_p6.clone(), if last_p3x { Some(crate::check::types::t_unit_p()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SBind(p_p7, init_p8, Some(step_p9)) => {
                let env_p0x = env_p0.clone();
                let init_p8x = init_p8.clone();
                let last_p3x = *last_p3;
                let p_p7x = p_p7.clone();
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                let step_p9x = step_p9.clone();
                crate::prelude::call_then(start_hold_stmt_f(env_p0x.clone(), st_p1x.clone(), p_p7x.clone(), init_p8x.clone(), step_p9x.clone(), s_p2x.span_p.clone()), move |hold_stmt_f_9873: crate::check::types::St| {
                    let st2_pa = hold_stmt_f_9873;
                    prism_rtl::Turn::Finished((env_p0x.clone(), st2_pa.clone(), if last_p3x { Some(crate::check::types::t_unit_p()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SIgnore(e_pb) => {
                let e_pbx = e_pb.clone();
                let env_p0x = env_p0.clone();
                let last_p3x = *last_p3;
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_ignore_stmt_f(env_p0x.clone(), st_p1x.clone(), e_pbx.clone(), s_p2x.span_p.clone()), move |ignore_stmt_f_9995: crate::check::types::St| {
                    let st2_pc = ignore_stmt_f_9995;
                    prism_rtl::Turn::Finished((env_p0x.clone(), st2_pc.clone(), if last_p3x { Some(crate::check::types::t_unit_p()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SLet(p_pd, ty_oe, e_pf) => {
                let ty_oex = ty_oe.clone();
                let e_pfx = e_pf.clone();
                let env_p0x = env_p0.clone();
                let last_p3x = *last_p3;
                let p_pdx = p_pd.clone();
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lets::start_check_let_f(env_p0x.clone(), st_p1x.clone(), p_pdx.clone(), ty_oex.clone(), e_pfx.clone(), s_p2x.span_p.clone()), move |check_let_f_10122: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2_pg, st2_ph) = check_let_f_10122;
                    prism_rtl::Turn::Finished((env2_pg.clone(), st2_ph.clone(), if last_p3x { Some(crate::check::types::t_unit_p()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SFn(f_pi) => {
                let env_p0x = env_p0.clone();
                let f_pix = f_pi.clone();
                let last_p3x = *last_p3;
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lets::start_check_local_fn_f(env_p0x.clone(), st_p1x.clone(), f_pix.clone(), s_p2x.span_p.clone()), move |check_local_fn_f_10247: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2_pj, st2_pk) = check_local_fn_f_10247;
                    prism_rtl::Turn::Finished((env2_pj.clone(), st2_pk.clone(), if last_p3x { Some(crate::check::types::t_unit_p()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((env_p0.clone(), st_p1.clone(), if *last_p3 { Some(crate::check::types::t_unit_p()) } else { None })),
            crate::syntax::StmtKind::SWidget(w_pl) => {
                let env_p0x = env_p0.clone();
                let last_p3x = *last_p3;
                let st_p1x = st_p1.clone();
                let w_plx = w_pl.clone();
                crate::prelude::call_then(start_infer_widget_block_f(env_p0x.clone(), st_p1x.clone(), w_plx.body_p.clone()), move |infer_widget_block_f_10432: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pn, st2_po) = infer_widget_block_f_10432;
                    let st3_pm = match crate::prelude::get(&env_p0x.locals_p, &crate::check::env::sname_key_f(&w_plx.name_p)) {
                        Some(sc_pp) => crate::check::types::unify::unify_f(&st2_po, &sc_pp.ty_p, &crate::check::types::Ty::TyAt(Rc::new(t_pn.clone()), env_p0x.scope_p.clone()), &w_plx.span_p),
                        None => st2_po.clone(),
                    };
                    prism_rtl::Turn::Finished((env_p0x.clone(), st3_pm.clone(), if last_p3x { Some(crate::check::types::t_unit_p()) } else { None }))
                })
            },
            crate::syntax::StmtKind::SExpr(e_pq) => {
                let e_pqx = e_pq.clone();
                let env_p0x = env_p0.clone();
                let last_p3x = *last_p3;
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_bare_line_f(env_p0x.clone(), st_p1x.clone(), e_pqx.clone(), last_p3x), move |bare_line_f_10690: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pr, st2_ps) = bare_line_f_10690;
                    if last_p3x {
                        prism_rtl::Turn::Finished((env_p0x.clone(), st2_ps.clone(), Some(t_pr.clone())))
                    } else {
                        prism_rtl::Turn::Finished((env_p0x.clone(), st2_ps.clone(), None))
                    }
                })
            },
            _ => prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), &s_p2.span_p, &Text::lit("this statement belongs in a `given:` or `update` block")), if *last_p3 { Some(crate::check::types::t_unit_p()) } else { None })),
        }
    }
}

/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
pub fn start_widget_stmt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, s_p2: crate::syntax::Stmt, last_p3: bool) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>> {
    Rc::new(WidgetStmt { env_p0, st_p1, s_p2, last_p3 })
}

/// ```prism
/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
/// ```
pub fn bind_stmt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, e_p3: &crate::syntax::Expr, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    let (t_p5, st1_p6) = crate::check::expr::infer_f(env_p0, st_p1, e_p3);
    let (out_p7, st2_p8) = if is_builder_f(e_p3) {
        (t_p5.clone(), st1_p6.clone())
    } else {
        bind_output_f(env_p0, &st1_p6, &t_p5, &e_p3.span_p)
    };
    let (_, st3_p9) = crate::check::expr::patterns::bind_pattern_f(env_p0, &st2_p8, p_p2, &out_p7, &false);
    st3_p9.clone()
}

/// The step machine of `BindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
/// ```
pub struct BindStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub e_p3: crate::syntax::Expr,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for BindStmt {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let e_p3 = &self.e_p3;
        let span_p4 = &self.span_p4;
        let e_p3x = e_p3.clone();
        let env_p0x = env_p0.clone();
        let p_p2x = p_p2.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_p3x.clone()), move |infer_f_11305: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p5, st1_p6) = infer_f_11305;
            let (out_p7, st2_p8) = if is_builder_f(&e_p3x) {
                (t_p5.clone(), st1_p6.clone())
            } else {
                bind_output_f(&env_p0x, &st1_p6, &t_p5, &e_p3x.span_p)
            };
            crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p0x.clone(), st2_p8.clone(), p_p2x.clone(), out_p7.clone(), false), move |bind_pattern_f_11435: (crate::check::expr::Env, crate::check::types::St)| {
                let (_, st3_p9) = bind_pattern_f_11435;
                prism_rtl::Turn::Finished(st3_p9.clone())
            })
        })
    }
}

/// `Start BindStmt, x`: what the function value is when passed to `@Run`.
pub fn start_bind_stmt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, e_p3: crate::syntax::Expr, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(BindStmt { env_p0, st_p1, p_p2, e_p3, span_p4 })
}

/// ```prism
/// IsBuilder: fn Expr -> Bool
/// ```
pub fn is_builder_f(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ERebuild(_, _) => true,
        crate::syntax::ExprKind::EFor(_, _, _) => true,
        crate::syntax::ExprKind::EGroup(x_p1) => is_builder_f(&**x_p1),
        _ => false,
    }
}

/// ```prism
/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
/// ```
pub fn bind_output_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, t_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::check::types::recording::walk_f(st_p1, t_p2) {
        crate::check::types::Ty::TyAt(inner_p4, rw_p5) => ((*inner_p4).clone(), add_incl_f(st_p1, &rw_p5, &env_p0.scope_p, span_p3, &Text::lit("child"))),
        crate::check::types::Ty::TyElem(rw_p6, o_p7) => ((*o_p7).clone(), add_incl_f(st_p1, &rw_p6, &env_p0.scope_p, span_p3, &Text::lit("element"))),
        crate::check::types::Ty::TySig(s_p8, inner_p9) => match crate::check::types::recording::walk_f(st_p1, &*inner_p9) {
            crate::check::types::Ty::TyAt(_, _) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(st_p1, &Text::lit("bind-dynamic"), span_p3, &Text::from(format!("binding a `{}`; say what happens to the old widgets with `rebuild`", &crate::check::types::show_ty_f(st_p1, t_p2))), &Text::lit("write `rebuild` over the dynamic, with the blueprint inside"))),
            crate::check::types::Ty::TyElem(_, _) => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(st_p1, &Text::lit("bind-dynamic"), span_p3, &Text::from(format!("binding a `{}`, a {} of elements; say what happens to the old element with `rebuild`", &crate::check::types::show_ty_f(st_p1, t_p2), &(if &s_p8 == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }))), &Text::lit("write `rebuild` over the dynamic field\'s value, with the element inside"))),
            _ => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), span_p3, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &crate::check::types::show_ty_f(st_p1, t_p2))))),
        },
        crate::check::types::Ty::TyFlex(_) => {
            let (v_pa, st2_pb) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
            (v_pa.clone(), crate::check::types::unify::unify_f(&st2_pb, t_p2, &crate::check::types::Ty::TyAt(Rc::new(v_pa.clone()), env_p0.scope_p.clone()), span_p3))
        },
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st_p1.clone()),
        other_pc => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), span_p3, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &crate::check::types::show_ty_f(st_p1, &other_pc))))),
    }
}

/// The step machine of `BindOutput`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
/// ```
pub struct BindOutput {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub t_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BindOutput {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let t_p2 = &self.t_p2;
        let span_p3 = &self.span_p3;
        let env_p0x = env_p0.clone();
        let span_p3x = span_p3.clone();
        let st_p1x = st_p1.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), t_p2x.clone()), move |walk_f_11830: crate::check::types::Ty| match walk_f_11830 {
            crate::check::types::Ty::TyAt(inner_p4, rw_p5) => prism_rtl::Turn::Finished(((*inner_p4).clone(), add_incl_f(&st_p1x, &rw_p5, &env_p0x.scope_p, &span_p3x, &Text::lit("child")))),
            crate::check::types::Ty::TyElem(rw_p6, o_p7) => prism_rtl::Turn::Finished(((*o_p7).clone(), add_incl_f(&st_p1x, &rw_p6, &env_p0x.scope_p, &span_p3x, &Text::lit("element")))),
            crate::check::types::Ty::TySig(s_p8, inner_p9) => crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x.clone(), (*inner_p9).clone()), move |walk_f_12020: crate::check::types::Ty| match walk_f_12020 {
                crate::check::types::Ty::TyAt(_, _) => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p2x.clone()), move |show_ty_f_12125: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(&st_p1x, &Text::lit("bind-dynamic"), &span_p3x, &Text::from(format!("binding a `{}`; say what happens to the old widgets with `rebuild`", &show_ty_f_12125)), &Text::lit("write `rebuild` over the dynamic, with the blueprint inside"))))),
                crate::check::types::Ty::TyElem(_, _) => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p2x.clone()), move |show_ty_f_12350: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(&st_p1x, &Text::lit("bind-dynamic"), &span_p3x, &Text::from(format!("binding a `{}`, a {} of elements; say what happens to the old element with `rebuild`", &show_ty_f_12350, &(if &s_p8 == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }))), &Text::lit("write `rebuild` over the dynamic field\'s value, with the element inside"))))),
                _ => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), t_p2x.clone()), move |show_ty_f_12658: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p1x, &Text::lit("mismatch"), &span_p3x, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &show_ty_f_12658)))))),
            }),
            crate::check::types::Ty::TyFlex(_) => {
                let (v_pa, st2_pb) = crate::check::types::fresh_var_f(&st_p1x, &false, &Text::lit(""));
                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pb.clone(), t_p2x.clone(), crate::check::types::Ty::TyAt(Rc::new(v_pa.clone()), env_p0x.scope_p.clone()), span_p3x.clone()), move |unify_f_12758: crate::check::types::St| prism_rtl::Turn::Finished((v_pa.clone(), unify_f_12758)))
            },
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, st_p1x.clone())),
            other_pc => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), other_pc.clone()), move |show_ty_f_12922: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p1x, &Text::lit("mismatch"), &span_p3x, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &show_ty_f_12922)))))),
        })
    }
}

/// `Start BindOutput, x`: what the function value is when passed to `@Run`.
pub fn start_bind_output_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, t_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BindOutput { env_p0, st_p1, t_p2, span_p3 })
}

/// ```prism
/// AddIncl: fn St, Rw, Rw, Range, Text -> St
/// ```
pub fn add_incl_f(st_p0: &crate::check::types::St, sub_p1: &crate::check::types::Rw, sup_p2: &crate::check::types::Rw, span_p3: &crate::syntax::Range, what_p4: &Text) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.incls_p = crate::prelude::push(&this.incls_p, &crate::check::types::Incl { sub_p: sub_p1.clone(), sup_p: sup_p2.clone(), file_p: this.file_p.clone(), span_p: span_p3.clone(), what_p: what_p4.clone(), forward_p: false });
    this
}

/// ```prism
/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
/// ```
pub fn hold_stmt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern_, init_p3: &crate::syntax::Expr, step_p4: &crate::syntax::Expr, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    let (v_p8, st1_p9) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
    let held_p6 = crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_p8.clone()));
    let (_, st2_pa) = crate::check::expr::patterns::bind_pattern_f(env_p0, &st1_p9, p_p2, &held_p6, &false);
    let st3_p7 = crate::check::expr::check_f(env_p0, &st2_pa, init_p3, &v_p8);
    let (step_ty_pb, st4_pc) = crate::check::expr::infer_f(env_p0, &st3_p7, step_p4);
    if (&crate::check::types::head_sigil_f(&st4_pc, &step_ty_pb) == &Text::lit("!")) || (&step_ty_pb == &crate::check::types::Ty::TyErr) {
        crate::check::types::unify::unify_f(&st4_pc, &crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_p8.clone())), &step_ty_pb, &step_p4.span_p)
    } else {
        crate::check::types::recording::err_fix_f(&st4_pc, &Text::lit("mismatch"), &step_p4.span_p, &Text::from(format!("a hold\'s step is an event; this is `{}`", &crate::check::types::show_ty_f(&st4_pc, &step_ty_pb))), &Text::lit("fire it with an event: `... on !e`"))
    }
}

/// The step machine of `HoldStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
/// ```
pub struct HoldStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern_,
    pub init_p3: crate::syntax::Expr,
    pub step_p4: crate::syntax::Expr,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for HoldStmt {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let init_p3 = &self.init_p3;
        let step_p4 = &self.step_p4;
        let span_p5 = &self.span_p5;
        let (v_p8, st1_p9) = crate::check::types::fresh_var_f(st_p1, &false, &Text::lit(""));
        let held_p6 = crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_p8.clone()));
        let env_p0x = env_p0.clone();
        let init_p3x = init_p3.clone();
        let p_p2x = p_p2.clone();
        let span_p5x = span_p5.clone();
        let step_p4x = step_p4.clone();
        crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p0x.clone(), st1_p9.clone(), p_p2x.clone(), held_p6.clone(), false), move |bind_pattern_f_13465: (crate::check::expr::Env, crate::check::types::St)| {
            let (_, st2_pa) = bind_pattern_f_13465;
            crate::prelude::call_then(crate::check::expr::start_check_f(env_p0x.clone(), st2_pa.clone(), init_p3x.clone(), v_p8.clone()), move |check_f_13516: crate::check::types::St| {
                let st3_p7 = check_f_13516;
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st3_p7.clone(), step_p4x.clone()), move |infer_f_13566: (crate::check::types::Ty, crate::check::types::St)| {
                    let (step_ty_pb, st4_pc) = infer_f_13566;
                    crate::prelude::call_then(crate::check::types::start_head_sigil_f(st4_pc.clone(), step_ty_pb.clone()), move |head_sigil_f_13595: Text| if (&head_sigil_f_13595 == &Text::lit("!")) || (&step_ty_pb == &crate::check::types::Ty::TyErr) {
                        prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st4_pc.clone(), expected_p1: crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(v_p8.clone())), found_p2: step_ty_pb.clone(), span_p3: step_p4x.span_p.clone() }))
                    } else {
                        crate::prelude::call_then(crate::check::types::start_show_ty_f(st4_pc.clone(), step_ty_pb.clone()), move |show_ty_f_13773: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st4_pc, &Text::lit("mismatch"), &step_p4x.span_p, &Text::from(format!("a hold\'s step is an event; this is `{}`", &show_ty_f_13773)), &Text::lit("fire it with an event: `... on !e`"))))
                    })
                })
            })
        })
    }
}

/// `Start HoldStmt, x`: what the function value is when passed to `@Run`.
pub fn start_hold_stmt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern_, init_p3: crate::syntax::Expr, step_p4: crate::syntax::Expr, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(HoldStmt { env_p0, st_p1, p_p2, init_p3, step_p4, span_p5 })
}

/// ```prism
/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
/// ```
pub fn ignore_stmt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    let (t_p4, st1_p5) = crate::check::expr::infer_f(env_p0, st_p1, e_p2);
    match crate::check::types::recording::walk_f(&st1_p5, &t_p4) {
        crate::check::types::Ty::TyAt(_, _) => {
            let (_, st2_p6) = bind_output_f(env_p0, &st1_p5, &t_p4, &e_p2.span_p);
            st2_p6.clone()
        },
        crate::check::types::Ty::TyElem(_, _) => {
            let (_, st2_p7) = bind_output_f(env_p0, &st1_p5, &t_p4, &e_p2.span_p);
            st2_p7.clone()
        },
        crate::check::types::Ty::TySig(_, inner_p8) => match crate::check::types::recording::walk_f(&st1_p5, &*inner_p8) {
            crate::check::types::Ty::TyAt(_, _) => {
                let (_, st2_p9) = bind_output_f(env_p0, &st1_p5, &t_p4, &e_p2.span_p);
                st2_p9.clone()
            },
            crate::check::types::Ty::TyElem(_, _) => {
                let (_, st2_pa) = bind_output_f(env_p0, &st1_p5, &t_p4, &e_p2.span_p);
                st2_pa.clone()
            },
            _ => st1_p5.clone(),
        },
        _ => st1_p5.clone(),
    }
}

/// The step machine of `IgnoreStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
/// ```
pub struct IgnoreStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for IgnoreStmt {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let span_p3 = &self.span_p3;
        let e_p2x = e_p2.clone();
        let env_p0x = env_p0.clone();
        let span_p3x = span_p3.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone()), move |infer_f_14006: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p4, st1_p5) = infer_f_14006;
            crate::prelude::call_then(crate::check::types::recording::start_walk_f(st1_p5.clone(), t_p4.clone()), move |walk_f_14033: crate::check::types::Ty| match walk_f_14033 {
                crate::check::types::Ty::TyAt(_, _) => crate::prelude::call_then(start_bind_output_f(env_p0x.clone(), st1_p5.clone(), t_p4.clone(), e_p2x.span_p.clone()), move |bind_output_f_14109: (crate::check::types::Ty, crate::check::types::St)| {
                    let (_, st2_p6) = bind_output_f_14109;
                    prism_rtl::Turn::Finished(st2_p6.clone())
                }),
                crate::check::types::Ty::TyElem(_, _) => crate::prelude::call_then(start_bind_output_f(env_p0x.clone(), st1_p5.clone(), t_p4.clone(), e_p2x.span_p.clone()), move |bind_output_f_14221: (crate::check::types::Ty, crate::check::types::St)| {
                    let (_, st2_p7) = bind_output_f_14221;
                    prism_rtl::Turn::Finished(st2_p7.clone())
                }),
                crate::check::types::Ty::TySig(_, inner_p8) => crate::prelude::call_then(crate::check::types::recording::start_walk_f(st1_p5.clone(), (*inner_p8).clone()), move |walk_f_14303: crate::check::types::Ty| match walk_f_14303 {
                    crate::check::types::Ty::TyAt(_, _) => crate::prelude::call_then(start_bind_output_f(env_p0x.clone(), st1_p5.clone(), t_p4.clone(), e_p2x.span_p.clone()), move |bind_output_f_14391: (crate::check::types::Ty, crate::check::types::St)| {
                        let (_, st2_p9) = bind_output_f_14391;
                        prism_rtl::Turn::Finished(st2_p9.clone())
                    }),
                    crate::check::types::Ty::TyElem(_, _) => crate::prelude::call_then(start_bind_output_f(env_p0x.clone(), st1_p5.clone(), t_p4.clone(), e_p2x.span_p.clone()), move |bind_output_f_14515: (crate::check::types::Ty, crate::check::types::St)| {
                        let (_, st2_pa) = bind_output_f_14515;
                        prism_rtl::Turn::Finished(st2_pa.clone())
                    }),
                    _ => prism_rtl::Turn::Finished(st1_p5.clone()),
                }),
                _ => prism_rtl::Turn::Finished(st1_p5.clone()),
            })
        })
    }
}

/// `Start IgnoreStmt, x`: what the function value is when passed to `@Run`.
pub fn start_ignore_stmt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(IgnoreStmt { env_p0, st_p1, e_p2, span_p3 })
}

/// ```prism
/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub fn bare_line_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, last_p3: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p5, st2_p6) = bare_line_kind_f(env_p0, st_p1, e_p2, last_p3);
    let shown_p4 = match &*e_p2.kind_p {
        crate::syntax::ExprKind::EFreeSigil(m14974_0_0, _) if (m14974_0_0 == &Text::lit("@")) => crate::check::types::Ty::TyAt(Rc::new(t_p5.clone()), env_p0.scope_p.clone()),
        crate::syntax::ExprKind::EMatch(_, _) => crate::check::types::Ty::TyAt(Rc::new(t_p5.clone()), env_p0.scope_p.clone()),
        crate::syntax::ExprKind::EIf(_, _, _) => crate::check::types::Ty::TyAt(Rc::new(t_p5.clone()), env_p0.scope_p.clone()),
        _ => t_p5.clone(),
        _ => unreachable!("no arm matched"),
    };
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EFreeSigil(m15166_0_0, _) if (m15166_0_0 == &Text::lit("@")) => (t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &e_p2.span_p, &shown_p4)),
        crate::syntax::ExprKind::EMatch(_, _) => (t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &e_p2.span_p, &shown_p4)),
        crate::syntax::ExprKind::EIf(_, _, _) => (t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &e_p2.span_p, &shown_p4)),
        crate::syntax::ExprKind::EGroup(_) => (t_p5.clone(), note_as_last_f(&st2_p6, &e_p2.span_p)),
        _ => (t_p5.clone(), st2_p6.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BareLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub struct BareLine {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub last_p3: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BareLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let last_p3 = &self.last_p3;
        let e_p2x = e_p2.clone();
        let env_p0x = env_p0.clone();
        let last_p3x = *last_p3;
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_bare_line_kind_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone(), last_p3x), move |bare_line_kind_f_14928: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p5, st2_p6) = bare_line_kind_f_14928;
            let shown_p4 = match &*e_p2x.kind_p {
                crate::syntax::ExprKind::EFreeSigil(m14974_0_0, _) if (m14974_0_0 == &Text::lit("@")) => crate::check::types::Ty::TyAt(Rc::new(t_p5.clone()), env_p0x.scope_p.clone()),
                crate::syntax::ExprKind::EMatch(_, _) => crate::check::types::Ty::TyAt(Rc::new(t_p5.clone()), env_p0x.scope_p.clone()),
                crate::syntax::ExprKind::EIf(_, _, _) => crate::check::types::Ty::TyAt(Rc::new(t_p5.clone()), env_p0x.scope_p.clone()),
                _ => t_p5.clone(),
                _ => unreachable!("no arm matched"),
            };
            match &*e_p2x.kind_p {
                crate::syntax::ExprKind::EFreeSigil(m15166_0_0, _) if (m15166_0_0 == &Text::lit("@")) => prism_rtl::Turn::Finished((t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &e_p2x.span_p, &shown_p4))),
                crate::syntax::ExprKind::EMatch(_, _) => prism_rtl::Turn::Finished((t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &e_p2x.span_p, &shown_p4))),
                crate::syntax::ExprKind::EIf(_, _, _) => prism_rtl::Turn::Finished((t_p5.clone(), crate::check::types::recording::note_ty_f(&st2_p6, &e_p2x.span_p, &shown_p4))),
                crate::syntax::ExprKind::EGroup(_) => prism_rtl::Turn::Finished((t_p5.clone(), note_as_last_f(&st2_p6, &e_p2x.span_p))),
                _ => prism_rtl::Turn::Finished((t_p5.clone(), st2_p6.clone())),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start BareLine, x`: what the function value is when passed to `@Run`.
pub fn start_bare_line_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, last_p3: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BareLine { env_p0, st_p1, e_p2, last_p3 })
}

/// ```prism
/// NoteAsLast: fn St, Range -> St
/// ```
pub fn note_as_last_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range) -> crate::check::types::St {
    match crate::syntax::lexer::chars::last_o(&st_p0.typed_p.exprs_p) {
        Some(n_p2) => crate::check::types::recording::note_ty_f(st_p0, span_p1, &n_p2.ty_p),
        None => st_p0.clone(),
    }
}

/// ```prism
/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub fn bare_line_kind_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, last_p3: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EMatch(scrut_p4, arms_p5) => building_match_f(env_p0, st_p1, &**scrut_p4, arms_p5, &e_p2.span_p, last_p3),
        crate::syntax::ExprKind::EIf(c_p6, then_b_p7, else_b_o8) => building_if_f(env_p0, st_p1, &**c_p6, then_b_p7, else_b_o8, &e_p2.span_p, last_p3),
        crate::syntax::ExprKind::EFreeSigil(m15748_2_0, x_p9) if (m15748_2_0 == &Text::lit("@")) => {
            let (t_pa, st2_pb) = crate::check::expr::infer_f(env_p0, st_p1, &**x_p9);
            if *last_p3 {
                (t_pa.clone(), st2_pb.clone())
            } else {
                (t_pa.clone(), discarded_f(&st2_pb, &t_pa, &e_p2.span_p))
            }
        },
        crate::syntax::ExprKind::EGroup(x_pc) => bare_line_f(env_p0, st_p1, &**x_pc, last_p3),
        _ => {
            let (t_pd, st1_pe) = crate::check::expr::infer_f(env_p0, st_p1, e_p2);
            let (res_pg, st2_ph) = match crate::check::types::recording::walk_f(&st1_pe, &t_pd) {
                crate::check::types::Ty::TyAt(_, _) => bind_output_f(env_p0, &st1_pe, &t_pd, &e_p2.span_p),
                crate::check::types::Ty::TyElem(_, _) => bind_output_f(env_p0, &st1_pe, &t_pd, &e_p2.span_p),
                crate::check::types::Ty::TyErr => (crate::check::types::t_unit_p(), st1_pe.clone()),
                other_pf => if is_builder_f(e_p2) {
                    (other_pf.clone(), st1_pe.clone())
                } else {
                    if &crate::check::types::recording::walk_f(&st1_pe, &other_pf) == &crate::check::types::t_unit_p() {
                        (crate::check::types::t_unit_p(), st1_pe.clone())
                    } else {
                        (other_pf.clone(), crate::check::types::recording::err_fix_f(&st1_pe, &Text::lit("mismatch"), &e_p2.span_p, &Text::from(format!("a bare line emits an element or builds a blueprint; this is `{}`", &crate::check::types::show_ty_f(&st1_pe, &other_pf))), &Text::from(format!("end the block on a value with `@ {}`", &crate::check::expr::src_text_f(env_p0, &e_p2.span_p)))))
                    }
                },
            };
            if *last_p3 {
                (res_pg.clone(), st2_ph.clone())
            } else {
                (res_pg.clone(), discarded_f(&st2_ph, &res_pg, &e_p2.span_p))
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BareLineKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub struct BareLineKind {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub last_p3: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BareLineKind {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let last_p3 = &self.last_p3;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EMatch(scrut_p4, arms_p5) => prism_rtl::Turn::More(Rc::new(BuildingMatch { env_p0: env_p0.clone(), st_p1: st_p1.clone(), scrut_p2: (**scrut_p4).clone(), arms_p3: arms_p5.clone(), span_p4: e_p2.span_p.clone(), last_p5: *last_p3 })),
            crate::syntax::ExprKind::EIf(c_p6, then_b_p7, else_b_o8) => prism_rtl::Turn::More(Rc::new(BuildingIf { env_p0: env_p0.clone(), st_p1: st_p1.clone(), c_p2: (**c_p6).clone(), then_b_p3: then_b_p7.clone(), else_b_o4: else_b_o8.clone(), span_p5: e_p2.span_p.clone(), last_p6: *last_p3 })),
            crate::syntax::ExprKind::EFreeSigil(m15748_2_0, x_p9) if (m15748_2_0 == &Text::lit("@")) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let last_p3x = *last_p3;
                let st_p1x = st_p1.clone();
                let x_p9x = (**x_p9).clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), x_p9x.clone()), move |infer_f_15960: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pa, st2_pb) = infer_f_15960;
                    if last_p3x {
                        prism_rtl::Turn::Finished((t_pa.clone(), st2_pb.clone()))
                    } else {
                        crate::prelude::call_then(start_discarded_f(st2_pb.clone(), t_pa.clone(), e_p2x.span_p.clone()), move |discarded_f_16017: crate::check::types::St| prism_rtl::Turn::Finished((t_pa.clone(), discarded_f_16017)))
                    }
                })
            },
            crate::syntax::ExprKind::EGroup(x_pc) => prism_rtl::Turn::More(Rc::new(BareLine { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: (**x_pc).clone(), last_p3: *last_p3 })),
            _ => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let last_p3x = *last_p3;
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_p2x.clone()), move |infer_f_16125: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pd, st1_pe) = infer_f_16125;
                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(st1_pe.clone(), t_pd.clone()), move |walk_f_16175: crate::check::types::Ty| {
                        let (res_pg, st2_ph) = match walk_f_16175 {
                            crate::check::types::Ty::TyAt(_, _) => bind_output_f(&env_p0x, &st1_pe, &t_pd, &e_p2x.span_p),
                            crate::check::types::Ty::TyElem(_, _) => bind_output_f(&env_p0x, &st1_pe, &t_pd, &e_p2x.span_p),
                            crate::check::types::Ty::TyErr => (crate::check::types::t_unit_p(), st1_pe.clone()),
                            other_pf => if is_builder_f(&e_p2x) {
                                (other_pf.clone(), st1_pe.clone())
                            } else {
                                if &crate::check::types::recording::walk_f(&st1_pe, &other_pf) == &crate::check::types::t_unit_p() {
                                    (crate::check::types::t_unit_p(), st1_pe.clone())
                                } else {
                                    (other_pf.clone(), crate::check::types::recording::err_fix_f(&st1_pe, &Text::lit("mismatch"), &e_p2x.span_p, &Text::from(format!("a bare line emits an element or builds a blueprint; this is `{}`", &crate::check::types::show_ty_f(&st1_pe, &other_pf))), &Text::from(format!("end the block on a value with `@ {}`", &crate::check::expr::src_text_f(&env_p0x, &e_p2x.span_p)))))
                                }
                            },
                        };
                        if last_p3x {
                            prism_rtl::Turn::Finished((res_pg.clone(), st2_ph.clone()))
                        } else {
                            crate::prelude::call_then(start_discarded_f(st2_ph.clone(), res_pg.clone(), e_p2x.span_p.clone()), move |discarded_f_16740: crate::check::types::St| prism_rtl::Turn::Finished((res_pg.clone(), discarded_f_16740)))
                        }
                    })
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start BareLineKind, x`: what the function value is when passed to `@Run`.
pub fn start_bare_line_kind_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, last_p3: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BareLineKind { env_p0, st_p1, e_p2, last_p3 })
}

/// ```prism
/// Discarded: unbounded fn St, Ty, Range -> St
/// ```
pub fn discarded_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, span_p2: &crate::syntax::Range) -> crate::check::types::St {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TyCon(m16904_0_0, m16904_0_1) if (&m16904_0_0 == &Text::lit("unit")) && ((&m16904_0_1).len() == 0) => st_p0.clone(),
        crate::check::types::Ty::TyErr => st_p0.clone(),
        crate::check::types::Ty::TyFlex(_) => crate::check::types::unify::unify_f(st_p0, &crate::check::types::t_unit_p(), t_p1, span_p2),
        other_p3 => crate::check::types::recording::err_fix_f(st_p0, &Text::lit("discarded"), span_p2, &Text::from(format!("this line\'s result is `{}`; drop it with `ignore <-`", &crate::check::types::show_ty_f(st_p0, &other_p3))), &Text::lit("write `ignore <-` in front of it, or bind it")),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Discarded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Discarded: unbounded fn St, Ty, Range -> St
/// ```
pub struct Discarded {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub span_p2: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for Discarded {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let span_p2 = &self.span_p2;
        let span_p2x = span_p2.clone();
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_16910: crate::check::types::Ty| match walk_f_16910 {
            crate::check::types::Ty::TyCon(m16904_0_0, m16904_0_1) if (&m16904_0_0 == &Text::lit("unit")) && ((&m16904_0_1).len() == 0) => prism_rtl::Turn::Finished(st_p0x.clone()),
            crate::check::types::Ty::TyErr => prism_rtl::Turn::Finished(st_p0x.clone()),
            crate::check::types::Ty::TyFlex(_) => prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: st_p0x.clone(), expected_p1: crate::check::types::t_unit_p(), found_p2: t_p1x.clone(), span_p3: span_p2x.clone() })),
            other_p3 => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p0x.clone(), other_p3.clone()), move |show_ty_f_17073: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p0x, &Text::lit("discarded"), &span_p2x, &Text::from(format!("this line\'s result is `{}`; drop it with `ignore <-`", &show_ty_f_17073)), &Text::lit("write `ignore <-` in front of it, or bind it")))),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start Discarded, x`: what the function value is when passed to `@Run`.
pub fn start_discarded_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty, span_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Discarded { st_p0, t_p1, span_p2 })
}

/// ```prism
/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
/// ```
pub fn building_match_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, scrut_p2: &crate::syntax::Expr, arms_p3: &Array<crate::syntax::Arm>, span_p4: &crate::syntax::Range, last_p5: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    let (st_ty_pb, st1_pc) = crate::check::expr::infer_f(env_p0, st_p1, scrut_p2);
    let sh_p6 = crate::check::types::head_sigil_f(&st1_pc, &st_ty_pb);
    let st2_p7 = if crate::check::expr::is_time_sigil_f(&sh_p6) {
        crate::check::types::recording::err_fix_f(&st1_pc, &Text::lit("building-match"), &scrut_p2.span_p, &Text::from(format!("a blueprint in a match over a {}; use `rebuild`", &(if &sh_p6 == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }))), &Text::from(format!("write `rebuild {}:` with `match _:` inside", &crate::check::expr::src_text_f(env_p0, &scrut_p2.span_p))))
    } else {
        st1_pc.clone()
    };
    let plain_scrut_p8 = if crate::check::expr::is_time_sigil_f(&sh_p6) {
        crate::check::expr::inner_of_f(&st2_p7, &st_ty_pb)
    } else {
        st_ty_pb.clone()
    };
    let (res_pd, st3_pe) = crate::check::types::fresh_var_f(&st2_p7, &false, &Text::lit(""));
    let st4_p9 = crate::prelude::run_to_end(crate::prelude::fold_job(arms_p3.clone(), st3_pe.clone(), {
        let env_p0x = env_p0.clone();
        let plain_scrut_p8x = plain_scrut_p8.clone();
        let res_pdx = res_pd.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
            let env_p0xy = env_p0x.clone();
            let plain_scrut_p8xy = plain_scrut_p8x.clone();
            let res_pdxy = res_pdx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_pf = p0;
                let arm_pg = p1;
                {
                    let (env2_pj, s1_pk) = match &arm_pg.pattern_o {
                        Some(p_pi) => crate::check::expr::patterns::bind_pattern_f(&env_p0xy, &s_pf, p_pi, &plain_scrut_p8xy, &true),
                        None => (env_p0xy.clone(), s_pf.clone()),
                    };
                    let s2_ph = match &arm_pg.guard_o {
                        Some(gd_pl) => crate::check::expr::lifting::check_cond_f(&env2_pj, &s1_pk, gd_pl),
                        None => s1_pk.clone(),
                    };
                    let (bt_pm, s3_pn) = arm_widget_block_f(&env2_pj, &s2_ph, &arm_pg.body_p);
                    prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: s3_pn.clone(), expected_p1: res_pdxy.clone(), found_p2: bt_pm.clone(), span_p3: arm_pg.body_p.span_p.clone() }))
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    let st5_pa = crate::check::passes::match_coverage_f(env_p0, &st4_p9, &plain_scrut_p8, arms_p3, span_p4);
    if *last_p5 {
        (res_pd.clone(), st5_pa.clone())
    } else {
        (res_pd.clone(), discarded_f(&st5_pa, &res_pd, span_p4))
    }
}

/// The step machine of `BuildingMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
/// ```
pub struct BuildingMatch {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub scrut_p2: crate::syntax::Expr,
    pub arms_p3: Array<crate::syntax::Arm>,
    pub span_p4: crate::syntax::Range,
    pub last_p5: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BuildingMatch {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let scrut_p2 = &self.scrut_p2;
        let arms_p3 = &self.arms_p3;
        let span_p4 = &self.span_p4;
        let last_p5 = &self.last_p5;
        let arms_p3x = arms_p3.clone();
        let env_p0x = env_p0.clone();
        let last_p5x = *last_p5;
        let scrut_p2x = scrut_p2.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), scrut_p2x.clone()), move |infer_f_17477: (crate::check::types::Ty, crate::check::types::St)| {
            let (st_ty_pb, st1_pc) = infer_f_17477;
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pc.clone(), st_ty_pb.clone()), move |head_sigil_f_17511: Text| {
                let sh_p6 = head_sigil_f_17511;
                let st2_p7 = if crate::check::expr::is_time_sigil_f(&sh_p6) {
                    crate::check::types::recording::err_fix_f(&st1_pc, &Text::lit("building-match"), &scrut_p2x.span_p, &Text::from(format!("a blueprint in a match over a {}; use `rebuild`", &(if &sh_p6 == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }))), &Text::from(format!("write `rebuild {}:` with `match _:` inside", &crate::check::expr::src_text_f(&env_p0x, &scrut_p2x.span_p))))
                } else {
                    st1_pc.clone()
                };
                let plain_scrut_p8 = if crate::check::expr::is_time_sigil_f(&sh_p6) {
                    crate::check::expr::inner_of_f(&st2_p7, &st_ty_pb)
                } else {
                    st_ty_pb.clone()
                };
                let (res_pd, st3_pe) = crate::check::types::fresh_var_f(&st2_p7, &false, &Text::lit(""));
                crate::prelude::call_value(crate::prelude::fold_job(arms_p3x.clone(), st3_pe.clone(), {
                    let env_p0xx = env_p0x.clone();
                    let plain_scrut_p8x = plain_scrut_p8.clone();
                    let res_pdx = res_pd.clone();
                    Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                        let env_p0xxy = env_p0xx.clone();
                        let plain_scrut_p8xy = plain_scrut_p8x.clone();
                        let res_pdxy = res_pdx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let s_pf = p0;
                            let arm_pg = p1;
                            {
                                let (env2_pj, s1_pk) = match &arm_pg.pattern_o {
                                    Some(p_pi) => crate::check::expr::patterns::bind_pattern_f(&env_p0xxy, &s_pf, p_pi, &plain_scrut_p8xy, &true),
                                    None => (env_p0xxy.clone(), s_pf.clone()),
                                };
                                let s2_ph = match &arm_pg.guard_o {
                                    Some(gd_pl) => crate::check::expr::lifting::check_cond_f(&env2_pj, &s1_pk, gd_pl),
                                    None => s1_pk.clone(),
                                };
                                let (bt_pm, s3_pn) = arm_widget_block_f(&env2_pj, &s2_ph, &arm_pg.body_p);
                                prism_rtl::Turn::More(Rc::new(crate::check::types::unify::Unify { st_p0: s3_pn.clone(), expected_p1: res_pdxy.clone(), found_p2: bt_pm.clone(), span_p3: arm_pg.body_p.span_p.clone() }))
                            }
                        }))
                    }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
                }), move |fold_17902: crate::check::types::St| {
                    let st4_p9 = fold_17902;
                    crate::prelude::call_then(crate::check::passes::start_match_coverage_f(env_p0x.clone(), st4_p9.clone(), plain_scrut_p8.clone(), arms_p3x.clone(), span_p4x.clone()), move |match_coverage_f_18270: crate::check::types::St| {
                        let st5_pa = match_coverage_f_18270;
                        if last_p5x {
                            prism_rtl::Turn::Finished((res_pd.clone(), st5_pa.clone()))
                        } else {
                            crate::prelude::call_then(start_discarded_f(st5_pa.clone(), res_pd.clone(), span_p4x.clone()), move |discarded_f_18357: crate::check::types::St| prism_rtl::Turn::Finished((res_pd.clone(), discarded_f_18357)))
                        }
                    })
                })
            })
        })
    }
}

/// `Start BuildingMatch, x`: what the function value is when passed to `@Run`.
pub fn start_building_match_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, scrut_p2: crate::syntax::Expr, arms_p3: Array<crate::syntax::Arm>, span_p4: crate::syntax::Range, last_p5: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BuildingMatch { env_p0, st_p1, scrut_p2, arms_p3, span_p4, last_p5 })
}

/// ```prism
/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
/// ```
pub fn building_if_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::syntax::Cond, then_b_p3: &crate::syntax::Block, else_b_o4: &Option<crate::syntax::Block>, span_p5: &crate::syntax::Range, last_p6: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    let (env2_pk, st1_pl) = match c_p2 {
        crate::syntax::Cond::CondExpr(e_p7) => {
            let (ct_pa, s1_pb) = crate::check::expr::infer_f(env_p0, st_p1, &**e_p7);
            let sh_p8 = crate::check::types::head_sigil_f(&s1_pb, &ct_pa);
            let s2_p9 = if crate::check::expr::is_time_sigil_f(&sh_p8) {
                crate::check::types::recording::err_fix_f(&s1_pb, &Text::lit("building-match"), &e_p7.span_p, &Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &Text::lit("write `rebuild` over the condition, with `if _:` inside"))
            } else {
                s1_pb.clone()
            };
            (env_p0.clone(), crate::check::types::unify::unify_f(&s2_p9, &crate::check::types::t_bool_p(), &(if crate::check::expr::is_time_sigil_f(&sh_p8) {
                crate::check::expr::inner_of_f(&s2_p9, &ct_pa)
            } else {
                ct_pa.clone()
            }), &e_p7.span_p))
        },
        crate::syntax::Cond::CondBind(p_pc, e_pd, gd_oe) => {
            let (et_pf, s1_pg) = crate::check::expr::infer_f(env_p0, st_p1, &**e_pd);
            let (en_ph, s2_pi) = crate::check::expr::patterns::bind_pattern_f(env_p0, &s1_pg, p_pc, &et_pf, &true);
            match &**gd_oe {
                Some(g_pj) => (en_ph.clone(), crate::check::expr::lifting::check_cond_f(&en_ph, &s2_pi, g_pj)),
                None => (en_ph.clone(), s2_pi.clone()),
            }
        },
    };
    let (t1_pm, st2_pn) = arm_widget_block_f(&env2_pk, &st1_pl, then_b_p3);
    match else_b_o4 {
        Some(b_po) => {
            let (t2_pq, st3_pr) = arm_widget_block_f(env_p0, &st2_pn, b_po);
            let st4_pp = crate::check::types::unify::unify_f(&st3_pr, &t1_pm, &t2_pq, &b_po.span_p);
            if *last_p6 {
                (t1_pm.clone(), st4_pp.clone())
            } else {
                (t1_pm.clone(), discarded_f(&st4_pp, &t1_pm, span_p5))
            }
        },
        None => {
            let st3_ps = crate::check::types::unify::unify_f(&st2_pn, &crate::check::types::t_unit_p(), &t1_pm, &then_b_p3.span_p);
            (crate::check::types::t_unit_p(), st3_ps.clone())
        },
    }
}

/// The step machine of `BuildingIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
/// ```
pub struct BuildingIf {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::syntax::Cond,
    pub then_b_p3: crate::syntax::Block,
    pub else_b_o4: Option<crate::syntax::Block>,
    pub span_p5: crate::syntax::Range,
    pub last_p6: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for BuildingIf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let then_b_p3 = &self.then_b_p3;
        let else_b_o4 = &self.else_b_o4;
        let span_p5 = &self.span_p5;
        let last_p6 = &self.last_p6;
        let (env2_pk, st1_pl) = match c_p2 {
            crate::syntax::Cond::CondExpr(e_p7) => {
                let (ct_pa, s1_pb) = crate::check::expr::infer_f(env_p0, st_p1, &**e_p7);
                let sh_p8 = crate::check::types::head_sigil_f(&s1_pb, &ct_pa);
                let s2_p9 = if crate::check::expr::is_time_sigil_f(&sh_p8) {
                    crate::check::types::recording::err_fix_f(&s1_pb, &Text::lit("building-match"), &e_p7.span_p, &Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &Text::lit("write `rebuild` over the condition, with `if _:` inside"))
                } else {
                    s1_pb.clone()
                };
                (env_p0.clone(), crate::check::types::unify::unify_f(&s2_p9, &crate::check::types::t_bool_p(), &(if crate::check::expr::is_time_sigil_f(&sh_p8) {
                    crate::check::expr::inner_of_f(&s2_p9, &ct_pa)
                } else {
                    ct_pa.clone()
                }), &e_p7.span_p))
            },
            crate::syntax::Cond::CondBind(p_pc, e_pd, gd_oe) => {
                let (et_pf, s1_pg) = crate::check::expr::infer_f(env_p0, st_p1, &**e_pd);
                let (en_ph, s2_pi) = crate::check::expr::patterns::bind_pattern_f(env_p0, &s1_pg, p_pc, &et_pf, &true);
                match &**gd_oe {
                    Some(g_pj) => (en_ph.clone(), crate::check::expr::lifting::check_cond_f(&en_ph, &s2_pi, g_pj)),
                    None => (en_ph.clone(), s2_pi.clone()),
                }
            },
        };
        let (t1_pm, st2_pn) = arm_widget_block_f(&env2_pk, &st1_pl, then_b_p3);
        match else_b_o4 {
            Some(b_po) => {
                let (t2_pq, st3_pr) = arm_widget_block_f(env_p0, &st2_pn, b_po);
                let b_pox = b_po.clone();
                let last_p6x = *last_p6;
                let span_p5x = span_p5.clone();
                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st3_pr.clone(), t1_pm.clone(), t2_pq.clone(), b_pox.span_p.clone()), move |unify_f_19356: crate::check::types::St| {
                    let st4_pp = unify_f_19356;
                    if last_p6x {
                        prism_rtl::Turn::Finished((t1_pm.clone(), st4_pp.clone()))
                    } else {
                        crate::prelude::call_then(start_discarded_f(st4_pp.clone(), t1_pm.clone(), span_p5x.clone()), move |discarded_f_19428: crate::check::types::St| prism_rtl::Turn::Finished((t1_pm.clone(), discarded_f_19428)))
                    }
                })
            },
            None => {
                let span_p5x = span_p5.clone();
                let then_b_p3x = then_b_p3.clone();
                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pn.clone(), crate::check::types::t_unit_p(), t1_pm.clone(), then_b_p3x.span_p.clone()), move |unify_f_19490: crate::check::types::St| {
                    let st3_ps = unify_f_19490;
                    prism_rtl::Turn::Finished((crate::check::types::t_unit_p(), st3_ps.clone()))
                })
            },
        }
    }
}

/// `Start BuildingIf, x`: what the function value is when passed to `@Run`.
pub fn start_building_if_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, c_p2: crate::syntax::Cond, then_b_p3: crate::syntax::Block, else_b_o4: Option<crate::syntax::Block>, span_p5: crate::syntax::Range, last_p6: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(BuildingIf { env_p0, st_p1, c_p2, then_b_p3, else_b_o4, span_p5, last_p6 })
}

/// ```prism
/// ArmWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub fn arm_widget_block_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block) -> (crate::check::types::Ty, crate::check::types::St) {
    infer_widget_block_f(env_p0, st_p1, b_p2)
}
