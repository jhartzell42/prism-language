//! The module `Check.Blocks.Borrows`, from `target/bootstrap/src/prismc/check/blocks/borrows.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_update(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, target_p2: &crate::syntax::Expr, body_p3: &crate::syntax::Block, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p9, st1_pa) = crate::check::expr::infer(env_p0, st_p1, target_p2);
    let sh_p5 = crate::check::types::head_sigil(&st1_pa, &t_p9);
    let st2_p6 = if crate::check::expr::is_time_sigil(&sh_p5) || (&sh_p5 == &Text::lit("@")) {
        crate::check::types::recording::err_fix(&st1_pa, &Text::lit("time-in-update"), &target_p2.span, &Text::from(format!("`update` over a `{}`", &crate::check::types::show_ty(&st1_pa, &t_p9))), &Text::lit("update the plain value, and lift the function that does it"))
    } else {
        st1_pa.clone()
    };
    let env2_p7 = {
        let mut this: crate::check::expr::Env = crate::check::blocks::structure::with_topic(env_p0, &Text::lit("&_"), &t_p9);
        this.in_update = true;
        this
    };
    let (_, st3_pb) = update_stmts(&env2_p7, &st2_p6, &body_p3.stmts);
    let st4_p8 = crate::check::passes::borrows::and_block_checks(&env2_p7, &st3_pb, body_p3, &t_p9);
    (t_p9.clone(), st4_p8.clone())
}

/// The step machine of `InferUpdate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferUpdate {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub target_p2: crate::syntax::Expr,
    pub body_p3: crate::syntax::Block,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferUpdate {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let target_p2 = &self.target_p2;
        let body_p3 = &self.body_p3;
        let span_p4 = &self.span_p4;
        let body_p3 = body_p3.clone();
        let env_p0 = env_p0.clone();
        let span_p4 = span_p4.clone();
        let st_p1 = st_p1.clone();
        let target_p2 = target_p2.clone();
        call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), target_p2.clone()), move |infer_1577: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p9, st1_pa) = infer_1577;
            call_then(crate::check::types::start_head_sigil(st1_pa.clone(), t_p9.clone()), move |head_sigil_1612: Text| {
                let sh_p5 = head_sigil_1612;
                let st2_p6 = if crate::check::expr::is_time_sigil(&sh_p5) || (&sh_p5 == &Text::lit("@")) {
                    crate::check::types::recording::err_fix(&st1_pa, &Text::lit("time-in-update"), &target_p2.span, &Text::from(format!("`update` over a `{}`", &crate::check::types::show_ty(&st1_pa, &t_p9))), &Text::lit("update the plain value, and lift the function that does it"))
                } else {
                    st1_pa.clone()
                };
                let env2_p7 = {
                    let mut this: crate::check::expr::Env = crate::check::blocks::structure::with_topic(&env_p0, &Text::lit("&_"), &t_p9);
                    this.in_update = true;
                    this
                };
                call_then(start_update_stmts(env2_p7.clone(), st2_p6.clone(), body_p3.stmts.clone()), move |update_stmts_1930: (crate::check::expr::Env, crate::check::types::St)| {
                    let (_, st3_pb) = update_stmts_1930;
                    call_then(crate::check::passes::borrows::start_and_block_checks(env2_p7.clone(), st3_pb.clone(), body_p3.clone(), t_p9.clone()), move |and_block_checks_1978: crate::check::types::St| {
                        let st4_p8 = and_block_checks_1978;
                        prism_rtl::Turn::Finished((t_p9.clone(), st4_p8.clone()))
                    })
                })
            })
        })
    }
}

/// `Start InferUpdate, x`: what the function value is when passed to `@Run`.
pub fn start_infer_update(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, target_p2: crate::syntax::Expr, body_p3: crate::syntax::Block, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferUpdate { env_p0, st_p1, target_p2, body_p3, span_p4 })
}

/// ```prism
/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub fn update_stmts(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, stmts_p2: &Array<crate::syntax::Stmt>) -> (crate::check::expr::Env, crate::check::types::St) {
    run_to_end(fold_job(stmts_p2.clone(), (env_p0.clone(), st_p1.clone()), Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| entered(once_job(move || {
        let (en_p3, s_p4) = p0;
        let stmt_p5 = p1;
        prism_rtl::Turn::More(Rc::new(UpdateStmt { env_p0: en_p3.clone(), st_p1: s_p4.clone(), s_p2: stmt_p5.clone() }))
    }))) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>))
}

/// The step machine of `UpdateStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub struct UpdateStmts {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub stmts_p2: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for UpdateStmts {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let stmts_p2 = &self.stmts_p2;
        fold_job(stmts_p2.clone(), (env_p0.clone(), st_p1.clone()), Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| entered(once_job(move || {
            let (en_p3, s_p4) = p0;
            let stmt_p5 = p1;
            prism_rtl::Turn::More(Rc::new(UpdateStmt { env_p0: en_p3.clone(), st_p1: s_p4.clone(), s_p2: stmt_p5.clone() }))
        }))) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>).cycle()
    }
}

/// `Start UpdateStmts, x`: what the function value is when passed to `@Run`.
pub fn start_update_stmts(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, stmts_p2: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(UpdateStmts { env_p0, st_p1, stmts_p2 })
}

/// ```prism
/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub fn update_stmt(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, s_p2: &crate::syntax::Stmt) -> (crate::check::expr::Env, crate::check::types::St) {
    match &s_p2.kind {
        crate::syntax::StmtKind::SSet(target_p3, value_p4) => {
            let (tt_p6, st1_p7) = crate::check::expr::infer(env_p0, st_p1, target_p3);
            let st2_p5 = ref_target(env_p0, &st1_p7, target_p3);
            (env_p0.clone(), crate::check::expr::check(env_p0, &st2_p5, value_p4, &tt_p6))
        },
        crate::syntax::StmtKind::SAccum(target_p8, op_p9, value_pa) => {
            let (tt_pf, st1_pg) = crate::check::expr::infer(env_p0, st_p1, target_p8);
            let st2_pb = ref_target(env_p0, &st1_pg, target_p8);
            let st3_pc = crate::check::expr::check(env_p0, &st2_pb, value_pa, &tt_pf);
            let st4_pd = crate::check::expr::add_want(&st3_pc, &Text::lit("Prelude.Num"), &tt_pf, &s_p2.span);
            let st5_pe = if op_p9 == &Text::lit("-=") {
                crate::check::expr::add_want(&st4_pd, &Text::lit("Prelude.Sub"), &tt_pf, &s_p2.span)
            } else {
                st4_pd.clone()
            };
            (env_p0.clone(), st5_pe.clone())
        },
        crate::syntax::StmtKind::SLet(p_ph, ty_oi, e_pj) => {
            let (t_pl, st1_pm) = crate::check::expr::infer(env_p0, st_p1, e_pj);
            let st2_pk = match ty_oi {
                Some(ty_pn) => {
                    let (at_po, s2_pp) = crate::check::env::reading::conv_type(&crate::check::expr::env_cx(env_p0), &st1_pm, ty_pn);
                    crate::check::types::unify::unify(&s2_pp, &at_po, &t_pl, &e_pj.span)
                },
                None => st1_pm.clone(),
            };
            let (env2_pq, st3_pr) = crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(env_p0), &st2_pk, p_ph, &t_pl, &false);
            (env2_pq.clone(), st3_pr.clone())
        },
        crate::syntax::StmtKind::SWhile(c_ps, body_pt) => (env_p0.clone(), update_while(env_p0, st_p1, c_ps, body_pt)),
        crate::syntax::StmtKind::SExpr(e_pu) => match &*e_pu.kind {
            crate::syntax::ExprKind::EIf(c_pv, then_b_p10, else_b_o11) => (env_p0.clone(), update_if(env_p0, st_p1, &**c_pv, then_b_p10, else_b_o11)),
            crate::syntax::ExprKind::EMatch(scrut_p12, arms_p13) => (env_p0.clone(), update_match(env_p0, st_p1, &**scrut_p12, arms_p13, &e_pu.span)),
            crate::syntax::ExprKind::EFor(binders_o14, source_p15, body_p16) => (env_p0.clone(), update_for(env_p0, st_p1, binders_o14, &**source_p15, body_p16, &e_pu.span)),
            _ => {
                let (t_p17, st1_p18) = crate::check::expr::infer(env_p0, st_p1, e_pu);
                (env_p0.clone(), crate::check::blocks::discarded(&st1_p18, &t_p17, &e_pu.span))
            },
        },
        crate::syntax::StmtKind::SFn(f_p19) => {
            let (env1_p1a, st1_p1b) = crate::check::expr::lets::pre_bind(env_p0, st_p1, s_p2);
            crate::check::expr::lets::check_local_fn(&env1_p1a, &st1_p1b, f_p19, &s_p2.span)
        },
        crate::syntax::StmtKind::SSignature(_) => crate::check::expr::lets::pre_bind(env_p0, st_p1, s_p2),
        _ => (env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &s_p2.span, &Text::lit("this statement belongs in a widget or `given:` block"))),
    }
}

/// The step machine of `UpdateStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub struct UpdateStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub s_p2: crate::syntax::Stmt,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for UpdateStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let s_p2 = &self.s_p2;
        match &s_p2.kind {
            crate::syntax::StmtKind::SSet(target_p3, value_p4) => {
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                let target_p3 = target_p3.clone();
                let value_p4 = value_p4.clone();
                call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), target_p3.clone()), move |infer_2330: (crate::check::types::Ty, crate::check::types::St)| {
                    let (tt_p6, st1_p7) = infer_2330;
                    let st2_p5 = ref_target(&env_p0, &st1_p7, &target_p3);
                    call_then(crate::check::expr::start_check(env_p0.clone(), st2_p5.clone(), value_p4.clone(), tt_p6.clone()), move |check_2413: crate::check::types::St| prism_rtl::Turn::Finished((env_p0.clone(), check_2413)))
                })
            },
            crate::syntax::StmtKind::SAccum(target_p8, op_p9, value_pa) => {
                let env_p0 = env_p0.clone();
                let op_p9 = op_p9.clone();
                let s_p2 = s_p2.clone();
                let st_p1 = st_p1.clone();
                let target_p8 = target_p8.clone();
                let value_pa = value_pa.clone();
                call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), target_p8.clone()), move |infer_2498: (crate::check::types::Ty, crate::check::types::St)| {
                    let (tt_pf, st1_pg) = infer_2498;
                    let st2_pb = ref_target(&env_p0, &st1_pg, &target_p8);
                    call_then(crate::check::expr::start_check(env_p0.clone(), st2_pb.clone(), value_pa.clone(), tt_pf.clone()), move |check_2583: crate::check::types::St| {
                        let st3_pc = check_2583;
                        let st4_pd = crate::check::expr::add_want(&st3_pc, &Text::lit("Prelude.Num"), &tt_pf, &s_p2.span);
                        let st5_pe = if &op_p9 == &Text::lit("-=") {
                            crate::check::expr::add_want(&st4_pd, &Text::lit("Prelude.Sub"), &tt_pf, &s_p2.span)
                        } else {
                            st4_pd.clone()
                        };
                        prism_rtl::Turn::Finished((env_p0.clone(), st5_pe.clone()))
                    })
                })
            },
            crate::syntax::StmtKind::SLet(p_ph, ty_oi, e_pj) => {
                let ty_oi = ty_oi.clone();
                let e_pj = e_pj.clone();
                let env_p0 = env_p0.clone();
                let p_ph = p_ph.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), e_pj.clone()), move |infer_2814: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pl, st1_pm) = infer_2814;
                    let st2_pk = match &ty_oi {
                        Some(ty_pn) => {
                            let (at_po, s2_pp) = crate::check::env::reading::conv_type(&crate::check::expr::env_cx(&env_p0), &st1_pm, ty_pn);
                            crate::check::types::unify::unify(&s2_pp, &at_po, &t_pl, &e_pj.span)
                        },
                        None => st1_pm.clone(),
                    };
                    call_then(crate::check::expr::patterns::start_bind_pattern(crate::check::blocks::structure::unpending(&env_p0), st2_pk.clone(), p_ph.clone(), t_pl.clone(), false), move |bind_pattern_3030: (crate::check::expr::Env, crate::check::types::St)| {
                        let (env2_pq, st3_pr) = bind_pattern_3030;
                        prism_rtl::Turn::Finished((env2_pq.clone(), st3_pr.clone()))
                    })
                })
            },
            crate::syntax::StmtKind::SWhile(c_ps, body_pt) => {
                let body_pt = body_pt.clone();
                let c_ps = c_ps.clone();
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                call_then(start_update_while(env_p0.clone(), st_p1.clone(), c_ps.clone(), body_pt.clone()), move |update_while_3126: crate::check::types::St| prism_rtl::Turn::Finished((env_p0.clone(), update_while_3126)))
            },
            crate::syntax::StmtKind::SExpr(e_pu) => match &*e_pu.kind {
                crate::syntax::ExprKind::EIf(c_pv, then_b_p10, else_b_o11) => {
                    let else_b_o11 = else_b_o11.clone();
                    let c_pv = (**c_pv).clone();
                    let env_p0 = env_p0.clone();
                    let st_p1 = st_p1.clone();
                    let then_b_p10 = then_b_p10.clone();
                    call_then(start_update_if(env_p0.clone(), st_p1.clone(), c_pv.clone(), then_b_p10.clone(), else_b_o11.clone()), move |update_if_3223: crate::check::types::St| prism_rtl::Turn::Finished((env_p0.clone(), update_if_3223)))
                },
                crate::syntax::ExprKind::EMatch(scrut_p12, arms_p13) => {
                    let arms_p13 = arms_p13.clone();
                    let e_pu = e_pu.clone();
                    let env_p0 = env_p0.clone();
                    let scrut_p12 = (**scrut_p12).clone();
                    let st_p1 = st_p1.clone();
                    call_then(start_update_match(env_p0.clone(), st_p1.clone(), scrut_p12.clone(), arms_p13.clone(), e_pu.span.clone()), move |update_match_3297: crate::check::types::St| prism_rtl::Turn::Finished((env_p0.clone(), update_match_3297)))
                },
                crate::syntax::ExprKind::EFor(binders_o14, source_p15, body_p16) => {
                    let binders_o14 = binders_o14.clone();
                    let body_p16 = body_p16.clone();
                    let e_pu = e_pu.clone();
                    let env_p0 = env_p0.clone();
                    let source_p15 = (**source_p15).clone();
                    let st_p1 = st_p1.clone();
                    call_then(start_update_for(env_p0.clone(), st_p1.clone(), binders_o14.clone(), source_p15.clone(), body_p16.clone(), e_pu.span.clone()), move |update_for_3386: crate::check::types::St| prism_rtl::Turn::Finished((env_p0.clone(), update_for_3386)))
                },
                _ => {
                    let e_pu = e_pu.clone();
                    let env_p0 = env_p0.clone();
                    let st_p1 = st_p1.clone();
                    call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), e_pu.clone()), move |infer_3487: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_p17, st1_p18) = infer_3487;
                        call_then(crate::check::blocks::start_discarded(st1_p18.clone(), t_p17.clone(), e_pu.span.clone()), move |discarded_3524: crate::check::types::St| prism_rtl::Turn::Finished((env_p0.clone(), discarded_3524)))
                    })
                },
            },
            crate::syntax::StmtKind::SFn(f_p19) => {
                let env_p0 = env_p0.clone();
                let f_p19 = f_p19.clone();
                let s_p2 = s_p2.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::expr::lets::start_pre_bind(env_p0.clone(), st_p1.clone(), s_p2.clone()), move |pre_bind_3591: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env1_p1a, st1_p1b) = pre_bind_3591;
                    prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::CheckLocalFn { env_p0: env1_p1a.clone(), st_p1: st1_p1b.clone(), f_p2: f_p19.clone(), span_p3: s_p2.span.clone() }))
                })
            },
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::PreBind { env_p0: env_p0.clone(), st_p1: st_p1.clone(), s_p2: s_p2.clone() })),
            _ => prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &s_p2.span, &Text::lit("this statement belongs in a widget or `given:` block")))),
        }
    }
}

/// `Start UpdateStmt, x`: what the function value is when passed to `@Run`.
pub fn start_update_stmt(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, s_p2: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(UpdateStmt { env_p0, st_p1, s_p2 })
}

/// ```prism
/// RefTarget: fn Env, St, Expr -> St
/// ```
pub fn ref_target(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> crate::check::types::St {
    if is_ref(e_p2) {
        st_p1.clone()
    } else {
        crate::check::types::recording::err_fix(st_p1, &Text::lit("mismatch"), &e_p2.span, &Text::lit("the left of `<=` is a reference: `&_`, a local `&x`, or a path from one"), &Text::from(format!("write `&_.{}`, or make a local with `let &x = ...`", &crate::check::expr::src_text(env_p0, &e_p2.span))))
    }
}

/// ```prism
/// IsRef: fn Expr -> Bool
/// ```
pub fn is_ref(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind {
        crate::syntax::ExprKind::EName(n_p1) => crate::syntax::lexer::chars::has_prefix(&n_p1.sigils, &Text::lit("&")),
        crate::syntax::ExprKind::EField(r_p2, _, _) => is_ref(&**r_p2),
        crate::syntax::ExprKind::EIndex(r_p3, _) => is_ref(&**r_p3),
        crate::syntax::ExprKind::EGroup(x_p4) => is_ref(&**x_p4),
        _ => false,
    }
}

/// ```prism
/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
/// ```
pub fn update_if(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::syntax::Cond, then_b_p3: &crate::syntax::Block, else_b_o4: &Option<crate::syntax::Block>) -> crate::check::types::St {
    let (env2_pe, st1_pf) = match c_p2 {
        crate::syntax::Cond::CondExpr(e_p5) => (env_p0.clone(), crate::check::expr::lifting::check_cond(env_p0, st_p1, &**e_p5)),
        crate::syntax::Cond::CondBind(p_p6, e_p7, gd_o8) => {
            let (et_p9, s1_pa) = crate::check::expr::infer(env_p0, st_p1, &**e_p7);
            let (en_pb, s2_pc) = crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(env_p0), &s1_pa, p_p6, &et_p9, &true);
            match &**gd_o8 {
                Some(g_pd) => (en_pb.clone(), crate::check::expr::lifting::check_cond(&en_pb, &s2_pc, g_pd)),
                None => (en_pb.clone(), s2_pc.clone()),
            }
        },
    };
    let (_, st2_pg) = update_stmts(&env2_pe, &st1_pf, &then_b_p3.stmts);
    match else_b_o4 {
        Some(b_ph) => {
            let (_, st3_pi) = update_stmts(env_p0, &st2_pg, &b_ph.stmts);
            st3_pi.clone()
        },
        None => st2_pg.clone(),
    }
}

/// The step machine of `UpdateIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
/// ```
pub struct UpdateIf {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::syntax::Cond,
    pub then_b_p3: crate::syntax::Block,
    pub else_b_o4: Option<crate::syntax::Block>,
}

impl prism_rtl::Job<crate::check::types::St> for UpdateIf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let then_b_p3 = &self.then_b_p3;
        let else_b_o4 = &self.else_b_o4;
        let (env2_pe, st1_pf) = match c_p2 {
            crate::syntax::Cond::CondExpr(e_p5) => (env_p0.clone(), crate::check::expr::lifting::check_cond(env_p0, st_p1, &**e_p5)),
            crate::syntax::Cond::CondBind(p_p6, e_p7, gd_o8) => {
                let (et_p9, s1_pa) = crate::check::expr::infer(env_p0, st_p1, &**e_p7);
                let (en_pb, s2_pc) = crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(env_p0), &s1_pa, p_p6, &et_p9, &true);
                match &**gd_o8 {
                    Some(g_pd) => (en_pb.clone(), crate::check::expr::lifting::check_cond(&en_pb, &s2_pc, g_pd)),
                    None => (en_pb.clone(), s2_pc.clone()),
                }
            },
        };
        let else_b_o4 = else_b_o4.clone();
        let env_p0 = env_p0.clone();
        let then_b_p3 = then_b_p3.clone();
        call_then(start_update_stmts(env2_pe.clone(), st1_pf.clone(), then_b_p3.stmts.clone()), move |update_stmts_4808: (crate::check::expr::Env, crate::check::types::St)| {
            let (_, st2_pg) = update_stmts_4808;
            match &else_b_o4 {
                Some(b_ph) => {
                    let b_ph = b_ph.clone();
                    call_then(start_update_stmts(env_p0.clone(), st2_pg.clone(), b_ph.stmts.clone()), move |update_stmts_4908: (crate::check::expr::Env, crate::check::types::St)| {
                        let (_, st3_pi) = update_stmts_4908;
                        prism_rtl::Turn::Finished(st3_pi.clone())
                    })
                },
                None => prism_rtl::Turn::Finished(st2_pg.clone()),
            }
        })
    }
}

/// `Start UpdateIf, x`: what the function value is when passed to `@Run`.
pub fn start_update_if(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, c_p2: crate::syntax::Cond, then_b_p3: crate::syntax::Block, else_b_o4: Option<crate::syntax::Block>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UpdateIf { env_p0, st_p1, c_p2, then_b_p3, else_b_o4 })
}

/// ```prism
/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
/// ```
pub fn update_match(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, scrut_p2: &crate::syntax::Expr, arms_p3: &Array<crate::syntax::Arm>, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    let (t_p6, st1_p7) = crate::check::expr::infer(env_p0, st_p1, scrut_p2);
    let st2_p5 = run_to_end(fold_job(arms_p3.clone(), st1_p7.clone(), {
        let env_p0 = env_p0.clone();
        let t_p6 = t_p6.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
            let env_p0 = env_p0.clone();
            let t_p6 = t_p6.clone();
            entered(once_job(move || {
                let s_p8 = p0;
                let arm_p9 = p1;
                {
                    let (env2_pc, s1_pd) = match &arm_p9.pattern {
                        Some(p_pb) => crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(&env_p0), &s_p8, p_pb, &t_p6, &true),
                        None => (env_p0.clone(), s_p8.clone()),
                    };
                    let s2_pa = match &arm_p9.guard {
                        Some(gd_pe) => crate::check::expr::lifting::check_cond(&env2_pc, &s1_pd, gd_pe),
                        None => s1_pd.clone(),
                    };
                    call_then(start_update_stmts(env2_pc.clone(), s2_pa.clone(), arm_p9.body.stmts.clone()), move |update_stmts_5417: (crate::check::expr::Env, crate::check::types::St)| {
                        let (_, s3_pf) = update_stmts_5417;
                        prism_rtl::Turn::Finished(s3_pf.clone())
                    })
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    crate::check::passes::match_coverage(env_p0, &st2_p5, &t_p6, arms_p3, span_p4)
}

/// The step machine of `UpdateMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
/// ```
pub struct UpdateMatch {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub scrut_p2: crate::syntax::Expr,
    pub arms_p3: Array<crate::syntax::Arm>,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for UpdateMatch {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let scrut_p2 = &self.scrut_p2;
        let arms_p3 = &self.arms_p3;
        let span_p4 = &self.span_p4;
        let arms_p3 = arms_p3.clone();
        let env_p0 = env_p0.clone();
        let scrut_p2 = scrut_p2.clone();
        let span_p4 = span_p4.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), scrut_p2.clone()), move |infer_5096: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p6, st1_p7) = infer_5096;
            call_value(fold_job(arms_p3.clone(), st1_p7.clone(), {
                let env_p0 = env_p0.clone();
                let t_p6 = t_p6.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                    let env_p0 = env_p0.clone();
                    let t_p6 = t_p6.clone();
                    entered(once_job(move || {
                        let s_p8 = p0;
                        let arm_p9 = p1;
                        {
                            let (env2_pc, s1_pd) = match &arm_p9.pattern {
                                Some(p_pb) => crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(&env_p0), &s_p8, p_pb, &t_p6, &true),
                                None => (env_p0.clone(), s_p8.clone()),
                            };
                            let s2_pa = match &arm_p9.guard {
                                Some(gd_pe) => crate::check::expr::lifting::check_cond(&env2_pc, &s1_pd, gd_pe),
                                None => s1_pd.clone(),
                            };
                            call_then(start_update_stmts(env2_pc.clone(), s2_pa.clone(), arm_p9.body.stmts.clone()), move |update_stmts_5417: (crate::check::expr::Env, crate::check::types::St)| {
                                let (_, s3_pf) = update_stmts_5417;
                                prism_rtl::Turn::Finished(s3_pf.clone())
                            })
                        }
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }), move |fold_5131: crate::check::types::St| {
                let st2_p5 = fold_5131;
                prism_rtl::Turn::More(Rc::new(crate::check::passes::MatchCoverage { env_p0: env_p0.clone(), st_p1: st2_p5.clone(), t_p2: t_p6.clone(), arms_p3: arms_p3.clone(), span_p4: span_p4.clone() }))
            })
        })
    }
}

/// `Start UpdateMatch, x`: what the function value is when passed to `@Run`.
pub fn start_update_match(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, scrut_p2: crate::syntax::Expr, arms_p3: Array<crate::syntax::Arm>, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UpdateMatch { env_p0, st_p1, scrut_p2, arms_p3, span_p4 })
}

/// ```prism
/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
/// ```
pub fn update_while(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::syntax::Cond, body_p3: &crate::syntax::Block) -> crate::check::types::St {
    let (env2_pd, st1_pe) = match c_p2 {
        crate::syntax::Cond::CondExpr(e_p4) => (env_p0.clone(), crate::check::expr::lifting::check_cond(env_p0, st_p1, &**e_p4)),
        crate::syntax::Cond::CondBind(p_p5, e_p6, gd_o7) => {
            let (et_p8, s1_p9) = crate::check::expr::infer(env_p0, st_p1, &**e_p6);
            let (en_pa, s2_pb) = crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(env_p0), &s1_p9, p_p5, &et_p8, &true);
            match &**gd_o7 {
                Some(g_pc) => (en_pa.clone(), crate::check::expr::lifting::check_cond(&en_pa, &s2_pb, g_pc)),
                None => (en_pa.clone(), s2_pb.clone()),
            }
        },
    };
    let (_, st2_pf) = update_stmts(&env2_pd, &st1_pe, &body_p3.stmts);
    st2_pf.clone()
}

/// The step machine of `UpdateWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
/// ```
pub struct UpdateWhile {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::syntax::Cond,
    pub body_p3: crate::syntax::Block,
}

impl prism_rtl::Job<crate::check::types::St> for UpdateWhile {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let body_p3 = &self.body_p3;
        let (env2_pd, st1_pe) = match c_p2 {
            crate::syntax::Cond::CondExpr(e_p4) => (env_p0.clone(), crate::check::expr::lifting::check_cond(env_p0, st_p1, &**e_p4)),
            crate::syntax::Cond::CondBind(p_p5, e_p6, gd_o7) => {
                let (et_p8, s1_p9) = crate::check::expr::infer(env_p0, st_p1, &**e_p6);
                let (en_pa, s2_pb) = crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(env_p0), &s1_p9, p_p5, &et_p8, &true);
                match &**gd_o7 {
                    Some(g_pc) => (en_pa.clone(), crate::check::expr::lifting::check_cond(&en_pa, &s2_pb, g_pc)),
                    None => (en_pa.clone(), s2_pb.clone()),
                }
            },
        };
        let body_p3 = body_p3.clone();
        call_then(start_update_stmts(env2_pd.clone(), st1_pe.clone(), body_p3.stmts.clone()), move |update_stmts_6052: (crate::check::expr::Env, crate::check::types::St)| {
            let (_, st2_pf) = update_stmts_6052;
            prism_rtl::Turn::Finished(st2_pf.clone())
        })
    }
}

/// `Start UpdateWhile, x`: what the function value is when passed to `@Run`.
pub fn start_update_while(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, c_p2: crate::syntax::Cond, body_p3: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UpdateWhile { env_p0, st_p1, c_p2, body_p3 })
}

/// ```prism
/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
/// ```
pub fn update_for(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, binders_o2: &Option<crate::syntax::ForBinders>, source_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    let (t_p7, st1_p8) = crate::check::expr::infer(env_p0, st_p1, source_p3);
    let (k_p9, v_pa, st2_pb) = crate::check::blocks::structure::coll_parts(&st1_p8, &t_p7, &source_p3.span);
    let env1_p6 = crate::check::blocks::structure::loop_indices(env_p0);
    let (env2_pg, st3_ph) = match binders_o2 {
        None => (crate::check::blocks::structure::with_topic(&env1_p6, &Text::lit("&_"), &v_pa), st2_pb.clone()),
        Some(bs_pc) => match &bs_pc.second {
            Some(second_pd) => {
                let (e1_pe, s1_pf) = crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(&env1_p6), &st2_pb, &bs_pc.first, &k_p9, &false);
                crate::check::expr::patterns::bind_pattern(&e1_pe, &s1_pf, second_pd, &v_pa, &false)
            },
            None => crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(&env1_p6), &st2_pb, &bs_pc.first, &v_pa, &false),
        },
    };
    let (_, st4_pi) = update_stmts(&env2_pg, &st3_ph, &body_p4.stmts);
    st4_pi.clone()
}

/// The step machine of `UpdateFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
/// ```
pub struct UpdateFor {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub binders_o2: Option<crate::syntax::ForBinders>,
    pub source_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for UpdateFor {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let binders_o2 = &self.binders_o2;
        let source_p3 = &self.source_p3;
        let body_p4 = &self.body_p4;
        let span_p5 = &self.span_p5;
        let binders_o2 = binders_o2.clone();
        let body_p4 = body_p4.clone();
        let env_p0 = env_p0.clone();
        let source_p3 = source_p3.clone();
        let span_p5 = span_p5.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), source_p3.clone()), move |infer_6360: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p7, st1_p8) = infer_6360;
            call_then(crate::check::blocks::structure::start_coll_parts(st1_p8.clone(), t_p7.clone(), source_p3.span.clone()), move |coll_parts_6406: (crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)| {
                let (k_p9, v_pa, st2_pb) = coll_parts_6406;
                let env1_p6 = crate::check::blocks::structure::loop_indices(&env_p0);
                let (env2_pg, st3_ph) = match &binders_o2 {
                    None => (crate::check::blocks::structure::with_topic(&env1_p6, &Text::lit("&_"), &v_pa), st2_pb.clone()),
                    Some(bs_pc) => match &bs_pc.second {
                        Some(second_pd) => {
                            let (e1_pe, s1_pf) = crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(&env1_p6), &st2_pb, &bs_pc.first, &k_p9, &false);
                            crate::check::expr::patterns::bind_pattern(&e1_pe, &s1_pf, second_pd, &v_pa, &false)
                        },
                        None => crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(&env1_p6), &st2_pb, &bs_pc.first, &v_pa, &false),
                    },
                };
                call_then(start_update_stmts(env2_pg.clone(), st3_ph.clone(), body_p4.stmts.clone()), move |update_stmts_6846: (crate::check::expr::Env, crate::check::types::St)| {
                    let (_, st4_pi) = update_stmts_6846;
                    prism_rtl::Turn::Finished(st4_pi.clone())
                })
            })
        })
    }
}

/// `Start UpdateFor, x`: what the function value is when passed to `@Run`.
pub fn start_update_for(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, binders_o2: Option<crate::syntax::ForBinders>, source_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UpdateFor { env_p0, st_p1, binders_o2, source_p3, body_p4, span_p5 })
}
