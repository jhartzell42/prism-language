//! The module `Check.Blocks.Borrows`, from `target/bootstrap/src/prismc/check/blocks/borrows.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `SetWritten`:
///
/// ```prism
/// type SetWritten = choice:
/// ```
#[derive(::std::clone::Clone)]
pub enum SetWritten {
    SetsPresent,
    SetsAbsent,
    SetsEither,
}

impl crate::prelude::ToPod for SetWritten {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            SetWritten::SetsPresent => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SetsPresent", 0), vec![]),
            SetWritten::SetsAbsent => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SetsAbsent", 1), vec![]),
            SetWritten::SetsEither => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SetsEither", 2), vec![]),
        }
    }
}

impl crate::prelude::FromPod for SetWritten {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "SetsPresent" && a.len() == 0 => ::std::result::Result::Ok(SetWritten::SetsPresent),
            crate::prelude::Pod::Choice(c, a) if &**c == "SetsAbsent" && a.len() == 0 => ::std::result::Result::Ok(SetWritten::SetsAbsent),
            crate::prelude::Pod::Choice(c, a) if &**c == "SetsEither" && a.len() == 0 => ::std::result::Result::Ok(SetWritten::SetsEither),
            other => ::prism_rtl::pod::mismatch("a SetWritten", other),
        }
    }
}

/// ```prism
/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_update_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, target_p2: &crate::syntax::Expr, body_p3: &crate::syntax::Block, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p9, st1_pa) = crate::check::expr::infer_f(env_p0, st_p1, target_p2);
    let sh_p5 = crate::check::types::head_sigil_f(&st1_pa, &t_p9);
    let st2_p6 = if crate::check::expr::is_time_sigil_f(&sh_p5) || (&sh_p5 == &crate::prelude::Text::lit("@")) {
        crate::check::types::recording::err_fix_f(&st1_pa, &crate::prelude::Text::lit("time-in-update"), &target_p2.span_p, &crate::prelude::Text::from(format!("`update` over a `{}`", &crate::check::types::show_ty_f(&st1_pa, &t_p9))), &crate::prelude::Text::lit("update the plain value, and lift the function that does it"))
    } else {
        st1_pa.clone()
    };
    let env2_p7 = {
        let mut this: crate::check::expr::Env = crate::check::blocks::structure::with_topic_f(env_p0, &crate::prelude::Text::lit("&_"), &t_p9);
        this.in_update_p = true;
        this
    };
    let (_, st3_pb) = update_stmts_f(&env2_p7, &st2_p6, &body_p3.stmts_p);
    let st4_p8 = crate::check::passes::borrows::and_block_checks_f(&env2_p7, &st3_pb, body_p3, &t_p9);
    (t_p9.clone(), st4_p8.clone())
}

/// The step machine of `InferUpdate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferUpdate {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub target_p2: crate::syntax::Expr,
    pub body_p3: crate::syntax::Block,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferUpdate {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let target_p2 = &self.target_p2;
        let body_p3 = &self.body_p3;
        let span_p4 = &self.span_p4;
        let body_p3x = body_p3.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        let target_p2x = target_p2.clone();
        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), target_p2x.clone()), move |infer_f_1577: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p9, st1_pa) = infer_f_1577;
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pa.clone(), t_p9.clone()), move |head_sigil_f_1612: crate::prelude::Text| {
                let sh_p5 = head_sigil_f_1612;
                let body_p3xz = body_p3x.clone();
                let env_p0xz = env_p0x.clone();
                let t_p9z = t_p9.clone();
                let k_let1633 = move |v1633: crate::check::types::St| {
                    let st2_p6 = v1633;
                    let env2_p7 = {
                        let mut this: crate::check::expr::Env = crate::check::blocks::structure::with_topic_f(&env_p0xz, &crate::prelude::Text::lit("&_"), &t_p9z);
                        this.in_update_p = true;
                        this
                    };
                    crate::prelude::call_then(start_update_stmts_f(env2_p7.clone(), st2_p6.clone(), body_p3xz.stmts_p.clone()), move |update_stmts_f_1930: (crate::check::expr::Env, crate::check::types::St)| {
                        let (_, st3_pb) = update_stmts_f_1930;
                        crate::prelude::call_then(crate::check::passes::borrows::start_and_block_checks_f(env2_p7.clone(), st3_pb.clone(), body_p3xz.clone(), t_p9z.clone()), move |and_block_checks_f_1978: crate::check::types::St| {
                            let st4_p8 = and_block_checks_f_1978;
                            ::prism_rtl::Turn::Finished((t_p9z.clone(), st4_p8.clone()))
                        })
                    })
                };
                if crate::check::expr::is_time_sigil_f(&sh_p5) || (&sh_p5 == &crate::prelude::Text::lit("@")) {
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(st1_pa.clone(), t_p9.clone()), move |show_ty_f_1739: crate::prelude::Text| k_let1633(crate::check::types::recording::err_fix_f(&st1_pa, &crate::prelude::Text::lit("time-in-update"), &target_p2x.span_p, &crate::prelude::Text::from(format!("`update` over a `{}`", &show_ty_f_1739)), &crate::prelude::Text::lit("update the plain value, and lift the function that does it"))))
                } else {
                    k_let1633(st1_pa.clone())
                }
            })
        })
    }
}

/// `Start InferUpdate, x`: what the function value is when passed to `@Run`.
pub fn start_infer_update_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, target_p2: crate::syntax::Expr, body_p3: crate::syntax::Block, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferUpdate { env_p0, st_p1, target_p2, body_p3, span_p4 })
}

/// ```prism
/// KeepsNonEmpty: unbounded fn Env, St, Expr, Expr -> St
/// ```
pub fn keeps_non_empty_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, target_p2: &crate::syntax::Expr, value_p3: &crate::syntax::Expr) -> crate::check::types::St {
    match &*target_p2.kind_p {
        crate::syntax::ExprKind::EGroup(x_p4) => keeps_non_empty_f(env_p0, st_p1, &**x_p4, value_p3),
        crate::syntax::ExprKind::EIndex(collection_p5, _) => {
            let (ct_p6, read_p7) = crate::check::expr::infer_f(env_p0, st_p1, &**collection_p5);
            match non_empty_map_o(&read_p7, &ct_p6) {
                ::std::option::Option::Some(_) => {
                    let shown_p8 = crate::check::types::show_ty_f(&read_p7, &ct_p6);
                    let plain_p9 = crate::prelude::Text::from(format!("update the plain map (`as` drops the promise) and check the result with `as {}?`", &shown_p8));
                    match set_value_f(value_p3) {
                        SetWritten::SetsPresent => st_p1.clone(),
                        SetWritten::SetsAbsent => crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("mismatch"), &value_p3.span_p, &crate::prelude::Text::from(format!("setting `nil` at a key removes it, and a `{}` is non-empty", &shown_p8)), &plain_p9),
                        SetWritten::SetsEither => crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("mismatch"), &value_p3.span_p, &crate::prelude::Text::from(format!("this may be `nil`, which set at a key removes it, and a `{}` is non-empty", &shown_p8)), &crate::prelude::Text::from(format!("write `? v` to set a value, or {}", &plain_p9))),
                    }
                },
                ::std::option::Option::None => st_p1.clone(),
            }
        },
        _ => st_p1.clone(),
    }
}

/// The step machine of `KeepsNonEmpty`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KeepsNonEmpty: unbounded fn Env, St, Expr, Expr -> St
/// ```
pub struct KeepsNonEmpty {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub target_p2: crate::syntax::Expr,
    pub value_p3: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::check::types::St> for KeepsNonEmpty {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let target_p2 = &self.target_p2;
        let value_p3 = &self.value_p3;
        match &*target_p2.kind_p {
            crate::syntax::ExprKind::EGroup(x_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(KeepsNonEmpty { env_p0: env_p0.clone(), st_p1: st_p1.clone(), target_p2: (**x_p4).clone(), value_p3: value_p3.clone() })),
            crate::syntax::ExprKind::EIndex(collection_p5, _) => {
                let collection_p5x = (**collection_p5).clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let value_p3x = value_p3.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), collection_p5x.clone()), move |infer_f_2728: (crate::check::types::Ty, crate::check::types::St)| {
                    let (ct_p6, read_p7) = infer_f_2728;
                    match non_empty_map_o(&read_p7, &ct_p6) {
                        ::std::option::Option::Some(_) => crate::prelude::call_then(crate::check::types::start_show_ty_f(read_p7.clone(), ct_p6.clone()), move |show_ty_f_2841: crate::prelude::Text| {
                            let shown_p8 = show_ty_f_2841;
                            let plain_p9 = crate::prelude::Text::from(format!("update the plain map (`as` drops the promise) and check the result with `as {}?`", &shown_p8));
                            match set_value_f(&value_p3x) {
                                SetWritten::SetsPresent => ::prism_rtl::Turn::Finished(st_p1x.clone()),
                                SetWritten::SetsAbsent => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("mismatch"), &value_p3x.span_p, &crate::prelude::Text::from(format!("setting `nil` at a key removes it, and a `{}` is non-empty", &shown_p8)), &plain_p9)),
                                SetWritten::SetsEither => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("mismatch"), &value_p3x.span_p, &crate::prelude::Text::from(format!("this may be `nil`, which set at a key removes it, and a `{}` is non-empty", &shown_p8)), &crate::prelude::Text::from(format!("write `? v` to set a value, or {}", &plain_p9)))),
                            }
                        }),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(st_p1x.clone()),
                    }
                })
            },
            _ => ::prism_rtl::Turn::Finished(st_p1.clone()),
        }
    }
}

/// `Start KeepsNonEmpty, x`: what the function value is when passed to `@Run`.
pub fn start_keeps_non_empty_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, target_p2: crate::syntax::Expr, value_p3: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(KeepsNonEmpty { env_p0, st_p1, target_p2, value_p3 })
}

/// ```prism
/// ?NonEmptyMap: unbounded fn St, Ty -> ?Ty
/// ```
pub fn non_empty_map_o(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> ::std::option::Option<crate::check::types::Ty> {
    match crate::check::types::non_empty_coll_o(st_p0, t_p1) {
        ::std::option::Option::Some(c_p2) => match crate::check::types::recording::walk_f(st_p0, &c_p2) {
            crate::check::types::Ty::TyMap(_, _) => ::std::option::Option::Some(c_p2.clone()),
            _ => ::std::option::Option::None,
        },
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// SetValue: fn Expr -> SetWritten
/// ```
pub fn set_value_f(value_p0: &crate::syntax::Expr) -> SetWritten {
    match &*value_p0.kind_p {
        crate::syntax::ExprKind::EGroup(x_p1) => set_value_f(&**x_p1),
        crate::syntax::ExprKind::EFreeSigil(m3877_1_0, _) if (m3877_1_0 == &crate::prelude::Text::lit("?")) => SetWritten::SetsPresent,
        crate::syntax::ExprKind::ENil(_) => SetWritten::SetsAbsent,
        _ => SetWritten::SetsEither,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub fn update_stmts_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, stmts_p2: &crate::prelude::Array<crate::syntax::Stmt>) -> (crate::check::expr::Env, crate::check::types::St) {
    crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p2.clone(), (env_p0.clone(), st_p1.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (en_p3, s_p4) = p0;
        let stmt_p5 = p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdateStmt { env_p0: en_p3.clone(), st_p1: s_p4.clone(), s_p2: stmt_p5.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>))
}

/// The step machine of `UpdateStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub struct UpdateStmts {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub stmts_p2: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for UpdateStmts {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let stmts_p2 = &self.stmts_p2;
        crate::prelude::fold_job(stmts_p2.clone(), (env_p0.clone(), st_p1.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (en_p3, s_p4) = p0;
            let stmt_p5 = p1;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdateStmt { env_p0: en_p3.clone(), st_p1: s_p4.clone(), s_p2: stmt_p5.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>).cycle()
    }
}

/// `Start UpdateStmts, x`: what the function value is when passed to `@Run`.
pub fn start_update_stmts_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, stmts_p2: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(UpdateStmts { env_p0, st_p1, stmts_p2 })
}

/// ```prism
/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub fn update_stmt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, s_p2: &crate::syntax::Stmt) -> (crate::check::expr::Env, crate::check::types::St) {
    match &s_p2.kind_p {
        crate::syntax::StmtKind::SSet(target_p3, value_p4) => {
            let (tt_p6, st1_p7) = crate::check::expr::infer_f(env_p0, st_p1, target_p3);
            let st2_p5 = ref_target_f(env_p0, &st1_p7, target_p3);
            (env_p0.clone(), keeps_non_empty_f(env_p0, &crate::check::expr::check_f(env_p0, &st2_p5, value_p4, &tt_p6), target_p3, value_p4))
        },
        crate::syntax::StmtKind::SAccum(target_p8, op_p9, value_pa) => {
            let (tt_pf, st1_pg) = crate::check::expr::infer_f(env_p0, st_p1, target_p8);
            let st2_pb = ref_target_f(env_p0, &st1_pg, target_p8);
            let st3_pc = crate::check::expr::check_f(env_p0, &st2_pb, value_pa, &tt_pf);
            let st4_pd = crate::check::expr::add_want_f(&st3_pc, &crate::prelude::Text::lit("Prelude.Num"), &tt_pf, &s_p2.span_p);
            let st5_pe = if op_p9 == &crate::prelude::Text::lit("-=") {
                crate::check::expr::add_want_f(&st4_pd, &crate::prelude::Text::lit("Prelude.Sub"), &tt_pf, &s_p2.span_p)
            } else {
                st4_pd.clone()
            };
            (env_p0.clone(), st5_pe.clone())
        },
        crate::syntax::StmtKind::SLet(p_ph, ty_oi, e_pj) => {
            let (t_pl, st1_pm) = crate::check::expr::infer_f(env_p0, st_p1, e_pj);
            let st2_pk = match ty_oi {
                ::std::option::Option::Some(ty_pn) => {
                    let (at_po, s2_pp) = crate::check::env::reading::conv_type_f(&crate::check::expr::env_cx_f(env_p0), &st1_pm, ty_pn);
                    crate::check::types::unify::unify_f(&s2_pp, &at_po, &t_pl, &e_pj.span_p)
                },
                ::std::option::Option::None => st1_pm.clone(),
            };
            let (env2_pq, st3_pr) = crate::check::expr::patterns::bind_pattern_f(&crate::check::blocks::structure::unpending_f(env_p0), &st2_pk, p_ph, &t_pl, &false);
            (env2_pq.clone(), st3_pr.clone())
        },
        crate::syntax::StmtKind::SWhile(c_ps, body_pt) => (env_p0.clone(), update_while_f(env_p0, st_p1, c_ps, body_pt)),
        crate::syntax::StmtKind::SExpr(e_pu) => match &*e_pu.kind_p {
            crate::syntax::ExprKind::EIf(c_pv, then_b_p10, else_b_o11) => (env_p0.clone(), update_if_f(env_p0, st_p1, &**c_pv, then_b_p10, else_b_o11)),
            crate::syntax::ExprKind::EMatch(scrut_p12, arms_p13) => (env_p0.clone(), update_match_f(env_p0, st_p1, &**scrut_p12, arms_p13, &e_pu.span_p)),
            crate::syntax::ExprKind::EFor(binders_o14, source_p15, body_p16) => (env_p0.clone(), update_for_f(env_p0, st_p1, binders_o14, &**source_p15, body_p16, &e_pu.span_p)),
            crate::syntax::ExprKind::EBinary(m5194_3_0, left_p17, _) if (m5194_3_0 == &crate::prelude::Text::lit("<=")) => (env_p0.clone(), set_without_reference_f(env_p0, st_p1, &**left_p17)),
            _ => {
                let (t_p18, st1_p19) = crate::check::expr::infer_f(env_p0, st_p1, e_pu);
                (env_p0.clone(), crate::check::blocks::discarded_f(&st1_p19, &t_p18, &e_pu.span_p))
            },
            _ => unreachable!("no arm matched"),
        },
        crate::syntax::StmtKind::SFn(f_p1a) => {
            let (env1_p1b, st1_p1c) = crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2);
            crate::check::expr::lets::check_local_fn_f(&env1_p1b, &st1_p1c, &crate::prelude::Array::from(vec![f_p1a.clone()]), &s_p2.span_p)
        },
        crate::syntax::StmtKind::SSignature(_) => crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2),
        _ => (env_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &s_p2.span_p, &crate::prelude::Text::lit("this statement belongs in a widget or `given:` block"))),
    }
}

/// The step machine of `UpdateStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub struct UpdateStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub s_p2: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for UpdateStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let s_p2 = &self.s_p2;
        match &s_p2.kind_p {
            crate::syntax::StmtKind::SSet(target_p3, value_p4) => {
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let target_p3x = target_p3.clone();
                let value_p4x = value_p4.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), target_p3x.clone()), move |infer_f_4317: (crate::check::types::Ty, crate::check::types::St)| {
                    let (tt_p6, st1_p7) = infer_f_4317;
                    crate::prelude::call_then(start_ref_target_f(env_p0x.clone(), st1_p7.clone(), target_p3x.clone()), move |ref_target_f_4357: crate::check::types::St| {
                        let st2_p5 = ref_target_f_4357;
                        crate::prelude::call_then(crate::check::expr::start_check_f(env_p0x.clone(), st2_p5.clone(), value_p4x.clone(), tt_p6.clone()), move |check_f_4420: crate::check::types::St| crate::prelude::call_then(start_keeps_non_empty_f(env_p0x.clone(), check_f_4420, target_p3x.clone(), value_p4x.clone()), move |keeps_non_empty_f_4400: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), keeps_non_empty_f_4400))))
                    })
                })
            },
            crate::syntax::StmtKind::SAccum(target_p8, op_p9, value_pa) => {
                let env_p0x = env_p0.clone();
                let op_p9x = op_p9.clone();
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                let target_p8x = target_p8.clone();
                let value_pax = value_pa.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), target_p8x.clone()), move |infer_f_4521: (crate::check::types::Ty, crate::check::types::St)| {
                    let (tt_pf, st1_pg) = infer_f_4521;
                    crate::prelude::call_then(start_ref_target_f(env_p0x.clone(), st1_pg.clone(), target_p8x.clone()), move |ref_target_f_4561: crate::check::types::St| {
                        let st2_pb = ref_target_f_4561;
                        crate::prelude::call_then(crate::check::expr::start_check_f(env_p0x.clone(), st2_pb.clone(), value_pax.clone(), tt_pf.clone()), move |check_f_4606: crate::check::types::St| {
                            let st3_pc = check_f_4606;
                            let st4_pd = crate::check::expr::add_want_f(&st3_pc, &crate::prelude::Text::lit("Prelude.Num"), &tt_pf, &s_p2x.span_p);
                            let st5_pe = if &op_p9x == &crate::prelude::Text::lit("-=") {
                                crate::check::expr::add_want_f(&st4_pd, &crate::prelude::Text::lit("Prelude.Sub"), &tt_pf, &s_p2x.span_p)
                            } else {
                                st4_pd.clone()
                            };
                            ::prism_rtl::Turn::Finished((env_p0x.clone(), st5_pe.clone()))
                        })
                    })
                })
            },
            crate::syntax::StmtKind::SLet(p_ph, ty_oi, e_pj) => {
                let ty_oix = ty_oi.clone();
                let e_pjx = e_pj.clone();
                let env_p0x = env_p0.clone();
                let p_phx = p_ph.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_pjx.clone()), move |infer_f_4837: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pl, st1_pm) = infer_f_4837;
                    let env_p0xz = env_p0x.clone();
                    let p_phxz = p_phx.clone();
                    let t_plz = t_pl.clone();
                    let k_let4862 = move |v4862: crate::check::types::St| {
                        let st2_pk = v4862;
                        crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::blocks::structure::unpending_f(&env_p0xz), st2_pk.clone(), p_phxz.clone(), t_plz.clone(), false), move |bind_pattern_f_5053: (crate::check::expr::Env, crate::check::types::St)| {
                            let (env2_pq, st3_pr) = bind_pattern_f_5053;
                            ::prism_rtl::Turn::Finished((env2_pq.clone(), st3_pr.clone()))
                        })
                    };
                    match ty_oix.clone() {
                        ::std::option::Option::Some(ty_pn) => crate::prelude::call_then(crate::check::env::reading::start_conv_type_f(crate::check::expr::env_cx_f(&env_p0x), st1_pm.clone(), ty_pn.clone()), move |conv_type_f_4934: (crate::check::types::Ty, crate::check::types::St)| {
                            let (at_po, s2_pp) = conv_type_f_4934;
                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(s2_pp.clone(), at_po.clone(), t_pl.clone(), e_pjx.span_p.clone()), move |unify_f_4980: crate::check::types::St| k_let4862(unify_f_4980))
                        }),
                        ::std::option::Option::None => k_let4862(st1_pm.clone()),
                    }
                })
            },
            crate::syntax::StmtKind::SWhile(c_ps, body_pt) => {
                let body_ptx = body_pt.clone();
                let c_psx = c_ps.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_update_while_f(env_p0x.clone(), st_p1x.clone(), c_psx.clone(), body_ptx.clone()), move |update_while_f_5149: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), update_while_f_5149)))
            },
            crate::syntax::StmtKind::SExpr(e_pu) => match &*e_pu.kind_p {
                crate::syntax::ExprKind::EIf(c_pv, then_b_p10, else_b_o11) => {
                    let else_b_o11x = else_b_o11.clone();
                    let c_pvx = (**c_pv).clone();
                    let env_p0x = env_p0.clone();
                    let st_p1x = st_p1.clone();
                    let then_b_p10x = then_b_p10.clone();
                    crate::prelude::call_then(start_update_if_f(env_p0x.clone(), st_p1x.clone(), c_pvx.clone(), then_b_p10x.clone(), else_b_o11x.clone()), move |update_if_f_5246: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), update_if_f_5246)))
                },
                crate::syntax::ExprKind::EMatch(scrut_p12, arms_p13) => {
                    let arms_p13x = arms_p13.clone();
                    let e_pux = e_pu.clone();
                    let env_p0x = env_p0.clone();
                    let scrut_p12x = (**scrut_p12).clone();
                    let st_p1x = st_p1.clone();
                    crate::prelude::call_then(start_update_match_f(env_p0x.clone(), st_p1x.clone(), scrut_p12x.clone(), arms_p13x.clone(), e_pux.span_p.clone()), move |update_match_f_5320: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), update_match_f_5320)))
                },
                crate::syntax::ExprKind::EFor(binders_o14, source_p15, body_p16) => {
                    let binders_o14x = binders_o14.clone();
                    let body_p16x = body_p16.clone();
                    let e_pux = e_pu.clone();
                    let env_p0x = env_p0.clone();
                    let source_p15x = (**source_p15).clone();
                    let st_p1x = st_p1.clone();
                    crate::prelude::call_then(start_update_for_f(env_p0x.clone(), st_p1x.clone(), binders_o14x.clone(), source_p15x.clone(), body_p16x.clone(), e_pux.span_p.clone()), move |update_for_f_5409: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), update_for_f_5409)))
                },
                crate::syntax::ExprKind::EBinary(m5194_3_0, left_p17, _) if (m5194_3_0 == &crate::prelude::Text::lit("<=")) => {
                    let env_p0x = env_p0.clone();
                    let left_p17x = (**left_p17).clone();
                    let st_p1x = st_p1.clone();
                    crate::prelude::call_then(start_set_without_reference_f(env_p0x.clone(), st_p1x.clone(), left_p17x.clone()), move |set_without_reference_f_5722: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), set_without_reference_f_5722)))
                },
                _ => {
                    let e_pux = e_pu.clone();
                    let env_p0x = env_p0.clone();
                    let st_p1x = st_p1.clone();
                    crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_pux.clone()), move |infer_f_5807: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_p18, st1_p19) = infer_f_5807;
                        crate::prelude::call_then(crate::check::blocks::start_discarded_f(st1_p19.clone(), t_p18.clone(), e_pux.span_p.clone()), move |discarded_f_5844: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), discarded_f_5844)))
                    })
                },
                _ => unreachable!("no arm matched"),
            },
            crate::syntax::StmtKind::SFn(f_p1a) => {
                let env_p0x = env_p0.clone();
                let f_p1ax = f_p1a.clone();
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lets::start_pre_bind_f(env_p0x.clone(), st_p1x.clone(), s_p2x.clone()), move |pre_bind_f_5911: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env1_p1b, st1_p1c) = pre_bind_f_5911;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::lets::CheckLocalFn { env_p0: env1_p1b.clone(), st_p1: st1_p1c.clone(), clauses_p2: crate::prelude::Array::from(vec![f_p1ax.clone()]), span_p3: s_p2x.span_p.clone() }))
                })
            },
            crate::syntax::StmtKind::SSignature(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::lets::PreBind { env_p0: env_p0.clone(), st_p1: st_p1.clone(), s_p2: s_p2.clone() })),
            _ => ::prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &s_p2.span_p, &crate::prelude::Text::lit("this statement belongs in a widget or `given:` block")))),
        }
    }
}

/// `Start UpdateStmt, x`: what the function value is when passed to `@Run`.
pub fn start_update_stmt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, s_p2: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(UpdateStmt { env_p0, st_p1, s_p2 })
}

/// ```prism
/// RefTarget: unbounded fn Env, St, Expr -> St
/// ```
pub fn ref_target_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> crate::check::types::St {
    if is_ref_f(e_p2) {
        st_p1.clone()
    } else {
        crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("mismatch"), &e_p2.span_p, &crate::prelude::Text::lit("the left of `<=` is a reference: `&_`, a local `&x`, or a path from one"), &crate::prelude::Text::from(format!("write `&_.{}`, or make a local with `let &x = ...`", &crate::check::expr::src_text_f(env_p0, &e_p2.span_p))))
    }
}

/// The step machine of `RefTarget`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RefTarget: unbounded fn Env, St, Expr -> St
/// ```
pub struct RefTarget {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::check::types::St> for RefTarget {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let e_p2x = e_p2.clone();
        let env_p0x = env_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(start_is_ref_f(e_p2x.clone()), move |is_ref_f_6282: bool| if is_ref_f_6282 {
            ::prism_rtl::Turn::Finished(st_p1x.clone())
        } else {
            ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("mismatch"), &e_p2x.span_p, &crate::prelude::Text::lit("the left of `<=` is a reference: `&_`, a local `&x`, or a path from one"), &crate::prelude::Text::from(format!("write `&_.{}`, or make a local with `let &x = ...`", &crate::check::expr::src_text_f(&env_p0x, &e_p2x.span_p)))))
        })
    }
}

/// `Start RefTarget, x`: what the function value is when passed to `@Run`.
pub fn start_ref_target_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(RefTarget { env_p0, st_p1, e_p2 })
}

/// ```prism
/// SetWithoutReference: unbounded fn Env, St, Expr -> St
/// ```
pub fn set_without_reference_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, left_p2: &crate::syntax::Expr) -> crate::check::types::St {
    match bare_path_o(env_p0, left_p2) {
        ::std::option::Option::Some(bare_p3) => crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("mismatch"), &left_p2.span_p, &crate::prelude::Text::from(format!("a reference path writes its field steps bare; `{}` shows a field\'s stack", &crate::check::expr::src_text_f(env_p0, &left_p2.span_p))), &crate::prelude::Text::from(format!("write `{}`", &bare_p3))),
        ::std::option::Option::None => crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("mismatch"), &left_p2.span_p, &crate::prelude::Text::lit("the left of `<=` is a reference: `&_`, a local `&x`, or a path from one"), &crate::prelude::Text::lit("set a part of `&_`, or make a local with `let &x = ...`")),
    }
}

/// The step machine of `SetWithoutReference`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetWithoutReference: unbounded fn Env, St, Expr -> St
/// ```
pub struct SetWithoutReference {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub left_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::check::types::St> for SetWithoutReference {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let left_p2 = &self.left_p2;
        match bare_path_o(env_p0, left_p2) {
            ::std::option::Option::Some(bare_p3) => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("mismatch"), &left_p2.span_p, &crate::prelude::Text::from(format!("a reference path writes its field steps bare; `{}` shows a field\'s stack", &crate::check::expr::src_text_f(env_p0, &left_p2.span_p))), &crate::prelude::Text::from(format!("write `{}`", &bare_p3)))),
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("mismatch"), &left_p2.span_p, &crate::prelude::Text::lit("the left of `<=` is a reference: `&_`, a local `&x`, or a path from one"), &crate::prelude::Text::lit("set a part of `&_`, or make a local with `let &x = ...`"))),
        }
    }
}

/// `Start SetWithoutReference, x`: what the function value is when passed to `@Run`.
pub fn start_set_without_reference_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, left_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(SetWithoutReference { env_p0, st_p1, left_p2 })
}

/// ```prism
/// ?BarePath: unbounded fn Env, Expr -> ?Text
/// ```
pub fn bare_path_o(env_p0: &crate::check::expr::Env, e_p1: &crate::syntax::Expr) -> ::std::option::Option<crate::prelude::Text> {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::EName(n_p2) => if crate::syntax::lexer::chars::has_prefix_f(&n_p2.sigils_p, &crate::prelude::Text::lit("&")) {
            ::std::option::Option::Some(crate::check::expr::src_text_f(env_p0, &e_p1.span_p))
        } else {
            ::std::option::Option::None
        },
        crate::syntax::ExprKind::EField(r_p3, _, field_p4) => match bare_path_o(env_p0, &**r_p3) {
            ::std::option::Option::Some(root_p5) => ::std::option::Option::Some(crate::prelude::Text::from(format!("{}.{}", &root_p5, &field_p4.name_p))),
            ::std::option::Option::None => ::std::option::Option::None,
        },
        crate::syntax::ExprKind::EIndex(r_p6, index_p7) => match bare_path_o(env_p0, &**r_p6) {
            ::std::option::Option::Some(root_p8) => ::std::option::Option::Some(crate::prelude::Text::from(format!("{}[{}]", &root_p8, &crate::check::expr::src_text_f(env_p0, &index_p7.span_p)))),
            ::std::option::Option::None => ::std::option::Option::None,
        },
        crate::syntax::ExprKind::EGroup(x_p9) => bare_path_o(env_p0, &**x_p9),
        _ => match crate::check::env::lens_applied_o(e_p1) {
            ::std::option::Option::Some((_, argument_pa)) => match bare_path_o(env_p0, &argument_pa) {
                ::std::option::Option::Some(_) => ::std::option::Option::Some(crate::check::expr::src_text_f(env_p0, &e_p1.span_p)),
                ::std::option::Option::None => ::std::option::Option::None,
            },
            ::std::option::Option::None => ::std::option::Option::None,
        },
    }
}

/// ```prism
/// IsRef: unbounded fn Expr -> Bool
/// ```
pub fn is_ref_f(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::EName(n_p1) => crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &crate::prelude::Text::lit("&")),
        crate::syntax::ExprKind::EField(r_p2, _, _) => is_ref_f(&**r_p2),
        crate::syntax::ExprKind::EIndex(r_p3, _) => is_ref_f(&**r_p3),
        crate::syntax::ExprKind::EGroup(x_p4) => is_ref_f(&**x_p4),
        _ => match crate::check::env::lens_applied_o(e_p0) {
            ::std::option::Option::Some((_, argument_p5)) => is_ref_f(&argument_p5),
            ::std::option::Option::None => false,
        },
    }
}

/// The step machine of `IsRef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsRef: unbounded fn Expr -> Bool
/// ```
pub struct IsRef {
    pub e_p0: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for IsRef {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let e_p0 = &self.e_p0;
        match &*e_p0.kind_p {
            crate::syntax::ExprKind::EName(n_p1) => ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &crate::prelude::Text::lit("&"))),
            crate::syntax::ExprKind::EField(r_p2, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IsRef { e_p0: (**r_p2).clone() })),
            crate::syntax::ExprKind::EIndex(r_p3, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IsRef { e_p0: (**r_p3).clone() })),
            crate::syntax::ExprKind::EGroup(x_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IsRef { e_p0: (**x_p4).clone() })),
            _ => match crate::check::env::lens_applied_o(e_p0) {
                ::std::option::Option::Some((_, argument_p5)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IsRef { e_p0: argument_p5.clone() })),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
            },
        }
    }
}

/// `Start IsRef, x`: what the function value is when passed to `@Run`.
pub fn start_is_ref_f(e_p0: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsRef { e_p0 })
}

/// ```prism
/// CheckLens: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
/// ```
pub fn check_lens_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, name_p2: &crate::prelude::Text, clauses_p3: &crate::prelude::Array<crate::syntax::decls::FnClause>, sc_p4: &crate::check::types::Scheme, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    match &sc_p4.ty_p {
        crate::check::types::Ty::TyErr => st_p1.clone(),
        _ => {
            let env2_p6 = {
                let mut this: crate::check::expr::Env = env_p0.clone();
                this.in_update_p = true;
                this
            };
            let st1_p7 = crate::check::expr::lets::check_clauses_f(&env2_p6, st_p1, name_p2, clauses_p3, sc_p4, span_p5);
            let whole_p8 = match crate::check::types::schemes::skolemize_f(sc_p4) {
                crate::check::types::Ty::TyFn(_, params_pa, _) => crate::prelude::or(&crate::prelude::index(&params_pa, &crate::prelude::Nat::from(0u32)), &crate::check::types::Ty::TyErr),
                _ => crate::check::types::Ty::TyErr,
            };
            let st2_p9 = match crate::prelude::index(clauses_p3, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(c_pb) => lens_clause_f(&env2_p6, &st1_p7, &c_pb, &whole_p8),
                ::std::option::Option::None => st1_p7.clone(),
            };
            crate::prelude::fold(&crate::prelude::drop(clauses_p3, &crate::prelude::Nat::from(1u32)), &st2_p9, &(|s_pc: &crate::check::types::St, c_pd: &crate::syntax::decls::FnClause| crate::check::types::recording::err_fix_f(s_pc, &crate::prelude::Text::lit("lens-body"), &c_pd.span_p, &crate::prelude::Text::lit("a lens has one clause: its body is one path"), &crate::prelude::Text::lit("delete this clause"))))
        },
    }
}

/// The step machine of `CheckLens`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLens: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
/// ```
pub struct CheckLens {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub name_p2: crate::prelude::Text,
    pub clauses_p3: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub sc_p4: crate::check::types::Scheme,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for CheckLens {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let name_p2 = &self.name_p2;
        let clauses_p3 = &self.clauses_p3;
        let sc_p4 = &self.sc_p4;
        let span_p5 = &self.span_p5;
        match &sc_p4.ty_p {
            crate::check::types::Ty::TyErr => ::prism_rtl::Turn::Finished(st_p1.clone()),
            _ => {
                let env2_p6 = {
                    let mut this: crate::check::expr::Env = env_p0.clone();
                    this.in_update_p = true;
                    this
                };
                let clauses_p3x = clauses_p3.clone();
                let name_p2x = name_p2.clone();
                let sc_p4x = sc_p4.clone();
                let span_p5x = span_p5.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lets::start_check_clauses_f(env2_p6.clone(), st_p1x.clone(), name_p2x.clone(), clauses_p3x.clone(), sc_p4x.clone(), span_p5x.clone()), move |check_clauses_f_9216: crate::check::types::St| {
                    let st1_p7 = check_clauses_f_9216;
                    crate::prelude::call_then(crate::check::types::schemes::start_skolemize_f(sc_p4x.clone()), move |skolemize_f_9289: crate::check::types::Ty| {
                        let whole_p8 = match skolemize_f_9289 {
                            crate::check::types::Ty::TyFn(_, params_pa, _) => crate::prelude::or(&crate::prelude::index(&params_pa, &crate::prelude::Nat::from(0u32)), &crate::check::types::Ty::TyErr),
                            _ => crate::check::types::Ty::TyErr,
                        };
                        let clauses_p3xz = clauses_p3x.clone();
                        let k_let9401 = move |v9401: crate::check::types::St| {
                            let st2_p9 = v9401;
                            ::prism_rtl::Turn::Finished(crate::prelude::fold(&crate::prelude::drop(&clauses_p3xz, &crate::prelude::Nat::from(1u32)), &st2_p9, &(|s_pc: &crate::check::types::St, c_pd: &crate::syntax::decls::FnClause| crate::check::types::recording::err_fix_f(s_pc, &crate::prelude::Text::lit("lens-body"), &c_pd.span_p, &crate::prelude::Text::lit("a lens has one clause: its body is one path"), &crate::prelude::Text::lit("delete this clause")))))
                        };
                        match crate::prelude::index(&clauses_p3x, &crate::prelude::Nat::from(0u32)) {
                            ::std::option::Option::Some(c_pb) => crate::prelude::call_then(start_lens_clause_f(env2_p6.clone(), st1_p7.clone(), c_pb.clone(), whole_p8.clone()), move |lens_clause_f_9446: crate::check::types::St| k_let9401(lens_clause_f_9446)),
                            ::std::option::Option::None => k_let9401(st1_p7.clone()),
                        }
                    })
                })
            },
        }
    }
}

/// `Start CheckLens, x`: what the function value is when passed to `@Run`.
pub fn start_check_lens_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, name_p2: crate::prelude::Text, clauses_p3: crate::prelude::Array<crate::syntax::decls::FnClause>, sc_p4: crate::check::types::Scheme, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CheckLens { env_p0, st_p1, name_p2, clauses_p3, sc_p4, span_p5 })
}

/// ```prism
/// LensClause: unbounded fn Env, St, FnClause, Ty -> St
/// ```
pub fn lens_clause_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::syntax::decls::FnClause, whole_p3: &crate::check::types::Ty) -> crate::check::types::St {
    match crate::prelude::index(&c_p2.params_p, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(p_p4) => match lens_parameter_o(&p_p4) {
            ::std::option::Option::None => crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("lens-body"), &p_p4.span_p, &crate::prelude::Text::lit("a lens\'s parameter is a reference, written with `&`"), &crate::prelude::Text::from(format!("write `&{}`, and the body as a path from it", &crate::check::expr::src_text_f(env_p0, &p_p4.span_p)))),
            ::std::option::Option::Some(n_p5) => {
                let root_p6 = crate::check::env::sname_key_f(&n_p5);
                let wrong_p7 = crate::prelude::Text::from(format!("a lens\'s body is a reference from its parameter: a path from `{}`, or a lens applied to one", &root_p6));
                match &c_p2.body_p {
                    crate::syntax::decls::FnBody::BodyExpr(e_p8) => if is_ref_f(e_p8) && (&crate::prelude::take(&crate::check::passes::borrows::ref_path_f(e_p8), &crate::prelude::Nat::from(1u32)) == &crate::prelude::Array::from(vec![root_p6.clone()])) {
                        {
                            let (inside_p9, _) = crate::check::expr::patterns::bind_pattern_f(&crate::check::blocks::structure::unpending_f(env_p0), st_p1, &p_p4, whole_p3, &false);
                            lens_keys_f(&inside_p9, st_p1, e_p8, &true)
                        }
                    } else {
                        crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("lens-body"), &e_p8.span_p, &wrong_p7, &crate::prelude::Text::from(format!("write a path, `{}.field`", &root_p6)))
                    },
                    crate::syntax::decls::FnBody::BodyBlock(b_pa) => crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("lens-body"), &b_pa.span_p, &wrong_p7, &crate::prelude::Text::from(format!("write a path, `{}.field`", &root_p6))),
                }
            },
        },
        ::std::option::Option::None => st_p1.clone(),
    }
}

/// The step machine of `LensClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LensClause: unbounded fn Env, St, FnClause, Ty -> St
/// ```
pub struct LensClause {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::syntax::decls::FnClause,
    pub whole_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::St> for LensClause {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let whole_p3 = &self.whole_p3;
        match crate::prelude::index(&c_p2.params_p, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::Some(p_p4) => match lens_parameter_o(&p_p4) {
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("lens-body"), &p_p4.span_p, &crate::prelude::Text::lit("a lens\'s parameter is a reference, written with `&`"), &crate::prelude::Text::from(format!("write `&{}`, and the body as a path from it", &crate::check::expr::src_text_f(env_p0, &p_p4.span_p))))),
                ::std::option::Option::Some(n_p5) => {
                    let root_p6 = crate::check::env::sname_key_f(&n_p5);
                    let wrong_p7 = crate::prelude::Text::from(format!("a lens\'s body is a reference from its parameter: a path from `{}`, or a lens applied to one", &root_p6));
                    match &c_p2.body_p {
                        crate::syntax::decls::FnBody::BodyExpr(e_p8) => {
                            let e_p8x = e_p8.clone();
                            let env_p0x = env_p0.clone();
                            let st_p1x = st_p1.clone();
                            let whole_p3x = whole_p3.clone();
                            crate::prelude::call_then(start_is_ref_f(e_p8x.clone()), move |is_ref_f_10357: bool| if is_ref_f_10357 && (&crate::prelude::take(&crate::check::passes::borrows::ref_path_f(&e_p8x), &crate::prelude::Nat::from(1u32)) == &crate::prelude::Array::from(vec![root_p6.clone()])) {
                                crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::blocks::structure::unpending_f(&env_p0x), st_p1x.clone(), p_p4.clone(), whole_p3x.clone(), false), move |bind_pattern_f_10454: (crate::check::expr::Env, crate::check::types::St)| {
                                    let (inside_p9, _) = bind_pattern_f_10454;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(LensKeys { env_p0: inside_p9.clone(), st_p1: st_p1x.clone(), e_p2: e_p8x.clone(), last_p3: true }))
                                })
                            } else {
                                ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("lens-body"), &e_p8x.span_p, &wrong_p7, &crate::prelude::Text::from(format!("write a path, `{}.field`", &root_p6))))
                            })
                        },
                        crate::syntax::decls::FnBody::BodyBlock(b_pa) => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("lens-body"), &b_pa.span_p, &wrong_p7, &crate::prelude::Text::from(format!("write a path, `{}.field`", &root_p6)))),
                    }
                },
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(st_p1.clone()),
        }
    }
}

/// `Start LensClause, x`: what the function value is when passed to `@Run`.
pub fn start_lens_clause_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, c_p2: crate::syntax::decls::FnClause, whole_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(LensClause { env_p0, st_p1, c_p2, whole_p3 })
}

/// ```prism
/// ?LensParameter: fn Pattern -> ?SName
/// ```
pub fn lens_parameter_o(p_p0: &crate::syntax::Pattern) -> ::std::option::Option<crate::syntax::SName> {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p1) => if crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &crate::prelude::Text::lit("&")) && !crate::check::env::is_lens_name_f(n_p1) {
            ::std::option::Option::Some(n_p1.clone())
        } else {
            ::std::option::Option::None
        },
        crate::syntax::PatternKind::PGroup(q_p2) => lens_parameter_o(&**q_p2),
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// LensKeys: unbounded fn Env, St, Expr, Bool -> St
/// ```
pub fn lens_keys_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr, last_p3: &bool) -> crate::check::types::St {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EGroup(x_p4) => lens_keys_f(env_p0, st_p1, &**x_p4, last_p3),
        crate::syntax::ExprKind::EField(r_p5, _, _) => lens_keys_f(env_p0, st_p1, &**r_p5, &false),
        crate::syntax::ExprKind::EIndex(r_p6, _) => {
            let (ct_p8, read_p9) = crate::check::expr::infer_f(env_p0, st_p1, &**r_p6);
            let keyed_p7 = match crate::check::types::recording::walk_f(&read_p9, &crate::prelude::or(&crate::check::types::non_empty_coll_o(&read_p9, &ct_p8), &ct_p8)) {
                crate::check::types::Ty::TyMap(_, _) => true,
                crate::check::types::Ty::TyCon(m11677_1_0, _) if (&m11677_1_0 == &crate::prelude::Text::lit("Table")) => true,
                _ => false,
                _ => unreachable!("no arm matched"),
            };
            if keyed_p7 {
                crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("lens-map-key"), &e_p2.span_p, &crate::prelude::Text::from(format!("a named lens cannot {} a map key: a key\'s part is an entry, not a location", &(if *last_p3 {
                    crate::prelude::Text::lit("end at")
                } else {
                    crate::prelude::Text::lit("step through")
                }))), &crate::prelude::Text::lit("write the path in the `update` block"))
            } else {
                lens_keys_f(env_p0, st_p1, &**r_p6, &false)
            }
        },
        _ => match crate::check::env::lens_applied_o(e_p2) {
            ::std::option::Option::Some((_, argument_pa)) => lens_keys_f(env_p0, st_p1, &argument_pa, &false),
            ::std::option::Option::None => st_p1.clone(),
        },
    }
}

/// The step machine of `LensKeys`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LensKeys: unbounded fn Env, St, Expr, Bool -> St
/// ```
pub struct LensKeys {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
    pub last_p3: bool,
}

impl ::prism_rtl::Job<crate::check::types::St> for LensKeys {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        let last_p3 = &self.last_p3;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EGroup(x_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LensKeys { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: (**x_p4).clone(), last_p3: *last_p3 })),
            crate::syntax::ExprKind::EField(r_p5, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LensKeys { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: (**r_p5).clone(), last_p3: false })),
            crate::syntax::ExprKind::EIndex(r_p6, _) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let last_p3x = *last_p3;
                let r_p6x = (**r_p6).clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), r_p6x.clone()), move |infer_f_11640: (crate::check::types::Ty, crate::check::types::St)| {
                    let (ct_p8, read_p9) = infer_f_11640;
                    crate::prelude::call_then(crate::check::types::start_non_empty_coll_o(read_p9.clone(), ct_p8.clone()), move |non_empty_coll_o_11699: ::std::option::Option<crate::check::types::Ty>| crate::prelude::call_then(crate::check::types::recording::start_walk_f(read_p9.clone(), crate::prelude::or(&non_empty_coll_o_11699, &ct_p8)), move |walk_f_11683: crate::check::types::Ty| {
                        let keyed_p7 = match walk_f_11683 {
                            crate::check::types::Ty::TyMap(_, _) => true,
                            crate::check::types::Ty::TyCon(m11677_1_0, _) if (&m11677_1_0 == &crate::prelude::Text::lit("Table")) => true,
                            _ => false,
                            _ => unreachable!("no arm matched"),
                        };
                        if keyed_p7 {
                            ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("lens-map-key"), &e_p2x.span_p, &crate::prelude::Text::from(format!("a named lens cannot {} a map key: a key\'s part is an entry, not a location", &(if last_p3x {
                                crate::prelude::Text::lit("end at")
                            } else {
                                crate::prelude::Text::lit("step through")
                            }))), &crate::prelude::Text::lit("write the path in the `update` block")))
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(LensKeys { env_p0: env_p0x.clone(), st_p1: st_p1x.clone(), e_p2: r_p6x.clone(), last_p3: false }))
                        }
                    }))
                })
            },
            _ => match crate::check::env::lens_applied_o(e_p2) {
                ::std::option::Option::Some((_, argument_pa)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LensKeys { env_p0: env_p0.clone(), st_p1: st_p1.clone(), e_p2: argument_pa.clone(), last_p3: false })),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(st_p1.clone()),
            },
        }
    }
}

/// `Start LensKeys, x`: what the function value is when passed to `@Run`.
pub fn start_lens_keys_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr, last_p3: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(LensKeys { env_p0, st_p1, e_p2, last_p3 })
}

/// ```prism
/// LensArgument: unbounded fn Env, St, Expr -> St
/// ```
pub fn lens_argument_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, e_p2: &crate::syntax::Expr) -> crate::check::types::St {
    match crate::check::env::lens_applied_o(e_p2) {
        ::std::option::Option::Some((n_p3, argument_p4)) => if is_ref_f(&argument_p4) {
            st_p1.clone()
        } else {
            crate::check::types::recording::err_fix_f(st_p1, &crate::prelude::Text::lit("lens-argument"), &e_p2.span_p, &crate::prelude::Text::from(format!("the lens `{}` is applied to a reference, and `{}` is a plain value", &crate::check::env::sname_key_f(&n_p3), &crate::check::expr::src_text_f(env_p0, &argument_p4.span_p))), &crate::prelude::Text::lit("apply it in an `update` block, to `&_`, a local `&x`, or a path from one"))
        },
        ::std::option::Option::None => st_p1.clone(),
    }
}

/// The step machine of `LensArgument`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LensArgument: unbounded fn Env, St, Expr -> St
/// ```
pub struct LensArgument {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::check::types::St> for LensArgument {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let e_p2 = &self.e_p2;
        match crate::check::env::lens_applied_o(e_p2) {
            ::std::option::Option::Some((n_p3, argument_p4)) => {
                let e_p2x = e_p2.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(start_is_ref_f(argument_p4.clone()), move |is_ref_f_12467: bool| if is_ref_f_12467 {
                    ::prism_rtl::Turn::Finished(st_p1x.clone())
                } else {
                    ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&st_p1x, &crate::prelude::Text::lit("lens-argument"), &e_p2x.span_p, &crate::prelude::Text::from(format!("the lens `{}` is applied to a reference, and `{}` is a plain value", &crate::check::env::sname_key_f(&n_p3), &crate::check::expr::src_text_f(&env_p0x, &argument_p4.span_p))), &crate::prelude::Text::lit("apply it in an `update` block, to `&_`, a local `&x`, or a path from one")))
                })
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(st_p1.clone()),
        }
    }
}

/// `Start LensArgument, x`: what the function value is when passed to `@Run`.
pub fn start_lens_argument_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(LensArgument { env_p0, st_p1, e_p2 })
}

/// ```prism
/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
/// ```
pub fn update_if_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::syntax::Cond, then_b_p3: &crate::syntax::Block, else_b_o4: &::std::option::Option<crate::syntax::Block>) -> crate::check::types::St {
    let (env2_pe, st1_pf) = match c_p2 {
        crate::syntax::Cond::CondExpr(e_p5) => (env_p0.clone(), crate::check::expr::lifting::check_cond_f(env_p0, st_p1, &**e_p5)),
        crate::syntax::Cond::CondBind(p_p6, e_p7, gd_o8) => {
            let (et_p9, s1_pa) = crate::check::expr::infer_f(env_p0, st_p1, &**e_p7);
            let (en_pb, s2_pc) = crate::check::expr::patterns::bind_pattern_f(&crate::check::blocks::structure::unpending_f(env_p0), &s1_pa, p_p6, &et_p9, &true);
            match &**gd_o8 {
                ::std::option::Option::Some(g_pd) => (en_pb.clone(), crate::check::expr::lifting::check_cond_f(&en_pb, &s2_pc, g_pd)),
                ::std::option::Option::None => (en_pb.clone(), s2_pc.clone()),
            }
        },
    };
    let (_, st2_pg) = update_stmts_f(&env2_pe, &st1_pf, &then_b_p3.stmts_p);
    match else_b_o4 {
        ::std::option::Option::Some(b_ph) => {
            let (_, st3_pi) = update_stmts_f(env_p0, &st2_pg, &b_ph.stmts_p);
            st3_pi.clone()
        },
        ::std::option::Option::None => st2_pg.clone(),
    }
}

/// The step machine of `UpdateIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
/// ```
pub struct UpdateIf {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::syntax::Cond,
    pub then_b_p3: crate::syntax::Block,
    pub else_b_o4: ::std::option::Option<crate::syntax::Block>,
}

impl ::prism_rtl::Job<crate::check::types::St> for UpdateIf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let then_b_p3 = &self.then_b_p3;
        let else_b_o4 = &self.else_b_o4;
        let else_b_o4z = else_b_o4.clone();
        let env_p0z = env_p0.clone();
        let then_b_p3z = then_b_p3.clone();
        let k_let12831 = move |v12831: (crate::check::expr::Env, crate::check::types::St)| {
            let (env2_pe, st1_pf) = v12831;
            crate::prelude::call_then(start_update_stmts_f(env2_pe.clone(), st1_pf.clone(), then_b_p3z.stmts_p.clone()), move |update_stmts_f_13192: (crate::check::expr::Env, crate::check::types::St)| {
                let (_, st2_pg) = update_stmts_f_13192;
                match &else_b_o4z {
                    ::std::option::Option::Some(b_ph) => {
                        let b_phx = b_ph.clone();
                        crate::prelude::call_then(start_update_stmts_f(env_p0z.clone(), st2_pg.clone(), b_phx.stmts_p.clone()), move |update_stmts_f_13292: (crate::check::expr::Env, crate::check::types::St)| {
                            let (_, st3_pi) = update_stmts_f_13292;
                            ::prism_rtl::Turn::Finished(st3_pi.clone())
                        })
                    },
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(st2_pg.clone()),
                }
            })
        };
        match c_p2.clone() {
            crate::syntax::Cond::CondExpr(e_p5) => {
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lifting::start_check_cond_f(env_p0x.clone(), st_p1x.clone(), (*e_p5).clone()), move |check_cond_f_12888: crate::check::types::St| k_let12831((env_p0x.clone(), check_cond_f_12888)))
            },
            crate::syntax::Cond::CondBind(p_p6, e_p7, gd_o8) => {
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), (*e_p7).clone()), move |infer_f_12969: (crate::check::types::Ty, crate::check::types::St)| {
                    let (et_p9, s1_pa) = infer_f_12969;
                    crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::blocks::structure::unpending_f(&env_p0x), s1_pa.clone(), p_p6.clone(), et_p9.clone(), true), move |bind_pattern_f_13015: (crate::check::expr::Env, crate::check::types::St)| {
                        let (en_pb, s2_pc) = bind_pattern_f_13015;
                        match (*gd_o8).clone() {
                            ::std::option::Option::Some(g_pd) => crate::prelude::call_then(crate::check::expr::lifting::start_check_cond_f(en_pb.clone(), s2_pc.clone(), g_pd.clone()), move |check_cond_f_13111: crate::check::types::St| k_let12831((en_pb.clone(), check_cond_f_13111))),
                            ::std::option::Option::None => k_let12831((en_pb.clone(), s2_pc.clone())),
                        }
                    })
                })
            },
        }
    }
}

/// `Start UpdateIf, x`: what the function value is when passed to `@Run`.
pub fn start_update_if_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, c_p2: crate::syntax::Cond, then_b_p3: crate::syntax::Block, else_b_o4: ::std::option::Option<crate::syntax::Block>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(UpdateIf { env_p0, st_p1, c_p2, then_b_p3, else_b_o4 })
}

/// ```prism
/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
/// ```
pub fn update_match_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, scrut_p2: &crate::syntax::Expr, arms_p3: &crate::prelude::Array<crate::syntax::Arm>, span_p4: &crate::syntax::Range) -> crate::check::types::St {
    let (t_p6, st1_p7) = crate::check::expr::infer_f(env_p0, st_p1, scrut_p2);
    let st2_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(arms_p3.clone(), st1_p7.clone(), {
        let env_p0x = env_p0.clone();
        let t_p6x = t_p6.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
            let env_p0xy = env_p0x.clone();
            let t_p6xy = t_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p8 = p0;
                let arm_p9 = p1;
                {
                    let arm_p9z = arm_p9.clone();
                    let k_let13549 = move |v13549: (crate::check::expr::Env, crate::check::types::St)| {
                        let (env2_pc, s1_pd) = v13549;
                        let arm_p9zz = arm_p9z.clone();
                        let env2_pcz = env2_pc.clone();
                        let k_let13684 = move |v13684: crate::check::types::St| {
                            let s2_pa = v13684;
                            crate::prelude::call_then(start_update_stmts_f(env2_pcz.clone(), s2_pa.clone(), arm_p9zz.body_p.stmts_p.clone()), move |update_stmts_f_13801: (crate::check::expr::Env, crate::check::types::St)| {
                                let (_, s3_pf) = update_stmts_f_13801;
                                ::prism_rtl::Turn::Finished(s3_pf.clone())
                            })
                        };
                        match arm_p9z.guard_o.clone() {
                            ::std::option::Option::Some(gd_pe) => crate::prelude::call_then(crate::check::expr::lifting::start_check_cond_f(env2_pc.clone(), s1_pd.clone(), gd_pe.clone()), move |check_cond_f_13729: crate::check::types::St| k_let13684(check_cond_f_13729)),
                            ::std::option::Option::None => k_let13684(s1_pd.clone()),
                        }
                    };
                    match arm_p9.pattern_o.clone() {
                        ::std::option::Option::Some(p_pb) => crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::blocks::structure::unpending_f(&env_p0xy), s_p8.clone(), p_pb.clone(), t_p6xy.clone(), true), move |bind_pattern_f_13605: (crate::check::expr::Env, crate::check::types::St)| k_let13549(bind_pattern_f_13605)),
                        ::std::option::Option::None => k_let13549((env_p0xy.clone(), s_p8.clone())),
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }));
    crate::check::passes::match_coverage_f(env_p0, &st2_p5, &t_p6, arms_p3, span_p4)
}

/// The step machine of `UpdateMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
/// ```
pub struct UpdateMatch {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub scrut_p2: crate::syntax::Expr,
    pub arms_p3: crate::prelude::Array<crate::syntax::Arm>,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for UpdateMatch {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let scrut_p2 = &self.scrut_p2;
        let arms_p3 = &self.arms_p3;
        let span_p4 = &self.span_p4;
        let arms_p3x = arms_p3.clone();
        let env_p0x = env_p0.clone();
        let scrut_p2x = scrut_p2.clone();
        let span_p4x = span_p4.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), scrut_p2x.clone()), move |infer_f_13480: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p6, st1_p7) = infer_f_13480;
            crate::prelude::call_value(crate::prelude::fold_job(arms_p3x.clone(), st1_p7.clone(), {
                let env_p0xx = env_p0x.clone();
                let t_p6x = t_p6.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                    let env_p0xxy = env_p0xx.clone();
                    let t_p6xy = t_p6x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_p8 = p0;
                        let arm_p9 = p1;
                        {
                            let arm_p9z = arm_p9.clone();
                            let k_let13549 = move |v13549: (crate::check::expr::Env, crate::check::types::St)| {
                                let (env2_pc, s1_pd) = v13549;
                                let arm_p9zz = arm_p9z.clone();
                                let env2_pcz = env2_pc.clone();
                                let k_let13684 = move |v13684: crate::check::types::St| {
                                    let s2_pa = v13684;
                                    crate::prelude::call_then(start_update_stmts_f(env2_pcz.clone(), s2_pa.clone(), arm_p9zz.body_p.stmts_p.clone()), move |update_stmts_f_13801: (crate::check::expr::Env, crate::check::types::St)| {
                                        let (_, s3_pf) = update_stmts_f_13801;
                                        ::prism_rtl::Turn::Finished(s3_pf.clone())
                                    })
                                };
                                match arm_p9z.guard_o.clone() {
                                    ::std::option::Option::Some(gd_pe) => crate::prelude::call_then(crate::check::expr::lifting::start_check_cond_f(env2_pc.clone(), s1_pd.clone(), gd_pe.clone()), move |check_cond_f_13729: crate::check::types::St| k_let13684(check_cond_f_13729)),
                                    ::std::option::Option::None => k_let13684(s1_pd.clone()),
                                }
                            };
                            match arm_p9.pattern_o.clone() {
                                ::std::option::Option::Some(p_pb) => crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::blocks::structure::unpending_f(&env_p0xxy), s_p8.clone(), p_pb.clone(), t_p6xy.clone(), true), move |bind_pattern_f_13605: (crate::check::expr::Env, crate::check::types::St)| k_let13549(bind_pattern_f_13605)),
                                ::std::option::Option::None => k_let13549((env_p0xxy.clone(), s_p8.clone())),
                            }
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
            }), move |fold_13515: crate::check::types::St| {
                let st2_p5 = fold_13515;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::passes::MatchCoverage { env_p0: env_p0x.clone(), st_p1: st2_p5.clone(), t_p2: t_p6.clone(), arms_p3: arms_p3x.clone(), span_p4: span_p4x.clone() }))
            })
        })
    }
}

/// `Start UpdateMatch, x`: what the function value is when passed to `@Run`.
pub fn start_update_match_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, scrut_p2: crate::syntax::Expr, arms_p3: crate::prelude::Array<crate::syntax::Arm>, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(UpdateMatch { env_p0, st_p1, scrut_p2, arms_p3, span_p4 })
}

/// ```prism
/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
/// ```
pub fn update_while_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, c_p2: &crate::syntax::Cond, body_p3: &crate::syntax::Block) -> crate::check::types::St {
    let (env2_pd, st1_pe) = match c_p2 {
        crate::syntax::Cond::CondExpr(e_p4) => (env_p0.clone(), crate::check::expr::lifting::check_cond_f(env_p0, st_p1, &**e_p4)),
        crate::syntax::Cond::CondBind(p_p5, e_p6, gd_o7) => {
            let (et_p8, s1_p9) = crate::check::expr::infer_f(env_p0, st_p1, &**e_p6);
            let (en_pa, s2_pb) = crate::check::expr::patterns::bind_pattern_f(&crate::check::blocks::structure::unpending_f(env_p0), &s1_p9, p_p5, &et_p8, &true);
            match &**gd_o7 {
                ::std::option::Option::Some(g_pc) => (en_pa.clone(), crate::check::expr::lifting::check_cond_f(&en_pa, &s2_pb, g_pc)),
                ::std::option::Option::None => (en_pa.clone(), s2_pb.clone()),
            }
        },
    };
    let (_, st2_pf) = update_stmts_f(&env2_pd, &st1_pe, &body_p3.stmts_p);
    st2_pf.clone()
}

/// The step machine of `UpdateWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
/// ```
pub struct UpdateWhile {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub c_p2: crate::syntax::Cond,
    pub body_p3: crate::syntax::Block,
}

impl ::prism_rtl::Job<crate::check::types::St> for UpdateWhile {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let c_p2 = &self.c_p2;
        let body_p3 = &self.body_p3;
        let body_p3z = body_p3.clone();
        let k_let14075 = move |v14075: (crate::check::expr::Env, crate::check::types::St)| {
            let (env2_pd, st1_pe) = v14075;
            crate::prelude::call_then(start_update_stmts_f(env2_pd.clone(), st1_pe.clone(), body_p3z.stmts_p.clone()), move |update_stmts_f_14436: (crate::check::expr::Env, crate::check::types::St)| {
                let (_, st2_pf) = update_stmts_f_14436;
                ::prism_rtl::Turn::Finished(st2_pf.clone())
            })
        };
        match c_p2.clone() {
            crate::syntax::Cond::CondExpr(e_p4) => {
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lifting::start_check_cond_f(env_p0x.clone(), st_p1x.clone(), (*e_p4).clone()), move |check_cond_f_14132: crate::check::types::St| k_let14075((env_p0x.clone(), check_cond_f_14132)))
            },
            crate::syntax::Cond::CondBind(p_p5, e_p6, gd_o7) => {
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), (*e_p6).clone()), move |infer_f_14213: (crate::check::types::Ty, crate::check::types::St)| {
                    let (et_p8, s1_p9) = infer_f_14213;
                    crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::blocks::structure::unpending_f(&env_p0x), s1_p9.clone(), p_p5.clone(), et_p8.clone(), true), move |bind_pattern_f_14259: (crate::check::expr::Env, crate::check::types::St)| {
                        let (en_pa, s2_pb) = bind_pattern_f_14259;
                        match (*gd_o7).clone() {
                            ::std::option::Option::Some(g_pc) => crate::prelude::call_then(crate::check::expr::lifting::start_check_cond_f(en_pa.clone(), s2_pb.clone(), g_pc.clone()), move |check_cond_f_14355: crate::check::types::St| k_let14075((en_pa.clone(), check_cond_f_14355))),
                            ::std::option::Option::None => k_let14075((en_pa.clone(), s2_pb.clone())),
                        }
                    })
                })
            },
        }
    }
}

/// `Start UpdateWhile, x`: what the function value is when passed to `@Run`.
pub fn start_update_while_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, c_p2: crate::syntax::Cond, body_p3: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(UpdateWhile { env_p0, st_p1, c_p2, body_p3 })
}

/// ```prism
/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
/// ```
pub fn update_for_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, binders_o2: &::std::option::Option<crate::syntax::ForBinders>, source_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range) -> crate::check::types::St {
    let (t_p7, st1_p8) = crate::check::expr::infer_f(env_p0, st_p1, source_p3);
    let (k_p9, v_pa, st2_pb) = crate::check::blocks::structure::coll_parts_f(&st1_p8, &t_p7, &source_p3.span_p);
    let env1_p6 = crate::check::blocks::structure::loop_indices_f(env_p0);
    let (env2_pk, st3_pl) = match binders_o2 {
        ::std::option::Option::None => (crate::check::blocks::structure::with_topic_f(&crate::check::blocks::structure::with_topic_f(&env1_p6, &crate::prelude::Text::lit("&_"), &v_pa), &crate::prelude::Text::lit("key"), &k_p9), st2_pb.clone()),
        ::std::option::Option::Some(bs_pc) => match &bs_pc.second_o {
            ::std::option::Option::Some(second_pd) => {
                let (e1_pe, s1_pf) = crate::check::expr::patterns::bind_pattern_f(&crate::check::blocks::structure::unpending_f(&env1_p6), &st2_pb, &bs_pc.first_p, &k_p9, &false);
                let (e2_pg, s2_ph) = crate::check::expr::patterns::bind_pattern_f(&e1_pe, &crate::check::blocks::structure::for_binder_matches_f(env_p0, &s1_pf, &bs_pc.first_p, &k_p9), second_pd, &v_pa, &false);
                (e2_pg.clone(), crate::check::blocks::structure::for_binder_matches_f(env_p0, &s2_ph, second_pd, &v_pa))
            },
            ::std::option::Option::None => {
                let (e2_pi, s2_pj) = crate::check::expr::patterns::bind_pattern_f(&crate::check::blocks::structure::unpending_f(&crate::check::blocks::structure::with_topic_f(&env1_p6, &crate::prelude::Text::lit("key"), &k_p9)), &st2_pb, &bs_pc.first_p, &v_pa, &false);
                (e2_pi.clone(), crate::check::blocks::structure::for_binder_matches_f(env_p0, &s2_pj, &bs_pc.first_p, &v_pa))
            },
        },
    };
    let (_, st4_pm) = update_stmts_f(&env2_pk, &st3_pl, &body_p4.stmts_p);
    st4_pm.clone()
}

/// The step machine of `UpdateFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
/// ```
pub struct UpdateFor {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub binders_o2: ::std::option::Option<crate::syntax::ForBinders>,
    pub source_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for UpdateFor {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let binders_o2 = &self.binders_o2;
        let source_p3 = &self.source_p3;
        let body_p4 = &self.body_p4;
        let span_p5 = &self.span_p5;
        let binders_o2x = binders_o2.clone();
        let body_p4x = body_p4.clone();
        let env_p0x = env_p0.clone();
        let source_p3x = source_p3.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), source_p3x.clone()), move |infer_f_14889: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p7, st1_p8) = infer_f_14889;
            crate::prelude::call_then(crate::check::blocks::structure::start_coll_parts_f(st1_p8.clone(), t_p7.clone(), source_p3x.span_p.clone()), move |coll_parts_f_14935: (crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)| {
                let (k_p9, v_pa, st2_pb) = coll_parts_f_14935;
                let env1_p6 = crate::check::blocks::structure::loop_indices_f(&env_p0x);
                let body_p4xz = body_p4x.clone();
                let k_let15000 = move |v15000: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2_pk, st3_pl) = v15000;
                    crate::prelude::call_then(start_update_stmts_f(env2_pk.clone(), st3_pl.clone(), body_p4xz.stmts_p.clone()), move |update_stmts_f_15632: (crate::check::expr::Env, crate::check::types::St)| {
                        let (_, st4_pm) = update_stmts_f_15632;
                        ::prism_rtl::Turn::Finished(st4_pm.clone())
                    })
                };
                match binders_o2x.clone() {
                    ::std::option::Option::None => k_let15000((crate::check::blocks::structure::with_topic_f(&crate::check::blocks::structure::with_topic_f(&env1_p6, &crate::prelude::Text::lit("&_"), &v_pa), &crate::prelude::Text::lit("key"), &k_p9), st2_pb.clone())),
                    ::std::option::Option::Some(bs_pc) => match bs_pc.second_o.clone() {
                        ::std::option::Option::Some(second_pd) => crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::blocks::structure::unpending_f(&env1_p6), st2_pb.clone(), bs_pc.first_p.clone(), k_p9.clone(), false), move |bind_pattern_f_15193: (crate::check::expr::Env, crate::check::types::St)| {
                            let (e1_pe, s1_pf) = bind_pattern_f_15193;
                            crate::prelude::call_then(crate::check::blocks::structure::start_for_binder_matches_f(env_p0x.clone(), s1_pf.clone(), bs_pc.first_p.clone(), k_p9.clone()), move |for_binder_matches_f_15297: crate::check::types::St| crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(e1_pe.clone(), for_binder_matches_f_15297, second_pd.clone(), v_pa.clone(), false), move |bind_pattern_f_15280: (crate::check::expr::Env, crate::check::types::St)| {
                                let (e2_pg, s2_ph) = bind_pattern_f_15280;
                                crate::prelude::call_then(crate::check::blocks::structure::start_for_binder_matches_f(env_p0x.clone(), s2_ph.clone(), second_pd.clone(), v_pa.clone()), move |for_binder_matches_f_15377: crate::check::types::St| k_let15000((e2_pg.clone(), for_binder_matches_f_15377)))
                            }))
                        }),
                        ::std::option::Option::None => crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(crate::check::blocks::structure::unpending_f(&crate::check::blocks::structure::with_topic_f(&env1_p6, &crate::prelude::Text::lit("key"), &k_p9)), st2_pb.clone(), bs_pc.first_p.clone(), v_pa.clone(), false), move |bind_pattern_f_15466: (crate::check::expr::Env, crate::check::types::St)| {
                            let (e2_pi, s2_pj) = bind_pattern_f_15466;
                            crate::prelude::call_then(crate::check::blocks::structure::start_for_binder_matches_f(env_p0x.clone(), s2_pj.clone(), bs_pc.first_p.clone(), v_pa.clone()), move |for_binder_matches_f_15565: crate::check::types::St| k_let15000((e2_pi.clone(), for_binder_matches_f_15565)))
                        }),
                    },
                }
            })
        })
    }
}

/// `Start UpdateFor, x`: what the function value is when passed to `@Run`.
pub fn start_update_for_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, binders_o2: ::std::option::Option<crate::syntax::ForBinders>, source_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(UpdateFor { env_p0, st_p1, binders_o2, source_p3, body_p4, span_p5 })
}
