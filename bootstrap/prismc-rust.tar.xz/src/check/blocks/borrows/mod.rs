//! The module `Check.Blocks.Borrows`, from `target/bootstrap/src/prismc/check/blocks/borrows.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_update(env: &crate::check::expr::Env, st: &crate::check::types::St, target: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t, st1) = crate::check::expr::infer(env, st, target);
    let sh = crate::check::types::head_sigil(&st1, &t);
    let st2 = if crate::check::expr::is_time_sigil(&sh) || (&sh == &Text::lit("@")) {
        crate::check::types::recording::err_fix(&st1, &Text::lit("time-in-update"), &target.span, &Text::from(format!("`update` over a `{}`", &crate::check::types::show_ty(&st1, &t))), &Text::lit("update the plain value, and lift the function that does it"))
    } else {
        st1.clone()
    };
    let env2 = {
        let mut this: crate::check::expr::Env = crate::check::blocks::structure::with_topic(env, &Text::lit("&_"), &t);
        this.in_update = true;
        this
    };
    let (_, st3) = update_stmts(&env2, &st2, &body.stmts);
    let st4 = crate::check::passes::borrows::and_block_checks(&env2, &st3, body, &t);
    (t.clone(), st4.clone())
}

/// The step machine of `InferUpdate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferUpdate {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub target: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferUpdate {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let target = &self.target;
        let body = &self.body;
        let span = &self.span;
        let body = body.clone();
        let env = env.clone();
        let span = span.clone();
        let st = st.clone();
        let target = target.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), target.clone()), move |infer_1577: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st1) = infer_1577;
            call_then(crate::check::types::start_head_sigil(st1.clone(), t.clone()), move |head_sigil_1612: Text| {
                let sh = head_sigil_1612;
                let st2 = if crate::check::expr::is_time_sigil(&sh) || (&sh == &Text::lit("@")) {
                    crate::check::types::recording::err_fix(&st1, &Text::lit("time-in-update"), &target.span, &Text::from(format!("`update` over a `{}`", &crate::check::types::show_ty(&st1, &t))), &Text::lit("update the plain value, and lift the function that does it"))
                } else {
                    st1.clone()
                };
                let env2 = {
                    let mut this: crate::check::expr::Env = crate::check::blocks::structure::with_topic(&env, &Text::lit("&_"), &t);
                    this.in_update = true;
                    this
                };
                call_then(start_update_stmts(env2.clone(), st2.clone(), body.stmts.clone()), move |update_stmts_1930: (crate::check::expr::Env, crate::check::types::St)| {
                    let (_, st3) = update_stmts_1930;
                    call_then(crate::check::passes::borrows::start_and_block_checks(env2.clone(), st3.clone(), body.clone(), t.clone()), move |and_block_checks_1978: crate::check::types::St| {
                        let st4 = and_block_checks_1978;
                        prism_rtl::Turn::Finished((t.clone(), st4.clone()))
                    })
                })
            })
        })
    }
}

/// `Start InferUpdate, x`: what the function value is when passed to `@Run`.
pub fn start_infer_update(env: crate::check::expr::Env, st: crate::check::types::St, target: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferUpdate { env, st, target, body, span })
}

/// ```prism
/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub fn update_stmts(env: &crate::check::expr::Env, st: &crate::check::types::St, stmts: &Array<crate::syntax::Stmt>) -> (crate::check::expr::Env, crate::check::types::St) {
    run_to_end(fold_job(stmts.clone(), (env.clone(), st.clone()), Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| entered(once_job(move || {
        let (en, s) = p0;
        let stmt = p1;
        prism_rtl::Turn::More(Rc::new(UpdateStmt { env: en.clone(), st: s.clone(), s: stmt.clone() }))
    }))) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>))
}

/// The step machine of `UpdateStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub struct UpdateStmts {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for UpdateStmts {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        fold_job(stmts.clone(), (env.clone(), st.clone()), Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)| entered(once_job(move || {
            let (en, s) = p0;
            let stmt = p1;
            prism_rtl::Turn::More(Rc::new(UpdateStmt { env: en.clone(), st: s.clone(), s: stmt.clone() }))
        }))) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>>>).cycle()
    }
}

/// `Start UpdateStmts, x`: what the function value is when passed to `@Run`.
pub fn start_update_stmts(env: crate::check::expr::Env, st: crate::check::types::St, stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(UpdateStmts { env, st, stmts })
}

/// ```prism
/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub fn update_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, s: &crate::syntax::Stmt) -> (crate::check::expr::Env, crate::check::types::St) {
    match &s.kind {
        crate::syntax::StmtKind::SSet(target, value) => {
            let (tt, st1) = crate::check::expr::infer(env, st, target);
            let st2 = ref_target(env, &st1, target);
            (env.clone(), crate::check::expr::check(env, &st2, value, &tt))
        },
        crate::syntax::StmtKind::SAccum(target, op, value) => {
            let (tt, st1) = crate::check::expr::infer(env, st, target);
            let st2 = ref_target(env, &st1, target);
            let st3 = crate::check::expr::check(env, &st2, value, &tt);
            let st4 = crate::check::expr::add_want(&st3, &Text::lit("Prelude.Num"), &tt, &s.span);
            let st5 = if op == &Text::lit("-=") {
                crate::check::expr::add_want(&st4, &Text::lit("Prelude.Sub"), &tt, &s.span)
            } else {
                st4.clone()
            };
            (env.clone(), st5.clone())
        },
        crate::syntax::StmtKind::SLet(p_, ty_opt, e) => {
            let (t, st1) = crate::check::expr::infer(env, st, e);
            let st2 = match ty_opt {
                Some(ty) => {
                    let (at_, s2) = crate::check::env::reading::conv_type(&crate::check::expr::env_cx(env), &st1, ty);
                    crate::check::types::unify::unify(&s2, &at_, &t, &e.span)
                },
                None => st1.clone(),
            };
            let (env2, st3) = crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(env), &st2, p_, &t, &false);
            (env2.clone(), st3.clone())
        },
        crate::syntax::StmtKind::SWhile(c, body) => (env.clone(), update_while(env, st, c, body)),
        crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
            crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => (env.clone(), update_if(env, st, &**c, then_b, else_b_opt)),
            crate::syntax::ExprKind::EMatch(scrut, arms) => (env.clone(), update_match(env, st, &**scrut, arms, &e.span)),
            crate::syntax::ExprKind::EFor(binders_opt, source, body) => (env.clone(), update_for(env, st, binders_opt, &**source, body, &e.span)),
            _ => {
                let (t, st1) = crate::check::expr::infer(env, st, e);
                (env.clone(), crate::check::blocks::discarded(&st1, &t, &e.span))
            },
        },
        crate::syntax::StmtKind::SFn(f) => {
            let (env1, st1) = crate::check::expr::lets::pre_bind(env, st, s);
            crate::check::expr::lets::check_local_fn(&env1, &st1, f, &s.span)
        },
        crate::syntax::StmtKind::SSignature(_) => crate::check::expr::lets::pre_bind(env, st, s),
        _ => (env.clone(), crate::check::types::recording::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a widget or `given:` block"))),
    }
}

/// The step machine of `UpdateStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub struct UpdateStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for UpdateStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SSet(target, value) => {
                let env = env.clone();
                let st = st.clone();
                let target = target.clone();
                let value = value.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), target.clone()), move |infer_2330: (crate::check::types::Ty, crate::check::types::St)| {
                    let (tt, st1) = infer_2330;
                    let st2 = ref_target(&env, &st1, &target);
                    call_then(crate::check::expr::start_check(env.clone(), st2.clone(), value.clone(), tt.clone()), move |check_2413: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), check_2413)))
                })
            },
            crate::syntax::StmtKind::SAccum(target, op, value) => {
                let env = env.clone();
                let op = op.clone();
                let s = s.clone();
                let st = st.clone();
                let target = target.clone();
                let value = value.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), target.clone()), move |infer_2498: (crate::check::types::Ty, crate::check::types::St)| {
                    let (tt, st1) = infer_2498;
                    let st2 = ref_target(&env, &st1, &target);
                    call_then(crate::check::expr::start_check(env.clone(), st2.clone(), value.clone(), tt.clone()), move |check_2583: crate::check::types::St| {
                        let st3 = check_2583;
                        let st4 = crate::check::expr::add_want(&st3, &Text::lit("Prelude.Num"), &tt, &s.span);
                        let st5 = if &op == &Text::lit("-=") {
                            crate::check::expr::add_want(&st4, &Text::lit("Prelude.Sub"), &tt, &s.span)
                        } else {
                            st4.clone()
                        };
                        prism_rtl::Turn::Finished((env.clone(), st5.clone()))
                    })
                })
            },
            crate::syntax::StmtKind::SLet(p_, ty_opt, e) => {
                let ty_opt = ty_opt.clone();
                let e = e.clone();
                let env = env.clone();
                let p_ = p_.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_2814: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st1) = infer_2814;
                    let st2 = match &ty_opt {
                        Some(ty) => {
                            let (at_, s2) = crate::check::env::reading::conv_type(&crate::check::expr::env_cx(&env), &st1, ty);
                            crate::check::types::unify::unify(&s2, &at_, &t, &e.span)
                        },
                        None => st1.clone(),
                    };
                    call_then(crate::check::expr::patterns::start_bind_pattern(crate::check::blocks::structure::unpending(&env), st2.clone(), p_.clone(), t.clone(), false), move |bind_pattern_3030: (crate::check::expr::Env, crate::check::types::St)| {
                        let (env2, st3) = bind_pattern_3030;
                        prism_rtl::Turn::Finished((env2.clone(), st3.clone()))
                    })
                })
            },
            crate::syntax::StmtKind::SWhile(c, body) => {
                let body = body.clone();
                let c = c.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(start_update_while(env.clone(), st.clone(), c.clone(), body.clone()), move |update_while_3126: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), update_while_3126)))
            },
            crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => {
                    let else_b_opt = else_b_opt.clone();
                    let c = (**c).clone();
                    let env = env.clone();
                    let st = st.clone();
                    let then_b = then_b.clone();
                    call_then(start_update_if(env.clone(), st.clone(), c.clone(), then_b.clone(), else_b_opt.clone()), move |update_if_3223: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), update_if_3223)))
                },
                crate::syntax::ExprKind::EMatch(scrut, arms) => {
                    let arms = arms.clone();
                    let e = e.clone();
                    let env = env.clone();
                    let scrut = (**scrut).clone();
                    let st = st.clone();
                    call_then(start_update_match(env.clone(), st.clone(), scrut.clone(), arms.clone(), e.span.clone()), move |update_match_3297: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), update_match_3297)))
                },
                crate::syntax::ExprKind::EFor(binders_opt, source, body) => {
                    let binders_opt = binders_opt.clone();
                    let body = body.clone();
                    let e = e.clone();
                    let env = env.clone();
                    let source = (**source).clone();
                    let st = st.clone();
                    call_then(start_update_for(env.clone(), st.clone(), binders_opt.clone(), source.clone(), body.clone(), e.span.clone()), move |update_for_3386: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), update_for_3386)))
                },
                _ => {
                    let e = e.clone();
                    let env = env.clone();
                    let st = st.clone();
                    call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_3487: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t, st1) = infer_3487;
                        call_then(crate::check::blocks::start_discarded(st1.clone(), t.clone(), e.span.clone()), move |discarded_3524: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), discarded_3524)))
                    })
                },
            },
            crate::syntax::StmtKind::SFn(f) => {
                let env = env.clone();
                let f = f.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(crate::check::expr::lets::start_pre_bind(env.clone(), st.clone(), s.clone()), move |pre_bind_3591: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env1, st1) = pre_bind_3591;
                    prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::CheckLocalFn { env: env1.clone(), st: st1.clone(), f: f.clone(), span: s.span.clone() }))
                })
            },
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::PreBind { env: env.clone(), st: st.clone(), s: s.clone() })),
            _ => prism_rtl::Turn::Finished((env.clone(), crate::check::types::recording::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a widget or `given:` block")))),
        }
    }
}

/// `Start UpdateStmt, x`: what the function value is when passed to `@Run`.
pub fn start_update_stmt(env: crate::check::expr::Env, st: crate::check::types::St, s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(UpdateStmt { env, st, s })
}

/// ```prism
/// RefTarget: fn Env, St, Expr -> St
/// ```
pub fn ref_target(env: &crate::check::expr::Env, st: &crate::check::types::St, e: &crate::syntax::Expr) -> crate::check::types::St {
    if is_ref(e) {
        st.clone()
    } else {
        crate::check::types::recording::err_fix(st, &Text::lit("mismatch"), &e.span, &Text::lit("the left of `<=` is a reference: `&_`, a local `&x`, or a path from one"), &Text::from(format!("write `&_.{}`, or make a local with `let &x = ...`", &crate::check::expr::src_text(env, &e.span))))
    }
}

/// ```prism
/// IsRef: fn Expr -> Bool
/// ```
pub fn is_ref(e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")),
        crate::syntax::ExprKind::EField(r, _, _) => is_ref(&**r),
        crate::syntax::ExprKind::EIndex(r, _) => is_ref(&**r),
        crate::syntax::ExprKind::EGroup(x) => is_ref(&**x),
        _ => false,
    }
}

/// ```prism
/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
/// ```
pub fn update_if(env: &crate::check::expr::Env, st: &crate::check::types::St, c: &crate::syntax::Cond, then_b: &crate::syntax::Block, else_b_opt: &Option<crate::syntax::Block>) -> crate::check::types::St {
    let (env2, st1) = match c {
        crate::syntax::Cond::CondExpr(e) => (env.clone(), crate::check::expr::lifting::check_cond(env, st, &**e)),
        crate::syntax::Cond::CondBind(p_, e, gd_opt) => {
            let (et, s1) = crate::check::expr::infer(env, st, &**e);
            let (en, s2) = crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(env), &s1, p_, &et, &true);
            match &**gd_opt {
                Some(g) => (en.clone(), crate::check::expr::lifting::check_cond(&en, &s2, g)),
                None => (en.clone(), s2.clone()),
            }
        },
    };
    let (_, st2) = update_stmts(&env2, &st1, &then_b.stmts);
    match else_b_opt {
        Some(b) => {
            let (_, st3) = update_stmts(env, &st2, &b.stmts);
            st3.clone()
        },
        None => st2.clone(),
    }
}

/// The step machine of `UpdateIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
/// ```
pub struct UpdateIf {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub c: crate::syntax::Cond,
    pub then_b: crate::syntax::Block,
    pub else_b_opt: Option<crate::syntax::Block>,
}

impl prism_rtl::Job<crate::check::types::St> for UpdateIf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let (env2, st1) = match c {
            crate::syntax::Cond::CondExpr(e) => (env.clone(), crate::check::expr::lifting::check_cond(env, st, &**e)),
            crate::syntax::Cond::CondBind(p_, e, gd_opt) => {
                let (et, s1) = crate::check::expr::infer(env, st, &**e);
                let (en, s2) = crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(env), &s1, p_, &et, &true);
                match &**gd_opt {
                    Some(g) => (en.clone(), crate::check::expr::lifting::check_cond(&en, &s2, g)),
                    None => (en.clone(), s2.clone()),
                }
            },
        };
        let else_b_opt = else_b_opt.clone();
        let env = env.clone();
        let then_b = then_b.clone();
        call_then(start_update_stmts(env2.clone(), st1.clone(), then_b.stmts.clone()), move |update_stmts_4808: (crate::check::expr::Env, crate::check::types::St)| {
            let (_, st2) = update_stmts_4808;
            match &else_b_opt {
                Some(b) => {
                    let b = b.clone();
                    call_then(start_update_stmts(env.clone(), st2.clone(), b.stmts.clone()), move |update_stmts_4908: (crate::check::expr::Env, crate::check::types::St)| {
                        let (_, st3) = update_stmts_4908;
                        prism_rtl::Turn::Finished(st3.clone())
                    })
                },
                None => prism_rtl::Turn::Finished(st2.clone()),
            }
        })
    }
}

/// `Start UpdateIf, x`: what the function value is when passed to `@Run`.
pub fn start_update_if(env: crate::check::expr::Env, st: crate::check::types::St, c: crate::syntax::Cond, then_b: crate::syntax::Block, else_b_opt: Option<crate::syntax::Block>) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UpdateIf { env, st, c, then_b, else_b_opt })
}

/// ```prism
/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
/// ```
pub fn update_match(env: &crate::check::expr::Env, st: &crate::check::types::St, scrut: &crate::syntax::Expr, arms: &Array<crate::syntax::Arm>, span: &crate::syntax::Range) -> crate::check::types::St {
    let (t, st1) = crate::check::expr::infer(env, st, scrut);
    let st2 = run_to_end(fold_job(arms.clone(), st1.clone(), {
        let env = env.clone();
        let t = t.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
            let env = env.clone();
            let t = t.clone();
            entered(once_job(move || {
                let s = p0;
                let arm = p1;
                {
                    let (env2, s1) = match &arm.pattern {
                        Some(p_) => crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(&env), &s, p_, &t, &true),
                        None => (env.clone(), s.clone()),
                    };
                    let s2 = match &arm.guard {
                        Some(gd) => crate::check::expr::lifting::check_cond(&env2, &s1, gd),
                        None => s1.clone(),
                    };
                    call_then(start_update_stmts(env2.clone(), s2.clone(), arm.body.stmts.clone()), move |update_stmts_5417: (crate::check::expr::Env, crate::check::types::St)| {
                        let (_, s3) = update_stmts_5417;
                        prism_rtl::Turn::Finished(s3.clone())
                    })
                }
            }))
        }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    crate::check::passes::match_coverage(env, &st2, &t, arms, span)
}

/// The step machine of `UpdateMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
/// ```
pub struct UpdateMatch {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub scrut: crate::syntax::Expr,
    pub arms: Array<crate::syntax::Arm>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for UpdateMatch {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let scrut = &self.scrut;
        let arms = &self.arms;
        let span = &self.span;
        let arms = arms.clone();
        let env = env.clone();
        let scrut = scrut.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), scrut.clone()), move |infer_5096: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st1) = infer_5096;
            call_value(fold_job(arms.clone(), st1.clone(), {
                let env = env.clone();
                let t = t.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::Arm)| {
                    let env = env.clone();
                    let t = t.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let arm = p1;
                        {
                            let (env2, s1) = match &arm.pattern {
                                Some(p_) => crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(&env), &s, p_, &t, &true),
                                None => (env.clone(), s.clone()),
                            };
                            let s2 = match &arm.guard {
                                Some(gd) => crate::check::expr::lifting::check_cond(&env2, &s1, gd),
                                None => s1.clone(),
                            };
                            call_then(start_update_stmts(env2.clone(), s2.clone(), arm.body.stmts.clone()), move |update_stmts_5417: (crate::check::expr::Env, crate::check::types::St)| {
                                let (_, s3) = update_stmts_5417;
                                prism_rtl::Turn::Finished(s3.clone())
                            })
                        }
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }), move |fold_5131: crate::check::types::St| {
                let st2 = fold_5131;
                prism_rtl::Turn::More(Rc::new(crate::check::passes::MatchCoverage { env: env.clone(), st: st2.clone(), t: t.clone(), arms: arms.clone(), span: span.clone() }))
            })
        })
    }
}

/// `Start UpdateMatch, x`: what the function value is when passed to `@Run`.
pub fn start_update_match(env: crate::check::expr::Env, st: crate::check::types::St, scrut: crate::syntax::Expr, arms: Array<crate::syntax::Arm>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UpdateMatch { env, st, scrut, arms, span })
}

/// ```prism
/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
/// ```
pub fn update_while(env: &crate::check::expr::Env, st: &crate::check::types::St, c: &crate::syntax::Cond, body: &crate::syntax::Block) -> crate::check::types::St {
    let (env2, st1) = match c {
        crate::syntax::Cond::CondExpr(e) => (env.clone(), crate::check::expr::lifting::check_cond(env, st, &**e)),
        crate::syntax::Cond::CondBind(p_, e, gd_opt) => {
            let (et, s1) = crate::check::expr::infer(env, st, &**e);
            let (en, s2) = crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(env), &s1, p_, &et, &true);
            match &**gd_opt {
                Some(g) => (en.clone(), crate::check::expr::lifting::check_cond(&en, &s2, g)),
                None => (en.clone(), s2.clone()),
            }
        },
    };
    let (_, st2) = update_stmts(&env2, &st1, &body.stmts);
    st2.clone()
}

/// The step machine of `UpdateWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
/// ```
pub struct UpdateWhile {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub c: crate::syntax::Cond,
    pub body: crate::syntax::Block,
}

impl prism_rtl::Job<crate::check::types::St> for UpdateWhile {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let body = &self.body;
        let (env2, st1) = match c {
            crate::syntax::Cond::CondExpr(e) => (env.clone(), crate::check::expr::lifting::check_cond(env, st, &**e)),
            crate::syntax::Cond::CondBind(p_, e, gd_opt) => {
                let (et, s1) = crate::check::expr::infer(env, st, &**e);
                let (en, s2) = crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(env), &s1, p_, &et, &true);
                match &**gd_opt {
                    Some(g) => (en.clone(), crate::check::expr::lifting::check_cond(&en, &s2, g)),
                    None => (en.clone(), s2.clone()),
                }
            },
        };
        let body = body.clone();
        call_then(start_update_stmts(env2.clone(), st1.clone(), body.stmts.clone()), move |update_stmts_6052: (crate::check::expr::Env, crate::check::types::St)| {
            let (_, st2) = update_stmts_6052;
            prism_rtl::Turn::Finished(st2.clone())
        })
    }
}

/// `Start UpdateWhile, x`: what the function value is when passed to `@Run`.
pub fn start_update_while(env: crate::check::expr::Env, st: crate::check::types::St, c: crate::syntax::Cond, body: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UpdateWhile { env, st, c, body })
}

/// ```prism
/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
/// ```
pub fn update_for(env: &crate::check::expr::Env, st: &crate::check::types::St, binders_opt: &Option<crate::syntax::ForBinders>, source: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range) -> crate::check::types::St {
    let (t, st1) = crate::check::expr::infer(env, st, source);
    let (k, v_, st2) = crate::check::blocks::structure::coll_parts(&st1, &t, &source.span);
    let env1 = crate::check::blocks::structure::loop_indices(env);
    let (env2, st3) = match binders_opt {
        None => (crate::check::blocks::structure::with_topic(&env1, &Text::lit("&_"), &v_), st2.clone()),
        Some(bs) => match &bs.second {
            Some(second) => {
                let (e1, s1) = crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(&env1), &st2, &bs.first, &k, &false);
                crate::check::expr::patterns::bind_pattern(&e1, &s1, second, &v_, &false)
            },
            None => crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(&env1), &st2, &bs.first, &v_, &false),
        },
    };
    let (_, st4) = update_stmts(&env2, &st3, &body.stmts);
    st4.clone()
}

/// The step machine of `UpdateFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
/// ```
pub struct UpdateFor {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub binders_opt: Option<crate::syntax::ForBinders>,
    pub source: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for UpdateFor {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let binders_opt = &self.binders_opt;
        let source = &self.source;
        let body = &self.body;
        let span = &self.span;
        let binders_opt = binders_opt.clone();
        let body = body.clone();
        let env = env.clone();
        let source = source.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), source.clone()), move |infer_6360: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st1) = infer_6360;
            call_then(crate::check::blocks::structure::start_coll_parts(st1.clone(), t.clone(), source.span.clone()), move |coll_parts_6406: (crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)| {
                let (k, v_, st2) = coll_parts_6406;
                let env1 = crate::check::blocks::structure::loop_indices(&env);
                let (env2, st3) = match &binders_opt {
                    None => (crate::check::blocks::structure::with_topic(&env1, &Text::lit("&_"), &v_), st2.clone()),
                    Some(bs) => match &bs.second {
                        Some(second) => {
                            let (e1, s1) = crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(&env1), &st2, &bs.first, &k, &false);
                            crate::check::expr::patterns::bind_pattern(&e1, &s1, second, &v_, &false)
                        },
                        None => crate::check::expr::patterns::bind_pattern(&crate::check::blocks::structure::unpending(&env1), &st2, &bs.first, &v_, &false),
                    },
                };
                call_then(start_update_stmts(env2.clone(), st3.clone(), body.stmts.clone()), move |update_stmts_6846: (crate::check::expr::Env, crate::check::types::St)| {
                    let (_, st4) = update_stmts_6846;
                    prism_rtl::Turn::Finished(st4.clone())
                })
            })
        })
    }
}

/// `Start UpdateFor, x`: what the function value is when passed to `@Run`.
pub fn start_update_for(env: crate::check::expr::Env, st: crate::check::types::St, binders_opt: Option<crate::syntax::ForBinders>, source: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UpdateFor { env, st, binders_opt, source, body, span })
}
