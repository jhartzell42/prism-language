//! The module `Check.Blocks.Structure`, from `target/bootstrap/src/prismc/check/blocks/structure.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_rebuild(env: &crate::check::expr::Env, st: &crate::check::types::St, scrut: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t, st1) = crate::check::expr::infer(env, st, scrut);
    let (inner, st2) = match crate::check::types::recording::walk(&st1, &t) {
        crate::check::types::Ty::TySig(m1650_0_0, i) if (&m1650_0_0 == &Text::lit("$")) => ((*i).clone(), st1.clone()),
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st1.clone()),
        crate::check::types::Ty::TyFlex(_) => {
            let (v_, s2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
            (v_.clone(), crate::check::types::unify::unify(&s2, &crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_.clone())), &t, &scrut.span))
        },
        other => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(&st1, &Text::lit("mismatch"), &scrut.span, &Text::from(format!("`rebuild` builds over a dynamic; this is `{}`", &crate::check::types::show_ty(&st1, &other))), &Text::lit("a plain value is built once: write the block's lines in place"))),
        _ => unreachable!("no arm matched"),
    };
    let env2 = with_topic(env, &Text::lit("_"), &inner);
    let (res, st3) = crate::check::blocks::infer_widget_block(&env2, &st2, body);
    match crate::check::types::recording::walk(&st3, &res) {
        crate::check::types::Ty::TyCon(m2163_0_0, m2163_0_1) if (&m2163_0_0 == &Text::lit("unit")) && ((&m2163_0_1).len() == 0) => (crate::check::types::t_unit(), st3.clone()),
        other => (crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(other.clone())), st3.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InferRebuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferRebuild {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub scrut: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferRebuild {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let scrut = &self.scrut;
        let body = &self.body;
        let span = &self.span;
        let body = body.clone();
        let env = env.clone();
        let scrut = scrut.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::expr::start_infer(env.clone(), st.clone(), scrut.clone()), move |infer_1604: (crate::check::types::Ty, crate::check::types::St)| {
            let (t, st1) = infer_1604;
            call_then(crate::check::types::recording::start_walk(st1.clone(), t.clone()), move |walk_1656: crate::check::types::Ty| {
                let (inner, st2) = match walk_1656 {
                    crate::check::types::Ty::TySig(m1650_0_0, i) if (&m1650_0_0 == &Text::lit("$")) => ((*i).clone(), st1.clone()),
                    crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st1.clone()),
                    crate::check::types::Ty::TyFlex(_) => {
                        let (v_, s2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
                        (v_.clone(), crate::check::types::unify::unify(&s2, &crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_.clone())), &t, &scrut.span))
                    },
                    other => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(&st1, &Text::lit("mismatch"), &scrut.span, &Text::from(format!("`rebuild` builds over a dynamic; this is `{}`", &crate::check::types::show_ty(&st1, &other))), &Text::lit("a plain value is built once: write the block's lines in place"))),
                    _ => unreachable!("no arm matched"),
                };
                let env2 = with_topic(&env, &Text::lit("_"), &inner);
                call_then(crate::check::blocks::start_infer_widget_block(env2.clone(), st2.clone(), body.clone()), move |infer_widget_block_2126: (crate::check::types::Ty, crate::check::types::St)| {
                    let (res, st3) = infer_widget_block_2126;
                    call_then(crate::check::types::recording::start_walk(st3.clone(), res.clone()), move |walk_2169: crate::check::types::Ty| match walk_2169 {
                        crate::check::types::Ty::TyCon(m2163_0_0, m2163_0_1) if (&m2163_0_0 == &Text::lit("unit")) && ((&m2163_0_1).len() == 0) => prism_rtl::Turn::Finished((crate::check::types::t_unit(), st3.clone())),
                        other => prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(other.clone())), st3.clone())),
                        _ => unreachable!("no arm matched"),
                    })
                })
            })
        })
    }
}

/// `Start InferRebuild, x`: what the function value is when passed to `@Run`.
pub fn start_infer_rebuild(env: crate::check::expr::Env, st: crate::check::types::St, scrut: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferRebuild { env, st, scrut, body, span })
}

/// ```prism
/// WithTopic: fn Env, Text, Ty -> Env
/// ```
pub fn with_topic(env: &crate::check::expr::Env, name: &Text, t: &crate::check::types::Ty) -> crate::check::expr::Env {
    let mut this: crate::check::expr::Env = crate::check::expr::with_local(env, name, &crate::check::types::schemes::mono(t));
    this.pending = filter(&this.pending, &(|x: &Text| x != name));
    this
}

/// ```prism
/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_for(env: &crate::check::expr::Env, st: &crate::check::types::St, binders_opt: &Option<crate::syntax::ForBinders>, source: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    if env.in_update {
        (crate::check::types::t_unit(), crate::check::blocks::borrows::update_for(env, st, binders_opt, source, body, span))
    } else {
        {
            let (t, st1) = crate::check::expr::infer(env, st, source);
            let sh = crate::check::types::head_sigil(&st1, &t);
            let coll = if &sh == &Text::lit("$") { crate::check::expr::inner_of(&st1, &t) } else { t.clone() };
            let st2 = if (&sh == &Text::lit("!")) || (&sh == &Text::lit("@")) {
                crate::check::types::recording::err(&st1, &Text::lit("mismatch"), &source.span, &Text::from(format!("`for` runs over a map or an array, plain or dynamic; this is `{}`", &crate::check::types::show_ty(&st1, &t))))
            } else {
                st1.clone()
            };
            let (k, v_, st3) = coll_parts(&st2, &coll, &source.span);
            let live = &sh == &Text::lit("$");
            let env1 = loop_indices(env);
            let (env2, st4) = bind_for_binders(&env1, &st3, binders_opt, &k, &v_, &live);
            let (res, st5) = crate::check::blocks::infer_widget_block(&env2, &st4, body);
            gather(&st5, &res, &k, &live)
        }
    }
}

/// The step machine of `InferFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferFor {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub binders_opt: Option<crate::syntax::ForBinders>,
    pub source: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferFor {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let binders_opt = &self.binders_opt;
        let source = &self.source;
        let body = &self.body;
        let span = &self.span;
        if env.in_update {
            {
                let binders_opt = binders_opt.clone();
                let body = body.clone();
                let env = env.clone();
                let source = source.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(crate::check::blocks::borrows::start_update_for(env.clone(), st.clone(), binders_opt.clone(), source.clone(), body.clone(), span.clone()), move |update_for_2754: crate::check::types::St| prism_rtl::Turn::Finished((crate::check::types::t_unit(), update_for_2754)))
            }
        } else {
            {
                let binders_opt = binders_opt.clone();
                let body = body.clone();
                let env = env.clone();
                let source = source.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), source.clone()), move |infer_2840: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st1) = infer_2840;
                    call_then(crate::check::types::start_head_sigil(st1.clone(), t.clone()), move |head_sigil_2879: Text| {
                        let sh = head_sigil_2879;
                        let coll = if &sh == &Text::lit("$") { crate::check::expr::inner_of(&st1, &t) } else { t.clone() };
                        let st2 = if (&sh == &Text::lit("!")) || (&sh == &Text::lit("@")) {
                            crate::check::types::recording::err(&st1, &Text::lit("mismatch"), &source.span, &Text::from(format!("`for` runs over a map or an array, plain or dynamic; this is `{}`", &crate::check::types::show_ty(&st1, &t))))
                        } else {
                            st1.clone()
                        };
                        call_then(start_coll_parts(st2.clone(), coll.clone(), source.span.clone()), move |coll_parts_3150: (crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)| {
                            let (k, v_, st3) = coll_parts_3150;
                            let live = &sh == &Text::lit("$");
                            let env1 = loop_indices(&env);
                            call_then(start_bind_for_binders(env1.clone(), st3.clone(), binders_opt.clone(), k.clone(), v_.clone(), live), move |bind_for_binders_3275: (crate::check::expr::Env, crate::check::types::St)| {
                                let (env2, st4) = bind_for_binders_3275;
                                call_then(crate::check::blocks::start_infer_widget_block(env2.clone(), st4.clone(), body.clone()), move |infer_widget_block_3349: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (res, st5) = infer_widget_block_3349;
                                    prism_rtl::Turn::More(Rc::new(Gather { st: st5.clone(), res: res.clone(), k: k.clone(), live }))
                                })
                            })
                        })
                    })
                })
            }
        }
    }
}

/// `Start InferFor, x`: what the function value is when passed to `@Run`.
pub fn start_infer_for(env: crate::check::expr::Env, st: crate::check::types::St, binders_opt: Option<crate::syntax::ForBinders>, source: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferFor { env, st, binders_opt, source, body, span })
}

/// ```prism
/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
/// ```
pub fn coll_parts(st: &crate::check::types::St, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St) {
    'm3542: {
        let scrutinee = &crate::check::types::recording::walk(st, t);
        if let crate::check::types::Ty::TyMap(k, v_) = scrutinee {
            break 'm3542 ((**k).clone(), (**v_).clone(), st.clone());
        }
        if let crate::check::types::Ty::TyArray(v_) = scrutinee {
            break 'm3542 (crate::check::types::t_nat(), (**v_).clone(), st.clone());
        }
        if let crate::check::types::Ty::TyCon(m3542_2_0, m3542_2_1) = scrutinee && (m3542_2_0 == &Text::lit("Buffer")) && (m3542_2_1.len() == 1) && let Some(v_) = index(m3542_2_1, &Nat::from(0u32)) {
            break 'm3542 (crate::check::types::t_nat(), v_.clone(), st.clone());
        }
        if let crate::check::types::Ty::TyErr = scrutinee {
            break 'm3542 (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, st.clone());
        }
        if let crate::check::types::Ty::TyFlex(_) = scrutinee {
            break 'm3542 {
                let (v_, st2) = crate::check::types::fresh_var(st, &false, &Text::lit(""));
                (crate::check::types::t_nat(), v_.clone(), crate::check::types::unify::unify(&st2, &crate::check::types::Ty::TyArray(Rc::new(v_.clone())), t, span))
            };
        }
        if let other = scrutinee {
            break 'm3542 (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, crate::check::types::recording::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`for` runs over a map or an array; this is `{}`", &crate::check::types::show_ty(st, other)))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CollParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
/// ```
pub struct CollParts {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)> for CollParts {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)> {
        let st = &self.st;
        let t = &self.t;
        let span = &self.span;
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_3548: crate::check::types::Ty| 'm3542: {
            if let crate::check::types::Ty::TyMap(k, v_) = &walk_3548 {
                break 'm3542 prism_rtl::Turn::Finished(((**k).clone(), (**v_).clone(), st.clone()));
            }
            if let crate::check::types::Ty::TyArray(v_) = &walk_3548 {
                break 'm3542 prism_rtl::Turn::Finished((crate::check::types::t_nat(), (**v_).clone(), st.clone()));
            }
            if let crate::check::types::Ty::TyCon(m3542_2_0, m3542_2_1) = &walk_3548 && (m3542_2_0 == &Text::lit("Buffer")) && (m3542_2_1.len() == 1) && let Some(v_) = index(m3542_2_1, &Nat::from(0u32)) {
                break 'm3542 prism_rtl::Turn::Finished((crate::check::types::t_nat(), v_.clone(), st.clone()));
            }
            if let crate::check::types::Ty::TyErr = &walk_3548 {
                break 'm3542 prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, st.clone()));
            }
            if let crate::check::types::Ty::TyFlex(_) = &walk_3548 {
                break 'm3542 {
                    let (v_, st2) = crate::check::types::fresh_var(&st, &false, &Text::lit(""));
                    call_then(crate::check::types::unify::start_unify(st2.clone(), crate::check::types::Ty::TyArray(Rc::new(v_.clone())), t.clone(), span.clone()), move |unify_3782: crate::check::types::St| prism_rtl::Turn::Finished((crate::check::types::t_nat(), v_.clone(), unify_3782)))
                };
            }
            if let other = &walk_3548 {
                break 'm3542 {
                    let other = other.clone();
                    call_then(crate::check::types::start_show_ty(st.clone(), other.clone()), move |show_ty_3917: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("`for` runs over a map or an array; this is `{}`", &show_ty_3917))))))
                };
            }
            unreachable!("no clause matched")
        })
    }
}

/// `Start CollParts, x`: what the function value is when passed to `@Run`.
pub fn start_coll_parts(st: crate::check::types::St, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(CollParts { st, t, span })
}

/// ```prism
/// LoopIndices: fn Env -> Env
/// ```
pub fn loop_indices(env: &crate::check::expr::Env) -> crate::check::expr::Env {
    let outer1_opt = get(&env.locals, &Text::lit("ix"));
    let outer2_opt = get(&env.locals, &Text::lit("jx"));
    let e1 = crate::check::expr::with_local(env, &Text::lit("ix"), &crate::check::types::schemes::mono(&crate::check::types::t_nat()));
    let e2 = match &outer1_opt {
        Some(sc) => crate::check::expr::with_local(&e1, &Text::lit("jx"), sc),
        None => e1.clone(),
    };
    match &outer2_opt {
        Some(sc) => crate::check::expr::with_local(&e2, &Text::lit("kx"), sc),
        None => e2.clone(),
    }
}

/// ```prism
/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_for_binders(env: &crate::check::expr::Env, st: &crate::check::types::St, binders_opt: &Option<crate::syntax::ForBinders>, k: &crate::check::types::Ty, v_: &crate::check::types::Ty, live: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    let vt = if *live {
        crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_.clone()))
    } else {
        v_.clone()
    };
    match binders_opt {
        None => {
            let e1 = with_topic(env, &(if *live { Text::lit("$_") } else { Text::lit("_") }), &vt);
            (with_topic(&e1, &Text::lit("key"), k), st.clone())
        },
        Some(bs) => match &bs.second {
            Some(second) => {
                let (e1, st1) = crate::check::expr::patterns::bind_pattern(&unpending(env), st, &bs.first, k, &false);
                crate::check::expr::patterns::bind_pattern(&e1, &st1, second, &vt, &false)
            },
            None => {
                let e1 = with_topic(env, &Text::lit("key"), k);
                crate::check::expr::patterns::bind_pattern(&unpending(&e1), st, &bs.first, &vt, &false)
            },
        },
    }
}

/// The step machine of `BindForBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
/// ```
pub struct BindForBinders {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub binders_opt: Option<crate::syntax::ForBinders>,
    pub k: crate::check::types::Ty,
    pub v_: crate::check::types::Ty,
    pub live: bool,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindForBinders {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let binders_opt = &self.binders_opt;
        let k = &self.k;
        let v_ = &self.v_;
        let live = &self.live;
        let vt = if *live {
            crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_.clone()))
        } else {
            v_.clone()
        };
        match binders_opt {
            None => {
                let e1 = with_topic(env, &(if *live { Text::lit("$_") } else { Text::lit("_") }), &vt);
                prism_rtl::Turn::Finished((with_topic(&e1, &Text::lit("key"), k), st.clone()))
            },
            Some(bs) => match &bs.second {
                Some(second) => {
                    let bs = bs.clone();
                    let env = env.clone();
                    let k = k.clone();
                    let second = second.clone();
                    let st = st.clone();
                    call_then(crate::check::expr::patterns::start_bind_pattern(unpending(&env), st.clone(), bs.first.clone(), k.clone(), false), move |bind_pattern_4913: (crate::check::expr::Env, crate::check::types::St)| {
                        let (e1, st1) = bind_pattern_4913;
                        prism_rtl::Turn::More(Rc::new(crate::check::expr::patterns::BindPattern { env: e1.clone(), st: st1.clone(), p_: second.clone(), t: vt.clone(), refutable: false }))
                    })
                },
                None => {
                    let e1 = with_topic(env, &Text::lit("key"), k);
                    prism_rtl::Turn::More(Rc::new(crate::check::expr::patterns::BindPattern { env: unpending(&e1), st: st.clone(), p_: bs.first.clone(), t: vt.clone(), refutable: false }))
                },
            },
        }
    }
}

/// `Start BindForBinders, x`: what the function value is when passed to `@Run`.
pub fn start_bind_for_binders(env: crate::check::expr::Env, st: crate::check::types::St, binders_opt: Option<crate::syntax::ForBinders>, k: crate::check::types::Ty, v_: crate::check::types::Ty, live: bool) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindForBinders { env, st, binders_opt, k, v_, live })
}

/// ```prism
/// Unpending: fn Env -> Env
/// ```
pub fn unpending(env: &crate::check::expr::Env) -> crate::check::expr::Env {
    let mut this: crate::check::expr::Env = env.clone();
    this.pending = Array::new();
    this
}

/// ```prism
/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
/// ```
pub fn gather(st: &crate::check::types::St, res: &crate::check::types::Ty, k: &crate::check::types::Ty, live: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::check::types::recording::walk(st, res) {
        crate::check::types::Ty::TyCon(m5579_0_0, m5579_0_1) if (&m5579_0_0 == &Text::lit("unit")) && ((&m5579_0_1).len() == 0) => (crate::check::types::t_unit(), st.clone()),
        crate::check::types::Ty::TySig(m5579_1_0, t) if (&m5579_1_0 == &Text::lit("!")) => (crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new((*t).clone())))), st.clone()),
        crate::check::types::Ty::TySig(m5579_2_0, t) if (&m5579_2_0 == &Text::lit("$")) => (crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new((*t).clone())))), st.clone()),
        crate::check::types::Ty::TyTuple(ts) => if run_to_end(fold_job(ts.clone(), false, {
            let st = st.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(seen || crate::check::expr::is_time_sigil(&crate::check::types::head_sigil(&st, &x)))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })) {
            {
                let (parts, st2) = run_to_end(fold_job(ts.clone(), (Array::new(), st.clone()), {
                    let k = k.clone();
                    let live = *live;
                    Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)| {
                        let k = k.clone();
                        let live = live;
                        entered(once_job(move || {
                            let (acc, s) = p0;
                            let x = p1;
                            call_then(start_gather(s.clone(), x.clone(), k.clone(), live), move |gather_5939: (crate::check::types::Ty, crate::check::types::St)| {
                                let (g, s2) = gather_5939;
                                prism_rtl::Turn::Finished((push(&acc, &g), s2.clone()))
                            })
                        }))
                    }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
                }));
                (crate::check::types::Ty::TyTuple(parts.clone()), st2.clone())
            }
        } else {
            (live_map(live, k, &crate::check::types::Ty::TyTuple(ts.clone())), st.clone())
        },
        other => (live_map(live, k, &other), st.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Gather`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
/// ```
pub struct Gather {
    pub st: crate::check::types::St,
    pub res: crate::check::types::Ty,
    pub k: crate::check::types::Ty,
    pub live: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for Gather {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st = &self.st;
        let res = &self.res;
        let k = &self.k;
        let live = &self.live;
        let k = k.clone();
        let live = *live;
        let res = res.clone();
        let st = st.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), res.clone()), move |walk_5585: crate::check::types::Ty| match walk_5585 {
            crate::check::types::Ty::TyCon(m5579_0_0, m5579_0_1) if (&m5579_0_0 == &Text::lit("unit")) && ((&m5579_0_1).len() == 0) => prism_rtl::Turn::Finished((crate::check::types::t_unit(), st.clone())),
            crate::check::types::Ty::TySig(m5579_1_0, t) if (&m5579_1_0 == &Text::lit("!")) => prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new((*t).clone())))), st.clone())),
            crate::check::types::Ty::TySig(m5579_2_0, t) if (&m5579_2_0 == &Text::lit("$")) => prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new((*t).clone())))), st.clone())),
            crate::check::types::Ty::TyTuple(ts) => call_value(fold_job(ts.clone(), false, {
                let st = st.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(seen || crate::check::expr::is_time_sigil(&crate::check::types::head_sigil(&st, &x)))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |fold_5768: bool| if fold_5768 {
                call_value(fold_job(ts.clone(), (Array::new(), st.clone()), {
                    let k = k.clone();
                    let live = live;
                    Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)| {
                        let k = k.clone();
                        let live = live;
                        entered(once_job(move || {
                            let (acc, s) = p0;
                            let x = p1;
                            call_then(start_gather(s.clone(), x.clone(), k.clone(), live), move |gather_5939: (crate::check::types::Ty, crate::check::types::St)| {
                                let (g, s2) = gather_5939;
                                prism_rtl::Turn::Finished((push(&acc, &g), s2.clone()))
                            })
                        }))
                    }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
                }), move |fold_5867: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (parts, st2) = fold_5867;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyTuple(parts.clone()), st2.clone()))
                })
            } else {
                prism_rtl::Turn::Finished((live_map(&live, &k, &crate::check::types::Ty::TyTuple(ts.clone())), st.clone()))
            }),
            other => prism_rtl::Turn::Finished((live_map(&live, &k, &other), st.clone())),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start Gather, x`: what the function value is when passed to `@Run`.
pub fn start_gather(st: crate::check::types::St, res: crate::check::types::Ty, k: crate::check::types::Ty, live: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(Gather { st, res, k, live })
}

/// ```prism
/// LiveMap: fn Bool, Ty, Ty -> Ty
/// ```
pub fn live_map(live: &bool, k: &crate::check::types::Ty, v_: &crate::check::types::Ty) -> crate::check::types::Ty {
    if *live {
        crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone()))))
    } else {
        crate::check::types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone()))
    }
}

/// ```prism
/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
/// ```
pub fn infer_given(env: &crate::check::expr::Env, st: &crate::check::types::St, b: &crate::syntax::Block, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let mark = if (&env.mark == &Text::lit("?")) || (&env.mark == &Text::lit("~")) {
        env.mark.clone()
    } else {
        given_mark_of(&b.stmts)
    };
    infer_given_block(env, st, b, &mark)
}

/// The step machine of `InferGiven`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
/// ```
pub struct InferGiven {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub b: crate::syntax::Block,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferGiven {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let span = &self.span;
        let mark = if (&env.mark == &Text::lit("?")) || (&env.mark == &Text::lit("~")) {
            env.mark.clone()
        } else {
            given_mark_of(&b.stmts)
        };
        prism_rtl::Turn::More(Rc::new(InferGivenBlock { env: env.clone(), st: st.clone(), b: b.clone(), mark: mark.clone() }))
    }
}

/// `Start InferGiven, x`: what the function value is when passed to `@Run`.
pub fn start_infer_given(env: crate::check::expr::Env, st: crate::check::types::St, b: crate::syntax::Block, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferGiven { env, st, b, span })
}

/// ```prism
/// GivenMarkOf: fn [Stmt] -> Text
/// ```
pub fn given_mark_of(stmts: &Array<crate::syntax::Stmt>) -> Text {
    fold(stmts, &Text::lit("?"), &(|m: &Text, s: &crate::syntax::Stmt| m.clone()))
}

/// ```prism
/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
/// ```
pub fn infer_given_block(env: &crate::check::expr::Env, st: &crate::check::types::St, b: &crate::syntax::Block, mark: &Text) -> (crate::check::types::Ty, crate::check::types::St) {
    let n = len(&b.stmts);
    let (env2, st2, res_opt) = run_to_end(fold_job(crate::check::errors::range0(&n), (env.clone(), st.clone(), None), {
        let b = b.clone();
        let mark = mark.clone();
        let n = n.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)| {
            let b = b.clone();
            let mark = mark.clone();
            let n = n.clone();
            entered(once_job(move || {
                let (en, s, r_opt) = p0;
                let i = p1;
                {
                    let stmt = or(&index(&b.stmts, &i), &crate::check::blocks::dummy_stmt2());
                    prism_rtl::Turn::More(Rc::new(GivenStmt { env: en.clone(), st: s.clone(), s: stmt.clone(), mark: mark.clone(), last: &(&i + &Nat::from(1u32)) == &n, res_opt: r_opt.clone() }))
                }
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>>>
    }));
    match &res_opt {
        Some(t) => (t.clone(), st2.clone()),
        None => {
            let (v_, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
            (crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), st3.clone())
        },
    }
}

/// The step machine of `InferGivenBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
/// ```
pub struct InferGivenBlock {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub b: crate::syntax::Block,
    pub mark: Text,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferGivenBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let mark = &self.mark;
        let n = len(&b.stmts);
        let b = b.clone();
        let env = env.clone();
        let mark = mark.clone();
        let st = st.clone();
        call_value(fold_job(crate::check::errors::range0(&n), (env.clone(), st.clone(), None), {
            let b = b.clone();
            let mark = mark.clone();
            let n = n.clone();
            Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)| {
                let b = b.clone();
                let mark = mark.clone();
                let n = n.clone();
                entered(once_job(move || {
                    let (en, s, r_opt) = p0;
                    let i = p1;
                    {
                        let stmt = or(&index(&b.stmts, &i), &crate::check::blocks::dummy_stmt2());
                        prism_rtl::Turn::More(Rc::new(GivenStmt { env: en.clone(), st: s.clone(), s: stmt.clone(), mark: mark.clone(), last: &(&i + &Nat::from(1u32)) == &n, res_opt: r_opt.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>>>
        }), move |fold_7136: (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)| {
            let (env2, st2, res_opt) = fold_7136;
            match &res_opt {
                Some(t) => prism_rtl::Turn::Finished((t.clone(), st2.clone())),
                None => {
                    let (v_, st3) = crate::check::types::fresh_var(&st2, &false, &Text::lit(""));
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), st3.clone()))
                },
            }
        })
    }
}

/// `Start InferGivenBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_given_block(env: crate::check::expr::Env, st: crate::check::types::St, b: crate::syntax::Block, mark: Text) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferGivenBlock { env, st, b, mark })
}

/// ```prism
/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
/// ```
pub fn given_stmt(env: &crate::check::expr::Env, st: &crate::check::types::St, s: &crate::syntax::Stmt, mark: &Text, last: &bool, res_opt: &Option<crate::check::types::Ty>) -> (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>) {
    match &s.kind {
        crate::syntax::StmtKind::SBind(p_, e, None) => {
            let (t, st1) = crate::check::expr::infer(env, st, e);
            let (v_, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
            let st3 = crate::check::types::unify::unify(&st2, &crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), &t, &e.span);
            let (env2, st4) = crate::check::expr::patterns::bind_pattern(&unpending(env), &st3, p_, &v_, &true);
            (env2.clone(), st4.clone(), res_opt.clone())
        },
        crate::syntax::StmtKind::SRequire(c) => (env.clone(), crate::check::expr::lifting::check_cond(env, st, c), res_opt.clone()),
        crate::syntax::StmtKind::SForbid(c) => (env.clone(), crate::check::expr::lifting::check_cond(env, st, c), res_opt.clone()),
        crate::syntax::StmtKind::SLet(p_, ty_opt, e) => {
            let (env2, st2) = crate::check::expr::lets::check_let(env, st, p_, ty_opt, e, &s.span);
            (env2.clone(), st2.clone(), res_opt.clone())
        },
        crate::syntax::StmtKind::SFn(f) => {
            let (env1, st1) = crate::check::expr::lets::pre_bind(env, st, s);
            let (env2, st2) = crate::check::expr::lets::check_local_fn(&env1, &st1, f, &s.span);
            (env2.clone(), st2.clone(), res_opt.clone())
        },
        crate::syntax::StmtKind::SSignature(_) => {
            let (env2, st2) = crate::check::expr::lets::pre_bind(env, st, s);
            (env2.clone(), st2.clone(), res_opt.clone())
        },
        crate::syntax::StmtKind::SExpr(e) => if *last {
            {
                let (t, st1) = crate::check::expr::infer(env, st, e);
                let (v_, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
                let st3 = crate::check::types::unify::unify(&st2, &crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), &t, &e.span);
                (env.clone(), st3.clone(), Some(crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone()))))
            }
        } else {
            {
                let (t, st1) = crate::check::expr::infer(env, st, e);
                (env.clone(), crate::check::blocks::discarded(&st1, &t, &e.span), res_opt.clone())
            }
        },
        _ => (env.clone(), crate::check::types::recording::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a widget or `update` block")), res_opt.clone()),
    }
}

/// The step machine of `GivenStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
/// ```
pub struct GivenStmt {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub s: crate::syntax::Stmt,
    pub mark: Text,
    pub last: bool,
    pub res_opt: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)> for GivenStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        let mark = &self.mark;
        let last = &self.last;
        let res_opt = &self.res_opt;
        match &s.kind {
            crate::syntax::StmtKind::SBind(p_, e, None) => {
                let res_opt = res_opt.clone();
                let e = e.clone();
                let env = env.clone();
                let mark = mark.clone();
                let p_ = p_.clone();
                let st = st.clone();
                call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_7611: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st1) = infer_7611;
                    let (v_, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
                    call_then(crate::check::types::unify::start_unify(st2.clone(), crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), t.clone(), e.span.clone()), move |unify_7695: crate::check::types::St| {
                        let st3 = unify_7695;
                        call_then(crate::check::expr::patterns::start_bind_pattern(unpending(&env), st3.clone(), p_.clone(), v_.clone(), true), move |bind_pattern_7761: (crate::check::expr::Env, crate::check::types::St)| {
                            let (env2, st4) = bind_pattern_7761;
                            prism_rtl::Turn::Finished((env2.clone(), st4.clone(), res_opt.clone()))
                        })
                    })
                })
            },
            crate::syntax::StmtKind::SRequire(c) => {
                let res_opt = res_opt.clone();
                let c = c.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(crate::check::expr::lifting::start_check_cond(env.clone(), st.clone(), c.clone()), move |check_cond_7858: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), check_cond_7858, res_opt.clone())))
            },
            crate::syntax::StmtKind::SForbid(c) => {
                let res_opt = res_opt.clone();
                let c = c.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(crate::check::expr::lifting::start_check_cond(env.clone(), st.clone(), c.clone()), move |check_cond_7911: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), check_cond_7911, res_opt.clone())))
            },
            crate::syntax::StmtKind::SLet(p_, ty_opt, e) => {
                let res_opt = res_opt.clone();
                let ty_opt = ty_opt.clone();
                let e = e.clone();
                let env = env.clone();
                let p_ = p_.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(crate::check::expr::lets::start_check_let(env.clone(), st.clone(), p_.clone(), ty_opt.clone(), e.clone(), s.span.clone()), move |check_let_7989: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2, st2) = check_let_7989;
                    prism_rtl::Turn::Finished((env2.clone(), st2.clone(), res_opt.clone()))
                })
            },
            crate::syntax::StmtKind::SFn(f) => {
                let res_opt = res_opt.clone();
                let env = env.clone();
                let f = f.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(crate::check::expr::lets::start_pre_bind(env.clone(), st.clone(), s.clone()), move |pre_bind_8092: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env1, st1) = pre_bind_8092;
                    call_then(crate::check::expr::lets::start_check_local_fn(env1.clone(), st1.clone(), f.clone(), s.span.clone()), move |check_local_fn_8139: (crate::check::expr::Env, crate::check::types::St)| {
                        let (env2, st2) = check_local_fn_8139;
                        prism_rtl::Turn::Finished((env2.clone(), st2.clone(), res_opt.clone()))
                    })
                })
            },
            crate::syntax::StmtKind::SSignature(_) => {
                let res_opt = res_opt.clone();
                let env = env.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(crate::check::expr::lets::start_pre_bind(env.clone(), st.clone(), s.clone()), move |pre_bind_8252: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2, st2) = pre_bind_8252;
                    prism_rtl::Turn::Finished((env2.clone(), st2.clone(), res_opt.clone()))
                })
            },
            crate::syntax::StmtKind::SExpr(e) => if *last {
                {
                    let e = e.clone();
                    let env = env.clone();
                    let last = *last;
                    let mark = mark.clone();
                    let st = st.clone();
                    call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_8358: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t, st1) = infer_8358;
                        let (v_, st2) = crate::check::types::fresh_var(&st1, &false, &Text::lit(""));
                        call_then(crate::check::types::unify::start_unify(st2.clone(), crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), t.clone(), e.span.clone()), move |unify_8450: crate::check::types::St| {
                            let st3 = unify_8450;
                            prism_rtl::Turn::Finished((env.clone(), st3.clone(), Some(crate::check::types::Ty::TySig(mark.clone(), Rc::new(v_.clone())))))
                        })
                    })
                }
            } else {
                {
                    let res_opt = res_opt.clone();
                    let e = e.clone();
                    let env = env.clone();
                    let st = st.clone();
                    call_then(crate::check::expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_8717: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t, st1) = infer_8717;
                        call_then(crate::check::blocks::start_discarded(st1.clone(), t.clone(), e.span.clone()), move |discarded_8754: crate::check::types::St| prism_rtl::Turn::Finished((env.clone(), discarded_8754, res_opt.clone())))
                    })
                }
            },
            _ => prism_rtl::Turn::Finished((env.clone(), crate::check::types::recording::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a widget or `update` block")), res_opt.clone())),
        }
    }
}

/// `Start GivenStmt, x`: what the function value is when passed to `@Run`.
pub fn start_given_stmt(env: crate::check::expr::Env, st: crate::check::types::St, s: crate::syntax::Stmt, mark: Text, last: bool, res_opt: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>> {
    Rc::new(GivenStmt { env, st, s, mark, last, res_opt })
}
