//! The module `Check.Blocks.Structure`, from `target/bootstrap/src/prismc/check/blocks/structure.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_rebuild(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, scrut_p2: &crate::syntax::Expr, body_p3: &crate::syntax::Block, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p6, st1_p7) = crate::check::expr::infer(env_p0, st_p1, scrut_p2);
    let (inner_pc, st2_pd) = match crate::check::types::recording::walk(&st1_p7, &t_p6) {
        crate::check::types::Ty::TySig(m1650_0_0, i_p8) if (&m1650_0_0 == &Text::lit("$")) => ((*i_p8).clone(), st1_p7.clone()),
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st1_p7.clone()),
        crate::check::types::Ty::TyFlex(_) => {
            let (v_p9, s2_pa) = crate::check::types::fresh_var(&st1_p7, &false, &Text::lit(""));
            (v_p9.clone(), crate::check::types::unify::unify(&s2_pa, &crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_p9.clone())), &t_p6, &scrut_p2.span))
        },
        other_pb => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(&st1_p7, &Text::lit("mismatch"), &scrut_p2.span, &Text::from(format!("`rebuild` builds over a dynamic; this is `{}`", &crate::check::types::show_ty(&st1_p7, &other_pb))), &Text::lit("a plain value is built once: write the block\'s lines in place"))),
        _ => unreachable!("no arm matched"),
    };
    let env2_p5 = with_topic(env_p0, &Text::lit("_"), &inner_pc);
    let (res_pe, st3_pf) = crate::check::blocks::infer_widget_block(&env2_p5, &st2_pd, body_p3);
    match crate::check::types::recording::walk(&st3_pf, &res_pe) {
        crate::check::types::Ty::TyCon(m2163_0_0, m2163_0_1) if (&m2163_0_0 == &Text::lit("unit")) && ((&m2163_0_1).len() == 0) => (crate::check::types::t_unit(), st3_pf.clone()),
        other_pg => (crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(other_pg)), st3_pf.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InferRebuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferRebuild {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub scrut_p2: crate::syntax::Expr,
    pub body_p3: crate::syntax::Block,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferRebuild {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let scrut_p2 = &self.scrut_p2;
        let body_p3 = &self.body_p3;
        let span_p4 = &self.span_p4;
        let body_p3 = body_p3.clone();
        let env_p0 = env_p0.clone();
        let scrut_p2 = scrut_p2.clone();
        let span_p4 = span_p4.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), scrut_p2.clone()), move |infer_1604: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p6, st1_p7) = infer_1604;
            call_then(crate::check::types::recording::start_walk(st1_p7.clone(), t_p6.clone()), move |walk_1656: crate::check::types::Ty| {
                let (inner_pc, st2_pd) = match walk_1656 {
                    crate::check::types::Ty::TySig(m1650_0_0, i_p8) if (&m1650_0_0 == &Text::lit("$")) => ((*i_p8).clone(), st1_p7.clone()),
                    crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st1_p7.clone()),
                    crate::check::types::Ty::TyFlex(_) => {
                        let (v_p9, s2_pa) = crate::check::types::fresh_var(&st1_p7, &false, &Text::lit(""));
                        (v_p9.clone(), crate::check::types::unify::unify(&s2_pa, &crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_p9.clone())), &t_p6, &scrut_p2.span))
                    },
                    other_pb => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix(&st1_p7, &Text::lit("mismatch"), &scrut_p2.span, &Text::from(format!("`rebuild` builds over a dynamic; this is `{}`", &crate::check::types::show_ty(&st1_p7, &other_pb))), &Text::lit("a plain value is built once: write the block\'s lines in place"))),
                    _ => unreachable!("no arm matched"),
                };
                let env2_p5 = with_topic(&env_p0, &Text::lit("_"), &inner_pc);
                call_then(crate::check::blocks::start_infer_widget_block(env2_p5.clone(), st2_pd.clone(), body_p3.clone()), move |infer_widget_block_2126: (crate::check::types::Ty, crate::check::types::St)| {
                    let (res_pe, st3_pf) = infer_widget_block_2126;
                    call_then(crate::check::types::recording::start_walk(st3_pf.clone(), res_pe.clone()), move |walk_2169: crate::check::types::Ty| match walk_2169 {
                        crate::check::types::Ty::TyCon(m2163_0_0, m2163_0_1) if (&m2163_0_0 == &Text::lit("unit")) && ((&m2163_0_1).len() == 0) => prism_rtl::Turn::Finished((crate::check::types::t_unit(), st3_pf.clone())),
                        other_pg => prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(other_pg.clone())), st3_pf.clone())),
                        _ => unreachable!("no arm matched"),
                    })
                })
            })
        })
    }
}

/// `Start InferRebuild, x`: what the function value is when passed to `@Run`.
pub fn start_infer_rebuild(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, scrut_p2: crate::syntax::Expr, body_p3: crate::syntax::Block, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferRebuild { env_p0, st_p1, scrut_p2, body_p3, span_p4 })
}

/// ```prism
/// WithTopic: fn Env, Text, Ty -> Env
/// ```
pub fn with_topic(env_p0: &crate::check::expr::Env, name_p1: &Text, t_p2: &crate::check::types::Ty) -> crate::check::expr::Env {
    let mut this: crate::check::expr::Env = crate::check::expr::with_local(env_p0, name_p1, &crate::check::types::schemes::mono(t_p2));
    this.pending = filter(&this.pending, &(|x_p3: &Text| x_p3 != name_p1));
    this
}

/// ```prism
/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_for(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, binders_o2: &Option<crate::syntax::ForBinders>, source_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    if env_p0.in_update {
        (crate::check::types::t_unit(), crate::check::blocks::borrows::update_for(env_p0, st_p1, binders_o2, source_p3, body_p4, span_p5))
    } else {
        {
            let (t_pb, st1_pc) = crate::check::expr::infer(env_p0, st_p1, source_p3);
            let sh_p6 = crate::check::types::head_sigil(&st1_pc, &t_pb);
            let coll_p7 = if &sh_p6 == &Text::lit("$") {
                crate::check::expr::inner_of(&st1_pc, &t_pb)
            } else {
                t_pb.clone()
            };
            let st2_p8 = if (&sh_p6 == &Text::lit("!")) || (&sh_p6 == &Text::lit("@")) {
                crate::check::types::recording::err(&st1_pc, &Text::lit("mismatch"), &source_p3.span, &Text::from(format!("`for` runs over a map or an array, plain or dynamic; this is `{}`", &crate::check::types::show_ty(&st1_pc, &t_pb))))
            } else {
                st1_pc.clone()
            };
            let (k_pd, v_pe, st3_pf) = coll_parts(&st2_p8, &coll_p7, &source_p3.span);
            let live_p9 = &sh_p6 == &Text::lit("$");
            let env1_pa = loop_indices(env_p0);
            let (env2_pg, st4_ph) = bind_for_binders(&env1_pa, &st3_pf, binders_o2, &k_pd, &v_pe, &live_p9);
            let (res_pi, st5_pj) = crate::check::blocks::infer_widget_block(&env2_pg, &st4_ph, body_p4);
            gather(&st5_pj, &res_pi, &k_pd, &live_p9)
        }
    }
}

/// The step machine of `InferFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferFor {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub binders_o2: Option<crate::syntax::ForBinders>,
    pub source_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferFor {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let binders_o2 = &self.binders_o2;
        let source_p3 = &self.source_p3;
        let body_p4 = &self.body_p4;
        let span_p5 = &self.span_p5;
        if env_p0.in_update {
            {
                let binders_o2 = binders_o2.clone();
                let body_p4 = body_p4.clone();
                let env_p0 = env_p0.clone();
                let source_p3 = source_p3.clone();
                let span_p5 = span_p5.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::blocks::borrows::start_update_for(env_p0.clone(), st_p1.clone(), binders_o2.clone(), source_p3.clone(), body_p4.clone(), span_p5.clone()), move |update_for_2754: crate::check::types::St| prism_rtl::Turn::Finished((crate::check::types::t_unit(), update_for_2754)))
            }
        } else {
            {
                let binders_o2 = binders_o2.clone();
                let body_p4 = body_p4.clone();
                let env_p0 = env_p0.clone();
                let source_p3 = source_p3.clone();
                let span_p5 = span_p5.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), source_p3.clone()), move |infer_2840: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pb, st1_pc) = infer_2840;
                    call_then(crate::check::types::start_head_sigil(st1_pc.clone(), t_pb.clone()), move |head_sigil_2879: Text| {
                        let sh_p6 = head_sigil_2879;
                        let coll_p7 = if &sh_p6 == &Text::lit("$") {
                            crate::check::expr::inner_of(&st1_pc, &t_pb)
                        } else {
                            t_pb.clone()
                        };
                        let st2_p8 = if (&sh_p6 == &Text::lit("!")) || (&sh_p6 == &Text::lit("@")) {
                            crate::check::types::recording::err(&st1_pc, &Text::lit("mismatch"), &source_p3.span, &Text::from(format!("`for` runs over a map or an array, plain or dynamic; this is `{}`", &crate::check::types::show_ty(&st1_pc, &t_pb))))
                        } else {
                            st1_pc.clone()
                        };
                        call_then(start_coll_parts(st2_p8.clone(), coll_p7.clone(), source_p3.span.clone()), move |coll_parts_3150: (crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)| {
                            let (k_pd, v_pe, st3_pf) = coll_parts_3150;
                            let live_p9 = &sh_p6 == &Text::lit("$");
                            let env1_pa = loop_indices(&env_p0);
                            call_then(start_bind_for_binders(env1_pa.clone(), st3_pf.clone(), binders_o2.clone(), k_pd.clone(), v_pe.clone(), live_p9), move |bind_for_binders_3275: (crate::check::expr::Env, crate::check::types::St)| {
                                let (env2_pg, st4_ph) = bind_for_binders_3275;
                                call_then(crate::check::blocks::start_infer_widget_block(env2_pg.clone(), st4_ph.clone(), body_p4.clone()), move |infer_widget_block_3349: (crate::check::types::Ty, crate::check::types::St)| {
                                    let (res_pi, st5_pj) = infer_widget_block_3349;
                                    prism_rtl::Turn::More(Rc::new(Gather { st_p0: st5_pj.clone(), res_p1: res_pi.clone(), k_p2: k_pd.clone(), live_p3: live_p9 }))
                                })
                            })
                        })
                    })
                })
            }
        }
    }
}

/// `Start InferFor, x`: what the function value is when passed to `@Run`.
pub fn start_infer_for(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, binders_o2: Option<crate::syntax::ForBinders>, source_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferFor { env_p0, st_p1, binders_o2, source_p3, body_p4, span_p5 })
}

/// ```prism
/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
/// ```
pub fn coll_parts(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, span_p2: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St) {
    'm3542: {
        let scrutinee = &crate::check::types::recording::walk(st_p0, t_p1);
        if let crate::check::types::Ty::TyMap(k_p3, v_p4) = scrutinee {
            break 'm3542 ((**k_p3).clone(), (**v_p4).clone(), st_p0.clone());
        }
        if let crate::check::types::Ty::TyArray(v_p5) = scrutinee {
            break 'm3542 (crate::check::types::t_nat(), (**v_p5).clone(), st_p0.clone());
        }
        if let crate::check::types::Ty::TyCon(m3542_2_0, m3542_2_1) = scrutinee && (m3542_2_0 == &Text::lit("Buffer")) && (m3542_2_1.len() == 1) && let Some(v_p6) = index(m3542_2_1, &Nat::from(0u32)) {
            break 'm3542 (crate::check::types::t_nat(), v_p6.clone(), st_p0.clone());
        }
        if let crate::check::types::Ty::TyErr = scrutinee {
            break 'm3542 (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, st_p0.clone());
        }
        if let crate::check::types::Ty::TyFlex(_) = scrutinee {
            break 'm3542 {
                let (v_p7, st2_p8) = crate::check::types::fresh_var(st_p0, &false, &Text::lit(""));
                (crate::check::types::t_nat(), v_p7.clone(), crate::check::types::unify::unify(&st2_p8, &crate::check::types::Ty::TyArray(Rc::new(v_p7.clone())), t_p1, span_p2))
            };
        }
        if let other_p9 = scrutinee {
            break 'm3542 (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, crate::check::types::recording::err(st_p0, &Text::lit("mismatch"), span_p2, &Text::from(format!("`for` runs over a map or an array; this is `{}`", &crate::check::types::show_ty(st_p0, other_p9)))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CollParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
/// ```
pub struct CollParts {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub span_p2: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)> for CollParts {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let span_p2 = &self.span_p2;
        let span_p2 = span_p2.clone();
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), t_p1.clone()), move |walk_3548: crate::check::types::Ty| 'm3542: {
            if let crate::check::types::Ty::TyMap(k_p3, v_p4) = &walk_3548 {
                break 'm3542 prism_rtl::Turn::Finished(((**k_p3).clone(), (**v_p4).clone(), st_p0.clone()));
            }
            if let crate::check::types::Ty::TyArray(v_p5) = &walk_3548 {
                break 'm3542 prism_rtl::Turn::Finished((crate::check::types::t_nat(), (**v_p5).clone(), st_p0.clone()));
            }
            if let crate::check::types::Ty::TyCon(m3542_2_0, m3542_2_1) = &walk_3548 && (m3542_2_0 == &Text::lit("Buffer")) && (m3542_2_1.len() == 1) && let Some(v_p6) = index(m3542_2_1, &Nat::from(0u32)) {
                break 'm3542 prism_rtl::Turn::Finished((crate::check::types::t_nat(), v_p6.clone(), st_p0.clone()));
            }
            if let crate::check::types::Ty::TyErr = &walk_3548 {
                break 'm3542 prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, st_p0.clone()));
            }
            if let crate::check::types::Ty::TyFlex(_) = &walk_3548 {
                break 'm3542 {
                    let (v_p7, st2_p8) = crate::check::types::fresh_var(&st_p0, &false, &Text::lit(""));
                    call_then(crate::check::types::unify::start_unify(st2_p8.clone(), crate::check::types::Ty::TyArray(Rc::new(v_p7.clone())), t_p1.clone(), span_p2.clone()), move |unify_3782: crate::check::types::St| prism_rtl::Turn::Finished((crate::check::types::t_nat(), v_p7.clone(), unify_3782)))
                };
            }
            if let other_p9 = &walk_3548 {
                break 'm3542 {
                    let other_p9 = other_p9.clone();
                    call_then(crate::check::types::start_show_ty(st_p0.clone(), other_p9.clone()), move |show_ty_3917: Text| prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, crate::check::types::recording::err(&st_p0, &Text::lit("mismatch"), &span_p2, &Text::from(format!("`for` runs over a map or an array; this is `{}`", &show_ty_3917))))))
                };
            }
            unreachable!("no clause matched")
        })
    }
}

/// `Start CollParts, x`: what the function value is when passed to `@Run`.
pub fn start_coll_parts(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty, span_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(CollParts { st_p0, t_p1, span_p2 })
}

/// ```prism
/// LoopIndices: fn Env -> Env
/// ```
pub fn loop_indices(env_p0: &crate::check::expr::Env) -> crate::check::expr::Env {
    let outer1_o1 = get(&env_p0.locals, &Text::lit("ix"));
    let outer2_o2 = get(&env_p0.locals, &Text::lit("jx"));
    let e1_p3 = crate::check::expr::with_local(env_p0, &Text::lit("ix"), &crate::check::types::schemes::mono(&crate::check::types::t_nat()));
    let e2_p4 = match &outer1_o1 {
        Some(sc_p5) => crate::check::expr::with_local(&e1_p3, &Text::lit("jx"), sc_p5),
        None => e1_p3.clone(),
    };
    match &outer2_o2 {
        Some(sc_p6) => crate::check::expr::with_local(&e2_p4, &Text::lit("kx"), sc_p6),
        None => e2_p4.clone(),
    }
}

/// ```prism
/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_for_binders(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, binders_o2: &Option<crate::syntax::ForBinders>, k_p3: &crate::check::types::Ty, v_p4: &crate::check::types::Ty, live_p5: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    let inner_p6 = *live_p5 && (&crate::check::types::head_sigil(st_p1, v_p4) == &Text::lit("$"));
    let vt_p7 = if *live_p5 && !inner_p6 {
        crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_p4.clone()))
    } else {
        v_p4.clone()
    };
    match binders_o2 {
        None => {
            let e1_p8 = with_topic(env_p0, &(if *live_p5 { Text::lit("$_") } else { Text::lit("_") }), &vt_p7);
            (with_topic(&e1_p8, &Text::lit("key"), k_p3), st_p1.clone())
        },
        Some(bs_p9) => match &bs_p9.second {
            Some(second_pa) => {
                let (e1_pb, st1_pc) = crate::check::expr::patterns::bind_pattern(&unpending(env_p0), st_p1, &bs_p9.first, k_p3, &false);
                let (st2_pd, vt2_pe) = for_inner_mark(&st1_pc, &inner_p6, second_pa, v_p4, &vt_p7);
                crate::check::expr::patterns::bind_pattern(&e1_pb, &st2_pd, second_pa, &vt2_pe, &false)
            },
            None => {
                let e1_pf = with_topic(env_p0, &Text::lit("key"), k_p3);
                let (st2_pg, vt2_ph) = for_inner_mark(st_p1, &inner_p6, &bs_p9.first, v_p4, &vt_p7);
                crate::check::expr::patterns::bind_pattern(&unpending(&e1_pf), &st2_pg, &bs_p9.first, &vt2_ph, &false)
            },
        },
    }
}

/// The step machine of `BindForBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
/// ```
pub struct BindForBinders {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub binders_o2: Option<crate::syntax::ForBinders>,
    pub k_p3: crate::check::types::Ty,
    pub v_p4: crate::check::types::Ty,
    pub live_p5: bool,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindForBinders {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let binders_o2 = &self.binders_o2;
        let k_p3 = &self.k_p3;
        let v_p4 = &self.v_p4;
        let live_p5 = &self.live_p5;
        let inner_p6 = *live_p5 && (&crate::check::types::head_sigil(st_p1, v_p4) == &Text::lit("$"));
        let vt_p7 = if *live_p5 && !inner_p6 {
            crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_p4.clone()))
        } else {
            v_p4.clone()
        };
        match binders_o2 {
            None => {
                let e1_p8 = with_topic(env_p0, &(if *live_p5 { Text::lit("$_") } else { Text::lit("_") }), &vt_p7);
                prism_rtl::Turn::Finished((with_topic(&e1_p8, &Text::lit("key"), k_p3), st_p1.clone()))
            },
            Some(bs_p9) => match &bs_p9.second {
                Some(second_pa) => {
                    let bs_p9 = bs_p9.clone();
                    let env_p0 = env_p0.clone();
                    let k_p3 = k_p3.clone();
                    let second_pa = second_pa.clone();
                    let st_p1 = st_p1.clone();
                    let v_p4 = v_p4.clone();
                    call_then(crate::check::expr::patterns::start_bind_pattern(unpending(&env_p0), st_p1.clone(), bs_p9.first.clone(), k_p3.clone(), false), move |bind_pattern_5167: (crate::check::expr::Env, crate::check::types::St)| {
                        let (e1_pb, st1_pc) = bind_pattern_5167;
                        let (st2_pd, vt2_pe) = for_inner_mark(&st1_pc, &inner_p6, &second_pa, &v_p4, &vt_p7);
                        prism_rtl::Turn::More(Rc::new(crate::check::expr::patterns::BindPattern { env_p0: e1_pb.clone(), st_p1: st2_pd.clone(), p_p2: second_pa.clone(), t_p3: vt2_pe.clone(), refutable_p4: false }))
                    })
                },
                None => {
                    let e1_pf = with_topic(env_p0, &Text::lit("key"), k_p3);
                    let (st2_pg, vt2_ph) = for_inner_mark(st_p1, &inner_p6, &bs_p9.first, v_p4, &vt_p7);
                    prism_rtl::Turn::More(Rc::new(crate::check::expr::patterns::BindPattern { env_p0: unpending(&e1_pf), st_p1: st2_pg.clone(), p_p2: bs_p9.first.clone(), t_p3: vt2_ph.clone(), refutable_p4: false }))
                },
            },
        }
    }
}

/// `Start BindForBinders, x`: what the function value is when passed to `@Run`.
pub fn start_bind_for_binders(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, binders_o2: Option<crate::syntax::ForBinders>, k_p3: crate::check::types::Ty, v_p4: crate::check::types::Ty, live_p5: bool) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    Rc::new(BindForBinders { env_p0, st_p1, binders_o2, k_p3, v_p4, live_p5 })
}

/// ```prism
/// ForInnerMark: fn St, Bool, Pattern, Ty, Ty -> ((St, Ty))
/// ```
pub fn for_inner_mark(st_p0: &crate::check::types::St, inner_p1: &bool, p_p2: &crate::syntax::Pattern_, v_p3: &crate::check::types::Ty, vt_p4: &crate::check::types::Ty) -> (crate::check::types::St, crate::check::types::Ty) {
    match &*p_p2.kind {
        crate::syntax::PatternKind::PName(n_p5) => if *inner_p1 && (&n_p5.sigils == &Text::lit("$$")) {
            {
                let name_p6 = crate::check::env::sname_key(n_p5);
                let bare_p7 = crate::syntax::lexer::chars::drop_prefix(&name_p6, &Text::lit("$$"));
                (crate::check::types::recording::err_fix(st_p0, &Text::lit("mark-stack"), &n_p5.span, &Text::from(format!("`{}` shows `$$`, a dynamic of a dynamic; a `for` over `$(k ==> $v)` binds the value under the row\'s key, which follows a replaced dynamic (Semantics ch. 4)", &name_p6)), &Text::from(format!("write `${}`, and read it where `@Flatten {}` was", &bare_p7, &name_p6))), crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(v_p3.clone())))
            }
        } else {
            (st_p0.clone(), vt_p4.clone())
        },
        _ => (st_p0.clone(), vt_p4.clone()),
    }
}

/// ```prism
/// Unpending: fn Env -> Env
/// ```
pub fn unpending(env_p0: &crate::check::expr::Env) -> crate::check::expr::Env {
    let mut this: crate::check::expr::Env = env_p0.clone();
    this.pending = Array::new();
    this
}

/// ```prism
/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
/// ```
pub fn gather(st_p0: &crate::check::types::St, res_p1: &crate::check::types::Ty, k_p2: &crate::check::types::Ty, live_p3: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::check::types::recording::walk(st_p0, res_p1) {
        crate::check::types::Ty::TyCon(m6848_0_0, m6848_0_1) if (&m6848_0_0 == &Text::lit("unit")) && ((&m6848_0_1).len() == 0) => (crate::check::types::t_unit(), st_p0.clone()),
        crate::check::types::Ty::TySig(m6848_1_0, t_p4) if (&m6848_1_0 == &Text::lit("!")) => (crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k_p2.clone()), Rc::new((*t_p4).clone())))), st_p0.clone()),
        crate::check::types::Ty::TySig(m6848_2_0, t_p5) if (&m6848_2_0 == &Text::lit("$")) => (crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k_p2.clone()), Rc::new((*t_p5).clone())))), st_p0.clone()),
        crate::check::types::Ty::TyTuple(ts_p6) => if run_to_end(fold_job(ts_p6.clone(), false, {
            let st_p0 = st_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let seen_p7 = p0;
                    let x_p8 = p1;
                    prism_rtl::Turn::Finished(seen_p7 || crate::check::expr::is_time_sigil(&crate::check::types::head_sigil(&st_p0, &x_p8)))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })) {
            {
                let (parts_pe, st2_pf) = run_to_end(fold_job(ts_p6.clone(), (Array::new(), st_p0.clone()), {
                    let k_p2 = k_p2.clone();
                    let live_p3 = *live_p3;
                    Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)| {
                        let k_p2 = k_p2.clone();
                        let live_p3 = live_p3;
                        entered(once_job(move || {
                            let (acc_p9, s_pa) = p0;
                            let x_pb = p1;
                            call_then(start_gather(s_pa.clone(), x_pb.clone(), k_p2.clone(), live_p3), move |gather_7208: (crate::check::types::Ty, crate::check::types::St)| {
                                let (g_pc, s2_pd) = gather_7208;
                                prism_rtl::Turn::Finished((push(&acc_p9, &g_pc), s2_pd.clone()))
                            })
                        }))
                    }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
                }));
                (crate::check::types::Ty::TyTuple(parts_pe.clone()), st2_pf.clone())
            }
        } else {
            (live_map(live_p3, k_p2, &crate::check::types::Ty::TyTuple(ts_p6.clone())), st_p0.clone())
        },
        other_pg => (live_map(live_p3, k_p2, &other_pg), st_p0.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Gather`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
/// ```
pub struct Gather {
    pub st_p0: crate::check::types::St,
    pub res_p1: crate::check::types::Ty,
    pub k_p2: crate::check::types::Ty,
    pub live_p3: bool,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for Gather {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let res_p1 = &self.res_p1;
        let k_p2 = &self.k_p2;
        let live_p3 = &self.live_p3;
        let k_p2 = k_p2.clone();
        let live_p3 = *live_p3;
        let res_p1 = res_p1.clone();
        let st_p0 = st_p0.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), res_p1.clone()), move |walk_6854: crate::check::types::Ty| match walk_6854 {
            crate::check::types::Ty::TyCon(m6848_0_0, m6848_0_1) if (&m6848_0_0 == &Text::lit("unit")) && ((&m6848_0_1).len() == 0) => prism_rtl::Turn::Finished((crate::check::types::t_unit(), st_p0.clone())),
            crate::check::types::Ty::TySig(m6848_1_0, t_p4) if (&m6848_1_0 == &Text::lit("!")) => prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("!"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k_p2.clone()), Rc::new((*t_p4).clone())))), st_p0.clone())),
            crate::check::types::Ty::TySig(m6848_2_0, t_p5) if (&m6848_2_0 == &Text::lit("$")) => prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k_p2.clone()), Rc::new((*t_p5).clone())))), st_p0.clone())),
            crate::check::types::Ty::TyTuple(ts_p6) => call_value(fold_job(ts_p6.clone(), false, {
                let st_p0 = st_p0.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let seen_p7 = p0;
                        let x_p8 = p1;
                        prism_rtl::Turn::Finished(seen_p7 || crate::check::expr::is_time_sigil(&crate::check::types::head_sigil(&st_p0, &x_p8)))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |fold_7037: bool| if fold_7037 {
                call_value(fold_job(ts_p6.clone(), (Array::new(), st_p0.clone()), {
                    let k_p2 = k_p2.clone();
                    let live_p3 = live_p3;
                    Rc::new(move |(p0, p1): ((Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)| {
                        let k_p2 = k_p2.clone();
                        let live_p3 = live_p3;
                        entered(once_job(move || {
                            let (acc_p9, s_pa) = p0;
                            let x_pb = p1;
                            call_then(start_gather(s_pa.clone(), x_pb.clone(), k_p2.clone(), live_p3), move |gather_7208: (crate::check::types::Ty, crate::check::types::St)| {
                                let (g_pc, s2_pd) = gather_7208;
                                prism_rtl::Turn::Finished((push(&acc_p9, &g_pc), s2_pd.clone()))
                            })
                        }))
                    }) as Rc<dyn Fn(((Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Array<crate::check::types::Ty>, crate::check::types::St)>>>
                }), move |fold_7136: (Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (parts_pe, st2_pf) = fold_7136;
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TyTuple(parts_pe.clone()), st2_pf.clone()))
                })
            } else {
                prism_rtl::Turn::Finished((live_map(&live_p3, &k_p2, &crate::check::types::Ty::TyTuple(ts_p6.clone())), st_p0.clone()))
            }),
            other_pg => prism_rtl::Turn::Finished((live_map(&live_p3, &k_p2, &other_pg), st_p0.clone())),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start Gather, x`: what the function value is when passed to `@Run`.
pub fn start_gather(st_p0: crate::check::types::St, res_p1: crate::check::types::Ty, k_p2: crate::check::types::Ty, live_p3: bool) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(Gather { st_p0, res_p1, k_p2, live_p3 })
}

/// ```prism
/// LiveMap: fn Bool, Ty, Ty -> Ty
/// ```
pub fn live_map(live_p0: &bool, k_p1: &crate::check::types::Ty, v_p2: &crate::check::types::Ty) -> crate::check::types::Ty {
    if *live_p0 {
        crate::check::types::Ty::TySig(Text::lit("$"), Rc::new(crate::check::types::Ty::TyMap(Rc::new(k_p1.clone()), Rc::new(v_p2.clone()))))
    } else {
        crate::check::types::Ty::TyMap(Rc::new(k_p1.clone()), Rc::new(v_p2.clone()))
    }
}

/// ```prism
/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
/// ```
pub fn infer_given(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let mark_p4 = if (&env_p0.mark == &Text::lit("?")) || (&env_p0.mark == &Text::lit("~")) {
        env_p0.mark.clone()
    } else {
        given_mark_of(&b_p2.stmts)
    };
    infer_given_block(env_p0, st_p1, b_p2, &mark_p4)
}

/// The step machine of `InferGiven`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
/// ```
pub struct InferGiven {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferGiven {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        let span_p3 = &self.span_p3;
        let mark_p4 = if (&env_p0.mark == &Text::lit("?")) || (&env_p0.mark == &Text::lit("~")) {
            env_p0.mark.clone()
        } else {
            given_mark_of(&b_p2.stmts)
        };
        prism_rtl::Turn::More(Rc::new(InferGivenBlock { env_p0: env_p0.clone(), st_p1: st_p1.clone(), b_p2: b_p2.clone(), mark_p3: mark_p4.clone() }))
    }
}

/// `Start InferGiven, x`: what the function value is when passed to `@Run`.
pub fn start_infer_given(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferGiven { env_p0, st_p1, b_p2, span_p3 })
}

/// ```prism
/// GivenMarkOf: fn [Stmt] -> Text
/// ```
pub fn given_mark_of(stmts_p0: &Array<crate::syntax::Stmt>) -> Text {
    fold(stmts_p0, &Text::lit("?"), &(|m_p1: &Text, s_p2: &crate::syntax::Stmt| m_p1.clone()))
}

/// ```prism
/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
/// ```
pub fn infer_given_block(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block, mark_p3: &Text) -> (crate::check::types::Ty, crate::check::types::St) {
    let n_p4 = len(&b_p2.stmts);
    let (env2_pa, st2_pb, res_oc) = run_to_end(fold_job(crate::check::errors::range0(&n_p4), (env_p0.clone(), st_p1.clone(), None), {
        let b_p2 = b_p2.clone();
        let mark_p3 = mark_p3.clone();
        let n_p4 = n_p4.clone();
        Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)| {
            let b_p2 = b_p2.clone();
            let mark_p3 = mark_p3.clone();
            let n_p4 = n_p4.clone();
            entered(once_job(move || {
                let (en_p5, s_p6, r_o7) = p0;
                let i_p8 = p1;
                {
                    let stmt_p9 = or(&index(&b_p2.stmts, &i_p8), &crate::check::blocks::dummy_stmt2());
                    prism_rtl::Turn::More(Rc::new(GivenStmt { env_p0: en_p5.clone(), st_p1: s_p6.clone(), s_p2: stmt_p9.clone(), mark_p3: mark_p3.clone(), last_p4: &(&i_p8 + &Nat::from(1u32)) == &n_p4, res_o5: r_o7.clone() }))
                }
            }))
        }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>>>
    }));
    match &res_oc {
        Some(t_pd) => (t_pd.clone(), st2_pb.clone()),
        None => {
            let (v_pe, st3_pf) = crate::check::types::fresh_var(&st2_pb, &false, &Text::lit(""));
            (crate::check::types::Ty::TySig(mark_p3.clone(), Rc::new(v_pe.clone())), st3_pf.clone())
        },
    }
}

/// The step machine of `InferGivenBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
/// ```
pub struct InferGivenBlock {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
    pub mark_p3: Text,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferGivenBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        let mark_p3 = &self.mark_p3;
        let n_p4 = len(&b_p2.stmts);
        let b_p2 = b_p2.clone();
        let env_p0 = env_p0.clone();
        let mark_p3 = mark_p3.clone();
        let st_p1 = st_p1.clone();
        call_value(fold_job(crate::check::errors::range0(&n_p4), (env_p0.clone(), st_p1.clone(), None), {
            let b_p2 = b_p2.clone();
            let mark_p3 = mark_p3.clone();
            let n_p4 = n_p4.clone();
            Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)| {
                let b_p2 = b_p2.clone();
                let mark_p3 = mark_p3.clone();
                let n_p4 = n_p4.clone();
                entered(once_job(move || {
                    let (en_p5, s_p6, r_o7) = p0;
                    let i_p8 = p1;
                    {
                        let stmt_p9 = or(&index(&b_p2.stmts, &i_p8), &crate::check::blocks::dummy_stmt2());
                        prism_rtl::Turn::More(Rc::new(GivenStmt { env_p0: en_p5.clone(), st_p1: s_p6.clone(), s_p2: stmt_p9.clone(), mark_p3: mark_p3.clone(), last_p4: &(&i_p8 + &Nat::from(1u32)) == &n_p4, res_o5: r_o7.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(((crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>>>
        }), move |fold_8405: (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)| {
            let (env2_pa, st2_pb, res_oc) = fold_8405;
            match &res_oc {
                Some(t_pd) => prism_rtl::Turn::Finished((t_pd.clone(), st2_pb.clone())),
                None => {
                    let (v_pe, st3_pf) = crate::check::types::fresh_var(&st2_pb, &false, &Text::lit(""));
                    prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(mark_p3.clone(), Rc::new(v_pe.clone())), st3_pf.clone()))
                },
            }
        })
    }
}

/// `Start InferGivenBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_given_block(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block, mark_p3: Text) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(InferGivenBlock { env_p0, st_p1, b_p2, mark_p3 })
}

/// ```prism
/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
/// ```
pub fn given_stmt(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, s_p2: &crate::syntax::Stmt, mark_p3: &Text, last_p4: &bool, res_o5: &Option<crate::check::types::Ty>) -> (crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>) {
    match &s_p2.kind {
        crate::syntax::StmtKind::SBind(p_p6, e_p7, None) => {
            let (t_p9, st1_pa) = crate::check::expr::infer(env_p0, st_p1, e_p7);
            let (v_pb, st2_pc) = crate::check::types::fresh_var(&st1_pa, &false, &Text::lit(""));
            let st3_p8 = crate::check::types::unify::unify(&st2_pc, &crate::check::types::Ty::TySig(mark_p3.clone(), Rc::new(v_pb.clone())), &t_p9, &e_p7.span);
            let (env2_pd, st4_pe) = crate::check::expr::patterns::bind_pattern(&unpending(env_p0), &st3_p8, p_p6, &v_pb, &true);
            (env2_pd.clone(), st4_pe.clone(), res_o5.clone())
        },
        crate::syntax::StmtKind::SRequire(c_pf) => (env_p0.clone(), crate::check::expr::lifting::check_cond(env_p0, st_p1, c_pf), res_o5.clone()),
        crate::syntax::StmtKind::SForbid(c_pg) => (env_p0.clone(), crate::check::expr::lifting::check_cond(env_p0, st_p1, c_pg), res_o5.clone()),
        crate::syntax::StmtKind::SLet(p_ph, ty_oi, e_pj) => {
            let (env2_pk, st2_pl) = crate::check::expr::lets::check_let(env_p0, st_p1, p_ph, ty_oi, e_pj, &s_p2.span);
            (env2_pk.clone(), st2_pl.clone(), res_o5.clone())
        },
        crate::syntax::StmtKind::SFn(f_pm) => {
            let (env1_pn, st1_po) = crate::check::expr::lets::pre_bind(env_p0, st_p1, s_p2);
            let (env2_pp, st2_pq) = crate::check::expr::lets::check_local_fn(&env1_pn, &st1_po, f_pm, &s_p2.span);
            (env2_pp.clone(), st2_pq.clone(), res_o5.clone())
        },
        crate::syntax::StmtKind::SSignature(_) => {
            let (env2_pr, st2_ps) = crate::check::expr::lets::pre_bind(env_p0, st_p1, s_p2);
            (env2_pr.clone(), st2_ps.clone(), res_o5.clone())
        },
        crate::syntax::StmtKind::SExpr(e_pt) => if *last_p4 {
            {
                let (t_pv, st1_p10) = crate::check::expr::infer(env_p0, st_p1, e_pt);
                let (v_p11, st2_p12) = crate::check::types::fresh_var(&st1_p10, &false, &Text::lit(""));
                let st3_pu = crate::check::types::unify::unify(&st2_p12, &crate::check::types::Ty::TySig(mark_p3.clone(), Rc::new(v_p11.clone())), &t_pv, &e_pt.span);
                (env_p0.clone(), st3_pu.clone(), Some(crate::check::types::Ty::TySig(mark_p3.clone(), Rc::new(v_p11.clone()))))
            }
        } else {
            {
                let (t_p13, st1_p14) = crate::check::expr::infer(env_p0, st_p1, e_pt);
                (env_p0.clone(), crate::check::blocks::discarded(&st1_p14, &t_p13, &e_pt.span), res_o5.clone())
            }
        },
        _ => (env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &s_p2.span, &Text::lit("this statement belongs in a widget or `update` block")), res_o5.clone()),
    }
}

/// The step machine of `GivenStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
/// ```
pub struct GivenStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub s_p2: crate::syntax::Stmt,
    pub mark_p3: Text,
    pub last_p4: bool,
    pub res_o5: Option<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)> for GivenStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let s_p2 = &self.s_p2;
        let mark_p3 = &self.mark_p3;
        let last_p4 = &self.last_p4;
        let res_o5 = &self.res_o5;
        match &s_p2.kind {
            crate::syntax::StmtKind::SBind(p_p6, e_p7, None) => {
                let res_o5 = res_o5.clone();
                let e_p7 = e_p7.clone();
                let env_p0 = env_p0.clone();
                let mark_p3 = mark_p3.clone();
                let p_p6 = p_p6.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), e_p7.clone()), move |infer_8880: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_p9, st1_pa) = infer_8880;
                    let (v_pb, st2_pc) = crate::check::types::fresh_var(&st1_pa, &false, &Text::lit(""));
                    call_then(crate::check::types::unify::start_unify(st2_pc.clone(), crate::check::types::Ty::TySig(mark_p3.clone(), Rc::new(v_pb.clone())), t_p9.clone(), e_p7.span.clone()), move |unify_8964: crate::check::types::St| {
                        let st3_p8 = unify_8964;
                        call_then(crate::check::expr::patterns::start_bind_pattern(unpending(&env_p0), st3_p8.clone(), p_p6.clone(), v_pb.clone(), true), move |bind_pattern_9030: (crate::check::expr::Env, crate::check::types::St)| {
                            let (env2_pd, st4_pe) = bind_pattern_9030;
                            prism_rtl::Turn::Finished((env2_pd.clone(), st4_pe.clone(), res_o5.clone()))
                        })
                    })
                })
            },
            crate::syntax::StmtKind::SRequire(c_pf) => {
                let res_o5 = res_o5.clone();
                let c_pf = c_pf.clone();
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::expr::lifting::start_check_cond(env_p0.clone(), st_p1.clone(), c_pf.clone()), move |check_cond_9127: crate::check::types::St| prism_rtl::Turn::Finished((env_p0.clone(), check_cond_9127, res_o5.clone())))
            },
            crate::syntax::StmtKind::SForbid(c_pg) => {
                let res_o5 = res_o5.clone();
                let c_pg = c_pg.clone();
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::expr::lifting::start_check_cond(env_p0.clone(), st_p1.clone(), c_pg.clone()), move |check_cond_9180: crate::check::types::St| prism_rtl::Turn::Finished((env_p0.clone(), check_cond_9180, res_o5.clone())))
            },
            crate::syntax::StmtKind::SLet(p_ph, ty_oi, e_pj) => {
                let res_o5 = res_o5.clone();
                let ty_oi = ty_oi.clone();
                let e_pj = e_pj.clone();
                let env_p0 = env_p0.clone();
                let p_ph = p_ph.clone();
                let s_p2 = s_p2.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::expr::lets::start_check_let(env_p0.clone(), st_p1.clone(), p_ph.clone(), ty_oi.clone(), e_pj.clone(), s_p2.span.clone()), move |check_let_9258: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2_pk, st2_pl) = check_let_9258;
                    prism_rtl::Turn::Finished((env2_pk.clone(), st2_pl.clone(), res_o5.clone()))
                })
            },
            crate::syntax::StmtKind::SFn(f_pm) => {
                let res_o5 = res_o5.clone();
                let env_p0 = env_p0.clone();
                let f_pm = f_pm.clone();
                let s_p2 = s_p2.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::expr::lets::start_pre_bind(env_p0.clone(), st_p1.clone(), s_p2.clone()), move |pre_bind_9361: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env1_pn, st1_po) = pre_bind_9361;
                    call_then(crate::check::expr::lets::start_check_local_fn(env1_pn.clone(), st1_po.clone(), f_pm.clone(), s_p2.span.clone()), move |check_local_fn_9408: (crate::check::expr::Env, crate::check::types::St)| {
                        let (env2_pp, st2_pq) = check_local_fn_9408;
                        prism_rtl::Turn::Finished((env2_pp.clone(), st2_pq.clone(), res_o5.clone()))
                    })
                })
            },
            crate::syntax::StmtKind::SSignature(_) => {
                let res_o5 = res_o5.clone();
                let env_p0 = env_p0.clone();
                let s_p2 = s_p2.clone();
                let st_p1 = st_p1.clone();
                call_then(crate::check::expr::lets::start_pre_bind(env_p0.clone(), st_p1.clone(), s_p2.clone()), move |pre_bind_9521: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2_pr, st2_ps) = pre_bind_9521;
                    prism_rtl::Turn::Finished((env2_pr.clone(), st2_ps.clone(), res_o5.clone()))
                })
            },
            crate::syntax::StmtKind::SExpr(e_pt) => if *last_p4 {
                {
                    let e_pt = e_pt.clone();
                    let env_p0 = env_p0.clone();
                    let last_p4 = *last_p4;
                    let mark_p3 = mark_p3.clone();
                    let st_p1 = st_p1.clone();
                    call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), e_pt.clone()), move |infer_9627: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_pv, st1_p10) = infer_9627;
                        let (v_p11, st2_p12) = crate::check::types::fresh_var(&st1_p10, &false, &Text::lit(""));
                        call_then(crate::check::types::unify::start_unify(st2_p12.clone(), crate::check::types::Ty::TySig(mark_p3.clone(), Rc::new(v_p11.clone())), t_pv.clone(), e_pt.span.clone()), move |unify_9719: crate::check::types::St| {
                            let st3_pu = unify_9719;
                            prism_rtl::Turn::Finished((env_p0.clone(), st3_pu.clone(), Some(crate::check::types::Ty::TySig(mark_p3.clone(), Rc::new(v_p11.clone())))))
                        })
                    })
                }
            } else {
                {
                    let res_o5 = res_o5.clone();
                    let e_pt = e_pt.clone();
                    let env_p0 = env_p0.clone();
                    let st_p1 = st_p1.clone();
                    call_then(crate::check::expr::start_infer(env_p0.clone(), st_p1.clone(), e_pt.clone()), move |infer_9986: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_p13, st1_p14) = infer_9986;
                        call_then(crate::check::blocks::start_discarded(st1_p14.clone(), t_p13.clone(), e_pt.span.clone()), move |discarded_10023: crate::check::types::St| prism_rtl::Turn::Finished((env_p0.clone(), discarded_10023, res_o5.clone())))
                    })
                }
            },
            _ => prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &s_p2.span, &Text::lit("this statement belongs in a widget or `update` block")), res_o5.clone())),
        }
    }
}

/// `Start GivenStmt, x`: what the function value is when passed to `@Run`.
pub fn start_given_stmt(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, s_p2: crate::syntax::Stmt, mark_p3: Text, last_p4: bool, res_o5: Option<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, Option<crate::check::types::Ty>)>> {
    Rc::new(GivenStmt { env_p0, st_p1, s_p2, mark_p3, last_p4, res_o5 })
}
