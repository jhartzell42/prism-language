//! The module `Check.Blocks.Structure`, from `target/bootstrap/src/prismc/check/blocks/structure.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_rebuild_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, scrut_p2: &crate::syntax::Expr, body_p3: &crate::syntax::Block, span_p4: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p6, st1_p7) = crate::check::expr::infer_f(env_p0, st_p1, scrut_p2);
    let (inner_pc, st2_pd) = match crate::check::types::recording::walk_f(&st1_p7, &t_p6) {
        crate::check::types::Ty::TySig(m1650_0_0, i_p8) if (&m1650_0_0 == &crate::prelude::Text::lit("$")) => ((*i_p8).clone(), st1_p7.clone()),
        crate::check::types::Ty::TyErr => (crate::check::types::Ty::TyErr, st1_p7.clone()),
        crate::check::types::Ty::TyFlex(_) => {
            let (v_p9, s2_pa) = crate::check::types::fresh_var_f(&st1_p7, &false, &crate::prelude::Text::lit(""));
            (v_p9.clone(), crate::check::types::unify::unify_f(&s2_pa, &crate::check::types::Ty::TySig(crate::prelude::Text::lit("$"), ::std::rc::Rc::new(v_p9.clone())), &t_p6, &scrut_p2.span_p))
        },
        other_pb => (crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(&st1_p7, &crate::prelude::Text::lit("mismatch"), &scrut_p2.span_p, &crate::prelude::Text::from(format!("`rebuild` builds over a dynamic; this is `{}`", &crate::check::types::show_ty_f(&st1_p7, &other_pb))), &crate::prelude::Text::lit("a plain value is built once: write the block\'s lines in place"))),
        _ => unreachable!("no arm matched"),
    };
    let env2_p5 = with_topic_f(env_p0, &crate::prelude::Text::lit("_"), &inner_pc);
    let (res_pe, st3_pf) = crate::check::blocks::infer_widget_block_f(&env2_p5, &st2_pd, body_p3);
    match crate::check::types::recording::walk_f(&st3_pf, &res_pe) {
        crate::check::types::Ty::TyCon(m2163_0_0, m2163_0_1) if (&m2163_0_0 == &crate::prelude::Text::lit("unit")) && ((&m2163_0_1).len() == 0) => (crate::check::types::t_unit_p(), st3_pf.clone()),
        other_pg => (crate::check::types::Ty::TySig(crate::prelude::Text::lit("$"), ::std::rc::Rc::new(other_pg)), st3_pf.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InferRebuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferRebuild {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub scrut_p2: crate::syntax::Expr,
    pub body_p3: crate::syntax::Block,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferRebuild {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let scrut_p2 = &self.scrut_p2;
        let body_p3 = &self.body_p3;
        let span_p4 = &self.span_p4;
        let body_p3x = body_p3.clone();
        let env_p0x = env_p0.clone();
        let scrut_p2x = scrut_p2.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), scrut_p2x.clone()), move |infer_f_1604: (crate::check::types::Ty, crate::check::types::St)| {
            let (t_p6, st1_p7) = infer_f_1604;
            crate::prelude::call_then(crate::check::types::recording::start_walk_f(st1_p7.clone(), t_p6.clone()), move |walk_f_1656: crate::check::types::Ty| {
                let body_p3xz = body_p3x.clone();
                let env_p0xz = env_p0x.clone();
                let k_let1629 = move |v1629: (crate::check::types::Ty, crate::check::types::St)| {
                    let (inner_pc, st2_pd) = v1629;
                    let env2_p5 = with_topic_f(&env_p0xz, &crate::prelude::Text::lit("_"), &inner_pc);
                    crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_f(env2_p5.clone(), st2_pd.clone(), body_p3xz.clone()), move |infer_widget_block_f_2126: (crate::check::types::Ty, crate::check::types::St)| {
                        let (res_pe, st3_pf) = infer_widget_block_f_2126;
                        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st3_pf.clone(), res_pe.clone()), move |walk_f_2169: crate::check::types::Ty| match walk_f_2169 {
                            crate::check::types::Ty::TyCon(m2163_0_0, m2163_0_1) if (&m2163_0_0 == &crate::prelude::Text::lit("unit")) && ((&m2163_0_1).len() == 0) => ::prism_rtl::Turn::Finished((crate::check::types::t_unit_p(), st3_pf.clone())),
                            other_pg => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(crate::prelude::Text::lit("$"), ::std::rc::Rc::new(other_pg.clone())), st3_pf.clone())),
                            _ => unreachable!("no arm matched"),
                        })
                    })
                };
                match walk_f_1656 {
                    crate::check::types::Ty::TySig(m1650_0_0, i_p8) if (&m1650_0_0 == &crate::prelude::Text::lit("$")) => k_let1629(((*i_p8).clone(), st1_p7.clone())),
                    crate::check::types::Ty::TyErr => k_let1629((crate::check::types::Ty::TyErr, st1_p7.clone())),
                    crate::check::types::Ty::TyFlex(_) => {
                        let (v_p9, s2_pa) = crate::check::types::fresh_var_f(&st1_p7, &false, &crate::prelude::Text::lit(""));
                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(s2_pa.clone(), crate::check::types::Ty::TySig(crate::prelude::Text::lit("$"), ::std::rc::Rc::new(v_p9.clone())), t_p6.clone(), scrut_p2x.span_p.clone()), move |unify_f_1825: crate::check::types::St| k_let1629((v_p9.clone(), unify_f_1825)))
                    },
                    other_pb => crate::prelude::call_then(crate::check::types::start_show_ty_f(st1_p7.clone(), other_pb.clone()), move |show_ty_f_1973: crate::prelude::Text| k_let1629((crate::check::types::Ty::TyErr, crate::check::types::recording::err_fix_f(&st1_p7, &crate::prelude::Text::lit("mismatch"), &scrut_p2x.span_p, &crate::prelude::Text::from(format!("`rebuild` builds over a dynamic; this is `{}`", &show_ty_f_1973)), &crate::prelude::Text::lit("a plain value is built once: write the block\'s lines in place"))))),
                    _ => unreachable!("no arm matched"),
                }
            })
        })
    }
}

/// `Start InferRebuild, x`: what the function value is when passed to `@Run`.
pub fn start_infer_rebuild_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, scrut_p2: crate::syntax::Expr, body_p3: crate::syntax::Block, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferRebuild { env_p0, st_p1, scrut_p2, body_p3, span_p4 })
}

/// ```prism
/// WithTopic: fn Env, Text, Ty -> Env
/// ```
pub fn with_topic_f(env_p0: &crate::check::expr::Env, name_p1: &crate::prelude::Text, t_p2: &crate::check::types::Ty) -> crate::check::expr::Env {
    let mut this: crate::check::expr::Env = crate::check::expr::with_local_f(env_p0, name_p1, &crate::check::types::schemes::mono_f(t_p2));
    this.pending_p = crate::prelude::filter(&this.pending_p, &(|x_p3: &crate::prelude::Text| x_p3 != name_p1));
    this
}

/// ```prism
/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_for_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, binders_o2: &::std::option::Option<crate::syntax::ForBinders>, source_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    if env_p0.in_update_p {
        (crate::check::types::t_unit_p(), crate::check::blocks::borrows::update_for_f(env_p0, st_p1, binders_o2, source_p3, body_p4, span_p5))
    } else {
        {
            let (t_pb, st1_pc) = crate::check::expr::infer_f(env_p0, st_p1, source_p3);
            let sh_p6 = crate::check::types::head_sigil_f(&st1_pc, &t_pb);
            let coll_p7 = if &sh_p6 == &crate::prelude::Text::lit("$") {
                crate::check::expr::inner_of_f(&st1_pc, &t_pb)
            } else {
                t_pb.clone()
            };
            let st2_p8 = if (&sh_p6 == &crate::prelude::Text::lit("!")) || (&sh_p6 == &crate::prelude::Text::lit("@")) {
                crate::check::types::recording::err_f(&st1_pc, &crate::prelude::Text::lit("mismatch"), &source_p3.span_p, &crate::prelude::Text::from(format!("`for` runs over a map or an array, plain or dynamic; this is `{}`", &crate::check::types::show_ty_f(&st1_pc, &t_pb))))
            } else {
                st1_pc.clone()
            };
            let (k_pd, v_pe, st3_pf) = coll_parts_f(&st2_p8, &coll_p7, &source_p3.span_p);
            let live_p9 = &sh_p6 == &crate::prelude::Text::lit("$");
            let env1_pa = loop_indices_f(env_p0);
            let (env2_pg, st4_ph) = bind_for_binders_f(&env1_pa, &st3_pf, binders_o2, &k_pd, &v_pe, &live_p9);
            let (res_pi, st5_pj) = crate::check::blocks::infer_widget_block_f(&env2_pg, &st4_ph, body_p4);
            gather_f(&st5_pj, &res_pi, &k_pd, &live_p9)
        }
    }
}

/// The step machine of `InferFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferFor {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub binders_o2: ::std::option::Option<crate::syntax::ForBinders>,
    pub source_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferFor {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let binders_o2 = &self.binders_o2;
        let source_p3 = &self.source_p3;
        let body_p4 = &self.body_p4;
        let span_p5 = &self.span_p5;
        if env_p0.in_update_p {
            {
                let binders_o2x = binders_o2.clone();
                let body_p4x = body_p4.clone();
                let env_p0x = env_p0.clone();
                let source_p3x = source_p3.clone();
                let span_p5x = span_p5.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::blocks::borrows::start_update_for_f(env_p0x.clone(), st_p1x.clone(), binders_o2x.clone(), source_p3x.clone(), body_p4x.clone(), span_p5x.clone()), move |update_for_f_2754: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::check::types::t_unit_p(), update_for_f_2754)))
            }
        } else {
            {
                let binders_o2x = binders_o2.clone();
                let body_p4x = body_p4.clone();
                let env_p0x = env_p0.clone();
                let source_p3x = source_p3.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), source_p3x.clone()), move |infer_f_2840: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pb, st1_pc) = infer_f_2840;
                    crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pc.clone(), t_pb.clone()), move |head_sigil_f_2879: crate::prelude::Text| {
                        let sh_p6 = head_sigil_f_2879;
                        let binders_o2xz = binders_o2x.clone();
                        let body_p4xz = body_p4x.clone();
                        let env_p0xz = env_p0x.clone();
                        let sh_p6z = sh_p6.clone();
                        let source_p3xz = source_p3x.clone();
                        let st1_pcz = st1_pc.clone();
                        let t_pbz = t_pb.clone();
                        let k_let2904 = move |v2904: crate::check::types::Ty| {
                            let coll_p7 = v2904;
                            let binders_o2xzz = binders_o2xz.clone();
                            let body_p4xzz = body_p4xz.clone();
                            let coll_p7z = coll_p7.clone();
                            let env_p0xzz = env_p0xz.clone();
                            let sh_p6zz = sh_p6z.clone();
                            let source_p3xzz = source_p3xz.clone();
                            let k_let2960 = move |v2960: crate::check::types::St| {
                                let st2_p8 = v2960;
                                crate::prelude::call_then(start_coll_parts_f(st2_p8.clone(), coll_p7z.clone(), source_p3xzz.span_p.clone()), move |coll_parts_f_3150: (crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)| {
                                    let (k_pd, v_pe, st3_pf) = coll_parts_f_3150;
                                    let live_p9 = &sh_p6zz == &crate::prelude::Text::lit("$");
                                    let env1_pa = loop_indices_f(&env_p0xzz);
                                    crate::prelude::call_then(start_bind_for_binders_f(env1_pa.clone(), st3_pf.clone(), binders_o2xzz.clone(), k_pd.clone(), v_pe.clone(), live_p9), move |bind_for_binders_f_3275: (crate::check::expr::Env, crate::check::types::St)| {
                                        let (env2_pg, st4_ph) = bind_for_binders_f_3275;
                                        crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_f(env2_pg.clone(), st4_ph.clone(), body_p4xzz.clone()), move |infer_widget_block_f_3349: (crate::check::types::Ty, crate::check::types::St)| {
                                            let (res_pi, st5_pj) = infer_widget_block_f_3349;
                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(Gather { st_p0: st5_pj.clone(), res_p1: res_pi.clone(), k_p2: k_pd.clone(), live_p3: live_p9 }))
                                        })
                                    })
                                })
                            };
                            if (&sh_p6z == &crate::prelude::Text::lit("!")) || (&sh_p6z == &crate::prelude::Text::lit("@")) {
                                crate::prelude::call_then(crate::check::types::start_show_ty_f(st1_pcz.clone(), t_pbz.clone()), move |show_ty_f_3095: crate::prelude::Text| k_let2960(crate::check::types::recording::err_f(&st1_pcz, &crate::prelude::Text::lit("mismatch"), &source_p3xz.span_p, &crate::prelude::Text::from(format!("`for` runs over a map or an array, plain or dynamic; this is `{}`", &show_ty_f_3095)))))
                            } else {
                                k_let2960(st1_pcz.clone())
                            }
                        };
                        if &sh_p6 == &crate::prelude::Text::lit("$") {
                            crate::prelude::call_then(crate::check::expr::start_inner_of_f(st1_pc.clone(), t_pb.clone()), move |inner_of_f_2929: crate::check::types::Ty| k_let2904(inner_of_f_2929))
                        } else {
                            k_let2904(t_pb.clone())
                        }
                    })
                })
            }
        }
    }
}

/// `Start InferFor, x`: what the function value is when passed to `@Run`.
pub fn start_infer_for_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, binders_o2: ::std::option::Option<crate::syntax::ForBinders>, source_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferFor { env_p0, st_p1, binders_o2, source_p3, body_p4, span_p5 })
}

/// ```prism
/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
/// ```
pub fn coll_parts_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, span_p2: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St) {
    'm3542: {
        let scrutinee = &crate::check::types::recording::walk_f(st_p0, t_p1);
        if let crate::check::types::Ty::TyMap(k_p3, v_p4) = scrutinee {
            break 'm3542 ((**k_p3).clone(), (**v_p4).clone(), st_p0.clone());
        }
        if let crate::check::types::Ty::TyArray(v_p5) = scrutinee {
            break 'm3542 (crate::check::types::t_nat_p(), (**v_p5).clone(), st_p0.clone());
        }
        if let crate::check::types::Ty::TyCon(m3542_2_0, m3542_2_1) = scrutinee && (m3542_2_0 == &crate::prelude::Text::lit("Buffer")) && (m3542_2_1.len() == 1) && let ::std::option::Option::Some(v_p6) = crate::prelude::index(m3542_2_1, &crate::prelude::Nat::from(0u32)) {
            break 'm3542 (crate::check::types::t_nat_p(), v_p6.clone(), st_p0.clone());
        }
        if let crate::check::types::Ty::TyCon(m3542_3_0, m3542_3_1) = scrutinee && (m3542_3_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m3542_3_1.len() == 1) && let ::std::option::Option::Some(c_p7) = crate::prelude::index(m3542_3_1, &crate::prelude::Nat::from(0u32)) {
            break 'm3542 coll_parts_f(st_p0, &c_p7, span_p2);
        }
        if let crate::check::types::Ty::TyErr = scrutinee {
            break 'm3542 (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, st_p0.clone());
        }
        if let crate::check::types::Ty::TyFlex(_) = scrutinee {
            break 'm3542 {
                let (v_p8, st2_p9) = crate::check::types::fresh_var_f(st_p0, &false, &crate::prelude::Text::lit(""));
                (crate::check::types::t_nat_p(), v_p8.clone(), crate::check::types::unify::unify_f(&st2_p9, &crate::check::types::Ty::TyArray(::std::rc::Rc::new(v_p8.clone())), t_p1, span_p2))
            };
        }
        if let other_pa = scrutinee {
            break 'm3542 (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(st_p0, &crate::prelude::Text::lit("mismatch"), span_p2, &crate::prelude::Text::from(format!("`for` runs over a map or an array; this is `{}`", &crate::check::types::show_ty_f(st_p0, other_pa)))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CollParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
/// ```
pub struct CollParts {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub span_p2: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)> for CollParts {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let span_p2 = &self.span_p2;
        let span_p2x = span_p2.clone();
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_3548: crate::check::types::Ty| 'm3542: {
            if let crate::check::types::Ty::TyMap(k_p3, v_p4) = &walk_f_3548 {
                break 'm3542 ::prism_rtl::Turn::Finished(((**k_p3).clone(), (**v_p4).clone(), st_p0x.clone()));
            }
            if let crate::check::types::Ty::TyArray(v_p5) = &walk_f_3548 {
                break 'm3542 ::prism_rtl::Turn::Finished((crate::check::types::t_nat_p(), (**v_p5).clone(), st_p0x.clone()));
            }
            if let crate::check::types::Ty::TyCon(m3542_2_0, m3542_2_1) = &walk_f_3548 && (m3542_2_0 == &crate::prelude::Text::lit("Buffer")) && (m3542_2_1.len() == 1) && let ::std::option::Option::Some(v_p6) = crate::prelude::index(m3542_2_1, &crate::prelude::Nat::from(0u32)) {
                break 'm3542 ::prism_rtl::Turn::Finished((crate::check::types::t_nat_p(), v_p6.clone(), st_p0x.clone()));
            }
            if let crate::check::types::Ty::TyCon(m3542_3_0, m3542_3_1) = &walk_f_3548 && (m3542_3_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m3542_3_1.len() == 1) && let ::std::option::Option::Some(c_p7) = crate::prelude::index(m3542_3_1, &crate::prelude::Nat::from(0u32)) {
                break 'm3542 ::prism_rtl::Turn::More(::std::rc::Rc::new(CollParts { st_p0: st_p0x.clone(), t_p1: c_p7.clone(), span_p2: span_p2x.clone() }));
            }
            if let crate::check::types::Ty::TyErr = &walk_f_3548 {
                break 'm3542 ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, st_p0x.clone()));
            }
            if let crate::check::types::Ty::TyFlex(_) = &walk_f_3548 {
                break 'm3542 {
                    let (v_p8, st2_p9) = crate::check::types::fresh_var_f(&st_p0x, &false, &crate::prelude::Text::lit(""));
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p9.clone(), crate::check::types::Ty::TyArray(::std::rc::Rc::new(v_p8.clone())), t_p1x.clone(), span_p2x.clone()), move |unify_f_3841: crate::check::types::St| ::prism_rtl::Turn::Finished((crate::check::types::t_nat_p(), v_p8.clone(), unify_f_3841)))
                };
            }
            if let other_pa = &walk_f_3548 {
                break 'm3542 {
                    let other_pax = other_pa.clone();
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p0x.clone(), other_pax.clone()), move |show_ty_f_3976: crate::prelude::Text| ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr, crate::check::types::recording::err_f(&st_p0x, &crate::prelude::Text::lit("mismatch"), &span_p2x, &crate::prelude::Text::from(format!("`for` runs over a map or an array; this is `{}`", &show_ty_f_3976))))))
                };
            }
            unreachable!("no clause matched")
        })
    }
}

/// `Start CollParts, x`: what the function value is when passed to `@Run`.
pub fn start_coll_parts_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty, span_p2: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(CollParts { st_p0, t_p1, span_p2 })
}

/// ```prism
/// LoopIndices: fn Env -> Env
/// ```
pub fn loop_indices_f(env_p0: &crate::check::expr::Env) -> crate::check::expr::Env {
    let outer1_o1 = crate::prelude::get(&env_p0.locals_p, &crate::prelude::Text::lit("ix"));
    let outer2_o2 = crate::prelude::get(&env_p0.locals_p, &crate::prelude::Text::lit("jx"));
    let e1_p3 = crate::check::expr::with_local_f(env_p0, &crate::prelude::Text::lit("ix"), &crate::check::types::schemes::mono_f(&crate::check::types::t_nat_p()));
    let e2_p4 = match &outer1_o1 {
        ::std::option::Option::Some(sc_p5) => crate::check::expr::with_local_f(&e1_p3, &crate::prelude::Text::lit("jx"), sc_p5),
        ::std::option::Option::None => e1_p3.clone(),
    };
    match &outer2_o2 {
        ::std::option::Option::Some(sc_p6) => crate::check::expr::with_local_f(&e2_p4, &crate::prelude::Text::lit("kx"), sc_p6),
        ::std::option::Option::None => e2_p4.clone(),
    }
}

/// ```prism
/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_for_binders_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, binders_o2: &::std::option::Option<crate::syntax::ForBinders>, k_p3: &crate::check::types::Ty, v_p4: &crate::check::types::Ty, live_p5: &bool) -> (crate::check::expr::Env, crate::check::types::St) {
    let inner_p6 = *live_p5 && (&crate::check::types::head_sigil_f(st_p1, v_p4) == &crate::prelude::Text::lit("$"));
    let vt_p7 = if *live_p5 && !inner_p6 {
        crate::check::types::Ty::TySig(crate::prelude::Text::lit("$"), ::std::rc::Rc::new(v_p4.clone()))
    } else {
        v_p4.clone()
    };
    match binders_o2 {
        ::std::option::Option::None => {
            let e1_p8 = with_topic_f(env_p0, &(if *live_p5 { crate::prelude::Text::lit("$_") } else { crate::prelude::Text::lit("_") }), &vt_p7);
            (with_topic_f(&e1_p8, &crate::prelude::Text::lit("key"), k_p3), st_p1.clone())
        },
        ::std::option::Option::Some(bs_p9) => match &bs_p9.second_o {
            ::std::option::Option::Some(second_pa) => {
                let (e1_pb, st1_pc) = crate::check::expr::patterns::bind_pattern_f(&unpending_f(env_p0), st_p1, &bs_p9.first_p, k_p3, &false);
                let (st2_pd, vt2_pe) = for_inner_mark_f(&for_binder_matches_f(env_p0, &st1_pc, &bs_p9.first_p, k_p3), &inner_p6, second_pa, v_p4, &vt_p7);
                let (e2_pf, st3_pg) = crate::check::expr::patterns::bind_pattern_f(&e1_pb, &st2_pd, second_pa, &vt2_pe, &false);
                (e2_pf.clone(), for_binder_matches_f(env_p0, &st3_pg, second_pa, &vt2_pe))
            },
            ::std::option::Option::None => {
                let e1_ph = with_topic_f(env_p0, &crate::prelude::Text::lit("key"), k_p3);
                let (st2_pi, vt2_pj) = for_inner_mark_f(st_p1, &inner_p6, &bs_p9.first_p, v_p4, &vt_p7);
                let (e2_pk, st3_pl) = crate::check::expr::patterns::bind_pattern_f(&unpending_f(&e1_ph), &st2_pi, &bs_p9.first_p, &vt2_pj, &false);
                (e2_pk.clone(), for_binder_matches_f(env_p0, &st3_pl, &bs_p9.first_p, &vt2_pj))
            },
        },
    }
}

/// The step machine of `BindForBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
/// ```
pub struct BindForBinders {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub binders_o2: ::std::option::Option<crate::syntax::ForBinders>,
    pub k_p3: crate::check::types::Ty,
    pub v_p4: crate::check::types::Ty,
    pub live_p5: bool,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)> for BindForBinders {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let binders_o2 = &self.binders_o2;
        let k_p3 = &self.k_p3;
        let v_p4 = &self.v_p4;
        let live_p5 = &self.live_p5;
        let binders_o2z = binders_o2.clone();
        let env_p0z = env_p0.clone();
        let k_p3z = k_p3.clone();
        let live_p5z = *live_p5;
        let st_p1z = st_p1.clone();
        let v_p4z = v_p4.clone();
        let k_let4891 = move |v4891: bool| {
            let inner_p6 = v4891;
            let vt_p7 = if live_p5z && !inner_p6 {
                crate::check::types::Ty::TySig(crate::prelude::Text::lit("$"), ::std::rc::Rc::new(v_p4z.clone()))
            } else {
                v_p4z.clone()
            };
            match &binders_o2z {
                ::std::option::Option::None => {
                    let e1_p8 = with_topic_f(&env_p0z, &(if live_p5z { crate::prelude::Text::lit("$_") } else { crate::prelude::Text::lit("_") }), &vt_p7);
                    ::prism_rtl::Turn::Finished((with_topic_f(&e1_p8, &crate::prelude::Text::lit("key"), &k_p3z), st_p1z.clone()))
                },
                ::std::option::Option::Some(bs_p9) => match &bs_p9.second_o {
                    ::std::option::Option::Some(second_pa) => {
                        let bs_p9x = bs_p9.clone();
                        let second_pax = second_pa.clone();
                        crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(unpending_f(&env_p0z), st_p1z.clone(), bs_p9x.first_p.clone(), k_p3z.clone(), false), move |bind_pattern_f_5226: (crate::check::expr::Env, crate::check::types::St)| {
                            let (e1_pb, st1_pc) = bind_pattern_f_5226;
                            crate::prelude::call_then(start_for_binder_matches_f(env_p0z.clone(), st1_pc.clone(), bs_p9x.first_p.clone(), k_p3z.clone()), move |for_binder_matches_f_5327: crate::check::types::St| {
                                let (st2_pd, vt2_pe) = for_inner_mark_f(&for_binder_matches_f_5327, &inner_p6, &second_pax, &v_p4z, &vt_p7);
                                crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(e1_pb.clone(), st2_pd.clone(), second_pax.clone(), vt2_pe.clone(), false), move |bind_pattern_f_5423: (crate::check::expr::Env, crate::check::types::St)| {
                                    let (e2_pf, st3_pg) = bind_pattern_f_5423;
                                    crate::prelude::call_then(start_for_binder_matches_f(env_p0z.clone(), st3_pg.clone(), second_pax.clone(), vt2_pe.clone()), move |for_binder_matches_f_5486: crate::check::types::St| ::prism_rtl::Turn::Finished((e2_pf.clone(), for_binder_matches_f_5486)))
                                })
                            })
                        })
                    },
                    ::std::option::Option::None => {
                        let e1_ph = with_topic_f(&env_p0z, &crate::prelude::Text::lit("key"), &k_p3z);
                        let (st2_pi, vt2_pj) = for_inner_mark_f(&st_p1z, &inner_p6, &bs_p9.first_p, &v_p4z, &vt_p7);
                        let bs_p9x = bs_p9.clone();
                        crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(unpending_f(&e1_ph), st2_pi.clone(), bs_p9x.first_p.clone(), vt2_pj.clone(), false), move |bind_pattern_f_5703: (crate::check::expr::Env, crate::check::types::St)| {
                            let (e2_pk, st3_pl) = bind_pattern_f_5703;
                            crate::prelude::call_then(start_for_binder_matches_f(env_p0z.clone(), st3_pl.clone(), bs_p9x.first_p.clone(), vt2_pj.clone()), move |for_binder_matches_f_5780: crate::check::types::St| ::prism_rtl::Turn::Finished((e2_pk.clone(), for_binder_matches_f_5780)))
                        })
                    },
                },
            }
        };
        if *live_p5 {
            {
                let st_p1x = st_p1.clone();
                let v_p4x = v_p4.clone();
                crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p1x.clone(), v_p4x.clone()), move |head_sigil_f_4913: crate::prelude::Text| k_let4891(&head_sigil_f_4913 == &crate::prelude::Text::lit("$")))
            }
        } else {
            k_let4891(false)
        }
    }
}

/// `Start BindForBinders, x`: what the function value is when passed to `@Run`.
pub fn start_bind_for_binders_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, binders_o2: ::std::option::Option<crate::syntax::ForBinders>, k_p3: crate::check::types::Ty, v_p4: crate::check::types::Ty, live_p5: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St)>> {
    ::std::rc::Rc::new(BindForBinders { env_p0, st_p1, binders_o2, k_p3, v_p4, live_p5 })
}

/// ```prism
/// ForBinderMatches: unbounded fn Env, St, Pattern, Ty -> St
/// ```
pub fn for_binder_matches_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, p_p2: &crate::syntax::Pattern, t_p3: &crate::check::types::Ty) -> crate::check::types::St {
    crate::check::passes::always_matches_f(env_p0, st_p1, p_p2, t_p3, &crate::prelude::Text::lit("a `for` binder"))
}

/// The step machine of `ForBinderMatches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBinderMatches: unbounded fn Env, St, Pattern, Ty -> St
/// ```
pub struct ForBinderMatches {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub p_p2: crate::syntax::Pattern,
    pub t_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::St> for ForBinderMatches {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let p_p2 = &self.p_p2;
        let t_p3 = &self.t_p3;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::passes::AlwaysMatches { env_p0: env_p0.clone(), st_p1: st_p1.clone(), p_p2: p_p2.clone(), t_p3: t_p3.clone(), what_p4: crate::prelude::Text::lit("a `for` binder") }))
    }
}

/// `Start ForBinderMatches, x`: what the function value is when passed to `@Run`.
pub fn start_for_binder_matches_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, p_p2: crate::syntax::Pattern, t_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(ForBinderMatches { env_p0, st_p1, p_p2, t_p3 })
}

/// ```prism
/// ForInnerMark: fn St, Bool, Pattern, Ty, Ty -> ((St, Ty))
/// ```
pub fn for_inner_mark_f(st_p0: &crate::check::types::St, inner_p1: &bool, p_p2: &crate::syntax::Pattern, v_p3: &crate::check::types::Ty, vt_p4: &crate::check::types::Ty) -> (crate::check::types::St, crate::check::types::Ty) {
    match &*p_p2.kind_p {
        crate::syntax::PatternKind::PName(n_p5) => if *inner_p1 && (&n_p5.sigils_p == &crate::prelude::Text::lit("$$")) {
            {
                let name_p6 = crate::check::env::sname_key_f(n_p5);
                let bare_p7 = crate::syntax::lexer::chars::drop_prefix_f(&name_p6, &crate::prelude::Text::lit("$$"));
                (crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("mark-stack"), &n_p5.span_p, &crate::prelude::Text::from(format!("`{}` shows `$$`, a dynamic of a dynamic; a `for` over `$(k ==> $v)` binds the value under the row\'s key, which follows a replaced dynamic (Semantics ch. 4)", &name_p6)), &crate::prelude::Text::from(format!("write `${}`, and read it where `@Flatten {}` was", &bare_p7, &name_p6))), crate::check::types::Ty::TySig(crate::prelude::Text::lit("$"), ::std::rc::Rc::new(v_p3.clone())))
            }
        } else {
            (st_p0.clone(), vt_p4.clone())
        },
        _ => (st_p0.clone(), vt_p4.clone()),
    }
}

/// ```prism
/// Unpending: fn Env -> Env
/// ```
pub fn unpending_f(env_p0: &crate::check::expr::Env) -> crate::check::expr::Env {
    let mut this: crate::check::expr::Env = env_p0.clone();
    this.pending_p = crate::prelude::Array::new();
    this
}

/// ```prism
/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
/// ```
pub fn gather_f(st_p0: &crate::check::types::St, res_p1: &crate::check::types::Ty, k_p2: &crate::check::types::Ty, live_p3: &bool) -> (crate::check::types::Ty, crate::check::types::St) {
    match crate::check::types::recording::walk_f(st_p0, res_p1) {
        crate::check::types::Ty::TyCon(m7253_0_0, m7253_0_1) if (&m7253_0_0 == &crate::prelude::Text::lit("unit")) && ((&m7253_0_1).len() == 0) => (crate::check::types::t_unit_p(), st_p0.clone()),
        crate::check::types::Ty::TySig(m7253_1_0, t_p4) if (&m7253_1_0 == &crate::prelude::Text::lit("!")) => (crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(crate::check::types::Ty::TyMap(::std::rc::Rc::new(k_p2.clone()), ::std::rc::Rc::new((*t_p4).clone())))), st_p0.clone()),
        crate::check::types::Ty::TySig(m7253_2_0, t_p5) if (&m7253_2_0 == &crate::prelude::Text::lit("$")) => (crate::check::types::Ty::TySig(crate::prelude::Text::lit("$"), ::std::rc::Rc::new(crate::check::types::Ty::TyMap(::std::rc::Rc::new(k_p2.clone()), ::std::rc::Rc::new((*t_p5).clone())))), st_p0.clone()),
        crate::check::types::Ty::TyTuple(ts_p6) => if crate::prelude::run_to_end(crate::prelude::fold_job(ts_p6.clone(), false, {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_p7 = p0;
                    let x_p8 = p1;
                    if seen_p7 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p0xy.clone(), x_p8.clone()), move |head_sigil_f_7490: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::expr::is_time_sigil_f(&head_sigil_f_7490)))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })) {
            {
                let (parts_pe, st2_pf) = crate::prelude::run_to_end(crate::prelude::fold_job(ts_p6.clone(), (crate::prelude::Array::new(), st_p0.clone()), {
                    let k_p2x = k_p2.clone();
                    let live_p3x = *live_p3;
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)| {
                        let k_p2xy = k_p2x.clone();
                        let live_p3xy = live_p3x;
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (acc_p9, s_pa) = p0;
                            let x_pb = p1;
                            crate::prelude::call_then(start_gather_f(s_pa.clone(), x_pb.clone(), k_p2xy.clone(), live_p3xy), move |gather_f_7613: (crate::check::types::Ty, crate::check::types::St)| {
                                let (g_pc, s2_pd) = gather_f_7613;
                                ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &g_pc), s2_pd.clone()))
                            })
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>>>
                }));
                (crate::check::types::Ty::TyTuple(parts_pe.clone()), st2_pf.clone())
            }
        } else {
            (live_map_f(live_p3, k_p2, &crate::check::types::Ty::TyTuple(ts_p6.clone())), st_p0.clone())
        },
        other_pg => (live_map_f(live_p3, k_p2, &other_pg), st_p0.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Gather`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
/// ```
pub struct Gather {
    pub st_p0: crate::check::types::St,
    pub res_p1: crate::check::types::Ty,
    pub k_p2: crate::check::types::Ty,
    pub live_p3: bool,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for Gather {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let res_p1 = &self.res_p1;
        let k_p2 = &self.k_p2;
        let live_p3 = &self.live_p3;
        let k_p2x = k_p2.clone();
        let live_p3x = *live_p3;
        let res_p1x = res_p1.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), res_p1x.clone()), move |walk_f_7259: crate::check::types::Ty| match walk_f_7259 {
            crate::check::types::Ty::TyCon(m7253_0_0, m7253_0_1) if (&m7253_0_0 == &crate::prelude::Text::lit("unit")) && ((&m7253_0_1).len() == 0) => ::prism_rtl::Turn::Finished((crate::check::types::t_unit_p(), st_p0x.clone())),
            crate::check::types::Ty::TySig(m7253_1_0, t_p4) if (&m7253_1_0 == &crate::prelude::Text::lit("!")) => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(crate::prelude::Text::lit("!"), ::std::rc::Rc::new(crate::check::types::Ty::TyMap(::std::rc::Rc::new(k_p2x.clone()), ::std::rc::Rc::new((*t_p4).clone())))), st_p0x.clone())),
            crate::check::types::Ty::TySig(m7253_2_0, t_p5) if (&m7253_2_0 == &crate::prelude::Text::lit("$")) => ::prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(crate::prelude::Text::lit("$"), ::std::rc::Rc::new(crate::check::types::Ty::TyMap(::std::rc::Rc::new(k_p2x.clone()), ::std::rc::Rc::new((*t_p5).clone())))), st_p0x.clone())),
            crate::check::types::Ty::TyTuple(ts_p6) => crate::prelude::call_value(crate::prelude::fold_job(ts_p6.clone(), false, {
                let st_p0xx = st_p0x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let seen_p7 = p0;
                        let x_p8 = p1;
                        if seen_p7 {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            crate::prelude::call_then(crate::check::types::start_head_sigil_f(st_p0xxy.clone(), x_p8.clone()), move |head_sigil_f_7490: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::expr::is_time_sigil_f(&head_sigil_f_7490)))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }), move |fold_7442: bool| if fold_7442 {
                crate::prelude::call_value(crate::prelude::fold_job(ts_p6.clone(), (crate::prelude::Array::new(), st_p0x.clone()), {
                    let k_p2xx = k_p2x.clone();
                    let live_p3xx = live_p3x;
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)| {
                        let k_p2xxy = k_p2xx.clone();
                        let live_p3xxy = live_p3xx;
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (acc_p9, s_pa) = p0;
                            let x_pb = p1;
                            crate::prelude::call_then(start_gather_f(s_pa.clone(), x_pb.clone(), k_p2xxy.clone(), live_p3xxy), move |gather_f_7613: (crate::check::types::Ty, crate::check::types::St)| {
                                let (g_pc, s2_pd) = gather_f_7613;
                                ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &g_pc), s2_pd.clone()))
                            })
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St), crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)>>>
                }), move |fold_7541: (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::St)| {
                    let (parts_pe, st2_pf) = fold_7541;
                    ::prism_rtl::Turn::Finished((crate::check::types::Ty::TyTuple(parts_pe.clone()), st2_pf.clone()))
                })
            } else {
                ::prism_rtl::Turn::Finished((live_map_f(&live_p3x, &k_p2x, &crate::check::types::Ty::TyTuple(ts_p6.clone())), st_p0x.clone()))
            }),
            other_pg => ::prism_rtl::Turn::Finished((live_map_f(&live_p3x, &k_p2x, &other_pg), st_p0x.clone())),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start Gather, x`: what the function value is when passed to `@Run`.
pub fn start_gather_f(st_p0: crate::check::types::St, res_p1: crate::check::types::Ty, k_p2: crate::check::types::Ty, live_p3: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(Gather { st_p0, res_p1, k_p2, live_p3 })
}

/// ```prism
/// LiveMap: fn Bool, Ty, Ty -> Ty
/// ```
pub fn live_map_f(live_p0: &bool, k_p1: &crate::check::types::Ty, v_p2: &crate::check::types::Ty) -> crate::check::types::Ty {
    if *live_p0 {
        crate::check::types::Ty::TySig(crate::prelude::Text::lit("$"), ::std::rc::Rc::new(crate::check::types::Ty::TyMap(::std::rc::Rc::new(k_p1.clone()), ::std::rc::Rc::new(v_p2.clone()))))
    } else {
        crate::check::types::Ty::TyMap(::std::rc::Rc::new(k_p1.clone()), ::std::rc::Rc::new(v_p2.clone()))
    }
}

/// ```prism
/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
/// ```
pub fn infer_given_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block, span_p3: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let mark_p4 = if (&env_p0.mark_p == &crate::prelude::Text::lit("?")) || (&env_p0.mark_p == &crate::prelude::Text::lit("~")) {
        env_p0.mark_p.clone()
    } else {
        given_mark_of_f(&b_p2.stmts_p)
    };
    infer_given_block_f(env_p0, st_p1, b_p2, &mark_p4)
}

/// The step machine of `InferGiven`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
/// ```
pub struct InferGiven {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferGiven {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        let span_p3 = &self.span_p3;
        let mark_p4 = if (&env_p0.mark_p == &crate::prelude::Text::lit("?")) || (&env_p0.mark_p == &crate::prelude::Text::lit("~")) {
            env_p0.mark_p.clone()
        } else {
            given_mark_of_f(&b_p2.stmts_p)
        };
        ::prism_rtl::Turn::More(::std::rc::Rc::new(InferGivenBlock { env_p0: env_p0.clone(), st_p1: st_p1.clone(), b_p2: b_p2.clone(), mark_p3: mark_p4.clone() }))
    }
}

/// `Start InferGiven, x`: what the function value is when passed to `@Run`.
pub fn start_infer_given_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferGiven { env_p0, st_p1, b_p2, span_p3 })
}

/// ```prism
/// GivenMarkOf: fn [Stmt] -> Text
/// ```
pub fn given_mark_of_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>) -> crate::prelude::Text {
    crate::prelude::fold(stmts_p0, &crate::prelude::Text::lit("?"), &(|m_p1: &crate::prelude::Text, s_p2: &crate::syntax::Stmt| m_p1.clone()))
}

/// ```prism
/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
/// ```
pub fn infer_given_block_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, b_p2: &crate::syntax::Block, mark_p3: &crate::prelude::Text) -> (crate::check::types::Ty, crate::check::types::St) {
    let n_p4 = crate::prelude::len(&b_p2.stmts_p);
    let (env2_pa, st2_pb, res_oc) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p4), (env_p0.clone(), st_p1.clone(), ::std::option::Option::None), {
        let b_p2x = b_p2.clone();
        let mark_p3x = mark_p3.clone();
        let n_p4x = n_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>), crate::prelude::Nat)| {
            let b_p2xy = b_p2x.clone();
            let mark_p3xy = mark_p3x.clone();
            let n_p4xy = n_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (en_p5, s_p6, r_o7) = p0;
                let i_p8 = p1;
                {
                    let stmt_p9 = crate::prelude::or(&crate::prelude::index(&b_p2xy.stmts_p, &i_p8), &crate::check::blocks::dummy_stmt2_p());
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(GivenStmt { env_p0: en_p5.clone(), st_p1: s_p6.clone(), s_p2: stmt_p9.clone(), clauses_p3: crate::check::expr::lets::local_clauses_f(&b_p2xy.stmts_p, &i_p8), mark_p4: mark_p3xy.clone(), last_p5: &(&i_p8 + &crate::prelude::Nat::from(1u32)) == &n_p4xy, res_o6: r_o7.clone() }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)>>>
    }));
    match &res_oc {
        ::std::option::Option::Some(t_pd) => (t_pd.clone(), st2_pb.clone()),
        ::std::option::Option::None => {
            let (v_pe, st3_pf) = crate::check::types::fresh_var_f(&st2_pb, &false, &crate::prelude::Text::lit(""));
            (crate::check::types::Ty::TySig(mark_p3.clone(), ::std::rc::Rc::new(v_pe.clone())), st3_pf.clone())
        },
    }
}

/// The step machine of `InferGivenBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
/// ```
pub struct InferGivenBlock {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub b_p2: crate::syntax::Block,
    pub mark_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for InferGivenBlock {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let b_p2 = &self.b_p2;
        let mark_p3 = &self.mark_p3;
        let n_p4 = crate::prelude::len(&b_p2.stmts_p);
        let b_p2x = b_p2.clone();
        let env_p0x = env_p0.clone();
        let mark_p3x = mark_p3.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p4), (env_p0x.clone(), st_p1x.clone(), ::std::option::Option::None), {
            let b_p2xx = b_p2x.clone();
            let mark_p3xx = mark_p3x.clone();
            let n_p4x = n_p4.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>), crate::prelude::Nat)| {
                let b_p2xxy = b_p2xx.clone();
                let mark_p3xxy = mark_p3xx.clone();
                let n_p4xy = n_p4x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (en_p5, s_p6, r_o7) = p0;
                    let i_p8 = p1;
                    {
                        let stmt_p9 = crate::prelude::or(&crate::prelude::index(&b_p2xxy.stmts_p, &i_p8), &crate::check::blocks::dummy_stmt2_p());
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(GivenStmt { env_p0: en_p5.clone(), st_p1: s_p6.clone(), s_p2: stmt_p9.clone(), clauses_p3: crate::check::expr::lets::local_clauses_f(&b_p2xxy.stmts_p, &i_p8), mark_p4: mark_p3xxy.clone(), last_p5: &(&i_p8 + &crate::prelude::Nat::from(1u32)) == &n_p4xy, res_o6: r_o7.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)>>>
        }), move |fold_8810: (crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)| {
            let (env2_pa, st2_pb, res_oc) = fold_8810;
            match &res_oc {
                ::std::option::Option::Some(t_pd) => ::prism_rtl::Turn::Finished((t_pd.clone(), st2_pb.clone())),
                ::std::option::Option::None => {
                    let (v_pe, st3_pf) = crate::check::types::fresh_var_f(&st2_pb, &false, &crate::prelude::Text::lit(""));
                    ::prism_rtl::Turn::Finished((crate::check::types::Ty::TySig(mark_p3x.clone(), ::std::rc::Rc::new(v_pe.clone())), st3_pf.clone()))
                },
            }
        })
    }
}

/// `Start InferGivenBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_given_block_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, b_p2: crate::syntax::Block, mark_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(InferGivenBlock { env_p0, st_p1, b_p2, mark_p3 })
}

/// ```prism
/// GivenStmt: unbounded fn Env, St, Stmt, [FnClause], Text, Bool, ?Ty -> ((Env, St, ?Ty))
/// ```
pub fn given_stmt_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, s_p2: &crate::syntax::Stmt, clauses_p3: &crate::prelude::Array<crate::syntax::decls::FnClause>, mark_p4: &crate::prelude::Text, last_p5: &bool, res_o6: &::std::option::Option<crate::check::types::Ty>) -> (crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>) {
    match &s_p2.kind_p {
        crate::syntax::StmtKind::SBind(p_p7, e_p8, ::std::option::Option::None) => {
            let (t_pa, st1_pb) = crate::check::expr::infer_f(env_p0, st_p1, e_p8);
            let (v_pc, st2_pd) = crate::check::types::fresh_var_f(&st1_pb, &false, &crate::prelude::Text::lit(""));
            let st3_p9 = crate::check::types::unify::unify_f(&st2_pd, &crate::check::types::Ty::TySig(mark_p4.clone(), ::std::rc::Rc::new(v_pc.clone())), &t_pa, &e_p8.span_p);
            let (env2_pe, st4_pf) = crate::check::expr::patterns::bind_pattern_f(&unpending_f(env_p0), &st3_p9, p_p7, &v_pc, &true);
            (env2_pe.clone(), st4_pf.clone(), res_o6.clone())
        },
        crate::syntax::StmtKind::SRequire(c_pg) => (env_p0.clone(), crate::check::expr::lifting::check_cond_f(env_p0, st_p1, c_pg), res_o6.clone()),
        crate::syntax::StmtKind::SForbid(c_ph) => (env_p0.clone(), crate::check::expr::lifting::check_cond_f(env_p0, st_p1, c_ph), res_o6.clone()),
        crate::syntax::StmtKind::SLet(p_pi, ty_oj, e_pk) => {
            let (env2_pl, st2_pm) = crate::check::expr::lets::check_let_f(env_p0, st_p1, p_pi, ty_oj, e_pk, &s_p2.span_p);
            (env2_pl.clone(), st2_pm.clone(), res_o6.clone())
        },
        crate::syntax::StmtKind::SFn(f_pn) => {
            let (env1_po, st1_pp) = crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2);
            let (env2_pq, st2_pr) = crate::check::expr::lets::check_local_fn_f(&env1_po, &st1_pp, clauses_p3, &s_p2.span_p);
            (env2_pq.clone(), st2_pr.clone(), res_o6.clone())
        },
        crate::syntax::StmtKind::SSignature(_) => {
            let (env2_ps, st2_pt) = crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2);
            (env2_ps.clone(), st2_pt.clone(), res_o6.clone())
        },
        crate::syntax::StmtKind::SExpr(e_pu) => if *last_p5 {
            {
                let (t_p10, st1_p11) = crate::check::expr::infer_f(env_p0, st_p1, e_pu);
                let (v_p12, st2_p13) = crate::check::types::fresh_var_f(&st1_p11, &false, &crate::prelude::Text::lit(""));
                let st3_pv = crate::check::types::unify::unify_f(&st2_p13, &crate::check::types::Ty::TySig(mark_p4.clone(), ::std::rc::Rc::new(v_p12.clone())), &t_p10, &e_pu.span_p);
                (env_p0.clone(), st3_pv.clone(), ::std::option::Option::Some(crate::check::types::Ty::TySig(mark_p4.clone(), ::std::rc::Rc::new(v_p12.clone()))))
            }
        } else {
            {
                let (t_p14, st1_p15) = crate::check::expr::infer_f(env_p0, st_p1, e_pu);
                (env_p0.clone(), crate::check::blocks::discarded_f(&st1_p15, &t_p14, &e_pu.span_p), res_o6.clone())
            }
        },
        _ => (env_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &s_p2.span_p, &crate::prelude::Text::lit("this statement belongs in a widget or `update` block")), res_o6.clone()),
    }
}

/// The step machine of `GivenStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivenStmt: unbounded fn Env, St, Stmt, [FnClause], Text, Bool, ?Ty -> ((Env, St, ?Ty))
/// ```
pub struct GivenStmt {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub s_p2: crate::syntax::Stmt,
    pub clauses_p3: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub mark_p4: crate::prelude::Text,
    pub last_p5: bool,
    pub res_o6: ::std::option::Option<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)> for GivenStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let s_p2 = &self.s_p2;
        let clauses_p3 = &self.clauses_p3;
        let mark_p4 = &self.mark_p4;
        let last_p5 = &self.last_p5;
        let res_o6 = &self.res_o6;
        match &s_p2.kind_p {
            crate::syntax::StmtKind::SBind(p_p7, e_p8, ::std::option::Option::None) => {
                let res_o6x = res_o6.clone();
                let e_p8x = e_p8.clone();
                let env_p0x = env_p0.clone();
                let mark_p4x = mark_p4.clone();
                let p_p7x = p_p7.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_p8x.clone()), move |infer_f_9333: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pa, st1_pb) = infer_f_9333;
                    let (v_pc, st2_pd) = crate::check::types::fresh_var_f(&st1_pb, &false, &crate::prelude::Text::lit(""));
                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pd.clone(), crate::check::types::Ty::TySig(mark_p4x.clone(), ::std::rc::Rc::new(v_pc.clone())), t_pa.clone(), e_p8x.span_p.clone()), move |unify_f_9417: crate::check::types::St| {
                        let st3_p9 = unify_f_9417;
                        crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(unpending_f(&env_p0x), st3_p9.clone(), p_p7x.clone(), v_pc.clone(), true), move |bind_pattern_f_9483: (crate::check::expr::Env, crate::check::types::St)| {
                            let (env2_pe, st4_pf) = bind_pattern_f_9483;
                            ::prism_rtl::Turn::Finished((env2_pe.clone(), st4_pf.clone(), res_o6x.clone()))
                        })
                    })
                })
            },
            crate::syntax::StmtKind::SRequire(c_pg) => {
                let res_o6x = res_o6.clone();
                let c_pgx = c_pg.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lifting::start_check_cond_f(env_p0x.clone(), st_p1x.clone(), c_pgx.clone()), move |check_cond_f_9580: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), check_cond_f_9580, res_o6x.clone())))
            },
            crate::syntax::StmtKind::SForbid(c_ph) => {
                let res_o6x = res_o6.clone();
                let c_phx = c_ph.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lifting::start_check_cond_f(env_p0x.clone(), st_p1x.clone(), c_phx.clone()), move |check_cond_f_9633: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), check_cond_f_9633, res_o6x.clone())))
            },
            crate::syntax::StmtKind::SLet(p_pi, ty_oj, e_pk) => {
                let res_o6x = res_o6.clone();
                let ty_ojx = ty_oj.clone();
                let e_pkx = e_pk.clone();
                let env_p0x = env_p0.clone();
                let p_pix = p_pi.clone();
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lets::start_check_let_f(env_p0x.clone(), st_p1x.clone(), p_pix.clone(), ty_ojx.clone(), e_pkx.clone(), s_p2x.span_p.clone()), move |check_let_f_9711: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2_pl, st2_pm) = check_let_f_9711;
                    ::prism_rtl::Turn::Finished((env2_pl.clone(), st2_pm.clone(), res_o6x.clone()))
                })
            },
            crate::syntax::StmtKind::SFn(f_pn) => {
                let res_o6x = res_o6.clone();
                let clauses_p3x = clauses_p3.clone();
                let env_p0x = env_p0.clone();
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lets::start_pre_bind_f(env_p0x.clone(), st_p1x.clone(), s_p2x.clone()), move |pre_bind_f_9814: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env1_po, st1_pp) = pre_bind_f_9814;
                    crate::prelude::call_then(crate::check::expr::lets::start_check_local_fn_f(env1_po.clone(), st1_pp.clone(), clauses_p3x.clone(), s_p2x.span_p.clone()), move |check_local_fn_f_9861: (crate::check::expr::Env, crate::check::types::St)| {
                        let (env2_pq, st2_pr) = check_local_fn_f_9861;
                        ::prism_rtl::Turn::Finished((env2_pq.clone(), st2_pr.clone(), res_o6x.clone()))
                    })
                })
            },
            crate::syntax::StmtKind::SSignature(_) => {
                let res_o6x = res_o6.clone();
                let env_p0x = env_p0.clone();
                let s_p2x = s_p2.clone();
                let st_p1x = st_p1.clone();
                crate::prelude::call_then(crate::check::expr::lets::start_pre_bind_f(env_p0x.clone(), st_p1x.clone(), s_p2x.clone()), move |pre_bind_f_9980: (crate::check::expr::Env, crate::check::types::St)| {
                    let (env2_ps, st2_pt) = pre_bind_f_9980;
                    ::prism_rtl::Turn::Finished((env2_ps.clone(), st2_pt.clone(), res_o6x.clone()))
                })
            },
            crate::syntax::StmtKind::SExpr(e_pu) => if *last_p5 {
                {
                    let e_pux = e_pu.clone();
                    let env_p0x = env_p0.clone();
                    let mark_p4x = mark_p4.clone();
                    let st_p1x = st_p1.clone();
                    crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_pux.clone()), move |infer_f_10086: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_p10, st1_p11) = infer_f_10086;
                        let (v_p12, st2_p13) = crate::check::types::fresh_var_f(&st1_p11, &false, &crate::prelude::Text::lit(""));
                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p13.clone(), crate::check::types::Ty::TySig(mark_p4x.clone(), ::std::rc::Rc::new(v_p12.clone())), t_p10.clone(), e_pux.span_p.clone()), move |unify_f_10178: crate::check::types::St| {
                            let st3_pv = unify_f_10178;
                            ::prism_rtl::Turn::Finished((env_p0x.clone(), st3_pv.clone(), ::std::option::Option::Some(crate::check::types::Ty::TySig(mark_p4x.clone(), ::std::rc::Rc::new(v_p12.clone())))))
                        })
                    })
                }
            } else {
                {
                    let res_o6x = res_o6.clone();
                    let e_pux = e_pu.clone();
                    let env_p0x = env_p0.clone();
                    let st_p1x = st_p1.clone();
                    crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x.clone(), st_p1x.clone(), e_pux.clone()), move |infer_f_10445: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_p14, st1_p15) = infer_f_10445;
                        crate::prelude::call_then(crate::check::blocks::start_discarded_f(st1_p15.clone(), t_p14.clone(), e_pux.span_p.clone()), move |discarded_f_10482: crate::check::types::St| ::prism_rtl::Turn::Finished((env_p0x.clone(), discarded_f_10482, res_o6x.clone())))
                    })
                }
            },
            _ => ::prism_rtl::Turn::Finished((env_p0.clone(), crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &s_p2.span_p, &crate::prelude::Text::lit("this statement belongs in a widget or `update` block")), res_o6.clone())),
        }
    }
}

/// `Start GivenStmt, x`: what the function value is when passed to `@Run`.
pub fn start_given_stmt_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, s_p2: crate::syntax::Stmt, clauses_p3: crate::prelude::Array<crate::syntax::decls::FnClause>, mark_p4: crate::prelude::Text, last_p5: bool, res_o6: ::std::option::Option<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::expr::Env, crate::check::types::St, ::std::option::Option<crate::check::types::Ty>)>> {
    ::std::rc::Rc::new(GivenStmt { env_p0, st_p1, s_p2, clauses_p3, mark_p4, last_p5, res_o6 })
}
